//! TASK-028 (ADR-031 D2): randomised invariant tests over many seeds and
//! configurations. The case generator is the engine's own seeded RNG with a
//! fixed generator seed, so every run checks the same cases and a failure is
//! reproducible from the printed config JSON, seed and tick.
//!
//! Invariants: birth/death accounting every tick, no replenishment, value
//! ranges (traits, energy, health, positions, climate), wrapping (torus
//! geometry, spatial index vs brute force across seams, climate seam
//! continuity), determinism, seed sensitivity, checkpoint split equivalence.

use evosim_core::batch::set_dotted;
use evosim_core::climate::ClimateMap;
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::rng::Rng;
use evosim_core::serde_json::{json, Value};
use evosim_core::sim::Simulation;
use evosim_core::topology::{Cell, Torus};

fn range_u(rng: &mut Rng, lo: u64, hi: u64) -> u64 {
    lo + rng.next_u64() % (hi - lo + 1)
}
fn range_f(rng: &mut Rng, lo: f64, hi: f64) -> f64 {
    lo + rng.next_f64() * (hi - lo)
}

/// Integer (key, lo, hi) and float (key, lo, hi) parameters that are varied.
const INT_KEYS: &[(&str, u64, u64)] = &[
    ("herbivores.max_litter", 1, 4),
    ("carnivores.max_litter", 1, 3),
    ("herbivores.max_speed", 1, 3),
    ("carnivores.max_speed", 1, 4),
    ("herbivores.max_vision", 1, 10),
    ("carnivores.max_vision", 1, 12),
    ("plants.dispersal_radius", 1, 5),
    ("plants.max_per_cell", 1, 4),
    ("herbivores.max_per_cell", 1, 4),
    ("carnivores.mating_cooldown", 10, 200),
    ("climate.year_length", 50, 800),
];
const FLOAT_KEYS: &[(&str, f64, f64)] = &[
    ("hunting.base_success", 0.05, 0.9),
    ("hunting.prey_density_half", 1.0, 80.0),
    ("plants.growth_rate", 0.3, 3.0),
    ("plants.seed_rate", 0.05, 1.0),
    ("herbivores.mutation_rate", 0.0, 0.5),
    ("carnivores.mutation_rate", 0.0, 0.5),
    ("plants.mutation_strength", 0.0, 0.3),
    ("climate.seasonal_amplitude", 0.0, 20.0),
    ("climate.weather_temperature_sd", 0.0, 5.0),
];

/// A random valid configuration: random world size (including 1-wide and
/// 1-high worlds), random initial counts (including zeros and crowded
/// worlds), random seed and a random subset of behaviour parameters.
fn random_config(rng: &mut Rng) -> Config {
    loop {
        let w = if rng.next_u64().is_multiple_of(8) { range_u(rng, 1, 3) } else { range_u(rng, 4, 48) } as u32;
        let h = if rng.next_u64().is_multiple_of(8) { range_u(rng, 1, 3) } else { range_u(rng, 4, 40) } as u32;
        let cells = (w * h) as u64;
        let mut count = |dens: f64| -> u32 {
            if rng.next_u64().is_multiple_of(6) {
                0
            } else {
                (range_f(rng, 0.0, dens) * cells as f64) as u32
            }
        };
        let (p, hb, c) = (count(0.6), count(0.2), count(0.05));
        let seed = rng.next_u64() >> 1;
        let mut v = Config::new(seed, w, h, p, hb, c).to_json_value();
        for &(k, lo, hi) in INT_KEYS {
            if rng.next_u64().is_multiple_of(3) {
                set_dotted(&mut v, k, json!(range_u(rng, lo, hi))).unwrap();
            }
        }
        for &(k, lo, hi) in FLOAT_KEYS {
            if rng.next_u64().is_multiple_of(3) {
                set_dotted(&mut v, k, json!(range_f(rng, lo, hi))).unwrap();
            }
        }
        if rng.next_u64().is_multiple_of(4) {
            set_dotted(&mut v, "climate.weather_enabled", json!(false)).unwrap();
        }
        if rng.next_u64().is_multiple_of(4) {
            set_dotted(&mut v, "plants.pollination_enabled", json!(false)).unwrap();
        }
        if let Ok(cfg) = Config::from_value(&v) {
            return cfg;
        }
    }
}

fn ctx(cfg: &Config, tick: u64) -> String {
    format!("config {} at tick {tick}", cfg.to_json_value())
}

/// Checks every per-state invariant; panics with the reproducing context.
fn check_state(sim: &Simulation, prev_alive: &mut [u64; 3]) {
    let cfg = sim.config();
    let t = sim.tick();
    let c = || ctx(cfg, t);
    let pop = sim.organisms();
    let tot = sim.totals();
    let torus = sim.world().torus();
    for k in Kind::ALL {
        let i = k.index();
        let alive = pop.count_alive(k) as u64;
        // accounting: initial + births - deaths == alive
        assert_eq!(tot.initial[i] + tot.births[i], tot.deaths[i] + alive, "accounting {k:?}: {}", c());
        assert_eq!(pop.alive(k).count() as u64, alive, "count_alive {k:?}: {}", c());
        // deaths by cause sum to deaths
        assert_eq!(tot.deaths_by_cause[i].iter().sum::<u64>(), tot.deaths[i], "death causes {k:?}: {}", c());
        // no replenishment: a kind at zero stays at zero
        if prev_alive[i] == 0 {
            assert_eq!(alive, 0, "{k:?} replenished: {}", c());
        }
        prev_alive[i] = alive;
        assert!(sim.living_species(k) as u64 <= alive, "species > alive {k:?}: {}", c());
        if alive > 0 {
            assert!(sim.living_species(k) >= 1, "living {k:?} without species: {}", c());
        }
        for o in pop.alive(k) {
            assert!(torus.contains(o.pos()), "organism {} outside world: {}", o.id().0, c());
            assert!(o.traits().in_range(k), "traits out of range {}: {}", o.id().0, c());
            assert!(o.energy().is_finite() && o.energy() >= 0.0 && o.energy() <= o.traits().max_energy, "energy {}: {}", o.id().0, c());
            assert!(o.health().is_finite() && o.health() >= 0.0 && o.health() <= o.traits().max_health, "health {}: {}", o.id().0, c());
            assert!(o.birth_tick() <= t, "birth in future {}: {}", o.id().0, c());
        }
    }
    pop.validate(sim.next_entity_id()).unwrap_or_else(|e| panic!("population invalid: {e}: {}", c()));
    let b = sim.world().climate_bounds();
    for cell in torus.cells() {
        let now = sim.world().current(cell);
        assert!(
            now.temperature.is_finite() && (b.t_min..=b.t_max).contains(&now.temperature),
            "temperature {} out of {b:?} at {cell:?}: {}",
            now.temperature,
            c()
        );
        assert!((b.p_min..=b.p_max).contains(&now.precipitation), "precipitation {} at {cell:?}: {}", now.precipitation, c());
    }
}

#[test]
fn accounting_ranges_no_replenishment() {
    let mut gen = Rng::seed_from_u64(0x7A5C_0028);
    let mut cases = 0;
    let mut extinctions = 0;
    for _ in 0..100 {
        let cfg = random_config(&mut gen);
        let ticks = range_u(&mut gen, 150, 400);
        let mut sim = Simulation::new(cfg).unwrap();
        let mut prev = [u64::MAX; 3];
        check_state(&sim, &mut prev);
        for _ in 0..ticks {
            sim.step();
            check_state(&sim, &mut prev);
        }
        extinctions += prev.iter().filter(|&&a| a == 0).count();
        cases += 1;
    }
    assert_eq!(cases, 100);
    // the generator must actually exercise extinct kinds (no-replenishment check)
    assert!(extinctions > 0);
}

#[test]
fn plants_zero_starves_animals_in_random_configs() {
    let mut gen = Rng::seed_from_u64(0x5EED_0005);
    for _ in 0..8 {
        let mut cfg = random_config(&mut gen);
        cfg.initial.plants = 0;
        cfg.initial.herbivores = cfg.initial.herbivores.max(1);
        cfg.initial.carnivores = cfg.initial.carnivores.max(1);
        let mut sim = Simulation::new(cfg.clone()).unwrap();
        let mut prev = [u64::MAX; 3];
        let mut ext = [None::<u64>; 3];
        for _ in 0..5000 {
            sim.step();
            check_state(&sim, &mut prev);
            for k in Kind::ALL {
                if ext[k.index()].is_none() && prev[k.index()] == 0 {
                    ext[k.index()] = Some(sim.tick());
                }
            }
            if prev[1] == 0 && prev[2] == 0 {
                break;
            }
        }
        let c = ctx(&cfg, sim.tick());
        assert_eq!(prev[0], 0, "plants appeared: {c}");
        let (h, ca) = (ext[1].unwrap_or_else(|| panic!("herbivores survive: {c}")), ext[2].unwrap_or_else(|| panic!("carnivores survive: {c}")));
        // Both animal kinds die out within the horizon (contract 5.3). Carnivores
        // may starve before the herbivores are gone, so only extinction is checked.
        assert!(h > 0 && ca > 0, "{c}");
    }
}

#[test]
fn wrapping_properties() {
    let mut gen = Rng::seed_from_u64(0x00A1_2A55);
    let mut queries = 0;
    for _ in 0..200 {
        let w = range_u(&mut gen, 1, 40) as u32;
        let h = range_u(&mut gen, 1, 40) as u32;
        let t = Torus::new(w, h).unwrap();
        for _ in 0..20 {
            let x = range_u(&mut gen, 0, (w - 1) as u64) as u32;
            let y = range_u(&mut gen, 0, (h - 1) as u64) as u32;
            let a = Cell { x, y };
            let dx = range_u(&mut gen, 0, 200) as i64 - 100;
            let dy = range_u(&mut gen, 0, 200) as i64 - 100;
            let b = t.wrap(x as i64 + dx, y as i64 + dy);
            assert!(t.contains(b));
            // wrapping by whole periods is the identity
            assert_eq!(t.wrap(x as i64 + dx * w as i64, y as i64 - dy * h as i64), a);
            // offset is the shortest displacement and reproduces b
            let o = t.offset(a, b);
            assert_eq!(t.wrap(x as i64 + o.dx as i64, y as i64 + o.dy as i64), b, "{w}x{h} {a:?} {b:?}");
            assert!(o.dx.unsigned_abs() <= w / 2 && o.dy.unsigned_abs() <= h / 2);
            let d = t.distance(a, b);
            assert_eq!(d, t.distance(b, a));
            assert_eq!(d, o.dx.unsigned_abs().max(o.dy.unsigned_abs()));
            // within(r) yields exactly the cells at distance <= r, each once
            let r = range_u(&mut gen, 0, 6) as u32;
            let mut got: Vec<Cell> = t.within(a, r).map(|(c, _)| c).collect();
            let n = got.len();
            got.sort_by_key(|c| (c.y, c.x));
            got.dedup();
            assert_eq!(got.len(), n, "duplicate cells in within {w}x{h} r={r}");
            let mut want: Vec<Cell> = t.cells().filter(|&c| t.distance(a, c) <= r).collect();
            want.sort_by_key(|c| (c.y, c.x));
            assert_eq!(got, want, "within {w}x{h} {a:?} r={r}");
            queries += 1;
        }
    }
    assert_eq!(queries, 4000);
}

#[test]
fn spatial_index_matches_brute_force_near_seams() {
    let mut gen = Rng::seed_from_u64(0x5EA_0001);
    for _ in 0..25 {
        let cfg = random_config(&mut gen);
        let mut sim = Simulation::new(cfg.clone()).unwrap();
        sim.run(range_u(&mut gen, 0, 60));
        let t = *sim.world().torus();
        let pop = sim.organisms();
        for _ in 0..30 {
            // centres biased to the seams (first/last rows/columns)
            let pick = |g: &mut Rng, n: u32| -> u32 {
                if g.next_u64().is_multiple_of(2) {
                    let e = range_u(g, 0, 1) as u32;
                    if g.next_u64().is_multiple_of(2) { e.min(n - 1) } else { (n - 1).saturating_sub(e) }
                } else {
                    range_u(g, 0, (n - 1) as u64) as u32
                }
            };
            let center = Cell { x: pick(&mut gen, t.width()), y: pick(&mut gen, t.height()) };
            let r = range_u(&mut gen, 0, 8) as u32;
            for filter in [None, Some(Kind::Plant), Some(Kind::Herbivore), Some(Kind::Carnivore)] {
                let got: Vec<(u32, u64)> = pop.within(center, r, filter).iter().map(|n| (n.distance, n.id.0)).collect();
                let mut want: Vec<(u32, u64)> = Kind::ALL
                    .iter()
                    .filter(|k| filter.is_none_or(|f| f == **k))
                    .flat_map(|&k| pop.alive(k))
                    .map(|o| (t.distance(center, o.pos()), o.id().0))
                    .filter(|&(d, _)| d <= r)
                    .collect();
                want.sort();
                assert_eq!(got, want, "within {center:?} r={r} {filter:?}: {}", ctx(&cfg, sim.tick()));
            }
        }
    }
}

#[test]
fn climate_seams_continuous_random_sizes() {
    let mut gen = Rng::seed_from_u64(0xC11_0A7E);
    for _ in 0..60 {
        let w = range_u(&mut gen, 2, 70) as u32;
        let h = range_u(&mut gen, 2, 70) as u32;
        let cfg = Config::new(gen.next_u64() >> 1, w, h, 0, 0, 0);
        let m = ClimateMap::from_config(&cfg).unwrap();
        let tb = |x: u32, y: u32| m.base_temperature(Cell { x, y });
        let pb = |x: u32, y: u32| m.base_precipitation(Cell { x, y });
        let (mut inner_t, mut inner_p, mut seam_t, mut seam_p) = (0f64, 0f64, 0f64, 0f64);
        for y in 0..h {
            for x in 0..w {
                let (nx, ny) = ((x + 1) % w, (y + 1) % h);
                let dt = (tb(x, y) - tb(nx, y)).abs().max(0.0);
                let dp = (pb(x, y) - pb(nx, y)).abs();
                if nx == 0 { seam_t = seam_t.max(dt); seam_p = seam_p.max(dp) } else { inner_t = inner_t.max(dt); inner_p = inner_p.max(dp) }
                let dt = (tb(x, y) - tb(x, ny)).abs();
                let dp = (pb(x, y) - pb(x, ny)).abs();
                if ny == 0 { seam_t = seam_t.max(dt); seam_p = seam_p.max(dp) } else { inner_t = inner_t.max(dt); inner_p = inner_p.max(dp) }
            }
        }
        assert!(seam_t <= inner_t + 1e-9 && seam_p <= inner_p + 1e-9, "{w}x{h}: seam ({seam_t},{seam_p}) > interior ({inner_t},{inner_p})");
    }
}

fn digest(sim: &Simulation) -> (String, Value) {
    let tot = sim.totals();
    (sim.state_hash(), json!([tot.initial, tot.births, tot.deaths]))
}

#[test]
fn determinism_and_seed_sensitivity() {
    let mut gen = Rng::seed_from_u64(0xDE7E_2028);
    let mut differing = 0;
    for _ in 0..24 {
        let cfg = random_config(&mut gen);
        let ticks = range_u(&mut gen, 50, 250);
        let series = |cfg: Config| {
            let mut sim = Simulation::new(cfg).unwrap();
            let mut s = Vec::new();
            for _ in 0..ticks {
                sim.step();
                s.push(Kind::ALL.map(|k| sim.organisms().count_alive(k)));
            }
            (digest(&sim), s)
        };
        let a = series(cfg.clone());
        let b = series(cfg.clone());
        assert_eq!(a, b, "not deterministic: {}", ctx(&cfg, ticks));
        let other = cfg.clone().with_seed(cfg.seed ^ 0x9E37_79B9);
        let c = series(other);
        assert_ne!(a.0 .0, c.0 .0, "different seed, same state_hash: {}", ctx(&cfg, ticks));
        differing += 1;
    }
    assert_eq!(differing, 24);
}

#[test]
fn checkpoint_split_equivalence() {
    let mut gen = Rng::seed_from_u64(0xC4EC_0028);
    for _ in 0..20 {
        let cfg = random_config(&mut gen);
        let a = range_u(&mut gen, 0, 150);
        let b = range_u(&mut gen, 0, 150);
        let mut whole = Simulation::new(cfg.clone()).unwrap();
        whole.run(a + b);
        let mut first = Simulation::new(cfg.clone()).unwrap();
        first.run(a);
        let text = first.checkpoint_json().unwrap();
        let mut second = Simulation::from_checkpoint_json(&text).unwrap();
        assert_eq!(second.state_hash(), first.state_hash(), "restore changed state: {}", ctx(&cfg, a));
        second.run(b);
        assert_eq!(second.tick(), a + b);
        assert_eq!(digest(&second), digest(&whole), "A={a} + B={b} != uninterrupted: {}", ctx(&cfg, a + b));
    }
}

use super::*;
use crate::config::Config;
use crate::organism::Kind;
use crate::rng::Rng;
use crate::sim::Simulation;

#[test]
fn sha256_fips_vectors() {
    assert_eq!(hex(&Sha256::digest(b"")), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855");
    assert_eq!(hex(&Sha256::digest(b"abc")), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    assert_eq!(
        hex(&Sha256::digest(b"abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq")),
        "248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1"
    );
    assert_eq!(
        hex(&Sha256::digest(&vec![b'a'; 1_000_000])),
        "cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0"
    );
    // Cross-checked with Python hashlib: sha256(bytes(range(256)) * 3).
    let data: Vec<u8> = (0..3).flat_map(|_| 0..=255u8).collect();
    assert_eq!(hex(&Sha256::digest(&data)), "f3a25aa93aa2fbba28d79260535bbd6a5eb0fc1c24a8b0f04e12b484c1dfe363");
}

#[test]
fn sha256_streaming_equals_one_shot() {
    let data: Vec<u8> = (0..130u32).map(|i| (i * 7 + 3) as u8).collect();
    let one = Sha256::digest(&data);
    for split in 0..=data.len() {
        let mut s = Sha256::new();
        s.update(&data[..split]);
        s.update(&data[split..]);
        assert_eq!(s.finalize(), one, "split {split}");
    }
    // byte-by-byte
    let mut s = Sha256::new();
    for b in &data {
        s.update(std::slice::from_ref(b));
    }
    assert_eq!(s.finalize(), one);
}

#[test]
fn hasher_sections_and_lengths_do_not_alias() {
    let mut a = StateHasher::new();
    a.str("ab");
    a.str("c");
    let mut b = StateHasher::new();
    b.str("a");
    b.str("bc");
    assert_ne!(a.finish_hex(), b.finish_hex());
    let mut a = StateHasher::new();
    a.f64(0.0);
    let mut b = StateHasher::new();
    b.f64(-0.0);
    assert_ne!(a.finish_hex(), b.finish_hex());
}

fn small(seed: u64) -> Config {
    Config::new(seed, 24, 18, 80, 24, 6)
}

fn stepped(seed: u64, n: u64) -> Simulation {
    let mut s = Simulation::new(small(seed)).unwrap();
    for _ in 0..n {
        s.step();
    }
    s
}

#[test]
fn state_hash_is_64_lower_hex_and_deterministic() {
    let a = stepped(5, 40);
    let b = stepped(5, 40);
    let h = a.state_hash();
    assert_eq!(h.len(), 64);
    assert!(h.chars().all(|c| c.is_ascii_digit() || ('a'..='f').contains(&c)));
    assert_eq!(h, b.state_hash());
    assert_eq!(h, a.clone().state_hash());
}

#[test]
fn state_hash_differs_for_seeds_and_ticks() {
    assert_ne!(stepped(1, 30).state_hash(), stepped(2, 30).state_hash());
    let mut s = Simulation::new(small(3)).unwrap();
    let h0 = s.state_hash();
    s.step();
    assert_ne!(h0, s.state_hash());
}

#[test]
fn empty_world_hash_still_changes_with_clock() {
    let mut s = Simulation::new(Config::new(1, 8, 8, 0, 0, 0)).unwrap();
    let mut seen = std::collections::BTreeSet::new();
    for _ in 0..5 {
        assert!(seen.insert(s.state_hash()));
        s.step();
    }
}

fn first_alive(s: &Simulation, k: Kind) -> crate::ids::EntityId {
    s.organisms().alive(k).next().expect("organism of kind").id()
}

/// Each mutation is applied to a fresh, identical copy; every one must change
/// the hash (and two copies without mutation must not).
#[test]
fn state_hash_is_sensitive_to_every_state_part() {
    let base = stepped(9, 25);
    let h = base.state_hash();
    type Mutation = (&'static str, Box<dyn Fn(&mut Simulation)>);
    let muts: Vec<Mutation> = vec![
        ("energy +1 ulp", Box::new(|s| {
            let id = first_alive(s, Kind::Herbivore);
            let o = s.organisms_mut().get_alive_mut(id).unwrap();
            let e = o.energy();
            o.set_energy(f64::from_bits(e.to_bits() + 1));
        })),
        ("position", Box::new(|s| {
            let id = first_alive(s, Kind::Plant);
            let o = s.organisms_mut().get_alive_mut(id).unwrap();
            let p = o.pos();
            o.set_pos(crate::topology::Cell { x: (p.x + 1) % 24, y: p.y });
        })),
        ("gene ulp", Box::new(|s| {
            let id = first_alive(s, Kind::Carnivore);
            s.organisms_mut().get_alive_mut(id).unwrap().nudge_gene_for_test(3);
        })),
        ("cooldown", Box::new(|s| {
            let id = first_alive(s, Kind::Herbivore);
            let o = s.organisms_mut().get_alive_mut(id).unwrap();
            let c = o.cooldown();
            o.set_cooldown(c + 1);
        })),
        ("heading", Box::new(|s| {
            let id = first_alive(s, Kind::Herbivore);
            let o = s.organisms_mut().get_alive_mut(id).unwrap();
            let h = o.heading();
            o.set_heading(if h == Some(crate::topology::Dir8::N) { Some(crate::topology::Dir8::S) } else { Some(crate::topology::Dir8::N) });
        })),
        ("rng state", Box::new(|s| {
            s.set_rng_state(Rng::seed_from_u64(12345).state()).unwrap();
        })),
        ("weather value", Box::new(|s| {
            let mut w = s.weather_state();
            w.temperature[0] += 0.25;
            s.set_weather_state(w).unwrap();
        })),
        ("resource cell", Box::new(|s| {
            let r = s.world_mut_for_test().resources_mut_for_test();
            r.values_mut()[5] += 1e-9;
        })),
        ("species record", Box::new(|s| {
            s.organisms_mut().species_mut_for_test().bump_first_ever_for_test();
        })),
        ("totals counter", Box::new(|s| {
            s.organisms_mut().totals_mut_for_test().deaths_by_cause[0][0] += 1;
        })),
        ("config parameter", Box::new(|s| {
            s.config_mut_for_test().plants.growth_rate += 0.001;
        })),
    ];
    let mut seen = std::collections::BTreeSet::new();
    seen.insert(h.clone());
    for (name, m) in muts {
        let mut s = base.clone();
        assert_eq!(s.state_hash(), h);
        m(&mut s);
        let h2 = s.state_hash();
        assert_ne!(h2, h, "mutation '{name}' did not change the hash");
        assert!(seen.insert(h2), "mutation '{name}' collided");
    }
}

#[test]
fn state_hash_sensitive_to_next_id_and_tick() {
    let base = Simulation::new(small(4)).unwrap();
    let r = base.rng_state();
    let a = Simulation::resume(small(4), 0, r, base.next_entity_id()).unwrap();
    assert_eq!(a.state_hash(), base.state_hash());
    let b = Simulation::resume(small(4), 0, r, base.next_entity_id() + 1).unwrap();
    assert_ne!(b.state_hash(), base.state_hash());
    let c = Simulation::resume(small(4), 1, r, base.next_entity_id()).unwrap();
    assert_ne!(c.state_hash(), base.state_hash());
}

/// The state hash streams derived `Debug` text (ADR-022 §5); a manual
/// `Debug` impl could hide fields, so none may exist in core.
#[test]
fn core_has_no_manual_debug_impls() {
    let src = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    let mut stack = vec![src];
    let pats = [concat!("Debug", " for "), concat!("fmt::Debug", " for")];
    while let Some(d) = stack.pop() {
        for e in std::fs::read_dir(&d).unwrap() {
            let p = e.unwrap().path();
            if p.is_dir() {
                stack.push(p);
            } else if p.extension().is_some_and(|x| x == "rs") {
                let t = std::fs::read_to_string(&p).unwrap();
                for pat in pats {
                    assert!(!t.contains(pat), "{} has a manual Debug impl", p.display());
                }
            }
        }
    }
}

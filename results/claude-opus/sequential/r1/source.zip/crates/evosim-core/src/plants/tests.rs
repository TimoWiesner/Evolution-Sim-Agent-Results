//! TASK-011 tests (ADR-014): growth depends on temperature and water,
//! limited shared resources, ageing and death, energy ledger, genome traits.

use super::*;
use crate::climate::CellNow;
use crate::config::{Config, PlantParams};
use crate::genome::{express, gene_index, Expression, Genome, GeneTrait};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRequest, DeathCause, Kind, Parents, Population, Traits};
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Torus};

fn calm_cfg(seed: u64, plants: u32) -> Config {
    let mut c = Config::new(seed, 24, 20, plants, 0, 0);
    c.climate.weather_enabled = false;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.noise_temperature = 0.0;
    c.climate.noise_precipitation = 0.0;
    c.plants.founder_variation = 0.0;
    // Growth tests stay isolated from reproduction (TASK-012, ADR-015).
    c.plants.seed_rate = 0.0;
    c
}

fn default_traits() -> Traits {
    Traits::founder_default(Kind::Plant, &Config::new(1, 8, 8, 0, 0, 0))
}

fn genome_with(changes: &[(GeneTrait, f32)]) -> Genome {
    let mut g = Genome::founder_default(Kind::Plant).genes().to_vec();
    for &(t, v) in changes {
        g[gene_index(Kind::Plant, t).unwrap()] = v;
    }
    Genome::from_genes(Kind::Plant, g).unwrap()
}

/// Standalone population on a 4×1 torus with plants (genome, cell x, energy).
fn pop_with(torus: Torus, plants: &[(Genome, u32, f64)]) -> Population {
    let mut p = Population::with_expression(Expression::default(), torus);
    for (g, x, e) in plants {
        p.request_birth(BirthRequest { pos: Cell { x: *x, y: 0 }, parents: Parents::None, energy: *e, health: None, genome: g.clone() });
    }
    let mut ids = IdAllocator::new();
    p.resolve_births(0, &mut ids);
    p
}

fn energies(p: &Population) -> Vec<f64> {
    p.alive(Kind::Plant).map(|o| o.energy()).collect()
}

fn ideal(t: &Traits) -> CellNow {
    CellNow { temperature: t.temp_optimum, precipitation: 1.0 }
}

// ---------- AC1/AC2: gain depends on current temperature and water ----------

#[test]
fn growth_depends_on_temperature_and_water() {
    let p = PlantParams::default();
    let t = default_traits();
    let fav = potential_gain(&t, ideal(&t), 1.0, &p);
    assert!(fav > 0.5, "favourable gain {fav}");
    let cool = potential_gain(&t, CellNow { temperature: t.temp_optimum - 0.9 * t.temp_tolerance, precipitation: 1.0 }, 1.0, &p);
    assert!(cool > 0.0 && cool < fav, "cool {cool} fav {fav}");
    let too_cold = potential_gain(&t, CellNow { temperature: t.temp_optimum - t.temp_tolerance - 0.1, precipitation: 1.0 }, 1.0, &p);
    assert_eq!(too_cold, 0.0);
    let too_hot = potential_gain(&t, CellNow { temperature: t.temp_optimum + t.temp_tolerance, precipitation: 1.0 }, 1.0, &p);
    assert_eq!(too_hot, 0.0);
    let half_dry = potential_gain(&t, CellNow { temperature: t.temp_optimum, precipitation: 0.3 }, 1.0, &p);
    assert!(half_dry > 0.0 && half_dry < fav, "half dry {half_dry}");
    let dry = potential_gain(&t, CellNow { temperature: t.temp_optimum, precipitation: 0.05 }, 1.0, &p);
    assert_eq!(dry, 0.0);
    // Monotone in temperature distance and in moisture.
    let mut last = f64::INFINITY;
    for k in 0..=20 {
        let g = potential_gain(&t, CellNow { temperature: t.temp_optimum - k as f64, precipitation: 1.0 }, 1.0, &p);
        assert!(g <= last + 1e-12);
        last = g;
    }
    let mut last = -1.0;
    for k in 0..=20 {
        let g = potential_gain(&t, CellNow { temperature: t.temp_optimum, precipitation: k as f64 / 20.0 }, 1.0, &p);
        assert!(g >= last - 1e-12);
        last = g;
    }
}

#[test]
fn same_plant_grows_less_in_cold_or_dry_cell_standalone() {
    let p = PlantParams::default();
    let torus = Torus::new(3, 1).unwrap();
    let g = Genome::founder_default(Kind::Plant);
    let mut pop = pop_with(torus, &[(g.clone(), 0, 5.0), (g.clone(), 1, 5.0), (g, 2, 5.0)]);
    let t = *pop.alive(Kind::Plant).next().unwrap().traits();
    let now = [ideal(&t), CellNow { temperature: t.temp_optimum - t.temp_tolerance * 1.2, precipitation: 1.0 }, CellNow { temperature: t.temp_optimum, precipitation: 0.02 }];
    let mut res = CellResources::new(&torus, p.resource_cap);
    for tick in 0..5 {
        res.regenerate(&now, &p, 1.0);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, tick);
    }
    let e = energies(&pop);
    assert!(e[0] > 5.0, "favourable plant grows: {e:?}");
    assert!(e[1] < 5.0 && e[2] < 5.0, "cold/dry plants do not grow: {e:?}");
    // Stressed plants lose health, favourable one stays healthy.
    let h: Vec<f64> = pop.alive(Kind::Plant).map(|o| o.health()).collect();
    assert_eq!(h[0], t.max_health);
    assert!(h[1] < t.max_health && h[2] < t.max_health);
}

#[test]
fn same_plant_grows_less_in_cold_or_dry_cell_sim() {
    let mut c = calm_cfg(7, 3);
    c.plants.max_age = 10_000;
    let mut sim = Simulation::new(c.clone()).unwrap();
    let grid = sim.world().current_grid().to_vec();
    let w = c.world.width as usize;
    let ids = sim.organisms().alive_ids(Kind::Plant);
    let t = *sim.organisms().get(ids[0]).unwrap().traits();
    let m = |cn: &CellNow| moisture(cn.precipitation, c.climate.max_precipitation);
    let score = |i: usize| (grid[i].temperature - t.temp_optimum).abs() - 10.0 * m(&grid[i]);
    let fav = (0..grid.len()).min_by(|&a, &b| score(a).total_cmp(&score(b))).unwrap();
    let cold = (0..grid.len()).min_by(|&a, &b| grid[a].temperature.total_cmp(&grid[b].temperature)).unwrap();
    let dry = (0..grid.len())
        .filter(|&i| (grid[i].temperature - t.temp_optimum).abs() < t.temp_tolerance * 0.5)
        .min_by(|&a, &b| m(&grid[a]).total_cmp(&m(&grid[b])))
        .unwrap();
    assert!(grid[cold].temperature < t.temp_optimum - t.temp_tolerance, "cold cell {:?}", grid[cold]);
    assert!(m(&grid[dry]) < m(&grid[fav]) && m(&grid[dry]) < c.plants.water_optimum, "dry {:?} fav {:?}", grid[dry], grid[fav]);
    let cell = |i: usize| Cell { x: (i % w) as u32, y: (i / w) as u32 };
    for (id, i) in ids.iter().zip([fav, cold, dry]) {
        sim.organisms_mut().move_organism(*id, cell(i)).unwrap();
        sim.organisms_mut().get_alive_mut(*id).unwrap().set_energy(5.0);
    }
    sim.run(8);
    let e: Vec<f64> = ids.iter().map(|id| sim.organisms().get(*id).map(|o| o.energy()).unwrap_or(0.0)).collect();
    assert!(e[0] > 5.0, "favourable grows {e:?}");
    assert!(e[0] > e[1] && e[0] > e[2], "favourable > cold, dry {e:?}");
    assert!(e[1] < 5.0, "too cold: no growth {e:?}");
    assert!(e[2] - 5.0 < (e[0] - 5.0) * 0.8, "dry grows clearly slower {e:?}");
}

// ---------- AC3: limited resources, competition ----------

#[test]
fn resources_limited_and_shared() {
    let p = PlantParams { resource_regen: 0.5, resource_cap: 2.0, upkeep: 0.0, ..Config::pre_task018_plants() };
    let torus = Torus::new(2, 1).unwrap();
    let g = Genome::founder_default(Kind::Plant);
    let mut solo = pop_with(torus, &[(g.clone(), 0, 1.0)]);
    let mut crowd = pop_with(torus, &[(g.clone(), 0, 1.0), (g.clone(), 0, 1.0), (g.clone(), 0, 1.0), (g, 0, 1.0)]);
    let t = *solo.alive(Kind::Plant).next().unwrap().traits();
    let now = [ideal(&t), ideal(&t)];
    let mut rs = CellResources::new(&torus, p.resource_cap);
    let mut rc = CellResources::new(&torus, p.resource_cap);
    for tick in 0..30 {
        rs.regenerate(&now, &p, 1.0);
        let before = rc.get(Cell { x: 0, y: 0 });
        rc.regenerate(&now, &p, 1.0);
        let avail = rc.get(Cell { x: 0, y: 0 });
        assert!(avail <= p.resource_cap && avail >= before);
        let gs = grow_plants(&mut solo, &mut rs, &now, &torus, &p, 1.0, tick);
        let gc = grow_plants(&mut crowd, &mut rc, &now, &torus, &p, 1.0, tick);
        assert!(gc.uptake <= avail + 1e-12, "uptake bounded by the cell's resource");
        assert!(gs.uptake <= 1.0 + 1e-12);
        for v in rc.values().iter().chain(rs.values()) {
            assert!((0.0..=p.resource_cap).contains(v));
        }
    }
    let es = energies(&solo)[0];
    let ec = energies(&crowd);
    // After depletion, the crowd shares 0.5/tick: each plant gains far less.
    assert!(ec.iter().all(|&e| e < es), "solo {es} crowd {ec:?}");
    let total: f64 = ec.iter().map(|e| e - 1.0).sum();
    assert!(total <= p.resource_cap + 30.0 * p.resource_regen + 1e-9, "total gain {total} bounded by cap + regen");
    // Equal plants get equal shares.
    assert!(ec.windows(2).all(|w| (w[0] - w[1]).abs() < 1e-12));
}

#[test]
fn growth_saturates_at_max_energy() {
    let p = PlantParams { upkeep: 0.0, ..PlantParams::default() };
    let torus = Torus::new(1, 1).unwrap();
    let mut pop = pop_with(torus, &[(Genome::founder_default(Kind::Plant), 0, 1.0)]);
    let t = *pop.alive(Kind::Plant).next().unwrap().traits();
    let now = [ideal(&t)];
    let mut res = CellResources::new(&torus, p.resource_cap);
    for tick in 0..200 {
        res.regenerate(&now, &p, 1.0);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, tick);
    }
    assert_eq!(energies(&pop)[0], t.max_energy);
    assert_eq!(res.get(Cell { x: 0, y: 0 }), p.resource_cap, "full plant takes nothing");
}

#[test]
fn fair_share_is_order_independent() {
    let p = PlantParams { resource_cap: 1.0, ..PlantParams::default() };
    let torus = Torus::new(1, 1).unwrap();
    let a = genome_with(&[(GeneTrait::TempTolerance, 0.2)]);
    let b = genome_with(&[(GeneTrait::TempTolerance, 0.8)]);
    let run = |order: &[(Genome, u32, f64)]| {
        let mut pop = pop_with(torus, order);
        let now = [CellNow { temperature: 10.0, precipitation: 1.0 }];
        let mut res = CellResources::new(&torus, p.resource_cap);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, 0);
        let mut v: Vec<(u64, f64)> = pop.alive(Kind::Plant).map(|o| (o.traits().temp_tolerance.to_bits(), o.energy())).collect();
        v.sort_by_key(|x| x.0);
        (v, res.get(Cell { x: 0, y: 0 }))
    };
    let r1 = run(&[(a.clone(), 0, 2.0), (b.clone(), 0, 2.0), (a.clone(), 0, 2.0)]);
    let r2 = run(&[(b, 0, 2.0), (a.clone(), 0, 2.0), (a, 0, 2.0)]);
    assert_eq!(r1, r2);
    assert!(r1.1 < 1e-12, "scarce resource fully shared out");
}

// ---------- AC3/AC5: energy ledger, no energy without a source ----------

fn plant_energy(sim: &Simulation) -> f64 {
    sim.organisms().alive(Kind::Plant).map(|o| o.energy()).sum()
}

#[test]
fn energy_ledger_balances() {
    let c = Config::new(11, 32, 24, 200, 0, 0);
    let mut sim = Simulation::new(c).unwrap();
    let r0 = sim.world().resources().total();
    for _ in 0..200 {
        let mut snaps = (0.0, 0.0, 0.0, 0.0);
        sim.step_with(|ctx| match ctx.phase {
            Phase::Resources => {
                snaps.0 = ctx.world.resources().total();
                snaps.1 = ctx.world.organisms().alive(Kind::Plant).map(|o| o.energy()).sum();
            }
            Phase::Plants => {
                snaps.2 = ctx.world.resources().total();
                let l = ctx.world.plant_ledger();
                // energy after = before + uptake - upkeep; uptake = resource removed.
                snaps.3 = ctx.world.organisms().stored(Kind::Plant).iter().map(|o| o.energy()).sum::<f64>();
                let removed = snaps.0 - snaps.2;
                assert!((removed - l.last_uptake).abs() < 1e-9, "removed {removed} uptake {}", l.last_uptake);
                let de = snaps.3 - snaps.1;
                // TASK-012: reproduction runs in the same phase and removes energy too.
                assert!((de - (l.last_uptake - l.last_upkeep - l.last_reproduction_spent)).abs() < 1e-9, "energy change {de}");
            }
            _ => {}
        });
        let l = sim.world().plant_ledger();
        let lhs = sim.world().resources().total();
        let rhs = r0 + l.regen_added - l.uptake;
        assert!((lhs - rhs).abs() <= 1e-9 * r0.max(1.0), "{lhs} vs {rhs}");
        for v in sim.world().resources().values() {
            assert!((0.0..=sim.world().resources().cap()).contains(v));
        }
    }
    assert!(sim.world().plant_ledger().uptake > 0.0);
    let _ = plant_energy(&sim);
}

#[test]
fn no_resource_no_growth() {
    let mut c = calm_cfg(3, 60);
    c.plants.resource_cap = 0.0;
    c.plants.resource_regen = 0.0;
    c.plants.max_age = 10_000;
    let mut sim = Simulation::new(c).unwrap();
    let start: Vec<(EntityId, f64)> = sim.organisms().alive(Kind::Plant).map(|o| (o.id(), o.energy())).collect();
    for _ in 0..60 {
        let before: Vec<(EntityId, f64)> = sim.organisms().alive(Kind::Plant).map(|o| (o.id(), o.energy())).collect();
        sim.step();
        for (id, e) in before {
            if let Some(o) = sim.organisms().get_alive(id) {
                assert!(o.energy() <= e, "energy appeared without a source");
            }
        }
    }
    assert_eq!(sim.world().plant_ledger().uptake, 0.0);
    assert_eq!(sim.organisms().count_alive(Kind::Plant), 0);
    let t = sim.totals();
    assert_eq!(t.deaths_of(Kind::Plant), start.len() as u64);
    assert!(t.deaths_by(Kind::Plant, DeathCause::Starvation) > 0);
}

// ---------- AC4: ageing and death ----------

#[test]
fn plants_die_of_old_age() {
    let mut c = calm_cfg(5, 1);
    c.plants.max_age = 12;
    let mut sim = Simulation::new(c.clone()).unwrap();
    let id = sim.organisms().alive_ids(Kind::Plant)[0];
    let t = *sim.organisms().get(id).unwrap().traits();
    assert!(t.max_lifespan <= 12);
    // Put it in the most favourable cell and keep it fed.
    let grid = sim.world().current_grid().to_vec();
    let w = c.world.width as usize;
    let best = (0..grid.len())
        .min_by(|&a, &b| ((grid[a].temperature - t.temp_optimum).abs() - 10.0 * grid[a].precipitation).total_cmp(&((grid[b].temperature - t.temp_optimum).abs() - 10.0 * grid[b].precipitation)))
        .unwrap();
    sim.organisms_mut().move_organism(id, Cell { x: (best % w) as u32, y: (best / w) as u32 }).unwrap();
    sim.run(t.max_lifespan as u64 + 1);
    assert_eq!(sim.totals().deaths_by(Kind::Plant, DeathCause::OldAge), 1);
}

#[test]
fn plants_starve_without_resources() {
    let p = Config::pre_task018_plants();
    let torus = Torus::new(1, 1).unwrap();
    let mut pop = pop_with(torus, &[(Genome::founder_default(Kind::Plant), 0, 1.0)]);
    let t = *pop.alive(Kind::Plant).next().unwrap().traits();
    let now = [ideal(&t)];
    let mut res = CellResources::new(&torus, 0.0);
    let mut tick = 0;
    while pop.count_alive(Kind::Plant) > 0 && tick < 100 {
        res.regenerate(&now, &p, 1.0);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, tick);
        pop.end_of_tick(tick);
        tick += 1;
    }
    assert_eq!(pop.totals().deaths_by(Kind::Plant, DeathCause::Starvation), 1);
    assert!(tick <= 10, "starved after {tick} ticks");
}

#[test]
fn plants_die_in_hostile_climate() {
    let p = PlantParams::default();
    let torus = Torus::new(2, 1).unwrap();
    let g = Genome::founder_default(Kind::Plant);
    let mut pop = pop_with(torus, &[(g.clone(), 0, 20.0), (g, 1, 20.0)]);
    let t = *pop.alive(Kind::Plant).next().unwrap().traits();
    let now = [
        CellNow { temperature: t.temp_optimum - 3.0 * t.temp_tolerance, precipitation: 1.0 },
        CellNow { temperature: t.temp_optimum, precipitation: 0.0 },
    ];
    let mut res = CellResources::new(&torus, p.resource_cap);
    for tick in 0..30 {
        res.regenerate(&now, &p, 1.0);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, tick);
        pop.end_of_tick(tick);
    }
    assert_eq!(pop.totals().deaths_by(Kind::Plant, DeathCause::Climate), 2, "cold and drought kill");
    assert!(pop.last_deaths().is_empty() || pop.totals().deaths_of(Kind::Plant) == 2);
}

#[test]
fn hostile_climate_deaths_reported_in_sim() {
    let mut c = calm_cfg(9, 40);
    c.climate.pole_temperature = -60.0;
    c.climate.equator_temperature = -40.0;
    let mut sim = Simulation::new(c).unwrap();
    let mut climate_events = 0;
    for _ in 0..30 {
        let rep = sim.step();
        climate_events += rep
            .events
            .iter()
            .filter(|e| matches!(e.kind, crate::sim::EventKind::Death { cause: DeathCause::Climate, .. }))
            .count();
    }
    assert_eq!(sim.organisms().count_alive(Kind::Plant), 0);
    assert_eq!(climate_events, 40);
}

#[test]
fn health_recovers_when_unstressed() {
    let p = PlantParams::default();
    let torus = Torus::new(1, 1).unwrap();
    let mut pop = pop_with(torus, &[(Genome::founder_default(Kind::Plant), 0, 10.0)]);
    let id = pop.alive_ids(Kind::Plant)[0];
    let t = *pop.get(id).unwrap().traits();
    pop.get_alive_mut(id).unwrap().set_health(t.max_health * 0.5);
    let now = [ideal(&t)];
    let mut res = CellResources::new(&torus, p.resource_cap);
    grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, 0);
    let h = pop.get(id).unwrap().health();
    assert!((h - t.max_health * (0.5 + p.heal_rate)).abs() < 1e-9);
}

// ---------- AC6: genome-derived traits ----------

#[test]
fn genome_traits_change_growth() {
    let p = PlantParams::default();
    let e = Expression::default();
    let warm = express(&genome_with(&[(GeneTrait::TempOptimum, 0.8)]), &e);
    let cool = express(&genome_with(&[(GeneTrait::TempOptimum, 0.3)]), &e);
    let hot_cell = CellNow { temperature: warm.temp_optimum, precipitation: 1.0 };
    assert!(potential_gain(&warm, hot_cell, 1.0, &p) > potential_gain(&cool, hot_cell, 1.0, &p));
    // Tolerance: wide survives/grows where narrow cannot, but has a lower peak.
    let narrow = express(&genome_with(&[(GeneTrait::TempTolerance, 0.1)]), &e);
    let wide = express(&genome_with(&[(GeneTrait::TempTolerance, 0.9)]), &e);
    let off = CellNow { temperature: narrow.temp_optimum - narrow.temp_tolerance * 1.5, precipitation: 1.0 };
    assert_eq!(potential_gain(&narrow, off, 1.0, &p), 0.0);
    assert!(potential_gain(&wide, off, 1.0, &p) > 0.0);
    assert!(stress(&narrow, off, 1.0, &p) > 0.0 && stress(&wide, off, 1.0, &p) == 0.0);
    let opt = CellNow { temperature: narrow.temp_optimum, precipitation: 1.0 };
    assert!(potential_gain(&narrow, opt, 1.0, &p) > potential_gain(&wide, opt, 1.0, &p), "generalist cost");
    // Strength raises upkeep; max_energy gene raises storage.
    let weak = express(&genome_with(&[(GeneTrait::Strength, 0.1)]), &e);
    let strong = express(&genome_with(&[(GeneTrait::Strength, 0.9)]), &e);
    assert!(upkeep_cost(&strong, &p) > upkeep_cost(&weak, &p));
    // In a simulation-like run the two tolerance genomes diverge in a cold cell.
    let torus = Torus::new(1, 1).unwrap();
    let mut pop = pop_with(torus, &[(genome_with(&[(GeneTrait::TempTolerance, 0.1)]), 0, 10.0), (genome_with(&[(GeneTrait::TempTolerance, 0.9)]), 0, 10.0)]);
    let now = [off];
    let mut res = CellResources::new(&torus, p.resource_cap);
    for tick in 0..40 {
        res.regenerate(&now, &p, 1.0);
        grow_plants(&mut pop, &mut res, &now, &torus, &p, 1.0, tick);
        pop.end_of_tick(tick);
    }
    let alive: Vec<f64> = pop.alive(Kind::Plant).map(|o| o.traits().temp_tolerance).collect();
    assert_eq!(alive, vec![wide.temp_tolerance], "only the tolerant genome survives the cold cell");
}

// ---------- determinism ----------

#[test]
fn plant_growth_uses_no_core_rng() {
    // Growth alone draws nothing; reproduction (TASK-012) is disabled here.
    let mut a = Config::new(21, 20, 16, 0, 0, 0);
    let mut b = Config::new(21, 20, 16, 150, 0, 0);
    a.plants.seed_rate = 0.0;
    b.plants.seed_rate = 0.0;
    let mut sa = Simulation::new(a).unwrap();
    let mut sb = Simulation::new(b).unwrap();
    sa.run(50);
    sb.run(50);
    assert_eq!(sa.rng_state(), sb.rng_state());
    assert!(sb.world().plant_ledger().uptake > 0.0);
}

#[test]
fn identical_runs_identical_plants_and_resources() {
    let c = Config::new(33, 20, 16, 120, 0, 0);
    let mut a = Simulation::new(c.clone()).unwrap();
    let mut b = Simulation::new(c).unwrap();
    a.run(80);
    b.run(80);
    assert_eq!(a.world().resources(), b.world().resources());
    assert_eq!(a.world().plant_ledger(), b.world().plant_ledger());
    assert_eq!(a.organisms(), b.organisms());
}

#[test]
fn resource_set_is_clamped() {
    let torus = Torus::new(2, 2).unwrap();
    let mut r = CellResources::new(&torus, 3.0);
    r.set(Cell { x: 1, y: 1 }, 99.0);
    assert_eq!(r.get(Cell { x: 1, y: 1 }), 3.0);
    r.set(Cell { x: 1, y: 1 }, -1.0);
    assert_eq!(r.get(Cell { x: 1, y: 1 }), 0.0);
    assert_eq!(r.total(), 9.0);
    assert_eq!(moisture(0.5, 0.0), 0.0);
    assert_eq!(moisture(2.0, 1.0), 1.0);
}

//! The three organism kinds (ADR-011).

/// Kind of organism. `Kind::ALL` order is the processing order of founder
/// creation, Births and Deaths.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize, serde::Deserialize)]
pub enum Kind {
    Plant,
    Herbivore,
    Carnivore,
}

impl Kind {
    pub const ALL: [Kind; 3] = [Kind::Plant, Kind::Herbivore, Kind::Carnivore];

    /// 0 = plants, 1 = herbivores, 2 = carnivores.
    pub fn index(self) -> usize {
        match self {
            Kind::Plant => 0,
            Kind::Herbivore => 1,
            Kind::Carnivore => 2,
        }
    }

    /// Contract key (`plants|herbivores|carnivores`).
    pub fn name(self) -> &'static str {
        match self {
            Kind::Plant => "plants",
            Kind::Herbivore => "herbivores",
            Kind::Carnivore => "carnivores",
        }
    }

    pub fn is_animal(self) -> bool {
        self != Kind::Plant
    }
}

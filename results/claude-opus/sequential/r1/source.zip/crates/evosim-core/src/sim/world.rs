//! The simulated world: toroidal grid, static base climate (TASK-006) and
//! the current seasonal + weather climate (TASK-007) and the organisms
//! (TASK-008) and the soil resource per cell with its ledger (TASK-011).

use crate::climate::{combine, year_phase, CellNow, ClimateBounds, ClimateMap, Weather, WeatherError, WeatherState};
use crate::config::{ClimateParams, Config, PlantParams};
use crate::genome::Expression;
use crate::organism::Population;
use crate::plants::{grow_plants, reproduce_plants, CellResources, GrowthTick, PlantLedger, ReproTick};
use crate::animals::{act_carnivores, act_herbivores, reproduce_animals, ReproLedger, FeedTick, HerbivoreLedger, HuntLedger, HuntTick, MoveTick};
use crate::organism::Kind;
use crate::rng::Rng;
use crate::topology::{Cell, TopologyError, Torus};

#[derive(Debug, Clone)]
pub struct World {
    torus: Torus,
    climate: ClimateMap,
    bounds: ClimateBounds,
    /// Weather lattices: the only climate state carried over between ticks.
    weather: Weather,
    /// Current climate per cell (row-major), derived from base map,
    /// `climate_tick` and `weather`.
    now: Vec<CellNow>,
    climate_tick: u64,
    /// All organisms (ADR-011).
    organisms: Population,
    /// Soil resource per cell, the only plant energy source (ADR-014).
    resources: CellResources,
    /// Audit of plant energy flows (ADR-014).
    plant_ledger: PlantLedger,
    /// Movement summary of the last Herbivores / Carnivores phase (ADR-016).
    last_moves: [MoveTick; 2],
    /// Herbivore feeding audit (ADR-017).
    herbivore_ledger: HerbivoreLedger,
    hunt_ledger: HuntLedger,
    repro_ledger: [ReproLedger; 2],
    /// Snapshot of the last Statistics phase (ADR-021).
    stats: crate::sim::stats::TickStats,
}

impl World {
    /// Builds the grid and its base climate. The climate is a pure function of
    /// the configuration and uses its own generator (the core RNG is untouched).
    /// The current grid describes tick 0 with zero weather.
    pub fn from_config(config: &Config) -> Result<World, TopologyError> {
        let torus = Torus::new(config.world.width, config.world.height)?;
        let climate = ClimateMap::generate(&torus, &config.climate, config.seed);
        let weather = Weather::new(torus.width(), torus.height(), &config.climate);
        let bounds = climate.bounds();
        let mut w = World { torus, climate, bounds, weather, now: Vec::new(), climate_tick: 0, organisms: Population::with_expression(Expression::from_config(config), torus), resources: CellResources::new(&torus, config.plants.resource_cap), plant_ledger: PlantLedger::default(), last_moves: [MoveTick::default(); 2], herbivore_ledger: HerbivoreLedger::default(), hunt_ledger: HuntLedger::default(), repro_ledger: [ReproLedger::default(); 2], stats: Default::default() };
        w.recompute_now(0);
        Ok(w)
    }

    pub fn torus(&self) -> &Torus {
        &self.torus
    }

    /// Static base climate of every cell (ADR-009).
    pub fn climate(&self) -> &ClimateMap {
        &self.climate
    }

    /// Climate phase of tick `tick`: advance the weather (core RNG draws if
    /// enabled), then recompute the current grid for `tick`.
    pub fn update_climate(&mut self, tick: u64, rng: &mut Rng, params: &ClimateParams) {
        self.weather.advance(params, rng);
        self.recompute_now(tick);
    }

    fn recompute_now(&mut self, tick: u64) {
        let p = self.climate.params();
        let s = year_phase(tick, p.year_length);
        let w = self.torus.width() as usize;
        let n = self.climate.cells().len();
        self.now.clear();
        self.now.reserve(n);
        for (i, base) in self.climate.cells().iter().enumerate() {
            let (x, y) = ((i % w) as f64, (i / w) as f64);
            let (at, ap) = self.weather.anomaly(x, y);
            self.now.push(combine(p, &self.bounds, base, s, at, ap));
        }
        self.climate_tick = tick;
    }

    /// Current temperature/precipitation of a cell (inside the world) at
    /// [`World::climate_tick`].
    pub fn current(&self, c: Cell) -> CellNow {
        self.now[c.y as usize * self.torus.width() as usize + c.x as usize]
    }

    /// Current climate of all cells, row-major.
    pub fn current_grid(&self) -> &[CellNow] {
        &self.now
    }

    /// Tick the current grid describes (the tick whose Climate phase ran
    /// last; 0 before any step).
    pub fn climate_tick(&self) -> u64 {
        self.climate_tick
    }

    /// Documented bounds of the current climate.
    pub fn climate_bounds(&self) -> ClimateBounds {
        self.bounds
    }

    /// All organisms (ADR-011).
    pub fn organisms(&self) -> &Population {
        &self.organisms
    }

    pub fn organisms_mut(&mut self) -> &mut Population {
        &mut self.organisms
    }

    /// Store `p` after rebuilding its spatial index on this world's torus.
    pub(crate) fn set_organisms(&mut self, mut p: Population) -> Result<(), String> {
        p.rebuild_index(self.torus)?;
        self.organisms = p;
        let t = self.organisms.totals();
        self.stats = crate::sim::stats::TickStats { tick: self.stats.tick, births: t.births, deaths: t.deaths, alive: Kind::ALL.map(|k| self.organisms.count_alive(k) as u64), ..Default::default() };
        Ok(())
    }

    pub fn weather(&self) -> &Weather {
        &self.weather
    }

    /// Restore the weather lattices and recompute the grid for `tick`.
    pub(crate) fn restore_weather(&mut self, s: WeatherState, tick: u64) -> Result<(), WeatherError> {
        self.weather.restore(s)?;
        self.recompute_now(tick);
        Ok(())
    }

    /// Soil resource per cell (ADR-014).
    pub fn resources(&self) -> &CellResources {
        &self.resources
    }

    /// Cumulative plant energy audit (ADR-014).
    pub fn plant_ledger(&self) -> &PlantLedger {
        &self.plant_ledger
    }

    /// Resources phase: regenerate every cell from its current moisture.
    pub fn regenerate_resources(&mut self, plants: &PlantParams, max_precipitation: f64) -> f64 {
        let added = self.resources.regenerate(&self.now, plants, max_precipitation);
        self.plant_ledger.record_regen(added);
        added
    }

    /// Plants phase growth: uptake, upkeep, climate stress (ADR-014).
    pub fn grow_plants(&mut self, tick: u64, plants: &PlantParams, max_precipitation: f64) -> GrowthTick {
        let g = grow_plants(&mut self.organisms, &mut self.resources, &self.now, &self.torus, plants, max_precipitation, tick);
        self.plant_ledger.record_growth(&g);
        g
    }

    /// Plants phase reproduction after growth (ADR-015): core RNG draws.
    pub fn reproduce_plants(&mut self, tick: u64, cfg: &Config, rng: &mut Rng) -> ReproTick {
        let r = reproduce_plants(&mut self.organisms, &self.resources, &self.torus, cfg, rng, tick);
        self.plant_ledger.record_repro(&r);
        r
    }

    /// Herbivores/Carnivores phase body (ADR-016): acting order over the
    /// living animals of `kind` (core RNG shuffle), then sense + move.
    /// Herbivores: feeding, metabolism, climate cost, decisions (ADR-017);
    /// the feeding summary goes into [`World::herbivore_ledger`].
    /// Carnivores: hunting turn (ADR-018); the hunting summary goes into
    /// [`World::hunt_ledger`].
    pub fn act_animals(&mut self, kind: Kind, cfg: &Config, tick: u64, rng: &mut Rng) -> MoveTick {
        let ids = crate::sim::acting_order(&self.organisms.alive_ids(kind), rng);
        match kind {
            Kind::Herbivore => {
                let (m, f) = act_herbivores(&mut self.organisms, &ids, cfg, &self.now, self.torus.width(), tick, rng);
                self.herbivore_ledger.record(&f);
                let r = reproduce_animals(&mut self.organisms, &ids, kind, cfg, rng);
                self.repro_ledger[0].record(&r);
                m
            }
            Kind::Carnivore => {
                let (m, h) = act_carnivores(&mut self.organisms, &ids, cfg, &self.now, self.torus.width(), tick, rng);
                self.hunt_ledger.record(&h);
                let r = reproduce_animals(&mut self.organisms, &ids, kind, cfg, rng);
                self.repro_ledger[1].record(&r);
                m
            }
            Kind::Plant => MoveTick::default(),
        }
    }

    /// Cumulative herbivore feeding audit; `.last` is the last Herbivores phase.
    pub fn herbivore_ledger(&self) -> &HerbivoreLedger {
        &self.herbivore_ledger
    }

    /// Cumulative reproduction audit of `kind` (ADR-019); plants → default.
    pub fn repro_ledger(&self, kind: Kind) -> ReproLedger {
        match kind {
            Kind::Herbivore => self.repro_ledger[0],
            Kind::Carnivore => self.repro_ledger[1],
            Kind::Plant => ReproLedger::default(),
        }
    }

    /// Cumulative hunting audit; `.last` is the last Carnivores phase.
    pub fn hunt_ledger(&self) -> &HuntLedger {
        &self.hunt_ledger
    }

    /// Hunting summary of the last Carnivores phase.
    pub fn last_hunt(&self) -> HuntTick {
        self.hunt_ledger.last
    }

    /// Feeding summary of the last Herbivores phase.
    pub fn last_feed(&self) -> FeedTick {
        self.herbivore_ledger.last
    }

    /// Movement summary of the last phase of `kind` (herbivore or carnivore).
    pub fn last_moves(&self, kind: Kind) -> MoveTick {
        match kind {
            Kind::Carnivore => self.last_moves[1],
            _ => self.last_moves[0],
        }
    }

    pub(crate) fn set_last_moves(&mut self, kind: Kind, t: MoveTick) {
        match kind {
            Kind::Carnivore => self.last_moves[1] = t,
            _ => self.last_moves[0] = t,
        }
    }

    /// Snapshot of the last Statistics phase (before any tick: founder counts, tick 0).
    pub fn stats(&self) -> &crate::sim::stats::TickStats {
        &self.stats
    }

    /// Statistics phase body (ADR-021): capture counts/births/deaths.
    pub(crate) fn update_stats(&mut self, tick: u64) {
        self.stats = crate::sim::stats::TickStats::capture(tick, &self.organisms, &self.stats);
    }
}

impl World {
    /// Canonical state stream of the world (ADR-022 §2). Exhaustive
    /// destructuring: a new field is a compile error until it is decided.
    pub(crate) fn hash_state(&self, h: &mut crate::digest::StateHasher) {
        let World {
            torus,
            // Derived cache: pure function of config + seed (both hashed).
            climate: _climate,
            // Derived cache: computed from `climate`.
            bounds: _bounds,
            weather,
            now,
            climate_tick,
            organisms,
            resources,
            plant_ledger,
            last_moves,
            herbivore_ledger,
            hunt_ledger,
            repro_ledger,
            stats,
        } = self;
        h.section("world.torus");
        h.debug(torus);
        h.section("world.climate");
        h.u64(*climate_tick);
        h.debug(weather);
        h.len(now.len());
        h.debug(now);
        h.section("world.resources");
        h.debug(resources);
        organisms.hash_state(h);
        h.section("world.ledgers");
        h.debug(plant_ledger);
        h.debug(herbivore_ledger);
        h.debug(hunt_ledger);
        h.debug(repro_ledger);
        // Per-tick report buffers: hashed too (Statistics reads the previous
        // snapshot), so any difference shows in the hash.
        h.debug(last_moves);
        h.debug(stats);
    }
}

#[cfg(test)]
impl World {
    /// Test-only mutable soil resources (hash sensitivity tests).
    pub(crate) fn resources_mut_for_test(&mut self) -> &mut CellResources {
        &mut self.resources
    }
}

/// Serialisable world state (checkpoints, ADR-025): every field of [`World`]
/// except the derived caches `climate` and `bounds`.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub(crate) struct WorldState {
    torus: Torus,
    weather: WeatherState,
    now: Vec<CellNow>,
    climate_tick: u64,
    organisms: Population,
    resources: CellResources,
    plant_ledger: PlantLedger,
    last_moves: [MoveTick; 2],
    herbivore_ledger: HerbivoreLedger,
    hunt_ledger: HuntLedger,
    repro_ledger: [ReproLedger; 2],
    stats: crate::sim::stats::TickStats,
}

impl World {
    /// Checkpoint export. Exhaustive destructuring: a new field is a compile
    /// error until the snapshot decides it (ADR-025).
    pub(crate) fn snapshot_state(&self) -> WorldState {
        let World {
            torus,
            climate: _climate,
            bounds: _bounds,
            weather,
            now,
            climate_tick,
            organisms,
            resources,
            plant_ledger,
            last_moves,
            herbivore_ledger,
            hunt_ledger,
            repro_ledger,
            stats,
        } = self;
        WorldState {
            torus: *torus,
            weather: weather.state(),
            now: now.clone(),
            climate_tick: *climate_tick,
            organisms: organisms.clone(),
            resources: resources.clone(),
            plant_ledger: *plant_ledger,
            last_moves: *last_moves,
            herbivore_ledger: *herbivore_ledger,
            hunt_ledger: *hunt_ledger,
            repro_ledger: *repro_ledger,
            stats: *stats,
        }
    }

    /// Checkpoint restore: derived caches from `config`, everything else from
    /// `s` verbatim, after structural checks against `config`. `tick` is the
    /// restored clock, `next_id` the restored ID counter.
    pub(crate) fn from_snapshot(config: &Config, s: WorldState, tick: u64, next_id: u64) -> Result<World, String> {
        let WorldState { torus, weather, now, climate_tick, mut organisms, resources, plant_ledger, last_moves, herbivore_ledger, hunt_ledger, repro_ledger, stats } = s;
        let mut w = World::from_config(config).map_err(|e| format!("world: {e}"))?;
        if torus != w.torus {
            return Err(format!("torus {}x{} differs from the configured world {}x{}", torus.width(), torus.height(), w.torus.width(), w.torus.height()));
        }
        let cells = w.torus.cell_count();
        if now.len() != cells {
            return Err(format!("current climate grid has {} cells, expected {cells}", now.len()));
        }
        if now.iter().any(|c| !c.temperature.is_finite() || !c.precipitation.is_finite()) {
            return Err("current climate grid contains a non-finite value".to_string());
        }
        if resources.values().len() != cells || resources.width() != w.torus.width() {
            return Err(format!("resource grid has {} cells, expected {cells}", resources.values().len()));
        }
        if resources.values().iter().any(|v| !v.is_finite()) {
            return Err("resource grid contains a non-finite value".to_string());
        }
        if climate_tick > tick {
            return Err(format!("climate tick {climate_tick} is after the clock {tick}"));
        }
        w.weather.restore(weather).map_err(|e| format!("weather: {e}"))?;
        organisms
            .restore_caches(Expression::from_config(config), crate::organism::CellCapacity::from_config(config), w.torus)
            .map_err(|e| format!("population: {e}"))?;
        organisms.validate(next_id).map_err(|e| format!("population: {e}"))?;
        w.now = now;
        w.climate_tick = climate_tick;
        w.organisms = organisms;
        w.resources = resources;
        w.plant_ledger = plant_ledger;
        w.last_moves = last_moves;
        w.herbivore_ledger = herbivore_ledger;
        w.hunt_ledger = hunt_ledger;
        w.repro_ledger = repro_ledger;
        w.stats = stats;
        Ok(w)
    }
}

//! TASK-009 tests (ADR-012), mapped to the acceptance criteria AC1–AC5.

use super::*;
use crate::config::{preset, preset_names, Config};
use crate::organism::{BirthRequest, Kind, Parents, Traits};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::Cell;

fn random_genome(kind: Kind, r: &mut Rng) -> Genome {
    Genome::from_genes(kind, (0..gene_table(kind).len()).map(|_| r.next_f32()).collect()).unwrap()
}

fn extreme_configs() -> Vec<Config> {
    let mut v: Vec<Config> = preset_names().iter().map(|n| preset(n).unwrap()).collect();
    let mut hi = Config::new(1, 8, 8, 1, 1, 1);
    for (sp, vi, age, en) in [(16u32, 64u32, 10_000_000u32, 1e6f64), (1, 1, 1, 0.1)] {
        hi.herbivores.max_speed = sp;
        hi.carnivores.max_speed = sp;
        hi.herbivores.max_vision = vi;
        hi.carnivores.max_vision = vi;
        hi.plants.max_age = age;
        hi.herbivores.max_age = age;
        hi.carnivores.max_age = age;
        hi.plants.max_energy = en;
        hi.herbivores.max_energy = en;
        hi.carnivores.max_energy = en;
        v.push(hi.clone());
    }
    v
}

// ---------- AC1 genome + deterministic in-range traits ----------

#[test]
fn gene_tables_match_adr() {
    assert_eq!(GENE_LAYOUT_VERSION, 1);
    assert_eq!(gene_table(Kind::Plant).len(), 13);
    assert_eq!(gene_table(Kind::Herbivore).len(), 17);
    assert_eq!(gene_table(Kind::Carnivore).len(), 17);
    let animal: Vec<&str> = gene_table(Kind::Herbivore).iter().map(|s| s.name).collect();
    assert_eq!(
        animal,
        [
            "strength", "fertility", "max_health", "lifespan", "max_energy", "temp_optimum", "temp_tolerance", "speed",
            "vision", "aggression", "caution", "marker_0", "marker_1", "marker_2", "marker_3", "marker_4", "marker_5"
        ]
    );
    let plant: Vec<&str> = gene_table(Kind::Plant).iter().map(|s| s.name).collect();
    assert_eq!(&plant[..7], &animal[..7]);
    assert_eq!(&plant[7..], &animal[11..]);
    for k in Kind::ALL {
        let t = gene_table(k);
        for (i, s) in t.iter().enumerate() {
            assert!(t[..i].iter().all(|o| o.name != s.name), "duplicate {}", s.name);
            assert!((0.0..=1.0).contains(&s.founder) && s.weight > 0.0);
            assert_eq!(s.target.is_none(), s.name.starts_with("marker_"));
        }
    }
    for t in [GeneTrait::Speed, GeneTrait::Vision, GeneTrait::Aggression, GeneTrait::Caution] {
        assert_eq!(gene_index(Kind::Plant, t), None);
        assert!(gene_index(Kind::Herbivore, t).is_some());
    }
}

#[test]
fn from_genes_rejects_invalid() {
    assert!(matches!(
        Genome::from_genes(Kind::Plant, vec![0.5; 12]),
        Err(GenomeError::WrongLength { expected: 13, got: 12, .. })
    ));
    let mut g = vec![0.5; 17];
    g[3] = 1.5;
    assert!(matches!(Genome::from_genes(Kind::Herbivore, g.clone()), Err(GenomeError::OutOfRange { index: 3, .. })));
    g[3] = f32::NAN;
    assert!(Genome::from_genes(Kind::Herbivore, g.clone()).is_err());
    g[3] = -0.0001;
    assert!(Genome::from_genes(Kind::Carnivore, g.clone()).is_err());
    g[3] = 1.0;
    let ok = Genome::from_genes(Kind::Carnivore, g).unwrap();
    assert_eq!(ok.kind(), Kind::Carnivore);
    assert_eq!(ok.len(), 17);
    assert!(!GenomeError::KindMismatch { a: Kind::Plant, b: Kind::Herbivore }.to_string().is_empty());
}

#[test]
fn express_deterministic() {
    let mut r = Rng::seed_from_u64(1);
    let e = Expression::from_config(&Config::contract_example());
    for k in Kind::ALL {
        for _ in 0..200 {
            let g = random_genome(k, &mut r);
            let before = r.state();
            assert_eq!(express(&g, &e), express(&g.clone(), &e));
            assert_eq!(r.state(), before, "express must not draw");
        }
    }
}

#[test]
fn express_in_range_extreme_genomes() {
    let mut r = Rng::seed_from_u64(2);
    for cfg in extreme_configs() {
        let e = Expression::from_config(&cfg);
        for k in Kind::ALL {
            let n = gene_table(k).len();
            let mut genomes = vec![Genome::from_genes(k, vec![0.0; n]).unwrap(), Genome::from_genes(k, vec![1.0; n]).unwrap()];
            genomes.extend((0..5000).map(|_| random_genome(k, &mut r)));
            for g in &genomes {
                let t = express(g, &e);
                assert!(t.in_range(k), "{} {:?}", k.name(), t);
                if !k.is_animal() {
                    assert_eq!((t.speed, t.vision, t.aggression, t.caution), (0.0, 0.0, 0.0, 0.0));
                }
            }
        }
    }
}

#[test]
fn express_monotone_in_gene() {
    let e = Expression::from_config(&Config::contract_example());
    type Reader = fn(&Traits) -> f64;
    let read: [(GeneTrait, Reader); 11] = [
        (GeneTrait::Strength, |t| t.strength),
        (GeneTrait::Fertility, |t| t.fertility),
        (GeneTrait::MaxHealth, |t| t.max_health),
        (GeneTrait::Lifespan, |t| t.max_lifespan as f64),
        (GeneTrait::MaxEnergy, |t| t.max_energy),
        (GeneTrait::TempOptimum, |t| t.temp_optimum),
        (GeneTrait::TempTolerance, |t| t.temp_tolerance),
        (GeneTrait::Speed, |t| t.speed),
        (GeneTrait::Vision, |t| t.vision),
        (GeneTrait::Aggression, |t| t.aggression),
        (GeneTrait::Caution, |t| t.caution),
    ];
    for k in [Kind::Herbivore, Kind::Carnivore, Kind::Plant] {
        for (gt, f) in read {
            let Some(i) = gene_index(k, gt) else { continue };
            let mut lo = Genome::founder_default(k);
            let mut hi = lo.clone();
            lo.genes_mut()[i] = 0.1;
            hi.genes_mut()[i] = 0.9;
            assert!(f(&express(&hi, &e)) > f(&express(&lo, &e)), "{} {gt:?}", k.name());
        }
    }
}

#[test]
fn founder_default_genome_gives_task008_defaults() {
    for cfg in extreme_configs() {
        let e = Expression::from_config(&cfg);
        let p = express(&Genome::founder_default(Kind::Plant), &e);
        assert_eq!((p.speed, p.vision, p.aggression, p.caution), (0.0, 0.0, 0.0, 0.0));
        assert_eq!((p.strength, p.fertility, p.max_health), (0.5, 0.5, 10.0));
        assert_eq!((p.max_lifespan, p.max_energy), (cfg.plants.max_age, cfg.plants.max_energy));
        assert_eq!((p.temp_optimum, p.temp_tolerance), (10.0, 16.0));
        for (k, hp) in [(Kind::Herbivore, 100.0), (Kind::Carnivore, 120.0)] {
            let t = express(&Genome::founder_default(k), &e);
            let h = &cfg.herbivores;
            let (sp, vi, age, en) = if k == Kind::Herbivore {
                (h.max_speed, h.max_vision, h.max_age, h.max_energy)
            } else {
                (cfg.carnivores.max_speed, cfg.carnivores.max_vision, cfg.carnivores.max_age, cfg.carnivores.max_energy)
            };
            assert_eq!(t.speed, sp as f64 / 2.0);
            assert_eq!(t.vision, vi as f64);
            assert_eq!(t.max_lifespan, age);
            assert_eq!(t.max_energy, en);
            assert_eq!(t.max_health, hp);
            assert_eq!((t.strength, t.fertility, t.aggression, t.caution), (0.5, 0.5, 0.5, 0.5));
            assert_eq!(t, Traits::founder_default(k, &cfg));
        }
    }
}

#[test]
fn every_organism_has_genome_traits_from_genome() {
    for name in preset_names() {
        let mut c = preset(name).unwrap();
        c.world.width = 16;
        c.world.height = 12;
        let mut sim = Simulation::new(c.clone()).unwrap();
        for _ in 0..100 {
            sim.step_with(|ctx| {
                if ctx.phase != Phase::Herbivores {
                    return;
                }
                for k in Kind::ALL {
                    let ids = ctx.world.organisms().alive_ids(k);
                    if ids.len() < 2 {
                        continue;
                    }
                    let a = ctx.world.organisms().get(ids[0]).unwrap().genome().clone();
                    let b = ctx.world.organisms().get(ids[1]).unwrap().genome().clone();
                    let g = child_sexual(&a, &b, MutationParams::for_kind(k, ctx.config), ctx.rng).unwrap();
                    let req = BirthRequest { pos: Cell { x: 0, y: 0 }, parents: Parents::Two(ids[0], ids[1]), energy: 1.0, health: None, genome: g };
                    ctx.world.organisms_mut().request_birth(req);
                }
            });
        }
        let pop = sim.organisms();
        assert!(pop.totals().births.iter().sum::<u64>() > 0 || pop.totals().initial.iter().sum::<u64>() < 2, "{name}");
        for k in Kind::ALL {
            for o in pop.stored(k) {
                assert_eq!(o.genome().kind(), k);
                assert!(Genome::from_genes(k, o.genome().genes().to_vec()).is_ok());
                assert_eq!(o.traits(), &express(o.genome(), pop.expression()));
                assert!(o.traits().in_range(k));
            }
        }
        assert_eq!(pop.expression(), &Expression::from_config(&c));
        pop.validate(sim.next_entity_id()).unwrap();
    }
}

#[test]
fn founders_genomes_deterministic_and_jittered() {
    let c = Config::new(7, 20, 16, 30, 20, 10);
    let genomes = |s: &Simulation| -> Vec<(Cell, Genome)> {
        Kind::ALL.iter().flat_map(|&k| s.organisms().alive(k).map(|o| (o.pos(), o.genome().clone())).collect::<Vec<_>>()).collect()
    };
    let a = Simulation::new(c.clone()).unwrap();
    let b = Simulation::new(c.clone()).unwrap();
    assert_eq!(genomes(&a), genomes(&b));
    let other = Simulation::new(c.clone().with_seed(8)).unwrap();
    assert_ne!(genomes(&a), genomes(&other));
    // jittered: not all equal to the default, but close to it
    let ga = genomes(&a);
    assert!(ga.iter().any(|(_, g)| *g != Genome::founder_default(g.kind())));
    for (_, g) in &ga {
        assert!(distance(g, &Genome::founder_default(g.kind())) < 0.1);
    }
    // founder_variation 0 → exact default genomes, same positions, same core RNG
    let mut z = c.clone();
    z.plants.founder_variation = 0.0;
    z.herbivores.founder_variation = 0.0;
    z.carnivores.founder_variation = 0.0;
    let sz = Simulation::new(z).unwrap();
    let gz = genomes(&sz);
    assert!(gz.iter().all(|(_, g)| *g == Genome::founder_default(g.kind())));
    let pa: Vec<Cell> = ga.iter().map(|x| x.0).collect();
    let pz: Vec<Cell> = gz.iter().map(|x| x.0).collect();
    assert_eq!(pa, pz);
    assert_eq!(a.rng_state(), sz.rng_state());
    assert_eq!(a.rng_state(), Rng::seed_from_u64(7).state());
}

// ---------- AC2 copy + crossover ----------

#[test]
fn copy_of_equals_parent() {
    let mut r = Rng::seed_from_u64(3);
    for k in Kind::ALL {
        let p = random_genome(k, &mut r);
        let before = r.state();
        let c = Genome::copy_of(&p);
        assert_eq!(c, p);
        assert_eq!(distance(&c, &p), 0.0);
        assert_eq!(r.state(), before);
        let child = child_asexual(&p, MutationParams::NONE, &mut r);
        assert_eq!(child, p);
        assert_eq!(r.state(), before);
    }
}

fn distinct_pair(k: Kind, r: &mut Rng) -> (Genome, Genome) {
    let n = gene_table(k).len();
    let a = Genome::from_genes(k, (0..n).map(|_| r.range_f64(0.0, 0.49) as f32).collect()).unwrap();
    let b = Genome::from_genes(k, (0..n).map(|_| r.range_f64(0.51, 1.0) as f32).collect()).unwrap();
    (a, b)
}

#[test]
fn crossover_each_locus_from_a_parent() {
    let mut r = Rng::seed_from_u64(4);
    for k in Kind::ALL {
        let (a, b) = distinct_pair(k, &mut r);
        for _ in 0..1000 {
            let c = crossover(&a, &b, &mut r).unwrap();
            assert_eq!(c.kind(), k);
            assert_eq!(c.len(), a.len());
            for i in 0..c.len() {
                assert!(c.genes()[i] == a.genes()[i] || c.genes()[i] == b.genes()[i]);
            }
        }
    }
}

#[test]
fn crossover_uses_both_parents() {
    let mut r = Rng::seed_from_u64(5);
    let (a, b) = distinct_pair(Kind::Herbivore, &mut r);
    let n = a.len();
    let mut from_a = vec![0u32; n];
    let trials = 1000;
    for _ in 0..trials {
        let c = crossover(&a, &b, &mut r).unwrap();
        for ((f, x), y) in from_a.iter_mut().zip(c.genes()).zip(a.genes()) {
            if x == y {
                *f += 1;
            }
        }
    }
    for &f in &from_a {
        assert!(f > 0 && f < trials, "each locus from both parents");
    }
    let frac = from_a.iter().sum::<u32>() as f64 / (trials as f64 * n as f64);
    assert!((0.45..0.55).contains(&frac), "{frac}");
    // documented draw count: one chance(0.5) per locus
    let mut r1 = Rng::seed_from_u64(9);
    let mut r2 = Rng::seed_from_u64(9);
    crossover(&a, &b, &mut r1).unwrap();
    for _ in 0..n {
        r2.chance(0.5);
    }
    assert_eq!(r1.state(), r2.state());
}

#[test]
fn crossover_kind_mismatch_errors() {
    let mut r = Rng::seed_from_u64(6);
    let a = Genome::founder_default(Kind::Herbivore);
    let b = Genome::founder_default(Kind::Carnivore);
    let before = r.state();
    assert_eq!(crossover(&a, &b, &mut r), Err(GenomeError::KindMismatch { a: Kind::Herbivore, b: Kind::Carnivore }));
    assert!(child_sexual(&a, &b, MutationParams { rate: 1.0, strength: 0.1 }, &mut r).is_err());
    assert_eq!(r.state(), before);
    let s = child_sexual(&a, &a, MutationParams { rate: 0.5, strength: 0.1 }, &mut r).unwrap();
    assert_eq!((s.kind(), s.len()), (Kind::Herbivore, 17));
    let p = child_asexual(&Genome::founder_default(Kind::Plant), MutationParams { rate: 0.5, strength: 0.1 }, &mut r);
    assert_eq!((p.kind(), p.len()), (Kind::Plant, 13));
}

// ---------- AC3 configurable mutation from the generator ----------

#[test]
fn mutation_params_from_config() {
    let c = Config::contract_example();
    assert_eq!(MutationParams::for_kind(Kind::Plant, &c), MutationParams { rate: 0.05, strength: 0.05 });
    let mut v = c.to_json_value();
    v["herbivores"]["mutation_rate"] = 0.3.into();
    v["herbivores"]["mutation_strength"] = 0.1.into();
    v["carnivores"]["mutation_rate"] = 0.0.into();
    let c2 = Config::from_value(&v).unwrap();
    assert_eq!(MutationParams::for_kind(Kind::Herbivore, &c2), MutationParams { rate: 0.3, strength: 0.1 });
    assert_eq!(MutationParams::for_kind(Kind::Carnivore, &c2).rate, 0.0);
    assert!(!MutationParams::for_kind(Kind::Carnivore, &c2).is_active());
    assert_eq!(c2.plants.founder_variation, 0.02);
}

#[test]
fn mutation_deterministic_from_rng() {
    let p = MutationParams { rate: 0.3, strength: 0.1 };
    let run = |seed: u64| {
        let mut r = Rng::seed_from_u64(seed);
        let mut g = Genome::founder_default(Kind::Herbivore);
        let hits = mutate(&mut g, p, &mut r);
        (g, hits, r.state())
    };
    assert_eq!(run(1), run(1));
    assert_ne!(run(1).0, run(2).0);
    // documented draw count: per locus chance(rate), normal on hit
    for seed in 0..50 {
        let mut r = Rng::seed_from_u64(seed);
        let mut reference = Rng::seed_from_u64(seed);
        let mut g = Genome::founder_default(Kind::Herbivore);
        let mut expected = g.clone();
        mutate(&mut g, p, &mut r);
        for x in expected.genes_mut() {
            if reference.chance(p.rate) {
                *x = (reflect_unit(*x as f64 + reference.normal(0.0, p.strength)) as f32).clamp(0.0, 1.0);
            }
        }
        assert_eq!(g, expected);
        assert_eq!(r.state(), reference.state());
    }
}

#[test]
fn mutation_rate_controls_frequency() {
    let mut r = Rng::seed_from_u64(10);
    let p = MutationParams { rate: 0.2, strength: 0.1 };
    let (mut hits, mut loci) = (0usize, 0usize);
    while loci < 20_000 {
        let mut g = Genome::founder_default(Kind::Carnivore);
        hits += mutate(&mut g, p, &mut r);
        loci += g.len();
    }
    let f = hits as f64 / loci as f64;
    assert!((0.18..0.22).contains(&f), "{f}");
    let mut g = Genome::founder_default(Kind::Carnivore);
    assert_eq!(mutate(&mut g, MutationParams { rate: 1.0, strength: 0.2 }, &mut r), g.len());
}

#[test]
fn mutation_strength_controls_size() {
    let mean_delta = |strength: f64| {
        let mut r = Rng::seed_from_u64(11);
        let base = Genome::founder_default(Kind::Herbivore);
        let mut sum = 0.0;
        for _ in 0..500 {
            let mut g = base.clone();
            mutate(&mut g, MutationParams { rate: 1.0, strength }, &mut r);
            sum += distance(&g, &base);
        }
        sum / 500.0
    };
    let (small, big) = (mean_delta(0.01), mean_delta(0.2));
    assert!(small > 0.0 && small < big, "{small} {big}");
}

#[test]
fn mutation_keeps_unit_interval() {
    let mut r = Rng::seed_from_u64(12);
    for k in Kind::ALL {
        let mut g = random_genome(k, &mut r);
        for _ in 0..10_000 {
            mutate(&mut g, MutationParams { rate: 1.0, strength: 1.0 }, &mut r);
            assert!(g.genes().iter().all(|x| x.is_finite() && (0.0..=1.0).contains(x)));
        }
        assert!(Genome::from_genes(k, g.genes().to_vec()).is_ok());
    }
}

#[test]
fn reflect_unit_cases() {
    let close = |a: f64, b: f64| (a - b).abs() < 1e-12;
    assert!(close(reflect_unit(-0.1), 0.1));
    assert!(close(reflect_unit(1.2), 0.8));
    assert!(close(reflect_unit(2.3), 0.3));
    assert!(close(reflect_unit(-1.5), 0.5));
    assert_eq!(reflect_unit(0.0), 0.0);
    assert_eq!(reflect_unit(1.0), 1.0);
    assert_eq!(reflect_unit(0.25), 0.25);
    assert!(reflect_unit(f64::NAN).is_nan());
    assert_eq!(reflect_unit(f64::INFINITY), f64::INFINITY);
    // non-finite parameters → no mutation, no draws
    let mut r = Rng::seed_from_u64(13);
    let before = r.state();
    let mut g = Genome::founder_default(Kind::Plant);
    for p in [MutationParams { rate: f64::NAN, strength: 0.1 }, MutationParams { rate: 0.5, strength: f64::INFINITY }] {
        assert_eq!(mutate(&mut g, p, &mut r), 0);
    }
    assert_eq!(g, Genome::founder_default(Kind::Plant));
    assert_eq!(r.state(), before);
}

// ---------- AC4 rate 0 vs rate > 0 ----------

#[test]
fn rate_zero_children_only_parental_material() {
    let mut r = Rng::seed_from_u64(14);
    for k in Kind::ALL {
        let (a, b) = distinct_pair(k, &mut r);
        for p in [MutationParams { rate: 0.0, strength: 0.5 }, MutationParams { rate: 0.0, strength: 0.0 }] {
            for _ in 0..2000 {
                let before = r.state();
                assert_eq!(child_asexual(&a, p, &mut r), a);
                assert_eq!(r.state(), before, "rate 0 must not draw");
                let mut reference = r.clone();
                let c = child_sexual(&a, &b, p, &mut r).unwrap();
                crossover(&a, &b, &mut reference).unwrap();
                assert_eq!(r.state(), reference.state(), "only crossover draws");
                for i in 0..c.len() {
                    assert!(c.genes()[i] == a.genes()[i] || c.genes()[i] == b.genes()[i]);
                }
            }
        }
    }
}

#[test]
fn rate_positive_differences_appear() {
    let mut r = Rng::seed_from_u64(15);
    let p = MutationParams::for_kind(Kind::Herbivore, &Config::contract_example());
    assert_eq!(p, MutationParams { rate: 0.05, strength: 0.05 });
    let (a, b) = distinct_pair(Kind::Herbivore, &mut r);
    let n = a.len();
    let (mut novel_sexual, mut novel_asexual) = (0usize, 0usize);
    for _ in 0..2000 {
        let c = child_sexual(&a, &b, p, &mut r).unwrap();
        assert!(c.genes().iter().all(|x| (0.0..=1.0).contains(x)));
        if (0..n).any(|i| c.genes()[i] != a.genes()[i] && c.genes()[i] != b.genes()[i]) {
            novel_sexual += 1;
        }
        let d = child_asexual(&a, p, &mut r);
        if d != a {
            novel_asexual += 1;
        }
    }
    // expected ≈ 2000·(1 − 0.95^17) ≈ 1166
    assert!(novel_sexual > 583 && novel_asexual > 583, "{novel_sexual} {novel_asexual}");
}

#[test]
fn newborns_inherit_with_mutation_via_core_rng() {
    let mut c = Config::new(21, 20, 16, 0, 6, 0).pre_task018();
    c.herbivores.mutation_rate = 0.5;
    c.herbivores.mutation_strength = 0.2;
    let run = || {
        let mut s = Simulation::new(c.clone()).unwrap();
        let mut kids = Vec::new();
        for _ in 0..5 {
            s.step_with(|ctx| {
                if ctx.phase == Phase::Herbivores {
                    let ids = ctx.world.organisms().alive_ids(Kind::Herbivore);
                    let a = ctx.world.organisms().get(ids[0]).unwrap().genome().clone();
                    let b = ctx.world.organisms().get(ids[1]).unwrap().genome().clone();
                    let g = child_sexual(&a, &b, MutationParams::for_kind(Kind::Herbivore, ctx.config), ctx.rng).unwrap();
                    let req = BirthRequest { pos: Cell { x: 3, y: 3 }, parents: Parents::Two(ids[0], ids[1]), energy: 10.0, health: None, genome: g };
                    ctx.world.organisms_mut().request_birth(req);
                }
            });
            let rec = s.organisms().last_births()[0];
            kids.push(s.organisms().get(rec.id).unwrap().genome().clone());
        }
        (kids, s.rng_state())
    };
    let (k1, s1) = run();
    let (k2, s2) = run();
    assert_eq!(k1, k2);
    assert_eq!(s1, s2);
    // the core RNG stream differs from a run without births (mutation draws from it)
    let mut plain = Simulation::new(c.clone()).unwrap();
    plain.run(5);
    assert_ne!(plain.rng_state(), s1);
    assert!(k1.iter().any(|g| g.genes().iter().any(|&x| x != 0.5 && x != 1.0) || distance(g, &Genome::founder_default(Kind::Herbivore)) > 0.05));
}

// ---------- AC5 distance ----------

#[test]
fn distance_zero_for_identical() {
    let mut r = Rng::seed_from_u64(16);
    for k in Kind::ALL {
        for _ in 0..200 {
            let g = random_genome(k, &mut r);
            assert_eq!(distance(&g, &g), 0.0);
            assert_eq!(distance(&g, &Genome::copy_of(&g)), 0.0);
        }
    }
}

#[test]
fn distance_symmetric_and_bounded() {
    let mut r = Rng::seed_from_u64(17);
    for k in Kind::ALL {
        for _ in 0..1000 {
            let (a, b) = (random_genome(k, &mut r), random_genome(k, &mut r));
            let d = distance(&a, &b);
            assert_eq!(d, distance(&b, &a));
            assert!((0.0..=1.0).contains(&d));
            assert_eq!(d > 0.0, a != b, "positive iff different");
        }
        let n = gene_table(k).len();
        let zero = Genome::from_genes(k, vec![0.0; n]).unwrap();
        let one = Genome::from_genes(k, vec![1.0; n]).unwrap();
        assert_eq!(distance(&zero, &one), 1.0);
    }
}

#[test]
fn distance_grows_with_difference() {
    for k in Kind::ALL {
        let base = Genome::from_genes(k, vec![0.2; gene_table(k).len()]).unwrap();
        let mut prev = 0.0;
        let mut g = base.clone();
        for i in 0..g.len() {
            g.genes_mut()[i] = 0.5;
            let d = distance(&base, &g);
            assert!(d > prev, "more differing loci → larger distance");
            prev = d;
        }
        let mut prev = 0.0;
        for step in 1..=5 {
            let mut g = base.clone();
            g.genes_mut()[0] = 0.2 + 0.1 * step as f32;
            let d = distance(&base, &g);
            assert!(d > prev, "larger difference → larger distance");
            prev = d;
        }
    }
}

#[test]
fn distance_kind_mismatch_is_one() {
    let a = Genome::founder_default(Kind::Herbivore);
    let b = Genome::founder_default(Kind::Carnivore);
    assert_eq!(distance(&a, &b), 1.0);
    assert_eq!(distance(&b, &a), 1.0);
    assert_eq!(distance(&Genome::founder_default(Kind::Plant), &a), 1.0);
}

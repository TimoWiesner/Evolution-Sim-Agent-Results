//! Ecology survival report (TASK-018, ADR-021): runs a configuration for a
//! number of ticks and records, per kind, the tick at which it died out.
//! Pure function of (configuration, seed, ticks): deterministic.

use crate::config::Config;
use crate::organism::Kind;
use crate::sim::{SimError, Simulation};

#[cfg(test)]
mod tests;

/// Fate of one kind in a survival run.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct KindFate {
    /// Tick after which the kind had 0 living organisms (0 = absent from the
    /// start); `None` = still alive at the end of the run.
    pub extinct_at: Option<u64>,
}

/// Outcome of one seed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SeedOutcome {
    pub seed: u64,
    pub ticks: u64,
    /// Per kind in `Kind::ALL` order (plants, herbivores, carnivores).
    pub fate: [KindFate; 3],
    pub final_alive: [u64; 3],
    pub peak_alive: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    /// Ticks during which all three kinds were alive (= first extinction tick
    /// of any kind, or `ticks` if none died out).
    pub coexist_until: u64,
}

/// Run `cfg` with `seed` (overrides `cfg.seed`) for `ticks` ticks.
pub fn survival_run(cfg: &Config, seed: u64, ticks: u64) -> Result<SeedOutcome, SimError> {
    let mut c = cfg.clone();
    c.seed = seed;
    let mut sim = Simulation::new(c)?;
    let mut fate = [KindFate::default(); 3];
    let mut peak = [0u64; 3];
    for k in Kind::ALL {
        let n = sim.organisms().count_alive(k) as u64;
        peak[k.index()] = n;
        if n == 0 {
            fate[k.index()].extinct_at = Some(0);
        }
    }
    while sim.tick() < ticks {
        sim.step();
        let s = *sim.last_stats();
        for k in Kind::ALL {
            let i = k.index();
            peak[i] = peak[i].max(s.alive[i]);
            if s.alive[i] == 0 && fate[i].extinct_at.is_none() {
                fate[i].extinct_at = Some(sim.tick());
            }
        }
        if fate.iter().all(|f| f.extinct_at.is_some()) {
            break; // nothing can ever be created again
        }
    }
    let t = sim.totals();
    let coexist_until = fate.iter().filter_map(|f| f.extinct_at).min().unwrap_or(ticks);
    Ok(SeedOutcome {
        seed,
        ticks,
        fate,
        final_alive: Kind::ALL.map(|k| sim.organisms().count_alive(k) as u64),
        peak_alive: peak,
        births: t.births,
        deaths: t.deaths,
        coexist_until,
    })
}

/// Runs every seed on its own thread; results in the order of `seeds`.
pub fn survival_runs(cfg: &Config, seeds: &[u64], ticks: u64) -> Result<Vec<SeedOutcome>, SimError> {
    std::thread::scope(|s| {
        let hs: Vec<_> = seeds.iter().map(|&seed| s.spawn(move || survival_run(cfg, seed, ticks))).collect();
        hs.into_iter().map(|h| h.join().expect("survival thread panicked")).collect()
    })
}

/// Name of a kind in reports.
pub fn kind_label(k: Kind) -> &'static str {
    match k {
        Kind::Plant => "plants",
        Kind::Herbivore => "herbivores",
        Kind::Carnivore => "carnivores",
    }
}

/// One text line, e.g.
/// `seed 3: plants survived (final 2911) | herbivores survived (final 788) | carnivores extinct at tick 1288 | coexistence 1288 ticks`.
pub fn format_line(o: &SeedOutcome) -> String {
    let parts: Vec<String> = Kind::ALL
        .iter()
        .map(|&k| {
            let i = k.index();
            match o.fate[i].extinct_at {
                Some(t) => format!("{} extinct at tick {t} (peak {})", kind_label(k), o.peak_alive[i]),
                None => format!("{} survived (final {}, peak {})", kind_label(k), o.final_alive[i], o.peak_alive[i]),
            }
        })
        .collect();
    format!("seed {}: {} | coexistence {} of {} ticks", o.seed, parts.join(" | "), o.coexist_until, o.ticks)
}

/// JSON form of an outcome (`extinct_at` null = survived).
pub fn outcome_json(o: &SeedOutcome) -> serde_json::Value {
    let mut kinds = serde_json::Map::new();
    for k in Kind::ALL {
        let i = k.index();
        kinds.insert(
            kind_label(k).to_string(),
            serde_json::json!({
                "survived": o.fate[i].extinct_at.is_none(),
                "extinct_at": o.fate[i].extinct_at,
                "final_alive": o.final_alive[i],
                "peak_alive": o.peak_alive[i],
                "births": o.births[i],
                "deaths": o.deaths[i],
            }),
        );
    }
    serde_json::json!({"seed": o.seed, "ticks": o.ticks, "coexist_until": o.coexist_until, "kinds": kinds})
}

//! Perception (ADR-016): living organisms within `floor(traits.vision)`
//! cells (toroidal Chebyshev, so across the wrapping edges), self excluded,
//! ordered by (distance, id). No RNG, no energy cost.

use crate::ids::EntityId;
use crate::organism::{Kind, Population, Traits};
use crate::spatial::Neighbour;
use crate::topology::Cell;

/// What one animal sees this tick.
#[derive(Debug, Clone, PartialEq)]
pub struct Perception {
    pub center: Cell,
    pub radius: u32,
    /// Living organisms within `radius`, without the observer, by (distance, id).
    pub seen: Vec<Neighbour>,
}

impl Perception {
    pub fn of_kind(&self, kind: Kind) -> impl Iterator<Item = &Neighbour> {
        self.seen.iter().filter(move |n| n.kind == kind)
    }

    /// Nearest seen organism of `kind` (ties: lower ID).
    pub fn nearest(&self, kind: Kind) -> Option<&Neighbour> {
        self.of_kind(kind).next()
    }
}

/// Vision radius in whole cells: `floor(vision)` (non-finite/negative → 0).
pub fn vision_radius(t: &Traits) -> u32 {
    if t.vision.is_finite() && t.vision > 0.0 {
        t.vision.floor() as u32
    } else {
        0
    }
}

/// Perception of the living organism `id` (`None` if absent or dead).
pub fn perceive(pop: &Population, id: EntityId) -> Option<Perception> {
    let o = pop.get_alive(id)?;
    let (center, radius) = (o.pos(), vision_radius(o.traits()));
    let mut seen = pop.within(center, radius, None);
    seen.retain(|n| n.id != id);
    Some(Perception { center, radius, seen })
}

//! The single simulation random number generator (ADR-005, ADR-008).
//!
//! `Rng` is xoshiro256** (Blackman & Vigna) seeded by SplitMix64. It is the
//! only source of randomness in the engine; every module receives `&mut Rng`
//! explicitly from the `Simulation`. There is no `Default` and no constructor
//! that does not take a seed or an exported state, so unseeded generators
//! cannot be created by accident.
//!
//! The full generator state (4 × u64) can be exported with [`Rng::state`] and
//! restored exactly with [`Rng::from_state`]; [`RngState::to_hex`] /
//! [`RngState::from_hex`] give a lossless text form for JSON checkpoints.

use std::fmt;

#[cfg(test)]
mod tests;

/// SplitMix64 (Steele, Lea, Flood), used only to expand a 64-bit seed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SplitMix64 {
    state: u64,
}

impl SplitMix64 {
    pub fn new(seed: u64) -> Self {
        SplitMix64 { state: seed }
    }

    pub fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }
}

/// Error restoring a generator state.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RngError {
    /// xoshiro256** must not be in the all-zero state.
    AllZeroState,
    /// The hex text was not exactly 64 hex digits.
    BadHex(String),
}

impl fmt::Display for RngError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RngError::AllZeroState => write!(f, "rng state must not be all zero"),
            RngError::BadHex(msg) => write!(f, "invalid rng state hex: {msg}"),
        }
    }
}

impl std::error::Error for RngError {}

/// Exported generator state: the four xoshiro256** words s0..s3.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct RngState {
    pub s: [u64; 4],
}

impl RngState {
    /// 64 lowercase hex digits: s0..s3, each word big-endian (16 digits).
    pub fn to_hex(&self) -> String {
        self.s.iter().map(|w| format!("{w:016x}")).collect()
    }

    /// Inverse of [`RngState::to_hex`]; accepts upper- or lowercase digits.
    /// Rejects wrong length, non-hex characters and the all-zero state.
    pub fn from_hex(text: &str) -> Result<RngState, RngError> {
        if text.len() != 64 {
            return Err(RngError::BadHex(format!(
                "expected 64 hex digits, got {} characters",
                text.chars().count()
            )));
        }
        if !text.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err(RngError::BadHex("contains a non-hex character".to_string()));
        }
        let mut s = [0u64; 4];
        for (i, w) in s.iter_mut().enumerate() {
            let chunk = &text[i * 16..(i + 1) * 16];
            *w = u64::from_str_radix(chunk, 16)
                .map_err(|e| RngError::BadHex(e.to_string()))?;
        }
        if s == [0; 4] {
            return Err(RngError::AllZeroState);
        }
        Ok(RngState { s })
    }
}

/// xoshiro256** generator. Clone is allowed (tests, look-ahead); the
/// simulation itself owns exactly one instance.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Rng {
    s: [u64; 4],
}

impl Rng {
    /// Seed from a 64-bit value: state = 4 consecutive SplitMix64 outputs.
    ///
    /// Guard: should those four outputs all be zero (practically impossible),
    /// SplitMix64 is restarted from `seed ^ 0x9E3779B97F4A7C15` and the state
    /// refilled until it is non-zero, so every seed yields a valid generator.
    pub fn seed_from_u64(seed: u64) -> Self {
        let mut sm = SplitMix64::new(seed);
        let mut s = [sm.next_u64(), sm.next_u64(), sm.next_u64(), sm.next_u64()];
        if s == [0; 4] {
            let mut sm2 = SplitMix64::new(seed ^ 0x9E37_79B9_7F4A_7C15);
            while s == [0; 4] {
                s = [sm2.next_u64(), sm2.next_u64(), sm2.next_u64(), sm2.next_u64()];
            }
        }
        Rng { s }
    }

    /// Restore an exported state exactly.
    pub fn from_state(st: RngState) -> Result<Self, RngError> {
        if st.s == [0; 4] {
            return Err(RngError::AllZeroState);
        }
        Ok(Rng { s: st.s })
    }

    /// Export the full state (restoring it reproduces all later draws).
    pub fn state(&self) -> RngState {
        RngState { s: self.s }
    }

    /// Next raw 64-bit output (xoshiro256** reference algorithm).
    pub fn next_u64(&mut self) -> u64 {
        let s = &mut self.s;
        let result = s[1].wrapping_mul(5).rotate_left(7).wrapping_mul(9);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        result
    }

    /// Upper 32 bits of one draw.
    pub fn next_u32(&mut self) -> u32 {
        (self.next_u64() >> 32) as u32
    }

    /// Uniform in [0, 1) with 53 bits of precision.
    pub fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 * (1.0 / (1u64 << 53) as f64)
    }

    /// Uniform in [0, 1) with 24 bits of precision.
    pub fn next_f32(&mut self) -> f32 {
        (self.next_u64() >> 40) as f32 * (1.0 / (1u32 << 24) as f32)
    }

    /// Unbiased uniform integer in [0, n) (Lemire multiply-shift with
    /// rejection). Panics if `n == 0`.
    pub fn below(&mut self, n: u64) -> u64 {
        assert!(n > 0, "Rng::below(0)");
        let threshold = n.wrapping_neg() % n;
        loop {
            let m = (self.next_u64() as u128) * (n as u128);
            if (m as u64) >= threshold {
                return (m >> 64) as u64;
            }
        }
    }

    /// Uniform integer in the inclusive range [lo, hi]. Panics if lo > hi.
    pub fn range_u32(&mut self, lo: u32, hi: u32) -> u32 {
        assert!(lo <= hi, "Rng::range_u32: lo > hi");
        let span = (hi - lo) as u64 + 1;
        lo + self.below(span) as u32
    }

    /// Uniform integer in the inclusive range [lo, hi], full i64 span safe.
    /// Panics if lo > hi.
    pub fn range_i64(&mut self, lo: i64, hi: i64) -> i64 {
        assert!(lo <= hi, "Rng::range_i64: lo > hi");
        let span = (hi as i128 - lo as i128) as u128 + 1;
        let off = if span > u64::MAX as u128 {
            self.next_u64()
        } else {
            self.below(span as u64)
        };
        (lo as i128 + off as i128) as i64
    }

    /// `lo + (hi - lo) * next_f64()`.
    pub fn range_f64(&mut self, lo: f64, hi: f64) -> f64 {
        lo + (hi - lo) * self.next_f64()
    }

    /// True with probability `p` (`next_f64() < p`). Always consumes exactly
    /// one draw, also for p <= 0 (never) and p >= 1 (always).
    pub fn chance(&mut self, p: f64) -> bool {
        self.next_f64() < p
    }

    /// Normal deviate via Box–Muller. Two draws per call, no cached spare, so
    /// the generator state stays exactly four words.
    pub fn normal(&mut self, mean: f64, sd: f64) -> f64 {
        let u1 = 1.0 - self.next_f64(); // (0, 1]
        let u2 = self.next_f64();
        let r = (-2.0 * u1.ln()).sqrt();
        mean + sd * r * (std::f64::consts::TAU * u2).cos()
    }

    /// Fisher–Yates shuffle from the end: for i = len-1 down to 1,
    /// swap(i, below(i+1)). Slices of length 0 or 1 consume no draws.
    pub fn shuffle<T>(&mut self, xs: &mut [T]) {
        let mut i = xs.len();
        while i > 1 {
            i -= 1;
            let j = self.below(i as u64 + 1) as usize;
            xs.swap(i, j);
        }
    }

    /// Uniform index into a collection of `len` items; `None` (no draw) if 0.
    pub fn choose_index(&mut self, len: usize) -> Option<usize> {
        if len == 0 {
            None
        } else {
            Some(self.below(len as u64) as usize)
        }
    }
}

//! TASK-006 climate tests. See tasks/TASK-006/handoffs/plan-cycle1.md for the
//! mapping of tests to the acceptance criteria.

use super::biome::*;
use super::export::{to_json, to_ppm, to_text};
use super::*;
use crate::config::{preset, preset_names};
use crate::sim::Simulation;

fn params(noise: bool) -> ClimateParams {
    let mut p = ClimateParams::default();
    if !noise {
        p.noise_temperature = 0.0;
        p.noise_precipitation = 0.0;
    }
    p
}

fn gen(w: u32, h: u32, p: &ClimateParams, seed: u64) -> ClimateMap {
    ClimateMap::generate(&Torus::new(w, h).unwrap(), p, seed)
}

/// Pole → equator column string (x = 0) for the first half of the rows plus the rest.
fn column(m: &ClimateMap) -> String {
    (0..m.height()).map(|y| m.get(Cell::new(0, y)).biome.symbol()).collect()
}

// ---------- every cell has a climate following from its position ----------

#[test]
fn every_cell_has_finite_climate() {
    let p = params(true);
    for (w, h) in [(64, 48), (17, 5), (1, 1), (200, 3)] {
        let m = gen(w, h, &p, 7);
        assert_eq!(m.cells().len(), (w * h) as usize);
        for c in m.cells() {
            assert!(c.temperature.is_finite());
            assert!(c.precipitation >= 0.0 && c.precipitation <= p.max_precipitation);
            assert!((0.0..=90.0).contains(&c.latitude));
            assert_eq!(c.biome, Biome::classify(c.temperature, c.precipitation / p.max_precipitation));
        }
    }
}

#[test]
fn climate_is_function_of_position_and_seed() {
    let p = params(true);
    assert_eq!(gen(64, 48, &p, 5), gen(64, 48, &p, 5));
    assert_ne!(gen(64, 48, &p, 5).cells(), gen(64, 48, &p, 6).cells());
    // Without noise every row is uniform and independent of the seed.
    let q = params(false);
    let a = gen(64, 48, &q, 1);
    assert_eq!(a.cells(), gen(64, 48, &q, 999).cells());
    for y in 0..48 {
        let c0 = *a.get(Cell::new(0, y));
        for x in 1..64 {
            assert_eq!(*a.get(Cell::new(x, y)), c0);
        }
        assert_eq!(c0.latitude, latitude_deg(y, 48));
        assert_eq!(c0.temperature, zonal_temperature(&q, c0.latitude));
    }
    // From config and via the world.
    let cfg = Config::contract_example();
    let m = ClimateMap::from_config(&cfg).unwrap();
    assert_eq!(&m, Simulation::new(cfg.clone()).unwrap().world().climate());
    assert_eq!(m.base_temperature(Cell::new(3, 4)), m.get(Cell::new(3, 4)).temperature);
    assert_eq!(m.base_precipitation(Cell::new(3, 4)), m.get(Cell::new(3, 4)).precipitation);
    assert_eq!(m.biome(Cell::new(3, 4)), m.get(Cell::new(3, 4)).biome);
}

#[test]
fn latitude_formula_values() {
    assert!((latitude_deg(0, 48) - 88.125).abs() < 1e-12);
    assert!((latitude_deg(47, 48) - 88.125).abs() < 1e-12);
    assert!((latitude_deg(23, 48) - 1.875).abs() < 1e-12);
    assert!((latitude_deg(24, 48) - 1.875).abs() < 1e-12);
    assert_eq!(latitude_deg(0, 1), 0.0);
    assert_eq!(latitude_deg(0, 2), 45.0);
    assert_eq!(latitude_deg(1, 2), 45.0);
    assert_eq!(latitude_deg(1, 3), 0.0);
    for h in 1..60 {
        for y in 0..h {
            assert_eq!(latitude_deg(y, h), latitude_deg(h - 1 - y, h), "mirror symmetry h={h} y={y}");
        }
    }
}

#[test]
fn zonal_profiles() {
    let p = params(false);
    assert_eq!(zonal_temperature(&p, 0.0), p.equator_temperature);
    assert!((zonal_temperature(&p, 90.0) - p.pole_temperature).abs() < 1e-9);
    assert!(zonal_precipitation_rel(0.0) == 1.0);
    assert!(zonal_precipitation_rel(25.0) < 0.3); // dry subtropics
    assert!(zonal_precipitation_rel(55.0) > 0.6); // storm track
    assert!(zonal_precipitation_rel(90.0) < 0.2); // dry poles
}

// ---------- Earth-like zone order ----------

#[test]
fn classify_thresholds() {
    assert_eq!(Biome::classify(-10.01, 1.0), Biome::Polar);
    assert_eq!(Biome::classify(-10.0, 1.0), Biome::Tundra);
    assert_eq!(Biome::classify(-0.01, 0.0), Biome::Tundra);
    assert_eq!(Biome::classify(0.0, 0.0), Biome::Temperate);
    assert_eq!(Biome::classify(17.99, 1.0), Biome::Temperate);
    assert_eq!(Biome::classify(18.0, 0.29), Biome::Desert);
    assert_eq!(Biome::classify(18.0, 0.3), Biome::Savanna);
    assert_eq!(Biome::classify(30.0, 0.59), Biome::Savanna);
    assert_eq!(Biome::classify(30.0, 0.6), Biome::Tropical);
    let ranks: Vec<u8> = Biome::ALL.iter().map(|b| b.rank()).collect();
    assert_eq!(ranks, vec![0, 1, 2, 3, 4, 5]);
    assert!(Biome::Polar < Biome::Tundra && Biome::Tundra < Biome::Temperate);
    assert!(Biome::Temperate < Biome::Desert && Biome::Savanna < Biome::Tropical);
    assert!(Biome::Desert.is_dry() && Biome::Savanna.is_dry() && !Biome::Tropical.is_dry());
    let zones: Vec<u8> = Biome::ALL.iter().map(|b| b.zone()).collect();
    assert_eq!(zones, vec![0, 1, 2, 3, 3, 4]);
    for b in Biome::ALL {
        assert_eq!(Biome::from_symbol(b.symbol()), Some(b));
    }
    assert_eq!(POLAR_MAX_T, -10.0);
    assert_eq!(TUNDRA_MAX_T, 0.0);
    assert_eq!(TEMPERATE_MAX_T, 18.0);
    assert_eq!(DESERT_MAX_R, 0.3);
    assert_eq!(SAVANNA_MAX_R, 0.6);
}

/// Zones (polar, tundra, temperate, dry, tropical) never go back towards cold
/// when walking from the pole band to the equator in either hemisphere.
fn assert_pole_to_equator_order(m: &ClimateMap, label: &str) {
    let h = m.height();
    for x in 0..m.width() {
        // Upper hemisphere: y = 0 (pole) → (h-1)/2 (equator); lower: y = h-1 → h/2.
        let up: Vec<u8> = (0..h.div_ceil(2)).map(|y| m.biome(Cell::new(x, y)).zone()).collect();
        let down: Vec<u8> = (h / 2..h).rev().map(|y| m.biome(Cell::new(x, y)).zone()).collect();
        for seq in [up, down] {
            assert!(seq.windows(2).all(|w| w[0] <= w[1]), "{label}: order broken in column {x}: {seq:?}");
        }
    }
}

#[test]
fn default_zone_order_pole_to_equator() {
    let p = params(false);
    let m = gen(64, 48, &p, 1);
    assert_eq!(column(&m), "IIIIUUUUFFFFFFDDDDDSSRRRRRRSSDDDDDFFFFFFUUUUIIII");
    // With defaults even the six ranks are monotone pole → equator.
    let up: Vec<u8> = (0..24).map(|y| m.biome(Cell::new(0, y)).rank()).collect();
    assert!(up.windows(2).all(|w| w[0] <= w[1]));
    let counts = m.biome_counts();
    assert!(counts.iter().all(|&n| n > 0), "all six biomes appear: {counts:?}");
    for h in [48, 100, 37, 12, 5, 3, 2, 1] {
        assert_pole_to_equator_order(&gen(4, h, &p, 1), &format!("h={h}"));
    }
    assert_eq!(column(&gen(1, 1, &p, 0)), "R");
    assert_eq!(column(&gen(1, 2, &p, 0)), "FF");
    assert_eq!(column(&gen(1, 3, &p, 0)), "FRF");
    assert_eq!(column(&gen(1, 5, &p, 0)), "UFRFU");
}

#[test]
fn presets_preserve_order() {
    for name in preset_names() {
        let mut cfg = preset(name).unwrap();
        cfg.climate.noise_temperature = 0.0;
        cfg.climate.noise_precipitation = 0.0;
        let m = ClimateMap::from_config(&cfg).unwrap();
        assert_pole_to_equator_order(&m, name);
    }
}

#[test]
fn noise_does_not_scramble_zones() {
    let p = params(true);
    for seed in 1..=20u64 {
        let m = gen(64, 48, &p, seed);
        let majority = |y: u32| -> u8 {
            let mut n = [0usize; 6];
            for x in 0..64 {
                n[m.biome(Cell::new(x, y)).zone() as usize] += 1;
            }
            (0..5u8).max_by_key(|&r| (n[r as usize], r)).unwrap()
        };
        let up: Vec<u8> = (0..24).map(majority).collect();
        let down: Vec<u8> = (24..48).rev().map(majority).collect();
        for seq in [up, down] {
            assert!(seq.windows(2).all(|w| w[0] <= w[1]), "seed {seed}: {seq:?}");
            assert_eq!(seq[0], Biome::Polar.zone());
            assert_eq!(*seq.last().unwrap(), Biome::Tropical.zone());
        }
    }
}

// ---------- no seam ----------

#[derive(Default, Clone, Copy, Debug)]
struct MaxDiff {
    t: f64,
    p: f64,
    rank: u8,
}

impl MaxDiff {
    fn add(&mut self, a: &CellClimate, b: &CellClimate) {
        self.t = self.t.max((a.temperature - b.temperature).abs());
        self.p = self.p.max((a.precipitation - b.precipitation).abs());
        self.rank = self.rank.max(a.biome.rank().abs_diff(b.biome.rank()));
    }
}

/// (interior, seam) maximum differences of horizontally (axis 0) or
/// vertically (axis 1) adjacent pairs.
fn axis_diffs(m: &ClimateMap, axis: u8) -> (MaxDiff, MaxDiff) {
    let (w, h) = (m.width(), m.height());
    let (mut inner, mut seam) = (MaxDiff::default(), MaxDiff::default());
    for y in 0..h {
        for x in 0..w {
            let (nx, ny, is_seam) =
                if axis == 0 { ((x + 1) % w, y, x + 1 == w) } else { (x, (y + 1) % h, y + 1 == h) };
            let (a, b) = (m.get(Cell::new(x, y)), m.get(Cell::new(nx, ny)));
            if is_seam {
                seam.add(a, b);
            } else {
                inner.add(a, b);
            }
        }
    }
    (inner, seam)
}

#[test]
fn seam_pairs_no_larger_than_interior() {
    let sizes = [(64, 48), (33, 17), (100, 7), (7, 100), (16, 16), (5, 5), (3, 3), (48, 36), (96, 64), (2, 2), (1, 9), (9, 1)];
    let mut checked = 0;
    for noise in [false, true] {
        let p = params(noise);
        for &(w, h) in &sizes {
            for seed in 0..30u64 {
                let m = gen(w, h, &p, seed);
                for axis in [0u8, 1] {
                    let dim = if axis == 0 { w } else { h };
                    let (inner, seam) = axis_diffs(&m, axis);
                    let ctx = format!("{w}x{h} seed {seed} noise {noise} axis {axis}: inner {inner:?} seam {seam:?}");
                    if dim >= 2 {
                        assert!(seam.t <= inner.t + 1e-9, "{ctx}");
                        assert!(seam.p <= inner.p + 1e-9, "{ctx}");
                        assert!(seam.rank <= inner.rank, "{ctx}");
                    } else {
                        // dim 1: the seam neighbour is the cell itself.
                        assert!(seam.t == 0.0 && seam.p == 0.0 && seam.rank == 0, "{ctx}");
                    }
                    checked += 1;
                }
            }
        }
    }
    assert_eq!(checked, 2 * sizes.len() * 30 * 2);
}

/// Every 8-neighbour pair (seams included) obeys the analytic Lipschitz bound:
/// zonal part: dφ/dy = 180/h deg per row, |dT/dφ| ≤ (T_eq−T_pole)·π/180
/// → (T_eq−T_pole)·π/h per row; |dp/dφ| ≤ 0.9·(2/15)·0.429 + 0.55·(2/15)·0.429
/// < 0.09 per degree. Noise: smoothstep-bilinear value noise with values in
/// [−1, 1] changes by at most 1.5·2 = 3 per lattice unit per axis; one cell =
/// gx/w (resp. gy/h) lattice units; a diagonal step adds both axes.
#[test]
fn all_neighbour_pairs_within_lipschitz_bound() {
    for (w, h) in [(64, 48), (33, 17), (5, 3), (1, 7), (100, 100), (2, 2)] {
        for seed in 0..10u64 {
            let p = params(true);
            let m = gen(w, h, &p, seed);
            let torus = Torus::new(w, h).unwrap();
            let gx = noise::lattice_size(w, p.noise_scale) as f64;
            let gy = noise::lattice_size(h, p.noise_scale) as f64;
            let nstep = 3.0 * (gx / w as f64 + gy / h as f64);
            let bt = (p.equator_temperature - p.pole_temperature) * std::f64::consts::PI / h as f64
                + p.noise_temperature * nstep
                + 1e-9;
            let bp = p.max_precipitation * (0.09 * 180.0 / h as f64 + p.noise_precipitation * nstep) + 1e-9;
            for c in torus.cells() {
                for (n, _) in torus.neighbours8(c) {
                    let (a, b) = (m.get(c), m.get(n));
                    assert!((a.temperature - b.temperature).abs() <= bt, "{w}x{h} {c:?}-{n:?}");
                    assert!((a.precipitation - b.precipitation).abs() <= bp, "{w}x{h} {c:?}-{n:?}");
                }
            }
        }
    }
}

#[test]
fn continuous_field_is_periodic() {
    for (w, h) in [(64, 48), (33, 17), (5, 3), (1, 1)] {
        let m = gen(w, h, &params(true), 11);
        let (wf, hf) = (w as f64, h as f64);
        for i in 0..200 {
            let fx = -3.0 + i as f64 * 0.37;
            let fy = -2.0 + i as f64 * 0.29;
            let a = m.sample(fx, fy);
            for (b, label) in [(m.sample(fx + wf, fy), "x"), (m.sample(fx, fy + hf), "y"), (m.sample(fx - 2.0 * wf, fy - hf), "xy")] {
                assert!((a.temperature - b.temperature).abs() < 1e-9, "{label} {w}x{h} {fx},{fy}");
                assert!((a.precipitation - b.precipitation).abs() < 1e-9, "{label}");
                assert!((a.latitude - b.latitude).abs() < 1e-9, "{label}");
            }
        }
        // Grid values are exactly the continuous field at integer points.
        for y in 0..h {
            for x in 0..w {
                assert_eq!(m.sample(x as f64, y as f64), *m.get(Cell::new(x, y)));
            }
        }
        // Approaching the seam from either side converges to the same value.
        let left = m.sample(wf - 0.5 - 1e-7, 0.0);
        let right = m.sample(-0.5 + 1e-7, 0.0);
        assert!((left.temperature - right.temperature).abs() < 1e-5);
        let top = m.sample(0.0, -0.5 + 1e-7);
        let bottom = m.sample(0.0, hf - 0.5 - 1e-7);
        assert!((top.temperature - bottom.temperature).abs() < 1e-5);
    }
}

#[test]
fn noise_lattice_wraps() {
    let mut rng = Rng::seed_from_u64(3);
    let n = PeriodicNoise::new(64, 48, 16, &mut rng);
    assert_eq!(n.lattice(), (4, 3));
    for i in 0..100 {
        let fx = i as f64 * 0.113 - 2.0;
        let fy = i as f64 * 0.071 - 1.0;
        let v = n.sample(fx, fy);
        assert!((-1.0..=1.0).contains(&v));
        assert!((v - n.sample(fx + 4.0, fy)).abs() < 1e-12);
        assert!((v - n.sample(fx, fy + 3.0)).abs() < 1e-12);
    }
    // Lattice points return the stored values; wrapping index 4 == 0.
    assert_eq!(n.sample(4.0, 0.0), n.sample(0.0, 0.0));
    assert_eq!(noise::lattice_size(1, 16), 1);
    assert_eq!(noise::lattice_size(7, 16), 1);
    assert_eq!(noise::lattice_size(8, 16), 1);
    assert_eq!(noise::lattice_size(24, 16), 2);
    assert_eq!(noise::lattice_size(100, 1), 100);
    assert_eq!(noise::lattice_size(crate::topology::MAX_DIM, 1), crate::topology::MAX_DIM);
}

// ---------- any size ----------

#[test]
fn tiny_worlds_work() {
    let mut sizes: Vec<(u32, u32)> = Vec::new();
    for w in 1..=9 {
        for h in 1..=9 {
            sizes.push((w, h));
        }
    }
    sizes.extend([(1, 1000), (1000, 1), (2, 2)]);
    let mut p = params(true);
    for &(w, h) in &sizes {
        for seed in [0u64, 1, u64::MAX] {
            for scale in [1u32, 16] {
                p.noise_scale = scale;
                let m = gen(w, h, &p, seed);
                assert_eq!(m.cells().len(), (w * h) as usize);
                assert!(m.cells().iter().all(|c| c.temperature.is_finite() && c.precipitation.is_finite()));
                if h == 1 {
                    assert!(m.cells().iter().all(|c| c.latitude == 0.0));
                }
                let text = to_text(&m);
                assert_eq!(text.lines().take(h as usize).filter(|l| l.chars().count() == w as usize).count(), h as usize);
            }
        }
    }
}

#[test]
fn large_world_builds() {
    let m = gen(1024, 512, &params(true), 42);
    assert_eq!(m.cells().len(), 1024 * 512);
    assert!(m.biome_counts().iter().all(|&n| n > 0));
}

// ---------- determinism / isolation ----------

#[test]
fn climate_does_not_consume_core_rng() {
    let cfg = Config::contract_example();
    let sim = Simulation::new(cfg.clone()).unwrap();
    assert_eq!(sim.rng_state(), Rng::seed_from_u64(cfg.seed).state());
}

// ---------- exports ----------

#[test]
fn text_export_shape() {
    let m = gen(64, 48, &params(true), 42);
    let t = to_text(&m);
    let lines: Vec<&str> = t.lines().collect();
    for l in &lines[..48] {
        assert_eq!(l.chars().count(), 64);
        assert!(l.chars().all(|c| Biome::from_symbol(c).is_some()));
    }
    assert_eq!(lines[48], "");
    for b in Biome::ALL {
        assert!(t.contains(&format!("{} {} (", b.symbol(), b.name())));
    }
    assert!(lines.last().unwrap().contains("counts:"));
}

#[test]
fn json_export_shape() {
    let m = gen(10, 6, &params(true), 42);
    let v = to_json(&m);
    assert_eq!(v["width"], 10);
    assert_eq!(v["height"], 6);
    assert_eq!(v["rows"].as_array().unwrap().len(), 6);
    assert_eq!(v["rows"][2].as_str().unwrap(), m.row_string(2));
    assert_eq!(v["temperature"].as_array().unwrap().len(), 6);
    assert_eq!(v["temperature"][5].as_array().unwrap().len(), 10);
    assert_eq!(v["temperature"][1][3].as_f64().unwrap(), m.get(Cell::new(3, 1)).temperature);
    assert_eq!(v["precipitation"][4][9].as_f64().unwrap(), m.get(Cell::new(9, 4)).precipitation);
    assert_eq!(v["latitude"].as_array().unwrap().len(), 6);
    assert_eq!(v["biomes"].as_array().unwrap().len(), 6);
    let total: u64 = Biome::ALL.iter().map(|b| v["counts"][b.name()].as_u64().unwrap()).sum();
    assert_eq!(total, 60);
}

#[test]
fn ppm_export_shape() {
    let m = gen(7, 3, &params(true), 42);
    let ppm = to_ppm(&m);
    let header = b"P6\n7 3\n255\n";
    assert_eq!(&ppm[..header.len()], header);
    assert_eq!(ppm.len(), header.len() + 7 * 3 * 3);
    assert_eq!(&ppm[header.len()..header.len() + 3], &m.get(Cell::new(0, 0)).biome.rgb());
}

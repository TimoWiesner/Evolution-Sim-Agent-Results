//! Typed events emitted during a tick (ADR-008).

use super::schedule::Phase;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Parents};
use crate::species::SpeciesId;

/// What happened. Extended by later tasks (births, deaths, extinctions, ...).
#[derive(Debug, Clone, PartialEq)]
#[non_exhaustive]
pub enum EventKind {
    /// Diagnostic event used by tests and tracing hooks.
    Probe { value: u64 },
    /// An organism was born (Births phase, TASK-008).
    Birth { id: EntityId, kind: Kind, parents: Parents, generation: u32 },
    /// An organism died (emitted in the Deaths phase for every death flagged
    /// since the previous Deaths phase, in flag order; TASK-008).
    Death { id: EntityId, kind: Kind, cause: DeathCause, age: u32 },
    /// A species arose in `tick` (Species phase, TASK-017; root species at tick 0).
    SpeciesAppeared { species: SpeciesId, kind: Kind, parent: Option<SpeciesId>, tick: u64 },
    /// The last member of a species died in `tick` (Species phase, TASK-017).
    SpeciesExtinct { species: SpeciesId, kind: Kind, tick: u64 },
}

/// One event, tagged with the tick and phase it was emitted in.
#[derive(Debug, Clone, PartialEq)]
pub struct Event {
    pub tick: u64,
    pub phase: Phase,
    pub kind: EventKind,
}

/// Result of one `Simulation::step`: the processed tick, the phases run (in
/// order, always `Phase::ORDER`) and the events in emission order.
#[derive(Debug, Clone, PartialEq)]
pub struct TickReport {
    pub tick: u64,
    pub phases: Vec<Phase>,
    pub events: Vec<Event>,
}

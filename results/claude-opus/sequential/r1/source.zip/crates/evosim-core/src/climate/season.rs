//! Seasonal cycle and documented climate bounds (ADR-010, TASK-007).
//!
//! Pure functions, no RNG. The year phase is computed from the integer
//! `tick mod year_length`, so ticks `t` and `t + Y` give bit-identical values.
//! All cells share the same phase (opposite hemispheric seasons would put
//! summer next to winter across the polar seam); the amplitude depends on
//! latitude.

use super::CellClimate;
use crate::config::ClimateParams;

/// Seasonal phase `s = sin(2π·(tick mod Y)/Y)` in [-1, 1]; `k = 0` spring
/// equinox, `k = Y/4` midsummer, `k = 3Y/4` midwinter. `Y = 0` is treated as 1.
pub fn year_phase(tick: u64, year_length: u32) -> f64 {
    let y = year_length.max(1) as u64;
    let k = tick % y;
    (std::f64::consts::TAU * k as f64 / y as f64).sin()
}

/// Latitude weight of the seasonal temperature swing: `0.1 + 0.9·sin φ`.
pub fn temperature_weight(lat_deg: f64) -> f64 {
    0.1 + 0.9 * lat_deg.to_radians().sin()
}

/// Latitude weight of the seasonal precipitation modulation:
/// `0.25 + 0.75·exp(−((φ−20)/15)²)` (strongest in the subtropics/tropics).
pub fn precipitation_weight(lat_deg: f64) -> f64 {
    let z = (lat_deg - 20.0) / 15.0;
    0.25 + 0.75 * (-z * z).exp()
}

/// Current (seasonal + weather) climate of one cell.
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct CellNow {
    /// Temperature in °C.
    pub temperature: f64,
    /// Precipitation in [0, climate.max_precipitation].
    pub precipitation: f64,
}

/// Closed-form bounds that every current cell value obeys (ADR-010):
/// `T ∈ [T_pole − A_T − A_s − 3σ_T, T_eq + A_T + A_s + 3σ_T]`, `P ∈ [0, P_max]`.
/// The weather SD enters the bounds even when weather is disabled.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ClimateBounds {
    pub t_min: f64,
    pub t_max: f64,
    pub p_min: f64,
    pub p_max: f64,
}

impl ClimateBounds {
    pub fn from_params(p: &ClimateParams) -> Self {
        let lo = p.pole_temperature.min(p.equator_temperature);
        let hi = p.pole_temperature.max(p.equator_temperature);
        let spread = p.noise_temperature + p.seasonal_amplitude + 3.0 * p.weather_temperature_sd;
        ClimateBounds { t_min: lo - spread, t_max: hi + spread, p_min: 0.0, p_max: p.max_precipitation }
    }

    pub fn contains(&self, c: CellNow) -> bool {
        c.temperature.is_finite()
            && c.precipitation.is_finite()
            && c.temperature >= self.t_min
            && c.temperature <= self.t_max
            && c.precipitation >= self.p_min
            && c.precipitation <= self.p_max
    }
}

/// The one formula for the current climate of a cell: base climate, season
/// phase `s` and weather anomalies `a_t` (°C) / `a_p` (relative units).
pub fn combine(p: &ClimateParams, bounds: &ClimateBounds, base: &CellClimate, s: f64, a_t: f64, a_p: f64) -> CellNow {
    let t = base.temperature + p.seasonal_amplitude * temperature_weight(base.latitude) * s + a_t;
    let r_base = if p.max_precipitation > 0.0 { base.precipitation / p.max_precipitation } else { 0.0 };
    let r = r_base * (1.0 + p.precipitation_seasonality * precipitation_weight(base.latitude) * s) + a_p;
    CellNow {
        temperature: t.clamp(bounds.t_min, bounds.t_max),
        precipitation: p.max_precipitation * r.clamp(0.0, 1.0),
    }
}

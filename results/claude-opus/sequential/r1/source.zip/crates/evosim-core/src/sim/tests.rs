use super::*;
use crate::ids::EntityId;

fn cfg(seed: u64) -> Config {
    Config::new(seed, 40, 30, 0, 0, 0)
}

/// Trace entry per tick: (tick, phases, events, rng state after the tick).
type Trace = Vec<(u64, Vec<Phase>, Vec<Event>, RngState)>;

/// Probe hook: every phase draws from the simulation RNG; acting phases also
/// compute the acting order of a fixed synthetic ID set.
fn probe(ctx: &mut PhaseCtx<'_>) {
    let v = ctx.rng.next_u64();
    ctx.emit(EventKind::Probe { value: v });
    if ctx.phase.is_acting() {
        let ids: Vec<EntityId> = (1..=20).map(EntityId).collect();
        let order = acting_order(&ids, ctx.rng);
        ctx.emit(EventKind::Probe { value: order[0].0 });
    }
}

fn trace(sim: &mut Simulation, ticks: u64) -> Trace {
    (0..ticks)
        .map(|_| {
            let r = sim.step_with(probe);
            (r.tick, r.phases, r.events, sim.rng_state())
        })
        .collect()
}

#[test]
fn new_holds_config_world_rng() {
    let c = cfg(42);
    let sim = Simulation::new(c.clone()).unwrap();
    assert_eq!(sim.tick(), 0);
    assert_eq!(sim.config(), &c);
    assert_eq!(sim.world().torus().width(), 40);
    assert_eq!(sim.world().torus().height(), 30);
    assert_eq!(sim.rng_state(), Rng::seed_from_u64(42).state());
    assert_eq!(sim.next_entity_id(), 1);
}

#[test]
fn invalid_world_is_error() {
    let mut c = cfg(1);
    c.world.width = 0;
    assert!(matches!(Simulation::new(c), Err(SimError::World(_))));
}

#[test]
fn step_advances_exactly_one_tick() {
    let mut sim = Simulation::new(cfg(1)).unwrap();
    for t in 0..5 {
        let r = sim.step();
        assert_eq!(r.tick, t);
        assert_eq!(sim.tick(), t + 1);
    }
    sim.run(245);
    assert_eq!(sim.tick(), 250);
}

#[test]
fn phase_order_is_fixed() {
    use Phase::*;
    assert_eq!(
        Phase::ORDER,
        [Climate, Resources, Plants, Herbivores, Carnivores, Births, Deaths, Species, Statistics]
    );
    let mut sim = Simulation::new(cfg(1)).unwrap();
    let r = sim.step();
    assert_eq!(r.phases, Phase::ORDER.to_vec());
    let acting: Vec<Phase> = Phase::ORDER.into_iter().filter(|p| p.is_acting()).collect();
    assert_eq!(acting, vec![Plants, Herbivores, Carnivores]);
    let names: Vec<&str> = Phase::ORDER.iter().map(|p| p.name()).collect();
    assert_eq!(
        names,
        ["climate", "resources", "plants", "herbivores", "carnivores", "births", "deaths", "species", "statistics"]
    );
}

#[test]
fn hook_sees_phases_in_order_with_current_tick() {
    let mut sim = Simulation::new(cfg(1)).unwrap();
    sim.run(3);
    let mut seen = Vec::new();
    let r = sim.step_with(|ctx| seen.push((ctx.tick, ctx.phase)));
    assert_eq!(r.tick, 3);
    assert_eq!(seen, Phase::ORDER.iter().map(|&p| (3, p)).collect::<Vec<_>>());
}

#[test]
fn events_keep_emission_order_and_tags() {
    let mut sim = Simulation::new(cfg(1)).unwrap();
    let mut n = 0;
    let r = sim.step_with(|ctx| {
        n += 1;
        ctx.emit(EventKind::Probe { value: n });
    });
    assert_eq!(r.events.len(), 9);
    for (i, e) in r.events.iter().enumerate() {
        assert_eq!(e.tick, 0);
        assert_eq!(e.phase, Phase::ORDER[i]);
        assert_eq!(e.kind, EventKind::Probe { value: i as u64 + 1 });
    }
}

#[test]
fn acting_order_is_permutation_and_deterministic() {
    let ids: Vec<EntityId> = (1..=50).map(|i| EntityId(i * 3)).collect();
    let mut rev = ids.clone();
    rev.reverse();
    let mut r1 = Rng::seed_from_u64(5);
    let mut r2 = Rng::seed_from_u64(5);
    let a = acting_order(&ids, &mut r1);
    let b = acting_order(&rev, &mut r2);
    assert_eq!(a, b, "input order must not matter");
    assert_eq!(r1, r2);
    let mut sorted = a.clone();
    sorted.sort();
    assert_eq!(sorted, ids);
    let c = acting_order(&ids, &mut Rng::seed_from_u64(6));
    assert_ne!(a, c);
    let mut buf = vec![EntityId(999)];
    acting_order_into(&ids, &mut Rng::seed_from_u64(5), &mut buf);
    assert_eq!(buf, a);
}

#[test]
fn acting_order_empty_and_single_draw_nothing() {
    let mut r = Rng::seed_from_u64(5);
    let before = r.state();
    assert!(acting_order(&[], &mut r).is_empty());
    assert_eq!(acting_order(&[EntityId(7)], &mut r), vec![EntityId(7)]);
    assert_eq!(r.state(), before);
}

#[test]
fn tie_break_by_ascending_id() {
    let mut v = vec![(2u32, EntityId(9)), (1, EntityId(5)), (2, EntityId(3)), (1, EntityId(4))];
    v.sort_by(cmp_key_then_id);
    assert_eq!(v, vec![(1, EntityId(4)), (1, EntityId(5)), (2, EntityId(3)), (2, EntityId(9))]);
    use crate::topology::Cell;
    let mut cells = vec![Cell { x: 0, y: 1 }, Cell { x: 5, y: 0 }, Cell { x: 1, y: 0 }];
    cells.sort();
    assert_eq!(cells, vec![Cell { x: 1, y: 0 }, Cell { x: 5, y: 0 }, Cell { x: 0, y: 1 }]);
}

#[test]
fn trace_same_seed_identical_over_150_ticks() {
    let mut a = Simulation::new(cfg(42)).unwrap();
    let mut b = Simulation::new(cfg(42)).unwrap();
    let ta = trace(&mut a, 150);
    let tb = trace(&mut b, 150);
    assert_eq!(ta.len(), 150);
    assert_eq!(ta, tb);
    assert_eq!(a.tick(), 150);
    // 9 draws + 3 acting probes per tick
    assert_eq!(ta[0].2.len(), 12);
}

#[test]
fn trace_different_seed_differs() {
    let ta = trace(&mut Simulation::new(cfg(42)).unwrap(), 150);
    let tb = trace(&mut Simulation::new(cfg(42).with_seed(43)).unwrap(), 150);
    assert_ne!(ta, tb);
    assert_ne!(ta[0], tb[0], "traces differ from tick 0");
    let differing = ta.iter().zip(&tb).filter(|(x, y)| x != y).count();
    assert_eq!(differing, 150);
}

#[test]
fn plain_step_same_seed_same_state_different_seed_differs() {
    let mut a = Simulation::new(cfg(7)).unwrap();
    let mut b = Simulation::new(cfg(7)).unwrap();
    let mut c = Simulation::new(cfg(8)).unwrap();
    for _ in 0..150 {
        assert_eq!(a.step(), b.step());
        c.step();
    }
    assert_eq!(a.rng_state(), b.rng_state());
    assert_eq!(a.tick(), 150);
    assert_ne!(a.rng_state(), c.rng_state());
}

#[test]
fn simulation_resume_continues_identically() {
    let mut a = Simulation::new(cfg(42)).unwrap();
    trace(&mut a, 37);
    let (tick, st, next) = (a.tick(), a.rng_state(), a.next_entity_id());
    let hex = st.to_hex();
    let mut b =
        Simulation::resume(cfg(42), tick, RngState::from_hex(&hex).unwrap(), next).unwrap();
    // Weather lattices are simulation state too (TASK-007).
    b.set_weather_state(a.weather_state()).unwrap();
    assert_eq!(b.tick(), 37);
    assert_eq!(trace(&mut a, 80), trace(&mut b, 80));
    assert_eq!(a.rng_state(), b.rng_state());
    assert!(matches!(
        Simulation::resume(cfg(42), 0, RngState { s: [0; 4] }, 1),
        Err(SimError::Rng(RngError::AllZeroState))
    ));
}

#[test]
fn set_rng_state_mid_run() {
    let mut a = Simulation::new(cfg(3)).unwrap();
    trace(&mut a, 10);
    let saved = a.rng_state();
    let first = trace(&mut a.clone(), 20);
    let mut b = Simulation::new(cfg(3)).unwrap();
    b.run(10);
    b.set_rng_state(saved).unwrap();
    assert_eq!(trace(&mut b, 20), first);
    assert!(b.set_rng_state(RngState { s: [0; 4] }).is_err());
}

fn rs_files(dir: &std::path::Path, out: &mut Vec<std::path::PathBuf>) {
    let mut entries: Vec<_> = std::fs::read_dir(dir).unwrap().map(|e| e.unwrap().path()).collect();
    entries.sort();
    for p in entries {
        if p.is_dir() {
            rs_files(&p, out);
        } else if p.extension().is_some_and(|e| e == "rs") {
            out.push(p);
        }
    }
}

#[test]
fn core_source_has_no_wall_clock_or_global_rng() {
    // Tokens are assembled with concat! so this file does not match itself.
    let forbidden = [
        concat!("System", "Time"),
        concat!("Instant", "::"),
        concat!("std::", "time"),
        concat!("thread", "_rng"),
        concat!("get", "random"),
        concat!("rand", "::"),
        concat!("Hash", "Map"),
        concat!("Hash", "Set"),
        concat!("Random", "State"),
    ];
    let src = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    let mut files = Vec::new();
    rs_files(&src, &mut files);
    assert!(files.len() >= 10, "scan found too few files: {files:?}");
    for f in files {
        let text = std::fs::read_to_string(&f).unwrap();
        for tok in forbidden {
            assert!(!text.contains(tok), "{} contains forbidden token {tok}", f.display());
        }
    }
    let manifest =
        std::fs::read_to_string(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("Cargo.toml"))
            .unwrap();
    for dep in [concat!("ra", "nd"), concat!("get", "random")] {
        assert!(
            !manifest.lines().any(|l| l.trim_start().starts_with(dep)),
            "core Cargo.toml depends on {dep}"
        );
    }
}

#[test]
fn core_manifest_has_no_ui_or_cli_dependency() {
    let manifest =
        std::fs::read_to_string(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("Cargo.toml"))
            .unwrap();
    for dep in [concat!("evosim", "-ui"), concat!("evosim", "-cli"), concat!("tiny", "_http")] {
        assert!(!manifest.contains(dep), "core depends on {dep}");
    }
}

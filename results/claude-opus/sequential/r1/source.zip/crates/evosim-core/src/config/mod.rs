//! Typed simulation configuration (ADR-006, docs/CONFIG.md).
//!
//! JSON is parsed with `serde_json` into a `Value` and read by hand-written
//! (fixed contract keys) and macro-generated (all other groups) readers that
//! check type and range and name the offending dotted key in every error.
//! Unknown keys are an error at every level. All non-fixed parameters have
//! defaults; writing a config emits every key, and reading it back gives an
//! equal `Config`.

mod error;
mod params;
mod presets;
mod value;
#[cfg(test)]
mod tests;

pub use error::{json_type_name, ConfigError, ConfigErrorKind, JSON_KEY, ROOT_KEY};
pub use params::{CarnivoreParams, ClimateParams, HerbivoreParams, HuntingParams, ParamSpec, PlantParams};
pub use presets::{preset, preset_description, preset_names};
pub use value::{ParamValue, Range};

use serde_json::{Map, Value};

/// Valid range of `world.width` / `world.height`.
pub const WORLD_DIM_RANGE: (u32, u32) = (1, 4096);
/// Valid range of each `initial.*` population.
pub const INITIAL_RANGE: (u32, u32) = (0, 1_000_000);

/// Fixed key `world` (contract section 3).
#[derive(Debug, Clone, PartialEq)]
pub struct WorldConfig {
    pub width: u32,
    pub height: u32,
}

/// Fixed key `initial` (contract section 3).
#[derive(Debug, Clone, PartialEq)]
pub struct InitialConfig {
    pub plants: u32,
    pub herbivores: u32,
    pub carnivores: u32,
}

/// Complete simulation configuration.
#[derive(Debug, Clone, PartialEq)]
pub struct Config {
    pub seed: u64,
    /// Free-form name (default `custom`).
    pub name: String,
    /// Free-form description (default empty).
    pub description: String,
    pub world: WorldConfig,
    pub initial: InitialConfig,
    pub climate: ClimateParams,
    pub plants: PlantParams,
    pub herbivores: HerbivoreParams,
    pub carnivores: CarnivoreParams,
    pub hunting: HuntingParams,
}

const TOP_KEYS: &[&str] = &[
    "seed", "name", "description", "world", "initial", "climate", "plants", "herbivores", "carnivores", "hunting",
];
const WORLD_KEYS: &[&str] = &["width", "height"];
const INITIAL_KEYS: &[&str] = &["plants", "herbivores", "carnivores"];
const DEFAULT_NAME: &str = "custom";

fn check_unknown(obj: &Map<String, Value>, allowed: &[&str], prefix: &str) -> Result<(), ConfigError> {
    for k in obj.keys() {
        if !allowed.contains(&k.as_str()) {
            let key = if prefix.is_empty() { k.clone() } else { format!("{prefix}.{k}") };
            return Err(ConfigError::unknown(key));
        }
    }
    Ok(())
}

fn required_object<'a>(obj: &'a Map<String, Value>, key: &str) -> Result<&'a Map<String, Value>, ConfigError> {
    let v = obj.get(key).ok_or_else(|| ConfigError::missing(key))?;
    v.as_object().ok_or_else(|| ConfigError::wrong_type(key, "object", v))
}

fn required<T: ParamValue>(obj: &Map<String, Value>, field: &str, key: &str, range: Range) -> Result<T, ConfigError> {
    let v = obj.get(field).ok_or_else(|| ConfigError::missing(key))?;
    T::read(v, key, range)
}

fn optional<T: ParamValue>(obj: &Map<String, Value>, key: &str, default: T) -> Result<T, ConfigError> {
    match obj.get(key) {
        Some(v) => T::read(v, key, None),
        None => Ok(default),
    }
}

fn r32(r: (u32, u32)) -> Range {
    Some((r.0 as f64, r.1 as f64))
}

impl Config {
    /// The contract section 3 example (seed 42, 64x48, 400/120/20) with all defaults.
    pub fn contract_example() -> Self {
        Self::new(42, 64, 48, 400, 120, 20)
    }

    /// A config with the given fixed keys and defaults for everything else.
    pub fn new(seed: u64, width: u32, height: u32, plants: u32, herbivores: u32, carnivores: u32) -> Self {
        Config {
            seed,
            name: DEFAULT_NAME.to_string(),
            description: String::new(),
            world: WorldConfig { width, height },
            initial: InitialConfig { plants, herbivores, carnivores },
            climate: ClimateParams::default(),
            plants: PlantParams::default(),
            herbivores: HerbivoreParams::default(),
            carnivores: CarnivoreParams::default(),
            hunting: HuntingParams::default(),
        }
    }

    /// Same config with a different seed (for `--seed`).
    pub fn with_seed(mut self, seed: u64) -> Self {
        self.seed = seed;
        self
    }

    /// Parse and validate JSON text.
    pub fn from_json_str(text: &str) -> Result<Self, ConfigError> {
        let v: Value = serde_json::from_str(text).map_err(|e| {
            ConfigError::new(
                JSON_KEY,
                ConfigErrorKind::Parse { line: e.line(), column: e.column(), msg: e.to_string() },
            )
        })?;
        Self::from_value(&v)
    }

    /// Read and validate a parsed JSON value. Returns the first error in
    /// deterministic order: unknown top-level keys, fixed keys, metadata,
    /// groups in schema order, then cross-field checks.
    pub fn from_value(v: &Value) -> Result<Self, ConfigError> {
        let obj = v.as_object().ok_or_else(|| ConfigError::wrong_type(ROOT_KEY, "object", v))?;
        check_unknown(obj, TOP_KEYS, "")?;

        let seed: u64 = required(obj, "seed", "seed", None)?;

        let w = required_object(obj, "world")?;
        check_unknown(w, WORLD_KEYS, "world")?;
        let world = WorldConfig {
            width: required(w, "width", "world.width", r32(WORLD_DIM_RANGE))?,
            height: required(w, "height", "world.height", r32(WORLD_DIM_RANGE))?,
        };

        let i = required_object(obj, "initial")?;
        check_unknown(i, INITIAL_KEYS, "initial")?;
        let initial = InitialConfig {
            plants: required(i, "plants", "initial.plants", r32(INITIAL_RANGE))?,
            herbivores: required(i, "herbivores", "initial.herbivores", r32(INITIAL_RANGE))?,
            carnivores: required(i, "carnivores", "initial.carnivores", r32(INITIAL_RANGE))?,
        };

        let cfg = Config {
            seed,
            name: optional(obj, "name", DEFAULT_NAME.to_string())?,
            description: optional(obj, "description", String::new())?,
            world,
            initial,
            climate: ClimateParams::read(obj.get(ClimateParams::GROUP))?,
            plants: PlantParams::read(obj.get(PlantParams::GROUP))?,
            herbivores: HerbivoreParams::read(obj.get(HerbivoreParams::GROUP))?,
            carnivores: CarnivoreParams::read(obj.get(CarnivoreParams::GROUP))?,
            hunting: HuntingParams::read(obj.get(HuntingParams::GROUP))?,
        };
        cfg.validate_cross_fields()?;
        Ok(cfg)
    }

    /// Test helper: the pre-TASK-018 default balance (values before the
    /// ADR-021 rebalancing). Mechanics unit tests written against those
    /// numbers pin them, so the tests stay independent of default tuning.
    #[cfg(test)]
    pub(crate) fn pre_task018(mut self) -> Self {
        self.plants = Self::pre_task018_plants();
        let h = &mut self.herbivores;
        (h.base_metabolism, h.max_meal, h.maturity_age, h.initial_energy, h.move_cost, h.max_litter, h.mating_cooldown, h.max_per_cell, h.reproduction_threshold) =
            (0.5, 5.0, 100, 50.0, 0.2, 3, 40, 4, 70.0);
        let c = &mut self.carnivores;
        (c.maturity_age, c.base_metabolism, c.move_cost, c.max_litter, c.mating_cooldown) = (150, 0.8, 0.3, 2, 80);
        let k = &mut self.hunting;
        (k.base_success, k.handling_time, k.cover_protection, k.prey_density_half) = (0.4, 5, 0.3, 0.0);
        self
    }

    /// Pre-TASK-018 plant defaults (see [`Config::pre_task018`]).
    #[cfg(test)]
    pub(crate) fn pre_task018_plants() -> PlantParams {
        PlantParams { resource_regen: 0.5, resource_cap: 10.0, upkeep: 0.2, growth_rate: 1.0, reproduction_threshold: 12.0, reproduction_cost: 6.0, initial_energy: 5.0, max_per_cell: 4, ..PlantParams::default() }
    }

    /// Cross-field constraints (kind `Invalid`, key = the field that must be smaller).
    pub fn validate_cross_fields(&self) -> Result<(), ConfigError> {
        let le = |key: &str, a: f64, other: &str, b: f64| -> Result<(), ConfigError> {
            if a <= b {
                Ok(())
            } else {
                Err(ConfigError::invalid(key, format!("{a} must be <= {other} ({b})")))
            }
        };
        let c = &self.climate;
        le("climate.pole_temperature", c.pole_temperature, "climate.equator_temperature", c.equator_temperature)?;
        let p = &self.plants;
        le("plants.initial_energy", p.initial_energy, "plants.max_energy", p.max_energy)?;
        le("plants.reproduction_threshold", p.reproduction_threshold, "plants.max_energy", p.max_energy)?;
        le("plants.reproduction_cost", p.reproduction_cost, "plants.max_energy", p.max_energy)?;
        let h = &self.herbivores;
        le("herbivores.initial_energy", h.initial_energy, "herbivores.max_energy", h.max_energy)?;
        le("herbivores.reproduction_threshold", h.reproduction_threshold, "herbivores.max_energy", h.max_energy)?;
        let k = &self.carnivores;
        le("carnivores.initial_energy", k.initial_energy, "carnivores.max_energy", k.max_energy)?;
        le("carnivores.reproduction_threshold", k.reproduction_threshold, "carnivores.max_energy", k.max_energy)?;
        Ok(())
    }

    /// Full explicit JSON (every key).
    pub fn to_json_value(&self) -> Value {
        let mut m = Map::new();
        m.insert("seed".into(), self.seed.write());
        m.insert("name".into(), self.name.write());
        m.insert("description".into(), self.description.write());
        let mut w = Map::new();
        w.insert("width".into(), self.world.width.write());
        w.insert("height".into(), self.world.height.write());
        m.insert("world".into(), Value::Object(w));
        let mut i = Map::new();
        i.insert("plants".into(), self.initial.plants.write());
        i.insert("herbivores".into(), self.initial.herbivores.write());
        i.insert("carnivores".into(), self.initial.carnivores.write());
        m.insert("initial".into(), Value::Object(i));
        m.insert(ClimateParams::GROUP.into(), self.climate.write());
        m.insert(PlantParams::GROUP.into(), self.plants.write());
        m.insert(HerbivoreParams::GROUP.into(), self.herbivores.write());
        m.insert(CarnivoreParams::GROUP.into(), self.carnivores.write());
        m.insert(HuntingParams::GROUP.into(), self.hunting.write());
        Value::Object(m)
    }

    /// Pretty JSON text with trailing newline (keys sorted, deterministic).
    pub fn to_json_pretty(&self) -> String {
        let mut s = serde_json::to_string_pretty(&self.to_json_value()).expect("config serialises");
        s.push('\n');
        s
    }
}

/// Every configuration key: fixed keys (no default), metadata, then all groups.
pub fn schema() -> Vec<ParamSpec> {
    let fixed = |key: &str, r: (u32, u32), doc: &'static str| ParamSpec {
        key: key.to_string(),
        type_name: "integer",
        default: None,
        min: Some(r.0 as f64),
        max: Some(r.1 as f64),
        doc,
    };
    let mut v = vec![
        ParamSpec {
            key: "seed".into(),
            type_name: "integer",
            default: None,
            min: Some(0.0),
            max: Some(u64::MAX as f64),
            doc: "Random seed (unsigned 64-bit); required",
        },
        fixed("world.width", WORLD_DIM_RANGE, "Grid width in cells; required"),
        fixed("world.height", WORLD_DIM_RANGE, "Grid height in cells; required"),
        fixed("initial.plants", INITIAL_RANGE, "Plants at tick 0; required"),
        fixed("initial.herbivores", INITIAL_RANGE, "Herbivores at tick 0; required"),
        fixed("initial.carnivores", INITIAL_RANGE, "Carnivores at tick 0; required"),
        ParamSpec {
            key: "name".into(),
            type_name: "string",
            default: Some(Value::from(DEFAULT_NAME)),
            min: None,
            max: None,
            doc: "Free-form configuration name",
        },
        ParamSpec {
            key: "description".into(),
            type_name: "string",
            default: Some(Value::from("")),
            min: None,
            max: None,
            doc: "Free-form description",
        },
    ];
    v.extend(ClimateParams::specs());
    v.extend(PlantParams::specs());
    v.extend(HerbivoreParams::specs());
    v.extend(CarnivoreParams::specs());
    v.extend(HuntingParams::specs());
    v
}

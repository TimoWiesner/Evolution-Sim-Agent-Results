//! Evolution analytics (TASK-020, ADR-023, docs/METRICS.md).
//!
//! [`MetricsRecorder`] takes read-only snapshots of a [`Simulation`] at the
//! series ticks of [`crate::report::run_observed`]. It is not part of the
//! simulation state, draws no random numbers and allocates no IDs, so it
//! cannot influence `state_hash`.

use crate::organism::{DeathCause, Kind, LifeTotals, Population, Traits};
use crate::report::{RunRecord, KIND_KEYS};
use crate::sim::Simulation;
use serde_json::{json, Map, Value};

#[cfg(test)]
mod tests;

/// Format identifier of the metrics document.
pub const FORMAT: &str = "evosim-metrics";
/// Format version of the metrics document.
pub const FORMAT_VERSION: u32 = 1;

/// JSON names of the [`Traits`] fields, in field order.
pub const TRAIT_NAMES: [&str; 11] = [
    "speed",
    "strength",
    "fertility",
    "max_health",
    "max_lifespan",
    "max_energy",
    "vision",
    "aggression",
    "caution",
    "temp_optimum",
    "temp_tolerance",
];

/// Trait values in [`TRAIT_NAMES`] order (exhaustive destructuring: adding a
/// field to `Traits` is a compile error here).
pub fn trait_values(t: &Traits) -> [f64; 11] {
    let Traits {
        speed,
        strength,
        fertility,
        max_health,
        max_lifespan,
        max_energy,
        vision,
        aggression,
        caution,
        temp_optimum,
        temp_tolerance,
    } = *t;
    [
        speed,
        strength,
        fertility,
        max_health,
        max_lifespan as f64,
        max_energy,
        vision,
        aggression,
        caution,
        temp_optimum,
        temp_tolerance,
    ]
}

/// Mean, population standard deviation, minimum and maximum of a value set.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Stat {
    pub mean: f64,
    pub sd: f64,
    pub min: f64,
    pub max: f64,
}

impl Stat {
    /// `None` for an empty set. Two passes: mean, then `sqrt(Σ(x−mean)²/n)`.
    pub fn of(values: &[f64]) -> Option<Stat> {
        if values.is_empty() {
            return None;
        }
        let n = values.len() as f64;
        let mean = values.iter().sum::<f64>() / n;
        let var = values.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / n;
        let min = values.iter().copied().fold(f64::INFINITY, f64::min);
        let max = values.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        Some(Stat { mean, sd: var.max(0.0).sqrt(), min, max })
    }

    fn to_json(s: Option<Stat>) -> Value {
        match s {
            Some(s) => json!({"mean": s.mean, "sd": s.sd, "min": s.min, "max": s.max}),
            None => Value::Null,
        }
    }
}

/// Metrics of one kind at one sample tick.
#[derive(Debug, Clone, PartialEq)]
pub struct KindSample {
    /// Living individuals.
    pub count: u64,
    /// Births / deaths since the previous sample (0 at the first sample).
    pub births: u64,
    pub deaths: u64,
    /// Cumulative since tick 0.
    pub births_total: u64,
    pub deaths_total: u64,
    /// Per [`DeathCause::ALL`] index: interval and cumulative.
    pub deaths_by_cause: [u64; DeathCause::COUNT],
    pub deaths_by_cause_total: [u64; DeathCause::COUNT],
    /// Living species, species records ever created, extinct records.
    pub species_living: u64,
    pub species_appeared: u64,
    pub species_extinct: u64,
    /// Highest and mean generation of the living (None if count is 0).
    pub generation_max: Option<u32>,
    pub generation_mean: Option<f64>,
    /// Per [`TRAIT_NAMES`] entry.
    pub traits: [Option<Stat>; 11],
    pub energy: Option<Stat>,
    pub age: Option<Stat>,
}

/// One sample: tick plus per-kind metrics in `Kind::ALL` order.
#[derive(Debug, Clone, PartialEq)]
pub struct Sample {
    pub tick: u64,
    pub kinds: [KindSample; 3],
}

/// Collects [`Sample`]s; see the module docs.
#[derive(Debug, Clone, Default)]
pub struct MetricsRecorder {
    samples: Vec<Sample>,
    prev: Option<LifeTotals>,
}

fn kind_sample(pop: &Population, kind: Kind, totals: &LifeTotals, prev: Option<&LifeTotals>) -> KindSample {
    let i = kind.index();
    let mut traits: [Vec<f64>; 11] = Default::default();
    let mut energy = Vec::new();
    let mut age = Vec::new();
    let mut gen_max: Option<u32> = None;
    let mut gen_sum = 0u64;
    let mut count = 0u64;
    for o in pop.alive(kind) {
        count += 1;
        for (v, x) in traits.iter_mut().zip(trait_values(o.traits())) {
            v.push(x);
        }
        energy.push(o.energy());
        age.push(o.age() as f64);
        gen_max = Some(gen_max.map_or(o.generation(), |m| m.max(o.generation())));
        gen_sum += o.generation() as u64;
    }
    let (pb, pd, pc) = match prev {
        Some(p) => (p.births[i], p.deaths[i], p.deaths_by_cause[i]),
        None => (totals.births[i], totals.deaths[i], totals.deaths_by_cause[i]),
    };
    let mut by_cause = [0u64; DeathCause::COUNT];
    for (c, slot) in by_cause.iter_mut().enumerate() {
        *slot = totals.deaths_by_cause[i][c] - pc[c];
    }
    let reg = pop.species();
    let (mut appeared, mut extinct) = (0u64, 0u64);
    for r in reg.of_kind(kind) {
        appeared += 1;
        if r.is_extinct() {
            extinct += 1;
        }
    }
    KindSample {
        count,
        births: totals.births[i] - pb,
        deaths: totals.deaths[i] - pd,
        births_total: totals.births[i],
        deaths_total: totals.deaths[i],
        deaths_by_cause: by_cause,
        deaths_by_cause_total: totals.deaths_by_cause[i],
        species_living: reg.living_count(kind) as u64,
        species_appeared: appeared,
        species_extinct: extinct,
        generation_max: gen_max,
        generation_mean: (count > 0).then(|| gen_sum as f64 / count as f64),
        traits: traits.map(|v| Stat::of(&v)),
        energy: Stat::of(&energy),
        age: Stat::of(&age),
    }
}

fn causes_json(c: &[u64; DeathCause::COUNT]) -> Value {
    let mut m = Map::new();
    for d in DeathCause::ALL {
        m.insert(d.name().to_string(), c[d.index()].into());
    }
    Value::Object(m)
}

impl KindSample {
    /// JSON object of docs/METRICS.md.
    pub fn to_json(&self) -> Value {
        let mut traits = Map::new();
        for (name, s) in TRAIT_NAMES.iter().zip(self.traits) {
            traits.insert((*name).to_string(), Stat::to_json(s));
        }
        json!({
            "count": self.count,
            "births": self.births,
            "deaths": self.deaths,
            "births_total": self.births_total,
            "deaths_total": self.deaths_total,
            "deaths_by_cause": causes_json(&self.deaths_by_cause),
            "deaths_by_cause_total": causes_json(&self.deaths_by_cause_total),
            "species": {
                "living": self.species_living,
                "appeared_total": self.species_appeared,
                "extinct_total": self.species_extinct,
            },
            "generation": {
                "max": self.generation_max.map_or(Value::Null, Value::from),
                "mean": self.generation_mean.map_or(Value::Null, Value::from),
            },
            "traits": Value::Object(traits),
            "energy": Stat::to_json(self.energy),
            "age": Stat::to_json(self.age),
        })
    }
}

impl MetricsRecorder {
    pub fn new() -> MetricsRecorder {
        MetricsRecorder::default()
    }

    /// Take one sample of the simulation now (read-only).
    pub fn record(&mut self, sim: &Simulation) {
        self.record_population(sim.tick(), sim.organisms());
    }

    /// Take one sample of `pop` labelled `tick`. Interval counts are the
    /// difference to the previous sample's totals (0 at the first sample).
    pub fn record_population(&mut self, tick: u64, pop: &Population) {
        let totals = *pop.totals();
        let prev = self.prev.as_ref().or(Some(&totals));
        let kinds = Kind::ALL.map(|k| kind_sample(pop, k, &totals, prev));
        self.samples.push(Sample { tick, kinds });
        self.prev = Some(totals);
    }

    pub fn samples(&self) -> &[Sample] {
        &self.samples
    }

    /// The metrics document of docs/METRICS.md.
    pub fn to_json(&self, seed: u64, rec: &RunRecord) -> Value {
        let samples: Vec<Value> = self
            .samples
            .iter()
            .map(|s| {
                let mut m = Map::new();
                m.insert("tick".to_string(), s.tick.into());
                for (key, k) in KIND_KEYS.iter().zip(&s.kinds) {
                    m.insert((*key).to_string(), k.to_json());
                }
                Value::Object(m)
            })
            .collect();
        json!({
            "format": FORMAT,
            "format_version": FORMAT_VERSION,
            "seed": seed,
            "tick_start": rec.tick_start,
            "tick_end": rec.tick_end,
            "sample_every": rec.sample_every,
            "kinds": KIND_KEYS,
            "traits": TRAIT_NAMES,
            "death_causes": DeathCause::ALL.map(|c| c.name()),
            "samples": samples,
        })
    }
}

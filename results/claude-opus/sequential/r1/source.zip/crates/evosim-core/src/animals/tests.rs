//! TASK-013 tests (ADR-016): sensing within vision across edges, stride
//! speed limit, movement cost, shortest wrap-aware path, cell-sharing rule,
//! spatial index sync, determinism.

use super::*;
use crate::config::Config;
use crate::genome::{gene_index, Expression, GeneTrait, Genome};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRequest, CellCapacity, Kind, Parents, Population};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Offset, Torus};

fn c(x: u32, y: u32) -> Cell {
    Cell { x, y }
}

/// Genome of `kind` with speed gene `speed_g` and vision gene `vision_g` (None = default).
fn genome(kind: Kind, speed_g: Option<f32>, vision_g: Option<f32>) -> Genome {
    let mut g = Genome::founder_default(kind).genes().to_vec();
    if let Some(s) = speed_g {
        g[gene_index(kind, GeneTrait::Speed).unwrap()] = s;
    }
    if let Some(v) = vision_g {
        g[gene_index(kind, GeneTrait::Vision).unwrap()] = v;
    }
    Genome::from_genes(kind, g).unwrap()
}

struct Bench {
    pop: Population,
    ids: IdAllocator,
}

impl Bench {
    fn new(w: u32, h: u32) -> Bench {
        Bench { pop: Population::with_expression(Expression::default(), Torus::new(w, h).unwrap()), ids: IdAllocator::new() }
    }
    fn add(&mut self, g: Genome, at: Cell, energy: f64) -> EntityId {
        self.pop.request_birth(BirthRequest { pos: at, parents: Parents::None, energy, health: None, genome: g });
        let r = self.pop.resolve_births(0, &mut self.ids);
        assert_eq!(r.len(), 1, "placement refused");
        r[0].id
    }
    fn plant(&mut self, at: Cell) -> EntityId {
        self.add(Genome::founder_default(Kind::Plant), at, 5.0)
    }
    fn herb(&mut self, at: Cell, vision_g: Option<f32>) -> EntityId {
        self.add(genome(Kind::Herbivore, None, vision_g), at, 50.0)
    }
    fn pos(&self, id: EntityId) -> Cell {
        self.pop.get_alive(id).unwrap().pos()
    }
    fn energy(&self, id: EntityId) -> f64 {
        self.pop.get_alive(id).unwrap().energy()
    }
    fn torus(&self) -> Torus {
        *self.pop.index().torus()
    }
}

fn costs() -> MoveCosts {
    MoveCosts::for_kind(Kind::Herbivore, &Config::contract_example().pre_task018())
}

/// Vision gene giving radius `r` for herbivores (max_vision 6 by default).
fn vg(r: u32) -> Option<f32> {
    Some((r as f32 + 0.5) / 6.0)
}

// ---------- AC1: perception within trait vision, across edges ----------

#[test]
fn sense_within_vision_only() {
    let mut b = Bench::new(40, 40);
    let me = b.herb(c(10, 10), vg(3));
    assert_eq!(vision_radius(b.pop.get_alive(me).unwrap().traits()), 3);
    let p3 = b.plant(c(13, 10));
    let p1 = b.plant(c(9, 11));
    let _p4 = b.plant(c(14, 10));
    let h2 = b.herb(c(10, 8), None);
    let p = perceive(&b.pop, me).unwrap();
    let ids: Vec<EntityId> = p.seen.iter().map(|n| n.id).collect();
    assert_eq!(ids, vec![p1, h2, p3], "distance order, self excluded, distance 4 unseen");
    assert_eq!(p.radius, 3);
    assert_eq!(p.nearest(Kind::Plant).unwrap().id, p1);
    assert_eq!(p.of_kind(Kind::Herbivore).count(), 1);
}

#[test]
fn sense_across_edges_and_corner() {
    let mut b = Bench::new(20, 20);
    let me = b.herb(c(0, 0), vg(2));
    let px = b.plant(c(19, 0));
    let py = b.plant(c(0, 18));
    let pc = b.plant(c(19, 19));
    let _far = b.plant(c(17, 0));
    let p = perceive(&b.pop, me).unwrap();
    let got: Vec<(EntityId, Offset)> = p.seen.iter().map(|n| (n.id, n.offset)).collect();
    assert_eq!(got.len(), 3);
    assert!(got.contains(&(px, Offset::new(-1, 0))));
    assert!(got.contains(&(py, Offset::new(0, -2))));
    assert!(got.contains(&(pc, Offset::new(-1, -1))));
}

#[test]
fn vision_follows_traits() {
    let mut b = Bench::new(30, 30);
    let short = b.herb(c(5, 5), vg(1));
    let long = b.herb(c(5, 6), vg(5));
    b.plant(c(5, 10));
    let max = b.add(genome(Kind::Herbivore, None, Some(1.0)), c(25, 25), 50.0);
    assert_eq!(vision_radius(b.pop.get_alive(max).unwrap().traits()), 6);
    assert_eq!(perceive(&b.pop, short).unwrap().of_kind(Kind::Plant).count(), 0);
    assert_eq!(perceive(&b.pop, long).unwrap().of_kind(Kind::Plant).count(), 1);
}

// ---------- AC2: cell to cell, steps per tick limited by speed ----------

#[test]
fn steps_limited_by_speed() {
    for max_speed in [1u32, 2, 3] {
        for k in 0..=20 {
            let speed = max_speed as f64 * k as f64 / 20.0;
            let (mut stride, mut total) = (0.0, 0u64);
            let n = 1000u64;
            for _ in 0..n {
                let (a, s) = steps_allowed(stride, speed, max_speed);
                assert!(a as f64 <= speed.ceil() && a <= max_speed, "speed {speed}: {a}");
                assert!((0.0..1.0).contains(&s));
                stride = s;
                total += a as u64;
            }
            let exact = (n as f64 * speed + 1e-6).floor() as i64;
            assert!((total as i64 - exact).abs() <= 1, "mean steps = speed: {total} vs {exact}");
        }
    }
}

#[test]
fn moves_are_single_cell_steps_and_capped() {
    let mut b = Bench::new(12, 12);
    let id = b.herb(c(11, 11), None);
    let t = b.torus();
    let target = c(4, 3);
    let mut prev = b.pos(id);
    for _ in 0..10 {
        let o = move_towards(&mut b.pop, id, target, 1, 0, &costs());
        assert!(o.steps <= 1);
        let now = b.pos(id);
        assert_eq!(t.distance(prev, now), o.steps, "exactly one neighbouring cell per step");
        prev = now;
    }
    // Several steps in one call: displacement equals steps (each step is one cell).
    let id2 = b.herb(c(0, 0), None);
    let o = move_towards(&mut b.pop, id2, c(6, 2), 3, 0, &costs());
    assert_eq!(o.steps, 3);
    assert_eq!(t.distance(c(0, 0), b.pos(id2)), 3);
}

// ---------- AC3: moving costs energy; faster/further costs more ----------

#[test]
fn cost_grows_with_distance_and_speed() {
    let c0 = costs();
    for k in 1..10 {
        assert!(path_cost(&c0, k + 1) > path_cost(&c0, k), "further costs more");
        assert!(path_cost(&c0, k + 1) / (k + 1) as f64 > path_cost(&c0, k) / k as f64, "faster costs more per cell");
        assert!((path_cost(&c0, k) - (1..=k).map(|i| step_cost(&c0, i)).sum::<f64>()).abs() < 1e-12);
    }
    assert_eq!(path_cost(&c0, 0), 0.0);
    let mut b = Bench::new(30, 30);
    let id = b.herb(c(1, 1), None);
    let e0 = b.energy(id);
    let o = move_towards(&mut b.pop, id, c(10, 1), 3, 0, &c0);
    assert_eq!(o.steps, 3);
    assert!((e0 - b.energy(id) - path_cost(&c0, 3)).abs() < 1e-12);
    assert!((o.energy_spent - path_cost(&c0, 3)).abs() < 1e-12);
    // Cannot pay → does not move, energy never negative.
    let poor = b.add(genome(Kind::Herbivore, None, None), c(20, 20), 0.1);
    let o = move_towards(&mut b.pop, poor, c(25, 20), 2, 0, &c0);
    assert_eq!((o.steps, b.pos(poor)), (0, c(20, 20)));
    assert!((b.energy(poor) - 0.1).abs() < 1e-12);
    let some = b.add(genome(Kind::Herbivore, None, None), c(20, 25), 0.5);
    let o = move_towards(&mut b.pop, some, c(25, 25), 3, 0, &c0);
    assert_eq!(o.steps, 1, "0.5 pays step 1 (0.2) but not step 2 (0.3) after it");
    assert!(b.energy(some) >= 0.0);
}

// ---------- AC4: shortest way, across an edge where shorter ----------

fn walk(w: u32, h: u32, from: Cell, to: Cell) -> Vec<Cell> {
    let mut b = Bench::new(w, h);
    let id = b.herb(from, None);
    let t = b.torus();
    let mut path = vec![from];
    for _ in 0..(w + h) {
        let d = t.distance(b.pos(id), to);
        if d == 0 {
            break;
        }
        let o = move_towards(&mut b.pop, id, to, 1, 0, &costs());
        assert_eq!(o.steps, 1);
        assert_eq!(t.distance(b.pos(id), to) + 1, d, "every step lowers the distance by 1");
        path.push(b.pos(id));
    }
    assert_eq!(*path.last().unwrap(), to);
    assert_eq!(path.len() as u32 - 1, t.distance(from, to), "optimal step count");
    path
}

#[test]
fn shortest_way_across_edges() {
    assert_eq!(walk(20, 10, c(1, 5), c(18, 5)), vec![c(1, 5), c(0, 5), c(19, 5), c(18, 5)]);
    assert_eq!(walk(10, 20, c(5, 18), c(5, 1)), vec![c(5, 18), c(5, 19), c(5, 0), c(5, 1)]);
    assert_eq!(walk(20, 20, c(0, 0), c(18, 18)), vec![c(0, 0), c(19, 19), c(18, 18)]);
    // Tie at n/2: positive direction (ADR-007).
    assert_eq!(walk(4, 1, c(0, 0), c(2, 0)), vec![c(0, 0), c(1, 0), c(2, 0)]);
}

#[test]
fn shortest_way_interior_does_not_wrap() {
    let p = walk(20, 20, c(5, 5), c(9, 7));
    assert!(p.iter().all(|q| (5..=9).contains(&q.x) && (5..=7).contains(&q.y)), "{p:?}");
}

#[test]
fn blocked_uses_alternative_or_waits() {
    let mut b = Bench::new(20, 20);
    b.pop.set_capacity(CellCapacity { plants: 4, herbivores: 1, carnivores: 1 });
    let me = b.herb(c(5, 5), None);
    b.herb(c(6, 5), None); // preferred cell full
    let o = move_towards(&mut b.pop, me, c(10, 5), 1, 0, &costs());
    assert_eq!((o.steps, b.pos(me)), (1, c(6, 6)), "alternative distance-reducing cell");
    // Exact diagonal: only one reducing cell; full → wait, energy unchanged.
    let d = b.herb(c(1, 1), None);
    b.herb(c(2, 2), None);
    let e0 = b.energy(d);
    let o = move_towards(&mut b.pop, d, c(4, 4), 2, 0, &costs());
    assert!(o.blocked && o.steps == 0);
    assert_eq!((b.pos(d), b.energy(d)), (c(1, 1), e0));
}

// ---------- AC5: one cell-sharing rule, applied everywhere ----------

#[test]
fn cell_sharing_rule_for_moves_births_founders() {
    let mut b = Bench::new(10, 10);
    b.pop.set_capacity(CellCapacity { plants: 1, herbivores: 2, carnivores: 1 });
    // Different kinds share a cell.
    b.plant(c(3, 3));
    b.herb(c(3, 3), None);
    b.herb(c(3, 3), None);
    b.add(genome(Kind::Carnivore, None, None), c(3, 3), 50.0);
    assert_eq!(b.pop.at(c(3, 3), None).len(), 4);
    assert!(!b.pop.has_room(c(3, 3), Kind::Herbivore) && b.pop.has_room(c(3, 4), Kind::Herbivore));
    // Birth into a full cell is dropped.
    b.pop.request_birth(BirthRequest { pos: c(3, 3), parents: Parents::None, energy: 1.0, health: None, genome: genome(Kind::Herbivore, None, None) });
    assert!(b.pop.resolve_births(0, &mut b.ids).is_empty());
    assert_eq!(b.pop.births_dropped_full(), 1);
    // Move into a full cell is refused.
    let m = b.herb(c(3, 4), None);
    let o = move_towards(&mut b.pop, m, c(3, 3), 1, 0, &costs());
    assert!(o.blocked && o.steps == 0);
    // Founders: 9 herbivores cap 1 on 3×3 → one per cell.
    let mut cfg = Config::new(5, 3, 3, 0, 9, 0);
    cfg.herbivores.max_per_cell = 1;
    let p = Population::founders(&cfg, &Torus::new(3, 3).unwrap(), &mut IdAllocator::new());
    for cell in Torus::new(3, 3).unwrap().cells() {
        assert_eq!(p.count_at(cell, Kind::Herbivore), 1);
    }
    // Overload (10 > cap·W·H) is the documented input-only exception.
    let cfg = Config { initial: crate::config::InitialConfig { herbivores: 10, ..cfg.initial.clone() }, ..cfg };
    let p = Population::founders(&cfg, &Torus::new(3, 3).unwrap(), &mut IdAllocator::new());
    assert_eq!(p.count_alive(Kind::Herbivore), 10);
}

#[test]
fn capacity_and_index_hold_in_crowded_run() {
    let mut cfg = Config::new(21, 8, 8, 40, 60, 30);
    cfg.herbivores.max_per_cell = 2;
    cfg.carnivores.max_per_cell = 1;
    let mut sim = Simulation::new(cfg.clone()).unwrap();
    let mut moved = 0u64;
    for _ in 0..200 {
        sim.step_with(|ctx| {
            if matches!(ctx.phase, Phase::Herbivores | Phase::Carnivores | Phase::Births) {
                let pop = ctx.world.organisms();
                for cell in ctx.world.torus().cells() {
                    assert!(pop.count_at(cell, Kind::Herbivore) <= 2);
                    assert!(pop.count_at(cell, Kind::Carnivore) <= 1);
                    assert!(pop.count_at(cell, Kind::Plant) <= cfg.plants.max_per_cell as usize);
                }
                pop.validate(u64::MAX).expect("index in sync");
                if ctx.phase != Phase::Births {
                    let k = if ctx.phase == Phase::Herbivores { Kind::Herbivore } else { Kind::Carnivore };
                    moved += ctx.world.last_moves(k).steps;
                }
            }
        });
    }
    assert!(moved > 0, "animals moved");
}

// ---------- AC6: index in sync, edges, idle movement, determinism ----------

#[test]
fn index_in_sync_and_edges_crossed_in_run() {
    let cfg = Config::new(3, 16, 12, 30, 20, 6);
    let mut sim = Simulation::new(cfg).unwrap();
    let mut prev: Vec<(EntityId, Cell)> = Vec::new();
    let mut wraps = 0;
    for _ in 0..300 {
        sim.step_with(|ctx| {
            if matches!(ctx.phase, Phase::Herbivores | Phase::Carnivores) {
                ctx.world.organisms().validate(u64::MAX).expect("index in sync after moves");
            }
        });
        let pop = sim.organisms();
        let t = *sim.world().torus();
        let now: Vec<(EntityId, Cell)> = Kind::ALL[1..].iter().flat_map(|&k| pop.alive(k).map(|o| (o.id(), o.pos()))).collect();
        for (id, p) in &now {
            if let Some((_, q)) = prev.iter().find(|(i, _)| i == id) {
                let max = pop.get_alive(*id).unwrap().traits().speed.ceil() as u32;
                assert!(t.distance(*q, *p) <= max.max(1));
                if (q.x as i64 - p.x as i64).abs() > 1 || (q.y as i64 - p.y as i64).abs() > 1 {
                    wraps += 1;
                }
            }
        }
        prev = now;
    }
    assert!(wraps > 0, "some animal crossed an edge");
}

#[test]
fn wander_without_targets() {
    let mut b = Bench::new(50, 50);
    let id = b.herb(c(25, 25), None);
    let cfg = Config::contract_example();
    let mut rng = Rng::seed_from_u64(7);
    let t = b.torus();
    let (mut same, mut steps) = (0, 0);
    let mut last = None;
    for _ in 0..60 {
        b.pop.get_alive_mut(id).unwrap().set_energy(50.0);
        let p0 = b.pos(id);
        let o = act_animals(&mut b.pop, &[id], Kind::Herbivore, &cfg, &mut rng);
        assert!(o.steps <= 1 && t.distance(p0, b.pos(id)) <= 1);
        steps += o.steps;
        let h = b.pop.get_alive(id).unwrap().heading();
        if o.steps == 1 && last == h {
            same += 1;
        }
        last = h;
    }
    assert!(steps >= 50, "herbivore (speed 1) wanders one step per tick: {steps}");
    assert!(same >= 30, "heading persistence: {same}");
    assert!(t.distance(c(25, 25), b.pos(id)) > 3);
}

#[test]
fn chase_visible_target() {
    let mut b = Bench::new(30, 30);
    let id = b.herb(c(28, 3), None);
    b.plant(c(3, 3)); // distance 5 across the x edge
    let cfg = Config::contract_example();
    let mut rng = Rng::seed_from_u64(1);
    for _ in 0..5 {
        act_animals(&mut b.pop, &[id], Kind::Herbivore, &cfg, &mut rng);
    }
    assert_eq!(b.pos(id), c(2, 3), "stops adjacent after 4 steps across the edge");
    let e = b.energy(id);
    act_animals(&mut b.pop, &[id], Kind::Herbivore, &cfg, &mut rng);
    assert_eq!((b.pos(id), b.energy(id)), (c(2, 3), e), "stays when adjacent");
}

#[test]
fn deterministic_and_seed_dependent() {
    let run = |seed: u64| {
        let mut s = Simulation::new(Config::new(seed, 24, 24, 50, 30, 8)).unwrap();
        s.run(100);
        let p = s.organisms();
        Kind::ALL[1..].iter().flat_map(|&k| p.alive(k).map(|o| (o.id(), o.pos(), o.energy().to_bits()))).collect::<Vec<_>>()
    };
    assert_eq!(run(5), run(5));
    assert_ne!(run(5), run(6));
}

#[test]
fn no_animals_no_extra_rng_draws() {
    let cfg = Config::new(9, 16, 16, 40, 0, 0);
    let mut s = Simulation::new(cfg.clone()).unwrap();
    let mut reference = Simulation::new(cfg).unwrap();
    s.run(20);
    // Animal phases consume no core RNG without animals: the state equals a
    // run whose animal phases are skipped — compare against itself via hook.
    let mut draws_in_animal_phases = false;
    for _ in 0..20 {
        let mut before = None;
        reference.step_with(|ctx| {
            if ctx.phase == Phase::Plants {
                before = Some(ctx.rng.state());
            }
            if ctx.phase == Phase::Carnivores && before != Some(ctx.rng.state()) {
                draws_in_animal_phases = true;
            }
        });
    }
    assert!(!draws_in_animal_phases);
    assert_eq!(s.rng_state(), reference.rng_state());
}

#[test]
fn new_config_keys_roundtrip() {
    let c0 = Config::contract_example();
    assert_eq!((c0.herbivores.max_per_cell, c0.carnivores.max_per_cell), (2, 2)); // ADR-021 defaults
    assert_eq!((c0.herbivores.sprint_cost, c0.carnivores.sprint_cost), (0.5, 0.5));
    assert_eq!(CellCapacity::default(), CellCapacity { plants: 2, herbivores: 2, carnivores: 2 });
    let mut v = c0.to_json_value();
    v["herbivores"]["max_per_cell"] = serde_json::json!(0);
    assert!(Config::from_value(&v).is_err());
}

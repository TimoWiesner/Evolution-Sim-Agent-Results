//! Carnivore attacks on herbivores (TASK-015, ADR-018).
//!
//! Pure helpers (power, cover, success probability, best prey in reach) and
//! [`attack`], which holds every hunting guarantee: reach ≤ [`ATTACK_REACH`],
//! cost paid on every non-refused attack, exactly one core-RNG draw, prey
//! killed at most once with `DeathCause::Predation`, gain ≤ prey energy.

use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Organism, Population};
use crate::rng::Rng;
use crate::topology::Cell;

use super::sense::vision_radius;

/// Attack reach in cells (toroidal Chebyshev): own cell + 8 neighbours.
pub const ATTACK_REACH: u32 = 1;
/// Success reduction of a maximally cautious (alert) prey.
pub const PREY_ALERTNESS: f64 = 0.3;
/// Success bonus per unit of carnivore aggression above 0.5.
pub const AGGRESSION_BONUS: f64 = 0.4;
/// Success factor of an attack on an adjacent (not same-cell) prey.
pub const ADJACENT_FACTOR: f64 = 0.8;
/// Lower clamp of the success probability (kills always possible).
pub const P_MIN: f64 = 0.02;
/// Upper clamp of the success probability (escapes always possible).
pub const P_MAX: f64 = 0.95;

/// Hunting parameters (from `hunting.*`, `carnivores.*`, speed caps, plant cap).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct HuntParams {
    pub base_success: f64,
    pub attack_cost: f64,
    pub handling_time: u32,
    pub cover_protection: f64,
    pub assimilation: f64,
    pub max_meal: f64,
    /// Speed normaliser `max(carnivores.max_speed, herbivores.max_speed, 1)`.
    pub v_ref: f64,
    /// `plants.max_per_cell` (cover saturates there).
    pub plant_cap: f64,
    /// `hunting.prey_density_half` (0 = local density factor off, ADR-030).
    pub prey_density_half: f64,
}

impl HuntParams {
    pub fn from_config(cfg: &Config) -> HuntParams {
        let h = &cfg.hunting;
        HuntParams {
            base_success: h.base_success,
            attack_cost: h.attack_cost,
            handling_time: h.handling_time,
            cover_protection: h.cover_protection,
            assimilation: cfg.carnivores.assimilation,
            max_meal: cfg.carnivores.max_meal,
            v_ref: cfg.carnivores.max_speed.max(cfg.herbivores.max_speed).max(1) as f64,
            plant_cap: cfg.plants.max_per_cell.max(1) as f64,
            prey_density_half: h.prey_density_half,
        }
    }
}

/// Combat power `0.5·strength + 0.5·speed/v_ref` ∈ [0, 1].
pub fn power(o: &Organism, p: &HuntParams) -> f64 {
    let t = o.traits();
    let v = if p.v_ref > 0.0 { (t.speed / p.v_ref).clamp(0.0, 1.0) } else { 0.0 };
    0.5 * t.strength.clamp(0.0, 1.0) + 0.5 * v
}

/// Plant cover of `cell`: `min(1, plants in cell / plants.max_per_cell)`.
pub fn cover(pop: &Population, cell: Cell, p: &HuntParams) -> f64 {
    (pop.count_at(cell, Kind::Plant) as f64 / p.plant_cap).clamp(0.0, 1.0)
}

/// Local type-III factor (ADR-030): `n/(n+half)`; `half <= 0` or not finite → 1 (off).
pub fn density_factor(n: u32, half: f64) -> f64 {
    if !(half.is_finite() && half > 0.0) {
        return 1.0;
    }
    let n = n as f64;
    n / (n + half)
}

/// Living herbivores within the vision radius of `pred` (toroidal Chebyshev,
/// spatial index; a local perception, never a global count — ADR-030).
pub fn local_prey(pop: &Population, pred: &Organism) -> u32 {
    let mut n = 0u32;
    pop.for_each_within(pred.pos(), vision_radius(pred.traits()), Some(Kind::Herbivore), |nb| {
        if pop.get_alive_of(Kind::Herbivore, nb.id).is_some() {
            n += 1;
        }
    });
    n
}

/// Density factor of `pred` (1 without counting when the factor is off).
pub fn density_of(pop: &Population, pred: &Organism, p: &HuntParams) -> f64 {
    if !(p.prey_density_half.is_finite() && p.prey_density_half > 0.0) {
        return 1.0;
    }
    density_factor(local_prey(pop, pred), p.prey_density_half)
}

/// ADR-018/ADR-030 attack formula (pure):
/// `clamp(base·(1+edge)·alert·drive·shelter·range·density, P_MIN, P_MAX)`.
pub fn success_probability(pred: &Organism, prey: &Organism, distance: u32, cover: f64, density: f64, p: &HuntParams) -> f64 {
    let edge = power(pred, p) - power(prey, p);
    let alert = 1.0 - PREY_ALERTNESS * prey.traits().caution.clamp(0.0, 1.0);
    let drive = 1.0 + AGGRESSION_BONUS * (pred.traits().aggression.clamp(0.0, 1.0) - 0.5);
    let shelter = 1.0 - p.cover_protection.clamp(0.0, 1.0) * cover.clamp(0.0, 1.0);
    let range = if distance == 0 { 1.0 } else { ADJACENT_FACTOR };
    let mut x = p.base_success * (1.0 + edge) * alert * drive * shelter * range;
    if density != 1.0 {
        x *= density;
    }
    if x.is_finite() {
        x.clamp(P_MIN, P_MAX)
    } else {
        P_MIN
    }
}

/// Result of one attack.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Attack {
    pub prey: Option<EntityId>,
    pub distance: u32,
    /// Success probability used for the draw (0 if refused).
    pub p: f64,
    pub success: bool,
    /// Energy actually spent on the attack.
    pub cost: f64,
    /// Prey energy at the moment of the kill (0 on escape/refusal).
    pub prey_energy: f64,
    /// Energy gained by the carnivore (≤ prey_energy).
    pub gained: f64,
    /// Refused: out of reach, dead or wrong kinds — no cost, no RNG draw.
    pub refused: bool,
}

impl Attack {
    fn refused(prey: EntityId, distance: u32) -> Attack {
        Attack { prey: Some(prey), distance, refused: true, ..Attack::default() }
    }
}

/// `pred_id` attacks `prey_id` (ADR-018). Refused unless both are alive, the
/// attacker is a carnivore, the target a herbivore and within
/// [`ATTACK_REACH`]. Otherwise: spend `attack_cost`, one `rng.chance(p)`; on
/// success kill the prey (`Predation`) and gain
/// `min(assimilation·E_prey, max_meal)` (capped at max_energy), start handling.
pub fn attack(pop: &mut Population, pred_id: EntityId, prey_id: EntityId, p: &HuntParams, tick: u64, rng: &mut Rng) -> Attack {
    let (Some(c), Some(h)) = (pop.get_alive(pred_id), pop.get_alive(prey_id)) else { return Attack::refused(prey_id, u32::MAX) };
    if c.kind() != Kind::Carnivore || h.kind() != Kind::Herbivore {
        return Attack::refused(prey_id, u32::MAX);
    }
    let distance = pop.index().torus().distance(c.pos(), h.pos());
    if distance > ATTACK_REACH {
        return Attack::refused(prey_id, distance);
    }
    let prob = success_probability(c, h, distance, cover(pop, h.pos(), p), density_of(pop, c, p), p);
    let cost = pop.get_alive_mut(pred_id).expect("alive").spend_energy(p.attack_cost);
    let mut a = Attack { prey: Some(prey_id), distance, p: prob, cost, ..Attack::default() };
    if !rng.chance(prob) {
        return a;
    }
    let e = pop.get_alive(prey_id).expect("alive").energy();
    if pop.kill(prey_id, DeathCause::Predation, tick) {
        a.success = true;
        a.prey_energy = e;
        let meal = (p.assimilation.clamp(0.0, 1.0) * e).min(p.max_meal.max(0.0));
        let me = pop.get_alive_mut(pred_id).expect("alive");
        a.gained = me.add_energy(meal);
        me.set_handling(p.handling_time);
    }
    a
}

/// The herbivore within [`ATTACK_REACH`] of `pred_id` with the highest
/// success probability (ties: distance, id) as `(prey, p, distance)`.
pub fn best_in_reach(pop: &Population, pred_id: EntityId, p: &HuntParams) -> Option<(EntityId, f64, u32)> {
    let c = pop.get_alive(pred_id)?;
    let mut best: Option<(EntityId, f64, u32)> = None;
    let density = density_of(pop, c, p);
    // Unsorted visit (ADR-029 §3A): order-independent maximum; q is clamped
    // and finite.
    pop.for_each_within(c.pos(), ATTACK_REACH, Some(Kind::Herbivore), |n| {
        let Some(h) = pop.get_alive_of(Kind::Herbivore, n.id) else { return };
        let q = success_probability(c, h, n.distance, cover(pop, n.cell, p), density, p);
        let better = match best {
            None => true,
            Some((bid, bq, bd)) => q > bq || (q == bq && (n.distance, n.id) < (bd, bid)),
        };
        if better {
            best = Some((n.id, q, n.distance));
        }
    });
    best
}

/// Hunting summary of one Carnivores phase.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct HuntTick {
    /// Carnivores that took a turn.
    pub hunters: u64,
    pub attacks: u64,
    pub kills: u64,
    pub escapes: u64,
    pub refused: u64,
    pub attack_cost: f64,
    /// Sum of prey energy of all kills.
    pub prey_energy: f64,
    /// Energy gained by carnivores (≤ prey_energy).
    pub gained: f64,
    pub metabolism: f64,
    pub starved: u64,
    pub handling: u64,
    pub rested: u64,
    /// Largest attacker → prey distance of any non-refused attack (≤ 1).
    pub max_attack_distance: u32,
}

impl HuntTick {
    pub fn record_attack(&mut self, a: &Attack) {
        if a.refused {
            self.refused += 1;
            return;
        }
        self.attacks += 1;
        self.kills += a.success as u64;
        self.escapes += (!a.success) as u64;
        self.attack_cost += a.cost;
        self.prey_energy += a.prey_energy;
        self.gained += a.gained;
        self.max_attack_distance = self.max_attack_distance.max(a.distance);
    }
}

/// Cumulative hunting audit plus the last phase.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct HuntLedger {
    pub attacks: u64,
    pub kills: u64,
    pub escapes: u64,
    pub refused: u64,
    pub attack_cost: f64,
    pub prey_energy: f64,
    pub gained: f64,
    pub metabolism: f64,
    pub starved: u64,
    pub max_attack_distance: u32,
    pub last: HuntTick,
}

impl HuntLedger {
    pub fn record(&mut self, t: &HuntTick) {
        self.attacks += t.attacks;
        self.kills += t.kills;
        self.escapes += t.escapes;
        self.refused += t.refused;
        self.attack_cost += t.attack_cost;
        self.prey_energy += t.prey_energy;
        self.gained += t.gained;
        self.metabolism += t.metabolism;
        self.starved += t.starved;
        self.max_attack_distance = self.max_attack_distance.max(t.max_attack_distance);
        self.last = *t;
    }
}

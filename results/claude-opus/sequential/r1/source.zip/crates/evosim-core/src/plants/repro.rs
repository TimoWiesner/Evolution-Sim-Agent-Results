//! Plant reproduction, dispersal and pollination (TASK-012, ADR-015).
//!
//! Runs in the Plants phase after growth. A plant with
//! `energy ≥ plants.reproduction_threshold` makes a seed with chance
//! `seed_rate · (0.5 + fertility)`, pays `reproduction_cost`, and the seed
//! lands on a uniform cell of the toroidal Chebyshev square of radius
//! `plants.dispersal_radius` around it. The seed establishes only if the cell
//! has room (`< max_per_cell` living plants incl. seeds accepted this tick)
//! and soil resource `≥ seed_min_resource`; otherwise it dies and its cost is
//! lost. Seeds are optionally fertilised by the nearest compatible plant
//! within `pollen_radius` (`Parents::Two`), else cloned + mutated
//! (`Parents::One`). New plants only come from living plants.

use super::resources::CellResources;
use crate::config::{Config, PlantParams};
use crate::genome::{child_asexual, child_sexual, distance, MutationParams};
use crate::ids::EntityId;
use crate::organism::{BirthRequest, Kind, Parents, Population, Traits};
use crate::rng::Rng;
use crate::topology::{Cell, Offset, Torus};

/// Chance per tick that an eligible plant makes a seed:
/// `clamp(seed_rate · (0.5 + fertility), 0, 1)`.
pub fn seed_probability(t: &Traits, p: &PlantParams) -> f64 {
    let v = p.seed_rate * (0.5 + t.fertility);
    if v.is_finite() {
        v.clamp(0.0, 1.0)
    } else {
        0.0
    }
}

/// Uniform landing cell in the toroidal Chebyshev square of radius `r`
/// around `from` (own cell included; offsets de-duplicated on small worlds).
/// Exactly two RNG draws (one per axis).
pub fn dispersal_target(torus: &Torus, from: Cell, r: u32, rng: &mut Rng) -> Cell {
    let xs = torus.x_offsets(r);
    let ys = torus.y_offsets(r);
    let dx = rng.range_i64(*xs.start() as i64, *xs.end() as i64) as i32;
    let dy = rng.range_i64(*ys.start() as i64, *ys.end() as i64) as i32;
    torus.translate(from, Offset { dx, dy })
}

/// Site check: room under THE cell-sharing rule (ADR-016: `living plants +
/// accepted seeds < pop.capacity().of(Plant)`, which `Population::founders`
/// sets from `plants.max_per_cell`) and soil resource (`R ≥ seed_min_resource`).
pub fn site_ok(pop: &Population, res: &CellResources, cell: Cell, accepted_here: u32, p: &PlantParams) -> bool {
    let living = pop.count_at(cell, Kind::Plant) as u64;
    let room = living + (accepted_here as u64) < (pop.capacity().of(Kind::Plant) as u64);
    room && res.get(cell) >= p.seed_min_resource
}

/// Totals of one reproduction step.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct ReproTick {
    /// Energy paid by parents for seeds.
    pub spent: f64,
    /// Energy handed to accepted seeds (≤ `spent`).
    pub seed_energy: f64,
    /// Seeds made (cost paid).
    pub made: u32,
    /// Seeds that died on an unsuitable site.
    pub failed: u32,
    /// Birth requests issued.
    pub requested: u32,
    /// Requests with two parents.
    pub pollinated: u32,
}

/// Plants-phase reproduction (ADR-015 steps 1–8). Draws nothing if no plant
/// is eligible or `seed_rate == 0`.
pub fn reproduce_plants(pop: &mut Population, res: &CellResources, torus: &Torus, cfg: &Config, rng: &mut Rng, _tick: u64) -> ReproTick {
    let p = &cfg.plants;
    let mut out = ReproTick::default();
    if p.seed_rate <= 0.0 || !p.seed_rate.is_finite() {
        return out;
    }
    let mut order: Vec<EntityId> = pop.alive(Kind::Plant).filter(|o| o.energy() >= p.reproduction_threshold).map(|o| o.id()).collect();
    if order.is_empty() {
        return out;
    }
    // Same as sim::acting_order (sorted, then shuffled with the core RNG).
    order.sort_unstable();
    rng.shuffle(&mut order);
    let mutation = MutationParams::for_kind(Kind::Plant, cfg);
    let mut accepted = vec![0u32; torus.cell_count()];
    for id in order {
        let Some(o) = pop.get_alive(id) else { continue };
        if !rng.chance(seed_probability(o.traits(), p)) {
            continue;
        }
        let pos = o.pos();
        let mother = o.genome().clone();
        let spent = pop.get_alive_mut(id).expect("alive").spend_energy(p.reproduction_cost);
        out.spent += spent;
        out.made += 1;
        let target = dispersal_target(torus, pos, p.dispersal_radius, rng);
        let ti = torus.index(target);
        if !site_ok(pop, res, target, accepted[ti], p) {
            out.failed += 1;
            continue;
        }
        let donor = if p.pollination_enabled && rng.chance(p.pollination_chance) {
            pop.nearest(pos, p.pollen_radius, Some(Kind::Plant), |n| {
                n.id != id && pop.get_alive_of(Kind::Plant, n.id).is_some_and(|d| distance(&mother, d.genome()) <= p.species_threshold)
            })
            .map(|n| n.id)
        } else {
            None
        };
        let (genome, parents) = match donor {
            Some(d) => {
                let dg = pop.get_alive(d).expect("alive donor").genome();
                (child_sexual(&mother, dg, mutation, rng).expect("same kind"), Parents::Two(id, d))
            }
            None => (child_asexual(&mother, mutation, rng), Parents::One(id)),
        };
        if donor.is_some() {
            out.pollinated += 1;
        }
        let energy = p.initial_energy.min(spent).max(0.0);
        out.seed_energy += energy;
        out.requested += 1;
        accepted[ti] += 1;
        pop.request_birth(BirthRequest { pos: target, parents, energy, health: None, genome });
    }
    out
}

//! TASK-014 tests (ADR-017): feeding reach, bite limit and energy transfer,
//! grazing death, metabolism and starvation, climate cost, gene-driven
//! decisions, determinism.

use super::feed::*;
use super::*;
use crate::climate::CellNow;
use crate::config::Config;
use crate::genome::{gene_index, Expression, GeneTrait, Genome};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRequest, DeathCause, Kind, Parents, Population};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Torus};

fn c(x: u32, y: u32) -> Cell {
    Cell { x, y }
}

fn herb_genome(set: &[(GeneTrait, f32)]) -> Genome {
    let mut g = Genome::founder_default(Kind::Herbivore).genes().to_vec();
    for &(t, v) in set {
        g[gene_index(Kind::Herbivore, t).unwrap()] = v;
    }
    Genome::from_genes(Kind::Herbivore, g).unwrap()
}

struct Bench {
    pop: Population,
    ids: IdAllocator,
    w: u32,
    h: u32,
    cfg: Config,
    rng: Rng,
}

impl Bench {
    fn new(w: u32, h: u32) -> Bench {
        Bench {
            pop: Population::with_expression(Expression::default(), Torus::new(w, h).unwrap()),
            ids: IdAllocator::new(),
            w,
            h,
            cfg: Config::contract_example(),
            rng: Rng::seed_from_u64(11),
        }
    }
    fn add(&mut self, g: Genome, at: Cell, energy: f64) -> EntityId {
        self.pop.request_birth(BirthRequest { pos: at, parents: Parents::None, energy, health: None, genome: g });
        let r = self.pop.resolve_births(0, &mut self.ids);
        assert_eq!(r.len(), 1, "placement refused");
        let id = r[0].id;
        self.pop.get_alive_mut(id).unwrap().set_energy(energy);
        id
    }
    fn plant(&mut self, at: Cell, energy: f64) -> EntityId {
        self.add(Genome::founder_default(Kind::Plant), at, energy)
    }
    fn herb(&mut self, at: Cell, genes: &[(GeneTrait, f32)], energy: f64) -> EntityId {
        self.add(herb_genome(genes), at, energy)
    }
    fn carn(&mut self, at: Cell) -> EntityId {
        self.add(Genome::founder_default(Kind::Carnivore), at, 80.0)
    }
    fn energy(&self, id: EntityId) -> f64 {
        self.pop.get_alive(id).map(|o| o.energy()).unwrap_or(-1.0)
    }
    fn pos(&self, id: EntityId) -> Cell {
        self.pop.get_alive(id).unwrap().pos()
    }
    /// One herbivore turn with a uniform temperature.
    fn turn(&mut self, id: EntityId, temp: f64) -> HerbivoreTurn {
        let now = vec![CellNow { temperature: temp, precipitation: 500.0 }; (self.w * self.h) as usize];
        self.turn_grid(id, &now)
    }
    fn turn_grid(&mut self, id: EntityId, now: &[CellNow]) -> HerbivoreTurn {
        let p = FeedParams::from_config(&self.cfg);
        let costs = MoveCosts::for_kind(Kind::Herbivore, &self.cfg);
        let rp = crate::animals::repro::ReproParams::for_kind(Kind::Herbivore, &self.cfg);
        herbivore_turn(&mut self.pop, id, &p, &costs, &rp, now, self.w, 1, &mut self.rng).expect("living herbivore")
    }
    fn plant_max(&self) -> f64 {
        self.cfg.plants.max_energy
    }
}

const MILD: f64 = 10.0; // founder optimum

// ---------- AC1: vision finds, reach ≤ 1 eats ----------

#[test]
fn eats_only_in_reach_never_further() {
    let mut b = Bench::new(20, 20);
    let pm = b.plant_max();
    // speed gene 0: cannot move, so only reach decides.
    let h = b.herb(c(5, 5), &[(GeneTrait::Speed, 0.0)], 30.0);
    let far = b.plant(c(7, 5), pm); // distance 2, visible
    let t = b.turn(h, MILD);
    assert_eq!(t.action, HerbivoreAction::Approach, "sees the plant");
    assert_eq!(t.bite.taken, 0.0);
    assert_eq!(b.energy(far), pm, "plant at distance 2 untouched");
    // direct bite attempt at distance 2 is refused by eat()
    let p = FeedParams::from_config(&b.cfg);
    let r = eat(&mut b.pop, h, far, &p, 1);
    assert_eq!((r.taken, r.gained, r.distance), (0.0, 0.0, 2));
    assert_eq!(b.energy(far), pm);
    // adjacent across the x wrap edge: eaten
    let h2 = b.herb(c(0, 10), &[(GeneTrait::Speed, 0.0)], 30.0);
    let edge = b.plant(c(19, 10), pm);
    let t2 = b.turn(h2, MILD);
    assert!(t2.bite.taken > 0.0 && t2.bite.distance == 1);
    assert!(b.energy(edge) < pm);
}

#[test]
fn approaches_plant_in_vision_but_not_beyond() {
    // vision gene → radius 3 (max_vision 6)
    let vg = 3.5 / 6.0;
    let mut b = Bench::new(30, 30);
    let pm = b.plant_max();
    let h = b.herb(c(10, 10), &[(GeneTrait::Vision, vg)], 30.0);
    b.plant(c(13, 10), pm); // d = 3 = r
    let t = b.turn(h, MILD);
    assert_eq!(t.action, HerbivoreAction::Approach);
    assert_eq!(b.pop.index().torus().distance(b.pos(h), c(13, 10)), 2);

    let mut b = Bench::new(30, 30);
    let h = b.herb(c(10, 10), &[(GeneTrait::Vision, vg)], 30.0);
    b.plant(c(14, 10), pm); // d = 4 > r
    let t = b.turn(h, MILD);
    assert_eq!(t.action, HerbivoreAction::Wander, "plant beyond vision is not seen");
}

#[test]
fn bite_distance_never_exceeds_reach_in_runs() {
    let cfg = Config::new(4, 32, 24, 200, 40, 0);
    let mut sim = Simulation::new(cfg).unwrap();
    let mut bites = 0;
    for _ in 0..300 {
        sim.step_with(|ctx| {
            if ctx.phase == Phase::Herbivores {
                let f = ctx.world.last_feed();
                assert!(f.max_bite_distance <= FEED_REACH);
                assert!(f.gained <= f.taken + 1e-12);
                assert!(f.bites == f.eaters);
            }
        });
        bites += sim.world().last_feed().bites;
    }
    let l = sim.world().herbivore_ledger();
    assert!(bites > 0 && l.bites == bites, "herbivores ate: {bites}");
    assert!(l.max_bite_distance <= 1);
    assert!(l.gained <= l.taken && l.gained > 0.0);
    assert!(l.metabolism > 0.0);
}

// ---------- AC2: limited bite, energy from the plant, at most gained ----------

#[test]
fn bite_limited_and_transferred() {
    for assim in [0.8, 1.0] {
        let mut b = Bench::new(10, 10);
        b.cfg.herbivores.assimilation = assim;
        b.cfg.herbivores.base_metabolism = 0.0;
        let pm = b.plant_max();
        let h = b.herb(c(3, 3), &[], 10.0);
        let pl = b.plant(c(3, 3), pm);
        let s_p = b.pop.get_alive(pl).unwrap().traits().strength;
        let t = b.turn(h, MILD);
        let cap = b.cfg.herbivores.max_meal * (1.0 - PLANT_TOUGHNESS * s_p);
        assert!((t.bite.taken - cap).abs() < 1e-12, "bite = cap {cap}, got {}", t.bite.taken);
        assert!(t.bite.taken <= b.cfg.herbivores.max_meal);
        assert!((b.energy(pl) - (pm - t.bite.taken)).abs() < 1e-12, "plant loses exactly the bite");
        assert!((b.energy(h) - (10.0 + assim * t.bite.taken)).abs() < 1e-12);
        assert!(b.energy(h) - 10.0 <= t.bite.taken + 1e-12, "gain ≤ eaten");
        // a second tick: still limited per tick (one bite)
        let e0 = b.energy(pl);
        let t2 = b.turn(h, MILD);
        assert!(t2.bite.taken <= cap + 1e-12 && (e0 - b.energy(pl) - t2.bite.taken).abs() < 1e-12);
    }
}

#[test]
fn one_bite_per_tick_even_with_many_plants() {
    let mut b = Bench::new(10, 10);
    b.cfg.herbivores.base_metabolism = 0.0;
    let pm = b.plant_max();
    let h = b.herb(c(5, 5), &[], 5.0);
    let ps: Vec<_> = [(4, 4), (5, 5), (6, 6), (5, 4)].iter().map(|&(x, y)| b.plant(c(x, y), pm)).collect();
    b.turn(h, MILD);
    let touched = ps.iter().filter(|&&p| b.energy(p) < pm).count();
    assert_eq!(touched, 1);
}

#[test]
fn grazing_can_kill_plant() {
    let mut b = Bench::new(10, 10);
    b.cfg.herbivores.graze_reserve = 0.0; // only without protected reserve (ADR-021)
    let h = b.herb(c(2, 2), &[(GeneTrait::Aggression, 1.0)], 20.0);
    let pl = b.plant(c(2, 3), 1.0);
    let t = b.turn(h, MILD);
    assert!(t.bite.plant_died && (t.bite.taken - 1.0).abs() < 1e-12);
    assert!(!b.pop.is_alive(pl));
    let deaths = b.pop.end_of_tick(1);
    assert!(deaths.iter().any(|d| d.id == pl && d.cause == DeathCause::Grazed));
}

// ---------- AC3: metabolism every tick, starvation ----------

#[test]
fn metabolism_every_tick_and_starvation() {
    let mut b = Bench::new(10, 10);
    let h = b.herb(c(5, 5), &[(GeneTrait::Speed, 0.0)], 3.0);
    let base = b.cfg.herbivores.base_metabolism;
    let mut last = b.energy(h);
    let mut ticks = 0;
    while b.pop.is_alive(h) {
        let t = b.turn(h, MILD);
        if b.pop.is_alive(h) {
            assert!(t.metabolism >= base - 1e-12, "pays at least base metabolism");
            assert!(b.energy(h) <= last - base + 1e-12);
            last = b.energy(h);
        } else {
            assert!(t.starved);
        }
        ticks += 1;
        assert!(ticks < 100);
    }
    let d = b.pop.end_of_tick(1);
    assert!(d.iter().any(|r| r.id == h && r.cause == DeathCause::Starvation));
    assert_eq!(b.pop.count_alive(Kind::Herbivore), 0);
}

#[test]
fn starvation_in_simulation_without_food() {
    let mut cfg = Config::new(2, 12, 12, 0, 10, 0);
    cfg.herbivores.initial_energy = 5.0;
    let mut sim = Simulation::new(cfg).unwrap();
    sim.run(40);
    assert_eq!(sim.organisms().count_alive(Kind::Herbivore), 0);
    assert!(sim.world().herbivore_ledger().starved > 0);
}

// ---------- AC4: climate consequence ----------

#[test]
fn extreme_climate_costs_more() {
    let b = Bench::new(4, 4);
    let mut b = b;
    let h = b.herb(c(0, 0), &[], 50.0);
    let t = *b.pop.get_alive(h).unwrap().traits();
    let p = FeedParams::from_config(&b.cfg);
    let mild = metabolic_cost(&t, t.temp_optimum, &p);
    let cold = metabolic_cost(&t, t.temp_optimum - 3.0 * t.temp_tolerance, &p);
    let hot = metabolic_cost(&t, t.temp_optimum + 3.0 * t.temp_tolerance, &p);
    assert!((cold / mild - (1.0 + 2.0 * p.climate_cost)).abs() < 1e-9);
    assert!((hot - cold).abs() < 1e-12);
    assert!(metabolic_cost(&t, t.temp_optimum + 0.9 * t.temp_tolerance, &p) == mild, "no cost inside tolerance");
    let p0 = FeedParams { climate_cost: 0.0, ..p };
    assert_eq!(metabolic_cost(&t, -60.0, &p0), metabolic_cost(&t, t.temp_optimum, &p0));
}

#[test]
fn cold_cell_drains_more_energy_in_turn() {
    let mut b = Bench::new(10, 10);
    let a = b.herb(c(1, 1), &[(GeneTrait::Speed, 0.0)], 50.0);
    let z = b.herb(c(6, 6), &[(GeneTrait::Speed, 0.0)], 50.0);
    let mut now = vec![CellNow { temperature: MILD, precipitation: 500.0 }; 100];
    now[6 * 10 + 6].temperature = -45.0;
    let ta = b.turn_grid(a, &now);
    let tz = b.turn_grid(z, &now);
    assert!(tz.metabolism > 2.0 * ta.metabolism, "cold {} vs mild {}", tz.metabolism, ta.metabolism);
    assert!(b.energy(z) < b.energy(a));
}

// ---------- AC5: genes change decisions ----------

#[test]
fn caution_gene_flee_vs_eat_same_situation() {
    let run = |caution: f32| {
        let mut b = Bench::new(20, 20);
        let pm = b.plant_max();
        let h = b.herb(c(10, 10), &[(GeneTrait::Caution, caution)], 50.0);
        let pl = b.plant(c(10, 10), pm);
        b.carn(c(12, 10));
        let t = b.turn(h, MILD);
        (t.action, b.pos(h), b.energy(pl) < pm)
    };
    let (a1, p1, ate1) = run(1.0);
    let (a0, p0, ate0) = run(0.0);
    assert_eq!(a1, HerbivoreAction::Flee);
    assert_ne!(p1, c(10, 10), "cautious one moved away");
    assert!(!ate1);
    assert_eq!(a0, HerbivoreAction::EatHere);
    assert_eq!(p0, c(10, 10));
    assert!(ate0);
}

#[test]
fn aggression_gene_greedy_vs_restrained() {
    let run = |aggr: f32| {
        let mut b = Bench::new(20, 20);
        b.cfg.herbivores.base_metabolism = 0.0;
        let h = b.herb(c(5, 5), &[(GeneTrait::Aggression, aggr), (GeneTrait::Speed, 0.0)], 40.0);
        let pl = b.plant(c(5, 5), 15.0);
        let t = b.turn(h, MILD);
        let reserve = b.cfg.herbivores.graze_reserve * b.plant_max();
        assert!(b.energy(pl) >= reserve - 1e-9, "reserve kept");
        (t.bite.taken, b.pop.is_alive(pl))
    };
    // ADR-021: the protected reserve no longer depends on aggression; both
    // take the same bite and both leave graze_reserve * max_energy.
    let (greedy, alive_g) = run(1.0);
    let (restrained, alive_r) = run(0.0);
    assert!(greedy > 0.0);
    assert_eq!(greedy, restrained, "greedy {greedy} vs restrained {restrained}");
    assert!(alive_r && alive_g, "every grazer leaves the reserve");
    // satiety differs too: energy 75 → aggression 0 rests (satiety 60), 1 eats (satiety 100)
    let mut b = Bench::new(10, 10);
    let pm = b.plant_max();
    let r = b.herb(c(1, 1), &[(GeneTrait::Aggression, 0.0)], 75.0);
    let g = b.herb(c(5, 5), &[(GeneTrait::Aggression, 1.0)], 75.0);
    b.plant(c(1, 1), pm);
    b.plant(c(5, 5), pm);
    assert_eq!(b.turn(r, MILD).action, HerbivoreAction::Rest);
    assert_eq!(b.turn(g, MILD).action, HerbivoreAction::EatHere);
}

#[test]
fn leaves_depleted_cell_for_better_patch() {
    let mut b = Bench::new(20, 20);
    let pm = b.plant_max();
    let h = b.herb(c(5, 5), &[], 20.0);
    let poor = b.plant(c(5, 5), b.cfg.herbivores.graze_reserve * pm + 0.1); // almost all reserve
    b.plant(c(9, 5), pm);
    let t = b.turn(h, MILD);
    assert_eq!(t.action, HerbivoreAction::Approach);
    assert_eq!(b.pos(h), c(6, 5));
    assert!(b.pop.is_alive(poor));
}

#[test]
fn deterministic_runs_with_feeding() {
    let run = |seed| {
        let mut s = Simulation::new(Config::new(seed, 24, 24, 120, 30, 4)).unwrap();
        s.run(150);
        let l = *s.world().herbivore_ledger();
        let p = s.organisms();
        (l.taken.to_bits(), l.bites, p.alive(Kind::Herbivore).map(|o| (o.id(), o.pos(), o.energy().to_bits())).collect::<Vec<_>>())
    };
    assert_eq!(run(8), run(8));
    assert_ne!(run(8), run(9));
}

/// Smoke run of the contract example (64×48, 400/120/20), 2000 ticks;
/// prints population counts. Not an acceptance check (coexistence is
/// TASK-018/027). Run: `cargo test --release -p evosim-core smoke_contract_example -- --ignored --nocapture`.
#[test]
#[ignore]
fn smoke_contract_example() {
    let mut s = Simulation::new(Config::contract_example()).unwrap();
    for t in 0..=2000u64 {
        if t % 250 == 0 {
            let p = s.organisms();
            let l = s.world().herbivore_ledger();
            println!(
                "tick {t}: plants {} herbivores {} carnivores {} | bites {} taken {:.1} gained {:.1} starved {} grazed {} fled {}",
                p.count_alive(Kind::Plant),
                p.count_alive(Kind::Herbivore),
                p.count_alive(Kind::Carnivore),
                l.bites,
                l.taken,
                l.gained,
                l.starved,
                l.grazed_dead,
                l.fled
            );
        }
        s.step();
    }
}

//! Headless run loop and result JSON (TASK-019, ADR-022 §3,
//! docs/CONTRACT.md §4). Wall-clock free: the caller measures time and passes
//! `elapsed_seconds` in.

use crate::organism::{DeathCause, Kind};
use crate::sim::Simulation;
use serde_json::{json, Map, Value};

#[cfg(test)]
mod tests;

/// JSON names of the kinds, in `Kind::ALL` order.
pub const KIND_KEYS: [&str; 3] = ["plants", "herbivores", "carnivores"];

/// Living individuals per kind at one tick.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SeriesPoint {
    pub tick: u64,
    pub counts: [u64; 3],
}

/// What one invocation of [`run_recorded`] observed.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RunRecord {
    pub tick_start: u64,
    pub tick_end: u64,
    pub sample_every: u64,
    pub series: Vec<SeriesPoint>,
    /// First tick (in this invocation, including `tick_start`) at which the
    /// kind had 0 living individuals; `None` = never.
    pub extinction_tick: [Option<u64>; 3],
}

/// Contract default spacing: 1/100 of `n`, at least 1.
pub fn default_sample_every(n: u64) -> u64 {
    (n / 100).max(1)
}

/// Living individuals per kind now.
pub fn counts(sim: &Simulation) -> [u64; 3] {
    Kind::ALL.map(|k| sim.organisms().count_alive(k) as u64)
}

/// Steps `sim` exactly `ticks` times (never stops early, also after total
/// extinction) and records the series: at `tick_start`, every
/// `sample_every` ticks after it, and at `tick_end`, without duplicates.
/// `sample_every` 0 is treated as 1.
pub fn run_recorded(sim: &mut Simulation, ticks: u64, sample_every: u64) -> RunRecord {
    run_observed(sim, ticks, sample_every, |_| {})
}

/// [`run_recorded`] with an observer that is called with read-only access to
/// the simulation right after every series point is taken (`tick_start`,
/// every K, `tick_end`; once per series point). The observer cannot change
/// the simulation (ADR-023 §1–2).
pub fn run_observed<F: FnMut(&Simulation)>(sim: &mut Simulation, ticks: u64, sample_every: u64, mut on_sample: F) -> RunRecord {
    let k = sample_every.max(1);
    let tick_start = sim.tick();
    let mut series = Vec::with_capacity((ticks / k) as usize + 2);
    let mut extinction_tick = [None; 3];
    let note = |tick: u64, c: [u64; 3], ext: &mut [Option<u64>; 3]| {
        for i in 0..3 {
            if c[i] == 0 && ext[i].is_none() {
                ext[i] = Some(tick);
            }
        }
    };
    let c0 = counts(sim);
    note(tick_start, c0, &mut extinction_tick);
    series.push(SeriesPoint { tick: tick_start, counts: c0 });
    on_sample(sim);
    for _ in 0..ticks {
        sim.step();
        let t = sim.tick();
        let c = counts(sim);
        note(t, c, &mut extinction_tick);
        if (t - tick_start).is_multiple_of(k) || t == tick_start + ticks {
            series.push(SeriesPoint { tick: t, counts: c });
            on_sample(sim);
        }
    }
    RunRecord { tick_start, tick_end: sim.tick(), sample_every: k, series, extinction_tick }
}

fn per_kind<T: Into<Value> + Copy>(v: [T; 3]) -> Value {
    let mut m = Map::new();
    for (i, key) in KIND_KEYS.iter().enumerate() {
        m.insert((*key).to_string(), v[i].into());
    }
    Value::Object(m)
}

/// Result JSON of contract §4 plus our extra keys (ADR-022 §3).
pub fn result_json(sim: &Simulation, rec: &RunRecord, elapsed_seconds: f64) -> Value {
    let cfg = sim.config();
    let totals = *sim.totals();
    let species = Kind::ALL.map(|k| sim.organisms().species().living_count(k) as u64);
    let fin = counts(sim);
    let mut final_obj = per_kind(fin);
    final_obj["species"] = per_kind(species);
    let ticks = rec.tick_end - rec.tick_start;
    let elapsed = if elapsed_seconds.is_finite() && elapsed_seconds > 0.0 { elapsed_seconds } else { 0.0 };
    let tps = if ticks > 0 && elapsed > 0.0 { ticks as f64 / elapsed } else { 0.0 };
    let series: Vec<Value> = rec
        .series
        .iter()
        .map(|p| json!({"tick": p.tick, "plants": p.counts[0], "herbivores": p.counts[1], "carnivores": p.counts[2]}))
        .collect();
    let mut by_cause = Map::new();
    for k in Kind::ALL {
        let mut m = Map::new();
        for c in DeathCause::ALL {
            m.insert(c.name().to_string(), totals.deaths_by(k, c).into());
        }
        by_cause.insert(KIND_KEYS[k.index()].to_string(), Value::Object(m));
    }
    let mut ext_obj = Map::new();
    for (i, key) in KIND_KEYS.iter().enumerate() {
        ext_obj.insert((*key).to_string(), rec.extinction_tick[i].map_or(Value::Null, Value::from));
    }
    let ext_obj = Value::Object(ext_obj);
    json!({
        "contract": crate::CONTRACT_VERSION,
        "name": crate::NAME,
        "version": crate::VERSION,
        "seed": cfg.seed,
        "tick_start": rec.tick_start,
        "tick_end": rec.tick_end,
        "world": {"width": cfg.world.width, "height": cfg.world.height},
        "final": final_obj,
        "totals": {
            "initial": per_kind(totals.initial),
            "births": per_kind(totals.births),
            "deaths": per_kind(totals.deaths),
            "deaths_by_cause": Value::Object(by_cause),
        },
        "sample_every": rec.sample_every,
        "series": series,
        "extinction_tick": ext_obj,
        "state_hash": sim.state_hash(),
        "elapsed_seconds": elapsed,
        "ticks_per_second": tps,
        "config": cfg.to_json_value(),
    })
}

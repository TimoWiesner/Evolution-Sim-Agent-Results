//! Organism traits and their per-kind valid ranges (ADR-011 table).

use super::Kind;
use crate::config::Config;
use crate::genome::{express, Expression, Genome};

/// Inclusive valid range of a real-valued trait.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Range {
    pub lo: f64,
    pub hi: f64,
}

impl Range {
    pub const fn new(lo: f64, hi: f64) -> Range {
        Range { lo, hi }
    }

    /// Clamp into the range; non-finite values map to `lo`.
    pub fn clamp(self, v: f64) -> f64 {
        if v.is_finite() {
            v.clamp(self.lo, self.hi)
        } else {
            self.lo
        }
    }

    pub fn contains(self, v: f64) -> bool {
        v.is_finite() && v >= self.lo && v <= self.hi
    }
}

/// Heritable traits of one organism. Fields are public for reading; an
/// `Organism` only ever stores values produced by [`Traits::clamped`].
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Traits {
    /// Cells per tick (plants: 0, sessile).
    pub speed: f64,
    /// Relative strength (plants: toughness against grazing).
    pub strength: f64,
    /// Relative fertility.
    pub fertility: f64,
    /// Health points at full health.
    pub max_health: f64,
    /// Maximum age in ticks.
    pub max_lifespan: u32,
    /// Maximum stored energy.
    pub max_energy: f64,
    /// Sensing radius in cells (plants: 0).
    pub vision: f64,
    /// Behavioural tendency: aggression (plants: 0).
    pub aggression: f64,
    /// Behavioural tendency: caution / risk aversion (plants: 0).
    pub caution: f64,
    /// Preferred temperature in °C (TASK-009, ADR-012).
    pub temp_optimum: f64,
    /// Temperature tolerance (half-width) in °C (TASK-009, ADR-012).
    pub temp_tolerance: f64,
}

/// Valid ranges of every trait for one kind.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TraitRanges {
    pub speed: Range,
    pub strength: Range,
    pub fertility: Range,
    pub max_health: Range,
    pub max_lifespan: (u32, u32),
    pub max_energy: Range,
    pub vision: Range,
    pub aggression: Range,
    pub caution: Range,
    pub temp_optimum: Range,
    pub temp_tolerance: Range,
}

impl TraitRanges {
    /// The ADR-011 range table.
    pub fn for_kind(kind: Kind) -> TraitRanges {
        let animal = kind.is_animal();
        let a = |hi: f64| Range::new(0.0, if animal { hi } else { 0.0 });
        TraitRanges {
            speed: a(16.0),
            strength: Range::new(0.0, 1.0),
            fertility: Range::new(0.0, 1.0),
            max_health: Range::new(1.0, 1000.0),
            max_lifespan: (1, 10_000_000),
            max_energy: Range::new(0.1, 1e6),
            vision: a(64.0),
            aggression: a(1.0),
            caution: a(1.0),
            temp_optimum: Range::new(-40.0, 60.0),
            temp_tolerance: Range::new(0.5, 50.0),
        }
    }
}

impl Traits {
    /// Clamp every field into the kind's range (non-finite → low end).
    pub fn clamped(kind: Kind, raw: Traits) -> Traits {
        let r = TraitRanges::for_kind(kind);
        Traits {
            speed: r.speed.clamp(raw.speed),
            strength: r.strength.clamp(raw.strength),
            fertility: r.fertility.clamp(raw.fertility),
            max_health: r.max_health.clamp(raw.max_health),
            max_lifespan: raw.max_lifespan.clamp(r.max_lifespan.0, r.max_lifespan.1),
            max_energy: r.max_energy.clamp(raw.max_energy),
            vision: r.vision.clamp(raw.vision),
            aggression: r.aggression.clamp(raw.aggression),
            caution: r.caution.clamp(raw.caution),
            temp_optimum: r.temp_optimum.clamp(raw.temp_optimum),
            temp_tolerance: r.temp_tolerance.clamp(raw.temp_tolerance),
        }
    }

    /// All fields 0 (raw starting point of expression; not in range).
    pub fn zero() -> Traits {
        Traits {
            speed: 0.0,
            strength: 0.0,
            fertility: 0.0,
            max_health: 0.0,
            max_lifespan: 0,
            max_energy: 0.0,
            vision: 0.0,
            aggression: 0.0,
            caution: 0.0,
            temp_optimum: 0.0,
            temp_tolerance: 0.0,
        }
    }

    /// Founder defaults: expression of the founder default genome (ADR-012).
    pub fn founder_default(kind: Kind, cfg: &Config) -> Traits {
        express(&Genome::founder_default(kind), &Expression::from_config(cfg))
    }

    /// True if every field lies in the kind's range.
    pub fn in_range(&self, kind: Kind) -> bool {
        let r = TraitRanges::for_kind(kind);
        r.speed.contains(self.speed)
            && r.strength.contains(self.strength)
            && r.fertility.contains(self.fertility)
            && r.max_health.contains(self.max_health)
            && (r.max_lifespan.0..=r.max_lifespan.1).contains(&self.max_lifespan)
            && r.max_energy.contains(self.max_energy)
            && r.vision.contains(self.vision)
            && r.aggression.contains(self.aggression)
            && r.caution.contains(self.caution)
            && r.temp_optimum.contains(self.temp_optimum)
            && r.temp_tolerance.contains(self.temp_tolerance)
    }
}

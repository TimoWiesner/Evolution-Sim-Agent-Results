//! Crossover, mutation and genetic distance (ADR-012).
//!
//! Draw discipline (fixed for reproducibility):
//! - [`crossover`]: exactly one `rng.chance(0.5)` per locus in order (L draws);
//!   kind mismatch → error, zero draws.
//! - [`mutate`]: zero draws if `rate <= 0` or `strength <= 0` (or either is
//!   non-finite); otherwise per locus in order one `rng.chance(rate)` and, on
//!   a hit, one `rng.normal(0, strength)` (two draws): L + 2·hits draws.

use super::{gene_table, Genome, GenomeError};
use crate::config::Config;
use crate::organism::Kind;
use crate::rng::Rng;

/// Reflect `x` into `[0, 1]` (period 2: `-0.1 → 0.1`, `1.2 → 0.8`).
/// Non-finite input is returned unchanged.
pub fn reflect_unit(x: f64) -> f64 {
    if !x.is_finite() {
        return x;
    }
    let y = x.rem_euclid(2.0);
    if y > 1.0 {
        2.0 - y
    } else {
        y
    }
}

/// Mutation parameters: per-locus probability and normal standard deviation.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MutationParams {
    pub rate: f64,
    pub strength: f64,
}

impl MutationParams {
    /// No mutation (zero draws).
    pub const NONE: MutationParams = MutationParams { rate: 0.0, strength: 0.0 };

    /// `<kind>.mutation_rate` / `<kind>.mutation_strength` from the configuration.
    pub fn for_kind(kind: Kind, cfg: &Config) -> MutationParams {
        let (rate, strength) = match kind {
            Kind::Plant => (cfg.plants.mutation_rate, cfg.plants.mutation_strength),
            Kind::Herbivore => (cfg.herbivores.mutation_rate, cfg.herbivores.mutation_strength),
            Kind::Carnivore => (cfg.carnivores.mutation_rate, cfg.carnivores.mutation_strength),
        };
        MutationParams { rate, strength }
    }

    /// True if [`mutate`] would draw from the generator.
    pub fn is_active(&self) -> bool {
        self.rate.is_finite() && self.strength.is_finite() && self.rate > 0.0 && self.strength > 0.0
    }
}

/// Mutate in place; returns the number of genes whose value changed.
pub fn mutate(genome: &mut Genome, p: MutationParams, rng: &mut Rng) -> usize {
    if !p.is_active() {
        return 0;
    }
    let mut changed = 0;
    for g in genome.genes_mut() {
        if rng.chance(p.rate) {
            let x = *g as f64 + rng.normal(0.0, p.strength);
            let r = reflect_unit(x);
            if r.is_finite() {
                let v = (r as f32).clamp(0.0, 1.0);
                if v != *g {
                    changed += 1;
                }
                *g = v;
            }
        }
    }
    changed
}

/// Uniform crossover: each locus from `a` (chance 0.5) or `b`.
pub fn crossover(a: &Genome, b: &Genome, rng: &mut Rng) -> Result<Genome, GenomeError> {
    if a.kind() != b.kind() {
        return Err(GenomeError::KindMismatch { a: a.kind(), b: b.kind() });
    }
    let genes = a.genes().iter().zip(b.genes()).map(|(&x, &y)| if rng.chance(0.5) { x } else { y }).collect();
    Ok(Genome { kind: a.kind(), genes })
}

/// One-parent child: copy + mutation.
pub fn child_asexual(parent: &Genome, p: MutationParams, rng: &mut Rng) -> Genome {
    let mut g = Genome::copy_of(parent);
    mutate(&mut g, p, rng);
    g
}

/// Two-parent child: crossover + mutation.
pub fn child_sexual(a: &Genome, b: &Genome, p: MutationParams, rng: &mut Rng) -> Result<Genome, GenomeError> {
    let mut g = crossover(a, b, rng)?;
    mutate(&mut g, p, rng);
    Ok(g)
}

/// Genetic distance `Σ wᵢ|aᵢ − bᵢ| / Σ wᵢ` ∈ `[0, 1]`: 0 iff identical,
/// symmetric, growing with every additional or larger difference. Genomes of
/// different kinds have distance 1.0.
pub fn distance(a: &Genome, b: &Genome) -> f64 {
    if a.kind() != b.kind() {
        return 1.0;
    }
    let table = gene_table(a.kind());
    let mut num = 0.0;
    let mut den = 0.0;
    for ((s, &x), &y) in table.iter().zip(a.genes()).zip(b.genes()) {
        num += s.weight * (x as f64 - y as f64).abs();
        den += s.weight;
    }
    if den > 0.0 {
        num / den
    } else {
        0.0
    }
}

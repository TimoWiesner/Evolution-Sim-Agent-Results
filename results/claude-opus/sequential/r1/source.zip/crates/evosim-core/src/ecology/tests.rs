use super::*;

fn cfg(p: u32, h: u32, c: u32) -> Config {
    Config::new(1, 48, 32, p, h, c)
}

#[test]
fn survival_run_reports_extinction_ticks() {
    let o = survival_run(&cfg(0, 60, 10), 1, 3000).unwrap();
    assert_eq!(o.fate[0].extinct_at, Some(0), "plants absent from the start");
    let th = o.fate[1].extinct_at.expect("herbivores starve");
    let tc = o.fate[2].extinct_at.expect("carnivores starve");
    assert!(th > 0 && tc >= th);
    assert_eq!(o.coexist_until, 0);
    assert_eq!(o.final_alive, [0, 0, 0]);
    let line = format_line(&o);
    assert!(line.contains("plants extinct at tick 0"), "{line}");
    assert!(line.contains(&format!("herbivores extinct at tick {th}")), "{line}");
}

#[test]
fn survival_run_plants_only_survive() {
    let o = survival_run(&cfg(200, 0, 0), 4, 500).unwrap();
    assert_eq!(o.fate[0].extinct_at, None);
    assert_eq!(o.fate[1].extinct_at, Some(0));
    assert!(o.final_alive[0] > 0);
    assert!(format_line(&o).contains("plants survived"));
    let j = outcome_json(&o);
    assert_eq!(j["kinds"]["plants"]["survived"], true);
    assert_eq!(j["kinds"]["herbivores"]["extinct_at"], 0);
}

#[test]
fn survival_runs_deterministic_and_in_seed_order() {
    let c = cfg(200, 40, 6);
    let a = survival_runs(&c, &[3, 1, 2], 300).unwrap();
    let b = survival_runs(&c, &[3, 1, 2], 300).unwrap();
    assert_eq!(a, b);
    assert_eq!(a.iter().map(|o| o.seed).collect::<Vec<_>>(), vec![3, 1, 2]);
    assert_eq!(a[1], survival_run(&c, 1, 300).unwrap());
}

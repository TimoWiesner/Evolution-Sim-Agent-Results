//! TASK-016 tests (ADR-019): mating requirements, never with itself,
//! crossover + mutation, parents/generation, cost for both parents,
//! cooldown, fertility effect, lone animals never reproduce, run invariants.

use super::repro::*;
use super::*;
use crate::climate::CellNow;
use crate::config::Config;
use crate::genome::{distance, gene_index, Expression, GeneTrait, Genome};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRequest, CellCapacity, Kind, Parents, Population};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Torus};

fn c(x: u32, y: u32) -> Cell {
    Cell { x, y }
}

fn genome(kind: Kind, set: &[(GeneTrait, f32)]) -> Genome {
    let mut g = Genome::founder_default(kind).genes().to_vec();
    for &(t, v) in set {
        g[gene_index(kind, t).unwrap()] = v;
    }
    Genome::from_genes(kind, g).unwrap()
}

/// Founder genome with every trait-neutral marker gene set to `v`.
fn uniform(kind: Kind, v: f32) -> Genome {
    let mut g = Genome::founder_default(kind).genes().to_vec();
    for (i, spec) in crate::genome::gene_table(kind).iter().enumerate() {
        if spec.name.starts_with("marker") {
            g[i] = v;
        }
    }
    Genome::from_genes(kind, g).unwrap()
}

struct Bench {
    pop: Population,
    ids: IdAllocator,
    cfg: Config,
    rng: Rng,
    tick: u64,
}

impl Bench {
    /// Mature-by-default bench: maturity_age 0, conception_chance 1, no mutation.
    fn new(w: u32, h: u32, seed: u64) -> Bench {
        let mut cfg = Config::contract_example().pre_task018();
        for (m, cc, mr) in [
            (&mut cfg.herbivores.maturity_age, &mut cfg.herbivores.conception_chance, &mut cfg.herbivores.mutation_rate),
            (&mut cfg.carnivores.maturity_age, &mut cfg.carnivores.conception_chance, &mut cfg.carnivores.mutation_rate),
        ] {
            *m = 0;
            *cc = 1.0;
            *mr = 0.0;
        }
        let mut pop = Population::with_expression(Expression::default(), Torus::new(w, h).unwrap());
        pop.set_capacity(CellCapacity::from_config(&cfg));
        Bench { pop, ids: IdAllocator::new(), cfg, rng: Rng::seed_from_u64(seed), tick: 1 }
    }
    fn add(&mut self, g: Genome, at: Cell, energy: f64) -> EntityId {
        self.pop.request_birth(BirthRequest { pos: at, parents: Parents::None, energy, health: None, genome: g });
        let r = self.pop.resolve_births(0, &mut self.ids);
        assert_eq!(r.len(), 1, "placement refused");
        let id = r[0].id;
        self.pop.get_alive_mut(id).unwrap().set_energy(energy);
        id
    }
    fn herb(&mut self, at: Cell, energy: f64) -> EntityId {
        self.add(Genome::founder_default(Kind::Herbivore), at, energy)
    }
    fn energy(&self, id: EntityId) -> f64 {
        self.pop.get_alive(id).map(|o| o.energy()).unwrap_or(-1.0)
    }
    /// One mating pass over `ids` (herbivores unless the ids are carnivores).
    fn mate(&mut self, ids: &[EntityId], kind: Kind) -> AnimalReproTick {
        reproduce_animals(&mut self.pop, ids, kind, &self.cfg, &mut self.rng)
    }
    /// Births phase + end of tick; returns the birth records.
    fn finish_tick(&mut self) -> Vec<crate::organism::BirthRecord> {
        let b = self.pop.resolve_births(self.tick, &mut self.ids);
        self.pop.end_of_tick(self.tick);
        self.tick += 1;
        b
    }
}

// ---------- AC1: requirements; never with itself ----------

#[test]
fn pair_in_reach_reproduces_including_across_wrap() {
    for (pa, pb) in [(c(3, 3), c(3, 3)), (c(3, 3), c(4, 4)), (c(0, 2), c(9, 2)), (c(5, 0), c(5, 7))] {
        let mut b = Bench::new(10, 8, 1);
        let x = b.herb(pa, 90.0);
        let y = b.herb(pb, 90.0);
        let t = b.mate(&[x, y], Kind::Herbivore);
        assert_eq!(t.attempts, 1, "{pa:?} {pb:?}");
        assert_eq!(t.conceived, 1);
        let births = b.finish_tick();
        assert!(!births.is_empty());
        for r in &births {
            assert_eq!(r.parents, Parents::Two(x, y));
            assert_ne!(x, y);
            assert_eq!(r.kind, Kind::Herbivore);
        }
    }
}

#[test]
fn no_mating_beyond_reach() {
    let mut b = Bench::new(10, 10, 2);
    let x = b.herb(c(2, 2), 90.0);
    let y = b.herb(c(4, 2), 90.0);
    let t = b.mate(&[x, y], Kind::Herbivore);
    assert_eq!((t.ready, t.attempts, b.pop.pending_births()), (2, 0, 0));
}

#[test]
fn no_mating_when_immature() {
    let mut b = Bench::new(10, 10, 3);
    b.cfg.herbivores.maturity_age = 5;
    let x = b.herb(c(2, 2), 90.0);
    let y = b.herb(c(2, 2), 90.0);
    b.pop.get_alive_mut(x).unwrap().set_age_for_test(4);
    b.pop.get_alive_mut(y).unwrap().set_age_for_test(50);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 0);
    b.pop.get_alive_mut(x).unwrap().set_age_for_test(5);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 1, "mature at exactly maturity_age");
}

#[test]
fn no_mating_low_energy() {
    let mut b = Bench::new(10, 10, 4);
    let x = b.herb(c(2, 2), 69.9); // threshold 70
    let y = b.herb(c(2, 2), 90.0);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 0);
    // energy ≥ threshold but not > cost
    b.cfg.herbivores.reproduction_threshold = 10.0;
    b.pop.get_alive_mut(x).unwrap().set_energy(35.0); // cost 35
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 0);
    b.pop.get_alive_mut(x).unwrap().set_energy(35.5);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 1);
}

#[test]
fn no_mating_incompatible_and_boundary_inclusive() {
    let mut b = Bench::new(10, 10, 5);
    let x = b.add(uniform(Kind::Herbivore, 0.0), c(2, 2), 90.0);
    let y = b.add(uniform(Kind::Herbivore, 1.0), c(2, 2), 90.0);
    let d = distance(b.pop.get(x).unwrap().genome(), b.pop.get(y).unwrap().genome());
    assert!(d > b.cfg.herbivores.mating_threshold);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 0);
    b.cfg.herbivores.mating_threshold = d;
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 1, "distance == threshold is compatible");
}

#[test]
fn no_mating_across_kinds() {
    let mut b = Bench::new(10, 10, 6);
    let h = b.herb(c(2, 2), 90.0);
    let k = b.add(Genome::founder_default(Kind::Carnivore), c(2, 2), 150.0);
    assert_eq!(b.mate(&[h, k], Kind::Herbivore).attempts, 0);
    assert_eq!(b.mate(&[h, k], Kind::Carnivore).attempts, 0);
    assert_eq!(b.pop.pending_births(), 0);
}

#[test]
fn no_mating_with_dead_partner() {
    let mut b = Bench::new(10, 10, 7);
    let x = b.herb(c(2, 2), 90.0);
    let y = b.herb(c(2, 2), 90.0);
    b.pop.kill(y, crate::organism::DeathCause::Predation, 1);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).attempts, 0);
}

#[test]
fn animal_never_mates_with_itself() {
    let mut b = Bench::new(6, 6, 8);
    let x = b.herb(c(2, 2), 100.0);
    for _ in 0..500 {
        b.pop.get_alive_mut(x).unwrap().set_energy(100.0);
        let t = b.mate(&[x, x, x], Kind::Herbivore);
        assert_eq!(t.attempts, 0);
        assert_eq!(b.pop.pending_births(), 0);
        b.finish_tick();
    }
    assert!(find_mate_in_reach(&b.pop, x, &ReproParams::for_kind(Kind::Herbivore, &b.cfg), &[]).is_none());
}

// ---------- AC2: crossover + mutation; parents and generation ----------

#[test]
fn child_genome_is_crossover_of_parents() {
    let mut b = Bench::new(40, 40, 9);
    b.cfg.herbivores.mating_threshold = 1.0;
    let (mut from_a, mut from_b) = (0usize, 0usize);
    let (ga, gb) = (uniform(Kind::Herbivore, 0.2), uniform(Kind::Herbivore, 0.8));
    let pairs: Vec<_> = (0..30u32).map(|i| (b.add(ga.clone(), c(i, 0), 100.0), b.add(gb.clone(), c(i, 1), 100.0))).collect();
    for &(x, y) in &pairs {
        b.mate(&[x, y], Kind::Herbivore);
    }
    let births = b.finish_tick();
    assert!(births.len() >= 30);
    for r in births {
        for (i, &g) in b.pop.get(r.id).unwrap().genome().genes().iter().enumerate() {
            assert!(g == ga.genes()[i] || g == gb.genes()[i], "gene {i}={g} not from a parent");
            if ga.genes()[i] != gb.genes()[i] {
                if g == ga.genes()[i] { from_a += 1 } else { from_b += 1 }
            }
        }
    }
    assert!(from_a > 0 && from_b > 0, "both parents contribute: {from_a} {from_b}");
}

#[test]
fn child_mutates() {
    let mut b = Bench::new(20, 20, 10);
    b.cfg.herbivores.mutation_rate = 1.0;
    b.cfg.herbivores.mutation_strength = 0.1;
    b.cfg.herbivores.mating_threshold = 1.0;
    let x = b.add(uniform(Kind::Herbivore, 0.2), c(1, 1), 100.0);
    let y = b.add(uniform(Kind::Herbivore, 0.8), c(1, 1), 100.0);
    b.mate(&[x, y], Kind::Herbivore);
    let births = b.finish_tick();
    assert!(!births.is_empty());
    let (ga, gb) = (b.pop.get(x).unwrap().genome().genes().to_vec(), b.pop.get(y).unwrap().genome().genes().to_vec());
    let g = b.pop.get(births[0].id).unwrap().genome().genes().to_vec();
    assert!(g.iter().enumerate().any(|(i, &v)| v != ga[i] && v != gb[i]), "mutation changed genes: {g:?}");
}

#[test]
fn birth_records_parents_and_generation() {
    let mut b = Bench::new(10, 10, 11);
    b.cfg.herbivores.max_litter = 1;
    let x = b.herb(c(2, 2), 100.0);
    let y = b.herb(c(2, 2), 100.0);
    b.mate(&[x, y], Kind::Herbivore);
    let r1 = b.finish_tick();
    assert_eq!(r1.len(), 1);
    let child = r1[0].id;
    let o = b.pop.get(child).unwrap();
    assert_eq!((o.parents(), o.generation()), (Parents::Two(x, y), 1));
    // child (gen 1) × founder (gen 0) → gen 2
    let z = b.herb(c(2, 2), 100.0);
    b.pop.get_alive_mut(child).unwrap().set_energy(100.0);
    b.mate(&[child, z], Kind::Herbivore);
    let r2 = b.finish_tick();
    assert_eq!(r2.len(), 1);
    let o2 = b.pop.get(r2[0].id).unwrap();
    assert_eq!(o2.parents(), Parents::Two(child, z));
    assert_eq!(o2.generation(), 2);
}

// ---------- AC3: both parents pay ----------

#[test]
fn both_parents_pay() {
    let mut b = Bench::new(10, 10, 12);
    let x = b.herb(c(2, 2), 90.0);
    let y = b.herb(c(2, 3), 80.0);
    let t = b.mate(&[x, y], Kind::Herbivore);
    let cost = b.cfg.herbivores.reproduction_cost;
    assert_eq!(b.energy(x), 90.0 - cost);
    assert_eq!(b.energy(y), 80.0 - cost);
    assert_eq!(t.energy_spent, 2.0 * cost);
    assert!(t.offspring_energy <= t.energy_spent + 1e-9);
    // failed conception costs nothing and sets no cooldown
    let mut b = Bench::new(10, 10, 13);
    b.cfg.herbivores.conception_chance = 0.0;
    let x = b.herb(c(2, 2), 90.0);
    let y = b.herb(c(2, 2), 90.0);
    let t = b.mate(&[x, y], Kind::Herbivore);
    assert_eq!((t.attempts, t.conceived), (1, 0));
    assert_eq!((b.energy(x), b.energy(y)), (90.0, 90.0));
    assert_eq!(b.pop.get(x).unwrap().cooldown(), 0);
}

#[test]
fn carnivores_pay_and_reproduce() {
    let mut b = Bench::new(10, 10, 14);
    let x = b.add(Genome::founder_default(Kind::Carnivore), c(2, 2), 150.0);
    let y = b.add(Genome::founder_default(Kind::Carnivore), c(3, 2), 140.0);
    let t = b.mate(&[y, x], Kind::Carnivore);
    assert_eq!(t.conceived, 1);
    assert_eq!(b.energy(x), 150.0 - 55.0);
    assert_eq!(b.energy(y), 140.0 - 55.0);
    let births = b.finish_tick();
    assert!(births.iter().all(|r| r.parents == Parents::Two(y, x) && r.kind == Kind::Carnivore));
    assert!(!births.is_empty() && births.len() <= 2);
}

// ---------- AC4: cooldown ----------

#[test]
fn cooldown_blocks_remating() {
    let mut b = Bench::new(10, 10, 15);
    let cd = b.cfg.herbivores.mating_cooldown;
    let x = b.herb(c(2, 2), 100.0);
    let y = b.herb(c(2, 2), 100.0);
    assert_eq!(b.mate(&[x, y], Kind::Herbivore).conceived, 1);
    assert_eq!(b.pop.get(x).unwrap().cooldown(), cd);
    assert_eq!(b.pop.get(y).unwrap().cooldown(), cd);
    // capacity: drop newborns so the cell never limits the test
    b.cfg.herbivores.max_per_cell = 64;
    b.pop.set_capacity(CellCapacity::from_config(&b.cfg));
    let mut next = None;
    for k in 1..=(cd as u64 + 5) {
        b.finish_tick();
        for id in [x, y] {
            b.pop.get_alive_mut(id).unwrap().set_energy(100.0);
        }
        if b.mate(&[x, y], Kind::Herbivore).conceived > 0 {
            next = Some(k);
            break;
        }
    }
    assert_eq!(next, Some(cd as u64), "ready again exactly mating_cooldown ticks later");
}

// ---------- AC5: fertility ----------

fn offspring_with_fertility(f: f32, trials: u32) -> u64 {
    let mut total = 0;
    for s in 0..trials {
        let mut b = Bench::new(8, 8, 1000 + s as u64);
        b.cfg.herbivores.conception_chance = 0.5;
        let x = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, f)]), c(3, 3), 100.0);
        let y = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, f)]), c(3, 3), 100.0);
        total += b.mate(&[x, y], Kind::Herbivore).offspring;
    }
    total
}

#[test]
fn fertility_changes_offspring() {
    let low = offspring_with_fertility(0.0, 500);
    let high = offspring_with_fertility(1.0, 500);
    // f=0: chance 0.25, litter 1 → ≈125; f=1: chance 0.75, litter up to 3 → ≈ 750·… ≫ low
    assert!(high > 2 * low, "fertility raises offspring: low {low} high {high}");
    assert!(low > 0);
}

#[test]
fn litter_bounds_and_room() {
    for s in 0..200 {
        let mut b = Bench::new(8, 8, 2000 + s);
        let x = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, 1.0)]), c(3, 3), 100.0);
        let y = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, 1.0)]), c(3, 3), 100.0);
        let t = b.mate(&[x, y], Kind::Herbivore);
        assert!(t.offspring >= 1 && t.offspring <= b.cfg.herbivores.max_litter as u64);
    }
    // 1×1 world, capacity 4, two parents → at most 2 children
    let mut b = Bench::new(1, 1, 3);
    b.cfg.herbivores.max_litter = 16;
    let x = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, 1.0)]), c(0, 0), 100.0);
    let y = b.add(genome(Kind::Herbivore, &[(GeneTrait::Fertility, 1.0)]), c(0, 0), 100.0);
    let t = b.mate(&[x, y], Kind::Herbivore);
    assert!(t.offspring <= 2, "{t:?}");
    assert_eq!(b.finish_tick().len() as u64, t.offspring, "no birth dropped for lack of room");
}

#[test]
fn no_room_costs_nothing() {
    let mut b = Bench::new(1, 1, 4);
    let ids: Vec<_> = (0..4).map(|_| b.herb(c(0, 0), 100.0)).collect();
    let t = b.mate(&ids, Kind::Herbivore);
    assert_eq!((t.attempts, t.no_room, t.conceived), (2, 2, 0));
    assert!(ids.iter().all(|&i| b.energy(i) == 100.0));
}

// ---------- AC6: a single animal never produces offspring ----------

#[test]
fn lone_herbivore_never_reproduces() {
    let mut cfg = Config::new(21, 24, 24, 300, 1, 0);
    cfg.herbivores.maturity_age = 0;
    cfg.herbivores.reproduction_threshold = 20.0;
    cfg.herbivores.reproduction_cost = 5.0;
    cfg.herbivores.conception_chance = 1.0;
    let mut sim = Simulation::new(cfg).unwrap();
    for _ in 0..3000 {
        sim.step();
        if sim.organisms().count_alive(Kind::Herbivore) == 0 {
            break;
        }
    }
    assert_eq!(sim.totals().births[Kind::Herbivore.index()], 0);
    assert_eq!(sim.world().repro_ledger(Kind::Herbivore).total.attempts, 0);
}

#[test]
fn lone_carnivore_never_reproduces() {
    let mut b = Bench::new(6, 6, 22);
    let x = b.add(Genome::founder_default(Kind::Carnivore), c(1, 1), 160.0);
    for _ in 0..2000 {
        b.pop.get_alive_mut(x).unwrap().set_energy(160.0);
        let t = b.mate(&[x], Kind::Carnivore);
        assert_eq!(t.attempts, 0);
        assert!(b.finish_tick().is_empty());
    }
}

// ---------- mate search / choice ----------

#[test]
fn mate_choice_prefers_most_energy() {
    let mut b = Bench::new(10, 10, 23);
    let x = b.herb(c(2, 2), 100.0);
    let near = b.herb(c(2, 2), 75.0);
    let rich = b.herb(c(3, 3), 95.0);
    let t = b.mate(&[x, near, rich], Kind::Herbivore);
    assert_eq!(t.attempts, 1, "near has no free partner left");
    let r = b.finish_tick();
    assert!(r.iter().all(|r| r.parents == Parents::Two(x, rich)));
}

#[test]
fn courting_moves_towards_mate() {
    let mut b = Bench::new(20, 20, 24);
    let x = b.herb(c(2, 2), 100.0);
    let y = b.herb(c(6, 2), 100.0); // distance 4, within vision of founders
    let now = vec![CellNow { temperature: 15.0, precipitation: 500.0 }; 400];
    let fp = FeedParams::from_config(&b.cfg);
    let costs = MoveCosts::for_kind(Kind::Herbivore, &b.cfg);
    let rp = ReproParams::for_kind(Kind::Herbivore, &b.cfg);
    let r = vision_radius(b.pop.get(x).unwrap().traits());
    assert!(r >= 4, "vision {r}");
    let mut d = 4;
    for _ in 0..5 {
        let t = herbivore_turn(&mut b.pop, x, &fp, &costs, &rp, &now, 20, 1, &mut b.rng).unwrap();
        b.pop.get_alive_mut(x).unwrap().set_energy(100.0);
        let nd = b.pop.index().torus().distance(b.pop.get(x).unwrap().pos(), b.pop.get(y).unwrap().pos());
        if d > MATING_REACH {
            assert_eq!(t.action, HerbivoreAction::Court);
            assert!(nd < d || t.moved.steps == 0, "approaches");
        } else {
            assert_ne!(t.action, HerbivoreAction::Court, "partner in reach: no courting");
        }
        d = nd;
    }
    assert!(d <= MATING_REACH, "reached mate: {d}");
}

// ---------- runs: determinism + invariants ----------

fn breeding_config(seed: u64) -> Config {
    let mut cfg = Config::new(seed, 32, 24, 300, 60, 0);
    cfg.herbivores.maturity_age = 20;
    cfg.herbivores.reproduction_threshold = 45.0;
    cfg.herbivores.reproduction_cost = 12.0;
    cfg
}

fn run_births(cfg: Config, ticks: u32) -> (u64, Vec<(u64, Parents)>) {
    let mut s = Simulation::new(cfg).unwrap();
    let mut v = Vec::new();
    for _ in 0..ticks {
        s.step();
        v.extend(s.organisms().last_births().iter().filter(|r| r.kind == Kind::Herbivore).map(|r| (r.id.0, r.parents)));
    }
    (s.totals().births[Kind::Herbivore.index()], v)
}

#[test]
fn reproduction_deterministic() {
    let a = run_births(breeding_config(31), 300);
    let b = run_births(breeding_config(31), 300);
    let c2 = run_births(breeding_config(32), 300);
    assert!(a.0 > 0, "herbivores reproduce in the breeding config");
    assert_eq!(a, b);
    assert_ne!(a.1, c2.1);
}

#[test]
fn runs_keep_invariants() {
    let mut cfg = Config::contract_example();
    cfg.herbivores.maturity_age = 30;
    cfg.carnivores.maturity_age = 40;
    let mut s = Simulation::new(cfg.clone()).unwrap();
    let initial = [cfg.initial.herbivores as u64, cfg.initial.carnivores as u64];
    for _ in 0..1500 {
        s.step_with(|ctx| {
            if ctx.phase == Phase::Herbivores || ctx.phase == Phase::Carnivores {
                for k in [Kind::Herbivore, Kind::Carnivore] {
                    let l = ctx.world.repro_ledger(k).last;
                    assert!(l.offspring_energy <= l.energy_spent + 1e-9);
                    assert!(l.conceived <= l.attempts && l.attempts * 2 <= l.ready + l.attempts * 2);
                }
            }
        });
        for r in s.organisms().last_births() {
            if r.kind == Kind::Plant {
                continue;
            }
            let Parents::Two(a, b) = r.parents else { panic!("animal birth without two parents: {r:?}") };
            assert_ne!(a, b);
        }
    }
    for (i, k) in [Kind::Herbivore, Kind::Carnivore].into_iter().enumerate() {
        let t = s.totals();
        let deaths: u64 = crate::organism::DeathCause::ALL.iter().map(|&d| t.deaths_by(k, d)).sum();
        assert_eq!(s.organisms().count_alive(k) as u64, initial[i] + t.births[k.index()] - deaths, "{k:?}");
    }
    assert!(s.organisms().validate(u64::MAX).is_ok());
}

#[test]
#[ignore]
fn smoke_reproduction() {
    let cfg = Config::contract_example();
    let mut s = Simulation::new(cfg).unwrap();
    for t in 0..=2000u64 {
        if t % 250 == 0 {
            let p = s.organisms();
            let h = s.world().repro_ledger(Kind::Herbivore).total;
            let k = s.world().repro_ledger(Kind::Carnivore).total;
            println!(
                "tick {t}: plants {} herbivores {} carnivores {} | herb conceived {} offspring {} | carn conceived {} offspring {}",
                p.count_alive(Kind::Plant),
                p.count_alive(Kind::Herbivore),
                p.count_alive(Kind::Carnivore),
                h.conceived,
                h.offspring,
                k.conceived,
                k.offspring
            );
        }
        s.step();
    }
}

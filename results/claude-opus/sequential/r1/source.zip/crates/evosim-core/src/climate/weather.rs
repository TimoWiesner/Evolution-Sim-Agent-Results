//! Weather: torus-periodic AR(1) anomaly lattices for temperature and
//! precipitation, driven by the core simulation RNG (ADR-010, TASK-007).
//!
//! The two lattices are the only weather state that carries over between
//! ticks ([`WeatherState`]); everything else is derived.

use std::fmt;

use super::noise::PeriodicNoise;
use crate::config::ClimateParams;
use crate::rng::Rng;

/// Exact weather state: lattice node values (row-major), T in °C, P relative.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct WeatherState {
    pub temperature: Vec<f64>,
    pub precipitation: Vec<f64>,
}

/// Invalid weather state on restore.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WeatherError {
    /// Lattice length mismatch: (field, expected, got).
    Length(&'static str, usize, usize),
    /// Non-finite value in field.
    NonFinite(&'static str),
}

impl fmt::Display for WeatherError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            WeatherError::Length(n, e, g) => write!(f, "weather {n} lattice: expected {e} values, got {g}"),
            WeatherError::NonFinite(n) => write!(f, "weather {n} lattice contains a non-finite value"),
        }
    }
}

impl std::error::Error for WeatherError {}

#[derive(Debug, Clone, PartialEq)]
pub struct Weather {
    width: u32,
    height: u32,
    t: PeriodicNoise,
    p: PeriodicNoise,
}

fn ar1(v: &mut [f64], rho: f64, sd: f64, rng: &mut Rng) {
    let k = (1.0 - rho * rho).max(0.0).sqrt() * sd;
    let lim = 3.0 * sd;
    for a in v.iter_mut() {
        let z = rng.normal(0.0, 1.0);
        *a = (rho * *a + k * z).clamp(-lim, lim);
    }
}

impl Weather {
    /// Zero weather for a `width × height` world (lattice from `weather_scale`).
    pub fn new(width: u32, height: u32, params: &ClimateParams) -> Weather {
        let s = params.weather_scale;
        Weather {
            width,
            height,
            t: PeriodicNoise::zeros(width, height, s),
            p: PeriodicNoise::zeros(width, height, s),
        }
    }

    /// Lattice size (gx, gy), same for both fields.
    pub fn lattice(&self) -> (u32, u32) {
        self.t.lattice()
    }

    /// One tick of weather: if enabled, every T node (row-major) then every P
    /// node draws one `rng.normal(0, 1)` and follows
    /// `a ← clamp(ρa + √(1−ρ²)·σ·z, −3σ, 3σ)`. Disabled: no draws, no change.
    pub fn advance(&mut self, params: &ClimateParams, rng: &mut Rng) {
        if !params.weather_enabled {
            return;
        }
        let rho = params.weather_persistence;
        ar1(self.t.values_mut(), rho, params.weather_temperature_sd, rng);
        ar1(self.p.values_mut(), rho, params.weather_precipitation_sd, rng);
    }

    /// (temperature °C, precipitation relative) anomaly at continuous cell
    /// coordinates; periodic, continuous across both seams.
    pub fn anomaly(&self, x: f64, y: f64) -> (f64, f64) {
        (self.t.at_cell(x, y, self.width, self.height), self.p.at_cell(x, y, self.width, self.height))
    }

    pub fn state(&self) -> WeatherState {
        WeatherState { temperature: self.t.values().to_vec(), precipitation: self.p.values().to_vec() }
    }

    /// Exact restore; lengths must match the lattice and values be finite.
    pub fn restore(&mut self, s: WeatherState) -> Result<(), WeatherError> {
        let n = self.t.values().len();
        for (name, v) in [("temperature", &s.temperature), ("precipitation", &s.precipitation)] {
            if v.len() != n {
                return Err(WeatherError::Length(name, n, v.len()));
            }
            if v.iter().any(|x| !x.is_finite()) {
                return Err(WeatherError::NonFinite(name));
            }
        }
        self.t.values_mut().copy_from_slice(&s.temperature);
        self.p.values_mut().copy_from_slice(&s.precipitation);
        Ok(())
    }
}

//! Evolution Simulation core engine.
//!
//! Provides product identity constants, `config` (TASK-003), `topology`
//! (TASK-004, toroidal grid geometry), and `rng`/`ids`/`sim` (TASK-005: seeded
//! generator, entity IDs, `Simulation` tick scheduler), `climate` (TASK-006:
//! latitude zones, base temperature/precipitation, biomes), `organism`
//! (TASK-008: kinds, traits, population, life cycle), `genome` (TASK-009:
//! DNA, expression, crossover, mutation, distance), `spatial` (TASK-010:
//! neighbour search index), `plants` (TASK-011: cell resources, plant
//! growth, climate stress), `animals` (TASK-013: sensing, movement, cell-
//! sharing rule), `species` (TASK-017: species classification, family
//! tree), `digest` + `report` (TASK-019: SHA-256 state hash, headless run
//! loop and result JSON), `snapshot` (TASK-022: checkpoints), `metrics` (TASK-020: per-sample
//! evolution analytics); further modules
//! (see docs/ARCHITECTURE.md) are added by later tasks. This crate must never
//! depend on `evosim-ui` or `evosim-cli`.

pub mod animals;
pub mod batch;
pub mod climate;
pub mod config;
pub mod digest;
pub mod ecology;
pub mod genome;
pub mod ids;
pub mod metrics;
pub mod organism;
pub mod plants;
pub mod report;
pub mod rng;
pub mod sim;
pub mod snapshot;
pub mod spatial;
pub mod species;
pub mod topology;

/// Re-export so front-ends can handle JSON values produced by the core.
pub use serde_json;

/// Product name reported by `evosim version`.
pub const NAME: &str = "evosim";
/// Product version (from the workspace Cargo version).
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
/// Interface contract version implemented (docs/CONTRACT.md).
pub const CONTRACT_VERSION: u32 = 1;

/// JSON object printed by `evosim version` (without trailing newline).
///
/// The constants contain no characters that need JSON escaping.
pub fn version_json() -> String {
    format!(
        "{{\"name\":\"{}\",\"version\":\"{}\",\"contract\":{}}}",
        NAME, VERSION, CONTRACT_VERSION
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_json_has_contract_shape() {
        assert_eq!(
            version_json(),
            format!("{{\"name\":\"evosim\",\"version\":\"{VERSION}\",\"contract\":1}}")
        );
    }

    #[test]
    fn constants_need_no_json_escaping() {
        for s in [NAME, VERSION] {
            assert!(!s.is_empty());
            assert!(s.chars().all(|c| c != '"' && c != '\\' && !c.is_control()));
        }
        assert_eq!(CONTRACT_VERSION, 1);
    }
}

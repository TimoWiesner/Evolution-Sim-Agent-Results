//! Batch runs, parameter sweeps and summary export (TASK-021, ADR-024,
//! docs/BATCH.md).
//!
//! Pure: no wall clock, no file I/O. The CLI (`evosim-cli/src/batch.rs`)
//! parses arguments, runs the simulations (possibly on several threads),
//! measures time and writes the files; this module expands the sweep into
//! run specifications and builds `summary.json` / `summary.csv` /
//! `aggregates.csv` from the per-run result JSON values.
//!
//! Time measurements in the summary are exactly [`TIME_KEYS`]; everything
//! else is a pure function of the config file content, the arguments (except
//! `--jobs`/`--out-dir`) and the build.

use crate::config::Config;
use crate::report::KIND_KEYS;
use serde_json::{json, Map, Value};

#[cfg(test)]
mod tests;

/// Summary format name and version.
pub const SUMMARY_FORMAT: &str = "evosim-batch-summary";
pub const SUMMARY_FORMAT_VERSION: u32 = 1;
/// Maximum number of runs of one batch (guard against typos).
pub const MAX_RUNS: usize = 10_000;
/// Locations of wall-clock measurements in `summary.json` (everything else is
/// reproducible): the top-level `timing` object and two keys of every run.
pub const TIME_KEYS: [&str; 3] = ["timing", "runs[].elapsed_seconds", "runs[].ticks_per_second"];
/// Keys that cannot be swept with `--param`.
pub const NOT_SWEEPABLE: [&str; 3] = ["seed", "name", "description"];

/// One `--param KEY=V1,V2,...` flag.
#[derive(Debug, Clone, PartialEq)]
pub struct Sweep {
    pub key: String,
    pub values: Vec<Value>,
}

/// One parameter combination (index = position in the cartesian product).
#[derive(Debug, Clone, PartialEq)]
pub struct Combo {
    pub index: usize,
    pub params: Vec<(String, Value)>,
}

impl Combo {
    /// Relative directory of the combination's files (`.` without sweep).
    pub fn dir(&self, has_sweep: bool) -> String {
        if has_sweep { format!("combo-{}", self.index) } else { ".".into() }
    }
}

/// One run of the batch.
#[derive(Debug, Clone)]
pub struct RunSpec {
    pub index: usize,
    pub combo: usize,
    pub seed: u64,
    pub config: Config,
    /// Relative path of the per-seed result file.
    pub file: String,
}

/// Parse `--seeds 1,2,3`: non-empty, non-negative integers, no duplicates.
pub fn parse_seeds(s: &str) -> Result<Vec<u64>, String> {
    let mut out = Vec::new();
    for tok in s.split(',') {
        let t = tok.trim();
        if t.is_empty() || !t.bytes().all(|b| b.is_ascii_digit()) {
            return Err(format!("--seeds needs a comma-separated list of non-negative integers, got '{s}'"));
        }
        let v: u64 = t.parse().map_err(|_| format!("--seeds value '{t}' is out of range"))?;
        if out.contains(&v) {
            return Err(format!("--seeds lists seed {v} more than once"));
        }
        out.push(v);
    }
    Ok(out)
}

/// Parse `KEY=V1,V2,...`; each value is a JSON literal (number, bool or
/// quoted string).
pub fn parse_param(s: &str) -> Result<Sweep, String> {
    let Some((key, vals)) = s.split_once('=') else {
        return Err(format!("--param needs KEY=V1,V2,..., got '{s}'"));
    };
    let key = key.trim();
    if key.is_empty() || key.split('.').any(|p| p.is_empty()) {
        return Err(format!("--param '{s}': invalid key '{key}'"));
    }
    if NOT_SWEEPABLE.contains(&key) {
        return Err(format!("--param '{s}': '{key}' cannot be swept (use --seeds for seeds)"));
    }
    let mut values: Vec<Value> = Vec::new();
    for tok in vals.split(',') {
        let t = tok.trim();
        if t.is_empty() {
            return Err(format!("--param '{s}': empty value"));
        }
        let v: Value = serde_json::from_str(t)
            .map_err(|_| format!("--param '{s}': value '{t}' is not a JSON literal (strings need JSON quotes)"))?;
        if !(v.is_number() || v.is_boolean() || v.is_string()) {
            return Err(format!("--param '{s}': value '{t}' must be a number, boolean or string"));
        }
        if values.contains(&v) {
            return Err(format!("--param '{s}': value '{t}' given more than once"));
        }
        values.push(v);
    }
    Ok(Sweep { key: key.to_string(), values })
}

/// Set `doc[a][b][c] = v` for key `a.b.c`, creating missing objects.
pub fn set_dotted(doc: &mut Value, key: &str, v: Value) -> Result<(), String> {
    let parts: Vec<&str> = key.split('.').collect();
    let mut cur = doc;
    for (i, p) in parts.iter().enumerate() {
        let Some(obj) = cur.as_object_mut() else {
            let at = parts[..i].join(".");
            return Err(format!("--param {key}: '{}' is not an object", if at.is_empty() { "<root>" } else { &at }));
        };
        if i + 1 == parts.len() {
            obj.insert((*p).to_string(), v);
            return Ok(());
        }
        cur = obj.entry((*p).to_string()).or_insert_with(|| Value::Object(Map::new()));
    }
    unreachable!("split yields at least one part")
}

/// Cartesian product of the sweeps; the first sweep varies slowest. No
/// sweeps → one combination without parameters.
pub fn combos(sweeps: &[Sweep]) -> Vec<Combo> {
    let mut acc: Vec<Vec<(String, Value)>> = vec![Vec::new()];
    for s in sweeps {
        let mut next = Vec::with_capacity(acc.len() * s.values.len());
        for prefix in &acc {
            for v in &s.values {
                let mut p = prefix.clone();
                p.push((s.key.clone(), v.clone()));
                next.push(p);
            }
        }
        acc = next;
    }
    acc.into_iter().enumerate().map(|(index, params)| Combo { index, params }).collect()
}

/// Expand the batch into run specifications (combinations outer, seeds
/// inner). Every combination's config is validated.
pub fn expand(base: &Value, sweeps: &[Sweep], seeds: &[u64]) -> Result<(Vec<Combo>, Vec<RunSpec>), String> {
    if seeds.is_empty() {
        return Err("--seeds is empty".into());
    }
    for (i, s) in sweeps.iter().enumerate() {
        if sweeps[..i].iter().any(|o| o.key == s.key) {
            return Err(format!("--param {} given more than once", s.key));
        }
        if s.values.is_empty() {
            return Err(format!("--param {} has no values", s.key));
        }
    }
    let n_combos = sweeps.iter().try_fold(1usize, |a, s| a.checked_mul(s.values.len()));
    match n_combos.and_then(|c| c.checked_mul(seeds.len())) {
        Some(n) if n <= MAX_RUNS => {}
        _ => return Err(format!("batch would have more than {MAX_RUNS} runs")),
    }
    let has_sweep = !sweeps.is_empty();
    let cs = combos(sweeps);
    let mut runs = Vec::new();
    for c in &cs {
        let mut doc = base.clone();
        for (k, v) in &c.params {
            set_dotted(&mut doc, k, v.clone())?;
        }
        let cfg = Config::from_value(&doc).map_err(|e| {
            let p: Vec<String> = c.params.iter().map(|(k, v)| format!("{k}={v}")).collect();
            if has_sweep { format!("--param {}: {e}", p.join(" ")) } else { e.to_string() }
        })?;
        for &seed in seeds {
            let file = if has_sweep { format!("combo-{}/seed-{seed}.json", c.index) } else { format!("seed-{seed}.json") };
            runs.push(RunSpec { index: runs.len(), combo: c.index, seed, config: cfg.clone().with_seed(seed), file });
        }
    }
    Ok((cs, runs))
}

/// What the summary needs from one finished run.
#[derive(Debug, Clone, PartialEq)]
pub struct RunOutcome {
    pub index: usize,
    pub combo: usize,
    pub seed: u64,
    pub file: String,
    pub tick_start: u64,
    pub tick_end: u64,
    pub final_counts: [u64; 3],
    pub species: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    pub extinction_tick: [Option<u64>; 3],
    pub state_hash: String,
    /// Wall-clock measurements (time keys).
    pub elapsed_seconds: f64,
    pub ticks_per_second: f64,
}

impl RunOutcome {
    /// Extract from a result JSON (`report::result_json`).
    pub fn from_result(spec: &RunSpec, v: &Value) -> Result<Self, String> {
        let u = |path: &[&str]| -> Result<u64, String> {
            let mut c = v;
            for p in path {
                c = &c[*p];
            }
            c.as_u64().ok_or_else(|| format!("result JSON lacks integer {}", path.join(".")))
        };
        let kinds = |pre: &[&str]| -> Result<[u64; 3], String> {
            let mut out = [0; 3];
            for (i, k) in KIND_KEYS.iter().enumerate() {
                let mut p = pre.to_vec();
                p.push(k);
                out[i] = u(&p)?;
            }
            Ok(out)
        };
        let mut ext = [None; 3];
        for (i, k) in KIND_KEYS.iter().enumerate() {
            ext[i] = v["extinction_tick"][*k].as_u64();
        }
        Ok(RunOutcome {
            index: spec.index,
            combo: spec.combo,
            seed: spec.seed,
            file: spec.file.clone(),
            tick_start: u(&["tick_start"])?,
            tick_end: u(&["tick_end"])?,
            final_counts: kinds(&["final"])?,
            species: kinds(&["final", "species"])?,
            births: kinds(&["totals", "births"])?,
            deaths: kinds(&["totals", "deaths"])?,
            extinction_tick: ext,
            state_hash: v["state_hash"].as_str().unwrap_or_default().to_string(),
            elapsed_seconds: v["elapsed_seconds"].as_f64().unwrap_or(0.0),
            ticks_per_second: v["ticks_per_second"].as_f64().unwrap_or(0.0),
        })
    }

    pub fn ticks(&self) -> u64 {
        self.tick_end - self.tick_start
    }

    /// All three kinds alive at `tick_end`.
    pub fn coexistence(&self) -> bool {
        self.final_counts.iter().all(|&c| c > 0)
    }
}

/// Batch-wide inputs of the summary.
#[derive(Debug, Clone)]
pub struct BatchMeta {
    pub config_file: String,
    pub ticks: u64,
    pub sample_every: u64,
    pub seeds: Vec<u64>,
    pub sweeps: Vec<Sweep>,
    /// Time measurements (only in `timing`).
    pub wall_seconds: f64,
    pub jobs: usize,
}

/// mean, min, max, population sd, median of integer samples (in the given
/// order; sums are order-fixed). `None` when empty.
pub fn stats(xs: &[u64]) -> Option<Value> {
    if xs.is_empty() {
        return None;
    }
    let n = xs.len() as f64;
    let mean = xs.iter().map(|&x| x as f64).sum::<f64>() / n;
    let var = xs.iter().map(|&x| (x as f64 - mean).powi(2)).sum::<f64>() / n;
    let mut s = xs.to_vec();
    s.sort_unstable();
    let m = s.len() / 2;
    let median = if s.len() % 2 == 1 { s[m] as f64 } else { (s[m - 1] as f64 + s[m] as f64) / 2.0 };
    Some(json!({"mean": mean, "min": s[0], "max": s[s.len() - 1], "sd": var.sqrt(), "median": median}))
}

fn params_obj(params: &[(String, Value)]) -> Value {
    Value::Object(params.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
}

fn per_kind<T: Into<Value> + Clone>(v: &[T; 3]) -> Value {
    Value::Object(KIND_KEYS.iter().zip(v.iter()).map(|(k, x)| ((*k).to_string(), x.clone().into())).collect())
}

/// Aggregates over a group of runs (ADR-024 §5 `AGG`).
pub fn aggregate(runs: &[&RunOutcome]) -> Value {
    let n = runs.len();
    let frac = |c: usize| if n == 0 { 0.0 } else { c as f64 / n as f64 };
    let mean = |xs: &[u64]| if xs.is_empty() { 0.0 } else { xs.iter().map(|&x| x as f64).sum::<f64>() / xs.len() as f64 };
    let coex = runs.iter().filter(|r| r.coexistence()).count();
    let mut kinds = Map::new();
    for (i, k) in KIND_KEYS.iter().enumerate() {
        let fin: Vec<u64> = runs.iter().map(|r| r.final_counts[i]).collect();
        let sp: Vec<u64> = runs.iter().map(|r| r.species[i]).collect();
        let ext: Vec<u64> = runs.iter().filter_map(|r| r.extinction_tick[i]).collect();
        let b: Vec<u64> = runs.iter().map(|r| r.births[i]).collect();
        let d: Vec<u64> = runs.iter().map(|r| r.deaths[i]).collect();
        let sp_stats = stats(&sp).map(|s| json!({"mean": s["mean"], "min": s["min"], "max": s["max"]}));
        let ext_stats = stats(&ext).map(|s| json!({"mean": s["mean"], "min": s["min"], "max": s["max"]}));
        kinds.insert(
            (*k).to_string(),
            json!({
                "final": stats(&fin).unwrap_or(Value::Null),
                "species_final": sp_stats.unwrap_or(Value::Null),
                "extinct_runs": ext.len(),
                "extinct_fraction": frac(ext.len()),
                "extinction_tick": ext_stats.unwrap_or(Value::Null),
                "births_mean": mean(&b),
                "deaths_mean": mean(&d),
            }),
        );
    }
    json!({"runs": n, "coexistence_runs": coex, "coexistence_fraction": frac(coex), "kinds": Value::Object(kinds)})
}

fn run_params<'a>(combos: &'a [Combo], r: &RunOutcome) -> &'a [(String, Value)] {
    combos.get(r.combo).map(|c| c.params.as_slice()).unwrap_or(&[])
}

/// The `summary.json` document (ADR-024 §5). `outcomes` must be in run
/// index order.
pub fn summary_json(meta: &BatchMeta, combos: &[Combo], outcomes: &[RunOutcome]) -> Value {
    let has_sweep = !meta.sweeps.is_empty();
    let sweep: Vec<Value> = meta.sweeps.iter().map(|s| json!({"key": s.key, "values": s.values})).collect();
    let combinations: Vec<Value> =
        combos.iter().map(|c| json!({"combo": c.index, "params": params_obj(&c.params), "dir": c.dir(has_sweep)})).collect();
    let runs: Vec<Value> = outcomes
        .iter()
        .map(|r| {
            let ext_flags = r.extinction_tick.map(|e| e.is_some());
            let ext_ticks: [Value; 3] = r.extinction_tick.map(|e| e.map_or(Value::Null, Value::from));
            let mut fin = per_kind(&r.final_counts);
            fin["species"] = per_kind(&r.species);
            json!({
                "index": r.index, "combo": r.combo, "seed": r.seed,
                "params": params_obj(run_params(combos, r)), "file": r.file,
                "tick_start": r.tick_start, "tick_end": r.tick_end, "ticks": r.ticks(),
                "final": fin, "births": per_kind(&r.births), "deaths": per_kind(&r.deaths),
                "extinct": per_kind(&ext_flags), "extinction_tick": per_kind(&ext_ticks),
                "coexistence": r.coexistence(), "state_hash": r.state_hash,
                "elapsed_seconds": r.elapsed_seconds, "ticks_per_second": r.ticks_per_second,
            })
        })
        .collect();
    let all: Vec<&RunOutcome> = outcomes.iter().collect();
    let by_combo: Vec<Value> = combos
        .iter()
        .map(|c| {
            let group: Vec<&RunOutcome> = outcomes.iter().filter(|r| r.combo == c.index).collect();
            let mut a = aggregate(&group);
            a["combo"] = c.index.into();
            a["params"] = params_obj(&c.params);
            a
        })
        .collect();
    let sum_elapsed: f64 = outcomes.iter().map(|r| r.elapsed_seconds).sum();
    json!({
        "format": SUMMARY_FORMAT, "format_version": SUMMARY_FORMAT_VERSION,
        "contract": crate::CONTRACT_VERSION, "name": crate::NAME, "version": crate::VERSION,
        "config_file": meta.config_file, "ticks": meta.ticks, "sample_every": meta.sample_every,
        "seeds": meta.seeds, "sweep": sweep, "combinations": combinations, "runs": runs,
        "aggregates": {"all": aggregate(&all), "by_combo": by_combo},
        "timing": {"wall_seconds": meta.wall_seconds, "jobs": meta.jobs, "sum_elapsed_seconds": sum_elapsed},
    })
}

/// Remove the time measurements ([`TIME_KEYS`]) from a summary (for
/// reproducibility comparisons).
pub fn strip_time(summary: &Value) -> Value {
    let mut v = summary.clone();
    if let Some(o) = v.as_object_mut() {
        o.remove("timing");
    }
    if let Some(runs) = v["runs"].as_array_mut() {
        for r in runs {
            if let Some(o) = r.as_object_mut() {
                o.remove("elapsed_seconds");
                o.remove("ticks_per_second");
            }
        }
    }
    v
}

/// RFC 4180 field quoting.
pub fn csv_field(s: &str) -> String {
    if s.contains([',', '"', '\n', '\r']) {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}

/// CSV text of a JSON scalar: strings without quotes, null empty.
fn csv_value(v: &Value) -> String {
    match v {
        Value::Null => String::new(),
        Value::String(s) => csv_field(s),
        other => csv_field(&other.to_string()),
    }
}

fn csv_line(fields: &[String]) -> String {
    let mut s = fields.join(",");
    s.push('\n');
    s
}

fn kind_cols(prefix: &str) -> Vec<String> {
    KIND_KEYS.iter().map(|k| format!("{prefix}_{k}")).collect()
}

/// `summary.csv`: one row per run (ADR-024 §6). The last two columns are the
/// time measurements.
pub fn summary_csv(sweeps: &[Sweep], combos: &[Combo], outcomes: &[RunOutcome]) -> String {
    let mut h: Vec<String> = vec!["index".into(), "combo".into(), "seed".into()];
    h.extend(sweeps.iter().map(|s| csv_field(&s.key)));
    h.push("ticks".into());
    for p in ["final", "species", "births", "deaths", "extinct", "extinction_tick"] {
        h.extend(kind_cols(p));
    }
    h.extend(["coexistence", "state_hash", "elapsed_seconds", "ticks_per_second"].map(String::from));
    let mut out = csv_line(&h);
    for r in outcomes {
        let params = run_params(combos, r);
        let mut f: Vec<String> = vec![r.index.to_string(), r.combo.to_string(), r.seed.to_string()];
        for s in sweeps {
            f.push(params.iter().find(|(k, _)| *k == s.key).map(|(_, v)| csv_value(v)).unwrap_or_default());
        }
        f.push(r.ticks().to_string());
        for arr in [&r.final_counts, &r.species, &r.births, &r.deaths] {
            f.extend(arr.iter().map(u64::to_string));
        }
        f.extend(r.extinction_tick.iter().map(|e| e.is_some().to_string()));
        f.extend(r.extinction_tick.iter().map(|e| e.map(|t| t.to_string()).unwrap_or_default()));
        f.push(r.coexistence().to_string());
        f.push(csv_field(&r.state_hash));
        f.push(Value::from(r.elapsed_seconds).to_string());
        f.push(Value::from(r.ticks_per_second).to_string());
        out.push_str(&csv_line(&f));
    }
    out
}

/// `aggregates.csv`: one row per (group, kind); group `all` then
/// `combo-<c>` (ADR-024 §6). Built from [`summary_json`]'s aggregates.
pub fn aggregates_csv(sweeps: &[Sweep], summary: &Value) -> String {
    let mut h: Vec<String> = vec!["group".into()];
    h.extend(sweeps.iter().map(|s| csv_field(&s.key)));
    h.extend(
        [
            "kind", "runs", "final_mean", "final_min", "final_max", "final_sd", "final_median", "extinct_runs",
            "extinct_fraction", "extinction_tick_mean", "coexistence_runs",
        ]
        .map(String::from),
    );
    let mut out = csv_line(&h);
    let agg = &summary["aggregates"];
    let mut groups: Vec<(String, &Value)> = vec![("all".into(), &agg["all"])];
    if let Some(bc) = agg["by_combo"].as_array() {
        for g in bc {
            groups.push((format!("combo-{}", g["combo"]), g));
        }
    }
    for (name, g) in groups {
        for k in KIND_KEYS {
            let kd = &g["kinds"][k];
            let mut f = vec![name.clone()];
            for s in sweeps {
                f.push(if name == "all" { String::new() } else { csv_value(&g["params"][&s.key]) });
            }
            f.push(k.to_string());
            f.push(csv_value(&g["runs"]));
            for st in ["mean", "min", "max", "sd", "median"] {
                f.push(csv_value(&kd["final"][st]));
            }
            f.push(csv_value(&kd["extinct_runs"]));
            f.push(csv_value(&kd["extinct_fraction"]));
            f.push(csv_value(&kd["extinction_tick"]["mean"]));
            f.push(csv_value(&g["coexistence_runs"]));
            out.push_str(&csv_line(&f));
        }
    }
    out
}

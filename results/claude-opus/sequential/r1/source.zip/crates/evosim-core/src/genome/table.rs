//! Gene layout v1 (ADR-012): per-kind static gene tables.

use crate::organism::Kind;

/// Layout version of the gene tables (bump when a row is added/reordered).
pub const GENE_LAYOUT_VERSION: u32 = 1;

/// Trait a gene is expressed into.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum GeneTrait {
    Strength,
    Fertility,
    MaxHealth,
    Lifespan,
    MaxEnergy,
    TempOptimum,
    TempTolerance,
    Speed,
    Vision,
    Aggression,
    Caution,
}

/// One row of a gene table.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct GeneSpec {
    pub name: &'static str,
    /// `None` = neutral marker gene.
    pub target: Option<GeneTrait>,
    /// Value in the founder default genome.
    pub founder: f32,
    /// Weight in the genetic distance.
    pub weight: f64,
}

const fn g(name: &'static str, target: GeneTrait, founder: f32) -> GeneSpec {
    GeneSpec { name, target: Some(target), founder, weight: 1.0 }
}

const fn m(name: &'static str) -> GeneSpec {
    GeneSpec { name, target: None, founder: 0.5, weight: 1.0 }
}

static PLANT_GENES: [GeneSpec; 13] = [
    g("strength", GeneTrait::Strength, 0.5),
    g("fertility", GeneTrait::Fertility, 0.5),
    g("max_health", GeneTrait::MaxHealth, 0.5),
    g("lifespan", GeneTrait::Lifespan, 1.0),
    g("max_energy", GeneTrait::MaxEnergy, 1.0),
    g("temp_optimum", GeneTrait::TempOptimum, 0.5),
    g("temp_tolerance", GeneTrait::TempTolerance, 0.5),
    m("marker_0"),
    m("marker_1"),
    m("marker_2"),
    m("marker_3"),
    m("marker_4"),
    m("marker_5"),
];

static ANIMAL_GENES: [GeneSpec; 17] = [
    g("strength", GeneTrait::Strength, 0.5),
    g("fertility", GeneTrait::Fertility, 0.5),
    g("max_health", GeneTrait::MaxHealth, 0.5),
    g("lifespan", GeneTrait::Lifespan, 1.0),
    g("max_energy", GeneTrait::MaxEnergy, 1.0),
    g("temp_optimum", GeneTrait::TempOptimum, 0.5),
    g("temp_tolerance", GeneTrait::TempTolerance, 0.5),
    g("speed", GeneTrait::Speed, 0.5),
    g("vision", GeneTrait::Vision, 1.0),
    g("aggression", GeneTrait::Aggression, 0.5),
    g("caution", GeneTrait::Caution, 0.5),
    m("marker_0"),
    m("marker_1"),
    m("marker_2"),
    m("marker_3"),
    m("marker_4"),
    m("marker_5"),
];

/// Gene table of a kind (herbivores and carnivores share the animal layout).
pub fn gene_table(kind: Kind) -> &'static [GeneSpec] {
    match kind {
        Kind::Plant => &PLANT_GENES,
        Kind::Herbivore | Kind::Carnivore => &ANIMAL_GENES,
    }
}

/// Locus of the gene expressed into `t`, if the kind has one.
pub fn gene_index(kind: Kind, t: GeneTrait) -> Option<usize> {
    gene_table(kind).iter().position(|s| s.target == Some(t))
}

//! TASK-004 topology tests. Name prefixes map to the acceptance criteria:
//! `edge_`, `corner_`, `negative_`, `multi_wrap_`, `world_1x1_`, `within_`,
//! `small_`, `non_square_`.

use super::*;
use std::collections::BTreeSet;

fn t(w: u32, h: u32) -> Torus {
    Torus::new(w, h).unwrap()
}

fn c(x: u32, y: u32) -> Cell {
    Cell::new(x, y)
}

/// Tiny deterministic generator for property loops (SplitMix64).
struct Mix(u64);
impl Mix {
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }
}

fn worlds_small() -> Vec<Torus> {
    let mut v = Vec::new();
    for w in 1..=7 {
        for h in 1..=7 {
            v.push(t(w, h));
        }
    }
    v.push(t(1, 12));
    v.push(t(12, 1));
    v.push(t(16, 9));
    v
}

// ---------------------------------------------------------------- AC4 errors
#[test]
fn small_new_rejects_invalid_dimensions() {
    assert_eq!(Torus::new(0, 5), Err(TopologyError::ZeroDimension { axis: "width" }));
    assert_eq!(Torus::new(5, 0), Err(TopologyError::ZeroDimension { axis: "height" }));
    assert_eq!(
        Torus::new(MAX_DIM + 1, 1),
        Err(TopologyError::TooLarge { axis: "width", value: MAX_DIM + 1 })
    );
    assert_eq!(
        Torus::new(1, MAX_DIM + 1),
        Err(TopologyError::TooLarge { axis: "height", value: MAX_DIM + 1 })
    );
    assert!(Torus::new(MAX_DIM, MAX_DIM).is_ok());
    assert!(Torus::new(0, 5).unwrap_err().to_string().contains("width"));
    let w = t(10, 4);
    assert_eq!((w.width(), w.height(), w.cell_count()), (10, 4, 40));
}

// ---------------------------------------------------------------- AC1 wrap
#[test]
fn negative_coordinates_wrap() {
    let w = t(10, 6);
    assert_eq!(w.wrap(-1, -1), c(9, 5));
    assert_eq!(w.wrap(-10, -6), c(0, 0));
    assert_eq!(w.wrap(-11, -7), c(9, 5));
    assert_eq!(w.wrap(-3, 2), c(7, 2));
    assert_eq!(w.wrap(i64::MIN, i64::MIN), c(wrap_coord(i64::MIN, 10), wrap_coord(i64::MIN, 6)));
    assert!(w.contains(w.wrap(i64::MIN, i64::MAX)));
    assert_eq!(wrap_coord(i64::MIN, 10), 2); // -9223372036854775808 ≡ 2 (mod 10)
    assert_eq!(wrap_coord(i64::MAX, 10), 7);
    assert_eq!(w.wrap(i32::MIN as i64, i32::MAX as i64), c(2, 1)); // -2147483648 ≡ 2 mod 10; 2147483647 ≡ 1 mod 6
}

#[test]
fn multi_wrap_coordinates_several_widths_away() {
    let w = t(10, 6);
    assert_eq!(w.wrap(10, 6), c(0, 0));
    for k in 1..=5i64 {
        assert_eq!(w.wrap(-k * 10 + 3, k * 6 + 2), c(3, 2), "k={k}");
        assert_eq!(w.wrap(k * 10 + 3, -k * 6 + 2), c(3, 2), "k={k}");
        assert_eq!(w.wrap(1_000_000 * k * 10 + 9, -1_000_000 * k * 6 - 1), c(9, 5));
    }
    // translate by ±k·W / ±k·H returns the same cell
    let start = c(4, 1);
    for k in -5..=5i32 {
        assert_eq!(w.translate(start, Offset::new(k * 10, k * 6)), start);
    }
}

#[test]
fn multi_wrap_property_congruent_and_in_range() {
    let mut rng = Mix(0xC0FFEE);
    let worlds = [t(1, 1), t(1, 5), t(5, 1), t(7, 3), t(10, 4), t(4096, 4096), t(MAX_DIM, 1)];
    for w in worlds {
        for _ in 0..10_000 {
            let x = rng.next() as i64;
            let y = (rng.next() as i64) >> (rng.next() % 64);
            let cell = w.wrap(x, y);
            assert!(w.contains(cell));
            assert_eq!((x - cell.x as i64).rem_euclid(w.width() as i64), 0);
            assert_eq!((y - cell.y as i64).rem_euclid(w.height() as i64), 0);
        }
    }
}

#[test]
fn index_round_trip() {
    for w in worlds_small() {
        let all: Vec<Cell> = w.cells().collect();
        assert_eq!(all.len(), w.cell_count());
        for (i, cell) in all.iter().enumerate() {
            assert_eq!(w.index(*cell), i);
            assert_eq!(w.cell_at(i), *cell);
        }
        // row-major ordering of Cell matches index order
        let mut sorted = all.clone();
        sorted.sort();
        assert_eq!(sorted, all);
    }
}

// ------------------------------------------------- AC2 distance / direction
#[test]
fn edge_left_right_seam() {
    let w = t(10, 6);
    for y in 0..6 {
        let left = c(0, y);
        let right = c(9, y);
        assert_eq!(w.distance(left, right), 1);
        assert_eq!(w.offset(left, right), Offset::new(-1, 0));
        assert_eq!(w.direction(left, right), Some(Dir8::W));
        assert_eq!(w.offset(right, left), Offset::new(1, 0));
        assert_eq!(w.direction(right, left), Some(Dir8::E));
        assert_eq!(w.step(left, Dir8::W), right);
        assert_eq!(w.step(right, Dir8::E), left);
    }
}

#[test]
fn edge_top_bottom_seam() {
    let w = t(10, 6);
    for x in 0..10 {
        let top = c(x, 0);
        let bottom = c(x, 5);
        assert_eq!(w.distance(top, bottom), 1);
        assert_eq!(w.offset(top, bottom), Offset::new(0, -1));
        assert_eq!(w.direction(top, bottom), Some(Dir8::N));
        assert_eq!(w.offset(bottom, top), Offset::new(0, 1));
        assert_eq!(w.direction(bottom, top), Some(Dir8::S));
        assert_eq!(w.step(top, Dir8::N), bottom);
        assert_eq!(w.step(bottom, Dir8::S), top);
    }
}

#[test]
fn edge_near_seam_shorter_way_across_both_axes() {
    let w = t(20, 12);
    // x: 1 -> 18 is 3 west across the seam (not 17 east); y: 10 -> 1 is 3 south across
    let a = c(1, 10);
    let b = c(18, 1);
    assert_eq!(w.offset(a, b), Offset::new(-3, 3));
    assert_eq!(w.distance(a, b), 3);
    assert_eq!(w.direction(a, b), Some(Dir8::SW));
    assert_eq!(w.offset(b, a), Offset::new(3, -3));
    assert_eq!(w.direction(b, a), Some(Dir8::NE));
}

#[test]
fn edge_interior_pair_does_not_wrap() {
    let w = t(10, 10);
    assert_eq!(w.offset(c(2, 2), c(5, 2)), Offset::new(3, 0));
    assert_eq!(w.offset(c(5, 6), c(2, 2)), Offset::new(-3, -4));
    assert_eq!(w.distance(c(5, 6), c(2, 2)), 4);
    assert_eq!(w.direction(c(5, 6), c(2, 2)), Some(Dir8::NW));
}

#[test]
fn corner_all_four_corners_are_mutual_neighbours() {
    for w in [t(10, 6), t(3, 3), t(7, 4)] {
        let (mx, my) = (w.width() - 1, w.height() - 1);
        let corners = [c(0, 0), c(mx, 0), c(0, my), c(mx, my)];
        for a in corners {
            for b in corners {
                let d = w.distance(a, b);
                assert_eq!(d, if a == b { 0 } else { 1 }, "{a:?}->{b:?} in {w:?}");
                assert_eq!(w.translate(a, w.offset(a, b)), b);
            }
        }
        assert_eq!(w.offset(c(0, 0), c(mx, my)), Offset::new(-1, -1));
        assert_eq!(w.direction(c(0, 0), c(mx, my)), Some(Dir8::NW));
        assert_eq!(w.direction(c(mx, my), c(0, 0)), Some(Dir8::SE));
        assert_eq!(w.direction(c(mx, 0), c(0, my)), Some(Dir8::NE));
        assert_eq!(w.direction(c(0, my), c(mx, 0)), Some(Dir8::SW));
        assert_eq!(w.step(c(0, 0), Dir8::NW), c(mx, my));
        assert_eq!(w.step(c(mx, my), Dir8::SE), c(0, 0));
    }
}

#[test]
fn edge_tie_rule_even_dimension_returns_positive_offset() {
    let w = t(10, 4);
    // exactly half way: both directions return +5 (east), documented tie rule
    assert_eq!(w.offset(c(0, 0), c(5, 0)), Offset::new(5, 0));
    assert_eq!(w.offset(c(5, 0), c(0, 0)), Offset::new(5, 0));
    assert_eq!(w.offset(c(0, 0), c(0, 2)), Offset::new(0, 2));
    assert_eq!(w.offset(c(0, 2), c(0, 0)), Offset::new(0, 2));
    assert_eq!(w.distance(c(0, 0), c(5, 2)), 5);
    assert_eq!(w.max_distance(), 5);
    // odd dimension: no tie
    let o = t(9, 9);
    assert_eq!(o.offset(c(0, 0), c(4, 5)), Offset::new(4, -4));
    assert_eq!(o.max_distance(), 4);
}

#[test]
fn non_square_axes_are_independent() {
    let w = t(10, 4);
    assert_eq!(w.offset(c(0, 0), c(7, 3)), Offset::new(-3, -1));
    assert_eq!(w.distance(c(0, 0), c(7, 3)), 3);
    assert_eq!(w.offset(c(1, 1), c(4, 3)), Offset::new(3, 2));
    let tall = t(3, 50);
    assert_eq!(w.max_distance(), 5);
    assert_eq!(tall.max_distance(), 25);
    assert_eq!(tall.distance(c(0, 0), c(2, 49)), 1);
    assert_eq!(tall.distance(c(0, 0), c(1, 25)), 25);
}

#[test]
fn distance_exhaustive_shortest_and_consistent() {
    for w in worlds_small() {
        let (wd, ht) = (w.width() as i64, w.height() as i64);
        for a in w.cells() {
            for b in w.cells() {
                let o = w.offset(a, b);
                // offset lands on b and is in canonical range
                assert_eq!(w.translate(a, o), b);
                assert!(o.dx >= -((wd - 1) / 2) as i32 && o.dx <= (wd / 2) as i32);
                assert!(o.dy >= -((ht - 1) / 2) as i32 && o.dy <= (ht / 2) as i32);
                // shortest: no representative of b - a is shorter per axis
                let best = |d: i64, n: i64| {
                    (-2..=2).map(|k| (d + k * n).abs()).min().unwrap() as u32
                };
                let bx = best(b.x as i64 - a.x as i64, wd);
                let by = best(b.y as i64 - a.y as i64, ht);
                assert_eq!(o.dx.unsigned_abs(), bx);
                assert_eq!(o.dy.unsigned_abs(), by);
                assert_eq!(w.distance(a, b), bx.max(by));
                assert_eq!(w.distance(a, b), w.distance(b, a));
                assert!(w.distance(a, b) <= w.max_distance());
                assert_eq!(w.direction(a, b), Dir8::from_offset(o));
                assert_eq!(w.direction(a, b).is_none(), a == b);
                // first step along direction does not increase distance... it decreases by 1
                if let Some(d) = w.direction(a, b) {
                    assert_eq!(w.distance(w.step(a, d), b) + 1, w.distance(a, b));
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Dir8
#[test]
fn dir8_offsets_round_trip() {
    let mut seen = BTreeSet::new();
    for d in Dir8::ALL {
        let o = d.offset();
        assert_eq!(o.chebyshev(), 1);
        assert_eq!(Dir8::from_offset(o), Some(d));
        assert_eq!(Dir8::from_offset(Offset::new(o.dx * 7, o.dy * 7)), Some(d));
        assert_eq!(d.opposite().offset(), Offset::new(-o.dx, -o.dy));
        assert!(seen.insert((o.dx, o.dy)));
        let w = t(5, 5);
        for cell in w.cells() {
            assert_eq!(w.step(w.step(cell, d), d.opposite()), cell);
        }
    }
    assert_eq!(Dir8::N.offset(), Offset::new(0, -1)); // y grows south
    assert_eq!(Dir8::from_offset(Offset::ZERO), None);
    assert_eq!(Dir8::from_offset(Offset::new(3, -1)), Some(Dir8::NE));
    assert!(Offset::ZERO.is_zero());
    assert_eq!(Offset::new(-3, 5).chebyshev(), 5);
    assert_eq!(Offset::new(i32::MIN, 0).chebyshev(), 1u32 << 31);
}

// ---------------------------------------------------------------- AC3 within
#[test]
fn within_exhaustive_oracle_no_duplicates() {
    for w in worlds_small() {
        for center in w.cells() {
            for r in 0..=10u32 {
                let items: Vec<(Cell, Offset)> = w.within(center, r).collect();
                let it = w.within(center, r);
                assert_eq!(it.len(), items.len());
                assert_eq!(items.len(), w.count_within(r));
                let set: BTreeSet<Cell> = items.iter().map(|(c, _)| *c).collect();
                assert_eq!(set.len(), items.len(), "duplicates in {w:?} r={r}");
                let oracle: BTreeSet<Cell> =
                    w.cells().filter(|c| w.distance(center, *c) <= r).collect();
                assert_eq!(set, oracle, "{w:?} center={center:?} r={r}");
                for (cell, o) in &items {
                    assert_eq!(*o, w.offset(center, *cell));
                    assert_eq!(o.chebyshev(), w.distance(center, *cell));
                }
                assert_eq!(w.cells_within(center, r), items.iter().map(|(c, _)| *c).collect::<Vec<_>>());
                // rings partition within
                let mut union = BTreeSet::new();
                let mut total = 0;
                for d in 0..=r {
                    for (cell, o) in w.ring(center, d) {
                        assert_eq!(o.chebyshev(), d);
                        assert!(union.insert(cell));
                        total += 1;
                    }
                }
                assert_eq!(total, items.len());
                assert_eq!(union, set);
            }
        }
    }
}

#[test]
fn within_radius_larger_than_world_lists_each_cell_once() {
    for w in [t(10, 6), t(1, 1), t(1, 9), t(8, 1), t(2, 2), t(64, 3)] {
        for r in [w.max_distance(), w.max_distance() + 1, 100, 1_000_000, u32::MAX] {
            let center = w.wrap(3, 2);
            let cells = w.cells_within(center, r);
            let set: BTreeSet<Cell> = cells.iter().copied().collect();
            assert_eq!(cells.len(), w.cell_count(), "{w:?} r={r}");
            assert_eq!(set.len(), w.cell_count());
            assert_eq!(w.count_within(r), w.cell_count());
        }
    }
}

#[test]
fn within_deterministic_order_and_size() {
    let w = t(10, 10);
    let got: Vec<Offset> = w.within(c(0, 0), 1).map(|(_, o)| o).collect();
    let want = [
        (-1, -1), (0, -1), (1, -1),
        (-1, 0), (0, 0), (1, 0),
        (-1, 1), (0, 1), (1, 1),
    ];
    assert_eq!(got, want.iter().map(|&(dx, dy)| Offset::new(dx, dy)).collect::<Vec<_>>());
    assert_eq!(w.count_within(0), 1);
    assert_eq!(w.count_within(2), 25);
    assert_eq!(w.count_within(4), 81);
    assert_eq!(w.count_within(5), 100);
    let big = t(4096, 4096);
    assert_eq!(big.count_within(3), 49);
    assert_eq!(big.ring(c(0, 0), 3).count(), 49 - 25);
    assert_eq!(big.within(c(4095, 4095), 1).len(), 9);
}

#[test]
fn edge_within_across_seam() {
    let w = t(10, 6);
    let cells: BTreeSet<Cell> = w.cells_within(c(0, 0), 1).into_iter().collect();
    let want: BTreeSet<Cell> = [
        c(9, 5), c(0, 5), c(1, 5),
        c(9, 0), c(0, 0), c(1, 0),
        c(9, 1), c(0, 1), c(1, 1),
    ]
    .into_iter()
    .collect();
    assert_eq!(cells, want);
}

#[test]
fn neighbours8_distinct_cells() {
    let w = t(10, 6);
    let n = w.neighbours8(c(0, 0));
    assert_eq!(n.len(), 8);
    for (cell, d) in &n {
        assert_eq!(w.step(c(0, 0), *d), *cell);
    }
    let dirs: BTreeSet<Dir8> = n.iter().map(|(_, d)| *d).collect();
    assert_eq!(dirs.len(), 8);
    // 2×2: only 3 other cells exist, each listed once
    let two = t(2, 2);
    let n2 = two.neighbours8(c(0, 0));
    let s2: BTreeSet<Cell> = n2.iter().map(|(c, _)| *c).collect();
    assert_eq!(n2.len(), 3);
    assert_eq!(s2, [c(1, 0), c(0, 1), c(1, 1)].into_iter().collect());
}

// ---------------------------------------------------------------- AC4 small
#[test]
fn world_1x1_everything_maps_to_single_cell() {
    let w = t(1, 1);
    let only = c(0, 0);
    for (x, y) in [(0, 0), (-1, -1), (5, -7), (i64::MIN, i64::MAX), (123_456_789, 1)] {
        assert_eq!(w.wrap(x, y), only);
    }
    assert_eq!(w.distance(only, only), 0);
    assert_eq!(w.offset(only, only), Offset::ZERO);
    assert_eq!(w.direction(only, only), None);
    assert_eq!(w.max_distance(), 0);
    for d in Dir8::ALL {
        assert_eq!(w.step(only, d), only);
    }
    for r in [0, 1, 2, 1000, u32::MAX] {
        assert_eq!(w.cells_within(only, r), vec![only]);
        assert_eq!(w.count_within(r), 1);
        assert_eq!(w.ring(only, r).count(), usize::from(r == 0));
    }
    assert!(w.neighbours8(only).is_empty());
    assert_eq!(w.cell_count(), 1);
    assert_eq!(w.index(only), 0);
}

#[test]
fn small_1xn_and_nx1_worlds() {
    let col = t(1, 7);
    for (x, y) in [(-5, 3), (9, 10), (0, -1)] {
        let cell = col.wrap(x, y);
        assert_eq!(cell.x, 0);
        assert!(cell.y < 7);
    }
    assert_eq!(col.wrap(-5, -1), c(0, 6));
    assert_eq!(col.distance(c(0, 0), c(0, 6)), 1);
    assert_eq!(col.distance(c(0, 1), c(0, 4)), 3);
    assert_eq!(col.direction(c(0, 0), c(0, 6)), Some(Dir8::N));
    assert_eq!(col.step(c(0, 3), Dir8::E), c(0, 3)); // x moves are no-ops
    assert_eq!(col.step(c(0, 3), Dir8::NE), c(0, 2));
    let n = col.neighbours8(c(0, 0));
    let set: BTreeSet<Cell> = n.iter().map(|(c, _)| *c).collect();
    assert_eq!(set, [c(0, 6), c(0, 1)].into_iter().collect());
    assert_eq!(n.len(), 2);
    assert_eq!(col.cells_within(c(0, 3), 2).len(), 5);
    assert_eq!(col.cells_within(c(0, 3), 3).len(), 7);
    assert_eq!(col.cells_within(c(0, 3), 99).len(), 7);

    let row = t(7, 1);
    assert_eq!(row.wrap(-1, 42), c(6, 0));
    assert_eq!(row.distance(c(0, 0), c(6, 0)), 1);
    assert_eq!(row.direction(c(6, 0), c(0, 0)), Some(Dir8::E));
    assert_eq!(row.step(c(2, 0), Dir8::S), c(2, 0));
    assert_eq!(row.neighbours8(c(0, 0)).len(), 2);

    let two = t(1, 2);
    assert_eq!(two.distance(c(0, 0), c(0, 1)), 1);
    assert_eq!(two.neighbours8(c(0, 0)).len(), 1);
    assert_eq!(two.cells_within(c(0, 1), u32::MAX).len(), 2);
}

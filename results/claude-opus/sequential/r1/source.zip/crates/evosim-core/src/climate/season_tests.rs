//! TASK-007 tests: seasons, weather, bounds, query, state (ADR-010).

use super::season::*;
use super::*;
use crate::config::{preset, preset_names, Config};
use crate::sim::{SimError, Simulation};
use crate::topology::Cell;

fn cfg(seed: u64, w: u32, h: u32, weather: bool, year: u32) -> Config {
    let mut c = Config::new(seed, w, h, 0, 0, 0);
    c.climate.weather_enabled = weather;
    c.climate.year_length = year;
    c
}

fn bits(g: &[CellNow]) -> Vec<(u64, u64)> {
    g.iter().map(|c| (c.temperature.to_bits(), c.precipitation.to_bits())).collect()
}

fn grid_of(sim: &Simulation) -> Vec<(u64, u64)> {
    bits(sim.world().current_grid())
}

// ---------- seasons ----------

#[test]
fn season_period_is_year_length() {
    for y in [1u32, 2, 7, 400, 1000] {
        let mut c = cfg(5, 32, 24, false, y);
        c.climate.year_length = y;
        let m = ClimateMap::from_config(&c).unwrap();
        for t in [0u64, 1, 3, 99, 401, 12345] {
            for cell in [Cell { x: 0, y: 0 }, Cell { x: 7, y: 11 }, Cell { x: 31, y: 23 }] {
                let a = m.seasonal(cell, t);
                let b = m.seasonal(cell, t + y as u64);
                assert_eq!(a.temperature.to_bits(), b.temperature.to_bits());
                assert_eq!(a.precipitation.to_bits(), b.precipitation.to_bits());
            }
        }
    }
}

#[test]
fn year_phase_shape() {
    assert_eq!(year_phase(0, 400), 0.0);
    assert!((year_phase(100, 400) - 1.0).abs() < 1e-12);
    assert!((year_phase(300, 400) + 1.0).abs() < 1e-12);
    assert_eq!(year_phase(5, 1), 0.0);
    assert_eq!(year_phase(5, 0), 0.0);
    assert_eq!(year_phase(400 * 7 + 100, 400).to_bits(), year_phase(100, 400).to_bits());
}

#[test]
fn every_cell_has_seasonal_cycle() {
    let c = cfg(42, 64, 48, false, 400);
    let m = ClimateMap::from_config(&c).unwrap();
    let torus = crate::topology::Torus::new(64, 48).unwrap();
    for cell in torus.cells() {
        let su = m.seasonal(cell, 100);
        let wi = m.seasonal(cell, 300);
        let eq = m.seasonal(cell, 0);
        assert!(su.temperature > eq.temperature && eq.temperature > wi.temperature, "{cell:?}");
        if m.get(cell).precipitation > 0.0 && su.precipitation < c.climate.max_precipitation {
            assert!(su.precipitation > wi.precipitation, "{cell:?}");
        } else {
            assert!(su.precipitation >= wi.precipitation, "{cell:?}");
        }
    }
}

#[test]
fn seasonal_amplitude_grows_with_latitude() {
    let c = cfg(42, 64, 48, false, 400);
    let m = ClimateMap::from_config(&c).unwrap();
    let swing = |y: u32| {
        let cell = Cell { x: 10, y };
        m.seasonal(cell, 100).temperature - m.seasonal(cell, 300).temperature
    };
    let pole = swing(0);
    let eq = swing(24);
    assert!(pole > 4.0 * eq, "pole {pole} eq {eq}");
    let lat = m.get(Cell { x: 10, y: 0 }).latitude;
    assert!((pole - 2.0 * 8.0 * temperature_weight(lat)).abs() < 1e-9);
    assert!((temperature_weight(0.0) - 0.1).abs() < 1e-12);
    assert!((temperature_weight(90.0) - 1.0).abs() < 1e-12);
    assert!(precipitation_weight(20.0) > precipitation_weight(0.0));
    assert!(precipitation_weight(20.0) > precipitation_weight(70.0));
}

#[test]
fn year_length_from_config() {
    let a = ClimateMap::from_config(&cfg(1, 16, 16, false, 10)).unwrap();
    let b = ClimateMap::from_config(&cfg(1, 16, 16, false, 20)).unwrap();
    let cell = Cell { x: 3, y: 1 };
    assert_ne!(a.seasonal(cell, 5), b.seasonal(cell, 5)); // winter-ish equinox vs midsummer
    assert_eq!(a.seasonal(cell, 5), b.seasonal(cell, 10).clone());
    let mut j = Config::new(1, 8, 8, 0, 0, 0).to_json_value();
    j["climate"]["year_length"] = 13.into();
    assert_eq!(Config::from_value(&j).unwrap().climate.year_length, 13);
}

// ---------- weather off: year repeats exactly ----------

#[test]
fn weather_off_year_repeats_exactly() {
    for y in [1u32, 13, 400] {
        let c = cfg(9, 40, 30, false, y);
        let mut sim = Simulation::new(c.clone()).unwrap();
        let rng0 = sim.rng_state();
        let m = ClimateMap::from_config(&c).unwrap();
        let mut grids = Vec::new();
        for t in 0..(3 * y as u64) {
            sim.step();
            assert_eq!(sim.world().climate_tick(), t);
            grids.push(grid_of(&sim));
        }
        let y = y as usize;
        for t in 0..2 * y {
            assert_eq!(grids[t], grids[t + y], "Y={y} t={t}");
        }
        assert_eq!(sim.rng_state(), rng0, "weather off must not draw");
        // and equals the pure seasonal function
        let cell = Cell { x: 5, y: 7 };
        assert_eq!(sim.climate_now(cell), m.seasonal(cell, sim.tick() - 1));
    }
}

// ---------- weather: seeded from the core RNG ----------

#[test]
fn weather_same_seed_identical() {
    let mut a = Simulation::new(cfg(42, 40, 30, true, 50)).unwrap();
    let mut b = Simulation::new(cfg(42, 40, 30, true, 50)).unwrap();
    for _ in 0..300 {
        a.step();
        b.step();
        assert_eq!(grid_of(&a), grid_of(&b));
        assert_eq!(a.rng_state(), b.rng_state());
    }
    assert_eq!(a.weather_state(), b.weather_state());
}

#[test]
fn weather_different_seed_differs() {
    // same base climate (noise off) so differences come from weather only
    let mut ca = cfg(1, 40, 30, true, 50);
    ca.climate.noise_temperature = 0.0;
    ca.climate.noise_precipitation = 0.0;
    let mut cb = ca.clone();
    cb.seed = 2;
    let mut a = Simulation::new(ca).unwrap();
    let mut b = Simulation::new(cb).unwrap();
    a.run(20);
    b.run(20);
    assert_eq!(a.world().climate().cells(), b.world().climate().cells());
    assert_ne!(grid_of(&a), grid_of(&b));
}

#[test]
fn weather_draws_from_core_rng() {
    let c = cfg(77, 64, 48, true, 400);
    let mut sim = Simulation::new(c.clone()).unwrap();
    let (gx, gy) = sim.world().weather().lattice();
    assert_eq!((gx, gy), (4, 3));
    sim.step();
    let mut r = crate::rng::Rng::seed_from_u64(77);
    for _ in 0..(4 * gx * gy) {
        r.next_u64(); // each normal = 2 next_f64 = 2 next_u64
    }
    assert_eq!(sim.rng_state(), r.state());
    // reproduce the T lattice with the same draws
    let mut r = crate::rng::Rng::seed_from_u64(77);
    let k = (1.0f64 - 0.81).sqrt() * 2.0;
    let expect: Vec<f64> =
        (0..gx * gy).map(|_| (k * r.normal(0.0, 1.0)).clamp(-6.0, 6.0)).collect();
    assert_eq!(sim.weather_state().temperature, expect);
}

#[test]
fn weather_actually_varies_and_persists() {
    let c = cfg(3, 64, 48, true, 400);
    let mut sim = Simulation::new(c.clone()).unwrap();
    let m = ClimateMap::from_config(&c).unwrap();
    let cell = Cell { x: 20, y: 20 };
    let mut an = Vec::new();
    for _ in 0..500 {
        sim.step();
        let t = sim.tick() - 1;
        an.push(sim.climate_now(cell).temperature - m.seasonal(cell, t).temperature);
    }
    assert!(an.iter().any(|a| a.abs() > 0.1));
    let mean = an.iter().sum::<f64>() / an.len() as f64;
    let var: f64 = an.iter().map(|a| (a - mean).powi(2)).sum::<f64>();
    let cov: f64 = an.windows(2).map(|w| (w[0] - mean) * (w[1] - mean)).sum::<f64>();
    assert!(cov / var > 0.5, "lag-1 autocorrelation {}", cov / var);
}

// ---------- bounds ----------

#[test]
fn bounds_formula_defaults() {
    let b = ClimateBounds::from_params(&ClimateParams::default());
    assert!((b.t_min - -40.5).abs() < 1e-12, "{b:?}");
    assert!((b.t_max - 43.5).abs() < 1e-12, "{b:?}");
    assert_eq!((b.p_min, b.p_max), (0.0, 1.0));
}

#[test]
fn combine_clamps() {
    let p = ClimateParams::default();
    let b = ClimateBounds::from_params(&p);
    let base = CellClimate { latitude: 90.0, temperature: 1e6, precipitation: 0.9, biome: Biome::Polar };
    let n = combine(&p, &b, &base, 1.0, 1e6, 1e6);
    assert_eq!((n.temperature, n.precipitation), (b.t_max, 1.0));
    let base = CellClimate { temperature: -1e6, ..base };
    let n = combine(&p, &b, &base, -1.0, -1e6, -1e6);
    assert_eq!((n.temperature, n.precipitation), (b.t_min, 0.0));
}

fn check_bounds(c: Config, ticks: u64) {
    let mut sim = Simulation::new(c).unwrap();
    let b = sim.world().climate_bounds();
    assert!(sim.world().current_grid().iter().all(|v| b.contains(*v)));
    for _ in 0..ticks {
        sim.step();
        for v in sim.world().current_grid() {
            assert!(b.contains(*v), "{v:?} outside {b:?} at tick {}", sim.tick() - 1);
        }
    }
}

#[test]
fn values_stay_within_bounds() {
    for name in preset_names() {
        let mut c = preset(name).unwrap();
        c.world.width = c.world.width.min(64);
        c.world.height = c.world.height.min(48);
        check_bounds(c, if name == "harsh" { 5000 } else { 2000 });
    }
    for (w, h) in [(1, 1), (3, 1), (64, 48)] {
        for rho in [0.0, 0.999] {
            let mut c = cfg(11, w, h, true, 37);
            c.climate.seasonal_amplitude = 40.0;
            c.climate.weather_temperature_sd = 20.0;
            c.climate.weather_precipitation_sd = 2.0;
            c.climate.weather_persistence = rho;
            c.climate.noise_temperature = 20.0;
            c.climate.noise_precipitation = 1.0;
            c.climate.precipitation_seasonality = 1.0;
            c.climate.weather_scale = 1;
            check_bounds(c, 1500);
        }
    }
}

// ---------- query ----------

#[test]
fn query_current_matches_formula() {
    let c = cfg(21, 40, 30, true, 30);
    let mut sim = Simulation::new(c.clone()).unwrap();
    let m = ClimateMap::from_config(&c).unwrap();
    let cell = Cell { x: 13, y: 29 };
    assert_eq!(sim.world().climate_tick(), 0);
    assert_eq!(sim.climate_now(cell), m.seasonal(cell, 0));
    for t in 0..100u64 {
        sim.step();
        assert_eq!(sim.world().climate_tick(), t);
        let (at, ap) = sim.world().weather().anomaly(cell.x as f64, cell.y as f64);
        let want = combine(&c.climate, &m.bounds(), m.get(cell), year_phase(t, 30), at, ap);
        assert_eq!(sim.climate_now(cell), want);
        assert_eq!(sim.world().current(cell), want);
    }
}

#[test]
fn seasonal_query_any_tick() {
    let m = ClimateMap::from_config(&cfg(1, 8, 8, false, 400)).unwrap();
    let b = m.bounds();
    for t in [0u64, 100, 1_000_000_007, u64::MAX - 1, u64::MAX] {
        assert!(b.contains(m.seasonal(Cell { x: 1, y: 2 }, t)));
    }
}

// ---------- state ----------

#[test]
fn resume_with_weather_state_continues_identically() {
    let c = cfg(42, 40, 30, true, 50);
    let mut a = Simulation::new(c.clone()).unwrap();
    a.run(137);
    let mut b = Simulation::resume(c.clone(), a.tick(), a.rng_state(), a.next_entity_id()).unwrap();
    b.set_weather_state(a.weather_state()).unwrap();
    assert_eq!(grid_of(&a), grid_of(&b));
    assert_eq!(b.world().climate_tick(), 136);
    for _ in 0..200 {
        a.step();
        b.step();
        assert_eq!(grid_of(&a), grid_of(&b));
        assert_eq!(a.rng_state(), b.rng_state());
    }
}

#[test]
fn resume_without_weather_state_differs() {
    let c = cfg(42, 40, 30, true, 50);
    let mut a = Simulation::new(c.clone()).unwrap();
    a.run(137);
    let mut b = Simulation::resume(c, a.tick(), a.rng_state(), a.next_entity_id()).unwrap();
    a.step();
    b.step();
    assert_eq!(a.rng_state(), b.rng_state());
    assert_ne!(grid_of(&a), grid_of(&b));
}

#[test]
fn set_weather_state_rejects_bad() {
    let mut sim = Simulation::new(cfg(1, 64, 48, true, 50)).unwrap();
    sim.run(3);
    let good = sim.weather_state();
    let mut s = good.clone();
    s.temperature.pop();
    assert!(matches!(sim.set_weather_state(s), Err(SimError::Weather(WeatherError::Length(..)))));
    let mut s = good.clone();
    s.precipitation[0] = f64::NAN;
    assert!(matches!(sim.set_weather_state(s), Err(SimError::Weather(WeatherError::NonFinite(_)))));
    assert_eq!(sim.weather_state(), good, "failed restore leaves state unchanged");
}

// ---------- seam continuity ----------

#[test]
fn seasonal_seam_continuous() {
    let (w, h) = (64u32, 48u32);
    let mut sim = Simulation::new(cfg(5, w, h, true, 40)).unwrap();
    for _ in 0..60 {
        sim.step();
        let g = sim.world().current_grid();
        let at = |x: u32, y: u32| g[(y * w + x) as usize];
        let d = |a: CellNow, b: CellNow| {
            ((a.temperature - b.temperature).abs(), (a.precipitation - b.precipitation).abs())
        };
        let (mut it, mut ip, mut st, mut sp) = (0.0f64, 0.0f64, 0.0f64, 0.0f64);
        for y in 0..h {
            for x in 0..w {
                let (dt, dp) = d(at(x, y), at((x + 1) % w, y));
                let (et, ep) = d(at(x, y), at(x, (y + 1) % h));
                let seam_x = x == w - 1;
                let seam_y = y == h - 1;
                if seam_x { st = st.max(dt); sp = sp.max(dp); } else { it = it.max(dt); ip = ip.max(dp); }
                if seam_y { st = st.max(et); sp = sp.max(ep); } else { it = it.max(et); ip = ip.max(ep); }
            }
        }
        assert!(st <= it + 1e-9, "seam T step {st} > interior {it}");
        assert!(sp <= ip + 1e-9, "seam P step {sp} > interior {ip}");
    }
    // weather field itself is periodic
    let wx = sim.world().weather();
    for (x, y) in [(0.0, 0.0), (3.3, 7.7), (63.9, 47.9)] {
        let a = wx.anomaly(x, y);
        let b = wx.anomaly(x + w as f64, y - h as f64);
        assert!((a.0 - b.0).abs() < 1e-9 && (a.1 - b.1).abs() < 1e-9);
    }
}

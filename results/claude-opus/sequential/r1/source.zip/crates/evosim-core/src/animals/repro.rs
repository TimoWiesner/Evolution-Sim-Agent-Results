//! Animal sexual reproduction (TASK-016, ADR-019).
//!
//! At the end of the Herbivores / Carnivores phase every *ready* animal
//! (mature, enough energy, cooldown 0, alive) in acting order tries to mate
//! once with the compatible ready partner within [`MATING_REACH`] that has the
//! most energy (ties by (distance, id)). Compatible = distinct, same kind,
//! genome distance ≤ `<kind>.mating_threshold`. Conception chance and litter
//! size depend on the mean fertility of the pair; both parents pay
//! `reproduction_cost`, the children share the paid pool, both parents start
//! a `mating_cooldown`. Birth is immediate (requested for this tick's Births
//! phase, `Parents::Two(a, b)`; `resolve_births` sets the generation).

use crate::config::Config;
use crate::genome::{child_sexual, distance, MutationParams};
use crate::ids::EntityId;
use crate::organism::{BirthRequest, Kind, Organism, Parents, Population};
use crate::rng::Rng;
use crate::spatial::Neighbour;
use crate::topology::Cell;

/// Maximum Chebyshev distance (across the wrap) between mating partners.
pub const MATING_REACH: u32 = 1;

/// Reproduction parameters of one animal kind.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ReproParams {
    pub maturity_age: u32,
    pub threshold: f64,
    pub cost: f64,
    pub mating_threshold: f64,
    pub cooldown: u32,
    pub conception_chance: f64,
    pub max_litter: u32,
    pub mutation: MutationParams,
}

impl ReproParams {
    /// Parameters of `kind`; for plants all-zero values that make nothing ready.
    pub fn for_kind(kind: Kind, cfg: &Config) -> ReproParams {
        let mutation = MutationParams::for_kind(kind, cfg);
        match kind {
            Kind::Herbivore => {
                let h = &cfg.herbivores;
                ReproParams {
                    maturity_age: h.maturity_age,
                    threshold: h.reproduction_threshold,
                    cost: h.reproduction_cost,
                    mating_threshold: h.mating_threshold,
                    cooldown: h.mating_cooldown,
                    conception_chance: h.conception_chance,
                    max_litter: h.max_litter,
                    mutation,
                }
            }
            Kind::Carnivore => {
                let c = &cfg.carnivores;
                ReproParams {
                    maturity_age: c.maturity_age,
                    threshold: c.reproduction_threshold,
                    cost: c.reproduction_cost,
                    mating_threshold: c.mating_threshold,
                    cooldown: c.mating_cooldown,
                    conception_chance: c.conception_chance,
                    max_litter: c.max_litter,
                    mutation,
                }
            }
            Kind::Plant => ReproParams {
                maturity_age: u32::MAX,
                threshold: f64::INFINITY,
                cost: 0.0,
                mating_threshold: 0.0,
                cooldown: 0,
                conception_chance: 0.0,
                max_litter: 1,
                mutation,
            },
        }
    }
}

/// Ready to mate: living animal, mature, cooldown 0, health > 0,
/// `energy ≥ threshold` and `energy > cost`.
pub fn is_ready(o: &Organism, rp: &ReproParams) -> bool {
    o.is_alive()
        && o.kind() != Kind::Plant
        && o.age() >= rp.maturity_age
        && o.cooldown() == 0
        && o.health() > 0.0
        && o.energy() >= rp.threshold
        && o.energy() > rp.cost
}

/// Compatible partners: distinct IDs, same kind, genome distance ≤ `mating_threshold`.
pub fn compatible(a: &Organism, b: &Organism, rp: &ReproParams) -> bool {
    a.id() != b.id() && a.kind() == b.kind() && distance(a.genome(), b.genome()) <= rp.mating_threshold
}

/// Conception chance of a pair with mean fertility `f`:
/// `clamp(conception_chance · (0.5 + f), 0, 1)`.
pub fn conception_probability(f: f64, rp: &ReproParams) -> f64 {
    let v = rp.conception_chance * (0.5 + f);
    if v.is_finite() {
        v.clamp(0.0, 1.0)
    } else {
        0.0
    }
}

/// Energy condition of a pair in `[0, 1]`:
/// `(min(E) − threshold) / (min(maxE) − threshold)`, 0 if the denominator ≤ 0.
pub fn litter_condition(a: &Organism, b: &Organism, rp: &ReproParams) -> f64 {
    let e = a.energy().min(b.energy());
    let m = a.traits().max_energy.min(b.traits().max_energy);
    let den = m - rp.threshold;
    if den.is_nan() || den <= 0.0 {
        return 0.0;
    }
    let v = (e - rp.threshold) / den;
    if v.is_finite() {
        v.clamp(0.0, 1.0)
    } else {
        0.0
    }
}

/// Ready, compatible partner of `id` within [`MATING_REACH`] with the highest
/// energy (ties: first in (distance, id) order), not in `engaged`.
pub fn find_mate_in_reach(pop: &Population, id: EntityId, rp: &ReproParams, engaged: &[EntityId]) -> Option<EntityId> {
    let a = pop.get_alive(id)?;
    let mut best: Option<(EntityId, f64)> = None;
    for n in pop.within(a.pos(), MATING_REACH, Some(a.kind())) {
        if n.id == id || engaged.binary_search(&n.id).is_ok() {
            continue;
        }
        let Some(b) = pop.get_alive(n.id) else { continue };
        if !is_ready(b, rp) || !compatible(a, b, rp) {
            continue;
        }
        if best.is_none_or(|(_, e)| b.energy() > e) {
            best = Some((n.id, b.energy()));
        }
    }
    best.map(|(b, _)| b)
}

/// Nearest (distance, id) ready compatible partner of `id` within radius `r`
/// (used by the Court action).
pub fn visible_mate(pop: &Population, id: EntityId, r: u32, rp: &ReproParams) -> Option<Neighbour> {
    let a = pop.get_alive(id)?;
    pop.nearest(a.pos(), r, Some(a.kind()), |n| n.id != id && pop.get_alive_of(n.kind, n.id).is_some_and(|b| is_ready(b, rp) && compatible(a, b, rp)))
}

/// Ordered birth sites with free slots: cell of `a`, cell of `b`, then the
/// 8 neighbours of `a` (Dir8 order), de-duplicated. Free = capacity − living
/// − births already placed there by this pass (`placed`).
fn birth_sites(pop: &Population, a: Cell, b: Cell, kind: Kind, placed: &[(Cell, u32)]) -> Vec<(Cell, u32)> {
    let torus = *pop.index().torus();
    let mut cells = vec![a];
    if b != a {
        cells.push(b);
    }
    for (c, _) in torus.neighbours8(a) {
        if !cells.contains(&c) {
            cells.push(c);
        }
    }
    let cap = pop.capacity().of(kind) as u64;
    cells
        .into_iter()
        .filter_map(|c| {
            let used = pop.count_at(c, kind) as u64 + placed.iter().filter(|(p, _)| *p == c).map(|(_, n)| *n as u64).sum::<u64>();
            let free = cap.saturating_sub(used).min(u32::MAX as u64) as u32;
            (free > 0).then_some((c, free))
        })
        .collect()
}

/// Totals of one mating pass.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct AnimalReproTick {
    /// Ready animals at their initiator turn (not yet engaged).
    pub ready: u64,
    /// Pairs formed (attempts).
    pub attempts: u64,
    /// Attempts ended because no birth site had room.
    pub no_room: u64,
    /// Successful conceptions.
    pub conceived: u64,
    /// Birth requests issued.
    pub offspring: u64,
    /// Energy paid by parents.
    pub energy_spent: f64,
    /// Energy handed to offspring requests (≤ `energy_spent`).
    pub offspring_energy: f64,
}

impl AnimalReproTick {
    fn add(&mut self, o: &AnimalReproTick) {
        self.ready += o.ready;
        self.attempts += o.attempts;
        self.no_room += o.no_room;
        self.conceived += o.conceived;
        self.offspring += o.offspring;
        self.energy_spent += o.energy_spent;
        self.offspring_energy += o.offspring_energy;
    }
}

/// Cumulative reproduction audit of one animal kind.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct ReproLedger {
    pub total: AnimalReproTick,
    pub last: AnimalReproTick,
}

impl ReproLedger {
    pub fn record(&mut self, t: &AnimalReproTick) {
        self.total.add(t);
        self.last = *t;
    }
}

/// Mating pass for `kind` over the initiators `ids` (acting order). Draws
/// nothing for plants or when no pair forms.
pub fn reproduce_animals(pop: &mut Population, ids: &[EntityId], kind: Kind, cfg: &Config, rng: &mut Rng) -> AnimalReproTick {
    let mut out = AnimalReproTick::default();
    if kind == Kind::Plant {
        return out;
    }
    let rp = ReproParams::for_kind(kind, cfg);
    let mut engaged: Vec<EntityId> = Vec::new();
    let mut placed: Vec<(Cell, u32)> = Vec::new();
    for &a_id in ids {
        if engaged.binary_search(&a_id).is_ok() {
            continue;
        }
        let Some(a) = pop.get_alive(a_id) else { continue };
        if a.kind() != kind || !is_ready(a, &rp) {
            continue;
        }
        out.ready += 1;
        let Some(b_id) = find_mate_in_reach(pop, a_id, &rp, &engaged) else { continue };
        debug_assert_ne!(a_id, b_id, "an animal never mates with itself");
        for e in [a_id, b_id] {
            if let Err(i) = engaged.binary_search(&e) {
                engaged.insert(i, e);
            }
        }
        out.attempts += 1;
        let a = pop.get_alive(a_id).expect("alive");
        let b = pop.get_alive(b_id).expect("alive");
        let sites = birth_sites(pop, a.pos(), b.pos(), kind, &placed);
        let slots: u64 = sites.iter().map(|s| s.1 as u64).sum();
        if slots == 0 {
            out.no_room += 1;
            continue;
        }
        let f = (a.traits().fertility + b.traits().fertility) / 2.0;
        if !rng.chance(conception_probability(f, &rp)) {
            continue;
        }
        let p_extra = {
            let v = f * litter_condition(a, b, &rp);
            if v.is_finite() {
                v.clamp(0.0, 1.0)
            } else {
                0.0
            }
        };
        let mut n: u64 = 1;
        for _ in 1..rp.max_litter.max(1) {
            n += rng.chance(p_extra) as u64;
        }
        let n = n.min(slots);
        let (ga, gb) = (a.genome().clone(), b.genome().clone());
        let mut pool = 0.0;
        for id in [a_id, b_id] {
            let o = pop.get_alive_mut(id).expect("alive");
            pool += o.spend_energy(rp.cost);
            o.set_cooldown(rp.cooldown);
        }
        out.conceived += 1;
        out.energy_spent += pool;
        let each = pool / n as f64;
        let mut site_iter = sites.into_iter().flat_map(|(c, k)| std::iter::repeat_n(c, k as usize));
        for _ in 0..n {
            let pos = site_iter.next().expect("n ≤ slots");
            let genome = child_sexual(&ga, &gb, rp.mutation, rng).expect("same kind");
            match placed.iter_mut().find(|(c, _)| *c == pos) {
                Some(p) => p.1 += 1,
                None => placed.push((pos, 1)),
            }
            out.offspring += 1;
            out.offspring_energy += each;
            pop.request_birth(BirthRequest { pos, parents: Parents::Two(a_id, b_id), energy: each, health: None, genome });
        }
    }
    out
}

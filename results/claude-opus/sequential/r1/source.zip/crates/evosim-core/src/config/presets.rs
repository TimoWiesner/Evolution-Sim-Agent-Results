//! Built-in presets, selectable by name (ADR-006).

use super::error::{ConfigError, ConfigErrorKind};
use super::Config;

const PRESETS: &[(&str, &str)] = &[
    ("default", "Contract example: 64x48, 400 plants, 120 herbivores, 20 carnivores, default parameters"),
    ("lush", "Large, mild and wet world with fast-growing resources and bigger populations"),
    ("harsh", "Small world with cold poles, strong seasons, noisy weather and scarce resources"),
    ("plants-only", "Only plants (zero animals), higher plant mutation rate: plant evolution study"),
];

/// Names of all built-in presets.
pub fn preset_names() -> Vec<&'static str> {
    PRESETS.iter().map(|p| p.0).collect()
}

/// One-line description of a preset.
pub fn preset_description(name: &str) -> Option<&'static str> {
    PRESETS.iter().find(|p| p.0 == name).map(|p| p.1)
}

/// Build the preset `name`; unknown names give `UnknownPreset` (key `preset`).
pub fn preset(name: &str) -> Result<Config, ConfigError> {
    let mut c = Config::contract_example();
    c.name = name.to_string();
    c.description = preset_description(name).unwrap_or_default().to_string();
    match name {
        "default" => {}
        "lush" => {
            c.world.width = 96;
            c.world.height = 64;
            c.initial.plants = 900;
            c.initial.herbivores = 220;
            c.initial.carnivores = 30;
            c.plants.resource_regen = 1.0;
            c.plants.resource_cap = 16.0;
            c.climate.pole_temperature = -10.0;
            c.climate.seasonal_amplitude = 4.0;
            c.climate.max_precipitation = 1.5;
        }
        "harsh" => {
            c.world.width = 48;
            c.world.height = 36;
            c.initial.plants = 300;
            c.initial.herbivores = 80;
            c.initial.carnivores = 10;
            c.climate.pole_temperature = -40.0;
            c.climate.equator_temperature = 22.0;
            c.climate.seasonal_amplitude = 16.0;
            c.climate.weather_temperature_sd = 4.0;
            c.plants.resource_regen = 0.3;
        }
        "plants-only" => {
            c.initial.plants = 600;
            c.initial.herbivores = 0;
            c.initial.carnivores = 0;
            c.plants.mutation_rate = 0.1;
        }
        _ => {
            return Err(ConfigError::new(
                "preset",
                ConfigErrorKind::UnknownPreset {
                    name: name.to_string(),
                    available: preset_names().iter().map(|s| s.to_string()).collect(),
                },
            ))
        }
    }
    Ok(c)
}

//! TASK-018 ecology integration tests (ADR-021): tick order, fixed-keys
//! config, creation only by reproduction, final extinction, population
//! balance, extinction scenarios and default-parameter viability.

use super::*;
use crate::organism::Parents;
use std::collections::BTreeMap;

const FIXED_KEYS_ONLY: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

fn fixed(seed: u64, p: u32, h: u32, c: u32) -> Config {
    let mut cfg = Config::from_json_str(FIXED_KEYS_ONLY).unwrap();
    cfg.seed = seed;
    cfg.initial.plants = p;
    cfg.initial.herbivores = h;
    cfg.initial.carnivores = c;
    cfg
}

fn alive(sim: &Simulation) -> [u64; 3] {
    Kind::ALL.map(|k| sim.organisms().count_alive(k) as u64)
}

#[test]
fn tick_runs_all_phases_in_documented_order() {
    let mut sim = Simulation::new(fixed(3, 400, 120, 20)).unwrap();
    sim.run(5);
    let mut seen: Vec<(Phase, [u64; 3], usize, u64)> = Vec::new();
    let before_births = *sim.totals();
    let r = sim.step_with(|ctx| {
        let p = ctx.world.organisms();
        seen.push((ctx.phase, Kind::ALL.map(|k| p.stored_len(k) as u64), p.pending_births(), ctx.world.stats().tick));
    });
    assert_eq!(r.phases, Phase::ORDER.to_vec());
    let order: Vec<Phase> = seen.iter().map(|s| s.0).collect();
    assert_eq!(
        order,
        vec![Phase::Climate, Phase::Resources, Phase::Plants, Phase::Herbivores, Phase::Carnivores, Phase::Births, Phase::Deaths, Phase::Species, Phase::Statistics]
    );
    assert_eq!(sim.world().climate_tick(), 5, "climate updated for this tick");
    // birth requests accumulate during the acting phases and are all resolved in Births
    let idx = |ph: Phase| seen.iter().position(|s| s.0 == ph).unwrap();
    assert_eq!(seen[idx(Phase::Births)].2, 0, "Births resolves every request");
    assert!(seen[idx(Phase::Carnivores)].2 >= seen[idx(Phase::Plants)].2);
    // removals happen in Deaths only (alive counts unchanged before it except by births)
    let births_now = sim.totals();
    let born: u64 = (0..3).map(|i| births_now.births[i] - before_births.births[i]).sum();
    let at_births: u64 = seen[idx(Phase::Births)].1.iter().sum();
    let at_climate: u64 = seen[idx(Phase::Climate)].1.iter().sum();
    assert_eq!(at_births, at_climate + born, "nothing is removed before Deaths");
    let at_deaths: u64 = seen[idx(Phase::Deaths)].1.iter().sum();
    let died: u64 = (0..3).map(|i| births_now.deaths[i] - before_births.deaths[i]).sum();
    assert_eq!(at_deaths, at_births - died, "Deaths removes every flagged organism");
    // Statistics snapshot is taken last
    assert_eq!(seen[idx(Phase::Species)].3, 4);
    assert_eq!(seen[idx(Phase::Statistics)].3, 5);
    assert_eq!(sim.last_stats().alive, alive(&sim));
}

#[test]
fn fixed_keys_only_config_runs_1000_ticks() {
    for seed in [42, 1, 2] {
        let mut cfg = Config::from_json_str(FIXED_KEYS_ONLY).unwrap();
        cfg.seed = seed;
        cfg.validate_cross_fields().unwrap();
        let mut sim = Simulation::new(cfg).unwrap();
        for t in 0..1000 {
            sim.step();
            if t % 100 == 99 {
                sim.organisms().validate(sim.next_entity_id()).unwrap();
            }
        }
        assert_eq!(sim.tick(), 1000);
        assert!(sim.organisms().count_alive(Kind::Plant) > 0);
    }
}

#[test]
fn balance_holds_every_tick() {
    for seed in [42, 7] {
        let mut sim = Simulation::new(fixed(seed, 400, 120, 20)).unwrap();
        let mut sum_births = [0u64; 3];
        let mut sum_deaths = [0u64; 3];
        for _ in 0..1000 {
            sim.step();
            balance_ok(sim.totals(), sim.organisms()).unwrap();
            let s = *sim.last_stats();
            assert_eq!(s.alive, alive(&sim));
            for i in 0..3 {
                sum_births[i] += s.births_tick[i];
                sum_deaths[i] += s.deaths_tick[i];
                assert_eq!(sim.totals().initial[i] + s.births[i] - s.deaths[i], s.alive[i]);
            }
        }
        assert_eq!(sum_births, sim.totals().births);
        assert_eq!(sum_deaths, sim.totals().deaths);
        sim.organisms().validate(sim.next_entity_id()).unwrap();
    }
}

/// Every organism after tick 0 is a Birth event with parents of the right
/// kind; birth counters equal the number of Birth events.
#[test]
fn no_creation_outside_reproduction() {
    let mut sim = Simulation::new(fixed(5, 400, 120, 20)).unwrap();
    let mut kind_of: BTreeMap<u64, Kind> = BTreeMap::new();
    for k in Kind::ALL {
        for o in sim.organisms().alive(k) {
            assert_eq!(o.parents(), Parents::None);
            kind_of.insert(o.id().0, k);
        }
    }
    let mut events = [0u64; 3];
    for _ in 0..800 {
        let ids_before = sim.next_entity_id();
        let r = sim.step();
        for e in &r.events {
            if let EventKind::Birth { id, kind, parents, .. } = e.kind {
                events[kind.index()] += 1;
                assert!(id.0 >= ids_before);
                let ps = match parents {
                    Parents::None => panic!("birth without parents"),
                    Parents::One(a) => vec![a],
                    Parents::Two(a, b) => vec![a, b],
                };
                if kind != Kind::Plant {
                    assert_eq!(ps.len(), 2, "animals reproduce sexually");
                }
                for p in ps {
                    assert_eq!(kind_of.get(&p.0), Some(&kind), "parent of same kind");
                }
                kind_of.insert(id.0, kind);
            }
        }
        // every living organism is known (founder or born)
        for k in Kind::ALL {
            for o in sim.organisms().alive(k) {
                assert_eq!(kind_of.get(&o.id().0), Some(&k));
            }
        }
    }
    assert_eq!(events, sim.totals().births);
}

#[test]
fn extinct_kind_stays_extinct() {
    for seed in [1, 2, 3] {
        let mut sim = Simulation::new(fixed(seed, 400, 120, 20)).unwrap();
        let mut zero_at: [Option<u64>; 3] = [None; 3];
        let mut births_at_zero = [0u64; 3];
        for _ in 0..2000 {
            sim.step();
            let a = alive(&sim);
            for i in 0..3 {
                match zero_at[i] {
                    Some(_) => {
                        assert_eq!(a[i], 0, "kind {i} came back (seed {seed})");
                        assert_eq!(sim.totals().births[i], births_at_zero[i]);
                    }
                    None if a[i] == 0 => {
                        zero_at[i] = Some(sim.tick());
                        births_at_zero[i] = sim.totals().births[i];
                    }
                    None => {}
                }
            }
        }
    }
    // a kind absent from the start stays absent
    let mut sim = Simulation::new(fixed(9, 400, 60, 0)).unwrap();
    for _ in 0..600 {
        sim.step();
        assert_eq!(sim.organisms().count_alive(Kind::Carnivore), 0);
    }
    assert_eq!(sim.totals().births[Kind::Carnivore.index()], 0);
}

fn run_until_extinct(sim: &mut Simulation, kinds: &[Kind], max: u64) -> BTreeMap<Kind, u64> {
    let mut out = BTreeMap::new();
    while sim.tick() < max && out.len() < kinds.len() {
        sim.step();
        for &k in kinds {
            if !out.contains_key(&k) && sim.organisms().count_alive(k) == 0 {
                out.insert(k, sim.tick());
            }
        }
    }
    out
}

#[test]
fn no_plants_herbivores_then_carnivores_die_out() {
    for seed in [1, 2] {
        let mut sim = Simulation::new(fixed(seed, 0, 120, 20)).unwrap();
        let ex = run_until_extinct(&mut sim, &[Kind::Herbivore, Kind::Carnivore], 3000);
        let th = ex[&Kind::Herbivore];
        let tc = ex[&Kind::Carnivore];
        assert!(th <= tc, "herbivores ({th}) die out before carnivores ({tc})");
        assert_eq!(sim.totals().births[Kind::Plant.index()], 0);
    }
}

#[test]
fn no_herbivores_carnivores_die_out() {
    for seed in [1, 2] {
        let mut sim = Simulation::new(fixed(seed, 400, 0, 20)).unwrap();
        let ex = run_until_extinct(&mut sim, &[Kind::Carnivore], 3000);
        assert!(ex.contains_key(&Kind::Carnivore), "carnivores without prey die out");
        assert_eq!(sim.totals().births[Kind::Carnivore.index()], 0);
        assert!(sim.organisms().count_alive(Kind::Plant) > 0);
    }
}

#[test]
fn plants_alone_persist_and_reproduce() {
    for seed in [1, 2] {
        let mut sim = Simulation::new(fixed(seed, 400, 0, 0)).unwrap();
        for _ in 0..3000 {
            sim.step();
            assert!(sim.organisms().count_alive(Kind::Plant) > 0, "plants alive at tick {}", sim.tick());
        }
        assert!(sim.totals().births[Kind::Plant.index()] > 400, "plants reproduce on their own");
        let max_gen = sim.organisms().alive(Kind::Plant).map(|o| o.generation()).max().unwrap();
        assert!(max_gen >= 5, "many plant generations ({max_gen})");
    }
}

#[test]
fn default_herbivores_with_plenty_of_plants_survive_and_reproduce() {
    for seed in [1, 2, 3] {
        let mut sim = Simulation::new(fixed(seed, 1000, 120, 0)).unwrap();
        for _ in 0..600 {
            sim.step();
            assert!(sim.organisms().count_alive(Kind::Herbivore) > 0, "herbivores alive at {}", sim.tick());
        }
        let hb = sim.totals().births[Kind::Herbivore.index()];
        assert!(hb >= 60, "herbivores reproduce ({hb} births, seed {seed})");
        let max_gen = sim.organisms().alive(Kind::Herbivore).map(|o| o.generation()).max().unwrap();
        assert!(max_gen >= 2, "generation {max_gen}");
        assert!(sim.organisms().count_alive(Kind::Plant) > 0);
    }
}

//! Simulation state and tick scheduler (ADR-008).
//!
//! [`Simulation`] holds the configuration, the tick counter (clock), the one
//! core [`Rng`], the [`World`] and the [`IdAllocator`]. [`Simulation::step`]
//! advances it by exactly one tick, running the phases of [`Phase::ORDER`]
//! in that fixed order. External commands (UI edits, pause, reset) are
//! applied only between `step()` calls.

pub mod event;
pub mod schedule;
pub mod stats;
pub mod world;

#[cfg(test)]
mod tests;
#[cfg(test)]
mod tests_ecology;

use std::fmt;

use crate::climate::{CellNow, WeatherError, WeatherState};
use crate::config::Config;
use crate::ids::IdAllocator;
use crate::organism::{Kind, LifeTotals, Population};
use crate::rng::{Rng, RngError, RngState};
use crate::species::{SpeciesChange, SpeciesRegistry};
use crate::topology::{Cell, TopologyError};

pub use event::{Event, EventKind, TickReport};
pub use schedule::{acting_order, acting_order_into, cmp_key_then_id, Phase};
pub use stats::{balance_ok, TickStats};
pub use world::World;

/// Error constructing or restoring a simulation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SimError {
    World(TopologyError),
    Rng(RngError),
    Weather(WeatherError),
    /// Invalid organism population (restore).
    Population(String),
}

impl fmt::Display for SimError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SimError::World(e) => write!(f, "invalid world: {e}"),
            SimError::Rng(e) => write!(f, "invalid rng state: {e}"),
            SimError::Weather(e) => write!(f, "invalid weather state: {e}"),
            SimError::Population(e) => write!(f, "invalid population: {e}"),
        }
    }
}

impl std::error::Error for SimError {}

impl From<TopologyError> for SimError {
    fn from(e: TopologyError) -> Self {
        SimError::World(e)
    }
}

impl From<WeatherError> for SimError {
    fn from(e: WeatherError) -> Self {
        SimError::Weather(e)
    }
}

impl From<RngError> for SimError {
    fn from(e: RngError) -> Self {
        SimError::Rng(e)
    }
}

/// Mutable view handed to one phase of one tick.
pub struct PhaseCtx<'a> {
    /// The tick being processed (= number of ticks completed before it).
    pub tick: u64,
    pub phase: Phase,
    pub rng: &'a mut Rng,
    pub world: &'a mut World,
    pub ids: &'a mut IdAllocator,
    pub config: &'a Config,
    events: &'a mut Vec<Event>,
}

impl PhaseCtx<'_> {
    /// Append an event to this tick's report (emission order is kept).
    pub fn emit(&mut self, kind: EventKind) {
        self.events.push(Event { tick: self.tick, phase: self.phase, kind });
    }
}

/// The whole simulation state.
#[derive(Debug, Clone)]
pub struct Simulation {
    config: Config,
    tick: u64,
    rng: Rng,
    world: World,
    ids: IdAllocator,
}

impl Simulation {
    /// Fresh simulation at tick 0; RNG seeded from `config.seed` only.
    pub fn new(config: Config) -> Result<Self, SimError> {
        let mut world = World::from_config(&config)?;
        let rng = Rng::seed_from_u64(config.seed);
        let mut ids = IdAllocator::new();
        // Founders use their own generator (ADR-011): core RNG unchanged.
        let founders = Population::founders(&config, world.torus(), &mut ids);
        world.set_organisms(founders).map_err(SimError::Population)?;
        Ok(Simulation { config, tick: 0, rng, world, ids })
    }

    /// Restore clock, RNG and ID counter (TASK-022 extends this with the full
    /// world/organism state). Weather starts at zero; restore it separately
    /// with [`Simulation::set_weather_state`] (part of the simulation state).
    /// The founders of `config` are re-created (IDs from 1); TASK-022 replaces
    /// them with the saved population via [`Simulation::set_population`]. The
    /// ID counter continues at `max(next_id, first ID after the founders)`.
    pub fn resume(config: Config, tick: u64, rng: RngState, next_id: u64) -> Result<Self, SimError> {
        let mut world = World::from_config(&config)?;
        let rng = Rng::from_state(rng)?;
        let mut founder_ids = IdAllocator::new();
        let founders = Population::founders(&config, world.torus(), &mut founder_ids);
        world.set_organisms(founders).map_err(SimError::Population)?;
        let ids = IdAllocator::from_next(next_id.max(founder_ids.peek_next()));
        Ok(Simulation { config, tick, rng, world, ids })
    }

    /// Advance by exactly one tick.
    pub fn step(&mut self) -> TickReport {
        self.step_with(|_| {})
    }

    /// Advance by exactly one tick; `hook` runs after the built-in body of
    /// every phase (diagnostics/tests). It cannot change the phase order.
    pub fn step_with<F: FnMut(&mut PhaseCtx<'_>)>(&mut self, mut hook: F) -> TickReport {
        let t = self.tick;
        let mut events = Vec::new();
        let mut phases = Vec::with_capacity(Phase::ORDER.len());
        for phase in Phase::ORDER {
            let mut ctx = PhaseCtx {
                tick: t,
                phase,
                rng: &mut self.rng,
                world: &mut self.world,
                ids: &mut self.ids,
                config: &self.config,
                events: &mut events,
            };
            run_phase(&mut ctx);
            hook(&mut ctx);
            phases.push(phase);
        }
        self.tick = t.checked_add(1).expect("tick counter overflow");
        TickReport { tick: t, phases, events }
    }

    /// Run `n` ticks, discarding reports.
    pub fn run(&mut self, n: u64) {
        for _ in 0..n {
            self.step();
        }
    }

    /// Number of completed ticks.
    pub fn tick(&self) -> u64 {
        self.tick
    }

    pub fn config(&self) -> &Config {
        &self.config
    }

    pub fn world(&self) -> &World {
        &self.world
    }

    /// Exact RNG state export (checkpoints).
    pub fn rng_state(&self) -> RngState {
        self.rng.state()
    }

    /// Exact RNG state restore (only between ticks).
    pub fn set_rng_state(&mut self, s: RngState) -> Result<(), SimError> {
        self.rng = Rng::from_state(s)?;
        Ok(())
    }

    /// Current temperature/precipitation of `cell` (inside the world): the
    /// values of the last processed tick (`world().climate_tick()`, which is
    /// `tick() - 1` after a step, 0 before any step).
    pub fn climate_now(&self, cell: Cell) -> CellNow {
        self.world.current(cell)
    }

    /// Exact export of the weather lattices (carried-over climate state).
    pub fn weather_state(&self) -> WeatherState {
        self.world.weather().state()
    }

    /// Exact restore of the weather lattices (only between ticks); the
    /// current grid is recomputed for tick `tick().saturating_sub(1)`.
    pub fn set_weather_state(&mut self, s: WeatherState) -> Result<(), SimError> {
        self.world.restore_weather(s, self.tick.saturating_sub(1))?;
        Ok(())
    }

    /// All organisms (ADR-011).
    pub fn organisms(&self) -> &Population {
        self.world.organisms()
    }

    /// Mutable organisms (only between ticks: UI edits, tests).
    pub fn organisms_mut(&mut self) -> &mut Population {
        self.world.organisms_mut()
    }

    /// Snapshot of the last Statistics phase (ADR-021).
    pub fn last_stats(&self) -> &TickStats {
        self.world.stats()
    }

    /// Births/deaths per kind since tick 0.
    pub fn totals(&self) -> &LifeTotals {
        self.world.organisms().totals()
    }

    /// Replace the population (checkpoint restore, TASK-022). Every stored ID
    /// must be below `next_entity_id()` so IDs are never reused, and each kind
    /// Vec must hold its kind in strictly ascending ID order. The spatial index
    /// is rebuilt on this world's torus (positions outside it are an error).
    pub fn set_population(&mut self, mut p: Population) -> Result<(), SimError> {
        p.set_capacity(crate::organism::CellCapacity::from_config(&self.config));
        p.rebuild_index(*self.world.torus()).map_err(SimError::Population)?;
        p.validate(self.ids.peek_next()).map_err(SimError::Population)?;
        self.world.set_organisms(p).map_err(SimError::Population)?;
        Ok(())
    }

    /// Species registry / family tree (ADR-020).
    pub fn species(&self) -> &SpeciesRegistry {
        self.world.organisms().species()
    }

    /// Number of species of `kind` with living members now.
    pub fn living_species(&self, kind: Kind) -> usize {
        self.species().living_count(kind)
    }

    /// The value the next allocated `EntityId` will have.
    pub fn next_entity_id(&self) -> u64 {
        self.ids.peek_next()
    }
}

/// Built-in body of each phase; the order is fixed by `Phase::ORDER` and must
/// not be changed here. Ecology order of one tick (ADR-021, docs/ECOLOGY.md):
/// 1. Climate (season + weather)
/// 2. Resources (soil regeneration)
/// 3. Plants (growth/upkeep/climate stress, then seed reproduction requests)
/// 4. Herbivores (shuffled turns: metabolism, flee/court/rest/graze; mating pass)
/// 5. Carnivores (shuffled turns: metabolism, handling/court/rest/hunt; mating pass)
/// 6. Births (requests resolved, species classified)
/// 7. Deaths (aging, natural deaths, removal of everything flagged)
/// 8. Species (appeared/extinct events)
/// 9. Statistics (counts/births/deaths snapshot, [`TickStats`])
fn run_phase(ctx: &mut PhaseCtx<'_>) {
    match ctx.phase {
        Phase::Climate => ctx.world.update_climate(ctx.tick, ctx.rng, &ctx.config.climate), // TASK-007
        Phase::Resources => {
            // TASK-011: soil resource regeneration (ADR-014).
            ctx.world.regenerate_resources(&ctx.config.plants, ctx.config.climate.max_precipitation);
        }
        Phase::Plants => {
            // TASK-011: growth, upkeep, climate stress (no RNG).
            ctx.world.grow_plants(ctx.tick, &ctx.config.plants, ctx.config.climate.max_precipitation);
            // TASK-012: reproduction, dispersal, pollination (ADR-015, core RNG).
            ctx.world.reproduce_plants(ctx.tick, ctx.config, ctx.rng);
        }
        // TASK-013: sensing + movement (ADR-016); TASK-014: herbivore
        // feeding/metabolism/decisions (ADR-017, `animals::act_herbivores`).
        Phase::Herbivores => {
            let t = ctx.world.act_animals(Kind::Herbivore, ctx.config, ctx.tick, ctx.rng);
            ctx.world.set_last_moves(Kind::Herbivore, t);
        }
        Phase::Carnivores => {
            let t = ctx.world.act_animals(Kind::Carnivore, ctx.config, ctx.tick, ctx.rng);
            ctx.world.set_last_moves(Kind::Carnivore, t);
        }
        Phase::Births => {
            // TASK-008: resolve requests in request order (same-tick rule, ADR-011).
            let recs = ctx.world.organisms_mut().resolve_births(ctx.tick, ctx.ids);
            for r in recs {
                ctx.emit(EventKind::Birth { id: r.id, kind: r.kind, parents: r.parents, generation: r.generation });
            }
        }
        Phase::Deaths => {
            // TASK-008: aging, natural deaths, order-preserving removal.
            let recs = ctx.world.organisms_mut().end_of_tick(ctx.tick);
            for r in recs {
                ctx.emit(EventKind::Death { id: r.id, kind: r.kind, cause: r.cause, age: r.age });
            }
        }
        Phase::Species => {
            // TASK-017: emit the species changes recorded since the last Species phase (ADR-020).
            for c in ctx.world.organisms_mut().species_mut().take_journal() {
                match c {
                    SpeciesChange::Appeared { id, kind, parent, tick } => ctx.emit(EventKind::SpeciesAppeared { species: id, kind, parent, tick }),
                    SpeciesChange::Extinct { id, kind, tick } => ctx.emit(EventKind::SpeciesExtinct { species: id, kind, tick }),
                }
            }
        }
        // TASK-018: per-tick counts/births/deaths snapshot (ADR-021), no RNG.
        Phase::Statistics => ctx.world.update_stats(ctx.tick),
    }
}

impl Simulation {
    /// Lowercase hex SHA-256 of the complete simulation state (ADR-022):
    /// configuration (incl. seed), clock, RNG state, ID counter, world
    /// (climate state, resources, organisms with genomes, species, ledgers).
    /// Equal states give equal hashes; any field difference changes it.
    pub fn state_hash(&self) -> String {
        let Simulation { config, tick, rng, world, ids } = self;
        let mut h = crate::digest::StateHasher::new();
        h.section("config");
        h.debug(config);
        h.section("clock");
        h.u64(*tick);
        h.section("rng");
        h.debug(&rng.state());
        h.section("ids");
        h.debug(ids);
        world.hash_state(&mut h);
        h.finish_hex()
    }

    /// All state parts by value/reference (checkpoint export, ADR-025).
    /// Exhaustive destructuring: a new field must be decided here.
    pub(crate) fn parts(&self) -> (&Config, u64, RngState, &World, &IdAllocator) {
        let Simulation { config, tick, rng, world, ids } = self;
        (config, *tick, rng.state(), world, ids)
    }

    /// Assemble a simulation from restored parts (checkpoint import).
    pub(crate) fn from_parts(config: Config, tick: u64, rng: Rng, world: World, ids: IdAllocator) -> Simulation {
        Simulation { config, tick, rng, world, ids }
    }

    /// Test-only mutable world access (hash sensitivity tests).
    #[cfg(test)]
    pub(crate) fn world_mut_for_test(&mut self) -> &mut World {
        &mut self.world
    }

    /// Test-only mutable configuration access (hash sensitivity tests).
    #[cfg(test)]
    pub(crate) fn config_mut_for_test(&mut self) -> &mut Config {
        &mut self.config
    }
}

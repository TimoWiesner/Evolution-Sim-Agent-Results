//! Movement (ADR-016): cell-to-cell steps (one of the eight neighbours,
//! wrapping), steps per tick from a deterministic stride limited by speed,
//! cost per step growing within a tick, wrap-aware shortest steps, and the
//! correlated random walk. Every step checks THE cell-sharing rule
//! (`Population::has_room`) and uses `Population::move_organism`.

use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{Kind, Population};
use crate::rng::Rng;
use crate::topology::{Cell, Dir8, Offset, Torus};

/// Chance per wandering tick to draw a new heading (correlated random walk).
pub const WANDER_TURN_CHANCE: f64 = 0.25;

/// Movement cost parameters of one kind.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MoveCosts {
    /// Energy of the first cell moved in a tick (`<kind>.move_cost`).
    pub move_cost: f64,
    /// Extra factor per additional cell in the same tick (`<kind>.sprint_cost`).
    pub sprint_cost: f64,
    /// Hard cap of steps per tick (`<kind>.max_speed`).
    pub max_speed: u32,
}

impl MoveCosts {
    /// Costs of `kind` (plants: zero / 0 steps).
    pub fn for_kind(kind: Kind, cfg: &Config) -> MoveCosts {
        match kind {
            Kind::Plant => MoveCosts { move_cost: 0.0, sprint_cost: 0.0, max_speed: 0 },
            Kind::Herbivore => MoveCosts {
                move_cost: cfg.herbivores.move_cost,
                sprint_cost: cfg.herbivores.sprint_cost,
                max_speed: cfg.herbivores.max_speed,
            },
            Kind::Carnivore => MoveCosts {
                move_cost: cfg.carnivores.move_cost,
                sprint_cost: cfg.carnivores.sprint_cost,
                max_speed: cfg.carnivores.max_speed,
            },
        }
    }
}

/// Cost of the `i`-th step (1-based) within one tick:
/// `move_cost · (1 + sprint_cost · (i − 1))`.
pub fn step_cost(c: &MoveCosts, i: u32) -> f64 {
    c.move_cost * (1.0 + c.sprint_cost * (i.saturating_sub(1)) as f64)
}

/// Cost of `k` steps in one tick: `move_cost · (k + sprint_cost · k(k−1)/2)`.
pub fn path_cost(c: &MoveCosts, k: u32) -> f64 {
    let k = k as f64;
    c.move_cost * (k + c.sprint_cost * k * (k - 1.0) / 2.0)
}

/// Deterministic stride: `budget = stride + speed`; steps allowed this tick
/// `= min(floor(budget), max_speed)`; the fraction is carried (unused whole
/// steps are lost). Returns `(allowed, new_stride ∈ [0,1))`.
pub fn steps_allowed(stride: f64, speed: f64, max_speed: u32) -> (u32, f64) {
    let s = if stride.is_finite() && stride > 0.0 { stride } else { 0.0 };
    let v = if speed.is_finite() && speed > 0.0 { speed } else { 0.0 };
    let budget = s + v;
    let whole = budget.floor();
    let mut frac = budget - whole;
    if !(0.0..1.0).contains(&frac) {
        frac = 0.0;
    }
    ((whole.min(max_speed as f64)) as u32, frac)
}

/// Result of one movement call.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MoveOutcome {
    pub steps: u32,
    pub energy_spent: f64,
    /// A wanted step was refused by the cell-sharing rule.
    pub blocked: bool,
    pub end: Cell,
}

impl MoveOutcome {
    /// No movement at `cell`.
    pub fn stay(cell: Cell) -> MoveOutcome {
        MoveOutcome { steps: 0, energy_spent: 0.0, blocked: false, end: cell }
    }
}

/// Movement summary of one phase.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct MoveTick {
    /// Actors that took at least one step.
    pub movers: u64,
    pub steps: u64,
    pub energy_spent: f64,
    /// Actors with a step refused by the cell-sharing rule.
    pub blocked: u64,
}

impl MoveTick {
    pub fn record(&mut self, o: &MoveOutcome) {
        self.movers += (o.steps > 0) as u64;
        self.steps += o.steps as u64;
        self.energy_spent += o.energy_spent;
        self.blocked += o.blocked as u64;
    }
}

fn dir_of(dx: i32, dy: i32) -> Option<Dir8> {
    Dir8::from_offset(Offset { dx, dy })
}

/// Distance-reducing unit steps from `from` towards `to`, in preference
/// order: the signum direction of the shortest (wrap-aware) offset first,
/// then the ADR-016 alternatives (`|dx|>|dy|`: (sx,0),(sx,+1),(sx,−1);
/// `|dy|>|dx|`: (0,sy),(+1,sy),(−1,sy)), keeping only steps that lower the
/// toroidal distance by exactly 1. Empty if `from == to`.
pub fn preferred_steps(torus: &Torus, from: Cell, to: Cell) -> Vec<Dir8> {
    let o = torus.offset(from, to);
    let d = o.chebyshev();
    if d == 0 {
        return Vec::new();
    }
    let (sx, sy) = (o.dx.signum(), o.dy.signum());
    let mut cand: Vec<Option<Dir8>> = vec![dir_of(sx, sy)];
    if o.dx.abs() > o.dy.abs() {
        cand.extend([dir_of(sx, 0), dir_of(sx, 1), dir_of(sx, -1)]);
    } else if o.dy.abs() > o.dx.abs() {
        cand.extend([dir_of(0, sy), dir_of(1, sy), dir_of(-1, sy)]);
    }
    let mut out: Vec<Dir8> = Vec::with_capacity(3);
    for dir in cand.into_iter().flatten() {
        if !out.contains(&dir) && torus.distance(torus.step(from, dir), to) + 1 == d {
            out.push(dir);
        }
    }
    out
}

/// One step of `id` in `dir` paying the cost of step number `i`, if the
/// target cell has room and the animal can pay. `Err(true)` = no room,
/// `Err(false)` = not enough energy / not alive.
fn try_step(pop: &mut Population, id: EntityId, dir: Dir8, i: u32, c: &MoveCosts) -> Result<f64, bool> {
    let Some(o) = pop.get_alive(id) else { return Err(false) };
    let cost = step_cost(c, i);
    if o.energy() < cost {
        return Err(false);
    }
    let to = pop.index().torus().step(o.pos(), dir);
    if !pop.has_room(to, o.kind()) {
        return Err(true);
    }
    pop.move_organism(id, to).expect("alive organism, cell inside the torus");
    Ok(pop.get_alive_mut(id).expect("alive").spend_energy(cost))
}

/// Move `id` towards `target` along a shortest (wrap-aware) path, one cell
/// per step, until its distance is ≤ `stop_at`, `max_steps` are used, it
/// cannot pay the next step, or every distance-reducing cell is full
/// (`blocked`; it waits, the path is never lengthened). Step numbers (cost)
/// start at 1 for this call.
pub fn move_towards(pop: &mut Population, id: EntityId, target: Cell, max_steps: u32, stop_at: u32, c: &MoveCosts) -> MoveOutcome {
    let Some(o) = pop.get_alive(id) else { return MoveOutcome::stay(target) };
    let mut out = MoveOutcome::stay(o.pos());
    let torus = *pop.index().torus();
    while out.steps < max_steps && torus.distance(out.end, target) > stop_at {
        let mut moved = false;
        let mut no_room = false;
        for dir in preferred_steps(&torus, out.end, target) {
            match try_step(pop, id, dir, out.steps + 1, c) {
                Ok(e) => {
                    out.energy_spent += e;
                    moved = true;
                    break;
                }
                Err(true) => no_room = true,
                Err(false) => return out,
            }
        }
        if !moved {
            out.blocked = no_room;
            break;
        }
        out.steps += 1;
        out.end = pop.get_alive(id).expect("alive").pos();
    }
    out
}

/// Move `id` away from `threat` (opposite of the shortest offset, then its
/// two neighbouring directions), each step increasing the distance, up to
/// `max_steps`. No move if `threat` is its own cell.
pub fn move_away(pop: &mut Population, id: EntityId, threat: Cell, max_steps: u32, c: &MoveCosts) -> MoveOutcome {
    let Some(o) = pop.get_alive(id) else { return MoveOutcome::stay(threat) };
    let mut out = MoveOutcome::stay(o.pos());
    let torus = *pop.index().torus();
    while out.steps < max_steps {
        let Some(toward) = Dir8::from_offset(torus.offset(out.end, threat)) else { break };
        let a = toward.opposite() as usize;
        let d = torus.distance(out.end, threat);
        let mut moved = false;
        let mut no_room = false;
        for dir in [Dir8::ALL[a], Dir8::ALL[(a + 1) % 8], Dir8::ALL[(a + 7) % 8]] {
            if torus.distance(torus.step(out.end, dir), threat) <= d {
                continue;
            }
            match try_step(pop, id, dir, out.steps + 1, c) {
                Ok(e) => {
                    out.energy_spent += e;
                    moved = true;
                    break;
                }
                Err(true) => no_room = true,
                Err(false) => return out,
            }
        }
        if !moved {
            out.blocked = no_room;
            break;
        }
        out.steps += 1;
        out.end = pop.get_alive(id).expect("alive").pos();
    }
    out
}

/// Correlated random walk when nothing interesting is in sight (ADR-016).
/// `allowed == 0`: nothing happens (no draws). Otherwise: heading `None` or
/// `chance(WANDER_TURN_CHANCE)` → new heading `Dir8::ALL[below(8)]`; then at
/// most one step in the heading; a full target cell draws a new heading and
/// the animal stays this tick; too little energy: it stays.
pub fn wander(pop: &mut Population, id: EntityId, allowed: u32, c: &MoveCosts, rng: &mut Rng) -> MoveOutcome {
    let Some(o) = pop.get_alive(id) else { return MoveOutcome::stay(Cell::new(0, 0)) };
    let mut out = MoveOutcome::stay(o.pos());
    if allowed == 0 {
        return out;
    }
    let heading = match o.heading() {
        Some(h) if !rng.chance(WANDER_TURN_CHANCE) => h,
        _ => Dir8::ALL[rng.below(8) as usize],
    };
    pop.get_alive_mut(id).expect("alive").set_heading(Some(heading));
    match try_step(pop, id, heading, 1, c) {
        Ok(e) => {
            out.steps = 1;
            out.energy_spent = e;
            out.end = pop.get_alive(id).expect("alive").pos();
        }
        Err(true) => {
            out.blocked = true;
            let h = Dir8::ALL[rng.below(8) as usize];
            pop.get_alive_mut(id).expect("alive").set_heading(Some(h));
        }
        Err(false) => {}
    }
    out
}

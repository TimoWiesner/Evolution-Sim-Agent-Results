//! Typed reading/writing of single JSON values with range checks.

use super::error::ConfigError;
use serde_json::Value;

/// Inclusive valid range `(min, max)`; `None` for booleans and strings.
pub type Range = Option<(f64, f64)>;

/// A parameter value type that can be read from / written to JSON.
pub trait ParamValue: Sized + Clone + PartialEq {
    /// Type name for docs and error messages.
    const TYPE_NAME: &'static str;
    /// Read and range-check `v`; errors name `key`.
    fn read(v: &Value, key: &str, range: Range) -> Result<Self, ConfigError>;
    /// Write as JSON.
    fn write(&self) -> Value;
}

/// Read a JSON integer as u64; negative or too large integers are out of range,
/// non-integers are a wrong type.
fn read_unsigned(v: &Value, key: &str, type_name: &'static str, lo: u64, hi: u64) -> Result<u64, ConfigError> {
    let Value::Number(n) = v else {
        return Err(ConfigError::wrong_type(key, type_name, v));
    };
    if let Some(x) = n.as_u64() {
        if x < lo || x > hi {
            return Err(ConfigError::out_of_range(key, x, lo as f64, hi as f64));
        }
        return Ok(x);
    }
    if let Some(x) = n.as_i64() {
        // negative integer
        return Err(ConfigError::out_of_range(key, x, lo as f64, hi as f64));
    }
    // float literal: integers too large for u64 are parsed as f64 by serde_json
    let f = n.as_f64().unwrap_or(f64::NAN);
    if f.fract() == 0.0 && f.abs() >= 1.8e19 {
        return Err(ConfigError::out_of_range(key, n, lo as f64, hi as f64));
    }
    Err(ConfigError::wrong_type(key, type_name, v))
}

fn bounds(range: Range, tmin: u64, tmax: u64) -> (u64, u64) {
    match range {
        Some((a, b)) => (a.max(tmin as f64) as u64, b.min(tmax as f64) as u64),
        None => (tmin, tmax),
    }
}

impl ParamValue for u32 {
    const TYPE_NAME: &'static str = "integer";
    fn read(v: &Value, key: &str, range: Range) -> Result<Self, ConfigError> {
        let (lo, hi) = bounds(range, 0, u32::MAX as u64);
        read_unsigned(v, key, Self::TYPE_NAME, lo, hi).map(|x| x as u32)
    }
    fn write(&self) -> Value {
        Value::from(*self)
    }
}

impl ParamValue for u64 {
    const TYPE_NAME: &'static str = "integer";
    fn read(v: &Value, key: &str, range: Range) -> Result<Self, ConfigError> {
        let (lo, hi) = match range {
            Some(_) => bounds(range, 0, u64::MAX),
            None => (0, u64::MAX),
        };
        read_unsigned(v, key, Self::TYPE_NAME, lo, hi)
    }
    fn write(&self) -> Value {
        Value::from(*self)
    }
}

impl ParamValue for f64 {
    const TYPE_NAME: &'static str = "number";
    fn read(v: &Value, key: &str, range: Range) -> Result<Self, ConfigError> {
        let x = v.as_f64().ok_or_else(|| ConfigError::wrong_type(key, Self::TYPE_NAME, v))?;
        if let Some((lo, hi)) = range {
            if !(x >= lo && x <= hi) {
                return Err(ConfigError::out_of_range(key, x, lo, hi));
            }
        }
        Ok(x)
    }
    fn write(&self) -> Value {
        Value::from(*self)
    }
}

impl ParamValue for bool {
    const TYPE_NAME: &'static str = "boolean";
    fn read(v: &Value, key: &str, _range: Range) -> Result<Self, ConfigError> {
        v.as_bool().ok_or_else(|| ConfigError::wrong_type(key, Self::TYPE_NAME, v))
    }
    fn write(&self) -> Value {
        Value::Bool(*self)
    }
}

impl ParamValue for String {
    const TYPE_NAME: &'static str = "string";
    fn read(v: &Value, key: &str, _range: Range) -> Result<Self, ConfigError> {
        v.as_str().map(str::to_owned).ok_or_else(|| ConfigError::wrong_type(key, Self::TYPE_NAME, v))
    }
    fn write(&self) -> Value {
        Value::String(self.clone())
    }
}

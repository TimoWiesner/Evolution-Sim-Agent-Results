//! Declarative parameter table (ADR-006). Each line defines one non-fixed
//! parameter: `field: type = default, "doc" [, [min, max]];` (inclusive range,
//! required for numeric types). Adding a parameter = adding one line here and
//! one row in docs/CONFIG.md; the generic tests cover it automatically.

use super::error::ConfigError;
use super::value::{ParamValue, Range};
use serde_json::{Map, Value};

/// Machine-readable description of one configuration key.
#[derive(Debug, Clone, PartialEq)]
pub struct ParamSpec {
    /// Dotted key, e.g. `plants.max_age`.
    pub key: String,
    /// `integer`, `number`, `boolean` or `string`.
    pub type_name: &'static str,
    /// Default value; `None` for the fixed (required) contract keys.
    pub default: Option<Value>,
    pub min: Option<f64>,
    pub max: Option<f64>,
    pub doc: &'static str,
}

macro_rules! opt_range {
    () => {
        None
    };
    ($a:expr, $b:expr) => {
        Some(($a as f64, $b as f64))
    };
}

macro_rules! param_group {
    ($(#[$m:meta])* $Name:ident, $group:literal {
        $( $field:ident : $ty:ty = $default:expr, $doc:literal $(, [$min:expr, $max:expr])? ; )*
    }) => {
        $(#[$m])*
        #[derive(Debug, Clone, PartialEq)]
        pub struct $Name { $( #[doc = $doc] pub $field: $ty, )* }

        impl Default for $Name {
            fn default() -> Self { Self { $( $field: $default, )* } }
        }

        impl $Name {
            /// Top-level JSON key of this group.
            pub const GROUP: &'static str = $group;
            /// Field names in declaration order.
            pub const FIELDS: &'static [&'static str] = &[$( stringify!($field), )*];

            /// Read the group; `None` (absent) gives the defaults, absent fields
            /// keep their default. Unknown keys are an error.
            pub fn read(v: Option<&Value>) -> Result<Self, ConfigError> {
                let mut out = Self::default();
                let Some(v) = v else { return Ok(out) };
                let obj = v.as_object().ok_or_else(|| ConfigError::wrong_type($group, "object", v))?;
                for k in obj.keys() {
                    if !Self::FIELDS.contains(&k.as_str()) {
                        return Err(ConfigError::unknown(format!("{}.{}", $group, k)));
                    }
                }
                $(
                    if let Some(x) = obj.get(stringify!($field)) {
                        out.$field = <$ty as ParamValue>::read(
                            x, concat!($group, ".", stringify!($field)), Self::range(stringify!($field)))?;
                    }
                )*
                Ok(out)
            }

            fn range(field: &str) -> Range {
                $( if field == stringify!($field) { return opt_range!($($min, $max)?); } )*
                None
            }

            /// Write every field.
            pub fn write(&self) -> Value {
                let mut m = Map::new();
                $( m.insert(stringify!($field).to_string(), ParamValue::write(&self.$field)); )*
                Value::Object(m)
            }

            /// Schema entries of this group (defaults from `Default`).
            pub fn specs() -> Vec<ParamSpec> {
                let d = Self::default();
                vec![$(
                    {
                        let r: Range = opt_range!($($min, $max)?);
                        ParamSpec {
                            key: concat!($group, ".", stringify!($field)).to_string(),
                            type_name: <$ty as ParamValue>::TYPE_NAME,
                            default: Some(ParamValue::write(&d.$field)),
                            min: r.map(|r| r.0),
                            max: r.map(|r| r.1),
                            doc: $doc,
                        }
                    },
                )*]
            }
        }
    };
}

param_group!(
    /// Climate: latitudinal temperature/precipitation zones, seasons, weather (TASK-006/007).
    ClimateParams, "climate" {
        year_length: u32 = 400, "Ticks per simulated year (season cycle)", [1, 100_000];
        equator_temperature: f64 = 28.0, "Base temperature at the equator row (deg C)", [-50, 60];
        pole_temperature: f64 = -25.0, "Mean temperature at the poles (deg C); must be <= equator_temperature", [-80, 40];
        seasonal_amplitude: f64 = 8.0, "Seasonal temperature amplitude at the pole (deg C); scaled by 0.1+0.9*sin(latitude)", [0, 40];
        max_precipitation: f64 = 1.0, "Precipitation in the wettest zone (relative units)", [0, 10];
        precipitation_seasonality: f64 = 0.3, "Relative seasonal variation of precipitation", [0, 1];
        weather_enabled: bool = true, "Random weather fluctuations on top of the climate";
        weather_temperature_sd: f64 = 2.0, "Stationary SD of the weather temperature anomaly (deg C); clamped to +-3 SD", [0, 20];
        weather_precipitation_sd: f64 = 0.1, "Stationary SD of the weather precipitation anomaly, relative to max_precipitation; clamped to +-3 SD", [0, 2];
        weather_persistence: f64 = 0.9, "Autocorrelation of weather from tick to tick", [0, 0.999];
        noise_temperature: f64 = 1.5, "Amplitude of the seeded static temperature anomaly field (deg C)", [0, 20];
        noise_precipitation: f64 = 0.05, "Amplitude of the seeded static precipitation anomaly, relative to max_precipitation", [0, 1];
        noise_scale: u32 = 16, "Feature size of the climate anomaly field in cells", [1, 4096];
        weather_scale: u32 = 16, "Feature size of the weather anomaly lattice in cells", [1, 4096];
    }
);

param_group!(
    /// Plants: cell resources, growth, reproduction, dispersal, mutation (TASK-011/012).
    PlantParams, "plants" {
        max_per_cell: u32 = 2, "Maximum number of plants in one cell", [1, 64];
        resource_cap: f64 = 15.0, "Maximum soil resource per cell", [0, 1000];
        resource_regen: f64 = 1.0, "Soil resource regeneration per tick", [0, 1000];
        initial_energy: f64 = 4.0, "Energy of a founder/new plant; must be <= max_energy", [0, 1e6];
        max_energy: f64 = 20.0, "Maximum energy a plant can store", [0.1, 1e6];
        max_age: u32 = 300, "Maximum plant age in ticks", [1, 10_000_000];
        reproduction_threshold: f64 = 8.0, "Energy needed to reproduce; must be <= max_energy", [0, 1e6];
        reproduction_cost: f64 = 4.0, "Energy spent per offspring; must be <= max_energy", [0, 1e6];
        dispersal_radius: u32 = 3, "Maximum seed dispersal distance in cells", [0, 64];
        pollination_enabled: bool = true, "Allow cross-pollination between nearby compatible plants";
        mutation_rate: f64 = 0.05, "Per-gene mutation probability", [0, 1];
        mutation_strength: f64 = 0.05, "Standard deviation of a gene mutation", [0, 1];
        founder_variation: f64 = 0.02, "SD of the random deviation of founder genes from the default genome", [0, 1];
        species_threshold: f64 = 0.15, "Genetic distance that founds a new species", [0, 1];
        growth_rate: f64 = 1.5, "Maximum energy a plant takes up per tick at ideal temperature and water (ADR-014)", [0, 1e6];
        upkeep: f64 = 0.1, "Plant energy spent per tick on respiration, scaled by 0.75+0.5*strength", [0, 1e6];
        water_min: f64 = 0.1, "Relative moisture (precipitation / climate.max_precipitation) below which plants cannot grow and suffer drought", [0, 1];
        water_optimum: f64 = 0.5, "Relative moisture at and above which water does not limit plant growth", [0, 1];
        generalist_cost: f64 = 0.3, "Reduction of the peak growth rate for maximal temperature tolerance", [0, 1];
        stress_damage: f64 = 0.1, "Plant health lost per tick under full climate stress, as fraction of max_health", [0, 1];
        heal_rate: f64 = 0.05, "Plant health regained per tick without climate stress, as fraction of max_health", [0, 1];
        seed_rate: f64 = 0.5, "Chance per tick that a plant with energy >= reproduction_threshold makes a seed, scaled by 0.5+fertility (0 disables reproduction, ADR-015)", [0, 1];
        seed_min_resource: f64 = 1.0, "Soil resource a landing cell needs for a seed to establish (ADR-015)", [0, 1000];
        pollination_chance: f64 = 0.3, "Chance that a seed is fertilised by a compatible plant within pollen_radius (needs pollination_enabled)", [0, 1];
        pollen_radius: u32 = 2, "Maximum distance in cells of a pollen donor", [0, 64];
    }
);

param_group!(
    /// Herbivores: energy, life cycle, movement, feeding, reproduction (TASK-013/014).
    HerbivoreParams, "herbivores" {
        initial_energy: f64 = 80.0, "Energy of a founder/newborn; must be <= max_energy", [0, 1e6];
        max_energy: f64 = 100.0, "Maximum stored energy", [0.1, 1e6];
        max_age: u32 = 1500, "Maximum age in ticks", [1, 10_000_000];
        maturity_age: u32 = 60, "Age at which reproduction becomes possible", [0, 10_000_000];
        base_metabolism: f64 = 0.3, "Energy used per tick at rest", [0, 1000];
        move_cost: f64 = 0.1, "Energy used per cell moved", [0, 1000];
        sprint_cost: f64 = 0.5, "Extra cost factor per additional cell in the same tick: the i-th step of a tick costs move_cost*(1+sprint_cost*(i-1))", [0, 100];
        max_speed: u32 = 2, "Maximum cells moved per tick", [1, 16];
        max_vision: u32 = 6, "Maximum sensing radius in cells", [1, 64];
        max_per_cell: u32 = 2, "Maximum number of organisms of this kind in one cell (cell-sharing rule, ADR-016)", [1, 64];
        max_meal: f64 = 2.0, "Maximum energy eaten per tick", [0, 1e6];
        climate_cost: f64 = 1.0, "Extra metabolism factor per unit of thermal stress outside the temperature tolerance (up to x(1+2*climate_cost) in extreme cold or heat, ADR-017)", [0, 100];
        assimilation: f64 = 0.8, "Fraction of the plant energy eaten that the herbivore gains (rest is lost, ADR-017)", [0, 1];
        graze_reserve: f64 = 0.35, "Protected plant reserve: share of a plant's max_energy that no bite can take (ADR-021)", [0, 1];
        reproduction_threshold: f64 = 70.0, "Energy needed to mate; must be <= max_energy", [0, 1e6];
        reproduction_cost: f64 = 35.0, "Energy given to an offspring per parent", [0, 1e6];
        mating_threshold: f64 = 0.2, "Maximum genetic distance of compatible mates", [0, 1];
        mating_cooldown: u32 = 40, "Ticks after a mating before the animal can mate again (ADR-019)", [0, 10_000_000];
        conception_chance: f64 = 0.5, "Base chance that a mating conceives; scaled by 0.5 + mean parent fertility (ADR-019)", [0, 1];
        max_litter: u32 = 3, "Maximum offspring per conception (ADR-019)", [1, 16];
        mutation_rate: f64 = 0.05, "Per-gene mutation probability", [0, 1];
        mutation_strength: f64 = 0.05, "Standard deviation of a gene mutation", [0, 1];
        founder_variation: f64 = 0.02, "SD of the random deviation of founder genes from the default genome", [0, 1];
        species_threshold: f64 = 0.15, "Genetic distance that founds a new species", [0, 1];
    }
);

param_group!(
    /// Carnivores: same fields as herbivores, different defaults (TASK-015/016).
    CarnivoreParams, "carnivores" {
        initial_energy: f64 = 80.0, "Energy of a founder/newborn; must be <= max_energy", [0, 1e6];
        max_energy: f64 = 160.0, "Maximum stored energy", [0.1, 1e6];
        max_age: u32 = 2000, "Maximum age in ticks", [1, 10_000_000];
        maturity_age: u32 = 150, "Age at which reproduction becomes possible", [0, 10_000_000];
        base_metabolism: f64 = 0.3, "Energy used per tick at rest", [0, 1000];
        move_cost: f64 = 0.15, "Energy used per cell moved", [0, 1000];
        sprint_cost: f64 = 0.5, "Extra cost factor per additional cell in the same tick: the i-th step of a tick costs move_cost*(1+sprint_cost*(i-1))", [0, 100];
        max_speed: u32 = 3, "Maximum cells moved per tick", [1, 16];
        max_vision: u32 = 8, "Maximum sensing radius in cells", [1, 64];
        max_per_cell: u32 = 2, "Maximum number of organisms of this kind in one cell (cell-sharing rule, ADR-016)", [1, 64];
        max_meal: f64 = 60.0, "Maximum energy eaten per tick", [0, 1e6];
        climate_cost: f64 = 1.0, "Metabolism multiplier per unit of thermal stress (ADR-017 formula, ADR-018)", [0, 100];
        assimilation: f64 = 0.8, "Fraction of the prey energy a carnivore gains from a kill, capped by max_meal (rest is lost, ADR-018)", [0, 1];
        reproduction_threshold: f64 = 110.0, "Energy needed to mate; must be <= max_energy", [0, 1e6];
        reproduction_cost: f64 = 55.0, "Energy given to an offspring per parent", [0, 1e6];
        mating_threshold: f64 = 0.2, "Maximum genetic distance of compatible mates", [0, 1];
        mating_cooldown: u32 = 120, "Ticks after a mating before the animal can mate again (ADR-019)", [0, 10_000_000];
        conception_chance: f64 = 0.5, "Base chance that a mating conceives; scaled by 0.5 + mean parent fertility (ADR-019)", [0, 1];
        max_litter: u32 = 1, "Maximum offspring per conception (ADR-019)", [1, 16];
        mutation_rate: f64 = 0.05, "Per-gene mutation probability", [0, 1];
        mutation_strength: f64 = 0.05, "Standard deviation of a gene mutation", [0, 1];
        founder_variation: f64 = 0.02, "SD of the random deviation of founder genes from the default genome", [0, 1];
        species_threshold: f64 = 0.15, "Genetic distance that founds a new species", [0, 1];
    }
);

param_group!(
    /// Hunting: carnivore attacks on herbivores (TASK-015).
    HuntingParams, "hunting" {
        base_success: f64 = 0.33, "Base probability that an attack succeeds (before the local prey-density factor, ADR-030)", [0, 1];
        attack_cost: f64 = 1.0, "Energy a carnivore spends per attack", [0, 1000];
        handling_time: u32 = 15, "Ticks a carnivore needs to eat a kill", [0, 1000];
        cover_protection: f64 = 0.6, "Reduction of attack success by dense plant cover", [0, 1];
        prey_density_half: f64 = 40.0, "Local prey density at which attack success is halved: success x n/(n+half), n = herbivores within the attacker's vision (0 = off, ADR-030)", [0, 1000];
    }
);

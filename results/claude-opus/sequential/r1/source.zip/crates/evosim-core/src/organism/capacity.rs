//! THE cell-sharing rule (ADR-016), defined once and applied everywhere:
//!
//! > Organisms of different kinds may always share a cell. Organisms of the
//! > same kind may share a cell up to a per-kind capacity `cap(kind)`:
//! > `plants.max_per_cell`, `herbivores.max_per_cell`,
//! > `carnivores.max_per_cell`. Nothing may make an organism enter a cell
//! > (move step, birth, seed, founder placement) that already holds
//! > `cap(kind)` living organisms of its kind.
//!
//! Users: `Population::has_room` (movement in `animals`, `resolve_births`
//! guard, founder placement probe) and `plants::site_ok` (seeds, which also
//! count seeds accepted earlier in the same tick). Only exception: founders
//! when `initial.<kind> > cap(kind)·W·H` (input overload, see ADR-016).

use super::Kind;
use crate::config::Config;

/// Per-kind same-kind capacity of one cell.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CellCapacity {
    pub plants: u32,
    pub herbivores: u32,
    pub carnivores: u32,
}

impl CellCapacity {
    pub fn from_config(cfg: &Config) -> CellCapacity {
        CellCapacity {
            plants: cfg.plants.max_per_cell,
            herbivores: cfg.herbivores.max_per_cell,
            carnivores: cfg.carnivores.max_per_cell,
        }
    }

    /// `cap(kind)`.
    pub fn of(&self, kind: Kind) -> u32 {
        match kind {
            Kind::Plant => self.plants,
            Kind::Herbivore => self.herbivores,
            Kind::Carnivore => self.carnivores,
        }
    }
}

impl Default for CellCapacity {
    /// Capacities of `Config::contract_example()`.
    fn default() -> Self {
        CellCapacity::from_config(&Config::contract_example())
    }
}

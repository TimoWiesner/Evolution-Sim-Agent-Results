//! Carnivore turn (TASK-015, ADR-018): stride → metabolism (with climate
//! cost) → handling / rest / attack in reach / pursue + strike / wander (at
//! most one move call, at most one attack) → starvation check.

use super::feed::{metabolic_cost, satiety, FeedParams};
use super::hunt::{attack, best_in_reach, Attack, HuntParams, HuntTick, ATTACK_REACH};
use super::movement::{move_towards, steps_allowed, wander, MoveCosts, MoveOutcome, MoveTick};
use super::repro::{find_mate_in_reach, is_ready, visible_mate, ReproParams, MATING_REACH};
use super::sense::vision_radius;
use crate::climate::CellNow;
use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Population};
use crate::rng::Rng;

/// What a carnivore decided this turn (exposed for tests and tools).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CarnivoreAction {
    /// Eating/resting after a kill (handling time): no move, no attack.
    Handle,
    /// Ready to mate, no partner in reach: moved towards a visible ready mate (ADR-019).
    Court,
    /// Sated: no move, no attack.
    Rest,
    /// Prey already in reach: attack without moving.
    Attack,
    /// Moved towards visible prey and struck once it was in reach.
    PursueAttack,
    /// Moved towards visible prey, not yet in reach.
    Pursue,
    /// No prey in sight.
    Wander,
}

/// One carnivore turn result.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CarnivoreTurn {
    pub action: CarnivoreAction,
    pub moved: MoveOutcome,
    pub attack: Option<Attack>,
    pub metabolism: f64,
    pub starved: bool,
}

/// Metabolism parameters of carnivores (ADR-017 formula, carnivore keys).
pub fn carnivore_feed_params(cfg: &Config) -> FeedParams {
    let c = &cfg.carnivores;
    FeedParams { max_meal: c.max_meal, assimilation: c.assimilation, base_metabolism: c.base_metabolism, climate_cost: c.climate_cost, graze_reserve: 0.0 }
}

/// Carnivores phase body for the actors `ids` (already in acting order).
pub fn act_carnivores(pop: &mut Population, ids: &[EntityId], cfg: &Config, now: &[CellNow], width: u32, tick: u64, rng: &mut Rng) -> (MoveTick, HuntTick) {
    let mut mt = MoveTick::default();
    let mut ht = HuntTick::default();
    let fp = carnivore_feed_params(cfg);
    let hp = HuntParams::from_config(cfg);
    let costs = MoveCosts::for_kind(Kind::Carnivore, cfg);
    let rp = ReproParams::for_kind(Kind::Carnivore, cfg);
    for &id in ids {
        let Some(t) = carnivore_turn(pop, id, &fp, &hp, &costs, &rp, now, width, tick, rng) else { continue };
        ht.hunters += 1;
        mt.record(&t.moved);
        if let Some(a) = &t.attack {
            ht.record_attack(a);
        }
        ht.metabolism += t.metabolism;
        ht.starved += t.starved as u64;
        ht.handling += (t.action == CarnivoreAction::Handle) as u64;
        ht.rested += (t.action == CarnivoreAction::Rest) as u64;
    }
    (mt, ht)
}

/// One carnivore's turn; `None` if `id` is not a living carnivore (or is
/// already at 0 energy/health, left to the Deaths sweep as in ADR-017).
#[allow(clippy::too_many_arguments)]
pub fn carnivore_turn(
    pop: &mut Population,
    id: EntityId,
    fp: &FeedParams,
    hp: &HuntParams,
    costs: &MoveCosts,
    rp: &ReproParams,
    now: &[CellNow],
    width: u32,
    tick: u64,
    rng: &mut Rng,
) -> Option<CarnivoreTurn> {
    let o = pop.get_alive(id)?;
    if o.kind() != Kind::Carnivore || o.energy() <= 0.0 || o.health() <= 0.0 {
        return None;
    }
    let (center, traits, stride, handling) = (o.pos(), *o.traits(), o.stride(), o.handling());
    let (allowed, new_stride) = steps_allowed(stride, traits.speed, costs.max_speed);
    let temperature = now.get(center.y as usize * width as usize + center.x as usize).map(|c| c.temperature).unwrap_or(traits.temp_optimum);
    let cost = metabolic_cost(&traits, temperature, fp);
    let me = pop.get_alive_mut(id).expect("alive");
    me.set_stride(new_stride);
    let metabolism = me.spend_energy(cost);
    let energy = me.energy();

    let mut moved = MoveOutcome::stay(center);
    let mut strike = None;
    let action = if handling > 0 {
        me.set_handling(handling - 1);
        CarnivoreAction::Handle
    } else if let Some(m) = (pop.get_alive(id).is_some_and(|o| is_ready(o, rp)) && find_mate_in_reach(pop, id, rp, &[]).is_none())
        .then(|| visible_mate(pop, id, vision_radius(&traits), rp))
        .flatten()
    {
        moved = move_towards(pop, id, m.cell, allowed, MATING_REACH, costs);
        CarnivoreAction::Court
    } else if energy >= satiety(&traits) {
        CarnivoreAction::Rest
    } else if let Some((prey, _, _)) = best_in_reach(pop, id, hp) {
        strike = Some(attack(pop, id, prey, hp, tick, rng));
        CarnivoreAction::Attack
    } else if let Some(n) = pop.nearest(center, vision_radius(&traits), Some(Kind::Herbivore), |_| true) {
        moved = move_towards(pop, id, n.cell, allowed, ATTACK_REACH, costs);
        if let Some((prey, _, _)) = best_in_reach(pop, id, hp) {
            strike = Some(attack(pop, id, prey, hp, tick, rng));
            CarnivoreAction::PursueAttack
        } else {
            CarnivoreAction::Pursue
        }
    } else {
        moved = wander(pop, id, allowed, costs, rng);
        CarnivoreAction::Wander
    };
    let starved = pop.get_alive(id).is_some_and(|o| o.energy() <= 0.0) && pop.kill(id, DeathCause::Starvation, tick);
    Some(CarnivoreTurn { action, moved, attack: strike, metabolism, starved })
}

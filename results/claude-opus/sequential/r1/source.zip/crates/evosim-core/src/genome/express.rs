//! Gene → trait expression (ADR-012): linear over config-derived ranges,
//! followed by `Traits::clamped` as the final range guarantee. Pure, no RNG.

use super::{gene_table, GeneTrait, Genome};
use crate::config::Config;
use crate::organism::{Kind, Traits};

/// Config-derived expression constants of one kind.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct KindScale {
    pub max_speed: f64,
    pub max_vision: f64,
    pub max_age: u32,
    pub max_energy: f64,
    /// Health at gene value 0.5 (10 / 100 / 120).
    pub base_health: f64,
}

/// Expression constants for all kinds (index `Kind::index()`).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Expression {
    pub scales: [KindScale; 3],
}

impl Expression {
    pub fn from_config(cfg: &Config) -> Expression {
        Expression {
            scales: [
                KindScale {
                    max_speed: 0.0,
                    max_vision: 0.0,
                    max_age: cfg.plants.max_age,
                    max_energy: cfg.plants.max_energy,
                    base_health: 10.0,
                },
                KindScale {
                    max_speed: cfg.herbivores.max_speed as f64,
                    max_vision: cfg.herbivores.max_vision as f64,
                    max_age: cfg.herbivores.max_age,
                    max_energy: cfg.herbivores.max_energy,
                    base_health: 100.0,
                },
                KindScale {
                    max_speed: cfg.carnivores.max_speed as f64,
                    max_vision: cfg.carnivores.max_vision as f64,
                    max_age: cfg.carnivores.max_age,
                    max_energy: cfg.carnivores.max_energy,
                    base_health: 120.0,
                },
            ],
        }
    }

    pub fn scale(&self, kind: Kind) -> &KindScale {
        &self.scales[kind.index()]
    }
}

impl Default for Expression {
    /// Expression of `Config::contract_example()`.
    fn default() -> Expression {
        Expression::from_config(&Config::contract_example())
    }
}

/// Traits of a genome (deterministic; always within the kind's ranges).
pub fn express(genome: &Genome, e: &Expression) -> Traits {
    let kind = genome.kind();
    let s = e.scale(kind);
    let mut t = Traits::zero();
    for (spec, &gene) in gene_table(kind).iter().zip(genome.genes()) {
        let g = (gene as f64).clamp(0.0, 1.0);
        match spec.target {
            None => {}
            Some(GeneTrait::Strength) => t.strength = g,
            Some(GeneTrait::Fertility) => t.fertility = g,
            Some(GeneTrait::MaxHealth) => t.max_health = s.base_health * (0.5 + g),
            Some(GeneTrait::Lifespan) => {
                let v = (s.max_age as f64 * (0.5 + 0.5 * g)).round().max(1.0);
                t.max_lifespan = if v >= u32::MAX as f64 { u32::MAX } else { v as u32 };
            }
            Some(GeneTrait::MaxEnergy) => t.max_energy = s.max_energy * (0.5 + 0.5 * g),
            Some(GeneTrait::TempOptimum) => t.temp_optimum = -20.0 + 60.0 * g,
            Some(GeneTrait::TempTolerance) => t.temp_tolerance = 2.0 + 28.0 * g,
            Some(GeneTrait::Speed) => t.speed = s.max_speed * g,
            Some(GeneTrait::Vision) => t.vision = s.max_vision * g,
            Some(GeneTrait::Aggression) => t.aggression = g,
            Some(GeneTrait::Caution) => t.caution = g,
        }
    }
    Traits::clamped(kind, t)
}

//! TASK-003 tests: fixed keys, defaults, errors naming keys, round-trip, presets.

use super::*;
use serde_json::{json, Value};

const FIXED_ONLY: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

fn fixed() -> Value {
    serde_json::from_str(FIXED_ONLY).unwrap()
}

/// Set a dotted key (creating intermediate objects) in a JSON object.
fn set(v: &mut Value, key: &str, x: Value) {
    let mut cur = v;
    let parts: Vec<&str> = key.split('.').collect();
    for p in &parts[..parts.len() - 1] {
        let o = cur.as_object_mut().unwrap();
        cur = o.entry(p.to_string()).or_insert_with(|| json!({}));
    }
    cur.as_object_mut().unwrap().insert(parts[parts.len() - 1].to_string(), x);
}

fn remove(v: &mut Value, key: &str) {
    let mut cur = v;
    let parts: Vec<&str> = key.split('.').collect();
    for p in &parts[..parts.len() - 1] {
        cur = cur.get_mut(*p).unwrap();
    }
    cur.as_object_mut().unwrap().remove(parts[parts.len() - 1]);
}

fn err_with(key: &str, x: Value) -> ConfigError {
    let mut v = fixed();
    set(&mut v, key, x);
    Config::from_value(&v).expect_err(&format!("{key} should be rejected"))
}

fn assert_named(e: &ConfigError, key: &str) {
    assert_eq!(e.key, key, "{e}");
    assert!(e.to_string().contains(&format!("`{key}`")), "message misses key: {e}");
}

#[test]
fn fixed_keys_only_is_valid() {
    let c = Config::from_json_str(FIXED_ONLY).unwrap();
    assert_eq!(c.seed, 42);
    assert_eq!(c.world, WorldConfig { width: 64, height: 48 });
    assert_eq!(c.initial, InitialConfig { plants: 400, herbivores: 120, carnivores: 20 });
    assert_eq!(c.climate, ClimateParams::default());
    assert_eq!(c.plants, PlantParams::default());
    assert_eq!(c.herbivores, HerbivoreParams::default());
    assert_eq!(c.carnivores, CarnivoreParams::default());
    assert_eq!(c.hunting, HuntingParams::default());
    assert_eq!(c, Config::contract_example());
    assert_eq!(c.name, "custom");
}

#[test]
fn defaults_satisfy_cross_field_checks() {
    Config::contract_example().validate_cross_fields().unwrap();
}

#[test]
fn zero_populations_accepted() {
    for (p, h, k) in [(0, 0, 0), (0, 120, 20), (400, 0, 20), (400, 120, 0)] {
        let mut v = fixed();
        set(&mut v, "initial", json!({"plants": p, "herbivores": h, "carnivores": k}));
        let c = Config::from_value(&v).unwrap();
        assert_eq!(c.initial, InitialConfig { plants: p, herbivores: h, carnivores: k });
    }
}

#[test]
fn every_non_fixed_param_has_default_in_range() {
    let s = schema();
    let fixed_keys = ["seed", "world.width", "world.height", "initial.plants", "initial.herbivores", "initial.carnivores"];
    assert!(s.len() > 50);
    for spec in &s {
        if fixed_keys.contains(&spec.key.as_str()) {
            assert!(spec.default.is_none(), "{}", spec.key);
            continue;
        }
        let d = spec.default.as_ref().unwrap_or_else(|| panic!("{} has no default", spec.key));
        match spec.type_name {
            "integer" | "number" => {
                let x = d.as_f64().unwrap();
                let (lo, hi) = (spec.min.unwrap(), spec.max.unwrap());
                assert!(lo <= x && x <= hi, "{} default {x} not in [{lo},{hi}]", spec.key);
            }
            "boolean" => assert!(d.is_boolean()),
            "string" => assert!(d.is_string()),
            t => panic!("unexpected type {t}"),
        }
    }
    // keys unique
    let mut keys: Vec<_> = s.iter().map(|x| x.key.clone()).collect();
    keys.sort();
    keys.dedup();
    assert_eq!(keys.len(), s.len());
}

#[test]
fn missing_fixed_key_names_key() {
    for key in [
        "seed", "world", "world.width", "world.height", "initial", "initial.plants", "initial.herbivores",
        "initial.carnivores",
    ] {
        let mut v = fixed();
        remove(&mut v, key);
        let e = Config::from_value(&v).unwrap_err();
        assert_eq!(e.kind, ConfigErrorKind::Missing, "{key}: {e}");
        assert_named(&e, key);
    }
}

#[test]
fn wrong_type_names_key() {
    let cases = [
        ("seed", json!("42")),
        ("seed", json!(4.5)),
        ("world.width", json!(64.0)),
        ("world.height", json!(null)),
        ("world", json!([1])),
        ("initial", json!(5)),
        ("initial.plants", json!(true)),
        ("initial.carnivores", json!("20")),
        ("climate.weather_enabled", json!(1)),
        ("climate", json!("warm")),
        ("plants.max_age", json!("x")),
        ("plants.mutation_rate", json!("0.1")),
        ("name", json!(5)),
    ];
    for (key, x) in cases {
        let e = err_with(key, x.clone());
        assert!(matches!(e.kind, ConfigErrorKind::WrongType { .. }), "{key}={x}: {e}");
        assert_named(&e, key);
    }
    let e = Config::from_json_str("[]").unwrap_err();
    assert!(matches!(e.kind, ConfigErrorKind::WrongType { expected: "object", found: "array" }));
    assert_named(&e, ROOT_KEY);
}

#[test]
fn out_of_range_names_key() {
    let cases = [
        ("world.width", json!(0)),
        ("world.height", json!(4097)),
        ("world.width", json!(-3)),
        ("initial.plants", json!(-1)),
        ("initial.herbivores", json!(1_000_001)),
        ("seed", json!(-1)),
        ("plants.mutation_rate", json!(1.5)),
        ("plants.max_per_cell", json!(0)),
        ("climate.weather_persistence", json!(1.0)),
        ("herbivores.max_speed", json!(17)),
        ("carnivores.base_metabolism", json!(-0.1)),
        ("hunting.base_success", json!(2)),
    ];
    for (key, x) in cases {
        let e = err_with(key, x.clone());
        assert!(matches!(e.kind, ConfigErrorKind::OutOfRange { .. }), "{key}={x}: {e}");
        assert_named(&e, key);
    }
    // integer literal too large even for u64
    let mut text = FIXED_ONLY.replace("\"width\": 64", "\"width\": 100000000000000000000000");
    let e = Config::from_json_str(&text).unwrap_err();
    assert!(matches!(e.kind, ConfigErrorKind::OutOfRange { .. }), "{e}");
    assert_named(&e, "world.width");
    text = FIXED_ONLY.replace("\"seed\": 42", "\"seed\": 18446744073709551615");
    assert_eq!(Config::from_json_str(&text).unwrap().seed, u64::MAX);
}

#[test]
fn every_spec_rejects_out_of_range_and_wrong_type() {
    for spec in schema() {
        let wrong = if spec.type_name == "string" { json!(1) } else { json!("str") };
        let e = err_with(&spec.key, wrong);
        assert!(matches!(e.kind, ConfigErrorKind::WrongType { .. }), "{}: {e}", spec.key);
        assert_named(&e, &spec.key);
        if spec.key == "seed" {
            continue; // full u64 range; negative covered above
        }
        if let (Some(lo), Some(hi)) = (spec.min, spec.max) {
            let int = spec.type_name == "integer";
            let above = if int { json!(hi as u64 + 1) } else { json!(hi + 1.0) };
            let e = err_with(&spec.key, above);
            assert!(matches!(e.kind, ConfigErrorKind::OutOfRange { .. }), "{}: {e}", spec.key);
            assert_named(&e, &spec.key);
            let below = if int { json!(lo as i64 - 1) } else { json!(lo - 1.0) };
            let e = err_with(&spec.key, below);
            assert!(matches!(e.kind, ConfigErrorKind::OutOfRange { .. }), "{}: {e}", spec.key);
            assert_named(&e, &spec.key);
        }
    }
}

#[test]
fn unknown_key_rejected() {
    for key in ["foo", "plants.max_agee", "world.depth", "initial.fungi", "hunting.x"] {
        let e = err_with(key, json!(1));
        assert_eq!(e.kind, ConfigErrorKind::UnknownKey, "{key}: {e}");
        assert_named(&e, key);
    }
}

#[test]
fn cross_field_invalid() {
    let mut v = fixed();
    set(&mut v, "climate.pole_temperature", json!(30.0));
    set(&mut v, "climate.equator_temperature", json!(20.0));
    let e = Config::from_value(&v).unwrap_err();
    assert!(matches!(e.kind, ConfigErrorKind::Invalid { .. }), "{e}");
    assert_named(&e, "climate.pole_temperature");

    let e = err_with("herbivores.reproduction_threshold", json!(500.0));
    assert!(matches!(e.kind, ConfigErrorKind::Invalid { .. }), "{e}");
    assert_named(&e, "herbivores.reproduction_threshold");
}

#[test]
fn parse_error_reports_position() {
    let e = Config::from_json_str("{\n  \"seed\": ").unwrap_err();
    match &e.kind {
        ConfigErrorKind::Parse { line, .. } => assert_eq!(*line, 2),
        k => panic!("unexpected {k:?}"),
    }
    assert_named(&e, JSON_KEY);
}

fn assert_round_trip(c: &Config) {
    let text = c.to_json_pretty();
    let back = Config::from_json_str(&text).unwrap_or_else(|e| panic!("{e}\n{text}"));
    assert_eq!(&back, c);
    assert_eq!(back.to_json_pretty(), text, "second write differs");
    assert_eq!(Config::from_value(&c.to_json_value()).unwrap(), *c);
}

/// Small deterministic generator for the randomised round-trip test.
struct XorShift(u64);
impl XorShift {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
    fn unit(&mut self) -> f64 {
        (self.next() >> 11) as f64 / (1u64 << 53) as f64
    }
}

fn random_value(rng: &mut XorShift, spec: &ParamSpec) -> Value {
    match spec.type_name {
        "boolean" => json!(rng.next() & 1 == 1),
        "string" => json!(format!("s{}\u{e9}\"\\\n", rng.next() % 1000)),
        "integer" if spec.key == "seed" => json!(rng.next()),
        "integer" => {
            let (lo, hi) = (spec.min.unwrap() as u64, spec.max.unwrap() as u64);
            // bias towards small values so cross-field checks pass more often
            json!(lo + rng.next() % (hi - lo + 1).min(5000))
        }
        _ => {
            let (lo, hi) = (spec.min.unwrap(), spec.max.unwrap());
            let x = match rng.next() % 4 {
                0 => lo,
                1 => 0.1 + 0.2,
                _ => lo + (hi - lo) * rng.unit(),
            };
            json!(x.clamp(lo, hi))
        }
    }
}

#[test]
fn round_trip_fixed_presets_and_random() {
    assert_round_trip(&Config::from_json_str(FIXED_ONLY).unwrap());
    for n in preset_names() {
        assert_round_trip(&preset(n).unwrap());
    }
    let specs = schema();
    let mut rng = XorShift(0x9E37_79B9_7F4A_7C15);
    let (mut ok, mut tries) = (0, 0);
    while ok < 200 {
        tries += 1;
        assert!(tries < 200_000, "random generator rarely produces valid configs");
        let mut v = json!({});
        for s in &specs {
            set(&mut v, &s.key, random_value(&mut rng, s));
        }
        match Config::from_value(&v) {
            Ok(c) => {
                assert_round_trip(&c);
                ok += 1;
            }
            Err(ConfigError { kind: ConfigErrorKind::Invalid { .. }, .. }) => {}
            Err(e) => panic!("random in-range config rejected: {e}"),
        }
    }
}

#[test]
fn presets_valid_distinct_selectable() {
    let names = preset_names();
    assert!(names.len() >= 3);
    let all: Vec<Config> = names.iter().map(|n| preset(n).unwrap()).collect();
    for (n, c) in names.iter().zip(&all) {
        assert_eq!(c.name, *n);
        assert!(preset_description(n).is_some());
        c.validate_cross_fields().unwrap();
        assert_eq!(Config::from_json_str(&c.to_json_pretty()).unwrap(), *c);
    }
    // default preset == contract example (apart from metadata)
    let mut d = all[0].clone();
    d.name = "custom".into();
    d.description.clear();
    assert_eq!(d, Config::contract_example());
    // pairwise meaningful differences: world/initial or simulation parameters
    for i in 0..all.len() {
        for j in i + 1..all.len() {
            let (a, b) = (&all[i], &all[j]);
            let differs = a.world != b.world
                || a.initial != b.initial
                || a.climate != b.climate
                || a.plants != b.plants;
            assert!(differs, "presets {} and {} do not differ meaningfully", names[i], names[j]);
        }
    }
    let lush = preset("lush").unwrap();
    let harsh = preset("harsh").unwrap();
    assert!(lush.plants.resource_regen > harsh.plants.resource_regen);
    assert!(lush.climate.pole_temperature > harsh.climate.pole_temperature);
    assert_eq!(preset("plants-only").unwrap().initial.herbivores, 0);

    let e = preset("nope").unwrap_err();
    assert_named(&e, "preset");
    match e.kind {
        ConfigErrorKind::UnknownPreset { name, available } => {
            assert_eq!(name, "nope");
            assert_eq!(available.len(), names.len());
        }
        k => panic!("unexpected {k:?}"),
    }
}

#[test]
fn with_seed_overrides_seed_only() {
    let c = Config::contract_example();
    let d = c.clone().with_seed(7);
    assert_eq!(d.seed, 7);
    assert_eq!(d.with_seed(42), c);
}

#[test]
fn docs_list_every_key() {
    let doc = include_str!("../../../../docs/CONFIG.md");
    for s in schema() {
        assert!(doc.contains(&format!("`{}`", s.key)), "docs/CONFIG.md misses `{}`", s.key);
    }
}

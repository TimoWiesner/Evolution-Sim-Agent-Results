//! Organism storage and the shared life cycle (ADR-011).
//!
//! **THE same-tick rule.** Within tick t, all births are resolved in the
//! Births phase before the Deaths phase removes anything. A birth request is
//! honoured only if every parent is still alive (not flagged dead) when the
//! Births phase resolves it; otherwise it is dropped without allocating an ID
//! or counting a birth. A parent that dies in the Deaths phase of tick t still
//! has its tick-t children. A newborn exists from the Births phase on, does not
//! act and does not age in tick t, but is subject to the natural-death checks
//! of tick t's Deaths phase (then it counts as one birth and one death of t).
//! Deaths are counted when flagged, births when resolved, so
//! `initial + births − deaths = living` per kind at all times.
//!
//! The population owns the spatial index of its living organisms (ADR-013):
//! killed organisms leave it at once, newborns enter it when resolved
//! (position wrapped into the torus), moves go through `move_organism`.

use super::{BirthRecord, CellCapacity, BirthRequest, DeathCause, DeathRecord, Kind, LifeTotals, Organism, Parents, FOUNDER_SEED_TAG};
use crate::genome::{mutate, Expression, Genome, MutationParams, FOUNDER_GENOME_TAG};
use crate::config::Config;
use crate::ids::{EntityId, IdAllocator};
use crate::rng::Rng;
use crate::species::SpeciesRegistry;
use crate::spatial::{Neighbour, SpatialError, SpatialIndex};
use crate::topology::{Cell, Torus};

/// All organisms: one Vec per kind, each sorted by ascending `EntityId`.
#[derive(Debug, Clone, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct Population {
    by_kind: [Vec<Organism>; 3],
    pending: Vec<BirthRequest>,
    totals: LifeTotals,
    /// Deaths flagged since the last Deaths phase.
    tick_deaths: Vec<DeathRecord>,
    last_deaths: Vec<DeathRecord>,
    last_births: Vec<BirthRecord>,
    /// Gene → trait constants (from the configuration, ADR-012).
    #[serde(skip)]
    expression: Expression,
    /// Spatial index of the *living* organisms (ADR-013), kept in sync by
    /// founders, `resolve_births`, `kill`, `move_organism`, `rebuild_index`.
    #[serde(skip)]
    index: SpatialIndex,
    /// Same-kind capacity per cell (THE cell-sharing rule, ADR-016).
    #[serde(skip)]
    capacity: CellCapacity,
    /// Birth requests dropped because their cell was full (since tick 0).
    births_dropped_full: u64,
    /// Species and family tree (ADR-020); updated on every creation/kill.
    species: SpeciesRegistry,
    /// Derived lookup cache (TASK-026, ADR-029 §3C): `id_cols[k][i] ==
    /// by_kind[k][i].id`, a dense copy of the sorted ID column so `locate`
    /// binary-searches 8-byte keys instead of whole organisms. Rebuilt
    /// whenever `by_kind` changes shape; not serialised, not hashed. Used
    /// only when its length matches (`locate` falls back otherwise).
    #[serde(skip)]
    id_cols: [Vec<EntityId>; 3],
}

impl Population {
    /// Empty population with the expression of `Config::contract_example()`.
    pub fn new() -> Population {
        Population::default()
    }

    /// Empty population with the given expression constants on `torus`.
    pub fn with_expression(expression: Expression, torus: Torus) -> Population {
        Population { expression, index: SpatialIndex::new(torus), ..Population::default() }
    }

    /// Gene → trait constants used for every organism created here.
    pub fn expression(&self) -> &Expression {
        &self.expression
    }

    /// Founders of the configuration: `initial.plants`, then herbivores, then
    /// carnivores (IDs ascending in that order) at uniform random cells drawn
    /// from `Rng::seed_from_u64(seed ^ FOUNDER_SEED_TAG)`. Not births.
    /// Genome = founder default genome mutated with rate 1 and strength
    /// `<kind>.founder_variation`, drawn from a second generator
    /// `Rng::seed_from_u64(seed ^ FOUNDER_GENOME_TAG)` in ID order (ADR-012).
    pub fn founders(cfg: &Config, torus: &Torus, ids: &mut IdAllocator) -> Population {
        let mut rng = Rng::seed_from_u64(cfg.seed ^ FOUNDER_SEED_TAG);
        let mut grng = Rng::seed_from_u64(cfg.seed ^ FOUNDER_GENOME_TAG);
        let mut p = Population::with_expression(Expression::from_config(cfg), *torus);
        p.capacity = CellCapacity::from_config(cfg);
        p.species = SpeciesRegistry::from_config(cfg);
        for kind in Kind::ALL {
            let (n, energy, variation) = match kind {
                Kind::Plant => (cfg.initial.plants, cfg.plants.initial_energy, cfg.plants.founder_variation),
                Kind::Herbivore => (cfg.initial.herbivores, cfg.herbivores.initial_energy, cfg.herbivores.founder_variation),
                Kind::Carnivore => (cfg.initial.carnivores, cfg.carnivores.initial_energy, cfg.carnivores.founder_variation),
            };
            let jitter = MutationParams { rate: 1.0, strength: variation };
            let expr = p.expression;
            p.by_kind[kind.index()].reserve(n as usize);
            for _ in 0..n {
                let x = rng.below(torus.width() as u64) as u32;
                let y = rng.below(torus.height() as u64) as u32;
                let Cell { x, y } = founder_cell(&p.index, p.capacity.of(kind), kind, Cell { x, y });
                let mut genome = Genome::founder_default(kind);
                mutate(&mut genome, jitter, &mut grng);
                let id = ids.alloc();
                let s = p.species.classify_founder(&genome, 0);
                p.by_kind[kind.index()].push(Organism::new(id, Cell { x, y }, genome, &expr, Parents::None, 0, 0, energy, None, s));
                p.index.insert(id, kind, Cell { x, y }).expect("fresh founder inside the torus");
            }
            p.totals.initial[kind.index()] = n as u64;
        }
        p.rebuild_id_cols();
        // Founder root species are initial state like the founders themselves
        // (no Birth events either): no SpeciesAppeared events (ADR-020).
        p.species.take_journal();
        p
    }

    /// Same-kind cell capacity in force (THE cell-sharing rule, ADR-016).
    pub fn capacity(&self) -> CellCapacity {
        self.capacity
    }

    /// Replace the capacity (tests, restore with a configuration).
    pub fn set_capacity(&mut self, c: CellCapacity) {
        self.capacity = c;
    }

    /// Checkpoint restore (ADR-025): re-create the derived caches skipped by
    /// serialisation (expression, capacity, spatial index) on `torus`.
    pub(crate) fn restore_caches(&mut self, expression: Expression, capacity: CellCapacity, torus: Torus) -> Result<(), String> {
        self.expression = expression;
        self.capacity = capacity;
        self.rebuild_index(torus)
    }

    /// Living organisms of `kind` in `cell`.
    pub fn count_at(&self, cell: Cell, kind: Kind) -> usize {
        self.index.count_at(cell, kind)
    }

    /// Cell-sharing rule: may one more organism of `kind` enter `cell`?
    pub fn has_room(&self, cell: Cell, kind: Kind) -> bool {
        (self.count_at(cell, kind) as u64) < self.capacity.of(kind) as u64
    }

    /// Species registry / family tree (ADR-020).
    pub fn species(&self) -> &SpeciesRegistry {
        &self.species
    }

    /// Mutable registry (Species phase journal).
    pub(crate) fn species_mut(&mut self) -> &mut SpeciesRegistry {
        &mut self.species
    }

    /// Replace the species thresholds (tests; future classifications only).
    pub fn set_species_thresholds(&mut self, t: [f64; 3]) {
        self.species.set_thresholds(t);
    }

    /// Birth requests dropped because their cell was full (since tick 0).
    pub fn births_dropped_full(&self) -> u64 {
        self.births_dropped_full
    }

    /// Re-derive the ID columns from `by_kind` (after any shape change).
    fn rebuild_id_cols(&mut self) {
        for (c, v) in self.id_cols.iter_mut().zip(self.by_kind.iter()) {
            c.clear();
            c.extend(v.iter().map(|o| o.id));
        }
    }

    /// Index of `id` in `by_kind[k]` (binary search on the dense ID column
    /// when it is in sync, else on the organisms themselves).
    #[inline]
    fn slot_in(&self, k: usize, id: EntityId) -> Option<usize> {
        let col = &self.id_cols[k];
        let v = &self.by_kind[k];
        if col.len() == v.len() {
            col.binary_search(&id).ok()
        } else {
            v.binary_search_by_key(&id, |o| o.id).ok()
        }
    }

    fn locate(&self, id: EntityId) -> Option<(usize, usize)> {
        (0..3).find_map(|k| self.slot_in(k, id).map(|i| (k, i)))
    }

    /// Stored organism (includes organisms flagged dead this tick).
    pub fn get(&self, id: EntityId) -> Option<&Organism> {
        self.locate(id).map(|(k, i)| &self.by_kind[k][i])
    }

    /// Mutable stored organism (includes flagged-dead ones). Crate-internal:
    /// behaviour code must use [`Population::get_alive_mut`].
    pub(crate) fn get_mut(&mut self, id: EntityId) -> Option<&mut Organism> {
        self.locate(id).map(move |(k, i)| &mut self.by_kind[k][i])
    }

    /// Living organism (`None` if absent or flagged dead).
    pub fn get_alive(&self, id: EntityId) -> Option<&Organism> {
        self.get(id).filter(|o| o.alive)
    }

    /// Living organism `id` known to be of `kind` (e.g. from a
    /// `Neighbour`): a single binary search (ADR-029 §3C). Same result as
    /// [`Population::get_alive`] whenever `id` is of `kind`, else `None`.
    #[inline]
    pub fn get_alive_of(&self, kind: Kind, id: EntityId) -> Option<&Organism> {
        let k = kind.index();
        self.slot_in(k, id).map(|i| &self.by_kind[k][i]).filter(|o| o.alive)
    }

    pub fn get_alive_mut(&mut self, id: EntityId) -> Option<&mut Organism> {
        self.get_mut(id).filter(|o| o.alive)
    }

    pub fn is_alive(&self, id: EntityId) -> bool {
        self.get_alive(id).is_some()
    }

    /// Living organisms of `kind`, ascending ID.
    pub fn alive(&self, kind: Kind) -> impl Iterator<Item = &Organism> {
        self.by_kind[kind.index()].iter().filter(|o| o.alive)
    }

    /// IDs of living organisms of `kind`, ascending (input of `acting_order`).
    pub fn alive_ids(&self, kind: Kind) -> Vec<EntityId> {
        self.alive(kind).map(|o| o.id).collect()
    }

    pub fn count_alive(&self, kind: Kind) -> usize {
        self.alive(kind).count()
    }

    /// Stored entries incl. flagged-dead ones (diagnostics/tests).
    pub fn stored_len(&self, kind: Kind) -> usize {
        self.by_kind[kind.index()].len()
    }

    /// Stored organisms of `kind` incl. flagged-dead ones, ascending ID.
    pub fn stored(&self, kind: Kind) -> &[Organism] {
        &self.by_kind[kind.index()]
    }

    /// Cumulative counters since tick 0.
    pub fn totals(&self) -> &LifeTotals {
        &self.totals
    }

    /// Death records returned by the last Deaths phase.
    pub fn last_deaths(&self) -> &[DeathRecord] {
        &self.last_deaths
    }

    /// Birth records of the last Births phase.
    pub fn last_births(&self) -> &[BirthRecord] {
        &self.last_births
    }

    /// Flag a living organism dead with `cause` in `tick`. Returns false if
    /// absent or already dead (first cause wins, counted once). The organism
    /// is hidden from all queries at once and removed in the Deaths phase.
    pub fn kill(&mut self, id: EntityId, cause: DeathCause, tick: u64) -> bool {
        let Some(o) = self.get_alive_mut(id) else { return false };
        o.alive = false;
        let pos = o.pos;
        let species = o.species;
        let rec = DeathRecord { id, kind: o.kind, cause, tick, age: o.age, pos: o.pos, generation: o.generation };
        let k = rec.kind.index();
        self.totals.deaths[k] += 1;
        self.totals.deaths_by_cause[k][cause.index()] += 1;
        self.tick_deaths.push(rec);
        self.species.on_death(species, tick);
        let removed = self.index.remove(id);
        debug_assert_eq!(removed.map(|r| r.0), Some(pos), "index out of sync");
        true
    }

    /// Queue a birth for the next Births phase.
    pub fn request_birth(&mut self, req: BirthRequest) {
        self.pending.push(req);
    }

    pub fn pending_births(&self) -> usize {
        self.pending.len()
    }

    /// Births phase: resolve requests in request order (same-tick rule:
    /// dropped if any parent is not alive). Returns the records of this tick.
    pub fn resolve_births(&mut self, tick: u64, ids: &mut IdAllocator) -> Vec<BirthRecord> {
        let reqs = std::mem::take(&mut self.pending);
        let mut out = Vec::with_capacity(reqs.len());
        for r in reqs {
            let mut ok = true;
            let mut gen = 0u32;
            for pid in r.parents.ids() {
                match self.get_alive(pid) {
                    Some(p) => gen = gen.max(p.generation),
                    None => ok = false,
                }
            }
            if !ok {
                continue;
            }
            // Cell-sharing rule (ADR-016): a birth into a full cell is dropped.
            let pos = self.index.torus().wrap(r.pos.x as i64, r.pos.y as i64);
            if !self.has_room(pos, r.kind()) {
                self.births_dropped_full += 1;
                continue;
            }
            let generation = if r.parents.is_founder() { 0 } else { gen.saturating_add(1) };
            // Species rule (ADR-020): classified via the first stored parent.
            let species = match r.parents.ids().next().and_then(|m| self.get_alive(m)).map(|m| m.species) {
                Some(ms) => self.species.classify_child(ms, &r.genome, tick),
                None => self.species.classify_founder(&r.genome, tick),
            };
            let id = ids.alloc();
            let kind = r.kind();
            let expr = self.expression;
            let v = &mut self.by_kind[kind.index()];
            debug_assert!(v.last().is_none_or(|l| l.id < id), "IDs must be appended ascending");
            v.push(Organism::new(id, pos, r.genome, &expr, r.parents, generation, tick, r.energy, r.health, species));
            self.id_cols[kind.index()].push(id);
            self.index.insert(id, kind, pos).expect("fresh ID, wrapped position");
            self.totals.births[kind.index()] += 1;
            out.push(BirthRecord { id, kind, parents: r.parents, generation, pos, tick, species });
        }
        self.last_births = out.clone();
        out
    }

    /// Deaths phase sweep (ascending kind, then ID, over living organisms):
    /// age += 1 unless born in this tick's Births phase; natural death, first
    /// match: health 0 → Injury, energy 0 → Starvation, age ≥ max_lifespan →
    /// OldAge; then remove every flagged organism. Returns all death records
    /// of the tick in flag order.
    pub fn end_of_tick(&mut self, tick: u64) -> Vec<DeathRecord> {
        let mut natural: Vec<(EntityId, DeathCause)> = Vec::new();
        for v in self.by_kind.iter_mut() {
            for o in v.iter_mut().filter(|o| o.alive) {
                let newborn = o.birth_tick == tick && !o.parents.is_founder();
                if !newborn {
                    o.age = o.age.saturating_add(1);
                }
                o.cooldown = o.cooldown.saturating_sub(1);
                let cause = if o.health <= 0.0 {
                    Some(DeathCause::Injury)
                } else if o.energy <= 0.0 {
                    Some(DeathCause::Starvation)
                } else if o.age >= o.traits.max_lifespan {
                    Some(DeathCause::OldAge)
                } else {
                    None
                };
                if let Some(c) = cause {
                    natural.push((o.id, c));
                }
            }
        }
        for (id, c) in natural {
            self.kill(id, c, tick);
        }
        for v in self.by_kind.iter_mut() {
            v.retain(|o| o.alive);
        }
        self.rebuild_id_cols();
        let recs = std::mem::take(&mut self.tick_deaths);
        self.last_deaths = recs.clone();
        recs
    }
}

impl Population {
    /// Spatial index of the living organisms (ADR-013).
    pub fn index(&self) -> &SpatialIndex {
        &self.index
    }

    /// The only way to move a living organism: updates its position and the
    /// index. Returns the old cell. Errors: `Unknown` if absent or flagged
    /// dead, `OutsideWorld` if `to` is not a cell of the torus.
    pub fn move_organism(&mut self, id: EntityId, to: Cell) -> Result<Cell, SpatialError> {
        if !self.is_alive(id) {
            return Err(SpatialError::Unknown(id));
        }
        let old = self.index.move_to(id, to)?;
        self.get_mut(id).expect("alive").set_pos(to);
        Ok(old)
    }

    /// Living organisms within radius `r` of `center`, sorted by (distance, id).
    pub fn within(&self, center: Cell, r: u32, filter: Option<Kind>) -> Vec<Neighbour> {
        self.index.within(center, r, filter)
    }

    /// Every living organism within radius `r` of `center`, visited once in
    /// **unspecified order** (no allocation, no sort; ADR-029 §3A).
    #[inline]
    pub fn for_each_within(&self, center: Cell, r: u32, filter: Option<Kind>, f: impl FnMut(&Neighbour)) {
        self.index.for_each_within(center, r, filter, f)
    }

    /// Like [`Population::within`], reusing `out`.
    pub fn within_into(&self, center: Cell, r: u32, filter: Option<Kind>, out: &mut Vec<Neighbour>) {
        self.index.within_into(center, r, filter, out)
    }

    /// First living organism in (distance, id) order satisfying `pred`.
    /// `pred` must be pure (see [`SpatialIndex::nearest`]).
    pub fn nearest(&self, center: Cell, r: u32, filter: Option<Kind>, pred: impl FnMut(&Neighbour) -> bool) -> Option<Neighbour> {
        self.index.nearest(center, r, filter, pred)
    }

    /// IDs of living organisms in `cell`, ascending.
    pub fn at(&self, cell: Cell, filter: Option<Kind>) -> Vec<EntityId> {
        self.index.at(cell, filter)
    }

    /// Rebuild the index of all living organisms on `torus` (restore path).
    pub fn rebuild_index(&mut self, torus: Torus) -> Result<(), String> {
        let mut idx = SpatialIndex::new(torus);
        for v in &self.by_kind {
            for o in v.iter().filter(|o| o.alive) {
                idx.insert(o.id, o.kind, o.pos).map_err(|e| format!("organism {}: {e}", o.id.0))?;
            }
        }
        self.index = idx;
        self.rebuild_id_cols();
        Ok(())
    }

    fn living_entries(&self) -> impl Iterator<Item = (EntityId, Kind, Cell)> + '_ {
        self.by_kind.iter().flat_map(|v| v.iter().filter(|o| o.alive).map(|o| (o.id, o.kind, o.pos)))
    }
}

impl Population {
    /// Consistency check used by `Simulation::set_population`: kinds stored in
    /// their own Vec, IDs strictly ascending, unique across kinds, all
    /// `< next_id`, traits/energy/health in range.
    pub fn validate(&self, next_id: u64) -> Result<(), String> {
        let mut all: Vec<EntityId> = Vec::new();
        for kind in Kind::ALL {
            let v = &self.by_kind[kind.index()];
            for (i, o) in v.iter().enumerate() {
                if o.kind != kind {
                    return Err(format!("organism {} of kind {} stored under {}", o.id.0, o.kind.name(), kind.name()));
                }
                if i > 0 && v[i - 1].id >= o.id {
                    return Err(format!("{} IDs not strictly ascending at {}", kind.name(), o.id.0));
                }
                if o.id.0 == 0 || o.id.0 >= next_id {
                    return Err(format!("organism ID {} not in [1, next_id={next_id})", o.id.0));
                }
                if o.genome.kind() != kind || Genome::from_genes(kind, o.genome.genes().to_vec()).is_err() {
                    return Err(format!("organism {} has an invalid genome", o.id.0));
                }
                if o.traits != crate::genome::express(&o.genome, &self.expression) {
                    return Err(format!("organism {} traits differ from its genome's expression", o.id.0));
                }
                if !(o.stride.is_finite() && (0.0..1.0).contains(&o.stride)) || (kind == Kind::Plant && (o.heading.is_some() || o.stride != 0.0)) {
                    return Err(format!("organism {} has invalid movement state", o.id.0));
                }
                if !o.traits.in_range(kind)
                    || !(0.0..=o.traits.max_energy).contains(&o.energy)
                    || !(0.0..=o.traits.max_health).contains(&o.health)
                {
                    return Err(format!("organism {} has out-of-range traits/energy/health", o.id.0));
                }
                all.push(o.id);
            }
        }
        all.sort();
        if all.windows(2).any(|w| w[0] == w[1]) {
            return Err("duplicate organism ID".to_string());
        }
        self.index.check_against(self.living_entries()).map_err(|e| format!("spatial index: {e}"))?;
        let living = self.by_kind.iter().flat_map(|v| v.iter().filter(|o| o.alive).map(|o| (o.kind, o.species)));
        self.species.check(living).map_err(|e| format!("species: {e}"))?;
        Ok(())
    }
}

/// Founder placement under the cell-sharing rule (ADR-016): the drawn cell if
/// it has room, else the first cell with room probing row-major (wrapping)
/// from it; if every cell is full (input overload) the drawn cell.
fn founder_cell(index: &SpatialIndex, cap: u32, kind: Kind, drawn: Cell) -> Cell {
    let t = *index.torus();
    let n = t.cell_count();
    let start = t.index(drawn);
    for k in 0..n {
        let c = t.cell_at((start + k) % n);
        if (index.count_at(c, kind) as u64) < cap as u64 {
            return c;
        }
    }
    drawn
}

impl Population {
    /// Canonical state stream of all organisms (ADR-022 §2).
    pub(crate) fn hash_state(&self, h: &mut crate::digest::StateHasher) {
        let Population {
            by_kind,
            pending,
            totals,
            tick_deaths,
            last_deaths,
            last_births,
            // Derived cache: pure function of the (hashed) configuration.
            expression: _expression,
            // Derived cache: positions of the living organisms (hashed).
            index: _index,
            // Derived cache: from the configuration.
            capacity: _capacity,
            // Derived cache: copy of the hashed IDs (ADR-029 §3C).
            id_cols: _id_cols,
            births_dropped_full,
            species,
        } = self;
        h.section("population");
        for v in by_kind {
            h.len(v.len());
            for o in v {
                h.debug(o);
            }
        }
        h.len(pending.len());
        h.debug(pending);
        h.debug(totals);
        h.u64(*births_dropped_full);
        h.debug(tick_deaths);
        h.debug(last_deaths);
        h.debug(last_births);
        species.hash_state(h);
    }
}

#[cfg(test)]
impl Population {
    /// Test-only mutable totals (hash sensitivity tests).
    /// Whether the derived ID columns mirror `by_kind` exactly (ADR-029 §3C).
    pub(crate) fn id_cols_in_sync_for_test(&self) -> bool {
        self.id_cols.iter().zip(self.by_kind.iter()).all(|(c, v)| c.len() == v.len() && c.iter().zip(v.iter()).all(|(a, o)| *a == o.id))
    }

    pub(crate) fn totals_mut_for_test(&mut self) -> &mut LifeTotals {
        &mut self.totals
    }
    /// Test-only mutable species registry.
    pub(crate) fn species_mut_for_test(&mut self) -> &mut SpeciesRegistry {
        &mut self.species
    }
}

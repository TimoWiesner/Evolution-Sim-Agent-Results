use super::*;
use crate::report::{result_json, run_recorded};
use crate::sim::Simulation;

fn base() -> Value {
    json!({"seed": 1, "world": {"width": 24, "height": 16}, "initial": {"plants": 60, "herbivores": 20, "carnivores": 4}})
}

#[test]
fn parse_seeds_ok_and_errors() {
    assert_eq!(parse_seeds("1,2,3").unwrap(), vec![1, 2, 3]);
    assert_eq!(parse_seeds("0").unwrap(), vec![0]);
    assert_eq!(parse_seeds(" 4, 5").unwrap(), vec![4, 5]);
    for bad in ["", "1,,2", "-1", "x", "1,1", "1.5", "99999999999999999999999", "1,"] {
        assert!(parse_seeds(bad).is_err(), "{bad}");
    }
}

#[test]
fn parse_param_ok_and_errors() {
    let s = parse_param("plants.growth_rate=0.8,1.2").unwrap();
    assert_eq!(s.key, "plants.growth_rate");
    assert_eq!(s.values, vec![json!(0.8), json!(1.2)]);
    assert_eq!(parse_param("a.b=true,\"x\",3").unwrap().values, vec![json!(true), json!("x"), json!(3)]);
    for bad in ["k", "=1", "k=", "seed=1,2", "name=\"a\"", "k=[1]", "k={}", "k=null", "k=1,1", "k=abc", "a..b=1", "k=1,,2"] {
        assert!(parse_param(bad).is_err(), "{bad}");
    }
}

#[test]
fn set_dotted_nested_create_and_error() {
    let mut d = base();
    set_dotted(&mut d, "world.width", json!(30)).unwrap();
    assert_eq!(d["world"]["width"], 30);
    set_dotted(&mut d, "plants.growth_rate", json!(1.5)).unwrap();
    assert_eq!(d["plants"]["growth_rate"], 1.5);
    assert!(set_dotted(&mut d, "seed.x", json!(1)).is_err());
}

#[test]
fn combos_cartesian_first_slowest() {
    let a = Sweep { key: "a".into(), values: vec![json!(1), json!(2)] };
    let b = Sweep { key: "b".into(), values: vec![json!("x"), json!("y"), json!("z")] };
    let c = combos(&[a, b]);
    assert_eq!(c.len(), 6);
    assert_eq!(c[0].params, vec![("a".into(), json!(1)), ("b".into(), json!("x"))]);
    assert_eq!(c[1].params, vec![("a".into(), json!(1)), ("b".into(), json!("y"))]);
    assert_eq!(c[3].params, vec![("a".into(), json!(2)), ("b".into(), json!("x"))]);
    assert_eq!(combos(&[]).len(), 1);
    assert!(combos(&[])[0].params.is_empty());
}

#[test]
fn expand_2x2_order() {
    let sw = vec![parse_param("plants.growth_rate=0.8,1.2").unwrap()];
    let (cs, runs) = expand(&base(), &sw, &[1, 2]).unwrap();
    assert_eq!(cs.len(), 2);
    assert_eq!(runs.len(), 4);
    let got: Vec<(usize, usize, u64, &str, f64)> =
        runs.iter().map(|r| (r.index, r.combo, r.seed, r.file.as_str(), r.config.plants.growth_rate)).collect();
    assert_eq!(
        got,
        vec![
            (0, 0, 1, "combo-0/seed-1.json", 0.8),
            (1, 0, 2, "combo-0/seed-2.json", 0.8),
            (2, 1, 1, "combo-1/seed-1.json", 1.2),
            (3, 1, 2, "combo-1/seed-2.json", 1.2)
        ]
    );
    assert!(runs.iter().all(|r| r.config.seed == r.seed));
    let (_, plain) = expand(&base(), &[], &[3, 1]).unwrap();
    assert_eq!(plain.iter().map(|r| r.file.as_str()).collect::<Vec<_>>(), ["seed-3.json", "seed-1.json"]);
}

#[test]
fn expand_errors() {
    let e = expand(&base(), &[parse_param("nope.key=1,2").unwrap()], &[1]).unwrap_err();
    assert!(e.contains("nope"), "{e}");
    let e = expand(&base(), &[parse_param("plants.growth_rate=-5").unwrap()], &[1]).unwrap_err();
    assert!(e.contains("plants.growth_rate"), "{e}");
    let e = expand(&base(), &[parse_param("world.width=\"wide\"").unwrap()], &[1]).unwrap_err();
    assert!(e.contains("world.width"), "{e}");
    let a = parse_param("world.width=20,30").unwrap();
    assert!(expand(&base(), &[a.clone(), a], &[1]).is_err());
    assert!(expand(&base(), &[], &[]).is_err());
    let big = Sweep { key: "world.width".into(), values: (1..=101).map(Value::from).collect() };
    let seeds: Vec<u64> = (0..100).collect();
    assert!(expand(&base(), &[big], &seeds).unwrap_err().contains("10000"));
}

fn outcome(index: usize, combo: usize, fin: [u64; 3], ext: [Option<u64>; 3]) -> RunOutcome {
    RunOutcome {
        index,
        combo,
        seed: index as u64,
        file: format!("seed-{index}.json"),
        tick_start: 0,
        tick_end: 100,
        final_counts: fin,
        species: [1, 1, if fin[2] > 0 { 1 } else { 0 }],
        births: [10, 4, 2],
        deaths: [5, 3, 2],
        extinction_tick: ext,
        state_hash: "ab".into(),
        elapsed_seconds: 0.5,
        ticks_per_second: 200.0,
    }
}

fn meta(sweeps: Vec<Sweep>) -> BatchMeta {
    BatchMeta { config_file: "c.json".into(), ticks: 100, sample_every: 1, seeds: vec![0, 1], sweeps, wall_seconds: 1.0, jobs: 2 }
}

#[test]
fn aggregates_on_synthetic_outcomes() {
    let sw = vec![Sweep { key: "a".into(), values: vec![json!(1), json!(2)] }];
    let cs = combos(&sw);
    let os = vec![
        outcome(0, 0, [10, 4, 2], [None, None, None]),
        outcome(1, 0, [20, 6, 0], [None, None, Some(40)]),
        outcome(2, 1, [30, 0, 0], [None, Some(70), Some(20)]),
        outcome(3, 1, [40, 2, 1], [None, None, None]),
    ];
    let s = summary_json(&meta(sw.clone()), &cs, &os);
    let all = &s["aggregates"]["all"];
    assert_eq!(all["runs"], 4);
    assert_eq!(all["coexistence_runs"], 2);
    assert_eq!(all["coexistence_fraction"], 0.5);
    let p = &all["kinds"]["plants"];
    assert_eq!(p["final"]["mean"], 25.0);
    assert_eq!(p["final"]["min"], 10);
    assert_eq!(p["final"]["max"], 40);
    assert_eq!(p["final"]["median"], 25.0);
    assert!((p["final"]["sd"].as_f64().unwrap() - 125f64.sqrt()).abs() < 1e-12);
    assert_eq!(p["extinct_runs"], 0);
    assert_eq!(p["extinction_tick"], Value::Null);
    let c = &all["kinds"]["carnivores"];
    assert_eq!(c["extinct_runs"], 2);
    assert_eq!(c["extinct_fraction"], 0.5);
    assert_eq!(c["extinction_tick"]["mean"], 30.0);
    assert_eq!(c["extinction_tick"]["min"], 20);
    assert_eq!(c["final"]["mean"], 0.75);
    assert_eq!(all["kinds"]["herbivores"]["extinct_runs"], 1);
    let bc = s["aggregates"]["by_combo"].as_array().unwrap();
    assert_eq!(bc.len(), 2);
    assert_eq!(bc[1]["params"]["a"], 2);
    assert_eq!(bc[1]["kinds"]["plants"]["final"]["mean"], 35.0);
    assert_eq!(bc[0]["kinds"]["carnivores"]["extinct_runs"], 1);
    let runs = s["runs"].as_array().unwrap();
    assert_eq!(runs.len(), 4);
    assert_eq!(runs[2]["params"]["a"], 2);
    assert_eq!(runs[2]["ticks"], 100);
    assert_eq!(runs[2]["extinct"]["herbivores"], true);
    assert_eq!(runs[2]["extinction_tick"]["herbivores"], 70);
    assert_eq!(s["timing"]["jobs"], 2);
    assert_eq!(s["format"], SUMMARY_FORMAT);
    // CSV: header + 4 rows; aggregates: (1 + 2 groups) x 3 kinds.
    let csv = summary_csv(&sw, &cs, &os);
    let lines: Vec<&str> = csv.lines().collect();
    assert_eq!(lines.len(), 5);
    assert!(lines[0].starts_with("index,combo,seed,a,ticks,final_plants,"));
    assert!(lines[0].ends_with(",coexistence,state_hash,elapsed_seconds,ticks_per_second"));
    assert!(lines[3].starts_with("2,1,2,2,100,30,0,0,"));
    let n_cols = lines[0].split(',').count();
    assert!(lines.iter().all(|l| l.split(',').count() == n_cols));
    let agg = aggregates_csv(&sw, &s);
    let al: Vec<&str> = agg.lines().collect();
    assert_eq!(al.len(), 1 + 9);
    assert!(al[1].starts_with("all,,plants,4,25.0,10,40,"));
    assert!(al[7].starts_with("combo-1,2,plants,2,35.0,30,40,"));
}

#[test]
fn stats_median_odd_even() {
    assert_eq!(stats(&[3, 1, 2]).unwrap()["median"], 2.0);
    assert_eq!(stats(&[4, 1]).unwrap()["median"], 2.5);
    assert!(stats(&[]).is_none());
}

#[test]
fn csv_quoting() {
    assert_eq!(csv_field("abc"), "abc");
    assert_eq!(csv_field("a,b"), "\"a,b\"");
    assert_eq!(csv_field("say \"hi\""), "\"say \"\"hi\"\"\"");
    assert_eq!(csv_field("x\ny"), "\"x\ny\"");
    assert_eq!(csv_value(&json!("a,b")), "\"a,b\"");
    assert_eq!(csv_value(&Value::Null), "");
    assert_eq!(csv_value(&json!(true)), "true");
}

fn real_batch(elapsed: f64) -> Value {
    let sw = vec![parse_param("plants.growth_rate=0.8,1.2").unwrap()];
    let (cs, specs) = expand(&base(), &sw, &[1, 2]).unwrap();
    let os: Vec<RunOutcome> = specs
        .iter()
        .map(|s| {
            let mut sim = Simulation::new(s.config.clone()).unwrap();
            let rec = run_recorded(&mut sim, 30, 10);
            RunOutcome::from_result(s, &result_json(&sim, &rec, elapsed)).unwrap()
        })
        .collect();
    let mut m = meta(sw);
    m.ticks = 30;
    m.sample_every = 10;
    m.wall_seconds = elapsed * 9.0;
    summary_json(&m, &cs, &os)
}

#[test]
fn summary_without_time_is_deterministic() {
    let a = real_batch(0.25);
    let b = real_batch(0.75);
    assert_ne!(a, b, "time keys differ");
    assert_eq!(strip_time(&a), strip_time(&b));
    let runs = a["runs"].as_array().unwrap();
    assert_eq!(runs.len(), 4);
    assert!(runs.iter().all(|r| r["ticks"] == 30));
    // Different seeds -> different hashes within a combination.
    assert_ne!(runs[0]["state_hash"], runs[1]["state_hash"]);
}

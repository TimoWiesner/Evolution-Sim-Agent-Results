//! Entity identifiers (ADR-008). IDs are unique `u64`s allocated
//! monotonically from 1 (0 is reserved as "none") and never reused, so
//! ascending `EntityId` is a stable tie-break order for organisms.

/// Unique, never reused organism identifier.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize, serde::Deserialize)]
pub struct EntityId(pub u64);

/// Monotonic ID allocator.
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct IdAllocator {
    next: u64,
}

impl Default for IdAllocator {
    fn default() -> Self {
        Self::new()
    }
}

impl IdAllocator {
    /// First allocated ID is 1.
    pub fn new() -> Self {
        IdAllocator { next: 1 }
    }

    /// Continue allocation at `next` (checkpoint restore). `0` is mapped to 1.
    pub fn from_next(next: u64) -> Self {
        IdAllocator { next: next.max(1) }
    }

    /// Allocate the next ID. Panics on u64 exhaustion (unreachable in practice).
    pub fn alloc(&mut self) -> EntityId {
        let id = self.next;
        self.next = id.checked_add(1).expect("EntityId space exhausted");
        EntityId(id)
    }

    /// The value the next `alloc()` will return.
    pub fn peek_next(&self) -> u64 {
        self.next
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn allocator_starts_at_one_and_increases() {
        let mut a = IdAllocator::new();
        assert_eq!(a.peek_next(), 1);
        let ids: Vec<EntityId> = (0..10).map(|_| a.alloc()).collect();
        assert_eq!(ids[0], EntityId(1));
        assert!(ids.windows(2).all(|w| w[0] < w[1]));
        assert_eq!(a.peek_next(), 11);
        let mut b = IdAllocator::from_next(a.peek_next());
        assert_eq!(b.alloc(), a.alloc());
        assert_eq!(IdAllocator::from_next(0).peek_next(), 1);
    }
}

//! Torus-periodic value noise (ADR-009). The lattice tiles the world exactly,
//! and lattice indices wrap modulo the lattice size, so the field is
//! continuous across both seams.

use crate::rng::Rng;

/// Smooth bilinear value noise on a `gx × gy` periodic lattice, values in [-1, 1].
#[derive(Debug, Clone, PartialEq)]
pub struct PeriodicNoise {
    gx: u32,
    gy: u32,
    v: Vec<f64>,
}

/// Lattice size along one axis: `max(1, round(dim / scale))` in integer math.
pub fn lattice_size(dim: u32, scale: u32) -> u32 {
    let scale = scale.max(1) as u64;
    (((dim as u64) + scale / 2) / scale).max(1) as u32
}

fn smoothstep(t: f64) -> f64 {
    t * t * (3.0 - 2.0 * t)
}

/// Splits a lattice coordinate into (i0, i1, smoothed fraction) with wrapping.
fn axis(f: f64, g: u32) -> (usize, usize, f64) {
    let gf = g as f64;
    let f = f.rem_euclid(gf);
    let fl = f.floor();
    let mut i0 = fl as u32;
    if i0 >= g {
        i0 = 0; // rem_euclid may round up to exactly g
    }
    let t = (f - fl).clamp(0.0, 1.0);
    let i1 = (i0 + 1) % g;
    (i0 as usize, i1 as usize, smoothstep(t))
}

impl PeriodicNoise {
    /// Lattice for a `width × height` world with feature size `scale` cells;
    /// draws `gx·gy` values row-major from `rng`.
    pub fn new(width: u32, height: u32, scale: u32, rng: &mut Rng) -> PeriodicNoise {
        let gx = lattice_size(width, scale);
        let gy = lattice_size(height, scale);
        let n = gx as usize * gy as usize;
        let v = (0..n).map(|_| 2.0 * rng.next_f64() - 1.0).collect();
        PeriodicNoise { gx, gy, v }
    }

    pub fn lattice(&self) -> (u32, u32) {
        (self.gx, self.gy)
    }

    fn at(&self, i: usize, j: usize) -> f64 {
        self.v[j * self.gx as usize + i]
    }

    /// Value at lattice coordinates (periodic with periods gx, gy).
    pub fn sample(&self, fx: f64, fy: f64) -> f64 {
        let (x0, x1, tx) = axis(fx, self.gx);
        let (y0, y1, ty) = axis(fy, self.gy);
        let a = self.at(x0, y0) + (self.at(x1, y0) - self.at(x0, y0)) * tx;
        let b = self.at(x0, y1) + (self.at(x1, y1) - self.at(x0, y1)) * tx;
        a + (b - a) * ty
    }

    /// Value at continuous cell coordinates (cell (x, y) centre = (x, y)),
    /// periodic with periods `width`, `height`.
    pub fn at_cell(&self, cx: f64, cy: f64, width: u32, height: u32) -> f64 {
        let fx = (cx + 0.5) * self.gx as f64 / width as f64;
        let fy = (cy + 0.5) * self.gy as f64 / height as f64;
        self.sample(fx, fy)
    }
}

impl PeriodicNoise {
    /// All-zero lattice for a `width × height` world (no draws).
    pub fn zeros(width: u32, height: u32, scale: u32) -> PeriodicNoise {
        let gx = lattice_size(width, scale);
        let gy = lattice_size(height, scale);
        PeriodicNoise { gx, gy, v: vec![0.0; gx as usize * gy as usize] }
    }

    /// Lattice from explicit row-major values; `None` if the length does not
    /// match the lattice size for (width, height, scale).
    pub fn from_values(width: u32, height: u32, scale: u32, v: Vec<f64>) -> Option<PeriodicNoise> {
        let gx = lattice_size(width, scale);
        let gy = lattice_size(height, scale);
        (v.len() == gx as usize * gy as usize).then_some(PeriodicNoise { gx, gy, v })
    }

    /// Lattice node values, row-major.
    pub fn values(&self) -> &[f64] {
        &self.v
    }

    pub fn values_mut(&mut self) -> &mut [f64] {
        &mut self.v
    }
}

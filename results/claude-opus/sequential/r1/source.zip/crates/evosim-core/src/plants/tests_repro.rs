//! TASK-012 tests (ADR-015): reproduction threshold and cost, dispersal
//! within the radius across the wrapping edges, inheritance with mutation,
//! parents and generation, site check (room / resources), plants only from
//! plants.

use super::*;
use crate::config::Config;
use crate::genome::{distance, gene_index, Expression, GeneTrait, Genome};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRecord, DeathCause, BirthRequest, Kind, Parents, Population};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Torus};

/// Reproduction-only test configuration: seed_rate 1 (p = 1 for the default
/// fertility 0.5), no pollination, no mutation, roomy cells.
fn repro_cfg() -> Config {
    let mut c = Config::new(1, 16, 12, 0, 0, 0).pre_task018();
    c.plants.seed_rate = 1.0;
    c.plants.pollination_enabled = false;
    c.plants.mutation_rate = 0.0;
    c.plants.max_per_cell = 64;
    c
}

struct Bench {
    torus: Torus,
    pop: Population,
    res: CellResources,
    ids: IdAllocator,
    rng: Rng,
    tick: u64,
}

impl Bench {
    fn new(w: u32, h: u32, cap: f64) -> Bench {
        let torus = Torus::new(w, h).unwrap();
        let mut pop = Population::with_expression(Expression::default(), torus);
        pop.set_capacity(crate::organism::CellCapacity::from_config(&Config::new(1, 1, 1, 0, 0, 0).pre_task018()));
        Bench { torus, pop, res: CellResources::new(&torus, cap), ids: IdAllocator::new(), rng: Rng::seed_from_u64(99), tick: 0 }
    }

    /// Add plants (genome, cell, energy) as founders; returns their IDs.
    fn add(&mut self, plants: &[(Genome, Cell, f64)]) -> Vec<EntityId> {
        for (g, c, e) in plants {
            self.pop.request_birth(BirthRequest { pos: *c, parents: Parents::None, energy: *e, health: None, genome: g.clone() });
        }
        self.pop.resolve_births(self.tick, &mut self.ids).iter().map(|r| r.id).collect()
    }

    /// One reproduction step and the Births phase; returns (tick totals, births).
    fn step(&mut self, cfg: &Config) -> (ReproTick, Vec<BirthRecord>) {
        // The population's capacity is THE cell-sharing rule (ADR-016).
        self.pop.set_capacity(crate::organism::CellCapacity::from_config(cfg));
        let r = reproduce_plants(&mut self.pop, &self.res, &self.torus, cfg, &mut self.rng, self.tick);
        let b = self.pop.resolve_births(self.tick, &mut self.ids);
        self.tick += 1;
        (r, b)
    }

    fn energy(&self, id: EntityId) -> f64 {
        self.pop.get_alive(id).unwrap().energy()
    }

    fn set_energy(&mut self, id: EntityId, e: f64) {
        self.pop.get_alive_mut(id).unwrap().set_energy(e);
    }
}

fn g0() -> Genome {
    Genome::founder_default(Kind::Plant)
}

fn c(x: u32, y: u32) -> Cell {
    Cell { x, y }
}

// ---------- AC1: only with enough energy; reproduction costs energy ----------

#[test]
fn no_reproduction_below_threshold() {
    let cfg = repro_cfg();
    let mut b = Bench::new(16, 12, 10.0);
    let ids = b.add(&[(g0(), c(3, 3), cfg.plants.reproduction_threshold - 0.01), (g0(), c(8, 8), 1.0)]);
    let before = b.rng.state();
    for _ in 0..50 {
        let (r, births) = b.step(&cfg);
        assert_eq!(r, ReproTick::default());
        assert!(births.is_empty());
    }
    assert_eq!(b.rng.state(), before, "no eligible plant → no RNG draws");
    assert!((b.energy(ids[0]) - (cfg.plants.reproduction_threshold - 0.01)).abs() < 1e-12);
    assert_eq!(b.energy(ids[1]), 1.0);
}

#[test]
fn seed_rate_zero_disables_reproduction_without_draws() {
    let mut cfg = repro_cfg();
    cfg.plants.seed_rate = 0.0;
    let mut b = Bench::new(16, 12, 10.0);
    b.add(&[(g0(), c(3, 3), 20.0)]);
    let before = b.rng.state();
    let (r, births) = b.step(&cfg);
    assert_eq!(r, ReproTick::default());
    assert!(births.is_empty());
    assert_eq!(b.rng.state(), before);
}

#[test]
fn reproduction_costs_energy() {
    let cfg = repro_cfg();
    let p = &cfg.plants;
    let mut b = Bench::new(16, 12, 10.0);
    let id = b.add(&[(g0(), c(5, 5), 15.0)])[0];
    let (r, births) = b.step(&cfg);
    assert_eq!((r.made, r.requested, r.failed), (1, 1, 0));
    assert!((b.energy(id) - (15.0 - p.reproduction_cost)).abs() < 1e-12, "parent paid the cost");
    assert!((r.spent - p.reproduction_cost).abs() < 1e-12);
    assert_eq!(births.len(), 1);
    let child = b.pop.get_alive(births[0].id).unwrap();
    let expect = p.initial_energy.min(p.reproduction_cost);
    assert!((child.energy() - expect).abs() < 1e-12, "child energy {}", child.energy());
    assert!(child.energy() <= r.spent + 1e-12, "no energy created");
    // Parent now below threshold (15 - 6 = 9 < 12): no further seeds.
    let (r2, births2) = b.step(&cfg);
    assert_eq!(r2.made, 0);
    assert!(births2.is_empty());

    // A cheap seed gets at most its cost as energy.
    let mut cheap = repro_cfg();
    cheap.plants.reproduction_cost = 2.0;
    let mut b = Bench::new(16, 12, 10.0);
    b.add(&[(g0(), c(5, 5), 15.0)]);
    let (r, births) = b.step(&cheap);
    assert!((r.seed_energy - 2.0).abs() < 1e-12);
    assert!((b.pop.get_alive(births[0].id).unwrap().energy() - 2.0).abs() < 1e-12);
}

#[test]
fn ledger_reproduction_balances() {
    let c0 = Config::new(11, 32, 24, 200, 0, 0);
    let mut sim = Simulation::new(c0).unwrap();
    for _ in 0..200 {
        let mut before = 0.0;
        let mut seed_e = 0.0;
        sim.step_with(|ctx| match ctx.phase {
            Phase::Resources => before = ctx.world.organisms().alive(Kind::Plant).map(|o| o.energy()).sum(),
            Phase::Plants => {
                let after: f64 = ctx.world.organisms().stored(Kind::Plant).iter().map(|o| o.energy()).sum();
                let l = ctx.world.plant_ledger();
                let de = after - before;
                assert!((de - (l.last_uptake - l.last_upkeep - l.last_reproduction_spent)).abs() < 1e-9, "de {de}");
                assert!(l.last_seed_energy <= l.last_reproduction_spent + 1e-12);
                seed_e = l.last_seed_energy;
            }
            Phase::Births => {
                let pop = ctx.world.organisms();
                let newborn: f64 = pop.last_births().iter().filter(|r| r.kind == Kind::Plant).map(|r| pop.get(r.id).unwrap().energy()).sum();
                assert!(newborn <= seed_e + 1e-9, "newborn energy {newborn} > seed energy {seed_e}");
                assert!(pop.last_births().len() as u32 <= ctx.world.plant_ledger().last_seeds_requested);
            }
            _ => {}
        });
    }
    let l = sim.world().plant_ledger();
    assert!(l.seeds_made > 0 && l.reproduction_spent > 0.0, "{l:?}");
    assert!(l.seed_energy <= l.reproduction_spent);
    assert!(sim.totals().births_of(Kind::Plant) <= l.seeds_requested);
    assert_eq!(l.seeds_made, l.seeds_failed + l.seeds_requested);
}

// ---------- AC2: within the dispersal distance, also across edges ----------

#[test]
fn offspring_within_dispersal_radius() {
    let mut rng = Rng::seed_from_u64(5);
    for &(w, h) in &[(1, 1), (3, 3), (5, 4), (16, 12), (40, 30)] {
        let t = Torus::new(w, h).unwrap();
        for r in 0..=4u32 {
            for k in 0..400u32 {
                let from = c(k % w, (k / w) % h);
                let to = dispersal_target(&t, from, r, &mut rng);
                assert!(t.contains(to));
                assert!(t.distance(from, to) <= r, "{w}x{h} r={r} {from:?}->{to:?}");
            }
        }
    }
    // Uniform square: all 49 offsets of radius 3 are reachable on a big world.
    let t = Torus::new(40, 30).unwrap();
    let mut seen = std::collections::BTreeSet::new();
    for _ in 0..5000 {
        let to = dispersal_target(&t, c(20, 15), 3, &mut rng);
        let o = t.offset(c(20, 15), to);
        seen.insert((o.dx, o.dy));
    }
    assert_eq!(seen.len(), 49);
    // Through the full reproduction path as well.
    let mut cfg = repro_cfg();
    cfg.plants.dispersal_radius = 2;
    let mut b = Bench::new(16, 12, 10.0);
    let id = b.add(&[(g0(), c(7, 6), 20.0)])[0];
    for _ in 0..100 {
        b.set_energy(id, 20.0);
        for rec in b.step(&cfg).1 {
            assert!(b.torus.distance(c(7, 6), rec.pos) <= 2);
        }
    }
}

#[test]
fn dispersal_crosses_edges() {
    let cfg = repro_cfg();
    for &corner in &[c(0, 0), c(15, 11)] {
        let mut b = Bench::new(16, 12, 10.0);
        let id = b.add(&[(g0(), corner, 20.0)])[0];
        let mut wrapped_x = 0;
        let mut wrapped_y = 0;
        let mut n = 0;
        for _ in 0..200 {
            b.set_energy(id, 20.0);
            for rec in b.step(&cfg).1 {
                n += 1;
                assert!(b.torus.distance(corner, rec.pos) <= 3, "{corner:?} -> {:?}", rec.pos);
                if corner.x == 0 && rec.pos.x >= 13 || corner.x == 15 && rec.pos.x <= 2 {
                    wrapped_x += 1;
                }
                if corner.y == 0 && rec.pos.y >= 9 || corner.y == 11 && rec.pos.y <= 2 {
                    wrapped_y += 1;
                }
            }
        }
        assert_eq!(n, 200);
        assert!(wrapped_x > 20 && wrapped_y > 20, "{corner:?}: wrapped x {wrapped_x}, y {wrapped_y}");
    }
}

#[test]
fn radius_zero_stays_in_cell() {
    let mut cfg = repro_cfg();
    cfg.plants.dispersal_radius = 0;
    let mut b = Bench::new(16, 12, 10.0);
    let id = b.add(&[(g0(), c(4, 9), 20.0)])[0];
    for _ in 0..30 {
        b.set_energy(id, 20.0);
        let (_, births) = b.step(&cfg);
        assert_eq!(births.len(), 1);
        assert_eq!(births[0].pos, c(4, 9));
    }
}

// ---------- AC3: inherit the genome with mutation; parent ID, generation ----------

#[test]
fn offspring_inherit_mutated_genome() {
    // Without mutation: exact copy, one parent, generation + 1, grandchild 2.
    let cfg = repro_cfg();
    let mut g = g0().genes().to_vec();
    g[gene_index(Kind::Plant, GeneTrait::TempOptimum).unwrap()] = 0.3;
    let mother = Genome::from_genes(Kind::Plant, g).unwrap();
    let mut b = Bench::new(16, 12, 10.0);
    let pid = b.add(&[(mother.clone(), c(2, 2), 20.0)])[0];
    let (_, births) = b.step(&cfg);
    assert_eq!(births[0].parents, Parents::One(pid));
    assert_eq!(births[0].generation, 1);
    let child = b.pop.get_alive(births[0].id).unwrap();
    assert_eq!(child.genome(), &mother);
    assert_eq!(child.parents(), Parents::One(pid));
    assert_eq!(child.generation(), 1);
    let cid = child.id();
    b.set_energy(pid, 0.0);
    b.set_energy(cid, 20.0);
    let (_, births) = b.step(&cfg);
    assert_eq!(births.len(), 1);
    assert_eq!(births[0].parents, Parents::One(cid));
    assert_eq!(b.pop.get_alive(births[0].id).unwrap().generation(), 2);

    // With mutation: genes differ, but the child stays close to the parent.
    let mut mcfg = repro_cfg();
    mcfg.plants.mutation_rate = 1.0;
    mcfg.plants.mutation_strength = 0.05;
    let mut b = Bench::new(16, 12, 10.0);
    let pid = b.add(&[(mother.clone(), c(2, 2), 20.0)])[0];
    let mut differ = 0;
    for _ in 0..20 {
        b.set_energy(pid, 20.0);
        let (_, births) = b.step(&mcfg);
        let ch = b.pop.get_alive(births[0].id).unwrap();
        assert_eq!(ch.parents(), Parents::One(pid));
        assert_eq!(ch.generation(), 1);
        let d = distance(&mother, ch.genome());
        assert!(d < 0.15, "distance {d}");
        if d > 0.0 {
            differ += 1;
        }
        // Traits are expressed from the mutated genome.
        assert_eq!(*ch.traits(), crate::genome::express(ch.genome(), b.pop.expression()));
    }
    assert_eq!(differ, 20, "every child mutated with rate 1");
}

#[test]
fn pollination_records_both_parents() {
    let mut cfg = repro_cfg();
    cfg.plants.pollination_enabled = true;
    cfg.plants.pollination_chance = 1.0;
    cfg.plants.pollen_radius = 2;
    let mother = g0();
    let mut dg = g0().genes().to_vec();
    for i in [0usize, 2, 4] {
        dg[i] = (dg[i] + 0.2).min(1.0);
    }
    let donor = Genome::from_genes(Kind::Plant, dg).unwrap();
    assert!(distance(&mother, &donor) <= cfg.plants.species_threshold);
    let mut b = Bench::new(16, 12, 10.0);
    let ids = b.add(&[(mother.clone(), c(5, 5), 20.0), (donor.clone(), c(6, 6), 1.0)]);
    let mut mixed = false;
    for _ in 0..20 {
        b.set_energy(ids[0], 20.0);
        let (r, births) = b.step(&cfg);
        assert_eq!(r.pollinated, 1);
        assert_eq!(births[0].parents, Parents::Two(ids[0], ids[1]));
        let ch = b.pop.get_alive(births[0].id).unwrap();
        assert_eq!(ch.generation(), 1);
        for (i, &x) in ch.genome().genes().iter().enumerate() {
            assert!(x == mother.genes()[i] || x == donor.genes()[i]);
        }
        mixed |= ch.genome() != &mother && ch.genome() != &donor;
        // Remove the child so it cannot become the nearest donor next time.
        let cid = births[0].id;
        assert!(b.pop.kill(cid, DeathCause::OldAge, b.tick));
    }
    assert!(mixed, "crossover mixes both genomes");

    // Donor out of pollen range, incompatible donor, or pollination off → one parent.
    let mut far = Bench::new(16, 12, 10.0);
    let ids = far.add(&[(mother.clone(), c(5, 5), 20.0), (donor.clone(), c(9, 5), 1.0)]);
    assert_eq!(far.step(&cfg).1[0].parents, Parents::One(ids[0]));

    let mut ig = g0().genes().to_vec();
    for x in ig.iter_mut() {
        *x = 1.0;
    }
    let alien = Genome::from_genes(Kind::Plant, ig).unwrap();
    assert!(distance(&mother, &alien) > cfg.plants.species_threshold);
    let mut inc = Bench::new(16, 12, 10.0);
    let ids = inc.add(&[(mother.clone(), c(5, 5), 20.0), (alien, c(5, 5), 1.0)]);
    assert_eq!(inc.step(&cfg).1[0].parents, Parents::One(ids[0]));

    let mut off = cfg.clone();
    off.plants.pollination_enabled = false;
    let mut b = Bench::new(16, 12, 10.0);
    let ids = b.add(&[(mother, c(5, 5), 20.0), (donor, c(5, 5), 1.0)]);
    assert_eq!(b.step(&off).1[0].parents, Parents::One(ids[0]));
}

// ---------- AC4: no offspring without room or resources ----------

#[test]
fn no_offspring_in_full_cell() {
    let mut cfg = repro_cfg();
    cfg.plants.max_per_cell = 4;
    let mut b = Bench::new(1, 1, 10.0);
    let ids = b.add(&[(g0(), c(0, 0), 20.0), (g0(), c(0, 0), 20.0), (g0(), c(0, 0), 20.0), (g0(), c(0, 0), 20.0)]);
    let (r, births) = b.step(&cfg);
    assert_eq!((r.made, r.failed, r.requested), (4, 4, 0));
    assert!(births.is_empty());
    assert_eq!(b.pop.count_alive(Kind::Plant), 4);
    for id in ids {
        assert!((b.energy(id) - (20.0 - cfg.plants.reproduction_cost)).abs() < 1e-12, "failed seed still costs energy");
    }
}

#[test]
fn accepted_seeds_respect_capacity_in_same_tick() {
    let mut cfg = repro_cfg();
    cfg.plants.max_per_cell = 4;
    let mut b = Bench::new(1, 1, 10.0);
    b.add(&[(g0(), c(0, 0), 20.0), (g0(), c(0, 0), 20.0), (g0(), c(0, 0), 20.0)]);
    let (r, births) = b.step(&cfg);
    assert_eq!((r.made, r.requested, r.failed), (3, 1, 2));
    assert_eq!(births.len(), 1);
    assert_eq!(b.pop.count_alive(Kind::Plant), 4);
    // Radius 0 on a big world: same rule per cell.
    let mut cfg0 = cfg.clone();
    cfg0.plants.dispersal_radius = 0;
    cfg0.plants.max_per_cell = 2;
    let mut b = Bench::new(8, 8, 10.0);
    b.add(&[(g0(), c(3, 3), 20.0), (g0(), c(3, 3), 20.0)]);
    let (r, births) = b.step(&cfg0);
    assert_eq!((r.made, r.requested), (2, 0));
    assert!(births.is_empty());
}

#[test]
fn capacity_holds_in_long_run() {
    let c0 = Config::new(17, 24, 18, 120, 0, 0);
    let cap = c0.plants.max_per_cell as usize;
    let mut sim = Simulation::new(c0).unwrap();
    let mut births = 0usize;
    for _ in 0..300 {
        sim.step_with(|ctx| {
            if ctx.phase == Phase::Births {
                let pop = ctx.world.organisms();
                for r in pop.last_births() {
                    births += 1;
                    let n = pop.at(r.pos, Some(Kind::Plant)).len();
                    assert!(n <= cap, "cell {:?} holds {n} plants after a birth", r.pos);
                }
            }
        });
    }
    assert!(births > 0);
}

#[test]
fn no_offspring_without_resources() {
    let mut cfg = repro_cfg();
    cfg.plants.dispersal_radius = 1;
    let mut b = Bench::new(5, 5, 10.0);
    for cell in b.torus.cells().collect::<Vec<_>>() {
        b.res.set(cell, 0.5); // < seed_min_resource 1.0
    }
    let id = b.add(&[(g0(), c(2, 2), 20.0)])[0];
    for _ in 0..30 {
        b.set_energy(id, 20.0);
        let (r, births) = b.step(&cfg);
        assert_eq!(r.failed, 1);
        assert!(births.is_empty());
    }
    // Only the one cell with resource receives offspring.
    b.res.set(c(3, 2), 5.0);
    let mut n = 0;
    for _ in 0..90 {
        b.set_energy(id, 20.0);
        for rec in b.step(&cfg).1 {
            assert_eq!(rec.pos, c(3, 2));
            n += 1;
        }
    }
    assert!(n > 0);
}

// ---------- AC5: plants only come from plants ----------

#[test]
fn zero_plants_stay_zero() {
    for cfg in [Config::new(3, 32, 24, 0, 30, 5), Config::new(4, 32, 24, 0, 0, 0)] {
        let mut sim = Simulation::new(cfg).unwrap();
        for _ in 0..1000 {
            sim.step();
            assert_eq!(sim.organisms().count_alive(Kind::Plant), 0);
            assert_eq!(sim.totals().births_of(Kind::Plant), 0);
        }
        assert_eq!(sim.world().plant_ledger().seeds_made, 0);
    }
    // After all plants died, none come back.
    let mut c0 = Config::new(5, 16, 12, 80, 0, 0);
    c0.plants.resource_cap = 0.0;
    let mut sim = Simulation::new(c0).unwrap();
    let mut t = 0;
    while sim.organisms().count_alive(Kind::Plant) > 0 {
        sim.step();
        t += 1;
        assert!(t < 2000, "plants should starve without resources");
    }
    let births = sim.totals().births_of(Kind::Plant);
    for _ in 0..200 {
        sim.step();
        assert_eq!(sim.organisms().count_alive(Kind::Plant), 0);
    }
    assert_eq!(sim.totals().births_of(Kind::Plant), births);
}

// ---------- spread, persistence, determinism ----------

#[test]
fn plants_spread_and_persist() {
    let c0 = Config::new(42, 64, 48, 400, 0, 0);
    let mut sim = Simulation::new(c0).unwrap();
    let occupied = |s: &Simulation| s.organisms().alive(Kind::Plant).map(|o| o.pos()).collect::<std::collections::BTreeSet<_>>().len();
    let start = occupied(&sim);
    sim.run(600);
    let end = occupied(&sim);
    let max_gen = sim.organisms().alive(Kind::Plant).map(|o| o.generation()).max().unwrap_or(0);
    let alive = sim.organisms().count_alive(Kind::Plant);
    eprintln!("spread: occupied {start} -> {end}, alive {alive}, births {}, max generation {max_gen}", sim.totals().births_of(Kind::Plant));
    assert!(sim.totals().births_of(Kind::Plant) > 0);
    assert!(max_gen >= 2, "max generation {max_gen}");
    assert!(alive > 0, "plants persist for 600 ticks (max_age 300)");
    assert!(end > start, "occupied cells {start} -> {end}");
}

#[test]
fn reproduction_is_deterministic() {
    let c0 = Config::new(8, 24, 18, 150, 0, 0);
    let mut a = Simulation::new(c0.clone()).unwrap();
    let mut b = Simulation::new(c0).unwrap();
    a.run(150);
    b.run(150);
    assert_eq!(a.organisms(), b.organisms());
    assert_eq!(a.world().plant_ledger(), b.world().plant_ledger());
    assert_eq!(a.rng_state(), b.rng_state());
    assert!(a.world().plant_ledger().seeds_requested > 0);
}

#[test]
fn seed_probability_scales_with_fertility() {
    let cfg = repro_cfg();
    let mut p = cfg.plants.clone();
    p.seed_rate = 0.4;
    let mut t = crate::organism::Traits::founder_default(Kind::Plant, &cfg);
    t.fertility = 0.5;
    assert!((seed_probability(&t, &p) - 0.4).abs() < 1e-12);
    t.fertility = 1.0;
    assert!((seed_probability(&t, &p) - 0.6).abs() < 1e-12);
    t.fertility = 0.0;
    assert!((seed_probability(&t, &p) - 0.2).abs() < 1e-12);
    p.seed_rate = 1.0;
    t.fertility = 1.0;
    assert_eq!(seed_probability(&t, &p), 1.0);
}

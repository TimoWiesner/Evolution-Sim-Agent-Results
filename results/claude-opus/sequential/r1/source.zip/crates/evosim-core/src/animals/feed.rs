//! Herbivore feeding, metabolism and climate cost (TASK-014, ADR-017).
//!
//! Pure functions (no RNG): bite size, metabolism with thermal stress,
//! satiety/need, best plant in reach / in sight, the bite itself (the reach
//! guarantee `distance <= FEED_REACH` lives in [`eat`]) and the flight test.

use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Organism, Population, Traits};
use crate::spatial::Neighbour;

/// Feeding reach in cells (toroidal Chebyshev): own cell + 8 neighbours.
pub const FEED_REACH: u32 = 1;
/// Share of `max_meal` a plant of strength 1 withholds from a bite.
pub const PLANT_TOUGHNESS: f64 = 0.5;
/// Default of `herbivores.graze_reserve` (ADR-021): share of a plant's max
/// energy no bite can take (protected root reserve, independent of aggression).
pub const GRAZE_RESERVE: f64 = 0.35;
/// Satiety of an aggression-0 herbivore as share of its max energy.
pub const SATIETY_BASE: f64 = 0.6;
/// A bite is worth taking without moving if ≥ this share of `min(max_meal, need)`.
pub const GOOD_ENOUGH: f64 = 0.5;
/// Cap of the thermal stress `s_T`.
pub const CLIMATE_STRESS_MAX: f64 = 2.0;
/// Extra metabolism of a maximal temperature generalist.
pub const GENERALIST_METABOLISM: f64 = 0.2;
/// A plant at or below this energy after a bite is grazed to death.
pub const GRAZED_EPS: f64 = 1e-9;

/// Herbivore feeding parameters (from `herbivores.*`).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FeedParams {
    pub max_meal: f64,
    pub assimilation: f64,
    pub base_metabolism: f64,
    pub climate_cost: f64,
    /// Protected plant reserve as share of the plant's max energy (ADR-021).
    pub graze_reserve: f64,
}

impl FeedParams {
    pub fn from_config(cfg: &Config) -> FeedParams {
        let h = &cfg.herbivores;
        FeedParams { max_meal: h.max_meal, assimilation: h.assimilation, base_metabolism: h.base_metabolism, climate_cost: h.climate_cost, graze_reserve: h.graze_reserve }
    }
}

/// Thermal stress `clamp(|T − opt| / tol − 1, 0, CLIMATE_STRESS_MAX)`: 0
/// inside the tolerance band, growing outside it (extreme cold or heat).
pub fn thermal_stress(t: &Traits, temperature: f64) -> f64 {
    let tol = t.temp_tolerance.max(1e-9);
    let s = (temperature - t.temp_optimum).abs() / tol - 1.0;
    if s.is_finite() {
        s.clamp(0.0, CLIMATE_STRESS_MAX)
    } else {
        CLIMATE_STRESS_MAX
    }
}

/// Energy burnt per tick at rest:
/// `base · (1 + climate_cost · s_T) · (1 + GENERALIST_METABOLISM · clamp((tol − 2)/28, 0, 1))`.
pub fn metabolic_cost(t: &Traits, temperature: f64, p: &FeedParams) -> f64 {
    let generalist = ((t.temp_tolerance - 2.0) / 28.0).clamp(0.0, 1.0);
    p.base_metabolism * (1.0 + p.climate_cost * thermal_stress(t, temperature)) * (1.0 + GENERALIST_METABOLISM * generalist)
}

/// Energy level at which a herbivore stops eating:
/// `(SATIETY_BASE + (1 − SATIETY_BASE)·aggression) · max_energy`.
pub fn satiety(t: &Traits) -> f64 {
    (SATIETY_BASE + (1.0 - SATIETY_BASE) * t.aggression.clamp(0.0, 1.0)) * t.max_energy
}

/// Plant energy wanted to reach satiety: `max(0, satiety − E) / assimilation`
/// (0 when assimilation is 0).
pub fn need(energy: f64, t: &Traits, p: &FeedParams) -> f64 {
    if p.assimilation <= 0.0 {
        return 0.0;
    }
    (satiety(t) - energy).max(0.0) / p.assimilation
}

/// Plant energy `herb` would take from `plant` in one bite (ADR-017, reserve
/// ADR-021): `min(max_meal·(1 − PLANT_TOUGHNESS·s_P), e_P − graze_reserve·max_P, need)`, ≥ 0.
/// Aggression only acts through satiety ([`need`]).
pub fn bite_size(herb: &Organism, plant: &Organism, p: &FeedParams) -> f64 {
    let ht = herb.traits();
    let pt = plant.traits();
    let cap = p.max_meal * (1.0 - PLANT_TOUGHNESS * pt.strength.clamp(0.0, 1.0));
    let reserve = p.graze_reserve.clamp(0.0, 1.0) * pt.max_energy;
    let edible = (plant.energy() - reserve).max(0.0);
    let b = cap.min(edible).min(need(herb.energy(), ht, p));
    if b.is_finite() {
        b.max(0.0)
    } else {
        0.0
    }
}

/// The plant within [`FEED_REACH`] of `herb_id` with the largest bite (ties:
/// distance, id) as `(plant, bite, distance)`.
pub fn best_in_reach(pop: &Population, herb_id: EntityId, p: &FeedParams) -> Option<(EntityId, f64, u32)> {
    let h = pop.get_alive(herb_id)?;
    let mut best: Option<(EntityId, f64, u32)> = None;
    // Unsorted visit (ADR-029 §3A): the maximum with the total tie-break
    // (distance, id) is order-independent; bites are finite (never NaN).
    pop.for_each_within(h.pos(), FEED_REACH, Some(Kind::Plant), |n| {
        let Some(pl) = pop.get_alive_of(Kind::Plant, n.id) else { return };
        let b = bite_size(h, pl, p);
        let better = match best {
            None => true,
            Some((bid, bb, bd)) => b > bb || (b == bb && (n.distance, n.id) < (bd, bid)),
        };
        if better {
            best = Some((n.id, b, n.distance));
        }
    });
    best
}

/// The visible plant at distance in `[FEED_REACH+1, r]` maximising
/// `bite/(1+d)` with `bite ≥ threshold` (ties: distance, id).
pub fn best_visible(pop: &Population, herb_id: EntityId, r: u32, threshold: f64, p: &FeedParams) -> Option<Neighbour> {
    let h = pop.get_alive(herb_id)?;
    let mut best: Option<(Neighbour, f64)> = None;
    // Unsorted visit (ADR-029 §3A): the maximum with the total tie-break
    // (distance, id) is order-independent; scores are finite (never NaN).
    pop.for_each_within(h.pos(), r, Some(Kind::Plant), |n| {
        if n.distance <= FEED_REACH {
            return;
        }
        let Some(pl) = pop.get_alive_of(Kind::Plant, n.id) else { return };
        let b = bite_size(h, pl, p);
        if b <= 0.0 || b < threshold {
            return;
        }
        let score = b / (1.0 + n.distance as f64);
        let better = match &best {
            None => true,
            Some((bn, bs)) => score > *bs || (score == *bs && (n.distance, n.id) < (bn.distance, bn.id)),
        };
        if better {
            best = Some((*n, score));
        }
    });
    best.map(|(n, _)| n)
}

/// Result of one bite.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Bite {
    /// Energy removed from the plant.
    pub taken: f64,
    /// Energy gained by the herbivore (≤ taken).
    pub gained: f64,
    pub plant_died: bool,
    pub distance: u32,
}

/// `herb_id` bites `plant_id`. Refused (zero bite) unless both are alive,
/// the plant is a plant and lies within [`FEED_REACH`] — the reach guarantee.
/// The plant loses exactly `taken`; the herbivore gains
/// `add_energy(assimilation·taken) ≤ taken`; a plant left at ≤ GRAZED_EPS is
/// killed with `DeathCause::Grazed`.
pub fn eat(pop: &mut Population, herb_id: EntityId, plant_id: EntityId, p: &FeedParams, tick: u64) -> Bite {
    let (Some(h), Some(pl)) = (pop.get_alive(herb_id), pop.get_alive(plant_id)) else { return Bite::default() };
    if pl.kind() != Kind::Plant || h.kind() == Kind::Plant {
        return Bite::default();
    }
    let distance = pop.index().torus().distance(h.pos(), pl.pos());
    if distance > FEED_REACH {
        return Bite { distance, ..Bite::default() };
    }
    let want = bite_size(h, pl, p);
    if want <= 0.0 {
        return Bite { distance, ..Bite::default() };
    }
    let plant = pop.get_alive_mut(plant_id).expect("alive");
    let taken = plant.spend_energy(want);
    let left = plant.energy();
    let gained = pop.get_alive_mut(herb_id).expect("alive").add_energy(p.assimilation.clamp(0.0, 1.0) * taken);
    let plant_died = left <= GRAZED_EPS && pop.kill(plant_id, DeathCause::Grazed, tick);
    Bite { taken, gained, plant_died, distance }
}

/// Flight test: flee iff `caution · danger > (1 − caution) · hunger`.
pub fn flee_decision(caution: f64, danger: f64, hunger: f64) -> bool {
    let c = caution.clamp(0.0, 1.0);
    c * danger > (1.0 - c) * hunger
}

/// Feeding summary of one Herbivores phase.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct FeedTick {
    /// Herbivores that took a bite.
    pub eaters: u64,
    pub bites: u64,
    /// Plant energy removed.
    pub taken: f64,
    /// Energy gained by herbivores (≤ taken).
    pub gained: f64,
    /// Energy burnt by metabolism (incl. climate cost).
    pub metabolism: f64,
    pub starved: u64,
    pub grazed_dead: u64,
    pub fled: u64,
    pub rested: u64,
    /// Largest distance herbivore → plant of any bite this tick (≤ FEED_REACH).
    pub max_bite_distance: u32,
}

impl FeedTick {
    pub fn record_bite(&mut self, b: &Bite) {
        if b.taken <= 0.0 {
            return;
        }
        self.eaters += 1;
        self.bites += 1;
        self.taken += b.taken;
        self.gained += b.gained;
        self.grazed_dead += b.plant_died as u64;
        self.max_bite_distance = self.max_bite_distance.max(b.distance);
    }
}

/// Cumulative herbivore feeding audit plus the last phase.
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct HerbivoreLedger {
    pub bites: u64,
    pub taken: f64,
    pub gained: f64,
    pub metabolism: f64,
    pub starved: u64,
    pub grazed_dead: u64,
    pub fled: u64,
    pub max_bite_distance: u32,
    pub last: FeedTick,
}

impl HerbivoreLedger {
    pub fn record(&mut self, t: &FeedTick) {
        self.bites += t.bites;
        self.taken += t.taken;
        self.gained += t.gained;
        self.metabolism += t.metabolism;
        self.starved += t.starved;
        self.grazed_dead += t.grazed_dead;
        self.fled += t.fled;
        self.max_bite_distance = self.max_bite_distance.max(t.max_bite_distance);
        self.last = *t;
    }
}

//! Soil resource per cell (ADR-014): `R ∈ [0, cap]`, the only source of
//! plant energy.

use crate::climate::CellNow;
use crate::config::PlantParams;
use crate::topology::{Cell, Torus};

/// Relative moisture `clamp(P / max_precipitation, 0, 1)` (0 if the maximum is 0).
pub fn moisture(precipitation: f64, max_precipitation: f64) -> f64 {
    if max_precipitation > 0.0 && precipitation.is_finite() {
        (precipitation / max_precipitation).clamp(0.0, 1.0)
    } else {
        0.0
    }
}

/// Soil resource of every cell, row-major.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct CellResources {
    width: u32,
    cap: f64,
    values: Vec<f64>,
}

impl CellResources {
    /// Every cell starts full (`R = cap`).
    pub fn new(torus: &Torus, cap: f64) -> CellResources {
        let cap = if cap.is_finite() { cap.max(0.0) } else { 0.0 };
        let n = torus.width() as usize * torus.height() as usize;
        CellResources { width: torus.width(), cap, values: vec![cap; n] }
    }

    pub fn cap(&self) -> f64 {
        self.cap
    }

    fn idx(&self, c: Cell) -> usize {
        c.y as usize * self.width as usize + c.x as usize
    }

    /// Resource of a cell inside the world.
    pub fn get(&self, c: Cell) -> f64 {
        self.values[self.idx(c)]
    }

    /// All values, row-major.
    /// Grid width the values are laid out for (checkpoint checks).
    pub(crate) fn width(&self) -> u32 {
        self.width
    }

    pub fn values(&self) -> &[f64] {
        &self.values
    }

    pub fn total(&self) -> f64 {
        self.values.iter().sum()
    }

    /// Set a cell (clamped into `[0, cap]`; tests and restore, TASK-022).
    #[cfg_attr(not(test), allow(dead_code))]
    pub(crate) fn set(&mut self, c: Cell, v: f64) {
        let i = self.idx(c);
        self.values[i] = if v.is_finite() { v.clamp(0.0, self.cap) } else { 0.0 };
    }

    pub(crate) fn values_mut(&mut self) -> &mut [f64] {
        &mut self.values
    }

    /// Resources phase: `R ← min(cap, R + regen·m)` per cell; returns the
    /// total amount actually added.
    pub fn regenerate(&mut self, now: &[CellNow], params: &PlantParams, max_precipitation: f64) -> f64 {
        debug_assert_eq!(now.len(), self.values.len());
        let regen = if params.resource_regen.is_finite() { params.resource_regen.max(0.0) } else { 0.0 };
        let mut added = 0.0;
        for (r, cn) in self.values.iter_mut().zip(now) {
            let m = moisture(cn.precipitation, max_precipitation);
            let new = (*r + regen * m).min(self.cap);
            if new > *r {
                added += new - *r;
                *r = new;
            }
        }
        added
    }
}

//! Fixed tick phase order and organism acting order (ADR-008).

use crate::ids::EntityId;
use crate::rng::Rng;

/// One step inside a tick. The order is fixed by [`Phase::ORDER`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Phase {
    /// Season / weather update (TASK-006/007).
    Climate,
    /// Cell resources regenerate (TASK-011).
    Resources,
    /// Plant growth, ageing, seeding (TASK-011/012). Acting phase.
    Plants,
    /// Herbivores sense, move, eat, mate (TASK-013..016). Acting phase.
    Herbivores,
    /// Carnivores sense, move, hunt, mate (TASK-015..016). Acting phase.
    Carnivores,
    /// Reproduction resolution; newborns get IDs in emission order.
    Births,
    /// Removal of organisms flagged dead (order-preserving compaction).
    Deaths,
    /// Species bookkeeping, extinction ticks (TASK-017).
    Species,
    /// Counters / series sampling (TASK-018).
    Statistics,
}

impl Phase {
    /// The binding order of phases inside every tick.
    pub const ORDER: [Phase; 9] = [
        Phase::Climate,
        Phase::Resources,
        Phase::Plants,
        Phase::Herbivores,
        Phase::Carnivores,
        Phase::Births,
        Phase::Deaths,
        Phase::Species,
        Phase::Statistics,
    ];

    /// Stable lowercase name (logs, JSON).
    pub fn name(self) -> &'static str {
        match self {
            Phase::Climate => "climate",
            Phase::Resources => "resources",
            Phase::Plants => "plants",
            Phase::Herbivores => "herbivores",
            Phase::Carnivores => "carnivores",
            Phase::Births => "births",
            Phase::Deaths => "deaths",
            Phase::Species => "species",
            Phase::Statistics => "statistics",
        }
    }

    /// Phases in which organisms act in shuffled order.
    pub fn is_acting(self) -> bool {
        matches!(self, Phase::Plants | Phase::Herbivores | Phase::Carnivores)
    }
}

/// Acting order for one acting phase: the IDs sorted ascending (canonical,
/// independent of input order), then Fisher–Yates shuffled with the core RNG.
/// The result is a pure function of (RNG state, set of IDs). IDs must be
/// unique. Lists of length 0 or 1 consume no draws.
pub fn acting_order(ids: &[EntityId], rng: &mut Rng) -> Vec<EntityId> {
    let mut out = Vec::with_capacity(ids.len());
    acting_order_into(ids, rng, &mut out);
    out
}

/// Buffer-reusing variant of [`acting_order`]; `out` is cleared first.
pub fn acting_order_into(ids: &[EntityId], rng: &mut Rng, out: &mut Vec<EntityId>) {
    out.clear();
    out.extend_from_slice(ids);
    out.sort_unstable();
    debug_assert!(out.windows(2).all(|w| w[0] < w[1]), "duplicate EntityId");
    rng.shuffle(out);
}

/// Stable tie-break comparison for any ordering by a key: key first, then
/// ascending `EntityId`. (Cells tie-break by `Cell`'s derived order (y, x).)
pub fn cmp_key_then_id<K: Ord>(a: &(K, EntityId), b: &(K, EntityId)) -> std::cmp::Ordering {
    a.0.cmp(&b.0).then(a.1.cmp(&b.1))
}

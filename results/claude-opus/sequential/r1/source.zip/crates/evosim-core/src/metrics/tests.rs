use super::*;
use crate::config::Config;
use crate::genome::Genome;
use crate::ids::IdAllocator;
use crate::organism::{BirthRequest, Parents, TraitRanges};
use crate::report::{run_observed, run_recorded};
use crate::topology::{Cell, Torus};

const EPS: f64 = 1e-12;

fn close(a: f64, b: f64) {
    assert!((a - b).abs() < EPS, "{a} != {b}");
}

#[test]
fn stat_on_hand_values() {
    let s = Stat::of(&[1.0, 2.0, 3.0]).unwrap();
    close(s.mean, 2.0);
    close(s.sd, (2.0f64 / 3.0).sqrt());
    close(s.min, 1.0);
    close(s.max, 3.0);
    let s = Stat::of(&[5.0]).unwrap();
    assert_eq!((s.mean, s.sd, s.min, s.max), (5.0, 0.0, 5.0, 5.0));
    assert_eq!(Stat::of(&[]), None);
    let s = Stat::of(&[2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0]).unwrap();
    close(s.mean, 5.0);
    close(s.sd, 2.0);
    assert_eq!((s.min, s.max), (2.0, 9.0));
}

#[test]
fn trait_values_follow_trait_names() {
    let t = Traits {
        speed: 1.0,
        strength: 2.0,
        fertility: 3.0,
        max_health: 4.0,
        max_lifespan: 5,
        max_energy: 6.0,
        vision: 7.0,
        aggression: 8.0,
        caution: 9.0,
        temp_optimum: 10.0,
        temp_tolerance: 11.0,
    };
    assert_eq!(trait_values(&t), [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0]);
    assert_eq!(TRAIT_NAMES[4], "max_lifespan");
    assert_eq!(TRAIT_NAMES[10], "temp_tolerance");
}

/// 3 plants, 2 herbivores, 1 carnivore; founder variation 0 → every kind's
/// founders share one genome → exactly one founder species per kind.
fn hand_world() -> (Population, IdAllocator) {
    let mut c = Config::new(5, 6, 6, 3, 2, 1);
    c.plants.founder_variation = 0.0;
    c.herbivores.founder_variation = 0.0;
    c.carnivores.founder_variation = 0.0;
    let torus = Torus::new(6, 6).unwrap();
    let mut ids = IdAllocator::new();
    let mut p = Population::founders(&c, &torus, &mut ids);
    let h = p.alive_ids(Kind::Herbivore);
    for (id, speed, gen, energy, age) in [(h[0], 1.0, 0, 10.0, 4), (h[1], 3.0, 2, 30.0, 6)] {
        let o = p.get_alive_mut(id).unwrap();
        let mut t = *o.traits();
        t.speed = speed;
        t.max_energy = 100.0;
        o.set_traits_for_test(t);
        o.set_generation_for_test(gen);
        o.set_energy(energy);
        o.set_age_for_test(age);
    }
    (p, ids)
}

#[test]
fn hand_world_values() {
    let (mut p, mut ids) = hand_world();
    let mut m = MetricsRecorder::new();

    // Sample 0: founders only.
    m.record_population(0, &p);
    let s = &m.samples()[0];
    assert_eq!(s.tick, 0);
    assert_eq!(s.kinds.each_ref().map(|k| k.count), [3, 2, 1]);
    for k in &s.kinds {
        assert_eq!((k.births, k.deaths, k.births_total, k.deaths_total), (0, 0, 0, 0));
        assert_eq!(k.deaths_by_cause, [0; 6]);
        assert_eq!((k.species_living, k.species_appeared, k.species_extinct), (1, 1, 0));
    }
    let h = &s.kinds[1];
    let speed = h.traits[0].unwrap();
    assert_eq!((speed.mean, speed.sd, speed.min, speed.max), (2.0, 1.0, 1.0, 3.0));
    assert_eq!((h.generation_max, h.generation_mean), (Some(2), Some(1.0)));
    let e = h.energy.unwrap();
    assert_eq!((e.mean, e.sd, e.min, e.max), (20.0, 10.0, 10.0, 30.0));
    let a = h.age.unwrap();
    assert_eq!((a.mean, a.sd, a.min, a.max), (5.0, 1.0, 4.0, 6.0));
    // Founder plants share one genome: every plant trait has sd 0, age 0.
    let pl = &s.kinds[0];
    assert!(pl.traits.iter().all(|t| t.unwrap().sd == 0.0));
    assert_eq!((pl.generation_max, pl.generation_mean), (Some(0), Some(0.0)));
    assert_eq!(pl.age.unwrap().max, 0.0);

    // Tick 1: one plant grazed, the carnivore starves, one plant birth.
    let plants = p.alive_ids(Kind::Plant);
    let carn = p.alive_ids(Kind::Carnivore)[0];
    assert!(p.kill(plants[0], DeathCause::Grazed, 1));
    assert!(p.kill(carn, DeathCause::Starvation, 1));
    let parent = plants[1];
    let genome: Genome = p.get_alive(parent).unwrap().genome().clone();
    let pos = (0..36).map(|i| Cell { x: i % 6, y: i / 6 }).find(|&c| p.has_room(c, Kind::Plant)).unwrap();
    p.request_birth(BirthRequest { pos, parents: Parents::One(parent), energy: 1.0, health: None, genome });
    assert_eq!(p.resolve_births(1, &mut ids).len(), 1);
    m.record_population(1, &p);
    let s = &m.samples()[1];
    let [pl, h, c] = &s.kinds;
    assert_eq!((pl.count, pl.births, pl.deaths, pl.births_total, pl.deaths_total), (3, 1, 1, 1, 1));
    assert_eq!(pl.deaths_by_cause, [0, 0, 0, 0, 1, 0]); // grazed
    assert_eq!((pl.generation_max, pl.species_living, pl.species_appeared), (Some(1), 1, 1));
    // generations 0, 0, 1 → mean 1/3
    close(pl.generation_mean.unwrap(), 1.0 / 3.0);
    assert_eq!((h.count, h.births, h.deaths), (2, 0, 0));
    assert_eq!((c.count, c.deaths, c.deaths_total), (0, 1, 1));
    assert_eq!(c.deaths_by_cause, [0, 1, 0, 0, 0, 0]); // starvation
    assert_eq!((c.species_living, c.species_appeared, c.species_extinct), (0, 1, 1));
    assert_eq!((c.generation_max, c.generation_mean), (None, None));
    assert!(c.traits.iter().all(Option::is_none));
    assert_eq!((c.energy, c.age), (None, None));

    // Tick 2: herbivore A (speed 1, gen 0) is preyed upon.
    let ha = p.alive_ids(Kind::Herbivore)[0];
    assert!(p.kill(ha, DeathCause::Predation, 2));
    m.record_population(2, &p);
    let [pl, h, c] = &m.samples()[2].kinds;
    assert_eq!((pl.births, pl.deaths, pl.births_total), (0, 0, 1));
    assert_eq!((h.count, h.deaths, h.deaths_total), (1, 1, 1));
    assert_eq!(h.deaths_by_cause, [0, 0, 0, 1, 0, 0]); // predation
    let speed = h.traits[0].unwrap();
    assert_eq!((speed.mean, speed.sd, speed.min, speed.max), (3.0, 0.0, 3.0, 3.0));
    assert_eq!((h.generation_max, h.generation_mean), (Some(2), Some(2.0)));
    assert_eq!((c.deaths, c.deaths_total), (0, 1));
    assert_eq!(c.deaths_by_cause, [0; 6]);
    assert_eq!(c.deaths_by_cause_total, [0, 1, 0, 0, 0, 0]);
}

#[test]
fn json_document_shape() {
    let (mut p, _) = hand_world();
    let mut m = MetricsRecorder::new();
    m.record_population(0, &p);
    let carn = p.alive_ids(Kind::Carnivore)[0];
    p.kill(carn, DeathCause::Climate, 3);
    m.record_population(3, &p);
    let rec = RunRecord { tick_start: 0, tick_end: 3, sample_every: 3, series: Vec::new(), extinction_tick: [None; 3] };
    let v = m.to_json(5, &rec);
    assert_eq!(v["format"], "evosim-metrics");
    assert_eq!(v["format_version"], 1);
    assert_eq!(v["seed"], 5);
    assert_eq!(v["kinds"], json!(["plants", "herbivores", "carnivores"]));
    assert_eq!(v["traits"].as_array().unwrap().len(), 11);
    assert_eq!(
        v["death_causes"],
        json!(["old_age", "starvation", "injury", "predation", "grazed", "climate"])
    );
    let samples = v["samples"].as_array().unwrap();
    assert_eq!(samples.len(), 2);
    assert_eq!(samples[1]["tick"], 3);
    for s in samples {
        for key in KIND_KEYS {
            let k = s[key].as_object().unwrap();
            for f in [
                "count", "births", "deaths", "births_total", "deaths_total", "deaths_by_cause",
                "deaths_by_cause_total", "species", "generation", "traits", "energy", "age",
            ] {
                assert!(k.contains_key(f), "{key}.{f}");
            }
            assert_eq!(k["deaths_by_cause"].as_object().unwrap().len(), 6);
            assert_eq!(k["traits"].as_object().unwrap().len(), 11);
        }
    }
    let c = &samples[1]["carnivores"];
    assert_eq!(c["count"], 0);
    assert_eq!(c["deaths_by_cause"]["climate"], 1);
    assert_eq!(c["generation"]["max"], Value::Null);
    assert_eq!(c["traits"]["speed"], Value::Null);
    assert_eq!(c["energy"], Value::Null);
    assert_eq!(samples[0]["herbivores"]["traits"]["speed"]["sd"], 1.0);
    // Serialises and parses back (all numbers finite).
    let text = serde_json::to_string(&v).unwrap();
    let back: Value = serde_json::from_str(&text).unwrap();
    assert_eq!(back, v);
}

#[test]
fn recording_does_not_change_state_hash() {
    let cfg = Config::new(3, 16, 12, 40, 10, 3);
    let mut a = Simulation::new(cfg.clone()).unwrap();
    let mut b = Simulation::new(cfg).unwrap();
    let mut m = MetricsRecorder::new();
    let ra = run_observed(&mut a, 300, 1, |s| m.record(s));
    let rb = run_recorded(&mut b, 300, 1);
    assert_eq!(a.state_hash(), b.state_hash());
    assert_eq!(ra, rb);
    assert_eq!(m.samples().len(), ra.series.len());
}

#[test]
fn invariants_over_a_real_run() {
    let mut sim = Simulation::new(Config::new(11, 24, 16, 120, 30, 6)).unwrap();
    let mut m = MetricsRecorder::new();
    let rec = run_observed(&mut sim, 400, 7, |s| m.record(s));
    let samples = m.samples();
    assert_eq!(samples.len(), rec.series.len());
    let initial = sim.totals().initial;
    for (s, p) in samples.iter().zip(&rec.series) {
        assert_eq!(s.tick, p.tick);
        for k in Kind::ALL {
            let ks = &s.kinds[k.index()];
            assert_eq!(ks.count, p.counts[k.index()]);
            assert_eq!(initial[k.index()] + ks.births_total - ks.deaths_total, ks.count);
            assert_eq!(ks.deaths_by_cause.iter().sum::<u64>(), ks.deaths);
            assert_eq!(ks.deaths_by_cause_total.iter().sum::<u64>(), ks.deaths_total);
            assert!(ks.species_living + ks.species_extinct == ks.species_appeared);
            if ks.count > 0 {
                assert!(ks.generation_max.unwrap() as f64 >= ks.generation_mean.unwrap());
                let r = TraitRanges::for_kind(k);
                let ranges = [
                    (r.speed.lo, r.speed.hi),
                    (r.strength.lo, r.strength.hi),
                    (r.fertility.lo, r.fertility.hi),
                    (r.max_health.lo, r.max_health.hi),
                    (r.max_lifespan.0 as f64, r.max_lifespan.1 as f64),
                    (r.max_energy.lo, r.max_energy.hi),
                    (r.vision.lo, r.vision.hi),
                    (r.aggression.lo, r.aggression.hi),
                    (r.caution.lo, r.caution.hi),
                    (r.temp_optimum.lo, r.temp_optimum.hi),
                    (r.temp_tolerance.lo, r.temp_tolerance.hi),
                ];
                for (st, (lo, hi)) in ks.traits.iter().zip(ranges) {
                    let st = st.unwrap();
                    assert!(st.min >= lo && st.max <= hi && st.min <= st.mean && st.mean <= st.max + 1e-9);
                    assert!(st.sd >= 0.0 && st.sd.is_finite());
                }
            } else {
                assert!(ks.traits.iter().all(Option::is_none));
            }
        }
    }
    for k in Kind::ALL {
        let i = k.index();
        let first = &samples[0].kinds[i];
        let last = samples.last().unwrap().kinds[i].clone();
        let sb: u64 = samples.iter().map(|s| s.kinds[i].births).sum();
        let sd: u64 = samples.iter().map(|s| s.kinds[i].deaths).sum();
        assert_eq!(sb, last.births_total - first.births_total);
        assert_eq!(sd, last.deaths_total - first.deaths_total);
        assert_eq!(last.births_total, sim.totals().births[i]);
        assert_eq!(last.species_living, sim.organisms().species().living_count(k) as u64);
    }
}

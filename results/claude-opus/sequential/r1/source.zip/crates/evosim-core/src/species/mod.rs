//! Species classification and family tree (TASK-017, ADR-020).
//!
//! **THE species rule.** Each species keeps the genome of its first member as
//! immutable representative. An organism is classified exactly once, when it
//! is created, and never re-assigned:
//! - founder: first root species of its kind (ascending ID) with
//!   `distance(g, rep) <= T_kind`, else a new root species;
//! - newborn with mother species `M` (species of the first stored parent):
//!   `distance(child, rep(M)) <= T_kind` joins `M` (exactly at the threshold
//!   stays); else the first *living* daughter `D` of `M` with
//!   `distance(child, rep(D)) <= T_kind`; else a new daughter species of `M`
//!   founded at the birth tick.
//!
//! `T_kind = <kind>.species_threshold`. A species whose last member dies gets
//! `extinct_tick` = tick of that death and can never gain members again.
//! IDs are one global sequential counter from 1 in creation order; names are
//! a pure function of (kind, root ID, ID). No RNG is used.

mod names;

#[cfg(test)]
mod tests;
#[cfg(test)]
mod tests_sim;

pub use names::{genus_suffix, species_code, species_name, syllable_word, SYLLABLES};

use crate::config::Config;
use crate::genome::{distance, Genome};
use crate::organism::Kind;

/// Species identifier (global, sequential from 1, never reused).
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize, serde::Deserialize)]
pub struct SpeciesId(pub u32);

/// One species of the family tree.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SpeciesRecord {
    id: SpeciesId,
    kind: Kind,
    name: String,
    parent: Option<SpeciesId>,
    root: SpeciesId,
    origin_tick: u64,
    extinct_tick: Option<u64>,
    representative: Genome,
    living: u64,
    ever: u64,
    daughters: Vec<SpeciesId>,
}

impl SpeciesRecord {
    pub fn id(&self) -> SpeciesId {
        self.id
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    /// Binomial name (see [`species_name`]).
    pub fn name(&self) -> &str {
        &self.name
    }
    /// Short code, e.g. `"H3"`.
    pub fn code(&self) -> String {
        species_code(self.kind, self.id)
    }
    /// Species it split from (`None` for root species founded at tick 0).
    pub fn parent(&self) -> Option<SpeciesId> {
        self.parent
    }
    /// Root ancestor (itself for a root species).
    pub fn root(&self) -> SpeciesId {
        self.root
    }
    /// Tick the species arose (its first member was created).
    pub fn origin_tick(&self) -> u64 {
        self.origin_tick
    }
    /// Tick its last living member died; `None` while it has members.
    pub fn extinct_tick(&self) -> Option<u64> {
        self.extinct_tick
    }
    pub fn is_extinct(&self) -> bool {
        self.extinct_tick.is_some()
    }
    /// Immutable genome of the first member.
    pub fn representative(&self) -> &Genome {
        &self.representative
    }
    /// Currently living members.
    pub fn living(&self) -> u64 {
        self.living
    }
    /// Members ever created.
    pub fn ever(&self) -> u64 {
        self.ever
    }
    /// Direct daughter species, ascending ID.
    pub fn daughters(&self) -> &[SpeciesId] {
        &self.daughters
    }
    /// Alive at the end of tick `t` (`origin <= t` and not extinct by `t`).
    pub fn alive_at(&self, t: u64) -> bool {
        self.origin_tick <= t && self.extinct_tick.is_none_or(|e| e > t)
    }
}

/// Species change of the current tick (journal, emitted in the Species phase).
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub enum SpeciesChange {
    Appeared { id: SpeciesId, kind: Kind, parent: Option<SpeciesId>, tick: u64 },
    Extinct { id: SpeciesId, kind: Kind, tick: u64 },
}

/// All species ever recognised (index = id − 1).
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SpeciesRegistry {
    records: Vec<SpeciesRecord>,
    thresholds: [f64; 3],
    living_per_kind: [u64; 3],
    journal: Vec<SpeciesChange>,
}

impl Default for SpeciesRegistry {
    fn default() -> Self {
        SpeciesRegistry::with_thresholds([0.15; 3])
    }
}

impl SpeciesRegistry {
    /// Empty registry with per-kind thresholds (index `Kind::index()`).
    pub fn with_thresholds(thresholds: [f64; 3]) -> SpeciesRegistry {
        SpeciesRegistry { records: Vec::new(), thresholds, living_per_kind: [0; 3], journal: Vec::new() }
    }

    /// Empty registry with `<kind>.species_threshold` of `cfg`.
    pub fn from_config(cfg: &Config) -> SpeciesRegistry {
        SpeciesRegistry::with_thresholds([cfg.plants.species_threshold, cfg.herbivores.species_threshold, cfg.carnivores.species_threshold])
    }

    /// Threshold `T_kind` in force.
    pub fn threshold(&self, kind: Kind) -> f64 {
        self.thresholds[kind.index()]
    }

    /// Replace the thresholds (tests; affects only future classifications).
    pub fn set_thresholds(&mut self, thresholds: [f64; 3]) {
        self.thresholds = thresholds;
    }

    pub fn get(&self, id: SpeciesId) -> Option<&SpeciesRecord> {
        (id.0 as usize).checked_sub(1).and_then(|i| self.records.get(i))
    }

    fn rec_mut(&mut self, id: SpeciesId) -> &mut SpeciesRecord {
        &mut self.records[id.0 as usize - 1]
    }

    /// All records in ascending ID (creation) order.
    pub fn iter(&self) -> impl Iterator<Item = &SpeciesRecord> {
        self.records.iter()
    }

    /// Number of species ever recognised (all kinds).
    pub fn len(&self) -> usize {
        self.records.len()
    }

    pub fn is_empty(&self) -> bool {
        self.records.is_empty()
    }

    /// Records of one kind, ascending ID.
    pub fn of_kind(&self, kind: Kind) -> impl Iterator<Item = &SpeciesRecord> {
        self.records.iter().filter(move |r| r.kind == kind)
    }

    /// Species of `kind` with living members now (O(1)).
    pub fn living_count(&self, kind: Kind) -> usize {
        self.living_per_kind[kind.index()] as usize
    }

    /// Species of `kind` alive at the end of tick `t` (from the records).
    pub fn living_count_at(&self, kind: Kind, t: u64) -> usize {
        self.of_kind(kind).filter(|r| r.alive_at(t)).count()
    }

    /// `id`, its parent, ..., up to the root (empty if unknown).
    pub fn lineage(&self, id: SpeciesId) -> Vec<SpeciesId> {
        let mut out = Vec::new();
        let mut cur = self.get(id).map(|r| r.id);
        while let Some(c) = cur {
            out.push(c);
            cur = self.get(c).and_then(|r| r.parent);
        }
        out
    }

    fn create(&mut self, kind: Kind, parent: Option<SpeciesId>, g: &Genome, tick: u64) -> SpeciesId {
        let id = SpeciesId(self.records.len() as u32 + 1);
        let root = match parent {
            Some(p) => self.get(p).map(|r| r.root).unwrap_or(id),
            None => id,
        };
        self.records.push(SpeciesRecord {
            id,
            kind,
            name: species_name(kind, root, id),
            parent,
            root,
            origin_tick: tick,
            extinct_tick: None,
            representative: g.clone(),
            living: 0,
            ever: 0,
            daughters: Vec::new(),
        });
        if let Some(p) = parent {
            self.rec_mut(p).daughters.push(id);
        }
        self.journal.push(SpeciesChange::Appeared { id, kind, parent, tick });
        id
    }

    fn join(&mut self, id: SpeciesId) -> SpeciesId {
        let r = self.rec_mut(id);
        if r.living == 0 {
            // Only a just-created species can be joined with 0 members.
            let k = r.kind.index();
            r.living = 1;
            r.ever += 1;
            self.living_per_kind[k] += 1;
        } else {
            r.living += 1;
            r.ever += 1;
        }
        id
    }

    /// Classify a founder (rule step 1) and count it as a member.
    pub(crate) fn classify_founder(&mut self, g: &Genome, tick: u64) -> SpeciesId {
        let kind = g.kind();
        let t = self.threshold(kind);
        let found = self.records.iter().find(|r| r.kind == kind && r.parent.is_none() && !r.is_extinct() && distance(g, &r.representative) <= t).map(|r| r.id);
        let id = match found {
            Some(id) => id,
            None => self.create(kind, None, g, tick),
        };
        self.join(id)
    }

    /// Classify a newborn whose first parent belongs to `mother` (rule step 2)
    /// and count it as a member. An unknown/extinct/other-kind `mother` falls
    /// back to founder classification (cannot happen for real births).
    pub(crate) fn classify_child(&mut self, mother: SpeciesId, g: &Genome, tick: u64) -> SpeciesId {
        let kind = g.kind();
        let t = self.threshold(kind);
        let Some(m) = self.get(mother).filter(|r| r.kind == kind && !r.is_extinct()) else {
            return self.classify_founder(g, tick);
        };
        if distance(g, &m.representative) <= t {
            return self.join(mother);
        }
        let daughter = m.daughters.iter().copied().find(|&d| self.get(d).is_some_and(|r| r.living > 0 && distance(g, &r.representative) <= t));
        let id = match daughter {
            Some(d) => d,
            None => self.create(kind, Some(mother), g, tick),
        };
        self.join(id)
    }

    /// A member of `id` died in `tick`; the last one makes the species extinct.
    pub(crate) fn on_death(&mut self, id: SpeciesId, tick: u64) {
        let Some(i) = (id.0 as usize).checked_sub(1).filter(|&i| i < self.records.len()) else { return };
        let r = &mut self.records[i];
        if r.living == 0 {
            return;
        }
        r.living -= 1;
        if r.living == 0 {
            r.extinct_tick = Some(tick);
            let (kind, id) = (r.kind, r.id);
            self.living_per_kind[kind.index()] -= 1;
            self.journal.push(SpeciesChange::Extinct { id, kind, tick });
        }
    }

    /// Changes since the last call (Species phase).
    pub(crate) fn take_journal(&mut self) -> Vec<SpeciesChange> {
        std::mem::take(&mut self.journal)
    }

    /// Pending (not yet emitted) changes.
    pub fn journal(&self) -> &[SpeciesChange] {
        &self.journal
    }

    /// Consistency against the living organisms `(kind, species)`.
    pub(crate) fn check(&self, living: impl Iterator<Item = (Kind, SpeciesId)>) -> Result<(), String> {
        let mut counts = vec![0u64; self.records.len()];
        for (kind, s) in living {
            let r = self.get(s).ok_or_else(|| format!("unknown species {}", s.0))?;
            if r.kind != kind {
                return Err(format!("{} organism in {} species {}", kind.name(), r.kind.name(), s.0));
            }
            counts[s.0 as usize - 1] += 1;
        }
        let mut per_kind = [0u64; 3];
        for (r, &c) in self.records.iter().zip(&counts) {
            if r.living != c {
                return Err(format!("species {} counts {} living members, found {c}", r.id.0, r.living));
            }
            if r.extinct_tick.is_some() != (c == 0) {
                return Err(format!("species {} extinction state inconsistent", r.id.0));
            }
            if c > 0 {
                per_kind[r.kind.index()] += 1;
            }
        }
        if per_kind != self.living_per_kind {
            return Err("living species per kind inconsistent".to_string());
        }
        Ok(())
    }
}

impl SpeciesRegistry {
    /// Canonical state stream of the species registry (ADR-022 §2).
    pub(crate) fn hash_state(&self, h: &mut crate::digest::StateHasher) {
        let SpeciesRegistry { records, thresholds, living_per_kind, journal } = self;
        h.section("species");
        h.debug(thresholds);
        h.debug(living_per_kind);
        h.len(records.len());
        for r in records {
            h.debug(r);
        }
        h.debug(journal);
    }
}

#[cfg(test)]
impl SpeciesRegistry {
    /// Test-only: bump the `ever` counter of the first record.
    pub(crate) fn bump_first_ever_for_test(&mut self) {
        self.records[0].ever += 1;
    }
}

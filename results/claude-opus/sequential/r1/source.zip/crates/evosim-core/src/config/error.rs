//! Configuration errors. Every error names the offending dotted key (ADR-006).

use std::fmt;

/// Key used for errors that concern the whole document.
pub const ROOT_KEY: &str = "<root>";
/// Key used for JSON syntax errors.
pub const JSON_KEY: &str = "<json>";

/// What went wrong with a configuration value.
#[derive(Debug, Clone, PartialEq)]
pub enum ConfigErrorKind {
    /// The text is not valid JSON.
    Parse { line: usize, column: usize, msg: String },
    /// The value has the wrong JSON type.
    WrongType { expected: &'static str, found: &'static str },
    /// A required (fixed) key is missing.
    Missing,
    /// A value lies outside its valid inclusive range.
    OutOfRange { value: String, min: f64, max: f64 },
    /// A key that the configuration does not define.
    UnknownKey,
    /// A cross-field constraint is violated.
    Invalid { reason: String },
    /// No built-in preset with this name.
    UnknownPreset { name: String, available: Vec<String> },
}

/// A configuration error with the dotted key path it concerns, e.g. `world.width`.
#[derive(Debug, Clone, PartialEq)]
pub struct ConfigError {
    pub key: String,
    pub kind: ConfigErrorKind,
}

impl ConfigError {
    pub fn new(key: impl Into<String>, kind: ConfigErrorKind) -> Self {
        ConfigError { key: key.into(), kind }
    }
    pub fn missing(key: impl Into<String>) -> Self {
        Self::new(key, ConfigErrorKind::Missing)
    }
    pub fn unknown(key: impl Into<String>) -> Self {
        Self::new(key, ConfigErrorKind::UnknownKey)
    }
    pub fn wrong_type(key: impl Into<String>, expected: &'static str, found: &serde_json::Value) -> Self {
        Self::new(key, ConfigErrorKind::WrongType { expected, found: json_type_name(found) })
    }
    pub fn out_of_range(key: impl Into<String>, value: impl fmt::Display, min: f64, max: f64) -> Self {
        Self::new(key, ConfigErrorKind::OutOfRange { value: value.to_string(), min, max })
    }
    pub fn invalid(key: impl Into<String>, reason: impl Into<String>) -> Self {
        Self::new(key, ConfigErrorKind::Invalid { reason: reason.into() })
    }
}

/// JSON type name used in error messages.
pub fn json_type_name(v: &serde_json::Value) -> &'static str {
    use serde_json::Value::*;
    match v {
        Null => "null",
        Bool(_) => "boolean",
        Number(n) if n.is_f64() => "number",
        Number(_) => "integer",
        String(_) => "string",
        Array(_) => "array",
        Object(_) => "object",
    }
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "config error: `{}`: ", self.key)?;
        match &self.kind {
            ConfigErrorKind::Parse { line, column, msg } => {
                write!(f, "invalid JSON at line {line} column {column}: {msg}")
            }
            ConfigErrorKind::WrongType { expected, found } => {
                write!(f, "wrong type: expected {expected}, found {found}")
            }
            ConfigErrorKind::Missing => write!(f, "missing required key"),
            ConfigErrorKind::OutOfRange { value, min, max } => {
                write!(f, "value {value} out of range [{min}, {max}]")
            }
            ConfigErrorKind::UnknownKey => write!(f, "unknown key"),
            ConfigErrorKind::Invalid { reason } => write!(f, "invalid value: {reason}"),
            ConfigErrorKind::UnknownPreset { name, available } => {
                write!(f, "unknown preset '{name}' (available: {})", available.join(", "))
            }
        }
    }
}

impl std::error::Error for ConfigError {}

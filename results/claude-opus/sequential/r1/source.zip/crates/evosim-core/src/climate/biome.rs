//! The six biomes, ordered cold → hot (ADR-009).

/// Upper temperature bound (exclusive) of [`Biome::Polar`] in °C.
pub const POLAR_MAX_T: f64 = -10.0;
/// Upper temperature bound (exclusive) of [`Biome::Tundra`] in °C.
pub const TUNDRA_MAX_T: f64 = 0.0;
/// Upper temperature bound (exclusive) of [`Biome::Temperate`] in °C.
pub const TEMPERATE_MAX_T: f64 = 18.0;
/// Upper relative precipitation bound (exclusive) of [`Biome::Desert`].
pub const DESERT_MAX_R: f64 = 0.3;
/// Upper relative precipitation bound (exclusive) of [`Biome::Savanna`].
pub const SAVANNA_MAX_R: f64 = 0.6;

/// Biome of a cell. `Ord` follows the Earth-like order cold → hot:
/// polar, tundra, temperate, dry (desert, savanna), tropical.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Biome {
    Polar,
    Tundra,
    Temperate,
    Desert,
    Savanna,
    Tropical,
}

impl Biome {
    /// All biomes in rank order.
    pub const ALL: [Biome; 6] =
        [Biome::Polar, Biome::Tundra, Biome::Temperate, Biome::Desert, Biome::Savanna, Biome::Tropical];

    /// Rank 0 (polar) … 5 (tropical).
    pub fn rank(self) -> u8 {
        self as u8
    }

    /// Lowercase name.
    pub fn name(self) -> &'static str {
        match self {
            Biome::Polar => "polar",
            Biome::Tundra => "tundra",
            Biome::Temperate => "temperate",
            Biome::Desert => "desert",
            Biome::Savanna => "savanna",
            Biome::Tropical => "tropical",
        }
    }

    /// One-character symbol for text maps.
    pub fn symbol(self) -> char {
        match self {
            Biome::Polar => 'I',
            Biome::Tundra => 'U',
            Biome::Temperate => 'F',
            Biome::Desert => 'D',
            Biome::Savanna => 'S',
            Biome::Tropical => 'R',
        }
    }

    /// Inverse of [`Biome::symbol`].
    pub fn from_symbol(c: char) -> Option<Biome> {
        Biome::ALL.into_iter().find(|b| b.symbol() == c)
    }

    /// Colour for image export.
    pub fn rgb(self) -> [u8; 3] {
        match self {
            Biome::Polar => [235, 245, 255],
            Biome::Tundra => [150, 170, 160],
            Biome::Temperate => [60, 140, 60],
            Biome::Desert => [230, 200, 120],
            Biome::Savanna => [190, 180, 70],
            Biome::Tropical => [10, 100, 30],
        }
    }

    /// Earth-like zone index of the acceptance criterion, cold → hot:
    /// 0 polar, 1 tundra, 2 temperate, 3 dry (desert and savanna), 4 tropical.
    /// Within the dry zone desert and savanna may alternate (e.g. a savanna
    /// fringe on the poleward side of a desert), so order checks use zones.
    pub fn zone(self) -> u8 {
        match self {
            Biome::Polar => 0,
            Biome::Tundra => 1,
            Biome::Temperate => 2,
            Biome::Desert | Biome::Savanna => 3,
            Biome::Tropical => 4,
        }
    }

    /// Desert or savanna (the "dry" zone).
    pub fn is_dry(self) -> bool {
        matches!(self, Biome::Desert | Biome::Savanna)
    }

    /// Rule of the legend, e.g. `T < -10`.
    pub fn rule(self) -> &'static str {
        match self {
            Biome::Polar => "T < -10",
            Biome::Tundra => "-10 <= T < 0",
            Biome::Temperate => "0 <= T < 18",
            Biome::Desert => "T >= 18, r < 0.3",
            Biome::Savanna => "T >= 18, 0.3 <= r < 0.6",
            Biome::Tropical => "T >= 18, r >= 0.6",
        }
    }

    /// Whittaker-like classification from temperature (°C) and relative
    /// precipitation `r = P / P_max` in [0, 1].
    pub fn classify(temperature: f64, precip_rel: f64) -> Biome {
        if temperature < POLAR_MAX_T {
            Biome::Polar
        } else if temperature < TUNDRA_MAX_T {
            Biome::Tundra
        } else if temperature < TEMPERATE_MAX_T {
            Biome::Temperate
        } else if precip_rel < DESERT_MAX_R {
            Biome::Desert
        } else if precip_rel < SAVANNA_MAX_R {
            Biome::Savanna
        } else {
            Biome::Tropical
        }
    }
}

//! Grid coordinates and toroidal topology (ADR-007, TASK-004).
//!
//! The world is a `width × height` grid whose left/right and top/bottom edges
//! are joined (a torus). Conventions used project-wide:
//!
//! * **Axes:** `x` grows east, `y` grows south (screen convention); `Dir8::N`
//!   is the offset `(0, -1)`.
//! * **Positions:** [`Cell`] `{x, y: u32}` is always canonical
//!   (`x < width`, `y < height`) when produced by a [`Torus`] method.
//! * **Displacements/directions:** [`Offset`] `{dx, dy: i32}` and the unit
//!   direction enum [`Dir8`].
//! * **Metric:** toroidal **Chebyshev** distance `max(|dx|, |dy|)` of the
//!   shortest per-axis offset. This is the single distance measure for the
//!   whole project (perception, movement, dispersal, mating, spatial queries).
//! * **Shortest offset / tie rule:** per axis `d = (b - a) mod n`; if
//!   `d > n/2` then `d - n`. The canonical offset range per axis is
//!   `[-⌊(n-1)/2⌋, ⌊n/2⌋]`; for even `n` the tie at exactly `n/2` yields the
//!   positive (east/south) offset, so `offset(a,b)` is not always
//!   `-offset(b,a)`, but `distance` is symmetric.
//! * **Neighbourhoods:** [`Torus::within`] enumerates every cell with
//!   distance `<= r` exactly once, also when `r` exceeds the world size.

use std::fmt;
use std::ops::RangeInclusive;

#[cfg(test)]
mod tests;

/// Largest allowed world dimension per axis. Keeps all intermediate
/// `i32`/`i64` arithmetic overflow-free (config limits worlds to 4096).
pub const MAX_DIM: u32 = 1 << 20;

/// Invalid world dimensions.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TopologyError {
    /// A dimension was 0.
    ZeroDimension { axis: &'static str },
    /// A dimension exceeded [`MAX_DIM`].
    TooLarge { axis: &'static str, value: u32 },
}

impl fmt::Display for TopologyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TopologyError::ZeroDimension { axis } => {
                write!(f, "world {axis} must be at least 1")
            }
            TopologyError::TooLarge { axis, value } => {
                write!(f, "world {axis} {value} exceeds maximum {MAX_DIM}")
            }
        }
    }
}

impl std::error::Error for TopologyError {}

/// A canonical grid cell. Ordered row-major: by `(y, x)`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct Cell {
    pub x: u32,
    pub y: u32,
}

impl Cell {
    /// Creates a cell without validation; use [`Torus::wrap`] for arbitrary
    /// input or [`Torus::contains`] to check.
    pub const fn new(x: u32, y: u32) -> Cell {
        Cell { x, y }
    }
}

impl Ord for Cell {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        (self.y, self.x).cmp(&(other.y, other.x))
    }
}

impl PartialOrd for Cell {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

/// A signed displacement between cells (east = +dx, south = +dy).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct Offset {
    pub dx: i32,
    pub dy: i32,
}

impl Offset {
    pub const ZERO: Offset = Offset { dx: 0, dy: 0 };

    pub const fn new(dx: i32, dy: i32) -> Offset {
        Offset { dx, dy }
    }

    /// Chebyshev length `max(|dx|, |dy|)`.
    pub fn chebyshev(self) -> u32 {
        self.dx.unsigned_abs().max(self.dy.unsigned_abs())
    }

    pub fn is_zero(self) -> bool {
        self.dx == 0 && self.dy == 0
    }

    /// Component-wise sign: the unit step towards this offset.
    pub fn signum(self) -> Offset {
        Offset { dx: self.dx.signum(), dy: self.dy.signum() }
    }
}

/// One of the eight unit move directions (y grows south).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, serde::Serialize, serde::Deserialize)]
pub enum Dir8 {
    N,
    NE,
    E,
    SE,
    S,
    SW,
    W,
    NW,
}

impl Dir8 {
    pub const ALL: [Dir8; 8] =
        [Dir8::N, Dir8::NE, Dir8::E, Dir8::SE, Dir8::S, Dir8::SW, Dir8::W, Dir8::NW];

    /// Unit offset of this direction.
    pub fn offset(self) -> Offset {
        let (dx, dy) = match self {
            Dir8::N => (0, -1),
            Dir8::NE => (1, -1),
            Dir8::E => (1, 0),
            Dir8::SE => (1, 1),
            Dir8::S => (0, 1),
            Dir8::SW => (-1, 1),
            Dir8::W => (-1, 0),
            Dir8::NW => (-1, -1),
        };
        Offset { dx, dy }
    }

    /// Direction of the sign of `o`; `None` for the zero offset.
    pub fn from_offset(o: Offset) -> Option<Dir8> {
        let s = o.signum();
        Some(match (s.dx, s.dy) {
            (0, -1) => Dir8::N,
            (1, -1) => Dir8::NE,
            (1, 0) => Dir8::E,
            (1, 1) => Dir8::SE,
            (0, 1) => Dir8::S,
            (-1, 1) => Dir8::SW,
            (-1, 0) => Dir8::W,
            (-1, -1) => Dir8::NW,
            _ => return None,
        })
    }

    /// The opposite direction.
    pub fn opposite(self) -> Dir8 {
        Dir8::ALL[(self as usize + 4) % 8]
    }
}

/// Maps any integer coordinate onto `0..n` (n >= 1).
pub fn wrap_coord(v: i64, n: u32) -> u32 {
    debug_assert!(n >= 1);
    v.rem_euclid(n as i64) as u32
}

/// Shortest signed offset from `a` to `b` on a circular axis of length `n`
/// (`a, b < n`). Range `[-⌊(n-1)/2⌋, ⌊n/2⌋]`; tie at n/2 → positive.
pub fn axis_delta(a: u32, b: u32, n: u32) -> i32 {
    let n = n as i64;
    let d = (b as i64 - a as i64).rem_euclid(n);
    (if d > n / 2 { d - n } else { d }) as i32
}

/// Distinct per-axis offsets with `|offset| <= r` on an axis of length `n`:
/// `-r..=r` if that has fewer than `n` values, else the full canonical range
/// `-⌊(n-1)/2⌋..=⌊n/2⌋` (exactly `n` values, one per cell).
pub fn axis_offsets(r: u32, n: u32) -> RangeInclusive<i32> {
    if 2 * (r as u64) + 1 >= n as u64 {
        -(((n - 1) / 2) as i32)..=((n / 2) as i32)
    } else {
        -(r as i32)..=(r as i32)
    }
}

/// The toroidal world geometry.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Torus {
    width: u32,
    height: u32,
}

impl Torus {
    /// Creates a `width × height` torus; both dimensions must be in
    /// `1..=MAX_DIM`.
    pub fn new(width: u32, height: u32) -> Result<Torus, TopologyError> {
        for (axis, v) in [("width", width), ("height", height)] {
            if v == 0 {
                return Err(TopologyError::ZeroDimension { axis });
            }
            if v > MAX_DIM {
                return Err(TopologyError::TooLarge { axis, value: v });
            }
        }
        Ok(Torus { width, height })
    }

    pub fn width(&self) -> u32 {
        self.width
    }

    pub fn height(&self) -> u32 {
        self.height
    }

    pub fn cell_count(&self) -> usize {
        self.width as usize * self.height as usize
    }

    /// Maps any integer coordinate (negative, many widths away) to a cell.
    pub fn wrap(&self, x: i64, y: i64) -> Cell {
        Cell { x: wrap_coord(x, self.width), y: wrap_coord(y, self.height) }
    }

    pub fn contains(&self, c: Cell) -> bool {
        c.x < self.width && c.y < self.height
    }

    /// Flat row-major index `y * width + x` for per-cell arrays.
    pub fn index(&self, c: Cell) -> usize {
        debug_assert!(self.contains(c), "cell {c:?} outside {self:?}");
        c.y as usize * self.width as usize + c.x as usize
    }

    /// Inverse of [`Torus::index`] (`i < cell_count()`).
    pub fn cell_at(&self, i: usize) -> Cell {
        debug_assert!(i < self.cell_count());
        let w = self.width as usize;
        Cell { x: (i % w) as u32, y: (i / w) as u32 }
    }

    /// Iterates all cells in row-major order.
    pub fn cells(&self) -> impl Iterator<Item = Cell> + '_ {
        (0..self.cell_count()).map(move |i| self.cell_at(i))
    }

    /// Cell reached from `c` by displacement `o` (wrapping).
    pub fn translate(&self, c: Cell, o: Offset) -> Cell {
        self.wrap(c.x as i64 + o.dx as i64, c.y as i64 + o.dy as i64)
    }

    /// Neighbouring cell in direction `d` (wrapping).
    pub fn step(&self, c: Cell, d: Dir8) -> Cell {
        self.translate(c, d.offset())
    }

    /// Shortest displacement from `a` to `b` (tie at n/2 → positive).
    pub fn offset(&self, a: Cell, b: Cell) -> Offset {
        Offset {
            dx: axis_delta(a.x, b.x, self.width),
            dy: axis_delta(a.y, b.y, self.height),
        }
    }

    /// Toroidal Chebyshev distance — the project-wide metric.
    pub fn distance(&self, a: Cell, b: Cell) -> u32 {
        self.offset(a, b).chebyshev()
    }

    /// Unit direction of the first step on a shortest path from `a` to `b`;
    /// `None` if `a == b`.
    pub fn direction(&self, a: Cell, b: Cell) -> Option<Dir8> {
        Dir8::from_offset(self.offset(a, b))
    }

    /// Largest possible distance between two cells.
    pub fn max_distance(&self) -> u32 {
        (self.width / 2).max(self.height / 2)
    }

    /// Distinct x offsets within radius `r`.
    pub fn x_offsets(&self, r: u32) -> RangeInclusive<i32> {
        axis_offsets(r, self.width)
    }

    /// Distinct y offsets within radius `r`.
    pub fn y_offsets(&self, r: u32) -> RangeInclusive<i32> {
        axis_offsets(r, self.height)
    }

    /// Every cell at distance `<= r` from `center` exactly once, with its
    /// shortest offset from `center`. Order: dy outer, dx inner (ascending).
    pub fn within(&self, center: Cell, r: u32) -> WithinIter {
        let xs = self.x_offsets(r);
        let ys = self.y_offsets(r);
        WithinIter {
            torus: *self,
            center,
            dx_start: *xs.start(),
            dx_end: *xs.end(),
            dy_end: *ys.end(),
            dx: *xs.start(),
            dy: *ys.start(),
        }
    }

    /// `within` collected into cells.
    pub fn cells_within(&self, center: Cell, r: u32) -> Vec<Cell> {
        self.within(center, r).map(|(c, _)| c).collect()
    }

    /// Number of cells at distance `<= r` from any cell.
    pub fn count_within(&self, r: u32) -> usize {
        let span = |rng: RangeInclusive<i32>| (*rng.end() - *rng.start() + 1) as usize;
        span(self.x_offsets(r)) * span(self.y_offsets(r))
    }

    /// Cells at exactly distance `d` from `center` (each once).
    pub fn ring(&self, center: Cell, d: u32) -> impl Iterator<Item = (Cell, Offset)> {
        self.within(center, d).filter(move |(_, o)| o.chebyshev() == d)
    }

    /// Distinct 8-neighbours of `c` (excluding `c` itself) with the direction
    /// leading to them. Fewer than 8 on worlds narrower than 3 cells; empty
    /// on 1×1.
    pub fn neighbours8(&self, c: Cell) -> Vec<(Cell, Dir8)> {
        self.within(c, 1)
            .filter_map(|(cell, o)| Dir8::from_offset(o).map(|d| (cell, d)))
            .collect()
    }
}

/// Allocation-free iterator returned by [`Torus::within`].
#[derive(Debug, Clone)]
pub struct WithinIter {
    torus: Torus,
    center: Cell,
    dx_start: i32,
    dx_end: i32,
    dy_end: i32,
    dx: i32,
    dy: i32,
}

impl Iterator for WithinIter {
    type Item = (Cell, Offset);

    fn next(&mut self) -> Option<(Cell, Offset)> {
        if self.dy > self.dy_end {
            return None;
        }
        let o = Offset { dx: self.dx, dy: self.dy };
        if self.dx >= self.dx_end {
            self.dx = self.dx_start;
            self.dy += 1;
        } else {
            self.dx += 1;
        }
        Some((self.torus.translate(self.center, o), o))
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.dy > self.dy_end {
            return (0, Some(0));
        }
        let row = (self.dx_end - self.dx_start + 1) as usize;
        let rows_after = (self.dy_end - self.dy) as usize;
        let n = rows_after * row + (self.dx_end - self.dx + 1) as usize;
        (n, Some(n))
    }
}

impl ExactSizeIterator for WithinIter {}

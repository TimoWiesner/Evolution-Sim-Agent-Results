//! TASK-008 tests: kinds, fields, traits, ranges, death, totals and THE
//! same-tick rule (ADR-011). Simulation-level tests drive the scheduler with
//! `step_with` hooks that kill organisms and request births in any phase.

use super::*;
use crate::genome::{express, Expression, Genome};
use crate::config::{preset, preset_names, Config};
use crate::ids::{EntityId, IdAllocator};
use crate::rng::Rng;
use crate::sim::{acting_order, EventKind, Phase, PhaseCtx, Simulation, TickReport};
use crate::topology::{Cell, Torus};
use std::collections::BTreeSet;

fn cfg(seed: u64, p: u32, h: u32, c: u32) -> Config {
    Config::new(seed, 20, 16, p, h, c)
}

/// Keep every carnivore at max energy (sated → rests, no hunting, ADR-018) so
/// tests about life-cycle bookkeeping are not disturbed by predation.
fn sate_carnivores(p: &mut Population) {
    for id in p.alive_ids(Kind::Carnivore) {
        let o = p.get_alive_mut(id).unwrap();
        let m = o.traits().max_energy;
        o.set_energy(m);
    }
}

fn req(kind: Kind, parents: Parents, energy: f64, _cfg: &Config) -> BirthRequest {
    BirthRequest { pos: Cell { x: 1, y: 2 }, parents, energy, health: None, genome: Genome::founder_default(kind) }
}

fn assert_invariant(p: &Population) {
    for k in Kind::ALL {
        assert_eq!(p.totals().living_expected(k), p.count_alive(k) as u64, "living invariant for {}", k.name());
    }
}

fn assert_ranges(p: &Population) {
    for k in Kind::ALL {
        for o in p.stored(k) {
            assert!(o.energy() >= 0.0 && o.energy() <= o.traits().max_energy, "energy {}", o.energy());
            assert!(o.health() >= 0.0 && o.health() <= o.traits().max_health, "health {}", o.health());
            assert!(o.traits().in_range(k));
        }
    }
}

// ---------- AC1 kinds ----------

#[test]
fn three_kinds_exist() {
    assert_eq!(Kind::ALL, [Kind::Plant, Kind::Herbivore, Kind::Carnivore]);
    let idx: Vec<usize> = Kind::ALL.iter().map(|k| k.index()).collect();
    assert_eq!(idx, [0, 1, 2]);
    let names: Vec<&str> = Kind::ALL.iter().map(|k| k.name()).collect();
    assert_eq!(names, ["plants", "herbivores", "carnivores"]);
    assert!(!Kind::Plant.is_animal() && Kind::Herbivore.is_animal() && Kind::Carnivore.is_animal());
    assert_eq!(DeathCause::ALL.len(), DeathCause::COUNT);
    for (i, c) in DeathCause::ALL.iter().enumerate() {
        assert_eq!(c.index(), i);
    }
}

// ---------- AC2 fields and IDs ----------

#[test]
fn organism_exposes_all_fields() {
    let c = cfg(5, 2, 2, 1);
    let mut sim = Simulation::new(c.clone()).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let f = sim.organisms().get(h[0]).unwrap().clone();
    assert_eq!(f.id(), EntityId(3));
    assert_eq!(f.kind(), Kind::Herbivore);
    assert!(sim.world().torus().contains(f.pos()));
    assert_eq!(f.age(), 0);
    assert_eq!(f.energy(), c.herbivores.initial_energy);
    assert_eq!(f.health(), f.traits().max_health);
    assert_eq!(f.traits(), &express(f.genome(), &Expression::from_config(&c)));
    assert!(f.traits().in_range(Kind::Herbivore));
    assert_eq!(f.parents(), Parents::None);
    assert_eq!(f.generation(), 0);
    assert_eq!(f.birth_tick(), 0);
    assert!(f.is_alive());
    let (a, b) = (h[0], h[1]);
    sim.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::Two(a, b), 30.0, ctx.config));
        }
    });
    let kid = sim.organisms().get(EntityId(6)).unwrap();
    assert_eq!(kid.kind(), Kind::Herbivore);
    assert_eq!(kid.pos(), Cell { x: 1, y: 2 });
    assert_eq!(kid.parents(), Parents::Two(a, b));
    assert_eq!(kid.parents().ids().collect::<Vec<_>>(), vec![a, b]);
    assert_eq!(kid.generation(), 1);
    assert_eq!(kid.birth_tick(), 0);
    assert_eq!(kid.age(), 0);
    assert_eq!(kid.energy(), 30.0);
    // Founder aged once.
    assert_eq!(sim.organisms().get(a).unwrap().age(), 1);
}

#[test]
fn ids_unique_never_reused_under_random_ops() {
    let c = cfg(1, 5, 5, 5);
    let torus = Torus::new(20, 16).unwrap();
    let mut ids = IdAllocator::new();
    let mut p = Population::founders(&c, &torus, &mut ids);
    let mut seen: BTreeSet<EntityId> = Kind::ALL.iter().flat_map(|&k| p.alive_ids(k)).collect();
    let mut removed: BTreeSet<EntityId> = BTreeSet::new();
    let mut r = Rng::seed_from_u64(7);
    let mut tick = 0u64;
    for _ in 0..2000 {
        match r.below(4) {
            0 => {
                let k = Kind::ALL[r.below(3) as usize];
                let alive = p.alive_ids(k);
                let parents = match (alive.len(), r.below(3)) {
                    (0, _) | (_, 0) => Parents::None,
                    (n, 1) => Parents::One(alive[r.below(n as u64) as usize]),
                    (n, _) => Parents::Two(alive[r.below(n as u64) as usize], alive[r.below(n as u64) as usize]),
                };
                p.request_birth(req(k, parents, r.range_f64(0.1, 10.0), &c));
            }
            1 => {
                let max_seen = seen.iter().next_back().copied().unwrap_or(EntityId(0));
                for b in p.resolve_births(tick, &mut ids) {
                    assert!(b.id > max_seen && !seen.contains(&b.id), "fresh ID");
                    seen.insert(b.id);
                }
            }
            2 => {
                let k = Kind::ALL[r.below(3) as usize];
                let alive = p.alive_ids(k);
                if !alive.is_empty() {
                    let id = alive[r.below(alive.len() as u64) as usize];
                    let cause = DeathCause::ALL[r.below(DeathCause::COUNT as u64) as usize];
                    assert!(p.kill(id, cause, tick));
                    assert!(!p.kill(id, cause, tick));
                }
            }
            _ => {
                for d in p.end_of_tick(tick) {
                    removed.insert(d.id);
                }
                tick += 1;
                for id in &removed {
                    assert!(p.get(*id).is_none(), "removed ID {} visible", id.0);
                }
            }
        }
        assert_invariant(&p);
        for k in Kind::ALL {
            assert!(p.stored(k).windows(2).all(|w| w[0].id() < w[1].id()), "sorted");
        }
    }
    assert!(seen.len() > 50 && !removed.is_empty());
}

// ---------- AC3 traits ----------

#[test]
fn trait_ranges_table_matches_adr() {
    for k in Kind::ALL {
        let r = TraitRanges::for_kind(k);
        let a = k.is_animal();
        assert_eq!(r.speed, Range::new(0.0, if a { 16.0 } else { 0.0 }));
        assert_eq!(r.strength, Range::new(0.0, 1.0));
        assert_eq!(r.fertility, Range::new(0.0, 1.0));
        assert_eq!(r.max_health, Range::new(1.0, 1000.0));
        assert_eq!(r.max_lifespan, (1, 10_000_000));
        assert_eq!(r.max_energy, Range::new(0.1, 1e6));
        assert_eq!(r.vision, Range::new(0.0, if a { 64.0 } else { 0.0 }));
        assert_eq!(r.aggression, Range::new(0.0, if a { 1.0 } else { 0.0 }));
        assert_eq!(r.caution, Range::new(0.0, if a { 1.0 } else { 0.0 }));
        assert_eq!(r.temp_optimum, Range::new(-40.0, 60.0));
        assert_eq!(r.temp_tolerance, Range::new(0.5, 50.0));
    }
}

#[test]
fn clamped_forces_ranges() {
    let mut r = Rng::seed_from_u64(11);
    let specials = [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, -1e300, 1e300, -1.0, 0.0, 0.5, 2.0];
    let pick = |r: &mut Rng| {
        if r.chance(0.5) {
            specials[r.below(specials.len() as u64) as usize]
        } else {
            r.range_f64(-2000.0, 2000.0)
        }
    };
    for _ in 0..3000 {
        let raw = Traits {
            speed: pick(&mut r),
            strength: pick(&mut r),
            fertility: pick(&mut r),
            max_health: pick(&mut r),
            max_lifespan: r.next_u32(),
            max_energy: pick(&mut r),
            vision: pick(&mut r),
            aggression: pick(&mut r),
            caution: pick(&mut r),
            temp_optimum: pick(&mut r),
            temp_tolerance: pick(&mut r),
        };
        for k in Kind::ALL {
            let t = Traits::clamped(k, raw);
            assert!(t.in_range(k), "{t:?}");
            if !k.is_animal() {
                assert_eq!((t.speed, t.vision, t.aggression, t.caution), (0.0, 0.0, 0.0, 0.0));
            }
        }
    }
    let nan = Traits {
        speed: f64::NAN,
        strength: f64::NAN,
        fertility: f64::NAN,
        max_health: f64::NAN,
        max_lifespan: 0,
        max_energy: f64::NAN,
        vision: f64::NAN,
        aggression: f64::NAN,
        caution: f64::NAN,
        temp_optimum: f64::NAN,
        temp_tolerance: f64::NAN,
    };
    let t = Traits::clamped(Kind::Carnivore, nan);
    assert_eq!((t.max_health, t.max_lifespan, t.max_energy, t.speed), (1.0, 1, 0.1, 0.0));
}

#[test]
fn founder_defaults_in_range_for_all_presets() {
    for name in preset_names() {
        let c = preset(name).unwrap();
        for k in Kind::ALL {
            let t = Traits::founder_default(k, &c);
            assert!(t.in_range(k), "{name} {}", k.name());
            if k.is_animal() {
                assert!((0.0..=1.0).contains(&t.aggression) && (0.0..=1.0).contains(&t.caution));
                assert!(t.speed > 0.0 && t.vision > 0.0);
            }
        }
        let c2 = Config { world: crate::config::WorldConfig { width: 16, height: 12 }, ..c };
        let sim = Simulation::new(c2).unwrap();
        assert_ranges(sim.organisms());
    }
    let c = cfg(0, 0, 0, 0);
    let t = Traits::founder_default(Kind::Herbivore, &c);
    assert_eq!(t.max_lifespan, c.herbivores.max_age);
    assert_eq!(t.max_energy, c.herbivores.max_energy);
    assert_eq!(t.speed, c.herbivores.max_speed as f64 / 2.0);
    assert_eq!(t.max_health, 100.0);
    assert_eq!(Traits::founder_default(Kind::Plant, &c).max_health, 10.0);
    assert_eq!(Traits::founder_default(Kind::Carnivore, &c).max_health, 120.0);
}

// ---------- AC4a energy/health ranges ----------

#[test]
fn energy_health_never_leave_range() {
    let c = cfg(3, 10, 10, 10);
    let torus = Torus::new(20, 16).unwrap();
    let mut p = Population::founders(&c, &torus, &mut IdAllocator::new());
    let ids: Vec<EntityId> = Kind::ALL.iter().flat_map(|&k| p.alive_ids(k)).collect();
    let specials = [-1e9, -1.0, 0.0, 1e-300, 1e300, f64::NAN, f64::INFINITY, f64::NEG_INFINITY];
    let mut r = Rng::seed_from_u64(99);
    for _ in 0..10_000 {
        let id = ids[r.below(ids.len() as u64) as usize];
        let x = if r.chance(0.5) { specials[r.below(8) as usize] } else { r.range_f64(-200.0, 200.0) };
        let o = p.get_alive_mut(id).unwrap();
        let (e0, h0) = (o.energy(), o.health());
        match r.below(6) {
            0 => {
                let g = o.add_energy(x);
                assert!(g >= 0.0 && (o.energy() - e0 - g).abs() < 1e-9);
            }
            1 => {
                let s = o.spend_energy(x);
                assert!(s >= 0.0 && (e0 - o.energy() - s).abs() < 1e-9);
            }
            2 => o.set_energy(x),
            3 => {
                let l = o.damage(x);
                assert!(l >= 0.0 && (h0 - o.health() - l).abs() < 1e-9);
            }
            4 => {
                let hd = o.heal(x);
                assert!(hd >= 0.0 && (o.health() - h0 - hd).abs() < 1e-9);
            }
            _ => o.set_health(x),
        }
        let o = p.get(id).unwrap();
        assert!(o.energy() >= 0.0 && o.energy() <= o.traits().max_energy, "{x} -> {}", o.energy());
        assert!(o.health() >= 0.0 && o.health() <= o.traits().max_health, "{x} -> {}", o.health());
    }
}

#[test]
fn energy_health_in_range_during_hook_driven_run() {
    let mut sim = Simulation::new(cfg(4, 20, 20, 20)).unwrap();
    let mut r = Rng::seed_from_u64(5);
    for _ in 0..100 {
        sim.step_with(|ctx| {
            if ctx.phase.is_acting() {
                let kind = Kind::ALL[[Phase::Plants, Phase::Herbivores, Phase::Carnivores]
                    .iter()
                    .position(|p| *p == ctx.phase)
                    .unwrap()];
                for id in ctx.world.organisms().alive_ids(kind) {
                    let o = ctx.world.organisms_mut().get_alive_mut(id).unwrap();
                    o.spend_energy(r.range_f64(-1.0, 3.0));
                    o.add_energy(r.range_f64(-1.0, 3.0));
                    o.damage(r.range_f64(-1.0, 4.0));
                    o.heal(r.range_f64(-1.0, 3.0));
                }
            }
            assert_ranges(ctx.world.organisms());
        });
        assert_ranges(sim.organisms());
        assert_invariant(sim.organisms());
    }
    assert!(sim.totals().deaths.iter().sum::<u64>() > 0);
}

// ---------- AC4b death ----------

#[test]
fn kill_flags_records_cause_and_hides() {
    let c = cfg(2, 3, 3, 3);
    let mut sim = Simulation::new(c).unwrap();
    for _ in 0..4 {
        sim.step_with(|ctx| {
            if ctx.phase == Phase::Plants {
                sate_carnivores(ctx.world.organisms_mut());
            }
        });
    }
    let p = sim.organisms_mut();
    let id = p.alive_ids(Kind::Herbivore)[1];
    let pos = p.get(id).unwrap().pos();
    assert!(p.kill(id, DeathCause::Predation, 4));
    assert!(!p.is_alive(id) && p.get_alive(id).is_none() && p.get_alive_mut(id).is_none());
    assert!(!p.alive_ids(Kind::Herbivore).contains(&id));
    assert_eq!(p.count_alive(Kind::Herbivore), 2);
    assert_eq!(p.stored_len(Kind::Herbivore), 3, "removed only in the Deaths phase");
    assert!(p.get(id).is_some_and(|o| !o.is_alive()));
    let before = *p.totals();
    assert!(!p.kill(id, DeathCause::OldAge, 4), "second kill ignored");
    assert_eq!(*p.totals(), before);
    assert_eq!(before.deaths_of(Kind::Herbivore), 1);
    assert_eq!(before.deaths_by(Kind::Herbivore, DeathCause::Predation), 1);
    assert!(!p.kill(EntityId(999), DeathCause::Injury, 4), "absent ID");
    let r = sim.step();
    let d: Vec<_> = r.events.iter().filter(|e| matches!(e.kind, EventKind::Death { .. })).collect();
    assert_eq!(d.len(), 1);
    assert_eq!(d[0].kind, EventKind::Death { id, kind: Kind::Herbivore, cause: DeathCause::Predation, age: 4 });
    assert_eq!(d[0].phase, Phase::Deaths);
    let rec = sim.organisms().last_deaths()[0];
    assert_eq!((rec.id, rec.cause, rec.tick, rec.age, rec.pos), (id, DeathCause::Predation, 4, 4, pos));
    assert!(sim.organisms().get(id).is_none());
    assert_eq!(sim.organisms().stored_len(Kind::Herbivore), 2);
}

#[test]
fn natural_deaths_sweep() {
    let mut c = cfg(8, 0, 4, 1);
    c.carnivores.max_age = 5;
    let mut sim = Simulation::new(c).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let carn = sim.organisms().alive_ids(Kind::Carnivore)[0];
    {
        let p = sim.organisms_mut();
        p.get_alive_mut(h[0]).unwrap().set_health(0.0); // Injury
        p.get_alive_mut(h[1]).unwrap().set_energy(0.0); // Starvation
        let o = p.get_alive_mut(h[2]).unwrap(); // both → Injury wins
        o.set_health(0.0);
        o.set_energy(0.0);
    }
    let r = sim.step();
    let causes: Vec<(EntityId, DeathCause)> = r
        .events
        .iter()
        .filter_map(|e| match e.kind {
            EventKind::Death { id, cause, .. } => Some((id, cause)),
            _ => None,
        })
        .collect();
    assert_eq!(causes, vec![(h[0], DeathCause::Injury), (h[1], DeathCause::Starvation), (h[2], DeathCause::Injury)]);
    assert_eq!(sim.organisms().alive_ids(Kind::Herbivore), vec![h[3]]);
    // Carnivore lifespan 5: dies in the Deaths phase of tick 4 with age 5.
    for t in 1..5u64 {
        let r = sim.step();
        let died = r.events.iter().any(|e| matches!(e.kind, EventKind::Death { id, .. } if id == carn));
        assert_eq!(died, t == 4, "tick {t}");
        if died {
            assert!(r.events.iter().any(|e| e.kind
                == EventKind::Death { id: carn, kind: Kind::Carnivore, cause: DeathCause::OldAge, age: 5 }));
        }
    }
    assert_eq!(sim.organisms().count_alive(Kind::Carnivore), 0);
    assert_eq!(sim.totals().deaths_by(Kind::Carnivore, DeathCause::OldAge), 1);
}

#[test]
fn dead_organism_never_acts_again() {
    let mut sim = Simulation::new(cfg(9, 0, 10, 0)).unwrap();
    let victim = sim.organisms().alive_ids(Kind::Herbivore)[4];
    let mut acted_after: Vec<EntityId> = Vec::new();
    let mut killed = false;
    for t in 0..50u64 {
        sim.step_with(|ctx| {
            if ctx.phase != Phase::Herbivores {
                return;
            }
            let order = acting_order(&ctx.world.organisms().alive_ids(Kind::Herbivore), ctx.rng);
            for (i, id) in order.iter().enumerate() {
                // Acting loops re-check liveness before every actor.
                if ctx.world.organisms().get_alive(*id).is_none() {
                    continue;
                }
                if killed {
                    acted_after.push(*id);
                }
                if t == 3 && i == 0 && !killed {
                    // First actor kills the victim mid-loop.
                    assert!(ctx.world.organisms_mut().kill(victim, DeathCause::Predation, ctx.tick));
                    killed = true;
                }
            }
        });
        if t >= 3 {
            assert!(sim.organisms().get(victim).is_none());
        }
    }
    assert!(killed && !acted_after.is_empty());
    assert!(!acted_after.contains(&victim), "dead organism acted");
    assert_eq!(sim.totals().deaths_by(Kind::Herbivore, DeathCause::Predation), 1);
}

// ---------- AC5 per-kind counters ----------

#[test]
fn totals_per_kind_since_tick_zero() {
    let mut c = cfg(12, 15, 10, 6);
    c.plants.max_age = 20;
    c.herbivores.max_age = 35;
    c.carnivores.max_age = 50;
    let mut sim = Simulation::new(c).unwrap();
    let t0 = *sim.totals();
    assert_eq!(t0.initial, [15, 10, 6]);
    assert_eq!((t0.births, t0.deaths), ([0; 3], [0; 3]), "founders are not births");
    let mut births = [0u64; 3];
    let mut deaths = [0u64; 3];
    let mut r = Rng::seed_from_u64(13);
    for _ in 0..200 {
        let rep: TickReport = sim.step_with(|ctx| {
            if !ctx.phase.is_acting() && ctx.phase != Phase::Species {
                return;
            }
            let k = Kind::ALL[r.below(3) as usize];
            let alive = ctx.world.organisms().alive_ids(k);
            if !alive.is_empty() && r.chance(0.3) {
                let id = alive[r.below(alive.len() as u64) as usize];
                ctx.world.organisms_mut().kill(id, DeathCause::Climate, ctx.tick);
            }
            for _ in 0..r.below(3) {
                let parents = if alive.is_empty() {
                    Parents::None
                } else {
                    Parents::One(alive[r.below(alive.len() as u64) as usize])
                };
                let e = ctx.config.plants.initial_energy;
                ctx.world.organisms_mut().request_birth(req(k, parents, e, ctx.config));
            }
            for k in Kind::ALL {
                let p = ctx.world.organisms();
                assert_eq!(p.totals().living_expected(k), p.count_alive(k) as u64, "between phases");
            }
        });
        for e in &rep.events {
            match e.kind {
                EventKind::Birth { kind, .. } => births[kind.index()] += 1,
                EventKind::Death { kind, .. } => deaths[kind.index()] += 1,
                _ => {}
            }
        }
        assert_invariant(sim.organisms());
    }
    let t = sim.totals();
    // Kills in the Species phase are reported in the next tick's Deaths phase;
    // count still-unreported ones via the population (flagged, not removed).
    let pending: [u64; 3] =
        Kind::ALL.map(|k| sim.organisms().stored(k).iter().filter(|o| !o.is_alive()).count() as u64);
    for i in 0..3 {
        assert_eq!(t.births[i], births[i]);
        assert_eq!(t.deaths[i], deaths[i] + pending[i]);
        assert_eq!(t.deaths_by_cause[i].iter().sum::<u64>(), t.deaths[i]);
        assert!(t.births[i] > 0 && t.deaths[i] > 0);
    }
    assert!(t.deaths_by(Kind::Plant, DeathCause::OldAge) > 0);
}

// ---------- AC6 THE same-tick rule ----------

#[test]
fn same_tick_parent_killed_before_births_drops_request() {
    let c = cfg(20, 0, 3, 1);
    let mut sim = Simulation::new(c).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let next = sim.next_entity_id();
    let r = sim.step_with(|ctx| match ctx.phase {
        Phase::Herbivores => {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::Two(h[0], h[1]), 20.0, ctx.config));
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::One(h[2]), 20.0, ctx.config));
        }
        Phase::Carnivores => {
            assert!(ctx.world.organisms_mut().kill(h[1], DeathCause::Predation, ctx.tick));
        }
        _ => {}
    });
    let b: Vec<_> = r.events.iter().filter(|e| matches!(e.kind, EventKind::Birth { .. })).collect();
    assert_eq!(b.len(), 1, "request with dead parent dropped");
    assert_eq!(b[0].kind, EventKind::Birth { id: EntityId(next), kind: Kind::Herbivore, parents: Parents::One(h[2]), generation: 1 });
    assert_eq!(sim.next_entity_id(), next + 1, "no ID allocated for dropped request");
    assert_eq!(sim.totals().births_of(Kind::Herbivore), 1);
    assert_eq!(sim.organisms().pending_births(), 0);
    assert_invariant(sim.organisms());
}

#[test]
fn same_tick_parent_dies_of_old_age_still_has_child() {
    let mut c = cfg(21, 0, 1, 0);
    c.herbivores.max_age = 3;
    let mut sim = Simulation::new(c).unwrap();
    let parent = sim.organisms().alive_ids(Kind::Herbivore)[0];
    sim.run(2); // parent age 2 = lifespan − 1
    let r = sim.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::One(parent), 20.0, ctx.config));
        }
    });
    let kinds: Vec<&EventKind> = r.events.iter().map(|e| &e.kind).collect();
    assert_eq!(kinds.len(), 2);
    assert!(matches!(kinds[0], EventKind::Birth { parents: Parents::One(p), .. } if *p == parent));
    assert_eq!(*kinds[1], EventKind::Death { id: parent, kind: Kind::Herbivore, cause: DeathCause::OldAge, age: 3 });
    assert_eq!(r.events[0].phase, Phase::Births);
    assert_eq!(r.events[1].phase, Phase::Deaths);
    assert_eq!(sim.organisms().count_alive(Kind::Herbivore), 1);
    assert_eq!(sim.organisms().alive(Kind::Herbivore).next().unwrap().age(), 0);
    assert_invariant(sim.organisms());
}

#[test]
fn same_tick_newborn_with_zero_energy_born_and_dies() {
    let mut sim = Simulation::new(cfg(22, 0, 2, 0)).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let next = EntityId(sim.next_entity_id());
    let r = sim.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::Two(h[0], h[1]), 0.0, ctx.config));
        }
    });
    let kinds: Vec<&EventKind> = r.events.iter().map(|e| &e.kind).collect();
    assert_eq!(kinds.len(), 2);
    assert!(matches!(kinds[0], EventKind::Birth { id, .. } if *id == next));
    assert_eq!(*kinds[1], EventKind::Death { id: next, kind: Kind::Herbivore, cause: DeathCause::Starvation, age: 0 });
    let t = sim.totals();
    assert_eq!((t.births_of(Kind::Herbivore), t.deaths_of(Kind::Herbivore)), (1, 1));
    assert!(sim.organisms().get(next).is_none());
    assert_invariant(sim.organisms());
}

#[test]
fn same_tick_newborn_does_not_age_or_act() {
    let mut sim = Simulation::new(cfg(23, 0, 2, 0)).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let kid = EntityId(sim.next_entity_id());
    let mut actors_in_birth_tick: Vec<EntityId> = Vec::new();
    sim.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::Two(h[0], h[1]), 10.0, ctx.config));
        }
        if ctx.phase.is_acting() {
            for k in Kind::ALL {
                actors_in_birth_tick.extend(acting_order(&ctx.world.organisms().alive_ids(k), ctx.rng));
            }
        }
        if ctx.phase == Phase::Births {
            assert!(ctx.world.organisms().is_alive(kid), "exists from the Births phase on");
        }
    });
    assert!(!actors_in_birth_tick.contains(&kid));
    assert_eq!(sim.organisms().get(kid).unwrap().age(), 0);
    assert_eq!(sim.organisms().get(h[0]).unwrap().age(), 1);
    let mut acted = false;
    sim.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            acted = acting_order(&ctx.world.organisms().alive_ids(Kind::Herbivore), ctx.rng).contains(&kid);
        }
    });
    assert!(acted, "acts from the next tick on");
    assert_eq!(sim.organisms().get(kid).unwrap().age(), 1);
}

#[test]
fn same_tick_births_ids_in_request_order() {
    let mut sim = Simulation::new(cfg(24, 3, 2, 2)).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let cs = sim.organisms().alive_ids(Kind::Carnivore);
    let ps = sim.organisms().alive_ids(Kind::Plant);
    let first = sim.next_entity_id();
    let r = sim.step_with(|ctx| {
        if ctx.phase == Phase::Plants {
            sate_carnivores(ctx.world.organisms_mut());
            ctx.world.organisms_mut().request_birth(req(Kind::Carnivore, Parents::Two(cs[0], cs[1]), 9.0, ctx.config));
            ctx.world.organisms_mut().request_birth(req(Kind::Plant, Parents::One(ps[0]), 1.0, ctx.config));
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::Two(h[1], h[0]), 9.0, ctx.config));
            ctx.world.organisms_mut().request_birth(req(Kind::Plant, Parents::One(ps[2]), 1.0, ctx.config));
        }
    });
    let born: Vec<(EntityId, Kind)> = r
        .events
        .iter()
        .filter_map(|e| match e.kind {
            EventKind::Birth { id, kind, .. } => Some((id, kind)),
            _ => None,
        })
        .collect();
    assert_eq!(
        born,
        vec![
            (EntityId(first), Kind::Carnivore),
            (EntityId(first + 1), Kind::Plant),
            (EntityId(first + 2), Kind::Herbivore),
            (EntityId(first + 3), Kind::Plant)
        ]
    );
    for k in Kind::ALL {
        assert!(sim.organisms().stored(k).windows(2).all(|w| w[0].id() < w[1].id()));
    }
    assert_eq!(sim.organisms().get(EntityId(first + 2)).unwrap().parents(), Parents::Two(h[1], h[0]));
}

#[test]
fn same_tick_kill_after_flag_in_deaths_counts_once() {
    let mut c = cfg(25, 0, 0, 1);
    c.carnivores.max_age = 1;
    let mut sim = Simulation::new(c).unwrap();
    let id = sim.organisms().alive_ids(Kind::Carnivore)[0];
    let mut late_kill = None;
    let r = sim.step_with(|ctx| {
        if ctx.phase == Phase::Deaths {
            late_kill = Some(ctx.world.organisms_mut().kill(id, DeathCause::Predation, ctx.tick));
        }
    });
    assert_eq!(late_kill, Some(false), "already dead (OldAge) and removed");
    let deaths = r.events.iter().filter(|e| matches!(e.kind, EventKind::Death { .. })).count();
    assert_eq!(deaths, 1);
    assert_eq!(sim.totals().deaths_of(Kind::Carnivore), 1);
    assert_eq!(sim.totals().deaths_by(Kind::Carnivore, DeathCause::Predation), 0);
}

#[test]
fn same_tick_newborn_of_parent_killed_after_births_survives() {
    // A parent killed in a later phase than Births (here Deaths hook) does not
    // undo an already resolved child.
    let mut sim = Simulation::new(cfg(26, 0, 1, 0)).unwrap();
    let p = sim.organisms().alive_ids(Kind::Herbivore)[0];
    let kid = EntityId(sim.next_entity_id());
    sim.step_with(|ctx| match ctx.phase {
        Phase::Herbivores => {
            ctx.world.organisms_mut().request_birth(req(Kind::Herbivore, Parents::One(p), 10.0, ctx.config))
        }
        Phase::Births => assert!(ctx.world.organisms_mut().kill(p, DeathCause::Predation, ctx.tick)),
        _ => {}
    });
    assert!(sim.organisms().is_alive(kid));
    assert!(sim.organisms().get(p).is_none());
    assert_invariant(sim.organisms());
}

// ---------- founders / determinism ----------

#[test]
fn founders_from_config() {
    let c = cfg(30, 7, 5, 3);
    let sim = Simulation::new(c.clone()).unwrap();
    let p = sim.organisms();
    assert_eq!(p.alive_ids(Kind::Plant), (1..=7).map(EntityId).collect::<Vec<_>>());
    assert_eq!(p.alive_ids(Kind::Herbivore), (8..=12).map(EntityId).collect::<Vec<_>>());
    assert_eq!(p.alive_ids(Kind::Carnivore), (13..=15).map(EntityId).collect::<Vec<_>>());
    assert_eq!(sim.next_entity_id(), 16);
    for k in Kind::ALL {
        for o in p.alive(k) {
            assert!(sim.world().torus().contains(o.pos()));
            assert_eq!((o.generation(), o.parents(), o.age(), o.birth_tick()), (0, Parents::None, 0, 0));
            assert_eq!(o.health(), o.traits().max_health);
        }
    }
    let mut c2 = c.clone();
    c2.plants.initial_energy = 1e6; // above max_energy → clamped
    let s2 = Simulation::new(c2.clone()).unwrap();
    assert!(s2.organisms().alive(Kind::Plant).all(|o| o.energy() == o.traits().max_energy && o.energy() <= c2.plants.max_energy));
}

#[test]
fn founders_zero_initial_valid() {
    let mut sim = Simulation::new(Config::new(1, 1, 1, 0, 0, 0)).unwrap();
    sim.run(5);
    for k in Kind::ALL {
        assert_eq!(sim.organisms().count_alive(k), 0);
    }
    let mut one = Simulation::new(Config::new(1, 1, 1, 2, 1, 1)).unwrap();
    one.run(3);
    assert!(one.organisms().alive(Kind::Plant).all(|o| o.pos() == Cell { x: 0, y: 0 }));
}

#[test]
fn founders_same_seed_identical_different_seed_differs() {
    let a = Simulation::new(cfg(40, 30, 20, 10)).unwrap();
    let b = Simulation::new(cfg(40, 30, 20, 10)).unwrap();
    let c = Simulation::new(cfg(41, 30, 20, 10)).unwrap();
    assert_eq!(a.organisms(), b.organisms());
    assert_ne!(a.organisms(), c.organisms());
}

#[test]
fn founders_do_not_consume_core_rng() {
    let sim = Simulation::new(cfg(42, 30, 20, 10)).unwrap();
    assert_eq!(sim.rng_state(), Rng::seed_from_u64(42).state());
}

#[test]
fn lifecycle_run_deterministic() {
    let mut c = cfg(50, 40, 10, 5);
    c.plants.max_age = 7;
    let run = || {
        let mut s = Simulation::new(c.clone()).unwrap();
        let reps: Vec<TickReport> = (0..300)
            .map(|_| {
                s.step_with(|ctx: &mut PhaseCtx<'_>| {
                    if ctx.phase == Phase::Plants {
                        let ids = ctx.world.organisms().alive_ids(Kind::Plant);
                        for id in acting_order(&ids, ctx.rng).into_iter().take(5) {
                            let pos = ctx.world.organisms().get(id).unwrap().pos();
                            let mut r = req(Kind::Plant, Parents::One(id), 2.0, ctx.config);
                            r.pos = pos;
                            ctx.world.organisms_mut().request_birth(r);
                        }
                    }
                })
            })
            .collect();
        (reps, s.organisms().clone(), *s.totals(), s.rng_state())
    };
    let (a, b) = (run(), run());
    assert_eq!(a, b);
    assert!(a.2.births[0] > 100 && a.2.deaths[0] > 100);
}

#[test]
fn set_population_validates() {
    let mut a = Simulation::new(cfg(60, 5, 5, 5)).unwrap();
    a.run(3);
    let p = a.organisms().clone();
    let mut b = Simulation::new(cfg(61, 0, 0, 0)).unwrap();
    assert!(matches!(b.set_population(p.clone()), Err(crate::sim::SimError::Population(_))), "IDs >= next_id");
    let mut c = Simulation::resume(cfg(60, 5, 5, 5), a.tick(), a.rng_state(), a.next_entity_id()).unwrap();
    c.set_weather_state(a.weather_state()).unwrap();
    c.set_population(p).unwrap();
    assert_eq!(c.organisms(), a.organisms());
    assert_eq!(c.next_entity_id(), 16);
    for _ in 0..20 {
        assert_eq!(a.step(), c.step());
    }
}

// ---------- TASK-010: spatial index sync (ADR-013) ----------

fn living(p: &Population) -> Vec<(EntityId, Kind, Cell)> {
    let mut v: Vec<_> = Kind::ALL.iter().flat_map(|k| p.alive(*k).map(|o| (o.id(), o.kind(), o.pos()))).collect();
    v.sort_by_key(|e| e.0);
    v
}

#[test]
fn index_tracks_founders_births_kills_moves() {
    let mut sim = Simulation::new(cfg(77, 30, 20, 10)).unwrap();
    assert_eq!(sim.organisms().index().len(), 60);
    sim.organisms().validate(sim.next_entity_id()).unwrap();
    let torus = *sim.world().torus();
    let mut r = Rng::seed_from_u64(99);
    let (mut moves, mut kills, mut births) = (0, 0, 0);
    for _ in 0..100 {
        sim.step_with(|ctx| {
            if ctx.phase == Phase::Herbivores || ctx.phase == Phase::Carnivores {
                let k = if ctx.phase == Phase::Herbivores { Kind::Herbivore } else { Kind::Carnivore };
                for id in acting_order(&ctx.world.organisms().alive_ids(k), ctx.rng) {
                    if ctx.world.organisms().get_alive(id).is_none() {
                        continue;
                    }
                    let to = Cell { x: r.below(20) as u32, y: r.below(16) as u32 };
                    let from = ctx.world.organisms().get_alive(id).unwrap().pos();
                    assert_eq!(ctx.world.organisms_mut().move_organism(id, to), Ok(from));
                    moves += 1;
                    let p = ctx.world.organisms();
                    assert!(p.at(from, None).iter().all(|i| *i != id) || from == to);
                    assert!(p.at(to, Some(k)).contains(&id));
                    if r.chance(0.05) {
                        let near = ctx.world.organisms().within(to, 2, None);
                        if let Some(v) = near.iter().find(|n| n.id != id) {
                            assert!(ctx.world.organisms_mut().kill(v.id, DeathCause::Predation, ctx.tick));
                            assert!(ctx.world.organisms().within(v.cell, 0, None).iter().all(|n| n.id != v.id));
                            kills += 1;
                        }
                    }
                }
            }
            if ctx.phase == Phase::Plants {
                let alive = ctx.world.organisms().alive_ids(Kind::Plant);
                for _ in 0..r.below(4) {
                    let parents = if alive.is_empty() { Parents::None } else { Parents::One(alive[r.below(alive.len() as u64) as usize]) };
                    // Out-of-world request positions are wrapped into the torus.
                    let mut q = req(Kind::Plant, parents, 5.0, ctx.config);
                    q.pos = Cell { x: 20 + r.below(5) as u32, y: r.below(40) as u32 };
                    ctx.world.organisms_mut().request_birth(q);
                    births += 1;
                }
            }
            let p = ctx.world.organisms();
            p.index().check_against(living(p)).unwrap();
        });
        sim.organisms().validate(sim.next_entity_id()).unwrap();
        for k in Kind::ALL {
            assert!(sim.organisms().stored(k).iter().all(|o| torus.contains(o.pos())));
        }
    }
    assert!(moves > 500 && kills > 5 && births > 50, "{moves} {kills} {births}");
}

#[test]
fn move_organism_errors_and_dead_disappear_at_once() {
    let mut sim = Simulation::new(cfg(8, 3, 3, 0)).unwrap();
    let h = sim.organisms().alive_ids(Kind::Herbivore);
    let next = sim.next_entity_id();
    let p = sim.organisms_mut();
    let pos = p.get(h[0]).unwrap().pos();
    assert_eq!(p.move_organism(h[0], Cell { x: 20, y: 0 }), Err(crate::spatial::SpatialError::OutsideWorld(Cell { x: 20, y: 0 })));
    assert_eq!(p.get(h[0]).unwrap().pos(), pos, "failed move leaves position");
    assert_eq!(p.move_organism(EntityId(999), Cell { x: 0, y: 0 }), Err(crate::spatial::SpatialError::Unknown(EntityId(999))));
    assert!(p.kill(h[0], DeathCause::Predation, 0));
    assert!(!p.index().contains(h[0]));
    assert!(p.within(pos, 50, None).iter().all(|n| n.id != h[0]), "flagged dead never returned");
    assert_eq!(p.move_organism(h[0], Cell { x: 0, y: 0 }), Err(crate::spatial::SpatialError::Unknown(h[0])));
    p.validate(next).unwrap();
    sim.step();
    sim.organisms().validate(sim.next_entity_id()).unwrap();
}

#[test]
fn set_population_rebuilds_index() {
    let mut a = Simulation::new(cfg(60, 5, 5, 5)).unwrap();
    a.run(3);
    let mut p = a.organisms().clone();
    p.rebuild_index(Torus::new(3, 3).unwrap()).ok(); // stale/foreign index, possibly partial
    let mut c = Simulation::resume(cfg(60, 5, 5, 5), a.tick(), a.rng_state(), a.next_entity_id()).unwrap();
    c.set_weather_state(a.weather_state()).unwrap();
    c.set_population(p).unwrap();
    assert_eq!(c.organisms().index(), a.organisms().index());
    assert_eq!(c.organisms(), a.organisms());
    // A position outside the world is rejected.
    let mut bad = a.organisms().clone();
    let id = bad.alive_ids(Kind::Plant)[0];
    bad.get_mut(id).unwrap().set_pos(Cell { x: 500, y: 0 });
    let mut d = Simulation::resume(cfg(60, 5, 5, 5), a.tick(), a.rng_state(), a.next_entity_id()).unwrap();
    assert!(matches!(d.set_population(bad), Err(crate::sim::SimError::Population(_))));
}

#[test]
fn identical_sims_give_identical_queries() {
    let mut a = Simulation::new(cfg(4, 40, 20, 10)).unwrap();
    let mut b = Simulation::new(cfg(4, 40, 20, 10)).unwrap();
    a.run(5);
    b.run(5);
    for (x, y, r) in [(0, 0, 3), (19, 15, 2), (7, 7, 30)] {
        assert_eq!(a.organisms().within(Cell { x, y }, r, None), b.organisms().within(Cell { x, y }, r, None));
    }
}

/// TASK-026 (ADR-029 §3C): the derived ID-column cache stays in sync through
/// founders, births, deaths and checkpoint restore, and the kind-aware lookup
/// `get_alive_of` agrees with `get_alive` for every stored organism.
#[test]
fn id_column_cache_and_kind_lookup_match_get_alive() {
    let check = |p: &Population| {
        assert!(p.id_cols_in_sync_for_test());
        for k in Kind::ALL {
            for o in p.stored(k) {
                assert_eq!(p.get_alive_of(k, o.id()).map(|x| x.id()), p.get_alive(o.id()).map(|x| x.id()));
                for other in Kind::ALL.into_iter().filter(|x| *x != k) {
                    assert!(p.get_alive_of(other, o.id()).is_none());
                }
            }
        }
        assert!(p.get_alive_of(Kind::Plant, EntityId(u64::MAX)).is_none());
    };
    let mut sim = Simulation::new(cfg(11, 150, 60, 10)).unwrap();
    check(sim.world().organisms());
    let mut births = 0usize;
    for _ in 0..120 {
        let rep = sim.step_with(|ctx| {
            if ctx.phase == Phase::Herbivores {
                // Mid-tick (flagged-dead organisms still stored).
                check(ctx.world.organisms());
            }
        });
        births += rep.events.iter().filter(|e| matches!(e.kind, EventKind::Birth { .. })).count();
        check(sim.world().organisms());
    }
    assert!(births > 0, "test should cover births");
    let text = crate::snapshot::to_json_string(&sim).unwrap();
    let back = crate::snapshot::from_json_str(&text).unwrap();
    check(back.world().organisms());
    assert_eq!(back.state_hash(), sim.state_hash());
}

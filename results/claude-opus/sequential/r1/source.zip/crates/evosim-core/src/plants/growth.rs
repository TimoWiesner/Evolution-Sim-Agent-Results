//! Plant growth, upkeep and climate stress (ADR-014). Pure functions plus
//! the Plants-phase driver [`grow_plants`]. Deterministic, no RNG.

use super::resources::{moisture, CellResources};
use crate::climate::CellNow;
use crate::config::PlantParams;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Population, Traits};
use crate::topology::Torus;

/// Thermal suitability `max(0, 1 − ((T − opt)/tol)²)`.
pub fn thermal_factor(t: &Traits, temperature: f64) -> f64 {
    let tol = t.temp_tolerance.max(1e-9);
    let z = (temperature - t.temp_optimum) / tol;
    (1.0 - z * z).max(0.0)
}

/// Water suitability: linear ramp from `water_min` (0) to `water_optimum` (1).
pub fn water_factor(m: f64, p: &PlantParams) -> f64 {
    if p.water_optimum <= p.water_min {
        return if m >= p.water_min { 1.0 } else { 0.0 };
    }
    ((m - p.water_min) / (p.water_optimum - p.water_min)).clamp(0.0, 1.0)
}

/// Generalist cost: `1 − generalist_cost · clamp((tol − 2)/28, 0, 1)`.
pub fn generalist_peak(t: &Traits, p: &PlantParams) -> f64 {
    1.0 - p.generalist_cost * ((t.temp_tolerance - 2.0) / 28.0).clamp(0.0, 1.0)
}

/// Climate stress `max(s_T, s_W)` in `[0, 1]`: temperature beyond the
/// tolerance or moisture below `water_min`.
pub fn stress(t: &Traits, now: CellNow, m: f64, p: &PlantParams) -> f64 {
    let tol = t.temp_tolerance.max(1e-9);
    let s_t = ((now.temperature - t.temp_optimum).abs() / tol - 1.0).clamp(0.0, 1.0);
    let s_w = if p.water_min > 0.0 && m < p.water_min { 1.0 - m / p.water_min } else { 0.0 };
    s_t.max(s_w)
}

/// Uptake rate before energy headroom and resource sharing:
/// `growth_rate · f_T · f_W · peak`.
pub fn potential_gain(t: &Traits, now: CellNow, max_precipitation: f64, p: &PlantParams) -> f64 {
    let m = moisture(now.precipitation, max_precipitation);
    (p.growth_rate * thermal_factor(t, now.temperature) * water_factor(m, p) * generalist_peak(t, p)).max(0.0)
}

/// Upkeep per tick: `upkeep · (0.75 + 0.5·strength)`.
pub fn upkeep_cost(t: &Traits, p: &PlantParams) -> f64 {
    p.upkeep * (0.75 + 0.5 * t.strength)
}

/// Totals of one Plants phase.
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct GrowthTick {
    /// Resource removed from cells = energy gained by plants.
    pub uptake: f64,
    /// Energy spent on upkeep.
    pub upkeep: f64,
    /// Plants killed with `DeathCause::Climate`.
    pub climate_deaths: u32,
}

/// Plants phase growth (ADR-014): fair-share uptake per cell, upkeep,
/// climate stress damage/healing and climate deaths. Order-independent.
pub fn grow_plants(
    pop: &mut Population,
    res: &mut CellResources,
    now: &[CellNow],
    torus: &Torus,
    p: &PlantParams,
    max_precipitation: f64,
    tick: u64,
) -> GrowthTick {
    let w = torus.width() as usize;
    let ids = pop.alive_ids(Kind::Plant);
    // Demand per plant (ascending id) and per cell.
    let mut demand: Vec<(EntityId, usize, f64)> = Vec::with_capacity(ids.len());
    let mut cell_demand = vec![0.0f64; res.values().len()];
    for &id in &ids {
        let o = pop.get_alive(id).expect("alive id");
        let ci = o.pos().y as usize * w + o.pos().x as usize;
        let headroom = (o.traits().max_energy - o.energy()).max(0.0);
        let d = potential_gain(o.traits(), now[ci], max_precipitation, p).min(headroom);
        cell_demand[ci] += d;
        demand.push((id, ci, d));
    }
    let share: Vec<f64> = cell_demand
        .iter()
        .zip(res.values())
        .map(|(&dd, &r)| if dd > r && dd > 0.0 { r / dd } else { 1.0 })
        .collect();
    let mut out = GrowthTick::default();
    let mut to_kill: Vec<EntityId> = Vec::new();
    for (id, ci, d) in demand {
        let grant = (d * share[ci]).min(res.values()[ci]).max(0.0);
        let o = pop.get_alive_mut(id).expect("alive id");
        let gained = o.add_energy(grant);
        let r = &mut res.values_mut()[ci];
        *r = (*r - gained).max(0.0);
        out.uptake += gained;
        out.upkeep += o.spend_energy(upkeep_cost(o.traits(), p));
        let m = moisture(now[ci].precipitation, max_precipitation);
        let s = stress(o.traits(), now[ci], m, p);
        let mh = o.traits().max_health;
        if s > 0.0 {
            o.damage(p.stress_damage * mh * s);
            if o.health() <= 0.0 {
                to_kill.push(id);
            }
        } else {
            o.heal(p.heal_rate * mh);
        }
    }
    for id in to_kill {
        if pop.kill(id, DeathCause::Climate, tick) {
            out.climate_deaths += 1;
        }
    }
    out
}

//! Checkpoint tests (ADR-025): exact round trip, save-and-resume equals an
//! uninterrupted run at several split points, every error class.

use super::*;
use crate::organism::Kind;

/// Small world with all three kinds, weather on, short maturity so animals
/// mate, carnivores hunt (handling/cooldown state), forced plant mutation so
/// species split.
fn busy_cfg(seed: u64) -> Config {
    let mut c = Config::new(seed, 24, 16, 120, 30, 8);
    c.herbivores.maturity_age = 15;
    c.carnivores.maturity_age = 25;
    c.plants.mutation_rate = 1.0;
    c.plants.mutation_strength = 0.3;
    c.climate.weather_scale = 6;
    c
}

fn stepped(cfg: &Config, n: u64) -> Simulation {
    let mut s = Simulation::new(cfg.clone()).unwrap();
    s.run(n);
    s
}

fn round_trip(s: &Simulation) -> Simulation {
    let text = s.checkpoint_json().unwrap();
    Simulation::from_checkpoint_json(&text).unwrap()
}

/// Everything observable that the result JSON uses, plus the full hash.
fn observe(s: &Simulation) -> (String, u64, crate::organism::LifeTotals, [usize; 3], [usize; 3], u64) {
    (
        s.state_hash(),
        s.tick(),
        *s.totals(),
        Kind::ALL.map(|k| s.organisms().count_alive(k)),
        Kind::ALL.map(|k| s.living_species(k)),
        s.next_entity_id(),
    )
}

#[test]
fn round_trip_is_exact_at_several_ticks() {
    let cfg = busy_cfg(3);
    for n in [0u64, 1, 150] {
        let s = stepped(&cfg, n);
        let r = round_trip(&s);
        assert_eq!(observe(&s), observe(&r), "tick {n}");
        assert!(s.organisms() == r.organisms(), "organisms with genomes at tick {n}");
        assert_eq!(s.species(), r.species(), "species registry at tick {n}");
        assert_eq!(s.weather_state(), r.weather_state());
        assert_eq!(s.world().current_grid(), r.world().current_grid());
        assert_eq!(s.world().climate(), r.world().climate(), "rebuilt base climate");
        assert_eq!(s.organisms().index(), r.organisms().index(), "rebuilt spatial index");
        assert_eq!(s.rng_state(), r.rng_state());
        assert_eq!(s.config(), r.config());
        // A checkpoint of the restored simulation is byte-identical.
        assert_eq!(s.checkpoint_json().unwrap(), r.checkpoint_json().unwrap());
    }
}

#[test]
fn busy_config_exercises_the_state() {
    // Guard that the split tests below cover rich state.
    let s = stepped(&busy_cfg(3), 200);
    assert!(s.species().iter().count() > 3, "species split happened");
    assert!(s.totals().births[0] > 0 && s.totals().births[1] + s.totals().births[2] > 0, "plants and animals reproduced: {:?}", s.totals());
    assert!(s.totals().deaths[1] > 0, "herbivores died (predation: carnivore handling state used)");
    assert!(s.totals().deaths.iter().sum::<u64>() > 0);
}

#[test]
fn save_and_resume_equals_uninterrupted_at_split_points() {
    let cfg = busy_cfg(11);
    let b = 120;
    for a in [0u64, 1, 37, 200] {
        let whole = stepped(&cfg, a + b);
        let first = stepped(&cfg, a);
        let mut resumed = Simulation::from_checkpoint_json(&first.checkpoint_json().unwrap()).unwrap();
        assert_eq!(resumed.tick(), a);
        resumed.run(b);
        assert_eq!(observe(&whole), observe(&resumed), "split at {a}");
        assert!(whole.organisms() == resumed.organisms(), "split at {a}");
    }
}

#[test]
fn chained_checkpoints_equal_uninterrupted() {
    let cfg = busy_cfg(5);
    let whole = stepped(&cfg, 90);
    let mut s = Simulation::new(cfg).unwrap();
    for _ in 0..3 {
        s.run(30);
        s = round_trip(&s);
    }
    assert_eq!(observe(&whole), observe(&s));
}

#[test]
fn seeded_random_split_points() {
    for seed in 1..=4u64 {
        let cfg = busy_cfg(seed * 101);
        let mut r = Rng::seed_from_u64(seed);
        let a = r.below(80);
        let b = 1 + r.below(60);
        let whole = stepped(&cfg, a + b);
        let mut res = round_trip(&stepped(&cfg, a));
        res.run(b);
        assert_eq!(observe(&whole), observe(&res), "seed {seed} split {a}+{b}");
    }
}

#[test]
fn resume_after_total_extinction() {
    let cfg = Config::new(9, 16, 12, 0, 10, 4);
    let mut whole = stepped(&cfg, 400);
    assert_eq!(Kind::ALL.map(|k| whole.organisms().count_alive(k)), [0, 0, 0], "everything extinct");
    let mut res = round_trip(&whole);
    whole.run(20);
    res.run(20);
    assert_eq!(observe(&whole), observe(&res));
}

fn text_of(cfg: &Config, n: u64) -> String {
    stepped(cfg, n).checkpoint_json().unwrap()
}

/// A JSON edit applied to a checkpoint document.
type Edit = Box<dyn Fn(&mut Value)>;

fn edit(text: &str, f: impl FnOnce(&mut Value)) -> String {
    let mut v: Value = serde_json::from_str(text).unwrap();
    f(&mut v);
    serde_json::to_string(&v).unwrap()
}

#[test]
fn header_fields_present() {
    let cfg = busy_cfg(2);
    let s = stepped(&cfg, 10);
    let v: Value = serde_json::from_str(&s.checkpoint_json().unwrap()).unwrap();
    assert_eq!(v["format"], CHECKPOINT_FORMAT);
    assert_eq!(v["version"], CHECKPOINT_VERSION);
    assert_eq!(v["tick"], 10);
    assert_eq!(v["engine"], crate::VERSION);
    assert_eq!(v["state_hash"], s.state_hash());
    for key in ["tick", "rng", "ids", "world"] {
        assert!(v["state"].get(key).is_some(), "state.{key}");
    }
    for key in ["torus", "weather", "now", "climate_tick", "organisms", "resources", "plant_ledger", "herbivore_ledger", "hunt_ledger", "repro_ledger", "last_moves", "stats"] {
        assert!(v["state"]["world"].get(key).is_some(), "state.world.{key}");
    }
    for key in ["by_kind", "pending", "totals", "tick_deaths", "last_deaths", "last_births", "births_dropped_full", "species"] {
        assert!(v["state"]["world"]["organisms"].get(key).is_some(), "organisms.{key}");
    }
    assert!(v["state"]["world"]["organisms"].get("index").is_none(), "caches are not stored");
}

#[test]
fn garbage_and_truncation_are_parse_errors() {
    for bad in ["", " ", "garbage", "{", "[1,2", "\"evosim-checkpoint\" 1"] {
        assert!(matches!(from_json_str(bad), Err(SnapshotError::Parse(_))), "{bad:?}");
    }
    let text = text_of(&busy_cfg(4), 30);
    let n = text.len();
    for k in 1..=10 {
        let cut = n * k / 11;
        let t = &text[..cut];
        assert!(matches!(from_json_str(t), Err(SnapshotError::Parse(_))), "cut at {cut} of {n}");
    }
    // Only the trailing newline removed: still a complete document.
    assert!(from_json_str(text.trim_end()).is_ok());
}

#[test]
fn wrong_format_or_version_is_a_version_error() {
    let text = text_of(&busy_cfg(4), 5);
    let cases: Vec<Edit> = vec![
        Box::new(|v| v["version"] = Value::from(2)),
        Box::new(|v| v["version"] = Value::from(0)),
        Box::new(|v| v["version"] = Value::from("1")),
        Box::new(|v| v["version"] = Value::from(1.5)),
        Box::new(|v| {
            v.as_object_mut().unwrap().remove("version");
        }),
        Box::new(|v| v["format"] = Value::from("other")),
        Box::new(|v| {
            v.as_object_mut().unwrap().remove("format");
        }),
    ];
    for (i, c) in cases.into_iter().enumerate() {
        let t = edit(&text, c);
        assert!(matches!(from_json_str(&t), Err(SnapshotError::Version(_))), "case {i}");
    }
    assert!(matches!(from_json_str("[1,2,3]"), Err(SnapshotError::Version(_))));
}

#[test]
fn missing_or_bad_fields_are_invalid() {
    let text = text_of(&busy_cfg(4), 5);
    let cases: Vec<(&str, Edit)> = vec![
        ("no world", Box::new(|v| {
            v["state"].as_object_mut().unwrap().remove("world");
        })),
        ("no state", Box::new(|v| {
            v.as_object_mut().unwrap().remove("state");
        })),
        ("no config", Box::new(|v| {
            v.as_object_mut().unwrap().remove("config");
        })),
        ("unknown config key", Box::new(|v| v["config"]["bogus"] = Value::from(1))),
        ("bad config value", Box::new(|v| v["config"]["world"]["width"] = Value::from(0))),
        ("world size differs", Box::new(|v| v["config"]["world"]["width"] = Value::from(25))),
        ("tick mismatch", Box::new(|v| v["tick"] = Value::from(6))),
        ("energy is a string", Box::new(|v| v["state"]["world"]["organisms"]["by_kind"][0][0]["energy"] = Value::from("x"))),
        ("zero rng", Box::new(|v| v["state"]["rng"]["s"] = serde_json::json!([0, 0, 0, 0]))),
        ("short resources", Box::new(|v| {
            v["state"]["world"]["resources"]["values"].as_array_mut().unwrap().pop();
        })),
        ("short climate grid", Box::new(|v| {
            v["state"]["world"]["now"].as_array_mut().unwrap().pop();
        })),
        ("short weather", Box::new(|v| {
            v["state"]["world"]["weather"]["temperature"].as_array_mut().unwrap().pop();
        })),
        ("organism outside world", Box::new(|v| v["state"]["world"]["organisms"]["by_kind"][0][0]["pos"]["x"] = Value::from(999))),
        ("id beyond counter", Box::new(|v| v["state"]["ids"]["next"] = Value::from(2))),
        ("no hash", Box::new(|v| {
            v.as_object_mut().unwrap().remove("state_hash");
        })),
    ];
    for (name, c) in cases {
        let t = edit(&text, c);
        match from_json_str(&t) {
            Err(SnapshotError::Invalid(_)) => {}
            other => panic!("{name}: expected Invalid, got {:?}", other.map(|s| s.tick())),
        }
    }
}

#[test]
fn tampered_values_fail_the_integrity_check() {
    let text = text_of(&busy_cfg(4), 40);
    let cases: Vec<(&str, Edit)> = vec![
        ("energy", Box::new(|v| {
            let e = &mut v["state"]["world"]["organisms"]["by_kind"][0][0]["energy"];
            *e = Value::from(e.as_f64().unwrap() * 0.5);
        })),
        ("stored hash", Box::new(|v| v["state_hash"] = Value::from("0".repeat(64)))),
        ("birth counter", Box::new(|v| {
            let b = &mut v["state"]["world"]["organisms"]["totals"]["births"][0];
            *b = Value::from(b.as_u64().unwrap() + 1);
        })),
        ("resource", Box::new(|v| v["state"]["world"]["resources"]["values"][3] = Value::from(0.125))),
        ("seed", Box::new(|v| v["config"]["seed"] = Value::from(77))),
    ];
    for (name, c) in cases {
        let t = edit(&text, c);
        assert!(matches!(from_json_str(&t), Err(SnapshotError::Integrity { .. })), "{name}");
    }
}

#[test]
fn error_messages_are_one_line() {
    for e in [from_json_str("x").err().unwrap(), from_json_str("{\"format\":\"evosim-checkpoint\",\"version\":9}").err().unwrap()] {
        let m = e.to_string();
        assert!(!m.is_empty() && !m.contains('\n'), "{m}");
    }
}

//! Plant growth, cell resources, climate stress (TASK-011, ADR-014).
//!
//! Energy source: the soil resource `R` of each cell ([`CellResources`]),
//! refilled in the Resources phase from the cell's current moisture up to
//! `plants.resource_cap`. In the Plants phase each living plant takes up a
//! fair share of its cell's `R` (1 resource unit = 1 energy unit), limited by
//! temperature and water suitability, its genome-derived traits and its
//! energy headroom; upkeep (respiration) then removes energy. No plant energy
//! appears without being removed from `R` first ([`PlantLedger`]).
//! Growth draws nothing from the core RNG; reproduction ([`repro`], TASK-012,
//! ADR-015) draws from it in the Plants phase after growth.

pub mod growth;
pub mod repro;
pub mod resources;

#[cfg(test)]
mod tests;
#[cfg(test)]
mod tests_repro;

pub use growth::{generalist_peak, grow_plants, potential_gain, stress, thermal_factor, upkeep_cost, water_factor, GrowthTick};
pub use repro::{dispersal_target, reproduce_plants, seed_probability, site_ok, ReproTick};
pub use resources::{moisture, CellResources};

/// Cumulative audit of plant energy flows since tick 0 (plus last tick).
#[derive(Debug, Clone, Copy, PartialEq, Default, serde::Serialize, serde::Deserialize)]
pub struct PlantLedger {
    /// Resource added to all cells by regeneration.
    pub regen_added: f64,
    /// Resource removed from cells = energy gained by plants.
    pub uptake: f64,
    /// Energy spent by plants on upkeep.
    pub upkeep: f64,
    pub last_regen: f64,
    pub last_uptake: f64,
    pub last_upkeep: f64,
    /// Energy paid by plants for seeds (ADR-015).
    pub reproduction_spent: f64,
    /// Energy handed to accepted seeds (≤ `reproduction_spent`).
    pub seed_energy: f64,
    pub seeds_made: u64,
    pub seeds_failed: u64,
    pub seeds_requested: u64,
    pub pollinated: u64,
    pub last_reproduction_spent: f64,
    pub last_seed_energy: f64,
    pub last_seeds_made: u32,
    pub last_seeds_failed: u32,
    pub last_seeds_requested: u32,
    pub last_pollinated: u32,
}

impl PlantLedger {
    pub(crate) fn record_regen(&mut self, added: f64) {
        self.regen_added += added;
        self.last_regen = added;
    }

    pub(crate) fn record_growth(&mut self, g: &GrowthTick) {
        self.uptake += g.uptake;
        self.upkeep += g.upkeep;
        self.last_uptake = g.uptake;
        self.last_upkeep = g.upkeep;
    }

    pub(crate) fn record_repro(&mut self, r: &ReproTick) {
        self.reproduction_spent += r.spent;
        self.seed_energy += r.seed_energy;
        self.seeds_made += r.made as u64;
        self.seeds_failed += r.failed as u64;
        self.seeds_requested += r.requested as u64;
        self.pollinated += r.pollinated as u64;
        self.last_reproduction_spent = r.spent;
        self.last_seed_energy = r.seed_energy;
        self.last_seeds_made = r.made;
        self.last_seeds_failed = r.failed;
        self.last_seeds_requested = r.requested;
        self.last_pollinated = r.pollinated;
    }
}

//! Genome, inheritance and mutation (TASK-009, ADR-012; refines ADR-004).
//!
//! A [`Genome`] is the kind plus a fixed-length vector of `f32` genes in
//! `[0, 1]` laid out by the per-kind [`gene_table`] (layout
//! [`GENE_LAYOUT_VERSION`]). Traits are derived from it by the pure function
//! [`express`]. Children are produced by [`Genome::copy_of`] (one parent) or
//! [`crossover`] (two parents), then [`mutate`]d with [`MutationParams`] using
//! the generator passed in (behaviour tasks pass the simulation core RNG,
//! `PhaseCtx::rng`). [`distance`] is the genetic distance in `[0, 1]`.

mod express;
mod ops;
mod table;

#[cfg(test)]
mod tests;

pub use express::{express, Expression, KindScale};
pub use ops::{child_asexual, child_sexual, crossover, distance, mutate, reflect_unit, MutationParams};
pub use table::{gene_index, gene_table, GeneSpec, GeneTrait, GENE_LAYOUT_VERSION};

use crate::organism::Kind;
use std::fmt;

/// XOR tag of the founder-genome jitter generator seed (core RNG untouched).
pub const FOUNDER_GENOME_TAG: u64 = 0x0F0B_DE25_0000_0009;

/// Heritable DNA of one organism.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Genome {
    kind: Kind,
    genes: Vec<f32>,
}

/// Invalid genome construction or operator input.
#[derive(Debug, Clone, PartialEq)]
pub enum GenomeError {
    /// Two genomes of different kinds were combined.
    KindMismatch { a: Kind, b: Kind },
    /// Gene vector length does not match the kind's table.
    WrongLength { kind: Kind, expected: usize, got: usize },
    /// Gene not finite or outside `[0, 1]`.
    OutOfRange { index: usize, value: f32 },
}

impl fmt::Display for GenomeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            GenomeError::KindMismatch { a, b } => write!(f, "genome kind mismatch: {} vs {}", a.name(), b.name()),
            GenomeError::WrongLength { kind, expected, got } => {
                write!(f, "{} genome needs {expected} genes, got {got}", kind.name())
            }
            GenomeError::OutOfRange { index, value } => write!(f, "gene {index} = {value} not in [0, 1]"),
        }
    }
}

impl std::error::Error for GenomeError {}

impl Genome {
    /// Validated construction: length = table length, every gene finite in `[0, 1]`.
    pub fn from_genes(kind: Kind, genes: Vec<f32>) -> Result<Genome, GenomeError> {
        let expected = gene_table(kind).len();
        if genes.len() != expected {
            return Err(GenomeError::WrongLength { kind, expected, got: genes.len() });
        }
        if let Some((index, &value)) = genes.iter().enumerate().find(|(_, v)| !(v.is_finite() && (0.0..=1.0).contains(*v))) {
            return Err(GenomeError::OutOfRange { index, value });
        }
        Ok(Genome { kind, genes })
    }

    /// Founder default genome (table `founder` column); expresses to the
    /// TASK-008 founder default traits.
    pub fn founder_default(kind: Kind) -> Genome {
        Genome { kind, genes: gene_table(kind).iter().map(|s| s.founder).collect() }
    }

    pub fn kind(&self) -> Kind {
        self.kind
    }

    pub fn genes(&self) -> &[f32] {
        &self.genes
    }

    pub fn len(&self) -> usize {
        self.genes.len()
    }

    pub fn is_empty(&self) -> bool {
        self.genes.is_empty()
    }

    /// Value of the gene expressed into `t` (`None` if the kind has none).
    pub fn gene(&self, t: GeneTrait) -> Option<f32> {
        gene_index(self.kind, t).map(|i| self.genes[i])
    }

    /// Asexual inheritance: exact copy of the parent (mutation applied separately).
    pub fn copy_of(parent: &Genome) -> Genome {
        parent.clone()
    }

    pub(crate) fn genes_mut(&mut self) -> &mut [f32] {
        &mut self.genes
    }
}

#[cfg(test)]
impl Genome {
    /// Test-only: change gene `i` by one f32 ULP.
    pub(crate) fn nudge_gene_for_test(&mut self, i: usize) {
        let g = &mut self.genes[i];
        *g = if *g > 0.5 { f32::from_bits(g.to_bits() - 1) } else { f32::from_bits(g.to_bits() + 1) };
    }
}

//! TASK-015 tests (ADR-018): pursuit within vision, attack reach, trait- and
//! RNG-dependent outcomes, single predation death, gain ≤ prey energy,
//! attack cost, handling, starvation without prey, run-level invariants.

use super::hunt::*;
use super::*;
use crate::climate::CellNow;
use crate::config::Config;
use crate::genome::{gene_index, Expression, GeneTrait, Genome};
use crate::ids::{EntityId, IdAllocator};
use crate::organism::{BirthRequest, DeathCause, Kind, Parents, Population};
use crate::rng::Rng;
use crate::sim::{Phase, Simulation};
use crate::topology::{Cell, Torus};

fn c(x: u32, y: u32) -> Cell {
    Cell { x, y }
}

fn genome(kind: Kind, set: &[(GeneTrait, f32)]) -> Genome {
    let mut g = Genome::founder_default(kind).genes().to_vec();
    for &(t, v) in set {
        g[gene_index(kind, t).unwrap()] = v;
    }
    Genome::from_genes(kind, g).unwrap()
}

struct Bench {
    pop: Population,
    ids: IdAllocator,
    w: u32,
    h: u32,
    cfg: Config,
    rng: Rng,
}

impl Bench {
    fn new(w: u32, h: u32, seed: u64) -> Bench {
        Bench {
            pop: Population::with_expression(Expression::default(), Torus::new(w, h).unwrap()),
            ids: IdAllocator::new(),
            w,
            h,
            cfg: Config::contract_example().pre_task018(),
            rng: Rng::seed_from_u64(seed),
        }
    }
    fn add(&mut self, g: Genome, at: Cell, energy: f64) -> EntityId {
        self.pop.request_birth(BirthRequest { pos: at, parents: Parents::None, energy, health: None, genome: g });
        let r = self.pop.resolve_births(0, &mut self.ids);
        assert_eq!(r.len(), 1, "placement refused");
        let id = r[0].id;
        self.pop.get_alive_mut(id).unwrap().set_energy(energy);
        id
    }
    fn herb(&mut self, at: Cell, genes: &[(GeneTrait, f32)], energy: f64) -> EntityId {
        self.add(genome(Kind::Herbivore, genes), at, energy)
    }
    fn carn(&mut self, at: Cell, genes: &[(GeneTrait, f32)], energy: f64) -> EntityId {
        self.add(genome(Kind::Carnivore, genes), at, energy)
    }
    fn energy(&self, id: EntityId) -> f64 {
        self.pop.get_alive(id).map(|o| o.energy()).unwrap_or(-1.0)
    }
    fn hp(&self) -> HuntParams {
        HuntParams::from_config(&self.cfg)
    }
    fn hit(&mut self, pred: EntityId, prey: EntityId) -> Attack {
        let hp = self.hp();
        attack(&mut self.pop, pred, prey, &hp, 1, &mut self.rng)
    }
    fn turn(&mut self, id: EntityId) -> CarnivoreTurn {
        let now = vec![CellNow { temperature: 10.0, precipitation: 500.0 }; (self.w * self.h) as usize];
        let fp = carnivore::carnivore_feed_params(&self.cfg);
        let hp = self.hp();
        let costs = MoveCosts::for_kind(Kind::Carnivore, &self.cfg);
        let rp = crate::animals::repro::ReproParams::for_kind(Kind::Carnivore, &self.cfg);
        carnivore_turn(&mut self.pop, id, &fp, &hp, &costs, &rp, &now, self.w, 1, &mut self.rng).expect("living carnivore")
    }
    fn dist(&self, a: EntityId, b: EntityId) -> u32 {
        self.pop.index().torus().distance(self.pop.get_alive(a).unwrap().pos(), self.pop.get_alive(b).unwrap().pos())
    }
}

// ---------- AC1: pursuit within vision, attack only from reach ≤ 1 ----------

#[test]
fn attacks_only_in_reach() {
    let mut b = Bench::new(20, 20, 1);
    let cr = b.carn(c(0, 0), &[], 50.0);
    let far = b.herb(c(2, 0), &[], 50.0);
    let before = b.rng.state();
    let a = b.hit(cr, far);
    assert!(a.refused && !a.success && a.cost == 0.0 && a.distance == 2);
    assert_eq!(b.energy(cr), 50.0, "refused attack costs nothing");
    assert_eq!(b.rng.state(), before, "refused attack draws no RNG");
    assert!(b.pop.is_alive(far));
    // Adjacent across the x-wrap: allowed.
    let wrap = b.herb(c(19, 0), &[], 50.0);
    let a = b.hit(cr, wrap);
    assert!(!a.refused && a.distance == 1);
    // Same cell: allowed, range factor 1.
    let mut b = Bench::new(20, 20, 1);
    let cr = b.carn(c(5, 5), &[], 50.0);
    let same = b.herb(c(5, 5), &[], 50.0);
    let a = b.hit(cr, same);
    assert!(!a.refused && a.distance == 0);
    // Wrong kinds are refused.
    let other = b.carn(c(5, 6), &[], 50.0);
    assert!(b.hit(cr, other).refused);
}

#[test]
fn pursues_visible_prey_until_attack() {
    let mut b = Bench::new(40, 40, 3);
    let cr = b.carn(c(10, 10), &[], 40.0);
    let r = vision_radius(b.pop.get_alive(cr).unwrap().traits());
    assert!(r >= 4, "vision radius {r}");
    let prey = b.herb(c(10 + r, 12), &[], 50.0);
    let mut d = b.dist(cr, prey);
    assert_eq!(d, r);
    let mut attacked = false;
    for _ in 0..(2 * r) {
        let t = b.turn(cr);
        match t.action {
            CarnivoreAction::Pursue => {
                let nd = b.dist(cr, prey);
                assert!(nd < d, "pursuit closes in: {d} -> {nd}");
                assert!(t.attack.is_none());
                d = nd;
            }
            CarnivoreAction::PursueAttack | CarnivoreAction::Attack => {
                let a = t.attack.unwrap();
                assert!(!a.refused && a.distance <= ATTACK_REACH);
                attacked = true;
                break;
            }
            other => panic!("unexpected action {other:?}"),
        }
    }
    assert!(attacked, "carnivore reached and attacked the prey");
}

#[test]
fn prey_beyond_vision_not_pursued() {
    let mut b = Bench::new(40, 40, 3);
    let cr = b.carn(c(10, 10), &[], 40.0);
    let r = vision_radius(b.pop.get_alive(cr).unwrap().traits());
    let _prey = b.herb(c(10 + r + 1, 10), &[], 50.0);
    let t = b.turn(cr);
    assert_eq!(t.action, CarnivoreAction::Wander);
    assert!(t.attack.is_none());
}

#[test]
fn attack_distance_never_exceeds_one_in_runs() {
    let cfg = Config::new(5, 32, 24, 200, 60, 10);
    let mut sim = Simulation::new(cfg).unwrap();
    for _ in 0..300 {
        sim.step_with(|ctx| {
            if ctx.phase == Phase::Carnivores {
                let h = ctx.world.last_hunt();
                assert!(h.max_attack_distance <= ATTACK_REACH);
                assert_eq!(h.kills + h.escapes, h.attacks);
                assert!(h.gained <= h.prey_energy + 1e-9);
                assert!(h.attack_cost <= h.attacks as f64 * ctx.config.hunting.attack_cost + 1e-9);
            }
        });
    }
    let l = *sim.world().hunt_ledger();
    assert!(l.attacks > 0, "carnivores attacked: {l:?}");
    assert!(l.kills > 0 && l.escapes > 0, "{l:?}");
    assert!(l.max_attack_distance <= 1);
    assert!(l.gained <= l.prey_energy);
    assert_eq!(sim.totals().deaths_by(Kind::Herbivore, DeathCause::Predation), l.kills, "every kill is one predation death");
}

// ---------- AC2: traits + core RNG decide; kills and escapes both occur ----------

#[test]
fn kills_and_escapes_both_occur() {
    let mut kills = 0u32;
    let n = 2000u32;
    let mut p0 = 0.0;
    let mut rng = Rng::seed_from_u64(77);
    for _ in 0..n {
        let mut b = Bench::new(8, 8, 0);
        let cr = b.carn(c(3, 3), &[], 50.0);
        let h = b.herb(c(3, 3), &[], 50.0);
        let hp = b.hp();
        let a = attack(&mut b.pop, cr, h, &hp, 1, &mut rng);
        assert!(!a.refused);
        p0 = a.p;
        kills += a.success as u32;
        assert_eq!(a.success, !b.pop.is_alive(h));
    }
    let escapes = n - kills;
    assert!(kills > 0 && escapes > 0, "kills {kills} escapes {escapes}");
    let mean = p0 * n as f64;
    let sd = (n as f64 * p0 * (1.0 - p0)).sqrt();
    assert!((kills as f64 - mean).abs() < 5.0 * sd, "kills {kills} vs expected {mean:.0} (p {p0:.3})");
}

#[test]
fn traits_change_success() {
    let mut b = Bench::new(10, 10, 0);
    let hp = b.hp();
    let weak_c = b.carn(c(1, 1), &[(GeneTrait::Strength, 0.1), (GeneTrait::Speed, 0.1)], 50.0);
    let strong_c = b.carn(c(1, 2), &[(GeneTrait::Strength, 0.9), (GeneTrait::Speed, 0.9)], 50.0);
    let calm_c = b.carn(c(1, 3), &[(GeneTrait::Aggression, 0.0)], 50.0);
    let fierce_c = b.carn(c(1, 4), &[(GeneTrait::Aggression, 1.0)], 50.0);
    let weak_h = b.herb(c(5, 1), &[(GeneTrait::Strength, 0.1), (GeneTrait::Speed, 0.1)], 50.0);
    let strong_h = b.herb(c(5, 2), &[(GeneTrait::Strength, 0.9), (GeneTrait::Speed, 0.9)], 50.0);
    let bold_h = b.herb(c(5, 3), &[(GeneTrait::Caution, 0.0)], 50.0);
    let shy_h = b.herb(c(5, 4), &[(GeneTrait::Caution, 1.0)], 50.0);
    let o = |id| b.pop.get_alive(id).unwrap();
    let p = |pc, ph| success_probability(o(pc), o(ph), 0, 0.0, 1.0, &hp);
    assert!(p(strong_c, weak_h) > p(weak_c, weak_h));
    assert!(p(strong_c, strong_h) < p(strong_c, weak_h));
    assert!(p(fierce_c, weak_h) > p(calm_c, weak_h));
    assert!(p(strong_c, shy_h) < p(strong_c, bold_h));
    assert!(success_probability(o(strong_c), o(weak_h), 1, 0.0, 1.0, &hp) < p(strong_c, weak_h), "adjacent harder");
    assert!(success_probability(o(weak_c), o(strong_h), 0, 1.0, 1.0, &hp) <= p(weak_c, strong_h), "cover protects");
    assert!(success_probability(o(strong_c), o(weak_h), 0, 1.0, 1.0, &hp) < p(strong_c, weak_h));
    // Empirical kill rates differ (same RNG seed, different traits).
    let rate = |cg: &[(GeneTrait, f32)], hg: &[(GeneTrait, f32)]| {
        let mut rng = Rng::seed_from_u64(5);
        let mut k = 0;
        for _ in 0..2000 {
            let mut b = Bench::new(8, 8, 0);
            let cr = b.carn(c(3, 3), cg, 50.0);
            let h = b.herb(c(3, 3), hg, 50.0);
            let hp = b.hp();
            k += attack(&mut b.pop, cr, h, &hp, 1, &mut rng).success as u32;
        }
        k
    };
    let strong = rate(&[(GeneTrait::Strength, 0.9), (GeneTrait::Speed, 0.9)], &[(GeneTrait::Strength, 0.1), (GeneTrait::Speed, 0.1)]);
    let weak = rate(&[(GeneTrait::Strength, 0.1), (GeneTrait::Speed, 0.1)], &[(GeneTrait::Strength, 0.9), (GeneTrait::Speed, 0.9)]);
    assert!(strong > weak + 300, "strong {strong} vs weak {weak}");
}

#[test]
fn chance_comes_from_core_rng() {
    let outcomes = |seed| {
        let mut rng = Rng::seed_from_u64(seed);
        (0..200)
            .map(|_| {
                let mut b = Bench::new(8, 8, 0);
                let cr = b.carn(c(3, 3), &[], 50.0);
                let h = b.herb(c(3, 4), &[], 50.0);
                let hp = b.hp();
                let mut probe = rng.clone();
                probe.next_f64();
                let a = attack(&mut b.pop, cr, h, &hp, 1, &mut rng);
                assert_eq!(rng.state(), probe.state(), "exactly one draw per attack");
                a.success
            })
            .collect::<Vec<_>>()
    };
    assert_eq!(outcomes(1), outcomes(1));
    assert_ne!(outcomes(1), outcomes(2));
}

// ---------- AC3: one death, cause predation, never eaten twice ----------

#[test]
fn prey_dies_once_with_predation_and_is_not_eaten_twice() {
    let mut b = Bench::new(10, 10, 9);
    b.cfg.hunting.base_success = 1.0;
    let c1 = b.carn(c(4, 4), &[(GeneTrait::Strength, 1.0)], 30.0);
    let c2 = b.carn(c(4, 5), &[(GeneTrait::Strength, 1.0)], 30.0);
    let h = b.herb(c(4, 4), &[(GeneTrait::Strength, 0.0), (GeneTrait::Speed, 0.0)], 40.0);
    let mut first = b.hit(c1, h);
    let mut guard = 0;
    while !first.success {
        guard += 1;
        assert!(guard < 50, "p≈0.95 must kill quickly");
        first = b.hit(c1, h);
    }
    assert!(!b.pop.is_alive(h));
    let (e2, s2) = (b.energy(c2), b.rng.state());
    let second = b.hit(c2, h);
    assert!(second.refused && !second.success && second.gained == 0.0 && second.cost == 0.0);
    assert_eq!((b.energy(c2), b.rng.state()), (e2, s2));
    let again = b.hit(c1, h);
    assert!(again.refused && again.gained == 0.0);
    let deaths = b.pop.end_of_tick(1);
    let mine: Vec<_> = deaths.iter().filter(|d| d.id == h).collect();
    assert_eq!(mine.len(), 1);
    assert_eq!(mine[0].cause, DeathCause::Predation);
    assert_eq!(b.pop.totals().deaths_by(Kind::Herbivore, DeathCause::Predation), 1);
    assert!(b.pop.get(h).is_none() || !b.pop.is_alive(h));
}

#[test]
fn several_carnivores_same_prey_one_kill() {
    for seed in 0..200 {
        let mut b = Bench::new(10, 10, seed);
        b.cfg.hunting.base_success = 1.0;
        let c1 = b.carn(c(4, 4), &[], 30.0);
        let c2 = b.carn(c(4, 4), &[], 30.0);
        let c3 = b.carn(c(5, 4), &[], 30.0);
        let h = b.herb(c(4, 5), &[], 40.0);
        let prey_e = b.energy(h);
        let now = vec![CellNow { temperature: 10.0, precipitation: 500.0 }; 100];
        let (_, t) = act_carnivores(&mut b.pop, &[c1, c2, c3], &b.cfg, &now, 10, 1, &mut b.rng);
        assert!(t.kills <= 1, "seed {seed}: {t:?}");
        assert!(t.gained <= prey_e + 1e-12);
        let d = b.pop.end_of_tick(1);
        assert_eq!(d.iter().filter(|r| r.id == h).count() as u64, t.kills);
        assert!(d.iter().filter(|r| r.id == h).all(|r| r.cause == DeathCause::Predation));
    }
}

// ---------- AC4: gain ≤ prey energy ----------

#[test]
fn gain_at_most_prey_energy() {
    for (assim, meal) in [(1.0, 1e6), (0.8, 1e6), (1.0, 3.0), (0.5, 60.0)] {
        for prey_e in [5.0, 40.0, 90.0] {
            let mut b = Bench::new(8, 8, 4);
            b.cfg.hunting.base_success = 1.0;
            b.cfg.carnivores.assimilation = assim;
            b.cfg.carnivores.max_meal = meal;
            let cr = b.carn(c(2, 2), &[(GeneTrait::Strength, 1.0)], 10.0);
            let h = b.herb(c(2, 2), &[(GeneTrait::Strength, 0.0)], prey_e);
            let e_h = b.energy(h);
            let mut a = b.hit(cr, h);
            while !a.success {
                a = b.hit(cr, h);
            }
            assert_eq!(a.prey_energy, e_h);
            assert!(a.gained <= a.prey_energy, "{a:?}");
            assert!((a.gained - (assim * e_h).min(meal)).abs() < 1e-9, "{a:?}");
        }
    }
}

// ---------- AC5: hunting costs energy; no prey → starvation ----------

#[test]
fn attack_costs_energy_win_or_lose() {
    let mut escapes = 0;
    let mut kills = 0;
    let mut rng = Rng::seed_from_u64(21);
    for _ in 0..400 {
        let mut b = Bench::new(8, 8, 0);
        let cost = b.cfg.hunting.attack_cost;
        assert!(cost > 0.0);
        let cr = b.carn(c(3, 3), &[], 50.0);
        let h = b.herb(c(3, 3), &[], 40.0);
        let hp = b.hp();
        let a = attack(&mut b.pop, cr, h, &hp, 1, &mut rng);
        assert_eq!(a.cost, cost);
        let after = b.energy(cr);
        if a.success {
            kills += 1;
            assert!((after - (50.0 - cost + a.gained)).abs() < 1e-9);
        } else {
            escapes += 1;
            assert!((after - (50.0 - cost)).abs() < 1e-12, "failed attack still costs");
        }
    }
    assert!(kills > 0 && escapes > 0);
}

#[test]
fn carnivore_without_prey_starves() {
    let mut b = Bench::new(20, 20, 6);
    let cr = b.carn(c(5, 5), &[], 6.0);
    let mut starved = false;
    for _ in 0..50 {
        let t = b.turn(cr);
        assert!(t.attack.is_none());
        assert!(t.metabolism > 0.0);
        if t.starved {
            starved = true;
            break;
        }
    }
    assert!(starved, "no prey → starvation");
    let d = b.pop.end_of_tick(1);
    assert_eq!(d.iter().filter(|r| r.id == cr).map(|r| r.cause).collect::<Vec<_>>(), vec![DeathCause::Starvation]);
}

#[test]
fn carnivores_starve_in_runs_without_herbivores() {
    let mut sim = Simulation::new(Config::new(3, 24, 24, 100, 0, 6)).unwrap();
    sim.run(400);
    assert_eq!(sim.organisms().count_alive(Kind::Carnivore), 0);
    assert_eq!(sim.totals().deaths_by(Kind::Carnivore, DeathCause::Starvation), 6);
    assert_eq!(sim.world().hunt_ledger().attacks, 0);
}

#[test]
fn handling_blocks_attacks_after_kill() {
    let mut b = Bench::new(12, 12, 2);
    b.cfg.hunting.base_success = 1.0;
    let cr = b.carn(c(4, 4), &[(GeneTrait::Strength, 1.0), (GeneTrait::Aggression, 1.0)], 10.0);
    let mut prey = b.herb(c(4, 4), &[(GeneTrait::Strength, 0.0)], 5.0);
    let _spare = b.herb(c(5, 4), &[(GeneTrait::Strength, 0.0)], 5.0);
    loop {
        let t = b.turn(cr);
        let a = t.attack.expect("prey in reach");
        if a.success {
            break;
        }
        prey = a.prey.unwrap();
    }
    let _ = prey;
    let ht = b.cfg.hunting.handling_time;
    assert!(ht > 0);
    for _ in 0..ht {
        let t = b.turn(cr);
        assert_eq!(t.action, CarnivoreAction::Handle);
        assert!(t.attack.is_none() && t.moved.steps == 0);
    }
    let t = b.turn(cr);
    assert_ne!(t.action, CarnivoreAction::Handle);
    assert!(t.attack.is_some(), "free to hunt the spare prey again");
}

#[test]
fn deterministic_runs_with_hunting() {
    let run = |seed| {
        let mut s = Simulation::new(Config::new(seed, 24, 24, 150, 40, 8)).unwrap();
        s.run(150);
        let l = *s.world().hunt_ledger();
        let p = s.organisms();
        (l.attacks, l.kills, l.gained.to_bits(), p.alive(Kind::Carnivore).map(|o| (o.id(), o.pos(), o.energy().to_bits())).collect::<Vec<_>>())
    };
    assert_eq!(run(8), run(8));
    assert_ne!(run(8), run(9));
}

/// Smoke run of the contract example, 1000 ticks; prints counts and the
/// hunting ledger. Not an acceptance check (coexistence is TASK-018/027).
/// Run: `cargo test --release -p evosim-core smoke_hunting -- --ignored --nocapture`.
#[test]
#[ignore]
fn smoke_hunting() {
    let mut cfg = Config::contract_example();
    if let Ok(v) = std::env::var("HT") { cfg.hunting.handling_time = v.parse().unwrap(); }
    if let Ok(v) = std::env::var("BS") { cfg.hunting.base_success = v.parse().unwrap(); }
    let mut s = Simulation::new(cfg).unwrap();
    for t in 0..=1000u64 {
        if t % 100 == 0 {
            let p = s.organisms();
            let l = s.world().hunt_ledger();
            println!(
                "tick {t}: plants {} herbivores {} carnivores {} | attacks {} kills {} escapes {} gained {:.1}/{:.1} starved {}",
                p.count_alive(Kind::Plant),
                p.count_alive(Kind::Herbivore),
                p.count_alive(Kind::Carnivore),
                l.attacks,
                l.kills,
                l.escapes,
                l.gained,
                l.prey_energy,
                l.starved
            );
        }
        s.step();
    }
}

// ---- TASK-027 / ADR-030: local type-III hunting response ----

#[test]
fn density_factor_values() {
    assert_eq!(density_factor(0, 40.0), 0.0);
    assert!((density_factor(40, 40.0) - 0.5).abs() < 1e-12);
    assert!((density_factor(120, 40.0) - 0.75).abs() < 1e-12);
    for n in [0, 1, 7, 1000] {
        assert_eq!(density_factor(n, 0.0), 1.0, "half 0 = off");
        assert_eq!(density_factor(n, f64::NAN), 1.0);
        assert_eq!(density_factor(n, -3.0), 1.0);
    }
    let mut last = -1.0;
    for n in 0..200 {
        let f = density_factor(n, 25.0);
        assert!((0.0..1.0).contains(&f) && f > last, "monotone in [0,1)");
        last = f;
    }
}

/// Bench with the density factor on; carnivore at (10,10) with vision radius r.
fn density_bench(half: f64) -> (Bench, EntityId, EntityId, u32) {
    let mut b = Bench::new(40, 40, 3);
    b.cfg.hunting.prey_density_half = half;
    let cr = b.carn(c(10, 10), &[], 50.0);
    let h = b.herb(c(10, 10), &[], 50.0);
    let r = crate::animals::sense::vision_radius(b.pop.get_alive(cr).unwrap().traits());
    (b, cr, h, r)
}

#[test]
fn more_local_prey_raises_success_and_off_is_unchanged() {
    let (mut b, cr, h, r) = density_bench(10.0);
    assert!(r >= 2, "default carnivore vision radius {r}");
    let hp = b.hp();
    let p1 = best_in_reach(&b.pop, cr, &hp).unwrap().1;
    assert_eq!(local_prey(&b.pop, b.pop.get_alive(cr).unwrap()), 1, "target counts itself");
    // Add herbivores inside vision (not in reach): success rises.
    let mut ps = vec![p1];
    for k in 0..6u32 {
        b.herb(c(10 + 2 + (k % 2), 10 + k / 2), &[], 50.0);
        let hp = b.hp();
        let p = best_in_reach(&b.pop, cr, &hp).unwrap();
        assert_eq!(p.0, h, "ranking of the only prey in reach unchanged");
        ps.push(p.1);
    }
    assert!(ps.windows(2).all(|w| w[1] > w[0]), "monotone {ps:?}");
    assert_eq!(local_prey(&b.pop, b.pop.get_alive(cr).unwrap()), 7);
    // Off: identical to the pre-TASK-027 formula, independent of neighbours.
    let mut hp0 = b.hp();
    hp0.prey_density_half = 0.0;
    let (o_c, o_h) = (b.pop.get_alive(cr).unwrap(), b.pop.get_alive(h).unwrap());
    assert_eq!(best_in_reach(&b.pop, cr, &hp0).unwrap().1, success_probability(o_c, o_h, 0, cover(&b.pop, o_h.pos(), &hp0), 1.0, &hp0));
    // Factor applied exactly: p = clamp(p_off * 7/17).
    let p_off = success_probability(o_c, o_h, 0, cover(&b.pop, o_h.pos(), &hp0), 1.0, &hp0);
    let expect = (p_off * 7.0 / 17.0).clamp(P_MIN, P_MAX);
    assert!((ps[6] - expect).abs() < 1e-12, "{} vs {expect}", ps[6]);
}

#[test]
fn far_away_herbivores_do_not_matter_and_count_wraps() {
    // Local rule: herbivores outside the vision radius never change success
    // (no global count), herbivores across the wrap seam inside vision do.
    let (mut b, cr, _h, r) = density_bench(10.0);
    let hp = b.hp();
    let p_alone = best_in_reach(&b.pop, cr, &hp).unwrap().1;
    for k in 0..30u32 {
        b.herb(c(10 + r + 2 + (k % 10), 25 + k / 10), &[], 50.0); // far away
    }
    let hp = b.hp();
    assert_eq!(best_in_reach(&b.pop, cr, &hp).unwrap().1, p_alone, "far herds ignored");
    // Carnivore near the seam at x=0: prey at x=39 is within vision.
    let mut b2 = Bench::new(40, 40, 3);
    b2.cfg.hunting.prey_density_half = 10.0;
    let c2 = b2.carn(c(0, 5), &[], 50.0);
    b2.herb(c(0, 5), &[], 50.0);
    b2.herb(c(39, 5), &[], 50.0);
    b2.herb(c(40 - r, 6), &[], 50.0);
    assert_eq!(local_prey(&b2.pop, b2.pop.get_alive(c2).unwrap()), 3, "wrap-aware count");
}

#[test]
fn density_attack_keeps_one_draw_and_bounds() {
    // One RNG draw per attack also with the factor; probability stays in [P_MIN, P_MAX].
    for half in [0.0, 1.0, 40.0, 1000.0] {
        let (mut b, cr, h, _) = density_bench(half);
        let hp = b.hp();
        let mut rng = Rng::seed_from_u64(9);
        let mut twin = rng.clone();
        let a = attack(&mut b.pop, cr, h, &hp, 1, &mut rng);
        assert!(!a.refused && a.p >= P_MIN && a.p <= P_MAX, "half {half}: p {}", a.p);
        twin.chance(0.5);
        assert_eq!(rng.next_u64(), twin.next_u64(), "exactly one draw (half {half})");
    }
}

use super::*;
use crate::config::Config;

fn sim(cfg: Config) -> Simulation {
    Simulation::new(cfg).unwrap()
}

fn ticks(r: &RunRecord) -> Vec<u64> {
    r.series.iter().map(|p| p.tick).collect()
}

#[test]
fn default_sample_every_rule() {
    assert_eq!(default_sample_every(0), 1);
    assert_eq!(default_sample_every(50), 1);
    assert_eq!(default_sample_every(199), 1);
    assert_eq!(default_sample_every(1000), 10);
    assert_eq!(default_sample_every(10_000), 100);
}

#[test]
fn zero_ticks_gives_one_point() {
    let mut s = sim(Config::new(1, 16, 12, 30, 8, 2));
    let h = s.state_hash();
    let r = run_recorded(&mut s, 0, 1);
    assert_eq!((r.tick_start, r.tick_end), (0, 0));
    assert_eq!(ticks(&r), vec![0]);
    assert_eq!(r.series[0].counts, [30, 8, 2]);
    assert_eq!(s.state_hash(), h);
}

#[test]
fn series_spacing_and_end_without_duplicates() {
    let mut s = sim(Config::new(1, 16, 12, 30, 8, 2));
    let r = run_recorded(&mut s, 250, 100);
    assert_eq!(ticks(&r), vec![0, 100, 200, 250]);
    let mut s = sim(Config::new(1, 16, 12, 30, 8, 2));
    let r = run_recorded(&mut s, 200, 100);
    assert_eq!(ticks(&r), vec![0, 100, 200]);
    let mut s = sim(Config::new(1, 16, 12, 30, 8, 2));
    let r = run_recorded(&mut s, 7, 0);
    assert_eq!(r.sample_every, 1);
    assert_eq!(ticks(&r), (0..=7).collect::<Vec<_>>());
}

#[test]
fn extinct_world_runs_exactly_n_ticks() {
    let mut s = sim(Config::new(2, 8, 8, 0, 0, 0));
    let r = run_recorded(&mut s, 123, 50);
    assert_eq!(s.tick(), 123);
    assert_eq!(r.tick_end, 123);
    assert_eq!(r.extinction_tick, [Some(0); 3]);
    // No plants: animals die out and stay out (no replenishment).
    let mut s = sim(Config::new(2, 16, 12, 0, 10, 3));
    let r = run_recorded(&mut s, 600, 100);
    assert_eq!(s.tick(), 600);
    assert_eq!(r.extinction_tick[0], Some(0));
    let ext_h = r.extinction_tick[1].expect("herbivores die out without plants");
    assert!(r.series.iter().filter(|p| p.tick >= ext_h).all(|p| p.counts[1] == 0));
    assert_eq!(counts(&s), [0, 0, 0]);
}

#[test]
fn result_json_has_contract_keys_and_balance() {
    let mut s = sim(Config::new(11, 20, 14, 60, 16, 4));
    let r = run_recorded(&mut s, 120, default_sample_every(120));
    let v = result_json(&s, &r, 0.5);
    assert_eq!(v["contract"], 1);
    assert_eq!(v["seed"], 11);
    assert_eq!(v["tick_start"], 0);
    assert_eq!(v["tick_end"], 120);
    assert_eq!(v["world"]["width"], 20);
    assert_eq!(v["world"]["height"], 14);
    for (i, k) in KIND_KEYS.iter().enumerate() {
        let fin = v["final"][k].as_u64().unwrap();
        assert!(v["final"]["species"][k].is_u64());
        let b = v["totals"]["births"][k].as_u64().unwrap();
        let d = v["totals"]["deaths"][k].as_u64().unwrap();
        let init = v["totals"]["initial"][k].as_u64().unwrap();
        assert_eq!(init + b - d, fin, "balance {k}");
        assert_eq!(init, [60, 16, 4][i]);
        let causes: u64 = v["totals"]["deaths_by_cause"][k].as_object().unwrap().values().map(|x| x.as_u64().unwrap()).sum();
        assert_eq!(causes, d);
        assert_eq!(v["series"][0][k].as_u64().unwrap(), init);
        assert_eq!(v["series"].as_array().unwrap().last().unwrap()[k].as_u64().unwrap(), fin);
    }
    let h = v["state_hash"].as_str().unwrap();
    assert_eq!(h, s.state_hash());
    assert_eq!(v["elapsed_seconds"].as_f64().unwrap(), 0.5);
    assert_eq!(v["ticks_per_second"].as_f64().unwrap(), 240.0);
    assert_eq!(v["sample_every"], 1);
    assert!(v["config"].is_object());
    assert!(v["extinction_tick"].is_object());
}

#[test]
fn result_json_zero_ticks_and_zero_elapsed_is_finite() {
    let mut s = sim(Config::new(1, 8, 8, 5, 0, 0));
    let r = run_recorded(&mut s, 0, 1);
    let v = result_json(&s, &r, 0.0);
    assert_eq!(v["ticks_per_second"].as_f64().unwrap(), 0.0);
    assert_eq!(v["extinction_tick"]["plants"], serde_json::Value::Null);
    assert_eq!(v["extinction_tick"]["herbivores"], 0);
    let v = result_json(&s, &r, f64::NAN);
    assert_eq!(v["elapsed_seconds"].as_f64().unwrap(), 0.0);
}

#[test]
fn run_recorded_is_deterministic() {
    let run = |seed| {
        let mut s = sim(Config::new(seed, 20, 14, 60, 16, 4));
        let r = run_recorded(&mut s, 80, 10);
        (r, s.state_hash())
    };
    assert_eq!(run(3), run(3));
    assert_ne!(run(3).1, run(4).1);
}

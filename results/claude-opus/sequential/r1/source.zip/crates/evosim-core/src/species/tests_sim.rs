//! Simulation-level species tests (ADR-020): forced divergence, determinism,
//! per-tick consistency of living species counts, extinction events.

use super::*;
use crate::config::Config;
use crate::genome::distance;
use crate::organism::{DeathCause, Kind};
use crate::sim::{EventKind, Phase, Simulation};

fn divergent_cfg(seed: u64) -> Config {
    let mut c = Config::new(seed, 32, 24, 200, 0, 0);
    c.plants.mutation_rate = 1.0;
    c.plants.mutation_strength = 0.3;
    c
}

type Snap = (u32, Kind, String, Option<SpeciesId>, u64, Option<u64>, u64);

fn snapshot(s: &Simulation) -> Vec<Snap> {
    s.species().iter().map(|r| (r.id().0, r.kind(), r.name().to_string(), r.parent(), r.origin_tick(), r.extinct_tick(), r.living())).collect()
}

fn check_every_organism(s: &Simulation) {
    let reg = s.species();
    for k in Kind::ALL {
        let mut distinct: Vec<SpeciesId> = Vec::new();
        for o in s.organisms().alive(k) {
            let r = reg.get(o.species()).expect("species exists");
            assert_eq!(r.kind(), k, "species of the organism's kind");
            assert!(!r.is_extinct(), "living member of an extinct species");
            distinct.push(o.species());
        }
        distinct.sort();
        distinct.dedup();
        assert_eq!(reg.living_count(k), distinct.len(), "living species count of {}", k.name());
        assert_eq!(reg.living_count_at(k, s.tick() - 1), distinct.len());
    }
    s.organisms().validate(s.next_entity_id()).unwrap();
}

#[test]
fn forced_divergence_splits_in_simulation() {
    let mut s = Simulation::new(divergent_cfg(7)).unwrap();
    let root = s.species().of_kind(Kind::Plant).next().unwrap().id();
    assert_eq!(s.species().of_kind(Kind::Plant).count(), 1, "founders form one root species");
    let mut split_tick = None;
    let mut appeared_events = 0;
    for _ in 0..300 {
        let rep = s.step();
        appeared_events += rep.events.iter().filter(|e| e.phase == Phase::Species && matches!(e.kind, EventKind::SpeciesAppeared { parent: Some(_), .. })).count();
        if let Some(d) = s.species().of_kind(Kind::Plant).find(|r| r.parent() == Some(root)) {
            split_tick = Some(d.origin_tick());
            let rep_root = s.species().get(root).unwrap().representative();
            assert!(distance(d.representative(), rep_root) > s.species().threshold(Kind::Plant));
            break;
        }
    }
    let t = split_tick.expect("strong mutation must split the plant lineage within 300 ticks");
    assert!(t > 0);
    assert!(appeared_events >= 1, "split announced by a SpeciesAppeared event");
    check_every_organism(&s);
}

#[test]
fn no_mutation_never_splits() {
    let mut c = divergent_cfg(7);
    c.plants.mutation_rate = 0.0;
    let mut s = Simulation::new(c).unwrap();
    for _ in 0..150 {
        s.step();
    }
    assert!(s.organisms().count_alive(Kind::Plant) > 0);
    assert_eq!(s.species().len(), 1);
    assert!(s.species().iter().all(|r| r.parent().is_none()));
}

#[test]
fn same_seed_same_species_registry() {
    let run = || {
        let mut s = Simulation::new(divergent_cfg(11)).unwrap();
        s.run(200);
        snapshot(&s)
    };
    let a = run();
    let b = run();
    assert!(a.len() >= 2, "test needs at least one split, got {}", a.len());
    assert_eq!(a, b);
}

#[test]
fn living_species_count_matches_population_every_tick() {
    for cfg in [Config::contract_example(), divergent_cfg(3)] {
        let mut s = Simulation::new(cfg).unwrap();
        let mut history: Vec<[usize; 3]> = Vec::new();
        for _ in 0..120 {
            s.step();
            check_every_organism(&s);
            history.push(Kind::ALL.map(|k| s.living_species(k)));
        }
        for (t, counts) in history.iter().enumerate() {
            for k in Kind::ALL {
                assert_eq!(s.species().living_count_at(k, t as u64), counts[k.index()], "history at tick {t}");
            }
        }
    }
}

#[test]
fn species_events_and_extinction_tick_in_simulation() {
    let mut s = Simulation::new(Config::contract_example()).unwrap();
    let first = s.step();
    // Founder root species are initial state (origin tick 0), not announced as events.
    assert!(first.events.iter().all(|e| !matches!(e.kind, EventKind::SpeciesAppeared { .. })));
    assert!(s.species().iter().all(|r| r.origin_tick() == 0 && r.parent().is_none()));
    assert_eq!(Kind::ALL.map(|k| s.living_species(k)), [1, 1, 1]);
    let carn = s.species().of_kind(Kind::Carnivore).next().unwrap().id();
    // Kill every carnivore in the Herbivores phase of tick 1.
    let rep = s.step_with(|ctx| {
        if ctx.phase == Phase::Herbivores {
            let t = ctx.tick;
            let pop = ctx.world.organisms_mut();
            for id in pop.alive_ids(Kind::Carnivore) {
                pop.kill(id, DeathCause::Injury, t);
            }
        }
    });
    let rec = s.species().get(carn).unwrap();
    assert!(s.species().of_kind(Kind::Carnivore).all(|r| r.is_extinct()));
    assert_eq!(rec.extinct_tick(), Some(1));
    assert_eq!(rec.origin_tick(), 0);
    assert_eq!(rec.parent(), None);
    assert_eq!(s.living_species(Kind::Carnivore), 0);
    assert!(rep.events.iter().any(|e| e.phase == Phase::Species && e.kind == EventKind::SpeciesExtinct { species: carn, kind: Kind::Carnivore, tick: 1 }));
}

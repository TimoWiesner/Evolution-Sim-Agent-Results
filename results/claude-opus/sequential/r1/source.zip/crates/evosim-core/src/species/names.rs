//! Deterministic species names (ADR-020): pure function of (kind, root ID, ID).

use super::SpeciesId;
use crate::organism::Kind;

/// Fixed syllable table of the bijective base-16 encoding.
pub const SYLLABLES: [&str; 16] = ["ka", "lo", "mi", "ru", "te", "va", "no", "si", "pa", "de", "xo", "bu", "ri", "ze", "fa", "ul"];

/// Bijective base-16 word of `n >= 1` (1 → "ka", 16 → "ul", 17 → "kaka").
/// `n == 0` maps to "ka" too (never used: IDs start at 1).
pub fn syllable_word(n: u32) -> String {
    let mut n = n.max(1) as u64;
    let mut parts: Vec<&str> = Vec::new();
    while n > 0 {
        let d = ((n - 1) % 16) as usize;
        parts.push(SYLLABLES[d]);
        n = (n - 1) / 16;
    }
    parts.reverse();
    parts.concat()
}

/// Genus suffix per kind.
pub fn genus_suffix(kind: Kind) -> &'static str {
    match kind {
        Kind::Plant => "ia",
        Kind::Herbivore => "odon",
        Kind::Carnivore => "raptor",
    }
}

/// Binomial `"<Genus> <epithet>"`: genus = capitalised word of the root
/// ancestor's ID + kind suffix, epithet = word of the species' own ID.
pub fn species_name(kind: Kind, root: SpeciesId, id: SpeciesId) -> String {
    let g = syllable_word(root.0);
    let mut c = g.chars();
    let first = c.next().map(|f| f.to_ascii_uppercase()).unwrap_or('K');
    format!("{first}{}{} {}", c.as_str(), genus_suffix(kind), syllable_word(id.0))
}

/// Short code `P<id>` / `H<id>` / `C<id>`.
pub fn species_code(kind: Kind, id: SpeciesId) -> String {
    let p = match kind {
        Kind::Plant => 'P',
        Kind::Herbivore => 'H',
        Kind::Carnivore => 'C',
    };
    format!("{p}{}", id.0)
}

//! Statistics phase (ADR-021): per-tick population counts and the
//! population-balance invariant `initial + births − deaths == alive`.
//! Uses no RNG and changes no simulation state except the snapshot.

use crate::organism::{Kind, LifeTotals, Population};

/// Snapshot taken in `Phase::Statistics` at the end of a tick.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
pub struct TickStats {
    /// The tick this snapshot describes.
    pub tick: u64,
    /// Living organisms per kind (`Kind::index` order) after the tick.
    pub alive: [u64; 3],
    /// Cumulative births per kind since tick 0.
    pub births: [u64; 3],
    /// Cumulative deaths per kind since tick 0.
    pub deaths: [u64; 3],
    /// Births per kind in this tick.
    pub births_tick: [u64; 3],
    /// Deaths per kind in this tick.
    pub deaths_tick: [u64; 3],
}

impl TickStats {
    /// Snapshot of `pop` after tick `tick`; `prev` is the previous snapshot
    /// (for the per-tick deltas).
    pub fn capture(tick: u64, pop: &Population, prev: &TickStats) -> TickStats {
        let t = pop.totals();
        let mut s = TickStats { tick, births: t.births, deaths: t.deaths, ..TickStats::default() };
        for k in Kind::ALL {
            let i = k.index();
            s.alive[i] = pop.count_alive(k) as u64;
            s.births_tick[i] = t.births[i].saturating_sub(prev.births[i]);
            s.deaths_tick[i] = t.deaths[i].saturating_sub(prev.deaths[i]);
        }
        s
    }

    pub fn alive_of(&self, k: Kind) -> u64 {
        self.alive[k.index()]
    }
}

/// Checks `initial + births − deaths == alive` for every kind.
pub fn balance_ok(totals: &LifeTotals, pop: &Population) -> Result<(), String> {
    for k in Kind::ALL {
        let i = k.index();
        let alive = pop.count_alive(k) as u64;
        let lhs = (totals.initial[i] + totals.births[i]).checked_sub(totals.deaths[i]);
        if lhs != Some(alive) {
            return Err(format!(
                "{k:?}: initial {} + births {} - deaths {} != alive {alive}",
                totals.initial[i], totals.births[i], totals.deaths[i]
            ));
        }
    }
    Ok(())
}

//! Unit tests of THE species rule, names, extinction and queries (ADR-020).

use super::*;
use crate::genome::{distance, Genome};
use crate::ids::IdAllocator;
use crate::organism::{BirthRequest, DeathCause, Kind, Parents, Population};
use crate::topology::{Cell, Torus};

fn base(kind: Kind) -> Genome {
    Genome::founder_default(kind)
}

/// `base` with every gene shifted by `delta` (clamped to [0, 1]).
fn shifted(kind: Kind, delta: f32) -> Genome {
    let g = base(kind);
    let genes = g.genes().iter().map(|&x| if x + delta <= 1.0 { x + delta } else { x - delta }).collect();
    Genome::from_genes(kind, genes).unwrap()
}

fn next_down(x: f64) -> f64 {
    assert!(x > 0.0);
    f64::from_bits(x.to_bits() - 1)
}

#[test]
fn founders_within_threshold_share_root_species() {
    let mut r = SpeciesRegistry::default();
    let a = r.classify_founder(&base(Kind::Plant), 0);
    let b = r.classify_founder(&shifted(Kind::Plant, 0.01), 0);
    let h = r.classify_founder(&base(Kind::Herbivore), 0);
    assert_eq!(a, SpeciesId(1));
    assert_eq!(a, b);
    assert_eq!(h, SpeciesId(2), "species are per kind");
    assert_eq!(r.living_count(Kind::Plant), 1);
    assert_eq!(r.living_count(Kind::Herbivore), 1);
    assert_eq!(r.get(a).unwrap().living(), 2);
    assert_eq!(r.get(a).unwrap().parent(), None);
}

#[test]
fn distant_founders_form_separate_roots() {
    let mut r = SpeciesRegistry::default();
    let a = r.classify_founder(&base(Kind::Herbivore), 0);
    let far = shifted(Kind::Herbivore, 0.3);
    assert!(distance(&far, &base(Kind::Herbivore)) > 0.15);
    let b = r.classify_founder(&far, 0);
    assert_ne!(a, b);
    assert_eq!(r.get(b).unwrap().parent(), None);
    assert_eq!(r.get(b).unwrap().root(), b);
    assert_eq!(r.living_count(Kind::Herbivore), 2);
}

#[test]
fn child_exactly_at_threshold_stays() {
    let child = shifted(Kind::Carnivore, 0.07);
    let d = distance(&child, &base(Kind::Carnivore));
    assert!(d > 0.0);
    let mut r = SpeciesRegistry::with_thresholds([d; 3]);
    let m = r.classify_founder(&base(Kind::Carnivore), 0);
    let c = r.classify_child(m, &child, 5);
    assert_eq!(c, m, "d == T stays in the mother species");
    assert_eq!(r.len(), 1);
    assert_eq!(r.get(m).unwrap().living(), 2);
}

#[test]
fn child_just_above_threshold_splits() {
    let child = shifted(Kind::Carnivore, 0.07);
    let d = distance(&child, &base(Kind::Carnivore));
    let mut r = SpeciesRegistry::with_thresholds([next_down(d); 3]);
    let m = r.classify_founder(&base(Kind::Carnivore), 0);
    let c = r.classify_child(m, &child, 5);
    assert_ne!(c, m, "d just above T founds a new species");
    let rec = r.get(c).unwrap();
    assert_eq!(rec.parent(), Some(m));
    assert_eq!(rec.root(), m);
    assert_eq!(rec.origin_tick(), 5);
    assert_eq!(rec.representative(), &child);
    assert_eq!(rec.extinct_tick(), None);
    assert_eq!(r.get(m).unwrap().daughters(), &[c]);
    assert_eq!(r.living_count(Kind::Carnivore), 2);
    assert_eq!(r.journal().len(), 2);
}

#[test]
fn daughter_species_reused_and_dead_daughter_not() {
    let mut r = SpeciesRegistry::with_thresholds([0.15; 3]);
    let k = Kind::Plant;
    let m = r.classify_founder(&base(k), 0);
    let d1 = r.classify_child(m, &shifted(k, 0.2), 3);
    assert_ne!(d1, m);
    // Near the first daughter: joins it.
    let again = r.classify_child(m, &shifted(k, 0.21), 4);
    assert_eq!(again, d1);
    // Far from mother and from d1: second daughter.
    let g2 = {
        let b = base(k);
        let n = b.genes().len();
        let genes = b.genes().iter().enumerate().map(|(i, &x)| if i < n / 2 { (x + 0.45).min(1.0) } else { (x - 0.45).max(0.0) }).collect();
        Genome::from_genes(k, genes).unwrap()
    };
    assert!(distance(&g2, &base(k)) > 0.15 && distance(&g2, &shifted(k, 0.2)) > 0.15);
    let d2 = r.classify_child(m, &g2, 6);
    assert!(d2 != d1 && d2 != m);
    assert_eq!(r.get(d2).unwrap().parent(), Some(m));
    // Kill d1 members: extinct daughter is not reused.
    r.on_death(d1, 7);
    r.on_death(d1, 7);
    assert_eq!(r.get(d1).unwrap().extinct_tick(), Some(7));
    let d3 = r.classify_child(m, &shifted(k, 0.2), 8);
    assert!(d3 != d1 && d3 != d2 && d3 != m);
    assert_eq!(r.lineage(d3), vec![d3, m]);
}

#[test]
fn extinction_tick_recorded_and_final() {
    let mut r = SpeciesRegistry::default();
    let m = r.classify_founder(&base(Kind::Herbivore), 0);
    let d = r.classify_child(m, &shifted(Kind::Herbivore, 0.3), 2);
    r.on_death(d, 9);
    let rec = r.get(d).unwrap();
    assert_eq!(rec.extinct_tick(), Some(9));
    assert_eq!(rec.parent(), Some(m));
    assert_eq!(rec.origin_tick(), 2);
    assert_eq!(r.get(m).unwrap().extinct_tick(), None);
    assert_eq!(r.living_count(Kind::Herbivore), 1);
    assert_eq!(r.living_count_at(Kind::Herbivore, 1), 1);
    assert_eq!(r.living_count_at(Kind::Herbivore, 2), 2);
    assert_eq!(r.living_count_at(Kind::Herbivore, 8), 2);
    assert_eq!(r.living_count_at(Kind::Herbivore, 9), 1);
    // Extinct root is not joined by later founders.
    r.on_death(m, 10);
    let n = r.classify_founder(&base(Kind::Herbivore), 11);
    assert!(n != m && n != d);
    let j = r.take_journal();
    assert!(j.contains(&SpeciesChange::Extinct { id: d, kind: Kind::Herbivore, tick: 9 }));
    assert!(j.contains(&SpeciesChange::Extinct { id: m, kind: Kind::Herbivore, tick: 10 }));
    assert!(r.journal().is_empty());
}

#[test]
fn names_are_pure_distinct_and_share_genus() {
    assert_eq!(syllable_word(1), "ka");
    assert_eq!(syllable_word(16), "ul");
    assert_eq!(syllable_word(17), "kaka");
    let mut seen = std::collections::BTreeSet::new();
    for i in 1..=2000u32 {
        assert!(seen.insert(syllable_word(i)), "word {i} not unique");
    }
    assert_eq!(species_name(Kind::Plant, SpeciesId(1), SpeciesId(1)), "Kaia ka");
    assert_eq!(species_name(Kind::Herbivore, SpeciesId(2), SpeciesId(2)), "Loodon lo");
    assert_eq!(species_name(Kind::Carnivore, SpeciesId(3), SpeciesId(20)), "Miraptor karu");
    assert_eq!(species_code(Kind::Carnivore, SpeciesId(7)), "C7");
    let mut r = SpeciesRegistry::default();
    let m = r.classify_founder(&base(Kind::Plant), 0);
    let d = r.classify_child(m, &shifted(Kind::Plant, 0.3), 1);
    let gm = r.get(m).unwrap().name().split(' ').next().unwrap().to_string();
    let gd = r.get(d).unwrap().name().split(' ').next().unwrap().to_string();
    assert_eq!(gm, gd, "descendants share the root genus");
    assert_ne!(r.get(m).unwrap().name(), r.get(d).unwrap().name());
}

fn req(g: Genome, parents: Parents) -> BirthRequest {
    BirthRequest { pos: Cell { x: 1, y: 1 }, parents, energy: 5.0, health: None, genome: g }
}

#[test]
fn population_births_classify_at_threshold_and_kill_extinguishes() {
    let torus = Torus::new(8, 8).unwrap();
    let mut p = Population::with_expression(crate::genome::Expression::default(), torus);
    p.set_capacity(crate::organism::CellCapacity::from_config(&Config::new(1, 8, 8, 0, 0, 0).pre_task018()));
    let mut ids = IdAllocator::new();
    let k = Kind::Plant;
    p.request_birth(req(base(k), Parents::None));
    let f = p.resolve_births(0, &mut ids)[0];
    let ms = p.get(f.id).unwrap().species();
    let child = shifted(k, 0.05);
    let d = distance(&child, &base(k));
    // Exactly at T: stays.
    p.set_species_thresholds([d; 3]);
    p.request_birth(req(child.clone(), Parents::One(f.id)));
    let b = p.resolve_births(1, &mut ids)[0];
    assert_eq!(b.species, ms);
    assert_eq!(p.get(b.id).unwrap().species(), ms);
    // Just above T: splits.
    p.set_species_thresholds([next_down(d); 3]);
    p.request_birth(req(child.clone(), Parents::One(f.id)));
    let s = p.resolve_births(2, &mut ids)[0];
    assert_ne!(s.species, ms);
    assert_eq!(p.species().get(s.species).unwrap().parent(), Some(ms));
    assert_eq!(p.species().living_count(k), 2);
    p.validate(ids.peek_next()).unwrap();
    // Dropped birth (dead parent) creates no species.
    let n = p.species().len();
    assert!(p.kill(s.id, DeathCause::OldAge, 3));
    p.request_birth(req(shifted(k, 0.4), Parents::One(s.id)));
    assert!(p.resolve_births(3, &mut ids).is_empty());
    assert_eq!(p.species().len(), n);
    assert_eq!(p.species().get(s.species).unwrap().extinct_tick(), Some(3));
    assert_eq!(p.species().living_count(k), 1);
    p.end_of_tick(3);
    p.validate(ids.peek_next()).unwrap();
}

#[test]
fn check_rejects_inconsistent_species() {
    let mut r = SpeciesRegistry::default();
    let m = r.classify_founder(&base(Kind::Plant), 0);
    assert!(r.check([(Kind::Plant, m)].into_iter()).is_ok());
    assert!(r.check([(Kind::Herbivore, m)].into_iter()).is_err(), "wrong kind");
    assert!(r.check([(Kind::Plant, SpeciesId(9))].into_iter()).is_err(), "unknown id");
    assert!(r.check(std::iter::empty()).is_err(), "living count mismatch");
}

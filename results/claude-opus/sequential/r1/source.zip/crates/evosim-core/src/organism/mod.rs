//! Organisms and the shared life cycle of all three kinds (TASK-008, ADR-011).
//!
//! An [`Organism`] has a never-reused [`EntityId`], a [`Kind`], a position,
//! age, energy, health, a [`Genome`] with the [`Traits`] expressed from it
//! (TASK-009), [`Parents`] and a generation. Energy and
//! health are private and only change through clamping mutators, so they never
//! leave `[0, max]`. Organisms live in a [`Population`] (one EntityId-sorted
//! Vec per kind) owned by the `World`. Deaths are flagged at once (the organism
//! becomes invisible to every query and acting loop) and removed in the Deaths
//! phase; births are requested during acting phases and resolved in the Births
//! phase. THE same-tick rule is documented in ADR-011 and on [`Population`].

mod capacity;
mod kind;
mod population;
mod traits;

#[cfg(test)]
mod tests;

pub use kind::Kind;
pub use population::Population;
pub use capacity::CellCapacity;
pub use traits::{Range, TraitRanges, Traits};

use crate::genome::{express, Expression, Genome};
use crate::ids::EntityId;
use crate::species::SpeciesId;
use crate::topology::{Cell, Dir8};

/// XOR tag of the founder-placement generator seed (core RNG untouched).
pub const FOUNDER_SEED_TAG: u64 = 0x0F0B_DE25_0000_0008;

/// Parent IDs of an organism.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum Parents {
    /// Founder (created at tick 0 from the configuration).
    None,
    /// Asexual offspring.
    One(EntityId),
    /// Sexual offspring (stored as given).
    Two(EntityId, EntityId),
}

impl Parents {
    /// Parent IDs in stored order.
    pub fn ids(&self) -> impl Iterator<Item = EntityId> {
        let (a, b) = match *self {
            Parents::None => (None, None),
            Parents::One(a) => (Some(a), None),
            Parents::Two(a, b) => (Some(a), Some(b)),
        };
        a.into_iter().chain(b)
    }

    pub fn is_founder(&self) -> bool {
        matches!(self, Parents::None)
    }
}

/// Why an organism died.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, serde::Serialize, serde::Deserialize)]
#[non_exhaustive]
pub enum DeathCause {
    /// Age reached `max_lifespan`.
    OldAge,
    /// Energy reached 0.
    Starvation,
    /// Health reached 0.
    Injury,
    /// Killed by a carnivore (TASK-015).
    Predation,
    /// Plant eaten by a herbivore (TASK-014).
    Grazed,
    /// Killed by climate stress (TASK-011+).
    Climate,
}

impl DeathCause {
    pub const ALL: [DeathCause; 6] = [
        DeathCause::OldAge,
        DeathCause::Starvation,
        DeathCause::Injury,
        DeathCause::Predation,
        DeathCause::Grazed,
        DeathCause::Climate,
    ];
    pub const COUNT: usize = 6;

    pub fn index(self) -> usize {
        match self {
            DeathCause::OldAge => 0,
            DeathCause::Starvation => 1,
            DeathCause::Injury => 2,
            DeathCause::Predation => 3,
            DeathCause::Grazed => 4,
            DeathCause::Climate => 5,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            DeathCause::OldAge => "old_age",
            DeathCause::Starvation => "starvation",
            DeathCause::Injury => "injury",
            DeathCause::Predation => "predation",
            DeathCause::Grazed => "grazed",
            DeathCause::Climate => "climate",
        }
    }
}

/// One organism.
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Organism {
    id: EntityId,
    kind: Kind,
    pos: Cell,
    age: u32,
    energy: f64,
    health: f64,
    traits: Traits,
    genome: Genome,
    parents: Parents,
    generation: u32,
    birth_tick: u64,
    alive: bool,
    /// Wander heading of the correlated random walk (ADR-016); `None` at birth.
    heading: Option<Dir8>,
    /// Fractional step budget carried between ticks, in `[0, 1)` (ADR-016).
    stride: f64,
    /// Remaining handling ticks after a kill (carnivores, ADR-018); 0 otherwise.
    handling: u32,
    /// Remaining mating cooldown ticks (animals, ADR-019); 0 = may mate.
    cooldown: u32,
    /// Species assigned once at creation (ADR-020).
    species: SpeciesId,
}

/// Non-finite or negative amounts count as 0.
fn amount(x: f64) -> f64 {
    if x.is_finite() && x > 0.0 {
        x
    } else {
        0.0
    }
}

/// Clamp an absolute value into `[0, max]`; non-finite → 0.
fn level(x: f64, max: f64) -> f64 {
    if x.is_finite() {
        x.clamp(0.0, max)
    } else {
        0.0
    }
}

impl Organism {
    /// Build a living organism; kind from the genome, traits = `express(genome,
    /// expr)` (in range), energy and health clamped to `[0, max]`
    /// (`health = None` → `max_health`).
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        id: EntityId,
        pos: Cell,
        genome: Genome,
        expr: &Expression,
        parents: Parents,
        generation: u32,
        birth_tick: u64,
        energy: f64,
        health: Option<f64>,
        species: SpeciesId,
    ) -> Organism {
        let kind = genome.kind();
        let traits = express(&genome, expr);
        Organism {
            id,
            kind,
            pos,
            age: 0,
            energy: level(energy, traits.max_energy),
            health: level(health.unwrap_or(traits.max_health), traits.max_health),
            traits,
            genome,
            parents,
            generation,
            birth_tick,
            alive: true,
            heading: None,
            stride: 0.0,
            handling: 0,
            cooldown: 0,
            species,
        }
    }

    pub fn id(&self) -> EntityId {
        self.id
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    pub fn pos(&self) -> Cell {
        self.pos
    }
    /// Ticks survived (incremented in each Deaths phase except the birth tick).
    pub fn age(&self) -> u32 {
        self.age
    }
    /// Always in `[0, traits().max_energy]`.
    pub fn energy(&self) -> f64 {
        self.energy
    }
    /// Always in `[0, traits().max_health]`.
    pub fn health(&self) -> f64 {
        self.health
    }
    pub fn traits(&self) -> &Traits {
        &self.traits
    }
    /// Heritable DNA; `traits()` is always `express(genome(), expression)`.
    pub fn genome(&self) -> &Genome {
        &self.genome
    }
    pub fn parents(&self) -> Parents {
        self.parents
    }
    /// Founders 0, child = 1 + max parent generation.
    pub fn generation(&self) -> u32 {
        self.generation
    }
    pub fn birth_tick(&self) -> u64 {
        self.birth_tick
    }
    /// Species (assigned once at creation, never changed; ADR-020).
    pub fn species(&self) -> SpeciesId {
        self.species
    }
    /// False once flagged dead (until removal in the Deaths phase).
    pub fn is_alive(&self) -> bool {
        self.alive
    }

    /// Current wander heading (ADR-016; `None` until the first wander step).
    pub fn heading(&self) -> Option<Dir8> {
        self.heading
    }

    /// Fractional step budget carried to the next tick, in `[0, 1)`.
    pub fn stride(&self) -> f64 {
        self.stride
    }

    /// Remaining handling ticks after a kill (ADR-018); 0 = free to hunt.
    pub fn handling(&self) -> u32 {
        self.handling
    }

    /// Remaining mating cooldown ticks (ADR-019); 0 = may mate.
    pub fn cooldown(&self) -> u32 {
        self.cooldown
    }

    pub(crate) fn set_cooldown(&mut self, t: u32) {
        self.cooldown = t;
    }

    #[cfg(test)]
    pub(crate) fn set_age_for_test(&mut self, a: u32) {
        self.age = a;
    }

    pub(crate) fn set_handling(&mut self, t: u32) {
        self.handling = t;
    }

    pub(crate) fn set_heading(&mut self, h: Option<Dir8>) {
        self.heading = h;
    }

    /// Set the carried stride; values outside `[0, 1)` or non-finite → 0.
    pub(crate) fn set_stride(&mut self, s: f64) {
        self.stride = if s.is_finite() && (0.0..1.0).contains(&s) { s } else { 0.0 };
    }

    /// Move to `pos`. Crate-internal: only `Population::move_organism` may
    /// call it so the spatial index stays in sync (ADR-013).
    pub(crate) fn set_pos(&mut self, pos: Cell) {
        self.pos = pos;
    }

    /// Add energy, capped at `max_energy`; returns the amount actually gained.
    pub fn add_energy(&mut self, x: f64) -> f64 {
        let before = self.energy;
        self.energy = (before + amount(x)).min(self.traits.max_energy);
        self.energy - before
    }

    /// Spend energy, floored at 0; returns the amount actually spent.
    pub fn spend_energy(&mut self, x: f64) -> f64 {
        let before = self.energy;
        self.energy = (before - amount(x)).max(0.0);
        before - self.energy
    }

    /// Set energy, clamped into `[0, max_energy]` (non-finite → 0).
    pub fn set_energy(&mut self, v: f64) {
        self.energy = level(v, self.traits.max_energy);
    }

    /// Reduce health, floored at 0; returns the health actually lost.
    pub fn damage(&mut self, x: f64) -> f64 {
        let before = self.health;
        self.health = (before - amount(x)).max(0.0);
        before - self.health
    }

    /// Restore health, capped at `max_health`; returns the amount healed.
    pub fn heal(&mut self, x: f64) -> f64 {
        let before = self.health;
        self.health = (before + amount(x)).min(self.traits.max_health);
        self.health - before
    }

    /// Set health, clamped into `[0, max_health]` (non-finite → 0).
    pub fn set_health(&mut self, v: f64) {
        self.health = level(v, self.traits.max_health);
    }
}

/// Recorded death (cause and circumstances).
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct DeathRecord {
    pub id: EntityId,
    pub kind: Kind,
    pub cause: DeathCause,
    /// Tick in which the organism was flagged dead.
    pub tick: u64,
    pub age: u32,
    pub pos: Cell,
    pub generation: u32,
}

/// Recorded birth.
#[derive(Debug, Clone, Copy, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct BirthRecord {
    pub id: EntityId,
    pub kind: Kind,
    pub parents: Parents,
    pub generation: u32,
    pub pos: Cell,
    pub tick: u64,
    /// Species the newborn was classified into.
    pub species: SpeciesId,
}

/// A birth requested by a behaviour task during an acting phase; resolved in
/// the Births phase (ADR-011 same-tick rule). Parents pay energy themselves.
/// The kind is the genome's kind; traits are expressed from the genome on
/// resolve (build it with `genome::child_asexual` / `child_sexual`).
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct BirthRequest {
    pub pos: Cell,
    pub parents: Parents,
    /// Initial energy (clamped to `[0, max_energy]`).
    pub energy: f64,
    /// Initial health; `None` = `max_health`.
    pub health: Option<f64>,
    /// Child genome.
    pub genome: Genome,
}

impl BirthRequest {
    pub fn kind(&self) -> Kind {
        self.genome.kind()
    }
}

/// Life-cycle counters per kind (index `Kind::index()`) since tick 0.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, serde::Serialize, serde::Deserialize)]
pub struct LifeTotals {
    /// Founders created from the configuration (not births).
    pub initial: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    pub deaths_by_cause: [[u64; DeathCause::COUNT]; 3],
}

impl LifeTotals {
    pub fn births_of(&self, k: Kind) -> u64 {
        self.births[k.index()]
    }
    pub fn deaths_of(&self, k: Kind) -> u64 {
        self.deaths[k.index()]
    }
    pub fn deaths_by(&self, k: Kind, c: DeathCause) -> u64 {
        self.deaths_by_cause[k.index()][c.index()]
    }
    /// `initial + births − deaths`: must equal the living count of `k`.
    pub fn living_expected(&self, k: Kind) -> u64 {
        let i = k.index();
        self.initial[i] + self.births[i] - self.deaths[i]
    }
}

#[cfg(test)]
impl Organism {
    /// Test-only: flip one gene by one f32 ULP (hash sensitivity tests).
    pub(crate) fn nudge_gene_for_test(&mut self, i: usize) {
        self.genome.nudge_gene_for_test(i);
    }

    /// Test-only: overwrite the traits (hand-built metrics worlds, TASK-020).
    pub(crate) fn set_traits_for_test(&mut self, t: Traits) {
        self.traits = t;
    }

    /// Test-only: overwrite the generation (hand-built metrics worlds).
    pub(crate) fn set_generation_for_test(&mut self, g: u32) {
        self.generation = g;
    }
}

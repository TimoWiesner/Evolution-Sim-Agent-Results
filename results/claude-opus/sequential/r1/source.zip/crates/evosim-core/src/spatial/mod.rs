//! Spatial search (TASK-010, ADR-013 refining ADR-003): per-cell buckets split
//! by kind, each sorted by ascending `EntityId`, plus a locator map from ID to
//! (cell, kind). Queries use the toroidal Chebyshev metric of `topology`
//! (ADR-007) and return hits sorted by `(distance, id)`.

use std::collections::BTreeMap;
use std::fmt;

use crate::ids::EntityId;
use crate::organism::Kind;
use crate::topology::{Cell, Offset, Torus};

#[cfg(test)]
mod tests;

/// One query hit.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Neighbour {
    pub id: EntityId,
    pub kind: Kind,
    pub cell: Cell,
    /// Shortest displacement from the query center to `cell`.
    pub offset: Offset,
    /// Toroidal Chebyshev distance from the query center.
    pub distance: u32,
}

/// Errors of index mutations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SpatialError {
    /// The ID is already in the index.
    Duplicate(EntityId),
    /// The ID is not in the index.
    Unknown(EntityId),
    /// The cell lies outside the torus.
    OutsideWorld(Cell),
}

impl fmt::Display for SpatialError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SpatialError::Duplicate(id) => write!(f, "entity {} already in the spatial index", id.0),
            SpatialError::Unknown(id) => write!(f, "entity {} not in the spatial index", id.0),
            SpatialError::OutsideWorld(c) => write!(f, "cell ({}, {}) outside the world", c.x, c.y),
        }
    }
}

impl std::error::Error for SpatialError {}

/// Sort key of query results: total and independent of insertion history.
fn sort_hits(v: &mut [Neighbour]) {
    v.sort_unstable_by_key(|n| (n.distance, n.id));
}

fn kind_matches(filter: Option<Kind>, k: Kind) -> bool {
    filter.is_none_or(|f| f == k)
}

/// Spatial index of entities on a torus.
#[derive(Debug, Clone, PartialEq)]
pub struct SpatialIndex {
    torus: Torus,
    /// `torus.index(cell) * 3 + kind.index()` → IDs ascending.
    buckets: Vec<Vec<EntityId>>,
    locator: BTreeMap<EntityId, (Cell, Kind)>,
}

impl Default for SpatialIndex {
    /// Empty index on a 1×1 torus (placeholder).
    fn default() -> Self {
        SpatialIndex::new(Torus::new(1, 1).expect("1x1 torus is valid"))
    }
}

impl SpatialIndex {
    pub fn new(torus: Torus) -> SpatialIndex {
        SpatialIndex { torus, buckets: vec![Vec::new(); torus.cell_count() * 3], locator: BTreeMap::new() }
    }

    pub fn torus(&self) -> &Torus {
        &self.torus
    }

    /// Number of entries.
    pub fn len(&self) -> usize {
        self.locator.len()
    }

    pub fn is_empty(&self) -> bool {
        self.locator.is_empty()
    }

    /// Remove every entry (the torus stays).
    pub fn clear(&mut self) {
        for b in &mut self.buckets {
            b.clear();
        }
        self.locator.clear();
    }

    /// Entries of `kind`.
    pub fn count(&self, kind: Kind) -> usize {
        self.locator.values().filter(|(_, k)| *k == kind).count()
    }

    fn slot(&self, cell: Cell, kind: Kind) -> usize {
        self.torus.index(cell) * 3 + kind.index()
    }

    pub fn insert(&mut self, id: EntityId, kind: Kind, cell: Cell) -> Result<(), SpatialError> {
        if !self.torus.contains(cell) {
            return Err(SpatialError::OutsideWorld(cell));
        }
        if self.locator.contains_key(&id) {
            return Err(SpatialError::Duplicate(id));
        }
        let s = self.slot(cell, kind);
        let b = &mut self.buckets[s];
        let pos = b.binary_search(&id).unwrap_err();
        b.insert(pos, id);
        self.locator.insert(id, (cell, kind));
        Ok(())
    }

    fn unbucket(&mut self, id: EntityId, cell: Cell, kind: Kind) {
        let s = self.slot(cell, kind);
        let b = &mut self.buckets[s];
        if let Ok(pos) = b.binary_search(&id) {
            b.remove(pos);
        }
    }

    /// Remove an entry; returns where it was.
    pub fn remove(&mut self, id: EntityId) -> Option<(Cell, Kind)> {
        let (cell, kind) = self.locator.remove(&id)?;
        self.unbucket(id, cell, kind);
        Some((cell, kind))
    }

    /// Move an entry to `cell`; returns the old cell. Same cell = no-op.
    pub fn move_to(&mut self, id: EntityId, cell: Cell) -> Result<Cell, SpatialError> {
        if !self.torus.contains(cell) {
            return Err(SpatialError::OutsideWorld(cell));
        }
        let (old, kind) = *self.locator.get(&id).ok_or(SpatialError::Unknown(id))?;
        if old == cell {
            return Ok(old);
        }
        self.unbucket(id, old, kind);
        let s = self.slot(cell, kind);
        let b = &mut self.buckets[s];
        let pos = b.binary_search(&id).unwrap_err();
        b.insert(pos, id);
        self.locator.insert(id, (cell, kind));
        Ok(old)
    }

    pub fn location(&self, id: EntityId) -> Option<(Cell, Kind)> {
        self.locator.get(&id).copied()
    }

    pub fn contains(&self, id: EntityId) -> bool {
        self.locator.contains_key(&id)
    }

    /// Number of entries of `kind` in `cell` (0 outside the torus); O(1).
    pub fn count_at(&self, cell: Cell, kind: Kind) -> usize {
        if !self.torus.contains(cell) {
            return 0;
        }
        self.buckets[self.slot(cell, kind)].len()
    }

    /// IDs in `cell` (ascending; `None` = all kinds merged). Empty for cells
    /// outside the torus.
    pub fn at(&self, cell: Cell, filter: Option<Kind>) -> Vec<EntityId> {
        if !self.torus.contains(cell) {
            return Vec::new();
        }
        let mut v: Vec<EntityId> = Vec::new();
        for k in Kind::ALL {
            if kind_matches(filter, k) {
                v.extend_from_slice(&self.buckets[self.slot(cell, k)]);
            }
        }
        v.sort_unstable();
        v
    }

    /// All entries within distance `r` of `center` (wrapped into the torus),
    /// optionally of one kind, each once, sorted by `(distance, id)`.
    pub fn within(&self, center: Cell, r: u32, filter: Option<Kind>) -> Vec<Neighbour> {
        let mut v = Vec::new();
        self.within_into(center, r, filter, &mut v);
        v
    }

    /// Whether a query of radius `r` scans the locator instead of cells.
    pub fn uses_locator_scan(&self, r: u32) -> bool {
        self.torus.count_within(r) > self.len()
    }

    /// Like [`SpatialIndex::within`] but clears and fills `out`.
    pub fn within_into(&self, center: Cell, r: u32, filter: Option<Kind>, out: &mut Vec<Neighbour>) {
        out.clear();
        let center = self.torus.wrap(center.x as i64, center.y as i64);
        if self.uses_locator_scan(r) {
            for (&id, &(cell, kind)) in &self.locator {
                if !kind_matches(filter, kind) {
                    continue;
                }
                let offset = self.torus.offset(center, cell);
                let distance = offset.chebyshev();
                if distance <= r {
                    out.push(Neighbour { id, kind, cell, offset, distance });
                }
            }
        } else {
            for (cell, offset) in self.torus.within(center, r) {
                let base = self.torus.index(cell) * 3;
                let distance = offset.chebyshev();
                for kind in Kind::ALL {
                    if !kind_matches(filter, kind) {
                        continue;
                    }
                    for &id in &self.buckets[base + kind.index()] {
                        out.push(Neighbour { id, kind, cell, offset, distance });
                    }
                }
            }
        }
        sort_hits(out);
    }

    /// Visit every hit of [`SpatialIndex::within`] exactly once, **in no
    /// specified order**, without allocating or sorting (TASK-026, ADR-029
    /// §3A). Only for order-independent consumers, e.g. a maximum with an
    /// explicit total tie-break on `(distance, id)`.
    #[inline]
    pub fn for_each_within(&self, center: Cell, r: u32, filter: Option<Kind>, mut f: impl FnMut(&Neighbour)) {
        let center = self.torus.wrap(center.x as i64, center.y as i64);
        if self.uses_locator_scan(r) {
            for (&id, &(cell, kind)) in &self.locator {
                if !kind_matches(filter, kind) {
                    continue;
                }
                let offset = self.torus.offset(center, cell);
                let distance = offset.chebyshev();
                if distance <= r {
                    f(&Neighbour { id, kind, cell, offset, distance });
                }
            }
        } else {
            for (cell, offset) in self.torus.within(center, r) {
                let base = self.torus.index(cell) * 3;
                let distance = offset.chebyshev();
                for kind in Kind::ALL {
                    if !kind_matches(filter, kind) {
                        continue;
                    }
                    for &id in &self.buckets[base + kind.index()] {
                        f(&Neighbour { id, kind, cell, offset, distance });
                    }
                }
            }
        }
    }

    /// Number of entries [`SpatialIndex::within`] would return.
    pub fn count_within(&self, center: Cell, r: u32, filter: Option<Kind>) -> usize {
        let center = self.torus.wrap(center.x as i64, center.y as i64);
        if self.uses_locator_scan(r) {
            self.locator
                .values()
                .filter(|(c, k)| kind_matches(filter, *k) && self.torus.distance(center, *c) <= r)
                .count()
        } else {
            self.torus
                .within(center, r)
                .map(|(cell, _)| {
                    let base = self.torus.index(cell) * 3;
                    Kind::ALL.iter().filter(|k| kind_matches(filter, **k)).map(|k| self.buckets[base + k.index()].len()).sum::<usize>()
                })
                .sum()
        }
    }

    /// First hit of `within` in `(distance, id)` order satisfying `pred`.
    ///
    /// Implemented as an unsorted min-search (TASK-026, ADR-029 §3B): `pred`
    /// is only called for hits whose `(distance, id)` is smaller than the best
    /// accepted one so far, so the set and order of `pred` calls differ from a
    /// sorted scan. **`pred` must be pure** (no side effects, result depends
    /// only on its argument); then the result is identical.
    pub fn nearest(&self, center: Cell, r: u32, filter: Option<Kind>, mut pred: impl FnMut(&Neighbour) -> bool) -> Option<Neighbour> {
        let mut best: Option<Neighbour> = None;
        self.for_each_within(center, r, filter, |n| {
            if best.is_none_or(|b| (n.distance, n.id) < (b.distance, b.id)) && pred(n) {
                best = Some(*n);
            }
        });
        best
    }

    /// All entries, ascending ID.
    pub fn entries(&self) -> impl Iterator<Item = (EntityId, Kind, Cell)> + '_ {
        self.locator.iter().map(|(&id, &(c, k))| (id, k, c))
    }

    /// Consistency check: the index holds exactly `expected` (any order) and
    /// its buckets agree with the locator.
    pub fn check_against(&self, expected: impl IntoIterator<Item = (EntityId, Kind, Cell)>) -> Result<(), String> {
        let mut exp: Vec<(EntityId, Kind, Cell)> = expected.into_iter().collect();
        exp.sort_by_key(|e| e.0);
        let got: Vec<(EntityId, Kind, Cell)> = self.entries().collect();
        if exp != got {
            return Err(format!("spatial index holds {} entries, expected {} (or positions differ)", got.len(), exp.len()));
        }
        let mut in_buckets = 0usize;
        for (s, b) in self.buckets.iter().enumerate() {
            if b.windows(2).any(|w| w[0] >= w[1]) {
                return Err(format!("bucket {s} not strictly ascending"));
            }
            let cell = self.torus.cell_at(s / 3);
            let kind = Kind::ALL[s % 3];
            for id in b {
                if self.locator.get(id) != Some(&(cell, kind)) {
                    return Err(format!("entity {} in bucket of ({}, {}) disagrees with locator", id.0, cell.x, cell.y));
                }
            }
            in_buckets += b.len();
        }
        if in_buckets != self.locator.len() {
            return Err(format!("{} bucket entries vs {} located", in_buckets, self.locator.len()));
        }
        Ok(())
    }
}

/// Brute-force oracle: every entry checked with `Torus::distance`, same
/// result order as [`SpatialIndex::within`].
pub fn brute_force_within(
    torus: &Torus,
    entries: impl IntoIterator<Item = (EntityId, Kind, Cell)>,
    center: Cell,
    r: u32,
    filter: Option<Kind>,
) -> Vec<Neighbour> {
    let center = torus.wrap(center.x as i64, center.y as i64);
    let mut v: Vec<Neighbour> = entries
        .into_iter()
        .filter(|(_, k, _)| kind_matches(filter, *k))
        .filter_map(|(id, kind, cell)| {
            let distance = torus.distance(center, cell);
            (distance <= r).then(|| Neighbour { id, kind, cell, offset: torus.offset(center, cell), distance })
        })
        .collect();
    sort_hits(&mut v);
    v
}

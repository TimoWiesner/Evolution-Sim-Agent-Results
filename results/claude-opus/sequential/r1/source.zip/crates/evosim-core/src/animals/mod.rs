//! Animal sensing and movement (TASK-013, ADR-016; user doc docs/ANIMALS.md).
//!
//! * [`sense`]: perception of living organisms within the trait-derived
//!   vision radius `floor(traits.vision)` (toroidal Chebyshev, across edges).
//! * [`movement`]: deterministic stride (steps per tick limited by speed),
//!   per-step cost growing within a tick, wrap-aware shortest steps towards a
//!   target, flight, and the correlated random walk used when nothing
//!   interesting is in sight.
//! * [`act_animals`]: the TASK-013 sense+move policy, kept as a
//!   movement-only helper (tests); no longer a phase body.
//! * [`feed`] / [`herbivore`]: herbivore feeding, metabolism, climate cost and
//!   gene-driven decisions (TASK-014, ADR-017); `act_herbivores` is the
//!   Herbivores phase body.
//! * [`hunt`] / [`carnivore`]: carnivore attacks (formula, reach, cost,
//!   gain, handling) and the carnivore turn (TASK-015, ADR-018);
//!   `act_carnivores` is the Carnivores phase body.
//! * [`repro`]: sexual reproduction of animals (TASK-016, ADR-019); the
//!   mating pass `reproduce_animals` runs at the end of each animal phase.
//!
//! Every move respects THE cell-sharing rule (`organism::CellCapacity`,
//! `Population::has_room`) and goes through `Population::move_organism`, so
//! the spatial index stays in sync.

pub mod carnivore;
pub mod feed;
pub mod herbivore;
pub mod hunt;
pub mod movement;
pub mod repro;
pub mod sense;

#[cfg(test)]
mod tests;
#[cfg(test)]
mod tests_feed;
#[cfg(test)]
mod tests_hunt;
#[cfg(test)]
mod tests_repro;

pub use movement::{
    move_away, move_towards, path_cost, preferred_steps, step_cost, steps_allowed, wander, MoveCosts, MoveOutcome, MoveTick,
    WANDER_TURN_CHANCE,
};
pub use sense::{perceive, vision_radius, Perception};
pub use feed::{Bite, FeedParams, FeedTick, HerbivoreLedger, FEED_REACH};
pub use carnivore::{act_carnivores, carnivore_turn, CarnivoreAction, CarnivoreTurn};
pub use repro::{compatible, is_ready, reproduce_animals, AnimalReproTick, ReproLedger, ReproParams, MATING_REACH};
pub use hunt::{Attack, HuntLedger, HuntParams, HuntTick, ATTACK_REACH};
pub use herbivore::{act_herbivores, herbivore_turn, HerbivoreAction, HerbivoreTurn};

use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{Kind, Population};
use crate::rng::Rng;

/// Kind an animal of `kind` is interested in (its food); `None` for plants.
pub fn food_kind(kind: Kind) -> Option<Kind> {
    match kind {
        Kind::Plant => None,
        Kind::Herbivore => Some(Kind::Plant),
        Kind::Carnivore => Some(Kind::Herbivore),
    }
}

/// Default TASK-013 policy for the actors `ids` (already in acting order) of
/// `kind`: per living actor, update the stride (steps allowed this tick);
/// if food is visible, head for the nearest one (distance, id) and stop at
/// distance ≤ 1 (stay if already there); otherwise wander. Plants: no-op.
pub fn act_animals(pop: &mut Population, ids: &[EntityId], kind: Kind, cfg: &Config, rng: &mut Rng) -> MoveTick {
    let mut tick = MoveTick::default();
    let Some(food) = food_kind(kind) else { return tick };
    let costs = MoveCosts::for_kind(kind, cfg);
    for &id in ids {
        let Some(o) = pop.get_alive(id) else { continue };
        if o.kind() != kind {
            continue;
        }
        let (center, speed, r, stride) = (o.pos(), o.traits().speed, vision_radius(o.traits()), o.stride());
        let (allowed, new_stride) = steps_allowed(stride, speed, costs.max_speed);
        pop.get_alive_mut(id).expect("alive").set_stride(new_stride);
        let target = pop.nearest(center, r, Some(food), |n| n.id != id);
        let out = match target {
            Some(n) if n.distance <= 1 => MoveOutcome::stay(center),
            Some(n) => move_towards(pop, id, n.cell, allowed, 1, &costs),
            None => wander(pop, id, allowed, &costs, rng),
        };
        tick.record(&out);
    }
    tick
}

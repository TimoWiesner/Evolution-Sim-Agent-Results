//! Inspection exports of a [`ClimateMap`] without any UI: text, JSON, PPM.

use super::{Biome, ClimateMap};
use serde_json::{json, Map, Value};

/// Text map: `height` lines of `width` biome symbols, a blank line, the
/// legend (one line per biome) and a counts line.
pub fn to_text(map: &ClimateMap) -> String {
    let mut s = String::with_capacity((map.width() as usize + 1) * map.height() as usize + 512);
    for y in 0..map.height() {
        s.push_str(&map.row_string(y));
        s.push('\n');
    }
    s.push('\n');
    for b in Biome::ALL {
        s.push_str(&format!("{} {} ({})\n", b.symbol(), b.name(), b.rule()));
    }
    let counts = map.biome_counts();
    let parts: Vec<String> = Biome::ALL.iter().map(|b| format!("{}={}", b.name(), counts[b.rank() as usize])).collect();
    s.push_str(&format!(
        "{}x{} cells; latitude: pole band on the top/bottom seam, equator mid-map; counts: {}\n",
        map.width(),
        map.height(),
        parts.join(" ")
    ));
    s
}

/// JSON export: size, biome legend, row strings, temperature and
/// precipitation grids (rows of numbers), latitude per row, counts.
pub fn to_json(map: &ClimateMap) -> Value {
    let (w, h) = (map.width() as usize, map.height() as usize);
    let cells = map.cells();
    let rows: Vec<Value> = (0..map.height()).map(|y| Value::String(map.row_string(y))).collect();
    let grid = |f: &dyn Fn(usize) -> f64| -> Value {
        Value::Array((0..h).map(|y| Value::Array((0..w).map(|x| json!(f(y * w + x))).collect())).collect())
    };
    let temperature = grid(&|i| cells[i].temperature);
    let precipitation = grid(&|i| cells[i].precipitation);
    let latitude: Vec<Value> = (0..h).map(|y| json!(cells[y * w].latitude)).collect();
    let counts_arr = map.biome_counts();
    let mut counts = Map::new();
    for b in Biome::ALL {
        counts.insert(b.name().to_string(), json!(counts_arr[b.rank() as usize]));
    }
    let biomes: Vec<Value> = Biome::ALL
        .iter()
        .map(|b| json!({"symbol": b.symbol().to_string(), "name": b.name(), "rank": b.rank(), "rule": b.rule(), "rgb": b.rgb()}))
        .collect();
    json!({
        "width": w,
        "height": h,
        "biomes": biomes,
        "rows": rows,
        "latitude": latitude,
        "temperature": temperature,
        "precipitation": precipitation,
        "counts": Value::Object(counts),
    })
}

/// Binary PPM (P6) image, one pixel per cell in biome colours.
pub fn to_ppm(map: &ClimateMap) -> Vec<u8> {
    let mut out = format!("P6\n{} {}\n255\n", map.width(), map.height()).into_bytes();
    out.reserve(map.cells().len() * 3);
    for c in map.cells() {
        out.extend_from_slice(&c.biome.rgb());
    }
    out
}

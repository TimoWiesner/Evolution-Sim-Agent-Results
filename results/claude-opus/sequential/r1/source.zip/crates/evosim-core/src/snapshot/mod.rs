//! Checkpoints (ADR-025, docs/CHECKPOINTS.md): the complete simulation state
//! as one UTF-8 JSON document
//! `{"format":"evosim-checkpoint","version":1,"engine":..,"tick":..,
//! "state_hash":..,"config":{..},"state":{..}}`.
//!
//! `state` holds exactly the state hashed by [`Simulation::state_hash`]
//! (ADR-022); the derived caches (base climate map, climate bounds, gene
//! expression, cell capacity, spatial index) are rebuilt from `config`.
//! After a restore the hash is recomputed and must equal the stored
//! `state_hash` ([`SnapshotError::Integrity`] otherwise). This module does no
//! file I/O; the CLI reads and writes the text.

#[cfg(test)]
mod tests;

use std::fmt;

use serde_json::Value;

use crate::config::Config;
use crate::ids::IdAllocator;
use crate::rng::{Rng, RngState};
use crate::sim::world::{World, WorldState};
use crate::sim::Simulation;

/// Value of the `format` key.
pub const CHECKPOINT_FORMAT: &str = "evosim-checkpoint";
/// Current checkpoint format version (the only one accepted).
pub const CHECKPOINT_VERSION: u64 = 1;

/// Why a checkpoint could not be written or read. All map to exit status 2.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SnapshotError {
    /// File missing/unreadable (used by callers doing I/O).
    Io(String),
    /// Not UTF-8, not JSON, truncated.
    Parse(String),
    /// Wrong or missing `format` / `version`.
    Version(String),
    /// Missing or ill-typed fields, invalid configuration or state.
    Invalid(String),
    /// Stored `state_hash` differs from the hash of the restored state.
    Integrity { stored: String, actual: String },
}

impl fmt::Display for SnapshotError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SnapshotError::Io(m) => write!(f, "{m}"),
            SnapshotError::Parse(m) => write!(f, "not a readable checkpoint (damaged or truncated): {m}"),
            SnapshotError::Version(m) => write!(f, "unsupported checkpoint: {m}"),
            SnapshotError::Invalid(m) => write!(f, "invalid checkpoint contents: {m}"),
            SnapshotError::Integrity { stored, actual } => {
                write!(f, "checkpoint is damaged: stored state_hash {stored} but restored state hashes to {actual}")
            }
        }
    }
}

impl std::error::Error for SnapshotError {}

/// Serialisable simulation state (everything but the configuration, which is
/// stored separately through the validated config path).
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
struct StateDto {
    tick: u64,
    rng: RngState,
    ids: IdAllocator,
    world: WorldState,
}

impl Simulation {
    /// Checkpoint text of this simulation (ADR-025); see [`to_json_string`].
    pub fn checkpoint_json(&self) -> Result<String, SnapshotError> {
        to_json_string(self)
    }

    /// Restore a simulation from checkpoint text; see [`from_json_str`].
    pub fn from_checkpoint_json(text: &str) -> Result<Simulation, SnapshotError> {
        from_json_str(text)
    }

    /// Exhaustive destructuring: a new field is a compile error until the
    /// snapshot decides it.
    fn snapshot_parts(&self) -> (Value, StateDto) {
        let (config, tick, rng, world, ids) = self.parts();
        (config.to_json_value(), StateDto { tick, rng, ids: ids.clone(), world: world.snapshot_state() })
    }
}

/// Serialise `sim` into checkpoint text (compact JSON + trailing newline).
pub fn to_json_string(sim: &Simulation) -> Result<String, SnapshotError> {
    let (config, state) = sim.snapshot_parts();
    let state = serde_json::to_value(&state).map_err(|e| SnapshotError::Invalid(format!("cannot serialise state: {e}")))?;
    let mut doc = serde_json::Map::new();
    doc.insert("format".into(), Value::from(CHECKPOINT_FORMAT));
    doc.insert("version".into(), Value::from(CHECKPOINT_VERSION));
    doc.insert("engine".into(), Value::from(crate::VERSION));
    doc.insert("tick".into(), Value::from(sim.tick()));
    doc.insert("state_hash".into(), Value::from(sim.state_hash()));
    doc.insert("config".into(), config);
    doc.insert("state".into(), state);
    let mut s = serde_json::to_string(&Value::Object(doc)).map_err(|e| SnapshotError::Invalid(format!("cannot serialise checkpoint: {e}")))?;
    s.push('\n');
    Ok(s)
}

/// Restore a simulation from checkpoint text. Checks, in this order: JSON
/// syntax, `format`, `version`, configuration, state structure, state
/// consistency, stored `state_hash`.
pub fn from_json_str(text: &str) -> Result<Simulation, SnapshotError> {
    let v: Value = serde_json::from_str(text).map_err(|e| SnapshotError::Parse(e.to_string()))?;
    let obj = v.as_object().ok_or_else(|| SnapshotError::Version("top level is not a JSON object".into()))?;
    match obj.get("format") {
        Some(Value::String(f)) if f == CHECKPOINT_FORMAT => {}
        Some(other) => return Err(SnapshotError::Version(format!("format {other} is not \"{CHECKPOINT_FORMAT}\""))),
        None => return Err(SnapshotError::Version("missing \"format\"".into())),
    }
    match obj.get("version") {
        Some(Value::Number(n)) if n.as_u64() == Some(CHECKPOINT_VERSION) => {}
        Some(other) => return Err(SnapshotError::Version(format!("version {other} is not supported (expected {CHECKPOINT_VERSION})"))),
        None => return Err(SnapshotError::Version("missing \"version\"".into())),
    }
    let stored_hash = match obj.get("state_hash") {
        Some(Value::String(h)) => h.clone(),
        _ => return Err(SnapshotError::Invalid("missing or non-string \"state_hash\"".into())),
    };
    let tick = obj.get("tick").and_then(Value::as_u64).ok_or_else(|| SnapshotError::Invalid("missing or non-integer \"tick\"".into()))?;
    let config_v = obj.get("config").ok_or_else(|| SnapshotError::Invalid("missing \"config\"".into()))?;
    let config = Config::from_value(config_v).map_err(|e| SnapshotError::Invalid(format!("config: {e}")))?;
    let state_v = obj.get("state").ok_or_else(|| SnapshotError::Invalid("missing \"state\"".into()))?;
    let state = StateDto::deserialize_value(state_v)?;
    if state.tick != tick {
        return Err(SnapshotError::Invalid(format!("tick {tick} differs from state tick {}", state.tick)));
    }
    let sim = restore(config, state).map_err(SnapshotError::Invalid)?;
    let actual = sim.state_hash();
    if actual != stored_hash {
        return Err(SnapshotError::Integrity { stored: stored_hash, actual });
    }
    Ok(sim)
}

impl StateDto {
    fn deserialize_value(v: &Value) -> Result<StateDto, SnapshotError> {
        <StateDto as serde::Deserialize>::deserialize(v).map_err(|e| SnapshotError::Invalid(format!("state: {e}")))
    }
}

fn restore(config: Config, s: StateDto) -> Result<Simulation, String> {
    let StateDto { tick, rng, ids, world } = s;
    let rng = Rng::from_state(rng).map_err(|e| format!("rng: {e}"))?;
    if ids.peek_next() == 0 {
        return Err("ID counter is 0 (IDs start at 1)".to_string());
    }
    let world = World::from_snapshot(&config, world, tick, ids.peek_next())?;
    Ok(Simulation::from_parts(config, tick, rng, world, ids))
}

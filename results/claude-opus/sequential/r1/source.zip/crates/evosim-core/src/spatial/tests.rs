use super::*;
use crate::rng::Rng;

fn t(w: u32, h: u32) -> Torus {
    Torus::new(w, h).unwrap()
}

fn id(n: u64) -> EntityId {
    EntityId(n)
}

fn ids(v: &[Neighbour]) -> Vec<u64> {
    v.iter().map(|n| n.id.0).collect()
}

#[test]
fn seam_query_finds_across_both_edges() {
    let mut s = SpatialIndex::new(t(10, 8));
    s.insert(id(1), Kind::Plant, Cell::new(9, 7)).unwrap();
    s.insert(id(2), Kind::Herbivore, Cell::new(9, 0)).unwrap();
    s.insert(id(3), Kind::Carnivore, Cell::new(0, 7)).unwrap();
    s.insert(id(4), Kind::Plant, Cell::new(5, 4)).unwrap();
    let r = s.within(Cell::new(0, 0), 1, None);
    assert_eq!(ids(&r), vec![1, 2, 3]);
    assert_eq!(r[0].offset, Offset::new(-1, -1));
    assert_eq!(r[1].offset, Offset::new(-1, 0));
    assert_eq!(r[2].offset, Offset::new(0, -1));
    assert!(r.iter().all(|n| n.distance == 1));
    assert_eq!(s.count_within(Cell::new(0, 0), 1, None), 3);
    // Same from the opposite corner.
    let r = s.within(Cell::new(9, 7), 1, None);
    assert_eq!(ids(&r), vec![1, 2, 3]);
}

#[test]
fn kind_filter_returns_only_that_kind() {
    let mut s = SpatialIndex::new(t(6, 6));
    let mut n = 0;
    for y in 0..6 {
        for x in 0..6 {
            n += 1;
            s.insert(id(n), Kind::ALL[(n % 3) as usize], Cell::new(x, y)).unwrap();
        }
    }
    for k in Kind::ALL {
        let r = s.within(Cell::new(2, 2), 1, Some(k));
        assert!(!r.is_empty());
        assert!(r.iter().all(|h| h.kind == k));
        assert_eq!(r.len(), s.count_within(Cell::new(2, 2), 1, Some(k)));
        assert!(s.at(Cell::new(0, 0), Some(k)).iter().all(|i| s.location(*i).unwrap().1 == k));
    }
    let all = s.within(Cell::new(2, 2), 1, None).len();
    let per: usize = Kind::ALL.iter().map(|k| s.within(Cell::new(2, 2), 1, Some(*k)).len()).sum();
    assert_eq!(all, 9);
    assert_eq!(per, all);
}

#[test]
fn no_duplicates_for_radius_larger_than_world() {
    for (w, h) in [(1, 1), (1, 5), (5, 1), (2, 2), (3, 3), (4, 7)] {
        let torus = t(w, h);
        // Several entities per cell, both scan paths (few vs many entities).
        for per_cell in [1u64, 4] {
            let mut s = SpatialIndex::new(torus);
            let mut n = 0;
            for c in torus.cells() {
                for _ in 0..per_cell {
                    n += 1;
                    s.insert(id(n), Kind::ALL[(n % 3) as usize], c).unwrap();
                }
            }
            for r in 0..=20 {
                for center in torus.cells() {
                    let hits = s.within(center, r, None);
                    let mut u = ids(&hits);
                    u.sort();
                    u.dedup();
                    assert_eq!(u.len(), hits.len(), "duplicates {w}x{h} r={r}");
                    assert!(hits.iter().all(|h| h.distance <= r && h.distance == torus.distance(center, h.cell)));
                    if r >= torus.max_distance() {
                        assert_eq!(hits.len() as u64, n, "every entity once {w}x{h} r={r}");
                    }
                }
            }
        }
    }
}

#[test]
fn every_result_within_radius_and_offset_consistent() {
    let torus = t(13, 9);
    let mut s = SpatialIndex::new(torus);
    let mut rng = Rng::seed_from_u64(5);
    for n in 1..=200 {
        let c = Cell::new(rng.below(13) as u32, rng.below(9) as u32);
        s.insert(id(n), Kind::ALL[rng.below(3) as usize], c).unwrap();
    }
    for r in 0..8 {
        let center = Cell::new(rng.below(13) as u32, rng.below(9) as u32);
        for h in s.within(center, r, None) {
            assert!(h.distance <= r);
            assert_eq!(torus.translate(center, h.offset), h.cell);
            assert_eq!(h.offset, torus.offset(center, h.cell));
        }
    }
}

#[test]
fn removed_never_returned() {
    let mut s = SpatialIndex::new(t(8, 8));
    s.insert(id(1), Kind::Plant, Cell::new(3, 3)).unwrap();
    s.insert(id(2), Kind::Plant, Cell::new(3, 3)).unwrap();
    assert_eq!(s.remove(id(1)), Some((Cell::new(3, 3), Kind::Plant)));
    assert_eq!(s.remove(id(1)), None);
    assert!(!s.contains(id(1)));
    for r in 0..10 {
        assert_eq!(ids(&s.within(Cell::new(3, 3), r, None)), vec![2]);
    }
    assert_eq!(s.at(Cell::new(3, 3), None), vec![id(2)]);
    s.check_against([(id(2), Kind::Plant, Cell::new(3, 3))]).unwrap();
}

#[test]
fn moved_not_returned_from_old_cell() {
    let mut s = SpatialIndex::new(t(20, 20));
    s.insert(id(7), Kind::Herbivore, Cell::new(1, 1)).unwrap();
    assert_eq!(s.move_to(id(7), Cell::new(15, 15)), Ok(Cell::new(1, 1)));
    assert!(s.within(Cell::new(1, 1), 0, None).is_empty());
    assert!(s.within(Cell::new(1, 1), 3, None).is_empty());
    assert!(s.at(Cell::new(1, 1), None).is_empty());
    let r = s.within(Cell::new(15, 15), 0, Some(Kind::Herbivore));
    assert_eq!(ids(&r), vec![7]);
    assert_eq!(s.location(id(7)), Some((Cell::new(15, 15), Kind::Herbivore)));
    s.check_against([(id(7), Kind::Herbivore, Cell::new(15, 15))]).unwrap();
}

#[test]
fn mutation_errors() {
    let mut s = SpatialIndex::new(t(4, 4));
    s.insert(id(1), Kind::Plant, Cell::new(0, 0)).unwrap();
    assert_eq!(s.insert(id(1), Kind::Plant, Cell::new(1, 0)), Err(SpatialError::Duplicate(id(1))));
    assert_eq!(s.insert(id(2), Kind::Plant, Cell::new(4, 0)), Err(SpatialError::OutsideWorld(Cell::new(4, 0))));
    assert_eq!(s.move_to(id(9), Cell::new(1, 1)), Err(SpatialError::Unknown(id(9))));
    assert_eq!(s.move_to(id(1), Cell::new(0, 4)), Err(SpatialError::OutsideWorld(Cell::new(0, 4))));
    assert_eq!(s.len(), 1);
    s.check_against([(id(1), Kind::Plant, Cell::new(0, 0))]).unwrap();
    assert!(!SpatialError::Unknown(id(9)).to_string().is_empty());
}

#[test]
fn move_to_same_cell_noop() {
    let mut s = SpatialIndex::new(t(4, 4));
    s.insert(id(1), Kind::Plant, Cell::new(2, 2)).unwrap();
    let before = s.clone();
    assert_eq!(s.move_to(id(1), Cell::new(2, 2)), Ok(Cell::new(2, 2)));
    assert_eq!(s, before);
}

#[test]
fn results_sorted_by_distance_then_id() {
    let mut s = SpatialIndex::new(t(30, 30));
    let mut rng = Rng::seed_from_u64(11);
    for n in (1..=300).rev() {
        s.insert(id(n), Kind::ALL[rng.below(3) as usize], Cell::new(rng.below(30) as u32, rng.below(30) as u32)).unwrap();
    }
    for r in [0, 1, 3, 7, 20] {
        let hits = s.within(Cell::new(4, 28), r, None);
        assert!(hits.windows(2).all(|w| (w[0].distance, w[0].id) < (w[1].distance, w[1].id)));
    }
    let first = s.nearest(Cell::new(4, 28), 30, Some(Kind::Carnivore), |_| true).unwrap();
    assert_eq!(Some(first), s.within(Cell::new(4, 28), 30, Some(Kind::Carnivore)).first().copied());
    let pred = s.nearest(Cell::new(4, 28), 30, None, |n| n.id.0 % 7 == 0).unwrap();
    assert_eq!(pred.id.0 % 7, 0);
}

#[test]
fn order_independent_of_insertion_history() {
    let torus = t(25, 17);
    let mut rng = Rng::seed_from_u64(3);
    let ents: Vec<(EntityId, Kind, Cell)> = (1..=250)
        .map(|n| (id(n), Kind::ALL[rng.below(3) as usize], Cell::new(rng.below(25) as u32, rng.below(17) as u32)))
        .collect();
    let mut a = SpatialIndex::new(torus);
    for &(i, k, c) in &ents {
        a.insert(i, k, c).unwrap();
    }
    let mut order = ents.clone();
    rng.shuffle(&mut order);
    let mut b = SpatialIndex::new(torus);
    for &(i, k, c) in &order {
        // Insert elsewhere first, then move back (round trip).
        b.insert(i, k, torus.wrap(c.x as i64 + 5, c.y as i64 + 3)).unwrap();
    }
    for &(i, _, c) in &order {
        b.move_to(i, c).unwrap();
    }
    assert_eq!(a, b);
    for r in [0, 2, 5, 12] {
        for center in [Cell::new(0, 0), Cell::new(24, 16), Cell::new(12, 8)] {
            assert_eq!(a.within(center, r, None), b.within(center, r, None));
        }
    }
}

/// AC4: ≥ 1,000 randomised queries vs brute force with interleaved
/// insert/move/remove, small worlds and radii larger than the world.
#[test]
fn randomised_matches_brute_force() {
    let worlds = [(1, 1), (1, 7), (7, 1), (2, 2), (3, 5), (16, 16), (64, 48), (200, 200)];
    let mut rng = Rng::seed_from_u64(0x5A7_1A1);
    let (mut queries, mut locator_path, mut cell_path, mut nonempty) = (0usize, 0usize, 0usize, 0usize);
    let mut next = 1u64;
    for (w, h) in worlds {
        let torus = t(w, h);
        let mut s = SpatialIndex::new(torus);
        let mut shadow: Vec<(EntityId, Kind, Cell)> = Vec::new();
        let rand_cell = |rng: &mut Rng| Cell::new(rng.below(w as u64) as u32, rng.below(h as u64) as u32);
        let target = rng.below(300) as usize;
        for _ in 0..target {
            let c = rand_cell(&mut rng);
            let k = Kind::ALL[rng.below(3) as usize];
            s.insert(id(next), k, c).unwrap();
            shadow.push((id(next), k, c));
            next += 1;
        }
        for round in 0..700 {
            match rng.below(4) {
                0 => {
                    let c = rand_cell(&mut rng);
                    let k = Kind::ALL[rng.below(3) as usize];
                    s.insert(id(next), k, c).unwrap();
                    shadow.push((id(next), k, c));
                    next += 1;
                }
                1 if !shadow.is_empty() => {
                    let i = rng.below(shadow.len() as u64) as usize;
                    let e = shadow.swap_remove(i);
                    assert_eq!(s.remove(e.0), Some((e.2, e.1)));
                }
                2 | 3 if !shadow.is_empty() => {
                    let i = rng.below(shadow.len() as u64) as usize;
                    let c = rand_cell(&mut rng);
                    assert_eq!(s.move_to(shadow[i].0, c), Ok(shadow[i].2));
                    shadow[i].2 = c;
                }
                _ => {}
            }
            let center = rand_cell(&mut rng);
            let r = rng.below(w.max(h) as u64 + 4) as u32;
            let filter = match rng.below(4) {
                0 => None,
                k => Some(Kind::ALL[k as usize - 1]),
            };
            let got = s.within(center, r, filter);
            let want = brute_force_within(&torus, shadow.iter().copied(), center, r, filter);
            assert_eq!(got, want, "{w}x{h} round {round} center {center:?} r={r} filter {filter:?}");
            assert_eq!(s.count_within(center, r, filter), want.len());
            if s.uses_locator_scan(r) {
                locator_path += 1;
            } else {
                cell_path += 1;
            }
            if !want.is_empty() {
                nonempty += 1;
            }
            queries += 1;
            if round % 50 == 0 {
                s.check_against(shadow.iter().copied()).unwrap();
            }
        }
        s.check_against(shadow.iter().copied()).unwrap();
    }
    assert!(queries >= 1000, "{queries}");
    assert!(locator_path > 100 && cell_path > 100, "locator {locator_path} cell {cell_path}");
    assert!(nonempty > queries / 3, "nonempty {nonempty}");
}

#[test]
fn center_outside_is_wrapped_and_default_is_1x1() {
    let mut s = SpatialIndex::default();
    assert_eq!(s.torus().cell_count(), 1);
    s.insert(id(1), Kind::Plant, Cell::new(0, 0)).unwrap();
    assert_eq!(ids(&s.within(Cell::new(5, 5), 0, None)), vec![1]);
    s.clear();
    assert!(s.is_empty());
    assert_eq!(s.count(Kind::Plant), 0);
}

/// TASK-026 (ADR-029 §3A/§3B): the unsorted visitor yields exactly the hit
/// multiset of `within`, and the min-search `nearest` equals the first hit of
/// the sorted `within` that satisfies the (pure) predicate, on tiny wrapping
/// worlds (duplicate-offset edge cases, locator branch) and a normal world.
#[test]
fn unsorted_visitor_and_min_search_nearest_match_sorted_oracle() {
    let worlds = [(1, 1), (3, 3), (5, 4), (2, 7), (64, 48)];
    let mut rng = Rng::seed_from_u64(0x7A5C_026);
    let mut next = 1u64;
    let (mut checked, mut some_nearest, mut locator, mut cells) = (0usize, 0usize, 0usize, 0usize);
    for (w, h) in worlds {
        let torus = t(w, h);
        for density in [3u64, 40, 400] {
            let mut s = SpatialIndex::new(torus);
            let n = rng.below(density) + 1;
            for _ in 0..n {
                let c = Cell::new(rng.below(w as u64) as u32, rng.below(h as u64) as u32);
                s.insert(id(next), Kind::ALL[rng.below(3) as usize], c).unwrap();
                next += 1;
            }
            for r in 0..=8u32 {
                for _ in 0..6 {
                    let center = Cell::new(rng.below(w as u64) as u32, rng.below(h as u64) as u32);
                    let filter = match rng.below(4) {
                        0 => None,
                        k => Some(Kind::ALL[k as usize - 1]),
                    };
                    let want = s.within(center, r, filter);
                    let mut got = Vec::new();
                    s.for_each_within(center, r, filter, |n| got.push(*n));
                    got.sort_unstable_by_key(|n| (n.distance, n.id));
                    assert_eq!(got, want, "{w}x{h} center {center:?} r={r} {filter:?}");
                    // Pure predicates of several selectivities.
                    let m = rng.below(5) + 1;
                    let pred = |n: &Neighbour| n.id.0 % m == 0;
                    let near = s.nearest(center, r, filter, pred);
                    assert_eq!(near, want.iter().copied().find(|n| pred(n)), "{w}x{h} r={r} m={m}");
                    assert_eq!(s.nearest(center, r, filter, |_| true), want.first().copied());
                    assert_eq!(s.nearest(center, r, filter, |_| false), None);
                    some_nearest += near.is_some() as usize;
                    if s.uses_locator_scan(r) {
                        locator += 1;
                    } else {
                        cells += 1;
                    }
                    checked += 1;
                }
            }
        }
    }
    assert!(checked >= 600 && some_nearest > checked / 4, "{checked} {some_nearest}");
    assert!(locator > 50 && cells > 50, "locator {locator} cells {cells}");
}

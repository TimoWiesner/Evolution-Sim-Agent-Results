//! State digest (TASK-019, ADR-022): in-crate SHA-256 and the canonical
//! state stream writer [`StateHasher`]. Leaf module without crate deps.
//!
//! Canonical encoding: typed writers (little-endian integers, floats via
//! `to_bits`, length prefixes, section tags) plus [`StateHasher::debug`],
//! which streams the *derived* `Debug` representation of a value. Derived
//! `Debug` prints every field (no manual `Debug` impls exist in core), and
//! Rust prints floats with the shortest representation that round-trips, so
//! two values with different field contents give different text. Owning
//! types destructure themselves exhaustively at the top level so that a new
//! field forces a hashing decision at compile time.

mod sha256;
#[cfg(test)]
mod tests;

pub use sha256::{hex, Sha256};

use std::fmt;

/// Version tag that starts every state stream.
pub const STATE_STREAM_VERSION: &str = "evosim-state-v1";

/// Typed writer over SHA-256.
#[derive(Debug, Clone, Default)]
pub struct StateHasher {
    sha: Sha256,
}

impl StateHasher {
    pub fn new() -> StateHasher {
        let mut h = StateHasher { sha: Sha256::new() };
        h.str(STATE_STREAM_VERSION);
        h
    }

    pub fn bytes(&mut self, b: &[u8]) {
        self.u64(b.len() as u64);
        self.sha.update(b);
    }
    pub fn str(&mut self, s: &str) {
        self.bytes(s.as_bytes());
    }
    pub fn u8(&mut self, v: u8) {
        self.sha.update(&[v]);
    }
    pub fn bool(&mut self, v: bool) {
        self.u8(v as u8);
    }
    pub fn u32(&mut self, v: u32) {
        self.sha.update(&v.to_le_bytes());
    }
    pub fn u64(&mut self, v: u64) {
        self.sha.update(&v.to_le_bytes());
    }
    pub fn i64(&mut self, v: i64) {
        self.sha.update(&v.to_le_bytes());
    }
    pub fn f64(&mut self, v: f64) {
        self.u64(v.to_bits());
    }
    pub fn f32(&mut self, v: f32) {
        self.u32(v.to_bits());
    }
    /// Length prefix of a sequence.
    pub fn len(&mut self, n: usize) {
        self.u64(n as u64);
    }
    /// Section tag so adjacent sections cannot alias.
    pub fn section(&mut self, name: &'static str) {
        self.u8(0xA5);
        self.str(name);
    }
    /// Stream the derived `Debug` text of `v`, terminated by a separator
    /// byte (0x00 never occurs in Debug output of our types' contents).
    pub fn debug<T: fmt::Debug + ?Sized>(&mut self, v: &T) {
        use fmt::Write;
        let _ = write!(DebugSink(&mut self.sha), "{v:?}");
        self.sha.update(&[0]);
    }
    /// Lowercase hex of the SHA-256 of everything written.
    pub fn finish_hex(self) -> String {
        hex(&self.sha.finalize())
    }
}

struct DebugSink<'a>(&'a mut Sha256);

impl fmt::Write for DebugSink<'_> {
    fn write_str(&mut self, s: &str) -> fmt::Result {
        self.0.update(s.as_bytes());
        Ok(())
    }
}

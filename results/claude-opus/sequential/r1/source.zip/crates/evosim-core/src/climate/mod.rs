//! Static base climate: latitude zones, base temperature/precipitation and
//! biomes per cell, continuous across both seams of the torus (ADR-009,
//! TASK-006). Seasons and weather (TASK-007, ADR-010) are a separate layer
//! on top: `season` (pure cycle + bounds) and `weather` (AR(1) lattices).
//!
//! Latitude is *folded*: `φ(y) = 90·|1 − 2(y + 0.5)/h|`, so the equator lies
//! in the middle row(s) and the single polar band straddles the top/bottom
//! seam. The formula is periodic in y with period h and symmetric about the
//! seam, therefore rows `h−1` and `0` have identical latitude. East-west
//! variation comes only from seeded torus-periodic noise (`noise`), drawn from
//! a dedicated generator so the core simulation RNG stream is not touched.

pub mod biome;
pub mod export;
pub mod noise;
pub mod season;
pub mod weather;
#[cfg(test)]
mod season_tests;
#[cfg(test)]
mod tests;

pub use biome::Biome;
pub use noise::PeriodicNoise;
pub use season::{combine, year_phase, CellNow, ClimateBounds};
pub use weather::{Weather, WeatherError, WeatherState};

use crate::config::{ClimateParams, Config};
use crate::rng::Rng;
use crate::topology::{Cell, TopologyError, Torus};

/// Domain-separation tag XORed into the seed for the climate generator.
pub const CLIMATE_SEED_TAG: u64 = 0xC1A7_E5EE_D000_0006;

/// Folded latitude in degrees (0 = equator, 90 = pole) of row `y`.
pub fn latitude_deg(y: u32, height: u32) -> f64 {
    latitude_deg_f(y as f64, height)
}

/// Continuous latitude at row coordinate `fy` (row centre = integer value);
/// periodic in `fy` with period `height`.
pub fn latitude_deg_f(fy: f64, height: u32) -> f64 {
    // φ = 90·|1 − 2u|, u = (fy + 0.5)/h, written as 90·|h − s|/h with
    // s = (2fy + 1) mod 2h so that rows y and h−1−y give bit-identical values.
    let h = height.max(1) as f64;
    let s = (2.0 * fy + 1.0).rem_euclid(2.0 * h);
    (90.0 * (h - s).abs() / h).clamp(0.0, 90.0)
}

/// Zonal (noise-free) temperature: `T_pole + (T_eq − T_pole)·cos φ`.
pub fn zonal_temperature(p: &ClimateParams, lat_deg: f64) -> f64 {
    p.pole_temperature + (p.equator_temperature - p.pole_temperature) * lat_deg.to_radians().cos()
}

fn gauss(x: f64, m: f64, s: f64) -> f64 {
    let z = (x - m) / s;
    (-z * z).exp()
}

/// Zonal relative precipitation in [0, 1]: wet equator, dry subtropics,
/// mid-latitude storm track around 55°, dry poles.
pub fn zonal_precipitation_rel(lat_deg: f64) -> f64 {
    (0.10 + 0.90 * gauss(lat_deg, 0.0, 15.0) + 0.55 * gauss(lat_deg, 55.0, 15.0)).min(1.0)
}

/// Base climate of one cell.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CellClimate {
    /// Folded latitude in degrees, 0 (equator) … 90 (pole).
    pub latitude: f64,
    /// Base temperature in °C.
    pub temperature: f64,
    /// Base precipitation in [0, climate.max_precipitation].
    pub precipitation: f64,
    pub biome: Biome,
}

/// Base climate of every cell (row-major, index = `Torus::index`).
#[derive(Debug, Clone, PartialEq)]
pub struct ClimateMap {
    width: u32,
    height: u32,
    cells: Vec<CellClimate>,
    noise_t: PeriodicNoise,
    noise_p: PeriodicNoise,
    params: ClimateParams,
}

impl ClimateMap {
    /// Pure function of (world size, climate parameters, seed).
    pub fn generate(torus: &Torus, params: &ClimateParams, seed: u64) -> ClimateMap {
        let (w, h) = (torus.width(), torus.height());
        let mut rng = Rng::seed_from_u64(seed ^ CLIMATE_SEED_TAG);
        let noise_t = PeriodicNoise::new(w, h, params.noise_scale, &mut rng);
        let noise_p = PeriodicNoise::new(w, h, params.noise_scale, &mut rng);
        let mut map =
            ClimateMap { width: w, height: h, cells: Vec::new(), noise_t, noise_p, params: params.clone() };
        let cells: Vec<CellClimate> = torus.cells().map(|c| map.sample(c.x as f64, c.y as f64)).collect();
        map.cells = cells;
        map
    }

    /// Climate of the configured world.
    pub fn from_config(config: &Config) -> Result<ClimateMap, TopologyError> {
        let torus = Torus::new(config.world.width, config.world.height)?;
        Ok(Self::generate(&torus, &config.climate, config.seed))
    }

    /// Continuous evaluation at cell coordinates (cell (x, y) centre = (x, y)),
    /// periodic with periods width and height. Grid values are exactly
    /// `sample(x, y)` at integer points.
    pub fn sample(&self, fx: f64, fy: f64) -> CellClimate {
        let p = &self.params;
        let latitude = latitude_deg_f(fy, self.height);
        let nt = self.noise_t.at_cell(fx, fy, self.width, self.height);
        let np = self.noise_p.at_cell(fx, fy, self.width, self.height);
        let temperature = zonal_temperature(p, latitude) + p.noise_temperature * nt;
        let rel = (zonal_precipitation_rel(latitude) + p.noise_precipitation * np).clamp(0.0, 1.0);
        let precipitation = p.max_precipitation * rel;
        let r = if p.max_precipitation > 0.0 { rel } else { 0.0 };
        CellClimate { latitude, temperature, precipitation, biome: Biome::classify(temperature, r) }
    }

    pub fn width(&self) -> u32 {
        self.width
    }

    pub fn height(&self) -> u32 {
        self.height
    }

    pub fn params(&self) -> &ClimateParams {
        &self.params
    }

    /// Climate of a cell (must be inside the world).
    pub fn get(&self, c: Cell) -> &CellClimate {
        &self.cells[c.y as usize * self.width as usize + c.x as usize]
    }

    pub fn biome(&self, c: Cell) -> Biome {
        self.get(c).biome
    }

    pub fn base_temperature(&self, c: Cell) -> f64 {
        self.get(c).temperature
    }

    pub fn base_precipitation(&self, c: Cell) -> f64 {
        self.get(c).precipitation
    }

    /// All cells, row-major.
    pub fn cells(&self) -> &[CellClimate] {
        &self.cells
    }

    /// Number of cells per biome, indexed by rank.
    pub fn biome_counts(&self) -> [usize; 6] {
        let mut n = [0usize; 6];
        for c in &self.cells {
            n[c.biome.rank() as usize] += 1;
        }
        n
    }

    /// Documented bounds of the current climate for these parameters.
    pub fn bounds(&self) -> ClimateBounds {
        ClimateBounds::from_params(&self.params)
    }

    /// Weather-free seasonal climate of a cell at any tick (deterministic;
    /// equals the simulation's current value when weather is disabled).
    pub fn seasonal(&self, c: Cell, tick: u64) -> CellNow {
        let s = year_phase(tick, self.params.year_length);
        combine(&self.params, &self.bounds(), self.get(c), s, 0.0, 0.0)
    }

    /// Row `y` as a string of biome symbols.
    pub fn row_string(&self, y: u32) -> String {
        let w = self.width as usize;
        self.cells[y as usize * w..(y as usize + 1) * w].iter().map(|c| c.biome.symbol()).collect()
    }
}

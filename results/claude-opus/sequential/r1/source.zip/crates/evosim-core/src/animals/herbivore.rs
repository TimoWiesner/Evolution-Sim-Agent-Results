//! Herbivore turn (TASK-014, ADR-017): stride → metabolism (with climate
//! cost) → decide (flee / rest / forage) with at most one move call → at most
//! one bite within reach → starvation check.

use super::feed::{best_in_reach, best_visible, eat, flee_decision, metabolic_cost, need, satiety, FeedParams, FeedTick, GOOD_ENOUGH};
use super::movement::{move_away, move_towards, steps_allowed, wander, MoveCosts, MoveOutcome, MoveTick};
use super::repro::{find_mate_in_reach, is_ready, visible_mate, ReproParams, MATING_REACH};
use super::sense::vision_radius;
use crate::climate::CellNow;
use crate::config::Config;
use crate::ids::EntityId;
use crate::organism::{DeathCause, Kind, Population};
use crate::rng::Rng;

/// What a herbivore decided this turn (exposed for tests and tools).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HerbivoreAction {
    Flee,
    /// Ready to mate, no partner in reach: moved towards a visible ready mate (ADR-019).
    Court,
    Rest,
    EatHere,
    Approach,
    Wander,
}

/// One herbivore turn result.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct HerbivoreTurn {
    pub action: HerbivoreAction,
    pub moved: MoveOutcome,
    pub bite: super::feed::Bite,
    pub metabolism: f64,
    pub starved: bool,
}

/// Herbivores phase body for the actors `ids` (already in acting order).
/// `now` is the current climate grid (row-major, `width` columns).
pub fn act_herbivores(pop: &mut Population, ids: &[EntityId], cfg: &Config, now: &[CellNow], width: u32, tick: u64, rng: &mut Rng) -> (MoveTick, FeedTick) {
    let mut mt = MoveTick::default();
    let mut ft = FeedTick::default();
    let p = FeedParams::from_config(cfg);
    let costs = MoveCosts::for_kind(Kind::Herbivore, cfg);
    let rp = ReproParams::for_kind(Kind::Herbivore, cfg);
    for &id in ids {
        let Some(t) = herbivore_turn(pop, id, &p, &costs, &rp, now, width, tick, rng) else { continue };
        mt.record(&t.moved);
        ft.record_bite(&t.bite);
        ft.metabolism += t.metabolism;
        ft.starved += t.starved as u64;
        ft.fled += (t.action == HerbivoreAction::Flee) as u64;
        ft.rested += (t.action == HerbivoreAction::Rest) as u64;
    }
    (mt, ft)
}

/// One herbivore's turn; `None` if `id` is not a living herbivore.
#[allow(clippy::too_many_arguments)]
pub fn herbivore_turn(
    pop: &mut Population,
    id: EntityId,
    p: &FeedParams,
    costs: &MoveCosts,
    rp: &ReproParams,
    now: &[CellNow],
    width: u32,
    tick: u64,
    rng: &mut Rng,
) -> Option<HerbivoreTurn> {
    let o = pop.get_alive(id)?;
    if o.kind() != Kind::Herbivore {
        return None;
    }
    // Already at 0 energy or health at the start of the turn (set outside
    // this phase): the animal is dying and is left to the Deaths-phase
    // sweep, which applies the ADR-011 cause precedence (Injury first).
    if o.energy() <= 0.0 || o.health() <= 0.0 {
        return None;
    }
    let (center, traits, stride) = (o.pos(), *o.traits(), o.stride());
    let (allowed, new_stride) = steps_allowed(stride, traits.speed, costs.max_speed);
    let temperature = now.get(center.y as usize * width as usize + center.x as usize).map(|c| c.temperature).unwrap_or(traits.temp_optimum);
    let cost = metabolic_cost(&traits, temperature, p);
    let me = pop.get_alive_mut(id).expect("alive");
    me.set_stride(new_stride);
    let metabolism = me.spend_energy(cost);
    let energy = me.energy();
    let r = vision_radius(&traits);
    let hunger = if traits.max_energy > 0.0 { (1.0 - energy / traits.max_energy).clamp(0.0, 1.0) } else { 1.0 };

    let mut moved = MoveOutcome::stay(center);
    let mut bite = super::feed::Bite::default();
    let action;
    let threat = pop.nearest(center, r, Some(Kind::Carnivore), |_| true);
    let flee = threat.filter(|n| flee_decision(traits.caution, 1.0 - n.distance as f64 / (r as f64 + 1.0), hunger));
    let mate = if flee.is_none() && pop.get_alive(id).is_some_and(|o| is_ready(o, rp)) && find_mate_in_reach(pop, id, rp, &[]).is_none() {
        visible_mate(pop, id, r, rp)
    } else {
        None
    };
    if let Some(n) = flee {
        action = HerbivoreAction::Flee;
        moved = move_away(pop, id, n.cell, allowed, costs);
    } else if let Some(m) = mate {
        action = HerbivoreAction::Court;
        moved = move_towards(pop, id, m.cell, allowed, MATING_REACH, costs);
        if let Some((pid, b, _)) = best_in_reach(pop, id, p) {
            if b > 0.0 {
                bite = eat(pop, id, pid, p, tick);
            }
        }
    } else if energy >= satiety(&traits) {
        action = HerbivoreAction::Rest;
    } else {
        let threshold = GOOD_ENOUGH * p.max_meal.min(need(energy, &traits, p));
        let here = best_in_reach(pop, id, p);
        match here {
            Some((pid, b, _)) if b > 0.0 && b >= threshold => {
                action = HerbivoreAction::EatHere;
                bite = eat(pop, id, pid, p, tick);
            }
            _ => {
                if let Some(target) = best_visible(pop, id, r, threshold, p) {
                    action = HerbivoreAction::Approach;
                    moved = move_towards(pop, id, target.cell, allowed, super::feed::FEED_REACH, costs);
                } else if here.is_some_and(|(_, b, _)| b > 0.0) {
                    action = HerbivoreAction::EatHere;
                } else {
                    action = HerbivoreAction::Wander;
                    moved = wander(pop, id, allowed, costs, rng);
                }
                if let Some((pid, b, _)) = best_in_reach(pop, id, p) {
                    if b > 0.0 {
                        bite = eat(pop, id, pid, p, tick);
                    }
                }
            }
        }
    }
    let starved = pop.get_alive(id).is_some_and(|o| o.energy() <= 0.0) && pop.kill(id, DeathCause::Starvation, tick);
    Some(HerbivoreTurn { action, moved, bite, metabolism, starved })
}

//! HTTP server: static assets + API (ADR-026 §3). One thread per connection.

use crate::http::{self, Request, Response};
use crate::session::{AutotestReport, UiSession};
use crate::control::Command;
use crate::{charts, scenario};
use evosim_core::serde_json::{self, json, Value};
use std::io::BufReader;
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::sync::atomic::Ordering;
use std::thread::JoinHandle;
use std::time::Duration;

pub const INDEX_HTML: &str = include_str!("../web/index.html");
pub const APP_JS: &str = include_str!("../web/app.js");
pub const STYLE_CSS: &str = include_str!("../web/style.css");
pub const CHARTS_JS: &str = include_str!("../web/charts.js");
pub const SETUP_JS: &str = include_str!("../web/setup.js");

pub struct Server {
    addr: SocketAddr,
    session: UiSession,
    handle: Option<JoinHandle<()>>,
}

impl Server {
    /// Bind `127.0.0.1:port` (0 = ephemeral) and start the accept loop.
    pub fn bind(session: UiSession, port: u16) -> std::io::Result<Server> {
        let listener = TcpListener::bind(("127.0.0.1", port))?;
        let addr = listener.local_addr()?;
        let s = session.clone();
        let handle = std::thread::spawn(move || {
            for conn in listener.incoming() {
                if s.shared.stop.load(Ordering::SeqCst) {
                    break;
                }
                if let Ok(stream) = conn {
                    let s2 = s.clone();
                    std::thread::spawn(move || handle_conn(stream, &s2));
                }
            }
        });
        Ok(Server { addr, session, handle: Some(handle) })
    }

    pub fn addr(&self) -> SocketAddr {
        self.addr
    }

    pub fn local_url(&self) -> String {
        format!("http://{}/", self.addr)
    }

    /// Block until the accept loop ends (interactive mode: never, until killed).
    pub fn join(mut self) {
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }

    /// Stop the session and unblock the accept loop.
    pub fn shutdown(mut self) {
        self.session.stop();
        let _ = TcpStream::connect_timeout(&self.addr, Duration::from_secs(1));
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }
}

fn handle_conn(stream: TcpStream, s: &UiSession) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
    let _ = stream.set_nodelay(true);
    let Ok(mut w) = stream.try_clone() else { return };
    let mut r = BufReader::new(stream);
    let resp = match http::parse_request(&mut r) {
        Ok(req) => route(&req, s),
        Err(e) => Response::text(e.status(), "bad request"),
    };
    let _ = http::write_response(&mut w, &resp);
}

/// Route a request (public for tests).
pub fn route(req: &Request, s: &UiSession) -> Response {
    let get = req.method == "GET" || req.method == "HEAD";
    match req.path.as_str() {
        "/" | "/index.html" | "/app.js" | "/style.css" | "/charts.js" | "/setup.js" | "/api/world" | "/api/frame" | "/api/checkpoint"
        | "/api/schema" | "/api/presets" | "/api/config" | "/api/config/download" | "/api/charts" | "/api/histogram"
            if !get => {
            Response::text(405, "method not allowed")
        }
        "/api/control" | "/api/select" | "/api/checkpoint/save" | "/api/checkpoint/load" | "/api/checkpoint/upload"
        | "/api/config/validate" | "/api/new"
            if req.method != "POST" =>
        {
            Response::text(405, "method not allowed")
        }
        "/api/control" | "/api/select" | "/api/checkpoint/save" | "/api/checkpoint/load" => {
            let v = if req.body.iter().all(|b| b.is_ascii_whitespace()) {
                Value::Object(Default::default())
            } else {
                match serde_json::from_slice::<Value>(&req.body) {
                    Ok(v) => v,
                    Err(e) => return error_json(&format!("invalid json: {e}")),
                }
            };
            let mut v = v;
            if !v.is_object() {
                return error_json("body must be a JSON object");
            }
            match req.path.as_str() {
                "/api/select" => {
                    v["cmd"] = Value::from(if v["x"].is_null() && v["id"].is_null() { "deselect" } else { "select" })
                }
                "/api/checkpoint/save" => v["cmd"] = Value::from("save"),
                "/api/checkpoint/load" => v["cmd"] = Value::from("load"),
                _ => {}
            }
            match Command::from_json(&v) {
                Ok(cmd) => command_reply(s, cmd),
                Err(e) => error_json(&e.0),
            }
        }
        "/api/checkpoint/upload" => match String::from_utf8(req.body.clone()) {
            Ok(text) => command_reply(s, Command::LoadText(text)),
            Err(_) => error_json("checkpoint must be UTF-8 JSON"),
        },
        "/api/checkpoint" => match s.checkpoint_text() {
            Ok((tick, text)) => Response::new(200, "application/json", text.into_bytes())
                .with_header("Content-Disposition", &format!("attachment; filename=\"evosim-checkpoint-tick{tick}.json\"")),
            Err(e) => Response::json(500, &json!({"ok": false, "error": e.0})),
        },
        "/api/schema" => Response::json(200, &scenario::schema_json()),
        "/api/presets" => Response::json(200, &scenario::presets_json()),
        "/api/config" => Response::json(200, &s.read_engine(|e| scenario::config_reply(&e.config))),
        "/api/config/download" => {
            let (name, text) = s.read_engine(|e| (e.config.name.clone(), e.config.to_json_pretty()));
            let safe: String = name.chars().map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '-' }).collect();
            Response::new(200, "application/json", text.into_bytes())
                .with_header("Content-Disposition", &format!("attachment; filename=\"evosim-config-{safe}.json\""))
        }
        "/api/config/validate" | "/api/new" => {
            let parsed = match std::str::from_utf8(&req.body) {
                Ok(t) => scenario::validate_text(t),
                Err(_) => Err(vec![scenario::FieldError::new(scenario::DOC_KEY, "configuration must be UTF-8 JSON")]),
            };
            match parsed {
                Err(errs) => Response::json(400, &scenario::errors_json(&errs)),
                Ok(c) if req.path == "/api/config/validate" => Response::json(200, &scenario::config_reply(&c)),
                Ok(c) => {
                    let reply = scenario::config_reply(&c);
                    match s.command(Command::NewWorld(Box::new(c))) {
                        Ok(mut v) => {
                            v["config"] = reply["config"].clone();
                            v["seed_text"] = reply["seed_text"].clone();
                            Response::json(200, &v)
                        }
                        Err(e) => error_json(&e.0),
                    }
                }
            }
        }
        "/api/charts" => {
            let v = charts::query_param(&req.query, "v").and_then(|x| x.parse::<u64>().ok());
            let t = charts::query_param(&req.query, "since").and_then(|x| x.parse::<u64>().ok());
            let since = v.zip(t);
            Response::json(200, &s.read_engine(|e| e.history.to_json(e.epoch, since, Some(charts::ChartPoint::of(&e.sim)))))
        }
        "/api/histogram" => {
            let kind = charts::query_param(&req.query, "kind").unwrap_or_else(|| "herbivores".into());
            let tr = charts::query_param(&req.query, "trait").unwrap_or_else(|| "speed".into());
            let bins = charts::query_param(&req.query, "bins").and_then(|x| x.parse::<usize>().ok()).unwrap_or(20);
            let (Some(k), Some(t)) = (charts::parse_kind(&kind), charts::trait_index(&tr)) else {
                return error_json(&format!("unknown kind '{kind}' or trait '{tr}'"));
            };
            let mut h = s.read_engine(|e| {
                let mut h = charts::histogram(&e.sim, k, t, bins);
                h["epoch"] = e.epoch.into();
                h
            });
            h["bins"] = h["counts"].as_array().map_or(0, |a| a.len()).into();
            Response::json(200, &h)
        }
        "/charts.js" => Response::new(200, "text/javascript; charset=utf-8", CHARTS_JS),
        "/setup.js" => Response::new(200, "text/javascript; charset=utf-8", SETUP_JS),
        "/" | "/index.html" => Response::new(200, "text/html; charset=utf-8", INDEX_HTML),
        "/app.js" => Response::new(200, "text/javascript; charset=utf-8", APP_JS),
        "/style.css" => Response::new(200, "text/css; charset=utf-8", STYLE_CSS),
        "/api/world" => Response::new(200, "application/json", s.world_json().into_bytes()),
        "/api/frame" => Response::new(200, "application/octet-stream", s.latest_frame().to_vec()),
        "/api/autotest/report" => {
            if req.method != "POST" {
                return Response::text(405, "method not allowed");
            }
            let text = String::from_utf8_lossy(&req.body).to_string();
            let Ok(v) = serde_json::from_str::<Value>(&text) else {
                return Response::text(400, "invalid json");
            };
            let rep = AutotestReport {
                mode: v["mode"].as_str().unwrap_or("").to_string(),
                frames: v["frames"].as_u64().unwrap_or(0),
                fps: v["fps"].as_f64().unwrap_or(0.0),
                last_tick: v["last_tick"].as_u64().unwrap_or(0),
                raw: text,
            };
            *s.shared.report.lock().unwrap() = Some(rep);
            Response::text(200, "ok")
        }
        _ => Response::text(404, "not found"),
    }
}

fn error_json(msg: &str) -> Response {
    Response::json(400, &json!({"ok": false, "error": msg}))
}

fn command_reply(s: &UiSession, cmd: Command) -> Response {
    match s.command(cmd) {
        Ok(v) => Response::json(200, &v),
        Err(e) => error_json(&e.0),
    }
}

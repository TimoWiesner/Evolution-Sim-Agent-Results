//! Display-free scenario logic for the "New world" dialog (ADR-028 §2):
//! parameter schema for the form, presets, per-field validation that collects
//! every error, and the config reply used by export / import.

use evosim_core::config::{preset, preset_description, preset_names, schema, Config, ConfigError, ConfigErrorKind, ParamSpec};
use evosim_core::serde_json::{self, json, Map, Value};

/// Parameters shown up front in the dialog (beyond seed, world size and the
/// initial populations). Every other key is in the "Advanced" section.
pub const FEATURED: [&str; 12] = [
    "climate.year_length",
    "climate.equator_temperature",
    "climate.pole_temperature",
    "climate.seasonal_amplitude",
    "climate.weather_enabled",
    "plants.resource_regen",
    "plants.mutation_rate",
    "plants.max_age",
    "herbivores.mutation_rate",
    "herbivores.max_age",
    "carnivores.mutation_rate",
    "hunting.base_success",
];

/// Keys of the "World" section (always shown first).
pub const BASIC: [&str; 6] = ["seed", "world.width", "world.height", "initial.plants", "initial.herbivores", "initial.carnivores"];

/// UI-only guard so a typo cannot freeze the browser (not a contract limit).
pub const MAX_UI_CELLS: u64 = 1_048_576;

/// Key used for errors that concern the whole document / JSON text.
pub const DOC_KEY: &str = "<json>";

#[derive(Debug, Clone, PartialEq)]
pub struct FieldError {
    pub key: String,
    pub message: String,
}

impl FieldError {
    pub fn new(key: impl Into<String>, message: impl Into<String>) -> FieldError {
        FieldError { key: key.into(), message: message.into() }
    }
    pub fn to_json(&self) -> Value {
        json!({"key": self.key, "message": self.message})
    }
}

/// `{ok:false, errors:[...]}`.
pub fn errors_json(errs: &[FieldError]) -> Value {
    json!({"ok": false, "errors": errs.iter().map(FieldError::to_json).collect::<Vec<_>>(),
           "error": errs.iter().map(|e| format!("{}: {}", e.key, e.message)).collect::<Vec<_>>().join("; ")})
}

fn fmt_bound(x: f64) -> String {
    if x.fract() == 0.0 && x.abs() < 1e15 {
        format!("{}", x as i64)
    } else if x >= 1.8e19 {
        "18446744073709551615".into()
    } else {
        format!("{x}")
    }
}

/// Short human message for a core config error (without the key prefix).
pub fn message_of(e: &ConfigError) -> String {
    match &e.kind {
        ConfigErrorKind::Parse { line, column, msg } => format!("invalid JSON at line {line} column {column}: {msg}"),
        ConfigErrorKind::WrongType { expected, found } => format!("expected {expected}, found {found}"),
        ConfigErrorKind::Missing => "required".into(),
        ConfigErrorKind::OutOfRange { min, max, .. } => format!("must be between {} and {}", fmt_bound(*min), fmt_bound(*max)),
        ConfigErrorKind::UnknownKey => "unknown parameter".into(),
        ConfigErrorKind::Invalid { reason } => reason.clone(),
        ConfigErrorKind::UnknownPreset { name, .. } => format!("unknown preset '{name}'"),
    }
}

fn to_field_error(e: &ConfigError) -> FieldError {
    FieldError::new(e.key.clone(), message_of(e))
}

/// Value at a dotted path (`"a.b"`), if present.
pub fn get_path<'a>(v: &'a Value, key: &str) -> Option<&'a Value> {
    key.split('.').try_fold(v, |cur, seg| cur.as_object()?.get(seg))
}

fn set_path(v: &mut Value, key: &str, x: Value) {
    let segs: Vec<&str> = key.split('.').collect();
    let mut cur = v;
    for s in &segs[..segs.len() - 1] {
        if !cur[*s].is_object() {
            cur[*s] = Value::Object(Map::new());
        }
        cur = &mut cur[*s];
    }
    cur[segs[segs.len() - 1]] = x;
}

fn group_of(key: &str) -> &'static str {
    match key.split('.').next().unwrap_or("") {
        "seed" | "world" | "initial" => "World",
        "name" | "description" => "Info",
        "climate" => "Climate",
        "plants" => "Plants",
        "herbivores" => "Herbivores",
        "carnivores" => "Carnivores",
        "hunting" => "Hunting",
        _ => "Other",
    }
}

fn spec_json(p: &ParamSpec) -> Value {
    json!({
        "key": p.key,
        "group": group_of(&p.key),
        "type": p.type_name,
        "default": p.default.clone().unwrap_or(Value::Null),
        "min": if p.key == "seed" { Value::from(0) } else { p.min.map_or(Value::Null, Value::from) },
        "max": if p.key == "seed" { Value::from("18446744073709551615") } else { p.max.map_or(Value::Null, Value::from) },
        "doc": p.doc,
        "required": p.default.is_none(),
        "basic": BASIC.contains(&p.key.as_str()),
        "featured": FEATURED.contains(&p.key.as_str()),
    })
}

/// Form schema: every `config::schema()` entry + UI flags.
pub fn schema_json() -> Value {
    json!({"params": schema().iter().map(spec_json).collect::<Vec<_>>(), "featured": FEATURED, "basic": BASIC, "max_cells": MAX_UI_CELLS})
}

/// `{config, seed_text}`: seeds above 2^53 survive JavaScript via `seed_text`.
pub fn config_reply(c: &Config) -> Value {
    json!({"ok": true, "config": c.to_json_value(), "seed_text": c.seed.to_string(), "text": c.to_json_pretty()})
}

/// Built-in presets with description and full config.
pub fn presets_json() -> Value {
    let list: Vec<Value> = preset_names()
        .into_iter()
        .filter_map(|n| {
            let c = preset(n).ok()?;
            let mut v = config_reply(&c);
            v["name"] = json!(n);
            v["description"] = json!(preset_description(n).unwrap_or(""));
            v.as_object_mut()?.remove("text");
            v.as_object_mut()?.remove("ok");
            Some(v)
        })
        .collect();
    json!({"presets": list})
}

/// Validate a form / imported document. Per-field pass first (all errors at
/// once), then the core validator (unknown keys, cross-field rules), then the
/// UI cell guard.
pub fn validate_form(v: &Value) -> Result<Config, Vec<FieldError>> {
    if !v.is_object() {
        return Err(vec![FieldError::new(DOC_KEY, "configuration must be a JSON object")]);
    }
    let base = Config::contract_example().to_json_value();
    let mut errs = Vec::new();
    for spec in schema() {
        match get_path(v, &spec.key) {
            None if spec.default.is_none() => errs.push(FieldError::new(spec.key.clone(), "required")),
            None => {}
            Some(x) => {
                // check this single value with the core rules on an otherwise valid document
                let mut probe = base.clone();
                set_path(&mut probe, &spec.key, x.clone());
                if let Err(e) = Config::from_value(&probe) {
                    if e.key == spec.key && !matches!(e.kind, ConfigErrorKind::Invalid { .. }) {
                        errs.push(to_field_error(&e));
                    }
                }
            }
        }
    }
    if !errs.is_empty() {
        return Err(errs);
    }
    let c = Config::from_value(v).map_err(|e| vec![to_field_error(&e)])?;
    if u64::from(c.world.width) * u64::from(c.world.height) > MAX_UI_CELLS {
        return Err(vec![FieldError::new("world.width", format!("world too large for the UI (width × height must be at most {MAX_UI_CELLS} cells)"))]);
    }
    Ok(c)
}

/// Validate JSON text (import of an exported file).
pub fn validate_text(text: &str) -> Result<Config, Vec<FieldError>> {
    let v: Value = serde_json::from_str(text)
        .map_err(|e| vec![FieldError::new(DOC_KEY, format!("invalid JSON at line {} column {}: {e}", e.line(), e.column()))])?;
    validate_form(&v)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn keys(e: &[FieldError]) -> Vec<&str> {
        e.iter().map(|x| x.key.as_str()).collect()
    }

    #[test]
    fn presets_roundtrip() {
        let p = presets_json();
        let list = p["presets"].as_array().unwrap();
        assert!(list.len() >= 4);
        for e in list {
            let name = e["name"].as_str().unwrap();
            let c = preset(name).unwrap();
            assert_eq!(validate_form(&e["config"]).unwrap(), c, "{name}");
            assert_eq!(e["seed_text"], c.seed.to_string());
            assert!(!e["description"].as_str().unwrap().is_empty());
        }
    }

    #[test]
    fn export_import_identical() {
        for seed in [0u64, 42, (1 << 53) + 1, u64::MAX] {
            let mut c = preset("lush").unwrap();
            c.seed = seed;
            c.world.width = 80;
            c.world.height = 50;
            c.initial.plants = 777;
            c.initial.herbivores = 99;
            c.initial.carnivores = 11;
            c.climate.year_length = 321;
            c.climate.seasonal_amplitude = 7.5;
            c.climate.weather_enabled = !c.climate.weather_enabled;
            c.plants.mutation_rate = 0.123;
            c.herbivores.max_age = 1234;
            c.hunting.base_success = 0.31;
            let text = c.to_json_pretty();
            let back = validate_text(&text).unwrap();
            assert_eq!(back, c);
            assert_eq!(back.to_json_pretty(), text);
            assert_eq!(config_reply(&back)["seed_text"], seed.to_string());
        }
    }

    #[test]
    fn collects_all_field_errors() {
        let mut v = Config::contract_example().to_json_value();
        v["world"]["width"] = json!(0);
        v["initial"]["plants"] = json!(-1);
        v["plants"]["mutation_rate"] = json!(2.0);
        v["climate"]["year_length"] = json!("x");
        let e = validate_form(&v).unwrap_err();
        assert_eq!(keys(&e), vec!["world.width", "initial.plants", "climate.year_length", "plants.mutation_rate"]);
        assert!(e[0].message.contains("between 1 and 4096"), "{}", e[0].message);
        assert!(e[2].message.contains("expected integer"), "{}", e[2].message);

        let mut v = Config::contract_example().to_json_value();
        v.as_object_mut().unwrap().remove("seed");
        assert_eq!(keys(&validate_form(&v).unwrap_err()), vec!["seed"]);

        let mut v = Config::contract_example().to_json_value();
        v["plants"]["bogus"] = json!(1);
        assert_eq!(keys(&validate_form(&v).unwrap_err()), vec!["plants.bogus"]);

        let mut v = Config::contract_example().to_json_value();
        v["climate"]["pole_temperature"] = json!(40.0);
        v["climate"]["equator_temperature"] = json!(10.0);
        let e = validate_form(&v).unwrap_err();
        assert_eq!(keys(&e), vec!["climate.pole_temperature"]);

        let mut v = Config::contract_example().to_json_value();
        v["world"]["width"] = json!(4096);
        v["world"]["height"] = json!(4096);
        let e = validate_form(&v).unwrap_err();
        assert_eq!(keys(&e), vec!["world.width"]);
        assert!(e[0].message.contains("too large"));

        assert_eq!(keys(&validate_form(&json!([1])).unwrap_err()), vec![DOC_KEY]);
        assert_eq!(keys(&validate_text("{nope").unwrap_err()), vec![DOC_KEY]);
        // seed accepts the full u64 range, rejects negative and fractional values
        let mut v = Config::contract_example().to_json_value();
        v["seed"] = json!(u64::MAX);
        assert_eq!(validate_form(&v).unwrap().seed, u64::MAX);
        v["seed"] = json!(-3);
        assert_eq!(keys(&validate_form(&v).unwrap_err()), vec!["seed"]);
        v["seed"] = json!(1.5);
        assert_eq!(keys(&validate_form(&v).unwrap_err()), vec!["seed"]);
    }

    #[test]
    fn schema_json_marks_featured() {
        let s = schema_json();
        let params = s["params"].as_array().unwrap();
        let all: Vec<&str> = params.iter().map(|p| p["key"].as_str().unwrap()).collect();
        for k in FEATURED.iter().chain(BASIC.iter()) {
            assert!(all.contains(k), "{k} not in schema");
        }
        let featured: Vec<&Value> = params.iter().filter(|p| p["featured"] == true).collect();
        assert!(featured.len() >= 5);
        assert!(featured.iter().all(|p| p["required"] == false && !p["default"].is_null()));
        assert_eq!(params.iter().filter(|p| p["basic"] == true).count(), 6);
        assert_eq!(params.iter().find(|p| p["key"] == "seed").unwrap()["max"], "18446744073709551615");
        assert!(params.iter().all(|p| p["group"] != "Other"));
    }
}

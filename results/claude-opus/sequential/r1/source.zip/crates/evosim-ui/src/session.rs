//! UI session: owns the [`Engine`] (`Simulation::new` + `step`, exactly as the
//! CLI) and a sim thread that publishes frames (ADR-026 §2, ADR-027 §4).

use crate::control::{Command, ControlError, Engine};
use crate::frame;
use evosim_core::config::Config;
use evosim_core::serde_json::Value;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

/// Report POSTed by the page in automation modes.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct AutotestReport {
    pub mode: String,
    pub frames: u64,
    pub fps: f64,
    pub last_tick: u64,
    pub raw: String,
}

pub struct Shared {
    /// Simulation + all control state. HTTP commands and the sim thread lock
    /// it in turn, so commands are applied between ticks.
    pub engine: Mutex<Engine>,
    /// `(epoch, /api/world JSON)`; rebuilt when Reset/Load replace the world.
    pub world_json: Mutex<(u64, String)>,
    pub frame: Mutex<Arc<Vec<u8>>>,
    pub stop: AtomicBool,
    /// Run unthrottled until this tick (automation).
    pub fast_until: AtomicU64,
    pub tick: AtomicU64,
    /// Measured ticks/s × 10 (for frame meta built by command handlers).
    pub tps10: AtomicU64,
    /// Command handlers waiting for the engine lock (sim thread backs off).
    pub pending: AtomicU32,
    pub report: Mutex<Option<AutotestReport>>,
}

#[derive(Clone)]
pub struct UiSession {
    pub shared: Arc<Shared>,
}

pub const DEFAULT_TPS: u64 = 20;

impl UiSession {
    /// New session; the simulation starts running (as in TASK-023).
    pub fn new(config: Config) -> Result<UiSession, String> {
        let mut engine = Engine::new(config).map_err(|e| e.to_string())?;
        engine.running = true;
        Ok(Self::from_engine(engine))
    }

    pub fn from_engine(engine: Engine) -> UiSession {
        let world_json = frame::world_json(&engine.sim);
        let first = Arc::new(frame::encode_engine_frame(&engine, 0.0));
        let tick = engine.tick();
        let epoch = engine.epoch;
        UiSession {
            shared: Arc::new(Shared {
                engine: Mutex::new(engine),
                world_json: Mutex::new((epoch, world_json)),
                frame: Mutex::new(first),
                stop: AtomicBool::new(false),
                fast_until: AtomicU64::new(0),
                tick: AtomicU64::new(tick),
                tps10: AtomicU64::new(0),
                pending: AtomicU32::new(0),
                report: Mutex::new(None),
            }),
        }
    }

    pub fn latest_frame(&self) -> Arc<Vec<u8>> {
        self.shared.frame.lock().unwrap().clone()
    }

    pub fn world_json(&self) -> String {
        self.shared.world_json.lock().unwrap().1.clone()
    }

    pub fn tick(&self) -> u64 {
        self.shared.tick.load(Ordering::SeqCst)
    }

    pub fn set_fast_until(&self, t: u64) {
        self.shared.fast_until.store(t, Ordering::SeqCst);
    }

    pub fn stop(&self) {
        self.shared.stop.store(true, Ordering::SeqCst);
    }

    /// Run `f` with the engine locked (commands, tests, automation).
    pub fn with_engine<R>(&self, f: impl FnOnce(&mut Engine) -> R) -> R {
        self.shared.pending.fetch_add(1, Ordering::SeqCst);
        let mut e = self.shared.engine.lock().unwrap();
        self.shared.pending.fetch_sub(1, Ordering::SeqCst);
        let r = f(&mut e);
        self.publish(&e);
        r
    }

    /// Run `f` with the engine locked, without publishing a frame (read-only
    /// queries such as chart data).
    pub fn read_engine<R>(&self, f: impl FnOnce(&Engine) -> R) -> R {
        self.shared.pending.fetch_add(1, Ordering::SeqCst);
        let e = self.shared.engine.lock().unwrap();
        self.shared.pending.fetch_sub(1, Ordering::SeqCst);
        f(&e)
    }

    /// Apply a control command and publish a fresh frame at once.
    pub fn command(&self, cmd: Command) -> Result<Value, ControlError> {
        self.with_engine(|e| e.apply(cmd))
    }

    /// Checkpoint text of the current state.
    pub fn checkpoint_text(&self) -> Result<(u64, String), ControlError> {
        self.with_engine(|e| e.checkpoint_text().map(|t| (e.tick(), t)))
    }

    fn publish(&self, e: &Engine) {
        publish(&self.shared, e, self.shared.tps10.load(Ordering::SeqCst) as f64 / 10.0);
    }

    /// Start the sim thread. Steps at the engine's speed level (unthrottled
    /// below `fast_until`); publishes a frame at most every 33 ms and always
    /// when pacing.
    pub fn spawn_sim_thread(&self) -> JoinHandle<()> {
        let sh = self.shared.clone();
        std::thread::spawn(move || {
            let mut last_publish = Instant::now() - Duration::from_secs(1);
            let mut window_start = Instant::now();
            let mut window_ticks = 0u64;
            let mut tps = 0.0;
            let mut next_due = Instant::now();
            while !sh.stop.load(Ordering::SeqCst) {
                if sh.pending.load(Ordering::SeqCst) > 0 {
                    std::thread::sleep(Duration::from_micros(200));
                    continue;
                }
                let mut e = sh.engine.lock().unwrap();
                let tick = e.tick();
                let fast = tick < sh.fast_until.load(Ordering::SeqCst);
                if !e.running {
                    drop(e);
                    tps = 0.0;
                    sh.tps10.store(0, Ordering::SeqCst);
                    window_ticks = 0;
                    window_start = Instant::now();
                    std::thread::sleep(Duration::from_millis(20));
                    next_due = Instant::now();
                    continue;
                }
                let target = if fast { None } else { e.pace() };
                if let Some(target) = target {
                    let now = Instant::now();
                    if now < next_due {
                        drop(e);
                        std::thread::sleep((next_due - now).min(Duration::from_millis(20)));
                        continue;
                    }
                    next_due = next_due.max(now - Duration::from_millis(200)) + Duration::from_secs_f64(1.0 / f64::from(target));
                }
                e.step_tick();
                window_ticks += 1;
                let el = window_start.elapsed().as_secs_f64();
                if el >= 0.5 {
                    tps = window_ticks as f64 / el;
                    sh.tps10.store((tps * 10.0).round() as u64, Ordering::SeqCst);
                    window_ticks = 0;
                    window_start = Instant::now();
                }
                sh.tick.store(e.tick(), Ordering::SeqCst);
                if last_publish.elapsed() >= Duration::from_millis(33) || target.is_some() {
                    publish(&sh, &e, tps);
                    last_publish = Instant::now();
                }
                drop(e);
                if target.is_none() {
                    std::thread::yield_now();
                }
            }
        })
    }
}

/// Encode and store the frame of `e` (and the world JSON if the epoch changed).
fn publish(sh: &Shared, e: &Engine, tps: f64) {
    {
        let mut w = sh.world_json.lock().unwrap();
        if w.0 != e.epoch {
            *w = (e.epoch, frame::world_json(&e.sim));
        }
    }
    sh.tick.store(e.tick(), Ordering::SeqCst);
    let f = Arc::new(frame::encode_engine_frame(e, tps));
    *sh.frame.lock().unwrap() = f;
}

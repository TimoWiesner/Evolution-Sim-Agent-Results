//! Minimal std-only HTTP/1.1 subset (ADR-026 §1): request line, headers,
//! `Content-Length` body, always `Connection: close`.

use std::io::{BufRead, Read, Write};

pub const MAX_HEADER: usize = 16 * 1024;
pub const MAX_BODY: usize = 1024 * 1024;
/// Body limit of `POST /api/checkpoint/upload` (checkpoints can be large).
pub const MAX_UPLOAD: usize = 256 * 1024 * 1024;

/// Body limit by path (ADR-027 §5).
pub fn body_limit(path: &str) -> usize {
    if path == "/api/checkpoint/upload" {
        MAX_UPLOAD
    } else {
        MAX_BODY
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Request {
    pub method: String,
    pub path: String,
    pub query: String,
    pub body: Vec<u8>,
}

#[derive(Debug, Clone, PartialEq)]
pub enum HttpError {
    BadRequest(String),
    TooLarge,
    Io(String),
}

impl HttpError {
    pub fn status(&self) -> u16 {
        match self {
            HttpError::BadRequest(_) | HttpError::Io(_) => 400,
            HttpError::TooLarge => 413,
        }
    }
}

/// Parse one request from `r` with the per-path [`body_limit`].
pub fn parse_request(r: &mut impl BufRead) -> Result<Request, HttpError> {
    parse_request_with_limit(r, body_limit)
}

/// Parse one request; `limit(path)` is the maximum body size for that path.
pub fn parse_request_with_limit(r: &mut impl BufRead, limit: impl Fn(&str) -> usize) -> Result<Request, HttpError> {
    let mut header_bytes = 0usize;
    let mut line = String::new();
    let mut read_line = |r: &mut dyn BufRead, line: &mut String| -> Result<(), HttpError> {
        line.clear();
        let n = r.take((MAX_HEADER + 1) as u64).read_line(line).map_err(|e| HttpError::Io(e.to_string()))?;
        header_bytes += n;
        if header_bytes > MAX_HEADER {
            return Err(HttpError::TooLarge);
        }
        if n == 0 {
            return Err(HttpError::BadRequest("unexpected end of request".into()));
        }
        Ok(())
    };
    read_line(r, &mut line)?;
    let mut parts = line.split_whitespace();
    let (Some(method), Some(target), Some(version)) = (parts.next(), parts.next(), parts.next()) else {
        return Err(HttpError::BadRequest("malformed request line".into()));
    };
    if !version.starts_with("HTTP/1.") || !target.starts_with('/') {
        return Err(HttpError::BadRequest("unsupported request line".into()));
    }
    let method = method.to_string();
    let (path, query) = match target.split_once('?') {
        Some((p, q)) => (p.to_string(), q.to_string()),
        None => (target.to_string(), String::new()),
    };
    let mut content_length = 0usize;
    loop {
        read_line(r, &mut line)?;
        let l = line.trim_end_matches(['\r', '\n']);
        if l.is_empty() {
            break;
        }
        let Some((k, v)) = l.split_once(':') else {
            return Err(HttpError::BadRequest("malformed header".into()));
        };
        if k.trim().eq_ignore_ascii_case("content-length") {
            content_length =
                v.trim().parse().map_err(|_| HttpError::BadRequest("bad Content-Length".into()))?;
        }
    }
    if content_length > limit(&path) {
        return Err(HttpError::TooLarge);
    }
    let mut body = vec![0u8; content_length];
    r.read_exact(&mut body).map_err(|e| HttpError::Io(e.to_string()))?;
    Ok(Request { method, path, query, body })
}

/// Value of `key` in a `a=1&b=2` query string.
pub fn query_param<'a>(query: &'a str, key: &str) -> Option<&'a str> {
    query.split('&').find_map(|kv| {
        let (k, v) = kv.split_once('=').unwrap_or((kv, ""));
        (k == key).then_some(v)
    })
}

#[derive(Debug, Clone)]
pub struct Response {
    pub status: u16,
    pub content_type: &'static str,
    pub body: Vec<u8>,
    /// Extra headers (e.g. `Content-Disposition`).
    pub headers: Vec<(String, String)>,
}

impl Response {
    pub fn new(status: u16, content_type: &'static str, body: impl Into<Vec<u8>>) -> Self {
        Response { status, content_type, body: body.into(), headers: Vec::new() }
    }
    pub fn json(status: u16, v: &evosim_core::serde_json::Value) -> Self {
        Self::new(status, "application/json", v.to_string().into_bytes())
    }
    pub fn with_header(mut self, k: &str, v: &str) -> Self {
        self.headers.push((k.to_string(), v.to_string()));
        self
    }
    pub fn text(status: u16, s: &str) -> Self {
        Self::new(status, "text/plain; charset=utf-8", s.as_bytes().to_vec())
    }
}

fn reason(status: u16) -> &'static str {
    match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        405 => "Method Not Allowed",
        413 => "Payload Too Large",
        _ => "Internal Server Error",
    }
}

pub fn write_response(w: &mut impl Write, resp: &Response) -> std::io::Result<()> {
    write!(
        w,
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n",
        resp.status,
        reason(resp.status),
        resp.content_type,
        resp.body.len()
    )?;
    for (k, v) in &resp.headers {
        write!(w, "{k}: {v}\r\n")?;
    }
    w.write_all(b"\r\n")?;
    w.write_all(&resp.body)?;
    w.flush()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[test]
    fn get_with_query() {
        let mut c = Cursor::new(b"GET /api/frame?x=1&autotest=smoke HTTP/1.1\r\nHost: a\r\n\r\n".to_vec());
        let r = parse_request(&mut c).unwrap();
        assert_eq!(r.method, "GET");
        assert_eq!(r.path, "/api/frame");
        assert_eq!(query_param(&r.query, "autotest"), Some("smoke"));
        assert_eq!(query_param(&r.query, "y"), None);
        assert!(r.body.is_empty());
    }

    #[test]
    fn post_with_body() {
        let mut c = Cursor::new(b"POST /r HTTP/1.1\r\ncontent-length: 5\r\n\r\nhello".to_vec());
        let r = parse_request(&mut c).unwrap();
        assert_eq!(r.method, "POST");
        assert_eq!(r.body, b"hello");
    }

    #[test]
    fn malformed_is_400() {
        for raw in [&b"garbage\r\n\r\n"[..], b"GET / HTTP/1.1\r\nnocolon\r\n\r\n", b"", b"GET x HTTP/1.1\r\n\r\n"] {
            let e = parse_request(&mut Cursor::new(raw.to_vec())).unwrap_err();
            assert_eq!(e.status(), 400, "{raw:?}");
        }
    }

    #[test]
    fn oversize_is_413() {
        let raw = format!("POST / HTTP/1.1\r\nContent-Length: {}\r\n\r\n", MAX_BODY + 1);
        assert_eq!(parse_request(&mut Cursor::new(raw.into_bytes())).unwrap_err(), HttpError::TooLarge);
        let raw = format!("GET / HTTP/1.1\r\nX: {}\r\n\r\n", "a".repeat(MAX_HEADER + 10));
        assert_eq!(parse_request(&mut Cursor::new(raw.into_bytes())).unwrap_err(), HttpError::TooLarge);
    }

    #[test]
    fn upload_route_has_larger_limit() {
        let n = MAX_BODY + 10;
        let mut raw = format!("POST /api/checkpoint/upload HTTP/1.1\r\nContent-Length: {n}\r\n\r\n").into_bytes();
        raw.extend(std::iter::repeat_n(b'a', n));
        assert_eq!(parse_request(&mut Cursor::new(raw)).unwrap().body.len(), n);
        let raw = format!("POST /api/control HTTP/1.1\r\nContent-Length: {n}\r\n\r\n");
        assert_eq!(parse_request(&mut Cursor::new(raw.into_bytes())).unwrap_err(), HttpError::TooLarge);
    }

    #[test]
    fn extra_headers_written() {
        let mut v = Vec::new();
        write_response(&mut v, &Response::text(200, "x").with_header("Content-Disposition", "attachment")).unwrap();
        let s = String::from_utf8(v).unwrap();
        assert!(s.contains("\r\nContent-Disposition: attachment\r\n\r\nx"));
    }

    #[test]
    fn response_format() {
        let mut v = Vec::new();
        write_response(&mut v, &Response::text(404, "nope")).unwrap();
        let s = String::from_utf8(v).unwrap();
        assert!(s.starts_with("HTTP/1.1 404 Not Found\r\n"));
        assert!(s.contains("Content-Length: 4\r\n"));
        assert!(s.ends_with("\r\n\r\nnope"));
    }
}

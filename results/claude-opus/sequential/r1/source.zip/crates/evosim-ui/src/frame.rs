//! World description and binary frame encoding (protocol v1, ADR-026 §3).

use evosim_core::climate::biome::Biome;
use evosim_core::climate::season::year_phase;
use evosim_core::organism::Kind;
use crate::control::Engine;
use evosim_core::serde_json::{json, Value};
use evosim_core::sim::Simulation;
use evosim_core::topology::Cell;

pub const PROTOCOL: u32 = 1;
pub const MAGIC: &[u8; 4] = b"EVF1";
pub const RECORD_BYTES: usize = 6;

const B64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/// Standard base64 (RFC 4648, with padding).
pub fn base64_encode(data: &[u8]) -> String {
    let mut s = String::with_capacity(data.len().div_ceil(3) * 4);
    for ch in data.chunks(3) {
        let b = [ch[0], *ch.get(1).unwrap_or(&0), *ch.get(2).unwrap_or(&0)];
        let n = (u32::from(b[0]) << 16) | (u32::from(b[1]) << 8) | u32::from(b[2]);
        for i in 0..4 {
            if i <= ch.len() {
                s.push(B64[((n >> (18 - 6 * i)) & 63) as usize] as char);
            } else {
                s.push('=');
            }
        }
    }
    s
}

pub fn biome_id(b: Biome) -> u8 {
    Biome::ALL.iter().position(|x| *x == b).unwrap_or(0) as u8
}

/// Row-major biome ids of every cell.
pub fn biome_grid(sim: &Simulation) -> Vec<u8> {
    let w = sim.config().world.width;
    let h = sim.config().world.height;
    let cm = sim.world().climate();
    let mut v = Vec::with_capacity((w * h) as usize);
    for y in 0..h {
        for x in 0..w {
            v.push(biome_id(cm.biome(Cell { x, y })));
        }
    }
    v
}

/// `GET /api/world` JSON.
pub fn world_json(sim: &Simulation) -> String {
    let c = sim.config();
    let biomes: Vec<_> = Biome::ALL
        .iter()
        .map(|b| {
            json!({"id": biome_id(*b), "name": b.name(), "symbol": b.symbol().to_string(),
                   "rgb": b.rgb(), "rule": b.rule()})
        })
        .collect();
    json!({
        "protocol": PROTOCOL,
        "width": c.world.width,
        "height": c.world.height,
        "seed": c.seed,
        "seed_text": c.seed.to_string(),
        "name": c.name,
        "year_length": c.climate.year_length,
        "biomes": biomes,
        "cells": base64_encode(&biome_grid(sim)),
    })
    .to_string()
}

pub fn kind_code(k: Kind) -> u8 {
    match k {
        Kind::Plant => 0,
        Kind::Herbivore => 1,
        Kind::Carnivore => 2,
    }
}

/// Binary frame: "EVF1", u32 LE json_len, JSON meta, 6-byte organism records.
pub fn encode_frame(sim: &Simulation, running: bool, tps: f64) -> Vec<u8> {
    encode_with_meta(sim, running, tps, None)
}

/// Frame of a controlled engine: meta adds `epoch`, `speed`, `selected` (ADR-027 §5).
pub fn encode_engine_frame(e: &Engine, tps: f64) -> Vec<u8> {
    let extra = json!({"epoch": e.epoch, "speed": e.speed_json(), "selected": e.inspector_json(), "charts_version": e.history.version});
    encode_with_meta(&e.sim, e.running, tps, Some(extra))
}

fn encode_with_meta(sim: &Simulation, running: bool, tps: f64, extra: Option<Value>) -> Vec<u8> {
    let pop = sim.organisms();
    let counts = |k| pop.count_alive(k);
    let mut meta = json!({
        "tick": sim.tick(),
        "counts": {"plants": counts(Kind::Plant), "herbivores": counts(Kind::Herbivore), "carnivores": counts(Kind::Carnivore)},
        "species": {"plants": sim.living_species(Kind::Plant), "herbivores": sim.living_species(Kind::Herbivore), "carnivores": sim.living_species(Kind::Carnivore)},
        "season_phase": year_phase(sim.tick(), sim.config().climate.year_length),
        "running": running,
        "tps": (tps * 10.0).round() / 10.0,
    });
    if let (Some(Value::Object(x)), Some(m)) = (extra, meta.as_object_mut()) {
        m.extend(x);
    }
    let meta = meta.to_string();
    let n: usize = Kind::ALL.iter().map(|k| counts(*k)).sum();
    let mut v = Vec::with_capacity(8 + meta.len() + n * RECORD_BYTES);
    v.extend_from_slice(MAGIC);
    v.extend_from_slice(&(meta.len() as u32).to_le_bytes());
    v.extend_from_slice(meta.as_bytes());
    for k in Kind::ALL {
        for o in pop.alive(k) {
            let p = o.pos();
            v.extend_from_slice(&(p.x as u16).to_le_bytes());
            v.extend_from_slice(&(p.y as u16).to_le_bytes());
            v.push(kind_code(k));
            let max = o.traits().max_energy.max(1e-9);
            v.push(((o.energy() / max).clamp(0.0, 1.0) * 255.0).round() as u8);
        }
    }
    v
}

/// One decoded organism record: x, y, kind code, energy fraction 0–255.
pub type Record = (u16, u16, u8, u8);

/// Decode a frame (tests and tools): meta JSON text and records.
pub fn decode_frame(b: &[u8]) -> Option<(String, Vec<Record>)> {
    if b.len() < 8 || &b[0..4] != MAGIC {
        return None;
    }
    let len = u32::from_le_bytes(b[4..8].try_into().ok()?) as usize;
    let meta = String::from_utf8(b.get(8..8 + len)?.to_vec()).ok()?;
    let rest = &b[8 + len..];
    if !rest.len().is_multiple_of(RECORD_BYTES) {
        return None;
    }
    let recs = rest
        .chunks(RECORD_BYTES)
        .map(|r| (u16::from_le_bytes([r[0], r[1]]), u16::from_le_bytes([r[2], r[3]]), r[4], r[5]))
        .collect();
    Some((meta, recs))
}

#[cfg(test)]
mod tests {
    use super::*;
    use evosim_core::config::Config;

    #[test]
    fn base64_rfc4648_vectors() {
        for (i, o) in [("", ""), ("f", "Zg=="), ("fo", "Zm8="), ("foo", "Zm9v"), ("foob", "Zm9vYg=="), ("fooba", "Zm9vYmE="), ("foobar", "Zm9vYmFy")] {
            assert_eq!(base64_encode(i.as_bytes()), o);
        }
    }

    #[test]
    fn frame_matches_population() {
        let mut sim = Simulation::new(Config::contract_example()).unwrap();
        sim.run(5);
        let f = encode_frame(&sim, true, 20.0);
        let (meta, recs) = decode_frame(&f).unwrap();
        let m: Value = evosim_core::serde_json::from_str(&meta).unwrap();
        assert_eq!(m["tick"], 5);
        let total: usize = Kind::ALL.iter().map(|k| sim.organisms().count_alive(*k)).sum();
        assert_eq!(recs.len(), total);
        assert_eq!(m["counts"]["plants"].as_u64().unwrap() as usize, sim.organisms().count_alive(Kind::Plant));
        let expected: Vec<(u16, u16, u8)> = Kind::ALL
            .iter()
            .flat_map(|k| sim.organisms().alive(*k).map(|o| (o.pos().x as u16, o.pos().y as u16, kind_code(*k))).collect::<Vec<_>>())
            .collect();
        let got: Vec<(u16, u16, u8)> = recs.iter().map(|r| (r.0, r.1, r.2)).collect();
        assert_eq!(got, expected);
    }

    #[test]
    fn world_json_grid() {
        let sim = Simulation::new(Config::contract_example()).unwrap();
        let v: Value = evosim_core::serde_json::from_str(&world_json(&sim)).unwrap();
        assert_eq!(v["width"], 64);
        assert_eq!(v["biomes"].as_array().unwrap().len(), 6);
        let cells = v["cells"].as_str().unwrap();
        assert_eq!(cells.len(), (64 * 48usize).div_ceil(3) * 4);
        assert!(biome_grid(&sim).iter().all(|b| *b < 6));
    }

    #[test]
    fn engine_frame_meta() {
        let mut e = Engine::new(Config::contract_example()).unwrap();
        e.step_tick();
        let (meta, _) = decode_frame(&encode_engine_frame(&e, 3.0)).unwrap();
        let m: Value = evosim_core::serde_json::from_str(&meta).unwrap();
        assert_eq!(m["tick"], 1);
        assert_eq!(m["running"], false);
        assert_eq!(m["epoch"], 0);
        assert_eq!(m["speed"]["index"], crate::control::DEFAULT_SPEED);
        assert!(m["selected"].is_null());
        assert!(m["counts"]["plants"].is_u64());
    }

    #[test]
    fn decode_rejects_garbage() {
        assert!(decode_frame(b"XXXX\0\0\0\0").is_none());
        assert!(decode_frame(b"EV").is_none());
    }
}

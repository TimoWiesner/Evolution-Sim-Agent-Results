//! Local browser UI for Evolution Simulation (ADR-002, ADR-026).
//!
//! `evosim ui` serves a Canvas world view from a std-only HTTP server; one sim
//! thread drives the same engine (`Simulation::new` + `step`) as `evosim run`.
//! Dependency direction: `evosim-ui -> evosim-core` only.

pub mod automation;
pub mod charts;
pub mod control;
pub mod frame;
pub mod http;
pub mod scenario;
pub mod server;
pub mod session;

use evosim_core::config::Config;
use std::io::Write;
use std::path::PathBuf;

pub const DEFAULT_PORT: u16 = 8765;

/// Whether the UI is implemented in this build.
pub fn available() -> bool {
    true
}

/// Name of the product this UI belongs to (proves the core dependency).
pub fn product_name() -> &'static str {
    evosim_core::NAME
}

#[derive(Debug, Clone, PartialEq)]
pub enum UiMode {
    Interactive { port: u16 },
    Smoke,
    Screenshots(PathBuf),
}

pub struct UiOptions {
    pub config: Config,
    pub mode: UiMode,
}

/// Run the UI. Returns 0 on success, 1 on automation failure, 2 on usage errors.
pub fn run(opts: UiOptions, out: &mut impl Write, err: &mut impl Write) -> u8 {
    match opts.mode {
        UiMode::Smoke => match automation::smoke_test(opts.config) {
            Ok(s) => {
                let _ = writeln!(
                    out,
                    "{{\"smoke\":\"ok\",\"ticks\":{},\"frames\":{},\"fps\":{:.1},\"elapsed_s\":{:.1}}}",
                    s.ticks, s.report.frames, s.report.fps, s.elapsed_s
                );
                0
            }
            Err(e) => {
                let _ = writeln!(err, "error: ui smoke test failed: {e}");
                1
            }
        },
        UiMode::Screenshots(dir) => {
            if !dir.is_dir() {
                let _ = writeln!(err, "error: --screenshots directory '{}' does not exist", dir.display());
                return 2;
            }
            match automation::screenshots(opts.config, &dir) {
                Ok(files) => {
                    for f in files {
                        let _ = writeln!(err, "wrote {}", f.display());
                    }
                    0
                }
                Err(e) => {
                    let _ = writeln!(err, "error: ui screenshots failed: {e}");
                    1
                }
            }
        }
        UiMode::Interactive { port } => {
            let session = match session::UiSession::new(opts.config) {
                Ok(s) => s,
                Err(e) => {
                    let _ = writeln!(err, "error: {e}");
                    return 2;
                }
            };
            let server = match server::Server::bind(session.clone(), port) {
                Ok(s) => s,
                Err(_) if port == DEFAULT_PORT => match server::Server::bind(session.clone(), 0) {
                    Ok(s) => s,
                    Err(e) => {
                        let _ = writeln!(err, "error: cannot start local server: {e}");
                        return 1;
                    }
                },
                Err(e) => {
                    let _ = writeln!(err, "error: cannot listen on 127.0.0.1:{port}: {e}");
                    return 2;
                }
            };
            let _sim = session.spawn_sim_thread();
            let _ = writeln!(out, "Evolution Simulation UI: {}  (open in a browser; Ctrl+C to quit)", server.local_url());
            let _ = out.flush();
            server.join();
            0
        }
    }
}

#[cfg(test)]
mod tests {
    #[test]
    fn ui_is_available() {
        assert!(super::available());
        assert_eq!(super::product_name(), "evosim");
    }
}

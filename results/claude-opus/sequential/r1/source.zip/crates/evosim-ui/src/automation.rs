//! Smoke test and screenshots driven through headless chromium (ADR-026 §8).
//! No CDP: the page POSTs a report; screenshots use chromium's `--screenshot`.

use crate::server::Server;
use crate::session::{AutotestReport, UiSession};
use evosim_core::config::Config;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

pub const SMOKE_TIMEOUT: Duration = Duration::from_secs(50);
pub const SHOTS_TIMEOUT: Duration = Duration::from_secs(100);
pub const MIN_W: u32 = 1280;
pub const MIN_H: u32 = 720;
pub const WINDOW: &str = "1600,900";
/// Window height passed to the page so it fills the whole headless screenshot.
pub const WINDOW_H: u32 = 900;

/// Chromium binary: `$CHROME_BIN` → `$PUPPETEER_EXECUTABLE_PATH` → `chromium`.
pub fn find_chromium() -> String {
    for k in ["CHROME_BIN", "PUPPETEER_EXECUTABLE_PATH"] {
        if let Ok(v) = std::env::var(k) {
            if !v.is_empty() {
                return v;
            }
        }
    }
    "chromium".into()
}

/// A chromium child plus its temp profile; killed and cleaned up on drop.
pub struct Browser {
    child: Child,
    profile: PathBuf,
}

impl Browser {
    pub fn spawn(url: &str, extra: &[String]) -> Result<Browser, String> {
        let profile = std::env::temp_dir().join(format!(
            "evosim-ui-chromium-{}-{}",
            std::process::id(),
            Instant::now().elapsed().as_nanos() ^ (rand_suffix())
        ));
        std::fs::create_dir_all(&profile).map_err(|e| format!("cannot create chromium profile dir: {e}"))?;
        let bin = find_chromium();
        let mut cmd = Command::new(&bin);
        cmd.args(["--headless", "--no-sandbox", "--disable-gpu", "--no-first-run", "--hide-scrollbars", "--mute-audio"])
            .arg(format!("--user-data-dir={}", profile.display()))
            .arg(format!("--window-size={WINDOW}"))
            .args(extra)
            .arg(url)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        let child = cmd.spawn().map_err(|e| format!("cannot start chromium '{bin}': {e}"))?;
        Ok(Browser { child, profile })
    }

    /// Exit status if the process ended.
    pub fn try_wait(&mut self) -> Option<std::process::ExitStatus> {
        self.child.try_wait().ok().flatten()
    }
}

fn rand_suffix() -> u128 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0)
}

impl Drop for Browser {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_dir_all(&self.profile);
    }
}

/// Width and height of a PNG file (signature + IHDR check).
pub fn png_dimensions(path: &Path) -> Result<(u32, u32), String> {
    let b = std::fs::read(path).map_err(|e| format!("cannot read {}: {e}", path.display()))?;
    if b.len() < 24 || &b[0..8] != b"\x89PNG\r\n\x1a\n" || &b[12..16] != b"IHDR" {
        return Err(format!("{} is not a PNG file", path.display()));
    }
    let w = u32::from_be_bytes(b[16..20].try_into().unwrap());
    let h = u32::from_be_bytes(b[20..24].try_into().unwrap());
    Ok((w, h))
}

#[derive(Debug, Clone)]
pub struct SmokeSummary {
    pub ticks: u64,
    pub report: AutotestReport,
    pub elapsed_s: f64,
}

fn start(config: Config) -> Result<(UiSession, Server), String> {
    let session = UiSession::new(config)?;
    let server = Server::bind(session.clone(), 0).map_err(|e| format!("cannot bind local server: {e}"))?;
    Ok((session, server))
}

fn take_report(s: &UiSession) -> Option<AutotestReport> {
    s.shared.report.lock().unwrap().take()
}

/// `ui --smoke-test`: real server + page in headless chromium; ≥10 ticks, ≥1 frame.
pub fn smoke_test(config: Config) -> Result<SmokeSummary, String> {
    let t0 = Instant::now();
    let (session, server) = start(config)?;
    let sim_thread = session.spawn_sim_thread();
    let url = format!("{}?autotest=smoke", server.local_url());
    let mut browser = Browser::spawn(&url, &[])?;
    let result = loop {
        if let Some(r) = take_report(&session) {
            if r.frames >= 1 && session.tick() >= 10 {
                break Ok(r);
            }
            if r.frames < 1 {
                break Err(format!("page reported no rendered frames: {}", r.raw));
            }
            // report early: keep the report and wait for ticks
            *session.shared.report.lock().unwrap() = Some(r);
        }
        if let Some(st) = browser.try_wait() {
            break Err(format!("chromium exited early ({st}) before the page reported"));
        }
        if t0.elapsed() > SMOKE_TIMEOUT {
            break Err(format!("smoke test timed out after {} s (tick {})", SMOKE_TIMEOUT.as_secs(), session.tick()));
        }
        std::thread::sleep(Duration::from_millis(50));
    };
    drop(browser);
    let ticks = session.tick();
    server.shutdown();
    let _ = sim_thread.join();
    result.map(|report| SmokeSummary { ticks, report, elapsed_s: t0.elapsed().as_secs_f64() })
}

/// Tick the screenshots are taken at (charts need some history).
pub const SHOT_TICK: u64 = 300;

/// `ui --screenshots DIR`: advance ≥300 ticks, then capture `main.png` (+ optional charts, setup, zoomed, inspector views).
pub fn screenshots(config: Config, dir: &Path) -> Result<Vec<PathBuf>, String> {
    let t0 = Instant::now();
    let (session, server) = start(config)?;
    session.set_fast_until(SHOT_TICK);
    let sim_thread = session.spawn_sim_thread();
    while session.tick() < SHOT_TICK {
        if t0.elapsed() > SHOTS_TIMEOUT / 2 {
            server.shutdown();
            return Err(format!("simulation did not reach tick {SHOT_TICK} in time"));
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    // make sure the published frame is from tick >= 100
    while crate::frame::decode_frame(&session.latest_frame())
        .and_then(|(m, _)| evosim_core::serde_json::from_str::<evosim_core::serde_json::Value>(&m).ok())
        .and_then(|v| v["tick"].as_u64())
        .unwrap_or(0)
        < SHOT_TICK
    {
        std::thread::sleep(Duration::from_millis(10));
    }
    let shots: [(&str, &str, bool); 5] = [
        ("main.png", "", true),
        ("charts.png", "&view=charts", false),
        ("setup.png", "&setup=1", false),
        ("world-zoomed.png", "&zoom=40", false),
        ("inspector.png", "&inspect=1&zoom=24", false),
    ];
    let mut written = Vec::new();
    let mut err = None;
    for (name, extra, required) in shots {
        let path = dir.join(name);
        let _ = std::fs::remove_file(&path);
        match capture(&session, &server, &path, extra, t0) {
            Ok(()) => written.push(path),
            Err(e) if required => {
                err = Some(e);
                break;
            }
            Err(e) => eprintln!("warning: optional screenshot {name} failed: {e}"),
        }
    }
    server.shutdown();
    let _ = sim_thread.join();
    match err {
        Some(e) => Err(e),
        None => Ok(written),
    }
}

fn capture(session: &UiSession, server: &Server, path: &Path, extra: &str, t0: Instant) -> Result<(), String> {
    let _ = take_report(session);
    let url = format!("{}?autotest=shots&h={WINDOW_H}&min={SHOT_TICK}{extra}", server.local_url());
    let args = vec![format!("--screenshot={}", path.display()), "--virtual-time-budget=8000".to_string()];
    let mut browser = Browser::spawn(&url, &args)?;
    loop {
        if browser.try_wait().is_some() {
            break;
        }
        if t0.elapsed() > SHOTS_TIMEOUT {
            return Err(format!("screenshot {} timed out", path.display()));
        }
        std::thread::sleep(Duration::from_millis(50));
    }
    drop(browser);
    let report = take_report(session).ok_or_else(|| format!("page did not report a drawn frame for {}", path.display()))?;
    if report.frames < 1 || report.last_tick < SHOT_TICK {
        return Err(format!("page drew no frame with tick >= {SHOT_TICK}: {}", report.raw));
    }
    if extra.contains("inspect=1") && !report.raw.contains("\"inspected\":true") {
        return Err(format!("page did not select an organism for {}: {}", path.display(), report.raw));
    }
    let (w, h) = png_dimensions(path)?;
    if w < MIN_W || h < MIN_H {
        return Err(format!("{} is {w}x{h}, need at least {MIN_W}x{MIN_H}", path.display()));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn png_header_parsed() {
        let dir = std::env::temp_dir().join(format!("evosim-png-test-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let p = dir.join("a.png");
        let mut b = b"\x89PNG\r\n\x1a\n\0\0\0\x0dIHDR".to_vec();
        b.extend_from_slice(&1600u32.to_be_bytes());
        b.extend_from_slice(&900u32.to_be_bytes());
        std::fs::write(&p, &b).unwrap();
        assert_eq!(png_dimensions(&p).unwrap(), (1600, 900));
        std::fs::write(&p, b"not a png at all, definitely not").unwrap();
        assert!(png_dimensions(&p).is_err());
        let _ = std::fs::remove_dir_all(&dir);
    }
}

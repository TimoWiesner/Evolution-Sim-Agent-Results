//! Display-free chart data (ADR-028 §4): a bounded history of per-kind
//! samples fed from `Engine::step_tick`, and the on-demand trait histogram.
//! Read-only on the simulation (no RNG, no IDs), so it cannot change a run.

use evosim_core::metrics::{trait_values, Stat, TRAIT_NAMES};
use evosim_core::organism::{Kind, TraitRanges};
use evosim_core::serde_json::{json, Value};
use evosim_core::sim::Simulation;

/// Points kept before the history is decimated.
pub const MAX_POINTS: usize = 600;
/// Births / deaths are shown as events per this many ticks.
pub const RATE_TICKS: f64 = 100.0;

pub const KIND_KEYS: [&str; 3] = ["plants", "herbivores", "carnivores"];

#[derive(Debug, Clone, PartialEq)]
pub struct ChartPoint {
    pub tick: u64,
    pub count: [u64; 3],
    pub births_total: [u64; 3],
    pub deaths_total: [u64; 3],
    pub species: [u64; 3],
    pub mean: [[Option<f64>; 11]; 3],
    pub sd: [[Option<f64>; 11]; 3],
}

impl ChartPoint {
    /// Read-only snapshot of `sim` now.
    pub fn of(sim: &Simulation) -> ChartPoint {
        let pop = sim.organisms();
        let totals = pop.totals();
        let mut p = ChartPoint {
            tick: sim.tick(),
            count: [0; 3],
            births_total: [0; 3],
            deaths_total: [0; 3],
            species: [0; 3],
            mean: [[None; 11]; 3],
            sd: [[None; 11]; 3],
        };
        for k in Kind::ALL {
            let i = k.index();
            let mut vals: [Vec<f64>; 11] = Default::default();
            for o in pop.alive(k) {
                for (v, x) in vals.iter_mut().zip(trait_values(o.traits())) {
                    v.push(x);
                }
            }
            p.count[i] = vals[0].len() as u64;
            p.births_total[i] = totals.births[i];
            p.deaths_total[i] = totals.deaths[i];
            p.species[i] = sim.living_species(k) as u64;
            for t in 0..11 {
                let s = Stat::of(&vals[t]);
                p.mean[i][t] = s.map(|s| s.mean);
                p.sd[i][t] = s.map(|s| s.sd);
            }
        }
        p
    }

    fn to_json(&self, prev: Option<&ChartPoint>) -> Value {
        let rate = |tot: &[u64; 3], ptot: Option<&[u64; 3]>, i: usize| -> Value {
            match (prev, ptot) {
                (Some(pp), Some(pt)) if self.tick > pp.tick => json!((tot[i] - pt[i]) as f64 * RATE_TICKS / (self.tick - pp.tick) as f64),
                _ => Value::Null,
            }
        };
        let kinds: Vec<Value> = (0..3)
            .map(|i| {
                json!({
                    "count": self.count[i],
                    "births_total": self.births_total[i],
                    "deaths_total": self.deaths_total[i],
                    "births_rate": rate(&self.births_total, prev.map(|p| &p.births_total), i),
                    "deaths_rate": rate(&self.deaths_total, prev.map(|p| &p.deaths_total), i),
                    "species": self.species[i],
                    "mean": self.mean[i].to_vec(),
                    "sd": self.sd[i].to_vec(),
                })
            })
            .collect();
        json!({"tick": self.tick, "kinds": kinds})
    }
}

/// Bounded time series of [`ChartPoint`]s.
#[derive(Debug, Clone)]
pub struct ChartHistory {
    pub points: Vec<ChartPoint>,
    /// A point is recorded every `stride` ticks (doubles on decimation).
    pub stride: u64,
    /// Bumped whenever earlier points change (clear / decimation).
    pub version: u64,
    pub max_points: usize,
}

impl Default for ChartHistory {
    fn default() -> Self {
        Self::new()
    }
}

impl ChartHistory {
    pub fn new() -> ChartHistory {
        Self::with_max(MAX_POINTS)
    }

    pub fn with_max(max_points: usize) -> ChartHistory {
        ChartHistory { points: Vec::new(), stride: 1, version: 0, max_points: max_points.max(4) }
    }

    /// Start over with the current state as the first point (new epoch).
    pub fn clear_and_seed(&mut self, sim: &Simulation) {
        self.points.clear();
        self.stride = 1;
        self.version += 1;
        self.points.push(ChartPoint::of(sim));
    }

    /// Called after each tick; records on stride boundaries.
    pub fn observe(&mut self, sim: &Simulation) {
        let last = self.points.last().map(|p| p.tick);
        if last.is_some_and(|t| sim.tick() < t + self.stride) {
            return;
        }
        self.points.push(ChartPoint::of(sim));
        if self.points.len() > self.max_points {
            self.decimate();
        }
    }

    /// Keep every other point (always the first and last), double the stride.
    pub fn decimate(&mut self) {
        let n = self.points.len();
        let kept: Vec<ChartPoint> =
            self.points.iter().enumerate().filter(|(i, _)| i % 2 == 0 || *i == n - 1).map(|(_, p)| p.clone()).collect();
        self.points = kept;
        self.stride *= 2;
        self.version += 1;
    }

    /// Chart reply. `since = (version, tick)`: if the version still matches,
    /// only points after `tick` are sent (`full:false`); else everything.
    /// `now` is an optional live point appended when newer than the last.
    pub fn to_json(&self, epoch: u64, since: Option<(u64, u64)>, now: Option<ChartPoint>) -> Value {
        let (full, from) = match since {
            Some((v, t)) if v == self.version => (false, Some(t)),
            _ => (true, None),
        };
        let mut out = Vec::new();
        for (i, p) in self.points.iter().enumerate() {
            if from.is_some_and(|t| p.tick <= t) {
                continue;
            }
            out.push(p.to_json(i.checked_sub(1).map(|j| &self.points[j])));
        }
        let live = now.filter(|n| self.points.last().is_none_or(|l| n.tick > l.tick)).map(|n| n.to_json(self.points.last()));
        json!({
            "ok": true,
            "epoch": epoch,
            "version": self.version,
            "full": full,
            "stride": self.stride,
            "rate_ticks": RATE_TICKS,
            "kinds": KIND_KEYS,
            "traits": TRAIT_NAMES,
            "points": out,
            "live": live,
        })
    }
}

/// Kind from `plants|herbivores|carnivores` (or the singular forms).
pub fn parse_kind(s: &str) -> Option<Kind> {
    match s {
        "plants" | "plant" => Some(Kind::Plant),
        "herbivores" | "herbivore" => Some(Kind::Herbivore),
        "carnivores" | "carnivore" => Some(Kind::Carnivore),
        _ => None,
    }
}

pub fn trait_index(s: &str) -> Option<usize> {
    TRAIT_NAMES.iter().position(|n| *n == s)
}

/// `(lo, hi)` of the ADR-011 range of trait `t` for `kind`.
pub fn trait_range(kind: Kind, t: usize) -> (f64, f64) {
    let r = TraitRanges::for_kind(kind);
    let p = |x: evosim_core::organism::Range| (x.lo, x.hi);
    match t {
        0 => p(r.speed),
        1 => p(r.strength),
        2 => p(r.fertility),
        3 => p(r.max_health),
        4 => (f64::from(r.max_lifespan.0), f64::from(r.max_lifespan.1)),
        5 => p(r.max_energy),
        6 => p(r.vision),
        7 => p(r.aggression),
        8 => p(r.caution),
        9 => p(r.temp_optimum),
        _ => p(r.temp_tolerance),
    }
}

/// Distribution of trait `t` among the living organisms of `kind`.
/// Bin edges span the trait's full heritable range.
pub fn histogram(sim: &Simulation, kind: Kind, t: usize, bins: usize) -> Value {
    let bins = bins.clamp(2, 100);
    let (rlo, rhi) = trait_range(kind, t);
    let vals: Vec<f64> = sim.organisms().alive(kind).map(|o| trait_values(o.traits())[t]).collect();
    // axis = observed spread (+5 % padding, at least 2 % of the heritable range),
    // so a narrow distribution is not squeezed into one bar; empty → full range
    let (mut lo, mut hi) = if vals.is_empty() {
        (rlo, rhi)
    } else {
        let mn = vals.iter().copied().fold(f64::INFINITY, f64::min);
        let mx = vals.iter().copied().fold(f64::NEG_INFINITY, f64::max);
        let span = (mx - mn).max((rhi - rlo).abs() * 0.02).max(1e-6);
        let mid = (mx + mn) / 2.0;
        (mid - span * 0.55, mid + span * 0.55)
    };
    if hi.partial_cmp(&lo) != Some(std::cmp::Ordering::Greater) {
        hi = lo + 1.0;
    }
    for v in &vals {
        lo = lo.min(*v);
        hi = hi.max(*v);
    }
    let w = (hi - lo) / bins as f64;
    let mut counts = vec![0u64; bins];
    for v in &vals {
        let i = (((v - lo) / w).floor() as isize).clamp(0, bins as isize - 1) as usize;
        counts[i] += 1;
    }
    let edges: Vec<f64> = (0..=bins).map(|i| lo + w * i as f64).collect();
    let s = Stat::of(&vals);
    json!({
        "ok": true,
        "tick": sim.tick(),
        "kind": KIND_KEYS[kind.index()],
        "trait": TRAIT_NAMES[t],
        "n": vals.len(),
        "edges": edges,
        "counts": counts,
        "mean": s.map(|s| s.mean),
        "sd": s.map(|s| s.sd),
        "range": [rlo, rhi],
    })
}

/// Raw (undecoded, simple `%XX`-free) query parameter.
pub fn query_param(query: &str, name: &str) -> Option<String> {
    query.split('&').find_map(|kv| {
        let (k, v) = kv.split_once('=').unwrap_or((kv, ""));
        (k == name).then(|| v.to_string())
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::control::Engine;
    use evosim_core::config::Config;

    fn engine() -> Engine {
        Engine::new(Config::contract_example()).unwrap()
    }

    #[test]
    fn history_records_and_rates() {
        let mut e = engine();
        let t0 = *e.sim.organisms().totals();
        for _ in 0..50 {
            e.step_tick();
        }
        let h = &e.history;
        assert_eq!(h.points.len(), 51);
        assert!(h.points.windows(2).all(|w| w[0].tick < w[1].tick));
        let last = h.points.last().unwrap();
        for k in Kind::ALL {
            assert_eq!(last.count[k.index()], e.sim.organisms().count_alive(k) as u64);
            assert_eq!(last.species[k.index()], e.sim.living_species(k) as u64);
        }
        let j = h.to_json(0, None, None);
        let pts = j["points"].as_array().unwrap();
        assert_eq!(pts.len(), 51);
        assert!(pts[0]["kinds"][0]["births_rate"].is_null());
        let t1 = *e.sim.organisms().totals();
        for i in 0..3 {
            let sum: f64 = pts[1..].iter().map(|p| p["kinds"][i]["births_rate"].as_f64().unwrap() / RATE_TICKS).sum();
            assert!((sum - (t1.births[i] - t0.births[i]) as f64).abs() < 1e-6);
            let sum: f64 = pts[1..].iter().map(|p| p["kinds"][i]["deaths_rate"].as_f64().unwrap() / RATE_TICKS).sum();
            assert!((sum - (t1.deaths[i] - t0.deaths[i]) as f64).abs() < 1e-6);
        }
        // mean of a trait equals the manual mean
        let vals: Vec<f64> = e.sim.organisms().alive(Kind::Plant).map(|o| o.traits().speed).collect();
        let m = vals.iter().sum::<f64>() / vals.len() as f64;
        assert!((last.mean[0][0].unwrap() - m).abs() < 1e-9);
        // extinct kind → null mean
        let mut c = Config::contract_example();
        c.initial.carnivores = 0;
        let e2 = Engine::new(c).unwrap();
        let j = e2.history.to_json(0, None, None);
        assert!(j["points"][0]["kinds"][2]["mean"][0].is_null());
        assert_eq!(j["points"][0]["kinds"][2]["count"], 0);
    }

    #[test]
    fn decimation_bounded_and_consistent() {
        let mut e = engine();
        e.history = ChartHistory::with_max(8);
        e.history.clear_and_seed(&e.sim);
        let v0 = e.history.version;
        let t0 = *e.sim.organisms().totals();
        let mut snapshots = std::collections::BTreeMap::new();
        for _ in 0..200 {
            e.step_tick();
            snapshots.insert(e.tick(), *e.sim.organisms().totals());
            assert!(e.history.points.len() <= 9);
        }
        assert!(e.history.stride > 1);
        assert!(e.history.version > v0);
        assert_eq!(e.history.points[0].tick, 0);
        for p in &e.history.points[1..] {
            assert_eq!(p.births_total, snapshots[&p.tick].births);
        }
        let j = e.history.to_json(0, None, None);
        let pts = j["points"].as_array().unwrap();
        let last_tick = pts.last().unwrap()["tick"].as_u64().unwrap();
        let t1 = snapshots[&last_tick];
        for i in 0..3 {
            let mut sum = 0.0;
            for w in pts.windows(2) {
                let dt = (w[1]["tick"].as_u64().unwrap() - w[0]["tick"].as_u64().unwrap()) as f64;
                sum += w[1]["kinds"][i]["births_rate"].as_f64().unwrap() * dt / RATE_TICKS;
            }
            assert!((sum - (t1.births[i] - t0.births[i]) as f64).abs() < 1e-6);
        }
    }

    #[test]
    fn incremental_since() {
        let mut e = engine();
        for _ in 0..10 {
            e.step_tick();
        }
        let v = e.history.version;
        let j = e.history.to_json(3, Some((v, 6)), None);
        assert_eq!(j["full"], false);
        assert_eq!(j["epoch"], 3);
        let ticks: Vec<u64> = j["points"].as_array().unwrap().iter().map(|p| p["tick"].as_u64().unwrap()).collect();
        assert_eq!(ticks, vec![7, 8, 9, 10]);
        // the first incremental point still has its rate (diffed against the previous point)
        assert!(j["points"][0]["kinds"][0]["births_rate"].is_number());
        let j = e.history.to_json(0, Some((v + 7, 6)), None);
        assert_eq!(j["full"], true);
        assert_eq!(j["points"].as_array().unwrap().len(), 11);
        // live point only when newer than the last recorded one
        let j = e.history.to_json(0, Some((v, 10)), Some(ChartPoint::of(&e.sim)));
        assert!(j["live"].is_null());
    }

    #[test]
    fn recording_does_not_change_hash() {
        let mut e = engine();
        let mut s = Simulation::new(Config::contract_example()).unwrap();
        for _ in 0..60 {
            e.step_tick();
            s.step();
        }
        let _ = histogram(&e.sim, Kind::Herbivore, 0, 20);
        assert_eq!(e.sim.state_hash(), s.state_hash());
    }

    #[test]
    fn histogram_counts() {
        let mut e = engine();
        for _ in 0..20 {
            e.step_tick();
        }
        for k in Kind::ALL {
            for t in 0..11 {
                let h = histogram(&e.sim, k, t, 16);
                let n = e.sim.organisms().count_alive(k) as u64;
                assert_eq!(h["n"], n);
                let counts = h["counts"].as_array().unwrap();
                assert_eq!(counts.len(), 16);
                assert_eq!(h["edges"].as_array().unwrap().len(), 17);
                assert_eq!(counts.iter().map(|c| c.as_u64().unwrap()).sum::<u64>(), n);
                let vals: Vec<f64> = e.sim.organisms().alive(k).map(|o| trait_values(o.traits())[t]).collect();
                if n > 0 {
                    let m = vals.iter().sum::<f64>() / n as f64;
                    assert!((h["mean"].as_f64().unwrap() - m).abs() < 1e-9);
                }
            }
        }
        let mut c = Config::contract_example();
        c.initial.carnivores = 0;
        let e2 = Engine::new(c).unwrap();
        let h = histogram(&e2.sim, Kind::Carnivore, 0, 10);
        assert_eq!(h["n"], 0);
        assert!(h["mean"].is_null());
        assert!(h["counts"].as_array().unwrap().iter().all(|c| c == 0));
        assert_eq!(trait_index("speed"), Some(0));
        assert_eq!(trait_index("nope"), None);
        assert_eq!(parse_kind("herbivores"), Some(Kind::Herbivore));
        assert_eq!(parse_kind("x"), None);
        assert_eq!(query_param("v=3&since=10&kind=plants", "since").as_deref(), Some("10"));
        assert_eq!(query_param("a=1", "b"), None);
    }
}

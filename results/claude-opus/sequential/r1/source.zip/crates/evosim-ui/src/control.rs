//! Display-free run control + inspector logic (ADR-027 §1–3).
//!
//! [`Engine`] owns the simulation and every control rule (run / pause / step /
//! reset / speed / selection / checkpoint save+load). The HTTP layer only parses
//! requests into [`Command`]s, so all rules are unit-tested here without a
//! server, browser or display.

use crate::charts::ChartHistory;
use evosim_core::config::Config;
use evosim_core::genome::gene_table;
use evosim_core::ids::EntityId;
use evosim_core::organism::{Kind, Organism, Parents, TraitRanges};
use evosim_core::serde_json::{json, Value};
use evosim_core::sim::Simulation;
use evosim_core::topology::Cell;
use std::fmt;
use std::path::{Path, PathBuf};

/// Speed levels in ticks per second; `None` = unthrottled ("Max").
pub const SPEED_LEVELS: [Option<u32>; 8] = [Some(1), Some(2), Some(5), Some(10), Some(20), Some(50), Some(200), None];
/// Default level index (20 ticks/s, the ADR-026 default).
pub const DEFAULT_SPEED: usize = 4;

/// Clamp any requested speed index into `0..SPEED_LEVELS.len()` (never wraps).
pub fn clamp_speed(i: i64) -> usize {
    i.clamp(0, SPEED_LEVELS.len() as i64 - 1) as usize
}

/// Human label of a speed level.
pub fn speed_label(i: usize) -> String {
    match SPEED_LEVELS[clamp_speed(i as i64)] {
        Some(t) => format!("{t}×"),
        None => "Max".into(),
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum Command {
    Run,
    Pause,
    Toggle,
    Step,
    Reset,
    Faster,
    Slower,
    SetSpeed(i64),
    Select { x: i64, y: i64 },
    SelectId(u64),
    Deselect,
    Save(PathBuf),
    Load(PathBuf),
    LoadText(String),
    /// Start a new world from a validated configuration (ADR-028 §3).
    NewWorld(Box<Config>),
}

#[derive(Debug, Clone, PartialEq)]
pub struct ControlError(pub String);

impl fmt::Display for ControlError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

fn err<T>(s: impl Into<String>) -> Result<T, ControlError> {
    Err(ControlError(s.into()))
}

fn int_field(v: &Value, k: &str) -> Result<i64, ControlError> {
    match &v[k] {
        Value::Number(n) => n
            .as_i64()
            .or_else(|| n.as_f64().filter(|f| f.is_finite()).map(|f| f.clamp(-1e15, 1e15).floor() as i64))
            .ok_or_else(|| ControlError(format!("'{k}' must be an integer"))),
        Value::Null => err(format!("missing '{k}'")),
        _ => err(format!("'{k}' must be an integer")),
    }
}

fn path_field(v: &Value) -> Result<PathBuf, ControlError> {
    match v["path"].as_str().map(str::trim) {
        Some(p) if !p.is_empty() => Ok(PathBuf::from(p)),
        _ => err("missing checkpoint 'path'"),
    }
}

impl Command {
    /// Parse `{"cmd": "...", ...}` (body of `POST /api/control`).
    pub fn from_json(v: &Value) -> Result<Command, ControlError> {
        let Some(cmd) = v["cmd"].as_str() else { return err("missing 'cmd'") };
        Ok(match cmd {
            "run" => Command::Run,
            "pause" => Command::Pause,
            "toggle" => Command::Toggle,
            "step" => Command::Step,
            "reset" => Command::Reset,
            "faster" => Command::Faster,
            "slower" => Command::Slower,
            "speed" => Command::SetSpeed(int_field(v, "speed")?),
            "select" => {
                if !v["id"].is_null() {
                    Command::SelectId(int_field(v, "id")?.max(0) as u64)
                } else {
                    Command::Select { x: int_field(v, "x")?, y: int_field(v, "y")? }
                }
            }
            "deselect" => Command::Deselect,
            "save" => Command::Save(path_field(v)?),
            "load" => Command::Load(path_field(v)?),
            "new" => match crate::scenario::validate_form(&v["config"]) {
                Ok(c) => Command::NewWorld(Box::new(c)),
                Err(errs) => {
                    return err(errs.iter().map(|e| format!("{}: {}", e.key, e.message)).collect::<Vec<_>>().join("; "))
                }
            },
            other => return err(format!("unknown command '{other}'")),
        })
    }
}

/// Singular kind label used by the inspector.
pub fn kind_label(k: Kind) -> &'static str {
    match k {
        Kind::Plant => "plant",
        Kind::Herbivore => "herbivore",
        Kind::Carnivore => "carnivore",
    }
}

fn kind_priority(k: Kind) -> u8 {
    match k {
        Kind::Carnivore => 0,
        Kind::Herbivore => 1,
        Kind::Plant => 2,
    }
}

/// How the selected organism died.
#[derive(Debug, Clone, PartialEq)]
pub struct DeathInfo {
    pub tick: u64,
    pub cause: String,
    pub age: u32,
    pub pos: Cell,
}

/// Currently selected organism: last living snapshot plus death, if any.
#[derive(Debug, Clone, PartialEq)]
pub struct Selection {
    pub id: EntityId,
    pub kind: Kind,
    /// Inspector JSON of the last tick the organism was alive.
    pub last: Value,
    pub death: Option<DeathInfo>,
}

impl Selection {
    fn new(sim: &Simulation, o: &Organism) -> Selection {
        Selection { id: o.id(), kind: o.kind(), last: inspector_data(sim, o), death: None }
    }

    /// Refresh after a tick: living → new data; gone → record its death once.
    pub fn observe(&mut self, sim: &Simulation) {
        if self.death.is_some() {
            return;
        }
        let pop = sim.organisms();
        if let Some(o) = pop.get_alive(self.id) {
            self.last = inspector_data(sim, o);
            return;
        }
        let d = pop.last_deaths().iter().find(|d| d.id == self.id);
        let last_pos = Cell {
            x: self.last["pos"]["x"].as_u64().unwrap_or(0) as u32,
            y: self.last["pos"]["y"].as_u64().unwrap_or(0) as u32,
        };
        self.death = Some(match d {
            Some(d) => DeathInfo { tick: d.tick, cause: d.cause.name().into(), age: d.age, pos: d.pos },
            None => DeathInfo {
                tick: sim.tick(),
                cause: "unknown".into(),
                age: self.last["age"].as_u64().unwrap_or(0) as u32,
                pos: last_pos,
            },
        });
    }

    pub fn alive(&self) -> bool {
        self.death.is_none()
    }

    /// Inspector JSON: last data + `alive` + `death`.
    pub fn to_json(&self) -> Value {
        let mut v = self.last.clone();
        v["alive"] = json!(self.alive());
        v["death"] = match &self.death {
            None => Value::Null,
            Some(d) => json!({"tick": d.tick, "cause": d.cause, "age": d.age, "pos": {"x": d.pos.x, "y": d.pos.y}}),
        };
        v
    }
}

fn species_code(sim: &Simulation, o: &Organism) -> Option<String> {
    sim.species().get(o.species()).map(|r| r.code())
}

/// Inspector data of a living organism (ADR-027 §3).
pub fn inspector_data(sim: &Simulation, o: &Organism) -> Value {
    let kind = o.kind();
    let t = o.traits();
    let r = TraitRanges::for_kind(kind);
    let tr = |name: &str, value: f64, lo: f64, hi: f64| json!({"name": name, "value": value, "min": lo, "max": hi});
    let traits = vec![
        tr("speed", t.speed, r.speed.lo, r.speed.hi),
        tr("strength", t.strength, r.strength.lo, r.strength.hi),
        tr("fertility", t.fertility, r.fertility.lo, r.fertility.hi),
        tr("max_health", t.max_health, r.max_health.lo, r.max_health.hi),
        tr("max_lifespan", f64::from(t.max_lifespan), f64::from(r.max_lifespan.0), f64::from(r.max_lifespan.1)),
        tr("max_energy", t.max_energy, r.max_energy.lo, r.max_energy.hi),
        tr("vision", t.vision, r.vision.lo, r.vision.hi),
        tr("aggression", t.aggression, r.aggression.lo, r.aggression.hi),
        tr("caution", t.caution, r.caution.lo, r.caution.hi),
        tr("temp_optimum", t.temp_optimum, r.temp_optimum.lo, r.temp_optimum.hi),
        tr("temp_tolerance", t.temp_tolerance, r.temp_tolerance.lo, r.temp_tolerance.hi),
    ];
    let table = gene_table(kind);
    let genome: Vec<Value> = o
        .genome()
        .genes()
        .iter()
        .enumerate()
        .map(|(i, g)| {
            let spec = table.get(i);
            json!({
                "name": spec.map(|s| s.name).unwrap_or("?"),
                "value": f64::from(*g),
                "founder": spec.map(|s| f64::from(s.founder)),
                "target": spec.and_then(|s| s.target).map(|t| format!("{t:?}").to_lowercase()),
            })
        })
        .collect();
    let pop = sim.organisms();
    let parent_ids: Vec<EntityId> = match o.parents() {
        Parents::None => vec![],
        Parents::One(a) => vec![a],
        Parents::Two(a, b) => vec![a, b],
    };
    let parents: Vec<Value> = parent_ids
        .iter()
        .map(|id| match pop.get_alive(*id) {
            Some(p) => json!({"id": id.0, "alive": true, "kind": kind_label(p.kind()), "species_code": species_code(sim, p)}),
            None => json!({"id": id.0, "alive": false, "kind": Value::Null, "species_code": Value::Null}),
        })
        .collect();
    let sp = sim.species().get(o.species());
    let species = json!({
        "id": o.species().0,
        "code": sp.map(|s| s.code()),
        "name": sp.map(|s| s.name().to_string()),
        "parent_code": sp.and_then(|s| s.parent()).and_then(|p| sim.species().get(p)).map(|p| p.code()),
    });
    json!({
        "id": o.id().0,
        "kind": kind_label(kind),
        "species": species,
        "age": o.age(),
        "birth_tick": o.birth_tick(),
        "generation": o.generation(),
        "pos": {"x": o.pos().x, "y": o.pos().y},
        "energy": o.energy(),
        "max_energy": t.max_energy,
        "health": o.health(),
        "max_health": t.max_health,
        "cooldown": o.cooldown(),
        "traits": traits,
        "genome": genome,
        "parents": parents,
        "tick": sim.tick(),
    })
}

/// Write `text` to `path` via a temporary sibling + rename.
pub fn write_file_atomic(path: &Path, text: &str) -> std::io::Result<()> {
    let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| "checkpoint".into());
    let tmp = path.with_file_name(format!(".{name}.tmp-{}", std::process::id()));
    std::fs::write(&tmp, text)?;
    std::fs::rename(&tmp, path).inspect_err(|_| {
        let _ = std::fs::remove_file(&tmp);
    })
}

/// The controlled simulation.
pub struct Engine {
    pub sim: Simulation,
    /// Configuration used by Reset (the loaded checkpoint's after a Load).
    pub config: Config,
    pub running: bool,
    pub speed: usize,
    /// Incremented whenever the world is replaced (Reset / Load).
    pub epoch: u64,
    pub selection: Option<Selection>,
    /// Chart time series (ADR-028 §4); reset whenever the world is replaced.
    pub history: ChartHistory,
}

impl Engine {
    pub fn new(config: Config) -> Result<Engine, ControlError> {
        let sim = Simulation::new(config.clone()).map_err(|e| ControlError(format!("cannot create world: {e}")))?;
        Ok(Self::from_parts(sim, config))
    }

    fn from_parts(sim: Simulation, config: Config) -> Engine {
        let mut history = ChartHistory::new();
        history.clear_and_seed(&sim);
        Engine { sim, config, running: false, speed: DEFAULT_SPEED, epoch: 0, selection: None, history }
    }

    pub fn from_sim(sim: Simulation) -> Engine {
        let config = sim.config().clone();
        Self::from_parts(sim, config)
    }

    pub fn tick(&self) -> u64 {
        self.sim.tick()
    }

    /// Target ticks per second of the current level (`None` = unthrottled).
    pub fn pace(&self) -> Option<u32> {
        SPEED_LEVELS[self.speed]
    }

    /// The only place the simulation advances: one tick + selection update.
    pub fn step_tick(&mut self) {
        self.sim.step();
        if let Some(s) = self.selection.as_mut() {
            s.observe(&self.sim);
        }
        self.history.observe(&self.sim);
    }

    pub fn inspector_json(&self) -> Value {
        self.selection.as_ref().map(Selection::to_json).unwrap_or(Value::Null)
    }

    pub fn speed_json(&self) -> Value {
        json!({
            "index": self.speed,
            "label": speed_label(self.speed),
            "tps": self.pace(),
            "levels": (0..SPEED_LEVELS.len()).map(speed_label).collect::<Vec<_>>(),
        })
    }

    /// Control state summary (reply of every command).
    pub fn status_json(&self) -> Value {
        json!({
            "ok": true,
            "tick": self.tick(),
            "running": self.running,
            "epoch": self.epoch,
            "speed": self.speed_json(),
            "selected": self.inspector_json(),
        })
    }

    pub fn checkpoint_text(&self) -> Result<String, ControlError> {
        self.sim.checkpoint_json().map_err(|e| ControlError(format!("cannot build checkpoint: {e}")))
    }

    fn replace_sim(&mut self, sim: Simulation) {
        self.config = sim.config().clone();
        self.sim = sim;
        self.running = false;
        self.epoch += 1;
        self.selection = None;
        self.history.clear_and_seed(&self.sim);
    }

    /// Organism at a (wrapped) cell: carnivore > herbivore > plant, lowest ID;
    /// empty cell → nearest within Chebyshev radius 1.
    pub fn pick(&self, x: i64, y: i64) -> Option<EntityId> {
        let w = i64::from(self.sim.config().world.width);
        let h = i64::from(self.sim.config().world.height);
        let cell = Cell { x: x.rem_euclid(w) as u32, y: y.rem_euclid(h) as u32 };
        let mut near = self.sim.organisms().within(cell, 1, None);
        near.sort_by_key(|n| (n.distance, kind_priority(n.kind), n.id));
        near.first().map(|n| n.id)
    }

    fn select_id(&mut self, id: EntityId) -> bool {
        match self.sim.organisms().get_alive(id) {
            Some(o) => {
                self.selection = Some(Selection::new(&self.sim, o));
                true
            }
            None => false,
        }
    }

    /// Apply one command; the reply is [`Engine::status_json`] (+ `message`).
    pub fn apply(&mut self, cmd: Command) -> Result<Value, ControlError> {
        let mut message = String::new();
        match cmd {
            Command::Run => self.running = true,
            Command::Pause => self.running = false,
            Command::Toggle => self.running = !self.running,
            Command::Step => {
                self.running = false;
                self.step_tick();
            }
            Command::Reset => {
                let sim = Simulation::new(self.config.clone()).map_err(|e| ControlError(format!("cannot reset: {e}")))?;
                self.replace_sim(sim);
                message = format!("reset to tick 0 (seed {})", self.config.seed);
            }
            Command::Faster => self.speed = clamp_speed(self.speed as i64 + 1),
            Command::Slower => self.speed = clamp_speed(self.speed as i64 - 1),
            Command::SetSpeed(i) => self.speed = clamp_speed(i),
            Command::Select { x, y } => match self.pick(x, y) {
                Some(id) => {
                    self.select_id(id);
                }
                None => self.selection = None,
            },
            Command::SelectId(id) => {
                if !self.select_id(EntityId(id)) {
                    return err(format!("organism {id} is not alive"));
                }
            }
            Command::Deselect => self.selection = None,
            Command::Save(path) => {
                let text = self.checkpoint_text()?;
                write_file_atomic(&path, &text)
                    .map_err(|e| ControlError(format!("cannot write checkpoint '{}': {e}", path.display())))?;
                message = format!("saved tick {} to {}", self.tick(), path.display());
            }
            Command::Load(path) => {
                let text = std::fs::read_to_string(&path)
                    .map_err(|e| ControlError(format!("cannot read checkpoint '{}': {e}", path.display())))?;
                self.load_text(&text)?;
                message = format!("loaded tick {} from {}", self.tick(), path.display());
            }
            Command::LoadText(text) => {
                self.load_text(&text)?;
                message = format!("loaded uploaded checkpoint at tick {}", self.tick());
            }
            Command::NewWorld(c) => {
                let sim = Simulation::new((*c).clone()).map_err(|e| ControlError(format!("cannot create world: {e}")))?;
                self.replace_sim(sim);
                self.running = true;
                message = format!("new world '{}' {}×{} (seed {})", c.name, c.world.width, c.world.height, c.seed);
            }
        }
        let mut v = self.status_json();
        v["message"] = json!(message);
        Ok(v)
    }

    fn load_text(&mut self, text: &str) -> Result<(), ControlError> {
        let sim = Simulation::from_checkpoint_json(text).map_err(|e| ControlError(format!("invalid checkpoint: {e}")))?;
        self.replace_sim(sim);
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg() -> Config {
        Config::contract_example()
    }

    fn engine() -> Engine {
        Engine::new(cfg()).unwrap()
    }

    fn tmpdir(tag: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("evosim-control-{tag}-{}", std::process::id()));
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn step_advances_exactly_one_tick() {
        let mut e = engine();
        let mut reference = Simulation::new(cfg()).unwrap();
        for _ in 0..5 {
            let t = e.tick();
            e.apply(Command::Step).unwrap();
            reference.step();
            assert_eq!(e.tick(), t + 1);
            assert_eq!(e.sim.state_hash(), reference.state_hash());
        }
        e.apply(Command::Run).unwrap();
        assert!(e.running);
        let t = e.tick();
        let r = e.apply(Command::Step).unwrap();
        assert!(!e.running, "step pauses");
        assert_eq!(e.tick(), t + 1);
        assert_eq!(r["tick"], t + 1);
        assert_eq!(r["running"], false);
    }

    #[test]
    fn run_pause_toggle() {
        let mut e = engine();
        assert!(!e.running);
        e.apply(Command::Run).unwrap();
        assert!(e.running);
        e.apply(Command::Pause).unwrap();
        assert!(!e.running);
        e.apply(Command::Toggle).unwrap();
        assert!(e.running);
        e.apply(Command::Toggle).unwrap();
        assert!(!e.running);
        // run/pause do not advance the world
        assert_eq!(e.tick(), 0);
    }

    #[test]
    fn reset_rebuilds_same_start() {
        let mut e = engine();
        let h0 = Simulation::new(cfg()).unwrap().state_hash();
        assert_eq!(e.sim.state_hash(), h0);
        for _ in 0..30 {
            e.step_tick();
        }
        e.apply(Command::SetSpeed(6)).unwrap();
        let id = e.sim.organisms().alive(Kind::Plant).next().unwrap().id();
        e.apply(Command::SelectId(id.0)).unwrap();
        e.apply(Command::Run).unwrap();
        let r = e.apply(Command::Reset).unwrap();
        assert_eq!(e.tick(), 0);
        assert_eq!(e.sim.state_hash(), h0);
        assert_eq!(e.epoch, 1);
        assert!(e.selection.is_none());
        assert!(!e.running);
        assert_eq!(e.speed, 6, "reset keeps speed");
        assert_eq!(r["epoch"], 1);
        for _ in 0..7 {
            e.step_tick();
        }
        e.apply(Command::Reset).unwrap();
        assert_eq!(e.sim.state_hash(), h0);
        assert_eq!(e.epoch, 2);
        // the replayed run is identical to the first one
        let mut a = engine();
        for _ in 0..12 {
            a.step_tick();
            e.step_tick();
        }
        assert_eq!(a.sim.state_hash(), e.sim.state_hash());
    }

    #[test]
    fn speed_clamps_and_is_never_negative() {
        assert!(SPEED_LEVELS.len() >= 3);
        assert!(SPEED_LEVELS.iter().all(|l| l.is_none_or(|t| t > 0)));
        let mut e = engine();
        assert_eq!(e.speed, DEFAULT_SPEED);
        assert_eq!(e.pace(), Some(20));
        e.apply(Command::SetSpeed(-5)).unwrap();
        assert_eq!(e.speed, 0);
        e.apply(Command::Slower).unwrap();
        assert_eq!(e.speed, 0);
        assert_eq!(e.pace(), Some(1));
        e.apply(Command::SetSpeed(i64::MIN)).unwrap();
        assert_eq!(e.speed, 0);
        e.apply(Command::SetSpeed(99)).unwrap();
        assert_eq!(e.speed, SPEED_LEVELS.len() - 1);
        e.apply(Command::Faster).unwrap();
        assert_eq!(e.speed, SPEED_LEVELS.len() - 1);
        assert_eq!(e.pace(), None);
        e.apply(Command::SetSpeed(2)).unwrap();
        e.apply(Command::Faster).unwrap();
        assert_eq!(e.speed, 3);
        e.apply(Command::Slower).unwrap();
        e.apply(Command::Slower).unwrap();
        assert_eq!(e.speed, 1);
        let s = e.speed_json();
        assert_eq!(s["label"], "2×");
        assert_eq!(s["levels"].as_array().unwrap().len(), SPEED_LEVELS.len());
        assert_eq!(speed_label(7), "Max");
        assert_eq!(Command::from_json(&json!({"cmd":"speed","speed":-3})).unwrap(), Command::SetSpeed(-3));
        assert_eq!(Command::from_json(&json!({"cmd":"speed","speed":2.7})).unwrap(), Command::SetSpeed(2));
        assert!(Command::from_json(&json!({"cmd":"speed","speed":"fast"})).is_err());
    }

    #[test]
    fn parse_commands() {
        let p = |v: Value| Command::from_json(&v);
        assert_eq!(p(json!({"cmd":"run"})).unwrap(), Command::Run);
        assert_eq!(p(json!({"cmd":"step"})).unwrap(), Command::Step);
        assert_eq!(p(json!({"cmd":"select","x":-1,"y":3})).unwrap(), Command::Select { x: -1, y: 3 });
        assert_eq!(p(json!({"cmd":"select","id":17})).unwrap(), Command::SelectId(17));
        assert_eq!(p(json!({"cmd":"save","path":"/tmp/a.json"})).unwrap(), Command::Save("/tmp/a.json".into()));
        assert!(p(json!({"cmd":"save","path":"  "})).is_err());
        assert!(p(json!({"cmd":"fly"})).is_err());
        assert!(p(json!({})).is_err());
        assert!(p(json!({"cmd":"select","x":1})).is_err());
    }

    #[test]
    fn select_prefers_animals_and_wraps() {
        let mut e = engine();
        let w = i64::from(e.sim.config().world.width);
        let c = e.sim.organisms().alive(Kind::Carnivore).next().unwrap();
        let (id, pos) = (c.id(), c.pos());
        for (x, y) in [(i64::from(pos.x), i64::from(pos.y)), (i64::from(pos.x) + w, i64::from(pos.y)), (i64::from(pos.x) - w, i64::from(pos.y))] {
            let r = e.apply(Command::Select { x, y }).unwrap();
            assert_eq!(r["selected"]["id"], id.0, "cell ({x},{y})");
            assert_eq!(r["selected"]["kind"], "carnivore");
        }
        // a cell with a plant and no animal within radius 0 gives an organism of that cell or a neighbour
        let p = e.sim.organisms().alive(Kind::Plant).next().unwrap().pos();
        let r = e.apply(Command::Select { x: i64::from(p.x), y: i64::from(p.y) }).unwrap();
        assert!(!r["selected"].is_null());
        // an empty world region selects nothing
        let mut c2 = cfg();
        c2.initial.plants = 1;
        c2.initial.herbivores = 0;
        c2.initial.carnivores = 0;
        let mut e2 = Engine::new(c2).unwrap();
        let only = e2.sim.organisms().alive(Kind::Plant).next().unwrap().pos();
        let r = e2.apply(Command::Select { x: i64::from(only.x) + 1, y: i64::from(only.y) + 1 }).unwrap();
        assert_eq!(r["selected"]["kind"], "plant", "radius-1 fallback");
        let r = e2.apply(Command::Select { x: i64::from(only.x) + 10, y: i64::from(only.y) + 10 }).unwrap();
        assert!(r["selected"].is_null());
        assert!(e2.apply(Command::SelectId(999_999)).is_err());
        e.apply(Command::Deselect).unwrap();
        assert!(e.selection.is_none());
    }

    #[test]
    fn inspector_has_all_fields() {
        let mut e = engine();
        let h = e.sim.organisms().alive(Kind::Herbivore).next().unwrap().id();
        let r = e.apply(Command::SelectId(h.0)).unwrap();
        let s = &r["selected"];
        for k in ["id", "kind", "species", "age", "energy", "health", "traits", "genome", "parents", "alive", "death", "generation", "pos"] {
            assert!(s.get(k).is_some(), "missing {k}");
        }
        assert_eq!(s["id"], h.0);
        assert_eq!(s["kind"], "herbivore");
        assert!(s["species"]["code"].is_string());
        assert_eq!(s["traits"].as_array().unwrap().len(), 11);
        assert_eq!(s["genome"].as_array().unwrap().len(), gene_table(Kind::Herbivore).len());
        assert!(s["genome"][0]["name"].is_string());
        assert_eq!(s["parents"].as_array().unwrap().len(), 0, "founder");
        assert_eq!(s["alive"], true);
        assert!(s["death"].is_null());
        // a born organism lists its parents
        let mut born = None;
        for _ in 0..400 {
            e.step_tick();
            born = Kind::ALL.iter().flat_map(|k| e.sim.organisms().alive(*k)).find(|o| o.parents() != Parents::None).map(|o| o.id());
            if born.is_some() {
                break;
            }
        }
        let born = born.expect("some organism was born within 400 ticks");
        let r = e.apply(Command::SelectId(born.0)).unwrap();
        let n = r["selected"]["parents"].as_array().unwrap().len();
        assert!((1..=2).contains(&n));
        assert!(r["selected"]["parents"][0]["id"].is_u64());
    }

    #[test]
    fn selection_follows_and_records_death() {
        let mut e = engine();
        let h = e.sim.organisms().alive(Kind::Herbivore).next().unwrap().id();
        e.apply(Command::SelectId(h.0)).unwrap();
        e.apply(Command::Step).unwrap();
        assert_eq!(e.inspector_json()["tick"], 1);
        assert_eq!(e.inspector_json()["age"], e.sim.organisms().get_alive(h).unwrap().age());
        // kill it in the middle of the next tick via the public population API
        let t = e.tick();
        e.sim.organisms_mut().kill(h, evosim_core::organism::DeathCause::Predation, t + 1);
        e.step_tick();
        let j = e.inspector_json();
        assert_eq!(j["alive"], false);
        assert_eq!(j["id"], h.0);
        assert!(j["traits"].is_array(), "data retained after death");
        assert!(j["death"]["tick"].is_u64());
        // first-cause-wins; whatever the cause name is, it is a known label
        assert!(j["death"]["cause"].is_string());
        assert_ne!(j["death"]["cause"], "unknown");
        // keeps showing the death while running on
        for _ in 0..5 {
            e.step_tick();
        }
        assert_eq!(e.inspector_json()["alive"], false);
        assert_eq!(e.inspector_json()["death"], j["death"]);
        // natural death: follow an organism until it dies
        let mut e = engine();
        let h = e.sim.organisms().alive(Kind::Herbivore).last().unwrap().id();
        e.apply(Command::SelectId(h.0)).unwrap();
        let mut died = false;
        for _ in 0..3000 {
            e.step_tick();
            let alive_now = e.sim.organisms().get_alive(h).is_some();
            let j = e.inspector_json();
            assert_eq!(j["alive"].as_bool().unwrap(), alive_now);
            if alive_now {
                assert_eq!(j["tick"], e.tick());
                let o = e.sim.organisms().get_alive(h).unwrap();
                assert_eq!(j["pos"]["x"], o.pos().x);
                assert_eq!(j["energy"], o.energy());
            } else {
                assert!(j["death"]["tick"].as_u64().unwrap() <= e.tick());
                assert_ne!(j["death"]["cause"], "unknown");
                died = true;
                break;
            }
        }
        assert!(died, "herbivore did not die within 3000 ticks");
    }

    #[test]
    fn save_load_roundtrip() {
        let d = tmpdir("ckpt");
        let path = d.join("save.json");
        let mut e = engine();
        for _ in 0..20 {
            e.step_tick();
        }
        let saved_hash = e.sim.state_hash();
        let r = e.apply(Command::Save(path.clone())).unwrap();
        assert!(r["message"].as_str().unwrap().contains("saved tick 20"));
        for _ in 0..10 {
            e.step_tick();
        }
        e.apply(Command::Run).unwrap();
        let r = e.apply(Command::Load(path.clone())).unwrap();
        assert_eq!(e.tick(), 20);
        assert_eq!(e.sim.state_hash(), saved_hash);
        assert!(!e.running);
        assert_eq!(r["epoch"], 1);
        // the loaded world continues exactly like the original
        let mut reference = Simulation::new(cfg()).unwrap();
        reference.run(25);
        for _ in 0..5 {
            e.step_tick();
        }
        assert_eq!(e.sim.state_hash(), reference.state_hash());
        // reset after load = tick 0 of the loaded configuration
        e.apply(Command::Reset).unwrap();
        assert_eq!(e.tick(), 0);
        assert_eq!(e.sim.state_hash(), Simulation::new(cfg()).unwrap().state_hash());
        // load via text (upload path)
        let text = std::fs::read_to_string(&path).unwrap();
        e.apply(Command::LoadText(text)).unwrap();
        assert_eq!(e.tick(), 20);
        // garbage leaves the sim untouched
        let bad = d.join("bad.json");
        std::fs::write(&bad, "{\"not\": \"a checkpoint\"}").unwrap();
        let before = e.sim.state_hash();
        let epoch = e.epoch;
        assert!(e.apply(Command::Load(bad)).is_err());
        assert!(e.apply(Command::Load(d.join("missing.json"))).is_err());
        assert!(e.apply(Command::LoadText("garbage".into())).is_err());
        assert_eq!(e.sim.state_hash(), before);
        assert_eq!(e.epoch, epoch);
        assert!(e.apply(Command::Save(d.join("no/such/dir/x.json"))).is_err());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn new_world_replaces_and_resets_history() {
        let mut e = engine();
        for _ in 0..30 {
            e.step_tick();
        }
        let id = e.sim.organisms().alive(Kind::Plant).next().unwrap().id();
        e.apply(Command::SelectId(id.0)).unwrap();
        assert_eq!(e.history.points.len(), 31);
        let mut c = evosim_core::config::preset("harsh").unwrap();
        c.seed = 99;
        c.initial.herbivores = 33;
        let cmd = Command::from_json(&json!({"cmd": "new", "config": c.to_json_value()})).unwrap();
        assert_eq!(cmd, Command::NewWorld(Box::new(c.clone())));
        let r = e.apply(cmd).unwrap();
        assert_eq!(e.epoch, 1);
        assert_eq!(r["epoch"], 1);
        assert_eq!(e.tick(), 0);
        assert!(e.running, "a new world starts running");
        assert!(e.selection.is_none());
        assert_eq!(e.config, c);
        assert_eq!(e.sim.state_hash(), Simulation::new(c.clone()).unwrap().state_hash());
        assert_eq!(e.history.points.len(), 1);
        assert_eq!(e.history.points[0].count[1], 33);
        // reset afterwards rebuilds the new world's tick 0
        e.step_tick();
        e.apply(Command::Reset).unwrap();
        assert_eq!(e.sim.state_hash(), Simulation::new(c).unwrap().state_hash());
        assert_eq!(e.history.points.len(), 1);
    }

    #[test]
    fn invalid_new_world_untouched() {
        let mut v = cfg().to_json_value();
        v["world"]["width"] = json!(0);
        v["plants"]["mutation_rate"] = json!(2);
        let e = Command::from_json(&json!({"cmd": "new", "config": v})).unwrap_err();
        assert!(e.0.contains("world.width") && e.0.contains("plants.mutation_rate"), "{}", e.0);
        assert!(Command::from_json(&json!({"cmd": "new"})).is_err());
    }

    #[test]
    fn reset_after_load_uses_loaded_config() {
        let d = tmpdir("cfg");
        let path = d.join("other.json");
        let mut other = cfg();
        other.seed = 4242;
        let mut s = Simulation::new(other.clone()).unwrap();
        s.run(3);
        std::fs::write(&path, s.checkpoint_json().unwrap()).unwrap();
        let mut e = engine();
        e.apply(Command::Load(path)).unwrap();
        e.apply(Command::Reset).unwrap();
        assert_eq!(e.config.seed, 4242);
        assert_eq!(e.sim.state_hash(), Simulation::new(other).unwrap().state_hash());
        let _ = std::fs::remove_dir_all(&d);
    }
}

'use strict';
const test = require('node:test');
const assert = require('node:assert');
const app = require('../app.js');

const close = (a, b) => Math.abs(a - b) < 1e-9;

test('screen <-> world round trip', () => {
  const cam = { cx: 10.5, cy: 7.25, scale: 6 };
  for (const [sx, sy] of [[0, 0], [123, 456], [1279, 719]]) {
    const [wx, wy] = app.screenToWorld(cam, sx, sy, 1280, 720);
    const [bx, by] = app.worldToScreen(cam, wx, wy, 1280, 720);
    assert.ok(close(sx, bx) && close(sy, by));
  }
});

test('zoomAt keeps the world point under the cursor fixed', () => {
  const cam = { cx: 32, cy: 24, scale: 10 };
  const before = app.screenToWorld(cam, 200, 150, 1000, 700);
  const z = app.zoomAt(cam, 200, 150, 2, 1000, 700, 1);
  assert.strictEqual(z.scale, 20);
  const after = app.screenToWorld(z, 200, 150, 1000, 700);
  assert.ok(close(before[0], after[0]) && close(before[1], after[1]));
});

test('zoom is clamped', () => {
  const cam = { cx: 0, cy: 0, scale: 60 };
  assert.strictEqual(app.zoomAt(cam, 0, 0, 10, 100, 100, 1).scale, app.MAX_SCALE);
  assert.strictEqual(app.zoomAt(cam, 0, 0, 1e-6, 100, 100, 3).scale, 3);
});

test('wrapMod and pan wrap around the torus', () => {
  assert.strictEqual(app.wrapMod(-1, 64), 63);
  assert.strictEqual(app.wrapMod(65, 64), 1);
  const p = app.pan({ cx: 1, cy: 1, scale: 10 }, 30, -20, 64, 48);
  assert.ok(close(p.cx, 62) && close(p.cy, 3));
});

test('fit shows the whole world', () => {
  const c = app.fitCamera(64, 48, 1280, 720);
  assert.strictEqual(c.scale, 15);
  assert.deepStrictEqual([c.cx, c.cy], [32, 24]);
});

test('tile offsets cover a wrapped view', () => {
  assert.deepStrictEqual(app.tileOffsets({ cx: 2, scale: 10 }, 200, 64), [-64, 0]);
  assert.deepStrictEqual(app.tileOffsets({ cx: 32, scale: 10 }, 200, 64), [0]);
});

test('season names by quarter', () => {
  assert.strictEqual(app.seasonName(0.1), 'Spring');
  assert.strictEqual(app.seasonName(0.6), 'Autumn');
});

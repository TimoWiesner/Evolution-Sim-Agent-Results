'use strict';
// Display-free tests of the TASK-024 control / inspector helpers in app.js.
const test = require('node:test');
const assert = require('node:assert');
const app = require('../app.js');

test('keyboard shortcuts map to control commands and are ignored in inputs', () => {
  assert.deepStrictEqual(app.keyToCommand(' ', false, false), { cmd: 'toggle' });
  assert.deepStrictEqual(app.keyToCommand('.', false, false), { cmd: 'step' });
  assert.deepStrictEqual(app.keyToCommand('n', false, false), { cmd: 'step' });
  assert.deepStrictEqual(app.keyToCommand('R', false, false), { cmd: 'reset' });
  assert.deepStrictEqual(app.keyToCommand('[', false, false), { cmd: 'slower' });
  assert.deepStrictEqual(app.keyToCommand(']', false, false), { cmd: 'faster' });
  assert.deepStrictEqual(app.keyToCommand('Escape', false, false), { cmd: 'deselect' });
  assert.deepStrictEqual(app.keyToCommand('f', false, false), { cmd: 'follow' });
  assert.deepStrictEqual(app.keyToCommand('s', true, true), { cmd: 'save' });
  assert.strictEqual(app.keyToCommand(' ', false, true), null, 'typing a space in the path field');
  assert.strictEqual(app.keyToCommand('r', true, false), null, 'Ctrl+R stays browser reload');
  assert.strictEqual(app.keyToCommand('x', false, false), null);
});

test('click vs drag threshold', () => {
  assert.ok(app.isClick(0, 0));
  assert.ok(app.isClick(2, -3));
  assert.ok(!app.isClick(4, 0));
  assert.ok(!app.isClick(10, 10));
});

test('speed index clamps and label', () => {
  assert.strictEqual(app.clampSpeedIndex(-3, 8), 0);
  assert.strictEqual(app.clampSpeedIndex(99, 8), 7);
  assert.strictEqual(app.clampSpeedIndex(3.7, 8), 3);
  assert.strictEqual(app.clampSpeedIndex('x', 8), 0);
  assert.strictEqual(app.speedLabel({ label: 'Max' }), 'Max');
  assert.strictEqual(app.speedLabel(null), '–');
});

const genome = [
  { name: 'strength', value: 0.5, founder: 0.5, target: 'strength' },
  { name: 'vision', value: 1.2, founder: 0.4, target: 'vision' },
  { name: 'temp_opt', value: -0.1, founder: 0.5, target: 'tempoptimum' },
  { name: 'marker_0', value: 0.25, founder: 0.5, target: null },
];

test('genome bars: one per locus, height = value, colour by trait group', () => {
  const bars = app.genomeBars(genome, 100, 50);
  assert.strictEqual(bars.length, 4);
  assert.strictEqual(bars[0].h, 25);
  assert.strictEqual(bars[1].h, 50, 'values clamp to 1');
  assert.strictEqual(bars[2].h, 0, 'values clamp to 0');
  assert.strictEqual(bars[0].founderY, 25);
  assert.deepStrictEqual(bars.map((b) => b.group), ['body', 'behaviour', 'climate', 'neutral']);
  assert.ok(bars[3].x + bars[3].w <= 100 + 1e-9);
  assert.notStrictEqual(bars[0].color, bars[3].color);
});

const sel = {
  id: 42, kind: 'herbivore', species: { id: 3, code: 'H3', name: 'Grassbiter', parent_code: 'H1' }, age: 17, birth_tick: 80,
  generation: 2, pos: { x: 5, y: 9 }, energy: 12.5, max_energy: 40, health: 30, max_health: 30, cooldown: 4,
  traits: [{ name: 'max_energy', value: 40, min: 0.1, max: 1e6 }, { name: 'caution', value: 0.3, min: 0, max: 1 }],
  genome, parents: [{ id: 7, alive: true, kind: 'herbivore', species_code: 'H3' }, { id: 9, alive: false, kind: null, species_code: null }],
  alive: true, death: null, tick: 97,
};

test('inspector lists ID, kind, species, age, energy, health, traits, genome and parents', () => {
  const f = app.formatInspector(sel);
  const rows = Object.fromEntries(f.rows);
  assert.strictEqual(rows.ID, '#42');
  assert.strictEqual(rows.Kind, 'herbivore');
  assert.ok(rows.Species.includes('H3') && rows.Species.includes('Grassbiter'));
  assert.strictEqual(rows.Age, '17 ticks');
  assert.ok(rows.Energy.startsWith('12.5'));
  assert.ok(rows.Health.startsWith('30.0'));
  assert.strictEqual(f.traits.length, 2);
  assert.ok(Math.abs(f.traits[1].frac - 0.3) < 1e-9);
  assert.strictEqual(f.genomeLen, 4);
  assert.strictEqual(f.parents.length, 2);
  assert.ok(f.parentsText.includes('#7 H3') && f.parentsText.includes('#9 †'));
  assert.strictEqual(f.death, null);
  assert.strictEqual(app.formatInspector(null), null);
  const founder = app.formatInspector(Object.assign({}, sel, { parents: [] }));
  assert.strictEqual(founder.parentsText, 'founder (no parents)');
});

test('inspector shows the death of the selection', () => {
  const dead = Object.assign({}, sel, { alive: false, death: { tick: 120, cause: 'predation', age: 40, pos: { x: 5, y: 9 } } });
  const f = app.formatInspector(dead);
  assert.ok(f.death.includes('Died at tick 120') && f.death.includes('predation'), f.death);
});

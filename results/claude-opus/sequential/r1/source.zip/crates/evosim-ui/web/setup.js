// Evolution Simulation — "New world" dialog (ADR-028 §2, §5): presets, parameter form,
// field validation and JSON import/export. Pure helpers are exported for `node --test`.
'use strict';

const U64_MAX = '18446744073709551615';
const SEED_SENTINEL = '__EVOSIM_SEED_DIGITS__';

function getPath(obj, key) { return key.split('.').reduce((o, k) => (o && typeof o === 'object' ? o[k] : undefined), obj); }
function setPath(obj, key, v) {
  const segs = key.split('.'); let o = obj;
  for (const s of segs.slice(0, -1)) { if (!o[s] || typeof o[s] !== 'object') o[s] = {}; o = o[s]; }
  o[segs[segs.length - 1]] = v;
}
function cmpDigits(a, b) { a = a.replace(/^0+(?=\d)/, ''); b = b.replace(/^0+(?=\d)/, ''); return a.length !== b.length ? a.length - b.length : a < b ? -1 : a > b ? 1 : 0; }
function fmtBound(v) { return typeof v === 'string' ? v : Number.isInteger(v) ? String(v) : String(+v.toPrecision(6)); }

// error text for one raw form value (string, or boolean for checkboxes); null = valid
function validateField(spec, raw) {
  const t = spec.type;
  if (t === 'boolean') return typeof raw === 'boolean' ? null : 'expected true or false';
  if (t === 'string') return typeof raw === 'string' ? null : 'expected text';
  const s = String(raw === undefined || raw === null ? '' : raw).trim();
  if (s === '') return spec.required ? 'required' : 'enter a value';
  if (spec.key === 'seed') {
    if (!/^\d+$/.test(s)) return 'must be a whole number ≥ 0';
    return cmpDigits(s, U64_MAX) > 0 ? `must be at most ${U64_MAX}` : null;
  }
  if (t === 'integer') {
    if (!/^[+-]?\d+$/.test(s)) return 'must be a whole number';
  } else if (!/^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(s)) return 'must be a number';
  const v = Number(s);
  if (!Number.isFinite(v)) return 'must be a finite number';
  if ((spec.min !== null && spec.min !== undefined && v < spec.min) || (spec.max !== null && spec.max !== undefined && v > spec.max)) {
    return `must be between ${fmtBound(spec.min)} and ${fmtBound(spec.max)}`;
  }
  return null;
}
// raw form value → JSON value (seed stays a digit string, see buildConfigText)
function parseField(spec, raw) {
  if (spec.type === 'boolean' || spec.type === 'string') return raw;
  const s = String(raw).trim();
  if (spec.key === 'seed') return s.replace(/^0+(?=\d)/, '');
  return Number(s);
}
function formatValue(spec, v) {
  if (spec.type === 'boolean') return !!v;
  if (spec.type === 'string') return v === undefined || v === null ? '' : String(v);
  return v === undefined || v === null ? '' : String(v);
}
// form state {key: raw} from a config object (+ exact seed text from the server)
function formFromConfig(config, seedText, params) {
  const f = {};
  for (const p of params) {
    let v = getPath(config, p.key);
    if (v === undefined) v = p.default;
    f[p.key] = p.key === 'seed' ? String(seedText !== undefined && seedText !== null ? seedText : v) : formatValue(p, v);
  }
  return f;
}
// all field errors {key: message}; also the UI cell guard on world.width
function validateForm(form, params, maxCells) {
  const errs = {};
  for (const p of params) {
    const e = validateField(p, form[p.key]);
    if (e) errs[p.key] = e;
  }
  if (!errs['world.width'] && !errs['world.height'] && maxCells) {
    const cells = Number(form['world.width']) * Number(form['world.height']);
    if (cells > maxCells) errs['world.width'] = `world too large for the UI (width × height must be at most ${maxCells.toLocaleString('en')} cells)`;
  }
  if (!errs['climate.pole_temperature'] && !errs['climate.equator_temperature'] && form['climate.pole_temperature'] !== undefined &&
      Number(form['climate.pole_temperature']) > Number(form['climate.equator_temperature'])) {
    errs['climate.pole_temperature'] = 'must be ≤ equator temperature';
  }
  return errs;
}
// config object (seed replaced by a sentinel) from a form
function configFromForm(form, params) {
  const c = {};
  for (const p of params) setPath(c, p.key, p.key === 'seed' ? SEED_SENTINEL : parseField(p, form[p.key]));
  return c;
}
// JSON text of the form; the seed digits are written raw so u64 seeds survive exactly
function buildConfigText(form, params) {
  const seed = parseField({ key: 'seed' }, form.seed);
  if (!/^\d+$/.test(seed)) throw new Error('invalid seed');
  return JSON.stringify(configFromForm(form, params), null, 2).replace(`"${SEED_SENTINEL}"`, seed) + '\n';
}
// best-effort form values from imported JSON text (even when invalid), seed digits taken from the text
function formFromText(text, params) {
  let obj;
  try { obj = JSON.parse(text); } catch (e) { return null; }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
  const m = /"seed"\s*:\s*(-?\d+)/.exec(text);
  return formFromConfig(obj, m ? m[1] : obj.seed, params);
}
// server errors [{key, message}] → {key: message}; keys not in the form go to '<json>'
function errorsByKey(list, params) {
  const known = new Set(params.map((p) => p.key)), out = {};
  for (const e of list || []) {
    const k = known.has(e.key) ? e.key : '<json>';
    out[k] = out[k] ? `${out[k]}; ${k === '<json>' ? e.key + ': ' : ''}${e.message}` : (k === '<json>' && e.key !== '<json>' ? `${e.key}: ` : '') + e.message;
  }
  return out;
}
function fieldLabel(key) {
  const last = key.split('.').pop().replace(/_/g, ' ');
  return last.charAt(0).toUpperCase() + last.slice(1);
}
function randomSeedText(rand) {
  rand = rand || Math.random;
  return String(Math.floor(rand() * 4294967296) * 4096 + Math.floor(rand() * 4096));
}

const SetupLib = { U64_MAX, getPath, setPath, validateField, parseField, formFromConfig, validateForm, configFromForm, buildConfigText,
  formFromText, errorsByKey, fieldLabel, randomSeedText, cmpDigits };
if (typeof module !== 'undefined') module.exports = SetupLib;
if (typeof window !== 'undefined') window.SetupLib = SetupLib;

// ---------- dialog (browser only) ----------
if (typeof document !== 'undefined') window.createSetupDialog = function createSetupDialog(opts) {
  const $ = (id) => document.getElementById(id);
  const dlg = $('setup');
  let schema = null, presets = [], params = [], form = {}, errs = {}, serverErrs = {}, chosen = null, inputs = {};
  const GROUP_ORDER = ['Climate', 'Plants', 'Herbivores', 'Carnivores', 'Hunting', 'Info'];

  function field(p) {
    const wrap = document.createElement('label'); wrap.className = 'field'; wrap.dataset.key = p.key;
    const name = document.createElement('span'); name.className = 'fname'; name.textContent = p.basic ? basicLabel(p.key) : fieldLabel(p.key);
    name.title = `${p.key} — ${p.doc}`;
    wrap.appendChild(name);
    let inp;
    if (p.type === 'boolean') { inp = document.createElement('input'); inp.type = 'checkbox'; wrap.classList.add('bool'); }
    else { inp = document.createElement('input'); inp.type = 'text'; inp.spellcheck = false; inp.inputMode = p.type === 'string' ? 'text' : 'decimal'; }
    inp.dataset.key = p.key;
    inp.oninput = inp.onchange = () => { form[p.key] = p.type === 'boolean' ? inp.checked : inp.value; delete serverErrs[p.key]; check(); markPreset(); };
    const row = document.createElement('span'); row.className = 'frow'; row.appendChild(inp);
    if (p.key === 'seed') {
      const dice = document.createElement('button'); dice.type = 'button'; dice.textContent = '🎲'; dice.title = 'Random seed';
      dice.onclick = () => { form.seed = randomSeedText(); inp.value = form.seed; check(); };
      row.appendChild(dice);
    }
    if (p.type !== 'boolean' && p.type !== 'string' && p.min !== null) {
      const hint = document.createElement('span'); hint.className = 'range'; hint.textContent = `${fmtBound(p.min)}…${p.key === 'seed' ? '2⁶⁴−1' : fmtBound(p.max)}`; row.appendChild(hint);
    }
    wrap.appendChild(row);
    const err = document.createElement('span'); err.className = 'ferr'; wrap.appendChild(err);
    inputs[p.key] = { inp, err, wrap, p };
    return wrap;
  }
  function basicLabel(k) {
    return { seed: 'Seed', 'world.width': 'Width (cells)', 'world.height': 'Height (cells)', 'initial.plants': 'Plants', 'initial.herbivores': 'Herbivores', 'initial.carnivores': 'Carnivores' }[k] || fieldLabel(k);
  }
  function section(title, list, cls) {
    const s = document.createElement('div'); s.className = 'fsection ' + (cls || '');
    if (title) { const h = document.createElement('h3'); h.textContent = title; s.appendChild(h); }
    const g = document.createElement('div'); g.className = 'fgrid'; list.forEach((p) => g.appendChild(field(p))); s.appendChild(g);
    return s;
  }
  function build() {
    params = schema.params;
    const body = $('setup-fields'); body.innerHTML = ''; inputs = {};
    const by = (k) => params.find((p) => p.key === k);
    body.appendChild(section('World', schema.basic.slice(0, 3).map(by), 'world'));
    body.appendChild(section('Initial populations', schema.basic.slice(3).map(by), 'world'));
    body.appendChild(section('Key parameters', schema.featured.map(by)));
    const adv = document.createElement('details'); adv.className = 'advanced';
    const sum = document.createElement('summary'); sum.textContent = `Advanced — all ${params.length - schema.basic.length - schema.featured.length} other parameters`; adv.appendChild(sum);
    adv.ontoggle = () => {
      if (!adv.open || adv.dataset.built) return;
      adv.dataset.built = '1';
      for (const g of GROUP_ORDER) {
        const list = params.filter((p) => p.group === g && !p.basic && !p.featured);
        if (list.length) adv.appendChild(section(g, list));
      }
      fill(); check();
    };
    body.appendChild(adv);
    const cards = $('setup-presets'); cards.innerHTML = '';
    for (const pr of presets) {
      const c = document.createElement('button'); c.type = 'button'; c.className = 'preset'; c.dataset.name = pr.name;
      const cfg = pr.config;
      c.innerHTML = `<b></b><span class="pdesc"></span><span class="pmeta"></span>`;
      c.querySelector('b').textContent = pr.name;
      c.querySelector('.pdesc').textContent = pr.description;
      c.querySelector('.pmeta').textContent = `${cfg.world.width}×${cfg.world.height} · ${cfg.initial.plants}/${cfg.initial.herbivores}/${cfg.initial.carnivores}`;
      c.onclick = () => choosePreset(pr.name);
      cards.appendChild(c);
    }
  }
  function fill() {
    for (const k of Object.keys(inputs)) {
      const { inp, p } = inputs[k];
      if (p.type === 'boolean') inp.checked = !!form[k]; else inp.value = form[k] === undefined ? '' : form[k];
    }
  }
  function check() {
    errs = validateForm(form, params, schema.max_cells);
    const all = Object.assign({}, serverErrs, errs);
    let n = 0;
    for (const k of Object.keys(inputs)) {
      const { err, wrap } = inputs[k];
      const m = all[k] || '';
      err.textContent = m; wrap.classList.toggle('invalid', !!m);
      if (m) n++;
    }
    // errors of fields inside the not-yet-built Advanced section
    const hidden = Object.keys(all).filter((k) => !inputs[k] && k !== '<json>');
    const top = [all['<json>'], ...hidden.map((k) => `${k}: ${all[k]}`)].filter(Boolean);
    $('setup-docerr').textContent = top.join(' · ');
    const total = Object.keys(all).length;
    $('setup-start').disabled = total > 0;
    $('setup-summary').textContent = total ? `${total} invalid field${total > 1 ? 's' : ''} — fix ${total > 1 ? 'them' : 'it'} to start` : 'Ready to start a new world';
    $('setup-summary').className = 'small ' + (total ? 'bad' : 'good');
    return total === 0 && n === 0;
  }
  function markPreset() {
    document.querySelectorAll('#setup-presets .preset').forEach((c) => c.classList.toggle('on', c.dataset.name === chosen));
    const pr = presets.find((p) => p.name === chosen);
    if (!pr) return;
    const base = formFromConfig(pr.config, pr.seed_text, params);
    const edited = params.filter((p) => String(base[p.key]) !== String(form[p.key])).length;
    $('setup-edited').textContent = edited ? `preset “${chosen}” · ${edited} edited` : `preset “${chosen}”`;
  }
  function choosePreset(name) {
    const pr = presets.find((p) => p.name === name); if (!pr) return;
    chosen = name; form = formFromConfig(pr.config, pr.seed_text, params); serverErrs = {};
    fill(); check(); markPreset();
  }
  function loadForm(newForm, errors) {
    form = newForm; serverErrs = errors || {}; chosen = null; fill(); check(); markPreset();
    $('setup-edited').textContent = 'imported file';
  }
  async function ensureLoaded() {
    if (schema) return;
    schema = await (await fetch('/api/schema', { cache: 'no-store' })).json();
    presets = (await (await fetch('/api/presets', { cache: 'no-store' })).json()).presets;
    build();
  }
  async function open(preset) {
    await ensureLoaded();
    const cur = await (await fetch('/api/config', { cache: 'no-store' })).json();
    form = formFromConfig(cur.config, cur.seed_text, params); serverErrs = {};
    chosen = presets.some((p) => p.name === cur.config.name) ? cur.config.name : null;
    fill(); check(); markPreset();
    if (!chosen) $('setup-edited').textContent = 'current world';
    if (preset) choosePreset(preset);
    if (!dlg.open) { if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', ''); }
  }
  function close() { if (dlg.open) { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); } }
  function setValue(key, value) { form[key] = value; fill(); check(); markPreset(); }
  async function start() {
    if (!check()) return false;
    const text = buildConfigText(form, params);
    const r = await fetch('/api/new', { method: 'POST', body: text, headers: { 'Content-Type': 'application/json' } });
    const j = await r.json().catch(() => ({ ok: false, errors: [{ key: '<json>', message: `HTTP ${r.status}` }] }));
    if (!r.ok || j.ok === false) { serverErrs = errorsByKey(j.errors || [{ key: '<json>', message: j.error }], params); check(); return false; }
    close(); if (opts && opts.onStarted) opts.onStarted(j);
    return true;
  }
  function exportForm() {
    if (!check()) return;
    const text = buildConfigText(form, params);
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    const name = (form.name || 'config').replace(/[^A-Za-z0-9_-]/g, '-');
    a.download = `evosim-config-${name}.json`; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  async function importText(text) {
    await ensureLoaded();
    const r = await fetch('/api/config/validate', { method: 'POST', body: text, headers: { 'Content-Type': 'application/json' } });
    const j = await r.json().catch(() => ({ ok: false, errors: [{ key: '<json>', message: `HTTP ${r.status}` }] }));
    if (r.ok && j.ok !== false) { loadForm(formFromConfig(j.config, j.seed_text, params), {}); return true; }
    const partial = formFromText(text, params);
    loadForm(partial || form, errorsByKey(j.errors, params));
    return false;
  }
  $('setup-start').onclick = start;
  $('setup-cancel').onclick = close;
  $('setup-close').onclick = close;
  $('setup-export').onclick = exportForm;
  $('setup-import').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; await importText(await f.text()); e.target.value = ''; };
  dlg.addEventListener('keydown', (e) => e.stopPropagation());
  return { open, close, start, choosePreset, setValue, importText, get errors() { return Object.assign({}, serverErrs, errs); }, get isOpen() { return dlg.open; } };
};

'use strict';
const test = require('node:test');
const assert = require('node:assert');
const C = require('../charts.js');

function pt(tick, n, births) {
  const k = (i) => ({ count: n[i], births_total: births[i], deaths_total: births[i] >> 1, species: i + 1,
    births_rate: null, deaths_rate: null, mean: C.TRAITS.map((_, t) => t + i), sd: C.TRAITS.map(() => 0.5) });
  return { tick, kinds: [k(0), k(1), k(2)] };
}

test('niceTicks covers the range with monotone ticks', () => {
  for (const [a, b] of [[0, 1], [0, 3523], [-12.5, 40], [0.97, 1.06], [5, 5], [7, 3]]) {
    const t = C.niceTicks(a, b, 5);
    assert.ok(t.min <= Math.min(a, b) && t.max >= Math.max(a, b), `${a}..${b}`);
    for (let i = 1; i < t.ticks.length; i++) assert.ok(t.ticks[i] > t.ticks[i - 1]);
    assert.ok(t.ticks.length >= 2 && t.ticks.length <= 12);
  }
  assert.deepStrictEqual(C.logTicks(3500).ticks, [0, 1, 10, 100, 1000, 10000]);
  assert.strictEqual(C.fmtTick(2500), '2.5k');
});

test('mergeChartData appends incrementally and resets on version/epoch change', () => {
  let s = C.emptyChartState();
  assert.strictEqual(C.chartQuery(s), '');
  s = C.mergeChartData(s, { ok: true, epoch: 0, version: 1, full: true, stride: 1, points: [pt(0, [1, 2, 3], [0, 0, 0]), pt(1, [2, 2, 3], [1, 0, 0])], live: null });
  assert.strictEqual(s.points.length, 2);
  assert.strictEqual(C.chartQuery(s), '?v=1&since=1');
  s = C.mergeChartData(s, { ok: true, epoch: 0, version: 1, full: false, points: [pt(1, [2, 2, 3], [1, 0, 0]), pt(2, [3, 2, 3], [2, 0, 0])], live: pt(3, [4, 2, 3], [3, 0, 0]) });
  assert.deepStrictEqual(s.points.map((p) => p.tick), [0, 1, 2], 'duplicate tick ignored');
  assert.strictEqual(C.allPoints(s).length, 4, 'live point appended for drawing');
  s = C.mergeChartData(s, { ok: true, epoch: 0, version: 2, full: true, points: [pt(0, [1, 2, 3], [0, 0, 0]), pt(2, [3, 2, 3], [2, 0, 0])] });
  assert.deepStrictEqual(s.points.map((p) => p.tick), [0, 2], 'decimated history replaces');
  s = C.mergeChartData(s, { ok: true, epoch: 1, version: 3, full: true, points: [pt(0, [9, 9, 9], [0, 0, 0])] });
  assert.strictEqual(s.points.length, 1);
  assert.strictEqual(s.epoch, 1);
  assert.strictEqual(C.mergeChartData(s, { ok: false }), s);
});

test('every chart has title, axis labels and a legend entry per series', () => {
  let s = C.emptyChartState();
  const pts = []; for (let t = 0; t <= 100; t += 10) pts.push(pt(t, [100 + t, 20, 5], [t * 3, t, 0]));
  s = C.mergeChartData(s, { ok: true, epoch: 0, version: 1, full: true, points: pts });
  for (const id of ['population', 'births', 'species', 'trait']) {
    const spec = C.buildSeries(id, s, { trait: 'vision', kind: id === 'trait' ? 'herbivores' : undefined });
    assert.ok(spec.title && spec.xLabel && spec.yLabel, id);
    assert.ok(spec.series.length >= 1);
    for (const ser of spec.series) assert.strictEqual(ser.points.length, pts.length);
    const legend = C.lineEntries(spec);
    assert.ok(legend.length >= 3 || id === 'trait', id);
    assert.ok(legend.every((e) => e.name && e.color));
  }
  const pop = C.buildSeries('population', s, {});
  assert.deepStrictEqual(pop.series.map((x) => x.name), ['Plants', 'Herbivores', 'Carnivores']);
  assert.strictEqual(pop.series[0].points[10][1], 200);
  const tr = C.buildSeries('trait', s, { trait: 'vision', kind: 'herbivores' });
  assert.strictEqual(tr.series[0].points[0][1], C.TRAITS.indexOf('vision') + 1);
  assert.deepStrictEqual(tr.series[0].band[0], [0, C.TRAITS.indexOf('vision') + 0.5, C.TRAITS.indexOf('vision') + 1.5]);
  assert.strictEqual(C.buildSeries('trait', s, { trait: 'speed', kind: 'all' }).series.length, 3);
  for (const k of Object.keys(C.CHART_SPECS)) assert.ok(C.CHART_SPECS[k].xLabel && C.CHART_SPECS[k].yLabel);
});

test('windowRates turns cumulative totals into events per 100 ticks', () => {
  const pts = []; for (let t = 0; t <= 100; t += 5) pts.push(pt(t, [1, 1, 1], [t * 2, 0, 0]));
  const r = C.windowRates(pts, 0, 'births_total', 25);
  assert.strictEqual(r[0][1], null);
  for (const [, v] of r.slice(1)) assert.ok(Math.abs(v - 200) < 1e-9);
  assert.ok(C.windowRates(pts, 1, 'births_total', 25).slice(1).every(([, v]) => v === 0));
});

test('histogramBars geometry', () => {
  const h = { counts: [0, 5, 10, 5], edges: [0, 1, 2, 3, 4] };
  const bars = C.histogramBars(h, { x: 10, y: 20, w: 400, h: 100 });
  assert.strictEqual(bars.length, 4);
  assert.strictEqual(bars[2].h, 100);
  assert.strictEqual(bars[1].h, 50);
  assert.strictEqual(bars[0].h, 0);
  assert.strictEqual(bars[3].x, 310);
  assert.strictEqual(bars[3].w, 100);
  assert.strictEqual(bars[2].y + bars[2].h, 120);
  assert.deepStrictEqual([bars[1].lo, bars[1].hi], [1, 2]);
  assert.deepStrictEqual(C.histogramBars({ counts: [], edges: [0] }, { x: 0, y: 0, w: 10, h: 10 }), []);
});

test('drawing functions run against a recording 2D context', () => {
  const calls = [];
  const ctx = new Proxy({ measureText: (s) => ({ width: s.length * 6 }) }, {
    get: (t, k) => (k in t ? t[k] : (...a) => calls.push([k, a])), set: () => true,
  });
  let s = C.mergeChartData(C.emptyChartState(), { ok: true, epoch: 0, version: 1, full: true, points: [pt(0, [1, 2, 3], [0, 0, 0]), pt(10, [5, 2, 0], [4, 1, 0])] });
  C.drawLineChart(ctx, C.buildSeries('population', s, {}), 300, 200);
  const texts = calls.filter((c) => c[0] === 'fillText').map((c) => c[1][0]);
  assert.ok(texts.includes('Tick') && texts.includes('Individuals (log scale)') && texts.includes('Plants') && texts.includes('Carnivores'));
  calls.length = 0;
  C.drawHistogram(ctx, { kind: 'herbivores', trait: 'speed', n: 3, edges: [0, 1, 2], counts: [1, 2], mean: 1.2 }, 300, 200);
  const t2 = calls.filter((c) => c[0] === 'fillText').map((c) => c[1][0]);
  assert.ok(t2.includes('Speed (cells/tick)') && t2.includes('Individuals') && t2.some((x) => /Herbivores/.test(x)));
});

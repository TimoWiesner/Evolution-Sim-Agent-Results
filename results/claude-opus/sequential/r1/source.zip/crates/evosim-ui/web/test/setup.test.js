'use strict';
const test = require('node:test');
const assert = require('node:assert');
const S = require('../setup.js');

const P = [
  { key: 'seed', type: 'integer', required: true, min: 0, max: S.U64_MAX },
  { key: 'world.width', type: 'integer', required: true, min: 1, max: 4096 },
  { key: 'world.height', type: 'integer', required: true, min: 1, max: 4096 },
  { key: 'initial.plants', type: 'integer', required: true, min: 0, max: 1000000 },
  { key: 'name', type: 'string', default: 'x' },
  { key: 'climate.equator_temperature', type: 'number', min: -50, max: 60, default: 28 },
  { key: 'climate.pole_temperature', type: 'number', min: -80, max: 40, default: -20 },
  { key: 'climate.weather_enabled', type: 'boolean', default: true },
  { key: 'plants.mutation_rate', type: 'number', min: 0, max: 1, default: 0.05 },
];
const spec = (k) => P.find((p) => p.key === k);

test('validateField: types, ranges, required, u64 seed', () => {
  const w = spec('world.width'), m = spec('plants.mutation_rate'), seed = spec('seed');
  assert.strictEqual(S.validateField(w, '64'), null);
  assert.match(S.validateField(w, '0'), /between 1 and 4096/);
  assert.match(S.validateField(w, '12.5'), /whole number/);
  assert.match(S.validateField(w, 'abc'), /whole number/);
  assert.strictEqual(S.validateField(w, ''), 'required');
  assert.strictEqual(S.validateField(m, '0.25'), null);
  assert.strictEqual(S.validateField(m, '1e-3'), null);
  assert.match(S.validateField(m, '2'), /between 0 and 1/);
  assert.match(S.validateField(m, '1,5'), /number/);
  assert.match(S.validateField(m, ''), /enter a value/);
  assert.strictEqual(S.validateField(spec('climate.weather_enabled'), false), null);
  assert.ok(S.validateField(spec('climate.weather_enabled'), 'yes'));
  assert.strictEqual(S.validateField(seed, '18446744073709551615'), null);
  assert.match(S.validateField(seed, '18446744073709551616'), /at most/);
  assert.match(S.validateField(seed, '-1'), /whole number/);
  assert.strictEqual(S.validateField(seed, '0'), null);
});

test('validateForm collects every error and the UI guards', () => {
  const f = { seed: '1', 'world.width': '0', 'world.height': 'x', 'initial.plants': '5', name: 'n', 'climate.equator_temperature': '10', 'climate.pole_temperature': '20', 'climate.weather_enabled': true, 'plants.mutation_rate': '3' };
  const e = S.validateForm(f, P, 1048576);
  assert.deepStrictEqual(Object.keys(e).sort(), ['climate.pole_temperature', 'plants.mutation_rate', 'world.height', 'world.width']);
  const big = Object.assign({}, f, { 'world.width': '4096', 'world.height': '4096', 'climate.pole_temperature': '-5', 'plants.mutation_rate': '0.1' });
  assert.deepStrictEqual(Object.keys(S.validateForm(big, P, 1048576)), ['world.width']);
});

test('form ↔ config round trip keeps every value and a full u64 seed exactly', () => {
  const cfg = { seed: 0, name: 'lush', world: { width: 96, height: 64 }, initial: { plants: 900 },
    climate: { equator_temperature: 28.5, pole_temperature: -10, weather_enabled: false }, plants: { mutation_rate: 0.123 } };
  const form = S.formFromConfig(cfg, '18446744073709551615', P);
  assert.strictEqual(form.seed, '18446744073709551615');
  assert.strictEqual(form['world.width'], '96');
  assert.strictEqual(form['climate.weather_enabled'], false);
  const text = S.buildConfigText(form, P);
  assert.match(text, /"seed": 18446744073709551615[,\n]/);
  const back = JSON.parse(text);
  delete back.seed; const exp = Object.assign({}, cfg); delete exp.seed;
  assert.deepStrictEqual(back, exp);
  // import of the exported text gives the same form
  assert.deepStrictEqual(S.formFromText(text, P), form);
  assert.strictEqual(S.formFromText('{bad', P), null);
  // missing optional keys fall back to defaults
  assert.strictEqual(S.formFromConfig({ seed: 1, world: {}, initial: {} }, null, P)['plants.mutation_rate'], '0.05');
});

test('server errors map to fields; unknown keys go to the document error', () => {
  const m = S.errorsByKey([{ key: 'world.width', message: 'must be between 1 and 4096' }, { key: 'plants.bogus', message: 'unknown parameter' }], P);
  assert.strictEqual(m['world.width'], 'must be between 1 and 4096');
  assert.match(m['<json>'], /plants\.bogus: unknown parameter/);
  assert.strictEqual(S.fieldLabel('plants.mutation_rate'), 'Mutation rate');
  assert.ok(/^\d+$/.test(S.randomSeedText(() => 0.5)));
  assert.strictEqual(S.cmpDigits('009', '10'), -1);
});

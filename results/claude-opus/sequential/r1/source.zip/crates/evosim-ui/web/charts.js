// Evolution Simulation — live charts (ADR-028 §1). Own Canvas 2D code, no library.
// Pure helpers are exported for `node --test`; drawing functions only need a 2D context.
'use strict';

const CHART_KINDS = ['plants', 'herbivores', 'carnivores'];
const KIND_NAMES = ['Plants', 'Herbivores', 'Carnivores'];
const KIND_COLORS = ['#5ec27a', '#e8d68a', '#ff6b5b'];
const TRAITS = ['speed', 'strength', 'fertility', 'max_health', 'max_lifespan', 'max_energy', 'vision', 'aggression', 'caution', 'temp_optimum', 'temp_tolerance'];
const TRAIT_LABELS = {
  speed: 'Speed (cells/tick)', strength: 'Strength', fertility: 'Fertility', max_health: 'Max health', max_lifespan: 'Max lifespan (ticks)',
  max_energy: 'Max energy', vision: 'Vision (cells)', aggression: 'Aggression', caution: 'Caution', temp_optimum: 'Temperature optimum (°C)',
  temp_tolerance: 'Temperature tolerance (°C)',
};
function traitLabel(t) { return TRAIT_LABELS[t] || String(t).replace(/_/g, ' '); }

// ---------- axis ticks ----------
function niceStep(range, n) {
  const raw = range / Math.max(1, n);
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / p;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p;
}
// "nice" ticks covering [min, max] (returns {min, max, step, ticks})
function niceTicks(min, max, n) {
  n = n || 5;
  if (!Number.isFinite(min) || !Number.isFinite(max)) { min = 0; max = 1; }
  if (max < min) { const t = min; min = max; max = t; }
  if (max === min) { const d = Math.abs(min) > 0 ? Math.abs(min) * 0.1 : 1; min -= d; max += d; }
  const step = niceStep(max - min, n);
  const lo = Math.floor(min / step + 1e-9) * step, hi = Math.ceil(max / step - 1e-9) * step;
  const ticks = [];
  for (let v = lo, i = 0; v <= hi + step * 1e-6 && i < 100; v = lo + step * ++i) ticks.push(Math.abs(v) < step * 1e-9 ? 0 : +v.toPrecision(12));
  return { min: lo, max: hi, step, ticks };
}
// symmetric-log ticks for y = log10(1 + v): 0, 1, 10, 100, … covering max
function logTicks(max) {
  const top = Math.max(1, Math.ceil(Math.log10(Math.max(1, max)) - 1e-9));
  const ticks = [0];
  for (let e = 0; e <= top; e++) ticks.push(Math.pow(10, e));
  return { min: 0, max: ticks[ticks.length - 1], ticks };
}
function logPos(v) { return Math.log10(1 + Math.max(0, v)); }
function fmtTick(v) {
  const a = Math.abs(v);
  if (a >= 1e6) return (v / 1e6).toFixed(a >= 1e7 ? 0 : 1) + 'M';
  if (a >= 1e4) return (v / 1e3).toFixed(0) + 'k';
  if (a >= 1000) return (v / 1e3).toFixed(1).replace(/\.0$/, '') + 'k';
  if (a === 0) return '0';
  if (a < 0.01) return v.toExponential(0);
  return String(+v.toPrecision(3));
}

// ---------- chart data state (incremental /api/charts replies) ----------
function emptyChartState() { return { epoch: null, version: null, stride: 1, points: [], live: null }; }
function mergeChartData(state, reply) {
  if (!reply || reply.ok === false) return state;
  const reset = reply.full || state.epoch !== reply.epoch || state.version !== reply.version;
  let points = reset ? [] : state.points.slice();
  const last = points.length ? points[points.length - 1].tick : -1;
  for (const p of reply.points || []) if (p.tick > last || reset) points.push(p);
  points.sort((a, b) => a.tick - b.tick);
  points = points.filter((p, i) => i === 0 || p.tick !== points[i - 1].tick);
  return { epoch: reply.epoch, version: reply.version, stride: reply.stride || 1, points, live: reply.live || null };
}
// query string for the next incremental request
function chartQuery(state) {
  if (state.version === null || !state.points.length) return '';
  return `?v=${state.version}&since=${state.points[state.points.length - 1].tick}`;
}
function allPoints(state) {
  return state.live ? state.points.concat([state.live]) : state.points;
}

// ---------- chart specifications ----------
const CHART_SPECS = {
  population: { title: 'Population by kind', xLabel: 'Tick', yLabel: 'Individuals (log scale)', log: true },
  births: { title: 'Births and deaths', xLabel: 'Tick', yLabel: 'Events / 100 ticks (log)', log: true },
  species: { title: 'Living species', xLabel: 'Tick', yLabel: 'Species' },
  trait: { title: 'Mean trait over time', xLabel: 'Tick', yLabel: 'Trait value (mean ± sd)' },
  histogram: { title: 'Trait distribution', xLabel: 'Trait value', yLabel: 'Individuals' },
};
// series for a line chart: {title, xLabel, yLabel, log, series:[{name, color, dash, points:[[x,y|null]], band}]}
function buildSeries(id, state, opts) {
  opts = opts || {};
  const spec = Object.assign({}, CHART_SPECS[id]);
  const pts = allPoints(state);
  const col = (f) => pts.map((p) => [p.tick, f(p)]);
  if (id === 'population') {
    spec.series = CHART_KINDS.map((k, i) => ({ name: KIND_NAMES[i], color: KIND_COLORS[i], points: col((p) => p.kinds[i].count) }));
  } else if (id === 'births') {
    spec.series = [];
    CHART_KINDS.forEach((k, i) => {
      spec.series.push({ name: `${KIND_NAMES[i]} births`, color: KIND_COLORS[i], points: windowRates(pts, i, 'births_total', opts.window) });
      spec.series.push({ name: `${KIND_NAMES[i]} deaths`, color: KIND_COLORS[i], dash: [4, 3], points: windowRates(pts, i, 'deaths_total', opts.window) });
    });
    // compact legend: colour = kind, line style = births / deaths
    spec.legend = KIND_NAMES.map((n, i) => ({ name: n, color: KIND_COLORS[i] }))
      .concat([{ name: 'births', color: '#c9d4df' }, { name: 'deaths', color: '#c9d4df', dash: [4, 3] }]);
  } else if (id === 'species') {
    spec.series = CHART_KINDS.map((k, i) => ({ name: KIND_NAMES[i], color: KIND_COLORS[i], points: col((p) => p.kinds[i].species) }));
  } else if (id === 'trait') {
    const t = Math.max(0, TRAITS.indexOf(opts.trait || 'speed'));
    const kinds = opts.kind === 'all' || !opts.kind ? [0, 1, 2] : [Math.max(0, CHART_KINDS.indexOf(opts.kind))];
    spec.title = `Mean ${traitLabel(TRAITS[t]).replace(/ \(.*\)$/, '').toLowerCase()} over time`;
    spec.yLabel = `${traitLabel(TRAITS[t])}, mean ± sd`;
    spec.series = kinds.map((i) => ({
      name: KIND_NAMES[i], color: KIND_COLORS[i], points: col((p) => p.kinds[i].mean[t]),
      band: kinds.length === 1 ? pts.map((p) => { const m = p.kinds[i].mean[t], s = p.kinds[i].sd[t]; return m === null || s === null ? null : [p.tick, m - s, m + s]; }) : null,
    }));
    if (kinds.length === 1) spec.legendExtra = '± 1 sd';
  }
  return spec;
}
// events per RATE ticks over a trailing window (≥ `window` ticks) from cumulative totals
const RATE_TICKS = 100;
function windowRates(pts, kind, field, window) {
  window = window || 25;
  const out = []; let j = 0;
  for (let i = 0; i < pts.length; i++) {
    while (j < i - 1 && pts[i].tick - pts[j + 1].tick >= window) j++;
    const dt = pts[i].tick - pts[j].tick;
    out.push([pts[i].tick, i === 0 || dt <= 0 ? null : (pts[i].kinds[kind][field] - pts[j].kinds[kind][field]) * RATE_TICKS / dt]);
  }
  return out;
}
function seriesBounds(spec) {
  let xmin = Infinity, xmax = -Infinity, ymin = Infinity, ymax = -Infinity;
  for (const s of spec.series) {
    for (const [x, y] of s.points) {
      if (x < xmin) xmin = x; if (x > xmax) xmax = x;
      if (y === null || y === undefined || !Number.isFinite(y)) continue;
      
      if (y < ymin) ymin = y; if (y > ymax) ymax = y;
    }
    for (const b of s.band || []) if (b) { ymin = Math.min(ymin, b[1]); ymax = Math.max(ymax, b[2]); }
  }
  if (!Number.isFinite(xmin)) { xmin = 0; xmax = 1; }
  if (xmax === xmin) xmax = xmin + 1;
  if (!Number.isFinite(ymin)) { ymin = 0; ymax = 1; }
  if (!spec.log && ymin > 0 && (id0(spec) || ymin < ymax * 0.5)) ymin = 0;
  return { xmin, xmax, ymin, ymax };
}
function id0(spec) { return spec.yLabel === CHART_SPECS.species.yLabel; }

// ---------- histogram geometry ----------
// bars in a plot box {x, y, w, h}: [{x, y, w, h, count, lo, hi}]
function histogramBars(h, box) {
  const counts = (h && h.counts) || [];
  const max = Math.max(1, ...counts);
  const bw = counts.length ? box.w / counts.length : 0;
  return counts.map((c, i) => {
    const bh = (c / max) * box.h;
    return { x: box.x + i * bw, y: box.y + box.h - bh, w: bw, h: bh, count: c, lo: h.edges[i], hi: h.edges[i + 1] };
  });
}

// ---------- drawing ----------
const THEME = { bg: '#141b23', grid: 'rgba(255,255,255,0.07)', axis: '#3a4858', text: '#c9d4df', muted: '#8b98a7', font: '11px Inter, "Segoe UI", system-ui, sans-serif' };
const PAD = { l: 52, r: 12, t: 26, b: 50 };

// legend rows needed for `entries` in a plot of width w
function legendRows(ctx, entries, w) {
  ctx.font = THEME.font;
  const items = legendLayout(entries, PAD.l, w - PAD.r, 0, (s) => ctx.measureText(s).width);
  return items.length ? items[items.length - 1].y / 14 + 1 : 0;
}
function prepare(ctx, w, h, title, entries) {
  ctx.fillStyle = THEME.bg; ctx.fillRect(0, 0, w, h);
  ctx.font = '600 12px Inter, "Segoe UI", system-ui, sans-serif'; ctx.fillStyle = THEME.text; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillText(title.length > 60 ? title.slice(0, 59) + '…' : title, 10, 16);
  const rows = legendRows(ctx, entries || [], w);
  ctx.font = THEME.font;
  const b = PAD.b - 14 + rows * 14;
  return { x: PAD.l, y: PAD.t, w: Math.max(10, w - PAD.l - PAD.r), h: Math.max(10, h - PAD.t - b) };
}
function axes(ctx, box, xt, yt, xs, ys, xLabel, yLabel) {
  ctx.strokeStyle = THEME.grid; ctx.lineWidth = 1; ctx.beginPath();
  for (const v of yt) { const y = Math.round(ys(v)) + 0.5; ctx.moveTo(box.x, y); ctx.lineTo(box.x + box.w, y); }
  ctx.stroke();
  ctx.strokeStyle = THEME.axis; ctx.beginPath(); ctx.moveTo(box.x + 0.5, box.y); ctx.lineTo(box.x + 0.5, box.y + box.h + 0.5); ctx.lineTo(box.x + box.w, box.y + box.h + 0.5); ctx.stroke();
  ctx.fillStyle = THEME.muted; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
  for (const v of yt) ctx.fillText(fmtTick(v), box.x - 5, ys(v));
  ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  let lastX = -1e9;
  for (const v of xt) { const x = xs(v); if (x - lastX < 34) continue; ctx.fillText(fmtTick(v), x, box.y + box.h + 4); lastX = x; }
  // axis titles
  ctx.fillStyle = THEME.text; ctx.textBaseline = 'alphabetic';
  ctx.fillText(xLabel, box.x + box.w / 2, box.y + box.h + 31);
  ctx.save(); ctx.translate(13, box.y + box.h / 2); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillText(yLabel.length > 34 ? yLabel.slice(0, 33) + '…' : yLabel, 0, 0); ctx.restore();
}
// legend entries laid out in rows below the x-axis title
function legendLayout(entries, x0, x1, y0, measure) {
  const out = []; let x = x0, y = y0;
  for (const e of entries) {
    const w = 18 + measure(e.name) + 12;
    if (x + w > x1 && x > x0) { x = x0; y += 14; }
    out.push(Object.assign({ x, y }, e)); x += w;
  }
  return out;
}
function drawLegend(ctx, entries, box, h) {
  ctx.font = THEME.font;
  const items = legendLayout(entries, box.x, box.x + box.w, box.y + box.h + 44, (s) => ctx.measureText(s).width);
  const shift = 0;
  ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.font = THEME.font;
  for (const it of items) {
    const y = it.y - shift;
    ctx.strokeStyle = it.color; ctx.fillStyle = it.color; ctx.lineWidth = 2; ctx.setLineDash(it.dash || []);
    if (it.bar) ctx.fillRect(it.x, y - 4, 12, 8); else { ctx.beginPath(); ctx.moveTo(it.x, y); ctx.lineTo(it.x + 14, y); ctx.stroke(); }
    ctx.setLineDash([]); ctx.fillStyle = THEME.text; ctx.fillText(it.name, it.x + 18, y);
  }
}
function lineEntries(spec) {
  if (spec.legend) return spec.legend;
  const entries = spec.series.map((s) => ({ name: s.name, color: s.color, dash: s.dash }));
  if (spec.legendExtra && spec.series[0]) entries.push({ name: spec.legendExtra, color: spec.series[0].color + '55', bar: true });
  return entries;
}
function drawLineChart(ctx, spec, w, h) {
  const entries = lineEntries(spec);
  const box = prepare(ctx, w, h, spec.title, entries);
  const b = seriesBounds(spec);
  const xt = niceTicks(b.xmin, b.xmax, Math.max(2, Math.floor(box.w / 70)));
  const yt = spec.log ? logTicks(b.ymax) : niceTicks(b.ymin, b.ymax, Math.max(2, Math.floor(box.h / 34)));
  const xs = (v) => box.x + ((v - b.xmin) / (b.xmax - b.xmin)) * box.w;
  const ys = spec.log
    ? (v) => box.y + box.h - (logPos(v) / logPos(yt.max)) * box.h
    : (v) => box.y + box.h - ((v - yt.min) / (yt.max - yt.min)) * box.h;
  axes(ctx, box, xt.ticks.filter((v) => v >= b.xmin && v <= b.xmax), yt.ticks, xs, ys, spec.xLabel, spec.yLabel);
  ctx.save(); ctx.beginPath(); ctx.rect(box.x, box.y - 2, box.w + 2, box.h + 4); ctx.clip();
  for (const s of spec.series) {
    if (s.band) { // ±sd band, split at gaps
      ctx.fillStyle = s.color + '26';
      let run = [];
      const flush = () => {
        if (run.length > 1) { ctx.beginPath(); run.forEach((p, i) => (i ? ctx.lineTo(xs(p[0]), ys(p[2])) : ctx.moveTo(xs(p[0]), ys(p[2])))); for (let i = run.length - 1; i >= 0; i--) ctx.lineTo(xs(run[i][0]), ys(run[i][1])); ctx.closePath(); ctx.fill(); }
        run = [];
      };
      for (const p of s.band) { if (p) run.push(p); else flush(); }
      flush();
    }
    ctx.strokeStyle = s.color; ctx.lineWidth = 1.8; ctx.setLineDash(s.dash || []); ctx.lineJoin = 'round';
    ctx.beginPath(); let pen = false;
    for (const [x, y] of s.points) {
      if (y === null || y === undefined || !Number.isFinite(y) || false) { pen = false; continue; }
      if (pen) ctx.lineTo(xs(x), ys(y)); else { ctx.moveTo(xs(x), ys(y)); pen = true; }
    }
    ctx.stroke(); ctx.setLineDash([]);
  }
  ctx.restore();
  drawLegend(ctx, entries, box, h);
  return { box, bounds: b };
}
function drawHistogram(ctx, hdata, w, h, opts) {
  opts = opts || {};
  const k = Math.max(0, CHART_KINDS.indexOf(hdata && hdata.kind));
  const title = hdata ? `Distribution of ${traitLabel(hdata.trait).replace(/ \(.*\)$/, '').toLowerCase()} · ${KIND_NAMES[k].toLowerCase()} (n=${hdata.n})` : CHART_SPECS.histogram.title;
  const entries = [{ name: `${KIND_NAMES[k]} (count per bin)`, color: KIND_COLORS[k], bar: true }, { name: 'mean', color: '#ffffff', dash: [5, 3] }];
  const box = prepare(ctx, w, h, title, entries);
  if (!hdata) return { box };
  const edges = hdata.edges, lo = edges[0], hi = edges[edges.length - 1];
  const maxc = Math.max(1, ...hdata.counts);
  const yt = niceTicks(0, maxc, Math.max(2, Math.floor(box.h / 34)));
  const xt = niceTicks(lo, hi, Math.max(2, Math.floor(box.w / 70)));
  const xs = (v) => box.x + ((v - lo) / (hi - lo || 1)) * box.w;
  const ys = (v) => box.y + box.h - (v / yt.max) * box.h;
  axes(ctx, box, xt.ticks.filter((v) => v >= lo - 1e-9 && v <= hi + 1e-9), yt.ticks, xs, ys, traitLabel(hdata.trait), CHART_SPECS.histogram.yLabel);
  const bars = histogramBars({ counts: hdata.counts, edges }, { x: box.x, y: ys(maxc), w: box.w, h: box.y + box.h - ys(maxc) });
  ctx.fillStyle = KIND_COLORS[k];
  for (const r of bars) if (r.count > 0) ctx.fillRect(r.x + 1, r.y, Math.max(1, r.w - 2), r.h);
  if (hdata.mean !== null && hdata.mean !== undefined) {
    const x = xs(hdata.mean);
    ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 3]); ctx.beginPath(); ctx.moveTo(x, box.y); ctx.lineTo(x, box.y + box.h); ctx.stroke(); ctx.setLineDash([]);
    entries[1].name = `mean ${fmtTick(hdata.mean)}`;
  } else {
    ctx.fillStyle = THEME.muted; ctx.textAlign = 'center'; ctx.fillText('no living individuals', box.x + box.w / 2, box.y + box.h / 2);
  }
  drawLegend(ctx, entries, box, h);
  return { box, bars };
}

const ChartsLib = { CHART_KINDS, KIND_NAMES, KIND_COLORS, TRAITS, TRAIT_LABELS, CHART_SPECS, traitLabel, niceTicks, logTicks, fmtTick,
  logPos, legendRows, lineEntries, windowRates, emptyChartState, mergeChartData, chartQuery, allPoints, buildSeries, seriesBounds, histogramBars, legendLayout, drawLineChart, drawHistogram };
if (typeof module !== 'undefined') module.exports = ChartsLib;
if (typeof window !== 'undefined') window.ChartsLib = ChartsLib;

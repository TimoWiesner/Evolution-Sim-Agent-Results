// Evolution Simulation — world view (ADR-026). Vanilla JS, Canvas 2D.
'use strict';

// ---------- pure camera math (unit-tested with node --test) ----------
const MIN_SCALE_ABS = 1, MAX_SCALE = 64;
function wrapMod(a, n) { return ((a % n) + n) % n; }
function worldToScreen(cam, wx, wy, vw, vh) {
  return [(wx - cam.cx) * cam.scale + vw / 2, (wy - cam.cy) * cam.scale + vh / 2];
}
function screenToWorld(cam, sx, sy, vw, vh) {
  return [(sx - vw / 2) / cam.scale + cam.cx, (sy - vh / 2) / cam.scale + cam.cy];
}
function clampScale(s, minScale) { return Math.max(minScale, Math.min(MAX_SCALE, s)); }
function zoomAt(cam, sx, sy, factor, vw, vh, minScale) {
  const [wx, wy] = screenToWorld(cam, sx, sy, vw, vh);
  const scale = clampScale(cam.scale * factor, minScale === undefined ? MIN_SCALE_ABS : minScale);
  // keep (wx, wy) under the cursor
  return { scale, cx: wx - (sx - vw / 2) / scale, cy: wy - (sy - vh / 2) / scale };
}
function fitCamera(W, H, vw, vh) {
  const scale = clampScale(Math.min(vw / W, vh / H), MIN_SCALE_ABS);
  return { cx: W / 2, cy: H / 2, scale };
}
function pan(cam, dx, dy, W, H) {
  return { scale: cam.scale, cx: wrapMod(cam.cx - dx / cam.scale, W), cy: wrapMod(cam.cy - dy / cam.scale, H) };
}
// world-tile offsets (multiples of W) visible in [x0, x1]
function tileOffsets(cam, vw, W) {
  const x0 = cam.cx - vw / 2 / cam.scale, x1 = cam.cx + vw / 2 / cam.scale;
  const out = [];
  for (let k = Math.floor(x0 / W); k <= Math.floor(x1 / W); k++) out.push(k * W);
  return out;
}
function decodeFrame(buf) {
  const dv = new DataView(buf);
  const magic = String.fromCharCode(dv.getUint8(0), dv.getUint8(1), dv.getUint8(2), dv.getUint8(3));
  if (magic !== 'EVF1') throw new Error('bad frame magic');
  const len = dv.getUint32(4, true);
  const meta = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 8, len)));
  const n = (buf.byteLength - 8 - len) / 6;
  const recs = new Uint8Array(buf, 8 + len);
  return { meta, n, recs };
}
const SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter'];
function seasonName(phase) { return SEASONS[Math.floor(wrapMod(phase, 1) * 4) % 4]; }

// ---------- pure control / inspector helpers (TASK-024, node-tested) ----------
function clampSpeedIndex(i, n) { i = Math.trunc(Number(i)); if (!Number.isFinite(i)) i = 0; return Math.max(0, Math.min(n - 1, i)); }
function speedLabel(speed) { return speed ? speed.label : '–'; }
// pointerdown→pointerup moved less than 4 px = click (select), else drag (pan)
function isClick(dx, dy) { return dx * dx + dy * dy < 16; }
// keyboard shortcut → control command (null = not a control key)
function keyToCommand(key, ctrl, inInput) {
  if (ctrl && (key === 's' || key === 'S')) return { cmd: 'save' };
  if (inInput || ctrl) return null;
  switch (key) {
    case ' ': return { cmd: 'toggle' };
    case '.': case 'n': case 'N': return { cmd: 'step' };
    case 'r': case 'R': return { cmd: 'reset' };
    case '[': return { cmd: 'slower' };
    case ']': return { cmd: 'faster' };
    case 'Escape': return { cmd: 'deselect' };
    case 'f': case 'F': return { cmd: 'follow' };
    case 'w': case 'W': return { cmd: 'newworld' };
    case 'c': case 'C': return { cmd: 'charts' };
    default: return null;
  }
}
const GENE_GROUPS = {
  body: { color: '#e0a458', label: 'body', targets: ['strength', 'maxhealth', 'lifespan', 'maxenergy'] },
  repro: { color: '#e070b0', label: 'reproduction', targets: ['fertility'] },
  climate: { color: '#5fa8e8', label: 'climate', targets: ['tempoptimum', 'temptolerance'] },
  behaviour: { color: '#9d7fe8', label: 'movement/behaviour', targets: ['speed', 'vision', 'aggression', 'caution'] },
  neutral: { color: '#6b7684', label: 'neutral marker', targets: [] },
};
function geneGroup(target) {
  for (const k of Object.keys(GENE_GROUPS)) if (GENE_GROUPS[k].targets.includes(target)) return k;
  return 'neutral';
}
// one bar per locus: height = value (0..1), founder tick mark, colour = trait group
function genomeBars(genome, width, height) {
  const n = genome.length, gap = n > 40 ? 0 : 1, w = n ? (width - gap * (n - 1)) / n : 0;
  return genome.map((g, i) => {
    const v = Math.max(0, Math.min(1, Number(g.value) || 0));
    const f = g.founder === null || g.founder === undefined ? null : Math.max(0, Math.min(1, g.founder));
    const group = geneGroup(g.target);
    return { x: i * (w + gap), w, h: v * height, y: height - v * height, founderY: f === null ? null : height - f * height,
      color: GENE_GROUPS[group].color, group, name: g.name, value: v };
  });
}
function fmtNum(v, d) { return typeof v === 'number' ? (Math.abs(v) >= 1000 ? Math.round(v).toLocaleString('en') : v.toFixed(d === undefined ? 2 : d)) : String(v); }
const CAUSES = { old_age: 'old age', starvation: 'starvation', injury: 'injury', predation: 'predation', grazed: 'grazed', climate: 'climate stress', unknown: 'unknown cause' };
// inspector content (text only, no DOM): header, death banner, stat rows, trait rows, parents
function formatInspector(sel) {
  if (!sel) return null;
  const sp = sel.species || {};
  const rows = [
    ['ID', '#' + sel.id], ['Kind', sel.kind], ['Species', `${sp.code || '?'} ${sp.name ? '“' + sp.name + '”' : ''}`.trim()],
    ['Age', `${sel.age} ticks`], ['Generation', String(sel.generation)], ['Born', `tick ${sel.birth_tick}`],
    ['Position', `(${sel.pos.x}, ${sel.pos.y})`],
    ['Energy', `${fmtNum(sel.energy, 1)} / ${fmtNum(sel.max_energy, 1)}`], ['Health', `${fmtNum(sel.health, 1)} / ${fmtNum(sel.max_health, 1)}`],
  ];
  if (sel.kind !== 'plant') rows.push(['Mating cooldown', String(sel.cooldown)]);
  const traits = (sel.traits || []).map((t) => ({ name: t.name.replace(/_/g, ' '), value: fmtNum(t.value), frac: t.max > t.min ? (t.value - t.min) / (t.max - t.min) : 0 }));
  const parents = (sel.parents || []).map((p) => ({ id: p.id, alive: p.alive, text: `#${p.id}${p.species_code ? ' ' + p.species_code : ''}${p.alive ? '' : ' †'}` }));
  const death = sel.alive === false && sel.death ? `† Died at tick ${sel.death.tick} (${CAUSES[sel.death.cause] || sel.death.cause}), age ${sel.death.age}` : null;
  return { title: `${sel.kind[0].toUpperCase()}${sel.kind.slice(1)} #${sel.id}`, species: sp.code || '', rows, traits, parents,
    parentsText: parents.length ? parents.map((p) => p.text).join(', ') : 'founder (no parents)', death, genomeLen: (sel.genome || []).length };
}

if (typeof module !== 'undefined') {
  module.exports = { wrapMod, worldToScreen, screenToWorld, zoomAt, fitCamera, pan, tileOffsets, clampScale, seasonName, MAX_SCALE,
    clampSpeedIndex, speedLabel, isClick, keyToCommand, genomeBars, geneGroup, formatInspector };
}

// ---------- organism symbols (shared by map and legend) ----------
const KIND = [
  { name: 'Plants', key: 'plants', fill: ['#2f7d3a', '#43a64f', '#6fdc6a'], stroke: '#0b2410', desc: 'green square' },
  { name: 'Herbivores', key: 'herbivores', fill: ['#b9a86a', '#e8d68a', '#fff3b8'], stroke: '#2b2410', desc: 'cream circle' },
  { name: 'Carnivores', key: 'carnivores', fill: ['#9c2a2a', '#e04848', '#ff7b6b'], stroke: '#ffffff', desc: 'red triangle' },
];
function symbolSize(kind, scale) {
  if (kind === 0) return Math.max(1.6, scale * 0.6);
  if (kind === 1) return Math.max(2.4, scale * 0.42);
  return Math.max(3.0, scale * 0.55);
}
function addShape(ctx, kind, x, y, r) {
  if (kind === 0) { ctx.rect(x - r / 2, y - r / 2, r, r); }
  else if (kind === 1) { ctx.moveTo(x + r, y); ctx.arc(x, y, r, 0, Math.PI * 2); }
  else { ctx.moveTo(x, y - r); ctx.lineTo(x + r * 0.95, y + r * 0.75); ctx.lineTo(x - r * 0.95, y + r * 0.75); ctx.closePath(); }
}
function drawSymbol(ctx, kind, x, y, r, level) {
  ctx.beginPath(); addShape(ctx, kind, x, y, r);
  ctx.fillStyle = KIND[kind].fill[level === undefined ? 1 : level]; ctx.fill();
  ctx.lineWidth = 1; ctx.strokeStyle = KIND[kind].stroke; ctx.stroke();
}

if (typeof document !== 'undefined') (function main() {
  const params = new URLSearchParams(location.search);
  const autotest = params.get('autotest');
  // Headless --screenshot captures the full window size while innerHeight is
  // smaller; stretch the page to the screen size so the PNG has no empty band.
  const forcedH = parseInt(params.get('h'), 10);
  // (TASK-025) headless chromium paints only innerHeight (~813 px) even though the PNG is
  // forcedH tall, so stretching the page clipped the chart dock; the layout now fits innerHeight.
  void forcedH;
  const $ = (id) => document.getElementById(id);
  const canvas = $('world'), ctx = canvas.getContext('2d');
  let world = null, terrain = null, frame = null, cam = null, dirty = true;
  let vw = 0, vh = 0, dpr = 1, inflight = false, frozen = false;
  let framesDrawn = 0, firstTick = null, drawMsSum = 0, reported = false;
  const t0 = performance.now();
  let fpsCount = 0, fpsT = performance.now(), fps = 0;
  let inspected = false;
  let follow = false, frameKey = '', inspectKey = '', worldEpoch = 0, pickRequested = false;
  const inspectShot = autotest === 'shots' && params.get('inspect') === '1';

  function resize() {
    dpr = window.devicePixelRatio || 1;
    const r = canvas.getBoundingClientRect();
    vw = r.width; vh = r.height;
    canvas.width = Math.round(vw * dpr); canvas.height = Math.round(vh * dpr);
    if (world && !cam) cam = fitCamera(world.width, world.height, vw, vh);
    dirty = true;
  }
  function minScale() { return world ? Math.max(MIN_SCALE_ABS, Math.min(vw / world.width, vh / world.height) * 0.5) : 1; }

  function buildTerrain() {
    const bytes = Uint8Array.from(atob(world.cells), (c) => c.charCodeAt(0));
    terrain = document.createElement('canvas');
    terrain.width = world.width; terrain.height = world.height;
    const tctx = terrain.getContext('2d');
    const img = tctx.createImageData(world.width, world.height);
    const pal = world.biomes.map((b) => b.rgb.map((v) => Math.round(v * 0.72 + 10)));
    for (let i = 0; i < bytes.length; i++) {
      const c = pal[bytes[i]] || [0, 0, 0];
      // subtle checker shading so single cells are readable when zoomed in
      const x = i % world.width, y = (i / world.width) | 0;
      const s = ((x + y) & 1) ? 0 : 6;
      img.data[i * 4] = c[0] + s; img.data[i * 4 + 1] = c[1] + s; img.data[i * 4 + 2] = c[2] + s; img.data[i * 4 + 3] = 255;
    }
    tctx.putImageData(img, 0, 0);
    world.grid = bytes;
  }

  function buildLegend() {
    const org = $('legend-org');
    KIND.forEach((k, i) => {
      const li = document.createElement('li');
      const c = document.createElement('canvas'); c.className = 'sym'; c.width = 16; c.height = 16; c.dataset.kind = i;
      li.appendChild(c);
      li.appendChild(document.createTextNode(k.name));
      const d = document.createElement('span'); d.className = 'desc'; d.textContent = k.desc + ', brighter = more energy'; li.appendChild(d);
      org.appendChild(li);
    });
    const bl = $('legend-biome');
    world.biomes.forEach((b) => {
      const li = document.createElement('li');
      const sw = document.createElement('span'); sw.className = 'swatch';
      sw.style.background = `rgb(${b.rgb.map((v) => Math.round(v * 0.72 + 10)).join(',')})`;
      li.appendChild(sw); li.appendChild(document.createTextNode(b.name));
      const d = document.createElement('span'); d.className = 'desc'; d.textContent = b.rule; li.appendChild(d);
      bl.appendChild(li);
    });
    document.querySelectorAll('canvas.sym').forEach((c) => {
      const g = c.getContext('2d'); g.clearRect(0, 0, 16, 16);
      const k = +c.dataset.kind; drawSymbol(g, k, 8, 8.5, k === 0 ? 9 : 6, 2);
    });
    $('worldname').textContent = `· ${world.name} · ${world.width}×${world.height} · seed ${world.seed}`;
  }

  function draw() {
    const ts = performance.now();
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = '#0a0e12'; ctx.fillRect(0, 0, vw, vh);
    if (!world || !cam) return;
    const W = world.width, H = world.height, s = cam.scale;
    const xs = tileOffsets(cam, vw, W);
    const ys = tileOffsets({ cx: cam.cy, scale: s }, vh, H);
    ctx.imageSmoothingEnabled = false;
    for (const ox of xs) for (const oy of ys) {
      const [sx, sy] = worldToScreen(cam, ox, oy, vw, vh);
      ctx.drawImage(terrain, sx, sy, W * s, H * s);
    }
    if (s >= 10) { // grid lines when zoomed in
      ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 1; ctx.beginPath();
      const [wx0, wy0] = screenToWorld(cam, 0, 0, vw, vh);
      for (let x = Math.floor(wx0); x <= wx0 + vw / s + 1; x++) { const px = Math.round((x - cam.cx) * s + vw / 2) + 0.5; ctx.moveTo(px, 0); ctx.lineTo(px, vh); }
      for (let y = Math.floor(wy0); y <= wy0 + vh / s + 1; y++) { const py = Math.round((y - cam.cy) * s + vh / 2) + 0.5; ctx.moveTo(0, py); ctx.lineTo(vw, py); }
      ctx.stroke();
    }
    if (frame) {
      const { n, recs } = frame;
      for (let kind = 0; kind < 3; kind++) {
        const r = symbolSize(kind, s);
        for (let lvl = 0; lvl < 3; lvl++) {
          ctx.beginPath();
          let any = false;
          for (let i = 0; i < n; i++) {
            const o = i * 6;
            if (recs[o + 4] !== kind) continue;
            const e = recs[o + 5];
            if ((e < 85 ? 0 : e < 170 ? 1 : 2) !== lvl) continue;
            const wx = recs[o] | (recs[o + 1] << 8), wy = recs[o + 2] | (recs[o + 3] << 8);
            for (const ox of xs) for (const oy of ys) {
              const px = (wx + 0.5 + ox - cam.cx) * s + vw / 2, py = (wy + 0.5 + oy - cam.cy) * s + vh / 2;
              if (px < -r || py < -r || px > vw + r || py > vh + r) continue;
              addShape(ctx, kind, px, py, r); any = true;
            }
          }
          if (!any) continue;
          ctx.fillStyle = KIND[kind].fill[lvl]; ctx.fill();
          if (kind > 0 || s >= 4) { ctx.lineWidth = kind === 2 ? 1.2 : 1; ctx.strokeStyle = KIND[kind].stroke; ctx.stroke(); }
        }
      }
    }
    drawSelection(xs, ys);
    drawMsSum += performance.now() - ts;
    $('zoomlabel').textContent = `Zoom ${s.toFixed(1)} px/cell · centre (${Math.floor(cam.cx)}, ${Math.floor(cam.cy)})`;
  }

  // pulsing ring + vision square around the selection; dashed cross once dead
  function drawSelection(xs, ys) {
    const sel = frame && frame.meta.selected;
    if (!sel || !cam) return;
    const s = cam.scale, W = world.width, H = world.height;
    const p = sel.alive === false && sel.death ? sel.death.pos : sel.pos;
    const pulse = 0.5 + 0.5 * Math.sin(performance.now() / 220);
    const vis = sel.alive !== false && sel.kind !== 'plant' ? Math.floor((sel.traits.find((t) => t.name === 'vision') || { value: 0 }).value) : 0;
    for (const ox of xs) for (const oy of ys) {
      const px = (p.x + 0.5 + ox - cam.cx) * s + vw / 2, py = (p.y + 0.5 + oy - cam.cy) * s + vh / 2;
      if (px < -W * s || py < -H * s || px > vw + W * s || py > vh + H * s) continue;
      if (vis > 0) {
        ctx.fillStyle = 'rgba(255,255,255,0.06)'; ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
        const r = (vis + 0.5) * s; ctx.fillRect(px - r, py - r, 2 * r, 2 * r); ctx.strokeRect(px - r, py - r, 2 * r, 2 * r); ctx.setLineDash([]);
      }
      const rr = Math.max(7, s * 0.9) + pulse * 3;
      if (sel.alive === false) {
        ctx.strokeStyle = '#ff6b5b'; ctx.lineWidth = 2; ctx.setLineDash([3, 3]); ctx.beginPath();
        ctx.moveTo(px - rr, py - rr); ctx.lineTo(px + rr, py + rr); ctx.moveTo(px + rr, py - rr); ctx.lineTo(px - rr, py + rr); ctx.stroke(); ctx.setLineDash([]);
      } else {
        ctx.beginPath(); ctx.arc(px, py, rr, 0, Math.PI * 2);
        ctx.lineWidth = 4; ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.stroke();
        ctx.lineWidth = 2; ctx.strokeStyle = `rgba(255,236,120,${0.7 + 0.3 * pulse})`; ctx.stroke();
      }
    }
  }

  // ---------- controls ----------
  function status(text, cls) { const el = $('ctl-status'); el.textContent = text; el.className = 'small ' + (cls || 'muted'); }
  async function api(path, body, raw) {
    try {
      const r = await fetch(path, { method: 'POST', body: raw !== undefined ? raw : JSON.stringify(body || {}), headers: { 'Content-Type': 'application/json' } });
      const j = await r.json().catch(() => ({ ok: false, error: `HTTP ${r.status}` }));
      if (!r.ok || j.ok === false) { status('⚠ ' + (j.error || `HTTP ${r.status}`), 'err'); return null; }
      if (j.message) status('✓ ' + j.message, 'ok');
      await poll(true);
      return j;
    } catch (e) { status('⚠ server not reachable', 'err'); return null; }
  }
  const control = (cmd, extra) => api('/api/control', Object.assign({ cmd }, extra || {}));
  function runCommand(c) {
    if (c.cmd === 'follow') { toggleFollow(); return; }
    if (c.cmd === 'newworld') { setup.open(); return; }
    if (c.cmd === 'charts') { toggleCharts(); return; }
    if (c.cmd === 'save') { savePath(); return; }
    if (c.cmd === 'reset') { follow = false; }
    control(c.cmd);
  }
  function savePath() { api('/api/checkpoint/save', { path: $('ckpt-path').value }); }
  function toggleFollow() { follow = !follow; $('btn-follow').classList.toggle('primary', follow); dirty = true; centreOnSelection(); }
  function centreOnSelection() {
    const sel = frame && frame.meta.selected;
    if (!sel || !cam) return;
    const p = sel.alive === false && sel.death ? sel.death.pos : sel.pos;
    cam = { scale: cam.scale, cx: p.x + 0.5, cy: p.y + 0.5 }; dirty = true;
  }
  $('btn-run').onclick = () => control('toggle');
  $('btn-step').onclick = () => control('step');
  $('btn-reset').onclick = () => runCommand({ cmd: 'reset' });
  $('btn-slower').onclick = () => control('slower');
  $('btn-faster').onclick = () => control('faster');
  $('btn-save').onclick = savePath;
  $('btn-load').onclick = () => api('/api/checkpoint/load', { path: $('ckpt-path').value });
  $('btn-download').onclick = () => { const a = document.createElement('a'); a.href = '/api/checkpoint'; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); status('✓ download started', 'ok'); };
  $('file-upload').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    status(`uploading ${f.name}…`); await api('/api/checkpoint/upload', null, await f.text()); e.target.value = '';
  };
  $('btn-follow').onclick = toggleFollow;
  $('btn-deselect').onclick = () => { follow = false; api('/api/select', {}); };

  function renderControls(m) {
    const run = !!m.running;
    const b = $('btn-run'); b.textContent = run ? '⏸ Pause' : '▶ Run'; b.classList.toggle('paused', run);
    const rs = $('runstate'); rs.textContent = run ? '● Running' : '❚❚ Paused'; rs.className = 'badge ' + (run ? 'run' : 'pause');
    if (m.speed) {
      $('speed-label').textContent = speedLabel(m.speed);
      $('speed-top').textContent = speedLabel(m.speed) + (m.speed.tps ? ' ticks/s' : ' speed');
      const meter = $('speed-meter');
      if (meter.children.length !== m.speed.levels.length) {
        meter.innerHTML = '';
        m.speed.levels.forEach((l, i) => { const seg = document.createElement('i'); seg.title = l; seg.onclick = () => control('speed', { speed: i }); meter.appendChild(seg); });
      }
      [...meter.children].forEach((c, i) => c.classList.toggle('on', i <= m.speed.index));
      $('btn-slower').disabled = m.speed.index <= 0; $('btn-faster').disabled = m.speed.index >= m.speed.levels.length - 1;
    }
  }

  function renderInspector(sel) {
    const key = sel ? JSON.stringify([sel.id, sel.tick, sel.alive]) : '';
    if (key === inspectKey) return;
    inspectKey = key;
    const f = formatInspector(sel);
    $('insp-empty').hidden = !!f; $('insp-body').hidden = !f;
    $('inspector').classList.toggle('dead', !!(f && f.death));
    $('inspector').classList.toggle('active', !!f);
    if (!f) return;
    const kindIdx = { plant: 0, herbivore: 1, carnivore: 2 }[sel.kind];
    const head = $('insp-head'); head.innerHTML = '';
    const sym = document.createElement('canvas'); sym.width = 20; sym.height = 20; drawSymbol(sym.getContext('2d'), kindIdx, 10, 10.5, kindIdx === 0 ? 12 : 7.5, 2);
    head.appendChild(sym); head.appendChild(document.createTextNode(f.title));
    const sp = document.createElement('span'); sp.className = 'sp'; sp.textContent = f.species + (sel.species.parent_code ? ` ← ${sel.species.parent_code}` : ''); head.appendChild(sp);
    const d = $('insp-death'); d.hidden = !f.death; d.textContent = f.death || '';
    const st = $('insp-stats'); st.innerHTML = '';
    for (const [k, v] of f.rows.slice(2)) {
      const tr = st.insertRow(); tr.insertCell().textContent = k; const td = tr.insertCell(); td.textContent = v;
      if (k === 'Energy' || k === 'Health') {
        const frac = k === 'Energy' ? sel.energy / Math.max(1e-9, sel.max_energy) : sel.health / Math.max(1e-9, sel.max_health);
        const bar = document.createElement('div'); bar.className = 'bar ' + k.toLowerCase();
        const fill = document.createElement('span'); fill.style.width = `${Math.round(Math.max(0, Math.min(1, frac)) * 100)}%`; bar.appendChild(fill); td.appendChild(bar);
      }
    }
    const tt = $('insp-traits'); tt.innerHTML = '';
    for (const t of f.traits) {
      const tr = tt.insertRow(); tr.insertCell().textContent = t.name; const td = tr.insertCell();
      const row = document.createElement('div'); row.style.display = 'flex'; row.style.gap = '6px'; row.style.alignItems = 'center';
      const val = document.createElement('span'); val.style.width = '58px'; val.textContent = t.value;
      const bar = document.createElement('div'); bar.className = 'bar trait'; bar.style.flex = '1';
      const fill = document.createElement('span'); fill.style.width = `${Math.round(Math.max(0, Math.min(1, t.frac)) * 100)}%`; bar.appendChild(fill);
      row.appendChild(val); row.appendChild(bar); td.appendChild(row);
    }
    $('insp-genome-n').textContent = `· ${f.genomeLen} loci`;
    const gc = $('genome');
    gc.width = Math.max(120, Math.round(gc.clientWidth || 260));
    const g = gc.getContext('2d'), GH = gc.height, bars = genomeBars(sel.genome, gc.width, GH - 4);
    g.clearRect(0, 0, gc.width, GH);
    for (const b of bars) {
      g.fillStyle = b.color; g.fillRect(b.x, b.y + 2, Math.max(1, b.w), b.h);
      if (b.founderY !== null) { g.fillStyle = '#ffffff'; g.fillRect(b.x, b.founderY + 1.5, Math.max(1, b.w), 1.5); }
    }
    gc.onmousemove = (e) => {
      const r = gc.getBoundingClientRect(), x = (e.clientX - r.left) * gc.width / r.width;
      const b = bars.find((q) => x >= q.x && x <= q.x + q.w + 1);
      gc.title = b ? `${b.name}: ${b.value.toFixed(3)} (${GENE_GROUPS[b.group].label})` : '';
    };
    const used = [...new Set(bars.map((b) => b.group))];
    $('genome-legend').innerHTML = used.map((k) => `<i style="background:${GENE_GROUPS[k].color}"></i>${GENE_GROUPS[k].label}`).join('') + '<i style="background:#fff;height:2px"></i>founder';
    const pc = $('insp-parents'); pc.innerHTML = '';
    if (!f.parents.length) { const s2 = document.createElement('span'); s2.className = 'muted small'; s2.textContent = 'founder (no parents)'; pc.appendChild(s2); }
    for (const p of f.parents) {
      const c = document.createElement(p.alive ? 'button' : 'span'); c.className = 'chip' + (p.alive ? '' : ' gone'); c.textContent = p.text;
      if (p.alive) { c.title = 'Inspect this parent'; c.onclick = () => api('/api/select', { id: p.id }); } else c.title = 'no longer alive';
      pc.appendChild(c);
    }
  }

  // ---------- scenario dialog + charts (TASK-025) ----------
  const CL = window.ChartsLib;
  let chartState = CL.emptyChartState(), hist = null, chartsDrawn = 0, histDrawn = 0, chartsInflight = false, histInflight = false;
  let chartsDirty = true, setupReady = false, lastChartsVersion = null;
  const setupShot = autotest === 'shots' && params.get('setup') === '1';
  const minTick = parseInt(params.get('min'), 10) || 100;
  const setup = window.createSetupDialog({ onStarted: (j) => {
    status('✓ ' + (j.message || 'new world started'), 'ok'); follow = false;
    chartState = CL.emptyChartState(); hist = null; chartsDirty = true; poll(true); pollCharts(); pollHist();
  } });
  const traitSel = $('trait-sel');
  CL.TRAITS.forEach((t) => { const o = document.createElement('option'); o.value = t; o.textContent = CL.traitLabel(t); traitSel.appendChild(o); });
  traitSel.value = 'speed';
  traitSel.onchange = () => { chartsDirty = true; pollHist(); };
  $('trait-kind').onchange = () => { chartsDirty = true; };
  $('hist-kind').onchange = () => pollHist();
  function toggleCharts(force) {
    const on = force === undefined ? !document.body.classList.contains('charts-full') : force;
    document.body.classList.toggle('charts-full', on);
    $('btn-charts').textContent = on ? '⤡ Collapse' : '⤢ Expand';
    resize(); chartsDirty = true; drawCharts();
  }
  $('btn-charts').onclick = () => toggleCharts();
  $('btn-new').onclick = () => setup.open();
  $('btn-cfg-export').onclick = () => { const a = document.createElement('a'); a.href = '/api/config/download'; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); status('✓ configuration download started', 'ok'); };
  $('cfg-import').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    const text = await f.text(); e.target.value = '';
    await setup.open(); const ok = await setup.importText(text);
    status(ok ? `✓ imported ${f.name} — review and press Start` : `⚠ ${f.name} has invalid fields (marked in the dialog)`, ok ? 'ok' : 'err');
  };
  function sizeCanvas(c) {
    const r = c.getBoundingClientRect(), w = Math.max(10, Math.round(r.width)), h = Math.max(10, Math.round(r.height));
    if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    return [g, w, h];
  }
  function drawCharts() {
    if (!chartsDirty) return;
    chartsDirty = false;
    const opts = { trait: traitSel.value, kind: $('trait-kind').value };
    document.querySelectorAll('#chartgrid .chart').forEach((el) => {
      const id = el.dataset.chart, c = el.querySelector('canvas');
      const [g, w, h] = sizeCanvas(c);
      if (id === 'histogram') { CL.drawHistogram(g, hist, w, h); if (hist) histDrawn++; }
      else CL.drawLineChart(g, CL.buildSeries(id, chartState, opts), w, h);
    });
    if (chartState.points.length >= 2) chartsDrawn++;
    const pts = CL.allPoints(chartState);
    $('chart-info').textContent = pts.length ? `ticks 0–${pts[pts.length - 1].tick.toLocaleString('en')} · ${chartState.points.length} samples (every ${chartState.stride} tick${chartState.stride > 1 ? 's' : ''})` : '';
  }
  async function pollCharts() {
    if (chartsInflight || frozen) return;
    chartsInflight = true;
    try {
      const j = await (await fetch('/api/charts' + CL.chartQuery(chartState), { cache: 'no-store' })).json();
      const before = chartState;
      chartState = CL.mergeChartData(chartState, j);
      if (before.epoch !== chartState.epoch) { hist = null; pollHist(); }
      chartsDirty = true;
    } catch (e) { /* keep last data */ }
    chartsInflight = false;
  }
  async function pollHist() {
    if (histInflight || frozen) return;
    histInflight = true;
    try {
      const j = await (await fetch(`/api/histogram?kind=${$('hist-kind').value}&trait=${traitSel.value}&bins=24`, { cache: 'no-store' })).json();
      if (j.ok !== false) { hist = j; chartsDirty = true; }
    } catch (e) { /* keep last data */ }
    histInflight = false;
  }
  function renderScenario(m) {
    if (!world) return;
    $('scenario-info').textContent = `Running “${world.name}” · ${world.width}×${world.height} · seed ${world.seed_text || world.seed}`;
    if (m.charts_version !== undefined && m.charts_version !== lastChartsVersion) { lastChartsVersion = m.charts_version; }
  }
  setInterval(pollCharts, 500);
  setInterval(pollHist, 1000);
  setInterval(drawCharts, 250);

  function updateHud(m) {
    renderScenario(m);
    $('tick').textContent = m.tick.toLocaleString('en');
    const yl = world.year_length || 1;
    $('year').textContent = Math.floor(m.tick / yl) + 1;
    $('season').textContent = seasonName(m.season_phase);
    $('seasonfill').style.width = `${Math.round(wrapMod(m.season_phase, 1) * 100)}%`;
    $('c-plants').textContent = m.counts.plants; $('c-herb').textContent = m.counts.herbivores; $('c-carn').textContent = m.counts.carnivores;
    $('perf').textContent = `${fps.toFixed(0)} fps · ${m.tps} ticks/s`;
    renderControls(m);
    renderInspector(m.selected);
    if (follow && m.selected) centreOnSelection();
  }

  async function reloadWorld() {
    const w = await (await fetch('/api/world', { cache: 'no-store' })).json();
    const resized = !world || w.width !== world.width || w.height !== world.height;
    world = w; buildTerrain();
    $('worldname').textContent = `· ${world.name} · ${world.width}×${world.height} · seed ${world.seed}`;
    if (resized) cam = fitCamera(world.width, world.height, vw, vh);
    dirty = true;
  }

  async function poll(force) {
    if ((inflight && !force) || frozen) return;
    inflight = true;
    try {
      const r = await fetch('/api/frame', { cache: 'no-store' });
      const f = decodeFrame(await r.arrayBuffer());
      const m = f.meta;
      if ((m.epoch || 0) !== worldEpoch) { worldEpoch = m.epoch || 0; await reloadWorld(); }
      const key = [m.tick, m.running, m.speed && m.speed.index, m.epoch, m.selected && m.selected.id, m.selected && m.selected.alive].join('|');
      if (!frame || key !== frameKey) { frame = f; frameKey = key; dirty = true; updateHud(m); }
    } catch (e) { /* server gone: keep last frame */ }
    inflight = false;
  }

  function report(mode) {
    if (reported) return; reported = true;
    const body = JSON.stringify({ mode, frames: framesDrawn, first_tick: firstTick, last_tick: frame ? frame.meta.tick : 0,
      fps: framesDrawn / ((performance.now() - t0) / 1000), draw_ms_avg: framesDrawn ? drawMsSum / framesDrawn : 0,
      organisms: frame ? frame.n : 0, viewport: [vw, vh], inspected: !!(frame && frame.meta.selected),
      inspected_kind: frame && frame.meta.selected ? frame.meta.selected.kind : null });
    fetch('/api/autotest/report', { method: 'POST', body, headers: { 'Content-Type': 'application/json' } }).catch(() => {});
  }

  // screenshot mode: select an animal (carnivore preferred) via the real select API
  async function pickForShot() {
    const want = ['plant', 'herbivore', 'carnivore'];
    for (let attempt = 0; attempt < 8; attempt++) {
      await poll(true);
      let best = null;
      for (let i = 0; i < frame.n; i++) { const o = i * 6, k = frame.recs[o + 4]; if (!best || k > best.k) best = { k, x: frame.recs[o] | (frame.recs[o + 1] << 8), y: frame.recs[o + 2] | (frame.recs[o + 3] << 8) }; if (k === 2) break; }
      if (!best) break;
      const j = await api('/api/select', { x: best.x, y: best.y });
      // the animal may have moved between frame and click: retry until the kind matches
      if (j && j.selected && (j.selected.kind === want[best.k] || attempt === 7)) { follow = true; inspected = true; return; }
    }
    pickRequested = false;
  }

  function loop() {
    if (frame && frame.meta.selected && frame.meta.selected.alive !== false) dirty = true; // pulse animation
    poll();
    if (dirty) {
      draw(); dirty = false;
      if (frame) {
        framesDrawn++; fpsCount++;
        if (firstTick === null) firstTick = frame.meta.tick;
        if (autotest === 'smoke' && framesDrawn >= 5 && (frame.meta.tick - firstTick >= 10 || performance.now() - t0 > 8000)) report('smoke');
        const chartsOk = chartsDrawn > 0 && histDrawn > 0 && hist && hist.tick >= minTick;
        if (autotest === 'shots' && frame.meta.tick >= minTick && chartsOk && (!setupShot || setupReady)) {
          if (!inspectShot) { drawCharts(); frozen = true; report('shots'); }
          else if (inspected && frame.meta.selected && frame.meta.selected.alive !== false) { centreOnSelection(); draw(); frozen = true; report('shots'); }
          else if (!pickRequested) { pickRequested = true; pickForShot(); }
        }
      }
    }
    const now = performance.now();
    if (now - fpsT >= 1000) { fps = fpsCount * 1000 / (now - fpsT); fpsCount = 0; fpsT = now; }
    requestAnimationFrame(loop);
  }

  // ---------- input ----------
  let drag = null;
  let down = null;
  canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY }; down = { x: e.clientX, y: e.clientY }; canvas.classList.add('drag'); canvas.setPointerCapture(e.pointerId); });
  canvas.addEventListener('pointermove', (e) => {
    const r = canvas.getBoundingClientRect();
    if (cam && world) {
      const [wx, wy] = screenToWorld(cam, e.clientX - r.left, e.clientY - r.top, vw, vh);
      const x = Math.floor(wrapMod(wx, world.width)), y = Math.floor(wrapMod(wy, world.height));
      const b = world.biomes[world.grid[y * world.width + x]];
      $('cursorinfo').textContent = `cell (${x}, ${y}) · ${b ? b.name : ''}`;
    }
    if (!drag || !cam) return;
    cam = pan(cam, e.clientX - drag.x, e.clientY - drag.y, world.width, world.height);
    drag = { x: e.clientX, y: e.clientY }; dirty = true;
  });
  const endDrag = () => { drag = null; canvas.classList.remove('drag'); };
  canvas.addEventListener('pointerup', (e) => {
    if (down && cam && world && isClick(e.clientX - down.x, e.clientY - down.y)) {
      const r = canvas.getBoundingClientRect();
      const [wx, wy] = screenToWorld(cam, e.clientX - r.left, e.clientY - r.top, vw, vh);
      api('/api/select', { x: Math.floor(wrapMod(wx, world.width)), y: Math.floor(wrapMod(wy, world.height)) }).then((j) => {
        if (j && !j.selected) { status('nothing here — click on an organism', 'muted'); follow = false; }
      });
    }
    down = null; endDrag();
  });
  canvas.addEventListener('pointercancel', () => { down = null; endDrag(); });
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault(); if (!cam) return;
    const r = canvas.getBoundingClientRect();
    cam = zoomAt(cam, e.clientX - r.left, e.clientY - r.top, Math.pow(1.15, -Math.sign(e.deltaY)), vw, vh, minScale()); dirty = true;
  }, { passive: false });
  const zoomCentre = (f) => { if (cam) { cam = zoomAt(cam, vw / 2, vh / 2, f, vw, vh, minScale()); dirty = true; } };
  const fit = () => { if (world) { cam = fitCamera(world.width, world.height, vw, vh); dirty = true; } };
  $('zin').onclick = () => zoomCentre(1.4); $('zout').onclick = () => zoomCentre(1 / 1.4); $('zfit').onclick = fit;
  window.addEventListener('keydown', (e) => {
    const t = e.target, inInput = !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    const c = keyToCommand(e.key, e.ctrlKey || e.metaKey, inInput);
    if (c) { e.preventDefault(); if (c.cmd === 'deselect') { follow = false; api('/api/select', {}); } else runCommand(c); return; }
    if (inInput || !cam) return;
    const step = 60;
    if (e.key === '+' || e.key === '=') zoomCentre(1.25);
    else if (e.key === '-') zoomCentre(0.8);
    else if (e.key === '0') fit();
    else if (e.key === 'ArrowLeft') cam = pan(cam, step, 0, world.width, world.height);
    else if (e.key === 'ArrowRight') cam = pan(cam, -step, 0, world.width, world.height);
    else if (e.key === 'ArrowUp') cam = pan(cam, 0, step, world.width, world.height);
    else if (e.key === 'ArrowDown') cam = pan(cam, 0, -step, world.width, world.height);
    else return;
    dirty = true;
  });
  window.addEventListener('resize', resize);

  (async () => {
    world = await (await fetch('/api/world', { cache: 'no-store' })).json();
    buildTerrain(); buildLegend(); resize();
    if (inspectShot) $('legend').hidden = true; // keep the inspector card fully on screen
    if (params.get('view') === 'charts') toggleCharts(true);
    pollCharts(); pollHist();
    if (setupShot) { // dialog with a preset chosen and one invalid field visible
      await setup.open('lush');
      setup.setValue('world.width', '0');
      setup.setValue('plants.mutation_rate', '1.7');
      setupReady = true;
    }
    const z = parseFloat(params.get('zoom'));
    if (z > 0) {
      cam = { cx: world.width / 2, cy: world.height / 2, scale: clampScale(z, 1) };
      await poll();
      if (frame) { // centre on the busiest animal area
        for (let i = 0; i < frame.n; i++) { const o = i * 6; if (frame.recs[o + 4] === 2 || (i === frame.n - 1)) { cam.cx = (frame.recs[o] | (frame.recs[o + 1] << 8)) + 0.5; cam.cy = (frame.recs[o + 2] | (frame.recs[o + 3] << 8)) + 0.5; break; } }
      }
    }
    requestAnimationFrame(loop);
  })();
})();

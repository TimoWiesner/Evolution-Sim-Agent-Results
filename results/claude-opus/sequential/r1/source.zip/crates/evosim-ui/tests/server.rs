//! Integration tests: real server on an ephemeral port, real sim thread.
use evosim_core::config::Config;
use evosim_core::serde_json::{self, Value};
use evosim_ui::frame::decode_frame;
use evosim_ui::server::Server;
use evosim_ui::session::UiSession;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::time::{Duration, Instant};

fn get(addr: std::net::SocketAddr, path: &str) -> (u16, Vec<u8>) {
    let mut s = TcpStream::connect(addr).unwrap();
    write!(s, "GET {path} HTTP/1.1\r\nHost: x\r\n\r\n").unwrap();
    let mut buf = Vec::new();
    s.read_to_end(&mut buf).unwrap();
    let split = buf.windows(4).position(|w| w == b"\r\n\r\n").unwrap();
    let head = String::from_utf8_lossy(&buf[..split]).to_string();
    let status = head[9..12].parse().unwrap();
    (status, buf[split + 4..].to_vec())
}

fn tick_of(frame: &[u8]) -> u64 {
    let (m, _) = decode_frame(frame).unwrap();
    serde_json::from_str::<Value>(&m).unwrap()["tick"].as_u64().unwrap()
}

#[test]
fn serves_page_world_and_advancing_frames() {
    let session = UiSession::new(Config::contract_example()).unwrap();
    let server = Server::bind(session.clone(), 0).unwrap();
    let th = session.spawn_sim_thread();
    let a = server.addr();
    let (st, body) = get(a, "/");
    assert_eq!(st, 200);
    let html = String::from_utf8(body).unwrap();
    assert!(html.contains("<canvas id=\"world\"") && html.contains("id=\"legend\""));
    assert_eq!(get(a, "/app.js").0, 200);
    assert_eq!(get(a, "/style.css").0, 200);
    assert_eq!(get(a, "/nope").0, 404);
    let (st, w) = get(a, "/api/world");
    assert_eq!(st, 200);
    let w: Value = serde_json::from_slice(&w).unwrap();
    assert_eq!((w["width"].as_u64(), w["height"].as_u64()), (Some(64), Some(48)));
    assert_eq!(w["biomes"].as_array().unwrap().len(), 6);
    let (st, f1) = get(a, "/api/frame");
    assert_eq!(st, 200);
    let (meta, recs) = decode_frame(&f1).unwrap();
    let m: Value = serde_json::from_str(&meta).unwrap();
    let n = m["counts"]["plants"].as_u64().unwrap() + m["counts"]["herbivores"].as_u64().unwrap() + m["counts"]["carnivores"].as_u64().unwrap();
    assert_eq!(recs.len() as u64, n);
    assert!(recs.iter().all(|r| r.0 < 64 && r.1 < 48 && r.2 < 3));
    std::thread::sleep(Duration::from_millis(700));
    let (_, f2) = get(a, "/api/frame");
    assert!(tick_of(&f2) > tick_of(&f1), "simulation advances");
    server.shutdown();
    th.join().unwrap();
}

#[test]
fn wrong_method_and_report() {
    let session = UiSession::new(Config::contract_example()).unwrap();
    let server = Server::bind(session.clone(), 0).unwrap();
    let mut s = TcpStream::connect(server.addr()).unwrap();
    let body = r#"{"mode":"smoke","frames":7,"fps":12.5,"last_tick":42}"#;
    write!(s, "POST /api/autotest/report HTTP/1.1\r\nContent-Length: {}\r\n\r\n{body}", body.len()).unwrap();
    let mut buf = String::new();
    s.read_to_string(&mut buf).unwrap();
    assert!(buf.starts_with("HTTP/1.1 200"));
    let r = session.shared.report.lock().unwrap().clone().unwrap();
    assert_eq!((r.frames, r.last_tick), (7, 42));
    let mut s = TcpStream::connect(server.addr()).unwrap();
    write!(s, "POST /api/frame HTTP/1.1\r\nContent-Length: 0\r\n\r\n").unwrap();
    let mut buf = String::new();
    s.read_to_string(&mut buf).unwrap();
    assert!(buf.starts_with("HTTP/1.1 405"));
    server.shutdown();
}

/// 1,000-organism fixture: frames keep coming several times per second.
#[test]
fn thousand_organisms_frame_throughput() {
    let text = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/ui-1000.json")).unwrap();
    let cfg = Config::from_json_str(&text).unwrap();
    let session = UiSession::new(cfg).unwrap();
    let (_, recs) = decode_frame(&session.latest_frame()).unwrap();
    assert!(recs.len() >= 1000, "fixture has {} organisms", recs.len());
    let server = Server::bind(session.clone(), 0).unwrap();
    let th = session.spawn_sim_thread();
    let t0 = Instant::now();
    let mut ticks = std::collections::BTreeSet::new();
    while t0.elapsed() < Duration::from_secs(2) {
        let (st, f) = get(server.addr(), "/api/frame");
        assert_eq!(st, 200);
        ticks.insert(tick_of(&f));
        std::thread::sleep(Duration::from_millis(33));
    }
    assert!(ticks.len() >= 10, "only {} distinct frames in 2 s", ticks.len());
    server.shutdown();
    th.join().unwrap();
}

fn request(addr: std::net::SocketAddr, method: &str, path: &str, body: &[u8]) -> (u16, String, Vec<u8>) {
    let mut s = TcpStream::connect(addr).unwrap();
    write!(s, "{method} {path} HTTP/1.1\r\nHost: x\r\nContent-Length: {}\r\n\r\n", body.len()).unwrap();
    s.write_all(body).unwrap();
    let mut buf = Vec::new();
    s.read_to_end(&mut buf).unwrap();
    let split = buf.windows(4).position(|w| w == b"\r\n\r\n").unwrap();
    let head = String::from_utf8_lossy(&buf[..split]).to_string();
    let status = head[9..12].parse().unwrap();
    (status, head, buf[split + 4..].to_vec())
}

fn post(addr: std::net::SocketAddr, path: &str, body: &str) -> (u16, Value) {
    let (st, _, b) = request(addr, "POST", path, body.as_bytes());
    (st, serde_json::from_slice(&b).unwrap_or(Value::Null))
}

fn meta(addr: std::net::SocketAddr) -> Value {
    let (_, f) = get(addr, "/api/frame");
    let (m, _) = decode_frame(&f).unwrap();
    serde_json::from_str(&m).unwrap()
}

/// Run controls through the real HTTP server with a running sim thread.
#[test]
fn controls_over_http() {
    let session = UiSession::new(Config::contract_example()).unwrap();
    let server = Server::bind(session.clone(), 0).unwrap();
    let th = session.spawn_sim_thread();
    let a = server.addr();
    std::thread::sleep(Duration::from_millis(200));
    let (st, r) = post(a, "/api/control", r#"{"cmd":"pause"}"#);
    assert_eq!(st, 200, "{r}");
    assert_eq!(r["running"], false);
    let m = meta(a);
    assert_eq!(m["running"], false);
    let t = m["tick"].as_u64().unwrap();
    std::thread::sleep(Duration::from_millis(150));
    assert_eq!(meta(a)["tick"].as_u64().unwrap(), t, "paused world does not advance");
    for i in 1..=3 {
        let (st, r) = post(a, "/api/control", r#"{"cmd":"step"}"#);
        assert_eq!(st, 200);
        assert_eq!(r["tick"].as_u64().unwrap(), t + i);
        assert_eq!(meta(a)["tick"].as_u64().unwrap(), t + i, "one step = exactly one tick");
    }
    // speed clamps
    let (_, r) = post(a, "/api/control", r#"{"cmd":"speed","speed":-7}"#);
    assert_eq!(r["speed"]["index"], 0);
    assert_eq!(r["speed"]["tps"], 1);
    let (_, r) = post(a, "/api/control", r#"{"cmd":"slower"}"#);
    assert_eq!(r["speed"]["index"], 0);
    let (_, r) = post(a, "/api/control", r#"{"cmd":"speed","speed":1000}"#);
    assert_eq!(r["speed"]["label"], "Max");
    let (_, r) = post(a, "/api/control", r#"{"cmd":"faster"}"#);
    assert_eq!(r["speed"]["label"], "Max");
    assert_eq!(meta(a)["speed"]["label"], "Max");
    // run at max, then reset
    post(a, "/api/control", r#"{"cmd":"run"}"#);
    std::thread::sleep(Duration::from_millis(200));
    assert!(meta(a)["tick"].as_u64().unwrap() > t + 3);
    let h0 = evosim_core::sim::Simulation::new(Config::contract_example()).unwrap().state_hash();
    let (st, r) = post(a, "/api/control", r#"{"cmd":"reset"}"#);
    assert_eq!(st, 200);
    assert_eq!((r["tick"].as_u64(), r["running"].as_bool(), r["epoch"].as_u64()), (Some(0), Some(false), Some(1)));
    assert_eq!(session.with_engine(|e| e.sim.state_hash()), h0, "reset gives the same starting world");
    let m = meta(a);
    assert_eq!((m["tick"].as_u64(), m["epoch"].as_u64()), (Some(0), Some(1)));
    // select a carnivore by cell; frame meta carries the inspector
    let (id, x, y) = session.with_engine(|e| {
        let c = e.sim.organisms().alive(evosim_core::organism::Kind::Carnivore).next().unwrap();
        (c.id().0, c.pos().x, c.pos().y)
    });
    let (st, r) = post(a, "/api/select", &format!(r#"{{"x":{x},"y":{y}}}"#));
    assert_eq!(st, 200);
    assert_eq!(r["selected"]["id"], id);
    post(a, "/api/control", r#"{"cmd":"step"}"#);
    let m = meta(a);
    assert_eq!(m["selected"]["id"], id);
    assert_eq!(m["selected"]["tick"], 1, "inspector follows the tick");
    assert!(m["selected"]["genome"].as_array().unwrap().len() > 5);
    let (_, r) = post(a, "/api/select", "{}");
    assert!(r["selected"].is_null());
    // bad input
    assert_eq!(post(a, "/api/control", r#"{"cmd":"warp"}"#).0, 400);
    assert_eq!(post(a, "/api/control", "not json").0, 400);
    assert_eq!(post(a, "/api/control", "[1]").0, 400);
    assert_eq!(get(a, "/api/control").0, 405);
    assert_eq!(post(a, "/api/select", r#"{"id":123456789}"#).0, 400);
    server.shutdown();
    th.join().unwrap();
}

#[test]
fn checkpoints_over_http() {
    let dir = std::env::temp_dir().join(format!("evosim-ui-ckpt-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("ui-save.json");
    let session = UiSession::new(Config::contract_example()).unwrap();
    let server = Server::bind(session.clone(), 0).unwrap();
    let th = session.spawn_sim_thread();
    let a = server.addr();
    post(a, "/api/control", r#"{"cmd":"pause"}"#);
    for _ in 0..10 {
        post(a, "/api/control", r#"{"cmd":"step"}"#);
    }
    let (t_saved, h_saved) = session.with_engine(|e| (e.tick(), e.sim.state_hash()));
    let body = serde_json::json!({"path": path.to_str().unwrap()}).to_string();
    let (st, r) = post(a, "/api/checkpoint/save", &body);
    assert_eq!(st, 200, "{r}");
    assert!(path.is_file());
    for _ in 0..5 {
        post(a, "/api/control", r#"{"cmd":"step"}"#);
    }
    let (st, r) = post(a, "/api/checkpoint/load", &body);
    assert_eq!(st, 200, "{r}");
    assert_eq!(r["tick"].as_u64(), Some(t_saved));
    assert_eq!(session.with_engine(|e| e.sim.state_hash()), h_saved);
    assert_eq!(meta(a)["tick"].as_u64(), Some(t_saved));
    // download carries a Content-Disposition header and round-trips via upload
    let (st, head, ck) = request(a, "GET", "/api/checkpoint", b"");
    assert_eq!(st, 200);
    assert!(head.contains("Content-Disposition: attachment; filename=\"evosim-checkpoint-tick"), "{head}");
    post(a, "/api/control", r#"{"cmd":"reset"}"#);
    assert_eq!(meta(a)["tick"], 0);
    let (st, _, r) = request(a, "POST", "/api/checkpoint/upload", &ck);
    assert_eq!(st, 200, "{}", String::from_utf8_lossy(&r));
    assert_eq!(session.with_engine(|e| e.sim.state_hash()), h_saved);
    // > 1 MiB upload accepted on that route (big checkpoint of the 1,000-organism fixture)
    let text = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/tests/fixtures/ui-1000.json")).unwrap();
    let big_sim = evosim_core::sim::Simulation::new(Config::from_json_str(&text).unwrap()).unwrap();
    let mut big = big_sim.checkpoint_json().unwrap();
    if big.len() <= 1024 * 1024 {
        big.push_str(&" ".repeat(1024 * 1024 + 1 - big.len()));
    }
    let (st, _, r) = request(a, "POST", "/api/checkpoint/upload", big.as_bytes());
    assert_eq!(st, 200, "{}", String::from_utf8_lossy(&r));
    assert_eq!(session.with_engine(|e| e.sim.state_hash()), big_sim.state_hash());
    assert_eq!(serde_json::from_str::<Value>(&session.world_json()).unwrap()["width"], big_sim.config().world.width);
    // errors leave the world untouched
    let (st, r) = post(a, "/api/checkpoint/load", r#"{"path":"/nonexistent/x.json"}"#);
    assert_eq!(st, 400);
    assert_eq!(r["ok"], false);
    assert_eq!(post(a, "/api/checkpoint/save", "{}").0, 400);
    let (st, _, _) = request(a, "POST", "/api/checkpoint/upload", b"{\"bad\":1}");
    assert_eq!(st, 400);
    assert_eq!(session.with_engine(|e| e.sim.state_hash()), big_sim.state_hash());
    server.shutdown();
    th.join().unwrap();
    let _ = std::fs::remove_dir_all(&dir);
}

fn get_json(addr: std::net::SocketAddr, path: &str) -> (u16, Value) {
    let (st, b) = get(addr, path);
    (st, serde_json::from_slice(&b).unwrap_or(Value::Null))
}

#[test]
fn scenario_and_charts_over_http() {
    let session = UiSession::new(Config::contract_example()).unwrap();
    let server = Server::bind(session.clone(), 0).unwrap();
    let th = session.spawn_sim_thread();
    let a = server.addr();
    assert_eq!(get(a, "/charts.js").0, 200);
    assert_eq!(get(a, "/setup.js").0, 200);
    let (st, html) = get(a, "/");
    assert_eq!(st, 200);
    let html = String::from_utf8(html).unwrap();
    assert!(html.contains("id=\"setup\"") && html.contains("id=\"chartgrid\""));
    // schema + presets
    let (st, schema) = get_json(a, "/api/schema");
    assert_eq!(st, 200);
    assert!(schema["params"].as_array().unwrap().iter().filter(|p| p["featured"] == true).count() >= 5);
    let (_, presets) = get_json(a, "/api/presets");
    let lush = presets["presets"].as_array().unwrap().iter().find(|p| p["name"] == "lush").unwrap().clone();
    // invalid input: 400 with errors at the fields, engine untouched
    std::thread::sleep(Duration::from_millis(200));
    let epoch0 = meta(a)["epoch"].as_u64().unwrap();
    let mut bad = lush["config"].clone();
    bad["world"]["width"] = Value::from(0);
    bad["plants"]["mutation_rate"] = Value::from(2.0);
    let (st, r) = post(a, "/api/new", &bad.to_string());
    assert_eq!(st, 400);
    assert_eq!(r["ok"], false);
    let keys: Vec<&str> = r["errors"].as_array().unwrap().iter().map(|e| e["key"].as_str().unwrap()).collect();
    assert_eq!(keys, vec!["world.width", "plants.mutation_rate"]);
    assert_eq!(meta(a)["epoch"].as_u64().unwrap(), epoch0, "invalid config does not start a world");
    let (_, cur) = get_json(a, "/api/config");
    assert_eq!(cur["config"]["world"]["width"], 64, "old world kept");
    // valid preset with edits (u64 seed beyond 2^53 written as raw digits)
    let mut good = lush["config"].clone();
    good["world"]["width"] = Value::from(70);
    good["initial"]["herbivores"] = Value::from(150);
    good["climate"]["year_length"] = Value::from(250);
    good["plants"]["mutation_rate"] = Value::from(0.08);
    good["herbivores"]["max_age"] = Value::from(900);
    good["carnivores"]["mutation_rate"] = Value::from(0.02);
    good["hunting"]["base_success"] = Value::from(0.2);
    good["seed"] = Value::from(0);
    let text = good.to_string().replace("\"seed\":0", "\"seed\":18446744073709551615");
    let (st, r) = post(a, "/api/new", &text);
    assert_eq!(st, 200, "{r}");
    assert_eq!(r["epoch"].as_u64().unwrap(), epoch0 + 1);
    assert_eq!(r["seed_text"], "18446744073709551615");
    let (_, cur) = get_json(a, "/api/config");
    assert_eq!(cur["seed_text"], "18446744073709551615");
    assert_eq!(cur["config"]["world"]["width"], 70);
    assert_eq!(cur["config"]["hunting"]["base_success"], 0.2);
    // export → import gives the same configuration
    let (st, exported) = get(a, "/api/config/download");
    assert_eq!(st, 200);
    let exported = String::from_utf8(exported).unwrap();
    assert!(exported.contains("\"seed\": 18446744073709551615"));
    let (st, imported) = post(a, "/api/config/validate", &exported);
    assert_eq!(st, 200);
    assert_eq!(imported["config"], cur["config"]);
    assert_eq!(imported["text"], exported);
    let (st, r) = post(a, "/api/config/validate", "{not json");
    assert_eq!(st, 400);
    assert_eq!(r["errors"][0]["key"], "<json>");
    // charts grow while running; incremental requests return only new points
    std::thread::sleep(Duration::from_millis(600));
    let (st, c1) = get_json(a, "/api/charts");
    assert_eq!(st, 200);
    assert_eq!(c1["epoch"].as_u64().unwrap(), epoch0 + 1);
    let pts = c1["points"].as_array().unwrap();
    assert!(pts.len() >= 2, "history recorded while running");
    assert_eq!(pts[0]["tick"], 0);
    assert_eq!(pts[0]["kinds"][1]["count"], 150);
    let last = pts.last().unwrap()["tick"].as_u64().unwrap();
    std::thread::sleep(Duration::from_millis(400));
    let (_, c2) = get_json(a, &format!("/api/charts?v={}&since={last}", c1["version"]));
    assert_eq!(c2["full"], false);
    let p2 = c2["points"].as_array().unwrap();
    assert!(!p2.is_empty(), "more points while running");
    assert!(p2.iter().all(|p| p["tick"].as_u64().unwrap() > last));
    // histogram of a selectable trait
    let (st, h) = get_json(a, "/api/histogram?kind=herbivores&trait=speed&bins=12");
    assert_eq!(st, 200);
    assert_eq!(h["counts"].as_array().unwrap().len(), 12);
    let sum: u64 = h["counts"].as_array().unwrap().iter().map(|c| c.as_u64().unwrap()).sum();
    assert_eq!(sum, h["n"].as_u64().unwrap());
    let (st, h) = get_json(a, "/api/histogram?kind=plants&trait=temp_optimum");
    assert_eq!(st, 200);
    assert_eq!(h["trait"], "temp_optimum");
    assert_eq!(get(a, "/api/histogram?kind=plants&trait=wings").0, 400);
    assert_eq!(request(a, "GET", "/api/new", b"").0, 405);
    assert_eq!(request(a, "POST", "/api/charts", b"").0, 405);
    server.shutdown();
    th.join().unwrap();
}

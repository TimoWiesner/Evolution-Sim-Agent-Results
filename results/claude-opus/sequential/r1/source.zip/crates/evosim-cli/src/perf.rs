//! `evosim perf`: reproducible throughput benchmark (TASK-026, ADR-029).
//!
//! Fixed setup by default: contract example configuration, seed 42, 1000
//! warm-up ticks, then `repeat` repetitions of 1000 measured ticks, each on a
//! clone of the warmed-up simulation (identical work). Only the `step_with`
//! calls are timed (one `Instant` per phase via the phase hook); counting
//! organisms happens outside the timed region. The median ticks/s is the
//! headline number. Output: JSON report `evosim-perf` v1.

use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::serde_json::{json, Value};
use evosim_core::sim::{Phase, Simulation};
use std::io::Write;
use std::time::Instant;

use crate::run::load_checkpoint_file;
use crate::{load_config_file, EXIT_OK, EXIT_USAGE};

/// Default seed of the benchmark.
pub const DEFAULT_SEED: u64 = 42;
/// Default warm-up ticks (not timed).
pub const DEFAULT_WARMUP: u64 = 1000;
/// Default measured ticks per repetition.
pub const DEFAULT_TICKS: u64 = 1000;
/// Default repetitions.
pub const DEFAULT_REPEAT: u32 = 3;

pub const PERF_USAGE: &str = "Usage: evosim perf [--config FILE | --load CHECKPOINT] [--seed N] [--warmup W] [--ticks M] [--repeat R] [--out FILE]\n       defaults: contract example configuration, seed 42, warmup 1000, ticks 1000, repeat 3; JSON report to stdout (or --out)";

/// Parsed `perf` options.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PerfArgs {
    pub config: Option<String>,
    pub load: Option<String>,
    pub seed: Option<u64>,
    pub warmup: u64,
    pub ticks: u64,
    pub repeat: u32,
    pub out: Option<String>,
}

impl Default for PerfArgs {
    fn default() -> Self {
        PerfArgs { config: None, load: None, seed: None, warmup: DEFAULT_WARMUP, ticks: DEFAULT_TICKS, repeat: DEFAULT_REPEAT, out: None }
    }
}

fn parse_num(flag: &str, v: &str) -> Result<u64, String> {
    v.parse::<u64>().map_err(|_| format!("{flag} expects a non-negative integer, got '{v}'"))
}

/// Parse `perf` options (without the command word). `Ok(None)` = help.
pub fn parse_perf_args(args: &[String]) -> Result<Option<PerfArgs>, String> {
    let mut a = PerfArgs::default();
    let mut seen: Vec<&str> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].as_str();
        match flag {
            "--help" | "-h" => return Ok(None),
            "--config" | "--load" | "--seed" | "--warmup" | "--ticks" | "--repeat" | "--out" => {
                if seen.contains(&flag) {
                    return Err(format!("{flag} given more than once"));
                }
                seen.push(flag);
                let v = args.get(i + 1).ok_or_else(|| format!("{flag} needs a value"))?;
                if v.is_empty() {
                    return Err(format!("{flag} needs a non-empty value"));
                }
                match flag {
                    "--config" => a.config = Some(v.clone()),
                    "--load" => a.load = Some(v.clone()),
                    "--out" => a.out = Some(v.clone()),
                    "--seed" => a.seed = Some(parse_num(flag, v)?),
                    "--warmup" => a.warmup = parse_num(flag, v)?,
                    "--ticks" => {
                        a.ticks = parse_num(flag, v)?;
                        if a.ticks == 0 {
                            return Err("--ticks must be at least 1".into());
                        }
                    }
                    "--repeat" => {
                        let r = parse_num(flag, v)?;
                        if r == 0 || r > 1000 {
                            return Err("--repeat must be in 1..=1000".into());
                        }
                        a.repeat = r as u32;
                    }
                    _ => unreachable!(),
                }
                i += 2;
            }
            other => return Err(format!("unknown option '{other}'")),
        }
    }
    if a.config.is_some() && a.load.is_some() {
        return Err("--config and --load are mutually exclusive".into());
    }
    if a.load.is_some() && a.seed.is_some() {
        return Err("--seed cannot be used with --load (the seed is part of the checkpoint)".into());
    }
    Ok(Some(a))
}

/// Result of one measured repetition.
#[derive(Debug, Clone, PartialEq)]
pub struct PerfRun {
    pub seconds: f64,
    pub ticks_per_second: f64,
    /// Seconds per phase, in `Phase::ORDER`.
    pub phase_seconds: [f64; 9],
    pub state_hash: String,
}

/// Organism counts over the measured ticks (after each tick).
#[derive(Debug, Clone, PartialEq)]
pub struct OrganismStats {
    pub min: u64,
    pub max: u64,
    pub mean: f64,
    /// Mean per kind (plants, herbivores, carnivores).
    pub mean_by_kind: [f64; 3],
    pub end_by_kind: [u64; 3],
}

/// Whole benchmark result.
#[derive(Debug, Clone, PartialEq)]
pub struct PerfReport {
    pub seed: u64,
    pub warmup: u64,
    pub ticks: u64,
    pub repeat: u32,
    pub tick_start: u64,
    pub tick_end: u64,
    pub runs: Vec<PerfRun>,
    pub organisms: OrganismStats,
}

impl PerfReport {
    /// Median ticks per second over the repetitions.
    pub fn median_tps(&self) -> f64 {
        let mut v: Vec<f64> = self.runs.iter().map(|r| r.ticks_per_second).collect();
        v.sort_by(|a, b| a.total_cmp(b));
        let n = v.len();
        if n == 0 {
            0.0
        } else if n % 2 == 1 {
            v[n / 2]
        } else {
            (v[n / 2 - 1] + v[n / 2]) / 2.0
        }
    }

    /// Whether every repetition ended with the same state hash.
    pub fn deterministic(&self) -> bool {
        self.runs.windows(2).all(|w| w[0].state_hash == w[1].state_hash)
    }
}

fn counts(sim: &Simulation) -> [u64; 3] {
    let p = sim.world().organisms();
    Kind::ALL.map(|k| p.count_alive(k) as u64)
}

/// Warm `sim` up for `warmup` ticks (untimed), then time `repeat`
/// repetitions of `ticks` ticks, each on a clone of the warmed-up state.
pub fn measure(mut sim: Simulation, warmup: u64, ticks: u64, repeat: u32) -> PerfReport {
    sim.run(warmup);
    let tick_start = sim.tick();
    let mut runs = Vec::with_capacity(repeat as usize);
    let mut organisms = None;
    for _ in 0..repeat.max(1) {
        let mut s = sim.clone();
        let mut phase_seconds = [0f64; 9];
        let mut total = 0f64;
        let mut stats = (u64::MAX, 0u64, 0f64, [0f64; 3]);
        for _ in 0..ticks {
            let mut last = Instant::now();
            let start = last;
            let mut k = 0usize;
            s.step_with(|_| {
                let now = Instant::now();
                phase_seconds[k] += (now - last).as_secs_f64();
                last = now;
                k += 1;
            });
            total += (last - start).as_secs_f64();
            let c = counts(&s);
            let sum: u64 = c.iter().sum();
            stats.0 = stats.0.min(sum);
            stats.1 = stats.1.max(sum);
            stats.2 += sum as f64;
            for i in 0..3 {
                stats.3[i] += c[i] as f64;
            }
        }
        if organisms.is_none() {
            let n = ticks.max(1) as f64;
            organisms = Some(OrganismStats {
                min: if ticks == 0 { 0 } else { stats.0 },
                max: stats.1,
                mean: stats.2 / n,
                mean_by_kind: stats.3.map(|x| x / n),
                end_by_kind: counts(&s),
            });
        }
        let tps = if total > 0.0 { ticks as f64 / total } else { f64::INFINITY };
        runs.push(PerfRun { seconds: total, ticks_per_second: tps, phase_seconds, state_hash: s.state_hash() });
    }
    PerfReport {
        seed: sim.config().seed,
        warmup,
        ticks,
        repeat: repeat.max(1),
        tick_start,
        tick_end: tick_start + ticks,
        runs,
        organisms: organisms.expect("at least one repetition"),
    }
}

fn cpu_model() -> String {
    std::fs::read_to_string("/proc/cpuinfo")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("model name")).and_then(|l| l.split_once(':')).map(|(_, v)| v.trim().to_string()))
        .unwrap_or_else(|| "unknown".into())
}

/// JSON report `evosim-perf` v1.
pub fn report_json(r: &PerfReport, label: &str) -> Value {
    let median = r.median_tps();
    // Phase shares: phase seconds summed over all repetitions.
    let mut phase_total = [0f64; 9];
    for run in &r.runs {
        for (i, s) in run.phase_seconds.iter().enumerate() {
            phase_total[i] += s;
        }
    }
    let all: f64 = phase_total.iter().sum();
    let phases: Vec<Value> = Phase::ORDER
        .iter()
        .enumerate()
        .map(|(i, p)| {
            json!({"phase": p.name(), "seconds": phase_total[i] / r.runs.len() as f64, "share": if all > 0.0 { phase_total[i] / all } else { 0.0 }})
        })
        .collect();
    let o = &r.organisms;
    json!({
        "format": "evosim-perf",
        "version": 1,
        "config": label,
        "seed": r.seed,
        "warmup": r.warmup,
        "ticks": r.ticks,
        "repeat": r.repeat,
        "tick_start": r.tick_start,
        "tick_end": r.tick_end,
        "ticks_per_second": median,
        "ticks_per_second_all": r.runs.iter().map(|x| x.ticks_per_second).collect::<Vec<_>>(),
        "elapsed_seconds": r.runs.iter().map(|x| x.seconds).collect::<Vec<_>>(),
        "organisms": {
            "min": o.min, "mean": o.mean, "max": o.max,
            "mean_by_kind": {"plants": o.mean_by_kind[0], "herbivores": o.mean_by_kind[1], "carnivores": o.mean_by_kind[2]},
            "end_by_kind": {"plants": o.end_by_kind[0], "herbivores": o.end_by_kind[1], "carnivores": o.end_by_kind[2]},
        },
        "phases": phases,
        "state_hash": r.runs[0].state_hash,
        "deterministic": r.deterministic(),
        "host": {"cpu_model": cpu_model(), "logical_cpus": std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1)},
    })
}

/// The `perf` command.
pub fn perf_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let a = match parse_perf_args(rest) {
        Ok(Some(a)) => a,
        Ok(None) => {
            let _ = writeln!(out, "{PERF_USAGE}");
            return EXIT_OK;
        }
        Err(e) => {
            let _ = writeln!(err, "error: {e}\n{PERF_USAGE}");
            return EXIT_USAGE;
        }
    };
    let (sim, label) = match (&a.config, &a.load) {
        (_, Some(l)) => match load_checkpoint_file(l) {
            Ok(s) => (s, format!("checkpoint:{l}")),
            Err(e) => {
                let _ = writeln!(err, "error: {e}");
                return EXIT_USAGE;
            }
        },
        (c, None) => {
            let (mut cfg, label) = match c {
                Some(c) => match load_config_file(c) {
                    Ok(cfg) => (cfg, c.clone()),
                    Err(e) => {
                        let _ = writeln!(err, "error: {e}");
                        return EXIT_USAGE;
                    }
                },
                None => (Config::contract_example(), "contract-example".to_string()),
            };
            cfg.seed = a.seed.unwrap_or(DEFAULT_SEED);
            match Simulation::new(cfg) {
                Ok(s) => (s, label),
                Err(e) => {
                    let _ = writeln!(err, "error: {e}");
                    return EXIT_USAGE;
                }
            }
        }
    };
    let r = measure(sim, a.warmup, a.ticks, a.repeat);
    let v = report_json(&r, &label);
    let text = evosim_core::serde_json::to_string_pretty(&v).expect("json") + "\n";
    match &a.out {
        Some(f) => {
            if let Err(e) = std::fs::write(f, &text) {
                let _ = writeln!(err, "error: cannot write '{f}': {e}");
                return EXIT_USAGE;
            }
        }
        None => {
            let _ = out.write_all(text.as_bytes());
        }
    }
    let o = &r.organisms;
    let _ = writeln!(
        err,
        "perf: {:.1} ticks/s (median of {}), ticks {}..{}, organisms min/mean/max {}/{:.0}/{}, state_hash {}",
        r.median_tps(),
        r.repeat,
        r.tick_start,
        r.tick_end,
        o.min,
        o.mean,
        o.max,
        &r.runs[0].state_hash[..16.min(r.runs[0].state_hash.len())]
    );
    EXIT_OK
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(a: &[&str]) -> Result<Option<PerfArgs>, String> {
        parse_perf_args(&a.iter().map(|s| s.to_string()).collect::<Vec<_>>())
    }

    #[test]
    fn parses_defaults_and_options() {
        assert_eq!(p(&[]).unwrap().unwrap(), PerfArgs::default());
        let a = p(&["--seed", "7", "--warmup", "0", "--ticks", "5", "--repeat", "2", "--out", "x.json"]).unwrap().unwrap();
        assert_eq!((a.seed, a.warmup, a.ticks, a.repeat, a.out.as_deref()), (Some(7), 0, 5, 2, Some("x.json")));
        assert_eq!(p(&["--help"]).unwrap(), None);
    }

    #[test]
    fn rejects_bad_options() {
        for bad in [
            vec!["--ticks", "x"],
            vec!["--ticks", "0"],
            vec!["--repeat", "0"],
            vec!["--seed"],
            vec!["--bogus"],
            vec!["--config", "a", "--load", "b"],
            vec!["--load", "b", "--seed", "1"],
            vec!["--ticks", "1", "--ticks", "2"],
        ] {
            assert!(p(&bad).is_err(), "{bad:?}");
        }
    }

    #[test]
    fn measure_is_deterministic_across_repeats() {
        let mut cfg = Config::contract_example();
        cfg.seed = 3;
        let r = measure(Simulation::new(cfg.clone()).unwrap(), 5, 10, 2);
        assert_eq!(r.runs.len(), 2);
        assert!(r.deterministic());
        assert_eq!((r.tick_start, r.tick_end), (5, 15));
        // Same end state as a plain run of warmup + ticks.
        let mut s = Simulation::new(cfg).unwrap();
        s.run(15);
        assert_eq!(r.runs[0].state_hash, s.state_hash());
        let v = report_json(&r, "x");
        for k in ["ticks_per_second", "organisms", "phases", "state_hash", "host", "warmup", "ticks", "seed"] {
            assert!(v.get(k).is_some(), "{k}");
        }
        assert_eq!(v["phases"].as_array().unwrap().len(), 9);
    }
}

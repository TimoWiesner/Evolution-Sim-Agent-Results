//! Shared file-output helpers of the CLI commands (`run`, `batch`).

use std::path::{Path, PathBuf};

/// Check that `out` can be written as a file: not a directory, parent exists.
pub(crate) fn check_out_path(flag: &str, out: &str) -> Result<PathBuf, String> {
    let p = PathBuf::from(out);
    if p.is_dir() {
        return Err(format!("{flag} '{out}' is a directory"));
    }
    let parent = match p.parent() {
        Some(d) if !d.as_os_str().is_empty() => d.to_path_buf(),
        _ => PathBuf::from("."),
    };
    if !parent.is_dir() {
        return Err(format!("{flag} '{out}': directory '{}' does not exist", parent.display()));
    }
    Ok(p)
}

/// Write `text` to `path` atomically (temp file in the same directory, then
/// rename). On failure the temp file is removed and `path` is untouched.
pub(crate) fn write_atomic(path: &Path, text: &str) -> Result<(), String> {
    let name = path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_else(|| "result".into());
    let tmp = path.with_file_name(format!(".{name}.tmp-{}", std::process::id()));
    let res = std::fs::write(&tmp, text).and_then(|_| std::fs::rename(&tmp, path));
    if let Err(e) = res {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("cannot write result file '{}': {e}", path.display()));
    }
    Ok(())
}


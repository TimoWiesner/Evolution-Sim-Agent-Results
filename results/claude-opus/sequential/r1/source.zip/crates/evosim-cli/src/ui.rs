//! `evosim ui` argument parsing (contract section 2); the UI lives in evosim-ui.

use crate::{load_config_file, usage, EXIT_OK, EXIT_USAGE};
use evosim_core::config;
use evosim_ui::{UiMode, UiOptions, DEFAULT_PORT};
use std::io::Write;
use std::path::PathBuf;

pub fn ui_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let mut cfg_path: Option<String> = None;
    let mut smoke = false;
    let mut shots: Option<PathBuf> = None;
    let mut port: Option<u16> = None;
    let mut it = rest.iter();
    while let Some(a) = it.next() {
        let mut value = |name: &str| -> Result<String, u8> {
            it.next().cloned().ok_or_else(|| {
                let _ = writeln!(err, "error: {name} needs a value");
                EXIT_USAGE
            })
        };
        match a.as_str() {
            "--help" | "-h" => {
                let _ = write!(out, "{}", usage());
                return EXIT_OK;
            }
            "--config" => match value("--config") {
                Ok(v) => cfg_path = Some(v),
                Err(c) => return c,
            },
            "--smoke-test" => smoke = true,
            "--screenshots" => match value("--screenshots") {
                Ok(v) => shots = Some(PathBuf::from(v)),
                Err(c) => return c,
            },
            "--port" => match value("--port").map(|v| v.parse::<u16>()) {
                Ok(Ok(p)) => port = Some(p),
                Ok(Err(_)) => {
                    let _ = writeln!(err, "error: --port must be an integer 0..65535");
                    return EXIT_USAGE;
                }
                Err(c) => return c,
            },
            other => {
                let _ = writeln!(err, "error: unknown option '{other}' for 'ui'\nRun 'evosim --help' for usage.");
                return EXIT_USAGE;
            }
        }
    }
    if smoke && shots.is_some() {
        let _ = writeln!(err, "error: --smoke-test and --screenshots cannot be combined");
        return EXIT_USAGE;
    }
    if port.is_some() && (smoke || shots.is_some()) {
        let _ = writeln!(err, "error: --port is only used by the interactive UI");
        return EXIT_USAGE;
    }
    let cfg = match cfg_path {
        Some(p) => match load_config_file(&p) {
            Ok(c) => c,
            Err(e) => {
                let _ = writeln!(err, "error: {e}");
                return EXIT_USAGE;
            }
        },
        None => match config::preset("default") {
            Ok(c) => c,
            Err(e) => {
                let _ = writeln!(err, "error: {e}");
                return EXIT_USAGE;
            }
        },
    };
    let mode = if smoke {
        UiMode::Smoke
    } else if let Some(d) = shots {
        UiMode::Screenshots(d)
    } else {
        UiMode::Interactive { port: port.unwrap_or(DEFAULT_PORT) }
    };
    evosim_ui::run(UiOptions { config: cfg, mode }, out, err)
}

//! Command dispatch for the `evosim` binary (docs/CONTRACT.md section 2).
//!
//! Hand-written argument parsing (ADR-001): small surface, exact control over
//! exit status 2 and stderr messages. Logs and errors go to `err`; only the
//! documented output goes to `out`.

use evosim_core::config::{self, Config};
use std::io::Write;

pub mod batch;
mod io;
pub mod perf;
pub mod run;
pub mod ui;

/// Exit status for success.
pub const EXIT_OK: u8 = 0;
/// Exit status for usage errors / invalid input (contract section 5.4).
pub const EXIT_USAGE: u8 = 2;

/// Usage text listing all commands.
pub fn usage() -> String {
    format!(
        "{name} {ver} - Evolution Simulation (contract {contract})

Usage:
  evosim <command> [options]

Commands:
  version   Print product name, version and contract version as JSON
  run       Run a headless simulation and write a result JSON (no display needed)
  batch     Run a configuration for several seeds and parameter values, write per-run results + summary
  ui        Start the local browser user interface (world view, legend, pan/zoom)
  config    Configuration tools: presets | show --preset NAME | validate FILE [--print] | schema
  climate   Inspect the climate: climate map [options] (biome map as text, JSON or PPM image)
            | climate series --x X --y Y [options] (seasonal + weather time series of one cell, JSON)
  spatial   Spatial index tools: spatial bench [options] (index vs brute force timing, JSON)
  ecology   Food-chain survival report: ecology survival [options] (extinction tick per seed and kind)
  perf      Throughput benchmark: ticks per second in a fixed reproducible setup (JSON report)
  help      Show this help (also: --help, -h)

run:   evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--metrics FILE] [--save FILE]
       evosim run --load FILE   --ticks N --out FILE [--sample-every K] [--metrics FILE] [--save FILE]
       simulates exactly N ticks (N >= 0, also after extinction) and writes the result JSON
       (docs/CONTRACT.md section 4) to --out; --sample-every defaults to max(1, N/100);
       stdout stays empty, a summary line goes to stderr; errors exit 2 without a result file.
       --metrics FILE also writes per-sample evolution metrics (docs/METRICS.md, same ticks as series)
       --save FILE writes a checkpoint of the complete state after the last tick; --load FILE
       continues from one (--ticks = additional ticks, no --seed); invalid checkpoint -> exit 2
       (format: docs/CHECKPOINTS.md)
batch: evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR
                    [--param KEY=V1,V2,...]... [--sample-every K] [--jobs J]
       runs every seed (and every combination of --param values: cartesian product, KEY = dotted
       config key of 'evosim config schema', values JSON literals) for N ticks; writes
       DIR/seed-<s>.json (same schema as run; with --param: DIR/combo-<c>/seed-<s>.json),
       DIR/summary.json (runs + aggregates), DIR/summary.csv and DIR/aggregates.csv (docs/BATCH.md);
       --jobs worker threads (default: CPU count) do not change any result; errors exit 2, nothing written
ui:    evosim ui [--config FILE] [--port N] | --smoke-test [--config FILE] | --screenshots DIR [--config FILE]
       serves the UI on http://127.0.0.1:N/ (default 8765, busy -> free port; URL printed to stdout);
       default world = preset 'default'; --smoke-test / --screenshots drive headless chromium
       (CHROME_BIN env or 'chromium'), exit 0 ok, 1 automation failure, 2 usage error
config: evosim config presets            list built-in presets
        evosim config show --preset NAME  print the full preset JSON
        evosim config validate FILE [--print]  check a config file (exit 0 ok, 2 invalid)
        evosim config schema              print every parameter as a Markdown table
climate: evosim climate map [--config FILE | --preset NAME] [--seed N] [--width W] [--height H]
                            [--format text|json|ppm] [--out FILE]
        default world: contract example (64x48, seed 42); text/json go to stdout unless --out;
        ppm (binary image, one pixel per cell) requires --out
         evosim climate series --x X --y Y [--ticks N] [--every K] [--no-weather]
                            [--config FILE | --preset NAME] [--seed N] [--width W] [--height H]
        runs the simulation clock N ticks (default: one year) and prints the current
        temperature/precipitation of cell (X, Y) after every K-th tick as JSON
spatial: evosim spatial bench [--width W] [--height H] [--organisms N] [--queries Q]
                            [--radius R] [--seed S]
        defaults 200x200, 2000 organisms (60/30/10 % plants/herbivores/carnivores),
        20000 queries (random center, filter none/plant/herbivore/carnivore), radius 6;
        times SpatialIndex::within_into against brute_force_within, checks identical
        results and prints JSON (exit 2 on bad options or a mismatch)
perf:  evosim perf [--config FILE | --load CHECKPOINT] [--seed N] [--warmup W] [--ticks M] [--repeat R] [--out FILE]
       defaults: contract example configuration, seed 42, warmup 1000 (untimed), 1000 measured ticks,
       3 repetitions on clones of the warmed-up state; prints median ticks/s, phase shares, organism
       min/mean/max and the end state_hash as JSON (docs/PERFORMANCE.md); bad options exit 2
ecology: evosim ecology survival [--config FILE | --preset NAME] [--seeds 1,2,3,4,5] [--ticks N] [--json]
        default: contract example configuration (only fixed keys = default parameters),
        seeds 1,2,3,4,5, 10000 ticks; one thread per seed; prints per seed and kind the
        tick at which the kind died out or that it survived (JSON array with --json)
",
        name = evosim_core::NAME,
        ver = evosim_core::VERSION,
        contract = evosim_core::CONTRACT_VERSION
    )
}

/// Dispatch a command line (without program name). Returns the exit status.
pub fn dispatch(args: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let Some(cmd) = args.first() else {
        let _ = write!(err, "error: no command given\n\n{}", usage());
        return EXIT_USAGE;
    };
    let rest = &args[1..];
    match cmd.as_str() {
        "--help" | "-h" | "help" => {
            let _ = write!(out, "{}", usage());
            EXIT_OK
        }
        "version" | "--version" | "-V" => {
            if let Some(extra) = rest.first() {
                let _ = writeln!(err, "error: 'version' takes no arguments (got '{extra}')");
                return EXIT_USAGE;
            }
            let _ = writeln!(out, "{}", evosim_core::version_json());
            EXIT_OK
        }
        "config" => config_command(rest, out, err),
        "climate" => climate_command(rest, out, err),
        "spatial" => spatial_command(rest, out, err),
        "ecology" => ecology_command(rest, out, err),
        "run" => run::run_command(rest, out, err),
        "batch" => batch::batch_command(rest, out, err),
        "ui" => ui::ui_command(rest, out, err),
        "perf" => perf::perf_command(rest, out, err),
        other => {
            let _ = writeln!(
                err,
                "error: unknown command '{other}'\nRun 'evosim --help' for the list of commands."
            );
            EXIT_USAGE
        }
    }
}

/// Read and validate a configuration file. The error message names the
/// offending key (ConfigError) or the unreadable file.
pub fn load_config_file(path: &str) -> Result<Config, String> {
    let text = std::fs::read_to_string(path).map_err(|e| format!("cannot read config file '{path}': {e}"))?;
    Config::from_json_str(&text).map_err(|e| format!("{path}: {e}"))
}

/// Markdown table of every configuration key (source of docs/CONFIG.md tables).
pub fn schema_markdown() -> String {
    let mut s = String::from("| Key | Type | Default | Range | Meaning |\n|---|---|---|---|---|\n");
    for p in config::schema() {
        let default = p.default.map(|d| format!("`{d}`")).unwrap_or_else(|| "required".into());
        let range = match (p.min, p.max) {
            (Some(a), Some(b)) if p.type_name == "integer" => format!("{} … {}", a as u64, b as u64),
            (Some(a), Some(b)) => format!("{a} … {b}"),
            _ => "—".into(),
        };
        s.push_str(&format!("| `{}` | {} | {} | {} | {} |\n", p.key, p.type_name, default, range, p.doc));
    }
    s
}

fn config_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let args: Vec<&str> = rest.iter().map(String::as_str).collect();
    match args.as_slice() {
        ["presets"] => {
            for n in config::preset_names() {
                let _ = writeln!(out, "{n}\t{}", config::preset_description(n).unwrap_or_default());
            }
            EXIT_OK
        }
        ["show", "--preset", name] => match config::preset(name) {
            Ok(c) => {
                let _ = write!(out, "{}", c.to_json_pretty());
                EXIT_OK
            }
            Err(e) => {
                let _ = writeln!(err, "error: {e}");
                EXIT_USAGE
            }
        },
        ["validate", path] | ["validate", path, "--print"] => match load_config_file(path) {
            Ok(c) => {
                if args.len() == 3 {
                    let _ = write!(out, "{}", c.to_json_pretty());
                }
                let _ = writeln!(err, "config ok: {path}");
                EXIT_OK
            }
            Err(e) => {
                let _ = writeln!(err, "error: {e}");
                EXIT_USAGE
            }
        },
        ["schema"] => {
            let _ = write!(out, "{}", schema_markdown());
            EXIT_OK
        }
        ["--help"] | ["-h"] => {
            let _ = write!(out, "{}", usage());
            EXIT_OK
        }
        _ => {
            let _ = writeln!(
                err,
                "error: usage: evosim config presets | show --preset NAME | validate FILE [--print] | schema"
            );
            EXIT_USAGE
        }
    }
}

/// Options of `evosim climate map`.
#[derive(Debug, Default)]
struct ClimateMapArgs {
    config: Option<String>,
    preset: Option<String>,
    seed: Option<u64>,
    width: Option<u32>,
    height: Option<u32>,
    format: Option<String>,
    out: Option<String>,
}

fn parse_climate_map_args(args: &[String]) -> Result<ClimateMapArgs, String> {
    parse_climate_common(args, "climate map")
}

fn parse_climate_common(args: &[String], sub: &str) -> Result<ClimateMapArgs, String> {
    let mut a = ClimateMapArgs::default();
    let mut it = args.iter();
    while let Some(flag) = it.next() {
        let mut value = || it.next().cloned().ok_or_else(|| format!("option '{flag}' needs a value"));
        fn num<T: std::str::FromStr>(flag: &str, v: String) -> Result<T, String> {
            v.parse().map_err(|_| format!("option '{flag}': invalid integer '{v}'"))
        }
        match flag.as_str() {
            "--config" => a.config = Some(value()?),
            "--preset" => a.preset = Some(value()?),
            "--seed" => a.seed = Some(num(flag, value()?)?),
            "--width" => a.width = Some(num(flag, value()?)?),
            "--height" => a.height = Some(num(flag, value()?)?),
            "--format" => a.format = Some(value()?),
            "--out" => a.out = Some(value()?),
            other => return Err(format!("unknown option '{other}' for '{sub}'")),
        }
    }
    if a.config.is_some() && a.preset.is_some() {
        return Err("use either --config or --preset, not both".into());
    }
    Ok(a)
}

/// Configuration selected by the `climate map` options (validated again after overrides).
fn climate_map_config(a: &ClimateMapArgs) -> Result<Config, String> {
    let mut c = match (&a.config, &a.preset) {
        (Some(path), _) => load_config_file(path)?,
        (_, Some(name)) => config::preset(name).map_err(|e| e.to_string())?,
        _ => Config::contract_example(),
    };
    if let Some(s) = a.seed {
        c.seed = s;
    }
    if let Some(w) = a.width {
        c.world.width = w;
    }
    if let Some(h) = a.height {
        c.world.height = h;
    }
    Config::from_value(&c.to_json_value()).map_err(|e| e.to_string())
}

/// Options of `evosim climate series`.
#[derive(Debug)]
struct ClimateSeriesArgs {
    common: ClimateMapArgs,
    x: u32,
    y: u32,
    ticks: Option<u64>,
    every: u64,
    no_weather: bool,
}

fn parse_climate_series_args(args: &[String]) -> Result<ClimateSeriesArgs, String> {
    let (mut x, mut y, mut ticks, mut every, mut no_weather) = (None, None, None, 1u64, false);
    let mut rest = Vec::new();
    let mut it = args.iter();
    while let Some(flag) = it.next() {
        let mut value = || it.next().cloned().ok_or_else(|| format!("option '{flag}' needs a value"));
        fn num<T: std::str::FromStr>(flag: &str, v: String) -> Result<T, String> {
            v.parse().map_err(|_| format!("option '{flag}': invalid integer '{v}'"))
        }
        match flag.as_str() {
            "--x" => x = Some(num::<u32>(flag, value()?)?),
            "--y" => y = Some(num::<u32>(flag, value()?)?),
            "--ticks" => ticks = Some(num::<u64>(flag, value()?)?),
            "--every" => every = num::<u64>(flag, value()?)?,
            "--no-weather" => no_weather = true,
            "--format" | "--out" => return Err(format!("option '{flag}' is not supported by 'climate series' (JSON on stdout)")),
            _ => {
                rest.push(flag.clone());
                if let Some(v) = it.next() {
                    rest.push(v.clone());
                }
            }
        }
    }
    if every == 0 {
        return Err("option '--every' must be >= 1".into());
    }
    let (Some(x), Some(y)) = (x, y) else {
        return Err("'climate series' needs --x X and --y Y".into());
    };
    let common = parse_climate_common(&rest, "climate series")?;
    Ok(ClimateSeriesArgs { common, x, y, ticks, every, no_weather })
}

/// Runs the simulation clock and returns the JSON series document.
fn climate_series(a: &ClimateSeriesArgs) -> Result<evosim_core::serde_json::Value, String> {
    use evosim_core::serde_json::json;
    use evosim_core::sim::Simulation;
    use evosim_core::topology::Cell;
    let mut cfg = climate_map_config(&a.common)?;
    if a.no_weather {
        cfg.climate.weather_enabled = false;
    }
    if a.x >= cfg.world.width || a.y >= cfg.world.height {
        return Err(format!(
            "cell ({}, {}) is outside the {}x{} world",
            a.x, a.y, cfg.world.width, cfg.world.height
        ));
    }
    let year = cfg.climate.year_length;
    let ticks = a.ticks.unwrap_or(year as u64);
    let weather = cfg.climate.weather_enabled;
    let mut sim = Simulation::new(cfg).map_err(|e| e.to_string())?;
    let b = sim.world().climate_bounds();
    let cell = Cell { x: a.x, y: a.y };
    let mut series = Vec::new();
    for t in 0..ticks {
        sim.step();
        if t % a.every == 0 {
            let now = sim.climate_now(cell);
            series.push(json!({"tick": t, "temperature": now.temperature, "precipitation": now.precipitation}));
        }
    }
    Ok(json!({
        "cell": {"x": a.x, "y": a.y},
        "year_length": year,
        "weather": weather,
        "bounds": {"t_min": b.t_min, "t_max": b.t_max, "p_min": b.p_min, "p_max": b.p_max},
        "series": series,
    }))
}

fn climate_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    use evosim_core::climate::{export, ClimateMap};
    match rest.first().map(String::as_str) {
        Some("map") => {}
        Some("series") => {
            return match parse_climate_series_args(&rest[1..]).and_then(|a| climate_series(&a)) {
                Ok(v) => {
                    let _ = writeln!(out, "{v}");
                    EXIT_OK
                }
                Err(e) => {
                    let _ = writeln!(err, "error: {e}");
                    EXIT_USAGE
                }
            };
        }
        Some("--help") | Some("-h") => {
            let _ = write!(out, "{}", usage());
            return EXIT_OK;
        }
        _ => {
            let _ = writeln!(err, "error: usage: evosim climate map [--config FILE | --preset NAME] [--seed N] [--width W] [--height H] [--format text|json|ppm] [--out FILE]\n       evosim climate series --x X --y Y [--ticks N] [--every K] [--no-weather] [--config FILE | --preset NAME] [--seed N] [--width W] [--height H]");
            return EXIT_USAGE;
        }
    }
    let result = parse_climate_map_args(&rest[1..]).and_then(|a| {
        let cfg = climate_map_config(&a)?;
        let map = ClimateMap::from_config(&cfg).map_err(|e| e.to_string())?;
        let bytes = match a.format.as_deref().unwrap_or("text") {
            "text" => export::to_text(&map).into_bytes(),
            "json" => {
                let mut s = evosim_core::serde_json::to_string_pretty(&export::to_json(&map)).map_err(|e| e.to_string())?;
                s.push('\n');
                s.into_bytes()
            }
            "ppm" if a.out.is_none() => return Err("--format ppm writes a binary image and needs --out FILE".into()),
            "ppm" => export::to_ppm(&map),
            other => return Err(format!("unknown --format '{other}' (text, json or ppm)")),
        };
        Ok((bytes, a.out, map.width(), map.height()))
    });
    match result {
        Ok((bytes, Some(path), w, h)) => match std::fs::write(&path, &bytes) {
            Ok(()) => {
                let _ = writeln!(err, "climate map {w}x{h} written to {path}");
                EXIT_OK
            }
            Err(e) => {
                let _ = writeln!(err, "error: cannot write '{path}': {e}");
                EXIT_USAGE
            }
        },
        Ok((bytes, None, _, _)) => {
            let _ = out.write_all(&bytes);
            EXIT_OK
        }
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            EXIT_USAGE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn call(args: &[&str]) -> (u8, String, String) {
        let args: Vec<String> = args.iter().map(|s| s.to_string()).collect();
        let (mut o, mut e) = (Vec::new(), Vec::new());
        let code = dispatch(&args, &mut o, &mut e);
        (code, String::from_utf8(o).unwrap(), String::from_utf8(e).unwrap())
    }

    #[test]
    fn version_prints_only_json() {
        let (c, o, e) = call(&["version"]);
        assert_eq!(c, 0);
        assert_eq!(o, format!("{}\n", evosim_core::version_json()));
        assert!(e.is_empty());
    }

    #[test]
    fn help_lists_commands() {
        for flag in ["--help", "-h", "help"] {
            let (c, o, _) = call(&[flag]);
            assert_eq!(c, 0);
            for cmd in ["version", "run", "batch", "ui"] {
                assert!(o.contains(cmd), "help misses {cmd}");
            }
        }
    }

    #[test]
    fn errors_exit_2_on_stderr() {
        for args in [&[][..], &["frobnicate"][..], &["version", "x"][..], &["run"][..]] {
            let (c, o, e) = call(args);
            assert_eq!(c, 2, "args {args:?}");
            assert!(o.is_empty());
            assert!(!e.is_empty());
        }
    }

    #[test]
    fn config_doc_table_is_current() {
        let doc = include_str!("../../../docs/CONFIG.md");
        assert!(doc.contains(&schema_markdown()), "docs/CONFIG.md table outdated: regenerate with `evosim config schema`");
    }

    #[test]
    fn climate_map_text_default() {
        let (c, o, e) = call(&["climate", "map"]);
        assert_eq!(c, 0, "{e}");
        let lines: Vec<&str> = o.lines().collect();
        for l in &lines[..48] {
            assert_eq!(l.len(), 64);
            assert!(l.chars().all(|ch| "IUFDSR".contains(ch)));
        }
        assert_eq!(lines[48], "");
        assert!(o.contains("I polar") && o.contains("R tropical"));
        // Deterministic and equal to the core export.
        assert_eq!(call(&["climate", "map"]).1, o);
        let m = evosim_core::climate::ClimateMap::from_config(&Config::contract_example()).unwrap();
        assert_eq!(o, evosim_core::climate::export::to_text(&m));
    }

    #[test]
    fn climate_map_overrides() {
        let (c, o, _) = call(&["climate", "map", "--width", "3", "--height", "1", "--seed", "7"]);
        assert_eq!(c, 0);
        assert_eq!(o.lines().next().unwrap().len(), 3);
        assert_eq!(o.lines().nth(1).unwrap(), "");
        let (c, o, _) = call(&["climate", "map", "--preset", "harsh", "--format", "json"]);
        assert_eq!(c, 0);
        let v: evosim_core::serde_json::Value = evosim_core::serde_json::from_str(&o).unwrap();
        assert_eq!((v["width"].as_u64(), v["height"].as_u64()), (Some(48), Some(36)));
    }

    #[test]
    fn climate_map_bad_args_exit_2() {
        for args in [
            &["climate"][..],
            &["climate", "bogus"][..],
            &["climate", "map", "--format", "svg"][..],
            &["climate", "map", "--format", "ppm"][..],
            &["climate", "map", "--width", "0"][..],
            &["climate", "map", "--width", "x"][..],
            &["climate", "map", "--seed"][..],
            &["climate", "map", "--preset", "nope"][..],
            &["climate", "map", "--config", "/nonexistent/c.json"][..],
            &["climate", "map", "--preset", "lush", "--config", "a.json"][..],
            &["climate", "map", "--frob"][..],
        ] {
            let (c, o, e) = call(args);
            assert_eq!(c, 2, "{args:?}");
            assert!(o.is_empty() && !e.is_empty(), "{args:?}");
        }
    }

    fn series(args: &[&str]) -> evosim_core::serde_json::Value {
        let mut a = vec!["climate", "series"];
        a.extend_from_slice(args);
        let (c, o, e) = call(&a);
        assert_eq!(c, 0, "{e}");
        evosim_core::serde_json::from_str(&o).unwrap()
    }

    #[test]
    fn climate_series_json_and_determinism() {
        let v = series(&["--x", "3", "--y", "2", "--ticks", "50"]);
        assert_eq!(v["series"].as_array().unwrap().len(), 50);
        assert_eq!(v["year_length"], 400);
        assert_eq!(v["weather"], true);
        assert_eq!(v["series"][7]["tick"], 7);
        let (t_min, t_max) = (v["bounds"]["t_min"].as_f64().unwrap(), v["bounds"]["t_max"].as_f64().unwrap());
        for r in v["series"].as_array().unwrap() {
            let t = r["temperature"].as_f64().unwrap();
            let p = r["precipitation"].as_f64().unwrap();
            assert!(t >= t_min && t <= t_max && (0.0..=1.0).contains(&p));
        }
        assert_eq!(series(&["--x", "3", "--y", "2", "--ticks", "50"]), v);
        assert_ne!(series(&["--x", "3", "--y", "2", "--ticks", "50", "--seed", "43"])["series"], v["series"]);
        let d = series(&["--x", "0", "--y", "0", "--every", "100"]);
        assert_eq!(d["series"].as_array().unwrap().len(), 4);
    }

    #[test]
    fn climate_series_no_weather_year_repeats() {
        let v = series(&["--x", "5", "--y", "1", "--no-weather", "--preset", "harsh", "--ticks", "800"]);
        assert_eq!(v["weather"], false);
        let s = v["series"].as_array().unwrap();
        assert_eq!(s.len(), 800);
        for t in 0..400 {
            assert_eq!(s[t]["temperature"], s[t + 400]["temperature"], "t={t}");
            assert_eq!(s[t]["precipitation"], s[t + 400]["precipitation"], "t={t}");
        }
        assert_ne!(s[100]["temperature"], s[300]["temperature"]);
    }

    #[test]
    fn climate_series_bad_args_exit_2() {
        for args in [
            &["climate", "series"][..],
            &["climate", "series", "--x", "1"][..],
            &["climate", "series", "--x", "64", "--y", "0"][..],
            &["climate", "series", "--x", "0", "--y", "48"][..],
            &["climate", "series", "--x", "0", "--y", "0", "--every", "0"][..],
            &["climate", "series", "--x", "0", "--y", "0", "--format", "text"][..],
            &["climate", "series", "--x", "0", "--y", "0", "--frob", "1"][..],
            &["climate", "series", "--x", "-1", "--y", "0"][..],
        ] {
            let (c, o, e) = call(args);
            assert_eq!(c, 2, "{args:?}");
            assert!(o.is_empty() && !e.is_empty(), "{args:?}");
        }
    }

    #[test]
    fn config_usage_errors_exit_2() {
        for args in [&["config"][..], &["config", "show"][..], &["config", "validate"][..], &["config", "bogus"][..]] {
            let (c, o, e) = call(args);
            assert_eq!(c, 2, "{args:?}");
            assert!(o.is_empty() && !e.is_empty());
        }
    }
}

/// Options of `evosim spatial bench`.
#[derive(Debug, Clone, PartialEq)]
pub struct SpatialBenchArgs {
    pub width: u32,
    pub height: u32,
    pub organisms: u64,
    pub queries: u64,
    pub radius: u32,
    pub seed: u64,
}

impl Default for SpatialBenchArgs {
    fn default() -> Self {
        SpatialBenchArgs { width: 200, height: 200, organisms: 2000, queries: 20000, radius: 6, seed: 1 }
    }
}

fn parse_spatial_bench_args(args: &[String]) -> Result<SpatialBenchArgs, String> {
    let mut a = SpatialBenchArgs::default();
    let mut it = args.iter();
    while let Some(flag) = it.next() {
        let v = it.next().ok_or_else(|| format!("option '{flag}' needs a value"))?;
        fn num<T: std::str::FromStr>(flag: &str, v: &str) -> Result<T, String> {
            v.parse().map_err(|_| format!("invalid value '{v}' for '{flag}'"))
        }
        match flag.as_str() {
            "--width" => a.width = num(flag, v)?,
            "--height" => a.height = num(flag, v)?,
            "--organisms" => a.organisms = num(flag, v)?,
            "--queries" => a.queries = num(flag, v)?,
            "--radius" => a.radius = num(flag, v)?,
            "--seed" => a.seed = num(flag, v)?,
            other => return Err(format!("unknown option '{other}' for 'spatial bench'")),
        }
    }
    if a.queries == 0 {
        return Err("--queries must be at least 1".into());
    }
    Ok(a)
}

/// Run the spatial benchmark (wall-clock timing lives here, never in core).
pub fn spatial_bench(a: &SpatialBenchArgs) -> Result<evosim_core::serde_json::Value, String> {
    use evosim_core::ids::EntityId;
    use evosim_core::organism::Kind;
    use evosim_core::rng::Rng;
    use evosim_core::spatial::{brute_force_within, Neighbour, SpatialIndex};
    use evosim_core::topology::{Cell, Torus};
    use std::time::Instant;

    let torus = Torus::new(a.width, a.height).map_err(|e| e.to_string())?;
    let mut rng = Rng::seed_from_u64(a.seed);
    let mut index = SpatialIndex::new(torus);
    let mut entries: Vec<(EntityId, Kind, Cell)> = Vec::with_capacity(a.organisms as usize);
    let rand_cell = |rng: &mut Rng| Cell::new(rng.below(a.width as u64) as u32, rng.below(a.height as u64) as u32);
    for n in 1..=a.organisms {
        let roll = rng.below(10);
        let kind = if roll < 6 { Kind::Plant } else if roll < 9 { Kind::Herbivore } else { Kind::Carnivore };
        let c = rand_cell(&mut rng);
        index.insert(EntityId(n), kind, c).map_err(|e| e.to_string())?;
        entries.push((EntityId(n), kind, c));
    }
    let queries: Vec<(Cell, Option<Kind>)> = (0..a.queries)
        .map(|_| {
            let c = rand_cell(&mut rng);
            let f = match rng.below(4) {
                0 => None,
                k => Some(Kind::ALL[k as usize - 1]),
            };
            (c, f)
        })
        .collect();

    let mut buf: Vec<Neighbour> = Vec::new();
    let mut idx_results: Vec<Vec<Neighbour>> = Vec::with_capacity(queries.len());
    let start = Instant::now();
    for &(c, f) in &queries {
        index.within_into(c, a.radius, f, &mut buf);
        idx_results.push(buf.clone());
    }
    let idx_ns = start.elapsed().as_nanos() as f64;

    let mut brute_results: Vec<Vec<Neighbour>> = Vec::with_capacity(queries.len());
    let start = Instant::now();
    for &(c, f) in &queries {
        brute_results.push(brute_force_within(&torus, entries.iter().copied(), c, a.radius, f));
    }
    let brute_ns = start.elapsed().as_nanos() as f64;

    let identical = idx_results == brute_results;
    let hits: usize = idx_results.iter().map(|v| v.len()).sum();
    let q = queries.len() as f64;
    let idx_per = idx_ns / q;
    let brute_per = brute_ns / q;
    let speedup = if idx_per > 0.0 { brute_per / idx_per } else { f64::INFINITY };
    let round1 = |x: f64| (x * 10.0).round() / 10.0;
    Ok(evosim_core::serde_json::json!({
        "width": a.width,
        "height": a.height,
        "organisms": a.organisms,
        "queries": a.queries,
        "radius": a.radius,
        "seed": a.seed,
        "index_ns_per_query": round1(idx_per),
        "brute_ns_per_query": round1(brute_per),
        "speedup": round1(speedup),
        "identical": identical,
        "hits": hits,
        "index_total_ms": round1(idx_ns / 1e6),
        "brute_total_ms": round1(brute_ns / 1e6),
        "index_scan": if index.uses_locator_scan(a.radius) { "locator" } else { "cells" },
    }))
}

fn spatial_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    match rest.first().map(|s| s.as_str()) {
        Some("bench") => {}
        Some("--help") | Some("-h") => {
            let _ = write!(out, "{}", usage());
            return EXIT_OK;
        }
        _ => {
            let _ = writeln!(err, "error: usage: evosim spatial bench [--width W] [--height H] [--organisms N] [--queries Q] [--radius R] [--seed S]");
            return EXIT_USAGE;
        }
    }
    let a = match parse_spatial_bench_args(&rest[1..]) {
        Ok(a) => a,
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            return EXIT_USAGE;
        }
    };
    match spatial_bench(&a) {
        Ok(v) => {
            let ok = v["identical"] == true;
            let _ = writeln!(out, "{v}");
            if ok {
                EXIT_OK
            } else {
                let _ = writeln!(err, "error: index results differ from brute force");
                EXIT_USAGE
            }
        }
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            EXIT_USAGE
        }
    }
}

struct EcologyArgs {
    config: Option<String>,
    preset: Option<String>,
    seeds: Vec<u64>,
    ticks: u64,
    json: bool,
}

fn parse_ecology_args(args: &[String]) -> Result<EcologyArgs, String> {
    let mut a = EcologyArgs { config: None, preset: None, seeds: vec![1, 2, 3, 4, 5], ticks: 10_000, json: false };
    let mut it = args.iter();
    while let Some(flag) = it.next() {
        let mut value = || it.next().cloned().ok_or_else(|| format!("option '{flag}' needs a value"));
        match flag.as_str() {
            "--config" => a.config = Some(value()?),
            "--preset" => a.preset = Some(value()?),
            "--seeds" => {
                let v = value()?;
                a.seeds = v
                    .split(',')
                    .map(|x| x.trim().parse::<u64>().map_err(|_| format!("invalid seed '{x}' in --seeds")))
                    .collect::<Result<_, _>>()?;
            }
            "--ticks" => {
                let v = value()?;
                a.ticks = v.parse().map_err(|_| format!("invalid value '{v}' for --ticks"))?;
            }
            "--json" => a.json = true,
            other => return Err(format!("unknown option '{other}' for 'ecology survival'")),
        }
    }
    if a.config.is_some() && a.preset.is_some() {
        return Err("--config and --preset are mutually exclusive".into());
    }
    if a.seeds.is_empty() {
        return Err("--seeds needs at least one seed".into());
    }
    Ok(a)
}

fn ecology_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    match rest.first().map(String::as_str) {
        Some("survival") => {}
        Some("--help") | Some("-h") => {
            let _ = write!(out, "{}", usage());
            return EXIT_OK;
        }
        _ => {
            let _ = writeln!(err, "error: usage: evosim ecology survival [--config FILE | --preset NAME] [--seeds 1,2,3,4,5] [--ticks N] [--json]");
            return EXIT_USAGE;
        }
    }
    let a = match parse_ecology_args(&rest[1..]) {
        Ok(a) => a,
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            return EXIT_USAGE;
        }
    };
    let cfg = match (&a.config, &a.preset) {
        (Some(p), _) => load_config_file(p),
        (_, Some(n)) => config::preset(n).map_err(|e| e.to_string()),
        _ => Ok(Config::contract_example()),
    };
    let cfg = match cfg {
        Ok(c) => c,
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            return EXIT_USAGE;
        }
    };
    let started = std::time::Instant::now();
    let res = match evosim_core::ecology::survival_runs(&cfg, &a.seeds, a.ticks) {
        Ok(r) => r,
        Err(e) => {
            let _ = writeln!(err, "error: {e}");
            return EXIT_USAGE;
        }
    };
    if a.json {
        let v: Vec<_> = res.iter().map(evosim_core::ecology::outcome_json).collect();
        let _ = writeln!(out, "{}", evosim_core::serde_json::Value::Array(v));
    } else {
        for o in &res {
            let _ = writeln!(out, "{}", evosim_core::ecology::format_line(o));
        }
    }
    let _ = writeln!(err, "ecology survival: {} seeds x {} ticks in {:.1} s", a.seeds.len(), a.ticks, started.elapsed().as_secs_f64());
    EXIT_OK
}

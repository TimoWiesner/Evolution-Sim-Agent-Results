//! `evosim batch` (TASK-021, ADR-024, docs/BATCH.md, docs/CONTRACT.md §2).
//!
//! Validation first (arguments, config, every sweep combination, every
//! `Simulation::new`, out-dir), then the runs on `--jobs` worker threads
//! (results stored by run index, so the output does not depend on
//! scheduling), then all files are written atomically in index order:
//! per-seed result files, `summary.json`, `summary.csv`, `aggregates.csv`.

use evosim_core::batch::{
    aggregates_csv, expand, parse_param, parse_seeds, summary_csv, summary_json, BatchMeta, RunOutcome, RunSpec, Sweep,
};
use evosim_core::report::{default_sample_every, result_json, run_recorded};
use evosim_core::serde_json::{self, Value};
use evosim_core::sim::Simulation;
use std::io::Write;
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Instant;

use crate::io::write_atomic;
use crate::{load_config_file, usage, EXIT_OK, EXIT_USAGE};

const BATCH_USAGE: &str = "Usage: evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR \
[--param KEY=V1,V2,...]... [--sample-every K] [--jobs J]";

/// Parsed `batch` arguments.
#[derive(Debug, Clone, PartialEq)]
pub struct BatchArgs {
    pub config: String,
    pub seeds: Vec<u64>,
    pub ticks: u64,
    pub out_dir: String,
    pub sweeps: Vec<Sweep>,
    pub sample_every: Option<u64>,
    pub jobs: Option<usize>,
}

fn parse_u64(flag: &str, v: &str) -> Result<u64, String> {
    if v.is_empty() || !v.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("{flag} needs a non-negative integer, got '{v}'"));
    }
    v.parse::<u64>().map_err(|_| format!("{flag} value '{v}' is out of range"))
}

/// Parse `batch` arguments (without the command word). `Ok(None)` = `--help`.
pub fn parse_batch_args(args: &[String]) -> Result<Option<BatchArgs>, String> {
    let (mut config, mut seeds, mut ticks, mut out_dir, mut sample, mut jobs) = (None, None, None, None, None, None);
    let mut sweeps: Vec<Sweep> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].as_str();
        match flag {
            "--help" | "-h" => return Ok(None),
            "--config" | "--seeds" | "--ticks" | "--out-dir" | "--param" | "--sample-every" | "--jobs" => {
                let Some(v) = args.get(i + 1) else {
                    return Err(format!("{flag} needs a value"));
                };
                let dup = match flag {
                    "--config" => config.replace(v.clone()).is_some(),
                    "--seeds" => seeds.replace(parse_seeds(v)?).is_some(),
                    "--ticks" => ticks.replace(parse_u64(flag, v)?).is_some(),
                    "--out-dir" => out_dir.replace(v.clone()).is_some(),
                    "--param" => {
                        let s = parse_param(v)?;
                        if sweeps.iter().any(|o| o.key == s.key) {
                            return Err(format!("--param {} given more than once", s.key));
                        }
                        sweeps.push(s);
                        false
                    }
                    "--sample-every" => {
                        let k = parse_u64(flag, v)?;
                        if k == 0 {
                            return Err("--sample-every must be at least 1".into());
                        }
                        sample.replace(k).is_some()
                    }
                    _ => {
                        let j = parse_u64(flag, v)?;
                        if j == 0 || j > 1024 {
                            return Err("--jobs must be between 1 and 1024".into());
                        }
                        jobs.replace(j as usize).is_some()
                    }
                };
                if dup {
                    return Err(format!("{flag} given more than once"));
                }
                i += 2;
            }
            other if other.starts_with('-') => return Err(format!("unknown option '{other}' for 'batch'")),
            other => return Err(format!("unexpected argument '{other}' for 'batch'")),
        }
    }
    let config = config.ok_or("missing required option --config FILE")?;
    let seeds = seeds.ok_or("missing required option --seeds S1,S2,...")?;
    let ticks = ticks.ok_or("missing required option --ticks N")?;
    let out_dir = out_dir.ok_or("missing required option --out-dir DIR")?;
    if config.is_empty() || out_dir.is_empty() {
        return Err("--config and --out-dir need a non-empty path".into());
    }
    Ok(Some(BatchArgs { config, seeds, ticks, out_dir, sweeps, sample_every: sample, jobs }))
}

/// One finished run: result JSON and its pretty text.
type Finished = (Value, String);

/// Run all specs on `jobs` threads; results by index.
fn run_all(specs: &[RunSpec], ticks: u64, k: u64, jobs: usize) -> Result<Vec<Finished>, String> {
    let slots: Mutex<Vec<Option<Result<Finished, String>>>> = Mutex::new(vec![None; specs.len()]);
    let next = AtomicUsize::new(0);
    std::thread::scope(|scope| {
        for _ in 0..jobs.min(specs.len()).max(1) {
            scope.spawn(|| loop {
                let i = next.fetch_add(1, Ordering::Relaxed);
                let Some(spec) = specs.get(i) else { break };
                let res = Simulation::new(spec.config.clone())
                    .map_err(|e| format!("run {} (seed {}): cannot create the simulation: {e:?}", spec.index, spec.seed))
                    .and_then(|mut sim| {
                        let start = Instant::now();
                        let rec = run_recorded(&mut sim, ticks, k);
                        let v = result_json(&sim, &rec, start.elapsed().as_secs_f64());
                        let text = serde_json::to_string_pretty(&v).map_err(|e| format!("cannot serialise result: {e}"))?;
                        Ok((v, text + "\n"))
                    });
                slots.lock().expect("no poisoned lock")[i] = Some(res);
            });
        }
    });
    slots.into_inner().expect("no poisoned lock").into_iter().map(|s| s.expect("every run executed")).collect()
}

/// The `batch` command. stdout stays empty; progress and errors go to `err`.
pub fn batch_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let fail = |err: &mut dyn Write, msg: String| {
        let _ = writeln!(err, "error: batch: {msg}");
        EXIT_USAGE
    };
    let a = match parse_batch_args(rest) {
        Ok(Some(a)) => a,
        Ok(None) => {
            let _ = write!(out, "{}", usage());
            return EXIT_OK;
        }
        Err(e) => return fail(err, format!("{e}\n{BATCH_USAGE}")),
    };
    // The unmodified file first, so errors are identical to `run`.
    if let Err(e) = load_config_file(&a.config) {
        return fail(err, e);
    }
    let base: Value = match std::fs::read_to_string(&a.config).map_err(|e| e.to_string()).and_then(|t| serde_json::from_str(&t).map_err(|e| e.to_string())) {
        Ok(v) => v,
        Err(e) => return fail(err, format!("cannot read config file '{}': {e}", a.config)),
    };
    let (combos, specs) = match expand(&base, &a.sweeps, &a.seeds) {
        Ok(x) => x,
        Err(e) => return fail(err, e),
    };
    for s in &specs {
        if let Err(e) = Simulation::new(s.config.clone()) {
            return fail(err, format!("run {} (seed {}): cannot create the simulation: {e:?}", s.index, s.seed));
        }
    }
    let dir = PathBuf::from(&a.out_dir);
    if dir.exists() && !dir.is_dir() {
        return fail(err, format!("--out-dir '{}' exists and is not a directory", a.out_dir));
    }
    let has_sweep = !a.sweeps.is_empty();
    let mut targets: Vec<PathBuf> = specs.iter().map(|s| dir.join(&s.file)).collect();
    targets.extend(["summary.json", "summary.csv", "aggregates.csv"].map(|f| dir.join(f)));
    if let Some(t) = targets.iter().find(|t| t.is_dir()) {
        return fail(err, format!("output file '{}' is a directory", t.display()));
    }
    if has_sweep {
        if let Some(c) = combos.iter().map(|c| dir.join(c.dir(true))).find(|p| p.exists() && !p.is_dir()) {
            return fail(err, format!("'{}' exists and is not a directory", c.display()));
        }
    }
    let k = a.sample_every.unwrap_or_else(|| default_sample_every(a.ticks));
    let jobs = a.jobs.unwrap_or_else(|| std::thread::available_parallelism().map_or(1, |n| n.get())).min(specs.len()).max(1);
    let _ = writeln!(err, "batch: {} runs ({} combinations x {} seeds), {} ticks each, {jobs} jobs", specs.len(), combos.len(), a.seeds.len(), a.ticks);

    let wall = Instant::now();
    let finished = match run_all(&specs, a.ticks, k, jobs) {
        Ok(f) => f,
        Err(e) => return fail(err, e),
    };
    let wall_seconds = wall.elapsed().as_secs_f64();
    let mut outcomes = Vec::with_capacity(specs.len());
    for (s, (v, _)) in specs.iter().zip(&finished) {
        match RunOutcome::from_result(s, v) {
            Ok(o) => outcomes.push(o),
            Err(e) => return fail(err, e),
        }
    }
    let meta = BatchMeta {
        config_file: a.config.clone(),
        ticks: a.ticks,
        sample_every: k,
        seeds: a.seeds.clone(),
        sweeps: a.sweeps.clone(),
        wall_seconds,
        jobs,
    };
    let summary = summary_json(&meta, &combos, &outcomes);
    let summary_text = match serde_json::to_string_pretty(&summary) {
        Ok(t) => t + "\n",
        Err(e) => return fail(err, format!("cannot serialise the summary: {e}")),
    };
    let runs_csv = summary_csv(&a.sweeps, &combos, &outcomes);
    let agg_csv = aggregates_csv(&a.sweeps, &summary);

    let mut dirs = vec![dir.clone()];
    if has_sweep {
        dirs.extend(combos.iter().map(|c| dir.join(c.dir(true))));
    }
    for d in &dirs {
        if let Err(e) = std::fs::create_dir_all(d) {
            return fail(err, format!("cannot create directory '{}': {e}", d.display()));
        }
    }
    let texts = finished.iter().map(|(_, t)| t.as_str()).chain([summary_text.as_str(), runs_csv.as_str(), agg_csv.as_str()]);
    for (path, text) in targets.iter().zip(texts) {
        if let Err(e) = write_atomic(path, text) {
            return fail(err, e);
        }
    }
    for o in &outcomes {
        let _ = writeln!(
            err,
            "batch: run {} combo {} seed {}: final {}/{}/{} in {:.3} s -> {}",
            o.index, o.combo, o.seed, o.final_counts[0], o.final_counts[1], o.final_counts[2], o.elapsed_seconds, o.file
        );
    }
    let all = &summary["aggregates"]["all"];
    let _ = writeln!(
        err,
        "batch: {} runs in {:.3} s, coexistence in {} runs, summary -> {}",
        specs.len(),
        wall_seconds,
        all["coexistence_runs"],
        dir.join("summary.json").display()
    );
    EXIT_OK
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(a: &[&str]) -> Result<Option<BatchArgs>, String> {
        parse_batch_args(&a.iter().map(|s| s.to_string()).collect::<Vec<_>>())
    }

    #[test]
    fn parses_minimal_and_full() {
        let r = p(&["--config", "c.json", "--seeds", "1,2,3", "--ticks", "10", "--out-dir", "d"]).unwrap().unwrap();
        assert_eq!((r.config.as_str(), r.seeds.clone(), r.ticks, r.out_dir.as_str()), ("c.json", vec![1, 2, 3], 10, "d"));
        assert!(r.sweeps.is_empty() && r.jobs.is_none() && r.sample_every.is_none());
        let r = p(&[
            "--param", "plants.growth_rate=0.8,1.2", "--config", "c", "--seeds", "1", "--ticks", "0", "--out-dir", "d",
            "--param", "initial.carnivores=0,4", "--jobs", "3", "--sample-every", "5",
        ])
        .unwrap()
        .unwrap();
        assert_eq!(r.sweeps.len(), 2);
        assert_eq!(r.sweeps[1].key, "initial.carnivores");
        assert_eq!((r.jobs, r.sample_every), (Some(3), Some(5)));
        assert_eq!(p(&["--help"]).unwrap(), None);
    }

    #[test]
    fn rejects_bad_arguments() {
        let base = ["--config", "c", "--seeds", "1,2", "--ticks", "5", "--out-dir", "d"];
        for drop in 0..4 {
            let mut a = base.to_vec();
            a.drain(drop * 2..drop * 2 + 2);
            assert!(p(&a).is_err(), "{a:?}");
        }
        for extra in [
            vec!["--seeds", "3"],
            vec!["--jobs", "0"],
            vec!["--jobs", "x"],
            vec!["--sample-every", "0"],
            vec!["--param", "k"],
            vec!["--param", "seed=1,2"],
            vec!["--param", "a=1", "--param", "a=2"],
            vec!["--frob"],
            vec!["stray"],
            vec!["--param"],
        ] {
            let mut a = base.to_vec();
            a.extend(extra.iter());
            assert!(p(&a).is_err(), "{a:?}");
        }
        assert!(p(&["--config", "c", "--seeds", "1,1", "--ticks", "5", "--out-dir", "d"]).is_err());
        assert!(p(&["--config", "c", "--seeds", "", "--ticks", "5", "--out-dir", "d"]).is_err());
    }
}

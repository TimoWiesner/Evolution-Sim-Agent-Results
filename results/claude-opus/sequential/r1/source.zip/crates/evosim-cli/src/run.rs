//! `evosim run` (TASK-019, ADR-022 §4, docs/CONTRACT.md §2/§4/§5).
//!
//! All validation happens before the loop; nothing is written on error. The
//! result is written to a temporary file next to `--out` and renamed onto it.
//! `--metrics FILE` (TASK-020, ADR-023, docs/METRICS.md) additionally writes
//! the metrics document the same way; the result JSON is unchanged.
//! `--load FILE` (TASK-022, ADR-025, docs/CHECKPOINTS.md) starts from a
//! checkpoint instead of `--config`; `--save FILE` writes one after the last
//! tick. An invalid checkpoint is exit 2 with no file written.

use evosim_core::metrics::MetricsRecorder;
use evosim_core::report::{default_sample_every, result_json, run_observed};
use evosim_core::sim::Simulation;
use evosim_core::snapshot;
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::io::{check_out_path, write_atomic};
use crate::{load_config_file, usage, EXIT_OK, EXIT_USAGE};

/// Parsed `run` arguments.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RunArgs {
    /// `--config FILE` (exactly one of `config` / `load` is set).
    pub config: Option<String>,
    /// `--load FILE`: continue from a checkpoint (TASK-022).
    pub load: Option<String>,
    /// `--save FILE`: write a checkpoint after the last tick (TASK-022).
    pub save: Option<String>,
    pub ticks: u64,
    pub out: String,
    pub seed: Option<u64>,
    pub sample_every: Option<u64>,
    /// Optional metrics file (TASK-020).
    pub metrics: Option<String>,
}

fn parse_u64(flag: &str, v: &str) -> Result<u64, String> {
    if v.is_empty() || !v.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("{flag} needs a non-negative integer, got '{v}'"));
    }
    v.parse::<u64>().map_err(|_| format!("{flag} value '{v}' is out of range"))
}

/// Parse `run` arguments (without the command word). `Ok(None)` = `--help`.
pub fn parse_run_args(args: &[String]) -> Result<Option<RunArgs>, String> {
    let (mut config, mut ticks, mut out, mut seed, mut sample) = (None, None, None, None, None);
    let (mut metrics, mut load, mut save): (Option<String>, Option<String>, Option<String>) = (None, None, None);
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].as_str();
        match flag {
            "--help" | "-h" => return Ok(None),
            "--config" | "--ticks" | "--out" | "--seed" | "--sample-every" | "--metrics" | "--save" | "--load" => {
                let Some(v) = args.get(i + 1) else {
                    return Err(format!("{flag} needs a value"));
                };
                let dup = match flag {
                    "--config" => config.replace(v.clone()).is_some(),
                    "--ticks" => ticks.replace(parse_u64(flag, v)?).is_some(),
                    "--out" => out.replace(v.clone()).is_some(),
                    "--seed" => seed.replace(parse_u64(flag, v)?).is_some(),
                    "--metrics" | "--save" | "--load" => {
                        if v.is_empty() {
                            return Err(format!("{flag} needs a non-empty path"));
                        }
                        let slot = match flag {
                            "--metrics" => &mut metrics,
                            "--save" => &mut save,
                            _ => &mut load,
                        };
                        slot.replace(v.clone()).is_some()
                    }
                    _ => {
                        let k = parse_u64(flag, v)?;
                        if k == 0 {
                            return Err("--sample-every must be at least 1".into());
                        }
                        sample.replace(k).is_some()
                    }
                };
                if dup {
                    return Err(format!("{flag} given more than once"));
                }
                i += 2;
            }
            other if other.starts_with('-') => return Err(format!("unknown option '{other}' for 'run'")),
            other => return Err(format!("unexpected argument '{other}' for 'run'")),
        }
    }
    match (&config, &load) {
        (None, None) => return Err("missing required option --config FILE (or --load FILE)".into()),
        (Some(_), Some(_)) => return Err("--config and --load are mutually exclusive".into()),
        _ => {}
    }
    if load.is_some() && seed.is_some() {
        return Err("--seed cannot be used with --load (the seed is part of the checkpoint)".into());
    }
    let ticks = ticks.ok_or("missing required option --ticks N")?;
    let out = out.ok_or("missing required option --out FILE")?;
    if config.as_deref() == Some("") || out.is_empty() {
        return Err("--config and --out need a non-empty path".into());
    }
    if let Some(m) = &metrics {
        if *m == out {
            return Err("--metrics must differ from --out".into());
        }
    }
    if let Some(sv) = &save {
        if *sv == out || metrics.as_deref() == Some(sv.as_str()) {
            return Err("--save must differ from --out and --metrics".into());
        }
    }
    Ok(Some(RunArgs { config, load, save, ticks, out, seed, sample_every: sample, metrics }))
}

/// Same path after canonicalising the parent directories (the files need not
/// exist yet).
fn same_file(a: &Path, b: &Path) -> bool {
    let canon = |p: &Path| {
        let parent = match p.parent() {
            Some(d) if !d.as_os_str().is_empty() => d.to_path_buf(),
            _ => PathBuf::from("."),
        };
        parent.canonicalize().ok().map(|d| d.join(p.file_name().unwrap_or_default()))
    };
    match (canon(a), canon(b)) {
        (Some(x), Some(y)) => x == y,
        _ => a == b,
    }
}

const RUN_USAGE: &str = "Usage: evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--metrics FILE] [--save FILE]\n       evosim run --load FILE --ticks N --out FILE [--sample-every K] [--metrics FILE] [--save FILE]";

/// Read and fully validate a checkpoint file (ADR-025). Every failure is a
/// one-line message (the caller exits 2).
pub fn load_checkpoint_file(path: &str) -> Result<Simulation, String> {
    let p = Path::new(path);
    if p.is_dir() {
        return Err(format!("cannot read checkpoint '{path}': is a directory"));
    }
    let bytes = std::fs::read(p).map_err(|e| format!("cannot read checkpoint '{path}': {e}"))?;
    let text = String::from_utf8(bytes).map_err(|_| format!("invalid checkpoint '{path}': not UTF-8 text (damaged)"))?;
    snapshot::from_json_str(&text).map_err(|e| format!("invalid checkpoint '{path}': {e}"))
}

/// Checkpoint text of `sim`, verified by decoding it again (save self-check,
/// ADR-025 §3) before anything is written.
fn checkpoint_text(sim: &Simulation) -> Result<String, String> {
    let text = snapshot::to_json_string(sim).map_err(|e| format!("cannot write checkpoint: {e}"))?;
    let back = snapshot::from_json_str(&text).map_err(|e| format!("checkpoint self-check failed: {e}"))?;
    if back.state_hash() != sim.state_hash() {
        return Err("checkpoint self-check failed: state hash differs after decoding".into());
    }
    Ok(text)
}

/// The `run` command. stdout stays empty; errors and the summary go to `err`.
pub fn run_command(rest: &[String], out: &mut impl Write, err: &mut impl Write) -> u8 {
    let fail = |err: &mut dyn Write, msg: String| {
        let _ = writeln!(err, "error: run: {msg}");
        EXIT_USAGE
    };
    let a = match parse_run_args(rest) {
        Ok(Some(a)) => a,
        Ok(None) => {
            let _ = write!(out, "{}", usage());
            return EXIT_OK;
        }
        Err(e) => return fail(err, format!("{e}\n{RUN_USAGE}")),
    };
    let out_path = match check_out_path("--out", &a.out) {
        Ok(p) => p,
        Err(e) => return fail(err, e),
    };
    let metrics_path = match a.metrics.as_deref().map(|m| check_out_path("--metrics", m)).transpose() {
        Ok(p) => p,
        Err(e) => return fail(err, e),
    };
    if let Some(m) = &metrics_path {
        if same_file(m, &out_path) {
            return fail(err, "--metrics must differ from --out".into());
        }
    }
    let save_path = match a.save.as_deref().map(|p| check_out_path("--save", p)).transpose() {
        Ok(p) => p,
        Err(e) => return fail(err, e),
    };
    if let Some(sp) = &save_path {
        if same_file(sp, &out_path) || metrics_path.as_ref().is_some_and(|m| same_file(sp, m)) {
            return fail(err, "--save must differ from --out and --metrics".into());
        }
    }
    let mut sim = match (&a.config, &a.load) {
        (Some(c), _) => {
            let mut cfg = match load_config_file(c) {
                Ok(c) => c,
                Err(e) => return fail(err, e),
            };
            if let Some(s) = a.seed {
                cfg = cfg.with_seed(s);
            }
            match Simulation::new(cfg) {
                Ok(s) => s,
                Err(e) => return fail(err, format!("cannot create the simulation: {e:?}")),
            }
        }
        (None, Some(l)) => match load_checkpoint_file(l) {
            Ok(s) => s,
            Err(e) => return fail(err, e),
        },
        (None, None) => unreachable!("parse_run_args requires --config or --load"),
    };
    let k = a.sample_every.unwrap_or_else(|| default_sample_every(a.ticks));
    let start = std::time::Instant::now();
    let mut recorder = metrics_path.as_ref().map(|_| MetricsRecorder::new());
    let rec = run_observed(&mut sim, a.ticks, k, |s| {
        if let Some(r) = recorder.as_mut() {
            r.record(s);
        }
    });
    let elapsed = start.elapsed().as_secs_f64();
    let seed = sim.config().seed;
    let v = result_json(&sim, &rec, elapsed);
    let text = match evosim_core::serde_json::to_string_pretty(&v) {
        Ok(t) => t + "\n",
        Err(e) => return fail(err, format!("cannot serialise the result: {e}")),
    };
    let metrics_text = match (&recorder, &metrics_path) {
        (Some(r), Some(_)) => match evosim_core::serde_json::to_string(&r.to_json(seed, &rec)) {
            Ok(t) => Some(t + "\n"),
            Err(e) => return fail(err, format!("cannot serialise the metrics: {e}")),
        },
        _ => None,
    };
    let save_text = match &save_path {
        Some(_) => match checkpoint_text(&sim) {
            Ok(t) => Some(t),
            Err(e) => return fail(err, e),
        },
        None => None,
    };
    // Write order: result, metrics, checkpoint (each atomically); on a
    // failure the files already written by this invocation are removed (no
    // partial output). The checkpoint goes last so an existing checkpoint
    // (`--save` == `--load`) is only replaced once everything else succeeded.
    let mut written: Vec<&Path> = Vec::new();
    let files = [(Some(out_path.as_path()), Some(text.as_str())), (metrics_path.as_deref(), metrics_text.as_deref()), (save_path.as_deref(), save_text.as_deref())];
    for (p, t) in files {
        if let (Some(p), Some(t)) = (p, t) {
            if let Err(e) = write_atomic(p, t) {
                for w in &written {
                    let _ = std::fs::remove_file(w);
                }
                return fail(err, e);
            }
            written.push(p);
        }
    }
    if let Some(sp) = &save_path {
        let _ = writeln!(err, "run: checkpoint at tick {} saved to {}", sim.tick(), sp.display());
    }
    let _ = writeln!(
        err,
        "run: {} ticks in {:.3} s ({:.1} ticks/s), tick {} -> {}, hash {} -> {}",
        a.ticks,
        elapsed,
        v["ticks_per_second"].as_f64().unwrap_or(0.0),
        rec.tick_start,
        rec.tick_end,
        &v["state_hash"].as_str().unwrap_or("")[..12.min(v["state_hash"].as_str().unwrap_or("").len())],
        a.out
    );
    EXIT_OK
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(a: &[&str]) -> Result<Option<RunArgs>, String> {
        parse_run_args(&a.iter().map(|s| s.to_string()).collect::<Vec<_>>())
    }

    #[test]
    fn parses_full_and_minimal() {
        let r = p(&["--config", "c.json", "--ticks", "10", "--out", "o.json"]).unwrap().unwrap();
        assert_eq!(r, RunArgs { config: Some("c.json".into()), load: None, save: None, ticks: 10, out: "o.json".into(), seed: None, sample_every: None, metrics: None });
        let r = p(&["--load", "cp.json", "--ticks", "3", "--out", "o", "--save", "cp.json"]).unwrap().unwrap();
        assert_eq!((r.config, r.load.as_deref(), r.save.as_deref()), (None, Some("cp.json"), Some("cp.json")));
        let r = p(&["--config", "c", "--ticks", "3", "--out", "o", "--save", "s.json", "--seed", "4"]).unwrap().unwrap();
        assert_eq!((r.save.as_deref(), r.seed), (Some("s.json"), Some(4)));
        let r = p(&["--config", "c", "--ticks", "1", "--out", "o", "--metrics", "m.json"]).unwrap().unwrap();
        assert_eq!(r.metrics.as_deref(), Some("m.json"));
        let r = p(&["--out", "o", "--seed", "7", "--sample-every", "3", "--ticks", "0", "--config", "c"]).unwrap().unwrap();
        assert_eq!((r.ticks, r.seed, r.sample_every), (0, Some(7), Some(3)));
        assert_eq!(p(&["--help"]).unwrap(), None);
    }

    #[test]
    fn rejects_bad_arguments() {
        let base = ["--config", "c", "--ticks", "5", "--out", "o"];
        for bad in [
            vec![],
            vec!["--ticks", "5", "--out", "o"],
            vec!["--config", "c", "--out", "o"],
            vec!["--config", "c", "--ticks", "5"],
            vec!["--config", "c", "--ticks", "-1", "--out", "o"],
            vec!["--config", "c", "--ticks", "abc", "--out", "o"],
            vec!["--config", "c", "--ticks", "1.5", "--out", "o"],
            vec!["--config", "c", "--ticks", "", "--out", "o"],
            vec!["--config", "c", "--ticks", "99999999999999999999999", "--out", "o"],
            vec!["--config", "c", "--ticks"],
            vec!["--load", "l", "--ticks", "5", "--out", "o", "--seed", "1"],
            vec!["--load", "", "--ticks", "5", "--out", "o"],
            vec!["--load", "l", "--load", "k", "--ticks", "5", "--out", "o"],
            vec!["--load", "l", "--out", "o"],
        ] {
            assert!(p(&bad).is_err(), "{bad:?}");
        }
        for extra in [
            vec!["--seed", "-3"],
            vec!["--seed", "x"],
            vec!["--sample-every", "0"],
            vec!["--ticks", "6"],
            vec!["--frob"],
            vec!["stray"],
            vec!["--load", "x"],
            vec!["--save"],
            vec!["--save", ""],
            vec!["--save", "s", "--save", "t"],
            vec!["--save", "o"],
            vec!["--save", "m", "--metrics", "m"],
            vec!["--metrics"],
            vec!["--metrics", ""],
            vec!["--metrics", "m", "--metrics", "n"],
            vec!["--metrics", "o"],
        ] {
            let mut a: Vec<&str> = base.to_vec();
            a.extend(extra.iter());
            assert!(p(&a).is_err(), "{a:?}");
        }
    }
}

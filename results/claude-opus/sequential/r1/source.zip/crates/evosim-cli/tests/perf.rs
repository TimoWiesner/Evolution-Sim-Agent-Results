//! TASK-026 (ADR-029 §5): slowdown guard and `evosim perf` CLI smoke test.
use evosim_cli::perf::{measure, parse_perf_args};
use evosim_core::config::Config;
use evosim_core::serde_json::Value;
use evosim_core::sim::Simulation;
use std::process::Command;

/// Default guard threshold in ticks/s: about 13x below the measured
/// optimised value (≈ 337 tps on the reference host) so slow or loaded
/// machines stay green, yet a large regression (e.g. back to an O(n) scan
/// per query) fails. Override with EVOSIM_PERF_MIN_TPS (0 disables).
const MIN_TPS: f64 = 25.0;

#[test]
fn slowdown_guard_release_only() {
    if cfg!(debug_assertions) {
        eprintln!("perf guard skipped: debug build (run via ./test.sh, which tests --release)");
        return;
    }
    let min = std::env::var("EVOSIM_PERF_MIN_TPS").ok().and_then(|v| v.parse::<f64>().ok()).unwrap_or(MIN_TPS);
    let mut cfg = Config::contract_example();
    cfg.seed = 42;
    let r = measure(Simulation::new(cfg).unwrap(), 1000, 300, 1);
    let tps = r.median_tps();
    eprintln!("perf guard: {tps:.1} ticks/s (threshold {min}), organisms mean {:.0} min {}", r.organisms.mean, r.organisms.min);
    assert!(r.organisms.mean >= 1500.0, "benchmark setup degenerated: mean organisms {}", r.organisms.mean);
    assert!(tps >= min, "simulation slowed down: {tps:.1} ticks/s < {min} (EVOSIM_PERF_MIN_TPS overrides)");
}

#[test]
fn perf_cli_smoke_and_bad_args() {
    let dir = std::env::temp_dir().join(format!("evosim-perf-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let out = dir.join("perf.json");
    let o = Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(["perf", "--warmup", "10", "--ticks", "20", "--repeat", "2", "--out"])
        .arg(&out)
        .output()
        .unwrap();
    assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
    let v: Value = evosim_core::serde_json::from_str(&std::fs::read_to_string(&out).unwrap()).unwrap();
    for k in ["format", "config", "seed", "warmup", "ticks", "repeat", "tick_start", "tick_end", "ticks_per_second", "ticks_per_second_all", "organisms", "phases", "state_hash", "deterministic", "host"] {
        assert!(v.get(k).is_some(), "missing key {k}");
    }
    assert_eq!(v["format"], "evosim-perf");
    assert_eq!((v["seed"].as_u64(), v["warmup"].as_u64(), v["ticks"].as_u64()), (Some(42), Some(10), Some(20)));
    assert_eq!((v["tick_start"].as_u64(), v["tick_end"].as_u64()), (Some(10), Some(30)));
    assert_eq!(v["deterministic"], true);
    assert_eq!(v["phases"].as_array().unwrap().len(), 9);
    assert!(v["ticks_per_second"].as_f64().unwrap() > 0.0);
    // The end state equals a plain run of warmup + ticks.
    let mut cfg = Config::contract_example();
    cfg.seed = 42;
    let mut s = Simulation::new(cfg).unwrap();
    s.run(30);
    assert_eq!(v["state_hash"].as_str().unwrap(), s.state_hash());
    for bad in [&["perf", "--ticks", "x"][..], &["perf", "--repeat", "0"], &["perf", "--nope"]] {
        let o = Command::new(env!("CARGO_BIN_EXE_evosim")).args(bad).output().unwrap();
        assert_eq!(o.status.code(), Some(2), "{bad:?}");
    }
    assert!(parse_perf_args(&["--ticks".into(), "x".into()]).is_err());
    let _ = std::fs::remove_dir_all(&dir);
}

//! Integration tests: spawn the real `evosim` binary.
use std::process::Command;

fn run(args: &[&str]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .output()
        .expect("spawn evosim")
}

#[test]
fn version_outputs_contract_json() {
    let o = run(&["version"]);
    assert_eq!(o.status.code(), Some(0));
    let s = String::from_utf8(o.stdout).unwrap();
    assert_eq!(s.trim_end(), evosim_core::version_json());
    assert!(s.contains("\"contract\":1"));
    assert!(s.contains("\"name\":\"evosim\""));
    assert!(o.stderr.is_empty());
}

#[test]
fn help_exit_0_lists_commands() {
    let o = run(&["--help"]);
    assert_eq!(o.status.code(), Some(0));
    let s = String::from_utf8(o.stdout).unwrap();
    for cmd in ["version", "run", "batch", "ui"] {
        assert!(s.contains(cmd));
    }
}

#[test]
fn unknown_command_exit_2() {
    let o = run(&["frobnicate"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(o.stdout.is_empty());
    assert!(!o.stderr.is_empty());
}

#[test]
fn no_args_and_extra_args_exit_2() {
    assert_eq!(run(&[]).status.code(), Some(2));
    assert_eq!(run(&["version", "extra"]).status.code(), Some(2));
}

fn tmp_file(name: &str, content: &str) -> String {
    let dir = std::env::temp_dir().join(format!("evosim-cli-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let p = dir.join(name);
    std::fs::write(&p, content).unwrap();
    p.to_string_lossy().into_owned()
}

const FIXED_ONLY: &str = r#"{"seed": 42, "world": {"width": 64, "height": 48},
  "initial": {"plants": 400, "herbivores": 120, "carnivores": 20}}"#;

#[test]
fn config_validate_fixed_only_ok() {
    let p = tmp_file("fixed.json", FIXED_ONLY);
    let o = run(&["config", "validate", &p]);
    assert_eq!(o.status.code(), Some(0));
    assert!(o.stdout.is_empty());
    let o = run(&["config", "validate", &p, "--print"]);
    assert_eq!(o.status.code(), Some(0));
    let printed = String::from_utf8(o.stdout).unwrap();
    let c = evosim_core::config::Config::from_json_str(&printed).unwrap();
    assert_eq!(c, evosim_core::config::Config::contract_example());
}

#[test]
fn config_validate_invalid_names_key_exit_2() {
    for (name, text, key) in [
        ("w0.json", FIXED_ONLY.replace("\"width\": 64", "\"width\": 0"), "world.width"),
        ("type.json", FIXED_ONLY.replace("\"seed\": 42", "\"seed\": \"42\""), "seed"),
        ("miss.json", FIXED_ONLY.replace(", \"carnivores\": 20", ""), "initial.carnivores"),
    ] {
        let p = tmp_file(name, &text);
        let o = run(&["config", "validate", &p]);
        assert_eq!(o.status.code(), Some(2), "{name}");
        assert!(o.stdout.is_empty());
        let e = String::from_utf8(o.stderr).unwrap();
        assert!(e.contains(key), "{name}: {e}");
    }
    let o = run(&["config", "validate", "/nonexistent/evosim.json"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(String::from_utf8(o.stderr).unwrap().contains("cannot read"));
}

#[test]
fn config_presets_listed_and_shown() {
    let o = run(&["config", "presets"]);
    assert_eq!(o.status.code(), Some(0));
    let s = String::from_utf8(o.stdout).unwrap();
    let names: Vec<&str> = s.lines().map(|l| l.split('\t').next().unwrap()).collect();
    assert!(names.len() >= 3);
    for n in names {
        let o = run(&["config", "show", "--preset", n]);
        assert_eq!(o.status.code(), Some(0), "{n}");
        let text = String::from_utf8(o.stdout).unwrap();
        let p = tmp_file(&format!("preset-{n}.json"), &text);
        assert_eq!(run(&["config", "validate", &p]).status.code(), Some(0), "{n}");
        assert_eq!(evosim_core::config::Config::from_json_str(&text).unwrap(), evosim_core::config::preset(n).unwrap());
    }
    let o = run(&["config", "show", "--preset", "nope"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(String::from_utf8(o.stderr).unwrap().contains("preset"));
}

#[test]
fn climate_map_json_parses() {
    let p = tmp_file("climate-cfg.json", r#"{"seed": 9, "world": {"width": 20, "height": 10},
  "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#);
    let o = run(&["climate", "map", "--config", &p, "--format", "json"]);
    assert_eq!(o.status.code(), Some(0));
    let v: evosim_core::serde_json::Value = evosim_core::serde_json::from_slice(&o.stdout).unwrap();
    assert_eq!(v["width"], 20);
    assert_eq!(v["height"], 10);
    let rows = v["rows"].as_array().unwrap();
    assert_eq!(rows.len(), 10);
    assert!(rows.iter().all(|r| r.as_str().unwrap().len() == 20));
}

#[test]
fn climate_map_ppm_written() {
    let dir = std::env::temp_dir().join(format!("evosim-cli-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let out = dir.join("climate.ppm");
    let o = run(&["climate", "map", "--format", "ppm", "--out", out.to_str().unwrap()]);
    assert_eq!(o.status.code(), Some(0));
    assert!(o.stdout.is_empty());
    let bytes = std::fs::read(&out).unwrap();
    let header = b"P6\n64 48\n255\n";
    assert_eq!(&bytes[..header.len()], header);
    assert_eq!(bytes.len(), header.len() + 3 * 64 * 48);
}

#[test]
fn climate_map_bad_args_exit_2() {
    let o = run(&["climate", "map", "--format", "ppm"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(o.stdout.is_empty() && !o.stderr.is_empty());
    let o = run(&["climate", "map", "--height", "0"]);
    assert_eq!(o.status.code(), Some(2));
}

#[test]
fn spatial_bench_index_faster_and_identical() {
    let o = run(&["spatial", "bench", "--queries", "2000"]);
    assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
    let v: evosim_core::serde_json::Value = evosim_core::serde_json::from_slice(&o.stdout).unwrap();
    assert_eq!(v["identical"], true);
    assert_eq!(v["organisms"], 2000);
    assert!(v["hits"].as_u64().unwrap() > 0);
    let speedup = v["speedup"].as_f64().unwrap();
    assert!(speedup > 1.0, "index not faster than brute force: {v}");
}

#[test]
fn spatial_bench_bad_args_exit_2() {
    for args in [&["spatial"][..], &["spatial", "bench", "--radius"], &["spatial", "bench", "--width", "0"], &["spatial", "bench", "--bogus", "1"]] {
        let o = run(args);
        assert_eq!(o.status.code(), Some(2), "{args:?}");
        assert!(o.stdout.is_empty());
    }
}

#[test]
fn ecology_survival_reports_per_seed_and_kind() {
    let o = run(&["ecology", "survival", "--ticks", "50", "--seeds", "1,2", "--json"]);
    assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
    let v: evosim_core::serde_json::Value = evosim_core::serde_json::from_slice(&o.stdout).unwrap();
    let a = v.as_array().unwrap();
    assert_eq!(a.len(), 2);
    assert_eq!(a[0]["seed"], 1);
    assert_eq!(a[1]["seed"], 2);
    for k in ["plants", "herbivores", "carnivores"] {
        assert!(a[0]["kinds"][k]["survived"].is_boolean());
    }
    let t = run(&["ecology", "survival", "--ticks", "20", "--seeds", "3"]);
    assert_eq!(t.status.code(), Some(0));
    let s = String::from_utf8(t.stdout).unwrap();
    assert!(s.starts_with("seed 3: plants "), "{s}");
    assert!(s.contains("herbivores") && s.contains("carnivores"));
}

#[test]
fn ecology_survival_bad_args_exit_2() {
    for args in [
        vec!["ecology"],
        vec!["ecology", "survival", "--ticks", "x"],
        vec!["ecology", "survival", "--seeds", "1,a"],
        vec!["ecology", "survival", "--bogus"],
        vec!["ecology", "survival", "--config", "/nonexistent.json"],
    ] {
        let o = run(&args);
        assert_eq!(o.status.code(), Some(2), "{args:?}");
        assert!(!o.stderr.is_empty());
    }
}

// ---- TASK-019: `evosim run` ----

fn run_dir(tag: &str) -> std::path::PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-run-{}-{tag}", std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

const SMALL: &str = r#"{"seed": 3, "world": {"width": 24, "height": 18},
  "initial": {"plants": 80, "herbivores": 24, "carnivores": 6}}"#;

fn run_ok(dir: &std::path::Path, cfg: &str, extra: &[&str], name: &str) -> evosim_core::serde_json::Value {
    let c = dir.join(format!("{name}.cfg.json"));
    std::fs::write(&c, cfg).unwrap();
    let out = dir.join(format!("{name}.json"));
    let mut args = vec!["run", "--config", c.to_str().unwrap(), "--out", out.to_str().unwrap()];
    args.extend_from_slice(extra);
    let o = Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(&args)
        .env_remove("DISPLAY")
        .env_remove("WAYLAND_DISPLAY")
        .output()
        .unwrap();
    assert_eq!(o.status.code(), Some(0), "stderr: {}", String::from_utf8_lossy(&o.stderr));
    assert!(o.stdout.is_empty(), "stdout must stay empty");
    assert!(!o.stderr.is_empty(), "summary line on stderr");
    evosim_core::serde_json::from_str(&std::fs::read_to_string(&out).unwrap()).unwrap()
}

#[test]
fn run_writes_contract_result_without_display() {
    let d = run_dir("basic");
    let v = run_ok(&d, SMALL, &["--ticks", "150"], "r");
    assert_eq!(v["contract"], 1);
    assert_eq!(v["seed"], 3);
    assert_eq!(v["tick_start"], 0);
    assert_eq!(v["tick_end"], 150);
    assert_eq!(v["world"]["width"], 24);
    let ticks: Vec<u64> = v["series"].as_array().unwrap().iter().map(|p| p["tick"].as_u64().unwrap()).collect();
    assert_eq!(ticks, (0..=150).collect::<Vec<_>>()); // default K = max(1, 150/100) = 1
    for k in ["plants", "herbivores", "carnivores"] {
        assert!(v["final"][k].is_u64() && v["final"]["species"][k].is_u64());
        let (i, b, dd) = (
            v["totals"]["initial"][k].as_u64().unwrap(),
            v["totals"]["births"][k].as_u64().unwrap(),
            v["totals"]["deaths"][k].as_u64().unwrap(),
        );
        assert_eq!(i + b - dd, v["final"][k].as_u64().unwrap());
    }
    assert_eq!(v["state_hash"].as_str().unwrap().len(), 64);
    assert!(v["elapsed_seconds"].is_number() && v["ticks_per_second"].is_number());
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn run_same_seed_identical_other_seed_differs() {
    let d = run_dir("det");
    let a = run_ok(&d, SMALL, &["--ticks", "120", "--seed", "7", "--sample-every", "25"], "a");
    let b = run_ok(&d, SMALL, &["--ticks", "120", "--seed", "7", "--sample-every", "25"], "b");
    let c = run_ok(&d, SMALL, &["--ticks", "120", "--seed", "8", "--sample-every", "25"], "c");
    for k in ["final", "totals", "series", "state_hash"] {
        assert_eq!(a[k], b[k], "{k}");
    }
    assert_eq!(a["seed"], 7);
    assert_eq!(c["seed"], 8);
    assert_ne!(a["state_hash"], c["state_hash"]);
    let ticks: Vec<u64> = a["series"].as_array().unwrap().iter().map(|p| p["tick"].as_u64().unwrap()).collect();
    assert_eq!(ticks, vec![0, 25, 50, 75, 100, 120]);
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn run_zero_ticks_and_extinct_world() {
    let d = run_dir("zero");
    let v = run_ok(&d, SMALL, &["--ticks", "0"], "z");
    assert_eq!(v["tick_end"], 0);
    assert_eq!(v["series"].as_array().unwrap().len(), 1);
    assert_eq!(v["final"]["plants"], 80);
    let empty = r#"{"seed": 1, "world": {"width": 8, "height": 8},
      "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#;
    let v = run_ok(&d, empty, &["--ticks", "77"], "e");
    assert_eq!(v["tick_end"], 77);
    assert_eq!(v["series"].as_array().unwrap().last().unwrap()["tick"], 77);
    let no_plants = r#"{"seed": 1, "world": {"width": 16, "height": 12},
      "initial": {"plants": 0, "herbivores": 10, "carnivores": 3}}"#;
    let v = run_ok(&d, no_plants, &["--ticks", "600"], "np");
    assert_eq!(v["tick_end"], 600);
    assert_eq!(v["final"]["herbivores"], 0);
    assert_eq!(v["final"]["carnivores"], 0);
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn run_errors_exit_2_stderr_no_result_file() {
    let d = run_dir("err");
    let good = d.join("good.json");
    std::fs::write(&good, SMALL).unwrap();
    let write = |name: &str, text: &str| {
        let p = d.join(name);
        std::fs::write(&p, text).unwrap();
        p.to_string_lossy().into_owned()
    };
    let g = good.to_string_lossy().into_owned();
    let bad_json = write("bad.json", "{ not json");
    let wrong_type = write("wt.json", r#"{"seed":"a","world":{"width":8,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let missing = write("mk.json", r#"{"seed":1,"world":{"width":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let zero_w = write("zw.json", r#"{"seed":1,"world":{"width":0,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let neg = write("neg.json", r#"{"seed":1,"world":{"width":8,"height":8},"initial":{"plants":-1,"herbivores":1,"carnivores":1}}"#);
    let unknown = write("uk.json", r#"{"seed":1,"world":{"width":8,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1},"bogus":1}"#);
    let missing_file = d.join("nope.json").to_string_lossy().into_owned();
    let out = d.join("out.json").to_string_lossy().into_owned();
    let no_dir_out = d.join("nodir").join("out.json").to_string_lossy().into_owned();
    let cases: Vec<Vec<String>> = vec![
        vec![],
        vec!["--ticks", "5", "--out", &out],
        vec!["--config", &g, "--out", &out],
        vec!["--config", &g, "--ticks", "5"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--frob"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "stray"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--ticks", "6"],
        vec!["--config", &g, "--ticks", "-1", "--out", &out],
        vec!["--config", &g, "--ticks", "abc", "--out", &out],
        vec!["--config", &g, "--ticks", "1.5", "--out", &out],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--seed", "-3"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--seed", "x"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--sample-every", "0"],
        vec!["--config", &missing_file, "--ticks", "5", "--out", &out],
        vec!["--config", &bad_json, "--ticks", "5", "--out", &out],
        vec!["--config", &wrong_type, "--ticks", "5", "--out", &out],
        vec!["--config", &missing, "--ticks", "5", "--out", &out],
        vec!["--config", &zero_w, "--ticks", "5", "--out", &out],
        vec!["--config", &neg, "--ticks", "5", "--out", &out],
        vec!["--config", &unknown, "--ticks", "5", "--out", &out],
        vec!["--config", &g, "--ticks", "5", "--out", &no_dir_out],
        vec!["--config", &g, "--ticks", "5", "--out", d.to_str().unwrap()],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--save", &out],
        vec!["--load", &missing_file, "--ticks", "5", "--out", &out],
    ]
    .into_iter()
    .map(|v| v.into_iter().map(String::from).collect())
    .collect();
    for c in cases {
        let o = Command::new(env!("CARGO_BIN_EXE_evosim")).arg("run").args(&c).output().unwrap();
        assert_eq!(o.status.code(), Some(2), "{c:?}");
        assert!(o.stdout.is_empty(), "{c:?}");
        assert!(!o.stderr.is_empty(), "{c:?}");
        assert!(!std::path::Path::new(&out).exists(), "{c:?} left a result file");
        assert!(!std::path::Path::new(&no_dir_out).exists());
    }
    // No stray temp files either.
    let names: Vec<String> = std::fs::read_dir(&d).unwrap().map(|e| e.unwrap().file_name().to_string_lossy().into_owned()).collect();
    assert!(names.iter().all(|n| !n.contains(".tmp-")), "{names:?}");
    let _ = std::fs::remove_dir_all(&d);
}

// ---- TASK-020: `evosim run --metrics` ----

#[test]
fn run_metrics_file_matches_result_and_keeps_hash() {
    let d = run_dir("metrics");
    let m = d.join("m.json");
    let plain = run_ok(&d, SMALL, &["--ticks", "130", "--seed", "4", "--sample-every", "20"], "plain");
    let with = run_ok(
        &d,
        SMALL,
        &["--ticks", "130", "--seed", "4", "--sample-every", "20", "--metrics", m.to_str().unwrap()],
        "with",
    );
    let strip = |v: &evosim_core::serde_json::Value| {
        let mut v = v.clone();
        let o = v.as_object_mut().unwrap();
        o.remove("elapsed_seconds");
        o.remove("ticks_per_second");
        v
    };
    assert_eq!(strip(&plain), strip(&with), "result must not change with --metrics");
    assert_eq!(plain["state_hash"], with["state_hash"]);
    let mv: evosim_core::serde_json::Value =
        evosim_core::serde_json::from_str(&std::fs::read_to_string(&m).unwrap()).unwrap();
    assert_eq!(mv["format"], "evosim-metrics");
    assert_eq!(mv["format_version"], 1);
    assert_eq!(mv["seed"], 4);
    assert_eq!(mv["sample_every"], 20);
    let samples = mv["samples"].as_array().unwrap();
    let series = with["series"].as_array().unwrap();
    assert_eq!(samples.len(), series.len());
    for (s, p) in samples.iter().zip(series) {
        assert_eq!(s["tick"], p["tick"]);
        for k in ["plants", "herbivores", "carnivores"] {
            assert_eq!(s[k]["count"], p[k], "{k}");
        }
    }
    let last = samples.last().unwrap();
    for k in ["plants", "herbivores", "carnivores"] {
        assert_eq!(last[k]["births_total"], with["totals"]["births"][k]);
        assert_eq!(last[k]["deaths_total"], with["totals"]["deaths"][k]);
        assert_eq!(last[k]["deaths_by_cause_total"], with["totals"]["deaths_by_cause"][k]);
        assert_eq!(last[k]["species"]["living"], with["final"]["species"][k]);
    }
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn run_metrics_errors_exit_2_no_files() {
    let d = run_dir("metrics-err");
    let g = d.join("good.json");
    std::fs::write(&g, SMALL).unwrap();
    let g = g.to_string_lossy().into_owned();
    let out = d.join("out.json").to_string_lossy().into_owned();
    let same_other_spelling = format!("{}/./out.json", d.display());
    let no_dir = d.join("nodir").join("m.json").to_string_lossy().into_owned();
    let m = d.join("m.json").to_string_lossy().into_owned();
    let cases: Vec<Vec<&str>> = vec![
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics"],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", ""],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", &m, "--metrics", &m],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", &out],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", &same_other_spelling],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", &no_dir],
        vec!["--config", &g, "--ticks", "5", "--out", &out, "--metrics", d.to_str().unwrap()],
    ];
    for c in cases {
        let o = Command::new(env!("CARGO_BIN_EXE_evosim")).arg("run").args(&c).output().unwrap();
        assert_eq!(o.status.code(), Some(2), "{c:?}");
        assert!(o.stdout.is_empty(), "{c:?}");
        assert!(!o.stderr.is_empty(), "{c:?}");
        assert!(!std::path::Path::new(&out).exists(), "{c:?} left a result file");
        assert!(!std::path::Path::new(&m).exists(), "{c:?} left a metrics file");
    }
    let _ = std::fs::remove_dir_all(&d);
}

// ---- TASK-021: evosim batch ----

const BATCH_SMALL: &str = r#"{"seed": 5, "world": {"width": 24, "height": 16},
  "initial": {"plants": 60, "herbivores": 20, "carnivores": 4}}"#;

fn batch_dir(name: &str) -> std::path::PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-batch-test-{}-{name}", std::process::id()));
    let _ = std::fs::remove_dir_all(&d);
    d
}

fn read_json(p: &std::path::Path) -> evosim_core::serde_json::Value {
    evosim_core::serde_json::from_str(&std::fs::read_to_string(p).unwrap_or_else(|e| panic!("{}: {e}", p.display()))).unwrap()
}

fn batch_ok(args: &[&str]) {
    let mut a = vec!["batch"];
    a.extend_from_slice(args);
    let o = run(&a);
    assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
    assert!(o.stdout.is_empty());
}

#[test]
fn batch_plain_seeds() {
    let cfg = tmp_file("batch-small.json", BATCH_SMALL);
    let d = batch_dir("plain");
    let ds = d.to_string_lossy().into_owned();
    batch_ok(&["--config", &cfg, "--seeds", "1,2,3", "--ticks", "40", "--out-dir", &ds]);
    let s = read_json(&d.join("summary.json"));
    assert_eq!(s["format"], "evosim-batch-summary");
    assert_eq!(s["sweep"].as_array().unwrap().len(), 0);
    let runs = s["runs"].as_array().unwrap();
    assert_eq!(runs.len(), 3);
    for (i, seed) in [1u64, 2, 3].iter().enumerate() {
        let f = d.join(format!("seed-{seed}.json"));
        let b = read_json(&f);
        assert_eq!(runs[i]["seed"], *seed);
        assert_eq!(runs[i]["file"], format!("seed-{seed}.json"));
        assert_eq!(runs[i]["ticks"], 40);
        // Same as `evosim run --seed`.
        let out = d.join(format!("run-{seed}.json"));
        let o = run(&["run", "--config", &cfg, "--seed", &seed.to_string(), "--ticks", "40", "--out", &out.to_string_lossy()]);
        assert_eq!(o.status.code(), Some(0));
        let r = read_json(&out);
        for k in ["contract", "seed", "tick_start", "tick_end", "world", "final", "totals", "series", "state_hash", "config"] {
            assert_eq!(b[k], r[k], "seed {seed} key {k}");
        }
        assert_eq!(runs[i]["state_hash"], b["state_hash"]);
    }
    assert!(d.join("summary.csv").is_file() && d.join("aggregates.csv").is_file());
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn batch_sweep_2x2() {
    let cfg = tmp_file("batch-small2.json", BATCH_SMALL);
    let d = batch_dir("sweep");
    let ds = d.to_string_lossy().into_owned();
    batch_ok(&["--config", &cfg, "--seeds", "1,2", "--ticks", "40", "--out-dir", &ds, "--param", "plants.growth_rate=0.8,1.2"]);
    let s = read_json(&d.join("summary.json"));
    let runs = s["runs"].as_array().unwrap();
    assert_eq!(runs.len(), 4);
    let expect = [(0.8, 1u64, "combo-0/seed-1.json"), (0.8, 2, "combo-0/seed-2.json"), (1.2, 1, "combo-1/seed-1.json"), (1.2, 2, "combo-1/seed-2.json")];
    let kinds = ["plants", "herbivores", "carnivores"];
    let mut finals = [[0u64; 3]; 4];
    let mut extinct = [0u64; 3];
    for (i, (g, seed, file)) in expect.iter().enumerate() {
        let r = &runs[i];
        assert_eq!(r["seed"], *seed);
        assert_eq!(r["params"]["plants.growth_rate"], *g);
        assert_eq!(r["ticks"], 40);
        assert_eq!(r["file"], *file);
        let b = read_json(&d.join(file));
        assert_eq!(b["config"]["plants"]["growth_rate"], *g);
        assert_eq!(b["seed"], *seed);
        for (k, kind) in kinds.iter().enumerate() {
            finals[i][k] = b["final"][kind].as_u64().unwrap();
            assert_eq!(r["final"][kind], finals[i][k]);
            if !b["extinction_tick"][kind].is_null() {
                extinct[k] += 1;
            }
        }
    }
    // Aggregates recomputed from the per-seed files.
    let all = &s["aggregates"]["all"];
    assert_eq!(all["runs"], 4);
    for (k, kind) in kinds.iter().enumerate() {
        let xs: Vec<u64> = finals.iter().map(|f| f[k]).collect();
        let a = &all["kinds"][kind];
        assert_eq!(a["final"]["min"], *xs.iter().min().unwrap());
        assert_eq!(a["final"]["max"], *xs.iter().max().unwrap());
        let mean = xs.iter().sum::<u64>() as f64 / 4.0;
        assert!((a["final"]["mean"].as_f64().unwrap() - mean).abs() < 1e-9);
        assert_eq!(a["extinct_runs"], extinct[k]);
        for c in 0..2 {
            let g = &s["aggregates"]["by_combo"][c];
            let ys = &xs[c * 2..c * 2 + 2];
            assert_eq!(g["kinds"][kind]["final"]["min"], *ys.iter().min().unwrap());
            assert_eq!(g["kinds"][kind]["final"]["max"], *ys.iter().max().unwrap());
        }
    }
    // CSV export.
    let csv = std::fs::read_to_string(d.join("summary.csv")).unwrap();
    let lines: Vec<&str> = csv.lines().collect();
    assert_eq!(lines.len(), 5);
    let header: Vec<&str> = lines[0].split(',').collect();
    assert_eq!(&header[..5], &["index", "combo", "seed", "plants.growth_rate", "ticks"]);
    for (i, (g, seed, _)) in expect.iter().enumerate() {
        let f: Vec<&str> = lines[i + 1].split(',').collect();
        assert_eq!(f.len(), header.len());
        assert_eq!(f[2], seed.to_string());
        assert_eq!(f[3].parse::<f64>().unwrap(), *g);
        assert_eq!(f[5].parse::<u64>().unwrap(), finals[i][0]);
    }
    let agg = std::fs::read_to_string(d.join("aggregates.csv")).unwrap();
    assert_eq!(agg.lines().count(), 1 + 3 * 3);
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn batch_reproducible() {
    use evosim_core::batch::strip_time;
    let cfg = tmp_file("batch-small3.json", BATCH_SMALL);
    let mut sums = Vec::new();
    let mut csvs = Vec::new();
    let mut aggs = Vec::new();
    for (name, jobs) in [("rep-a", "2"), ("rep-b", "2"), ("rep-c", "1"), ("rep-d", "3")] {
        let d = batch_dir(name);
        let ds = d.to_string_lossy().into_owned();
        batch_ok(&["--config", &cfg, "--seeds", "1,2", "--ticks", "40", "--out-dir", &ds, "--param", "plants.growth_rate=0.8,1.2", "--jobs", jobs]);
        sums.push(strip_time(&read_json(&d.join("summary.json"))));
        let csv = std::fs::read_to_string(d.join("summary.csv")).unwrap();
        let no_time: Vec<String> = csv.lines().map(|l| { let f: Vec<&str> = l.split(',').collect(); f[..f.len() - 2].join(",") }).collect();
        csvs.push(no_time);
        aggs.push(std::fs::read_to_string(d.join("aggregates.csv")).unwrap());
        let _ = std::fs::remove_dir_all(&d);
    }
    for i in 1..sums.len() {
        assert_eq!(sums[0], sums[i], "summary {i} differs");
        assert_eq!(csvs[0], csvs[i], "csv {i} differs");
        assert_eq!(aggs[0], aggs[i], "aggregates.csv {i} differs");
    }
}

#[test]
fn batch_errors_exit_2() {
    let cfg = tmp_file("batch-small4.json", BATCH_SMALL);
    let file_as_dir = tmp_file("batch-not-a-dir", "x");
    let d = batch_dir("errors");
    let ds = d.to_string_lossy().into_owned();
    let bad_cfg = tmp_file("batch-bad.json", r#"{"seed": 1, "world": {"width": 0, "height": 5}, "initial": {"plants": 1, "herbivores": 0, "carnivores": 0}}"#);
    let cases: Vec<Vec<&str>> = vec![
        vec!["--config", &cfg, "--ticks", "5", "--out-dir", &ds],
        vec!["--config", &cfg, "--seeds", "1,1", "--ticks", "5", "--out-dir", &ds],
        vec!["--config", &cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &ds, "--param", "nope.key=1,2"],
        vec!["--config", &cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &ds, "--param", "plants.growth_rate=-5"],
        vec!["--config", &cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &ds, "--param", "seed=1,2"],
        vec!["--config", &cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &ds, "--jobs", "0"],
        vec!["--config", "/nonexistent/x.json", "--seeds", "1", "--ticks", "5", "--out-dir", &ds],
        vec!["--config", &bad_cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &ds],
        vec!["--config", &cfg, "--seeds", "1", "--ticks", "5", "--out-dir", &file_as_dir],
    ];
    for c in cases {
        let mut a = vec!["batch"];
        a.extend(c.iter());
        let o = run(&a);
        assert_eq!(o.status.code(), Some(2), "{a:?}");
        assert!(!o.stderr.is_empty() && o.stdout.is_empty(), "{a:?}");
        assert!(!d.exists(), "out-dir created for {a:?}");
    }
    assert_eq!(std::fs::read_to_string(&file_as_dir).unwrap(), "x");
}

// ---- TASK-022: checkpoints (`run --save/--load`) ----

fn evosim_run(args: &[&str]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).arg("run").args(args).output().unwrap()
}

/// Config with all three kinds, weather and plant speciation.
const CP_CFG: &str = r#"{"seed": 5, "world": {"width": 24, "height": 16},
  "initial": {"plants": 120, "herbivores": 30, "carnivores": 6},
  "herbivores": {"maturity_age": 15}, "carnivores": {"maturity_age": 25},
  "plants": {"mutation_rate": 1.0, "mutation_strength": 0.3}}"#;

#[test]
fn checkpoint_resume_matches_uninterrupted() {
    let d = run_dir("cp");
    let cfg = d.join("cfg.json");
    std::fs::write(&cfg, CP_CFG).unwrap();
    let c = cfg.to_str().unwrap();
    let b = 60u64;
    for a in [0u64, 40] {
        let whole = d.join(format!("whole-{a}.json"));
        let o = evosim_run(&["--config", c, "--ticks", &(a + b).to_string(), "--out", whole.to_str().unwrap()]);
        assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
        let first = d.join(format!("first-{a}.json"));
        let cp = d.join(format!("cp-{a}.json"));
        let o = evosim_run(&["--config", c, "--ticks", &a.to_string(), "--out", first.to_str().unwrap(), "--save", cp.to_str().unwrap()]);
        assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
        assert!(o.stdout.is_empty());
        let cpv = read_json(&cp);
        assert_eq!(cpv["format"], "evosim-checkpoint");
        assert_eq!(cpv["version"], 1);
        assert_eq!(cpv["tick"], a);
        assert_eq!(cpv["state_hash"], read_json(&first)["state_hash"], "checkpoint hash = result hash at tick {a}");
        let second = d.join(format!("second-{a}.json"));
        let o = evosim_run(&["--load", cp.to_str().unwrap(), "--ticks", &b.to_string(), "--out", second.to_str().unwrap()]);
        assert_eq!(o.status.code(), Some(0), "{}", String::from_utf8_lossy(&o.stderr));
        assert!(o.stdout.is_empty());
        let (w, r) = (read_json(&whole), read_json(&second));
        for key in ["final", "totals", "state_hash", "tick_end", "config", "seed"] {
            assert_eq!(w[key], r[key], "split {a}: {key}");
        }
        assert_eq!(r["tick_start"], a);
        assert_eq!(r["tick_end"], a + b);
        // Zero-tick load reproduces the saved state exactly.
        let zero = d.join(format!("zero-{a}.json"));
        let o = evosim_run(&["--load", cp.to_str().unwrap(), "--ticks", "0", "--out", zero.to_str().unwrap()]);
        assert_eq!(o.status.code(), Some(0));
        let z = read_json(&zero);
        assert_eq!(z["state_hash"], cpv["state_hash"]);
        assert_eq!(z["final"], read_json(&first)["final"]);
        assert_eq!(z["totals"], read_json(&first)["totals"]);
    }
    // Chained: 30 + save, load 30 + save onto the same file, load 40 == 100.
    let whole = d.join("whole-100.json");
    assert_eq!(evosim_run(&["--config", c, "--ticks", "100", "--out", whole.to_str().unwrap()]).status.code(), Some(0));
    let cp = d.join("chain.json");
    let (cps, o1, o2, o3) = (cp.to_str().unwrap(), d.join("c1.json"), d.join("c2.json"), d.join("c3.json"));
    assert_eq!(evosim_run(&["--config", c, "--ticks", "30", "--out", o1.to_str().unwrap(), "--save", cps]).status.code(), Some(0));
    assert_eq!(evosim_run(&["--load", cps, "--ticks", "30", "--out", o2.to_str().unwrap(), "--save", cps]).status.code(), Some(0));
    assert_eq!(read_json(&cp)["tick"], 60);
    assert_eq!(evosim_run(&["--load", cps, "--ticks", "40", "--out", o3.to_str().unwrap()]).status.code(), Some(0));
    let (w, r) = (read_json(&whole), read_json(&o3));
    for key in ["final", "totals", "state_hash"] {
        assert_eq!(w[key], r[key], "chained: {key}");
    }
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn invalid_checkpoints_exit_2_without_files() {
    use evosim_core::serde_json::{self, Value};
    let d = run_dir("cperr");
    let cfg = d.join("cfg.json");
    std::fs::write(&cfg, CP_CFG).unwrap();
    let good = d.join("good.json");
    let o = evosim_run(&["--config", cfg.to_str().unwrap(), "--ticks", "20", "--out", d.join("r.json").to_str().unwrap(), "--save", good.to_str().unwrap()]);
    assert_eq!(o.status.code(), Some(0));
    let text = std::fs::read_to_string(&good).unwrap();
    let edited = |f: &dyn Fn(&mut Value)| {
        let mut v: Value = serde_json::from_str(&text).unwrap();
        f(&mut v);
        serde_json::to_string(&v).unwrap()
    };
    let write = |name: &str, body: &[u8]| {
        let p = d.join(name);
        std::fs::write(&p, body).unwrap();
        p.to_str().unwrap().to_string()
    };
    let cases: Vec<(&str, String)> = vec![
        ("missing", d.join("nope.json").to_str().unwrap().to_string()),
        ("directory", d.to_str().unwrap().to_string()),
        ("empty", write("empty.json", b"")),
        ("garbage", write("garbage.json", b"this is not a checkpoint")),
        ("not utf8", write("bin.json", &[0xff, 0xfe, 0x00, 0x7b])),
        ("truncated half", write("half.json", &text.as_bytes()[..text.len() / 2])),
        ("truncated end", write("end.json", &text.as_bytes()[..text.len() - 3])),
        ("version 99", write("v99.json", edited(&|v| v["version"] = Value::from(99)).as_bytes())),
        ("no version", write("nov.json", edited(&|v| {
            v.as_object_mut().unwrap().remove("version");
        }).as_bytes())),
        ("wrong format", write("fmt.json", edited(&|v| v["format"] = Value::from("evosim-result")).as_bytes())),
        ("tampered energy", write("energy.json", edited(&|v| {
            let e = &mut v["state"]["world"]["organisms"]["by_kind"][0][0]["energy"];
            *e = Value::from(e.as_f64().unwrap() * 0.5);
        }).as_bytes())),
        ("tampered hash", write("hash.json", edited(&|v| v["state_hash"] = Value::from("ab".repeat(32))).as_bytes())),
        ("missing world", write("noworld.json", edited(&|v| {
            v["state"].as_object_mut().unwrap().remove("world");
        }).as_bytes())),
    ];
    for (name, path) in &cases {
        let out = d.join(format!("out-{}.json", name.replace(' ', "_")));
        let save = d.join(format!("save-{}.json", name.replace(' ', "_")));
        let o = evosim_run(&["--load", path, "--ticks", "5", "--out", out.to_str().unwrap(), "--save", save.to_str().unwrap()]);
        assert_eq!(o.status.code(), Some(2), "{name}");
        assert!(!o.stderr.is_empty(), "{name}: message on stderr");
        assert!(o.stdout.is_empty(), "{name}");
        assert!(!out.exists(), "{name}: no result file");
        assert!(!save.exists(), "{name}: no checkpoint file");
    }
    // Argument errors around checkpoints.
    let out = d.join("args-out.json");
    let (g, o) = (good.to_str().unwrap(), out.to_str().unwrap());
    let c = cfg.to_str().unwrap();
    let missing_dir = d.join("no/such/dir/cp.json");
    for args in [
        vec!["--load", g, "--config", c, "--ticks", "5", "--out", o],
        vec!["--load", g, "--seed", "3", "--ticks", "5", "--out", o],
        vec!["--ticks", "5", "--out", o],
        vec!["--load", g, "--ticks", "5", "--out", o, "--save", o],
        vec!["--load", g, "--ticks", "5", "--out", o, "--save", missing_dir.to_str().unwrap()],
        vec!["--load", g, "--ticks", "5", "--out", o, "--save", d.to_str().unwrap()],
        vec!["--load", g, "--ticks", "5", "--out", o, "--save", ""],
    ] {
        let r = evosim_run(&args);
        assert_eq!(r.status.code(), Some(2), "{args:?}");
        assert!(!out.exists(), "{args:?}");
    }
    let _ = std::fs::remove_dir_all(&d);
}

#[test]
fn ui_usage_errors_exit_2() {
    let bin = env!("CARGO_BIN_EXE_evosim");
    let cases: &[&[&str]] = &[
        &["ui", "--bogus"],
        &["ui", "--screenshots", "/nonexistent/evosim-dir"],
        &["ui", "--smoke-test", "--screenshots", "/tmp"],
        &["ui", "--config", "/nonexistent/missing.json", "--smoke-test"],
        &["ui", "--port", "notaport"],
        &["ui", "--config"],
    ];
    for args in cases {
        let o = std::process::Command::new(bin).args(*args).output().unwrap();
        assert_eq!(o.status.code(), Some(2), "{args:?}: {}", String::from_utf8_lossy(&o.stderr));
    }
    let o = std::process::Command::new(bin).args(["ui", "--help"]).output().unwrap();
    assert_eq!(o.status.code(), Some(0));
}

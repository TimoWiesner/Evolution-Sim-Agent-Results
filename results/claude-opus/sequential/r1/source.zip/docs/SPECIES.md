# Species and family tree (TASK-017, ADR-020)

Code: `crates/evosim-core/src/species/` (`SpeciesRegistry`, `SpeciesRecord`, `SpeciesId`, `names.rs`).

## The species rule
- Every species stores the genome of its first member as an immutable **representative**.
- Genetic distance = `genome::distance` (weighted mean absolute gene difference, in `[0, 1]`).
- Threshold `T` = `<kind>.species_threshold` (default 0.15 for plants, herbivores, carnivores).
  Founder jitter (`founder_variation` 0.02) keeps all founders of a kind within one species;
  default mutation (0.05 / 0.05) needs tens of generations of directional drift to exceed 0.15.
- Classification happens **once, when an organism is created**; it is never re-classified.
  - Founder (tick 0, ascending EntityId): joins the first non-extinct root species of its kind
    with `d <= T`, else founds a new root species (no parent).
  - Newborn: `M` = species of the first stored parent (plant seed mother / initiating animal).
    `d(child, rep(M)) <= T` → joins `M` (**exactly at `T` it stays**); else the first living
    daughter species of `M` with `d <= T`; else it founds a new daughter species of `M`
    (`origin_tick` = birth tick, representative = child genome).
- Dropped birth requests (dead parent, full cell) never create species. No RNG is drawn.

## Records, extinction, IDs, names
- `SpeciesRecord`: `id`, `kind`, `name`, `parent`, `root`, `origin_tick`, `extinct_tick`,
  `representative`, `living`, `ever`, `daughters`.
- The last member's death (`Population::kill`, the only death path) sets `extinct_tick` to
  that tick. Extinction is final (no living parent / daughter reuse only of living species).
- `SpeciesId`: one global counter from 1 in creation order (founders: plants, herbivores,
  carnivores; then births in resolution order) — deterministic per seed.
- Names: `"<Genus> <epithet>"`, genus = syllable word of the root ancestor's ID + `ia` /
  `odon` / `raptor`, epithet = syllable word of the own ID (bijective base-16 over
  `ka lo mi ru te va no si pa de xo bu ri ze fa ul`). Example: root plant species 1 =
  `Kaia ka`; its daughter 4 = `Kaia ru`. Short code `P1`, `H2`, `C3`.

## Queries and events
- `Simulation::species()` / `Population::species()`: `get`, `iter`, `of_kind`, `lineage(id)`.
- `Simulation::living_species(kind)` / `living_count(kind)`: current number of species with
  living members (any tick, also inside phase hooks); `living_count_at(kind, t)`: value at the
  end of tick `t` from the records.
- Species phase emits `EventKind::SpeciesAppeared { species, kind, parent, tick }` for splits
  and `SpeciesExtinct { species, kind, tick }`. Founder root species (tick 0 initial state) are
  not announced as events, just like founders produce no Birth events.

## Caveats
- Species measure divergence from the species founder, not current population structure.
- Animals of different species can mate (`mating_threshold` 0.2 > 0.15); the child is
  classified via the first parent's species.

# Configuration reference

Configuration files are JSON (docs/CONTRACT.md §3). Design: [ADR-006](decisions/ADR-006-configuration.md); code: `crates/evosim-core/src/config/`.

## Rules
- **Fixed keys** `seed`, `world.width`, `world.height`, `initial.plants`, `initial.herbivores`, `initial.carnivores` are required. A file with only these keys is valid; every other key has a default (table below).
- Zero is valid for every `initial.*` population.
- **Unknown keys are an error** at every nesting level (e.g. `plants.max_agee`), so typos cannot silently fall back to defaults.
- Types: `integer` must be a JSON integer (`64.0` and `"64"` are wrong types; negative or too large integers are out of range). `number` accepts any JSON number. Ranges are inclusive.
- Cross-field checks: `climate.pole_temperature <= climate.equator_temperature`; for plants `initial_energy`, `reproduction_threshold`, `reproduction_cost <= max_energy`; for herbivores/carnivores `initial_energy`, `reproduction_threshold <= max_energy`. The error names the left-hand key.
- Errors name the offending dotted key, e.g. ``config error: `world.width`: value 0 out of range [1, 4096]``. Kinds: invalid JSON (key `<json>`, with line/column), wrong type, missing required key, out of range, unknown key, invalid value (cross-field), unknown preset (key `preset`). The first error in a deterministic order is reported. The CLI exits with status 2.
- Writing a config (`evosim config validate FILE --print`, `evosim config show --preset NAME`) emits **every** key with keys sorted; loading that output gives an equal configuration.
- Parameter semantics belong to the tasks that use them (climate, plants, animals); values are placeholders until tuned (TASK-027). Adding a parameter = one line in `crates/evosim-core/src/config/params.rs` + one row here (a test checks that every key is listed in this file).
- Other formats (TOML/YAML) are not supported.

## Commands
```sh
./evosim config presets                 # list presets
./evosim config show --preset lush      # full JSON of a preset
./evosim config validate my.json        # exit 0 ok / 2 invalid (message names key)
./evosim config validate my.json --print  # also print the normalised full config
./evosim config schema                  # regenerate the table below
```

## Presets
| Name | World | Initial plants/herbivores/carnivores | Differences from defaults |
|---|---|---|---|
| `default` | 64×48 | 400/120/20 | none (contract §3 example) |
| `lush` | 96×64 | 900/220/30 | `plants.resource_regen` 1.0, `plants.resource_cap` 16, `climate.pole_temperature` −10, `climate.seasonal_amplitude` 4, `climate.max_precipitation` 1.5 |
| `harsh` | 48×36 | 300/80/10 | `climate.pole_temperature` −40, `climate.equator_temperature` 22, `climate.seasonal_amplitude` 16, `climate.weather_temperature_sd` 4, `plants.resource_regen` 0.3 |
| `plants-only` | 64×48 | 600/0/0 | `plants.mutation_rate` 0.1 |

Preset `seed` is 42; `name` is the preset name. Presets are selected by name in code with `config::preset(name)`.

## Parameters
Groups: top-level metadata (`name`, `description`), `climate`, `plants`, `herbivores`, `carnivores`, `hunting`.

| Key | Type | Default | Range | Meaning |
|---|---|---|---|---|
| `seed` | integer | required | 0 … 18446744073709551615 | Random seed (unsigned 64-bit); required |
| `world.width` | integer | required | 1 … 4096 | Grid width in cells; required |
| `world.height` | integer | required | 1 … 4096 | Grid height in cells; required |
| `initial.plants` | integer | required | 0 … 1000000 | Plants at tick 0; required |
| `initial.herbivores` | integer | required | 0 … 1000000 | Herbivores at tick 0; required |
| `initial.carnivores` | integer | required | 0 … 1000000 | Carnivores at tick 0; required |
| `name` | string | `"custom"` | — | Free-form configuration name |
| `description` | string | `""` | — | Free-form description |
| `climate.year_length` | integer | `400` | 1 … 100000 | Ticks per simulated year (season cycle) |
| `climate.equator_temperature` | number | `28.0` | -50 … 60 | Base temperature at the equator row (deg C) |
| `climate.pole_temperature` | number | `-25.0` | -80 … 40 | Mean temperature at the poles (deg C); must be <= equator_temperature |
| `climate.seasonal_amplitude` | number | `8.0` | 0 … 40 | Seasonal temperature amplitude at the pole (deg C); scaled by 0.1+0.9*sin(latitude) |
| `climate.max_precipitation` | number | `1.0` | 0 … 10 | Precipitation in the wettest zone (relative units) |
| `climate.precipitation_seasonality` | number | `0.3` | 0 … 1 | Relative seasonal variation of precipitation |
| `climate.weather_enabled` | boolean | `true` | — | Random weather fluctuations on top of the climate |
| `climate.weather_temperature_sd` | number | `2.0` | 0 … 20 | Stationary SD of the weather temperature anomaly (deg C); clamped to +-3 SD |
| `climate.weather_precipitation_sd` | number | `0.1` | 0 … 2 | Stationary SD of the weather precipitation anomaly, relative to max_precipitation; clamped to +-3 SD |
| `climate.weather_persistence` | number | `0.9` | 0 … 0.999 | Autocorrelation of weather from tick to tick |
| `climate.noise_temperature` | number | `1.5` | 0 … 20 | Amplitude of the seeded static temperature anomaly field (deg C) |
| `climate.noise_precipitation` | number | `0.05` | 0 … 1 | Amplitude of the seeded static precipitation anomaly, relative to max_precipitation |
| `climate.noise_scale` | integer | `16` | 1 … 4096 | Feature size of the climate anomaly field in cells |
| `climate.weather_scale` | integer | `16` | 1 … 4096 | Feature size of the weather anomaly lattice in cells |
| `plants.max_per_cell` | integer | `2` | 1 … 64 | Maximum number of plants in one cell |
| `plants.resource_cap` | number | `15.0` | 0 … 1000 | Maximum soil resource per cell |
| `plants.resource_regen` | number | `1.0` | 0 … 1000 | Soil resource regeneration per tick |
| `plants.initial_energy` | number | `4.0` | 0 … 1000000 | Energy of a founder/new plant; must be <= max_energy |
| `plants.max_energy` | number | `20.0` | 0.1 … 1000000 | Maximum energy a plant can store |
| `plants.max_age` | integer | `300` | 1 … 10000000 | Maximum plant age in ticks |
| `plants.reproduction_threshold` | number | `8.0` | 0 … 1000000 | Energy needed to reproduce; must be <= max_energy |
| `plants.reproduction_cost` | number | `4.0` | 0 … 1000000 | Energy spent per offspring; must be <= max_energy |
| `plants.dispersal_radius` | integer | `3` | 0 … 64 | Maximum seed dispersal distance in cells |
| `plants.pollination_enabled` | boolean | `true` | — | Allow cross-pollination between nearby compatible plants |
| `plants.mutation_rate` | number | `0.05` | 0 … 1 | Per-gene mutation probability |
| `plants.mutation_strength` | number | `0.05` | 0 … 1 | Standard deviation of a gene mutation |
| `plants.founder_variation` | number | `0.02` | 0 … 1 | SD of the random deviation of founder genes from the default genome |
| `plants.species_threshold` | number | `0.15` | 0 … 1 | Genetic distance that founds a new species |
| `plants.growth_rate` | number | `1.5` | 0 … 1000000 | Maximum energy a plant takes up per tick at ideal temperature and water (ADR-014) |
| `plants.upkeep` | number | `0.1` | 0 … 1000000 | Plant energy spent per tick on respiration, scaled by 0.75+0.5*strength |
| `plants.water_min` | number | `0.1` | 0 … 1 | Relative moisture (precipitation / climate.max_precipitation) below which plants cannot grow and suffer drought |
| `plants.water_optimum` | number | `0.5` | 0 … 1 | Relative moisture at and above which water does not limit plant growth |
| `plants.generalist_cost` | number | `0.3` | 0 … 1 | Reduction of the peak growth rate for maximal temperature tolerance |
| `plants.stress_damage` | number | `0.1` | 0 … 1 | Plant health lost per tick under full climate stress, as fraction of max_health |
| `plants.heal_rate` | number | `0.05` | 0 … 1 | Plant health regained per tick without climate stress, as fraction of max_health |
| `plants.seed_rate` | number | `0.5` | 0 … 1 | Chance per tick that a plant with energy >= reproduction_threshold makes a seed, scaled by 0.5+fertility (0 disables reproduction, ADR-015) |
| `plants.seed_min_resource` | number | `1.0` | 0 … 1000 | Soil resource a landing cell needs for a seed to establish (ADR-015) |
| `plants.pollination_chance` | number | `0.3` | 0 … 1 | Chance that a seed is fertilised by a compatible plant within pollen_radius (needs pollination_enabled) |
| `plants.pollen_radius` | integer | `2` | 0 … 64 | Maximum distance in cells of a pollen donor |
| `herbivores.initial_energy` | number | `80.0` | 0 … 1000000 | Energy of a founder/newborn; must be <= max_energy |
| `herbivores.max_energy` | number | `100.0` | 0.1 … 1000000 | Maximum stored energy |
| `herbivores.max_age` | integer | `1500` | 1 … 10000000 | Maximum age in ticks |
| `herbivores.maturity_age` | integer | `60` | 0 … 10000000 | Age at which reproduction becomes possible |
| `herbivores.base_metabolism` | number | `0.3` | 0 … 1000 | Energy used per tick at rest |
| `herbivores.move_cost` | number | `0.1` | 0 … 1000 | Energy used per cell moved |
| `herbivores.sprint_cost` | number | `0.5` | 0 … 100 | Extra cost factor per additional cell in the same tick: the i-th step of a tick costs move_cost*(1+sprint_cost*(i-1)) |
| `herbivores.max_speed` | integer | `2` | 1 … 16 | Maximum cells moved per tick |
| `herbivores.max_vision` | integer | `6` | 1 … 64 | Maximum sensing radius in cells |
| `herbivores.max_per_cell` | integer | `2` | 1 … 64 | Maximum number of organisms of this kind in one cell (cell-sharing rule, ADR-016) |
| `herbivores.max_meal` | number | `2.0` | 0 … 1000000 | Maximum energy eaten per tick |
| `herbivores.climate_cost` | number | `1.0` | 0 … 100 | Extra metabolism factor per unit of thermal stress outside the temperature tolerance (up to x(1+2*climate_cost) in extreme cold or heat, ADR-017) |
| `herbivores.assimilation` | number | `0.8` | 0 … 1 | Fraction of the plant energy eaten that the herbivore gains (rest is lost, ADR-017) |
| `herbivores.graze_reserve` | number | `0.35` | 0 … 1 | Protected plant reserve: share of a plant's max_energy that no bite can take (ADR-021) |
| `herbivores.reproduction_threshold` | number | `70.0` | 0 … 1000000 | Energy needed to mate; must be <= max_energy |
| `herbivores.reproduction_cost` | number | `35.0` | 0 … 1000000 | Energy given to an offspring per parent |
| `herbivores.mating_threshold` | number | `0.2` | 0 … 1 | Maximum genetic distance of compatible mates |
| `herbivores.mating_cooldown` | integer | `40` | 0 … 10000000 | Ticks after a mating before the animal can mate again (ADR-019) |
| `herbivores.conception_chance` | number | `0.5` | 0 … 1 | Base chance that a mating conceives; scaled by 0.5 + mean parent fertility (ADR-019) |
| `herbivores.max_litter` | integer | `3` | 1 … 16 | Maximum offspring per conception (ADR-019) |
| `herbivores.mutation_rate` | number | `0.05` | 0 … 1 | Per-gene mutation probability |
| `herbivores.mutation_strength` | number | `0.05` | 0 … 1 | Standard deviation of a gene mutation |
| `herbivores.founder_variation` | number | `0.02` | 0 … 1 | SD of the random deviation of founder genes from the default genome |
| `herbivores.species_threshold` | number | `0.15` | 0 … 1 | Genetic distance that founds a new species |
| `carnivores.initial_energy` | number | `80.0` | 0 … 1000000 | Energy of a founder/newborn; must be <= max_energy |
| `carnivores.max_energy` | number | `160.0` | 0.1 … 1000000 | Maximum stored energy |
| `carnivores.max_age` | integer | `2000` | 1 … 10000000 | Maximum age in ticks |
| `carnivores.maturity_age` | integer | `150` | 0 … 10000000 | Age at which reproduction becomes possible |
| `carnivores.base_metabolism` | number | `0.3` | 0 … 1000 | Energy used per tick at rest |
| `carnivores.move_cost` | number | `0.15` | 0 … 1000 | Energy used per cell moved |
| `carnivores.sprint_cost` | number | `0.5` | 0 … 100 | Extra cost factor per additional cell in the same tick: the i-th step of a tick costs move_cost*(1+sprint_cost*(i-1)) |
| `carnivores.max_speed` | integer | `3` | 1 … 16 | Maximum cells moved per tick |
| `carnivores.max_vision` | integer | `8` | 1 … 64 | Maximum sensing radius in cells |
| `carnivores.max_per_cell` | integer | `2` | 1 … 64 | Maximum number of organisms of this kind in one cell (cell-sharing rule, ADR-016) |
| `carnivores.max_meal` | number | `60.0` | 0 … 1000000 | Maximum energy eaten per tick |
| `carnivores.climate_cost` | number | `1.0` | 0 … 100 | Metabolism multiplier per unit of thermal stress (ADR-017 formula, ADR-018) |
| `carnivores.assimilation` | number | `0.8` | 0 … 1 | Fraction of the prey energy a carnivore gains from a kill, capped by max_meal (rest is lost, ADR-018) |
| `carnivores.reproduction_threshold` | number | `110.0` | 0 … 1000000 | Energy needed to mate; must be <= max_energy |
| `carnivores.reproduction_cost` | number | `55.0` | 0 … 1000000 | Energy given to an offspring per parent |
| `carnivores.mating_threshold` | number | `0.2` | 0 … 1 | Maximum genetic distance of compatible mates |
| `carnivores.mating_cooldown` | integer | `120` | 0 … 10000000 | Ticks after a mating before the animal can mate again (ADR-019) |
| `carnivores.conception_chance` | number | `0.5` | 0 … 1 | Base chance that a mating conceives; scaled by 0.5 + mean parent fertility (ADR-019) |
| `carnivores.max_litter` | integer | `1` | 1 … 16 | Maximum offspring per conception (ADR-019) |
| `carnivores.mutation_rate` | number | `0.05` | 0 … 1 | Per-gene mutation probability |
| `carnivores.mutation_strength` | number | `0.05` | 0 … 1 | Standard deviation of a gene mutation |
| `carnivores.founder_variation` | number | `0.02` | 0 … 1 | SD of the random deviation of founder genes from the default genome |
| `carnivores.species_threshold` | number | `0.15` | 0 … 1 | Genetic distance that founds a new species |
| `hunting.base_success` | number | `0.33` | 0 … 1 | Base probability that an attack succeeds (before the local prey-density factor, ADR-030) |
| `hunting.attack_cost` | number | `1.0` | 0 … 1000 | Energy a carnivore spends per attack |
| `hunting.handling_time` | integer | `15` | 0 … 1000 | Ticks a carnivore needs to eat a kill |
| `hunting.cover_protection` | number | `0.6` | 0 … 1 | Reduction of attack success by dense plant cover |
| `hunting.prey_density_half` | number | `40.0` | 0 … 1000 | Local prey density at which attack success is halved: success x n/(n+half), n = herbivores within the attacker's vision (0 = off, ADR-030) |

# Spatial search (TASK-010)

Design: [ADR-013](decisions/ADR-013-spatial-index-detail.md) (refines [ADR-003](decisions/ADR-003-spatial-index.md)). Code: `crates/evosim-core/src/spatial/{mod.rs,tests.rs}`.

## Data structure
`SpatialIndex { torus, buckets, locator }`
- `buckets`: one `Vec<EntityId>` per (cell, kind), slot `torus.index(cell) * 3 + kind.index()`, each sorted ascending by ID (binary-search insert/remove).
- `locator`: `BTreeMap<EntityId, (Cell, Kind)>` — O(log N) move/remove, ID-ordered iteration.
- No hashed collections and no wall clock in core (ADR-005).

## Query interface
- `within(center, r, filter: Option<Kind>) -> Vec<Neighbour>`, `within_into(.., &mut Vec)` (buffer reuse), `count_within`, `nearest(center, r, filter, pred)`, `at(cell, filter) -> Vec<EntityId>`.
- `Neighbour { id, kind, cell, offset /* shortest from center */, distance /* toroidal Chebyshev */ }`.
- Order: ascending `(distance, id)` — total because IDs are unique, so it is independent of insertion/move history.
- Cells come from `Torus::within` (each distinct cell once, also for radii ≥ world size and worlds like 1×1, 1×N). When the scan area `torus.count_within(r)` exceeds the number of entries the query iterates the locator instead (same results, O(N) bound). The center is wrapped into the torus.
- Mutations: `insert` (`Duplicate`, `OutsideWorld`), `remove`, `move_to` (`Unknown`, `OutsideWorld`; same cell = no-op). `check_against(entries)` verifies buckets vs locator vs expected set.
- `spatial::brute_force_within(torus, entries, center, r, filter)` is the oracle (same order).

## Ownership / sync
`organism::Population` owns the index of **living** organisms: founders and resolved births are inserted (birth position wrapped into the torus), `kill` removes immediately, `Population::move_organism(id, cell)` is the only mover (`Organism::set_pos` is `pub(crate)`), `rebuild_index(torus)` on `Simulation::set_population` / `World::set_organisms`. `Population::validate` checks the index. Convenience: `Population::{index, within, within_into, nearest, at}`.

## Measurement (index vs brute force)
Command: `./evosim spatial bench [--width W --height H --organisms N --queries Q --radius R --seed S]` — N organisms at random cells (60/30/10 % plants/herbivores/carnivores), Q random queries (filter none/plant/herbivore/carnivore uniformly), timed with `std::time::Instant` in the CLI (release build); results of both methods are compared (`identical`).

Recorded 2026-11-22, TASK-010 IMPLEMENT, benchmark container (release build, single thread):

| world | organisms | queries | radius | index ns/query | brute ns/query | speedup | identical |
|---|---|---|---|---|---|---|---|
| 200×200 (default) | 2000 | 20000 | 6 | 954.8 | 8074.9 | 8.5× | true |
| 100×100 | 2000 | 20000 | 3 | 404.8 | 8086.5 | 20.0× | true |
| 50×50 | 2000 | 20000 | 8 | 5906.5 | 13328.7 | 2.3× | true |

Exact commands: `./evosim spatial bench`, `./evosim spatial bench --width 100 --height 100 --radius 3`, `./evosim spatial bench --width 50 --height 50 --radius 8`. Index time includes copying each result Vec (as brute force allocates one). The dense 50×50 r=8 case returns ~116 hits per query, so sorting dominates both methods. Timing is machine dependent; the CLI test `spatial_bench_index_faster_and_identical` asserts only `identical` and speedup > 1.

## Tests
- `spatial::tests` (12): seam, kind filter, no duplicates for radius > world (1×1, 1×5, 5×1, 2×2, 3×3, 4×7, r 0..=20), offsets, remove/move/no-op/errors, order, insertion-history independence, `randomised_matches_brute_force` (8 worlds incl. 1×1, 1×7, 7×1, 2×2, 200×200; 5,600 queries with interleaved insert/move/remove, radius up to max(w,h)+3, both scan paths exercised).
- `organism::tests` (4 new): index synced through 100 hook-driven ticks with moves/kills/births, dead organisms disappear at once, `set_population` rebuilds/rejects outside positions, identical sims give identical queries.

## Review re-measurement (TASK-010 REVIEW cycle 1, same container)
`./evosim spatial bench`: 917.9 vs 8083.2 ns/query (8.8×); 100×100 r3: 405.6 vs 8083.6 (19.9×); 50×50 r8: 5905.2 vs 13698.1 (2.3×); `--width 3 --height 3 --radius 10 --queries 2000`: 28799.7 vs 32249.4 (1.1×, every query returns all 2,000 organisms so sorting dominates). All `identical: true`.

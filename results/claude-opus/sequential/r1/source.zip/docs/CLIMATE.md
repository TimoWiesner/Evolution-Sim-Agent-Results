# Climate zones and biomes (TASK-006)

Design record: [ADR-009](decisions/ADR-009-climate-zones.md). Code: `crates/evosim-core/src/climate/` (`ClimateMap`, `Biome`, `PeriodicNoise`, `export`). This is the **static base climate**; seasons and weather (TASK-007) are added on top of these values.

## The compromise: latitude zones on a world without edges
The world is a torus: walking off the bottom edge brings you back at the top, walking off the right edge back at the left. A real planet has two separate poles and an equator; a torus has no edge where a pole could sit, and a simple "north pole at the top, south pole at the bottom" map would put a hard jump where the bottom row touches the top row again.

The simulation therefore **folds latitude**: going down the map you travel pole → equator → pole, and the bottom pole and the top pole are *the same* cold band continued across the wrap. Equivalently, the map shows two mirrored hemispheres glued together at the equator (middle rows) and at the pole (the top/bottom seam). Latitude of row `y` in a world of height `h`:

    φ(y) = 90° · |1 − 2·(y + 0.5)/h|        (0° equator … 90° pole)

This is periodic in `y` with period `h` and mirror-symmetric about the seam, so rows `h−1` and `0` have *identical* latitude — the seam is the smoothest place of the whole map. Consequences:
- there is exactly one polar band and one equatorial band; each zone appears twice (once per hemisphere) between them;
- an organism walking straight south crosses all zones twice per circuit;
- zone widths scale with the world height; x (east-west) does not change latitude;
- east-west variation comes only from a small seeded noise field that itself wraps in both directions.

## Formulas
- Temperature (°C): `T = T_pole + (T_eq − T_pole)·cos φ + A_T·nT(x, y)` with `climate.pole_temperature`, `climate.equator_temperature`, `climate.noise_temperature`.
- Precipitation: `P = P_max · clamp(p_lat(φ) + A_P·nP(x, y), 0, 1)`, `p_lat(φ) = min(1, 0.10 + 0.90·g(φ,0,15) + 0.55·g(φ,55,15))`, `g(x,m,s) = exp(−((x−m)/s)²)` — wet equator, dry subtropics, mid-latitude storm track, dry poles. Keys `climate.max_precipitation`, `climate.noise_precipitation`.
- Noise `nT`, `nP ∈ [−1, 1]`: smooth value noise on a lattice of `max(1, round(w/s)) × max(1, round(h/s))` points (`s = climate.noise_scale`, default 16 cells), lattice indices wrap, so the field is periodic on the torus. Generated from a dedicated generator seeded with `seed XOR 0xC1A7E5EED0000006`; the core simulation RNG is not touched. Set both amplitudes to 0 for pure stripes.

## Biomes (6) and zones (5)
`r = P / P_max`.

| Zone (cold → hot) | Biome | Rule | Symbol | Colour (PPM) |
|---|---|---|---|---|
| polar | Polar ice | T < −10 | `I` | 235,245,255 |
| tundra | Tundra | −10 ≤ T < 0 | `U` | 150,170,160 |
| temperate | Temperate | 0 ≤ T < 18 | `F` | 60,140,60 |
| dry | Desert | T ≥ 18, r < 0.3 | `D` | 230,200,120 |
| dry | Savanna | T ≥ 18, 0.3 ≤ r < 0.6 | `S` | 190,180,70 |
| tropical | Tropical | T ≥ 18, r ≥ 0.6 | `R` | 10,100,30 |

Going from the pole band towards the equator the zones never step back to a colder zone (tested for all presets and many sizes). With the defaults even the six biomes are strictly ordered: `IIII UUUU FFFFFF DDDDD SS RRR|RRR SS DDDDD FFFFFF UUUU IIII` (48 rows). Inside the dry zone, presets with a warm pole (`lush`) show a savanna fringe on the poleward side of the desert (Earth's steppe/grassland belt); this is why order is defined on the 5 zones (`Biome::zone()`), with desert and savanna together forming "dry".

Very small worlds: `h = 1` → one equatorial row (tropical with defaults), `h = 2` → both rows at 45° (temperate), `h = 3` → `F R F`, `h = 5` → `U F R F U`. Any size 1…2^20 works; noise collapses to a constant along an axis shorter than about half the noise scale.

## Inspecting the map without a UI
```
./evosim climate map                                   # text map of the contract example (64x48, seed 42) + legend + counts
./evosim climate map --preset lush --seed 7            # any preset / seed
./evosim climate map --config FILE --width 20 --height 9
./evosim climate map --format json --out climate.json  # size, legend, row strings, latitude per row, temperature/precipitation grids, counts
./evosim climate map --format ppm --out climate.ppm    # binary P6 image, one pixel per cell (requires --out)
```
Invalid options or configurations exit 2 with a message on stderr.

Default world (`./evosim climate map`):
```
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUIIIIIIIIIIIIIIIIIIIIIIUUUUUUUUUUUU
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
FFFFFFFFFFFFFFFFFFFFFFFFUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
DDDDDDDDDDDDDDDDDFFFFFFFFFFFFFFFFFFFFFFFFFDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
DDDDFFFFFFFFFFFFFFFFFFFFDDDDDDDDDDDDDDDFFFFFFFFFFFFFFFFFFFFFDDDD
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFUUUUUUUUUUUUUUUUUUUUUFFFFFF
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUIIIIIIIIIIIIIIIUUUUUUUUUU
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII

I polar (T < -10)
U tundra (-10 <= T < 0)
F temperate (0 <= T < 18)
D desert (T >= 18, r < 0.3)
S savanna (T >= 18, 0.3 <= r < 0.6)
R tropical (T >= 18, r >= 0.6)
64x48 cells; latitude: pole band on the top/bottom seam, equator mid-map; counts: polar=549 tundra=399 temperate=910 desert=574 savanna=256 tropical=384
```

## Seasons and weather (TASK-007, ADR-010)

The base climate above is static. On top of it every cell has a *current*
temperature and precipitation that changes every tick.

### Year and seasons
- `climate.year_length` = Y ticks per year. Year phase `s(t) = sin(2π·(t mod Y)/Y)`:
  `t mod Y = 0` spring equinox, `Y/4` midsummer (warmest, wettest), `3Y/4` midwinter.
  The phase is computed from the integer `t mod Y`, so `t` and `t+Y` are bit-identical.
- **One season for the whole world.** The two mirrored hemispheres meet at the
  polar seam (rows `h−1`/`0`) where seasons are strongest; opposite seasons
  would put summer next to winter there. So the season phase is shared and
  only its strength depends on latitude.
- Temperature: `T_season = A_s · (0.1 + 0.9·sin φ) · s`, `A_s = climate.seasonal_amplitude`.
- Precipitation (relative to `max_precipitation`): `r · (1 + c·(0.25 + 0.75·exp(−((φ−20)/15)²))·s)`,
  `c = climate.precipitation_seasonality`; wet summers, dry winters, strongest in the tropics/subtropics.

| Latitude | T swing (defaults, ±°C) | P modulation weight (× c = 0.3) |
|---|---|---|
| 0° (equator) | ±0.8 | 0.38 → ±11 % |
| 30° | ±4.4 | 0.73 → ±22 % |
| 60° | ±7.0 | 0.25 → ±7.5 % |
| 90° (pole) | ±8.0 | 0.25 → ±7.5 % |

### Weather
- Two coarse lattices (temperature °C, precipitation relative) of
  `round(w/weather_scale) × round(h/weather_scale)` nodes (min 1; default 64×48 → 4×3).
  Values are interpolated smoothly and periodically, so weather is spatially
  coherent and continuous across both seams. A 1×1 lattice means uniform weather.
- Every tick (Climate phase, first phase), if `climate.weather_enabled`: every
  temperature node (row-major), then every precipitation node draws one normal
  `z` from the **simulation RNG** and updates
  `a ← clamp(ρ·a + √(1−ρ²)·σ·z, −3σ, 3σ)` (`ρ = weather_persistence`,
  `σ = weather_temperature_sd` / `weather_precipitation_sd`). Same seed → same weather.
- Weather starts at 0 at tick 0. With weather disabled no random numbers are
  drawn and the anomalies stay 0, so every year repeats the previous one exactly.

### Current value and bounds
- `T(c,t) = T_base + T_season + aT`, `P(c,t) = P_max · clamp(r_season + aP, 0, 1)`.
- Documented bounds (hold by construction; a final clamp guards rounding):
  `T ∈ [T_pole − noise_temperature − seasonal_amplitude − 3·weather_temperature_sd, T_eq + noise_temperature + seasonal_amplitude + 3·weather_temperature_sd]`,
  `P ∈ [0, max_precipitation]`. Defaults: T ∈ [−40.5, 43.5] °C, P ∈ [0, 1].
  The weather term is included even when weather is off. API: `ClimateBounds::from_params`.
- The biome stays the static base biome.

### Query
- `Simulation::climate_now(cell)` / `World::current(cell)` / `World::current_grid()`:
  values for `World::climate_tick()`, the tick whose Climate phase ran last
  (`tick() − 1` after a step; tick 0 with zero weather before the first step).
- `ClimateMap::seasonal(cell, tick)`: weather-free value for any tick.
- CLI: `./evosim climate series --x X --y Y [--ticks N] [--every K] [--no-weather] [--config FILE | --preset NAME] [--seed N] [--width W --height H]`
  prints JSON `{"cell","year_length","weather","bounds","series":[{"tick","temperature","precipitation"}]}`.
  Example: `./evosim climate series --x 3 --y 2 --no-weather --ticks 800` (entries t and t+400 are identical).

### State
The weather lattices are the only climate state carried between ticks
(`Simulation::weather_state()` → `WeatherState`, restored with
`Simulation::set_weather_state`; `Simulation::resume` starts with zero weather).
The current grid is derived from it. Snapshots/state hashes (TASK-022) must include it.

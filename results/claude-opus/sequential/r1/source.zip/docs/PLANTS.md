# Plants: energy, resources, growth, death (TASK-011) and reproduction (TASK-012)

Design record: [ADR-014](decisions/ADR-014-plant-growth-resources.md). Code: `crates/evosim-core/src/plants/`.

## Where plant energy comes from
- Every cell has **one soil resource `R`** (an abstraction of water + nutrients; light is not modelled). `R` starts at `plants.resource_cap` and always stays in `[0, plants.resource_cap]`.
- **Resources phase** (every tick, after Climate): `R ← min(cap, R + plants.resource_regen · m)`, where `m = clamp(P_now / climate.max_precipitation, 0, 1)` is the cell's *current* moisture (seasons + weather included). Dry cells refill slowly.
- **Plants phase**: plants take up energy **only** from the `R` of their own cell, 1 unit of `R` = 1 unit of energy. Nothing else adds plant energy (no replenishment, no free energy). Health healing creates no energy.
- Energy leaves plants through **upkeep** (respiration) every tick: `plants.upkeep · (0.75 + 0.5·strength)`. Later tasks add grazing (TASK-014) and reproduction costs (TASK-012).
- Audit: `World::plant_ledger()` keeps cumulative `regen_added`, `uptake`, `upkeep`. Tested invariants: `Σ R(t) = Σ R(0) + regen_added − uptake`, and in each Plants phase the plants' energy change equals `uptake − upkeep` with `uptake` = resource removed from the cells (`plants::tests::energy_ledger_balances`, `no_resource_no_growth`).

## What limits growth
Per plant and tick the demand is `d = min(growth_rate · f_T · f_W · peak, max_energy − energy)`:
- `f_T = max(0, 1 − ((T_now − temp_optimum)/temp_tolerance)²)` – current temperature; 0 outside the tolerance.
- `f_W = clamp((m − water_min)/(water_optimum − water_min), 0, 1)` – current moisture; 0 below `plants.water_min`.
- `peak = 1 − generalist_cost · clamp((temp_tolerance − 2)/28, 0, 1)` – wide tolerance lowers the peak rate.
- Energy headroom (`max_energy` trait): a full plant takes nothing.
- **Competition**: all plants of a cell share its `R`. If total demand `D > R`, each plant gets `d · R/D` (fair share, independent of processing order, no random numbers). Total uptake per cell per tick ≤ `R` ≤ cap, so growth is bounded; at steady state a cell feeds about `resource_regen · m / upkeep` plants.

## Ageing and death
- **Old age**: age increases every tick; `age ≥ max_lifespan` (genome trait, ≤ `plants.max_age`) → `OldAge`.
- **Lack of energy**: energy 0 after upkeep → `Starvation` (Deaths phase).
- **Hostile climate**: stress `s = max(s_T, s_W)` with `s_T = clamp(|T − opt|/tol − 1, 0, 1)` and `s_W = 1 − m/water_min` if `m < water_min`. Stressed plants lose `stress_damage · max_health · s` health per tick; health 0 → `Climate` death. Unstressed plants heal `heal_rate · max_health` per tick.

## Genome-derived traits used
`temp_optimum`, `temp_tolerance` (thermal niche, stress, generalist cost), `max_energy` (storage), `strength` (upkeep cost; grazing toughness later), `max_lifespan`, `max_health` (how long stress is endured). `fertility` is used by TASK-012.

## Parameters (docs/CONFIG.md)
`plants.resource_cap`, `plants.resource_regen`, `plants.growth_rate`, `plants.upkeep`, `plants.water_min`, `plants.water_optimum`, `plants.generalist_cost`, `plants.stress_damage`, `plants.heal_rate`, `plants.max_age`, `plants.max_energy`.

## Known consequences
With the default founders (opt ≈ 10 °C, tol ≈ 16 °C) plants cannot grow at the poles or the hottest equator cells. Every founder dies by `max_age`; the population persists only through reproduction (below). Balance is tuned in TASK-027.

## Reproduction and dispersal (TASK-012, ADR-015)
Runs in the Plants phase right after growth (module `plants/repro.rs`, `reproduce_plants`).
- **Eligibility**: only living plants with `energy ≥ plants.reproduction_threshold` (default 12). If none is eligible, or `plants.seed_rate = 0`, the step draws no random numbers.
- **Order**: eligible plants in shuffled EntityId order (core RNG), because seeds compete for room.
- **Seed chance**: `clamp(seed_rate · (0.5 + fertility), 0, 1)` per tick (default fertility 0.5 → `seed_rate`, default 0.5).
- **Cost**: each seed costs the parent `reproduction_cost` (default 6), paid even if the seed fails. The seed starts with `min(initial_energy, cost)` (default 5); the rest is lost. Energy is never created.
- **Dispersal pattern**: uniform over the toroidal Chebyshev square of radius `plants.dispersal_radius` (default 3) around the parent, own cell included; wraps at all edges (one draw per axis).
- **Site check (room + resources)**: the seed establishes only if the landing cell holds fewer than `max_per_cell` living plants (counting seeds accepted earlier in the same tick) **and** its soil resource `R ≥ plants.seed_min_resource` (default 1). Otherwise the seed dies (`seeds_failed`). This makes reproduction density-dependent without global counts.
- **Pollination** (decision: asexual by default + optional pollination): if `pollination_enabled` and with chance `pollination_chance` (0.3) the seed is fertilised by the nearest other living plant within `pollen_radius` (2) whose genetic distance to the mother is `≤ plants.species_threshold` (placeholder until TASK-017) → uniform crossover, `Parents::Two(mother, donor)`. Otherwise clone, `Parents::One(mother)`. Then mutation with `plants.mutation_rate/strength`.
- **Recording**: the Births phase assigns the ID, `generation = 1 + max(parent generations)`, and emits `EventKind::Birth` with the parents. A request is dropped if the mother or donor dies later in the same tick.
- **Plants only from plants**: births come only from living plants; a world with zero plants stays at zero (test `zero_plants_stay_zero`). There is no seed bank.
- **Ledger** (`PlantLedger`): `reproduction_spent`, `seed_energy`, `seeds_made/failed/requested`, `pollinated` (+ `last_*`). Per Plants phase: energy change = `uptake − upkeep − reproduction_spent`; `seed_energy ≤ reproduction_spent`.

Observed (test `plants_spread_and_persist`, 64×48, 400 founder plants, no animals, seed 42, 600 ticks): occupied cells 379 → 804, 864 plants alive, 2 331 plant births, max generation 14. Tuning is TASK-027.

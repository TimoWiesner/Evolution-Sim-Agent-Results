# `evosim batch` — batch runs, parameter sweeps, summary export

Design: [ADR-024](decisions/ADR-024-batch-runs-export.md) (TASK-021). Contract: docs/CONTRACT.md §2.

## Command
```
evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR
             [--param KEY=V1,V2,...]... [--sample-every K] [--jobs J]
```
- `--seeds`: comma list of non-negative integers, no duplicates (each overrides the config seed).
- `--param KEY=V1,V2,...` (repeatable): `KEY` is a dotted config key from `evosim config schema`
  (e.g. `plants.growth_rate`, `initial.carnivores`, `world.width`). Values are JSON literals: `1.2`, `3`, `true`,
  `"text"` (strings need JSON quotes, shell-quote them). Integer keys need integer tokens: `3.0` or `1e2` are
  rejected as "wrong type" (serde_json parses them as floats). Several `--param` = cartesian product; the first
  `--param` varies slowest. `seed`, `name`, `description` are not sweepable. Same key twice, duplicate value,
  unknown key, wrong type, out-of-range → exit 2. At most 10,000 runs.
- `--sample-every K` as in `run` (default max(1, N/100)).
- `--jobs J` (1…1024): worker threads, default = CPU count (capped at the number of runs). Does not change any
  result (each run is an independent seeded simulation; results are collected by run index).
- Validation first: arguments, config file (same error messages as `run`), every combination's config and
  `Simulation::new`, the out-dir. Any error → exit 2, message on stderr, nothing created or written.
  A write error after the runs (disk full, …) → exit 2; files already written stay.
- `--out-dir` is created if missing; an existing directory is reused (files overwritten, stale files of older
  batches are not removed). stdout stays empty; one line per run and a total line go to stderr.

## Files
| File | Content |
|---|---|
| `DIR/seed-<s>.json` (no `--param`) / `DIR/combo-<c>/seed-<s>.json` | exactly the `run` result JSON (CONTRACT §4) of that run; its `config` key is the effective configuration |
| `DIR/summary.json` | format `evosim-batch-summary` v1, see below |
| `DIR/summary.csv` | one row per run |
| `DIR/aggregates.csv` | one row per (group, kind); group `all` then `combo-<c>` |

Run order: `index = combo * |seeds| + seed position`.

## `summary.json`
Top level: `format`, `format_version`, `contract`, `name`, `version`, `config_file` (as given), `ticks`,
`sample_every`, `seeds`, `sweep` (`[{key, values}]`, `[]` without `--param`), `combinations`
(`[{combo, params, dir}]`; `dir` = `"."` without sweep), `runs`, `aggregates`, `timing`.

`runs[]`: `index, combo, seed, params ({key: value}), file, tick_start, tick_end, ticks, final {plants, herbivores,
carnivores, species{...}}, births{...}, deaths{...}, extinct{kind: bool}, extinction_tick{kind: tick|null},
coexistence (all three alive at tick_end), state_hash, elapsed_seconds, ticks_per_second`.

`aggregates.all` and each `aggregates.by_combo[]` (plus `combo`, `params`):
`runs, coexistence_runs, coexistence_fraction, kinds{KIND: {final{mean,min,max,sd,median}, species_final{mean,min,max},
extinct_runs, extinct_fraction, extinction_tick{mean,min,max}|null, births_mean, deaths_mean}}`.
"Went extinct" = the run's `extinction_tick` of that kind is non-null (count reached 0; no replenishment, so the
final count is 0). `sd` is the population standard deviation; `median` of an even count is the mean of the middle two.

`timing`: `wall_seconds`, `jobs`, `sum_elapsed_seconds`.

## Reproducibility
Time measurements are exactly `timing`, `runs[].elapsed_seconds`, `runs[].ticks_per_second`
(`evosim_core::batch::TIME_KEYS`, `strip_time`). Everything else is a pure function of the config file content,
the arguments except `--jobs`/`--out-dir`, and the build; sums are taken in run-index order. In the CSVs, only the
last two columns of `summary.csv` are time values; `aggregates.csv` has none.

## CSV format
RFC 4180: comma, `\n`, fields with `,` `"` or newline quoted (quotes doubled). Parameter values in JSON text form
(strings without quotes), null → empty, bools `true`/`false`.

`summary.csv` header: `index,combo,seed,<param keys...>,ticks,final_<kind>×3,species_<kind>×3,births_<kind>×3,
deaths_<kind>×3,extinct_<kind>×3,extinction_tick_<kind>×3,coexistence,state_hash,elapsed_seconds,ticks_per_second`.

`aggregates.csv` header: `group,<param keys...>,kind,runs,final_mean,final_min,final_max,final_sd,final_median,
extinct_runs,extinct_fraction,extinction_tick_mean,coexistence_runs`.

## Tests
- core `batch::tests` (parsing, expansion order, aggregates on hand-made outcomes, CSV quoting, determinism).
- CLI `tests/cli.rs`: `batch_plain_seeds`, `batch_sweep_2x2`, `batch_reproducible`, `batch_errors_exit_2`.
- `scripts/check-entrypoints.sh`: e2e batch blocks.

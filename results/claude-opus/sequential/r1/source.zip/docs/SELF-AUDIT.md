# Self-audit against docs/PROJECT.md (TASK-028)

Status per requirement: **met**, **partly met** or **missing**. Evidence = document, test or recorded command.
Verification evidence for the interface contract: [VERIFICATION.md](VERIFICATION.md). Audited on 2026-11-23.

## Required behaviour

| # | Requirement (docs/PROJECT.md) | Status | Evidence / notes |
|---|---|---|---|
| 1 | Finite toroidal grid | met | `topology::Torus` (ADR-007); `wrapping_properties` in `crates/evosim-core/tests/randomized_invariants.rs` (4,000 random queries on 200 random tori incl. 1×N) |
| 2 | Cell-by-cell animal movement | met | ADR-016, docs/ANIMALS.md; moves only via `Population::move_organism` one cell step at a time |
| 3 | Wrap-aware perception and spatial lookup | met | ADR-003/013, docs/SPATIAL.md; `spatial_index_matches_brute_force_near_seams` (index vs brute-force torus oracle, seam-biased centres, 25 random worlds) |
| 4 | User-configurable dimensions and initial populations | met | CONTRACT §3 keys; `evosim run --config`, UI New world dialog (ADR-028) |
| 5 | Latitudinal climate zones, smooth torus seam, temperature + precipitation | met | ADR-009, docs/CLIMATE.md; `climate::tests::seam_pairs_no_larger_than_interior`; `climate_seams_continuous_random_sizes` (60 random sizes) |
| 6 | Seasons and weather vary over ticks and affect entities | met | ADR-010; plant climate stress (ADR-014), animal climate cost (`*.climate_cost`); `climate series` check in check-entrypoints |
| 7 | Explain the world topology compromise | met | docs/CLIMATE.md "The compromise: latitude zones on a world without edges" (folded latitude: poles on the top/bottom seam, equator mid-map) |
| 8 | Plants consume resources, grow, reproduce (asexual + pollination), mutate, form species | met | ADR-014/015, docs/PLANTS.md, species ADR-020 |
| 9 | Herbivores eat plants, carnivores eat herbivores | met | ADR-017/018, docs/ANIMALS.md, docs/ECOLOGY.md |
| 10 | Traits incl. speed, strength, health, fertility, genetic behaviour (aggression/risk) | met | 11 traits (`organism/traits.rs`: speed, strength, fertility, max_health, max_lifespan, max_energy, vision, aggression, caution, temp_optimum, temp_tolerance); ranges checked every tick in the randomised test |
| 11 | Coherent lifespan, energy, nutrition, costs, reproduction controls | met | ADR-011/014/017/018/019; energy sources documented (cell resources → plants → herbivores → carnivores); accounting checked every tick |
| 12 | Two-parent sexual reproduction for animals, inherited DNA, mutations | met | ADR-019, ADR-004/012 (uniform crossover + Gaussian mutation) |
| 13 | Emergent species via explicit stable species criterion | met | ADR-020, docs/SPECIES.md (founder-distance threshold assigned at birth, stable) |
| 14 | No forced anti-extinction mechanics | met | no organism creation outside initial population/reproduction; no rule reads global counts (ADR-030 audit); randomised test checks "zero stays zero" in 100 random configs; `initial.plants=0` check (contract §5.3) |
| 15 | Target population 1,000–5,000 entities | met | contract example runs at ~700–5,000 organisms (docs/PERFORMANCE.md); demo scenario ≈ 12,000–16,000 (larger world, by design) |
| 16 | ≥100 ticks/s at 2,000 entities on disclosed hardware | met | `./evosim perf` 346.9 ticks/s at mean 3,216 organisms on this container (docs/PERFORMANCE.md, host CPU in JSON report); not guaranteed on other hardware |
| 17 | Same engine for headless CLI and live UI | met | `evosim-ui` uses `evosim_core::sim::Simulation` (ADR-026); UI checkpoint files load in `evosim run --load` |
| 18 | UI: climate-coloured map, entity differentiation, pan/zoom, run/pause/reset/step, speed, inspect | met | ADR-026/027, README "User interface", `scripts/ui-checks.sh` |
| 19 | Edit initial parameters in UI, presets, import/export config (JSON), seed control | met | ADR-028; presets default/lush/harsh/plants-only; JSON only (TOML/YAML not supported — allowed: "at least one") |
| 20 | Save/load full state with DNA, RNG and climate | met | ADR-025, docs/CHECKPOINTS.md; `checkpoint_split_equivalence` (20 random configs) + contract check A+B |
| 21 | Headless multi-seed and parameter batch runs with comparative statistics | met | `evosim batch` (ADR-024, docs/BATCH.md): summary.json/csv, aggregates per combination |
| 22 | Visualisation: population, births/deaths, diversity, genetic distributions/means, generation trends | partly met | UI charts: population, births/deaths, living species, trait mean±sd over time, trait histogram (ADR-028). Generation trends are in `--metrics` output (generation max/mean, docs/METRICS.md) but not drawn as a UI chart |
| 23 | Unit, integration, regression, property-based, multi-thousand-tick tests; seed repeatability | met | `./test.sh`: cargo unit + integration tests, regression goldens (`scripts/perf-equivalence.txt`, hash goldens), seeded randomised property tests (`randomized_invariants.rs`; explicit seeded generator, no shrinking), multi-thousand-tick runs (`plants_zero_starves_animals_in_random_configs` up to 5,000 ticks; `scripts/long-runs.sh` 10 × 10,000 ticks, recorded in VERIFICATION.md) |

## Extinction and stabilising mechanisms

| Rule | Status | Evidence |
|---|---|---|
| No creation outside initial population/reproduction | met | births only in the Births phase from parents/seeds (ADR-019/015); randomised no-replenishment check |
| No rule depending on global/species counts | met | ADR-030 audit; `hunting.prey_density_half` uses the herbivores within the carnivore's own vision only |
| No immortality | met | every organism dies at `age ≥ max_lifespan` (heritable trait, upper bound from `*.max_age`; `organism/population.rs`) |
| No energy without documented source | met | docs/ECOLOGY.md energy flow; accounting identity |
| Coexistence as long as possible via ecology | partly met | demo scenario: see VERIFICATION.md §Coexistence; demo 10/10 seeds full 10,000 ticks; contract example only 6/15 seeds (median 2,208.5 on held-out seeds 1001–1010) |

## Agent-owned architecture decisions

ADR-001 (language/runtime: Rust + local browser UI ADR-002), ADR-003/013 (spatial index), ADR-004/012/020 (DNA,
inheritance, mutation, speciation) — all with alternatives, trade-offs, performance and test consequences.

## Known limitations (stated openly)
- **Coexistence of the contract example is not robust.** With the default parameters the three kinds coexist for
  10,000 ticks only in some seeds (see VERIFICATION.md); carnivores usually die out first (starvation after prey
  crashes). The tuning sits on a narrow ridge (`hunting.prey_density_half` / `base_success`, docs/BALANCE.md).
- The demo scenario's better coexistence comes from a larger world (more spatial refuges), not from new mechanisms;
  it is measured on few seeds and is not a guarantee.
- Performance numbers are from this container (12 cores, single-threaded simulation); other hardware differs. The
  simulation loop is sequential by design (deterministic turn order), so extra cores only help `batch --jobs`.
- Configuration import/export supports JSON only.
- Headless chromium paints only ~813 of 900 px in `ui --screenshots`; the bottom ~88 px of PNGs are empty.
- The UI limits worlds to 1,048,576 cells; `evosim run` has no such limit (but large worlds are slow).
- Species criterion = distance to the species founder at birth (ADR-020): stable, but it measures divergence from
  the founder, not current population structure; animals of different species can mate (`mating_threshold` 0.2 >
  `species_threshold` 0.15) and the child is classified via the first parent's species (docs/SPECIES.md).
- Randomised tests use an explicit seeded generator (fixed case list) rather than a shrinking property-testing
  framework; failing cases are printed but not minimised.
- Self-containment was verified in a minimal chroot on this container (dist/ + 4 base libraries); not on a separate
  physical Ubuntu machine. `dist/evosim` requires glibc ≥ the build host's (Ubuntu 24.04).
- UI generation-trend chart is missing (requirement 22 partly met).

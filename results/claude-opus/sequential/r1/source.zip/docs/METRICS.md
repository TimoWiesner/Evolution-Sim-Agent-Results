# Metrics file format (`evosim-metrics`, version 1)

TASK-020, design [ADR-023](decisions/ADR-023-metrics-analytics.md). Core: `crates/evosim-core/src/metrics/`.

## How to get it
```sh
./evosim run --config my.json --ticks 1000 --out result.json --metrics metrics.json [--sample-every 10]
```
`--metrics FILE` is optional. Without it nothing changes. With it the result JSON (`--out`) is byte-for-byte the
same apart from `elapsed_seconds`/`ticks_per_second`; in particular `state_hash` is identical (the recorder only reads
the simulation). The file is checked before the run like `--out` (parent directory must exist, must not be a
directory, must differ from `--out`); on any error exit status 2, a message on stderr and neither file is written.
Both files are written to a temporary file and renamed. Size: roughly 5 KB per sample (contract example, 1000 ticks,
101 samples: ≈ 0.5 MB, ≈ 4 % extra run time).

## Sampling
One sample per `series` point of the result: `tick_start`, every `sample_every` ticks after it, and `tick_end`
(no duplicates). `samples[i].tick == series[i].tick` and `samples[i].<kind>.count == series[i].<kind>`.
A sample is taken after the tick has been fully simulated (state at the end of that tick).

## Document
One JSON object (single line). Object key order is not significant.

| Key | Type | Meaning |
|---|---|---|
| `format` | string | always `"evosim-metrics"` |
| `format_version` | int | `1` |
| `seed` | int | seed of the run |
| `tick_start`, `tick_end`, `sample_every` | int | same as in the result |
| `kinds` | string[] | `["plants", "herbivores", "carnivores"]` |
| `traits` | string[] | the 11 trait names (see below), order of the `Traits` fields |
| `death_causes` | string[] | `["old_age", "starvation", "injury", "predation", "grazed", "climate"]` |
| `samples` | object[] | one per sample tick, ascending |

Each sample: `{"tick": T, "plants": K, "herbivores": K, "carnivores": K}` where `K` is:

| Key | Type | Meaning |
|---|---|---|
| `count` | int | living individuals at the end of tick T |
| `births`, `deaths` | int | births / deaths in the interval (previous sample tick, T]; `0` at the first sample |
| `births_total`, `deaths_total` | int | cumulative since tick 0 (founders are not births) |
| `deaths_by_cause` | object | cause → deaths in the interval, all 6 causes present (zeros included) |
| `deaths_by_cause_total` | object | cause → cumulative deaths since tick 0 |
| `species.living` | int | species of the kind with ≥ 1 living member (= `final.species` at the last sample) |
| `species.appeared_total` | int | species records of the kind ever created (founder species included) |
| `species.extinct_total` | int | of these, extinct ones (`living + extinct_total == appeared_total`) |
| `generation.max` | int or null | highest generation among the living (founders = 0) |
| `generation.mean` | float or null | mean generation of the living |
| `traits.<name>` | Stat or null | distribution of the trait over the living individuals |
| `energy` | Stat or null | distribution of current energy |
| `age` | Stat or null | distribution of age in ticks |

`Stat` = `{"mean": f, "sd": f, "min": f, "max": f}`. `sd` is the **population** standard deviation
`sqrt(Σ(x − mean)² / n)` (so one individual gives `0`). Computed in f64 over the living individuals in ID order
(deterministic). When `count` is 0 every Stat and both `generation` values are `null` (never fake zeros).

Trait names: `speed` (cells/tick), `strength`, `fertility`, `max_health`, `max_lifespan` (ticks), `max_energy`,
`vision` (cells), `aggression`, `caution`, `temp_optimum` (°C), `temp_tolerance` (°C). All kinds share the schema;
traits a kind does not use (plants: `speed`, `vision`, `aggression`, `caution`) are constant 0 with `sd` 0.

Identities that always hold: `count == initial + births_total − deaths_total` (initial from the result `totals`);
`Σ deaths_by_cause == deaths`; Σ over samples of `births` == last `births_total` − first `births_total`; the last
sample's `*_total` values equal the result's `totals`.

## Example (shortened)
```json
{"format":"evosim-metrics","format_version":1,"seed":42,"tick_start":0,"tick_end":1000,"sample_every":10,
 "kinds":["plants","herbivores","carnivores"],"traits":["speed","strength","..."],
 "death_causes":["old_age","starvation","injury","predation","grazed","climate"],
 "samples":[{"tick":500,
   "herbivores":{"count":76,"births":2,"deaths":4,"births_total":166,"deaths_total":210,
     "deaths_by_cause":{"old_age":0,"starvation":0,"injury":0,"predation":4,"grazed":0,"climate":0},
     "deaths_by_cause_total":{"...":0},
     "species":{"living":1,"appeared_total":1,"extinct_total":0},
     "generation":{"max":7,"mean":3.6447},
     "traits":{"speed":{"mean":1.0123,"sd":0.0468,"min":0.9271,"max":1.1236},"...":{}},
     "energy":{"mean":61.57,"sd":13.47,"min":21.28,"max":81.30},"age":{"...":0}},
   "plants":{"...":0},"carnivores":{"...":0}}]}
```

## Reading it
```python
import json
m = json.load(open("metrics.json"))
speed = [(s["tick"], s["herbivores"]["traits"]["speed"]) for s in m["samples"]]
```

# Ecology: food chain, tick order, extinction (TASK-018)

Design: [ADR-021](decisions/ADR-021-ecology-integration.md). Code: `sim/mod.rs` (`run_phase`), `sim/stats.rs`
(`TickStats`, `balance_ok`), `ecology/mod.rs` (`survival_run`, report), `animals/feed.rs` (`graze_reserve`).

## Tick order (`Phase::ORDER`)
1. Climate (season + weather) 2. Resources (soil regeneration) 3. Plants (growth/upkeep/climate stress, then seed
reproduction requests) 4. Herbivores (shuffled turns: metabolism, flee/court/rest/graze; mating pass) 5. Carnivores
(shuffled turns: metabolism, handling/court/rest/hunt; mating pass) 6. Births (requests resolved, species classified)
7. Deaths (aging, natural deaths, removal of everything flagged) 8. Species (appeared/extinct events)
9. Statistics (`TickStats`: alive / cumulative and per-tick births and deaths per kind).
Test: `sim::tests_ecology::tick_runs_all_phases_in_documented_order`.

## Creation and extinction
Organisms are created only as founders (tick 0) or by reproduction (Births phase, parents of the same kind).
There is no respawn/immigration, so a kind that reaches zero stays at zero. `initial + births − deaths == alive`
holds after every tick (`balance_ok`). Tests: `no_creation_outside_reproduction`, `extinct_kind_stays_extinct`,
`balance_holds_every_tick`, scenarios `no_plants_herbivores_then_carnivores_die_out`,
`no_herbivores_carnivores_die_out`, `plants_alone_persist_and_reproduce`.

## Stabilising mechanisms (all local, same for every organism)
- **Protected plant reserve** `herbivores.graze_reserve` = 0.35: no bite takes the last 35 % of a plant's max energy
  (root reserve). Without it grazing drained plants below upkeep and plants went extinct even without carnivores.
  Consequence: with reserve > 0 plants are not grazed to death (DeathCause::Grazed only when `graze_reserve` = 0).
- Regenerating, capped soil resources and density-dependent plant growth (plant self-limitation).
- Satiation of animals; handling time after a kill (15 ticks).
- Prey cover in plant-dense cells (`hunting.cover_protection` 0.6); prey caution/flight genes.
- Hunting requires finding prey (vision, reach 1), base attack success (0.33) scaled by local prey density n/(n+40): sparse prey ⇒ fewer kills.
- Climate zones (thermal metabolism costs).

## Default balance (current defaults; changed in TASK-018 and TASK-027, see docs/BALANCE.md)
plants: resource_regen 1.0, resource_cap 15, upkeep 0.1, growth_rate 1.5, initial_energy 4, reproduction_threshold 8,
reproduction_cost 4, max_per_cell 2. herbivores: base_metabolism 0.3, max_meal 2, move_cost 0.1, initial_energy 80,
maturity_age 60, reproduction_threshold 70, mating_cooldown 40, max_litter 3, max_per_cell 2, graze_reserve 0.35.
carnivores: base_metabolism 0.3, move_cost 0.15, maturity_age 150, max_litter 1, mating_cooldown 120.
hunting: base_success 0.33, prey_density_half 40, handling_time 15, cover_protection 0.6.

**TASK-027 (ADR-030, docs/BALANCE.md):** new local type-III hunting factor `hunting.prey_density_half` 40
(success × n/(n+40), n = herbivores within the carnivore's vision), `hunting.base_success` 0.33,
`herbivores.initial_energy` 80. Held-out coexistence median 2,208.5 ticks (3/10 to 10,000) vs 1,508.5 (0/10) before.

### Sweep (contract example config, 3,000 ticks, seeds 1–3; plant/herbivore values above fixed)
96 combinations of base_success {0.12,0.16,0.2} × handling {15,20} × cover {0.5,0.6} × carn metabolism {0.25,0.3}
× litter {1,2} × cooldown {80,120}. Best by median three-kind coexistence (ticks):
| base_success, handling, cover, metab, litter, cooldown | coexistence (s1,s2,s3 sorted) | herbivores extinct | carnivores extinct |
|---|---|---|---|
| 0.12, 15, 0.6, 0.3, 1, 120 (**chosen**) | 2091, 2185, 2204 | never | 2185, 2204, 2091 |
| 0.12, 15, 0.6, 0.3, 1, 80 | 1514, 2015, 2344 | never | 2015, 2344, 1514 |
| 0.12, 20, 0.6, 0.25, 1, 80 | 837, 1979, 2700+ | –, 537, – | –, 837, 1979 |
| 0.12, 20, 0.6, 0.3, 2, 80 | 1744, 1882, 2058 | never | 1882, 1744, 2058 |
Higher base_success (0.16/0.2) ⇒ herbivores eaten out within ~500 ticks. A partial second sweep (base_success
0.08/0.1, cover 0.7, carnivores.max_per_cell 1) was worse (carnivores starve by ~900–1,400). The usual failure mode
of the chosen setting is that carnivores slowly starve (~2,100 ticks); TASK-027 tunes further.

## Survival report (10,000 ticks × 5 seeds)
Command: `./scripts/extinction-report.sh` (= `./evosim ecology survival`; options `--config FILE | --preset NAME`,
`--seeds 1,2,3`, `--ticks N`, `--json`). Defaults: contract example config (only fixed keys), seeds 1–5, 10,000 ticks.
Recorded result (TASK-018 IMPLEMENT, 70.8 s wall for all five seeds in parallel):
```
seed 1: plants survived (final 1463, peak 4931) | herbivores survived (final 1143, peak 1404) | carnivores extinct at tick 2185 (peak 20) | coexistence 2185 of 10000 ticks
seed 2: plants extinct at tick 7480 (peak 4594) | herbivores extinct at tick 7488 (peak 1296) | carnivores extinct at tick 2204 (peak 23) | coexistence 2204 of 10000 ticks
seed 3: plants survived (final 1358, peak 4503) | herbivores survived (final 1005, peak 1327) | carnivores extinct at tick 2091 (peak 21) | coexistence 2091 of 10000 ticks
seed 4: plants survived (final 1451, peak 4629) | herbivores survived (final 980, peak 1292) | carnivores extinct at tick 2815 (peak 22) | coexistence 2815 of 10000 ticks
seed 5: plants survived (final 3804, peak 4883) | herbivores extinct at tick 694 (peak 120) | carnivores extinct at tick 1036 (peak 24) | coexistence 694 of 10000 ticks
```
Median three-kind coexistence: 2,185 ticks (previous defaults: ~115). Plants+herbivores persist 10,000 ticks on 3/5 seeds.

# ADR-013: Spatial index detail — kind-split cell buckets owned by `Population`

## Status
Accepted — 2026-11-22 — TASK-010 (PLAN cycle 1). Refines [ADR-003](ADR-003-spatial-index.md) (which left "one index per kind or one index with kind filter" open).

## Context
ADR-003 fixed a per-cell bucket index with a torus-aware Chebyshev scan and brute force as test oracle. TASK-010 must decide the concrete data structure and the query interface. Constraints: queries by radius around a cell, optionally restricted to one `Kind`; correct across the seams, no duplicates for radii ≥ world size or worlds like 1×1 / 1×N; adding, moving and removing organisms keeps the index correct (a removed or moved organism is never reported from its old cell); deterministic result order; measurably faster than brute force at ≈2,000 organisms. Core must not use hashed collections or wall clock (ADR-005, source-scan test).

## Alternatives considered
### A. Three independent per-kind indices held in `World`, synced by the scheduler
- Pros: kind filter is free; `Population` unchanged.
- Cons: every mutation path (`kill`, births, moves, `organisms_mut()` users, `set_population`) must remember to update a second structure; mid-phase kills would leave stale entries until the Deaths phase, so every query would have to re-check liveness.

### B. One index with mixed buckets `Vec<(EntityId, Kind)>` per cell
- Pros: one bucket per cell, smaller memory.
- Cons: kind-filtered queries scan foreign entries (plants usually dominate, so carnivore queries for prey would wade through plants).

### C. CSR layout rebuilt once per tick (counting sort)
- Pros: cache-friendly, no per-cell Vec.
- Cons: stale within a tick as soon as animals move; the task requires the index to stay correct under moves. Kept as a possible TASK-026 optimisation.

### D. Kind-split cell buckets + locator, owned by `Population` (chosen)

## Decision
New core module `spatial` (`crates/evosim-core/src/spatial/{mod.rs,tests.rs}`), depending only on `topology`, `ids`, `organism::Kind`.

```text
SpatialIndex {
    torus: Torus,
    buckets: Vec<Vec<EntityId>>,               // len = 3 · W · H, slot = torus.index(cell) · 3 + kind.index()
    locator: BTreeMap<EntityId, (Cell, Kind)>, // where each entry is
}
```
- Every bucket is sorted ascending by `EntityId` (insert/remove by binary search).
- `Default` = empty index on a 1×1 torus (placeholder only).
- Public interface:
  - `SpatialIndex::new(Torus)`, `torus()`, `len()`, `is_empty()`, `clear()`, `count(kind)`.
  - `insert(id, kind, cell) -> Result<(), SpatialError>` (`Duplicate(id)`, `OutsideWorld(cell)`).
  - `remove(id) -> Option<(Cell, Kind)>`; `move_to(id, cell) -> Result<Cell /*old*/, SpatialError>` (`Unknown(id)`, `OutsideWorld`); moving to the same cell is a no-op.
  - `location(id) -> Option<(Cell, Kind)>`; `contains(id)`.
  - `at(cell, filter: Option<Kind>) -> Vec<EntityId>` (ascending id; `None` = all kinds merged).
  - `within(center, r, filter) -> Vec<Neighbour>`, `within_into(center, r, filter, &mut Vec<Neighbour>)` (clears and fills; allocation reuse for behaviour loops), `count_within(center, r, filter) -> usize`, `nearest(center, r, filter, pred: impl FnMut(&Neighbour) -> bool) -> Option<Neighbour>`.
  - `Neighbour { id, kind, cell, offset: Offset /*shortest from center*/, distance: u32 }`.
  - `entries() -> impl Iterator<Item=(EntityId, Kind, Cell)>` (ascending id) and `check_against(expected entries) -> Result<(), String>` for consistency tests.
- Free function `spatial::brute_force_within(torus, entries, center, r, filter) -> Vec<Neighbour>` — the oracle, public so the CLI benchmark can time it.
- **Query algorithm**: cells come from `Torus::within(center, r)` (axis spans clamped to distinct cells, ADR-007 — no duplicates for big radii / tiny worlds). If `torus.count_within(r) > len()` (scan would visit more cells than there are entries) the query iterates the locator instead (O(N), same results). Hits are sorted by `(distance, id)`; ids are unique, so the order is total and deterministic. `offset`/`distance` come from `Torus::offset`/`Torus::distance` semantics (tie at n/2 → positive offset).
- `nearest` = first hit of `within` in `(distance, id)` order satisfying `pred` (simple; ring early-exit may be added by TASK-026).
- **Ownership / sync**: `Population` owns a `SpatialIndex` of **living** organisms; all mutations keep it in sync:
  - `Population::founders` inserts founders; `resolve_births` inserts newborns (position wrapped into the torus first);
  - `kill` removes the organism from the index immediately (flagged-dead organisms are already hidden from queries, ADR-011), so the Deaths-phase `retain` needs no index work;
  - `Population::move_organism(id, cell) -> Result<Cell, SpatialError>` is the only way to move a living organism (updates `pos` and index); `Organism::set_pos` becomes `pub(crate)`;
  - `Population::rebuild_index(torus) -> Result<(), String>` (used by `World::set_organisms` / `Simulation::set_population`; errors if a position lies outside the torus). The index is derived data: not serialised by TASK-022, rebuilt on restore.
  - Convenience: `Population::{index(), within(center, r, filter), nearest(..), at(cell, filter)}`; `Population::validate` additionally checks index == living organisms.
- `Population::new()` keeps its signature (1×1 placeholder index); `Population::with_expression(expr, torus)` gains the torus. `World::from_config` uses `Population::with_expression(Expression::from_config(cfg), torus)`.

## Rationale
### Performance
Query cost O(min((2r+1)², N) + k log k); with r ≤ 8 that is ≤ 289 bucket slots × 1 (filtered) or × 3 (all kinds), against N distance checks for brute force. Updates: O(log m) within a bucket + O(log N) locator. Memory: 3·W·H empty Vecs (24 B each) — 200×200 → ≈2.9 MB, acceptable. Measured in TASK-010 at 2,000 organisms with `evosim spatial bench` (numbers in docs/SPATIAL.md).
### Testability
Standalone `SpatialIndex` is testable against the brute-force oracle with a shadow model under random insert/move/remove; `Population` integration is checked by `validate` after hook-driven runs.
### Self-contained dist/
std only (`BTreeMap`, `Vec`); no new crate, Cargo.lock unchanged.

## Consequences
- Behaviour tasks (TASK-013+) query `ctx.world.organisms().within(..)`/`nearest(..)` and move only via `Population::move_organism`; results contain only living organisms, and an organism killed earlier in the same phase disappears at once.
- Newborns are in the index from the Births phase on (they cannot be found before they exist).
- TASK-022 restores via `set_population`, which rebuilds the index.
- TASK-026 may replace internals (CSR, ring early exit) as long as the oracle tests stay green.

## Verification strategy
`spatial/tests.rs`: randomised oracle comparison (≥ 1,000 queries over worlds incl. 1×1, 1×N, N×1, 2×2, radii > world size, with interleaved insert/move/remove), seam, duplicate, stale-position, order and kind-filter tests; organism/sim tests for index sync; CLI `evosim spatial bench` measurement recorded in docs/SPATIAL.md.

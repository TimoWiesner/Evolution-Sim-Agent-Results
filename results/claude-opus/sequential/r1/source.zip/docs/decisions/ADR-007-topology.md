# ADR-007: Grid coordinates, toroidal topology and distance measure

## Status
Accepted — 2026-11-22 — TASK-004 (refines the metric choice sketched in ADR-003).

## Context
The world is a W×H grid (`world.width`, `world.height`, 1..=4096 per ADR-006/contract) whose left/right and top/bottom edges are joined (torus). Every module that reasons about space (climate, spatial index, plants, animals, UI inspection) needs one shared, deterministic definition of: wrapping arbitrary integer coordinates, shortest displacement ("direction") between cells, distance, and "cells within radius r" — correct also for non-square, 1×1, 1×N and N×1 worlds and for radii larger than the world.

## Alternatives considered
### Distance measure
- **Euclidean** (√(dx²+dy²)): isotropic, "round" perception. Cons: floats or squared integers, neighbourhood is a disc whose cell count and listing are more awkward; does not match 8-neighbour moves (a diagonal step costs √2 while it takes one tick).
- **Manhattan** (|dx|+|dy|): integer, matches 4-neighbour moves. Cons: animals move in 8 directions (ADR-003), so a diagonal step would count 2 and movement range ≠ distance.
- **Chebyshev** (max(|dx|,|dy|)) — chosen: integer, one diagonal or orthogonal step = distance 1, so "speed s" = "reach every cell at distance ≤ s"; the radius-r neighbourhood is the (2r+1)² square, trivially enumerable and clampable to distinct cells; matches the ring scan of ADR-003.

### Position / direction types
- **Signed `i32` positions everywhere, wrap lazily**: easy arithmetic, but invalid positions can leak into state and hashing.
- **Flat cell index `usize` only**: compact, but displacement math needs div/mod everywhere and is unreadable in tests.
- **Canonical `Cell {x: u32, y: u32}` + signed `Offset {dx: i32, dy: i32}` + `Dir8` enum** — chosen: a `Cell` produced by `Torus` is always in range (invariant), offsets carry sign/direction, `Torus::index(cell)` gives the flat index for per-cell arrays.

## Decision
Module `crates/evosim-core/src/topology/` (leaf module, std only):

- `Torus { width: u32, height: u32 }`; `Torus::new(w, h) -> Result<Torus, TopologyError>` rejects 0 and values > `MAX_DIM = 1 << 20` (keeps all `i32`/`i64` intermediate math overflow-free; config already limits to 4096). Getters `width()`, `height()`, `cell_count() -> usize`.
- `Cell { pub x: u32, pub y: u32 }` (`Copy, Eq, Ord, Hash, Debug`; ordering by (y, x) = row-major). Only `Torus` methods create canonical cells from arbitrary input.
- `Offset { pub dx: i32, pub dy: i32 }` = displacement / direction; `chebyshev()`, `is_zero()`, `signum() -> Offset` (unit step direction).
- `Dir8` enum `N, NE, E, SE, S, SW, W, NW` with `ALL`, `offset()`; screen convention **y grows downward (south)**, x grows east. `Dir8::from_offset(Offset) -> Option<Dir8>` (None for zero).
- Wrapping: `wrap(x: i64, y: i64) -> Cell` via `rem_euclid` on i64 — any `i32`/`i64` coordinate incl. negative and many widths away maps to a valid cell. `wrap_coord(v: i64, n: u32) -> u32` helper. `translate(cell, Offset) -> Cell`, `step(cell, Dir8) -> Cell`.
- Shortest axis offset: `d = (b − a).rem_euclid(n)`; if `d > n/2` then `d − n`. Hence the canonical offset range per axis is `[−⌊(n−1)/2⌋, ⌊n/2⌋]`; **tie rule** for even n at exactly n/2: the positive offset (east/south) is returned. `offset(a, b) -> Offset` (a→b), `direction(a, b) -> Option<Dir8>` = `Dir8::from_offset(offset.signum())`.
- **Distance = toroidal Chebyshev**: `distance(a, b) = max(|dx|, |dy|)` of the shortest offset (u32). This is the single metric for perception, movement range, dispersal, mating and spatial queries project-wide. `max_distance() = max(⌊W/2⌋, ⌊H/2⌋)`.
- Neighbourhood: `axis_offsets(r, n)` = `−r..=r` if `2r+1 < n`, else the full canonical range `−⌊(n−1)/2⌋..=⌊n/2⌋` (exactly n distinct values). `within(center, r)` iterates dy over the y-offsets (outer) and dx over the x-offsets (inner), yielding `(Cell, Offset)` — deterministic row-major-by-offset order, no duplicates, every cell with distance ≤ r exactly once. `count_within(r) = |x-offsets|·|y-offsets|`. `ring(center, d)` = the subset of `within(center, d)` with Chebyshev(offset) == d (for nearest-first scans in TASK-010). `neighbours8(cell)` = `within(cell,1)` without the zero offset (distinct cells; empty for 1×1, 2 cells for 1×3 …).
- Iterators are allocation-free structs (`WithinIter`) plus `Vec` convenience (`cells_within`).

## Rationale
### Performance
All operations are O(1) integer ops except enumeration O(cells returned). `rem_euclid` on i64 is a single division; hot paths (ring scan) iterate precomputed offset ranges without per-cell wrapping branches beyond one add+compare.

### Testability
Exhaustive brute-force oracle over all worlds 1..=7 × 1..=7, every centre and radii 0..=10: `within` equals `{c | distance(center,c) ≤ r}`, no duplicates, count matches. Explicit tests for each edge, all corners, negative and multiply wrapped coordinates (±k·W, i64 extremes), 1×1, 1×N, N×1, tie rule.

### Self-contained dist/
Pure std Rust, no crates.

## Consequences
- ADR-003 spatial index builds its ring scan on `Torus::axis_offsets`/`ring`; climate (TASK-006) uses `Torus` for seam-continuous fields; all behaviour code uses `Torus::distance`, never ad-hoc `abs()`.
- Positions in organisms are `Cell`; displacements/movement intents are `Offset`/`Dir8`.
- On a 1×N world all cells share x=0; moves along x are no-ops (translate returns the same cell) — legal, not an error.

## Verification strategy
TASK-004 unit + exhaustive oracle tests in `crates/evosim-core/src/topology/tests.rs` (`cargo test -p evosim-core --release --locked topology`); TASK-010 oracle comparison of the spatial index against `Torus::distance`.

# ADR-001: Language and runtime of the simulation core

## Status
Accepted — 2026-11-22 — TASK-001 (architecture decisions).

## Context
The product is a grid-world ecological simulation with a headless CLI (`evosim run/batch/version`), a live UI (`evosim ui`) sharing the same engine, and a self-contained distributable `dist/evosim` that must run on a plain Ubuntu 24.04 x86-64 system **without any language runtime installed** (`docs/CONTRACT.md` §6). Performance goal: ≥100 ticks/s at 2,000 entities headless; 10,000-tick runs of the example config must finish in <300 s while up to four runs share the machine. Results must be deterministic per seed (§5.1) and checkpoints must reproduce uninterrupted runs exactly (§5.2). Available in the container: Rust/Cargo 1.100.0, Node 18.19.1, Python 3.12.3, build tools.

## Alternatives considered
### A. Python 3 (+ NumPy)
- Pros: fastest to write, rich ecosystem for statistics and plotting.
- Cons: per-organism logic (sensing, decisions, mating) is branchy and does not vectorise well; interpreter-bound loops are typically 10–50× slower than native, making 100 ticks/s at 2,000 entities risky. `dist/` would need PyInstaller or an embedded interpreter (large, fragile, glibc/so-file issues). Determinism fine with `random.Random`, but NumPy RNG/stream versions add coupling.

### B. TypeScript / JavaScript on Node 18
- Pros: one language for UI and core; good JIT performance; the browser UI could even run the engine directly.
- Cons: `dist/` must bundle a Node binary (pkg / single-executable-application), ~80–100 MB and tooling still experimental in Node 18; GC pauses; only f64 numbers and no native u64 (BigInt slow) which complicates a fast 64-bit RNG and exact state hashing.

### C. C++
- Pros: maximum performance, static linking possible.
- Cons: no standard package manager or test framework in the container; more undefined-behaviour risk; JSON/SHA/HTTP dependencies must be vendored manually; slower to test thoroughly.

### D. Rust (chosen)
- Pros: native speed, memory safety, Cargo with built-in `cargo test`, reproducible dependency pinning via `Cargo.lock`, single binary output.
- Cons: longer compile times; more verbose than Python for prototyping.

## Decision
The simulation core, CLI and UI server are written in **Rust (stable, edition 2021)** as a Cargo workspace (`crates/evosim-core`, `crates/evosim-ui`, `crates/evosim-cli`; see `docs/ARCHITECTURE.md`). The `evosim` launcher at the workspace root is a thin shell script that executes the release binary built by `./setup.sh`. Planned dependencies, kept minimal and pinned through `Cargo.lock`: `serde`, `serde_json` (feature `float_roundtrip`), `sha2` (state hash), `tiny_http` (UI server only), dev-dependency `proptest`; optional `toml` for TOML config. Argument parsing is hand-written or `clap` (TASK-002 decides), but usage errors must map to exit status 2.

## Rationale
### Performance
2,000 entities × 100 ticks/s ≈ 200,000 organism updates per second, each a few hundred nanoseconds of native work with a spatial lookup (ADR-003) — comfortably achievable single-threaded in Rust, leaving headroom for four parallel benchmark runs. Organisms are stored in contiguous `Vec`s (cache-friendly), no GC pauses. Release profile: `opt-level=3`, `lto = "thin"`, `codegen-units = 1`, no fast-math.

### Testability
`cargo test --workspace` runs unit tests (in-module `#[cfg(test)]`), integration tests (`crates/*/tests/`), property-based tests (`proptest`) and long multi-thousand-tick regression tests (release-mode where needed) with one command. Deterministic integer RNG (ADR-005) makes golden `state_hash` regression tests possible. CLI end-to-end tests spawn the built binary via `std::process::Command`.

### Self-contained dist/
`cargo build --release` produces one ELF binary that depends only on glibc, libm and libgcc_s, which are part of every Ubuntu 24.04 base system; web UI assets are embedded via `include_str!`/`include_bytes!` (ADR-002). `dist/` is therefore just `dist/evosim` (plus optional README). Verified in TASK-002/028 with `ldd dist/evosim`. Fallback if any non-base library appears: build for `x86_64-unknown-linux-musl` (fully static), target installed by `setup.sh` via `rustup target add`.

## Consequences
- `./setup.sh` must ensure a Rust toolchain (install via rustup only if `cargo` is missing) and run `cargo build --release`; no apt packages planned.
- Contributors need Rust knowledge; JS is only used for the browser front-end.
- Build time of a fresh release build (~1–2 min) must fit into setup.

## Verification strategy
- TASK-002: `./setup.sh` then `./evosim version`; `./build.sh` then `dist/evosim version`; `ldd dist/evosim` shows only base-system libraries.
- TASK-026: measured ticks/s at 2,000 entities recorded in docs with hardware (reference: AMD Ryzen 5 7500F, 12 logical cores).

## Addendum (TASK-002 IMPLEMENT, 2026-11-22)
- Argument parsing: **hand-written** (`crates/evosim-cli/src/lib.rs::dispatch`), no `clap`. Small surface, exact control of exit status 2 / stderr, zero external crates in the skeleton.
- `dist/` verified: `ldd dist/evosim` → only linux-vdso, libgcc_s, libc, ld-linux; a copy run with `env -i PATH=/usr/bin:/bin` works. Checked automatically by `scripts/check-entrypoints.sh` (part of `./test.sh`).

# ADR-021: Ecology integration, tick order, stabilising mechanisms, default balancing (TASK-018)

Status: Accepted (PLAN TASK-018 cycle 1; numbers refined in IMPLEMENT and recorded in docs/ECOLOGY.md)

## Context
All parts (climate, plant growth/reproduction, herbivore feeding, hunting, animal mating, species) exist,
but with the defaults the food chain does not work (measured in PLAN, 64×48, 400/120/20, seeds 1,2):
- Carnivores kill ~115 of 120 herbivores by t≈115; herbivores have 0 births; carnivores starve by t≈250.
- Without carnivores, herbivores still have **0 births** and **plants go extinct by t≈550**: plants in crowded cells
  get a fair share of soil regen `0.5·moisture` (< upkeep 0.2–0.25 each), so they live on stored energy;
  herbivores take that energy down to `(1−aggression)·0.25·max_energy` (2.5 for founders), the plants starve
  (DeathCause::Starvation, not Grazed) and never reach `reproduction_threshold` 12 → no seeds → extinction.
- More productive plants alone (regen 1.0–1.5, upkeep 0.1) only turn this into boom–bust: herbivores overshoot,
  eat every plant to the aggression-dependent reserve, plants go extinct at t≈550–1030.

## Decision 1: tick order (unchanged ADR-008 `Phase::ORDER`, now documented as the ecology order)
1. **Climate** – season + weather of tick t (core RNG when weather is enabled).
2. **Resources** – soil regeneration up to the cap.
3. **Plants** – growth/upkeep/climate stress (flags climate/starvation deaths), then plant reproduction (seed births requested).
4. **Herbivores** – shuffled turns: metabolism, flee/court/rest/feed (grazing), starvation flag; then the herbivore mating pass (birth requests).
5. **Carnivores** – shuffled turns: metabolism, handling/court/rest/hunt (predation kill flags), starvation flag; then carnivore mating pass.
6. **Births** – all birth requests resolved in request order (dropped if a parent is flagged dead, ADR-011), species classified (ADR-020).
7. **Deaths** – aging, natural deaths (old age, 0 energy/health), removal of everything flagged; totals updated.
8. **Species** – species appeared/extinct events from the registry journal.
9. **Statistics** – new: per-tick counts/births/deaths snapshot (`World::stats`/`Simulation::tick_stats`) and the
   population-balance invariant check data.
"Reproduction" in the acceptance list = plant reproduction (in Plants) + mating passes (in the animal phases) + Births;
"deaths" = flags during the acting phases + the Deaths phase. Rationale: plants grow before they are eaten, prey move
before predators, and every same-tick conflict is handled by the existing ADR-011 same-tick rule. Changing the order
would break all existing exact-RNG tests for no gain.

## Decision 2: stabilising mechanisms (all local, all organisms, all population sizes)
1. **Protected plant reserve (new, primary).** A herbivore bite can only take energy above
   `herbivores.graze_reserve · max_energy_P` (new key, default ≈0.35); the reserve no longer depends on
   herbivore aggression (aggression keeps its satiety role). Biology: the root/meristem reserve of grazed plants.
   It is not a population rule (it is the same for every plant/herbivore pair at all times). Effect measured in PLAN with
   a temporary patch: plants + herbivores coexisted 5,000 ticks on seeds 1,2 (plants 300–4,500, herbivores 300–1,100,
   ~3,500 herbivore births); without it plants went extinct in every run. A reserve of 0.5 starved all herbivores
   (crowded plants rarely exceed 10 energy). Decision: keep `GRAZE_RESERVE` code constant only as a fallback doc; the
   implementer replaces the formula `reserve = graze_reserve · max_P` and updates ADR-017 accordingly.
2. **Cell resources regenerating to a cap + density-dependent plant growth** (existing, ADR-014) – plant self-limitation.
3. **Satiation** of herbivores and carnivores (existing) and **handling time** after a kill (existing; longer default).
4. **Prey cover** in plant-dense cells (existing `hunting.cover_protection`, raised) and **prey caution/flight** (existing genes).
5. **Hunting success depends on finding prey** (vision radius, reach 1): sparse prey ⇒ fewer kills (existing).
6. **Climate zones** (existing): thermal metabolism cost makes poles/deserts poor for animals, plants survive there.
Rejected: any count-based rule, immigration, plant respawn (forbidden by PROJECT.md); seed bank (more code, same purpose
as the reserve); grazing-immune seedlings (does not prevent extinction once adults are eaten).

## Decision 3: default balancing (starting point, refined by the IMPLEMENT sweep)
Measured PLAN candidates (`f2`/`f3` = file contents in plan-cycle1.md):
- plants: resource_regen 1.0, resource_cap 15, upkeep 0.1, growth_rate 1.5, initial_energy 4, reproduction_threshold 8,
  reproduction_cost 4, max_per_cell 2.
- herbivores: base_metabolism 0.3, max_meal 2, move_cost 0.1, initial_energy 60, maturity_age 60, reproduction_threshold 70,
  mating_cooldown 40, max_litter 3, max_per_cell 2, graze_reserve 0.35 (new).
- carnivores/hunting: between f2 (base_success 0.10, handling 20, cover 0.6, carn metabolism 0.3, litter 1, cooldown 120 →
  carnivores starve at t≈1,250–1,380, plants+herbivores coexist 5,000 ticks on seeds 1–3) and f3 (base_success 0.25,
  handling 15, cover 0.5, metabolism 0.25, litter 2, cooldown 80 → herbivores eaten out by t≈330, carnivores dead t≈680).
  The implementer sweeps base_success ∈ {0.12..0.2}, handling_time, carnivores.max_per_cell/cooldown and picks the setting
  with the longest median three-kind coexistence over seeds 1–5 at 10,000 ticks; full coexistence is not required (TASK-027).
Performance: plants reach ~4,000–4,800 alive with these values; 2 seeds × 5,000 ticks took 27 s (≈370 ticks/s), within the
contract's 300 s per 10,000-tick run. If plants exceed ~5,000 alive, lower plants.max_per_cell / growth.

## Consequences
- Every existing test that fixes default-parameter behaviour must be checked; most tests set their own parameters.
  docs/CONFIG.md table must be regenerated (`./evosim config schema`), presets reviewed (plants-only/lush/harsh).
- New key changes the RNG-free bite formula only; determinism unaffected.


## Implementation result (IMPLEMENT cycle 1)
Chosen carnivore/hunting values: base_success 0.12, handling_time 15, cover_protection 0.6, carnivores base_metabolism 0.3, move_cost 0.15, max_litter 1, mating_cooldown 120 (other values as Decision 3). Sweep table and the recorded 10,000-tick × 5-seed report: docs/ECOLOGY.md. Mechanics unit tests that assert old default numbers pin the pre-TASK-018 values via test-only `Config::pre_task018()`.

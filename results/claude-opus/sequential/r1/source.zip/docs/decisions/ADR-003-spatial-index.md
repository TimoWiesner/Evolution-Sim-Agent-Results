# ADR-003: Neighbour search on the wrapping grid

## Status
Accepted — 2026-11-22 — TASK-001.

## Context
The world is a finite W×H grid that wraps left/right and top/bottom (torus). Animals move cell-to-cell (8-neighbourhood) and perceive food, mates, predators and prey within a small perception radius; plants disperse seeds and compete locally. Every perception and spatial lookup must be wrap-aware, deterministic, free of duplicates (also for radius ≥ world size and degenerate worlds like 1×1 or 1×N), and fast enough for ≥100 ticks/s at 2,000 entities.

## Alternatives considered
### A. Brute force (scan all organisms per query)
- Pros: trivially correct, no data structure to maintain.
- Cons: O(N) per query, O(N²) per tick ≈ 4 M distance checks per tick at 2,000 entities (400 M/s at 100 ticks/s) — too slow. **Kept as test oracle.**

### B. Coarse spatial hash (bucket size B > 1 cells)
- Pros: fewer buckets, less memory for huge worlds.
- Cons: needs an extra exact distance filter; wrap handling is awkward when W or H is not a multiple of B; no real gain on integer grids of the target size (≤ a few hundred cells per side).

### C. k-d tree / quadtree
- Pros: good for continuous space and very uneven density.
- Cons: the torus needs ghost copies or multiple queries per seam; rebuild or rebalancing every tick as animals move; deterministic tie order requires extra care; no advantage when positions are already integer cells.

### D. Per-cell bucket index (uniform grid, cell size 1) with torus-aware ring scan (chosen)
- Pros: O(1) cell lookup, natural fit to cell-to-cell movement and to "what is in my own cell" mechanics; cheap incremental updates.
- Cons: query cost grows with (2r+1)², so perception radii must stay small; memory O(W·H).

## Decision
`SpatialIndex { width, height, cells: Vec<Vec<EntityId>> }` (one per organism kind, or one index with kind filter — chosen in TASK-010). Each bucket is kept **sorted ascending by `EntityId`** (insert/remove via binary search) so iteration order is deterministic. The index is updated incrementally on spawn, death and every move; a full rebuild (counting sort into CSR layout) may replace incremental updates if profiling in TASK-026 shows it is faster.

Metric: **toroidal Chebyshev distance**, matching 8-neighbour moves: `dx = min(|x1−x2|, W−|x1−x2|)`, `dy` likewise, `d = max(dx, dy)`. Query `within(center, r, filter)` scans `dy ∈ [−r, r]`, `dx ∈ [−r, r]` with wrapped coordinates, but the spans are clamped to **distinct cells**: if `2r+1 ≥ W` every column is visited exactly once (same for rows), so there are no duplicate results for large radii or tiny worlds. Results are ordered deterministically by (distance, EntityId). `nearest(center, r, filter, predicate)` scans rings 0..r and stops at the first ring with a match (ties by EntityId).

## Rationale
### Performance
Query cost O((2r+1)² + k); with perception radius ≤ ~6 this is ≤169 bucket visits, usually most of them empty and cache-resident. Updates are O(log m) in bucket size m (typically 0–3). Memory O(W·H + N); a 200×200 world needs 40,000 small vectors. Expected cost at 2,000 entities is well under 1 ms per tick.

### Testability
Randomised comparison against the brute-force oracle (≥1,000 queries, including worlds 1×1, 1×N, N×1 and radii larger than the world), property tests for "no duplicates", "every result within r", "removed entities never returned", and timing comparison brute force vs index at 2,000 organisms recorded in docs (TASK-010).

### Self-contained dist/
Pure Rust standard library; no external crate, nothing to ship.

## Consequences
- Perception-radius genes are capped (e.g. ≤ 8) so query cost stays bounded.
- All movement code must go through index-updating helpers; a debug assertion / test checks index consistency with organism positions.
- Toroidal distance helpers live in the `topology` module and are shared by climate, spatial and behaviour code.

## Verification strategy
TASK-004 (topology unit and property tests), TASK-010 (oracle comparison, edge worlds, deletion tests, timing table).

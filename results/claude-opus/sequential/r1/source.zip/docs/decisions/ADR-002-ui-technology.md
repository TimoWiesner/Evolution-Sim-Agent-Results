# ADR-002: UI technology

## Status
Accepted — 2026-11-22 — TASK-001.

## Context
The UI must show a climate-coloured map, distinguish entities, support pan/zoom, run/pause/reset/step, adjustable speed, entity inspection, parameter editing, presets, config import/export, seed control, save/load and charts (`docs/PROJECT.md`). It must use the **same engine** as headless mode. `evosim ui --smoke-test` (≤60 s) and `evosim ui --screenshots DIR` (≤120 s, `DIR/main.png` ≥1280×720 from the real interface) must run without user input in the container, which provides `chromium` (headless, v131) and `xvfb-run`. Only `./evosim` must support screenshots; `dist/evosim` need not.

## Alternatives considered
### A. Native desktop UI with `egui`/`eframe` (Rust)
- Pros: same language and binary; immediate-mode UI is quick to build; no browser.
- Cons: needs OpenGL/mesa (software GL under `xvfb-run`), possibly extra apt packages; screenshot capture of the real window needs extra code (`ViewportCommand::Screenshot` or X11 grabbing); styling and charts are more limited; adds large native GUI dependencies to the binary (affects `dist/` portability to systems without X/GL libs).

### B. Electron or Tauri
- Pros: rich HTML UI, desktop feel.
- Cons: Electron needs Node packaging and ~150 MB runtime; Tauri needs `webkit2gtk` apt packages at build and run time; heavy dependency trees; a second process model to bridge to the Rust core.

### C. Python Tkinter front-end
- Pros: available almost everywhere.
- Cons: second runtime, IPC to the Rust core, weak visuals and slow canvas for thousands of objects.

### D. Node server + React/Vite front-end
- Pros: modern component UI.
- Cons: npm build step and a Node runtime at UI time; the engine would live in a different process/language than the CLI unless bridged.

### E. Local browser UI served by the Rust binary (chosen)
- Pros: one binary owns engine and HTTP server; front-end is static HTML/CSS/vanilla JS with Canvas 2D (no npm build); the container's headless chromium renders the real page for smoke test and screenshots.
- Cons: user needs a browser; HTTP polling/streaming adds a small protocol layer.

## Decision
`evosim ui` starts an HTTP server on `127.0.0.1:<port>` (std threads + `tiny_http`) inside the same binary; the server owns one `evosim_core::Simulation` and runs it in a background loop at the selected speed. Static assets (`crates/evosim-ui/web/index.html`, `app.js`, `style.css`) are embedded in the binary. The browser fetches compact frames (JSON metadata + typed arrays for cells/organisms) and sends commands (run, pause, step, reset, speed, inspect, edit config, preset, import/export, save/load). Commands are queued and applied **between ticks** only (ADR-005).

Automation: `--smoke-test` / `--screenshots DIR` start the server on a free port, then spawn chromium (`$CHROME_BIN`, `$PUPPETEER_EXECUTABLE_PATH`, fallback `chromium`) headless on a URL with an autotest flag (`?autotest=smoke` / `?autotest=shots&view=main|charts|inspector`) and `--window-size=1440,900`, using `--screenshot` with `--virtual-time-budget`, or a CDP driver over `--remote-debugging-port` implemented in Rust if timing proves flaky (decided in TASK-023). The page reports ticks advanced / frames rendered back to the server; the server verifies ≥10 (smoke) or ≥100 (screenshots) ticks and ≥1 frame, shuts down and exits 0, with hard timeouts below the contract limits.

## Rationale
### Performance
Simulation runs natively on the server side; frames are sent only at UI refresh rate (≤30 fps) and decoupled from tick rate. The climate/cell layer is drawn from a cached `ImageData` and only re-rendered when it changes; 1,000–5,000 organisms are cheap to draw on Canvas 2D.

### Testability
The HTTP/JSON API is testable from Rust integration tests without a browser (start server on ephemeral port, issue requests). The smoke test is itself an automated end-to-end test through real chromium. Engine logic stays in `evosim-core` and is tested headless.

### Self-contained dist/
Assets are compiled into the binary, so `dist/evosim` remains a single file; no Node, Python or GUI libraries are required to run it. `dist/evosim ui` works wherever a browser is available; screenshot/smoke automation is only required for `./evosim`, where the container chromium exists.

## Consequences
- A small, versioned JSON frame/command protocol must be maintained between `evosim-ui` (Rust) and `app.js`.
- Front-end is hand-written vanilla JS (no bundler); charts are drawn with Canvas as well.
- The UI never mutates engine state directly; it goes through the command queue.

## Verification strategy
- TASK-023: `./evosim ui --smoke-test` exits 0 < 60 s; `./evosim ui --screenshots /tmp/shots` writes `main.png` ≥1280×720.
- TASK-024/025: Rust integration tests of the API endpoints (step, reset, inspect, save/load).

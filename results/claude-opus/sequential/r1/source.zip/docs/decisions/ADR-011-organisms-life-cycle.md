# ADR-011: Organisms, trait ranges, storage and the shared life cycle

## Status
Accepted — 2026-11-22 — TASK-008 (plan). Builds on ADR-005 (EntityId order, order-preserving removal) and ADR-008 (phase order, Births before Deaths).

## Context
TASK-008 defines what an organism is and the rules of being born, living and dying shared by plants, herbivores and carnivores: unique never-reused IDs, kind, position, age, energy, health, traits, parent IDs, generation; traits incl. speed, strength, fertility, max lifespan/health and an animal behavioural tendency; energy/health always in range; dead organisms removed, never acting again, cause recorded; births/deaths counted per kind since tick 0; one documented rule for births and deaths in the same tick. Genomes (TASK-009), feeding/movement/reproduction behaviour (TASK-011..016) are out of scope; their tasks plug into the API defined here. Must stay cheap at 5 000 organisms and deterministic.

## Alternatives considered
### Storage
- **A. One `Vec<Organism>` for all kinds, sorted by `EntityId`** — one place, but every acting phase has to filter by kind; kind counts need a scan.
- **B. Generational arena / slot map (index + generation)** — O(1) lookup, but slot reuse makes iteration order depend on history and conflicts with "IDs never reused" unless a second ID is kept; harder to hash canonically.
- **C. Three `Vec<Organism>` (one per kind), each sorted by ascending `EntityId`, dead flagged and compacted with `retain` in the Deaths phase (chosen)** — matches ADR-005/008 exactly; acting phases iterate one Vec; lookup by binary search O(log n) (IDs ascending because newborns get larger IDs and are appended); canonical order for snapshot/hash for free.
- **D. Struct-of-arrays per field** — best cache use for hot loops, but awkward API and premature; can replace C internally later (TASK-026) behind the same API.

### Same-tick births and deaths
- **A. Immediate removal at death, immediate insertion at birth** — mid-phase Vec mutation invalidates acting orders and indices; order effects become hard to reason about.
- **B. Deferred births and deaths (chosen)** — births are *requested* during acting phases and *resolved* in the Births phase; deaths are *flagged* at once (organism becomes invisible/inactive immediately) and *removed* in the Deaths phase. One rule, below.

### Trait representation
- **A. Free map name → f64** — flexible, but unchecked names, slow, non-canonical.
- **B. Plain struct of named `f64`/`u32` fields with a per-kind range table and a clamping constructor (chosen)** — typed, fast, every value provably in range; TASK-009 maps genes onto these ranges.

## Decision
**Kinds.** `Kind { Plant, Herbivore, Carnivore }`, `Kind::ALL` in this order (= processing order of Births/Deaths and founder creation), `index()` 0..2, `name()` `"plants"|"herbivores"|"carnivores"` (contract keys), `is_animal()`.

**Organism fields.** `id: EntityId` (from `IdAllocator`, never reused), `kind`, `pos: Cell`, `age: u32` (ticks survived), `energy: f64` ∈ [0, traits.max_energy], `health: f64` ∈ [0, traits.max_health], `traits: Traits`, `parents: Parents` (`None` = founder, `One(id)` = asexual, `Two(a, b)` = sexual, stored as given), `generation: u32` (founders 0, child = 1 + max parent generation), `birth_tick: u64`, plus private `alive: bool`. Energy/health/alive are private; mutators clamp: `add_energy(x) -> gained`, `spend_energy(x) -> spent`, `set_energy`, `damage(x) -> lost`, `heal(x) -> healed`, `set_health`. Non-finite or negative amounts are treated as 0 (silently; implementation note TASK-008: no debug_assert, so property tests with NaN/negative inputs also run in debug builds). Energy reaching 0 or health reaching 0 does not remove the organism by itself: the end-of-tick sweep does (or the caller kills with a specific cause).

**Traits and ranges** (`organism::traits`, `Traits::clamped(kind, raw)` clamps every field into the kind's range, non-finite → range low end):

| Trait | Unit | Plant | Herbivore | Carnivore | Founder default (until TASK-009) |
|---|---|---|---|---|---|
| `speed` | cells/tick | [0, 0] (sessile) | [0, 16] | [0, 16] | 0 / `max_speed`/2 of the kind config |
| `strength` | relative | [0, 1] (toughness against grazing) | [0, 1] | [0, 1] | 0.5 |
| `fertility` | relative | [0, 1] | [0, 1] | [0, 1] | 0.5 |
| `max_health` | health points | [1, 1000] | [1, 1000] | [1, 1000] | 10 / 100 / 120 |
| `max_lifespan` | ticks (`u32`) | [1, 10 000 000] | same | same | `<kind>.max_age` |
| `max_energy` | energy | [0.1, 1e6] | same | same | `<kind>.max_energy` |
| `vision` | cells | [0, 0] | [0, 64] | [0, 64] | 0 / `max_vision` |
| `aggression` | relative | [0, 0] | [0, 1] | [0, 1] | 0 / 0.5 |
| `caution` | relative (risk aversion) | [0, 0] | [0, 1] | [0, 1] | 0 / 0.5 |

Animals have two behavioural tendencies (aggression, caution); plants have them fixed at 0. Later tasks may add traits (one field + one range row + test update).

**Storage.** `Population { by_kind: [Vec<Organism>; 3], pending: Vec<BirthRequest>, totals: LifeTotals, tick_deaths: Vec<DeathRecord>, tick_births: Vec<BirthRecord> }` owned by `World` (`World::organisms()`, `organisms_mut()`; `Simulation::organisms()`, `totals()`). Each Vec is sorted by ascending `EntityId`; lookup `get(id)`/`get_mut(id)` by binary search over the three Vecs, `get_alive`/`get_alive_mut` return `None` for flagged-dead organisms; `alive_ids(kind)` feeds `acting_order`; `count_alive(kind)`.

**Founders.** `Simulation::new` creates `initial.plants`, then `initial.herbivores`, then `initial.carnivores` organisms (IDs 1..=N ascending in that order) at uniform random cells drawn from a separate generator `Rng::seed_from_u64(seed ^ FOUNDER_SEED_TAG)` (`0x0F0B_DE25_0000_0008`), so the core RNG stream is unchanged. Founders: age 0, generation 0, `Parents::None`, `birth_tick` 0, energy = `<kind>.initial_energy` clamped to `max_energy`, health = `max_health`. Founders are *not* births. Cell capacity is not enforced for founders (TASK-011/012/013 may refine placement).

**Death.** `Population::kill(id, cause, tick) -> bool` flags a living organism dead (returns false if absent or already dead — first cause wins, never double-counted), increments `totals.deaths[kind]` and `totals.deaths_by_cause[kind][cause]`, and appends a `DeathRecord { id, kind, cause, tick, age, pos, generation }`. `DeathCause` (`#[non_exhaustive]`): `OldAge`, `Starvation`, `Injury`, `Predation`, `Grazed`, `Climate`. A flagged organism is skipped by every query and acting loop (acting loops must re-check `get_alive` before each actor acts) and is physically removed (order-preserving `retain`) at the end of the Deaths phase of the same tick; its ID is never handed out again.

**Shared end-of-tick sweep (Deaths phase)**, ascending kind then ascending ID, over living organisms: (1) aging: `age += 1` unless the organism was born in this tick's Births phase; (2) natural death, first match wins: health = 0 → `Injury`, energy = 0 → `Starvation`, age ≥ `max_lifespan` → `OldAge`; (3) emit one `EventKind::Death` per record of the tick in flag order; (4) remove all flagged organisms.

**Births.** Behaviour tasks call `Population::request_birth(BirthRequest { kind, pos, parents, energy, health: Option<f64>, traits })` (traits clamped on resolve). The Births phase resolves requests in request order: allocate ID, `generation = 1 + max(parent generations)`, age 0, `birth_tick = t`, append, `totals.births[kind] += 1`, emit `EventKind::Birth`.

**THE same-tick rule.** *Within tick t, all births are resolved in the Births phase before the Deaths phase removes anything. A birth request is honoured only if every parent is still alive (not flagged dead) when the Births phase resolves it; otherwise it is dropped without allocating an ID or counting a birth (its energy, already paid by the parent, is lost). A parent that dies in the Deaths phase of tick t (old age, starvation, injury) therefore still has its tick-t children. A newborn exists from the Births phase on, does not act and does not age in tick t, but is subject to the natural-death checks of tick t's Deaths phase; if it dies there it counts as one birth and one death of tick t. Deaths are counted when flagged, births when resolved, so after every tick (and between phases) `initial + births − deaths = living` per kind.*

**Totals.** `LifeTotals { initial: [u64; 3], births: [u64; 3], deaths: [u64; 3], deaths_by_cause: [[u64; DeathCause::COUNT]; 3] }`, cumulative since tick 0 (TASK-022 restores them from checkpoints).

## Rationale
### Performance
Per tick O(n) sweep + O(n) compaction; lookups O(log n) (~12 steps at 5 000). Organism ≈ 120 bytes → < 1 MB at 5 000. No allocation per tick beyond reused record buffers.
### Testability
All invariants are local and checked by property tests (random op sequences on `Population`) and by scheduler-hook tests on `Simulation` (`step_with` injects kills and birth requests in any phase), so the same-tick rule is tested before any behaviour exists.
### Self-contained dist/
Pure Rust, std only, no new crates.

## Consequences
- TASK-009 builds `Traits` from the genome via `Traits::clamped`; genome is stored on `Organism` then.
- TASK-010 spatial index must be updated on spawn/kill/move; `kill` flagging hides the organism immediately, the index entry may be removed at flag time.
- TASK-011..016 act via `get_alive_mut`, `kill(cause)`, `request_birth`; reproduction tasks deduct parent energy themselves.
- TASK-018/019 use `totals()` and `count_alive` for result JSON (`initial + births − deaths = final`).
- TASK-022 serialises `Population` incl. totals; `Simulation::set_population` restores it.

## Verification strategy
TASK-008 tests in `organism/tests.rs` and `sim/tests.rs` (see tasks/TASK-008/handoffs/plan-cycle1.md); later tasks keep the invariant test `living = initial + births − deaths` green.

# ADR-017: Herbivore feeding, metabolism, climate cost and gene-driven decisions

Status: Accepted (TASK-014 PLAN cycle 1)

## Context
TASK-014 must make herbivores live off plants: find plants within vision, eat only plants in their own or an adjacent cell, eat a limited amount per tick that is removed from the plant (which can die of it) and gained at most 1:1, pay energy every tick and die at 0, pay a climate consequence, and let behavioural genes change decisions. Owed decisions: the decision rule and the feeding reach. Hunting (TASK-015) and reproduction (TASK-016) are out of scope.

Existing facts: ADR-016 gives `perceive`/`Population::nearest`, `steps_allowed` (stride), `move_towards(.., stop_at)`, `move_away`, `wander` (each call numbers its steps from 1, so **one move call per actor per tick**), `has_room`. Keys already present: `herbivores.base_metabolism` (0.5), `herbivores.max_meal` (5.0). Animal genes `aggression`, `caution` (expressed 1:1 into `Traits::{aggression,caution} ∈ [0,1]`, founder 0.5) are not used yet; `temp_optimum = −20+60g` (founder 10 °C), `temp_tolerance = 2+28g` (founder 16 °C). `DeathCause::{Starvation, Grazed}` exist. Current cell climate is `World::now` (`CellNow{temperature, precipitation}`, row-major).

## Decision

### Feeding reach (owed decision)
**Reach = 1**: a herbivore may bite only a living plant at toroidal Chebyshev distance ≤ 1 from its cell **at the moment of biting** (own cell + 8 neighbours, across edges). Plants further away are only seen (vision) and approached. At most **one bite (one plant) per herbivore per tick**. Rationale: the maximum allowed by the task, so herbivores need not crowd into the plant's cell (cell capacity 4) and grazing spreads over neighbouring cells.

### Bite (amount eaten per tick)
For herbivore H (energy `E`, `Emax = traits.max_energy`, aggression `a`) and plant P (energy `e_P`, `max_energy_P`, strength `s_P`):
- `cap = max_meal · (1 − PLANT_TOUGHNESS · s_P)`, `PLANT_TOUGHNESS = 0.5` (plant strength already costs upkeep, ADR-014; now it also protects against grazing).
- `reserve = (1 − a) · GRAZE_RESERVE · max_energy_P`, `GRAZE_RESERVE = 0.25` (partial bite: a restrained grazer leaves part of the plant to regrow; a fully greedy one, `a = 1`, strips it).
- `edible = max(0, e_P − reserve)`.
- Satiation level `satiety = (SATIETY_BASE + (1 − SATIETY_BASE)·a) · Emax`, `SATIETY_BASE = 0.6`; `need = max(0, satiety − E) / assimilation` (0 if `assimilation = 0`).
- `bite = min(cap, edible, need)` (≤ `max_meal`). The plant loses exactly `bite` (`spend_energy`); the herbivore gains `add_energy(assimilation · bite)` ≤ bite. New key `herbivores.assimilation` (default 0.8, range [0,1]); the rest is lost as heat (energy pyramid).
- If the plant's energy is ≤ `1e-9` after the bite it is killed immediately with `DeathCause::Grazed` (`Population::kill`; removed in the Deaths phase).

### Metabolism, climate cost, starvation
Every living herbivore, every tick, at the start of its turn pays
`metabolic_cost = base_metabolism · (1 + climate_cost · s_T) · (1 + GENERALIST_METABOLISM · clamp((tol − 2)/28, 0, 1))`
with thermal stress `s_T = clamp(|T − opt| / tol − 1, 0, CLIMATE_STRESS_MAX = 2)` from the herbivore's current cell temperature `T` (`World::now`), `opt = traits.temp_optimum`, `tol = traits.temp_tolerance`; `GENERALIST_METABOLISM = 0.2`. New key `herbivores.climate_cost` (default 1.0, range [0,100]). Consequence: outside its tolerance (extreme cold or heat) a herbivore burns up to `1 + 2·climate_cost` times the base energy; a wide tolerance is not free. Movement cost (ADR-016) comes on top.
**Starvation**: if a herbivore's energy is ≤ 0 at the end of its turn (after metabolism, movement and eating) it is killed immediately with `DeathCause::Starvation` (so a starved herbivore never acts again or is seen by carnivores later in the tick). The Deaths-phase energy-0 check stays as a backstop.

### Decision rule (owed decision)
Per herbivore turn (acting order = ADR-008 shuffle): stride update → metabolism → decide → (at most one move call) → (at most one bite) → starvation check. With hunger `h = 1 − E/Emax`, caution `c`, aggression `a`, vision radius `r`:
1. **Danger vs food** — nearest visible carnivore at distance `d` (by (distance,id)): `danger = 1 − d/(r+1)`. **Flee** iff `c · danger > (1 − c) · h`: `move_away(carnivore cell, allowed)`, no bite this tick. (Cautious animals flee early; starving ones ignore danger; `c = 0` never flees.) Carnivores do not attack yet (TASK-015) — this is behaviour only.
2. **Sated** — if `E ≥ satiety`: rest (no move, no bite).
3. **Forage** — `best_here` = plant within reach maximising `bite` (ties: distance, id). If `bite(best_here) ≥ GOOD_ENOUGH · min(max_meal, need)` (`GOOD_ENOUGH = 0.5`): bite it, no move. Otherwise look for the visible plant at distance ≥ 2 maximising `bite / (1 + d)` with `bite ≥ GOOD_ENOUGH · min(max_meal, need)` (ties: distance, id) → `move_towards(cell, allowed, stop_at = 1)`; else, if `best_here` has `bite > 0`, bite it without moving; else `wander`. After a move, the best plant within reach of the **new** cell is bitten if its `bite > 0`.
Genes therefore change: flight vs feeding (caution), how full an animal eats and how much of a plant it leaves (aggression), what it sees and how far it goes (vision, speed, ADR-016), and its climate cost (temperature genes). Depleted cells are left because a poor `best_here` triggers a move to a better visible patch.

### Carnivores
Unchanged TASK-013 default policy (no metabolism, no eating) until TASK-015; the shared `act_animals` is split into `act_herbivores` (this ADR) and the existing carnivore policy.

### Accounting / RNG
Per-tick `FeedTick { eaters, bites, taken, gained, metabolism, starved, grazed_dead, fled, rested, max_bite_distance }` stored in `World` (last + cumulative `HerbivoreLedger`). `gained ≤ taken` always. RNG draws unchanged in kind (shuffle + wander); runs with herbivores get a new stream versus TASK-013, runs without animals are unchanged.

## Alternatives rejected
- Reach 0 (own cell only): forces crowding into plant cells against the capacity of 4.
- Eating every plant in reach per tick: makes the per-tick limit per plant instead of per herbivore.
- A new gene for appetite/restraint: would change gene layout v1 and every genome length; `aggression` (boldness/greed) and `caution` (risk aversion) already exist and are unused.
- Climate damage to health: energy cost is simpler, observable in energy audits and couples climate to food demand.
- Assimilation = 1: allowed by the key, but default 0.8 keeps the trophic pyramid plausible.

## Implementation notes (TASK-014 IMPLEMENT cycle 1)
- A herbivore whose energy or health is already ≤ 0 at the start of its turn (set outside the phase) does not act; the Deaths sweep removes it with the ADR-011 precedence (Injury before Starvation). Only animals that run out during their own turn are killed immediately with Starvation.
- `World::act_animals` gained a `tick` argument; `World::last_feed()` returns the last `FeedTick`.


## Note (TASK-018)
The grazing reserve `(1−aggression)·GRAZE_RESERVE·max_P` is superseded by ADR-021: reserve = `herbivores.graze_reserve · max_P` (default 0.35), independent of aggression; aggression only affects satiety.

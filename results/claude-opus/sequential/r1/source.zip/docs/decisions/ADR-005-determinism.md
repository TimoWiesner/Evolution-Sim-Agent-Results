# ADR-005: Determinism — random numbers, processing order and what to avoid

## Status
Accepted — 2026-11-22 — TASK-001.

## Context
`docs/CONTRACT.md` §5.1/5.2 requires: same configuration, seed and ticks ⇒ identical `final`, `totals`, `series` and `state_hash`; different seeds ⇒ different hashes; save after A ticks + load + B ticks ⇒ identical to A+B uninterrupted. The UI and headless mode share the engine, so UI interaction must not break determinism of the engine itself.

## Alternatives considered
### A. `rand` crate (`StdRng` / `SmallRng`)
- Pros: well-tested, convenient distributions.
- Cons: `StdRng`'s algorithm is explicitly not stable across `rand` versions; distribution sampling algorithms may change too; serialising the internal state requires extra features. Risk to golden hashes and checkpoints.

### B. Per-organism or per-thread RNG streams
- Pros: enables parallel processing.
- Cons: more state to checkpoint, stream derivation must be careful; parallel application order still needs to be fixed. Unnecessary at the target scale.

### C. Single in-crate xoshiro256** seeded with SplitMix64 (chosen)
- Pros: ~30 lines, fully under our control, fast, 4×u64 state trivially serialisable and hashable; bit-identical across platforms (integer arithmetic only).
- Cons: we must implement and test distributions (uniform float, range, normal via Box–Muller) ourselves.

## Decision
**Source of random numbers.** Exactly one `Rng` in the simulation state: **xoshiro256\*\*** implemented in `evosim-core::rng`, seeded from the config `seed` (or `--seed`) through **SplitMix64** to fill the 4×u64 state. All stochastic decisions in the engine (initial placement, weather noise, mutation, crossover, movement choices, hunting success) draw from it. Its state is saved in checkpoints and included in the state hash. Deterministic sub-streams, if ever needed, are derived via SplitMix64 of (seed, purpose constant) — never from time or thread IDs.

**Order inside a tick (fixed; finalised in TASK-005 by [ADR-008](ADR-008-tick-scheduler.md), which also fixes the per-phase acting-order shuffle).**
1. climate / season / weather update
2. cell resources regenerate
3. plants: growth, ageing, seeding
4. herbivores act (sense, move, eat, mate)
5. carnivores act (sense, move, hunt, mate)
6. reproduction resolution (newborns appended)
7. dead organisms removed (stable, order-preserving compaction)
8. species bookkeeping (extinction ticks)
9. statistics / series sampling; `tick += 1`

**Order of organisms.** Organisms live in `Vec`s sorted by ascending **`EntityId`**; IDs come from a monotonically increasing `u64` counter that is never reused. Newborns are appended (keeping order) and act from the next tick. Deaths are flagged during a phase and removed at its end with `retain` (order-preserving). Conflicts (two animals targeting the same prey or cell) are resolved by processing order. If a per-tick shuffle for fairness is introduced (TASK-005 decides), it uses the core RNG and is therefore deterministic. Spatial index buckets are sorted by `EntityId` (ADR-003).

**What must be avoided.**
- Wall-clock time (`Instant`, `SystemTime`) in simulation logic — wall clock is used only by the CLI/UI to measure `elapsed_seconds` / `ticks_per_second` and to pace the UI loop.
- Unseeded or global RNGs (`rand::thread_rng`, `getrandom`, JS `Math.random` for anything that affects the sim).
- Iterating `HashMap`/`HashSet` (std hasher is randomly seeded per process) in anything that affects state or output — use `Vec`, sorted vectors or `BTreeMap`/`BTreeSet`.
- Multithreaded mutation of shared state or parallel floating-point reductions with nondeterministic order; parallelism, if added, only for pure per-item computations whose results are applied in `EntityId` order.
- Compiler flags that change float semantics (no fast-math); float results are reproducible on the same machine and build (contract allows minor inter-platform differences).
- UI threads touching the simulation directly — UI commands are queued and applied between ticks.
- Population-count-dependent rules (also forbidden by `docs/PROJECT.md`).

**State hash and checkpoints.** `state_hash` = SHA-256 (lowercase hex) over a canonical, versioned serialisation of the full state: tick, RNG state, configuration, climate state, all organisms with genomes in `EntityId` order, species registry, ID counters and cumulative totals. Floats enter via `to_bits()`. Checkpoints use the same serialisation (serde JSON with `float_roundtrip`), so load→continue reproduces an uninterrupted run exactly.

## Rationale
### Performance
xoshiro256** costs ~1 ns per draw; a single sequential pass over sorted `Vec`s is cache-friendly. Avoiding hashing collections in hot paths also helps speed.

### Testability
Determinism tests: two runs same seed ⇒ equal hash; different seeds ⇒ different hash; save/load split equals uninterrupted run; golden RNG output vectors pin the algorithm; regression tests pin `state_hash` for fixed configs (updated deliberately when behaviour changes).

### Self-contained dist/
No external RNG crate; the only hashing dependency (`sha2`) is pure Rust and statically linked into the binary. **Amended by [ADR-022](ADR-022-headless-run-result-hash.md) (TASK-019): SHA-256 is implemented in-crate (`evosim-core::digest`), no `sha2` dependency.**

## Consequences
- Every engine function needing randomness takes `&mut Rng` explicitly; no hidden RNG access.
- Golden-hash regression tests must be updated (and the change documented) whenever simulation rules change.
- Single-threaded engine by default; parallelism is a later, opt-in optimisation that must preserve results.

## Verification strategy
TASK-005 (RNG golden vectors, scheduler order tests), TASK-019 (CLI determinism and different-seed tests), TASK-022 (checkpoint split equivalence), TASK-028 (repeatability across fresh builds).

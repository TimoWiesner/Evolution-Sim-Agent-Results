# ADR-009: Base climate, latitude zones and biomes on the torus

## Status
Accepted — 2026-11-22 — TASK-006 (plan). Builds on ADR-007 (topology) and ADR-005/ADR-008 (determinism). TASK-007 adds seasons/weather on top of this static base field.

## Context
Every cell needs a biome, a base temperature and a base precipitation that follow from its position and resemble Earth's latitude zones (polar, tundra, temperate, dry, tropical). The world is a torus (ADR-007): rows wrap top↔bottom and columns wrap left↔right. A real planet has two distinct poles and an equator; a torus has no edge where a pole could sit. Climate must be continuous across both seams (no neighbour pair across a seam may differ more than neighbour pairs elsewhere), must work for every size down to 1×1, and every random influence must be seeded.

## Alternatives considered
### Mapping latitude onto the wrapping y axis
- **A. Linear latitude: pole at y=0, other pole at y=h-1** — Earth-like map, but the top/bottom seam joins the two poles to each other only if both are cold; with an equator at one end the seam is a hard jump. Rejected: seam discontinuity.
- **B. Mirrored ("folded") latitude, pole band on the seam, equator in the middle row (chosen)** — latitude `φ(y) = 90° · |1 − 2u|`, `u = (y + 0.5)/h`. Rows 0..h/2 are one hemisphere, rows h/2..h the mirror hemisphere; the north and south pole are the *same* band, split by the seam (it appears at the top and bottom edge of a printed map, like an Earth map). The function is periodic in y with period h and symmetric about the seam, so rows `h-1` and `0` have identical base latitude.
- **C. Two equators and two poles (period h/2)** — also continuous, but zones become half as wide and tiny worlds lose zones entirely.
- **D. Latitude from distance to a point / on the x axis too** — not Earth-like (zones become rings or diagonals).

### Shape of the profiles
- Temperature linear in `cos φ` (chosen): `T_lat = T_pole + (T_eq − T_pole) · cos φ`. With defaults (28 °C / −25 °C) this gives ≈21 °C at 30°, ≈12.5 °C at 45°, ≈1.5 °C at 60°, ≈−11 °C at 75°, close to Earth's annual zonal mean. `cos²φ` was rejected: too cold already at 60°.
- Precipitation as sum of Gaussian bands (chosen): wet equator (ITCZ), dry subtropics (~20–30°), a mid-latitude storm-track maximum (~55°), dry poles. Alternative "monotone in temperature" rejected: no desert belt.

### Additional influences
- **None** — perfectly regular stripes; boring and no east-west variation.
- **Elevation field with lapse rate and rain shadow** — realistic, but more parameters and code; deferred (can be added later as another periodic noise field).
- **Seeded periodic value noise anomalies on temperature and precipitation (chosen)** — small, smooth, torus-periodic, cheap.

### Biome classification
- **By latitude band only** — trivially ordered but ignores precipitation and noise.
- **Whittaker-like thresholds on (T, P/P_max) (chosen)** — biome follows from the cell's own base climate; order follows from the monotone profiles.

## Decision
**Latitude.** `u = (y + 0.5) / h`, `φ = 90 · |1 − 2u|` degrees (0 = equator row(s) at y ≈ h/2, 90 = pole at the seam between row h-1 and row 0). x does not enter the latitude.

**Base temperature (°C).** `T = T_pole + (T_eq − T_pole) · cos(φ·π/180) + A_T · nT(x, y)` with `T_pole = climate.pole_temperature`, `T_eq = climate.equator_temperature`, `A_T = climate.noise_temperature` (new, default 1.5, range 0…20).

**Base precipitation (relative units, ≥ 0).** `p_lat(φ) = min(1, 0.10 + 0.90·g(φ, 0, 15) + 0.55·g(φ, 55, 15))`, `g(x, m, s) = exp(−((x−m)/s)²)`; `P = P_max · clamp(p_lat(φ) + A_P · nP(x, y), 0, 1)` with `P_max = climate.max_precipitation`, `A_P = climate.noise_precipitation` (new, default 0.05, range 0…1, relative to `P_max`).

**Noise.** `nT`, `nP` ∈ [−1, 1] are torus-periodic value-noise fields: lattice `gx = max(1, round(w / s))`, `gy = max(1, round(h / s))`, `s = climate.noise_scale` (new integer, default 16, range 1…4096 cells); lattice values `2·next_f64() − 1`, row-major, temperature lattice first then precipitation lattice, from a **dedicated** generator `Rng::seed_from_u64(seed ^ 0xC1A7_E5EE_D000_0006)` (domain-separated; the core simulation RNG stream is not touched, so adding the climate does not shift any other draw). Sample point `fx = (x + 0.5)·gx / w`, `i0 = floor(fx) mod gx`, `i1 = (i0 + 1) mod gx`, `t = smoothstep(fx − floor(fx))` (`3t² − 2t³`), same in y, bilinear blend. Because the index wraps modulo the lattice and the lattice tiles the torus exactly, the field is continuous across both seams. Noise amplitude 0 gives pure stripes.

**Biomes (6, ordered cold → hot; `Ord` follows this order).** With `r = P / P_max` (r = 0 if `P_max = 0`):
| Biome | Rule | Text symbol |
|---|---|---|
| Polar (ice) | T < −10 | `I` |
| Tundra | −10 ≤ T < 0 | `U` |
| Temperate | 0 ≤ T < 18 | `F` |
| Desert (dry) | T ≥ 18 and r < 0.3 | `D` |
| Savanna (dry) | T ≥ 18 and 0.3 ≤ r < 0.6 | `S` |
| Tropical (rainforest) | T ≥ 18 and r ≥ 0.6 | `R` |

Defaults on a 48-row map, pole→equator: `IIII UUUU FFFFFF DDDDD SS RRRRRR` (then mirrored). Presets that raise the pole temperature (`lush`) simply lose the polar band; order is preserved as a subsequence.

**Storage.** `ClimateMap` (row-major `Vec<CellClimate>`, index = `Torus::index`) is computed once in `World::from_config` from `(world size, climate params, seed)` — a pure function of the configuration, so checkpoints need not store it (TASK-022 may still hash it). Time variation (TASK-007) is a separate layer on top of these base values.

**Inspection.** `evosim climate map [--config FILE | --preset NAME] [--seed N] [--format text|json|ppm] [--out FILE]`: text = one symbol per cell + legend + biome counts; json = size, biome legend, row strings, temperature and precipitation grids; ppm = binary P6 image, one pixel per cell in biome colours.

**Implementation note (TASK-006 IMPLEMENT).** Order is checked on 5 zones (`Biome::zone()`: polar, tundra, temperate, dry = desert+savanna, tropical), matching the acceptance criterion. Reason: with `lush` (warm pole, wetter) cells reach 18 °C while still under the storm-track precipitation, giving a savanna fringe poleward of the desert (S D … S R); the 6 ranks are not monotone there, the 5 zones are. With defaults the 6 ranks are monotone too. Latitude is computed as `90·|h − s|/h`, `s = (2y+1) mod 2h` (algebraically equal to the formula above) so mirror rows are bit-identical.

## Rationale
### The topology compromise (user-facing explanation)
A torus cannot have two separate poles and an equator without a seam, so the world folds latitude: going down the map you travel pole → equator → pole, and the bottom pole and the top pole are the same cold band continued across the wrap. Equivalent view: the map shows two mirrored hemispheres glued at the equator in the middle and at the pole at the seam. East-west the climate only changes through small seeded noise that itself wraps. Consequences: there is exactly one polar band and one equatorial band; an organism walking straight south from the equator crosses all zones twice per circuit; climate zones are bands of rows whose width scales with the world height. The seam is mathematically invisible because the latitude formula is periodic and symmetric there (rows h-1 and 0 are mirror images).
### Performance
O(w·h) once at world creation (64×48 ≈ 3 k cells, microseconds). Lookup is an index into a Vec. No per-tick cost in this task.
### Testability
Pure functions of (y, h, params) for the latitude part; noise from a seeded, isolated generator; the seam property is checked exhaustively over many sizes and seeds.
### Self-contained dist/
std + existing serde_json only; no new crates.

## Consequences
- New config keys `climate.noise_temperature`, `climate.noise_precipitation`, `climate.noise_scale` (docs/CONFIG.md regenerated).
- `World` gains `climate()`; TASK-007 reads `CellClimate::{temperature, precipitation}` as the base for seasons/weather; plants/animals (TASK-011+) read biome/temperature/precipitation.
- Very small worlds: h = 1 → one equatorial row (all tropical with defaults); h = 2 → both rows at 45° (temperate). No panic for any size 1…MAX_DIM.

## Verification strategy
TASK-006 tests in `crates/evosim-core/src/climate/tests.rs` (seam, order, sizes, determinism, bounds) and CLI tests for `evosim climate map`; see tasks/TASK-006/handoffs/plan-cycle1.md.

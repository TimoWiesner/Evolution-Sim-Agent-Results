# ADR-028: UI scenario setup (presets, parameter form, JSON import/export) and live charts

## Status
Accepted — 2026-11-23 — TASK-025 (PLAN cycle 1). Extends [ADR-026](ADR-026-ui-server-world-view.md) and [ADR-027](ADR-027-ui-controls-inspector.md) (protocol v1 gains endpoints and a frame-meta key; the 6-byte record layout is unchanged). Uses [ADR-006](ADR-006-configuration.md) (config schema/validation/presets) and [ADR-023](ADR-023-metrics-analytics.md) (metrics recorder).

## Context
TASK-025: start a new world from the UI (preset → edit seed, world size, initial populations and ≥5 further parameters), show invalid input next to the field and refuse to start, export/import the configuration as a JSON file (round trip = same config), live charts (population per kind, births and deaths, species count, mean of ≥1 trait over time), a distribution chart of a selectable trait, axis labels + legends, and display-free tests for config and chart-data logic. "New simulation features" are out of scope.

Facts checked on 2026-11-23: `evosim_core::config::{schema() -> Vec<ParamSpec{key,type_name,default,min,max,doc}>, preset(name), preset_names(), preset_description(name), Config::{from_value, from_json_str, to_json_value, to_json_pretty}}` exist; `Config::from_value` returns only the **first** error (`ConfigError.key` = dotted key, cross-field errors keyed by the field that must be smaller). `metrics::MetricsRecorder::record(&Simulation)` builds a `Sample { tick, kinds: [KindSample; 3] }` with counts, cumulative births/deaths, `species_living`, and `traits: [Option<Stat{mean,sd,min,max}>; 11]` (order `metrics::TRAIT_NAMES`), `metrics::trait_values(&Traits) -> [f64; 11]`, `TraitRanges::for_kind(kind)` give the trait axes. `http::Request` already has `query`. The engine (`control::Engine`) is the single place that advances the sim (`step_tick`).

## Decisions

### 1. Chart drawing: own Canvas 2D code, no library
A small `web/charts.js` (≈300 lines): line chart (multiple series, optional ±sd band, gaps for `null`), bar histogram, "nice" axis ticks, axis titles, legend. Rationale: no network at run time (`./evosim` must work offline; ADR-026 embeds all assets with `include_str!`), no npm dependency or bundler, consistent dark theme, and the geometry helpers are plain functions testable with `node --test`. Rejected: Chart.js/uPlot (vendoring a minified third-party file into the binary, licence/size, harder to test without a DOM).

### 2. Display-free scenario logic in Rust: `crates/evosim-ui/src/scenario.rs`
- `featured_keys() -> &'static [&'static str]`: the parameters shown up front (our decision, see §6).
- `schema_json() -> Value`: every `config::schema()` entry `{key, group, type, default, min, max, doc, featured}`; groups = first key segment (`seed/world/initial` → "World", then climate, plants, herbivores, carnivores, hunting).
- `presets_json() -> Value`: `[{name, description, config, seed_text}]` for `preset_names()`.
- `validate_form(v: &Value) -> Result<Config, Vec<FieldError>>`, `FieldError { key, message }`:
  1. `v` must be an object (else one error with key `"<json>"`).
  2. **Per-field pass, collecting all errors** (so several wrong fields are all marked at once): for each `ParamSpec`, look up the dotted key; missing fixed key → "required"; wrong JSON type (integer must be an integer number, ranges as in ADR-006; `u64` seed accepted up to 2^64−1) → "expected integer/number/boolean/string"; out of range → "must be between MIN and MAX". Optional keys may be absent (default).
  3. If the per-field pass is clean: `Config::from_value(v)` (authoritative; catches unknown keys and cross-field rules); its single error is mapped to `FieldError { key: e.key, message: kind text }`.
  4. Extra UI-only guard (not a contract change): `world.width * world.height <= 1_048_576` cells (else error on `world.width`: "world too large for the UI (max 1,048,576 cells)") so a typo cannot freeze the browser. Documented in README.
- `config_reply(c: &Config) -> Value` = `{config: c.to_json_value(), seed_text: c.seed.to_string()}`.
- Round trip guarantee: `validate_form(&c.to_json_value()) == Ok(c)` for every preset and for randomised edits (test).

### 3. Engine: `Command::NewWorld(Box<Config>)`
`Engine::apply(NewWorld(c))` → `sim = Simulation::new(*c)` (same constructor as `evosim run`), `config = c`, `epoch += 1`, selection cleared, chart history cleared and seeded with the tick-0 sample, `running = true` (user pressed "Start"), speed kept. A failing constructor leaves the old world untouched. Validation happens **before** the command (`validate_form`), so the engine never sees an invalid config. `Reset`/`Load`/`LoadText` also reset the chart history (new epoch).

### 4. Chart history: `crates/evosim-ui/src/charts.rs` (display-free, read-only on the sim)
- `ChartPoint { tick, count: [u64;3], births_total: [u64;3], deaths_total: [u64;3], species: [u64;3], mean: [[Option<f64>;11];3], sd: [[Option<f64>;11];3] }`, built from one `MetricsRecorder::record` sample (reuse; no new statistics code). Recording takes `&Simulation` → cannot change `state_hash` (test compares hashes with/without).
- `ChartHistory { points: Vec<ChartPoint>, stride: u64, version: u64, max_points: usize (=600) }`. `observe(&Simulation)` is called by `Engine::step_tick` after every tick and records when `tick % stride == 0`; when `points.len() > max_points` the history is **decimated** (keep points whose tick is a multiple of `2*stride`, always keep the first point), `stride *= 2`, `version += 1`. So memory and per-request size are bounded for arbitrarily long runs, and cost is one O(N) pass per `stride` ticks. The latest state is always available as an extra "now" point in replies (computed on demand) so charts reach the current tick.
- Births/deaths are stored cumulatively; the reply derives per-interval values from consecutive kept points (`births[i] = total[i] − total[i−1]`, divided by `dt` and scaled to **per 100 ticks**), so decimation never loses or double-counts events. First point = 0.
- `to_json(since: Option<(version, tick)>) -> Value` = `{epoch, version, stride, full: bool, kinds, traits, points: [{t, n:[3], b:[3], d:[3], s:[3], m:[[11]x3], sd:[[11]x3]}]}`; `b`/`d` = interval rates per 100 ticks; if `since.version == version` only points with `t > since.tick` are returned (`full:false`), else everything (`full:true`). Nulls for extinct kinds (gaps, not zeros).
- `histogram(sim, kind, trait_index, bins) -> Value` = `{kind, trait, tick, n, mean, lo, hi, bins:[counts], edges:[bins+1]}`; axis range = `TraitRanges::for_kind(kind)` for that trait (stable axis between updates); if that range is degenerate (min == max) the data min/max ± 0.5 is used; values outside are clamped into the end bins; `bins` clamped to 1..=100 (default 20). Empty population → all-zero bins, `n = 0`, `mean = null`.

### 5. Protocol additions (still `protocol:1`)
- `GET /api/schema` → `scenario::schema_json()`; `GET /api/presets` → `presets_json()`.
- `GET /api/config` → `config_reply(engine.config)` (current world's configuration); `GET /api/config/download` → `to_json_pretty` with `Content-Disposition: attachment; filename="evosim-config-<name>.json"`.
- `POST /api/config/validate` (body = config JSON text) → `200 {ok:true, config, seed_text}` or `400 {ok:false, errors:[{key,message}]}`. Used by Import (and by Start before sending).
- `POST /api/new` (body = config JSON) → validate; errors → `400 {ok:false, errors}` and the engine is untouched (tick/epoch unchanged); ok → `NewWorld`, reply `status_json()` + `config_reply`. Also accepted as `/api/control {"cmd":"new","config":{…}}` for symmetry.
- `GET /api/charts?v=<version>&since=<tick>` → `ChartHistory::to_json` (+ "now" point); `GET /api/histogram?kind=herbivores&trait=speed&bins=20` → `histogram` (400 on unknown kind/trait).
- Frame meta gains `charts_version` (history version) so the page knows when a full refetch is needed. Query strings parsed by a tiny `query_param(query, name)` helper (percent-decoding of `%XX`/`+`).
- Seeds above 2^53: JS numbers lose precision, so every config reply carries `seed_text`, the form keeps the seed as a digit string, and `buildConfigText` writes the seed digits raw into the JSON text (placeholder replacement). Import sends the **file text** to `/api/config/validate` and fills the form from the reply's `config` + `seed_text`. This keeps export → import bit-identical for every u64 seed.

### 6. Editable parameters (our decision)
Required: `seed`, `world.width`, `world.height`, `initial.plants/herbivores/carnivores`. Featured (shown up front, 12): `climate.year_length`, `climate.equator_temperature`, `climate.pole_temperature`, `climate.seasonal_amplitude`, `climate.weather_enabled`, `plants.resource_regen`, `plants.mutation_rate`, `plants.max_age`, `herbivores.mutation_rate`, `herbivores.max_age`, `carnivores.mutation_rate`, `hunting.base_success` — they cover climate, resource supply, evolution speed, life span and predation, the levers an experimenter most likely varies. **All other schema parameters** are editable too in a collapsible "Advanced parameters" section grouped by kind, generated from `/api/schema` (no hand-maintained list can drift from the core). Plus `name` and `description` text fields.

### 7. UI
- **Setup dialog** ("New world…" button in the top bar, key `W`): preset cards (name, one-line description, size + initial counts badge; selected card highlighted) → form (World / Featured / Advanced). Each input has a `<small class="field-error" id="err-<key>">` right below it; client-side `validateField(spec, text)` marks errors on input (red border + message), "Start" is disabled while any client error exists, and server errors from `/api/new` are shown at the same places (server is authoritative). Buttons: Start, Export JSON (client-side Blob download of `buildConfigText(form)`), Import JSON (file input → text → `/api/config/validate` → fill form / show errors), Reset to preset, Cancel. Changing a field marks the card "modified".
- **Charts dock** below the world view (main view): five charts in a grid — Population per kind (lines), Births & deaths per 100 ticks (solid = births, dashed = deaths, per kind), Living species per kind, Trait mean over time (kind + trait selects, mean line + ±1 sd band), Trait distribution now (histogram; kind + trait selects, bins 20, mean marker). Each chart: title, x-axis label "tick" (histogram: trait name), y-axis label, legend. Polls `/api/charts` every 500 ms incrementally and `/api/histogram` every 1 s; redraws on new data and resize. A "Charts" toggle (key `C`) expands the dock to the full main area (larger charts) — used by `charts.png`.
- Pure JS helpers exported for node tests (`web/charts.js`, `web/setup.js`): `niceTicks(min,max,n)`, `extent(series)`, `mergeChartData(state, reply)` (incremental append / full replace by version / reset on epoch), `seriesFor(chartId, data, opts)` (→ `{title, xLabel, yLabel, series:[{name,color,dash,values}]}`), `CHART_SPECS`, `histogramBars(h, w, hgt)`, `linePath(points, scale)`, `parseFieldValue(spec, text)`, `validateField(spec, text)`, `formFromConfig(schema, config, seedText)`, `configFromForm(schema, form)` (→ nested object, omits nothing), `buildConfigText(schema, form)`.

### 8. Screenshots (`./evosim ui --screenshots DIR`)
`main.png` (finished interface: world + charts dock + sidebar, ≥100 ticks so the charts have data), `world-zoomed.png`, `inspector.png` (kept), new `charts.png` (`&view=charts`: expanded dashboard) and `setup.png` (`&setup=1`: dialog open with a preset selected and one deliberately invalid field showing its error message — demonstrates the validation UI). 4 optional extras ≤ contract limit of 5. Optional-shot failure stays a warning. The sim runs unthrottled to ≥300 ticks before shots (instead of 100) so the time-series charts are not trivially short; still well within 120 s (contract example measured 962 ticks/s headless on 2026-11-23: 300 ticks ≈ 0.3 s).

## Alternatives rejected
- Validating only in JS: duplicates ADR-006 rules and drifts; the server (core `Config::from_value`) stays authoritative, JS only gives instant feedback from the same schema ranges.
- Streaming chart samples inside every binary frame: bloats the 30 fps frame; charts need ~2 Hz.
- Recording metrics inside `Simulation`: would touch the hashed state stream (ADR-022/023).
- Storing every tick: unbounded memory on long runs; decimation keeps ≤ 600 points.

## Consequences
- New modules `scenario.rs`, `charts.rs` in `evosim-ui`; new web assets `charts.js`, `setup.js` (embedded, routes `/charts.js`, `/setup.js`); no new crates.
- `Engine` gains `history: ChartHistory`; `step_tick` gains one cheap branch per tick plus one O(N) sample per stride.

## Implementation notes (TASK-025 IMPLEMENT cycle 1)
- `scenario::validate_form` per-field pass: each value is probed by `Config::from_value` on the contract example with only that key replaced, so the per-field messages use exactly the core rules (no duplicated range table); cross-field (`Invalid`) results are left to the final whole-document pass.
- Chart points are built directly (`charts::ChartPoint::of`, using `metrics::{trait_values, Stat}` and `Population::totals()`), not via a throw-away `MetricsRecorder`, to avoid its per-death-cause work on every tick. Births/deaths are cumulative; the server reply gives per-interval rates and the page computes trailing-window rates (`windowRates`, ≥25 ticks) from the cumulative totals so the curves are not spiky at stride 1.
- Population and births/deaths charts use a log10(1+v) y-axis (plants ≈ 3,000 vs carnivores ≈ 20).
- Histogram axis = observed spread of the trait (+5 % padding, at least 2 % of the heritable range) so narrow distributions are visible; the reply also carries the heritable `range`.
- `/api/charts` and `/api/histogram` use `UiSession::read_engine` (lock without publishing a frame).
- Headless chromium (131, old and new headless) paints only `innerHeight` ≈ 813 px of the 900 px PNG; the former page stretch (TASK-023) clipped the chart dock, so it was removed: the UI now fits the painted area and the last ~88 px of each PNG are empty (GAP-023-R1 unchanged in nature).

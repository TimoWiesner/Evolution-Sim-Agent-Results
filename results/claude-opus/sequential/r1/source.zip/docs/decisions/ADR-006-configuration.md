# ADR-006: Configuration format, validation and presets

## Status
Accepted — 2026-11-22 — TASK-003 (plan). Implemented 2026-11-22 (TASK-003 implement cycle 1); deviation: added `evosim config schema` (Markdown table that docs/CONFIG.md embeds, checked by a test).

## Context
`docs/CONTRACT.md` §3 fixes `seed`, `world.{width,height}`, `initial.{plants,herbivores,carnivores}`; a file with only these keys must be valid, so every other parameter needs a default. Invalid configurations (wrong type, missing fixed key, value out of range) must give exit 2 with a message on stderr; TASK-003 additionally requires the message to **name the offending key**. A loaded config written back to JSON and reloaded must compare equal. At least three presets selectable by name. Later tasks (climate, plants, animals, UI) need a place to add parameters cheaply.

## Alternatives considered
### A. `#[derive(Deserialize)]` structs with `#[serde(default, deny_unknown_fields)]`
- Pros: little code.
- Cons: serde_json errors read "invalid type: string \"x\", expected u32 at line 3 column 12" — no key path (needs extra crate `serde_path_to_error`); range validation is a second hand-written pass anyway; no machine-readable list of parameters/ranges for docs and the UI editor.

### B. TOML/YAML as primary format
- Pros: comments, nicer to edit.
- Cons: contract requires JSON; extra crates; optional only.

### C. `serde_json::Value` parse + declarative parameter table (chosen)
- One macro defines, per group, each field's Rust type, default, valid range and doc string. It generates the struct, `Default`, a strict reader (`Value` → struct, with full dotted key paths in errors), a writer (struct → `Value`) and a schema list (`ParamSpec`) used for docs/UI/tests.
- Pros: precise errors naming `plants.max_age`; ranges live next to defaults; schema enables a test that docs list every key and that every default is inside its range; no extra crates beyond `serde_json`.
- Cons: a small macro to maintain.

## Decision
- **Dependency:** `serde_json` with feature `float_roundtrip` in `evosim-core` (exact f64 text round-trip). No derive needed for config.
- **Types:** integers `u32`/`u64` (JSON number must be an integer; `64.0` or `"64"` → wrong type), floats `f64` (any JSON number), `bool`, `String`. Negative integers / too large integers → out of range. `seed` is `u64` (0 … 2^64−1); negative seeds are rejected as out of range (documented).
- **Unknown keys are an error** (`unknown key 'plants.max_agee'`), at every nesting level. Reason: a typo would otherwise silently fall back to a default and change an experiment unnoticed. Exception: none (metadata goes in the defined `name`/`description` keys).
- **Errors:** `ConfigError { key: String, kind: ConfigErrorKind }` with kinds `Parse{line,column,msg}` (key `"<json>"`), `WrongType{expected,found}`, `Missing`, `OutOfRange{value,min,max}`, `UnknownKey`, `Invalid{reason}` (cross-field), `UnknownPreset{name, available}`. `Display`: ``config error: `world.width`: value 0 out of range [1, 4096]``. The first error in deterministic order is returned (fixed keys first, then groups in schema order; unknown-key check per object first).
- **Writing:** `to_json_value()` writes **all** keys (full explicit config), `to_json_pretty()` for files; `from_json_str(to_json_pretty(c)) == c`.
- **Presets:** built into core (`config::presets`), names `default`, `lush`, `harsh`, `plants-only`; `preset(name) -> Result<Config, ConfigError>`, `preset_names()`. `default` equals the contract §3 example loaded with defaults.
- **Optional formats:** none in TASK-003 (TOML may be added later behind the same `Value` reader).

## Rationale
### Performance
Config is parsed once per run; cost irrelevant.
### Testability
Every error kind is reachable with a tiny JSON string; schema allows generic tests (all defaults in range, every key documented, every key's out-of-range and wrong-type value rejected naming that key, randomised round-trip).
### Self-contained dist/
`serde_json` is pure Rust, statically linked into the binary.

## Consequences
- Later tasks add parameters by adding one line to the macro table (type, default, range, doc) and to `docs/CONFIG.md`; the generic tests cover them automatically. Semantics of a parameter belong to the task that uses it; defaults may be retuned (TASK-027).
- Checkpoints (TASK-022) embed the config via `to_json_value()`.
- `Cargo.lock` gains serde_json and its deps; `setup.sh` needs network for the first `cargo build --locked` (allowed by contract).

## Verification strategy
TASK-003 unit tests in `crates/evosim-core/src/config/` and CLI tests for `evosim config validate|show|presets`; TASK-019 maps `ConfigError` to exit 2 for `run`.

# ADR-019: Animal sexual reproduction (TASK-016)

Status: Accepted (PLAN TASK-016 cycle 1)

## Context
Herbivores and carnivores must reproduce sexually: two different living animals of the same kind, close to each other, mature, with enough energy and genetically compatible; never with itself. The child genome is crossover + mutation (ADR-012 `child_sexual`), both parent IDs and the generation are recorded (`Parents::Two`, `resolve_births` computes `1 + max(parent generations)`, ADR-011). Both parents pay energy; afterwards a waiting time applies; the fertility trait matters. Existing pieces: keys `<kind>.{maturity_age, reproduction_threshold, reproduction_cost, mating_threshold, mutation_rate, mutation_strength}`, `Population::{within, nearest, request_birth, has_room, count_at}`, ADR-011 same-tick rule (birth dropped if a parent is flagged dead when the Births phase resolves it), ADR-016 cell-capacity rule (birth into a full cell dropped).

## Alternatives considered
- **Gestation (pregnant parent, birth after G ticks)** — more realistic, but needs a stored embryo genome per organism (snapshot/hash state), a "mother" role, and a rule for the father dying. Rejected for v1.
- **Immediate birth + cooldown (chosen)** — the pair conceives and the litter is requested in the same tick (resolved in the Births phase). A per-animal `cooldown` counter is the waiting time. One small `u32` field, no embryo state.
- **Mate choice by RNG among candidates** — extra draws, no selection signal. **Mate choice by genetic similarity** — promotes inbreeding/fast speciation. **Chosen: the compatible ready candidate with the highest energy** (condition-dependent sexual selection), ties by (spatial distance, id) — deterministic, zero draws.
- **Compatibility by species ID (TASK-017)** — species do not exist yet and would make breeding units depend on bookkeeping. **Chosen: genome distance ≤ `<kind>.mating_threshold`** (ADR-004/012 `distance`), same kind enforced.

## Decision
New module `crates/evosim-core/src/animals/repro.rs`.

### Readiness (`ReproParams::for_kind(kind, cfg)`, `is_ready(o, rp)`)
An animal is *ready* iff alive, kind is Herbivore/Carnivore, `age ≥ maturity_age`, `cooldown == 0`, `health > 0`, `energy ≥ reproduction_threshold` **and** `energy > reproduction_cost` (paying never drives a parent to 0 — no forced starvation by mating).

### Compatibility
`compatible(a, b, rp)` ⇔ `a.id != b.id` ∧ same kind ∧ `genome::distance(a, b) ≤ mating_threshold` (boundary inclusive).

### Mate search (movement, inside the animal turns)
New action `Court` in `herbivore_turn` (after the flee check, before rest/forage) and in `carnivore_turn` (after handling, before rest/hunt): if the actor is ready and **no** ready compatible partner is within `MATING_REACH = 1`, but one is visible (`pop.nearest(center, vision_radius, Some(kind), pred)`), it moves towards it with `move_towards(.., reach 1, ..)` (one move call, no bite/attack that turn; herbivores still bite if food in reach after moving — implementer keeps "at most one move call, at most one bite"). If a partner is already in reach the animal behaves normally; mating happens in the pass below.

### Mating pass (end of each animal phase)
`reproduce_animals(pop, ids, kind, cfg, tick, rng) -> AnimalReproTick`, called by `World::act_animals` right after `act_herbivores` / `act_carnivores` with the same acting order `ids` (core-RNG shuffle already done). Per initiator `a` in that order:
1. skip if not alive, not ready, or already *engaged* this tick (engaged = took part in an attempt; kept in a small sorted `Vec<EntityId>`, no HashMap).
2. candidates = `pop.within(a.pos, MATING_REACH, Some(kind))` (ordered by (distance, id)), filtered by `id != a`, alive, ready, not engaged, compatible. Choose max energy (strict `>` keeps the first in (distance, id) order). None → next initiator.
3. both marked engaged (one attempt per animal per tick, success or not).
4. birth sites: ordered list = cell of `a`, cell of `b`, then the 8 neighbours of `a` in `Dir8` order (deduplicated on tiny worlds); free slots per site = `capacity − count_at(site) − pending births already placed there by this pass`. Total slots 0 → attempt ends (no draw, no cost; counted `no_room`).
5. fertility `f = (fertility_a + fertility_b)/2`. Conception: one `rng.chance(clamp(conception_chance · (0.5 + f), 0, 1))`. Fail → no cost, no cooldown (they may retry next tick).
6. litter `n = 1 + #successes of (max_litter − 1) draws rng.chance(f · condition)`, `condition = clamp((min(E_a, E_b) − threshold) / (min(maxE_a, maxE_b) − threshold), 0, 1)` (0 if denominator ≤ 0) — larger litters only for fertile, well-fed pairs. `n = min(n, total slots)`.
7. cost: each parent `spend_energy(reproduction_cost)` (always the full amount thanks to readiness). Pool `P = 2·reproduction_cost`; each child gets `P / n` (clamped to its own `max_energy` by `Organism::new`; excess lost as heat; never more than paid).
8. both parents `set_cooldown(mating_cooldown)`.
9. per child (in order): `genome = child_sexual(a.genome, b.genome, MutationParams::for_kind(kind,cfg), rng)`; `request_birth(BirthRequest { pos: next site with a free slot, parents: Parents::Two(a, b), energy: P/n, health: None, genome })`.

Self-mating is impossible by construction (candidate filter `id != a`, `compatible` checks ids, `Parents::Two(a,b)` built only with `a != b`, debug_assert).

### Waiting time
`Organism.cooldown: u32` (getter `cooldown()`, `pub(crate) set_cooldown`), 0 at birth/founding. Decremented by 1 (saturating) for every living organism in the aging step of `Population::end_of_tick`. Effective wait after a mating at tick t: the animal is ready again at tick `t + mating_cooldown` at the earliest.

### New config keys (herbivores / carnivores)
| key | herbivores | carnivores | range |
|---|---|---|---|
| `mating_cooldown` (u32) | 40 | 80 | [0, 1e7] |
| `conception_chance` (f64) | 0.5 | 0.5 | [0, 1] |
| `max_litter` (u32) | 3 | 2 | [1, 16] |
No new cross-field checks.

### Same-tick interactions (ADR-011 unchanged)
Herbivores mate at the end of the Herbivores phase; if a parent is then killed in the Carnivores phase the Births phase drops the request (energy already paid is lost). Births into cells that filled up meanwhile are dropped by `resolve_births` (`births_dropped_full`).

### Audit
`AnimalReproTick { ready, attempts, no_room, conceived, offspring, energy_spent, offspring_energy }`, cumulative `ReproLedger` per animal kind in `World` (`World::repro_ledger(kind)`), invariant `offspring_energy ≤ energy_spent`.

## Consequences
- RNG stream changes for all runs with mature ready animals; regression/expected-count tests may need updates (document numbers).
- TASK-022 snapshot must serialise `Organism::cooldown` and the repro ledgers; state hash includes `cooldown`.
- TASK-017 species classification happens on top (child vs mother-species representative = species of parent `a`).
- Population sizes are still bounded by food and per-cell capacity; no rule looks at global counts.

## Verification
`crates/evosim-core/src/animals/tests_repro.rs` (see tasks/TASK-016/handoffs/plan-cycle1.md).

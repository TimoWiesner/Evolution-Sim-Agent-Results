# ADR-012: Genome layout, gene→trait expression, crossover/mutation operators, distance

## Status
Accepted — 2026-11-22 — TASK-009 (plan). Refines ADR-004 (genome representation) and plugs into ADR-011 (Traits, Organism, BirthRequest).

## Context
TASK-009: every organism carries heritable DNA; traits are a deterministic function of the genome and stay in their ADR-011 ranges; children from one parent (copy) or two parents (crossover); mutation with configurable rate and strength drawn from the simulation's generator; a genetic distance (0 on identity, symmetric, growing with difference). ADR-004 already fixed the family of solution (fixed-length real genes in [0,1], uniform crossover, reflected Gaussian mutation, weighted mean |Δ| distance). This ADR fixes the concrete layout, mapping and API. std only, no new crates.

## Alternatives considered
### Gene storage
- **A. `[f32; 32]` fixed array for every kind** — `Copy`, no allocation, but plants carry meaningless animal genes that drift and dilute the distance; length 32 is arbitrary.
- **B. `Vec<f32>` with the per-kind length of a static gene table, plus the kind (chosen)** — exact per-kind layout as ADR-004 says, one small allocation per birth (negligible), easy to extend (layout version).
- **C. Store `f64`** — more precision than needed, double memory; f32 is plenty for [0,1] genes (values computed in f64, stored rounded).

### Trait mapping
- **A. Pure `lo + (hi−lo)·g` over the ADR-011 ranges** — ranges are deliberately wide (lifespan up to 10 M ticks); g = 0.5 would give absurd founders and ignore configuration.
- **B. Linear mapping over a config-derived range, then `Traits::clamped` as a final guarantee (chosen)** — the configuration keeps its meaning (`max_speed`, `max_vision`, `max_age`, `max_energy` are the upper ends), founders with the default genome reproduce the TASK-008 defaults exactly.
- **C. Sigmoid / polygenic sums** — smoother but harder to reason about; possible later.

### Founder genomes
- **A. All founders identical** — zero initial diversity; species/mate checks trivial at start.
- **B. Default genome + small reflected Gaussian jitter per founder from a dedicated generator (chosen)** — some standing variation for selection from tick 0, expected distance between two founders ≈ 0.023 (≪ species threshold 0.15), core RNG stream unchanged.

## Decision
**Module `genome`** (`crates/evosim-core/src/genome/`), depends on `organism::Kind`, `organism::Traits`, `rng`, `config`.

**Representation.** `Genome { kind: Kind, genes: Vec<f32> }`, every gene in [0, 1], `genes.len() == gene_table(kind).len()` (constructor `Genome::from_genes(kind, Vec<f32>) -> Result<Genome, GenomeError>` checks length, finiteness and range). `GENE_LAYOUT_VERSION: u32 = 1` (checkpoints, TASK-022). The genome carries its kind, so a child request cannot have a genome of the wrong kind.

**Gene tables (layout v1).** `GeneSpec { name, trait_target: Option<GeneTrait>, founder: f32, weight: f64 }`. Order:

| # | Gene | Plant | Animals | Expression (g ∈ [0,1]) | Founder value |
|---|---|---|---|---|---|
| | `strength` | ✓ | ✓ | `g` | 0.5 |
| | `fertility` | ✓ | ✓ | `g` | 0.5 |
| | `max_health` | ✓ | ✓ | `base_health · (0.5 + g)`, base 10 / 100 / 120 | 0.5 |
| | `lifespan` | ✓ | ✓ | `round(max_age · (0.5 + 0.5 g))`, ≥ 1 | 1.0 |
| | `max_energy` | ✓ | ✓ | `cfg max_energy · (0.5 + 0.5 g)` | 1.0 |
| | `temp_optimum` | ✓ | ✓ | `−20 + 60 g` °C | 0.5 (= 10 °C) |
| | `temp_tolerance` | ✓ | ✓ | `2 + 28 g` °C | 0.5 (= 16 °C) |
| | `speed` | – | ✓ | `max_speed · g` | 0.5 |
| | `vision` | – | ✓ | `max_vision · g` | 1.0 |
| | `aggression` | – | ✓ | `g` | 0.5 |
| | `caution` | – | ✓ | `g` | 0.5 |
| | `marker_0..marker_5` | ✓ | ✓ | none (neutral) | 0.5 |

Plants: 7 + 6 = 13 genes; herbivores/carnivores: 11 + 6 = 17 genes. Plant `speed/vision/aggression/caution` are fixed 0 (no gene). All weights 1.0 in v1. `max_speed`, `max_vision`, `max_age`, `max_energy` are the per-kind config values. Two traits are added to `Traits` and to the ADR-011 range table: `temp_optimum` ∈ [−40, 60] °C and `temp_tolerance` ∈ [0.5, 50] °C (all kinds; used by TASK-011/014). With the founder genome and no jitter, expression gives exactly the TASK-008 founder defaults (plus the two new traits).

**Expression.** `Expression` (Copy struct of the config-derived constants per kind, `Expression::from_config(&Config)`), `express(genome, &Expression) -> Traits` = `Traits::clamped(kind, raw)`; pure, deterministic, no RNG. `Traits::founder_default(kind, cfg)` becomes `express(&Genome::founder_default(kind), &Expression::from_config(cfg))`.

**Organism integration.** `Organism` gains a private `genome: Genome` and getter `genome()`; traits are computed from it in `Organism::new` and cached (there is no way to set traits independently). `BirthRequest { pos, parents, energy, health, genome }` — the `kind` and `traits` fields are removed (`BirthRequest::kind()` = `genome.kind()`); `BirthRequest`/`Organism` are `Clone`, not `Copy`. `Population` stores the `Expression` (set by `Population::founders(cfg, ..)`, `Population::with_expression(e)`; `Population::new()` uses the expression of `Config::contract_example()`).

**Founders.** Genome = `Genome::founder_default(kind)` mutated with rate 1 and strength `<kind>.founder_variation` (new config keys, default 0.02, range [0, 1]) using a dedicated generator `Rng::seed_from_u64(seed ^ FOUNDER_GENOME_TAG)` (`0x0F0B_DE25_0000_0009`), one founder after another in ID order. Founder positions (FOUNDER_SEED_TAG stream) and the core RNG are unchanged.

**Operators** (all draw from the `&mut Rng` passed in; behaviour tasks pass `ctx.rng`, the simulation's core generator):
- `Genome::copy_of(parent)` — exact clone (asexual inheritance before mutation).
- `crossover(a, b, rng) -> Result<Genome, GenomeError>` — uniform: for each locus in order one `rng.chance(0.5)`; true → gene of `a`, else of `b`. Different kinds → `GenomeError::KindMismatch` (no draws).
- `mutate(&mut genome, MutationParams { rate, strength }, rng) -> usize` (number of genes changed) — if `rate <= 0` or `strength <= 0`: no draws, returns 0. Otherwise per locus in order: one `rng.chance(rate)`; on hit `x = g + rng.normal(0, strength)` (two draws), `reflect(x)` into [0,1] (`y = x.rem_euclid(2); if y > 1 { 2 − y }`, non-finite → unchanged), stored as f32 then clamped to [0,1].
- `MutationParams::for_kind(kind, &Config)` reads `<kind>.mutation_rate` / `<kind>.mutation_strength` (existing keys).
- Helpers: `child_asexual(parent, params, rng)` = copy + mutate; `child_sexual(a, b, params, rng)` = crossover + mutate.

**Distance.** `distance(a, b) -> f64 = Σ wᵢ|aᵢ − bᵢ| / Σ wᵢ` in f64 over loci in order; ∈ [0, 1]; 0 iff identical; symmetric (computed with |·|, same summation order); strictly increases when an additional locus differs or a difference grows. Genomes of different kinds: distance 1.0 (maximal, documented).

## Rationale
### Performance
13–17 f32 per organism (≈ 70 B + Vec header); copy/crossover/mutation/distance O(L) ≈ 17 steps; only at births and mate checks.
### Testability
Pure functions with an explicit `&mut Rng`: deterministic unit/property tests (rate 0 → only parental alleles; rate > 0 → differences over many offspring; ranges for extreme genomes; distance axioms).
### Self-contained dist/
std only; no new crates; Cargo.lock unchanged.

## Consequences
- TASK-011/014 read `temp_optimum`/`temp_tolerance`; adding a gene = one table row + one trait field/range row + `GENE_LAYOUT_VERSION` bump.
- TASK-012/016 build children with `child_asexual`/`child_sexual` using `ctx.rng` and `MutationParams::for_kind`; mate compatibility uses `distance` ≤ `mating_threshold` (TASK-016).
- TASK-017 species use `distance` against a representative genome.
- TASK-022 serialises genes (f32 → exact JSON round-trip via f64) and the layout version; state hash includes genomes.
- Founder jitter changes founder traits slightly from the TASK-008 defaults; tests compare against `express(genome)`.

## Verification strategy
TASK-009 tests in `genome/tests.rs` and organism/sim tests (see tasks/TASK-009/handoffs/plan-cycle1.md).

# ADR-015: Plant reproduction, dispersal, pollination and site check (TASK-012)

## Status
Accepted — 2026-11-22 — TASK-012 (plan); implemented TASK-012 IMPLEMENT cycle 1 without deviations (shuffle replicates `acting_order` because `plants` must not depend on `sim`). Builds on ADR-011 (birth requests, same-tick rule), ADR-012 (genome operators), ADR-013 (spatial queries), ADR-014 (plant energy, cell resource R).

## Context
Plants must multiply only with enough energy and at an energy cost, place offspring within a dispersal distance (also across the wrapping edges), pass on the parent genome with mutation, record parent ID and generation, never place offspring where there is no room or no resources, and never appear from nothing (zero plants stays zero). Decisions owed: asexual only or also pollination; the dispersal pattern. Existing config keys: `plants.reproduction_threshold` 12, `reproduction_cost` 6, `dispersal_radius` 3, `pollination_enabled` true, `max_per_cell` 4, `initial_energy` 5, `mutation_rate/strength`, `species_threshold`.

## Alternatives considered
### Mode
- **A. Asexual only** — simplest, but plant lineages never recombine.
- **B. Asexual by default + optional pollination (chosen)** — a seed is fertilised by a compatible nearby pollen donor with probability `pollination_chance`; otherwise it is a clone + mutation. Matches ADR-004 and the existing `pollination_enabled` key; gives gene flow between neighbouring patches.
- **C. Obligate pollination** — isolated plants could never reproduce (Allee effect); too fragile for recolonisation.

### Dispersal pattern
- **A. Neighbour cell only (radius 1)** — slow spread; empty regions are recolonised slowly.
- **B. Uniform over the toroidal Chebyshev square of radius `dispersal_radius` around the parent, own cell included (chosen)** — one `range_i64` draw per axis over `Torus::x_offsets/y_offsets(r)` (already de-duplicated on tiny worlds), target = `Torus::translate`; distance ≤ r by construction, wraps at all edges.
- **C. Distance-weighted kernel (e.g. geometric)** — more realistic but more parameters; can replace B later (TASK-027) without interface changes.

### Unsuitable site
- **A. Retry until a free cell is found** — hides crowding, unbounded draws.
- **B. One landing site per seed; if unsuitable the seed dies and its cost is lost (chosen)** — reproduction success falls automatically with local crowding and resource depletion (density dependence, no global counts).

## Decision
Plants phase, after `grow_plants` (ADR-014), function `plants::reproduce_plants(pop, res, torus, cfg, rng, tick) -> ReproTick`:

1. **Eligible** = living plants (ascending id) with `energy ≥ plants.reproduction_threshold` and `plants.seed_rate > 0`. If none, no RNG draw at all.
2. **Order**: `acting_order(eligible, rng)` (shuffled, ADR-008) — seed competition for room is order-dependent, so the order is random but seeded.
3. Per plant: re-check alive; `rng.chance(p)` with `p = clamp(seed_rate · (0.5 + fertility), 0, 1)` (fertility gene → trait, default 0.5 → p = seed_rate). If false: nothing happens.
4. **Cost**: `spent = spend_energy(reproduction_cost)` — always paid when a seed is made. `seed_energy = min(plants.initial_energy, spent)` (≤ the cost; the rest is lost as construction cost). Energy never increases here.
5. **Landing site**: `dx = range_i64(x_offsets(r))`, `dy = range_i64(y_offsets(r))`, `r = plants.dispersal_radius`, `target = torus.translate(pos, Offset{dx,dy})`.
6. **Site check** ("room and resources"): `living plants in target (pop.at(target, Some(Plant)), flagged-dead hidden) + seeds already accepted for target this tick < max_per_cell` **and** `R(target) ≥ plants.seed_min_resource`. Fails → seed lost (`seeds_failed += 1`, energy lost), no request. R is not consumed by the check.
7. **Genome**: if `pollination_enabled` and `rng.chance(pollination_chance)`: donor = `pop.nearest(pos, pollen_radius, Some(Plant), id ≠ self ∧ genome::distance(self, donor) ≤ plants.species_threshold)` (ties by (distance, id)). Donor found → `child_sexual(self, donor, mut)`, `Parents::Two(self, donor)`; else `child_asexual(self, mut)`, `Parents::One(self)`. `mut = MutationParams::for_kind(Plant, cfg)`.
8. `request_birth(BirthRequest{ pos: target, parents, energy: seed_energy, health: None, genome })`. The Births phase allocates the ID and sets `generation = 1 + max(parent generations)` (ADR-011), so parent IDs and generation are recorded on the organism and in `BirthRecord`/`EventKind::Birth`.

Same-tick rule (ADR-011) unchanged: a request whose mother or pollen donor dies before the Births phase (e.g. grazed later in the tick) is dropped; the energy is lost.

`species_threshold` as compatibility criterion is a placeholder until TASK-017 defines species membership.

### Ledger
`PlantLedger` gains cumulative + `last_*`: `reproduction_spent`, `seed_energy`, `seeds_made`, `seeds_failed`, `seeds_requested`, `pollinated`. Invariants: Plants-phase energy change = `uptake − upkeep − reproduction_spent`; `seed_energy ≤ reproduction_spent`; plant births ≤ seeds_requested.

### New config keys
`plants.seed_rate` 0.5 [0,1] (0 disables reproduction, no RNG draws); `plants.seed_min_resource` 1.0 [0,1000]; `plants.pollination_chance` 0.3 [0,1]; `plants.pollen_radius` 2 [0,64]. No seed bank (possible later in TASK-027).

## Rationale
### Performance
Per tick O(eligible · (1 cell lookup + nearest within pollen_radius)); at 2 000 plants ≈ a few thousand bucket lookups. No allocation beyond a per-tick `Vec<u8>`/small map of accepted seeds per cell (reuse a `Vec<u16>` of cell count).
### Testability
Pure function on `Population`/`CellResources` with an explicit `Rng`; site check and pattern testable on tiny tori; `seed_rate = 0` isolates growth tests.
### Self-contained dist/
No new crates.

## Consequences
- RNG stream now depends on plants (Plants phase draws). TASK-011 test `plant_growth_uses_no_core_rng` must set `seed_rate = 0`.
- TASK-014 grazing kills may free room for seeds of later ticks only.
- TASK-017 replaces the compatibility predicate with species membership; TASK-022 snapshot includes the extended ledger; TASK-027 tunes seed_rate/radius/cost.

## Verification strategy
TASK-012 tests in `crates/evosim-core/src/plants/tests_repro.rs` (see tasks/TASK-012/handoffs/plan-cycle1.md).

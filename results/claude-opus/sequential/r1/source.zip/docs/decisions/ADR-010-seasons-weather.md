# ADR-010: Seasons and weather on top of the base climate

## Status
Accepted — 2026-11-22 — TASK-007 (plan). Builds on ADR-009 (static base climate), ADR-005/ADR-008 (one core RNG, Climate phase first in every tick).

## Context
The static base climate (ADR-009) must vary over time: a repeating year of configurable length (`climate.year_length`, ticks) with a seasonal cycle of temperature and precipitation in every cell, plus random weather drawn from the **simulation's** core generator so that equal seeds give equal weather. Values must stay within documented bounds, be queryable for any cell at any tick, a year must repeat bit-exactly when weather is off, and any weather state that carries over between ticks must be part of the simulation state (checkpoint/hash, TASK-022). The torus seams must stay continuous (ADR-009). Existing config keys (TASK-003): `year_length` 400, `seasonal_amplitude` 8 °C, `precipitation_seasonality` 0.3, `weather_enabled` true, `weather_temperature_sd` 2 °C, `weather_precipitation_sd` 0.1, `weather_persistence` 0.9.

## Alternatives considered
### Hemispheres and season phase
- **A. Opposite seasons in the two mirrored hemispheres (Earth-like)** — realistic, but the hemispheres touch at the pole seam (rows h−1 / 0) where the seasonal amplitude is largest: summer next to winter = a hard discontinuity across the seam. Rejected.
- **B. Same season phase everywhere, amplitude depending on latitude (chosen)** — continuous everywhere (the folded latitude is continuous and symmetric), simple, matches the "one hemisphere shown twice" reading of the folded map (ADR-009).
- **C. Opposite seasons with amplitude forced to 0 at the pole** — continuous but unphysical (poles have the strongest seasons).

### Weather model
- **Independent white noise per cell per tick** — no persistence, no spatial coherence, w·h draws per tick (slow for large worlds), noisy for organisms. Rejected.
- **One global AR(1) anomaly** — cheap, persistent, but no spatial structure (the whole world gets warmer at once).
- **Torus-periodic AR(1) anomaly lattice (chosen)** — a coarse lattice (`climate.weather_scale` cells per node) of temperature and precipitation anomalies; every node follows a stationary AR(1) process driven by core-RNG normals, the field is smoothly interpolated (same smoothstep-bilinear periodic sampling as ADR-009 noise) → spatially coherent "weather systems", persistent over ticks, continuous across both seams, 2·gx·gy normals per tick (64×48 default: 4×3 lattice → 24 normals).
- **Moving fronts / advected fields** — prettier, many more parameters; deferred.

### Storing the current values
- Recompute on every query — no storage, but plants/animals will query each cell many times per tick.
- **Per-cell "current climate" grid recomputed once in the Climate phase (chosen)** — O(w·h) per tick (≈3 k cells default, ~0.5 M for 1024×512 ≈ ms), O(1) lookups; it is derived data (function of base map, tick, weather lattice), so only the lattice must be checkpointed.

## Decision
**Year phase.** `k = t mod Y` (integer, `Y = climate.year_length`), `s(t) = sin(2π·k/Y)`. Day `k = 0` is the spring equinox, `k = Y/4` midsummer (warmest/wettest), `k = 3Y/4` midwinter. Because the phase is computed from the integer `t mod Y`, ticks `t` and `t + Y` give bit-identical seasonal values. All cells share the phase (alternative B).

**Seasonal temperature.** `T_season(φ, t) = A_s · w_T(φ) · s(t)`, `A_s = climate.seasonal_amplitude`, `w_T(φ) = 0.1 + 0.9·sin φ` (∈ [0.1, 1]): weak seasons at the equator (±0.8 °C default), strong at the pole (±8 °C) — continental-like high-latitude seasons.

**Seasonal precipitation (relative units).** `r_season = r_base · (1 + c · w_P(φ) · s(t))`, `c = climate.precipitation_seasonality`, `w_P(φ) = 0.25 + 0.75·g(φ, 20, 15)` (g as ADR-009): strongest wet/dry season in the tropics/subtropics (monsoon, savanna), weaker at the equator and at high latitudes. Summer is wet.

**Weather.** Two lattices `aT`, `aP` of `gx × gy` nodes, `gx = lattice_size(w, climate.weather_scale)` (new key, u32, default 16, range 1…4096), row-major. Initial state (tick 0, `Simulation::new`): all zero (no RNG draws in `new`). In the Climate phase of every tick, if `climate.weather_enabled`: for each node of `aT` (row-major) then of `aP`: `a ← clamp(ρ·a + √(1−ρ²)·σ·z, −3σ, 3σ)`, `z = rng.normal(0,1)` from the **core** RNG (`ctx.rng`), `ρ = climate.weather_persistence`, `σ = weather_temperature_sd` (°C) resp. `weather_precipitation_sd` (relative to `max_precipitation`). σ is the stationary SD. Draws happen even when σ = 0 (draw count depends only on lattice size and the flag). If weather is disabled: no draws, anomalies stay exactly 0. Cell anomaly = periodic smoothstep-bilinear sample of the lattice at the cell centre (`PeriodicNoise` sampling, ∈ [−3σ, 3σ]).

**Current cell climate (tick t).**
- `T(c,t) = clamp(T_base(c) + T_season(φ,t) + aT(c), T_min, T_max)`
- `P(c,t) = P_max · clamp(r_base(c)·(1 + c·w_P(φ)·s(t)) + aP(c), 0, 1)`, `r_base = P_base/P_max` (0 if P_max = 0)
- Documented bounds (`climate::ClimateBounds::from_params`): `T_min = T_pole − A_T − A_s − 3σ_T`, `T_max = T_eq + A_T + A_s + 3σ_T`, `P ∈ [0, P_max]`. These hold by construction; the final clamp is a safety net against rounding. Defaults: T ∈ [−40.5, 43.5] °C, P ∈ [0, 1].
- Biome stays the static base biome (ADR-009); the current values are what organisms (TASK-011+) read.

**Ownership / query.** `World` owns `Weather` (the two lattices = the only carried-over weather state) and a `Vec<CellNow{temperature, precipitation}>` current grid plus `climate_tick: u64` (tick the grid describes). The Climate phase of tick `t` updates the lattices, then recomputes the grid for `t`. Before any tick the grid describes tick 0 with zero weather. Query: `World::current(cell) -> CellNow`, `World::climate_tick()`, `Simulation::climate_now(cell)`; deterministic no-weather values for **any** tick: `ClimateMap::seasonal(cell, tick) -> CellNow`.

**State.** `WeatherState { temperature: Vec<f64>, precipitation: Vec<f64> }` (lattice values, exact f64). `Simulation::weather_state()` / `set_weather_state(WeatherState) -> Result<(), SimError>` (validates lengths and finiteness, then recomputes the current grid for `climate_tick = tick.saturating_sub(1)`, which equals the value an uninterrupted run has after `tick` completed ticks). Checkpoint and state hash (TASK-022) must include it; clock and RNG are already state.

## Rationale
### Performance
Per tick: 2·gx·gy normal draws + one O(w·h) pass with a few multiply-adds and two bilinear samples per cell; sin φ / w_T / w_P precomputed per row. Negligible against the ≥100 ticks/s at 2 000 entities goal.
### Testability
Seasons are a pure function of (cell, t mod Y) → exact year-repeat test with weather off; weather consumes only the core RNG in a fixed order → same seed same weather; bounds are closed-form; resume with/without weather state proves it is state.
### Self-contained dist/
std only, no new crates.

## Consequences
- New config key `climate.weather_scale`; docs/CONFIG.md regenerated.
- Core RNG stream now advances in the Climate phase every tick when weather is on (later phases' draws shift accordingly — fine, all determinism tests compare runs, not golden post-step RNG states).
- TASK-022 snapshot/hash must serialise `WeatherState` (and needs no copy of the derived grid). TASK-011+ read `World::current(cell)`.
- A world with opposite hemispheric seasons is impossible without a seam; documented in docs/CLIMATE.md.

## Verification strategy
Tests in `crates/evosim-core/src/climate/` (season/weather/bounds) and `sim/tests.rs` (determinism, state), CLI `evosim climate series`; see tasks/TASK-007/handoffs/plan-cycle1.md.

# ADR-030: Ecosystem balance — local type-III hunting response, measured trials (TASK-027)

Status: Accepted (IMPLEMENT TASK-027 cycle 1): D1 implemented, defaults prey_density_half 40, base_success 0.33, herbivores.initial_energy 80; D2/optional trial not run (time). Held-out median 2,208.5 vs 1,508.5 old, 3/10 full. Results and final numbers: docs/BALANCE.md.

## Context
Baseline (docs/BALANCE.md §1–2, contract example config, seeds 1–10, 10,000 ticks): median three-kind coexistence
1,708.5 ticks, 0/10 full. Two failure modes: (A, 6/10) carnivores slowly die of starvation with almost no births
while herbivores are abundant; (B, 4/10) herbivores are eaten out by t≈400–700 (all deaths predation) because the
carnivore kill rate barely falls when prey gets rare (plant cover ≈1 everywhere is no refuge). Parameter sweeps
(T1–T3) only move runs between mode A and mode B. A temporary prototype (P1) of a local prey-density factor on
attack success raised the median to 2,754–2,860 at 3,000 ticks (5/10 runs alive at 3,000) and, with
herbivores.initial_energy 80, to 3,944 at 5,000 ticks.

## Decision 1 (mechanism, primary): local type-III hunting response
Attack success gets one more factor, the *local prey density* the carnivore perceives:
```
n       = living herbivores within the attacker's vision radius (toroidal Chebyshev, spatial index,
          includes the target; counted when the attack/choice is made)
density = n / (n + hunting.prey_density_half)        (= 1 when prey_density_half = 0: old behaviour)
p       = clamp(base·(1+edge)·alert·drive·shelter·range·density, P_MIN, P_MAX)
```
New key `hunting.prey_density_half: f64` (≥0, range [0, 1000]); 0 disables the factor exactly (bit-identical old
results — used to reproduce the baseline: `--param hunting.prey_density_half=0 --param hunting.base_success=0.12`
plus the other old values). `hunting.base_success` is raised in the same trial to keep the kill rate where prey is
dense (prototype: half 40, base 0.36).
Biology: a predator hunting where prey is scattered has no search image, prey that is rarely met is more wary,
and hunts are less often successful — the classic type-III functional response; where herds are dense,
hunting is efficient. It is a **local perception rule** (what the carnivore can see), applied to every carnivore
at every tick whatever the global numbers — allowed by docs/PROJECT.md ("hunting success that depends on how
easy prey is to find"; "may react to what an organism can perceive"). It never looks at the size of a kind or
species, creates nothing, and cannot prevent an extinction (P_MIN 0.02 stays: a lone prey can still be killed).
Evolution: vision is heritable, so a far-seeing carnivore counts more prey (counted within its own vision).
Implementation: `animals/hunt.rs` — `HuntParams.prey_density_half`, pure `density_factor(n, half)`,
`local_prey(pop, pred, r)` counting with `Population::for_each_within` (pure closure, order-independent count),
extra argument to `success_probability`; `best_in_reach` and `attack` compute `n` once per call (same value for
all candidates, so the prey ranking is unchanged). Exactly one RNG draw per attack stays.

## Decision 2 (mechanism, secondary, tried after Decision 1): mate search of ready animals
Mode A is a reproduction bottleneck of a sparse predator. Trial: new key `<kind>.mate_search_radius: u32`
(herbivores and carnivores, 0 = vision radius = old behaviour): a ready animal looks for a ready compatible mate
within `max(vision, mate_search_radius)` (scent/calls) — prey detection keeps using vision, so it does not
increase hunting (T2 showed that larger *vision* mostly increases predation). Kept only if it measurably helps;
otherwise recorded as a failed trial and not merged as default (key may stay with default 0 or be removed).
Optional third trial if time remains: lower resting/handling metabolism of carnivores
(`carnivores.rest_metabolism`, factor on base_metabolism in Rest/Handle turns, 1 = old).

## Decision 3: parameters and trial protocol
- Tuning seeds 1–10; held-out seeds 1001–1010 (never used while tuning; ≥5 required, 10 used).
- Screening trials: 5,000 ticks on seeds 1–10 via `evosim batch --param` (≈45 s per 20 runs on 12 cores).
  Candidate defaults: 10,000 ticks on seeds 1–10, then once on 1001–1010. Metric: median three-kind coexistence
  (tie-break: number of runs reaching the end, then minimum). Stop when two consecutive trials do not improve the
  median by > 5 % or the time budget is spent.
- First sweep: `hunting.prey_density_half` {20, 40, 60} × `hunting.base_success` {0.24, 0.36, 0.48} ×
  `herbivores.initial_energy` {60, 80}; then refine handling_time / carnivore reproduction around the best.
- Every trial (also failures) goes into docs/BALANCE.md §3 with change / expected / measured.

## Alternatives considered
- Parameter-only tuning: measured T1–T3, knife edge between modes A and B — rejected as sole approach.
- Predator interference (success reduced by other carnivores nearby): carnivores are ~20 on 3,072 cells, they
  rarely meet — little effect expected; not tried first.
- Fixed-number refuges (one hidden herbivore per plant): herbivore cell cap is 2, plants saturate cells → weak.
- Learned search image (per-carnivore skill state): also type III, but adds organism state (genome/checkpoint/hash
  format) — more cost for the same effect as Decision 1.
- Any count-based rule, immigration, respawn: forbidden (PROJECT.md).

## Consequences
- Defaults change ⇒ state hashes of default-config runs change. Re-record `scripts/perf-equivalence.txt` (reason:
  TASK-027 defaults; equivalence of the TASK-026 optimisations was already proven on the old defaults) and any
  test pinning default-config numbers; unit tests asserting old hunting numbers pin `prey_density_half = 0`
  (or a test-only `Config::pre_task027()` like `pre_task018()`).
- New keys appear in `evosim config schema`, docs/CONFIG.md, UI form/presets (generated from the schema);
  checkpoints store the config — an older checkpoint without the key loads with the new default (documented).
- Performance: one extra radius-`vision` count per attack decision (only when prey is in reach); `evosim perf`
  re-run must stay ≥100 ticks/s (TASK-026: 336). Larger herbivore/carnivore populations may cost more.

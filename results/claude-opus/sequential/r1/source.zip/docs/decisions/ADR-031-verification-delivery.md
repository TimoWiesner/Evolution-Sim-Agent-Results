# ADR-031: Verification evidence, randomised invariant tests and demo scenario (TASK-028)

Status: Accepted (TASK-028 IMPLEMENT cycle 1; implemented as planned — demo winner D2 128×96, see docs/VERIFICATION.md)

## Context
TASK-028 must prove robustness and hand the product over: every `docs/CONTRACT.md` command/behaviour verified with
recorded evidence, a self-contained `dist/`, ≥10,000-tick runs for ≥3 seeds, randomised invariant tests, one test
command, README coverage incl. the demo command, coexistence measurements for `scenarios/demo.json` and the contract
§3 example, and a self-audit of `docs/PROJECT.md`. No new features.

## Decisions
D1 **Evidence location.** `docs/VERIFICATION.md` = contract checklist (§1–§7, one row per requirement: command,
expected, observed, where automated), long-run results, coexistence tables, test-suite run. `docs/SELF-AUDIT.md` =
every PROJECT.md requirement as met / partly met / missing with evidence links, plus "Known limitations". Raw data
(batch outputs, logs) in `tasks/TASK-028/data/` (small JSON only; no metrics files).
Alternative rejected: putting everything into README (too long; README links to both docs and states the results).

D2 **Randomised invariant tests without new crates.** A Cargo integration test
`crates/evosim-core/tests/randomized_invariants.rs` draws configurations from the in-crate seeded `rng` (world 1×1 …
48×36 incl. 1×N/N×1 strips, initial counts 0…dense incl. zeros, weather on/off, mutation-rate and selected parameter
variations via `batch::set_dotted` on the JSON value then `Config::from_value`) and seeds, and checks per tick:
birth/death accounting per kind (`initial + births − deaths = alive`, totals monotone), no replenishment (zero stays
zero), value ranges (energy/health within [0, max], traits `in_range`, ages ≥0, positions inside the torus,
`Population::validate(next_id)` ok, climate values finite and inside `World::climate_bounds`), wrapping (random
cells/offsets on random tori: wrapped results in bounds, distance symmetric and ≤ ⌊n/2⌋ per axis, `within` equals a
brute-force toroidal oracle near seams, climate continuity across both seams no larger than the largest interior
step), determinism (same config+seed → same `state_hash`/totals/series; other seed → other hash; save at random
tick A + load + B == A+B uninterrupted). The generator seed list is fixed so failures reproduce; each case prints
its config on failure. Budget: < 60 s in release inside `./test.sh`. `proptest` was rejected: it would add a
dependency to the `--locked` lockfile for no gain over an explicit seeded generator (shrinking is not needed with
small, printed cases).

D3 **Self-containment evidence beyond `ldd`.** In addition to the existing `ldd` whitelist + empty-env copy check, a
script `scripts/check-dist-chroot.sh` builds a minimal chroot containing only `dist/` plus the shared libraries
`ldd` reports (and the dynamic loader), then runs `dist/evosim version` and a short `dist/evosim run` inside it with
`env -i`. This proves no hidden dependency on files outside `dist/` (no runtimes, no `/usr/share` assets). It needs
root (available in the container); if chroot is not permitted it reports SKIP with the reason, never PASS.

D4 **Demo scenario = parameters only.** `scenarios/demo.json` uses only existing configuration keys (no engine change,
no anti-extinction). Candidates are measured at 10,000 ticks on tuning seeds 1–5 with `evosim batch --jobs 4`
(mirrors the benchmark's 4 parallel runs, so `elapsed_seconds` per run shows the 900 s limit is kept): larger
worlds with the contract ratio of initial populations (e.g. 96×72 900/270/45, 128×96 1600/480/80) and at most a few
documented parameter variations from the TASK-027 ridge analysis. The winner (best median coexistence, every run
< 300 s per run at 4 parallel to keep margin) is confirmed on held-out seeds 11–15. All trials, including failures,
are recorded in `docs/VERIFICATION.md` (section "Demo scenario trials").

## Consequences
- `./test.sh` gains the randomised test (cargo) and the chroot check; long 10,000-tick runs stay out of `./test.sh`
  (minutes) and are reproducible via `scripts/long-runs.sh`, whose output is recorded.
- Coexistence numbers are measurements, not guarantees; README states them with seeds.

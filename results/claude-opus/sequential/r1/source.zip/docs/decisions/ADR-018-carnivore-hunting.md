# ADR-018: Carnivore hunting (TASK-015)

Status: Accepted (PLAN TASK-015 cycle 1; implemented IMPLEMENT cycle 1)

## Context
Carnivores must live off herbivores: pursue them within vision, attack only from the same or an adjacent cell, succeed or fail depending on both animals' traits and the core RNG, kill prey exactly once (cause `Predation`), gain at most the prey's energy, pay for every attack, and starve without prey. Existing pieces: `hunting.{base_success 0.4, attack_cost 1.0, handling_time 5, cover_protection 0.3}` keys (TASK-003, unused so far), `DeathCause::Predation`, `Population::kill` (first cause wins, hides the victim from all queries at once), ADR-016 movement API, ADR-017 herbivore turn (metabolism, satiety, starvation, flight).

## Decision
New module `animals/hunt.rs` (pure helpers + `attack`) and `animals/carnivore.rs` (`act_carnivores`, `carnivore_turn`), dispatched from `World::act_animals` for `Kind::Carnivore` (the TASK-013 `act_animals` policy stays as a movement-only helper used by TASK-013 tests).

### Reach
`ATTACK_REACH = 1` (toroidal Chebyshev: own cell + 8 neighbours, across the wrap). The guarantee lives in `attack()`: it refuses (no RNG draw, no cost, `refused = true`) if the distance is > 1, either party is dead, or the kinds are wrong.

### Attack formula
For carnivore C and herbivore H (traits clamped to [0,1] where applicable):
```
v_ref   = max(carnivores.max_speed, herbivores.max_speed, 1)
power_X = 0.5·strength_X + 0.5·speed_X / v_ref
edge    = power_C − power_H                        ∈ [−1, 1]
alert   = 1 − PREY_ALERTNESS·caution_H             (PREY_ALERTNESS = 0.3)
drive   = 1 + AGGRESSION_BONUS·(aggression_C − 0.5) (AGGRESSION_BONUS = 0.4)
cover   = min(1, plants in H's cell / plants.max_per_cell)
shelter = 1 − hunting.cover_protection·cover
range   = 1 if same cell, ADJACENT_FACTOR (0.8) if adjacent
p = clamp(base_success · (1 + edge) · alert · drive · shelter · range, P_MIN = 0.02, P_MAX = 0.95)
success = rng.chance(p)      — exactly one core-RNG draw per (non-refused) attack
```
With founder genes (all animal strengths 0.5, speeds C 1.5 / H 1.0, v_ref 3) `p ≈ 0.4·1.083·0.85·1·shelter ≈ 0.37` in an empty cell → many kills and many escapes. P_MIN/P_MAX keep both outcomes possible for every trait combination. Cover is the refuge mechanism (local, per cell; allowed by PROJECT.md).

### Cost and gain
- Every non-refused attack costs `hunting.attack_cost` via `spend_energy` before the draw (success or not).
- On success: `e = prey.energy()` (read before the kill), `pop.kill(prey, Predation, tick)`; only if `kill` returns true: `gained = C.add_energy(min(carnivores.assimilation·e, carnivores.max_meal))` ⇒ `gained ≤ e` (assimilation ≤ 1, add_energy clamps at max_energy). The remainder is lost (no carcass, no energy enters the soil). New key `carnivores.assimilation` f64 = 0.8, [0,1].
- After a kill the carnivore is *handling* for `hunting.handling_time` ticks: it neither moves nor attacks (metabolism still applies). Stored as `Organism::handling: u32` (getter/setter; TASK-022 must serialise it).

### Several carnivores, same prey
Carnivores act one by one in the shuffled acting order (ADR-008). The first successful attack kills the prey; `kill` hides it from the index at once, so later carnivores neither see nor can attack it (`attack` on a dead id is refused, no cost) and choose another target. A failed attack leaves the prey alive in place; another carnivore may attack the same prey later in the same tick (implicit group hunting). Each carnivore makes at most one attack per tick.

### Carnivore turn (one move call max)
1. Skip if not a living carnivore or energy/health ≤ 0 at turn start (left to Deaths sweep, as ADR-017).
2. Stride update; metabolism `feed::metabolic_cost` with carnivore params (`base_metabolism`, new key `carnivores.climate_cost` f64 = 1.0, [0,100]).
3. If `handling > 0`: decrement, action `Handle` (no move/attack).
4. Else if `energy ≥ satiety(traits)` (ADR-017 satiety formula): action `Rest`.
5. Else: prey in reach → attack the one with highest p (ties: distance, id). Else nearest visible herbivore within `vision_radius` (distance, id) → `move_towards(.., stop_at = 1)`, then if a herbivore is now in reach, attack it (pursue + strike in one tick). Else `wander`.
6. If energy ≤ 0 → `kill(Starvation)`.

### Ledger
`HuntTick {hunters, attacks, kills, escapes, refused, attack_cost, prey_energy, gained, metabolism, starved, handling, rested, max_attack_distance}` + cumulative `HuntLedger` in `World` (`hunt_ledger()`, `last_hunt()`); invariant `gained ≤ prey_energy`, `kills + escapes = attacks`.

## Alternatives considered
- Logistic of trait difference: smoother but harder to reason about; the clamped product is transparent and monotone in each trait.
- Prey "escape" moves the prey away: would interfere with herbivore stride/move accounting from its own phase; rejected for now.
- Carcass left as food for others: extra entity type, out of scope.
- Splitting the gain over the handling time: more state; immediate gain + handling rest has the same rate-limiting effect.

## Consequences
- Carnivores phase now draws the RNG once per attack (in addition to shuffle/wander); runs with carnivores change their stream vs TASK-014 (expected; `no_animals_no_extra_rng_draws` unaffected).
- Performance: one `within(center,1,Herbivore)` + one `nearest` per carnivore per tick, same order as herbivores.
- Tests: see tasks/TASK-015/handoffs/plan-cycle1.md.

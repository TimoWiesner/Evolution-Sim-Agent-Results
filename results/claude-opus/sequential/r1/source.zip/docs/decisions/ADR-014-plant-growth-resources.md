# ADR-014: Plant growth, cell resources, ageing and death (TASK-011)

Status: Accepted (TASK-011 plan). Implementation: TASK-011 IMPLEMENT.

## Context
Plants must get energy from the resources of their cell. The gain must depend on the cell's current temperature and water, resources must be limited so that plants in a cell compete, and plants must die of old age, lack of energy or hostile climate. Genome-derived traits must affect growth or tolerance. No energy may appear without a documented source (docs/PROJECT.md, forced anti-extinction rules).

## Decision

### Resource model: one soil resource per cell ("fertility" R)
- `CellResources { values: Vec<f64> }` (row-major, one value per cell), owned by `World`. R abstracts water + nutrients; light is not modelled separately (it is uniform on this map).
- R(0) = `plants.resource_cap` in every cell.
- **Resources phase** (each tick, after Climate): `R ← min(cap, R + regen·m)`, where `m = clamp(P_now / climate.max_precipitation, 0, 1)` is the current relative moisture of the cell (`m = 0` if `max_precipitation = 0`) and `regen = plants.resource_regen`. Dry cells refill slowly → lower carrying capacity. The amount actually added is recorded in the ledger.
- R never leaves `[0, cap]`. R is the **only** source of plant energy.

### Growth (Plants phase), order-independent fair share
For each living plant `i` in cell `c` with traits `opt = temp_optimum`, `tol = temp_tolerance`, `strength`, `max_energy`:
- Thermal suitability `f_T = max(0, 1 − ((T_now − opt)/tol)²)`.
- Water suitability `f_W = clamp((m − w_min)/(w_opt − w_min), 0, 1)` with `w_min = plants.water_min`, `w_opt = plants.water_optimum`; if `w_opt ≤ w_min`, `f_W = 1` when `m ≥ w_min` else 0 (no cross-field config error needed).
- Generalist cost `peak = 1 − plants.generalist_cost · clamp((tol − 2)/28, 0, 1)` (wide tolerance → lower peak rate; prevents evolution to "tolerate everything").
- Demand `d_i = min(plants.growth_rate · f_T · f_W · peak, max_energy − energy)` (never above the headroom).
- Per cell: `D = Σ d_i`, `share = if D > R { R / D } else { 1 }`, grant `g_i = d_i · share`. Then `R ← max(0, R − Σ g_i)`; `energy += g_i` (1 resource unit = 1 energy unit). Summation in ascending EntityId order inside a cell, cells in row-major order → deterministic, **no RNG draws** (core RNG stream unchanged).
- Upkeep (after uptake): `spend_energy(plants.upkeep · (0.75 + 0.5·strength))` — energy leaves the system (respiration). Toughness (strength, later used against grazing in TASK-014) costs upkeep.
- Competition: all plants of a cell share one R, so per-plant gain falls with crowding and total gain per cell per tick is bounded by R (≤ cap + regen). Carrying capacity ≈ `regen·m / upkeep` plants per cell.

### Climate stress and death
- Stress `s = max(s_T, s_W)`, `s_T = clamp(|T_now − opt|/tol − 1, 0, 1)` (0 inside tolerance; growth already 0 at the edge), `s_W = if m < w_min { 1 − m/w_min } else 0` (`w_min = 0` → `s_W = 0`).
- `s > 0`: `damage(plants.stress_damage · max_health · s)`; if health reaches 0 the plant is killed immediately with `DeathCause::Climate` (`Population::kill`), reported in the tick's Deaths phase.
- `s = 0`: `heal(plants.heal_rate · max_health)` (health is not energy; healing creates no energy).
- Lack of energy: energy 0 after upkeep → `DeathCause::Starvation` in the existing Deaths sweep.
- Old age: existing `age ≥ max_lifespan` → `DeathCause::OldAge` (`max_lifespan` is genome-derived, ADR-012).

### Genome-derived traits used (no gene layout change, GENE_LAYOUT_VERSION stays 1)
`temp_optimum`, `temp_tolerance` (thermal niche + generalist cost), `max_energy` (storage/headroom), `strength` (upkeep), `max_lifespan`, `max_health` (stress endurance). `fertility` is left for TASK-012. A drought-tolerance gene was rejected for now: it would change the plant gene layout (13 genes) and TASK-009 tests; water response is a config-level curve.

### Energy ledger (audit of "no energy without a source")
`PlantLedger { regen_added, uptake, upkeep }` cumulative f64 totals on `World` (plus `last_*` per tick). Invariants tested: `Σ R(t) = Σ R(0) + regen_added − uptake` (within fp tolerance); every plant energy increase in the Plants phase equals the resource removed from its cell.

### New config keys (all with defaults; fixed contract keys unchanged)
`plants.growth_rate` 1.0 [0,1e6]; `plants.upkeep` 0.2 [0,1e6]; `plants.water_min` 0.1 [0,1]; `plants.water_optimum` 0.5 [0,1]; `plants.generalist_cost` 0.3 [0,1]; `plants.stress_damage` 0.1 [0,1]; `plants.heal_rate` 0.05 [0,1]. Existing `plants.resource_cap`, `plants.resource_regen` are now used. `plants.max_per_cell` stays reserved for placement (TASK-012).

## Consequences
- TASK-012 places offspring and spends plant energy; TASK-014 removes plant energy by grazing (could later add a root reserve). Grazing must not add energy to R.
- TASK-022 snapshot/hash must include `CellResources` and `PlantLedger`.
- Default founders (opt 10 °C, tol 16 °C) cannot grow at the poles or at the hottest equator cells; this is intended niche structure; balance is tuned in TASK-027.

## Alternatives considered
- First-come uptake in shuffled acting order: order-dependent and consumes RNG; rejected for fair share.
- Separate water and nutrient pools: more parameters without a needed behaviour; rejected.
- Climate-dependent cap: regen scaled by moisture already gives drier cells a lower carrying capacity.

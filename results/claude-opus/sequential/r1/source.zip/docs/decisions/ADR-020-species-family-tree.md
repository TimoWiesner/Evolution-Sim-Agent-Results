# ADR-020: Species classification, naming and family tree

## Status
Accepted — 2026-11-22 — TASK-017 (refines the species rule of ADR-004).

## Context
TASK-017 needs: every organism in a species of its kind, a documented genetic-distance rule,
deterministic IDs/names, new species when a lineage has diverged far enough (with a tested
boundary), records with parent species / origin tick / extinction tick, and a query of the
number of living species per kind at any tick. ADR-004 already fixed the direction:
fixed representative genome per species, classification once at birth, `d == T` stays.
Genomes and `genome::distance` (weighted mean absolute gene difference in `[0, 1]`) exist
(ADR-012). Config keys `plants|herbivores|carnivores.species_threshold` (default 0.15)
already exist.

## Alternatives considered
- **A. Periodic re-clustering** (k-medoids/DBSCAN every K ticks): follows drift, but labels
  flicker, O(N²), parameter-sensitive, IDs not stable. Rejected (ADR-004).
- **B. Re-classify every organism against its species representative every tick**: would move
  living organisms between species (unstable membership, many extinction/revival edge cases).
  Rejected.
- **C. Moving representative (species mean genome)**: follows drift so species never split by
  drift alone; costs a per-tick mean and makes the rule depend on the whole population. Rejected.
- **D. Founder-representative classification at birth, with daughter-species reuse (chosen).**

## Decision
**Representative.** Each species stores the genome of its first member (founder or the
newborn that founded it) as its immutable representative `rep(S)`.

**Threshold.** `T_kind = <kind>.species_threshold` (default 0.15 for all kinds; no ordering against
the animal `mating_threshold` 0.2 is enforced). Rationale: founder jitter
(`founder_variation` 0.02) gives founder–founder distances ≈ 0.02, so all founders of a kind
start as one species; with mutation rate 0.05 / strength 0.05 the per-generation drift of the
mean absolute gene difference is ≈ 0.002, so a split needs on the order of tens of generations
of directional drift — rare but reachable in long runs. TASK-027 may tune it.

**Classification rule (THE species rule).** Done exactly once, when the organism is created;
never re-assigned (stable membership, stable IDs).
1. *Founder* (tick 0, processed in ascending EntityId order per kind): joins the first root
   species of its kind (ascending SpeciesId) with `distance(g, rep) ≤ T_kind`; otherwise it
   founds a new root species (`parent = None`). With default founder variation this yields
   exactly one root species per non-empty kind.
2. *Newborn* (Births phase, in request order): let `M` = species of the first stored parent
   (`Parents::One(m)` / `Parents::Two(m, _)`; plants: the seed mother, animals: the initiating
   parent of the mating). Then
   - `distance(child, rep(M)) ≤ T_kind` → joins `M` (**exactly at the threshold stays**);
   - else the child joins the first *living* daughter species `D` of `M` (ascending SpeciesId,
     `D.parent == M`, `D.living > 0`) with `distance(child, rep(D)) ≤ T_kind`;
   - else the child founds a new species `N` with `parent = M`, `rep(N) = child genome`,
     `origin_tick = birth tick`.
   The daughter-reuse step keeps one divergence event (e.g. a litter or a seed burst of a
   diverged mother) from founding several sibling species.
3. The rule draws no random numbers; the simulation trajectory is unchanged by species
   bookkeeping (existing regression values stay valid).

**Extinction.** Every species keeps a living-member counter (increment on creation, decrement
in `Population::kill`, the single death path). When it reaches 0 the record gets
`extinct_tick = tick of that kill`. A species with 0 living members can never gain members
again (newborns need a living parent; daughter reuse only considers living species), so
extinction is final. A species may originate and go extinct in the same tick.

**IDs.** `SpeciesId(u32)`, one global sequential counter from 1 across all kinds, in creation
order (founders: plants, herbivores, carnivores by EntityId; then births in resolution order).
Deterministic because creation order is.

**Names.** Pure function of `(kind, root species ID, species ID)`: binomial
`"<Genus> <epithet>"`, genus = syllable word of the *root ancestor's* ID + kind suffix
(`-ia` plants, `-odon` herbivores, `-raptor` carnivores, capitalised), epithet = syllable
word of the species' own ID (bijective base-N encoding of the ID over a fixed syllable table,
lowercase). Descendants share the genus of their root lineage, so names show kinship. A short
code `P<id>` / `H<id>` / `C<id>` is also provided.

**Queries.** `SpeciesRegistry::living_count(kind)` (O(1), current state at any tick between
steps or inside a phase hook) and `living_count_at(kind, t)` from the records (end-of-tick
semantics: `origin ≤ t` and (`extinct` is None or `extinct > t`)), plus `get(id)`, `iter()`,
`of_kind(kind)`, `lineage(id)` (ancestors up to the root).

**Ownership.** The registry lives inside `Population` (it creates and kills every organism),
so checkpoints/restores (`Simulation::set_population`, TASK-022) carry it automatically and
`Population::validate` checks its consistency.

## Consequences
- Species reflect divergence from the species founder, not current population structure; a
  slowly drifting species keeps its ID until a newborn exceeds `T` (budding). Accepted.
- Two parents from different species may mate (animals: `mating_threshold` 0.2 > 0.15); the
  child is classified via the first parent's species. Documented.
- The Species phase emits `SpeciesAppeared` / `SpeciesExtinct` events from the registry's
  per-tick journal; `Population` must not consume RNG for this.

## Verification
Unit tests in `species/tests.rs` (rule, boundary `d == T` joins, `d = next_up(T)` splits,
daughter reuse, names/IDs deterministic, extinction tick, living counts) and simulation tests
(forced divergence run, same-seed runs produce identical registries, living count per kind
equals distinct species of living organisms at every tick).

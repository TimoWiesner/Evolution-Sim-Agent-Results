# ADR-016: Animal sensing, movement, movement cost and the cell-sharing rule

Status: Accepted (TASK-013 PLAN cycle 1)

## Context
TASK-013 must let herbivores and carnivores perceive organisms within a trait-derived vision range (also across the wrapping edges), move cell to cell with a per-tick distance limited by the speed trait, pay energy for moving (faster/further costs more), take the shortest (wrap-aware) way to a target, obey one documented cell-sharing rule applied everywhere, and keep the spatial index in sync. Owed decisions: movement when nothing interesting is in sight; the cell-sharing rule. What animals do on arrival (eat, attack, mate) belongs to TASK-014..016, which plug into the API below.

Existing facts: `Traits::speed ∈ [0, <kind>.max_speed]` (= max_speed·gene, founder gene 0.5 → herbivore 1.0, carnivore 1.5 cells/tick), `Traits::vision ∈ [0, <kind>.max_vision]` (founder gene 1.0 → 6 / 8 cells); keys `<kind>.move_cost` ("energy per cell moved"); topology metric = toroidal Chebyshev (ADR-007), shortest `Torus::offset` with tie at n/2 → positive; moves only via `Population::move_organism` (ADR-013); `plants.max_per_cell` capacity for plants (ADR-015).

## Decision

### Perception (`animals::sense`)
- Vision radius `r = floor(traits.vision)` cells (u32), Chebyshev on the torus. `perceive(pop, id) -> Perception { center, radius, seen: Vec<Neighbour> }` = `pop.within(center, r, None)` minus the animal itself; living organisms only, ordered by (distance, id) (ADR-013 order). Wrap-awareness comes from the spatial index (`Neighbour.offset` is the shortest displacement). Vision 0 → own cell only. Helpers: `of_kind(kind)`, `nearest(kind)`.
- Sensing draws no RNG and has no energy cost.

### Speed → steps per tick (deterministic stride)
- Each animal stores `stride: f64 ∈ [0,1)` (new `Organism` field, 0 for founders/newborns). At its turn: `budget = stride + speed`, `allowed = min(floor(budget), max_speed_cfg)`, `stride ← budget − floor(budget)` (fraction carried; unused whole steps are lost, not banked). Hence steps per tick ≤ `ceil(speed)` and the long-run mean of `allowed` equals `speed`. No RNG.

### Movement cost
- The i-th step within one tick costs `move_cost · (1 + sprint_cost · (i − 1))`; k steps cost `C(k) = move_cost · (k + sprint_cost · k(k−1)/2)`. Further (more cells) costs more; faster (more cells in the same tick) costs more per cell when `sprint_cost > 0`. New keys `herbivores.sprint_cost`, `carnivores.sprint_cost` (default 0.5, range [0, 100]).
- A step is taken only if `energy ≥` its marginal cost; it is paid with `spend_energy`. Energy never goes negative; an animal that cannot pay stops. Spent movement energy leaves the system (heat), recorded in a per-tick `MoveTick { steps, energy_spent, blocked }` summary.
- Resting metabolism is not part of this ADR (TASK-014/015).

### Shortest way to a target
- `step_towards(from, to)`: `o = torus.offset(from, to)`, preferred direction `(signum o.dx, signum o.dy)`; every such step lowers the toroidal Chebyshev distance by exactly 1, so `d` steps reach a target at distance `d` — optimal, crossing an edge whenever the wrapped offset is shorter. If the preferred cell has no room (cell-sharing rule), alternatives that also lower the distance by 1 are tried in fixed order (when `|dx| > |dy|`: `(sx,0),(sx,+1),(sx,−1)`; when `|dy| > |dx|`: `(0,sy),(+1,sy),(−1,sy)`; exact diagonal `|dx|=|dy|`: only `(sx,sy)` lowers the distance, so no alternative); none free → the animal waits (path is never lengthened). `move_towards(pop, torus, id, target_cell, max_steps, stop_at, costs) -> MoveOutcome` repeats single steps until distance ≤ `stop_at`, the step budget, energy or room runs out (`stop_at = 1` lets callers stop adjacent).
- `move_away(from, threat)` (for TASK-014 flight) = step in the opposite direction of the shortest offset; provided, not used by the default policy.

### Movement when nothing interesting is in sight (owed decision)
- Correlated random walk: each animal stores `heading: Option<Dir8>` (new `Organism` field, `None` at birth). When wandering: if `heading` is `None` or `rng.chance(WANDER_TURN_CHANCE = 0.25)` → `heading = Dir8::ALL[rng.below(8)]`; then take **at most one** step (`min(1, allowed)`) in `heading`; if that cell has no room, draw a new heading (no step this tick). Rationale: persistent headings explore/migrate away from depleted areas much better than a pure random walk (displacement ~ linear instead of √t over short horizons), one step keeps idle energy cost low (no sprint premium), and the RNG use is small and deterministic.

### Default policy in TASK-013 (replaced/extended by TASK-014/015)
- "Interesting" = nearest visible food kind (herbivore → plant, carnivore → herbivore) by (distance, id). If distance ≤ 1: stay (arrival handled by later tasks). Else `move_towards(target, allowed, stop_at = 1)` (reach own or adjacent cell, the later feeding/attack reach). Otherwise wander. `heading` is kept unchanged while chasing.

### Cell-sharing rule (owed decision, single rule)
> **Organisms of different kinds may always share a cell. Organisms of the same kind may share a cell up to a per-kind capacity `cap(kind)`: `plants.max_per_cell` (default 4), new `herbivores.max_per_cell` (default 4), new `carnivores.max_per_cell` (default 2). Nothing may make an organism enter a cell (move step, birth, seed, founder placement) that already holds `cap(kind)` living organisms of its kind.**
- Implemented once: `organism::CellCapacity { plants, herbivores, carnivores }` (`from_config`, `of(kind)`), stored in `Population` (set by `founders`; `set_capacity`), `Population::has_room(cell, kind) -> bool` (counts living same-kind organisms in the cell via the index). Used by: movement steps (`animals`), `resolve_births` (final guard: request whose cell is full is dropped, like a request with a dead parent; parents' energy is lost; counter `births_dropped_full`), plant seeding (`plants::site_ok` switches to the shared capacity, keeping its accepted-seeds-this-tick count), founders (drawn cell full → deterministic row-major probe from it to the next cell with room; no extra RNG draws, so positions are unchanged whenever no cell overflows).
- Single exception, only reachable through input: if `initial.<kind> > cap(kind)·W·H`, the surplus founders are placed at their drawn cell (documented overload; dynamics can never create it). Not rejected as a config error because the contract accepts any `initial.* ≥ 0`.
- Rationale: different kinds must meet in one cell (grazing, attacks from the same cell); a same-kind cap is a local crowding mechanism allowed by PROJECT.md (density dependence, carnivore spacing) and prevents degenerate stacking. Moving into a full cell is refused rather than swapped, so order effects are limited to the shuffled acting order (ADR-008).

### Phases / RNG
- Herbivores phase: `animals::act_all(ctx, Kind::Herbivore)`; Carnivores phase: same for carnivores. Actors = `acting_order(alive_ids(kind), rng)` (one shuffle draw sequence per phase), each re-checked with `get_alive`. RNG draws: shuffle + wander draws. This changes the core RNG stream (and hashes) of every run with animals; runs without animals are unchanged.

## Consequences
- `Organism` gains `heading`, `stride` (TASK-022 snapshot must serialise them; `validate` checks `stride ∈ [0,1)`).
- New keys: `herbivores.max_per_cell`, `carnivores.max_per_cell`, `herbivores.sprint_cost`, `carnivores.sprint_cost`; docs/CONFIG.md regenerated.
- TASK-014/015/016 reuse `perceive`, `move_towards`, `move_away`, `wander`, `steps_allowed`, `has_room`; TASK-016 must place newborns in a cell with room (or accept the drop at resolve).

## Alternatives rejected
- Unlimited sharing for animals: simplest, but no local crowding and an inconsistent rule vs plants.
- One organism per cell (exclusive): breaks grazing/attacks in the same cell and makes movement conflicts dominate.
- Probabilistic fractional speed (`floor + chance(frac)`): extra RNG draws and noisier limits; the stride gives the same mean deterministically.
- A* / BFS pathfinding: unnecessary — there are no obstacles except full cells, and greedy Chebyshev steps are already optimal.
- Euclidean vision disc: inconsistent with the project-wide Chebyshev metric used by index and movement.

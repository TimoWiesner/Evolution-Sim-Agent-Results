# ADR-025: Checkpoints (`evosim run --save/--load`)

## Status
Accepted — 2026-11-23 — TASK-022 (PLAN cycle 1).

## Context
Contract §2/§5.2: `--save FILE` writes the complete state after the last tick; `--load FILE` continues from it, `--ticks`
counting additional ticks; `A` ticks + save + load + `B` ticks must give the same `final`, `totals` and `state_hash` as
`A + B` uninterrupted ticks. An invalid checkpoint → exit 2, stderr message, no result file (§5.4). Our decisions: file
format and compression. ADR-022 fixes what "complete state" means: exactly the set hashed by `Simulation::state_hash()`
(config incl. seed, tick, RNG, ID counter, torus, weather lattices, current climate grid + `climate_tick`, resources,
all organisms with every field incl. genome/heading/stride/handling/cooldown/species, pending births, `LifeTotals`,
`births_dropped_full`, tick death/birth buffers, species registry incl. journal, all ledgers, `last_moves`, `TickStats`).
Only derived caches are excluded: `ClimateMap`, `ClimateBounds`, `Expression`, `SpatialIndex`, `CellCapacity`.

## Decisions

### 1. File format: one UTF-8 JSON document, serde-derived body
```json
{"format":"evosim-checkpoint","version":1,"engine":"<evosim VERSION>","tick":T,"state_hash":"<64 hex>",
 "config":{...Config::to_json_value()...},"state":{...}}
```
- `format` + `version` (integer, currently `CHECKPOINT_VERSION = 1`) are read **first** from a generic
  `serde_json::Value`; a different `format`, missing/non-integer/other `version` → `SnapshotError::Version` (exit 2) before
  the body is interpreted. `engine` is informative only (not checked; a different build may still load if the format
  version matches — the hash check below catches incompatibilities).
- `config` uses the existing validated path `Config::from_value` (unknown keys/ranges rejected).
- `state` is the serde serialisation of a DTO `snapshot::StateDto` built by **exhaustive destructuring** of
  `Simulation`, `World`, `Population` and `SpeciesRegistry` (same pattern as `hash_state`: adding a field to one of these
  owners is a compile error until the snapshot decides it). Leaf types get `#[derive(Serialize, Deserialize)]`
  (Organism, Traits, Genome, Parents, Kind, Dir8, Cell, EntityId, SpeciesId, SpeciesRecord, SpeciesChange, BirthRequest,
  BirthRecord, DeathRecord, DeathCause, LifeTotals, Torus, Weather, PeriodicNoise, CellNow, CellResources, RngState,
  IdAllocator, PlantLedger(+ticks), HerbivoreLedger/FeedTick, HuntLedger/HuntTick, ReproLedger, MoveTick, TickStats,
  ... whatever the compiler asks for). Private fields stay private; derives see them.
- Dependency: `serde = { version = "1", features = ["derive"] }` in evosim-core. `serde`, `serde_derive`, `syn`, `quote`,
  `proc-macro2` are already in `Cargo.lock` (via `serde_core`) and in the local cargo cache; PLAN verified an offline
  build of a derive + `float_roundtrip` probe (f64/f32/Option/arrays round-trip exactly). `Cargo.lock` gains only the
  edge `evosim-core → serde` (regenerate with `cargo build --offline`, then `--locked` works again).
- Floats: `serde_json` with `float_roundtrip` writes the shortest round-trip text for f64 and f32 → bit-exact restore.
  Non-finite floats would be written as `null` and fail to load; the state never contains them (sanitised by the rules),
  and the save self-check (§3) turns any such surprise into a clean exit 2 instead of a broken file.
- Restore: `Simulation::from_checkpoint` builds `World::from_config(&config)` (regenerates the derived caches
  `ClimateMap`/`ClimateBounds`, `Expression`, `CellCapacity`), then overwrites every saved field, rebuilds the spatial
  index with `Population::rebuild_index` (the index is canonical — buckets sorted by ID, `BTreeMap` locator — so a rebuild
  equals the incrementally maintained one), and runs `Population::validate` and `SpeciesRegistry` consistency checks.
  `now`/`climate_tick` are restored verbatim (not recomputed), so tick-0 checkpoints and mid-run checkpoints behave alike.

Alternatives rejected:
- *Hand-written JSON per type*: ~40 leaf types, error-prone, no gain over derive.
- *Custom binary format*: smaller/faster, but needs its own reader/writer and versioning; not human-inspectable; checkpoints
  are written once per run, so speed is irrelevant.
- *Debug text (like the hash)*: not parseable without a parser.

### 2. Compression: none
Plain JSON, no gzip. Reasons: no new dependency (no flate2/miniz download), checkpoints stay inspectable and diffable,
write/read cost is negligible against simulation time; size for the contract example is expected to be a few MB
(IMPLEMENT measures and records it in docs/CHECKPOINTS.md). Users can gzip externally; a later format version may add
compression behind the same `version` field.

### 3. Integrity: stored state hash, verified on load and after save
`state_hash` in the file is `sim.state_hash()` at save time. On load, after full restore, the hash is recomputed; a mismatch →
`SnapshotError::Integrity` (exit 2). This detects damaged-but-still-valid JSON (edited digit, swapped values) and any
incomplete restore (a field not round-tripped), because the hash covers the complete state. On save, the CLI decodes the
produced text again and compares hashes before writing (self-check); failure → exit 2, nothing written.

Error classes (`snapshot::SnapshotError`, Display gives a one-line message): `Io` (missing/unreadable), `Parse` (not JSON,
truncated, not UTF-8), `Version` (wrong `format`/`version`), `Invalid` (missing/ill-typed fields, config errors,
`SimError` from restore/validation), `Integrity` (hash mismatch). All map to exit 2 in the CLI.

### 4. CLI
- `evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--metrics FILE] [--save FILE]`
- `evosim run --load FILE --ticks N --out FILE [--sample-every K] [--metrics FILE] [--save FILE]`
- Exactly one of `--config`/`--load`; `--seed` with `--load` → exit 2 (the seed is part of the saved state). Each flag at
  most once, non-empty paths, `--save` must differ from `--out` and `--metrics` (path and canonical-path check);
  `--save` equal to `--load` is allowed (the load is fully read first). `--save` parent directory checked before the loop.
- The checkpoint is loaded and validated completely before the loop; on any error nothing is written.
- After the loop: build result text, metrics text, checkpoint text (+ self-check); then write checkpoint, result,
  metrics atomically (`io::write_atomic`); if a later write fails the earlier files of this invocation are removed → no
  result file on error.
- `tick_start` = loaded tick; `totals` cumulative (LifeTotals is in the checkpoint); series/extinction_tick relative to this
  invocation (ADR-022 already supports a non-zero start).

## Consequences
- New core module `snapshot` (`mod.rs`, `tests.rs`): `CHECKPOINT_FORMAT`, `CHECKPOINT_VERSION`, `SnapshotError`,
  `to_json_string(&Simulation) -> Result<String, SnapshotError>`, `from_json_str(&str) -> Result<Simulation, SnapshotError>`
  (+ `Simulation::checkpoint_json()` / `Simulation::from_checkpoint_json()` thin wrappers usable by the UI in TASK-024).
- `Simulation::resume` (TASK-005 placeholder) stays for its existing tests or is reimplemented on top of the snapshot.
- Any new state field forces both a hash and a snapshot decision at compile time.
- Checkpoints are only guaranteed to load on the same `CHECKPOINT_VERSION`; rule changes keep loading but continue
  under new rules (the stored hash still matches because the hash covers data, not rules).

## Verification
Core: round-trip equality (`state_hash` equal, `Debug` equal) at ticks 0, mid-run and after extinction; save at A then
continue B == uninterrupted A+B (`state_hash`, totals, counts) for A ∈ {0, 1, 37, 200} on a small world with all kinds
alive, weather enabled, carnivores with handling/cooldown, species splits (forced mutation config); version/format errors;
truncated text at many cut points; mutated digit → Integrity; missing field → Invalid. CLI integration: two-step vs
one-step `run` comparing `final`/`totals`/`state_hash` for split points 0 and 40 (and 0-tick load); error matrix
(missing, empty, garbage, truncated, wrong version, wrong format, tampered hash/organism value, `--load` + `--config`,
`--load` + `--seed`, `--save` == `--out`, `--save` into missing dir) → exit 2, stderr non-empty, no result/save file.
End-to-end in `scripts/check-entrypoints.sh`: `./evosim run` save/load equality on the contract example.

## IMPLEMENT notes (TASK-022 cycle 1)
- `Population` (and `SpeciesRegistry`, `Organism`, ledgers, …) derive `Serialize/Deserialize` directly; the three
  Population caches (`expression`, `index`, `capacity`) are `#[serde(skip)]` and rebuilt by
  `Population::restore_caches`. Only `World` uses a DTO (`sim::world::WorldState`, built by exhaustive destructuring in
  `World::snapshot_state`) because its caches (`ClimateMap`, `ClimateBounds`) have no meaningful default. Weather is stored
  as `WeatherState` (lattice values) and restored through `Weather::restore` (length/finite checks).
  `Simulation::{parts, from_parts}` (crate-internal, exhaustive destructuring) feed the snapshot module.
- Write order changed from "save → out → metrics" to "out → metrics → save" so that with `--save` == `--load` a failure
  never deletes the previous checkpoint (rollback removes only files written by this invocation).
- Measured size/timing: docs/CHECKPOINTS.md.

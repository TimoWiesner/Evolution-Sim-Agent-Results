# ADR-023: Metrics and evolution analytics

## Status
Accepted — 2026-11-23 — TASK-020 (PLAN cycle 1).

## Context
TASK-020 must record, at every sample tick: population per kind, births and deaths per kind, deaths by cause, living
species per kind, mean and spread of every trait per kind, highest and mean generation. Recording must not change
`state_hash`, must be writable to a file from the command line, the format must be documented, and tests must check the
values against a hand-verifiable world. Charts (TASK-025) and run comparison (TASK-021) will consume the data later.

Existing pieces: `report::run_recorded` (exact-N loop, series at `tick_start`, every K, `tick_end`), `LifeTotals`
(cumulative initial/births/deaths/deaths_by_cause per kind), `SpeciesRegistry::{living_count, of_kind}`,
`Organism::{traits, generation, energy, age}`, `Traits` (11 fields). The core source scan forbids hashed collections
and wall-clock tokens in core.

## Decisions

### 1. Sampling ticks = series ticks
A metrics sample is taken at exactly the ticks of `series` (contract §4 rule: `tick_start`, every K, `tick_end`, no
duplicates). One sampling rule for both, so `metrics.samples[i].tick == series[i].tick` and `count` equals the series
count. `run_recorded` gains an observer: `report::run_observed(sim, ticks, k, |&Simulation| ...)`; `run_recorded` becomes
`run_observed` with a no-op observer (behaviour unchanged).

### 2. Read-only recorder in a new core module `metrics`
`metrics::MetricsRecorder` keeps only its own data (`Vec<Sample>` and the previous `LifeTotals` copy for interval
deltas). `record(&mut self, sim: &Simulation)` takes `&Simulation` — the borrow checker guarantees it cannot change
simulation state, it draws no RNG and allocates no `EntityId`. It is **not** stored inside `Simulation`, so the state
stream of ADR-022 is untouched. A test and an end-to-end check still compare `state_hash` (and the whole result minus
timing) with and without recording.

### 3. Contents of one sample (per kind)
- `count`: living individuals.
- `births`, `deaths`: in the interval since the previous sample (exclusive) up to this tick (inclusive); 0 at the first
  sample. `births_total`, `deaths_total`: cumulative since tick 0 (`LifeTotals`, so also correct after a checkpoint load).
- `deaths_by_cause` (interval) and `deaths_by_cause_total` (cumulative): object `cause name → count` with all six causes
  of `DeathCause::ALL` (`old_age, starvation, injury, predation, grazed, climate`), zeros included.
- `species`: `living` (= `living_count`, same as `final.species` at the end), plus further metrics `appeared_total`
  (species records of the kind ever created) and `extinct_total` (records with `extinct_tick`).
- `generation`: `max` (integer) and `mean` over living individuals.
- `traits`: every field of `Traits` for every kind — `speed, strength, fertility, max_health, max_lifespan, max_energy,
  vision, aggression, caution, temp_optimum, temp_tolerance` — each `{mean, sd, min, max}`. Kinds share one schema;
  traits that are constant for a kind (plants: speed/vision/aggression/caution = 0) simply report sd 0.
- Further metrics (our decision): `energy` and `age` as `{mean, sd, min, max}` of the living individuals (condition and
  age structure; cheap, useful for TASK-025 charts).

Spread = **population standard deviation** `sqrt(Σ(x−mean)²/n)` (describes the living population itself, not an
estimate; n = 1 gives 0 instead of undefined). Computed in f64 with two passes (mean, then squared deviations) over the
living organisms in `EntityId` order → deterministic. With `count = 0` every statistic (`mean, sd, min, max`,
generation `max`/`mean`) is JSON `null` (no fake zeros for an extinct kind).

### 4. File format: one JSON document, written by `--metrics FILE`
`evosim run ... --metrics FILE` (extra option, our decision; the result JSON stays unchanged so contract results stay
small — 100 samples × 3 kinds × 13 statistics groups would add ~0.3 MB to every result and every batch file).
JSON (not CSV): nested per-kind/per-trait structure without column explosion, same tooling as the result, readable by
Python `json` and the browser UI (TASK-025). Rejected: extra result keys (size, see above), CSV (≈ 250 columns, nested
cause/trait groups flattened), JSON Lines (no header object). Document layout:

```json
{
  "format": "evosim-metrics", "format_version": 1,
  "seed": 42, "tick_start": 0, "tick_end": 1000, "sample_every": 10,
  "kinds": ["plants", "herbivores", "carnivores"],
  "traits": ["speed", "strength", "..."],
  "death_causes": ["old_age", "starvation", "injury", "predation", "grazed", "climate"],
  "samples": [
    { "tick": 0,
      "plants": { "count": 400, "births": 0, "deaths": 0, "births_total": 0, "deaths_total": 0,
                  "deaths_by_cause": {"old_age": 0, "...": 0}, "deaths_by_cause_total": {"old_age": 0, "...": 0},
                  "species": {"living": 1, "appeared_total": 1, "extinct_total": 0},
                  "generation": {"max": 0, "mean": 0.0},
                  "traits": {"speed": {"mean": 0.0, "sd": 0.0, "min": 0.0, "max": 0.0}, "...": {}},
                  "energy": {"mean": 0.0, "sd": 0.0, "min": 0.0, "max": 0.0},
                  "age": {"mean": 0.0, "sd": 0.0, "min": 0.0, "max": 0.0} },
      "herbivores": {}, "carnivores": {} }
  ]
}
```

The file is written like `--out`: validated before the loop (parent directory exists, not a directory, path differs
from `--out`), written to a temp file next to it and renamed after the result succeeded; on any error exit 2, neither
file is left behind. The user-facing reference is `docs/METRICS.md`; README links it.

### 5. Placement
`crates/evosim-core/src/metrics/{mod.rs, tests.rs}`: `Stat` (`of(values) -> Option<Stat>`), `KindSample`, `Sample`,
`MetricsRecorder::{new, record, samples, to_json(&RunRecord, seed)}`, `TRAIT_NAMES`, `trait_values(&Traits) -> [f64; 11]`
(`max_lifespan` as f64). It depends on `sim`, `organism`, `species`, `report::KIND_KEYS` (read-only). CLI wiring in
`crates/evosim-cli/src/run.rs`. `batch` (TASK-021) and the UI (TASK-025) can reuse `MetricsRecorder`.

## Consequences
- One extra pass over living organisms per sample: default 100–101 samples per run, O(N·13) each → negligible
  (measure contract example 1000 ticks with/without `--metrics`).
- Adding a `Traits` field requires adding it to `trait_values`/`TRAIT_NAMES` (destructure `Traits` exhaustively in
  `trait_values` so it is a compile error otherwise).
- `metrics.samples` and `series` share ticks; consumers can join them by index.

## Verification
Unit: `Stat::of` on hand values (`[1,2,3]` → mean 2, sd √(2/3), min 1, max 3; single value → sd 0; empty → None).
Hand world: small `Simulation` with hand-placed organisms of known traits/generations, kills with known causes and
births between samples; expected numbers written in the test by hand. Hash: same seed with and without recorder → equal
`state_hash`; CLI integration + `scripts/check-entrypoints.sh`: `run` with and without `--metrics` → identical result
(except timing), metrics file valid, sample ticks equal series ticks, `count` equals series counts; error matrix for
`--metrics` (missing value, repeated, missing parent dir, same as `--out`) → exit 2, no files.

## IMPLEMENT notes (TASK-020 cycle 1)
- Implemented as planned. Hand world uses `founder_variation = 0` for all kinds, so founders of a kind share one
  genome and form exactly one species → species numbers are hand-checkable (1 living at start; carnivore 0 living,
  1 extinct after its death).
- The metrics file is written compact (single line, `serde_json::to_string`), the result stays pretty-printed:
  ≈ 0.5 MB for the contract example 1000 ticks. Object keys come out alphabetically (serde_json default map);
  docs/METRICS.md states key order is not significant.
- `--metrics` equal to `--out` is rejected both as the same string (parse) and as the same file after
  canonicalising the parent directory (e.g. `dir/./out.json`).
- Measured: contract example 1000 ticks 0.835 s without, 0.865 s with `--metrics` (≈ +4 %), same `state_hash`.

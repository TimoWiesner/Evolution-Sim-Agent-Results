# ADR-008: Clock, random number API and tick scheduler

## Status
Accepted — 2026-11-22 — TASK-005 (plan). Refines ADR-005 (finalises the tick phase order and the organism acting order that ADR-005 left to TASK-005).

## Context
TASK-005 builds the frame every later feature plugs into: one `Simulation` holding tick counter, RNG and world, advanced by exactly one tick per `step()`. Requirements: all randomness from the config seed, no wall clock / global RNG; fixed, documented order of phases and of organisms with a stable tie rule; exact RNG state export/restore (checkpoints, TASK-022); same-seed traces identical over ≥100 ticks, different seeds differ; core independent of UI. Climate/plant/animal behaviour is out of scope; their phases exist as empty slots.

## Alternatives considered
### Random algorithm
- **A. `rand`/`rand_xoshiro` crates** — convenient, but `StdRng` is not value-stable across versions and adds dependencies (rejected in ADR-005).
- **B. PCG64 (in-crate)** — good quality, 128-bit state; needs 128-bit multiply, slightly slower, no advantage for us.
- **C. xoshiro256\*\* seeded via SplitMix64 (chosen, as ADR-005)** — 4×u64 state, integer-only, published reference vectors.

### Organism acting order
- **A. Ascending `EntityId` every tick** — simplest, but systematically favours old organisms (they always eat/mate first), a population-structure bias.
- **B. Per-tick Fisher–Yates shuffle with the core RNG of the EntityId-sorted list (chosen)** — fair over time, still a pure function of (RNG state, set of IDs); costs one draw per organism per acting phase (~2 µs at 2 000 organisms).
- **C. Random priority keys sorted with EntityId tie-break** — same fairness, O(n log n), needs a tie rule; B is simpler.

### Representation of steps
- **A. Trait objects / registered systems list** — flexible, but order becomes data that can be changed at runtime; harder to audit.
- **B. Static `Phase` enum + `Phase::ORDER` constant + `match` dispatch in `Simulation::step` (chosen)** — order visible in one place, testable, zero overhead. A diagnostic hook (`step_with`) lets tests inject behaviour after each phase without changing the order.

### Representation of events
- **A. Direct mutation only, no events** — loses an observable trace for tests/UI.
- **B. Typed `Event` records appended to a per-tick `TickReport` in emission order (chosen)** — deterministic, cheap, consumed by tests now and by metrics/UI later (births, deaths, extinctions added by TASK-008+).

## Decision
**RNG (`evosim_core::rng`).** `Rng` = xoshiro256\*\*; `Rng::seed_from_u64(seed)` fills the state with 4 consecutive SplitMix64 outputs (an all-zero result, practically impossible, is replaced by SplitMix64 of `seed ^ 0x9E3779B97F4A7C15` continuing — must be documented in code). Draws: `next_u64`, `next_u32` (upper 32 bits), `next_f64` ∈ [0,1) (`(x >> 11) * 2^-53`), `next_f32` ∈ [0,1) (`(x >> 40) * 2^-24`), `below(n)` unbiased (Lemire multiply-shift with rejection; `n = 0` panics), `range_u32(lo, hi)` / `range_i64(lo, hi)` inclusive, `range_f64(lo, hi)`, `chance(p)` (= `next_f64() < p`; p ≤ 0 never, p ≥ 1 always, still consumes one draw), `normal(mean, sd)` Box–Muller with **no cached spare** (two draws per call, state remains exactly 4 words), `shuffle(&mut [T])` Fisher–Yates from the end (`i` from len-1 down to 1, `j = below(i+1)`), `choose_index(len) -> Option<usize>`. Export/restore: `RngState { s: [u64; 4] }` (`Copy`, `Eq`), `Rng::state()`, `Rng::from_state(RngState) -> Result<Rng, RngError>` (all-zero rejected), `RngState::to_hex()` (64 lowercase hex chars, words big-endian in order s0..s3) and `RngState::from_hex(&str) -> Result<RngState, RngError>`; JSON checkpoints use the hex string (no u64-through-f64 precision risk). `Rng` has no `Default` and no constructor without a seed or state.

**Clock.** `Simulation.tick: u64` = number of completed ticks. `step()` processes tick `t = self.tick` (phases see `t`), then sets `tick = t + 1` (checked; overflow panics). Seasons/weather later derive from `t`.

**Tick phase order (fixed).** `Phase::ORDER`:
1. `Climate` — season / weather update (TASK-006/007)
2. `Resources` — cell resources regenerate (TASK-011)
3. `Plants` — growth, ageing, seeding (TASK-011/012)
4. `Herbivores` — sense, move, eat, mate (TASK-013..016)
5. `Carnivores` — sense, move, hunt, mate (TASK-015..016)
6. `Births` — reproduction resolution; newborns get IDs in event-emission order and are appended (act from next tick)
7. `Deaths` — organisms flagged dead during the tick are removed by order-preserving compaction
8. `Species` — species bookkeeping, extinction ticks (TASK-017)
9. `Statistics` — counters / series sampling (TASK-018)

then `tick += 1`. External commands (UI edits, pause, reset) are applied only between `step()` calls, never inside.

**Organism acting order and ties.** Inside an acting phase (Plants, Herbivores, Carnivores) the live organisms of that kind are taken in ascending `EntityId` (unique, `u64`, monotonically allocated by `IdAllocator`, never reused) and permuted once per phase per tick by `Rng::shuffle` (`sim::schedule::acting_order`). Organisms flagged dead earlier in the tick are skipped. Conflicts (two actors wanting the same food/cell/mate) go to the actor earlier in the acting order. Any other ordering by a key (distance, energy, …) breaks ties by ascending `EntityId`, and for cells by `Cell` order `(y, x)`. Births/Deaths/Species/Statistics phases process in ascending `EntityId` without shuffle. Determinism therefore depends only on RNG state and the ID set.

**Events.** `Event { tick: u64, phase: Phase, kind: EventKind }`, `EventKind` initially `Probe { value: u64 }` (diagnostic), extended by later tasks (`Born`, `Died`, `SpeciesExtinct`, …). `step()` returns `TickReport { tick, phases: Vec<Phase> (phases run, = ORDER), events: Vec<Event> }` in emission order.

**World.** `sim::World` currently holds the `Torus` built from `config.world`; climate, cells and organisms are added by later tasks. `Simulation { config, tick, rng, world, ids: IdAllocator }`, constructed with `Simulation::new(config) -> Result<_, SimError>` (RNG = `seed_from_u64(config.seed)`), restorable with `Simulation::resume(config, tick, RngState, next_id) -> Result<_, SimError>` (TASK-022 extends with full world state).

## Rationale
### Performance
One xoshiro draw ≈ 1 ns; shuffling 2 000 indices per acting phase ≈ 2–4 µs per tick, negligible against the 10 ms/tick budget (100 ticks/s). Static `match` dispatch, no allocation beyond reusable buffers.

### Testability
Golden vectors pin SplitMix64 and xoshiro256\*\*; statistical sanity tests for `below`/`next_f64`/`normal`; export→restore→continue equality; phase-order test via `TickReport.phases`; trace tests over ≥100 ticks via `step_with` probes that draw from the simulation RNG; source scan forbids wall clock / global RNG / `HashMap` in core.

### Self-contained dist/
No new crates; pure integer RNG code compiled into the binary.

## Consequences
- Every feature module gets `&mut Rng` explicitly from `Simulation`; no other RNG exists.
- Later tasks fill phase slots in `Simulation::run_phase`, never reorder `Phase::ORDER` without superseding this ADR.
- Shuffle consumes RNG per organism, so adding/removing an organism changes all later draws (expected; golden hashes are updated deliberately).
- `f64::ln/cos/sqrt` in `normal` come from the platform libm: minor inter-platform differences allowed by the contract.

## Verification strategy
TASK-005 tests (`rng::tests`, `sim::tests`, `determinism_scan`); TASK-019 CLI determinism; TASK-022 checkpoint split equivalence using `RngState` hex round trip.

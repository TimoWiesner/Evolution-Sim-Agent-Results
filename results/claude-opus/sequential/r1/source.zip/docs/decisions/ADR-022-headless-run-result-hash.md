# ADR-022: Headless `run` command, result JSON and state hash

## Status
Accepted — 2026-11-22 — TASK-019 (PLAN cycle 1).

## Context
TASK-019 delivers `evosim run` per `docs/CONTRACT.md` §2/§4/§5 (without `--save`/`--load`, which belong to TASK-022). It must
simulate exactly N ticks (also after total extinction, N = 0 allowed), run without a display, fail with exit 2 + stderr
message + no result file, and produce a `state_hash` that covers the complete simulation state. Our own decisions:
extra flags, extra result keys, hash function. `batch` (TASK-021) and checkpoints (TASK-022) will reuse the pieces.

## Decisions

### 1. Hash function: SHA-256, implemented in-crate
ADR-005 named the `sha2` crate; it was never added. We implement FIPS 180-4 SHA-256 ourselves in
`evosim-core/src/digest/sha256.rs` (~100 lines, integer only), verified against the FIPS/NIST vectors
("", "abc", the 448-bit two-block message, 1,000,000 × 'a') and against Python `hashlib` in a test fixture.
- Pros: no new dependency, `Cargo.lock` unchanged, `./evosim` stays offline-buildable, `dist/` stays one static-ish binary;
  collision resistance makes "different states give different hashes" hold in practice.
- Cons: own code to maintain (mitigated by the vectors). Rejected: FNV/xxHash (64 bit, collisions plausible across
  large sweeps, not a "digest"); `sha2` crate (extra download, no benefit).
Output: 64 lowercase hex digits.

### 2. Canonical state stream (`digest::StateHasher`)
`StateHasher` wraps SHA-256 and offers typed writers: `u8/u32/u64/i64/bool`, `f64` and `f32` via `to_bits()` (little
endian), `str`/bytes with u64 length prefix, `len(usize)` before every sequence, `opt` tag byte (0/1) for `Option`, and
`section(&'static str)` tags so adjacent sections can't alias. A version tag `"evosim-state-v1"` starts the stream.

Every owning type gets `pub(crate) fn hash_state(&self, h: &mut StateHasher)` in its own module and **destructures
itself exhaustively** (`let Organism { id, kind, pos, age, … } = self;` without `..`). A field added later without a
hashing decision is therefore a compile error, which keeps "complete state" true over time. Deliberately excluded fields
are bound as `_name` with a comment saying why.

Order of the stream (`Simulation::state_hash()`):
1. version tag; config (`Config::to_json_value()` serialised by serde_json — keys sorted because serde_json uses
   BTreeMap without `preserve_order` — includes the effective seed and every parameter);
2. clock `tick`; RNG state (4×u64); `IdAllocator` next id;
3. world: torus w/h; climate: `climate_tick`, current grid `now` (all cells, all fields), weather lattices (`Weather`
   width/height + both `PeriodicNoise` value vectors); cell resources (width, cap, all values);
4. population: per kind (Plant, Herbivore, Carnivore) the organism `Vec` in EntityId order, each organism with every field
   (id, kind, pos, age, energy, health, traits, genome kind + all genes, parents, generation, birth_tick, alive, heading,
   stride, handling, cooldown, species); pending birth requests (normally empty between ticks, still hashed);
   `LifeTotals` (initial, births, deaths, deaths_by_cause); `births_dropped_full`;
5. species registry: thresholds, living_per_kind, every record (id, kind, name, parent, root, origin_tick, extinct_tick,
   representative genome, living, ever, daughters);
6. ledgers: plant ledger, herbivore ledger, hunt ledger, both repro ledgers (all fields, cumulative and last-tick).

Excluded, with reason (each must be re-verified by IMPLEMENT and listed in the code comment):
- **Derived caches**, a pure function of hashed data: `ClimateMap` and `ClimateBounds` (config + seed), spatial index,
  `Expression` table and `CellCapacity` (config + organisms).
- **Per-tick report buffers** that the simulation rules never read and that are cleared/overwritten at the start of
  the next tick: `tick_deaths`, `last_deaths`, `last_births`, `last_moves`, `TickStats`, species `journal`. If
  IMPLEMENT finds one of them is read by a rule in a later tick, it is hashed instead.

TASK-022 checkpoints must restore exactly the hashed set (plus whatever it needs for the excluded caches to rebuild).

### 3. Run loop and result in core (`evosim-core/src/report/`)
Core stays wall-clock free; the CLI times the loop.
- `report::default_sample_every(n) = max(1, n / 100)`.
- `report::run_recorded(&mut Simulation, ticks, sample_every) -> RunRecord`: records counts at `tick_start`, steps
  exactly `ticks` times (no early exit on extinction), records a series point when `(tick - tick_start) % K == 0` and
  always at `tick_end` (no duplicates; N = 0 → one point), and the first tick in this invocation at which a kind's count
  is 0 (`extinction_tick`).
- `report::result_json(&Simulation, &RunRecord, elapsed_seconds) -> serde_json::Value` with all contract §4 keys:
  `contract`, `seed` (effective), `tick_start`, `tick_end`, `world`, `final` (counts + living species),
  `totals.births/deaths` (cumulative `LifeTotals`), `series`, `state_hash`, `elapsed_seconds`, `ticks_per_second`
  (= N / elapsed, 0 when N = 0 or elapsed = 0; always finite).
- Extra keys (our decision): `name` and `version` (engine identity), `sample_every`, `totals.initial`,
  `totals.deaths_by_cause` (per kind, cause name → count), `extinction_tick` (per kind, tick or null), `config` (the full
  effective configuration, so a result file is self-describing and reproducible).

### 4. CLI (`evosim-cli/src/run.rs`)
`evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K]`, hand-parsed like the other commands.
- Each flag at most once; unknown flags, positional arguments, missing values, missing `--config`/`--ticks`/`--out`,
  non-integer or negative `--ticks`/`--seed`, `--sample-every 0` → exit 2. `--save`/`--load` → exit 2 "not supported
  in this build (TASK-022)" until TASK-022. `--help` → usage on stdout, exit 0.
- Seed: `--seed` overrides via `Config::with_seed`; u64 like the config (negative rejected, as decided in TASK-003).
- All validation (arguments, config file, `Simulation::new`, `--out` parent is an existing directory) happens before
  the loop; nothing is written on error. The result is written to `<out>.tmp-<pid>` in the same directory and renamed
  onto `--out`, so a failed write never leaves a partial result file (on write/rename failure the temp file is removed,
  exit 2). An existing `--out` file is only replaced on success.
- stdout stays empty; one summary line goes to stderr (`run: N ticks in S s (T ticks/s) -> FILE`).
- No extra flags (no need found; keeps the contract surface small). `run` never touches `evosim-ui`, so no display
  is needed.

### 5. IMPLEMENT notes (TASK-019 cycle 1)
- Leaf encoding: instead of a hand-written `hash_state` per leaf type, the top-level owners (`Simulation`, `World`,
  `Population`, `SpeciesRegistry`) destructure themselves exhaustively and feed each field's **derived `Debug` text**
  into the stream (`StateHasher::debug`, one 0x00 terminator per value, length prefixes for sequences). Derived
  `Debug` prints every field of every nested type (no manual `Debug` impl exists in core; keep it that way), and Rust
  prints floats with the shortest round-trip representation, so the encoding is injective for our data except NaN
  payloads (never produced). A field added to a nested type is covered automatically; a field added to a top-level
  owner is a compile error until decided.
- Excluded set narrowed to **derived caches only**: `ClimateMap`, `ClimateBounds`, `Expression`, `SpatialIndex`,
  `CellCapacity`. The per-tick buffers (`tick_deaths`, `last_deaths`, `last_births`, `last_moves`, `TickStats` — the
  Statistics phase reads the previous `TickStats.tick` — species `journal`) are hashed too. TASK-022 must therefore
  restore them (or a checkpoint taken after ≥ 1 further tick is unaffected anyway).
- Result temp file: `.<name>.tmp-<pid>` next to `--out`, then `rename`.

## Consequences
- `batch` (TASK-021) calls `run_recorded` + `result_json` per seed; TASK-022 adds `--save/--load` and must make
  `run_recorded` start at a loaded `tick_start` (already supported: everything is relative to `sim.tick()`).
- Any new state field forces a hashing decision at compile time.
- `state_hash` values change whenever rules or defaults change; tests compare runs, not pinned golden hashes.

## Verification
Core: SHA-256 vectors; equal seeds → equal hash; different seeds → different hash; hash changes after one step; field
sensitivity tests (one-ULP energy change, moved organism, one gene, RNG state, next id, tick, one weather value, one
resource value, one species record field, totals). CLI: argument/error matrix (exit 2, stderr non-empty, no out file),
N = 0, extinct world keeps ticking, series rules, balance identity, run with `DISPLAY` unset. End-to-end in
`scripts/check-entrypoints.sh`: `./evosim run` twice with the same seed → identical `final/totals/series/state_hash`,
another seed → different hash.

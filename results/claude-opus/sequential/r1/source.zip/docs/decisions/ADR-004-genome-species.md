# ADR-004: Genome design — representation, inheritance, mutation and species rule

## Status
Accepted — 2026-11-22 — TASK-001.

## Context
Plants need DNA, mutation and speciation; herbivores and carnivores need two-parent sexual reproduction with heritable traits (speed, strength, health, fertility) and behavioural tendencies (aggression, risk). New species must emerge through an **explicit, stable species criterion**. The design must be cheap at 1,000–5,000 organisms, deterministic, serialisable into checkpoints and hashable.

## Alternatives considered
### A. Bitstring genome with Hamming distance
- Pros: very compact, classic GA operators, distance is a popcount.
- Cons: traits must be decoded from bit groups, mutations are coarse jumps (flipping a high bit changes a trait a lot), weak resolution for continuous traits.

### B. Periodic clustering of all genomes (k-means / DBSCAN every K ticks)
- Pros: species reflect the current population structure.
- Cons: O(N²) or a fixed k; species IDs are not stable between clusterings (labels flicker and must be matched), results depend on clustering parameters and order; costly at 5,000 organisms.

### C. NEAT-style neural genome for behaviour
- Pros: very expressive behaviour evolution.
- Cons: variable topology makes crossover and distance complex, evaluation is slow, behaviour is hard to inspect and test.

### D. Diploid genome with dominance
- Pros: more realistic (recessive alleles, heterozygote effects).
- Cons: doubles memory and complexity; dominance rules add parameters. Possible future extension.

### E. Fixed-length real-valued gene vector + founder-distance species (chosen)
- Pros: direct, continuous trait mapping; simple crossover/mutation; cheap distance; stable species IDs assigned once.
- Cons: species boundaries depend on the choice of threshold; founder representative does not follow slow drift (accepted, see consequences).

## Decision
**Representation.** `Genome { genes: Vec<f32> }` (or a fixed-size array per kind) with every gene in `[0, 1]`. A static gene table per kind (plant / herbivore / carnivore) defines index, name, trait range and mapping. Plant genes e.g. growth rate, max biomass, seed count, dispersal radius, temperature optimum and tolerance, water need, defence/toxicity, pollination tendency. Animal genes e.g. speed, strength, max health, fertility/litter size, body size/metabolism, perception radius, aggression, risk tolerance, sociality, temperature optimum and tolerance, digestive efficiency, mate choosiness. Plus 4–8 **neutral marker genes** without phenotype effect that drift freely, making lineage divergence measurable even under stabilising selection.

**Phenotype mapping.** Deterministic `trait = lo + (hi − lo) · g` (or a documented smooth curve), so traits are always in range. Derived costs create trade-offs (e.g. metabolic cost grows with speed² · size and with strength).

**Inheritance.** Plants: asexual clone by default; optional pollination = uniform crossover with a compatible plant nearby. Animals: two parents; **uniform crossover per gene** (each gene from mother or father with p = 0.5, drawn from the simulation RNG), then mutation.

**Mutation.** Per gene with probability `mutation_rate`, add Gaussian noise `N(0, mutation_strength)` (Box–Muller on the core RNG), then **reflect** into `[0, 1]` (avoids pile-up at bounds). Rate and strength are configurable per kind.

**Genetic distance.** `d(a, b) = Σ wᵢ·|aᵢ − bᵢ| / Σ wᵢ` (weighted mean absolute difference, default wᵢ = 1), `d ∈ [0, 1]`, symmetric, `d(a, a) = 0`.

**Species rule (explicit, stable).** Every species stores a founder/representative genome. At birth a newborn is compared with its mother's species representative: if `d(child, rep) ≤ T_kind` it joins that species; if `d > T_kind` it founds a new species (child genome becomes representative, `parent_species` = mother's species, recorded for the family tree). A distance exactly equal to the threshold stays in the parent species. Classification happens once at birth and is never re-assigned, so species IDs are stable and deterministic. Animals mate only with partners whose genetic distance is ≤ `mating_threshold` (reproductive isolation makes species real breeding units). Species IDs come from a sequential counter; display names are generated deterministically from the ID. `T_kind` default ≈ 0.15, configurable, tuned in TASK-017/027.

## Rationale
### Performance
~20–30 floats per organism; crossover and mutation are O(L); distance is O(L) and computed only at birth (against one representative) and in mate choice. Negligible compared to movement and sensing.

### Testability
Property tests: genes always in `[0, 1]` after mutation; with mutation rate 0 every child gene equals one parent's gene; distance symmetric, zero on identity, bounded. Deterministic tests: same seed ⇒ same child genome. Speciation test: forced divergence (high mutation) yields a new species with correct parent link; boundary test for `d == T`.

### Self-contained dist/
Pure Rust, no external dependencies; genomes serialise with serde (exact float round-trip) for checkpoints and state hash.

## Consequences
- Gene tables are versioned; checkpoints include the gene layout version.
- A species whose population drifts far from its founder still keeps its ID until a newborn exceeds the threshold; this is accepted and documented (species count can grow by successive budding).
- Extinct species stay in the registry with extinction tick for the family tree and metrics.

## Verification strategy
TASK-009 (genome, crossover, mutation, distance property tests), TASK-016 (two-parent reproduction), TASK-017 (species criterion, threshold boundary, family tree).

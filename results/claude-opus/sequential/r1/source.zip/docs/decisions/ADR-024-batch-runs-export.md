# ADR-024: Batch runs, parameter sweeps and summary export

## Status
Accepted — 2026-11-23 — TASK-021 (PLAN cycle 1).

## Context
TASK-021 delivers `evosim batch` (docs/CONTRACT.md §2): `evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR`
writes `DIR/seed-<seed>.json` (same schema as `run`) and `DIR/summary.json` (own format). In addition at least one
parameter must be sweepable over several values (test: 2 values × 2 seeds), `summary.json` lists every run (seed,
parameters, ticks) plus aggregates (mean/min/max final population per kind, extinction counts), a CSV export exists, and
the same batch run twice gives the same summary apart from time measurements. Our decisions: sweep syntax, parallelism,
extra statistics.

Existing pieces: `report::{run_recorded, result_json, default_sample_every}` (ADR-022), the CLI `run.rs` helpers
(`check_out_path`, `write_atomic`), `Config::from_value` (validates and rejects unknown dotted keys), the thread-per-seed
pattern of `ecology::survival_runs`.

## Decisions

### 1. Sweep specification: repeatable `--param KEY=V1,V2,...`
```
evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR
             [--param KEY=V1,V2,...]... [--sample-every K] [--jobs J]
```
- `KEY` is a dotted configuration key as listed by `evosim config schema` (e.g. `plants.growth_rate`,
  `herbivores.max_litter`, `world.width`, `initial.carnivores`). Each value token is parsed as a JSON literal
  (`1.2`, `3`, `true`; strings need JSON quotes). The value is written into the **raw JSON value of the config file** at
  that path (missing intermediate objects are created), then the whole document is validated with `Config::from_value`.
  So unknown keys, wrong types and out-of-range values give the ordinary config error naming the key → exit 2.
- `seed` (and `name`/`description`) cannot be swept with `--param` (seeds come from `--seeds`) → exit 2.
- Several `--param` flags form the **cartesian product**; combination order = first `--param` varies slowest, values in
  the given order. Same key twice, an empty value list, a duplicate value within one list → exit 2. At most 10,000 runs
  in total (guard against typos) → else exit 2.
- Rejected alternatives: a sweep JSON file (more ceremony for the common one-parameter case; can be added later without
  breaking this syntax), `--param` with ranges `a:b:step` (floating-point step ambiguity).

### 2. Run order, file names
- Runs are numbered `index = combo · |seeds| + seed_position`; combinations are the outer loop, seeds (in `--seeds`
  order) the inner loop. Duplicate seeds → exit 2 (they would overwrite each other's file).
- Without `--param` (one combination): files `DIR/seed-<seed>.json` exactly as the contract says.
- With `--param`: one sub-directory per combination, `DIR/combo-<c>/seed-<seed>.json` (`c` = 0-based combination
  index), so file names stay `seed-<seed>.json` and runs with the same seed don't collide. The summary records the
  relative path of each file.
- Each per-seed file is exactly the `run` result (`report::result_json`), no extra keys, so it equals the result of
  `evosim run --config <effective config> --seed <seed> --ticks N` apart from the time fields. Parameters of the run are
  visible in its `config` key (already part of the result) and in the summary.
- `--out-dir`: created (with parents) if missing; existing directory is reused, files are overwritten; a non-directory
  path → exit 2. Each file is written atomically (temp + rename, `run.rs::write_atomic` moved to a shared helper).

### 3. Validation first, then execution
All arguments, the config file, every combination's `Config` and `Simulation::new` (constructed and dropped, or kept)
are checked before any run starts and before any file or directory is created. Error → exit 2, message on stderr,
nothing written. Extinction is never an error.

### 4. Parallelism: `--jobs J`, deterministic results
- Runs execute on `J` worker threads (`std::thread::scope`, shared `AtomicUsize` work index). Default
  `J = min(available_parallelism, number of runs)`, `--jobs` ≥ 1 overrides it.
- Every run owns an independent `Simulation` seeded only by its config/seed (ADR-005), so results do not depend on
  scheduling. Results are collected into a `Vec` slot by run index; files and the summary are written after all runs
  finished, in index order; aggregates are summed in index order (floating-point sums are order-fixed).
- `jobs` is recorded only in the time section of the summary, so `--jobs 1` and `--jobs 4` give equal summaries apart
  from time measurements (tested).

### 5. `summary.json` (format `evosim-batch-summary`, version 1)
```json
{
  "format": "evosim-batch-summary", "format_version": 1, "contract": 1, "name": "...", "version": "...",
  "config_file": "path as given", "ticks": N, "sample_every": K, "seeds": [1, 2],
  "sweep": [ {"key": "plants.growth_rate", "values": [1.0, 1.5]} ],
  "combinations": [ {"combo": 0, "params": {"plants.growth_rate": 1.0}, "dir": "combo-0"} ],
  "runs": [ {
      "index": 0, "combo": 0, "seed": 1, "params": {"plants.growth_rate": 1.0}, "file": "combo-0/seed-1.json",
      "tick_start": 0, "tick_end": N, "ticks": N,
      "final": {"plants": 0, "herbivores": 0, "carnivores": 0, "species": {...}},
      "births": {...}, "deaths": {...},
      "extinct": {"plants": false, ...}, "extinction_tick": {"plants": null, ...},
      "coexistence": true, "state_hash": "...",
      "elapsed_seconds": 0.1, "ticks_per_second": 1000.0 } ],
  "aggregates": {
      "all": AGG,
      "by_combo": [ {"combo": 0, "params": {...}, ...AGG} ] },
  "timing": {"wall_seconds": 0.4, "jobs": 4, "sum_elapsed_seconds": 0.39}
}
```
`AGG` = `{"runs": n, "coexistence_runs": c, "coexistence_fraction": c/n, "kinds": {KIND: {
  "final": {"mean", "min", "max", "sd" (population), "median"},
  "species_final": {"mean", "min", "max"},
  "extinct_runs": e, "extinct_fraction": e/n,
  "extinction_tick": {"mean", "min", "max"} (over the extinct runs; null when e = 0),
  "births_mean", "deaths_mean" }}}`.
- "Went extinct" = the kind's `extinction_tick` is non-null (= final count 0, also when its initial count was 0;
  no replenishment, CONTRACT §5.3). Coexistence = all three kinds alive at `tick_end`.
- Without `--param`: `sweep` = `[]`, one combination with `params` `{}` and `dir` `"."`, `by_combo` has one entry.
- **Time measurements** = exactly the keys `runs[].elapsed_seconds`, `runs[].ticks_per_second` and the `timing` object.
  Everything else is a pure function of (config file content, arguments except `--jobs`/`--out-dir`, build).
  `config_file` is the path as given (not canonicalised), so the reproducibility test uses the same arguments.
- Means/sd/median as JSON numbers (f64); all counts integers. Extra statistics (our decision): sd, median, species,
  extinction tick, births/deaths means, coexistence count/fraction, per-combination aggregates.

### 6. CSV export (always written)
- `DIR/summary.csv`: one row per run, header
  `index,combo,seed,<param keys...>,ticks,final_plants,final_herbivores,final_carnivores,species_plants,species_herbivores,species_carnivores,births_plants,…,deaths_plants,…,extinct_plants,extinct_herbivores,extinct_carnivores,extinction_tick_plants,…,coexistence,state_hash,elapsed_seconds,ticks_per_second`.
- `DIR/aggregates.csv`: one row per (group, kind), header
  `group,<param keys...>,kind,runs,final_mean,final_min,final_max,final_sd,final_median,extinct_runs,extinct_fraction,extinction_tick_mean,coexistence_runs`
  with `group` = `all` (param cells empty) or `combo-<c>`.
- RFC 4180: comma separator, `\n` line ends, fields containing `,` `"` or newline quoted with doubled quotes; JSON values of
  params written in their JSON text form (strings without the JSON quotes); null → empty field; bools `true`/`false`.
- Rationale: CSV always written (cheap) instead of a flag, so "can be exported" needs no extra step; two files because
  runs and aggregates are differently shaped tables.

### 7. Code placement
- Core `evosim-core/src/batch/` (pure, no wall clock, no file I/O): sweep types, parsing helpers (`parse_seeds`,
  `parse_param`), `set_dotted`, `expand`, per-run outcome extraction from the result `Value`, `summary_json`,
  `summary_csv`, `aggregates_csv`. Time values are passed in by the caller.
- CLI `evosim-cli/src/batch.rs`: argument parsing, validation-first, thread pool with wall-clock timing per run, file
  writing. `write_atomic`/`check_out_path` move to `evosim-cli/src/io.rs` (shared with `run.rs`).

## Consequences
- `evosim batch` works for any key of the config schema, but each run's file is complete and self-describing.
- The summary is reproducible byte-for-byte after removing the three time-measurement locations.
- Memory: J simulations live at once; result Values are kept until the end (series ≤ ~100 points each), fine for the
  10,000-run cap.

## Implementation notes (TASK-021 IMPLEMENT cycle 1)
- `expand` returns `(Vec<Combo>, Vec<RunSpec>)`; `summary_csv(sweeps, combos, outcomes)` takes the combinations to look up
  each run's parameters; `aggregates_csv(sweeps, &summary)` is built from the summary's `aggregates` value.
- Extra helpers: `stats`, `aggregate`, `strip_time` (removes exactly `TIME_KEYS`), `RunOutcome::from_result`.
- Integer keys given float tokens (`3.0`, `1e2`) are rejected by the config parser as "wrong type" → exit 2 (documented
  in docs/BATCH.md).
- Per-run stderr lines are printed after all runs finished, in index order (worker threads don't write to stderr).
- `--jobs` is limited to 1…1024.

# Animals: sensing and movement (TASK-013, ADR-016)

Code: `crates/evosim-core/src/animals/` (`sense.rs`, `movement.rs`, `mod.rs::act_animals`), rule in `organism/capacity.rs`.

## Perception
- Vision radius `r = floor(traits.vision)` cells; `traits.vision = <kind>.max_vision · vision gene` (founders: herbivores 6, carnivores 8).
- Toroidal Chebyshev distance: an animal at (0,0) sees an organism at (W−1,H−1) at distance 1 (offset (−1,−1)).
- `perceive(pop, id)` → living organisms within `r`, self excluded, ordered by (distance, id). No RNG, no energy.

## Steps per tick (speed)
- Each animal carries `stride ∈ [0,1)`. Per tick: `budget = stride + speed`, `allowed = min(floor(budget), <kind>.max_speed)`, `stride = budget − floor(budget)`.
- So steps per tick ≤ ceil(speed) and the long-run mean is `speed` (herbivore founder 1.0 → 1 step/tick; carnivore founder 1.5 → 1,2,1,2,…).
- Every step moves to one of the eight neighbouring cells (wrapping).

## Movement cost
- i-th step within a tick costs `move_cost · (1 + sprint_cost · (i−1))`; k steps cost `move_cost · (k + sprint_cost · k(k−1)/2)`.
- Defaults herbivores (0.2, 0.5): 1 step 0.2, 2 steps 0.5, 3 steps 0.9. Carnivores (0.3, 0.5): 0.3, 0.75, 1.35.
- A step is taken only if energy ≥ its cost (energy never negative). Resting metabolism belongs to TASK-014/015.

## Shortest way
- Towards a target: signum step of the shortest wrapped offset; each step lowers the distance by exactly 1 (optimal, crosses edges when shorter; tie at n/2 → positive direction).
- If that cell is full: other distance-reducing cells in fixed order; none → wait (never a detour).

## Nothing interesting in sight (owed decision)
- Correlated random walk: keep heading, turn with chance 0.25 (new uniform Dir8), at most one step per tick; full cell → new heading, no step. No RNG draws if 0 steps are allowed this tick.
- Default TASK-013 policy: nearest visible food (herbivore → plant, carnivore → herbivore); distance ≤ 1 → stay; else move towards it up to `allowed` steps stopping adjacent; no food → wander.

## Cell-sharing rule (owed decision)
> Organisms of different kinds may always share a cell. Organisms of the same kind may share a cell up to `cap(kind)` = `plants.max_per_cell` (4), `herbivores.max_per_cell` (4), `carnivores.max_per_cell` (2). Nothing may make an organism enter a cell that already holds `cap(kind)` living organisms of its kind.

Applied by: movement steps, `resolve_births` (request into a full cell dropped, counter `Population::births_dropped_full`), plant seeds (`plants::site_ok`, reads `pop.capacity()`), founders (row-major probe from the drawn cell to the first cell with room). Only exception: `initial.<kind> > cap·W·H` (input overload; surplus founders stay at their drawn cell).

## API for TASK-014..016
`perceive`, `vision_radius`, `steps_allowed`, `move_towards(pop,id,target,max_steps,stop_at,costs)`, `move_away`, `wander`, `MoveCosts::for_kind`, `step_cost`, `path_cost`, `Population::{has_room,count_at,capacity}`, `World::last_moves(kind)`. Step numbering for cost restarts at 1 per `move_*` call; a later task combining several calls in one tick must account for that.

## Herbivore feeding (TASK-014, ADR-017)
Code: `animals/feed.rs` (pure functions), `animals/herbivore.rs` (`act_herbivores`, `herbivore_turn`), wired from `World::act_animals(Kind::Herbivore, cfg, tick, rng)`. Carnivores still use the TASK-013 `act_animals` policy (no metabolism yet; TASK-015).

- **Reach** `FEED_REACH = 1`: only a plant at toroidal Chebyshev distance ≤ 1 at bite time (own + 8 neighbour cells, across edges); enforced inside `feed::eat` (refuses further bites). Plants further away are only seen (vision radius) and approached. One bite (one plant) per herbivore per tick.
- **Bite** = `min(max_meal·(1 − 0.5·plant strength), plant energy − (1 − aggression)·0.25·plant max_energy, need)`, `need = max(0, satiety − E)/assimilation`, `satiety = (0.6 + 0.4·aggression)·max_energy`. Plant loses exactly the bite; herbivore gains `assimilation·bite` (key `herbivores.assimilation`, 0.8) ≤ bite. Plant left at ≤ 1e-9 → killed `Grazed`.
- **Metabolism** every turn: `base_metabolism·(1 + climate_cost·s_T)·(1 + 0.2·clamp((tol−2)/28,0,1))`, `s_T = clamp(|T−opt|/tol − 1, 0, 2)` from the current cell temperature (key `herbivores.climate_cost`, 1.0). Energy ≤ 0 at the end of the turn → killed `Starvation` immediately. A herbivore already at 0 energy or 0 health at the start of its turn does not act; the Deaths sweep handles it (keeps the ADR-011 Injury-first precedence).
- **Decision rule** (order): flee from the nearest visible carnivore iff `caution·(1 − d/(r+1)) > (1 − caution)·hunger` (no bite); rest if `E ≥ satiety`; bite best plant in reach if its bite ≥ 0.5·min(max_meal, need); else move towards the visible plant (d ≥ 2) maximising `bite/(1+d)` (with bite ≥ that threshold), else bite the poor plant in reach, else wander; after a move, bite the best plant in reach of the new cell. Exactly one move call per tick.
- **Audit**: `World::herbivore_ledger()` (cumulative bites/taken/gained/metabolism/starved/grazed_dead/fled, `max_bite_distance`; `.last` = `World::last_feed()`).
- Smoke (contract example 64×48, 400/120/20, no reproduction yet): herbivores 120 → 36 (t250) → 1 (t500) → 0 (t1500), all starvation; see tasks/TASK-014/handoffs/implement-cycle1.json. Run: `cargo test --release -p evosim-core smoke_contract_example -- --ignored --nocapture`.

## Carnivore hunting (TASK-015, ADR-018)
- Turn per carnivore (shuffled order): stride → metabolism (`base_metabolism`·(1+`carnivores.climate_cost`·thermal stress)·generalist factor) → handling (rest `hunting.handling_time` ticks after a kill) / rest when sated (ADR-017 satiety) / attack the herbivore in reach (own or adjacent cell, across the wrap) with the best odds / move towards the nearest herbivore within vision and strike if now in reach / wander → starvation at energy 0 (`DeathCause::Starvation`).
- Attack (`animals::hunt::attack`): refused (no cost, no RNG draw) beyond reach 1, on dead or wrong-kind targets. Otherwise pays `hunting.attack_cost`, then one core-RNG draw `chance(p)` with
  `p = clamp(base_success·(1+power_C−power_H)·(1−0.3·caution_H)·(1+0.4·(aggression_C−0.5))·(1−cover_protection·cover)·(1 | 0.8 adjacent), 0.02, 0.95)`, `power = 0.5·strength + 0.5·speed/v_ref`, `cover = plants in prey cell / plants.max_per_cell`.
- Kill: `Population::kill(prey, Predation)` (once; prey vanishes from all queries at once); gain = `min(carnivores.assimilation·E_prey, carnivores.max_meal)` capped at max energy ⇒ ≤ prey energy; rest is lost.
- Several carnivores on one prey: sequential; first success kills, later ones no longer see it (or are refused) and pick another target; a failed attack leaves the prey attackable by others in the same tick. One attack per carnivore per tick.
- Audit: `World::hunt_ledger()` / `last_hunt()` (attacks, kills, escapes, refused, cost, prey energy, gained, starved, max attack distance).
- Smoke (contract example, ignored test `smoke_hunting`, `HT`/`BS` env overrides handling_time/base_success): herbivores 120→3 by t100, extinct by t200; carnivores starve by t300 (no reproduction until TASK-016; tuning is TASK-018).

## Reproduction (TASK-016, ADR-019)
Code: `animals/repro.rs` (`reproduce_animals`, `is_ready`, `compatible`, `find_mate_in_reach`, `visible_mate`, `ReproParams`, `AnimalReproTick`, `ReproLedger`), called by `World::act_animals` right after each animal phase with the same acting order; audit `World::repro_ledger(kind)`.
- Ready: alive, `age ≥ maturity_age`, `cooldown == 0`, health > 0, `energy ≥ reproduction_threshold` and `energy > reproduction_cost`.
- Compatible: distinct IDs, same kind, genome distance ≤ `<kind>.mating_threshold` (inclusive). Partner within Chebyshev distance 1 (across the wrap). Choice: highest energy, ties by (distance, id). One attempt per animal per tick; an animal never mates with itself.
- Mate search: a ready animal with no partner in reach but one in vision takes the `Court` action (herbivores: after flee check; carnivores: after handling) and moves towards it.
- Conception: one draw with `clamp(conception_chance·(0.5+mean fertility))`; failure costs nothing. Litter: `1 + Binomial(max_litter−1, mean fertility·energy condition)`, capped by free slots in own cell, partner cell and the 8 neighbours (no room → no draw, no cost).
- Cost: each parent pays `reproduction_cost`; children share the pool `2·cost` equally (clamped to max_energy). Both parents get `cooldown = mating_cooldown`, decremented in `end_of_tick`; ready again `mating_cooldown` ticks later. Birth is immediate (`Parents::Two(a,b)`, generation = 1 + max parent generation).
- Smoke (contract example, ignored test `smoke_reproduction`): herbivores and carnivores are extinct by t250 before any mating (hunting pressure drops herbivores to ~3 by t100, maturity 100); no conception in the default run. With lower maturity/threshold (test `reproduction_deterministic` config) herbivores breed. Tuning is TASK-018/027.


## Grazing reserve (TASK-018, ADR-021)
A bite can only take plant energy above `herbivores.graze_reserve · max_energy_P` (default 0.35), independent of aggression (aggression only raises satiety). With a reserve > 0 plants are not grazed to death.

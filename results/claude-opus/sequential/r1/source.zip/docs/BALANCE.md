# Ecosystem balance (TASK-027)

Design: [ADR-030](decisions/ADR-030-ecosystem-balance.md). Raw data: `tasks/TASK-027/data/`.
Status: **complete (IMPLEMENT cycle 1)**: baseline + analysis (PLAN, before any change), trials, chosen defaults,
held-out check, performance re-run, outcome.

Coexistence of a run = first tick at which any kind reaches 0 (= `min(extinction_tick)`, the run length if none
died out). "First extinct" = the kind with the smallest extinction tick.

## 1. Baseline (before any change)
Build: commit `d6fdb93` (`tasks/TASK-027/data/baseline-commit.txt`), defaults of TASK-018/026.
Configuration: the contract §3 example, only the fixed keys (`tasks/TASK-027/data/contract-example.json`:
seed 42, 64×48, 400/120/20).

Command (39 s wall, 10 jobs):
```
./evosim batch --config tasks/TASK-027/data/contract-example.json --seeds 1,2,3,4,5,6,7,8,9,10 \
  --ticks 10000 --sample-every 50 --out-dir tasks/TASK-027/data/baseline --jobs 10
```
Death causes / curves: the same runs repeated with `./evosim run ... --seed S --ticks 10000 --sample-every 50
--metrics M` (state hashes equal to the batch files, checked for seed 1); extracted to
`tasks/TASK-027/data/baseline-curves.csv` (per seed, every 50 ticks: counts, births, deaths by cause of all three
kinds, mean energy) and `baseline-death-causes.json` (totals); the 7.5 MB metrics files were not kept (reproducible).

| seed | plants | herbivores | carnivores | coexistence | first extinct |
|---|---|---|---|---|---|
| 1 | survived (1463) | survived (1143) | extinct 2185 | 2185 | carnivores |
| 2 | extinct 7480 | extinct 7488 | extinct 2204 | 2204 | carnivores |
| 3 | survived (1358) | survived (1005) | extinct 2091 | 2091 | carnivores |
| 4 | survived (1451) | survived (980) | extinct 2815 | 2815 | carnivores |
| 5 | survived (3804) | extinct 694 | extinct 1036 | 694 | herbivores |
| 6 | survived (2011) | survived (999) | extinct 2449 | 2449 | carnivores |
| 7 | survived (3973) | extinct 526 | extinct 843 | 526 | herbivores |
| 8 | survived (4096) | extinct 397 | extinct 730 | 397 | herbivores |
| 9 | survived (1449) | survived (969) | extinct 1326 | 1326 | carnivores |
| 10 | survived (3862) | extinct 629 | extinct 887 | 629 | herbivores |

Median three-kind coexistence **1,708.5 ticks** (min 397, max 2,815); 0/10 runs keep all three kinds to 10,000.
Plants + herbivores persist 10,000 ticks in 5/10 seeds.

## 2. Analysis of the first extinction (from the recorded data)
Two failure modes, both ending with carnivores extinct well before 3,000 ticks:

**A. Carnivores die out first (6/10 seeds: 1, 2, 3, 4, 6, 9; t = 1,326–2,815).** Every carnivore death in the
whole run is `starvation` (27–46 per seed, no old age: max_age 2000 is never reached). The herbivores are *not*
scarce: they grow to 800–1,250 by t≈1,000–1,800 and stay there. Carnivore mean energy stays 60–110 (threshold
110, satiety ≈128) and carnivores die only a few per 250 ticks, but they almost never reproduce: 7–26 carnivore
births in the whole run (≈1 birth per 250 ticks for ~15 animals). The population shrinks slowly from 20 to 0.
Cause: low per-capita reproduction of a very sparse predator (20 on 3,072 cells): a birth needs two ready animals
(energy ≥110 *and* cooldown 0) within reach 1 at the same time, kills give ≤48 energy and are followed by
handling, and a ready carnivore without a visible mate does not search. Herbivore deaths in these seeds are mostly
starvation (4,100–5,900) and old age; predation only 215–680 over 10,000 ticks: predation does not regulate them,
plants and herbivores cycle (plants 800–4,500).

**B. Herbivores die out first (4/10 seeds: 5, 7, 8, 10; t = 397–694), then carnivores starve (t = 730–1,036).**
All herbivore deaths are `predation` (194–273); herbivore births fall from ~30 per 50 ticks to 0 while the 20–27
carnivores still kill 20–30 per 50 ticks. In the first ~500 ticks herbivores start at 120 with 60 energy (below
their reproduction threshold 70) and breed slowly; the herbivore curve goes 120 → 100 → 50 → 0 while plants are
at 3,000–4,500 (food is not limiting). Predation pressure at low prey density is too high: the kill rate of a
carnivore hardly drops when prey becomes rare (cover is ≈1 everywhere because plants saturate the cells, so it
does not act as a refuge), i.e. a type-II functional response without a low-density refuge.

**Conclusion.** Parameter values sit on a knife edge: making hunting harder or slower (base_success 0.09,
handling 30, cover 0.8) removes mode B but makes mode A happen earlier in all seeds; making carnivores breed
faster (threshold 90, litter 2, conception 1.0, cooldown 60, vision 16) brings mode B to most seeds (see §3
exploratory probes). A mechanism is needed that lowers predation when prey is locally rare and keeps it efficient
when prey is abundant (type-III response / refuge), plus better carnivore reproduction at high prey density.

## 3. Trials
Tuning seeds: **1–10**. Held-out seeds (never used while tuning): **1001–1010**.
Exploratory trials T1–T3 (and prototype P1/P1b) were run in PLAN on the baseline build (T4/T5 followed in IMPLEMENT with the mechanism) (parameter sweeps via `--param`, 3,000–4,000
ticks); P1 is a *temporary* prototype patch, reverted afterwards (not part of the code). Summary command:
`python3 tasks/TASK-027/data/coexistence-summary.py DIR/summary.json`. Values: median coexistence, sorted per
seed, first-extinct letters per seed 1..10 (c/h/p, `-` = all alive at the end).

| # | change | expected | measured | helped? |
|---|---|---|---|---|
| T1 | carnivores.max_litter {1,2} × reproduction_threshold {110,90} × hunting.base_success {0.12,0.09}; 4,000 ticks | more carnivore births ⇒ no mode A; lower success ⇒ no mode B | base 1708.5. Every other combo worse: success 0.09 ⇒ all mode A at 681–1,635 (median 981–1,166); threshold 90 or litter 2 with 0.12 ⇒ mode B in 5–8 seeds (median 628–1,155) | no |
| T2 | carnivores.max_vision {8,16} × conception_chance {0.5,1.0} × mating_cooldown {120,60}; 3,000 ticks | better mate finding ⇒ more births | births barely change (7–34); vision 16 ⇒ prey found faster ⇒ mode B in 7–8 seeds (median 462–584); cooldown 60 alone 1,404 | no |
| T3 | hunting.handling_time {15,30} × herbivores.initial_energy {60,80} × hunting.cover_protection {0.6,0.8}; 3,000 ticks | slower kills / herbivores ready to breed at once ⇒ no early prey crash | initial_energy 80: median **1,846** (1 seed to 3,000; still 4 mode B). handling 30: no mode B but carnivores starve 861–2,299 (median 1,533). cover 0.8: carnivores starve everywhere (902–1,203) | partly (initial_energy 80) |
| P1 | prototype mechanism: attack success × `n/(n+H)` with n = herbivores within the carnivore's vision, base_success × B; 3,000 ticks (H,B) = (20,2), (40,3), (10,1.6) | type-III response: prey refuge at low local density, efficient hunting where prey is dense | (20,2): median **2,754**, 5/10 to 3,000; (40,3): median **2,860**, 5/10 to 3,000, mode B only 1 seed; (10,1.6): 2,061 | yes |
| P1b | P1 (40,3) × herbivores.initial_energy {60,80}; 5,000 ticks | combination | IE 60: median 2,879, 3/10 to 5,000; IE 80: median **3,944** (1,987–5,000), 3/10 to 5,000; remaining failures mostly carnivore starvation (6–12 carnivore births) | yes |

Trials of the **implemented** mechanism (IMPLEMENT cycle 1; `hunting.prey_density_half`, ADR-030 D1; screening at
5,000 ticks, seeds 1–10, `--param` sweeps; raw output `tasks/TASK-027/data/trials/T4.txt`, `T5.txt` + summary.csv):

| # | change | expected | measured | helped? |
|---|---|---|---|---|
| I0 | implemented factor with `prey_density_half = 0` (off), old values | bit-identical dynamics to baseline | seed 1, 10,000 ticks: identical series/extinction ticks/final counts; `state_hash` differs only because the hashed config now contains the new key | check passed |
| T4 | mechanism on: `prey_density_half` {20,40,60} × `base_success` {0.24,0.36,0.48}, `herbivores.initial_energy` 80; 5,000 ticks (2 min 24 s) | best around (40, 0.36) as in P1b | (40,0.36): median **4,615.5**, 4/10 to 5,000, failures carnivore starvation; (20,0.24): 4,393.5, 3/10; (60,0.48): 2,756.5, 4/10; (20,0.36), (40,0.48): all 10 seeds herbivores eaten out (median 1,748–1,808, carnivores breed 70–114×); (40,0.24), (60,0.24), (60,0.36): carnivores starve with 0–6 births (515–1,588); (20,0.48): 779 | yes — but still a knife edge along the diagonal half/base ≈ 110 |
| T5 | refine at half 40: `base_success` {0.33,0.39} × `carnivores.mating_cooldown` {120,80}; 5,000 ticks (1 min 20 s) | slightly lower success removes the residual mode B; shorter cooldown more carnivore births (mode A) | (0.33,120): median **5,000**, 6/10 to 5,000, min 1,015 (seeds 2,6,7 carnivores with 0–4 births); (0.33,80): 3,911; (0.39,120): 3,655.5 (min 2,439); (0.39,80): 3,237.5, herbivores eaten out in 5 seeds | 0.33 yes; cooldown 80 **no** (worse in both) |

Not tried (time budget of the phase; recorded honestly): ADR-030 D2 `mate_search_radius` and the optional carnivore
rest metabolism. Remaining failures (§5) are mode A (carnivores with ≤7 births die out early), which is exactly what
D2 targets — next candidate. Stop rule: T5 was the last trial the 60-min phase allowed after the full-length runs.

## 4. Chosen defaults
Chosen by the ADR-030 metric (median at 5,000 ticks, tie-break runs reaching the end): T5 (40, 0.33, 120).

| key | before | after |
|---|---|---|
| `hunting.prey_density_half` (new, mechanism) | — (off) | **40** |
| `hunting.base_success` | 0.12 | **0.33** |
| `herbivores.initial_energy` | 60 | **80** |

Presets (lush/harsh/plants-only) are built from the defaults and follow them automatically. Full length on the tuning
seeds (`tasks/TASK-027/data/chosen-tuning/`, same command as §1 with `--out-dir .../chosen-tuning`):

| seed | plants | herbivores | carnivores | coexistence |
|---|---|---|---|---|
| 1 | survived | survived | extinct 9979 | 9979 |
| 2 | survived | survived | extinct 1987 | 1987 |
| 3 | survived | survived | survived | 10000 |
| 4 | survived | survived | survived | 10000 |
| 5 | survived | survived | survived | 10000 |
| 6 | survived | extinct 7071 | extinct 1015 | 1015 |
| 7 | survived | survived | extinct 1343 | 1343 |
| 8 | survived | survived | survived | 10000 |
| 9 | survived | survived | extinct 4921 | 4921 |
| 10 | survived | survived | extinct 6685 | 6685 |

Median **8,332** (baseline 1,708.5), 4/10 full (baseline 0/10). Tuned on these seeds — optimistic; see §5.

## 5. Held-out check (seeds 1001–1010, 10,000 ticks)
Never used while tuning. Chosen defaults, contract example config, plain batch:
```
./evosim batch --config tasks/TASK-027/data/contract-example.json --seeds 1001,...,1010 --ticks 10000 \
  --sample-every 50 --out-dir tasks/TASK-027/data/heldout --jobs 6
```
For comparison the **old behaviour** on the same seeds (`--param hunting.prey_density_half=0 --param
hunting.base_success=0.12 --param herbivores.initial_energy=60`, → `tasks/TASK-027/data/heldout-oldbehaviour/`).

| seed | new: plants | new: herbivores | new: carnivores | new coexist. | old coexist. (first extinct) |
|---|---|---|---|---|---|
| 1001 | survived | survived | survived | 10000 | 1993 (c) |
| 1002 | survived | survived | extinct 2429 | 2429 | 2328 (c) |
| 1003 | survived | survived | extinct 1080 | 1080 | 1968 (c) |
| 1004 | survived | survived | extinct 1983 | 1983 | 511 (h) |
| 1005 | survived | survived | survived | 10000 | 498 (h) |
| 1006 | survived | survived | extinct 1763 | 1763 | 1737 (c) |
| 1007 | survived | survived | extinct 1821 | 1821 | 1589 (c) |
| 1008 | survived | survived | extinct 1988 | 1988 | 531 (h) |
| 1009 | survived | survived | survived | 10000 | 1428 (c) |
| 1010 | survived | survived | extinct 5529 | 5529 | 821 (h) |

New: median **2,208.5**, 3/10 full, herbivores and plants survive in 10/10 (mode B is gone). Old: median 1,508.5,
0/10 full, herbivores eaten out in 4/10. Every remaining failure is mode A: carnivores die out (7 of 10 seeds,
1–7 carnivore births in 6 of them) while herbivores are abundant.

## 6. Performance with the chosen defaults
`./evosim perf` (TASK-026 method, unchanged): **346.9 ticks/s** (median of 3: 347.3/346.6/346.9), organisms
min/mean/max 692/3,216/5,049; TASK-026 measured 336 ticks/s; target ≥100 met. The extra vision-radius count is done
only when a herbivore is in attack reach and the factor is on. A 10,000-tick contract run took 36–60 s wall in the
batches (6 parallel jobs), far below the contract limit of 300 s.

## 7. Outcome and limits
- **Before**: median three-kind coexistence 1,708.5 ticks on seeds 1–10 (0/10 to 10,000); old behaviour on the
  held-out seeds 1,508.5 (0/10).
- **After**: 8,332 on the tuning seeds (4/10 to 10,000), **2,208.5 on the held-out seeds (3/10 to 10,000)**.
- **Goal partly reached**: the mechanism (local type-III hunting response) removes the prey crash (mode B) on all
  20 seeds and gives full 10,000-tick coexistence of all three kinds in 7 of 20 runs (before 0 of 20). It does not
  make coexistence reliable: in most remaining runs carnivores die out early.
- **Limits**: (1) mode A — a sparse predator population (20 on 3,072 cells) that reproduces very rarely; whether a
  run escapes it depends on early chance (who meets a mate). (2) The parameters still sit on a ridge (half/base ≈
  110–120): too low ⇒ starvation, too high ⇒ herbivores eaten out (T4). (3) The held-out median is much lower than
  the tuning median ⇒ the choice is partly fitted to seeds 1–10. (4) Only the contract example world was tuned;
  lush/harsh presets follow the defaults unmeasured. (5) Not tried: mate search radius (ADR-030 D2), carnivore
  rest metabolism — the next steps for mode A.
- Rules (PROJECT.md): the factor uses only the herbivores within the attacking carnivore's own vision (perception),
  never a global or species count; nothing is created; P_MIN keeps kills possible. Tests:
  `animals::tests_hunt::{density_factor_values, more_local_prey_raises_success_and_off_is_unchanged,
  far_away_herbivores_do_not_matter_and_count_wraps, density_attack_keeps_one_draw_and_bounds}`.

# Performance (TASK-026, ADR-029)

## Benchmark command
```
./evosim perf                      # = --seed 42 --warmup 1000 --ticks 1000 --repeat 3, contract example config
./evosim perf --out docs/perf/after.json
./evosim perf --config FILE | --load CHECKPOINT [--seed N] [--warmup W] [--ticks M] [--repeat R] [--out FILE]
```
- **Fixed setup:** contract example configuration (= preset `default`: 64×48 world, 400 plants / 120 herbivores / 20 carnivores initially), seed **42**.
- **Warm-up:** 1000 ticks (untimed), so the population is fully developed.
- **Measured:** 1000 ticks (t1000–t2000), repeated **3×**, each repetition on a `clone()` of the warmed-up state (identical work). Headline = **median ticks/s**.
- Only `Simulation::step_with` is timed, with one `Instant` per phase from the phase hook. Counting organisms after every tick is outside the timed region.
- Organisms alive over the measured ticks (all kinds): **min 1,784 / mean 3,409 / max 4,667**, so about 2,000 or more. Mean per kind: 2,664 plants, 738 herbivores, 6 carnivores. The minimum is reached only in the last ticks; the window spends nearly all of its time above 2,000.
- The JSON report (`evosim-perf` v1) also contains the per-phase seconds/shares, the end `state_hash` (identical across repetitions → `"deterministic": true`; equal to a plain run of 2000 ticks) and the host CPU.
- Raw reports: [perf/baseline.json](perf/baseline.json) (before), [perf/after.json](perf/after.json) (after).

## Hardware
AMD Ryzen 5 7500F 6-core / 12 threads, 30 GB RAM, Ubuntu 24.04 container, rustc 1.100.0, release profile (opt-level 3, thin LTO, codegen-units 1). Single-threaded engine.

## Results
| Setup | Before | After | Speed-up |
|---|---|---|---|
| `./evosim perf` (default, seed 42, W1000, M1000, R3), ≈3,400 organisms mean | **185.1 ticks/s** (185.1/186.1/185.1) | **337.2 ticks/s** (337.3/337.2/336.4) | 1.82× |
| `./evosim perf --config lush.json --ticks 500` (preset `lush`, seed 42), ≈7,000 organisms mean | 50.0 ticks/s | 90.0 ticks/s | 1.80× |

`lush.json` = `./evosim config show --preset lush`. Target (≥ 100 ticks/s at about 2,000 organisms): **met** before and after; after optimisation it is 3.4× the target.

**TASK-027 re-run with the new ecology defaults** (docs/BALANCE.md §6): `./evosim perf` **346.9 ticks/s** (347.3/346.6/346.9), organisms min/mean/max 692/3,216/5,049 — target still met; the golden hashes in `scripts/perf-equivalence.txt` were re-recorded because the defaults change behaviour intentionally.

Intermediate steps on the default benchmark: baseline 185 → after (A)+(B)+(C1) 268 → after (C2) 337 ticks/s.

## Profile
Coarse profile = phase shares from `evosim perf` (no extra tools). Fine profile = callgrind via `scripts/profile.sh` (needs `apt-get install -y valgrind`; Linux `perf` is blocked in the container). The script warms up 1700 ticks, saves a checkpoint and profiles 60 ticks loaded from it. The figures below are % of all instructions of that process (checkpoint loading and hashing are about 25% of it and are not part of the tick).

Phase shares (default benchmark):
| Phase | Before | After |
|---|---|---|
| herbivores | 94.5% | 91.3% |
| climate | 2.2% | 4.0% |
| plants | 2.5% | 3.5% |
| all others | < 1% | < 1% |

callgrind before (plan phase, inclusive): `herbivore_turn` 80.7%, `feed::best_visible` 54.5%, `SpatialIndex::within_into` 50.5%, of which **sorting hits by (distance, id) ≈27%** plus a fresh `Vec` per query, `Population::locate` 23.6% (three binary searches over 200-byte organism structs per lookup), `feed::best_in_reach` 10.8%.

callgrind after (inclusive): `herbivore_turn` 71.7%, `feed::best_visible` 45.2% (its per-candidate closure, i.e. plant lookup + `bite_size`, 29.4%), `best_in_reach` ≈8%, `Population::locate` 5.4% self. `within_into` and the sort no longer appear in the tick. callgrind counts instructions, so it does not show the cache-miss saving of (C2), which is where most of the wall-time gain of that step comes from.

## What was done (all exactly behaviour-preserving)
| Hot spot | Action |
|---|---|
| Sorting + allocating `within` hits (≈27% + 2%) | (A) `SpatialIndex::for_each_within` / `Population::for_each_within`: an unsorted visitor with no allocation. Used by `feed::best_visible`, `feed::best_in_reach` and `hunt::best_in_reach`. Their maxima have an explicit total tie-break on (distance, id) and finite scores, so the visit order cannot change the result. |
| `nearest` sorted the whole radius | (B) `nearest` is now an unsorted min-search over (distance, id). It calls `pred` only for candidates that beat the current best. This is identical because every predicate is pure, which is now a documented requirement. Covers threat/prey/food targeting, visible mates and pollination donors. |
| `Population::locate` (≈24%) | (C1) `get_alive_of(kind, id)`: one binary search where the kind is known from a `Neighbour`. (C2) Derived dense ID columns `id_cols[kind]` (`#[serde(skip)]`, not hashed): binary search over 8-byte IDs instead of 200-byte organisms (cache-friendly). They are rebuilt at founders, Deaths-phase compaction and checkpoint restore, and appended at births. `locate` falls back to the old search if the lengths ever differ. |
| Tried, rejected | (D) Ring-ordered `best_visible` scan with an exact early stop (bound `min(max_meal, need)/(1+d)`). Exact, but **slower** (248 vs 268 ticks/s): most bites are limited by the plant's edible energy, so the bound rarely prunes and the ring bookkeeping costs more. Reverted. Parallelism was not adopted, because the turn order is sequential by design (ADR-008). |

## Remaining bottleneck
`feed::best_visible`: every hungry herbivore that has no good bite in reach evaluates `bite_size` for every plant within its vision radius (up to (2r+1)² cells with about 0.9 plants/cell). Each evaluation is a lookup plus a few float operations on a cache-cold organism. Further gains would need a different (behaviour-changing) foraging rule or a per-cell plant summary that stays exactly equivalent. Both are out of scope here.

## Behaviour unchanged: evidence
- `scripts/perf-equivalence.sh` re-runs 9 golden runs (default/lush/harsh/plants-only × seeds 1/42 × 1500 ticks, plus default seed 42 × 3000) and compares `state_hash` with the values recorded before any change (`scripts/perf-equivalence.txt`). Result after optimisation: **all rows equal** (also checked on the unchanged baseline binary).
- The benchmark end hash `0eaedec2…` is identical before and after, and so is the `lush` benchmark hash `b76668e7…`.
- `./test.sh` (all workspace tests in release, including determinism, checkpoint round-trip and hash tests) exit 0.
- New tests: `spatial::tests::unsorted_visitor_and_min_search_nearest_match_sorted_oracle` (worlds 1×1, 3×3, 5×4, 2×7 and 64×48, radii 0–8, both query branches) and `organism::tests::id_column_cache_and_kind_lookup_match_get_alive` (sync through births, deaths, mid-tick and checkpoint restore).

## Slowdown guard
`crates/evosim-cli/tests/perf.rs::slowdown_guard_release_only` (part of `./test.sh`, which tests `--release`; skipped in debug builds). It runs the default config, seed 42, warm-up 1000 and 300 measured ticks. It asserts mean organisms ≥ 1,500 and **≥ 25 ticks/s** (about 13× below the measured 337, so slow or loaded machines stay green). `EVOSIM_PERF_MIN_TPS=<x>` overrides the threshold (0 disables it). `perf_cli_smoke_and_bad_args` checks the CLI, the JSON keys, determinism across repeats, and exit 2 on bad options.

## Re-baselining
The golden list is tied to the current ecology parameters. A later task that changes behaviour on purpose must re-record `scripts/perf-equivalence.txt` from its own baseline before optimising.

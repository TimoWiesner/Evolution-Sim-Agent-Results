# Checkpoints (`evosim run --save/--load`)

Design: [ADR-025](decisions/ADR-025-checkpoints.md). Implemented in TASK-022 (core module `snapshot`, CLI `run.rs`).

## Usage
```
evosim run --config FILE --ticks A --out r1.json --save cp.json      # A ticks, then checkpoint
evosim run --load cp.json --ticks B --out r2.json [--save cp2.json]  # B more ticks
```
`r2.json` has the same `final`, `totals` and `state_hash` as one run of `A + B` ticks (contract §5.2); `tick_start = A`,
`totals` are cumulative since tick 0, `series` covers only this invocation. Rules: exactly one of `--config`/`--load`;
`--seed` is rejected with `--load` (the seed is in the checkpoint); `--save` must differ from `--out`/`--metrics`, may equal
`--load`. `--ticks 0 --save` writes a checkpoint of the initial (tick-0) state.

## File format (version 1)
One UTF-8 JSON document, compact, trailing newline:
```json
{"format":"evosim-checkpoint","version":1,"engine":"0.1.0","tick":120,"state_hash":"<64 hex>",
 "config":{ ...same shape as a configuration file... },
 "state":{"tick":120,"rng":{"s":[u64,u64,u64,u64]},"ids":{"next":N},
          "world":{"torus","weather":{"temperature":[..],"precipitation":[..]},"now":[{"temperature","precipitation"}..],
                   "climate_tick","organisms":{"by_kind":[[organism..],[..],[..]],"pending","totals","tick_deaths",
                   "last_deaths","last_births","births_dropped_full","species":{records,thresholds,living_per_kind,journal}},
                   "resources","plant_ledger","last_moves","herbivore_ledger","hunt_ledger","repro_ledger","stats"}}}
```
- Organisms carry every field: id, kind, pos, age, energy, health, traits, genome (genes), parents, generation, birth_tick,
  alive, heading, stride, handling, cooldown, species.
- Not stored (rebuilt from `config` on load): base climate map, climate bounds, gene expression constants, per-cell
  capacity, spatial index. Everything else is exactly the state hashed by `state_hash` (ADR-022).
- Floats are written with `serde_json` `float_roundtrip` (shortest exact text) → bit-exact restore.
- `engine` is informative; `version` decides compatibility. Only version 1 loads; a future format change bumps it.

## Compression
None. Reasons: no extra dependency, the file stays inspectable/diffable, write+read cost is small. Users can gzip
externally (measured ratio ≈ 5.4×, see below).

## Validation on load (all → exit 2, message on stderr, no result/metrics/checkpoint file written)
1. File missing, a directory, or unreadable → `cannot read checkpoint 'F': ...`
2. Not UTF-8 / not JSON / truncated → `SnapshotError::Parse`
3. `format` ≠ `evosim-checkpoint`, `version` missing / not the integer 1 → `SnapshotError::Version`
4. Missing/ill-typed fields, invalid `config`, world size ≠ config, grid lengths wrong, organism outside the world,
   inconsistent population/species, zero RNG state, IDs ≥ counter, `tick` ≠ `state.tick` → `SnapshotError::Invalid`
5. Recomputed `state_hash` ≠ stored `state_hash` (any edited value) → `SnapshotError::Integrity`

On save the CLI decodes its own checkpoint text again and compares the hash (self-check) before writing. Files are
written atomically (temp file + rename) in the order result, metrics, checkpoint; on any failure the files written by
this invocation are removed, and an existing checkpoint at the `--save` path is only replaced when everything else
succeeded.

## Measurements (contract example 64×48, 400/120/20, seed 42, release build, this container)
| | value |
|---|---|
| checkpoint after 1000 ticks | 3,886,220 bytes (gzip -k: 718,922 bytes) |
| `run --ticks 1000` without / with `--save` | 0.86 s / 1.14 s wall (save + self-check ≈ 0.2 s) |
| `run --load cp --ticks 0` | 0.08 s wall |

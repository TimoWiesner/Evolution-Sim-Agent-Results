# Verification evidence (TASK-028, ADR-031)

Recorded on 2026-11-23 in the benchmark container (Ubuntu 24.04 x86-64, 12 cores, rustc 1.100.0, chromium 131).
Raw data: `tasks/TASK-028/data/` (batch summaries and per-seed result files of every long run).

## 1. Test suite (one command)

```sh
./test.sh
```
Final run of TASK-028 IMPLEMENT (2026-11-23): **exit 0 after 43 s**. Cargo: evosim-cli unit 18 + integration 27 +
perf 2, evosim-core 351 passed / 3 ignored (long-running, documented) + **7 randomised invariant tests**, evosim-ui
35 + 6 — 0 failed; `node --test` UI JavaScript 23/23 pass; `scripts/check-entrypoints.sh` **56 PASS lines, 0 FAIL,
0 SKIP, "ALL PASS"** (includes `scripts/ui-checks.sh` and `scripts/check-dist-chroot.sh`).

## 2. Contract checklist (docs/CONTRACT.md)

All rows are automated in `scripts/check-entrypoints.sh` (part of `./test.sh`; it runs from an unrelated temporary
cwd) unless another file is named. "PASS" = observed in the `./test.sh` run of §1.

| § | Requirement | How it is checked | Observed |
|---|---|---|---|
| 1 | `setup.sh`, `evosim`, `build.sh` exist, executable, work from any cwd | `-x` checks; all commands run from `mktemp -d` | PASS |
| 1 | `./setup.sh` succeeds, idempotent | run inside check-entrypoints (after an earlier build: second run) | PASS (exit 0) |
| 1 | `./evosim`, `dist/evosim` need no network | `run`/`version` do no network I/O (only the UI opens a local 127.0.0.1 server); chroot run has no resolv.conf/network config | PASS |
| 2 | `version` prints exactly one JSON object `{"name","version","contract":1}` on stdout | `json.loads` of whole stdout, key set equality, for `./evosim`, `dist/evosim`, copied dist (`env -i`), chroot | PASS |
| 2 | `run` headless (no `DISPLAY`) | `env -u DISPLAY -u WAYLAND_DISPLAY evosim run …` | PASS |
| 2 | `--seed` overrides the config seed | result `seed`==7; seed 8 gives different hash | PASS |
| 2 | `--ticks N` exactly N, also `0`, also after extinction | `--ticks 0` → `tick_end` 0, 1 series point; `initial.plants=0` run 3,000 ticks → `tick_end` 3000 with all kinds 0 | PASS |
| 2 | `--sample-every` default N/100 (≥ 1) and explicit | 300 ticks → series 0,3,…,300; `--ticks 250 --sample-every 40` → 0,40,…,240,250 | PASS |
| 2 | `--save` / `--load`, `--ticks` = additional ticks | 120 `--save` + `--load` 180 → `tick_start` 120, `tick_end` 300 | PASS |
| 2 | `batch` writes `DIR/seed-<s>.json` (run schema) + `summary.json` | seeds 1,2,3; also `--param` sweep; bad `--param` → exit 2 nothing written | PASS |
| 2 | `ui --smoke-test` ≤ 60 s, `ui --screenshots DIR` ≤ 120 s, `main.png` ≥ 1280×720 | `scripts/ui-checks.sh` (timed, PNG size parsed) | PASS |
| 3 | fixed-keys-only file valid; `initial.*` = 0 valid; width ≥ 1 | `config validate` fixed-only; width 0 → exit 2 naming `world.width`; randomised test uses 1-wide/1-high worlds and zero counts | PASS |
| 4 | result keys `contract, seed, tick_start, tick_end, world, final{…, species}, totals, series, state_hash, elapsed_seconds, ticks_per_second` | key assertions in the run/series checks; lowercase hex hash | PASS |
| 4 | `initial + births − deaths = final` per kind | run check; `scripts/coexistence.py` on every long run; every tick in `randomized_invariants.rs` | PASS |
| 4 | series ascending, no duplicates, `tick_start` … `tick_end` | exact tick lists compared | PASS |
| 5.1 | determinism: same config/seed/ticks → identical `final/totals/series/state_hash`; other seed → other hash | run twice + seed 8; batch twice (`--jobs` default vs 1); `determinism_and_seed_sensitivity` (24 random configs) | PASS |
| 5.2 | checkpoints: A + B == A+B (`final/totals/state_hash`) | CLI 120+180 vs 300; `checkpoint_split_equivalence` (20 random configs, random A, B); copied dist `--load` | PASS |
| 5.3 | no replenishment; `initial.plants=0` → herbivores then carnivores die out | CLI run 32×24 0/60/10: herbivores extinct, then carnivores, all stay 0; random no-replenishment check every tick in 100 configs; `plants_zero_starves_animals_in_random_configs` (8 configs) | PASS |
| 5.4 | errors → exit 2, stderr message, no result file: bad flag, unknown command, no command, negative ticks, missing `--config`, unreadable file, JSON syntax, wrong type, missing fixed key, out of range, truncated checkpoint, bad batch param, ui usage errors | check-entrypoints (each case asserts rc 2, non-empty stderr, empty stdout, no out file) + `crates/evosim-cli/tests/cli.rs` | PASS |
| 5.4 | extinction is not an error | `initial.plants=0` run exit 0 | PASS |
| 5.5 | stdout clean: only JSON from `version`; `run` prints nothing on stdout | stdout captured and asserted empty / single JSON | PASS |
| 6 | `./build.sh` → `dist/evosim`, same commands | build exit 0; dist `version`, `run`, `run --load` give identical hashes to `./evosim` | PASS |
| 6 | `dist/` self-contained | (a) `ldd` whitelist: only linux-vdso, libc, libm, libgcc_s, ld-linux; (b) copy of `dist/` run with `env -i PATH=/usr/bin:/bin`; (c) `scripts/check-dist-chroot.sh`: chroot containing only `dist/` + the 4 libraries ldd lists (no shell, no Python/Rust/Node, no project files) runs `version` and `run` | PASS |
| 6 | `dist/` not committed | `git check-ignore dist/evosim target/` | PASS |
| 7 | `scenarios/demo.json` accepted by `run`, `batch`, `ui --config` | `config validate`; `run --seed 5`; `batch --seeds 1,2`; `ui --smoke-test --config scenarios/demo.json`; copied dist run on demo | PASS |
| 7 | 10,000-tick runs within 300 s (example) / 900 s (demo) with 4 parallel | `scripts/long-runs.sh` (§3) | see §3 |

## 3. Long runs (10,000 ticks)

```sh
scripts/long-runs.sh        # writes tasks/TASK-028/data/long-runs/, prints the tables below
```
Executed 2026-11-23, 12-core container, `--jobs 4` (4 runs at the same time, as in the benchmark). Output:
`tasks/TASK-028/data/long-runs.txt`; data `tasks/TASK-028/data/long-runs/{contract-example,demo}/`.

| Configuration | Runs | Exit | Max `elapsed_seconds` per run | Limit | Accounting identity |
|---|---|---|---|---|---|
| contract example | seeds 1–5 × 10,000 ticks | all 0 | 31.3 s (319–417 ticks/s) | 300 s | OK for all |
| demo | seeds 1–5 × 10,000 ticks | all 0 | 160.0 s (62–71 ticks/s) | 900 s | OK for all |
| demo via `dist/evosim run` | seed 1 × 10,000 ticks | 0 | 154.8 s | 900 s | identical `state_hash`/final/totals to the batch run |

Additionally the demo trials (§5) ran 15 more 10,000-tick runs (D1, D3, D2 held-out), all exit 0, and TASK-027
recorded 20 contract-example runs of 10,000 ticks (seeds 1–10, 1001–1010). No run failed or errored.

## 4. Coexistence

Coexistence = first tick at which any of the three kinds is extinct (sampled every 100 ticks), or 10,000 if all
three are alive at the end. No forced anti-extinction is used; collapse is allowed.

### Contract §3 example (64×48, 400/120/20, only fixed keys = default parameters), seeds 1–5
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 1 | 1166 | 621 | 0 | -/-/9979 | 9,979 | carnivores | 29 |
| 2 | 1642 | 1072 | 0 | -/-/1987 | 1,987 | carnivores | 25 |
| 3 | 2722 | 888 | 10 | -/-/- | 10,000 | - | 31 |
| 4 | 3783 | 254 | 31 | -/-/- | 10,000 | - | 28 |
| 5 | 2872 | 627 | 31 | -/-/- | 10,000 | - | 24 |

median coexistence 10000 ticks (min 1987, max 10000); 3/5 runs with all three kinds at tick 10000; max elapsed 31.3 s
accounting initial+births-deaths=final and tick_end: OK
### Demo scenario `scenarios/demo.json` (128×96, 1600/480/80), seeds 1–5
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 1 | 10994 | 3012 | 138 | -/-/- | 10,000 | - | 158 |
| 2 | 12349 | 2052 | 60 | -/-/- | 10,000 | - | 141 |
| 3 | 12855 | 1381 | 71 | -/-/- | 10,000 | - | 142 |
| 4 | 11377 | 2472 | 115 | -/-/- | 10,000 | - | 160 |
| 5 | 12563 | 2027 | 110 | -/-/- | 10,000 | - | 156 |

median coexistence 10000 ticks (min 10000, max 10000); 5/5 runs with all three kinds at tick 10000; max elapsed 160.0 s
accounting initial+births-deaths=final and tick_end: OK

### Contract example on more seeds (TASK-027, docs/BALANCE.md §6, same build defaults)
Held-out seeds 1001–1010 (re-checked with `scripts/coexistence.py tasks/TASK-027/data/heldout/summary.json`): median coexistence **2,208.5 ticks** (min 1,080), 3/10 runs with all three kinds at 10,000 (carnivores
die out first in the others). Together with seeds 1–5 above (3/5 full, median 10,000; minimum 1,987): coexistence
for the default parameters on the small 64×48 world is **seed-dependent and not robust** — 6 of 15 measured runs keep
all three kinds for 10,000 ticks.

### Demo on held-out seeds 11–15
5/5 runs keep all three kinds to tick 10,000 (§5, `tasks/TASK-028/data/demo-trials/out-D2-heldout/`). In total the
demo kept plants, herbivores and carnivores alive for the full 10,000 ticks in **10 of 10** seeds measured.


## 5. Demo scenario trials

Goal (TASK-028 decision): longest three-kind coexistence without forced anti-extinction, using only existing
configuration keys and the current default parameters, at a size that stays far below the 900 s limit. Hypothesis:
the contract example (64×48) fails mostly because carnivores starve after local prey crashes; a larger world at the
same density offers more spatially separated sub-populations (refuges, recolonisation of depleted areas).
Candidates keep the contract densities (400/120/20 per 3,072 cells). Each: `evosim batch --seeds 1,2,3,4,5 --ticks 10000
--sample-every 100 --jobs 5` (5 parallel runs, i.e. more load than the benchmark's 4). Files:
`tasks/TASK-028/data/demo-trials/` (`run.sh`, configs `D*.json`, outputs `out-D*/`).

Summary of what was tried:

| Candidate | World | Initial p/h/c | Seeds | Median coexistence | Full 10,000 | Max run time (5 parallel) |
|---|---|---|---|---|---|---|
| contract example (reference, §4) | 64×48 | 400/120/20 | 1–5 | see §4 | see §4 | ~45 s |
| D1 | 96×72 | 900/270/45 | 1–5 | 5,951 | 2/5 | 104 s |
| **D2 (chosen)** | 128×96 | 1600/480/80 | 1–5 | **10,000** | **5/5** | 166 s |
| D2 held-out | 128×96 | 1600/480/80 | 11–15 | **10,000** | **5/5** | 281 s (10 runs in parallel) |
| D3 | 160×120 | 2500/750/125 | 1–5 | 10,000 | 5/5 | 460 s (10 runs in parallel) |

Choice: **D2**. D3 is equally good on seeds 1–5 but about 3× slower (≈ 400–460 s per run under load), too close to the
900 s limit on slower hardware; D2 keeps a margin of > 5× at 4 parallel runs. Parameter variations from the TASK-027
ridge (`hunting.*`) were not needed: area alone turned D1's carnivore starvation (3/5 runs) into full coexistence.
Coexistence is caused by space: a carnivore crash in one region does not end the lineage elsewhere and herbivores
recolonise depleted areas. Every candidate is "parameters only" — no engine change, no anti-extinction rule.

### D1 — 96×72, 900/270/45 (2.25× contract area)
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 1 | 2308 | 2659 | 0 | -/-/5951 | 5,951 | carnivores | 102 |
| 2 | 7051 | 1440 | 85 | -/-/- | 10,000 | - | 85 |
| 3 | 5716 | 1580 | 0 | -/-/3937 | 3,937 | carnivores | 104 |
| 4 | 2455 | 2578 | 0 | -/-/1998 | 1,998 | carnivores | 104 |
| 5 | 7994 | 738 | 52 | -/-/- | 10,000 | - | 66 |

median coexistence 5951 ticks (min 1998, max 10000); 2/5 runs with all three kinds at tick 10000; max elapsed 104.4 s
accounting initial+births-deaths=final and tick_end: OK
### D2 — 128×96, 1600/480/80 (4× area) — **chosen**
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 1 | 10994 | 3012 | 138 | -/-/- | 10,000 | - | 166 |
| 2 | 12349 | 2052 | 60 | -/-/- | 10,000 | - | 149 |
| 3 | 12855 | 1381 | 71 | -/-/- | 10,000 | - | 147 |
| 4 | 11377 | 2472 | 115 | -/-/- | 10,000 | - | 165 |
| 5 | 12563 | 2027 | 110 | -/-/- | 10,000 | - | 166 |

median coexistence 10000 ticks (min 10000, max 10000); 5/5 runs with all three kinds at tick 10000; max elapsed 166.5 s
accounting initial+births-deaths=final and tick_end: OK
### D3 — 160×120, 2500/750/125 (6.25× area)
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 1 | 19790 | 2307 | 196 | -/-/- | 10,000 | - | 439 |
| 2 | 18372 | 3367 | 244 | -/-/- | 10,000 | - | 460 |
| 3 | 20592 | 1577 | 126 | -/-/- | 10,000 | - | 437 |
| 4 | 20303 | 1887 | 182 | -/-/- | 10,000 | - | 390 |
| 5 | 20123 | 1966 | 150 | -/-/- | 10,000 | - | 390 |

median coexistence 10000 ticks (min 10000, max 10000); 5/5 runs with all three kinds at tick 10000; max elapsed 460.2 s
accounting initial+births-deaths=final and tick_end: OK
### D2 confirmation on held-out seeds 11–15 (never used for selection)
| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |
|---|---|---|---|---|---|---|---|
| 11 | 13565 | 857 | 87 | -/-/- | 10,000 | - | 197 |
| 12 | 10346 | 3113 | 64 | -/-/- | 10,000 | - | 262 |
| 13 | 12424 | 1599 | 114 | -/-/- | 10,000 | - | 281 |
| 14 | 13197 | 804 | 78 | -/-/- | 10,000 | - | 275 |
| 15 | 12133 | 1872 | 69 | -/-/- | 10,000 | - | 251 |

median coexistence 10000 ticks (min 10000, max 10000); 5/5 runs with all three kinds at tick 10000; max elapsed 280.6 s
accounting initial+births-deaths=final and tick_end: OK


## 6. Randomised invariant tests

`crates/evosim-core/tests/randomized_invariants.rs` (7 tests, fixed generator seeds, ~4 s in release). Random
configurations: world 1–48 × 1–40 (1/8 chance of 1–3 cells per axis), initial counts 0 … dense (1/6 chance of zero
per kind), random seeds, random subsets of 11 integer and 9 float parameters (litter, speed, vision, dispersal, cell
capacity, cooldown, year length, hunting success, prey density half, growth, seed rate, mutation rates/strength,
seasonality, weather sd), weather and pollination on/off. On failure the config JSON and tick are printed.

| Test | Cases | Invariants |
|---|---|---|
| `accounting_ranges_no_replenishment` | 100 configs × 150–400 ticks, checked every tick | `initial+births = deaths+alive` per kind; Σ deaths_by_cause = deaths; zero stays zero; living species ≤ alive (≥ 1 if alive); positions in torus; traits in range; energy/health finite in [0, max]; birth tick ≤ now; `Population::validate`; every cell's temperature/precipitation finite and inside `climate_bounds` |
| `plants_zero_starves_animals_in_random_configs` | 8 configs, ≤ 5,000 ticks | with `initial.plants = 0` both animal kinds die out, plants never appear |
| `wrapping_properties` | 200 random tori × 20 | wrap in bounds, period invariance, shortest offset reproduces target, `|offset| ≤ ⌊n/2⌋`, distance symmetric = Chebyshev of offset, `within(r)` = brute-force set without duplicates |
| `spatial_index_matches_brute_force_near_seams` | 25 random worlds × 30 seam-biased centres × 4 filters | index `within` == brute force over living organisms, sorted (distance, id) |
| `climate_seams_continuous_random_sizes` | 60 random sizes 2–70 | max step across both seams ≤ max interior step (temperature, precipitation) |
| `determinism_and_seed_sensitivity` | 24 configs, 50–250 ticks | two runs give equal state_hash, totals and per-tick series; another seed gives a different hash |
| `checkpoint_split_equivalence` | 20 configs, random A, B ≤ 150 | restore keeps the hash; A + B == uninterrupted A+B (hash, totals) |

No engine bug was found by these tests; no engine code was changed in TASK-028.

# TASK-023 PLAN cycle 1 — UI window and world view

Design: [ADR-026](../../../docs/decisions/ADR-026-ui-server-world-view.md) (refines ADR-002). Read it first; this file is the ordered work list.

## Facts verified during planning (2026-11-23)
- `crates/evosim-ui` is a placeholder (`available() -> false`, 1 test `placeholder_reports_unavailable`); CLI `crates/evosim-cli/src/lib.rs:110-124` routes `ui` to "not implemented" (exit 2) and has `load_config_file(path) -> Result<Config,String>` (line 138).
- Cargo cache has only serde/serde_json(+deps); tiny_http NOT cached → std-only HTTP server (ADR-026 §1). Network exists, but no new crates are needed.
- `chromium` = `/usr/local/bin/chromium` wrapper (adds `--no-sandbox`), Chromium 131. `chromium --headless --window-size=1440,900 --screenshot=/tmp/cr/a.png file:///tmp/cr/p.html` wrote a PNG in <1 s; a `data:` URL wrote nothing. dbus/GLib error lines on stderr are harmless noise.
- Core API available: `Simulation::new(Config)`, `step()`, `tick()`, `config()`, `world().climate().biome(Cell)`, `Biome::{ALL,name,symbol,rgb,rule}`, `organisms().alive(Kind)` / `count_alive(Kind)`, organism getters (pos, energy, kind), `living_species(kind)`, `climate::season::year_phase(tick, year_length)`, `config.climate.year_length`. Check getter names of `Organism` (`pos()`, `energy()`; max energy from config per kind) when implementing.
- No system packages needed (chromium and xvfb-run preinstalled).

## Ordered implementation steps
1. **`crates/evosim-ui/src/http.rs`** — minimal HTTP/1.1: `Request{method,path,query,body}`, `parse_request(&mut impl BufRead) -> Result<Request,HttpError>`, `Response{status,content_type,body:Vec<u8>}`, `write_response`. Limits: header 16 KiB, body 1 MiB, read timeout 5 s. Unit tests: GET with query, POST with body, malformed → 400, oversize → 413.
2. **`crates/evosim-ui/src/frame.rs`** — `world_json(&Simulation) -> String` (biome grid base64, legend entries), `encode_frame(&Simulation, running, tps) -> Vec<u8>` (EVF1 layout ADR-026 §3), `base64_encode`. Unit tests: record count == sum of `count_alive`, header magic/len, coordinates match organisms, base64 known vectors (RFC 4648 "", "f", "fo", "foo", "foobar").
3. **`crates/evosim-ui/src/session.rs`** — `UiSession::new(config) -> Result<_,String>` (via `Simulation::new`), shared state (`Mutex<Simulation>`, `Mutex<Arc<Vec<u8>>>` latest frame, `AtomicBool running/stop`, target tps, `Mutex<Option<AutotestReport>>`), `spawn_sim_thread()` (pacing per ADR-026 §2; `fast_until: Option<u64>` for automation), `stop()`.
4. **`crates/evosim-ui/src/server.rs`** — `Server::bind(port: u16 /*0 = ephemeral*/)`, accept loop thread, routing (`/`, `/app.js`, `/style.css`, `/api/world`, `/api/frame`, `POST /api/autotest/report`), `local_url()`; shutdown via stop flag + self-connect to unblock accept.
5. **`crates/evosim-ui/src/automation.rs`** — `find_chromium()`, `spawn_chromium(url, extra_args) -> Child` with temp `--user-data-dir` (under `std::env::temp_dir()`, removed afterwards), `smoke_test(config) -> Result<SmokeSummary,String>`, `screenshots(config, dir) -> Result<Vec<PathBuf>,String>`, `png_dimensions(path)` (signature + IHDR). Timeouts 50 s / 100 s. Exactly as ADR-026 §8.
6. **`crates/evosim-ui/src/lib.rs`** — `available() -> true`; `pub struct UiOptions{config, mode: UiMode::{Interactive{port}, Smoke, Screenshots(PathBuf)}}`; `pub fn run(opts, out, err) -> u8` (0 ok, 1 automation failure, 2 usage like missing DIR). Interactive: bind `127.0.0.1:<port>` (default 8765; if taken → ephemeral), print `Evolution Simulation UI: http://127.0.0.1:PORT/  (Ctrl+C to quit)`, block until killed. Replace the placeholder test.
7. **Web assets `crates/evosim-ui/web/{index.html,style.css,app.js}`** — layout/legend/rendering/pan-zoom/polling/autotest per ADR-026 §4–7. Put pure camera math in `app.js` behind `if (typeof module !== 'undefined') module.exports = {...}` so node can `require` it; DOM code only runs when `document` exists. Legend symbols drawn with the same functions as the map. Autotest: read `?autotest=smoke|shots&zoom=N`, POST report (smoke: after ≥5 frames and tick advance ≥10 or 8 s real time; shots: after first full draw of a frame with tick ≥100).
8. **CLI wiring `crates/evosim-cli/src/lib.rs`** — new `ui.rs`: parse `[--config FILE] [--smoke-test | --screenshots DIR] [--port N]`; `--config` via `load_config_file` (error → exit 2); default config = the `default` preset (find the existing preset accessor used by `config presets`); mutually exclusive smoke/screenshots → exit 2; unknown flag → exit 2; `--help` stays. Update help text (drop "(not implemented yet)") and usage lines (add `--port`). Remove the dead `"ui" if available()` arm.
9. **Tests**
   - Unit tests in steps 1, 2, 5 (`png_dimensions` on a hand-made PNG header).
   - `crates/evosim-ui/tests/server.rs`: start session+server on port 0 with a small config, GET `/` contains `<canvas`, `/app.js` 200, `/api/world` JSON width×height cells decode to width*height bytes with ids < 6, `/api/frame` magic + counts match, frames advance over 1 s, 404 path. Plus 1,000-organism fixture throughput test (ADR-026 §9).
   - `crates/evosim-cli/tests/cli.rs`: `ui --bogus` → 2, `ui --screenshots /nonexistent` → 2, `ui --smoke-test --screenshots x` → 2, `ui --config missing.json --smoke-test` → 2. Do NOT launch chromium in cargo tests (keep `cargo test` browser-free); end-to-end goes in check-entrypoints.
   - `crates/evosim-ui/web/test/camera.test.js` run with `node --test crates/evosim-ui/web/test/` (zoomAt keeps the world point under cursor fixed; screen↔world round trip; wrap modulo). Add to `test.sh`.
   - `scripts/check-entrypoints.sh`: `./evosim ui --smoke-test` exit 0 under `xvfb-run -a` (and also without xvfb), elapsed < 60 s; `./evosim ui --screenshots $TMP/shots` exit 0 < 120 s, `main.png` ≥1280×720 (check with python3 struct on IHDR); `./evosim ui --smoke-test --config crates/evosim-ui/tests/fixtures/ui-1000.json` reports fps ≥ 4 (or `scripts/ui-perf.sh`). Update any existing check expecting `ui` → exit 2.
10. **Docs** — README "User interface" section (`./setup.sh`, `./evosim ui [--config FILE] [--port N]`, open printed URL, pan = drag, zoom = wheel/+/−/Fit, legend, smoke/screenshots commands); docs/ARCHITECTURE.md (evosim-ui modules, std HTTP instead of tiny_http, protocol); docs/STATE.md status + test evidence; ADR-026 status note on which screenshot mechanism was used.
11. **Run** `./test.sh`, `cargo clippy --workspace --all-targets --release --locked -- -D warnings`, `xvfb-run -a ./evosim ui --smoke-test`, `./evosim ui --screenshots /tmp/shots` and look at `main.png` (Read tool) for visual quality.

## Acceptance mapping
| Must have | Evidence |
|---|---|
| `./evosim ui` starts local server + browser page, same engine | lib.rs/session use `Simulation::new`+`step`; server integration test; README |
| cells coloured by biome, organisms on top, kinds distinguishable | `/api/world` + frame tests; main.png; shape+colour per kind |
| legend | sidebar legend in index.html/app.js, visible in main.png |
| pan + zoom | camera node tests; UI handlers; zoomed screenshot |
| 1,000 organisms usable | fixture fps ≥ 4 via smoke perf + frame throughput test |
| smoke test on virtual display | `xvfb-run -a ./evosim ui --smoke-test` exit 0 < 60 s in check-entrypoints |
| README | README section |

## Risks
- `--virtual-time-budget` + live network: if the screenshot is captured before the frame is drawn, use `--timeout` fallback or make the page draw synchronously after awaiting fetches; verify main.png visually.
- Headless chromium keeps running in smoke mode — always kill the child and wait; leftover processes could hold ports.
- Thread-per-connection server: polling at 30 fps is fine; ensure sockets closed (Connection: close) to avoid FD leaks.
- Sim step time for large worlds may exceed pacing; frame publishing must not hold the Simulation lock while encoding? (encode under the lock is OK — ~µs for 1k organisms; measure).
- Port 8765 might be taken → fall back to ephemeral and print the actual URL.

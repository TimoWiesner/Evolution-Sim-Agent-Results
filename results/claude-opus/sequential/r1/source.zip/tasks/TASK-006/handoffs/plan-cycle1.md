# TASK-006 PLAN cycle 1 — Climate zones and biomes

Design record (binding): `docs/decisions/ADR-009-climate-zones.md`. std + serde_json only, no new crates, Cargo.lock unchanged. Out of scope: seasons/weather (TASK-007), effects on organisms.

## Ordered implementation steps

1. **Config keys** — `crates/evosim-core/src/config/params.rs`, `ClimateParams` (append after `weather_persistence`):
   ```
   noise_temperature: f64 = 1.5, "Amplitude of the seeded static temperature anomaly field (deg C)", [0, 20];
   noise_precipitation: f64 = 0.05, "Amplitude of the seeded static precipitation anomaly, relative to max_precipitation", [0, 1];
   noise_scale: u32 = 16, "Feature size of the climate anomaly field in cells", [1, 4096];
   ```
   Regenerate the table in `docs/CONFIG.md` with `./evosim config schema` (test `config_doc_table_is_current` enforces). Also correct the `equator_temperature` doc to "Base temperature at the equator row" if desired (then regenerate). Presets unchanged.

2. **New module `crates/evosim-core/src/climate/`** (`mod.rs`, `biome.rs`, `noise.rs`, `export.rs`, `tests.rs`); add `pub mod climate;` in `lib.rs` (+ crate doc). Must not use any token banned by `sim::tests::core_source_has_no_wall_clock_or_global_rng` (no hashed collections, wall clock words, global RNG).
   - `biome.rs`:
     ```rust
     #[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
     pub enum Biome { Polar, Tundra, Temperate, Desert, Savanna, Tropical } // cold → hot; Ord = this order
     impl Biome {
       pub const ALL: [Biome; 6];
       pub fn rank(self) -> u8;            // 0..5
       pub fn name(self) -> &'static str;  // "polar","tundra","temperate","desert","savanna","tropical"
       pub fn symbol(self) -> char;        // I U F D S R
       pub fn rgb(self) -> [u8; 3];        // ppm colours (e.g. polar 235,245,255; tundra 150,170,160; temperate 60,140,60; desert 230,200,120; savanna 190,180,70; tropical 10,100,30)
       pub fn is_dry(self) -> bool;        // Desert | Savanna
       pub fn classify(temperature: f64, precip_rel: f64) -> Biome; // thresholds in ADR-009: T<-10 Polar, <0 Tundra, <18 Temperate, else r<0.3 Desert, r<0.6 Savanna, else Tropical
     }
     pub const POLAR_MAX_T: f64 = -10.0; TUNDRA_MAX_T = 0.0; TEMPERATE_MAX_T = 18.0; DESERT_MAX_R = 0.3; SAVANNA_MAX_R = 0.6;
     ```
   - `noise.rs`: `pub struct PeriodicNoise { gx: u32, gy: u32, v: Vec<f64> }`;
     `PeriodicNoise::new(width, height, scale, rng: &mut Rng)` (gx = max(1, round(w/scale)) computed in integer math: `((w + scale/2) / scale).max(1)`, same for gy; values `2*rng.next_f64()-1` row-major);
     `sample(&self, fx: f64, fy: f64) -> f64` where fx, fy are lattice coordinates (wrap via `rem_euclid(gx as f64)`, i0 = floor, i1 = (i0+1)%gx, smoothstep, bilinear);
     `at_cell(&self, x, y, w, h) -> f64` = `sample((x+0.5)*gx/w, (y+0.5)*gy/h)`. Output ∈ [−1, 1].
   - `mod.rs`:
     ```rust
     pub const CLIMATE_SEED_TAG: u64 = 0xC1A7_E5EE_D000_0006;
     pub fn latitude_deg(y: u32, height: u32) -> f64;           // 90*|1-2u|, u=(y+0.5)/h ; in [0,90]
     pub fn latitude_deg_f(fy: f64, height: u32) -> f64;        // continuous version, periodic in fy with period h (use rem_euclid)
     pub fn zonal_temperature(p: &ClimateParams, lat_deg: f64) -> f64;     // T_pole + (T_eq-T_pole)*cos(lat)
     pub fn zonal_precipitation_rel(lat_deg: f64) -> f64;                   // min(1, 0.10+0.90 g(0,15)+0.55 g(55,15))
     #[derive(Debug, Clone, Copy, PartialEq)]
     pub struct CellClimate { pub latitude: f64, pub temperature: f64, pub precipitation: f64, pub biome: Biome }
     #[derive(Debug, Clone, PartialEq)]
     pub struct ClimateMap { width: u32, height: u32, cells: Vec<CellClimate>, noise_t: PeriodicNoise, noise_p: PeriodicNoise, params: ClimateParams }
     impl ClimateMap {
       pub fn generate(torus: &Torus, params: &ClimateParams, seed: u64) -> ClimateMap; // rng = Rng::seed_from_u64(seed ^ TAG); noise_t then noise_p; cells in torus.cells() (row-major) order
       pub fn from_config(config: &Config) -> Result<ClimateMap, TopologyError>;
       pub fn sample(&self, fx: f64, fy: f64) -> CellClimate;    // continuous evaluation at cell coords (cell centre of (x,y) = (x as f64, y as f64)); used by tests to prove periodicity
       pub fn width/height; pub fn get(&self, c: Cell) -> &CellClimate; pub fn biome(c)/base_temperature(c)/base_precipitation(c);
       pub fn cells(&self) -> &[CellClimate];                    // row-major
       pub fn biome_counts(&self) -> [usize; 6];                 // by rank
     }
     ```
     Cell value = `sample(x, y)`; precipitation = `P_max * clamp(p_lat + A_P*nP, 0, 1)`; biome = `classify(T, if P_max>0 {P/P_max} else {0})`. Keep the formula in one function so grid and continuous sample are bit-identical.
   - `export.rs`: `pub fn to_text(&ClimateMap) -> String` (h lines of w symbols, blank line, legend `I polar (T < -10)` …, counts line);
     `pub fn to_json(&ClimateMap) -> serde_json::Value` (`{"width","height","biomes":[{"symbol","name","rank"}],"rows":[strings],"temperature":[[f64]],"precipitation":[[f64]],"latitude":[f64 per row],"counts":{name:n}}`);
     `pub fn to_ppm(&ClimateMap) -> Vec<u8>` (`P6\n{w} {h}\n255\n` + RGB per cell row-major).

3. **World integration** — `crates/evosim-core/src/sim/world.rs`: `World { torus, climate: ClimateMap }`; `from_config` builds both; `pub fn climate(&self) -> &ClimateMap`. `Simulation::new`/`resume` unchanged otherwise (climate is a pure function of config; does not consume the core RNG — existing sim golden/determinism tests must still pass unchanged). Update `run_phase` comment: Climate slot = TASK-007 (base climate is static, built at world creation).

4. **CLI** — `crates/evosim-cli/src/lib.rs`: new command `climate`:
   `evosim climate map [--config FILE | --preset NAME] [--seed N] [--width W --height H] [--format text|json|ppm] [--out FILE]`
   - default source: `Config::contract_example()`-equivalent defaults (or preset `default`); `--seed`, `--width`, `--height` override (validate via config re-validation; w/h ≥ 1, ≤ MAX_DIM; errors → exit 2 on stderr).
   - text/json to stdout unless `--out`; ppm requires `--out` (binary; exit 2 otherwise). Success exit 0. Add usage lines to `usage()`. Unit tests in lib.rs, integration tests in `crates/evosim-cli/tests/cli.rs`.
   - Optionally add one check to `scripts/check-entrypoints.sh` (`./evosim climate map --format json` parses).

5. **Docs** — new `docs/CLIMATE.md` (user-facing: formulas, zone table, the topology compromise text from ADR-009 "Rationale", example text map of the default 64×48 world produced by the command, how to export); link from README and ARCHITECTURE; update STATE.md test results; ARCHITECTURE `climate` row → implemented (ADR-009).

## Tests (crates/evosim-core/src/climate/tests.rs) — mapping to Must-have
| Must-have | Test(s) |
|---|---|
| every cell has biome, base T, base P from position | `every_cell_has_finite_climate` (all cells finite T, P∈[0,P_max], latitude∈[0,90]); `climate_is_function_of_position_and_seed` (generate twice → equal; same row & noise off → equal across x; different seed → different noise field when noise on); `latitude_formula_values` (h=48: row 0 and 47 lat 88.125, row 23/24 lat 1.875) |
| Earth-like order | `default_zone_order_pole_to_equator`: default params, noise 0, h ∈ {48, 100, 37}: walking y from 0 to h/2 the biome rank is non-decreasing and all 6 biomes appear for h=48 (expected row string `IIIIUUUUFFFFFFDDDDDSSRRRRRR…`); `presets_preserve_order` (default/lush/harsh/plants-only, noise 0: non-decreasing ranks); `noise_does_not_scramble_zones` (default noise, 64×48, seeds 1..20: per-row majority biome rank non-decreasing from pole to equator); `classify_thresholds` boundary unit tests |
| no seam | `seam_pairs_no_larger_than_interior` for sizes {64×48, 33×17, 100×7, 7×100, 16×16, 5×5, 3×3} × seeds 0..30, noise on and off: per axis, max |ΔT|, |ΔP| and |Δrank| over seam pairs (x=w-1↔0, y=h-1↔0) ≤ max over interior pairs of the same axis + 1e-9 (when the axis has interior pairs, i.e. dim ≥ 3); `all_neighbour_pairs_within_lipschitz_bound` (every 8-neighbour pair incl. seams: |ΔT| ≤ (T_eq−T_pole)·π/h + A_T·3·(gx/w+gy/h) + 1e-9 — derive bound in code comment; analogous for P); `continuous_field_is_periodic` (sample(fx+w, fy) == sample(fx, fy) and sample(fx, fy+h) within 1e-9 for fractional points; grid equals sample at integer points bitwise); `noise_lattice_wraps` (PeriodicNoise unit tests) |
| docs explain compromise | docs/CLIMATE.md + ADR-009 (reviewer reads); optional doc test that CLIMATE.md contains "compromise" |
| print/export without UI | CLI tests: `climate_map_text_default` (exit 0, h lines of w chars from {IUFDSR}, legend), `climate_map_json_parses` (width/height/rows match config), `climate_map_ppm_written` (header `P6\n64 48\n255\n`, length = header + 3·w·h), `climate_map_bad_args_exit_2`; core unit tests for to_text/to_json/to_ppm |
| any size incl. tiny | `tiny_worlds_work`: all w,h ∈ 1..=9 plus 1×1000, 1000×1, 2×2 × seeds {0,1,u64::MAX}: no panic, finite values, seam test conditions hold (for dim < 3 only the Lipschitz bound), h=1 → lat 0; `large_world_builds` 1024×512 quick |
| determinism / isolation | `climate_does_not_consume_core_rng` (Simulation::new rng_state equals Rng::seed_from_u64(seed).state()); existing sim tests unchanged |

Python cross-check (optional, IMPLEMENT): `/tmp/clim.py` style transcription of the zonal formulas reproduced pole→equator strings: default 48 rows `IIIIUUUUFFFFFFDDDDDSSRRRRRRSSDDDDDFFFFFFUUUUIIII`; lush (pole −10) `UUUUFFFFFFFFFDDDDDDSSRRRRRRSS…`; harsh (22/−40) `IIIIIIIIUUUFFFFFFFDSSRRRRRRSSD…`; h=1 `R`, h=2 `FF`, h=3 `FRF`, h=5 `UFRFU`.

## Commands for IMPLEMENT/REVIEW
- `cargo test -p evosim-core --release --locked climate`
- `cargo test -p evosim-cli --release --locked`
- `./test.sh` (whole suite; runs setup/build)
- `./evosim climate map` / `./evosim climate map --format json --out /tmp/c.json` / `./evosim climate map --format ppm --out /tmp/c.ppm` (record outputs in handoff)
- `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`

## Risks
- Seam ≤ interior test with noise is a statistical property for random lattice values (seam is centred on a lattice point where smoothstep has zero slope, so it is structurally the smoothest place; still verify over the full seed sweep). If a seed fails, do not weaken silently: check the alignment `(x+0.5)*gx/w` first; the periodicity test is the structural proof. Document any adjustment.
- Narrow bands on small worlds (savanna ≈ 2 rows at h=48); h < 5 cannot show all zones — documented, not a failure (the criterion is "works", not "all zones visible").
- f64 transcendental functions (cos/exp) may differ in last bits across platforms — allowed ("minor inter-platform differences"); same machine is deterministic.
- Adding config keys changes `config show`/schema outputs; update CONFIG.md via the schema command.

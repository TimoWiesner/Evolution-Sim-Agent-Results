# TASK-016 PLAN cycle 1 — Animal reproduction

Design: [ADR-019](../../../docs/decisions/ADR-019-animal-reproduction.md) (read it first; this file is the ordered work list).

## Code facts found during planning
- `animals/herbivore.rs::herbivore_turn` and `animals/carnivore.rs::carnivore_turn` are the per-animal turns; `World::act_animals` (sim/world.rs) computes `ids = acting_order(alive_ids(kind), rng)` and dispatches. The mating pass is added there, after the turn loop, reusing `ids`.
- `plants/repro.rs` is the pattern to copy (filter → order → chance → spend → `child_sexual` → `request_birth`).
- `Population::resolve_births` already records `Parents::Two` and computes `generation = 1 + max(parents)`; it drops births whose parent is dead or whose cell is full.
- `satiety = (0.6 + 0.4·aggression)·max_energy` → founders: herbivore 80 (threshold 70), carnivore 128 (threshold 110). Ready animals therefore exist only in the band threshold…satiety+ for foraging animals; fine.
- Existing keys: `<kind>.maturity_age` (100/150), `reproduction_threshold` (70/110), `reproduction_cost` (35/55), `mating_threshold` (0.2). Founder genome distance ≈ 0.023 ⇒ founders compatible.
- `Genome::from_genes(kind, Vec<f32>)` lets tests build genomes with fertility gene 0 or 1 (gene index from `gene_table(kind)` by name `"fertility"`).
- Organism age is private; tests that need mature animals should set `maturity_age = 0` in the config (simplest) or use a `pub(crate)` test helper.

## Ordered steps
1. **organism/mod.rs**: add `cooldown: u32` to `Organism` (init 0 in `new`), getter `cooldown()`, `pub(crate) fn set_cooldown(u32)`. **organism/population.rs** `end_of_tick` aging step: `cooldown = cooldown.saturating_sub(1)` for every living organism (also newborns is harmless). Add any `pub(crate)` test helper for age if needed (`set_age_for_test` under `#[cfg(test)]`).
2. **config/params.rs**: add to HerbivoreParams / CarnivoreParams: `mating_cooldown: u32 = 40 / 80 [0, 10_000_000]`, `conception_chance: f64 = 0.5 [0,1]`, `max_litter: u32 = 3 / 2 [1,16]`. Update `docs/CONFIG.md` table rows (generated table if a generator/test exists — check config tests that compare docs/schema; update counts).
3. **animals/repro.rs** (new): `MATING_REACH: u32 = 1`; `ReproParams { maturity_age, threshold, cost, mating_threshold, cooldown, conception_chance, max_litter, mutation: MutationParams }` + `for_kind(kind, cfg)` (None/panic-free for Plant: return params but `reproduce_animals` no-ops on Plant); `is_ready(&Organism, &ReproParams) -> bool`; `compatible(&Organism, &Organism, &ReproParams) -> bool`; `conception_probability(f, rp)`; `litter_condition(...)`; `find_mate_in_reach(pop, id, rp, engaged) -> Option<EntityId>`; `visible_mate(pop, id, r, rp) -> Option<Neighbour>` (for Court); `birth_sites(pop, a_pos, b_pos, kind, placed) -> Vec<(Cell, u32 free)>`; `reproduce_animals(pop, ids, kind, cfg, tick, rng) -> AnimalReproTick`; `AnimalReproTick` + `ReproLedger { total: AnimalReproTick, last: AnimalReproTick, record() }`. Exactly the ADR-019 step order and RNG draw order (conception draw, then max_litter−1 litter draws, then per-child crossover+mutation draws).
4. **animals/herbivore.rs / carnivore.rs**: new enum variant `HerbivoreAction::Court` / `CarnivoreAction::Court`; branch placement per ADR-019 (herbivore: after flee, before rest; carnivore: after handling, before rest). Turn functions need `&ReproParams` → add parameter (update `act_*` and test call sites) or build from cfg inside `act_*` and pass down. Count `courted` in FeedTick/HuntTick (optional).
5. **animals/mod.rs**: `pub mod repro; #[cfg(test)] mod tests_repro;` re-exports. Module doc line.
6. **sim/world.rs**: `repro_ledger: [ReproLedger; 2]`; in `act_animals` after the kind's act call: `let r = reproduce_animals(&mut self.organisms, &ids, kind, cfg, tick, rng); self.repro_ledger[i].record(&r);` getter `repro_ledger(kind)`. sim/mod.rs run_phase comment mentions TASK-016.
7. **Tests** `animals/tests_repro.rs` (below), then fix existing tests broken by the changed RNG stream/behaviour (record which and why in the implement handoff; do not weaken invariant tests).
8. **Docs**: docs/ANIMALS.md section "Reproduction (TASK-016, ADR-019)"; docs/ARCHITECTURE.md animals row (implemented); docs/STATE.md TASK-016 notes + smoke numbers; docs/decisions/README.md already lists ADR-019.
9. `./test.sh` and `cargo clippy --release -p evosim-core --all-targets`.

## Tests (map to acceptance criteria)
AC1 (requirements, never with itself):
- `pair_in_reach_reproduces` — two ready founder herbivores in the same/adjacent cell (incl. across the x wrap), conception_chance 1 → ≥1 birth request, `Parents::Two(a,b)` with a≠b.
- `no_mating_beyond_reach` (distance 2), `no_mating_when_immature` (maturity_age > age), `no_mating_low_energy` (energy < threshold, and energy ≤ cost), `no_mating_incompatible` (genomes differing so distance > mating_threshold; also boundary d == threshold mates), `no_mating_across_kinds` (herbivore + carnivore adjacent), `no_mating_with_dead_partner` (partner killed first).
- `animal_never_mates_with_itself` — ids list containing the same ready animal twice, many ticks → zero requests.
AC2: `child_genome_is_crossover_of_parents` (mutation_rate 0: each locus equals a's or b's gene; across many children both parents contribute); `child_mutates` (rate 1 → genes outside parents' set appear); `birth_records_parents_and_generation` (step Simulation → child `parents() == Two(a,b)`, `generation == 1 + max`; use parents of different generations if possible via a two-step lineage or just founders → 1).
AC3: `both_parents_pay` — each parent energy drops by exactly `reproduction_cost`; ledger `offspring_energy ≤ energy_spent`; failed conception costs nothing.
AC4: `cooldown_blocks_remating` — after a mating both cooldowns == mating_cooldown; with energy restored each tick, no new mating for the next mating_cooldown−1 ticks; mates again afterwards (drive via `reproduce_animals` + `end_of_tick` or `Simulation::step_with`).
AC5: `fertility_changes_offspring` — pairs with fertility gene 0 vs 1 (other genes equal), same seeds, 500 trials each → mean offspring (conception rate and litter size) strictly larger for 1; `litter_bounds` 1 ≤ n ≤ max_litter and ≤ free slots.
AC6: `lone_herbivore_never_reproduces` — Simulation with 1 herbivore, plants, maturity_age 0, 3000 ticks (or until it dies) → `totals.births[Herbivore] == 0`; `lone_carnivore_never_reproduces` — direct `reproduce_animals` loop 2000 ticks with energy topped up → 0 requests.
Extra: `courting_moves_towards_mate` (ready herbivore at distance 3 from a ready mate, no food → action Court, distance shrinks); `reproduction_deterministic` (same seed ⇒ same births, different seed differs); `runs_keep_invariants` — contract example 2000 ticks: `living == initial + births − deaths` per kind, every animal birth has `Parents::Two` with distinct same-kind parents, ledger invariant; `#[ignore] smoke_reproduction` printing counts every 250 ticks for STATE.md.

## Expected behaviour / risks
- With default hunting, herbivores fall to ~3 by t100 (TASK-015 smoke) before maturity (100): reproduction may not rescue the default run; tuning is TASK-018/027. Record smoke numbers; do not tune hunting here unless trivially needed.
- Population growth bounded by food and per-cell capacity; check runtime of the 2000-tick test stays well under a few seconds in release.

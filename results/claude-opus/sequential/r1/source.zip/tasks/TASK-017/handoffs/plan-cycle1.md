# TASK-017 PLAN cycle 1 — Species and family tree

Design: [ADR-020](../../../docs/decisions/ADR-020-species-family-tree.md) (read first). This file is the ordered work list.

## Code facts found during planning
- No species code exists yet. `sim/mod.rs::run_phase` has an empty `Phase::Species` slot (after Deaths, before Statistics).
- Every organism is created in exactly two places: `Population::founders` (organism/population.rs) and `Population::resolve_births`; every death goes through `Population::kill` (natural deaths in `end_of_tick` call `kill` too). These are the hook points.
- `Organism::new` is `pub(crate)`, called with `(id, pos, genome, expr, parents, generation, birth_tick, energy, health)`. Tests construct organisms through Population/BirthRequest; check `grep -rn "Organism::new"` for all call sites.
- `genome::distance(&Genome,&Genome) -> f64` (f64 sum over f32 genes, weights from gene table). `Genome::from_genes(kind, Vec<f32>)` builds test genomes.
- Config keys `plants/herbivores/carnivores.species_threshold` (0.15) already exist in config/params.rs (plants also use it as pollen compatibility). No new config key needed.
- `EventKind` is `#[non_exhaustive]`; do NOT add a field to `EventKind::Birth` (organism/tests.rs:523 constructs it exactly). Add new variants instead.
- Core source scan test forbids hashed-collection / wall-clock tokens: use `Vec`/`BTreeMap` only.
- `Population::new()/default()` exists (tests); the registry needs a `Default` with thresholds 0.15.

## Ordered steps
1. **New module `crates/evosim-core/src/species/mod.rs`** (+ `names.rs`, `tests.rs`), `pub mod species;` in lib.rs (update crate doc).
   - `#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] pub struct SpeciesId(pub u32);`
   - `pub struct SpeciesRecord { id, kind: Kind, name: String, parent: Option<SpeciesId>, root: SpeciesId, origin_tick: u64, extinct_tick: Option<u64>, representative: Genome, living: u64, ever: u64, daughters: Vec<SpeciesId> }` with getters (`is_extinct()`, `code()` → "P3").
   - `pub struct SpeciesRegistry { records: Vec<SpeciesRecord> /* index id-1 */, thresholds: [f64; 3], living_per_kind: [u64; 3], journal: Vec<SpeciesChange> }`, `Default` (thresholds 0.15), `from_config(&Config)`, `with_thresholds([f64;3])`.
   - `pub(crate) fn classify_founder(&mut self, g: &Genome, tick: u64) -> SpeciesId` (root search, ADR-020 step 1).
   - `pub(crate) fn classify_child(&mut self, mother_species: SpeciesId, g: &Genome, tick: u64) -> SpeciesId` (steps 2a–2c; `≤` comparison; new record appended, pushed into parent's `daughters`, journal `Appeared`). Both increment `living`/`ever`/`living_per_kind`.
   - `pub(crate) fn on_death(&mut self, s: SpeciesId, tick: u64)`: decrement; at 0 set `extinct_tick = Some(tick)`, `living_per_kind -= 1`, journal `Extinct`.
   - Queries: `get(id)`, `iter()`, `len()`, `of_kind(kind)`, `living_count(kind) -> usize`, `living_count_at(kind, tick) -> usize`, `lineage(id) -> Vec<SpeciesId>` (self → root), `threshold(kind)`, `pub(crate) take_journal() -> Vec<SpeciesChange>`.
   - `pub enum SpeciesChange { Appeared { id, kind, parent: Option<SpeciesId>, tick }, Extinct { id, kind, tick } }`.
   - `pub(crate) fn check(&self, living: impl Iterator<Item=(Kind, SpeciesId)>) -> Result<(), String>` for validate: every species id exists, kind matches, per-species living counts equal, `extinct_tick.is_some() == (living == 0)`, `living_per_kind` consistent.
   - `names.rs`: `pub fn species_name(kind, root: SpeciesId, id: SpeciesId) -> String`; fixed syllable table (e.g. 16 syllables "ka","lo","mi","ru","te","va","no","si","pa","de","xo","bu","ri","ze","fa","ul"), bijective base-16 word of `id` (1 → "ka", 17 → "kaka"…), genus = capitalised word(root) + suffix ("ia"/"odon"/"raptor"), epithet = word(id). Pure, no RNG.
2. **organism/mod.rs**: add `species: SpeciesId` to `Organism` + `pub fn species(&self)`; extend `Organism::new` with a `species` parameter (update all call sites); `BirthRecord` gets `pub species: SpeciesId`; `DeathRecord` may get `species` too (optional).
3. **organism/population.rs**: field `species: SpeciesRegistry`.
   - `founders`: `p.species = SpeciesRegistry::from_config(cfg)`; per founder `let s = p.species.classify_founder(&genome, 0)`.
   - `with_expression`: default registry (callers needing config thresholds use founders or a new `set_species_thresholds`/`with_species` helper for tests).
   - `resolve_births`: after the drop checks pass (do not classify dropped requests!), `mother = first parent id` → `self.get_alive(mother).species()`; `classify_child(m, &r.genome, tick)`; founder-type requests (`Parents::None`, only tests) → `classify_founder`.
   - `kill`: `self.species.on_death(o.species, tick)`.
   - `pub fn species(&self) -> &SpeciesRegistry`; `pub(crate) fn species_mut`.
   - `validate`: call `self.species.check(...)`.
4. **sim/event.rs**: variants `SpeciesAppeared { species: SpeciesId, kind: Kind, parent: Option<SpeciesId> }`, `SpeciesExtinct { species: SpeciesId, kind: Kind }`. **sim/mod.rs** `Phase::Species`: `for c in ctx.world.organisms_mut().species_mut().take_journal() { emit(...) }` (event tick = ctx.tick; record tick inside the change is authoritative). Add `Simulation::species(&self) -> &SpeciesRegistry` and `Simulation::living_species(kind) -> usize`.
5. **Tests** (below). Run `./test.sh`; all existing tests must still pass unchanged (no RNG consumption → identical trajectories). If a test constructs `Organism::new` directly, add the species argument.
6. **Docs**: new `docs/SPECIES.md` (rule, threshold rationale, naming, queries, extinction semantics, caveats); docs/ARCHITECTURE.md `species` row → implemented; docs/STATE.md TASK-017 notes; docs/decisions/README.md row exists (ADR-020).
7. `cargo clippy --release -p evosim-core --all-targets` clean.

## Tests (map to acceptance criteria) — `species/tests.rs` + `species/tests_sim.rs`
AC1 (every organism has a species of its kind, documented rule):
- `every_organism_has_species_of_its_kind` — run default contract config ~200 ticks, at every tick (step_with hook in Species phase or after each step) every living organism's `species()` exists in the registry with the same kind and not extinct.
- `founders_form_one_root_species_per_kind` (default founder_variation) and `distant_founders_form_separate_roots` (genomes built with from_genes, distance > T).
- `validate_accepts_consistent_and_rejects_bad_species` (organism with species of another kind / unknown id → validate error).
AC2 (deterministic IDs and names):
- `same_seed_same_species_registry` — two Simulations with a divergence-prone config (high mutation) run N ticks; registries compared field by field (id, name, kind, parent, origin, extinct, living); at least 2 species exist so the test is meaningful.
- `names_are_pure_and_distinct` — `species_name` deterministic, distinct for ids 1..2000 within a kind, genus shared by descendants of one root, kind suffix correct.
AC3 (split and exact threshold):
- `child_exactly_at_threshold_stays` — registry with thresholds set to exactly `d = distance(child, rep)`; `classify_child` returns mother species, no new record.
- `child_just_above_threshold_splits` — threshold = `next_down(d)` (`f64::from_bits(d.to_bits()-1)`, d>0) → new species, parent = mother, origin_tick = given tick, rep = child genome.
- `daughter_species_reused` — second diverged child near the first one joins the daughter; a child far from both founds a second daughter; a daughter with 0 living is not reused.
- `forced_divergence_splits_in_simulation` — plants-only (or herbivore) config with `mutation_rate 1, mutation_strength 0.3`, run until registry has a species with `parent == Some(root)` and `origin_tick > 0`; assert some living organism belongs to it and its child genome distance to root rep > T; also a control run with `mutation_rate 0` never splits.
- Also integration boundary through `Population::resolve_births`: BirthRequest whose genome has distance exactly T from mother's species rep (construct with from_genes, set registry threshold to that distance) → child in mother's species.
AC4 (records):
- `extinction_tick_recorded` — kill all members of a species at tick t via `Population::kill` → `extinct_tick == Some(t)`, living 0, `living_count` drops; species alive keeps `None`; parent link and origin tick preserved after extinction; event `SpeciesExtinct` emitted in Species phase in a Simulation run (e.g. kill all carnivores via hook, check report).
- `lineage_walks_to_root`.
AC5 (living species per kind queryable at any tick):
- `living_species_count_matches_population_every_tick` — over a run, after each step `living_count(kind) == #distinct species among living organisms of kind` and `living_count_at(kind, t) == living_count(kind)` for the just-finished tick t; history query for earlier ticks equals the values recorded at those ticks.

## Notes for implement
- Keep `Population::kill` behaviour otherwise identical (first cause wins). `on_death` must be called only when kill succeeds.
- Births dropped (dead parent, full cell) must not create species.
- Mother lookup: in `resolve_births` all parents are checked alive before; read mother species before pushing the child (borrow order).
- Performance: one or a few `distance` calls per birth; negligible.

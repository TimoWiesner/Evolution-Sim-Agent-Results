# TASK-014 PLAN cycle 1 — Herbivore feeding and behaviour

Design: [ADR-017](../../../docs/decisions/ADR-017-herbivore-feeding-behaviour.md) (all formulas and constants are there; this file is the ordered work list).

## Current code facts (verified in PLAN)
- `animals/mod.rs::act_animals(pop, ids, kind, cfg, rng) -> MoveTick` is the single policy for both kinds; called by `World::act_animals(kind, cfg, rng)` (`sim/world.rs:163`) from `sim/mod.rs:256-262`.
- Movement API (ADR-016): `steps_allowed`, `move_towards(pop,id,target,max_steps,stop_at,&MoveCosts)`, `move_away(pop,id,threat,max_steps,&MoveCosts)`, `wander(pop,id,allowed,&MoveCosts,rng)`; step numbering restarts per call → use **exactly one** move call per herbivore per tick.
- `Organism::{add_energy, spend_energy}` return the actual amount; `Population::kill(id, cause, tick)`; `DeathCause::{Starvation, Grazed}` exist; `end_of_tick` already kills energy-0 organisms (Starvation) as backstop.
- Existing keys: `herbivores.base_metabolism` 0.5, `herbivores.max_meal` 5.0. Keys to add: `herbivores.climate_cost` (f64 = 1.0, [0,100]), `herbivores.assimilation` (f64 = 0.8, [0,1]) in `config/params.rs` HerbivoreParams. Then regenerate docs/CONFIG.md table (`./evosim config schema` → paste; tests `config/tests.rs:359` and CLI `lib.rs:431` compare it).
- Climate of a cell now: `World::now` (`&[CellNow]`, row-major `y*w+x`), founder animal temp opt 10 °C, tol 16 °C.
- Genes: `Traits::aggression`, `Traits::caution` (gene names "aggression", "caution", `gene_index(kind, GeneTrait::Aggression/Caution)`).

## Ordered implementation steps
1. **Config**: add the two keys (above) to HerbivoreParams; regenerate docs/CONFIG.md; config tests still pass.
2. **`animals/feed.rs`** (new, pure functions, no RNG):
   - consts `PLANT_TOUGHNESS=0.5, GRAZE_RESERVE=0.25, SATIETY_BASE=0.6, GOOD_ENOUGH=0.5, CLIMATE_STRESS_MAX=2.0, GENERALIST_METABOLISM=0.2, GRAZED_EPS=1e-9`.
   - `struct FeedParams { max_meal, assimilation, base_metabolism, climate_cost }` + `from_config(&Config)`.
   - `thermal_stress(t:&Traits, temperature) -> f64`; `metabolic_cost(t:&Traits, temperature, &FeedParams) -> f64`.
   - `satiety(t:&Traits) -> f64`; `need(energy, t, &FeedParams) -> f64`.
   - `bite_size(herb:&Organism, plant:&Organism, &FeedParams) -> f64` (ADR-017 formula).
   - `best_in_reach(pop, herb_id, &FeedParams) -> Option<(EntityId, f64 /*bite*/, u32 /*dist*/)>` using `pop.within(center, 1, Some(Kind::Plant))`, max bite, ties (distance, id).
   - `best_visible(pop, herb_id, r, threshold, &FeedParams) -> Option<Neighbour>` maximising `bite/(1+d)` over plants at distance ≥ 2 within `r`, bite ≥ threshold, ties (distance, id).
   - `eat(pop, herb_id, plant_id, &FeedParams, tick) -> Bite { taken, gained, plant_died, distance }`: asserts/guards distance ≤ 1 (returns zero bite otherwise — the reach guarantee lives here), `plant.spend_energy(bite)`, `herb.add_energy(assim*bite)`, kill plant `Grazed` if energy ≤ GRAZED_EPS.
   - `flee_decision(c, danger, hunger) -> bool` = `c*danger > (1-c)*hunger`.
   - `struct FeedTick { eaters, bites, taken, gained, metabolism, starved, grazed_dead, fled, rested, max_bite_distance: u32 }` + `HerbivoreLedger` (cumulative totals + `last: FeedTick`, `record(&FeedTick)`).
3. **`animals/herbivore.rs`** (new): `act_herbivores(pop, ids, cfg, now:&[CellNow], torus_width, tick, rng) -> (MoveTick, FeedTick)` implementing the per-turn sequence of ADR-017 (stride → metabolism from `now[cell]` → flee / rest / forage with one move call → at most one bite → starvation kill if energy ≤ 0). Use `pop.nearest(center, r, Some(Kind::Carnivore), ..)` for danger.
4. **`animals/mod.rs`**: keep `act_animals` unchanged (TASK-013 tests at animals/tests.rs:348-374 call it with Kind::Herbivore; it stays the carnivore policy and a movement-only helper); `World::act_animals` dispatches: Herbivore → `act_herbivores`, Carnivore → old policy). Export new items.
5. **`sim/world.rs` / `sim/mod.rs`**: `World::act_animals(kind, cfg, tick, rng)` passes `&self.now`, width, tick; store `herbivore_ledger: HerbivoreLedger` in World with getter `herbivore_ledger()`; update call sites (sim/mod.rs:257,261) and any tests calling `World::act_animals`/`animals::act_animals` (grep).
6. **Tests** `animals/tests_feed.rs` (registered in mod.rs `#[cfg(test)]`), reuse Bench pattern from animals/tests.rs (Population::with_expression + request_birth + resolve_births); build `now` grids as `vec![CellNow{temperature, precipitation}; w*h]`:
   - AC1 `eats_only_in_reach`: herbivore with speed gene 0 (cannot move), plant at distance 2 → plant energy unchanged after a turn; plant at distance 1 across the x wrap edge (herb (0,0), plant (W−1,0)) → eaten. `approaches_plant_in_vision_not_beyond`: plant at d ≤ r → distance decreases; plant at d = r+1 → not targeted (no approach; herbivore wanders or not towards). `bite_distance_never_exceeds_one`: 300-tick default-config Simulation run, assert `FeedTick.max_bite_distance ≤ 1` every tick and `bites > 0` overall.
   - AC2 `bite_limited_by_max_meal` (plant 20 energy, hungry herb → taken == max_meal·(1−0.5·s_P)), `plant_loses_taken_herbivore_gains_at_most` (Δplant = −taken, Δherb(excluding metabolism) = assim·taken ≤ taken; also with assimilation 1.0), `grazing_kills_plant` (aggression 1, plant energy < cap → plant killed with cause Grazed in last_deaths after end_of_tick), ledger conservation in a run: cumulative `gained ≤ taken`, `taken` equals sum of per-tick plant energy removed.
   - AC3 `metabolism_every_tick` (no plants: energy drops by ≥ base_metabolism each tick), `starves_and_dies` (low energy, no food → killed with Starvation, removed, `count_alive` 0).
   - AC4 `extreme_climate_costs_more`: `metabolic_cost` at T = opt is base·generalist factor; at T = opt ± 3·tol is ×(1+2·climate_cost); phase-level: identical herbivores in cold-grid vs mild-grid lose different energy; `climate_cost = 0` removes the difference.
   - AC5 `genes_change_decisions`: same situation (herb at energy 50/100, plant in own cell, carnivore at distance 2): caution 1.0 → flees (moves away, plant untouched, `fled == 1`); caution 0.0 → eats (plant energy drops). Second: aggression 1.0 vs 0.0 on the same plant (energy 6, max 20) → greedy strips/kills plant, restrained leaves reserve 5·… (different taken). Assert outcomes differ.
   - `sated_herbivore_rests` (E ≥ satiety → no bite, no move), `moves_from_depleted_cell_to_better_patch`.
   - Determinism: two runs same seed → same `state_hash`; existing `no_animals_no_extra_rng_draws` must still pass.
7. **Docs**: docs/ANIMALS.md section "Herbivore feeding (TASK-014)" (reach, bite, metabolism/climate, decision rule, constants); docs/STATE.md TASK-014 notes; ARCHITECTURE status (planned → implemented); CONFIG.md regenerated.
8. **Run** `./test.sh` (exit 0) and a smoke `./evosim run` of the contract example config (64×48, 400/120/20) for e.g. 2000 ticks recording herbivore counts/time (well under 300 s budget); record counts honestly (coexistence tuning is TASK-018, not a criterion here).

## Risks
- Population dynamics may collapse (herbivores starve or strip plants) with defaults; not an acceptance criterion, but record the smoke result; tune only via the new constants/keys if catastrophically fast.
- Existing TASK-013 tests that depend on herbivore energy/positions (e.g. movement cost equals path_cost in a phase run) will see metabolism now; adjust them to account for metabolism or use `base_metabolism = 0` in those configs — do not weaken their assertions.
- Hash/golden values in tests that pin RNG streams with herbivores may change; update only with justification.
- Time budget: tests must stay fast (use small worlds).

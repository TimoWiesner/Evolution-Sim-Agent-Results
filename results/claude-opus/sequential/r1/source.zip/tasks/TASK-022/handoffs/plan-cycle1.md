# TASK-022 PLAN cycle 1 — Savegames and checkpoints

Design: [ADR-025](../../../docs/decisions/ADR-025-checkpoints.md). Read it first; this file is the ordered work list.

## Facts found in PLAN (verified)
- Core has only `serde_json`; no serde derives exist. `serde`, `serde_derive`, `syn`, `quote`, `proc-macro2` are already
  in `Cargo.lock` and in `/opt/rust/cargo/registry/cache`. An offline probe crate with
  `serde = {version="1", features=["derive"]}` + `serde_json/float_roundtrip` built and round-tripped f64/f32/Option/arrays
  exactly (`cargo run --offline`, probe deleted afterwards).
- Complete state = what `Simulation::state_hash()` streams (`sim/mod.rs`, `sim/world.rs::hash_state`,
  `organism/population.rs::hash_state`, `species/mod.rs::hash_state`). Excluded caches: World.climate, World.bounds,
  Population.expression, Population.index, Population.capacity.
- `SpatialIndex` is canonical (buckets sorted by ID, BTreeMap locator) → `Population::rebuild_index` reproduces it.
- `Simulation::set_population` already rebuilds index + capacity + validates; `set_weather_state` recomputes `now` —
  for the checkpoint restore `now`/`climate_tick` verbatim instead (simplest exact restore).
- Existing `Simulation::resume(config, tick, rng, next_id)` is used by tests in organism/sim/climate/digest — keep it.
- CLI currently rejects `--save/--load` (`crates/evosim-cli/src/run.rs` parse_run_args; unit test `rejects_bad_arguments`
  lists them; integration test `crates/evosim-cli/tests/cli.rs:337-338` expects exit 2; `lib.rs:44` usage text). All
  three must be updated.

## Ordered steps
1. **Dependency.** `crates/evosim-core/Cargo.toml`: add `serde = { version = "1", features = ["derive"] }`. Run
   `cargo build --offline` once to update `Cargo.lock`, then confirm `cargo build --release --locked` works. Check
   `./setup.sh` and `./build.sh` still succeed (no network needed since crates are cached; in a fresh container setup.sh
   downloads them — allowed by the contract).
2. **Derives.** Add `serde::Serialize, serde::Deserialize` to every leaf type reachable from the hashed fields (list in
   ADR-025 §1; compiler drives completeness). Do NOT add derives to the caches. Do not add manual `Debug` impls.
   Arrays `[T; 3]`/`[T; 2]` derive fine. Enums: default externally tagged representation.
3. **Module `crates/evosim-core/src/snapshot/mod.rs`** (+ `pub mod snapshot;` in lib.rs, doc line):
   - `pub const CHECKPOINT_FORMAT: &str = "evosim-checkpoint"; pub const CHECKPOINT_VERSION: u64 = 1;`
   - `pub enum SnapshotError { Io(String), Parse(String), Version(String), Invalid(String), Integrity { stored, actual } }`
     with `Display` + `std::error::Error`.
   - DTOs `StateDto { tick, rng: RngState, ids: IdAllocator, world: WorldDto }`, `WorldDto { torus, weather, now,
     climate_tick, resources, plant_ledger, last_moves, herbivore_ledger, hunt_ledger, repro_ledger, stats, population:
     PopulationDto }`, `PopulationDto { by_kind, pending, totals, tick_deaths, last_deaths, last_births,
     births_dropped_full, species: SpeciesRegistry }` (SpeciesRegistry itself can derive; it has no caches). Owned or
     borrowed (`Serialize` via references is fine; two DTO flavours not required — owned clone is acceptable, cost is one
     state copy at save).
   - Build DTOs by exhaustive destructuring (`let World { torus, climate: _climate, ... } = self;`) in `pub(crate)` helper
     methods placed next to `hash_state` in sim/mod.rs, sim/world.rs, organism/population.rs (fields are private there).
     Restore helpers likewise: `World::restore_from(config, dto) -> Result<World, SimError>` = `World::from_config` then
     assign every field, `Population` assembled with `with_expression(Expression::from_config(cfg), torus)`, capacity
     `CellCapacity::from_config`, `rebuild_index(torus)`, `validate(next_id)`, species `validate`-style checks (reuse the
     existing species consistency function used by `Population::validate`).
   - Extra validation on load: `torus` equals `Torus::new(config.world.width,height)`; `now.len()` and resources length
     == cell count; weather lattice lengths match `Weather::new(...)` (reuse `restore_weather` checks or compare
     dimensions); `tick >= climate_tick`; RNG not all-zero (`Rng::from_state`). Any failure → `Invalid`.
   - `pub fn to_json_string(sim: &Simulation) -> Result<String, SnapshotError>`: top-level object
     `{format, version, engine: crate::VERSION, tick, state_hash, config: cfg.to_json_value(), state}` serialised compact
     (`serde_json::to_string`) + trailing newline. Serialisation error → `Invalid`.
   - `pub fn from_json_str(text: &str) -> Result<Simulation, SnapshotError>`: parse to `Value` (`Parse`); check `format`
     and `version` (`Version`); `Config::from_value(&v["config"])` (`Invalid`); `serde_json::from_value::<StateDto>`
     (`Invalid`); top-level `tick` == state tick (`Invalid`); restore; compare `state_hash` (`Integrity`).
   - `pub fn load_file(path) / save_text` not in core (core does no file I/O by convention? — config loading lives in
     CLI; keep file I/O in CLI). Convenience wrappers `Simulation::checkpoint_json()` / `Simulation::from_checkpoint_json()`.
4. **Core tests `crates/evosim-core/src/snapshot/tests.rs`** (small world e.g. 24×16, all three kinds, weather enabled,
   short maturity so animals mate; one config with forced plant mutation (mutation_rate 1, strength 0.3) to get species
   splits — see STATE TASK-017 note):
   - round trip at tick 0, after 1, after 150 ticks: hash equal, `format!("{:?}")` of sim equal except caches (compare hash +
     organisms + species Debug).
   - split equality: for A in {0, 1, 37, 200}, B = 120: uninterrupted A+B vs (A, save text, load, B): equal `state_hash`,
     `totals()`, per-kind counts, living species — at least two split points incl. 0 (acceptance #5).
   - continuation also after total extinction (initial plants 0, long run).
   - errors: empty, `"garbage"`, truncated at 10 cut points (len·k/11) → Parse; version 2, version "1", missing version,
     format "other" → Version; removed `state.world` key → Invalid; altered one organism energy digit in text (via Value
     edit) → Integrity; altered stored `state_hash` → Integrity; config with unknown key → Invalid.
   - property-style test: proptest is NOT a dependency (verified); use a seeded loop over 5 seeds × pseudo-random split
     points instead.
5. **CLI `crates/evosim-cli/src/run.rs`:**
   - `RunArgs { source: Source::{Config{path, seed}, Load(path)}, ticks, out, sample_every, metrics, save: Option<String> }`
     (or keep `config: Option<String>` + `load: Option<String>`; keep tests readable).
   - Parse rules: ADR-025 §4. Errors → exit 2 with usage line mentioning both forms.
   - Load: `std::fs::read` (Io: "cannot read checkpoint 'F': …"), `String::from_utf8` (Parse), `snapshot::from_json_str`.
     Message prefix `invalid checkpoint 'F': <SnapshotError>`.
   - Save path checked with `check_out_path("--save", …)` and `same_file` against out/metrics before the loop.
   - After loop: produce checkpoint text, self-check (`from_json_str(&text)` hash == `sim.state_hash()`), then write in
     order save → out → metrics with rollback (remove files already written in this invocation on later failure; for
     `--save` == `--load` path, rollback cannot restore the old checkpoint — acceptable, document).
   - stderr summary line mentions `loaded tick T` / `saved FILE`.
   - Update `lib.rs` usage text (line ~44) and help.
6. **CLI tests:** update unit test lists (remove `--save x`/`--load x` from must-fail; add: `--load` + `--config`, `--load` +
   `--seed`, neither, `--save ""`, duplicate `--save`, `--save` == `--out`). Integration (`crates/evosim-cli/tests/cli.rs`):
   replace lines 337-338 expectations; add `checkpoint_resume_matches_uninterrupted` for splits A=0 and A=40 (B=60) on
   a small config: compare `final`, `totals`, `state_hash`, plus `tick_start`/`tick_end`; chained save→load→save→load;
   `--ticks 0` load reproduces the saved hash; error matrix (missing file, empty, garbage, truncated half, version 99,
   wrong format, tampered organism value, tampered hash, directory as `--load`) → exit 2, stderr non-empty, no `--out`
   and no `--save` file.
7. **E2E `scripts/check-entrypoints.sh`:** contract example (or the existing run config there) 30 ticks + save, load + 20
   ticks vs 50 uninterrupted: equal final/totals/state_hash; truncated checkpoint → exit 2 + no out file. Also run the
   save/load check once with `dist/evosim` if that section already copies dist (it does for `run`).
8. **Docs:** new `docs/CHECKPOINTS.md` (format, version policy, compression choice, error classes, size + timing measured
   for the contract example at ~1000 ticks); docs/ARCHITECTURE.md (snapshot row: module exists, serde derive dep,
   Serialisation section); docs/STATE.md status line + TASK-022 notes; ADR-025 "IMPLEMENT notes" section for deviations;
   docs/decisions/README.md row (PLAN added it).
9. **Run** `./test.sh` (full) and `cargo clippy --workspace --all-targets --locked -- -D warnings` (if clippy is used in
   earlier tasks — check STATE "Test commands"); record exact commands/results in the implement handoff.

## Time budget hints
Contract example 1000 ticks ≈ 0.83 s release. Keep core split tests on small worlds (debug-mode tests are ~10–20× slower).

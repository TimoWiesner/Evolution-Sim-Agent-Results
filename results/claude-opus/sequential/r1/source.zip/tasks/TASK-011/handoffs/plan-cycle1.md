# TASK-011 PLAN cycle 1 — Plant growth and resources

Design: [ADR-014](../../../docs/decisions/ADR-014-plant-growth-resources.md) (formulas are normative there).

## Current code facts (verified in PLAN)
- `sim/mod.rs::run_phase`: `Phase::Resources` and `Phase::Plants` are empty slots; Births/Deaths filled (TASK-008).
- `World` (`sim/world.rs`) owns torus, climate, weather, current grid `now: Vec<CellNow>` (`World::current(cell)`), `organisms: Population`.
- `CellNow { temperature, precipitation }`, precipitation ∈ [0, `climate.max_precipitation`].
- `Organism::{add_energy, spend_energy, damage, heal}` return the amount actually changed; `Population::get_alive_mut(id)`, `alive_ids(kind)`, `kill(id, cause, tick)` (records into the tick's death list emitted by the Deaths phase). `DeathCause::Climate` already exists.
- `Population::end_of_tick` handles Injury/Starvation/OldAge; it checks health first — so climate deaths must be killed explicitly in the Plants phase to get cause `Climate`.
- Config `plants.*` already has `resource_cap` 10, `resource_regen` 0.5, `max_energy` 20, `initial_energy` 5, `max_age` 300. Adding a key = one line in `config/params.rs` + regenerate the docs/CONFIG.md table (`./evosim config schema`; test `config_doc_table_is_current`).
- Core-source scan test forbids wall-clock / global RNG / hashed collection tokens in core `.rs` (also in comments).

## Ordered implementation steps
1. **Config** (`crates/evosim-core/src/config/params.rs`): add to `PlantParams` the 7 keys of ADR-014 (`growth_rate`, `upkeep`, `water_min`, `water_optimum`, `generalist_cost`, `stress_damage`, `heal_rate`) with defaults/ranges/doc strings. Regenerate docs/CONFIG.md table. Check presets still validate (plants-only/harsh/lush may get tuned values only if needed).
2. **New module `plants`** (`crates/evosim-core/src/plants/{mod.rs, resources.rs, growth.rs, tests.rs}`; `pub mod plants;` in lib.rs):
   - `resources.rs`: `pub struct CellResources { cap: f64, values: Vec<f64> }` with `new(torus, cap)` (all = cap), `get(cell)`, `values()`, `total()`, `cap()`, `pub(crate) set(cell, v)` (clamped; tests), `regenerate(now: &[CellNow], params, max_precip) -> f64` (returns added amount). `pub fn moisture(p, max_precip) -> f64`.
   - `growth.rs`: pure functions `thermal_factor(traits, t)`, `water_factor(m, params)`, `generalist_peak(traits, params)`, `stress(traits, now, m, params) -> f64`, `potential_gain(traits, now, max_precip, params) -> f64` (= growth_rate·f_T·f_W·peak, before headroom/share), `upkeep_cost(traits, params)`. And `pub fn grow_plants(pop: &mut Population, res: &mut CellResources, now: &[CellNow], torus: &Torus, plants: &PlantParams, max_precip: f64, tick: u64) -> GrowthTick` implementing ADR-014: collect `alive_ids(Plant)` (sorted by id), compute demand per plant, accumulate per-cell demand in a `Vec<f64>` of cell count, grant fair shares, subtract from R, add energy (use return value of `add_energy` for the ledger), upkeep, stress damage/heal, `kill(id, DeathCause::Climate, tick)` when health hits 0. No RNG.
   - `pub struct PlantLedger { regen_added, uptake, upkeep, last_regen, last_uptake, last_upkeep }` (f64), `GrowthTick { uptake, upkeep, climate_deaths }`.
3. **World** (`sim/world.rs`): fields `resources: CellResources`, `plant_ledger: PlantLedger`; init in `from_config` from `config.plants.resource_cap`; accessors `resources()`, `plant_ledger()`, `pub(crate) resources_mut()`; methods `regenerate_resources(&PlantParams, max_precip)` and `grow_plants(tick, &PlantParams, max_precip)` that split-borrow `organisms`, `resources`, `now`, `torus`.
4. **Scheduler** (`sim/mod.rs::run_phase`): `Phase::Resources => ctx.world.regenerate_resources(&ctx.config.plants, ctx.config.climate.max_precipitation)`, `Phase::Plants => ctx.world.grow_plants(ctx.tick, ..)` (TASK-012 will add reproduction in the same phase). No events needed (climate deaths appear as `EventKind::Death` with cause Climate in the Deaths phase). Optional: `Simulation::resources()` convenience.
5. **Tests** (`plants/tests.rs`, plus sim-level ones), each named for its AC:
   - AC1/AC2 `growth_depends_on_temperature_and_water`: pure `potential_gain` with the same traits: favourable CellNow (T = opt, m = 1) > cold (T = opt − tol·0.9) > 0 and too cold (T ≤ opt − tol) == 0; dry (m < w_min) == 0, half-dry < wet.
   - AC2 `same_plant_grows_less_in_cold_or_dry_cell_sim`: real `Simulation` with `weather_enabled=false`, `seasonal_amplitude=0`, `noise_*=0`, `initial` 0 plants; pick a favourable cell, a polar cell and (via config with low `max_precipitation` variant or a cell with m < w_min found from `current_grid`) a dry cell; insert identical-genome plants (Population built with `with_expression` + `request_birth`/`resolve_births`, then `set_population`, or a crate-internal helper); run N ticks; assert energy(favourable) > energy(cold), energy(dry) and cold/dry ≤ start.
   - AC3 `resources_limited_and_shared`: 1 vs 4 identical plants in one cell with small regen: per-plant gain with 4 < with 1 after depletion; total gain per tick ≤ R_before; R ∈ [0, cap] always (property over a random run); `fair_share_is_order_independent` (permuting ids/insertion gives identical result).
   - AC3/AC5 `energy_ledger_balances`: over a 200-tick run with default config, `Σ R(t) − Σ R(0) == regen_added − uptake` (rel. tol 1e-9) and per tick plant energy increase in Plants phase == resource decrease (via `step_with` hook snapshots after Resources and after Plants); `no_regen_no_growth`: `resource_regen = 0`, `resource_cap = 0` → no plant ever gains energy, all die of Starvation.
   - AC4 `plants_die_of_old_age` (favourable cell, small max_age → OldAge), `plants_starve_without_resources` (Starvation), `plants_die_in_hostile_climate` (polar cell, cause Climate, before max age), `health_recovers_when_unstressed`.
   - AC6 `genome_traits_change_growth`: two genomes differing only in `temp_optimum` gene grow differently in the same cell; `temp_tolerance` gene: wider tolerance survives a cold cell where narrow dies, but has lower peak gain in an optimal cell; `strength` raises upkeep.
   - Determinism: `plant_growth_uses_no_core_rng` (RNG state after a step equals a run with plants count 0? — better: compare rng_state with and without plants; must be equal) and identical sims give identical energies.
   - Existing tests: run full suite; fix any assumption that plant energy stays constant (e.g. organism/sim tests with default plants).
6. **Docs**: new `docs/PLANTS.md` (user-facing: where plant energy comes from — only the cell resource R refilled from moisture; what limits it — cap, regen·moisture, temperature/water suitability, fair share, headroom, upkeep; death causes; traits; ledger invariant; parameter list). Update docs/ARCHITECTURE.md (`plants` module row: implemented parts, World owns `CellResources`), docs/decisions/README.md (ADR-014 row — done in PLAN), docs/STATE.md (TASK-011 notes + test results), docs/CONFIG.md (regenerated).
7. Run `./test.sh`, debug `cargo test -p evosim-core --locked`, `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`.

## Acceptance mapping
| AC | Shown by |
|---|---|
| Gain from cell resources, depends on current T and water | `grow_plants` uses `World::current` + R; tests growth_depends_on_temperature_and_water, energy_ledger_balances |
| Same plant grows slower/not at all in cold/dry cell | same_plant_grows_less_in_cold_or_dry_cell_sim (+ pure test) |
| Limited resources, competition | resources_limited_and_shared, fair_share_is_order_independent, R bounds |
| Ageing and death (old age, energy, climate) | plants_die_of_old_age, plants_starve_without_resources, plants_die_in_hostile_climate |
| Documentation of energy source/limits | docs/PLANTS.md + ADR-014; ledger tests |
| Genome traits influence growth/tolerance | genome_traits_change_growth |

## Risks
- Default founders (opt 10 °C, tol 16 °C) die in polar and hottest cells; without reproduction (TASK-012) all plants die by tick ~300 anyway. Acceptable; balance in TASK-027.
- Floating-point: share computation could leave R slightly negative → clamp with `max(0.0)` and record the actual removed amount in the ledger.
- Founders may exceed `max_per_cell` (placement is TASK-012); fair share handles any count.
- Time budget: implementation is moderate (~400 lines + tests); keep long sim tests ≤ a few hundred ticks on small worlds.

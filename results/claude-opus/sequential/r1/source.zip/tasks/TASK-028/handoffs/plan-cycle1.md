# TASK-028 PLAN cycle 1 — Reliability and delivery

Design decisions: [ADR-031](../../../docs/decisions/ADR-031-verification-delivery.md).

## Current state (inspected on 539e57b)
- Entry points `setup.sh`, `evosim`, `build.sh`, `test.sh` exist; `scripts/check-entrypoints.sh` already covers
  version, help, exit 2 (unknown command, bad flags, invalid config, truncated checkpoint, bad batch param), run
  end-to-end, metrics, checkpoint A+B equivalence, batch reproducibility, `ldd` whitelist + empty-env copy run, UI
  smoke/screenshots. `crates/evosim-cli/tests/cli.rs` covers more error cases (wrong type, missing key, zero ticks,
  extinct world, invalid checkpoints, ui usage errors).
- `target/release/evosim` links only libgcc_s, libm, libc, ld-linux. `dist/` is git-ignored.
- **Missing:** `scenarios/demo.json` (directory does not exist), README demo command and coexistence result,
  docs/VERIFICATION.md, self-audit, randomised multi-seed/multi-config invariant test (no `proptest` in the
  workspace; existing invariant tests use fixed configs), recorded ≥10,000-tick runs for this task.
- TASK-027 result: contract example held-out median coexistence 2,208.5 ticks (3/10 full); ~350 ticks/s on the
  contract example (12 cores here). Open nits GAP-027-R1/R2 (BALANCE.md §3 wording; ECOLOGY.md default list shows
  old values) — fix in this task (docs only).
- No system packages are needed (none installed with apt).

## Ordered implementation steps
1. **Baseline check** (≈2 min): `./setup.sh` (twice: idempotent), `./test.sh`, `./build.sh`; record exit codes.
2. **Randomised invariant test** `crates/evosim-core/tests/randomized_invariants.rs` (ADR-031 D2). Public API to use:
   `Config::{new, from_value, to_json_value}`, `batch::set_dotted`, `Simulation::{new, step, tick, organisms,
   totals, world, state_hash, checkpoint_json, from_checkpoint_json, next_entity_id}`, `Population::{alive,
   count_alive, validate}`, `Traits::in_range`, `World::{climate_bounds, ...}`, `topology::Torus`, `rng`.
   Tests (each a `#[test]`, fixed generator seeds, failing case prints config JSON + seed + tick):
   - `accounting_ranges_no_replenishment` — ≥40 random configs × 150–400 ticks, checks every tick.
   - `wrapping_properties` — ≥200 random tori × random cells/offsets; `within` vs brute-force oracle near seams;
     climate seam continuity on random sizes.
   - `determinism_and_seed_sensitivity` — ≥12 configs run twice (hash/totals/series equal), other seed differs.
   - `checkpoint_split_equivalence` — ≥8 configs, random A, B: hash+totals equal to A+B uninterrupted.
   Keep total < 60 s release. If an invariant fails, fix the engine bug (minimal fix, documented) — not a feature.
3. **Contract verification additions** in `scripts/check-entrypoints.sh` (only what is not yet checked; map first):
   version from another cwd + stdout exactly one JSON object; `--seed` override changes hash; `--ticks 0`;
   `initial.plants=0` → herbivores then carnivores die out and stay 0 (§5.3; choose ticks so it happens, check
   series); config wrong type / missing fixed key / out of range → exit 2 + stderr + no out file; default
   `--sample-every`; series ascending, no duplicates, starts at tick_start, ends at tick_end; totals identity;
   `run/batch/ui --smoke-test --config scenarios/demo.json` accepted; `dist/evosim run` on demo.
4. **Chroot self-containment** `scripts/check-dist-chroot.sh` (ADR-031 D3), called from `check-entrypoints.sh`
   after build; SKIP (not PASS) if chroot fails for permission reasons.
5. **Demo scenario trials** (parameter-only, ADR-031 D4): create candidates in `tasks/TASK-028/data/demo-trials/`,
   run `./evosim batch --config C --seeds 1,2,3,4,5 --ticks 10000 --sample-every 100 --out-dir D --jobs 4`; measure
   with `python3 scripts/coexistence.py D/summary.json` (copy of tasks/TASK-027/data/coexistence-summary.py, plus
   max per-run elapsed_seconds). First check speed of the largest candidate with a 1,000-tick run. Pick winner →
   `scenarios/demo.json` (pretty JSON, validated by `./evosim config validate`). Confirm on seeds 11–15. Time box:
   ≤20 min of compute; stop with the best measured candidate.
6. **Long runs** `scripts/long-runs.sh [OUTDIR]`: batch 10,000 ticks, seeds 1–5, `--jobs 4`, for (a) contract
   example `tasks/TASK-027/data/contract-example.json` (only fixed keys) and (b) `scenarios/demo.json`; prints
   per seed: exit status, final counts, extinction ticks, coexistence, elapsed_seconds, ticks/s; checks all runs
   exit 0 and totals identity. Store summaries in `tasks/TASK-028/data/long-runs/` (summary.json + seed files ok, no
   metrics). Also one `dist/evosim run` 10,000 ticks to show the distributable runs long.
7. **Docs**: `docs/VERIFICATION.md` (contract table §1–§7 with command/observed, long runs, coexistence tables for
   both configs, demo trials, test suite command+result, chroot result); `docs/SELF-AUDIT.md` (each PROJECT.md bullet
   and the extinction rules, status + evidence; known limitations: coexistence not robust on held-out seeds, perf
   only on this container's hardware, JSON only config format, headless chromium paints ~813 px, UI cell limit,
   species criterion founder-distance, etc.); README: install, run, batch, ui, configuration parameters (fixed keys
   + table of groups/main keys + link docs/CONFIG.md), **demo command** `./evosim ui --config scenarios/demo.json`
   (plus headless variant), coexistence result, test command, status line refresh. Fix GAP-027-R1/R2.
   Update docs/STATE.md, docs/ARCHITECTURE.md, ADR-031 → Accepted.
8. **Final** `./test.sh` (record exit code and counts) and `./build.sh`; handoff.

## Tests / evidence expected from IMPLEMENT
- `./test.sh` exit 0 incl. new randomised test and chroot check.
- `scripts/long-runs.sh` output: 10 runs × 10,000 ticks, all exit 0.
- Coexistence tables in VERIFICATION.md and README for contract example and demo (≥3 seeds each; plan: 5).

## Risks
- Larger demo worlds are slower: keep each 10,000-tick run well under 900 s with 4 parallel (measure first).
- Randomised tests may expose real engine bugs (e.g. 1×1 worlds, dense populations); fixes must not change
  default-run behaviour silently — re-run `scripts/perf-equivalence.sh`; if goldens change, record why.
- chroot may be restricted in some containers → SKIP with reason, keep ldd/env -i evidence.
- Test-suite runtime grows; keep new tests < 60 s.

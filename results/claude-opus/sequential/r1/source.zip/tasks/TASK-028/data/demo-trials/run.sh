#!/usr/bin/env bash
cd "$(dirname "$0")"
for c in "$@"; do
  s=$(date +%s)
  /workspace/evosim batch --config $c.json --seeds 1,2,3,4,5 --ticks 10000 --sample-every 100 --out-dir out-$c --jobs 5 2>$c.log
  echo "$c exit $? wall $(( $(date +%s)-s )) s" >> trials.log
done

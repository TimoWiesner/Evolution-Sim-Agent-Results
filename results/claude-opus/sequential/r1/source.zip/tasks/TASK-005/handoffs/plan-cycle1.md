# TASK-005 PLAN cycle 1 — Clock, random numbers and tick scheduler

Design record: `docs/decisions/ADR-008-tick-scheduler.md` (binding; refines ADR-005). std only, no new crates, Cargo.lock unchanged.

## Ordered implementation steps
1. **`crates/evosim-core/src/rng/mod.rs`** (+ `rng/tests.rs`)
   ```rust
   pub struct SplitMix64 { state: u64 }            // new(seed), next_u64()
   #[derive(Debug, Clone, Copy, PartialEq, Eq)] pub struct RngState { pub s: [u64; 4] }
   impl RngState { pub fn to_hex(&self) -> String; pub fn from_hex(s: &str) -> Result<Self, RngError>; }
   #[derive(Debug, Clone, PartialEq, Eq)] pub enum RngError { AllZeroState, BadHex(String) } // Display + Error
   #[derive(Debug, Clone, PartialEq, Eq)] pub struct Rng { s: [u64; 4] }   // no Default
   impl Rng {
     pub fn seed_from_u64(seed: u64) -> Self;      // 4 SplitMix64 outputs; all-zero guard (ADR-008)
     pub fn from_state(st: RngState) -> Result<Self, RngError>;
     pub fn state(&self) -> RngState;
     pub fn next_u64(&mut self) -> u64;            // xoshiro256**: r = rotl(s1*5,7)*9; t=s1<<17; s2^=s0; s3^=s1; s1^=s2; s0^=s3; s2^=t; s3=rotl(s3,45)
     pub fn next_u32(&mut self) -> u32;            // >> 32
     pub fn next_f64(&mut self) -> f64;            // (x>>11) as f64 * 2^-53
     pub fn next_f32(&mut self) -> f32;            // (x>>40) as f32 * 2^-24
     pub fn below(&mut self, n: u64) -> u64;       // Lemire: m = x as u128 * n; reject if (m as u64) < (n.wrapping_neg() % n)
     pub fn range_u32(&mut self, lo: u32, hi: u32) -> u32;   // inclusive, panics lo>hi
     pub fn range_i64(&mut self, lo: i64, hi: i64) -> i64;   // inclusive, full-span safe (via u64/u128)
     pub fn range_f64(&mut self, lo: f64, hi: f64) -> f64;   // lo + (hi-lo)*next_f64
     pub fn chance(&mut self, p: f64) -> bool;               // always one draw
     pub fn normal(&mut self, mean: f64, sd: f64) -> f64;    // Box–Muller, u1 = 1-next_f64 ∈ (0,1], no cached spare
     pub fn shuffle<T>(&mut self, xs: &mut [T]);             // Fisher–Yates from the end
     pub fn choose_index(&mut self, len: usize) -> Option<usize>;
   }
   ```
2. **`crates/evosim-core/src/ids.rs`** (leaf, so TASK-008 `organism` need not depend on `sim`):
   `#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] pub struct EntityId(pub u64);`
   `#[derive(Debug, Clone, PartialEq, Eq)] pub struct IdAllocator { next: u64 }` — `new()` (starts at 1; 0 reserved as "none"), `from_next(u64)`, `alloc() -> EntityId` (checked add), `peek_next() -> u64`.
3. **`crates/evosim-core/src/sim/`**
   - `schedule.rs`: `#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] pub enum Phase { Climate, Resources, Plants, Herbivores, Carnivores, Births, Deaths, Species, Statistics }`; `pub const ORDER: [Phase; 9]` (as `Phase::ORDER`); `Phase::name() -> &'static str`; `Phase::is_acting()` (Plants/Herbivores/Carnivores).
     `pub fn acting_order(ids: &[EntityId], rng: &mut Rng) -> Vec<EntityId>` — copies, `sort_unstable()` (ascending; IDs unique), debug_assert no duplicates, `rng.shuffle`. Also `acting_order_into(&mut Vec<EntityId>, ...)` buffer variant optional.
     `pub fn cmp_with_id_tiebreak<K: Ord>(a: (K, EntityId), b: (K, EntityId))`-style helper or doc only: ties by ascending EntityId, cells by `Cell` Ord (y,x).
   - `event.rs`: `pub struct Event { pub tick: u64, pub phase: Phase, pub kind: EventKind }` (Debug, Clone, PartialEq); `#[non_exhaustive] pub enum EventKind { Probe { value: u64 } }`; `pub struct TickReport { pub tick: u64, pub phases: Vec<Phase>, pub events: Vec<Event> }`.
   - `world.rs`: `pub struct World { torus: Torus }`, `World::from_config(&Config) -> Result<World, SimError>`, `torus()`.
   - `mod.rs`:
     ```rust
     pub enum SimError { World(TopologyError), Rng(RngError) }    // Display + Error
     pub struct Simulation { config: Config, tick: u64, rng: Rng, world: World, ids: IdAllocator }
     impl Simulation {
       pub fn new(config: Config) -> Result<Self, SimError>;          // rng = seed_from_u64(config.seed), tick 0
       pub fn resume(config: Config, tick: u64, rng: RngState, next_id: u64) -> Result<Self, SimError>;
       pub fn step(&mut self) -> TickReport;                          // = step_with(|_| {})
       pub fn step_with<F: FnMut(&mut PhaseCtx<'_>)>(&mut self, hook: F) -> TickReport;
       pub fn run(&mut self, n: u64);                                 // n × step(), discards reports
       pub fn tick(&self) -> u64; pub fn config(&self) -> &Config; pub fn world(&self) -> &World;
       pub fn rng_state(&self) -> RngState; pub fn set_rng_state(&mut self, s: RngState) -> Result<(), SimError>;
       pub fn next_entity_id(&self) -> u64;
     }
     pub struct PhaseCtx<'a> { pub tick: u64, pub phase: Phase, pub rng: &'a mut Rng, pub world: &'a mut World, pub ids: &'a mut IdAllocator, events: &'a mut Vec<Event> }
     impl PhaseCtx<'_> { pub fn emit(&mut self, kind: EventKind); }
     ```
     `step_with`: `let t = self.tick;` for each `phase in Phase::ORDER`: build ctx, `self.run_phase(&mut ctx)` (built-in `match phase { ... => {} }` — empty slots with comments naming the owning task), then `hook(&mut ctx)`, push phase into report; finally `self.tick = t.checked_add(1).expect(...)`. Hook runs *after* the built-in phase body, order cannot be changed by it.
   - `tests.rs`.
4. **`lib.rs`**: `pub mod ids; pub mod rng; pub mod sim;` + crate doc update.
5. **Docs**: ARCHITECTURE (rng/ids/sim rows → implemented, ADR-008 link), STATE (API + test commands + results), ADR README (done in plan).

## Tests — map to acceptance criteria
- **AC1 state + one-tick step**: `step_advances_exactly_one_tick` (tick 0→1→…; `TickReport.tick` = pre-step tick; `run(250)` → 250); `new_holds_config_world_rng` (world torus = config dims, rng_state == `Rng::seed_from_u64(seed).state()`); `step_with` hook sees `ctx.tick == t` for all 9 phases.
- **AC2 seeded randomness only**: `rng_seeded_from_config_seed` (two sims, same config → same rng state; `with_seed` differs); `core_source_has_no_wall_clock_or_global_rng` — walks `env!("CARGO_MANIFEST_DIR")/src` recursively, reads every `.rs`, fails on tokens `SystemTime`, `Instant::`, `std::time`, `thread_rng`, `getrandom`, `rand::`, `HashMap`, `HashSet`, `RandomState` (tokens built with `concat!` so the test file itself does not match; or skip lines in that test file). Also Cargo.toml of core has no `rand`/`getrandom`.
- **AC3 order documented + stable**: `phase_order_is_fixed` (`report.phases == Phase::ORDER.to_vec()` and ORDER equals the literal list from ADR-008); `hook_sees_phases_in_order`; `acting_order_is_permutation_and_deterministic` (same rng state + same ID set in different input orders → identical output; output is a permutation; different rng → different order for 50 IDs); `acting_order_empty_and_single_draw_nothing` (rng state unchanged for len 0/1); shuffle fairness smoke: over 20 000 shuffles of 4 IDs each position frequency within ±5 % of 1/4.
- **AC4 export/restore**: `rng_state_roundtrip_exact` (state → from_state → identical next 1 000 draws); `rng_state_hex_roundtrip` (to_hex length 64, lowercase, from_hex equal; bad length/char → BadHex; all-zero → AllZeroState); `simulation_resume_continues_identically` (run 37 ticks, export (tick, rng_state, next_id), resume into new sim, run both 80 more with probe hook → identical traces & states); `set_rng_state` mid-run.
- **AC5 trace test**: `trace_same_seed_identical_over_150_ticks` — probe hook: in every phase draw `ctx.rng.next_u64()` (and in acting phases `acting_order` of a fixed synthetic ID list `1..=20` emitted as Probe events of the first ID) → trace = Vec<(tick, phases, events, rng_state)> over 150 ticks; two sims seed 42 equal; `trace_different_seed_differs` (seed 43: traces differ, and differ at tick 0 already); also plain `step()` (no hook) for 150 ticks: same seed equal rng/tick, different seed differ.
- **AC6 no UI dependency**: `core_manifest_has_no_ui_or_cli_dependency` (reads `CARGO_MANIFEST_DIR/Cargo.toml`, asserts no `evosim-ui`/`evosim-cli`/`tiny_http`); recorded command `cargo tree -p evosim-core --locked` showing only serde_json tree.
- **RNG golden vectors** (`rng/tests.rs`): xoshiro256\*\* from state `[1,2,3,4]` → `11520, 0, 1509978240, 1215971899390074240` (rand_xoshiro reference test); SplitMix64 seed `1234567` → `6457827717110365317, 3203168211198807973, 9817491932198370423, 4593380528125082431, 16408922859458223821`. Implementer must cross-check these with an independent C or Python transcription of Vigna's reference code (scratch file outside src, e.g. /tmp) and record the command; if a value disagrees, trust the reference code and note it. Plus pinned vector for `Rng::seed_from_u64(42)` first 4 outputs (generated once, pinned as regression).
- Distribution sanity: `below(n)` always < n for n ∈ {1,2,3,7,2^63+1,u64::MAX}; `below(1)` = 0; chi-square-ish bucket test for `below(10)` (100 000 draws, each bucket 9 000–11 000); `next_f64` ∈ [0,1), mean ≈ 0.5 ±0.01; `normal(0,1)` mean ±0.02, var 1 ±0.05 over 100 000; `range_i64(i64::MIN, i64::MAX)` no panic; `range_u32(5,5)` = 5; `chance(0.0)` false/`chance(1.0)` true, each consumes exactly one draw.
- `IdAllocator`: starts at 1, strictly increasing, `from_next` continues.

## Commands
- `source scripts/find-cargo.sh; evosim_find_cargo; cargo test -p evosim-core --release --locked rng` / `... sim` / `... ids`
- `cargo test -p evosim-core --locked` (debug, overflow checks)
- `cargo clippy -p evosim-core --release --locked`
- `cargo tree -p evosim-core --locked`
- Full: `./test.sh` must stay exit 0 (baseline 51 Rust tests + 22 entry-point checks).

## Risks
- Golden vectors recalled from literature: must be independently cross-checked (see above).
- Lemire rejection threshold formula: `n.wrapping_neg() % n`; test edge n = u64::MAX and powers of two.
- `normal` uses libm (`ln`, `cos`, `sqrt`) → only same-machine bit determinism; allowed by contract.
- Source scan may false-positive on doc comments mentioning forbidden names (e.g. ADR text in rustdoc); phrase docs without the exact tokens or whitelist the scanning test file only.
- `Event`/`EventKind` are `#[non_exhaustive]`-style placeholders; TASK-008 adds Born/Died and may rename `Probe` usage—keep `Probe` for tests.
- `resume` only restores clock/RNG/IDs; TASK-022 must extend it with the full world/organism state.

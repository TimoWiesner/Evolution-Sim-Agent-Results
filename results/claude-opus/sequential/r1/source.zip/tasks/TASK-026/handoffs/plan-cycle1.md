# TASK-026 plan, cycle 1: performance measurement and optimisation

Design: [ADR-029](../../../docs/decisions/ADR-029-performance.md). Read it first.

## Baseline facts (plan phase, before any code change, commit 7bdb6a9)
Host: AMD Ryzen 5 7500F 6-core / 12 threads, 30 GB RAM, Ubuntu 24.04 container, rustc 1.100.0, release profile (opt 3, thin LTO, cgu 1).

- `evosim run` contract example seed 42, 2000 ticks: 313 ticks/s, which includes the cheap early ticks (most organisms are plants).
- Probe (throwaway crate `target/plan-probe`, not committed): warm-up 1000, then 1000 measured ticks with the `step_with` phase hook: **184.0 ticks/s**. Organisms at the end: 752 plants, 1031 herbivores, 1 carnivore.
  Phases: Herbivores 94.6%, Plants 2.5%, Climate 2.2%, Deaths 0.3%, Carnivores 0.2%, Resources 0.2%, others ≈0.
- Total organisms in the window t1000–t2000 (series every 250): 4406, 4225, 3358, 3316, 1784 (mostly plants plus herbivores; carnivores 10 → 1).
- callgrind (W=1700, M=60), inclusive: herbivore_turn 80.7%, feed::best_visible 54.5%, SpatialIndex::within_into 50.5% (sort ≈27%), Population::locate 23.6%, feed::best_in_reach 10.8%. Self: locate 15.8% + ≈6% in inlined slice code, within_into ≈19%, sort ≈10%, best_visible 4.3%, PeriodicNoise::sample 2.0%.
- Heavier case `lush` preset: 83–91 ticks/s over 1500 ticks at about 7,000 organisms.

### Golden state hashes (`./evosim run --config <preset json> --seed S --ticks T --out o.json`)
The preset JSON comes from `./evosim config show --preset NAME`.

| preset | seed | ticks | state_hash | final P/H/C |
|---|---|---|---|---|
| default | 1 | 1500 | 79e144f06ded5f34716552087fb56bc007edbcb071328fbe8eb1a98f609cd6c4 | 2699/1146/6 |
| default | 42 | 1500 | 83bde04f74e3fc8609496b4b7dfd7946cecf94e796dcebbb222fd9789ce81f0e | 2508/843/7 |
| default | 42 | 3000 | e0bcfcb2acd7b6022476ca04dcb8773706c36b4e51bf0d32ec59b1e18cd4c982 | 2191/985/0 |
| lush | 1 | 1500 | f66a8c1874ac11100d581551b4ce26bea35f753b91423b2725844e6f51be8d97 | 5122/2163/9 |
| lush | 42 | 1500 | b76668e79769789933cf7353deb6e4e3d0a088ffc2a37746ab587fd2d0e0f891 | 4844/2345/2 |
| harsh | 1 | 1500 | c1477d86e1b6b4da0b1f306893234fe974fff26cb9c64912bf8dbcd6c184b3a9 | 702/0/0 |
| harsh | 42 | 1500 | 3b7b5b4fd19a4dc3dbc088af4b49da97d94d6db29336774758e853d66c4e9b1b | 680/0/0 |
| plants-only | 1 | 1500 | 64ac5ee00b090dcdd2be050ceafeb22d59c7aa9b824f46f424850e54a0b4fca3 | 3645/0/0 |
| plants-only | 42 | 1500 | 67a687264332b870bc10bae9fc20a6dd7cba2df0556d203b21c15644e1a1e469 | 3480/0/0 |

Before changing code, the implementer re-runs these rows and confirms they match. They are the "before" reference. If they don't match, record the anomaly and re-baseline from HEAD.

## Ordered work list
1. **Benchmark first, no behaviour code touched.**
   - New `crates/evosim-cli/src/perf.rs`: `pub struct PerfArgs`, `pub fn parse_perf_args`, `pub fn measure(sim: Simulation, warmup: u64, ticks: u64, repeat: u32) -> PerfReport`, `pub fn report_json(&PerfReport, ...) -> serde_json::Value`, `pub fn perf_command(args, out, err) -> i32`. Dispatch `"perf"` in `crates/evosim-cli/src/lib.rs` and add it to the help text. Reuse `load_config_file` and the checkpoint loading used by `run --load`.
   - The timing follows ADR-029 §1: one `Instant` per phase, taken in the `step_with` hook. The phase durations are summed. Organism counts come from `count_alive` per kind after each step, outside the timed region. The median tps is taken over R clones.
   - Run `./evosim perf` on the unchanged engine and save the JSON as `docs/perf/baseline.json`, or paste the numbers into PERFORMANCE.md. That is the "before" number.
   - `scripts/profile.sh` (callgrind recipe, see ADR-029 §2). `apt-get install -y valgrind` is optional; the script exits 2 with a message if valgrind is missing.
   - `scripts/perf-equivalence.sh`: for each row of the golden table above, generate the preset JSON, run, and compare `state_hash`. Store the expected list in `scripts/perf-equivalence.txt`. Exit 0 if all rows match.
2. **(A) Unsorted visitor.** `SpatialIndex::for_each_within(&self, center, r, filter, f: impl FnMut(&Neighbour))`: the same cell/locator branch logic as `within_into`, but no `out` and no sort. Add `Population::for_each_within`. Switch `feed::best_visible`, `feed::best_in_reach` and `hunt::best_in_reach` to it. Their comparisons already have explicit total tie-breaks, so the result does not depend on visit order. Check that no score can be NaN; bite and probability are clamped/finite. Leave `find_mate_in_reach` and `sense::perceive` sorted, because their tie-break is "first in order".
3. **(B) `nearest` min-search** in `SpatialIndex::nearest`: iterate unsorted. For each n with `(n.distance, n.id) < best_key` and `pred(&n)`, set best = n. Document that `pred` must be pure. Audit the callers: plants/repro.rs:104, animals/repro.rs:151, herbivore.rs:94, carnivore.rs:118, animals/mod.rs:82. All are pure today.
4. **(C) Lookup cost.** Add `Population::get_alive_of(kind, id)`, a single binary search in `by_kind[kind]`, and use it on hits whose `Neighbour.kind` is known (best_visible/best_in_reach/hunt/visible_mate/pollination). In `best_visible`/`best_in_reach`, look up the herbivore once. Re-profile; if `locate` is still above about 10%, add the optional derived id→slot cache (ADR-029 §3C).
5. **Re-measure and iterate.** Run `./evosim perf` and `scripts/profile.sh`. Stop when the gain levels off. Do not change behaviour to win speed.
6. **Tests.**
   - `crates/evosim-core/src/spatial/tests.rs`: `for_each_within` visits exactly the multiset of `within` (sort the visited hits and compare), and min-search `nearest` equals `within(...).into_iter().find(pred)` for random populations and preds. Use worlds 1×1, 3×3, 5×4 (wrap/duplicate edge cases, locator branch) and 64×48 with radii 0..=8.
   - `crates/evosim-cli/tests/perf.rs`: the slowdown guard (ADR-029 §5) and a CLI smoke: `evosim perf --warmup 10 --ticks 20 --repeat 2 --out F` exits 0, the JSON has the documented keys and equal state_hash across repeats, and `--ticks x` exits 2.
   - Run the whole `./test.sh`, which includes the determinism and checkpoint tests, plus `scripts/perf-equivalence.sh`.
7. **Docs.** Write `docs/PERFORMANCE.md` (ADR-029 §6). Update docs/ARCHITECTURE.md (CLI module perf.rs, spatial visitor, nearest purity rule) and docs/STATE.md (valgrind optional dependency + install command, TASK-026 status). Add an ADR-029 row in docs/decisions/README.md (already added in plan) and a README.md line for `evosim perf`.

## Acceptance mapping
| Must have | Evidence |
|---|---|
| One documented command, fixed setup ≥ about 2,000 organisms, seed, warm-up, measured ticks | `./evosim perf` (defaults W=1000/M=1000/seed 42/contract example); the report prints organisms min/mean/max; documented in PERFORMANCE.md |
| PERFORMANCE.md hardware/command/before/after | step 1 baseline JSON + step 5 numbers |
| Profile names hot spots + actions | phase shares + callgrind tables before/after |
| ≥100 tps at about 2,000 organisms | baseline is already 184 tps; after the optimisation expect ≥300 |
| Behaviour unchanged | `./test.sh` exit 0 + `scripts/perf-equivalence.sh` all 9 hashes equal |
| Slowdown guard | `crates/evosim-cli/tests/perf.rs` (≥25 tps, release only) |

## Risks
- Any change to iteration order inside float sums or RNG draws breaks the hashes; the equivalence script catches it.
- The perf guard is flaky under heavy parallel test load. The threshold is about 7× under baseline and can be overridden with the env var.
- callgrind over warm-up is slow (≈90 s for 1760 ticks). Profile from a checkpoint (`--load`).
- The benchmark's organism count dips to about 1,800 near t2000. The mean is about 3,500. If the reviewer wants a strict ≥2,000 at every tick, use `--warmup 500` (window t500–t1500 stays above 3,300), but fewer herbivores makes it less demanding. The default W=1000 is kept and its min/mean is reported.

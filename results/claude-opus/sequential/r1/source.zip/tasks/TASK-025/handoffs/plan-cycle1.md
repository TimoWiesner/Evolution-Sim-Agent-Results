# TASK-025 PLAN cycle 1 — scenarios, presets and charts

Design: [ADR-028](../../../docs/decisions/ADR-028-ui-scenarios-charts.md) — read it first. Builds on ADR-026/027 code in `crates/evosim-ui` (TASK-023/024, both PASS).

## Current code facts (checked 2026-11-23)
- `control.rs`: `Engine { sim, config, running, speed, epoch, selection }`, `Command` enum + `Command::from_json`, `Engine::{new, from_sim, apply, step_tick, status_json, inspector_json, speed_json}`. `step_tick` is the only place the sim advances → hook chart history there. `Reset`/`Load`/`LoadText` bump `epoch`.
- `session.rs`: `Shared.engine: Mutex<Engine>`, `with_engine(f)` locks + publishes a frame; `publish` rebuilds world JSON when `epoch` changes (so a NewWorld is automatically picked up by the page, which refetches `/api/world` on epoch change).
- `server.rs::route(req, s)` is public; method checks via explicit path lists at the top of `route` — **add new paths to those lists**. `Response::{new,json,text}.with_header`. `http::Request { method, path, query, body }` (query already split off, not decoded).
- `frame.rs::encode_engine_frame(e, tps)` adds `epoch/speed/selected` meta — add `charts_version`.
- Core: `config::{schema(), preset(), preset_names(), preset_description(), Config::{from_value, to_json_value, to_json_pretty}}`, `ConfigError { key, kind }` (+ `Display`; first error only), `metrics::{MetricsRecorder (new/record/samples), TRAIT_NAMES, trait_values, Stat}`, `KindSample { count, births_total, deaths_total, species_living, traits: [Option<Stat>; 11], .. }`, `organism::traits::TraitRanges::for_kind(kind)` (check field access for per-trait min/max; `control.rs::inspector_data` already maps the 11 traits to `{name,value,min,max}` — reuse that mapping), `Kind::ALL`, `control::kind_label`.
- `automation.rs::screenshots`: `shots` array of `(file, url-extra, required)` at line ~160; fast-forward target 100 ticks (`set_fast_until`).
- Web: `index.html` (top bar, `#world` canvas, sidebar cards `#controls`, `#inspector`, `#charts` placeholder), `app.js` (module.exports block at ~line 110 guarded for node), tests `web/test/{camera,controls}.test.js` run by `node --test crates/evosim-ui/web/test/`.
- `./evosim run` contract example: 962 ticks/s; after 300 ticks ≈ 3,500 plants.

## Ordered work list
1. **`crates/evosim-ui/src/scenario.rs` (new)** — `FEATURED: [&str; 12]`, `FieldError { key, message }` (+ `to_json`), `schema_json()`, `presets_json()`, `validate_form(&Value) -> Result<Config, Vec<FieldError>>` (per-field pass collecting all errors → `Config::from_value` → UI cell-count guard), `validate_text(&str)` (parse error → key `"<json>"`), `config_reply(&Config)`, `get_path(&Value, "a.b")`. `pub mod scenario;` in `lib.rs`.
2. **`crates/evosim-ui/src/charts.rs` (new)** — `ChartPoint`, `ChartHistory { points, stride, version, max_points }` with `new()`, `clear_and_seed(&Simulation)`, `observe(&Simulation)`, `decimate()`, `now_point(&Simulation)`, `to_json(epoch, since: Option<(u64,u64)>, now: Option<ChartPoint>)`; `histogram(&Simulation, Kind, trait_idx, bins) -> Value`; `parse_kind(&str)`, `trait_index(&str)`; `query_param(query, name) -> Option<String>`. Point built from `MetricsRecorder::new().record(sim)` → `samples()[0]` (one-off recorder; or add a small helper if `record` needs previous totals — births/deaths interval come from our own cumulative diff anyway).
3. **`control.rs`** — `Engine.history: ChartHistory` (seeded in `new`/`from_sim`); `step_tick` → `self.history.observe(&self.sim)` after the tick; `Command::NewWorld(Box<Config>)` (+ `from_json` `"new"` with `config` validated through `scenario::validate_form`, error text joined), apply per ADR-028 §3; `Reset`/`Load`/`LoadText` call `history.clear_and_seed`. `status_json` unchanged.
4. **`frame.rs`** — meta `charts_version: e.history.version`.
5. **`server.rs`** — routes `GET /api/schema`, `/api/presets`, `/api/config`, `/api/config/download`, `/api/charts`, `/api/histogram`, `/charts.js`, `/setup.js`; `POST /api/config/validate`, `/api/new` (400 with `{ok:false, errors}` without touching the engine); extend the 405 path lists. Embed `CHARTS_JS`, `SETUP_JS` via `include_str!`.
6. **`automation.rs`** — fast-forward to ≥300 ticks; add optional shots `charts.png` (`&view=charts`) and `setup.png` (`&setup=1`). Page sets a "ready" condition before reporting: charts mode waits until `/api/charts` and `/api/histogram` were drawn at least once; setup mode waits until presets/schema loaded, selects preset `lush`, types an invalid width (`0`) so its field error is visible.
7. **Web** — `web/charts.js` (helpers + `drawLineChart(ctx, spec, box)`, `drawHistogram(ctx, h, box, opts)`; dark theme; kind colours = world-view colours: plants green, herbivores cream/yellow, carnivores red), `web/setup.js` (form helpers + dialog DOM), `index.html` (script tags, "New world…" button, `<dialog id="setup">`, charts dock `#chartdock` under the world with 5 `<canvas>` + selects for trait mean/distribution kind+trait, "Charts" expand toggle), `app.js` (poll charts/histogram, reset chart state on epoch change, keys `W` setup / `C` charts; `keyToCommand` extension), `style.css` (dock grid, cards, field errors). Keep `main.png` tidy: world view still dominant (≈60 % height), charts dock ≈ 40 %.
8. **Docs** — README "User interface": new world dialog, presets, import/export, charts, keys; `docs/ARCHITECTURE.md` evosim-ui row (scenario, charts modules, new assets/endpoints); ADR-028 implementation notes; `docs/STATE.md`.

## Tests (all display-free) — evidence for each acceptance criterion
Rust `scenario.rs` unit tests:
- `presets_roundtrip`: for every preset, `validate_form(&c.to_json_value()) == Ok(c)`; `presets_json` lists ≥ 4 with `config`+`seed_text`.
- `export_import_identical`: edit seed (incl. `u64::MAX`), width/height, initial, and ≥5 featured params on a preset → `to_json_pretty` → `validate_text` → equal `Config` and equal pretty text.
- `collects_all_field_errors`: `{world.width: 0, initial.plants: -1, plants.mutation_rate: 2, climate.year_length: "x"}` → 4 errors keyed exactly at those keys; missing `seed` → error at `seed`; unknown key → error at that key; cross-field (`climate.pole_temperature > equator_temperature`) → error at the Core key; cell guard → `world.width`.
- `schema_json_marks_featured`: ≥ 5 featured non-fixed keys, every featured key exists in `config::schema()`.
Rust `charts.rs` unit tests:
- `history_records_and_rates`: run 50 ticks via Engine; points ascending ticks, counts equal `count_alive`, species equal `living_species`, interval births/deaths sum (×dt/100) equals `LifeTotals` deltas; extinct kind → null means.
- `decimation_bounded_and_consistent`: small `max_points` (e.g. 8), run 200 ticks → len ≤ max+1, stride doubled, version bumped, cumulative totals at kept ticks unchanged, sums of interval births still equal the total.
- `incremental_since`: `to_json(since=(v, t))` returns only later points; stale version → `full:true`.
- `recording_does_not_change_hash`: Engine stepped N ticks vs plain `Simulation` stepped N → equal `state_hash`.
- `histogram_counts`: `n == count_alive(kind)`, sum(bins) == n, edges len = bins+1, mean matches manual mean; empty kind → zeros + null mean; unknown trait → error.
Rust `control.rs`: `new_world_replaces_and_resets_history` (epoch+1, tick 0, hash == `Simulation::new(cfg)`, history 1 point, selection none); `invalid_new_world_untouched`.
`tests/server.rs` (real HTTP, no browser): `scenario_over_http` — GET schema/presets; POST `/api/new` invalid (width 0, mutation_rate 2) → 400, two errors with those keys, tick/epoch unchanged; valid preset with edits → 200, epoch+1, `/api/config` returns the edited config; `/api/config/download` → POST `/api/config/validate` → identical config (export→import); `/api/charts` grows while running, incremental `since`; `/api/histogram?kind=herbivores&trait=speed` sums to count; bad trait → 400.
Node (`web/test/charts.test.js`, `web/test/setup.test.js`): `niceTicks` monotone/covering; `mergeChartData` append/full/epoch reset; every `CHART_SPECS` entry yields non-empty `xLabel`, `yLabel`, `title` and legend names per series; `histogramBars` geometry; `validateField` (integer/number/bool/range/empty/required, seed up to 2^64−1 as text); `formFromConfig`→`configFromForm` round trip; `buildConfigText` keeps a seed `18446744073709551615` exactly.
End-to-end: `./test.sh` (cargo workspace tests, node tests, check-entrypoints incl. `ui --smoke-test` and `ui --screenshots`); manual `mkdir -p /tmp/shots && ./evosim ui --screenshots /tmp/shots` and view `main.png`, `charts.png`, `setup.png`.

## Risks / notes for IMPLEMENT
- Lock contention: `/api/charts` and `/api/histogram` lock the engine; serialise JSON outside heavy work, histogram O(N). Use `with_engine` (bumps `pending`) — but it also publishes a frame; add a `read_engine(f)` variant without publish to avoid extra frame builds on every chart poll.
- Seed precision in JS (ADR-028 §5) — test it.
- Screenshot timing: charts mode must wait for chart data before reporting (virtual-time-budget 8000 ms has been sufficient so far).
- The Advanced section has ~90 fields; build it lazily/collapsed so the dialog stays fast; keep the dialog scrollable in 900 px.
- `MetricsRecorder::record` computes interval deltas against its own previous sample — use only cumulative fields from it.

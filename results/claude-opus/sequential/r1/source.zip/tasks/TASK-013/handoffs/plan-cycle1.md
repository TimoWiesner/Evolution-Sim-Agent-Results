# TASK-013 PLAN cycle 1 — Animal sensing and movement

Design: [ADR-016](../../../docs/decisions/ADR-016-animal-sensing-movement.md). This file is the ordered implementation plan.

## Current codebase facts (verified in PLAN)
- `sim/mod.rs::run_phase`: `Phase::Herbivores => {}` and `Phase::Carnivores => {}` are empty slots.
- `Traits.speed = max_speed·gene` (f64, founder 1.0 herb / 1.5 carn), `Traits.vision = max_vision·gene` (founder 6 / 8). Keys `<kind>.move_cost` (0.2 / 0.3), `max_speed` (2 / 3), `max_vision` (6 / 8) exist but are unused so far.
- Moves only via `Population::move_organism(id, to) -> Result<Cell, SpatialError>` (updates the index). Queries: `Population::{within, within_into, nearest, at}` return living only, (distance, id) ordered, `Neighbour { id, kind, cell, offset, distance }`.
- `Torus::{offset, distance, step, translate}`, `Dir8::{ALL, offset, from_offset, opposite}`.
- `plants::site_ok` uses `plants.max_per_cell` + accepted seeds; founders ignore capacity (ADR-011).
- `Organism` fields private, `Organism::new(..)` crate-internal; `Population::validate` checks invariants.
- No base metabolism for animals yet (TASK-014/015).

## Ordered steps
1. **Config** (`config/params.rs`): add to `HerbivoreParams` `max_per_cell: u32 = 4 [1, 1_000_000]` and `sprint_cost: f64 = 0.5 [0, 100]`; to `CarnivoreParams` `max_per_cell: u32 = 2`, `sprint_cost: f64 = 0.5`. Regenerate docs/CONFIG.md table (same mechanism as earlier tasks; check `evosim config` schema/docs command used before). Update presets only if they list every key explicitly.
2. **Cell capacity** (`organism/capacity.rs` or in `organism/mod.rs`): `pub struct CellCapacity { pub plants: u32, pub herbivores: u32, pub carnivores: u32 }`, `from_config(&Config)`, `of(Kind) -> u32`, `Default` = from `Config::contract_example()`. Re-export from `organism`.
   - `Population` gets field `capacity: CellCapacity`; `founders` sets it from cfg; `with_expression`/`new` use default; `pub fn capacity()`, `pub fn set_capacity(c)`; `pub fn count_at(cell, kind) -> usize` (living same-kind count; add `SpatialIndex::count_at(cell, kind)` if cheap, else `at(..).len()`); `pub fn has_room(cell, kind) -> bool { count_at < cap }`.
   - `resolve_births`: after the dead-parent check, wrap pos; if `!has_room(pos, kind)` drop the request (no ID, no birth) and increment `totals`-independent counter `births_dropped_full: u64` (pub getter; TASK-022 serialise). Plants never hit it (site_ok counts accepted seeds), so plant results are unchanged — verify with the existing `capacity_holds_in_long_run` test.
   - `founders`: if the drawn cell has no room, probe `torus.index(cell)+1, +2, …` (row-major, wrapping) to the first cell with room; if none after W·H probes, keep the drawn cell (documented input overload). No extra RNG draws.
   - `plants::site_ok` / repro: read capacity from `pop.capacity().of(Kind::Plant)` (same value as `plants.max_per_cell` because founders sets it from cfg) — or keep reading cfg but through the shared helper; the rule text must be one place (doc comment on `CellCapacity`).
3. **Organism state** (`organism/mod.rs`): fields `heading: Option<Dir8>` (None) and `stride: f64` (0.0); pub getters `heading()`, `stride()`; `pub(crate)` setters. Init in `Organism::new`. `validate`: `stride` finite and in [0,1); plants keep None/0.
4. **Module `animals`** (`crates/evosim-core/src/animals/{mod.rs, sense.rs, movement.rs, tests.rs}`, `pub mod animals;` in lib.rs):
   - `sense.rs`: `pub struct Perception { pub center: Cell, pub radius: u32, pub seen: Vec<Neighbour> }`; `pub fn vision_radius(t: &Traits) -> u32 { floor(vision) }`; `pub fn perceive(pop: &Population, id) -> Option<Perception>` (None if not alive); `Perception::{of_kind(kind) -> impl Iterator<Item=&Neighbour>, nearest(kind) -> Option<&Neighbour>}`. Self excluded.
   - `movement.rs`:
     - `pub struct MoveCosts { pub move_cost: f64, pub sprint_cost: f64, pub max_speed: u32 }`, `MoveCosts::for_kind(kind, &Config)`; `pub fn step_cost(c, i) -> f64` (i 1-based); `pub fn path_cost(c, k) -> f64` = `move_cost·(k + sprint·k(k−1)/2)`.
     - `pub fn steps_allowed(stride, speed, max_speed) -> (u32, f64 new_stride)`.
     - `pub fn preferred_steps(torus, from, to) -> SmallList<Dir8>` (≤3 distance-reducing dirs in ADR order; empty if from == to).
     - `pub struct MoveOutcome { pub steps: u32, pub energy_spent: f64, pub blocked: bool, pub end: Cell }`.
     - `pub fn move_towards(pop: &mut Population, id, target: Cell, max_steps: u32, stop_at: u32, c: &MoveCosts) -> MoveOutcome`: loop: d = distance; if d ≤ stop_at or steps == max_steps break; cost = step_cost(c, steps+1); if energy < cost break; first dir in preferred_steps whose cell `has_room` (the mover itself is not in that cell, so no self-count issue) → `move_organism`, `spend_energy(cost)`; none → blocked, break.
     - `pub fn move_away(pop, id, threat: Cell, max_steps, c) -> MoveOutcome` (opposite of preferred dir, alternatives = its two neighbours in Dir8 order; stops when blocked).
     - `pub fn wander(pop, id, allowed, c, rng) -> MoveOutcome` per ADR (turn chance const `WANDER_TURN_CHANCE = 0.25`, ≤1 step; blocked → new heading drawn, no step).
     - `pub fn act_all(world: &mut World-or-Population, kind, cfg, rng) -> MoveTick` — default policy: for id in acting order (use `sim::acting_order` from sim side: implement `act_all` in `sim/mod.rs` or pass the ordered ids in, because `animals` may not depend on `sim`; recommended: `run_phase` computes `acting_order(alive_ids(kind), rng)` and calls `animals::act_animals(pop, &ids, kind, cfg, rng) -> MoveTick`). Per actor: `get_alive` re-check; `(allowed, stride') = steps_allowed`; store stride'; perceive; target = nearest of food kind; d ≤ 1 → stay; else move_towards(stop_at 1); none → wander.
     - `pub struct MoveTick { pub movers, pub steps: u64, pub energy_spent: f64, pub blocked: u64 }` (Default, Add-able); `World` keeps `last_moves: [MoveTick; 2]` (optional, for tests / later stats).
   - Ensure no wall-clock/hashed-collection tokens (source scan test).
5. **Scheduler** (`sim/mod.rs::run_phase`): Herbivores → `let ids = acting_order(pop.alive_ids(Herbivore), rng); animals::act_animals(..)`; Carnivores likewise. Keep comment that TASK-014/015 extend the per-actor body.
6. **Docs**: new `docs/ANIMALS.md` (perception, steps, cost formula with worked numbers, shortest-path rule, wander, cell-sharing rule verbatim, API for TASK-014..016); ARCHITECTURE `animals` row → implemented; STATE TASK-013 notes; CONFIG.md table; ADR README row (already added in PLAN).

## Tests (`animals/tests.rs` + organism/config tests), all deterministic
Sensing:
1. `sense_within_vision_only`: herbivore vision 3 at (10,10) on 40×40; organisms at distance 3 seen, 4 not; self excluded; order (distance, id).
2. `sense_across_x_edge`, `sense_across_y_edge`, `sense_across_corner`: animal at (0,0) on 20×20, vision 2, organisms at (19,0), (0,18), (19,19) seen with offsets (−1,0),(0,−2),(−1,−1); organism at (17,0) (distance 3) not seen.
3. `vision_follows_traits`: two animals with different vision genes see different sets (radius = floor(trait)).
Movement:
4. `steps_limited_by_speed`: property over speeds in [0, max_speed] and many ticks: Chebyshev displacement per tick ≤ ceil(speed) (and = allowed); mean steps over 1000 ticks ≈ speed (±1/1000·…; exact: Σallowed = floor(n·speed + ε)).
5. `cell_to_cell`: every step changes position by exactly one Dir8 (hook observes positions after each step via MoveOutcome / per-step trace in test helper).
6. `cost_grows_with_distance_and_speed`: `path_cost(k)` strictly increasing in k; `path_cost(k)/k` strictly increasing for sprint > 0; energy before−after equals `path_cost(steps)` in a real move; animal with energy < step cost does not move; energy never negative.
7. `shortest_way_across_edge`: on 20×10, from (1,5) to (18,5) → 3 steps via x wrap (positions (0,5),(19,5),(18,5)); same for y and diagonal corner; distance drops by 1 per step; tie case n/2 follows positive offset.
8. `shortest_way_interior`: no wrapping when interior is shorter.
9. `blocked_alternative_and_wait`: full preferred cell → alternative distance-reducing cell used; all blocked → no move, energy unchanged.
Cell-sharing rule:
10. `capacity_respected_by_moves`: crowd many herbivores into a small world for 200 ticks; after every Herbivores/Carnivores phase no cell exceeds cap per kind; herbivore+carnivore co-occupy a cell is allowed (constructed case).
11. `resolve_births_drops_full_cell`, `founders_probe_to_free_cell` (cap 1, 1×1… and 3×3 with 9 founders → one per cell; 10 founders on 3×3 cap 1 → overload documented), plant capacity tests still pass.
Index & determinism:
12. `index_in_sync_after_moves`: run sim with animals 300 ticks; after each phase `pop.index().check_against(alive positions)` OK and `validate` OK.
13. `wander_without_targets`: no plants → herbivores wander, displacement > 0 over 50 ticks, ≤1 step/tick; heading persistence (most consecutive steps share heading).
14. `chase_visible_target`: herbivore 5 cells from a plant reaches distance ≤ 1 in ceil(4/speed)+1 ticks.
15. `same_seed_same_positions` and `different_seed_differs`; `no_animals_rng_unchanged` (runs without animals keep prior RNG stream).
16. Config: new keys parse/validate, unknown-key behaviour unchanged.

Commands: `cargo test -p evosim-core --release --locked animals`, debug `cargo test -p evosim-core --locked`, `cargo clippy -p evosim-core --release --locked --all-targets`, full `./test.sh`.

## Risks
- Existing tests that assert exact numbers of runs with animals (hash/position/RNG-dependent) will change because animal phases now draw RNG and move animals — update expectations, do not weaken invariants.
- Founder probing changes positions only when a drawn cell overflows; tests with many founders on tiny worlds may shift.
- `resolve_births` guard can silently swallow TASK-016 births → TASK-016 must choose a cell with room.
- Performance: per-step `has_room` via `at()` allocates; use a count method on the index buckets.
- Diagonal-exact blocking can stall a chaser (waits) — acceptable, documented.

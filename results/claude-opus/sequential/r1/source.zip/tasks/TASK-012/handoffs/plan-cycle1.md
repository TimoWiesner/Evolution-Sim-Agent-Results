# TASK-012 PLAN cycle 1 — Plant reproduction and dispersal

Design (normative): [ADR-015](../../../docs/decisions/ADR-015-plant-reproduction-dispersal.md). Decisions: asexual by default + optional pollination by a compatible nearby donor; dispersal uniform over the toroidal Chebyshev square of radius `plants.dispersal_radius` (own cell included); one landing site per seed, unsuitable site → seed dies, cost lost.

## Code facts verified in PLAN
- `sim/mod.rs::run_phase` `Phase::Plants` calls `ctx.world.grow_plants(tick, &cfg.plants, max_precip)`; `PhaseCtx` has `rng`, `config`, `world`, `ids`.
- `Population::request_birth(BirthRequest{pos, parents, energy, health, genome})`; `resolve_births` wraps pos, drops if any parent not alive, sets `generation = 1 + max(parent gens)`, records `BirthRecord{parents, generation}`.
- `Population::at(cell, Some(Kind::Plant)) -> Vec<EntityId>` (flagged-dead already removed from index by `kill`), `nearest(center, r, filter, pred(&Neighbour{id,kind,cell,offset,..}))`.
- `genome::{child_asexual, child_sexual, distance, MutationParams::for_kind}`; `sim::acting_order(ids, rng)` (sort + shuffle).
- `Torus::{x_offsets(r), y_offsets(r)} -> RangeInclusive<i32>` (de-duplicated on small worlds), `translate(c, Offset{dx,dy})`, `distance`.
- `Rng::{chance, range_i64(lo, hi)}` (`range_i64(lo, hi)` is inclusive of both ends — verified in PLAN; use `range_i64(*xs.start() as i64, *xs.end() as i64)`).
- Config already has `reproduction_threshold` 12, `reproduction_cost` 6 (cross-checked ≤ max_energy), `dispersal_radius` 3, `pollination_enabled` true, `max_per_cell` 4, `initial_energy` 5.
- `Traits::fertility` ∈ [0,1] is expressed from gene `fertility`.

## Ordered implementation steps
1. **Config** (`config/params.rs`, PlantParams): add `seed_rate: f64 = 0.5 [0,1]`, `seed_min_resource: f64 = 1.0 [0,1000]`, `pollination_chance: f64 = 0.3 [0,1]`, `pollen_radius: u32 = 2 [0,64]` with doc strings. Regenerate docs/CONFIG.md table (`./evosim config schema`; test `config_doc_table_is_current`). Presets keep validating.
2. **`plants/repro.rs`** (new; `pub mod repro;` + re-exports in `plants/mod.rs`):
   - `pub fn seed_probability(t: &Traits, p: &PlantParams) -> f64` = `clamp(seed_rate·(0.5+fertility),0,1)`.
   - `pub fn dispersal_target(torus: &Torus, from: Cell, r: u32, rng: &mut Rng) -> Cell`.
   - `pub fn site_ok(pop, res, cell, accepted_here: u32, p) -> bool` (room: plants in cell + accepted < max_per_cell; resource: `R ≥ seed_min_resource`).
   - `pub struct ReproTick { spent, seed_energy, made, failed, requested, pollinated }`.
   - `pub fn reproduce_plants(pop: &mut Population, res: &CellResources, torus: &Torus, cfg: &Config, rng: &mut Rng, tick: u64) -> ReproTick` exactly per ADR-015 steps 1–8 (eligible list built first; return early without draws if empty or `seed_rate == 0`; `accepted: Vec<u16>` of cell count; clone mother genome before mutable borrow; donor via `nearest` with predicate closure computing `distance` against the mother genome copy — borrow `pop` immutably for that, then `get_alive_mut` to pay cost; order: pay cost → target → site check → pollination → request).
   - Draw order per eligible plant (determinism): chance(p) → [cost] → dx → dy → [site ok] → chance(pollination_chance) if enabled → genome draws.
3. **Ledger** (`plants/mod.rs`): add fields `reproduction_spent, seed_energy, seeds_made, seeds_failed, seeds_requested, pollinated` (+ `last_*` for the energies at least) and `record_repro(&ReproTick)`.
4. **World** (`sim/world.rs`): `pub fn reproduce_plants(&mut self, tick, cfg: &Config, rng: &mut Rng) -> ReproTick` (split borrow organisms/resources/torus), records into ledger.
5. **Scheduler** (`sim/mod.rs` Phase::Plants): after `grow_plants`, `ctx.world.reproduce_plants(ctx.tick, ctx.config, ctx.rng)`. Births come out through the existing Births phase/events.
6. **Adapt TASK-011 tests** (`plants/tests.rs`): `calm_cfg` sets `plants.seed_rate = 0.0` (growth tests stay isolated); `plant_growth_uses_no_core_rng` sets `seed_rate = 0` in both configs (and rename/comment: growth draws nothing); `energy_ledger_balances` expects `de = uptake − upkeep − last_reproduction_spent` (or sets seed_rate 0 and add a second ledger test with reproduction). Run the full suite; fix any other test that assumed constant plant counts (sim/tests.rs, organism/tests.rs, CLI tests) without weakening their intent.
7. **Tests** `plants/tests_repro.rs` (names map to ACs):
   - AC1 `no_reproduction_below_threshold`: plant with energy < threshold (seed_rate 1, resource_regen 0 so it can't grow, or call `reproduce_plants` directly) → no request, energy unchanged, RNG state unchanged. `reproduction_costs_energy`: energy ≥ threshold, seed_rate 1 → energy drops by exactly `reproduction_cost`, child energy = min(initial_energy, cost) ≤ cost; `ledger_reproduction_balances` over a 200-tick sim: per Plants phase `Δenergy = uptake − upkeep − reproduction_spent`, `seed_energy ≤ reproduction_spent`, newborn energies sum ≤ last seed_energy.
   - AC2 `offspring_within_dispersal_radius`: many seeds (property loop over seeds/radii 0..=4 and world sizes incl. 3×3, 5×4) → `torus.distance(parent, child) ≤ r`; `dispersal_crosses_edges`: parent at (0,0) and at (w−1,h−1) on a 16×12 world with r=3 → some children have x ≥ w−3 / y ≥ h−3 (wrapped) and all within distance r; `radius_zero_stays_in_cell`. Also all 49 offsets reachable for r=3 on a big world (uniform pattern sanity).
   - AC3 `offspring_inherit_mutated_genome`: mutation_rate 0 → child genome == parent genome, `Parents::One(parent)`, generation = parent gen + 1 (check via `BirthRecord` and organism); mutation_rate 1 / strength 0.1 → genes differ but distance small; grandchild generation 2. `pollination_records_both_parents`: pollination_chance 1, two compatible plants within pollen_radius → `Parents::Two(mother, donor)`, genes each from one of the two (mutation 0); incompatible donor (distance > species_threshold) or `pollination_enabled=false` → `Parents::One`.
   - AC4 `no_offspring_in_full_cell`: 1×1 world (or r=0) with `max_per_cell` plants already → seeds fail, no births, `seeds_failed > 0`; `accepted_seeds_respect_capacity_in_same_tick`: many eligible parents, r=0, cell with room for 1 → at most 1 birth; property over a 300-tick sim: after every tick each cell has ≤ max_per_cell plants unless it held more founders (founders are unconstrained — test on cells where founder count ≤ cap, or with initial placement ≤ cap); `no_offspring_without_resources`: set R of all target cells < seed_min_resource (`resources_mut().set`) → no births; cell with R ok next to cells without → children only in the R-ok cell.
   - AC5 `zero_plants_stay_zero`: `Config::new(seed, 32, 24, 0, 30, 5)` and `(…,0,0,0)` run 1 000 ticks with default params → `count_alive(Plant) == 0`, `births_of(Plant) == 0` every tick; also after all plants die (`resource_cap = 0`) count stays 0 for 200 more ticks.
   - Spread/regression: `plants_spread_and_persist`: default config 64×48, 400 plants, 0 animals, 600 ticks → plant births > 0, generation max ≥ 2, occupied cells at end > occupied at start or population alive at tick 600 (record numbers in STATE). Determinism: two identical runs → identical `organisms()`, ledger, rng_state.
8. **Docs**: docs/PLANTS.md section "Reproduction and dispersal" (rules, defaults, density dependence, energy accounting); docs/ARCHITECTURE.md plants row; docs/STATE.md (test results, population numbers); docs/CONFIG.md regenerated.
9. Run `./test.sh`, `cargo test -p evosim-core --locked`, `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`; record a short headless run (`./evosim run --config <64x48 default> --ticks 1000` or equivalent CLI) with plant counts and timing.

## Acceptance mapping
| AC | Shown by |
|---|---|
| Only with enough energy; costs energy | no_reproduction_below_threshold, reproduction_costs_energy, ledger_reproduction_balances |
| Within dispersal distance, across edges | offspring_within_dispersal_radius, dispersal_crosses_edges, radius_zero_stays_in_cell |
| Inherit genome with mutation; parent ID + generation | offspring_inherit_mutated_genome, pollination_records_both_parents |
| No offspring without room/resources | no_offspring_in_full_cell, accepted_seeds_respect_capacity_in_same_tick, no_offspring_without_resources |
| Zero plants stay zero | zero_plants_stay_zero |

## Risks
- Existing tests break because plants now reproduce and draw RNG (mitigation step 6; never weaken an AC of an earlier task).
- Population may explode or collapse with defaults; carrying capacity is bounded by `max_per_cell` and R regen, so explosion is capped at 4·cells. Tuning is TASK-027; record observed numbers.
- Performance at 2 000+ plants: `nearest` per pollinating seed; keep pollen_radius small; measure ticks/s on a 64×48 run.
- `range_i64` bound semantics: verify before use (off-by-one would violate AC2 — the radius property test catches it).
- Founders can exceed `max_per_cell` (unchanged from ADR-011); capacity tests must not assume founder cells are ≤ cap.

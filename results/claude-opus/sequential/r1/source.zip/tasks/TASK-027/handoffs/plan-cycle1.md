# TASK-027 PLAN cycle 1 — Ecosystem balance

Design: docs/decisions/ADR-030-ecosystem-balance.md. Results doc: docs/BALANCE.md (baseline + analysis +
exploratory trials T1–T3, P1, P1b already filled; sections 3-tail..7 are *TODO IMPLEMENT*).

## Done in PLAN (acceptance points 1 and 2 already covered by recorded data)
- Baseline `./evosim batch` on contract example (only fixed keys), seeds 1–10, 10,000 ticks, at commit d6fdb93
  → `tasks/TASK-027/data/baseline/` (seed-*.json, summary.json/csv, aggregates.csv), log `baseline.log`.
  Median coexistence 1,708.5; per-seed table in BALANCE.md §1.
- Death causes + curves from `run --metrics` of the same 10 seeds → `baseline-curves.csv`, `baseline-death-causes.json`.
- Cause analysis written in BALANCE.md §2 *before any code change* (mode A: carnivore starvation/no births, 6/10;
  mode B: herbivores eaten out t 397–694, 4/10).
- Exploratory sweeps on the baseline build (T1–T3) and a temporary prototype P1 (env-var patch in
  `animals/hunt.rs::attack`, **reverted**; `git status` clean apart from new docs/data; seed-1 10,000-tick hash
  re-checked equal to baseline). Helper: `tasks/TASK-027/data/coexistence-summary.py`.

## Ordered implementation steps
1. **Config keys** (`crates/evosim-core/src/config/params.rs`):
   - `hunting.prey_density_half: f64 = <chosen>` "[0, 1000]", doc: "Local prey density at which attack success
     is halved: success × n/(n+half), n = herbivores within the carnivore's vision (0 = off, ADR-030)".
   - Trial 2 only if pursued: `herbivores.mate_search_radius`, `carnivores.mate_search_radius: u32 = 0` "[0, 64]".
   - Changed defaults per measurement (expected start: `hunting.base_success` 0.36, `herbivores.initial_energy` 80).
   Keep keys reachable by `--param` (schema automatically). Regenerate docs/CONFIG.md from `./evosim config schema`
   (see how TASK-018 did it; grep CONFIG.md generator in scripts/ or README).
2. **Hunting** (`crates/evosim-core/src/animals/hunt.rs`):
   - `HuntParams.prey_density_half` (from config); `pub fn density_factor(n: u32, half: f64) -> f64`
     (`half <= 0` or not finite → 1.0; else `n/(n+half)`); `pub fn local_prey(pop, pred: &Organism) -> u32` using
     `pop.for_each_within(pred.pos(), vision_radius(pred.traits()), Some(Kind::Herbivore), |n| if alive count)`.
   - `success_probability(pred, prey, distance, cover, density, p)` — new `density` argument multiplied before
     the clamp. Update 6 call sites (hunt.rs, tests_hunt.rs). `best_in_reach` and `attack` compute density once.
   - With `prey_density_half = 0` results must be bit-identical to the baseline: test
     `density_off_is_identical` (run contract config 1,500 ticks with half 0 + old values → equals baseline hash
     `scripts/perf-equivalence.txt` row `default 42 1500` *before* re-recording; simplest: build a Config with the
     old values and compare to the constant recorded there).
3. **Unit tests** (`animals/tests_hunt.rs`): density_factor values (0 → 0, half → 0.5, off → 1); success with
   more visible herbivores is higher (monotone); count is wrap-aware (prey across the seam counts); half = 0
   ⇒ factor 1; property test (proptest exists? else seeded loop) p ∈ [P_MIN, P_MAX]; one RNG draw per attack still.
   A rule test that no hunting input reads global counts: document by code review + test that two worlds with
   equal local neighbourhood but different far-away herbivore counts give the same success probability.
4. **Trials** (record every one in BALANCE.md §3 with change / expected / measured, also failures). Protocol ADR-030
   D3: seeds 1–10, 5,000 ticks screening; use `--param` sweeps, e.g.
   ```
   ./evosim batch --config tasks/TASK-027/data/contract-example.json --seeds 1,2,3,4,5,6,7,8,9,10 --ticks 5000 \
     --out-dir /tmp/t4 --param hunting.prey_density_half=20,40,60 --param hunting.base_success=0.24,0.36,0.48 \
     --param herbivores.initial_energy=60,80
   python3 tasks/TASK-027/data/coexistence-summary.py /tmp/t4/summary.json
   ```
   (≈18 combos × 10 runs ≈ 5–8 min). Then refine (handling_time {10,15,20}, carnivores.mating_cooldown,
   reproduction_threshold) around the best; then mechanism trial 2 (mate_search_radius 0 vs 16/24) on the best
   setting; for failure analysis use `run --metrics` (death causes). Copy compact summaries (not GBs) to
   `tasks/TASK-027/data/trials/` (summary.csv of each batch is small).
5. **Choose defaults**: set them in params.rs; 10,000 ticks on seeds 1–10 (`--out-dir tasks/TASK-027/data/chosen-tuning`).
6. **Held-out**: seeds 1001–1010, 10,000 ticks, chosen defaults, contract example config, plain `./evosim batch`
   (`--out-dir tasks/TASK-027/data/heldout`); record per seed/kind extinction tick or survival in BALANCE.md §5.
7. **Regression values**: `scripts/perf-equivalence.txt` re-record (reason: TASK-027 defaults); check
   `crates/evosim-cli/tests/{cli,perf}.rs`, `crates/evosim-ui/tests/server.rs`, `scripts/check-entrypoints.sh`,
   ecology tests (`ecology/tests.rs`, `sim::tests_ecology`) and docs/ECOLOGY.md recorded numbers; tests that pin
   old default behaviour get explicit old values (pattern `Config::pre_task018()` in config/mod.rs:182).
   Earlier must-haves: no-replenishment/extinction scenario tests (`no_plants_herbivores_then_carnivores_die_out`
   etc.) must still pass unchanged.
8. **UI presets**: presets are built from `Config` defaults (config/presets.rs) — lush/harsh may set hunting values;
   review that they still make sense (only presets may follow new defaults).
9. **Performance**: `./evosim perf` (TASK-026 method) with chosen defaults; target ≥100 ticks/s (PROJECT.md) and
   the release guard `crates/evosim-cli/tests/perf.rs` (≥25). Record in BALANCE.md §6 and docs/PERFORMANCE.md.
   10,000-tick contract run must stay far under 300 s (baseline ≈ 35–39 s per run).
10. **Docs**: BALANCE.md §3–7 (before/after coexistence, goal reached?, limits), ECOLOGY.md "Default balance"
    pointer to BALANCE.md, ADR-030 status → Accepted with results, docs/decisions/README.md row (added in PLAN),
    ARCHITECTURE.md line (added in PLAN), STATE.md.
11. `./test.sh` (full suite) exit 0; report exact command/result.

## Time budget hint (IMPLEMENT phase)
Build ~10 s incremental; one 10-seed × 10,000-tick batch ≈ 40 s (longer if coexistence keeps all three alive:
more organisms; P1b 20×5,000 took 47 s). Full `./test.sh` previously ≈ several minutes — run once at the end
plus targeted `cargo test -p evosim-core --release hunt`.

## Rules check (PROJECT.md)
`n` = herbivores within the attacker's own vision ⇒ perception, local, same rule for all, independent of global
kind/species counts; no creation; P_MIN keeps kills possible (no immortality). Mate search radius = perception.

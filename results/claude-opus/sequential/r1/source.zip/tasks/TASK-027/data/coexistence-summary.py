# Usage: python3 coexistence-summary.py DIR/summary.json  -> per combo: median/sorted three-kind coexistence ticks, first-extinct kind per seed (c/h/p/-), carnivore births
import json,statistics,sys
from collections import defaultdict
s=json.load(open(sys.argv[1]))
g=defaultdict(list)
for r in s['runs']:
    et=r['extinction_tick']; ticks=r['ticks']
    co=min([t if t is not None else ticks for t in et.values()])
    first=min(et, key=lambda k: et[k] if et[k] is not None else 10**9) if any(v is not None for v in et.values()) else '-'
    g[json.dumps(r['params'])].append((co,first[0], r['births']['carnivores']))
for k,v in g.items():
    cs=sorted(c for c,_,_ in v); print(k,'median',statistics.median(cs),cs,''.join(f for _,f,_ in v),'carnBirths',[b for *_,b in v])

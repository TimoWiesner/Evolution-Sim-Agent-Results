# TASK-003 PLAN cycle 1 — Typed configuration and presets

Design decision record: `docs/decisions/ADR-006-configuration.md` (read first).

## Ordered implementation steps

1. **Dependency.** `crates/evosim-core/Cargo.toml`: `serde_json = { version = "1", features = ["float_roundtrip"] }`. Run `cargo build` once (network) to update `Cargo.lock` (verified in plan: crates.io reachable, serde_json 1.0.154 resolves). Then `--locked` builds work offline.

2. **Module layout** (`crates/evosim-core/src/config/`), `pub mod config;` in `lib.rs`:
   - `mod.rs` — `Config`, `WorldConfig`, `InitialConfig`, `from_json_str`, `from_value`, `to_json_value`, `to_json_pretty`, `validate_cross_fields`, `schema()`; re-exports.
   - `error.rs` — `ConfigError { pub key: String, pub kind: ConfigErrorKind }`, `impl Display + std::error::Error`.
   - `value.rs` — trait `ParamValue: Sized + Clone + PartialEq` with `fn read(v: &Value, key: &str, range: &Range) -> Result<Self, ConfigError>`, `fn write(&self) -> Value`, `const TYPE_NAME: &str`; impls for `u32`, `u64`, `f64`, `bool`, `String`. `Range` = `Option<(f64,f64)>` (inclusive; `None` for bool/String). Helper `json_type_name(&Value)` ("string", "number", "integer", "boolean", "array", "object", "null").
   - `params.rs` — macro `param_group!` and all non-fixed groups.
   - `presets.rs` — `preset_names() -> &'static [&'static str]`, `preset(name) -> Result<Config, ConfigError>`, `preset_description(name)`.
   - `tests.rs` (or `#[cfg(test)] mod tests` per file).

3. **Macro** (sketch):
   ```rust
   macro_rules! param_group {
     ($(#[$m:meta])* $Name:ident, $group:literal {
        $( $field:ident : $ty:ty = $default:expr, $min:expr, $max:expr, $doc:literal; )*
     }) => {
       #[derive(Debug, Clone, PartialEq)] pub struct $Name { $(pub $field: $ty,)* }
       impl Default for $Name { fn default() -> Self { Self { $($field: $default,)* } } }
       impl $Name {
         pub const GROUP: &'static str = $group;
         pub fn read(v: Option<&Value>) -> Result<Self, ConfigError>   // None => default; non-object => WrongType(key=group)
         //   1. unknown keys (iterate map, which is BTreeMap-sorted => deterministic) -> UnknownKey "group.k"
         //   2. each field in declaration order: present => ParamValue::read(.., "group.field", range) else default
         pub fn write(&self) -> Value                                   // all fields
         pub fn specs() -> Vec<ParamSpec>                               // key, type, default(Value), min, max, doc
       }
     }
   }
   ```
   Ranges given as `f64` for numeric types; use `f64::NAN`-free sentinel: for bool/String pass `(), ()` via a second macro arm or use `None` — implementer's choice, keep `ParamSpec { min: Option<f64>, max: Option<f64> }`.

4. **Fixed keys** (hand-written, no defaults): `seed: u64` (required, range 0..=u64::MAX, negative → OutOfRange), `world: WorldConfig { width: u32, height: u32 }` each required, `1..=4096`; `initial: InitialConfig { plants, herbivores, carnivores: u32 }` each required, `0..=1_000_000`. Missing `world` object → `Missing` with key `world`; missing `world.width` → key `world.width`. Top-level must be an object (else WrongType key `"<root>"`).
   Optional top-level metadata: `name: String = "custom"`, `description: String = ""`.
   Cross-field check (kind `Invalid`): `climate.pole_temperature <= climate.equator_temperature` (key `climate.pole_temperature`); `plants.reproduction_cost <= plants.max_energy`, `herbivores/carnivores.reproduction_threshold <= max_energy`, `initial_energy <= max_energy` (key = the smaller-side field). Keep cross checks few.

5. **Parameter groups and defaults** (units/semantics owned by later tasks; they may retune defaults or add keys — just add a macro line + docs/CONFIG.md row):

   `climate` (TASK-006/007): `year_length u32 = 400 [1,100000]`; `equator_temperature f64 = 28.0 [-50,60]` °C; `pole_temperature f64 = -25.0 [-80,40]`; `seasonal_amplitude f64 = 8.0 [0,40]`; `max_precipitation f64 = 1.0 [0,10]`; `precipitation_seasonality f64 = 0.3 [0,1]`; `weather_enabled bool = true`; `weather_temperature_sd f64 = 2.0 [0,20]`; `weather_precipitation_sd f64 = 0.1 [0,2]`; `weather_persistence f64 = 0.9 [0,0.999]`.

   `plants` (TASK-011/012): `max_per_cell u32 = 4 [1,64]`; `resource_cap f64 = 10.0 [0,1000]`; `resource_regen f64 = 0.5 [0,1000]`; `initial_energy f64 = 5.0 [0,1e6]`; `max_energy f64 = 20.0 [0.1,1e6]`; `max_age u32 = 300 [1,10_000_000]`; `reproduction_threshold f64 = 12.0 [0,1e6]`; `reproduction_cost f64 = 6.0 [0,1e6]`; `dispersal_radius u32 = 3 [0,64]`; `pollination_enabled bool = true`; `mutation_rate f64 = 0.05 [0,1]`; `mutation_strength f64 = 0.05 [0,1]`; `species_threshold f64 = 0.15 [0,1]`.

   `herbivores` and `carnivores` share struct `AnimalParams` (one macro invocation can't give different defaults → implement `AnimalParams` with the macro and give `carnivores` a hand-written default via a second macro arg, OR generate two structs `HerbivoreParams`/`CarnivoreParams` with the same field list; implementer chooses, the latter is simplest). Fields (herbivore default / carnivore default, range): `initial_energy f64 50/80 [0,1e6]`; `max_energy f64 100/160 [0.1,1e6]`; `max_age u32 1500/2000 [1,1e7]`; `maturity_age u32 100/150 [0,1e7]`; `base_metabolism f64 0.5/0.8 [0,1e3]`; `move_cost f64 0.2/0.3 [0,1e3]`; `max_speed u32 2/3 [1,16]`; `max_vision u32 6/8 [1,64]`; `max_meal f64 5.0/60.0 [0,1e6]`; `reproduction_threshold f64 70/110 [0,1e6]`; `reproduction_cost f64 35/55 [0,1e6]`; `mating_threshold f64 0.2/0.2 [0,1]`; `mutation_rate f64 0.05/0.05 [0,1]`; `mutation_strength f64 0.05/0.05 [0,1]`; `species_threshold f64 0.15/0.15 [0,1]`.

   `hunting` (TASK-015): `base_success f64 = 0.4 [0,1]`; `attack_cost f64 = 1.0 [0,1e3]`; `handling_time u32 = 5 [0,1000]`; `cover_protection f64 = 0.3 [0,1]`.

   Top-level `Config { seed, name, description, world, initial, climate, plants, herbivores, carnivores, hunting }`, `#[derive(Debug, Clone, PartialEq)]`. Add `Config::with_seed(u64)` for `--seed`.

6. **Presets** (`presets.rs`), each built as `Config` in code (start from defaults, override):
   - `default`: exactly contract §3 example (seed 42, 64×48, 400/120/20), all defaults. Must equal `from_json_str(<only fixed keys>)` except `name` → set `name = "default"`? To keep equality test clean: preset `default` sets `name = "default"`; test compares after normalising name, or simply compare all groups.
   - `lush`: 96×64, 900/220/30, `resource_regen 1.0`, `resource_cap 16`, `pole_temperature -10`, `seasonal_amplitude 4`, `max_precipitation 1.5`.
   - `harsh`: 48×36, 300/80/10, `pole_temperature -40`, `equator_temperature 22`, `seasonal_amplitude 16`, `resource_regen 0.3`, `weather_temperature_sd 4`.
   - `plants-only`: 64×48, 600/0/0 (shows zero animal populations), plant mutation_rate 0.1.
   Test asserts pairwise differences in world size / initial / climate / resources and that each round-trips and passes validation (`from_value(to_json_value(p)) == p`).
   Unknown name → `ConfigError{key:"preset", kind: UnknownPreset{name, available}}`.

7. **CLI** (small, out-of-scope `run` untouched) in `crates/evosim-cli/src/lib.rs`: new command `config`:
   - `evosim config presets` → preset names + description lines, stdout, exit 0.
   - `evosim config show --preset NAME` → full JSON (pretty) to stdout, exit 0; unknown name → stderr message, exit 2.
   - `evosim config validate FILE` → reads file; ok: stderr "config ok" (stdout empty or the normalised JSON with `--print`), exit 0; unreadable/invalid: stderr `error: <ConfigError>` naming key, exit 2.
   Add to `usage()`. Also add `pub fn load_config_file(path) -> Result<Config, String>` in CLI lib for reuse by TASK-019 (`run`).
   Keep existing run/batch/ui stubs.

8. **Docs**: new `docs/CONFIG.md` = every key with type, default, range, unit/meaning, unknown-key policy, error format, presets table. Update `docs/STATE.md`, `docs/ARCHITECTURE.md` (config module files, serde_json dep), `README.md` (short "Configuration" section pointing to docs/CONFIG.md and `evosim config` commands), `docs/decisions/README.md` (ADR-006 row — already done in plan).

9. **Entry-point checks** (`scripts/check-entrypoints.sh`): add checks: `config validate` on a fixed-keys-only temp file → 0; on `{"seed":1,"world":{"width":0,"height":5},"initial":{...}}` → 2 and stderr contains `world.width`; `config show --preset lush` → valid JSON (python3 -c json.load) and round-trips through `config validate`.

## Tests (core, `cargo test -p evosim-core`)
- `fixed_keys_only_is_valid`: contract §3 example → Ok, all non-fixed groups equal `Default`.
- `zero_populations_accepted`: initial 0/0/0, and each one zero separately.
- `every_non_fixed_param_has_default_in_range`: iterate `schema()`, default value inside [min,max].
- `missing_fixed_key_names_key`: for each of `seed`, `world`, `world.width`, `world.height`, `initial`, `initial.plants`, `initial.herbivores`, `initial.carnivores` remove it → `kind == Missing`, `key ==` that path, `to_string()` contains the key.
- `wrong_type_names_key`: `seed:"42"`, `seed:4.5`, `world.width:64.0`, `world:[1]`, `initial.plants:true`, `climate.weather_enabled:1`, `plants.max_age:"x"`, `name:5`, root `[]` → WrongType with key.
- `out_of_range_names_key`: width 0, height 4097, plants -1, seed -1, `plants.mutation_rate 1.5`, `climate.weather_persistence 1.0` → OutOfRange with key.
- generic schema test: for every numeric spec, set value `max+1`(or `min-1`) → OutOfRange naming that key; for every spec set `"str"` (or `1` for String) → WrongType naming key.
- `unknown_key_rejected`: top-level `foo`, `plants.max_agee`, `world.depth` → UnknownKey with key.
- `cross_field_invalid`: pole > equator → Invalid key `climate.pole_temperature`.
- `parse_error`: `"{"` → Parse with line/column.
- `round_trip`: fixed-only, each preset, and 200 randomised configs (simple deterministic LCG/xorshift in the test, values uniform in each spec's range, including awkward floats like 0.1+0.2) → `from_json_str(&to_json_pretty(&c)) == c` and second write is byte-identical.
- `presets_valid_distinct_selectable`: `preset_names().len() >= 3`; each `preset(n)` Ok, validates, round-trips; pairwise differ; `preset("nope")` → UnknownPreset listing names.
- `docs_list_every_key`: `include_str!("../../../../docs/CONFIG.md")` contains every `spec.key`.
CLI tests (`crates/evosim-cli/tests/cli.rs` or unit tests via `dispatch`): config validate ok/invalid (stderr names key, exit 2), unreadable file exit 2, presets lists ≥3, show --preset output re-validates.

## Commands for verification
- `./test.sh` (whole suite)
- `cargo test -p evosim-core --release --locked config`
- `./evosim config validate /tmp/fixed.json; echo $?`

## Risks
- Defaults are placeholders; semantics/tuning by TASK-006…027 (ecology balance in TASK-027). Later tasks may rename keys — then update CONFIG.md, presets and tests together.
- `float_roundtrip` must be enabled or round-trip equality on f64 can fail for rare values.
- serde_json `Map` order: default (no `preserve_order`) is BTreeMap ⇒ written JSON is alphabetically sorted; fine and deterministic. Do not enable `preserve_order`.
- u64 seed: JSON seeds > 2^53 parse exactly via serde_json integer path (as_u64), OK.

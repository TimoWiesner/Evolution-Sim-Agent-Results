# TASK-015 PLAN cycle 1 — Carnivore hunting

Design: [ADR-018](../../../docs/decisions/ADR-018-carnivore-hunting.md) (formula, constants, multi-carnivore rule). This file is the ordered work list.

## Current code facts (verified in PLAN)
- `World::act_animals(kind, cfg, tick, rng)` (`crates/evosim-core/src/sim/world.rs:168`) dispatches Herbivore → `act_herbivores`; Carnivore → TASK-013 `animals::act_animals` (to be replaced by `act_carnivores`). Called from `sim/mod.rs:261`.
- `hunting.{base_success, attack_cost, handling_time, cover_protection}` already exist in `config/params.rs:205-213` (HuntingParams) and docs/CONFIG.md, but nothing reads them.
- CarnivoreParams (`config/params.rs:182-202`): base_metabolism 0.8, move_cost 0.3, max_speed 3, max_vision 8, max_meal 60, max_energy 160, initial 80. No `climate_cost`/`assimilation` yet (herbivores have them).
- `Population::kill` returns false if absent/already dead (first cause wins, counted once) and removes from the spatial index immediately → the "cannot be eaten twice" guarantee.
- `DeathCause::Predation` exists. `Rng::chance(p)`.
- Reusable: `feed::{metabolic_cost, satiety, FeedParams}`, movement `steps_allowed/move_towards/wander/MoveCosts::for_kind`, `vision_radius`, `Population::{within, nearest, count_at, capacity}`.
- Test bench pattern: `animals/tests_feed.rs` / `animals/tests.rs` (Population::with_expression + request_birth + resolve_births, `genome(kind, ..)` helpers).

## Ordered implementation steps
1. **Config**: add to CarnivoreParams `climate_cost: f64 = 1.0, [0,100]` and `assimilation: f64 = 0.8, [0,1]`; regenerate docs/CONFIG.md table (`./evosim config schema`; tests `config/tests.rs` + CLI compare it).
2. **Organism** (`organism/mod.rs`): add `handling: u32` (0 for founders/newborns) with `handling()` / `set_handling(u32)`. Check that state hash/snapshot code (if any) and `validate` are unaffected; note TASK-022 serialisation in STATE.md.
3. **`animals/hunt.rs`** (new): consts `ATTACK_REACH=1, PREY_ALERTNESS=0.3, AGGRESSION_BONUS=0.4, ADJACENT_FACTOR=0.8, P_MIN=0.02, P_MAX=0.95`; `struct HuntParams {base_success, attack_cost, handling_time, cover_protection, assimilation, max_meal, v_ref, plant_cap}` + `from_config`; `power(t,&HuntParams)`, `cover(pop, cell, &HuntParams)`, `success_probability(pred:&Organism, prey:&Organism, distance, cover, &HuntParams) -> f64` (pure); `struct Attack {prey, distance, p, success, cost, prey_energy, gained, refused}`; `attack(pop, pred_id, prey_id, &HuntParams, tick, rng) -> Attack` (refusal checks → spend cost → one `rng.chance(p)` → on success read prey energy, `kill(Predation)`, gain only if kill returned true, set handling); `best_in_reach(pop, pred_id, &HuntParams) -> Option<(EntityId, f64 p, u32 d)>`; `HuntTick` + `HuntLedger` (record).
4. **`animals/carnivore.rs`** (new): `CarnivoreAction {Handle, Rest, Attack, PursueAttack, Pursue, Wander}`, `CarnivoreTurn {action, moved, attack: Option<Attack>, metabolism, starved}`, `carnivore_turn(...)`, `act_carnivores(pop, ids, cfg, now, width, tick, rng) -> (MoveTick, HuntTick)` per ADR-018 turn order. Metabolism via `feed::metabolic_cost` with a `FeedParams` built from carnivore keys.
5. **`animals/mod.rs`**: register modules + `#[cfg(test)] mod tests_hunt;`, re-export; update module doc. **`sim/world.rs`**: Carnivore branch → `act_carnivores`, store `hunt_ledger: HuntLedger`, getters `hunt_ledger()`, `last_hunt()`.
6. **Tests** `animals/tests_hunt.rs`:
   - AC1 `attacks_only_in_reach`: call `attack` with prey at distance 2 → refused, no energy change, RNG state unchanged; distance 1 across the x-wrap (C (0,0), H (W−1,0)) → not refused. `pursues_visible_prey`: speed-1.5 carnivore, prey at d ≤ r (immobile prey) → distance decreases over turns until attack; prey at d = r+1 → no pursuit (action Wander). Run-level `attack_distance_never_exceeds_one`: default-config 300-tick Simulation, `last_hunt().max_attack_distance ≤ 1` each tick, attacks > 0 overall.
   - AC2 `kills_and_escapes_both_occur`: 2000 independent attacks on fresh pairs (seeded RNG) with founder traits → kills > 0 and escapes > 0 (and ~p fraction, e.g. within ±5σ). `traits_change_success`: `success_probability` strictly greater for stronger/faster carnivore and lower for stronger/faster/more cautious prey, lower with cover; empirical kill rate strong-vs-weak differs over 2000 draws. `chance_from_core_rng`: same seed → same outcomes; different seed → different sequence; each non-refused attack advances RNG by exactly one draw.
   - AC3 `prey_dies_once_with_predation`: kill → `last_deaths` after `end_of_tick` has exactly one record of prey with cause Predation, `deaths_by(Herbivore, Predation) == 1`; `second_attack_refused`: second carnivore attacking same prey id after kill → refused, no gain, no cost; `two_carnivores_same_prey` in a phase run (2 carnivores adjacent to 1 herbivore, base_success 1 so P_MAX 0.95… use many seeds): never more than one Predation death of that prey, total gained ≤ prey energy.
   - AC4 `gain_at_most_prey_energy`: prey energy 5 and 150, assimilation 1.0 and 0.8, max_meal large/small → gained ≤ prey_energy each; run-level ledger `gained ≤ prey_energy`.
   - AC5 `attack_costs_energy_on_failure_and_success` (force p via base_success 0 → P_MIN… better: compare energy delta = attack_cost exactly for an escape and cost − gain for kill, metabolism excluded by calling `attack` directly); `carnivore_without_prey_starves`: carnivore alone (no herbivores), low energy → dies with Starvation within expected ticks, removed; `handling_blocks_attacks`: after a kill, next `handling_time` turns action Handle, no attack.
   - Determinism: same seed twice → equal `state_hash`/rng state; `no_animals_no_extra_rng_draws` still passes.
7. **Existing tests**: TASK-013 tests in `animals/tests.rs` that run phases with carnivores (lines ~254-320: cell-capacity invariants) must still pass; if a carnivore-energy/position assertion depended on the old policy, adjust with justification (do not weaken invariants).
8. **Docs**: docs/ANIMALS.md section "Carnivore hunting (TASK-015)"; docs/STATE.md TASK-015 notes; ARCHITECTURE.md animals row + ADR list; docs/decisions/README.md row ADR-018 (added in PLAN); CONFIG.md regenerated.
9. **Run** `./test.sh` (exit 0), clippy, and smoke: contract example config 2000 ticks (`cargo test --release -p evosim-core smoke -- --ignored --nocapture` or `./evosim run`), record carnivore/herbivore counts and kills honestly (no reproduction until TASK-016, so carnivores are expected to decline/starve).

## Risks
- Without reproduction (TASK-016) everything declines; coexistence is TASK-018/027. Don't over-tune now.
- Predation accelerates herbivore decline; if smoke shows carnivores wiping herbivores in < 200 ticks, lower defaults (base_success) and record.
- `Organism` gains a field → any struct literal/constructor tests must be updated; snapshot/hash (TASK-022) must include `handling`.
- RNG stream changes for all runs with carnivores (hash-pinned tests with carnivores may need updating with justification).
- 30-minute phase limit: keep tests small (≤ 300 ticks, small worlds) and run release-mode targeted tests first.

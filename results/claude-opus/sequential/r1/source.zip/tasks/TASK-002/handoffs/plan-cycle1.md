# TASK-002 PLAN cycle 1 — Project bootstrap and quality gates

## Decisions (recorded here and in docs/STATE.md)
- **Layout**: Cargo workspace exactly as docs/ARCHITECTURE.md: root `Cargo.toml` (workspace, `resolver = "2"`, members `crates/*`), `crates/evosim-core` (lib), `crates/evosim-ui` (lib stub, depends on core), `crates/evosim-cli` (bin target named `evosim`, depends on core + ui). Commit `Cargo.lock`.
- **Build tool**: Cargo; release profile per ADR-001 (`opt-level=3`, `lto="thin"`, `codegen-units=1`, `panic` default).
- **No external crates in TASK-002.** Hand-written argument parsing and hand-written version JSON. Rationale: zero network need for build, trivially offline `./evosim`, nothing to vendor. serde/serde_json/sha2/proptest/tiny_http get added by the tasks that need them (setup.sh uses the network only then).
- **Argument parsing**: hand-written (ADR-001 left `clap` vs hand-written open). Small surface, exact control over exit code 2 and stderr messages.
- **Test framework**: built-in `cargo test` (unit tests in `#[cfg(test)]`, integration tests in `crates/*/tests/`) plus a shell entry-point check script. **One documented command: `./test.sh`** = `cargo test --workspace --release` followed by `scripts/check-entrypoints.sh` (contract-level checks of `./evosim`, `./build.sh`, `dist/evosim`).
- **Self-contained dist/**: `dist/evosim` is a copy of the release ELF binary (glibc-dynamic; depends only on libc/libm/libgcc_s/ld-linux present in every Ubuntu 24.04 base). Web assets later embedded via `include_str!`. Verified with `ldd` whitelist + running a copy in a temp dir with `env -i PATH=/usr/bin:/bin`. Fallback if a non-base lib ever appears: `RUSTFLAGS='-C target-feature=+crt-static'` (static glibc, no extra target needed) or musl target.
- **Exit codes**: `--help`/`-h`/`help` → usage on stdout, exit 0. No arguments → usage on stderr, exit 2. Unknown command/option → message on stderr, exit 2. `version` with extra args → exit 2. `run`/`batch`/`ui` exist in help but print "not implemented yet (TASK-0xx)" on stderr and exit 2 (out of scope; replaced by later tasks).
- **Version JSON**: `{"name":"evosim","version":"<CARGO_PKG_VERSION of evosim-core>","contract":1}` + newline, nothing else on stdout. Constants live in core (`evosim_core::NAME`, `VERSION`, `CONTRACT_VERSION`, `fn version_json() -> String`) so UI/result JSON reuse them.

## Ordered implementation steps
1. `Cargo.toml` (workspace root) with `[workspace] members=["crates/evosim-core","crates/evosim-ui","crates/evosim-cli"]`, `resolver="2"`, `[workspace.package] version="0.1.0" edition="2021"`, `[profile.release]` as above.
2. `crates/evosim-core/Cargo.toml` + `src/lib.rs`: `pub const NAME: &str = "evosim"; pub const VERSION: &str = env!("CARGO_PKG_VERSION"); pub const CONTRACT_VERSION: u32 = 1; pub fn version_json() -> String` (format!, escape-free since constants are plain). Unit tests: JSON shape exact string, contract == 1.
3. `crates/evosim-ui/Cargo.toml` + `src/lib.rs`: placeholder `pub fn available() -> bool { false }` or doc comment only; depends on core (establishes dependency direction). One trivial test optional.
4. `crates/evosim-cli/Cargo.toml` (`[[bin]] name="evosim" path="src/main.rs"`) + `src/main.rs`: `fn main() -> ExitCode` dispatching on `std::env::args().skip(1)`; put logic in `src/lib.rs` or `cli.rs` as `pub fn dispatch(args: &[String], out: &mut impl Write, err: &mut impl Write) -> u8` so it is unit-testable.
5. `crates/evosim-cli/tests/cli.rs`: spawn `env!("CARGO_BIN_EXE_evosim")`: version → exit 0, stdout exactly the JSON line, stderr empty; `--help` → exit 0 and stdout contains `version`, `run`, `batch`, `ui`; `frobnicate` → exit 2, stderr non-empty, stdout empty; no args → exit 2; `version extra` → exit 2.
6. `setup.sh` (bash, `set -euo pipefail`, cd to `$(dirname "$(readlink -f "$0")")`): locate cargo (PATH, `$HOME/.cargo/bin`, `/opt/rust/cargo/bin`); if absent install via `curl https://sh.rustup.rs -sSf | sh -s -- -y --profile minimal` and source env; then `cargo build --release --locked`; log to stderr; idempotent. No apt packages.
7. `evosim` (bash launcher): resolve own dir with `readlink -f`, `exec "$DIR/target/release/evosim" "$@"`; if binary missing print "run ./setup.sh first" to stderr, exit 2. No network, no cargo invocation.
8. `build.sh`: cd root, find cargo as in setup, `cargo build --release --locked`, `rm -rf dist && mkdir dist`, `cp target/release/evosim dist/evosim`, `strip` if available (optional), `chmod +x`; then sanity `dist/evosim version >/dev/null`.
9. `scripts/check-entrypoints.sh`: from a temp cwd run `/workspace/evosim version` and compare JSON (python3 json.loads or grep), `--help` exit 0, unknown → 2, `./build.sh`, `dist/evosim version`, `ldd dist/evosim` whitelist (linux-vdso, libc, libm, libgcc_s, ld-linux, libpthread/libdl/librt), copy dist to `mktemp -d` and run `env -i PATH=/usr/bin:/bin $tmp/evosim version`. Exits non-zero on any failure.
10. `test.sh`: `cargo test --workspace --release --locked && scripts/check-entrypoints.sh`.
11. `README.md`: requirements, `./setup.sh`, `./evosim --help`, `./evosim version`, `./build.sh` (dist/ self-contained explanation), `./test.sh` (and raw `cargo test --workspace`), layout pointer to docs/ARCHITECTURE.md.
12. `.gitignore` already contains `target/` and `dist/` — verify; add `Cargo.lock` must NOT be ignored.
13. Update docs/STATE.md (test command, decisions), docs/ARCHITECTURE.md status line (skeleton exists; cli `dispatch` layout), ADR-001 note that arg parsing = hand-written.
14. `chmod +x setup.sh evosim build.sh test.sh scripts/check-entrypoints.sh` and make sure git records mode 100755 (`git ls-files -s` after harness commit, or `git update-index --chmod=+x` not needed if file mode set before add).

## Tests / evidence to record in IMPLEMENT
- `./setup.sh` (exit 0), rerun (idempotent, exit 0).
- `cd /tmp && /workspace/evosim version` → JSON; `python3 -c 'import json,sys; d=json.load(sys.stdin); assert d["contract"]==1'`.
- `./evosim --help; echo $?` → 0; `./evosim bogus; echo $?` → 2.
- `./build.sh && dist/evosim version && ldd dist/evosim`.
- `./test.sh` → exit 0 with test counts.
- `git check-ignore dist/evosim target/` → both ignored.

## Risks
- Fresh container may lack cargo on PATH (here at /opt/rust/cargo/bin): setup/build search known locations, rustup install fallback needs network (allowed).
- Executable bits lost → ensure chmod before harness commit.
- `--locked` fails if Cargo.lock missing/out of date: generate Cargo.lock in implement and commit it.
- check-entrypoints.sh runs build.sh (overwrites dist/); acceptable, dist/ is ignored.

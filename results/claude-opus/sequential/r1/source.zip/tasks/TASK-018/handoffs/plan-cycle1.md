# TASK-018 PLAN cycle 1 – Ecology integration and extinction

Design: [ADR-021](../../../docs/decisions/ADR-021-ecology-integration.md). Read it first: it contains the measured
failure of the current defaults and the measured effect of each candidate change.

## Baseline facts measured in PLAN (temporary example binary, removed again; feed.rs reverted)
| config (64×48, 400 plants) | result |
|---|---|
| defaults, 120 H / 20 C | H extinct t≈115 (0 births), C t≈245, plants persist |
| defaults, 120 H / 0 C | plants extinct t≈555 (Starvation 289), H extinct t≈517, 0 H births |
| defaults, plants only | plants persist (400 t: 400→990→449, seasonal) |
| h4 params (below) + current reserve formula, 0 C | boom-bust, plants extinct t≈1,030 (2 seeds) / t≈3,600 with reserve 0.5·(1−0.5a) |
| h4 + reserve = 0.35·max_P fixed, 0 C | **P+H coexist 5,000 ticks, seeds 1,2** |
| h4 + reserve 0.5 fixed | H starve t≈160 |
| f2 (h4 + below) 20 C | C starve t≈1,240–1,380, P+H coexist 5,000 (seeds 1–3) |
| f3 | H eaten out t≈330, C dead t≈680 |

h4 = `plants{resource_regen 1.0, resource_cap 15, upkeep 0.1, growth_rate 1.5, reproduction_threshold 8, reproduction_cost 4, initial_energy 4, max_per_cell 2}`,
`herbivores{base_metabolism 0.3, max_meal 2, maturity_age 80, initial_energy 60, move_cost 0.1, max_litter 2, mating_cooldown 80, max_per_cell 2, reproduction_threshold 80}`.
f2 = h4 + `herbivores{max_litter 3, mating_cooldown 40, maturity_age 60, reproduction_threshold 70}`, `hunting{base_success 0.1, handling_time 20, cover_protection 0.6}`,
`carnivores{maturity_age 150, base_metabolism 0.3, move_cost 0.15, max_litter 1, mating_cooldown 120}`.
f3 = f2 but `hunting{base_success 0.25, handling_time 15, cover_protection 0.5}`, `carnivores{maturity_age 150, base_metabolism 0.25, move_cost 0.1, max_litter 2, mating_cooldown 80, reproduction_threshold 100, reproduction_cost 40}`.
Speed: 2 seeds × 5,000 ticks with ~4,000 plants + ~800 herbivores = 27 s release (≈370 ticks/s).

## Ordered work list
1. **Protected plant reserve** (`crates/evosim-core/src/animals/feed.rs`): new key `herbivores.graze_reserve: f64 = 0.35, [0,1]`
   in `config/params.rs`; `FeedParams.graze_reserve`; `bite_size` reserve = `graze_reserve · plant.max_energy` (no aggression term);
   delete/rename `GRAZE_RESERVE` constant; update ADR-017 text (note "superseded by ADR-021 for the reserve") and docs/ANIMALS.md.
   Fix tests in `animals/tests_feed.rs` that assert the old aggression-dependent reserve (grep `GRAZE_RESERVE`, `reserve`).
2. **Default rebalancing** in `config/params.rs`: start from f2 (plants/herbivores) and sweep carnivore/hunting values between f2 and f3
   (base_success 0.12–0.2, handling_time 15–25, cover 0.5–0.6, carn base_metabolism 0.25–0.3, max_litter 1–2, cooldown 80–120,
   carnivores.max_per_cell 1–2 as predator interference). Use the report command (step 5) at 3,000 ticks × 3 seeds for the sweep, then
   10,000 × 5 for the final. Choose the setting with the longest median three-kind coexistence; record the sweep table in docs/ECOLOGY.md.
   Keep cross-field validation valid (initial_energy ≤ max_energy, reproduction_cost ≤ threshold etc.). Regenerate docs/CONFIG.md via
   `./evosim config schema` (test `config_doc_table_is_current`). Check presets in `config/presets.rs` still validate and make sense
   (plants-only, lush, harsh). Keep plants alive ≤ ~5,000 for speed (contract 10,000 ticks ≤ 300 s).
3. **Statistics phase** (`sim/mod.rs` + new `sim/stats.rs` or `metrics` module `crates/evosim-core/src/metrics/mod.rs`):
   `TickStats { tick, alive: [u64;3], births: [u64;3], deaths: [u64;3] (cumulative), births_tick, deaths_tick }` stored in `World`
   (`World::last_stats()`, `Simulation::last_stats()`), filled in Phase::Statistics from `Population::count_alive` and `totals()`.
   Plus `pub fn balance_ok(&LifeTotals, &Population) -> Result<(), String>` checking `initial + births − deaths == alive` per kind.
   No RNG. TASK-019 reuses it for the result series/totals.
4. **Tick-order documentation**: doc comment on `Phase::ORDER` / `run_phase` listing the ecology order (ADR-021 §1); new user doc
   `docs/ECOLOGY.md` (tick order, mechanisms + why, default values, measured results, how to run the report).
5. **10,000-tick multi-seed report command**: core `crates/evosim-core/src/ecology.rs` (or `metrics::survival`):
   `pub struct KindFate { extinct_at: Option<u64> }`, `pub struct SeedOutcome { seed, ticks, fate: [KindFate;3], final_alive: [u64;3], births, deaths, coexist_until: u64 }`,
   `pub fn survival_run(cfg: &Config, seed: u64, ticks: u64) -> SeedOutcome` (extinct_at = first tick after which count_alive==0, tick 0 if initial 0).
   CLI dev subcommand in `crates/evosim-cli/src/lib.rs`: `evosim ecology survival [--config FILE] [--seeds 1,2,3,4,5] [--ticks 10000] [--json]`
   (defaults: contract example config, seeds 1..5, 10,000 ticks; one std::thread per seed, results printed in seed order: deterministic).
   Text output per seed and kind: `seed 3: plants survived (final 2911) | herbivores survived (final 788) | carnivores extinct at tick 1288`.
   Wrapper `scripts/extinction-report.sh [args]` (runs `./evosim ecology survival "$@"`). Record the final output in docs/ECOLOGY.md and STATE.md.
   Add CLI help text and an integration test in `crates/evosim-cli/tests/cli.rs` with small ticks (e.g. `--ticks 50 --seeds 1,2 --json` exit 0, 2 entries).
   Invalid args → exit 2.
6. **Tests** (new `crates/evosim-core/src/sim/tests_ecology.rs` or `ecology/tests.rs`, release run must stay fast; mark >30 s ones `#[ignore]`
   only if a non-ignored shorter variant covers the same criterion):
   - `tick_runs_all_phases_in_documented_order`: `step()` report `phases == Phase::ORDER`, and a `step_with` hook records which phase
     changed what (plants energy in Plants, births in Births, removals in Deaths, species events in Species, stats in Statistics).
   - `fixed_keys_only_config_runs_1000_ticks`: `Config::from_json_str(contract example JSON with only fixed keys)` → 1,000 steps, `validate` OK
     every 100 ticks, no panic (also seeds 1..3).
   - `balance_holds_every_tick`: contract example, 1,000 ticks, after every step `initial + births − deaths == count_alive` per kind and
     `Population::validate` OK at the end.
   - `extinct_kind_stays_extinct`: run until a kind hits 0 (or start with 0 of it) and assert it stays 0 for ≥500 further ticks; also
     property-style: for 3 seeds, for each kind, once 0 never > 0 again; births of that kind stay constant.
   - `no_creation_outside_reproduction`: every `EventKind::Birth` has `parents != Parents::None` after tick 0 and births counter == number of
     Birth events; animal births have two parents of the same kind, plant births parents of kind Plant.
   - Scenarios: `no_plants_herbivores_then_carnivores_die_out` (initial plants 0: herbivores extinct at tick tH, carnivores at tC ≥ tH, both within N ticks,
     e.g. ≤ 3,000); `no_herbivores_carnivores_die_out` (H 0 → C extinct, plants alive); `plants_alone_persist` (P only, 3,000 ticks, plants > 0 at end, plant births > 0).
   - `default_plants_reproduce_alone` (plants-only from defaults: births > initial, alive > 0 at 2,000 ticks) and
     `default_herbivores_with_plenty_of_plants_survive` (defaults, 0 carnivores, e.g. 400 or 1,000 plants: herbivores alive at tick 500
     (several hundred ticks) with herbivore births > 0 and generation ≥ 2 exists).
   - `survival_run_reports_extinction_tick` (small run with initial plants 0 gives extinct_at for all; plants-only gives None for plants).
   - Determinism: `survival_run` twice same seed identical.
7. **Docs/state**: docs/ECOLOGY.md (new), docs/STATE.md TASK-018 notes (keys changed, report command + recorded results), docs/ARCHITECTURE.md
   (metrics/ecology module row, Statistics phase filled), ADR-017 note, docs/CONFIG.md regenerated.
8. Run `./test.sh`, `cargo clippy --release -p evosim-core -p evosim-cli --all-targets`, then `./scripts/extinction-report.sh` (10,000 ticks, seeds 1–5)
   and paste output into docs/ECOLOGY.md + implement handoff.

## Acceptance mapping
| criterion | covered by |
|---|---|
| documented tick order | ADR-021 §1, docs/ECOLOGY.md, `tick_runs_all_phases_in_documented_order` |
| fixed-keys config 1,000 ticks | `fixed_keys_only_config_runs_1000_ticks` |
| creation only initial/reproduction; zero stays zero | `no_creation_outside_reproduction`, `extinct_kind_stays_extinct` |
| scenario tests | three scenario tests (step 6) |
| balance every tick | `balance_holds_every_tick` |
| default plants alone + herbivores with plenty of plants | `default_plants_reproduce_alone`, `default_herbivores_with_plenty_of_plants_survive` |
| 10,000 ticks × ≥5 seeds report recorded | `./scripts/extinction-report.sh` → docs/ECOLOGY.md |

## Risks
- Existing tests with exact numbers under defaults (e.g. smoke/ignored tests, `plants_spread` numbers in STATE, species tests) may change; update them
  where they assert default-dependent values, never weaken invariants.
- Coexistence is a knife edge (f2 vs f3); fine with a documented collapse (out of scope), but prefer the longest-coexisting setting.
- Large plant counts slow tests: keep core tests ≤ ~2,000 ticks on the 64×48 world, or use smaller worlds.

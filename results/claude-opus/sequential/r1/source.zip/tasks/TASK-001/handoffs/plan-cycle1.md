# TASK-001 PLAN (cycle 1): Architecture decisions

This is a documentation-only task. The IMPLEMENT phase writes the ADRs and the architecture ledger exactly as planned here. **No product code** (no `Cargo.toml`, `src/`, scripts, `setup.sh`, `evosim`, `build.sh`) may be added in TASK-001; those belong to TASK-002.

## Environment facts (observed 2026-11-22, plan phase)
- CPU: AMD Ryzen 5 7500F, 12 logical cores (reference hardware for perf claims later).
- `rustc 1.100.0`, `cargo 1.100.0`, `node v18.19.1`, `Python 3.12.3`.
- `chromium` = `/usr/local/bin/chromium`, Chromium 131.0.6778.33; `CHROME_BIN` set.
- `docs/decisions/README.md` exists (says: numbered ADRs with status, context, alternatives, decision, consequences, verification).
- No git remote configured is expected (`git remote -v` empty).

## Decisions fixed in this plan (IMPLEMENT must write them up, may refine wording, not substance)

### ADR format (TASK decision "format of the decision records")
Markdown files `docs/decisions/ADR-NNN-<slug>.md`, each with sections in this order:
`Status` (Accepted, date 2026-11-22, task TASK-001) · `Context` · `Alternatives considered` (≥2 realistic ones, each with pros/cons) · `Decision` · `Rationale` with explicit sub-headings **Performance**, **Testability**, **Self-contained dist/** · `Consequences` · `Verification strategy` (which later task/test proves it).
Update `docs/decisions/README.md` with an index table of the ADRs and this format.

### ADR-001 Language and runtime of the simulation core → **Rust (stable, edition 2021), Cargo workspace**
- Alternatives: (a) Python 3 + NumPy — fast to write, but per-organism logic is interpreter-bound (~10–50× slower; 100 ticks/s at 2,000 entities risky), dist/ needs PyInstaller/embedded interpreter (large, fragile); (b) TypeScript on Node 18 — one language for UI and core, decent JIT speed, but dist/ needs bundling a Node binary (pkg/SEA), GC pauses, floats deterministic but less control over integer/bit ops; (c) C++ — fast, but no package manager / more UB risk, slower to test.
- Choice reasons: Performance — native code, no GC, cache-friendly `Vec` storage; target ≥100 ticks/s at 2,000 entities is ~200k organism updates/s, well within budget even single-threaded. Testability — `cargo test` built in, `proptest` for property tests, integration tests in `tests/`, benches via `--release` timing tests. dist/ — `cargo build --release` produces one binary depending only on glibc/libm/libgcc_s (present on plain Ubuntu 24.04); web UI assets embedded with `include_str!`/`include_bytes!`, so `dist/` = the single `evosim` binary (+ optional README). Verify with `ldd dist/evosim` in TASK-002/028. Fallback if needed: `x86_64-unknown-linux-musl` target (fully static) installed by `setup.sh` via rustup.
- Planned crates (minimal, pinned via `Cargo.lock`): `serde`, `serde_json` (with `float_roundtrip`), `sha2` (state hash), `tiny_http` (UI server only), dev: `proptest`. Possibly `toml` for optional TOML config. CLI arg parsing: hand-written or `clap` (TASK-002 decides) – must map usage errors to exit 2.
- `setup.sh` (TASK-002): `cargo build --release` (installs rustup toolchain only if `cargo` missing). No apt packages planned.

### ADR-002 UI technology → **Local browser UI served by the same Rust binary**
- `evosim ui` starts an HTTP server on `127.0.0.1:<port>` (std threads + `tiny_http`), embeds static HTML/CSS/vanilla JS (Canvas 2D, no npm build step), and owns the engine instance (`evosim-core::Simulation`). Browser polls/receives compact frames (JSON metadata + binary/base64 cell and organism arrays) and sends commands (run/pause/step/reset/speed/inspect/config/save/load).
- Alternatives: (a) native desktop with `egui/eframe` — single binary, but needs OpenGL/mesa under `xvfb-run` for smoke/screenshots, harder to style, screenshot capture needs extra code; (b) Electron/Tauri — rich UI but huge dependency tree, Tauri needs webkit2gtk apt packages, Electron needs Node packaging; (c) Python Tkinter front-end talking to core — second runtime, weaker visuals; (d) Node server + React — needs npm build, second runtime at run time.
- Smoke test / screenshots: binary starts server on a free port, then spawns the container's `chromium --headless` (path from `CHROME_BIN`/`PUPPETEER_EXECUTABLE_PATH`, fallback `chromium`) with `--screenshot=DIR/main.png --window-size=1440,900 --virtual-time-budget=…` on a URL with query flags (`?autotest=smoke` / `?autotest=shots&view=main|charts|inspector`). Page reports "frame rendered"/tick count back to server via POST; server checks ≥10 / ≥100 ticks advanced and ≥1 frame rendered, then shuts down, exit 0; hard timeout guards (<60 s / <120 s). Alternative driver if `--screenshot` timing proves flaky: CDP over `--remote-debugging-port` from Rust (no Node needed). Decide in TASK-023.
- Performance: server-side simulation in native code; frames only sent at UI refresh rate (≤30 fps), canvas draws cell layer from cached ImageData; 1,000 organisms trivially drawable.
- Testability: HTTP API testable with Rust integration tests without a browser; smoke test itself is an automated end-to-end test.
- dist/: assets embedded in binary; `dist/evosim ui` works if a browser exists, but only `./evosim` must support screenshots (contract).

### ADR-003 Neighbour search on the wrapping grid → **Per-cell bucket index (uniform grid with cell size 1), torus-aware ring scan**
- Structure: `SpatialIndex { width, height, cells: Vec<SmallVec/ Vec<EntityId>> }` per kind (plants, herbivores, carnivores) — or one index with kind-filter; each bucket kept **sorted ascending by `EntityId`** (insert via binary search; remove via binary search). Incremental `insert/remove/move` on every position change; optional full rebuild (counting sort, CSR layout) if profiling in TASK-026 shows it is faster.
- Query `within(center, r, kind_filter)`: metric = **toroidal Chebyshev distance** (matches 8-neighbour cell moves) — dx = min(|x1-x2|, W-|x1-x2|) etc. Scan columns `dx ∈ [-r, r]`, rows `dy ∈ [-r, r]`, but clamp to **distinct** wrapped cells: if `2r+1 ≥ W` scan every column exactly once (same for rows) → no duplicates even for radii larger than the world or 1×1 worlds. Output order deterministic: by ring distance, then fixed scan order (dy, dx), then EntityId; or simply results sorted by (distance, id). Provide also `nearest(center, r, kind, predicate)` that scans rings 0..r and stops early.
- Alternatives: (a) brute force O(N) per query → O(N²) per tick, 4M distance checks/tick at 2,000 – too slow at 100 ticks/s, kept as test oracle; (b) coarse spatial hash (bucket size B>1) — fewer buckets, but needs extra distance filter and wrap handling when W not multiple of B; (c) k-d tree / quadtree — good for continuous space, awkward with torus wrapping (needs ghost copies), rebuild cost each tick, no gain on an integer grid.
- Performance: query cost O((2r+1)² + k); with perception radius ≤ ~6 that is ≤169 bucket visits; updates O(log m) per bucket. Memory O(W·H + N).
- Testability: randomized test vs brute force (≥1,000 queries, small worlds 1×1, 1×N, radius > world) — TASK-010; property tests for no duplicates and deletion correctness; timing comparison at 2,000 organisms recorded in docs.
- dist/: pure Rust, no deps.

### ADR-004 Genome design, inheritance, mutation, species rule → **Fixed-length real-valued gene vector per kind + founder-based distance threshold species**
- Representation: `Genome { genes: Vec<f32> }` (or fixed array) with values in `[0,1]`, length/layout per kind defined by a static gene table (name, trait range, mapping). Plant genes e.g. growth rate, max size/biomass, seed count, dispersal radius, temperature optimum, temperature tolerance, water need, defence/toxicity, pollination tendency. Animal genes e.g. speed, strength, max health, fertility/litter, size/metabolism, perception radius, aggression, risk tolerance/boldness, sociality/herding, temperature optimum/tolerance, diet efficiency, mate choosiness. Plus 4–8 **neutral marker genes** (no phenotype) that drift and make lineage divergence measurable even under stabilising selection.
- Phenotype mapping: deterministic `trait = lo + (hi-lo) * g` (or a smooth curve, documented per gene), so traits are always in range by construction. Derived costs (e.g. speed²·size metabolic cost) give trade-offs.
- Inheritance: plants – asexual copy (clone) by default, optional pollination = uniform crossover with a compatible nearby plant. Animals – two parents, **uniform crossover per gene** (each gene from mother or father with p=0.5, from simulation RNG), then mutation.
- Mutation: per gene with probability `mutation_rate` add Gaussian noise `N(0, mutation_strength)` (Box–Muller from core RNG), then **reflect** into [0,1] (avoids pile-up at bounds). Rates configurable per kind.
- Genetic distance: `d(a,b) = Σ w_i |a_i - b_i| / Σ w_i` (weighted mean absolute difference, w=1 default) ∈ [0,1]; d(a,a)=0, symmetric, monotone. (Euclidean considered; L1 chosen for cheap, intuitive threshold.)
- Species rule (stable, explicit): every species stores its **founder/representative genome**. A newborn inherits its (mother's) species if `d(child, species_rep) ≤ T_kind` (threshold, default e.g. 0.15, configurable); if `d > T_kind`, a new species is founded with this child as representative and `parent_species = mother's species`. Classification happens once at birth, never re-assigned → species IDs stable and deterministic. Exactly-at-threshold stays in the parent species (tested in TASK-017). Animals additionally only mate with partners whose distance ≤ `mating_threshold` (reproductive isolation → species are real breeding units). Species IDs: sequential counter per run; names generated deterministically from ID (syllable table).
- Alternatives: (a) bitstring genome with Hamming distance — simple, but coarse trait resolution and mutation effects too discrete; (b) periodic clustering (k-means/DBSCAN over all genomes every K ticks) — reflects current populations but cost O(N²) or needs k, IDs unstable between clusterings, flicker; (c) NEAT-style neural genome for behaviour — powerful but heavy, distance hard to define, slow; (d) diploid genome with dominance — more realistic, doubles cost and complexity; kept as possible future extension.
- Performance: ~20 floats per organism, crossover/mutation O(L); distance O(L) only at birth (vs one representative). Testability: rate 0 ⇒ child genes ⊂ parents' genes; property tests for range, symmetry, d=0; forced divergence test for speciation. dist/: pure Rust.

### ADR-005 Determinism, RNG and processing order
- Single source of randomness: one `Rng` in the simulation state, algorithm **xoshiro256\*\*** implemented in-crate (≈30 lines, no external crate whose stream could change across versions), seeded from config `seed` via **SplitMix64**. State = 4×u64, exported/restored exactly in checkpoints and included in `state_hash`. Optional deterministic sub-streams derived via SplitMix of (seed, purpose) — not threads.
- Order inside a tick (fixed, TASK-005 finalises): 1 climate/season/weather update → 2 cell resources regenerate → 3 plants (growth, seeding) → 4 herbivores act → 5 carnivores act → 6 reproduction resolution → 7 deaths removed (stable compaction) → 8 species bookkeeping (extinct ticks) → 9 statistics/sampling → tick += 1.
- Organism order: organisms live in `Vec`s ordered by ascending `EntityId`; IDs are allocated from a monotonically increasing u64 counter (never reused); newborns appended (thus remain sorted) and act from next tick; deaths flagged during the phase and removed at the end with order-preserving `retain`. Conflicts (two animals targeting the same prey/cell) resolved by processing order = id order. Optional fairness: per-tick shuffle using the core RNG (decided in TASK-005; still deterministic).
- Must avoid: wall-clock time in simulation logic (only for `elapsed_seconds` measurement); unseeded/global RNGs (`rand::thread_rng`, JS `Math.random` for sim); iterating `HashMap/HashSet` (std hashers are randomly seeded) — use `Vec`, `BTreeMap`, or sorted vectors; multithreaded mutation or parallel float reductions with nondeterministic order (parallelism only for pure per-item computations whose results are applied in id order); platform-dependent float functions in hot logic are acceptable (contract allows minor inter-platform differences) but no `-ffast-math`-like flags; UI must never mutate the sim except through the command queue applied between ticks.
- State hash: SHA-256 over a canonical, versioned binary/JSON serialization of the full state (tick, RNG state, config, climate state, all organisms incl. genomes in id order, species table, counters, totals). Floats hashed via `to_bits()`.
- Checkpoints: same serialization (serde JSON with exact float round-trip), so load→continue equals uninterrupted run.

### docs/ARCHITECTURE.md (rewrite) — planned modules and dependency rules
Cargo workspace:
```
crates/evosim-core   (lib)  – simulation engine, NO UI/IO-server deps
crates/evosim-ui     (lib)  – HTTP server, embedded web assets, UI session; depends on core
crates/evosim-cli    (bin "evosim") – argument parsing, run/batch/version/ui dispatch; depends on core, ui
```
Core modules (`evosim-core/src/`): `config` (typed config, defaults, presets, validation → errors) · `topology` (torus coords, wrap, distances) · `rng` (xoshiro256**, SplitMix64, normal) · `clock`/`sim` (Simulation state, `step()`, phase order, command application) · `climate` (latitudinal zones, seasons, weather fields) · `genome` (genes, mapping, crossover, mutation, distance) · `organism` (Plant/Animal structs, energy, age, health, life cycle) · `spatial` (bucket index) · `plants` (growth, resources, reproduction/dispersal) · `animals` (sensing, movement, herbivore feeding, carnivore hunting, mating) · `species` (registry, classification, phylogeny) · `metrics` (counts, births/deaths, diversity, trait stats, series) · `snapshot` (save/load, canonical serialization, state hash) · `batch` (multi-seed runner, summary stats; pure, no CLI).
Dependency rules: `topology`, `rng` depend on nothing; `config` on nothing internal; `genome` → rng; `climate` → topology, rng, config; `spatial` → topology; `organism` → genome; `plants`/`animals` → organism, spatial, climate, genome, species, rng; `species` → genome; `sim` → all simulation modules; `metrics` reads `sim` state; `snapshot` → sim. `evosim-core` never depends on `evosim-ui` or `evosim-cli` (enforced by Cargo: core's Cargo.toml has no path dep on them). UI and CLI only use the core's public API (`Simulation::new(config)`, `step()`, `snapshot()`, `load()`, query functions).
Also document: data ownership (Simulation owns everything; UI holds handle behind a Mutex in server thread), clocks (sim tick counter only; wall clock only in CLI/UI for timing/pacing), RNG strategy (link ADR-005), CLI/UI boundary, validation (config errors → exit 2), web asset layout `crates/evosim-ui/web/{index.html,app.js,style.css}`.

## Ordered IMPLEMENT steps
1. Write `docs/decisions/ADR-001-language-runtime.md` … `ADR-005-determinism.md` with the format above.
2. Update `docs/decisions/README.md`: format description + index table.
3. Rewrite `docs/ARCHITECTURE.md` with module table, dependency diagram (text), boundaries; link ADRs.
4. Update `docs/STATE.md`: TASK-001 status (implemented, awaiting review), chosen stack, system dependencies (none via apt; chromium provided by container), planned test command (`cargo test --workspace`, finalised in TASK-002).
5. Write `tasks/TASK-001/handoffs/implement-cycle1.json` with verification commands below.

## Verification commands (IMPLEMENT runs and records; REVIEW reruns)
- `ls docs/decisions/ADR-00{1,2,3,4,5}-*.md` → 5 files, exit 0.
- `for f in docs/decisions/ADR-*.md; do grep -c -E '^#+ .*(Alternatives|Decision|Performance|Testability|dist)' $f; done` → each ≥5.
- `grep -n -i -E 'wall.clock|HashMap|xoshiro|EntityId' docs/decisions/ADR-005-*.md` → hits for RNG source, order, avoid-list.
- `grep -n 'evosim-core' docs/ARCHITECTURE.md` and a line stating core must not depend on UI.
- `git status --porcelain` → only `docs/**` and `tasks/TASK-001/handoffs/**` changed; `git ls-files -o --exclude-standard | grep -v -E '^(docs|tasks)/'` → empty (no product code).
- `python3 -c "import json;json.load(open('tasks/TASK-001/handoffs/implement-cycle1.json'))"` → handoff valid.

## Risks
- Chromium `--screenshot` may fire before JS has run ticks → mitigate with `--virtual-time-budget` or CDP driver (TASK-023).
- glibc-dynamic binary assumed fine on plain Ubuntu 24.04; verify with `ldd`; musl fallback.
- Species threshold value needs tuning in TASK-017/027; founder-representative scheme can make old species "absorb" drift slowly—acceptable, documented.
- Uniform per-cell index assumes perception radii stay small (≤ ~10); if larger radii evolve, cap via gene range.

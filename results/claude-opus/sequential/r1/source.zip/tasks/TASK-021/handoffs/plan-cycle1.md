# TASK-021 PLAN cycle 1 — work list for IMPLEMENT

Design: docs/decisions/ADR-024-batch-runs-export.md (binding; read it first). Acceptance criteria → where they are shown:

| Must have | Shown by |
|---|---|
| `./evosim batch` writes per-seed results + summary (CONTRACT §2) | CLI integration test `batch_plain_seeds` + check-entrypoints e2e `./evosim batch --config ex.json --seeds 1,2,3 --ticks 50 --out-dir D` |
| ≥1 parameter varied over several values; test runs 2 values × 2 seeds | CLI integration test `batch_sweep_2x2` (`--param plants.growth_rate=0.8,1.2 --seeds 1,2`) + core unit test `expand_2x2_order` |
| summary.json lists every run (seed, params, ticks) + aggregates mean/min/max final per kind + extinction counts | `batch_sweep_2x2` recomputes aggregates from the 4 per-seed files; core unit test `aggregates_on_synthetic_outcomes` (hand values incl. an extinct kind) |
| CSV export | `batch_sweep_2x2` parses summary.csv (header + 4 rows, param column) and aggregates.csv; core test `csv_quoting` |
| Same batch twice → same summary apart from time | `batch_reproducible` (run twice into two dirs, strip `timing`, `runs[].elapsed_seconds`, `runs[].ticks_per_second`, compare `serde_json::Value` equal; also `--jobs 1` vs `--jobs 3` equal; summary.csv equal after dropping the last two columns) + e2e python check in check-entrypoints |

## Ordered steps

1. **Shared CLI I/O helpers**: create `crates/evosim-cli/src/io.rs` with `check_out_path`, `write_atomic` (moved from
   `run.rs`, unchanged behaviour), `pub(crate)`; `run.rs` uses them. Add `pub mod io;` (or `mod io;`) in `lib.rs`.
2. **Core module `crates/evosim-core/src/batch/mod.rs`** (+ `tests.rs`), `pub mod batch;` in `lib.rs`:
   - `pub struct Sweep { pub key: String, pub values: Vec<Value> }`
   - `pub fn parse_seeds(s: &str) -> Result<Vec<u64>, String>` (comma list, non-negative u64, non-empty, no duplicates,
     no empty tokens).
   - `pub fn parse_param(s: &str) -> Result<Sweep, String>` (`KEY=V1,V2`; key non-empty, not `seed`/`name`/`description`,
     each token `serde_json::from_str`, must be number/bool/string (no arrays/objects/null), no duplicate values, ≥1 value).
   - `pub fn set_dotted(doc: &mut Value, key: &str, v: Value) -> Result<(), String>` (creates intermediate objects; error
     if an intermediate is a non-object).
   - `pub struct Combo { pub index: usize, pub params: Vec<(String, Value)> }`;
     `pub fn combos(sweeps: &[Sweep]) -> Vec<Combo>` (cartesian, first sweep slowest; empty sweeps → one combo, no params).
   - `pub struct RunSpec { pub index, pub combo, pub seed, pub config: Config, pub file: String }`;
     `pub fn expand(base: &Value, sweeps: &[Sweep], seeds: &[u64]) -> Result<Vec<RunSpec>, String>` — duplicate sweep keys
     → error; >10,000 runs → error; per combo: clone base, `set_dotted` each param, `Config::from_value` (error message
     `--param KEY=VALUE: <ConfigError>`), then `with_seed(seed)` per seed; file `seed-<s>.json` or `combo-<c>/seed-<s>.json`.
   - `pub struct RunOutcome` extracted from a result `Value` (`RunOutcome::from_result(&RunSpec, &Value)`): seed, ticks,
     final counts/species, births/deaths, extinction_tick, state_hash, elapsed, tps.
   - `pub struct BatchMeta { config_file, ticks, sample_every, seeds, sweeps, wall_seconds, jobs }`
   - `pub fn summary_json(meta, combos, outcomes) -> Value` per ADR-024 §5 (sums in index order; sd population;
     median = mean of the two middle values for even n; extinction_tick stats null when no extinct run).
   - `pub fn summary_csv(...) -> String`, `pub fn aggregates_csv(...) -> String`, private `csv_field` (RFC 4180 quoting).
   - Constant list `pub const TIME_KEYS` / doc comment naming the time-measurement locations.
3. **CLI `crates/evosim-cli/src/batch.rs`**: `parse_batch_args` (flags `--config --seeds --ticks --out-dir` required,
   `--param` repeatable, `--sample-every` ≥1, `--jobs` ≥1, each non-repeatable flag at most once, `--help` → usage exit 0,
   unknown/positional → error), `batch_command(rest, out, err) -> u8`:
   load config file as raw `Value` (read + `serde_json::from_str`; first validate the unmodified file with
   `load_config_file` so errors match `run`), `expand`, `Simulation::new` for every spec (validation-first), out-dir
   check (exists as non-dir → exit 2; else `create_dir_all`, plus combo sub-dirs), then worker threads
   (`std::thread::scope`, `AtomicUsize` next index, each worker: `Simulation::new`, `Instant`, `report::run_recorded`,
   `result_json`, `to_string_pretty`) into `Vec<Option<(Value, String)>>` via `Mutex` or per-thread vecs merged by index;
   then write all per-seed files, `summary.json` (pretty), `summary.csv`, `aggregates.csv` atomically; stderr one line per
   run + total line; stdout empty. Write failure → exit 2 with message.
   Wire `"batch" => batch::batch_command(...)` in `lib.rs::dispatch`; update `usage()` batch section (full syntax,
   `--param`, `--jobs`, files written, link to docs/BATCH.md).
4. **Tests**
   - core `batch/tests.rs`: parse_seeds ok/errors (`""`, `1,,2`, `-1`, `x`, `1,1`); parse_param ok/errors (`k`, `=1`,
     `k=`, `seed=1,2`, `k=[1]`, `k=1,1`); set_dotted nested/create/error; `expand_2x2_order` (indices, files, effective
     config values via `cfg.plants.growth_rate`, seeds); expand errors (unknown key, out-of-range value naming key,
     duplicate key, >10,000); `aggregates_on_synthetic_outcomes`; `csv_quoting`; `summary_without_time_is_deterministic`
     (two small real batches via `report::run_recorded` → equal after stripping).
   - CLI unit tests in `batch.rs` for argument parsing.
   - CLI integration (`crates/evosim-cli/tests/cli.rs`), small world (e.g. 24×16, 60/20/4, 40 ticks):
     `batch_plain_seeds` (files seed-1/2/3.json, each equals `evosim run --seed s` result in final/totals/series/state_hash,
     summary runs = 3, `sweep` = []), `batch_sweep_2x2` (4 files under combo-0/1, params in runs, recompute
     mean/min/max/extinct counts from files and compare, CSV row counts/columns), `batch_reproducible` (twice + `--jobs 1`
     vs `--jobs 3`), `batch_errors_exit_2` (missing `--seeds`, `--seeds 1,1`, `--param nope.key=1,2`,
     `--param plants.growth_rate=-5`, `--param seed=1,2`, `--jobs 0`, unreadable config, out-dir is a file → exit 2,
     stderr non-empty, out-dir not created / no summary.json).
   - `scripts/check-entrypoints.sh`: e2e block: contract example config, `./evosim batch --seeds 1,2,3 --ticks 50
     --out-dir $T/b1` and again into `$T/b2` with `--jobs 1`; check seed-1..3.json + summary.json + summary.csv exist,
     python3 strips time keys and compares summaries, check a sweep `--param plants.growth_rate=0.8,1.2 --seeds 1,2`
     gives 4 runs. Keep ticks small (each check < 5 s).
5. **Docs**: new `docs/BATCH.md` (command, sweep syntax, file layout, summary.json schema, CSV columns, time keys,
   reproducibility); README demo/usage section for batch; ARCHITECTURE `batch` row (implemented, placement per ADR-024 §7);
   ADR README row ADR-024 (already added by PLAN); STATE.md status + test commands.
6. Run `./test.sh` and `cargo clippy --release --workspace --all-targets`; record exact results in the implement handoff.

## Notes / pitfalls
- Validate the unmodified config file first (`load_config_file`) so plain-batch errors are identical to `run`.
- `Config::from_value` rejects unknown keys → covers unknown `--param` keys. Check that a numeric value for an integer key
  given as `3.0` errors cleanly (it's the config parser's behaviour; just document).
- Do not add keys to per-seed files (keep them identical to `run` output).
- Float formatting: serde_json prints f64 deterministically; keep sums in index order.
- No timing values outside `timing`/`runs[].elapsed_seconds`/`runs[].ticks_per_second`.
- No system dependencies needed.

# TASK-020 PLAN cycle 1 — metrics and evolution analytics

Design: [ADR-023](../../../docs/decisions/ADR-023-metrics-analytics.md). Builds on ADR-022 (`report::run_recorded`,
`result_json`, CLI `run.rs`).
Out of scope: charts (TASK-025), multi-run comparison / batch (TASK-021), `--save/--load` (TASK-022).

## Facts found while planning
- `report::run_recorded(sim, ticks, k)` (crates/evosim-core/src/report/mod.rs) samples `series` at tick_start, every K,
  tick_end — reuse these exact ticks for metrics.
- `LifeTotals { initial, births, deaths, deaths_by_cause: [[u64; 6]; 3] }` is cumulative since tick 0 and updated
  immediately in `Population::kill` (deaths) and `resolve_births` (births) → interval values = difference of two copies.
  `LifeTotals` is `Copy`.
- `DeathCause::ALL` (6 causes) + `name()`; `Kind::ALL`, `Kind::index()`; `report::KIND_KEYS`.
- `Traits` has 11 fields (organism/traits.rs): speed, strength, fertility, max_health, max_lifespan (u32), max_energy,
  vision, aggression, caution, temp_optimum, temp_tolerance.
- `Organism::{traits, generation, energy, age, is_alive}`; `Population::alive(kind)` iterates living organisms in
  EntityId order; `count_alive` excludes flagged-dead organisms.
- `SpeciesRegistry::{living_count(kind), of_kind(kind), SpeciesRecord::is_extinct}`.
- `Population::validate` (used by `Simulation::set_population`) requires `traits == express(genome)` → a hand world with
  chosen trait values cannot go through `set_population`; test on a standalone `Population` instead (see step 2/5).
- Test helpers already exist: `Organism::set_age_for_test` (cfg(test)), `Population::totals_mut_for_test`,
  `species_mut_for_test`; `Organism::set_energy` is pub.
- Core source scan (`sim::tests::core_source_has_no_wall_clock_or_global_rng`) forbids hashed-collection and wall-clock
  tokens in every core file: use `serde_json::Map` / Vec / arrays only.
- CLI `run.rs` has `parse_run_args`, `check_out_path`, `write_atomic` (temp + rename), usage string; integration tests in
  `crates/evosim-cli/tests/cli.rs`; e2e in `scripts/check-entrypoints.sh` (TASK-019 block, ~line 91).

## Ordered work list
1. **`crates/evosim-core/src/report/mod.rs`**: add
   `pub fn run_observed<F: FnMut(&Simulation)>(sim: &mut Simulation, ticks: u64, sample_every: u64, mut on_sample: F) -> RunRecord`
   — identical loop to today's `run_recorded`, calling `on_sample(sim)` right after each `series.push` (tick_start
   included, tick_end exactly once). `run_recorded` = `run_observed(sim, ticks, k, |_| {})`. Existing report tests must
   pass unchanged.
2. **`crates/evosim-core/src/metrics/mod.rs`** (new, `pub mod metrics;` in lib.rs + module doc line):
   - `pub const TRAIT_NAMES: [&str; 11]` in Traits field order; `pub fn trait_values(t: &Traits) -> [f64; 11]`
     destructuring `Traits` exhaustively (`let Traits { speed, strength, … } = *t;`, no `..`).
   - `#[derive(Debug, Clone, Copy, PartialEq)] pub struct Stat { mean, sd, min, max: f64 }`;
     `pub fn Stat::of(values: &[f64]) -> Option<Stat>` (None if empty; two-pass mean / population sd).
   - `#[derive(Debug, Clone, PartialEq)] pub struct KindSample { count: u64, births: u64, deaths: u64, births_total: u64,
     deaths_total: u64, deaths_by_cause: [u64; 6], deaths_by_cause_total: [u64; 6], species_living: u64,
     species_appeared: u64, species_extinct: u64, generation_max: Option<u32>, generation_mean: Option<f64>,
     traits: [Option<Stat>; 11], energy: Option<Stat>, age: Option<Stat> }`.
   - `pub struct Sample { tick: u64, kinds: [KindSample; 3] }`.
   - `pub struct MetricsRecorder { samples: Vec<Sample>, prev: Option<LifeTotals> }` with `new()`,
     `record(&mut self, sim: &Simulation)` → `record_population(sim.tick(), sim.organisms())`,
     `pub fn record_population(&mut self, tick: u64, pop: &Population)` (interval = totals − prev, 0 at first sample;
     then `prev = Some(*pop.totals())`), `samples()`, and
     `to_json(&self, seed: u64, rec: &RunRecord) -> serde_json::Value` producing the ADR-023 §4 document (statistics
     with count 0 → `null`; `deaths_by_cause*` objects list all 6 causes).
   - Per-sample cost: one pass per kind collecting values into reusable Vecs.
3. **`crates/evosim-core/src/organism/mod.rs`**: add `#[cfg(test)] pub(crate) fn set_traits_for_test(&mut self, t: Traits)`
   and `set_generation_for_test(&mut self, g: u32)` (test only; no production behaviour change).
4. **`crates/evosim-cli/src/run.rs`**: new optional `--metrics FILE` (at most once, non-empty). Before the loop: same checks as
   `--out` via `check_out_path` (adapt message to the flag name), reject `--metrics` == `--out` (compare the strings and,
   if both exist, canonicalised paths) → exit 2. Run with `run_observed` + `MetricsRecorder::record`. After the loop:
   write the result first, then the metrics file, both atomically; if the metrics write fails remove the result file
   again and exit 2 (no partial output). Without `--metrics` behaviour and output are byte-for-byte the same as before
   (except timing). Update the usage line and `--help`.
5. **Tests — core `crates/evosim-core/src/metrics/tests.rs`**:
   a. `Stat::of`: `[1,2,3]` → mean 2, sd √(2/3)≈0.816497, min 1, max 3; `[5]` → sd 0; `[]` → None;
      `[2,4,4,4,5,5,7,9]` → mean 5, sd 2 (classic hand example).
   b. **Hand world**: `Population::founders(&Config::new(seed, 4, 4, 3, 2, 1), &torus, &mut IdAllocator)` (own allocator;
      check `ids` API), then via `get_alive_mut` + test helpers set herbivore A: speed 1, generation 0, energy 10, age 4;
      herbivore B: speed 3, generation 2, energy 30, age 6 (other traits read back are not needed — assert speed, energy,
      age, generation by hand: speed mean 2 sd 1 min 1 max 3; generation max 2 mean 1; energy mean 20 sd 10; age mean 5 sd 1).
      `record_population(0, &pop)` → counts [3,2,1], births/deaths 0, totals 0.
      Then `kill(plant1, Grazed, 1)`, `kill(carnivore, Starvation, 1)`, one plant birth via `request_birth` +
      `resolve_births(1, &mut ids)` (parent = a living plant, genome = copy) → `record_population(1, &pop)`:
      plants count 3, births 1, deaths 1, deaths_by_cause grazed 1; carnivores count 0 → all stats null,
      generation null, deaths starvation 1; herbivores unchanged with births/deaths 0.
      Then kill herbivore A with Predation at tick 2, `record_population(2)`: herbivores count 1, interval deaths 1
      (predation 1), deaths_total 1, speed mean 3 sd 0, generation max 2 mean 2; carnivore interval deaths 0 but
      deaths_total 1, deaths_by_cause_total starvation 1. Species `living` compared with hand reasoning about founders
      (ADR-020: check whether founders form one species per kind; if founder classification makes the number
      seed-dependent, set a known registry via `species_mut_for_test` or assert `extinct_total` for carnivores = their
      species count and `living` 0 for carnivores — at least one hand-checked species number per sample).
   c. JSON: `to_json` shape — top-level keys, `samples[i].tick` = series ticks, kinds have all keys, 11 trait names,
      6 cause names, nulls for an empty kind, valid JSON numbers (all finite).
   d. **Hash independence**: two `Simulation`s same config (e.g. `Config::new(3, 16, 12, 40, 10, 3)`), 300 ticks, one with
      `run_observed` + recorder (K = 1, max sampling), one with `run_recorded` → equal `state_hash`, equal `RunRecord`.
   e. Sim invariants over a real run: for every sample `count == series count`, `births_total − deaths_total + initial ==
      count`, Σ interval births == births_total(last) − births_total(first), Σ causes == deaths, generation_max ≥ mean,
      every trait stat within the kind's `TraitRanges` (min ≥ lo, max ≤ hi), sd ≥ 0.
6. **Tests — CLI `crates/evosim-cli/tests/cli.rs`** (+ parse unit tests in run.rs):
   parse `--metrics m.json`; repeated `--metrics`, missing value, empty value → error. Integration: run with and
   without `--metrics` (same config/seed/ticks) → results equal after removing `elapsed_seconds`/`ticks_per_second`;
   metrics file has `format == "evosim-metrics"`, sample ticks == result series ticks, per-kind `count` == series
   counts, last sample `births_total`/`deaths_total` == result `totals`; `--metrics` into a missing directory, or equal
   to `--out` → exit 2, stderr, neither file exists.
7. **`scripts/check-entrypoints.sh`**: add to the TASK-019 block one `./evosim run ... --metrics` call (same seed as
   run-a) and a python check: `state_hash` equal to run-a, metrics file valid with matching ticks/counts.
8. **Docs**: new `docs/METRICS.md` (format reference: every key, units, interval vs total semantics, null rule, sd
   definition, example command, sample of the file); README run section: `--metrics FILE` + link; ARCHITECTURE metrics
   row (implemented, files) and report row (`run_observed`); STATE status line + TASK-020 notes; ADR-023 "IMPLEMENT notes"
   section for any deviation.
9. Run `./test.sh` (full suite incl. check-entrypoints) and `cargo clippy --workspace --all-targets -- -D warnings`
   (check exact clippy command used in test.sh/STATE); measure `./evosim run` contract example 1000 ticks with and without
   `--metrics` (record both times in the implement handoff).

## Acceptance mapping
| Must have | Shown by |
|---|---|
| All quantities at every sample tick | metrics::tests (b, c, e); CLI integration (ticks == series ticks) |
| Recording does not influence `state_hash` | metrics::tests d; CLI integration with/without `--metrics`; check-entrypoints |
| Written to file from command line, documented option | `--metrics FILE` in run.rs, README, docs/METRICS.md; CLI tests |
| Format documented | docs/METRICS.md + ADR-023 §4 |
| Hand-verifiable small world | metrics::tests a, b |

## Risks
- Founder species classification may make "living species" not trivially hand-computable — handled in 5b.
- `Organism::new` is pub(crate); hand world uses founders + cfg(test) setters instead of constructing organisms.
- Removing the result file on a failed metrics write must not leave a temp file (reuse `write_atomic`).
- Keep forbidden tokens out of new core files (source scan test).

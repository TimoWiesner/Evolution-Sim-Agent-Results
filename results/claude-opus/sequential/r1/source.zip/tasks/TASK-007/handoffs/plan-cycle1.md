# TASK-007 PLAN cycle 1 — Seasons and weather

Design record (binding): `docs/decisions/ADR-010-seasons-weather.md` (formulas, bounds, state). std + serde_json only, no new crates, Cargo.lock unchanged. Out of scope: effects on plants/animals.

## Ordered implementation steps

1. **Config key** — `crates/evosim-core/src/config/params.rs`, `ClimateParams`, append:
   `weather_scale: u32 = 16, "Feature size of the weather anomaly lattice in cells", [1, 4096];`
   Optionally sharpen docs of existing keys (`seasonal_amplitude` → "Seasonal temperature amplitude at the pole (deg C); scaled by 0.1+0.9·sin(latitude)", `weather_precipitation_sd` → "... relative to max_precipitation", `weather_temperature_sd` → "Stationary SD of the weather temperature anomaly (deg C)"). Regenerate the table in `docs/CONFIG.md` with `./evosim config schema` (test `config_doc_table_is_current`). Presets unchanged.

2. **`climate/noise.rs`** — make the lattice reusable for weather:
   - `PeriodicNoise::zeros(width, height, scale) -> PeriodicNoise`
   - `pub fn values(&self) -> &[f64]`, `pub fn values_mut(&mut self) -> &mut [f64]`, `pub fn from_values(width, height, scale, v: Vec<f64>) -> Option<PeriodicNoise>` (None on length mismatch). `new` unchanged (same draws, TASK-006 tests unchanged).

3. **New `climate/season.rs`** (pure, no RNG):
   ```rust
   pub fn year_phase(tick: u64, year_length: u32) -> f64; // sin(2π·(tick % Y)/Y), Y>=1; computed from integer remainder
   pub fn temperature_weight(lat_deg: f64) -> f64;        // 0.1 + 0.9·sin φ
   pub fn precipitation_weight(lat_deg: f64) -> f64;      // 0.25 + 0.75·exp(−((φ−20)/15)²)
   #[derive(Debug, Clone, Copy, PartialEq)]
   pub struct CellNow { pub temperature: f64, pub precipitation: f64 }
   #[derive(Debug, Clone, Copy, PartialEq)]
   pub struct ClimateBounds { pub t_min: f64, pub t_max: f64, pub p_min: f64, pub p_max: f64 }
   impl ClimateBounds { pub fn from_params(p: &ClimateParams) -> Self; pub fn contains(&self, c: CellNow) -> bool }
   /// The one formula (used by grid recompute and ClimateMap::seasonal):
   pub fn combine(p: &ClimateParams, bounds: &ClimateBounds, base: &CellClimate, s: f64, a_t: f64, a_p: f64) -> CellNow;
   ```
   `combine`: T = clamp(base.T + A_s·w_T(base.latitude)·s + a_t, t_min, t_max); r_base = if P_max>0 {base.P/P_max} else {0}; P = P_max·clamp(r_base·(1 + c·w_P·s) + a_p, 0, 1). Bounds per ADR-010 (`t_min = pole − noise_temperature − seasonal_amplitude − 3·weather_temperature_sd`, `t_max = equator + ...`; p ∈ [0, max_precipitation]). Note: use `weather_*_sd` in bounds regardless of `weather_enabled` (bounds documented per config).
   Add `ClimateMap::seasonal(&self, c: Cell, tick: u64) -> CellNow` (= combine with a_t = a_p = 0) and `ClimateMap::bounds()`.

4. **New `climate/weather.rs`**:
   ```rust
   #[derive(Debug, Clone, PartialEq)]
   pub struct WeatherState { pub temperature: Vec<f64>, pub precipitation: Vec<f64> } // lattice values, row-major
   #[derive(Debug, Clone, PartialEq)]
   pub struct Weather { t: PeriodicNoise, p: PeriodicNoise }
   impl Weather {
     pub fn new(width, height, params) -> Weather;            // zeros, lattice via weather_scale
     pub fn lattice(&self) -> (u32, u32);
     pub fn advance(&mut self, params: &ClimateParams, rng: &mut Rng); // if !weather_enabled: return (no draws). else per node of t (row-major) then p: a = clamp(ρa + sqrt(1−ρ²)·σ·rng.normal(0.0,1.0), −3σ, 3σ)
     pub fn anomaly(&self, x: f64, y: f64, w, h) -> (f64, f64); // at_cell samples
     pub fn state(&self) -> WeatherState;
     pub fn restore(&mut self, s: WeatherState) -> Result<(), WeatherError>; // lengths must match, all finite
   }
   ```
   `WeatherError` (Display) → wrap as `SimError::Weather(String)` or a new variant.

5. **World** (`sim/world.rs`): fields `weather: Weather`, `now: Vec<CellNow>`, `climate_tick: u64`. `from_config` builds zero weather and fills `now` for tick 0. Methods:
   - `pub fn update_climate(&mut self, tick: u64, rng: &mut Rng, params)`: `weather.advance`, then `recompute_now(tick)`.
   - `fn recompute_now(&mut self, tick)`: one `s = year_phase(tick, Y)`; for each cell (row-major) `combine(base, s, anomaly)`; set `climate_tick = tick`.
   - Queries: `current(&self, c: Cell) -> CellNow`, `current_grid(&self) -> &[CellNow]`, `climate_tick()`, `weather() -> &Weather`.
   - `pub(crate) fn restore_weather(&mut self, s, tick)`.
   Keep the hot loop allocation-free (reuse `now`).

6. **Scheduler** (`sim/mod.rs`): `Phase::Climate => ctx.world.update_climate(ctx.tick, ctx.rng, &ctx.config.climate)`. Add `Simulation::climate_now(cell) -> CellNow`, `weather_state() -> WeatherState`, `set_weather_state(WeatherState) -> Result<(), SimError>` (recompute grid for `self.tick.saturating_sub(1)`). Doc comment on `resume`: weather is restored separately via `set_weather_state` until TASK-022 snapshots. Do not change `Phase::ORDER`.

7. **CLI** (`crates/evosim-cli/src/lib.rs`): `evosim climate series --x X --y Y [--ticks N (default = year_length)] [--every K (default 1)] [--config FILE | --preset NAME] [--seed N] [--width W --height H] [--no-weather]` → stdout JSON `{"cell":{"x","y"},"year_length","weather":bool,"bounds":{"t_min","t_max","p_min","p_max"},"series":[{"tick","temperature","precipitation"}]}`; row for tick t taken after `step()` of tick t (grid describes t). x/y outside world → exit 2. Reuse the `climate map` option parser where possible. Usage text updated. Unit + integration tests (exit 0 parse JSON; same seed twice identical; different seeds differ with weather; `--no-weather` with `--ticks 2Y` → second year equals first; bad x → exit 2). Optional entry-point check line in `scripts/check-entrypoints.sh`.

8. **Docs** — docs/CLIMATE.md new section "Seasons and weather (TASK-007)": formulas, zone differences table (equator/30°/60°/pole amplitudes for defaults), why both hemispheres share the season (seam), weather model, bounds formula + default values, query API, `evosim climate series` example, state note. ARCHITECTURE climate row + ADR index (README) entry ADR-010 (already added in PLAN), STATE.md.

## Tests (core: `climate/tests.rs` or new `climate/season_tests.rs`; sim: `sim/tests.rs`) — mapping to Must-have
| Must-have | Test(s) |
|---|---|
| configurable year; every cell follows seasonal cycle | `season_period_is_year_length` (Y ∈ {1, 2, 7, 400, 1000}: `seasonal(c,t) == seasonal(c,t+Y)` bitwise for sample cells/ticks); `every_cell_has_seasonal_cycle` (64×48 defaults, weather off: for every cell T(midsummer k=Y/4) > T(midwinter k=3Y/4) and P_summer ≥ P_winter, strict where r_base>0); `seasonal_amplitude_grows_with_latitude` (pole swing > equator swing; equals 2·A_s·w_T); `year_length_from_config` (change key → period changes, e.g. Y=10 vs 20 differ at t=5) |
| weather from sim RNG, same seed same weather | `weather_same_seed_identical` (two `Simulation`s seed 42, 300 ticks: `current_grid()` bitwise equal every tick, rng_state equal); `weather_different_seed_differs`; `weather_draws_from_core_rng` (one tick with weather on advances `rng_state` exactly by 2·gx·gy normals = 4·gx·gy `next_u64` of a reference `Rng::seed_from_u64(seed)`; weather off → rng_state unchanged after step); `weather_actually_varies` (weather on: grid at tick t ≠ seasonal(t) for some cell; anomaly autocorrelation >0 over 500 ticks — loose check) |
| documented bounds | `bounds_formula_defaults` (defaults → [−40.5, 43.5], [0,1]); `values_stay_within_bounds` (presets default/lush/harsh/plants-only + extreme config: seasonal_amplitude 40, sd 20/2, persistence 0 and 0.999, noise max, sizes 1×1, 3×1, 64×48, 5000 ticks harsh / 2000 others: every cell every tick within bounds, finite); unit test `combine_clamps` |
| query any cell any tick | `query_current_matches_formula` (after each step t: `climate_now(c)` == combine(base, s(t), weather anomaly) and `climate_tick()==t`; before any step == `seasonal(c,0)`); `seasonal_query_any_tick` (`ClimateMap::seasonal` for t = 0, Y/4, u64::MAX-ish works); CLI `climate series` test |
| weather off: one year repeats exactly | `weather_off_year_repeats_exactly` (weather_enabled=false, Y ∈ {1, 13, 400}, run 3Y ticks via `Simulation::step`: grid at tick t == grid at t+Y bitwise (`to_bits`) for all t in year 1..2, and RNG state unchanged); recorded command `./evosim climate series --x 3 --y 2 --no-weather --ticks 800` |
| weather state is sim state | `resume_with_weather_state_continues_identically` (run A 137 ticks; B = `Simulation::resume(cfg, tick, rng, next_id)` + `set_weather_state(A.weather_state())`; then 200 more ticks each: grids and rng bitwise equal); `resume_without_weather_state_differs` (shows state matters); `set_weather_state_rejects_bad` (wrong length / NaN → Err); `weather_state_only_carryover` doc/test: after restoring, `climate_now` equals A's immediately |
| seam continuity kept | `seasonal_seam_continuous` (weather off and on, several ticks: seam-pair max |ΔT|,|ΔP| ≤ interior max + small tolerance like TASK-006, plus Lipschitz-style check that weather lattice wraps: `Weather` sample periodic) |
| determinism hygiene | existing `core_source_has_no_wall_clock_or_global_rng` must pass (don't write banned tokens); existing sim/climate tests unchanged and passing |

## Commands for IMPLEMENT
- `cargo test -p evosim-core --release --locked climate` / `sim`
- `./test.sh` (full; runs setup/build)
- `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`
- `./evosim climate series --x 0 --y 0 --ticks 800 --no-weather` (inspect: entries t and t+400 identical)

## Risks
- RNG stream shift: phases after Climate now see a different RNG stream when weather is on; existing tests compare runs, not golden post-step states — verify `sim::tests` still pass; if a golden post-step RNG test exists, update only with explanation.
- Off-by-one in "current tick": the grid describes the tick whose Climate phase ran last (`climate_tick`); document clearly, test with `climate_tick()`.
- Performance for huge worlds: O(w·h) recompute per tick (~0.5 M cells at 1024×512, a few ms) — acceptable; could switch to lazy rows later.
- Weather sampled at lattice resolution: if `weather_scale` > world size the lattice is 1×1 → spatially uniform weather (documented).
- Bounds include 3σ even when weather disabled (conservative, documented).

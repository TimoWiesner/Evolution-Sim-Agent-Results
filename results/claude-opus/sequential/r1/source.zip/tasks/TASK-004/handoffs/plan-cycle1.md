# TASK-004 PLAN cycle 1 — Grid coordinates and toroidal topology

Design record: `docs/decisions/ADR-007-topology.md` (read first; it is binding for the API below).

## Ordered implementation steps
1. **Module files** (std only, no new crates, Cargo.lock unchanged):
   - `crates/evosim-core/src/topology/mod.rs` — types + `Torus` impl, docs.
   - `crates/evosim-core/src/topology/tests.rs` — `#[cfg(test)] mod tests;`.
   - `crates/evosim-core/src/lib.rs` — add `pub mod topology;` (update crate doc comment).
2. **Types**
   ```rust
   pub const MAX_DIM: u32 = 1 << 20;
   #[derive(Debug, Clone, Copy, PartialEq, Eq)] pub enum TopologyError { ZeroDimension{axis:&'static str}, TooLarge{axis:&'static str, value:u32} } // + Display, std::error::Error
   #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)] pub struct Cell { pub x: u32, pub y: u32 }  // impl Ord manually: (y, x)
   #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)] pub struct Offset { pub dx: i32, pub dy: i32 }
   impl Offset { pub const ZERO; pub fn new(dx,dy); pub fn chebyshev(self)->u32; pub fn is_zero(self)->bool; pub fn signum(self)->Offset; }
   #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)] pub enum Dir8 { N, NE, E, SE, S, SW, W, NW }
   impl Dir8 { pub const ALL: [Dir8; 8]; pub fn offset(self)->Offset; pub fn from_offset(o: Offset)->Option<Dir8> /* uses signum */; }
   // Convention: x east, y south (N = dy -1).
   #[derive(Debug, Clone, Copy, PartialEq, Eq)] pub struct Torus { width: u32, height: u32 }
   ```
3. **`Torus` methods**
   - `new(width, height) -> Result<Self, TopologyError>`; `width()`, `height()`, `cell_count() -> usize`.
   - `wrap_coord(v: i64, n: u32) -> u32` (free fn or assoc): `v.rem_euclid(n as i64) as u32`.
   - `wrap(x: i64, y: i64) -> Cell`; `contains(Cell) -> bool`; `index(Cell) -> usize` (= y*W + x, debug_assert contains); `cell_at(index) -> Cell`.
   - `translate(c, Offset) -> Cell` (via i64), `step(c, Dir8) -> Cell`.
   - `axis_delta(a: u32, b: u32, n: u32) -> i32`: `d = (b as i64 - a as i64).rem_euclid(n)`; `if d > n/2 { d - n } else { d }`.
   - `offset(a, b) -> Offset`, `distance(a, b) -> u32` (Chebyshev), `direction(a, b) -> Option<Dir8>`, `max_distance() -> u32`.
   - `axis_offsets(r: u32, n: u32) -> RangeInclusive<i32>`: if `2*(r as u64)+1 >= n as u64` → `-( (n-1)/2 ) ..= n/2`, else `-r ..= r` (use u64 to avoid overflow for r = u32::MAX).
   - `within(center, r) -> WithinIter` yielding `(Cell, Offset)`: outer dy, inner dx over the axis ranges; `cells_within(center, r) -> Vec<Cell>`; `count_within(r) -> usize`.
   - `ring(center, d) -> impl Iterator<Item=(Cell, Offset)>`: `within(center,d).filter(|(_,o)| o.chebyshev()==d)` (simple; TASK-010 may optimise).
   - `neighbours8(c) -> impl Iterator<Item=(Cell, Dir8)>` or Vec: `within(c,1)` minus zero offset, mapped to Dir8.
4. **Docs**: module rustdoc states metric, tie rule, axis convention; ARCHITECTURE/STATE already point to ADR-007 — update STATE test counts after implement.

## Tests (`topology/tests.rs`) — map to acceptance criteria
- AC1 wrap: `wrap(-1,-1)` = (W-1,H-1); `wrap(W,H)`=(0,0); `wrap(-k*W + 3, k*H + 2)` for k in 1..=5 → (3,2); `wrap(i64::MIN, i64::MAX)` in range; property loop (splitmix/LCG in test, fixed seed, 10 000 samples, worlds incl. 1×1, 1×N, 7×3) → result `contains` and congruent mod n; `translate` by ±k·W returns same cell.
- AC2 distance/direction: all four edges (x=0↔x=W-1 distance 1, direction W/E across seam; y=0↔y=H-1 N/S), all four corners pairwise distance 1 on worlds ≥3×3 (e.g. (0,0)↔(W-1,H-1) offset (-1,-1), direction NW), interior pair not wrapping (offset (3,0) on 10×10 not (-7,0)), tie rule on even width (offset (5,0) on width 10 from both... a→b gives +5, b→a gives +5 — document), symmetry `distance(a,b)==distance(b,a)`, `wrap(a+offset(a,b)) == b` exhaustive on small worlds, non-square (10×4) independent axes.
- AC3 within: exhaustive oracle: worlds 1..=7 × 1..=7 (plus 1×12, 12×1, 16×9), every centre, r in 0..=10 → set equal to brute force `{c | distance(center,c) <= r}`, no duplicates (BTreeSet size == iter len), `len == count_within(r)`, every offset's `chebyshev()` == `distance(center, cell)`; `r = u32::MAX` returns each cell once; ring partitions within (union over d=0..=r of rings == within, disjoint).
- AC4 small/non-square: `Torus::new(0,5)` / `(5,0)` / `(MAX_DIM+1,1)` errors; 1×1: wrap anything → (0,0), distance 0, direction None, within(r) = 1 cell for any r, neighbours8 empty; 1×N: x always 0, distance = vertical only; N×1 likewise; 2×2 neighbours8 = 3 distinct cells.
- AC5: test names prefixed `edge_`, `corner_`, `negative_`, `multi_wrap_`, `world_1x1_` so review can grep.
- Dir8: `from_offset(d.offset()) == Some(d)` for ALL; `from_offset(ZERO) == None`; `step` round trip with opposite direction.

## Commands
- `cargo test -p evosim-core --release --locked topology` (via `source scripts/find-cargo.sh` if cargo not on PATH)
- Full: `./test.sh` must stay exit 0 (previous baseline: 30 Rust tests + 22 entry-point checks).

## Risks
- Tie rule at n/2 for even dimensions makes `offset(a,b) != -offset(b,a)`; documented, distance still symmetric. Tests must assert this explicitly rather than assume antisymmetry.
- Overflow in `2r+1` or `i64` conversions — use u64/i64 arithmetic; MAX_DIM bound.
- Exhaustive oracle cost: 49 worlds × ≤49 centres × 11 radii × ≤49 cells ≈ 1.3 M checks — trivial in release.

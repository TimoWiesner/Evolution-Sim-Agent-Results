# TASK-008 PLAN cycle 1 — Organisms and life cycle

Binding design: `docs/decisions/ADR-011-organisms-life-cycle.md` (kinds, fields, trait ranges, storage, founders, death sweep, THE same-tick rule). std only, no new crates, Cargo.lock unchanged, no new config keys.

## Ordered implementation steps
1. **`crates/evosim-core/src/organism/kind.rs`** — `#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] pub enum Kind { Plant, Herbivore, Carnivore }`; `Kind::ALL: [Kind; 3]`, `index() -> usize`, `name() -> &'static str` (`plants|herbivores|carnivores`), `is_animal()`.
2. **`organism/traits.rs`** —
   ```rust
   #[derive(Debug, Clone, Copy, PartialEq)] pub struct Traits { pub speed: f64, pub strength: f64, pub fertility: f64,
       pub max_health: f64, pub max_lifespan: u32, pub max_energy: f64, pub vision: f64, pub aggression: f64, pub caution: f64 }
   #[derive(Debug, Clone, Copy, PartialEq)] pub struct Range { pub lo: f64, pub hi: f64 }
   pub struct TraitRanges { speed, strength, fertility, max_health, max_lifespan: (u32,u32), max_energy, vision, aggression, caution }
   impl TraitRanges { pub fn for_kind(kind: Kind) -> TraitRanges }   // table of ADR-011
   impl Traits {
       pub fn clamped(kind: Kind, raw: Traits) -> Traits;   // clamp each field; non-finite -> lo
       pub fn founder_default(kind: Kind, cfg: &Config) -> Traits; // ADR-011 default column, then clamped
       pub fn in_range(&self, kind: Kind) -> bool;
   }
   ```
   Fields are pub for reading; documented that values must come through `clamped` (Organism stores only clamped traits; `Organism::traits()` read-only, no `traits_mut`).
3. **`organism/mod.rs`** — `Organism` (fields of ADR-011, private `energy`, `health`, `alive`, `age`; getters `id() kind() pos() age() energy() health() traits() parents() generation() birth_tick() is_alive()`; `set_pos(Cell)`; energy/health mutators clamped as in ADR-011, return the actually applied amount). `#[derive(Debug, Clone, Copy, PartialEq, Eq)] pub enum Parents { None, One(EntityId), Two(EntityId, EntityId) }` + `ids() -> impl Iterator` / `as_slice`-like helper. `#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)] #[non_exhaustive] pub enum DeathCause { OldAge, Starvation, Injury, Predation, Grazed, Climate }` + `ALL`, `COUNT`, `index`, `name`. `DeathRecord`, `BirthRecord { id, kind, parents, generation, pos, tick }`, `BirthRequest { kind, pos, parents, energy, health: Option<f64>, traits }`, `LifeTotals` (+ `living_expected(kind) = initial + births - deaths`). `pub const FOUNDER_SEED_TAG: u64 = 0x0F0B_DE25_0000_0008;`
4. **`organism/population.rs`** — `#[derive(Debug, Clone, PartialEq)] pub struct Population` with:
   - `new()`, `founders(cfg: &Config, torus: &Torus, ids: &mut IdAllocator) -> Population` (ADR-011 founder rule, separate RNG `Rng::seed_from_u64(cfg.seed ^ FOUNDER_SEED_TAG)`, cell = `(below(w), below(h))` per organism, kinds in `Kind::ALL` order; sets `totals.initial`).
   - queries: `get(id)`, `get_mut(id)` (binary search in each kind Vec; include dead-flagged), `get_alive(id)`, `get_alive_mut(id)`, `is_alive(id)`, `alive(kind) -> impl Iterator<&Organism>`, `alive_ids(kind) -> Vec<EntityId>` (ascending), `count_alive(kind)`, `stored_len(kind)` (incl. flagged, for tests), `totals()`, `last_deaths()` / `last_births()` (records of the last processed tick).
   - `kill(id, cause, tick) -> bool` (ADR-011).
   - `request_birth(req)`; `pending_births() -> usize`.
   - `resolve_births(tick, ids) -> Vec<BirthRecord>` (Births phase; parents alive check; generation; appends keep sort order — debug_assert ascending).
   - `end_of_tick(tick) -> Vec<DeathRecord>` (Deaths phase: aging skip for `birth_tick == tick && parents != None`, natural checks, records of the whole tick in flag order, `retain` removal).
   - `set_totals` / constructor for TASK-022 not required now; `Simulation::set_population(p)` validates max ID < `next_entity_id` (else `SimError::Population(String)`).
5. **`sim/event.rs`** — add `EventKind::Birth { id: EntityId, kind: Kind, parents: Parents, generation: u32 }` and `EventKind::Death { id: EntityId, kind: Kind, cause: DeathCause, age: u32 }`.
6. **`sim/world.rs`** — `World` gains `organisms: Population`; `World::from_config` takes `ids: &mut IdAllocator` (or `Simulation::new` builds founders after world) — keep `World::from_config(&Config)` signature for existing callers and add `World::with_founders(config, ids)` used by `Simulation::new`; `organisms()`, `organisms_mut()`.
7. **`sim/mod.rs`** — `Simulation::new`: world + founders (IDs 1..=N); `resume` also re-creates founders with a fresh `IdAllocator` then sets `ids = from_next(next_id.max(founder_next))` and documents that TASK-022 replaces the population via `set_population`; `organisms()`, `totals()`, `set_population()`. `run_phase`: `Births => { for r in ctx.world.organisms_mut().resolve_births(tick, ctx.ids) { ctx.emit(Birth..) } }` (collect first to avoid borrow conflict), `Deaths => { emit Death for each record of end_of_tick }`.
8. **`lib.rs`** — `pub mod organism;` + doc line.
9. **Existing test update** — `sim::tests::new_holds_config_world_rng` asserts `next_entity_id() == 1`; change to `1 + initial total` (rng assertion stays: founders use their own RNG). Note: `sim/tests.rs::cfg()` uses initial 0/0/0, so that test should pass unchanged; only adapt tests that use non-zero initial counts.
10. **Docs** — ARCHITECTURE `organism` row → implemented + ADR-011 + technology summary line; STATE TASK-008 notes (API, rule, test commands/results); ADR index already has ADR-011 (done in plan).

## Tests (in `organism/tests.rs` unless noted) — mapping to Must-haves
- **AC1 kinds**: `three_kinds_exist` (ALL, index, names, is_animal).
- **AC2 fields + unique never-reused IDs**: `organism_exposes_all_fields` (founder and newborn: id, kind, pos, age, energy, health, traits, parents, generation); `ids_unique_never_reused_under_random_ops` — 2 000 random ops (request_birth with random living parents, resolve, kill with random cause, end_of_tick) driven by `Rng::seed_from_u64(7)`, keep a `BTreeSet` of every ID ever seen, assert each new ID is fresh and > all previous, removed IDs never returned by `get`.
- **AC3 traits**: `trait_ranges_table_matches_adr` (exact values per kind); `clamped_forces_ranges` (random/extreme/NaN/±inf raw traits for each kind → `in_range`, plants speed/vision/aggression/caution = 0); `founder_defaults_in_range_for_all_presets` (every `preset_names()`); animals have aggression and caution in [0,1].
- **AC4a ranges**: `energy_health_never_leave_range` — property test, 10 000 random mutator calls with values from {−1e9, −1, 0, tiny, huge, NaN, ±inf, random} on random organisms, check `0 ≤ energy ≤ max_energy` and `0 ≤ health ≤ max_health` after every call, plus return values ≥ 0 and consistent with the change; same check after every tick of a hook-driven sim run (sim/tests.rs).
- **AC4b death**: `kill_flags_records_cause_and_hides` (is_alive false, get_alive None, not in alive_ids/count_alive, second kill false and totals unchanged, DeathRecord cause/tick/age correct); `dead_removed_at_deaths_phase` (stored_len drops, get None); sim test `dead_organism_never_acts_again` — hook in Herbivores phase kills a herbivore mid acting loop; hook records every actor processed via `acting_order(alive_ids)` + `get_alive` check over the next 50 ticks; the dead ID never appears and Death event carries the cause; `natural_deaths_sweep` (health 0 → Injury, energy 0 → Starvation, priority Injury > Starvation > OldAge, lifespan L founder dies in the Deaths phase of tick L−1 with age L).
- **AC5 counters**: sim test `totals_per_kind_since_tick_zero` — config with small lifespans and hook-driven births/kills in every acting phase for 200 ticks; totals equal number of Birth/Death events per kind summed over all reports; founders not counted as births; `living == initial + births − deaths` per kind after every tick and `totals` zero at tick 0.
- **AC6 same-tick rule** (sim tests, names prefixed `same_tick_`): `same_tick_parent_killed_before_births_drops_request` (kill parent in Carnivores after request in Herbivores → no ID allocated, births unchanged); `same_tick_parent_dies_of_old_age_still_has_child` (parent with age = lifespan−1 requests birth → child born, parent Death OldAge, same tick); `same_tick_newborn_with_zero_energy_born_and_dies` (Birth and Death events in same report, counted in both, newborn age 0, cause Starvation, invariant holds); `same_tick_newborn_does_not_age_or_act` (age 0 after tick; not in any acting order of its birth tick; ages to 1 next tick); `same_tick_births_ids_in_request_order` (IDs ascending in request order, Vec stays sorted); `same_tick_kill_after_flag_in_deaths_counts_once`.
- **Founders/determinism** (sim tests): `founders_from_config` (counts, IDs 1..=N plants→herbivores→carnivores, positions inside torus, gen 0, Parents::None, energy=initial_energy clamped, health=max_health); `founders_zero_initial_valid` (all zeros → empty, 1×1 world works); `founders_same_seed_identical_different_seed_differs`; `founders_do_not_consume_core_rng` (rng_state == seed_from_u64(seed).state()); `lifecycle_run_deterministic` (two sims same seed, plants.max_age small, 300 ticks → identical populations, totals, reports).
- Existing: `./test.sh` must stay green (core 106 before).

## Commands
- `source scripts/find-cargo.sh; evosim_find_cargo; cargo test -p evosim-core --release --locked organism` and `... sim`
- `cargo test -p evosim-core --locked` (debug: overflow + debug_asserts)
- `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`
- `./test.sh` (full; runs setup/build)

## Risks
- Founder placement ignores `plants.max_per_cell`; TASK-011/012/013 may need capacity-aware placement (then change only `Population::founders`, document in ADR-011).
- `Simulation::resume` without `set_population` re-creates founders (incomplete until TASK-022).
- Death-event emission in the Deaths phase reports kills that happened in earlier phases of the same tick (event `phase` = Deaths); DeathRecord.tick is exact. Acceptable.
- Traits are placeholders (founder defaults, max_health constants) until TASK-009 maps genes; defaults may be retuned in TASK-018/027.
- Energy of dropped birth requests is lost; reproduction tasks must account for it in their energy documentation.
- With no metabolism yet, organisms in a plain run only die of old age; that is expected until TASK-011+.

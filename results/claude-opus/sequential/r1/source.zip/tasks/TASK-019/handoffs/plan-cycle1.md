# TASK-019 PLAN cycle 1 — headless `evosim run`

Design: [ADR-022](../../../docs/decisions/ADR-022-headless-run-result-hash.md). Contract: docs/CONTRACT.md §2 (`run`), §4, §5.1/5.4/5.5.
Out of scope: `--save`/`--load` (TASK-022, rejected with exit 2 for now), `batch` (TASK-021).

## Facts found while planning
- `run` currently exits 2 "not implemented yet" (`crates/evosim-cli/src/lib.rs` dispatch, `"run" | "batch" | "ui"` arm).
- No hash code exists; core depends only on `serde_json` (ADR-005 mentions `sha2`, never added) → in-crate SHA-256.
- Core source scan (`sim::tests::core_source_has_no_wall_clock_or_global_rng`) forbids wall-clock and hashed-collection
  tokens in core: timing stays in the CLI; do not write the words of the forbidden list (see test) in new core files.
- Relevant API: `Simulation::{new, step, tick, config, world, rng_state, next_entity_id, organisms, totals, species,
  living_species}`, `Population::count_alive(kind)`, `Config::{with_seed, to_json_value}`, CLI `load_config_file`.
- Speed: contract example 10,000 ticks ≈ 67 s single-threaded (`./evosim ecology survival --seeds 1`), well under 300 s;
  hashing once at the end is negligible.
- State fields (to hash): `Simulation{config,tick,rng,world,ids}`; `World{torus,climate,bounds,weather,now,climate_tick,
  organisms,resources,plant_ledger,last_moves,herbivore_ledger,hunt_ledger,repro_ledger,stats}`;
  `Population{by_kind,pending,totals,tick_deaths,last_deaths,last_births,expression,index,capacity,births_dropped_full,
  species}`; `Organism{id,kind,pos,age,energy,health,traits,genome,parents,generation,birth_tick,alive,heading,stride,
  handling,cooldown,species}`; `SpeciesRegistry{records,thresholds,living_per_kind,journal}`; `SpeciesRecord{…}`;
  `CellResources{width,cap,values}`; `Weather{width,height,t,p}`; `Genome{kind,genes:Vec<f32>}`; `RngState{s}`.

## Ordered work list
1. **`crates/evosim-core/src/digest/sha256.rs`** — `Sha256::new/update/finalize -> [u8;32]`, `hex(&[u8]) -> String`.
   Tests: FIPS vectors "" → e3b0c442…b855, "abc" → ba7816bf…15ad, "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
   → 248d6a61…06c1, 10^6 × 'a' → cdc76e5c…c0f0 (full digests in the test), plus streaming = one-shot for split points 0..130.
2. **`crates/evosim-core/src/digest/mod.rs`** — `StateHasher` (ADR-022 §2 writers, `finish_hex()`); leaf module, no deps.
   Register `pub mod digest;` in `lib.rs` (+ module doc line).
3. **`hash_state` methods with exhaustive destructuring** (no `..`), each in the owning module:
   `rng::RngState`/`Rng` (via `state()`), `ids::IdAllocator`, `topology::{Cell, Dir8}`, `genome::Genome`,
   `organism::{Traits, Parents, Organism, BirthRequest, LifeTotals}`, `organism::Population`, `species::{SpeciesRecord,
   SpeciesRegistry}`, `plants::{CellResources, PlantLedger}`, `climate::{Weather, CellNow, PeriodicNoise values}`,
   `animals::{HerbivoreLedger, FeedTick, HuntLedger(+its last struct), ReproLedger}`, `sim::World`, `sim::Simulation`.
   Excluded fields bound as `_field` + reason comment (ADR-022 list). Verify for each excluded per-tick buffer that no rule
   reads it in a later tick (grep its accessors); if one is read, hash it.
4. **`Simulation::state_hash(&self) -> String`** in `sim/mod.rs` (stream order of ADR-022 §2).
5. **`crates/evosim-core/src/report/mod.rs`** — `SeriesPoint{tick, plants, herbivores, carnivores}`, `RunRecord{tick_start,
   tick_end, sample_every, series, extinction_tick:[Option<u64>;3]}`, `default_sample_every(n)`,
   `run_recorded(&mut Simulation, ticks, sample_every) -> RunRecord` (sample_every ≥ 1 asserted/clamped; loop exactly
   `ticks` times; never break early), `result_json(&Simulation, &RunRecord, elapsed_seconds) -> Value` (contract keys +
   extras `name, version, sample_every, totals.initial, totals.deaths_by_cause, extinction_tick, config`).
   Kind JSON names: `plants`, `herbivores`, `carnivores`. Death-cause names: reuse existing `DeathCause` name fn if
   present, else add `DeathCause::name()` (snake_case).
6. **`crates/evosim-cli/src/run.rs`** (new, `mod run;` in lib.rs) — `parse_run_args`, `run_command(rest, out, err) -> u8`
   per ADR-022 §4: validate all → `Simulation::new` → `Instant` around `run_recorded` only → `result_json` →
   write `<out>.tmp-<pid>` + `fs::rename`; stderr summary; stdout empty. Wire `"run"` in `dispatch` (keep `batch`/`ui` stub
   arm). Update `usage()` text (run synopsis without "not implemented"; mention `--save/--load` arrive with TASK-022).
7. **Core tests** `crates/evosim-core/src/digest/tests.rs` + `crates/evosim-core/src/report/tests.rs`:
   - hash: 64 lowercase hex; same config+seed after 50 ticks → equal; seeds 1 vs 2 → different; tick 0 vs after
     `step()` → different; a world with all counts 0 still changes hash per tick (clock);
   - sensitivity (start from a stepped sim, clone or rebuild identically, mutate one thing, hash must differ): organism
     energy +1 ULP (`f64::from_bits(b+1)`), position, one gene (f32 ULP), cooldown/heading, RNG state (`set_rng_state`),
     next id, one weather value (`set_weather_state`), one resource cell, a species record field, totals counter, config
     parameter. Add `#[cfg(test)] pub(crate)` mutators only where no API exists;
   - report: N=0 → tick_end=tick_start, series one point; N=250,K=100 → series ticks [0,100,200,250]; N=200,K=100 →
     [0,100,200] (no duplicate); default K: N=1000→10, N=50→1; extinct world (initial all 0, and plants 0) runs exactly N
     ticks; balance `initial+births-deaths=final` per kind in result JSON; `result_json` contains every contract key with
     the right JSON type; `extinction_tick` set when a kind hits 0.
8. **CLI tests** — unit tests in `run.rs` (arg matrix) and integration tests in `crates/evosim-cli/tests/cli.rs` (via
   `CARGO_BIN_EXE_evosim`, temp dirs): success writes valid JSON, stdout empty; `--seed` overrides config seed (result
   `seed`); same seed twice → identical `final/totals/series/state_hash`; different seed → different hash; `--ticks 0`;
   extinct world keeps ticking to exactly N; `DISPLAY` removed (`env_remove("DISPLAY")`, `WAYLAND_DISPLAY`) works;
   error matrix each giving exit 2 + non-empty stderr + no out file: no args, missing --config/--ticks/--out, unknown
   flag, stray positional, duplicate flag, `--ticks -1`/`abc`/`1.5`, `--seed -3`/`x`, `--sample-every 0`, missing config
   file, invalid JSON, wrong type (`"seed":"a"`), missing fixed key, out-of-range (`width: 0`, negative initial), unknown
   key, `--out` in a non-existing directory, `--save x`, `--load x`.
9. **`scripts/check-entrypoints.sh`** — add end-to-end checks with the real launcher `./evosim run` from the unrelated
   cwd: contract example config (write it to the temp dir), 300 ticks, seed 7 twice → python3 compares
   `final,totals,series,state_hash` equal; seed 8 → hash differs; `--ticks 0` works; bad flag → exit 2, stderr, no file;
   `env -u DISPLAY`; also `dist/evosim run` once (contract §6 requires `run` from dist).
10. **Docs**: README (status line, "Run headless" section with example call
    `./evosim run --config my.json --ticks 1000 --out result.json --seed 7` and key list), docs/ARCHITECTURE.md (new
    modules `digest`, `report`, CLI `run.rs`; snapshot row → hash now in `digest` + `Simulation::state_hash`),
    docs/STATE.md (status, API, test evidence), ADR README index row for ADR-022 (done in PLAN), ADR-005 note (done).
11. Run `./test.sh` (full suite incl. setup/build; ~ several minutes) and `cargo clippy --release --workspace --all-targets`;
    record commands and results in the implement handoff. Also record one real call:
    `./evosim run --config <contract example> --ticks 1000 --out /tmp/r.json` (elapsed, hash).

## Risks
- Exhaustive destructuring across many modules is the bulk of the work; nested types in ledgers may need several small
  impls. Keep each `hash_state` next to its type.
- Per-tick buffer exclusions could be challenged in review; ADR-022 states the rule and the IMPLEMENT check (step 3).
- Whatever is hashed must be restorable by TASK-022 (ledgers, `now`, weather included) — noted in ADR-022 consequences.
- Floats in `now`/weather/resources are hashed bitwise: fine on one machine/build (contract allows platform diffs).
- Negative seeds stay rejected (TASK-003 decision); if the benchmark used negative seeds they'd fail with exit 2.
- `./test.sh` already takes minutes; keep new e2e runs small (≤ 300 ticks on 64×48).

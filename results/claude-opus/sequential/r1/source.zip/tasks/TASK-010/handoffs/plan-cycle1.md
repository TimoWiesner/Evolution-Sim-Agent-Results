# TASK-010 PLAN cycle 1 — Spatial search

Binding design: `docs/decisions/ADR-013-spatial-index-detail.md` (refines ADR-003). std only, no new crates, Cargo.lock unchanged. No wall clock in core (source-scan test): timing lives in the CLI only.

## Ordered implementation steps
1. **`crates/evosim-core/src/spatial/mod.rs`** (new; `pub mod spatial;` + doc line in `lib.rs`)
   - `#[derive(Debug, Clone, Copy, PartialEq, Eq)] pub struct Neighbour { pub id: EntityId, pub kind: Kind, pub cell: Cell, pub offset: Offset, pub distance: u32 }`.
   - `#[derive(Debug, Clone, PartialEq, Eq)] pub enum SpatialError { Duplicate(EntityId), Unknown(EntityId), OutsideWorld(Cell) }` + Display + Error.
   - `#[derive(Debug, Clone, PartialEq)] pub struct SpatialIndex { torus: Torus, buckets: Vec<Vec<EntityId>>, locator: BTreeMap<EntityId, (Cell, Kind)> }`; `impl Default` (1×1 torus). Slot `torus.index(cell) * 3 + kind.index()`.
   - Methods exactly as ADR-013: `new, torus, len, is_empty, clear, count(kind), insert, remove, move_to, location, contains, at, within, within_into, count_within, nearest, entries, check_against`.
   - `within_into`: if `self.torus.count_within(r) > self.len()` → iterate locator entries, filter kind, compute `torus.distance(center, cell) <= r`, offset `torus.offset(center, cell)`; else for `(cell, off)` in `torus.within(center, r)` push each id of the 1 or 3 kind buckets with `distance = off.chebyshev()`. Then `sort_unstable_by_key(|n| (n.distance, n.id))`.
   - `pub fn brute_force_within(torus: &Torus, entries: impl IntoIterator<Item=(EntityId, Kind, Cell)>, center, r, filter) -> Vec<Neighbour>` — independent oracle (uses only `Torus::distance/offset`, same sort).
   - Bucket insert: `binary_search` → `Err(pos)` insert; remove: `binary_search` → `Ok(pos)` remove.
2. **`organism/mod.rs`** — `Organism::set_pos` → `pub(crate)` (doc: only via `Population::move_organism`).
3. **`organism/population.rs`**
   - field `index: SpatialIndex`; `with_expression(expression, torus: Torus)`; `new()` unchanged (placeholder index).
   - `founders`: build with the torus, insert each founder after push.
   - `resolve_births`: `pos = torus.wrap(r.pos.x as i64, r.pos.y as i64)`, store that pos (also in BirthRecord), `index.insert(id, kind, pos)` (cannot fail: fresh id, wrapped pos; `expect`).
   - `kill`: after flagging, `self.index.remove(id)`.
   - `pub fn move_organism(&mut self, id, to: Cell) -> Result<Cell, SpatialError>`: `Unknown` if not alive, `OutsideWorld` if `!torus.contains(to)`; updates index then `set_pos`; returns old cell.
   - `pub fn index(&self) -> &SpatialIndex`, `within(center, r, filter) -> Vec<Neighbour>`, `within_into(..)`, `nearest(..)`, `at(cell, filter)` delegating.
   - `pub fn rebuild_index(&mut self, torus: Torus) -> Result<(), String>`: new index, insert every *living* organism (error if outside torus).
   - `validate(next_id)`: additionally `index.check_against(living organisms)`.
4. **`sim/world.rs`** — `from_config`: `Population::with_expression(Expression::from_config(config), torus)`; `set_organisms(p)` → `p.rebuild_index(self.torus)` before storing; return `Result<(), String>`.
   **`sim/mod.rs`** — `set_population`: validate (with next id) then `set_organisms` mapping Err to `SimError::Population`. Order: rebuild_index first then validate (validate checks index), or validate skips index check if torus differs — simplest: `p.rebuild_index(world torus)?; p.validate(next)?; store`.
5. **CLI `crates/evosim-cli/src/lib.rs`** — `"spatial" => spatial_command(rest, out, err)`; `evosim spatial bench [--width N] [--height N] [--organisms N] [--queries N] [--radius R] [--seed S]` (defaults 200, 200, 2000, 20000, 6, 1). Builds a `SpatialIndex` with N random organisms (kinds 60/30/10 %, positions from `Rng::seed_from_u64(seed)`), random query centers / filters (None/each kind), times index `within_into` over all queries and brute force over the same queries with `std::time::Instant`, verifies identical results, prints JSON `{"width","height","organisms","queries","radius","index_ns_per_query","brute_ns_per_query","speedup","identical":true,"hits"}`; exit 0, exit 2 on bad args or mismatch. Also time a "full tick-like" pass: one query per organism (N queries) — optional field `per_tick_ms_index/brute`. Help text line in `--help`.
6. **Docs** — new `docs/SPATIAL.md`: data structure, interface, order rule, sync rules, measurement table with exact command, machine note (container), and results for (200×200, 2000, r=6), (100×100, 2000, r=3), (50×50, 2000, r=8). ARCHITECTURE `spatial` row → implemented + ADR-013, note Population owns it; STATE notes/test counts.

## Tests (`spatial/tests.rs` unless noted) → Must-haves
- **AC1 radius/kind/edges/no duplicates**: `seam_query_finds_across_both_edges` (10×8, center (0,0), entities at (9,7),(9,0),(0,7),(5,4) r=1 → exactly first three, offsets (-1,-1),(-1,0),(0,-1)); `kind_filter_returns_only_that_kind`; `no_duplicates_for_radius_larger_than_world` (worlds 1×1, 1×5, 5×1, 2×2, 3×3, radius 0..=20: ids unique, every entity returned exactly once when r ≥ max_distance); `every_result_within_radius`.
- **AC2 add/move/remove**: `removed_never_returned`, `moved_not_returned_from_old_cell` (query old cell r=0 empty, new cell finds it, `location` updated), `move_errors` (Unknown, OutsideWorld, Duplicate insert), `move_to_same_cell_noop`; organism tests `index_tracks_founders_births_kills_moves` (hook-driven 100-tick sim, random `move_organism` of herbivores in Herbivores phase, random kills and births; after every phase `pop.validate` OK and index entries == living organisms), `killed_disappears_from_queries_immediately`, `set_population_rebuilds_index` (index of restored pop equals the original's; outside-torus position → Err).
- **AC3 deterministic order**: `results_sorted_by_distance_then_id`; `order_independent_of_insertion_history` (same set inserted in two random orders / with move round-trips → identical `within` output and `SpatialIndex` equality); two identical sims produce identical query results.
- **AC4 randomised oracle**: `randomised_matches_brute_force` — seeds fixed, worlds [(1,1),(1,7),(7,1),(2,2),(3,5),(16,16),(64,48),(200,200)], per world random 0..300 entities, ≥ 600 rounds of: random op (insert/move/remove, kept in a shadow `Vec`) then query with random center, radius 0..=max(w,h)+3, random filter; assert `index.within == brute_force_within(shadow)` and `check_against(shadow)`; count queries and assert ≥ 1,000 total (target ~5,000), both scan paths exercised (assert counters of locator-path and cell-path > 0 via a test-only helper or by choosing cases where `count_within(r) > len`).
- **AC5 performance**: CLI integration test `spatial_bench_index_faster` (`evosim spatial bench --queries 2000`) asserts exit 0, `identical:true`, `speedup > 1`; recorded run of the default command in docs/SPATIAL.md (numbers copied verbatim).
- Existing suites stay green (`./test.sh`).

## Commands
- `source scripts/find-cargo.sh; evosim_find_cargo; cargo test -p evosim-core --release --locked spatial` (+ `organism`, `sim`)
- `cargo test -p evosim-core --locked` (debug)
- `cargo clippy -p evosim-core -p evosim-cli --release --locked --all-targets`
- `./evosim spatial bench` (and the other two configurations) → docs/SPATIAL.md
- `./test.sh`

## Risks
- `with_expression` signature change and `set_pos` visibility touch existing code/tests (only `founders` and `World::from_config` use them now).
- `set_population` now rejects positions outside the torus (stricter than before; intended).
- Intra-crate module cycle `spatial` ↔ `organism` (Kind) — acceptable like `genome` ↔ `organism`.
- Benchmark timing noise in the container: CLI test only asserts speedup > 1 (expected ≫ 10 at r=6); keep query count moderate so the test is fast.
- Core source-scan test forbids wall-clock/hashed-collection words in core files — avoid them even in comments of `spatial/`.

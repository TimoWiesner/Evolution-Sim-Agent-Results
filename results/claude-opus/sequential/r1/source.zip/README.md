# Evolution Simulation (`evosim`)

A locally runnable grid-world ecological evolution game (plants, herbivores, carnivores).
Status: feature-complete (TASK-001 … TASK-028): engine, headless `run`/`batch`, checkpoints, browser UI with charts and scenario editing, demo scenario. Verification evidence: [docs/VERIFICATION.md](docs/VERIFICATION.md); self-audit and known limitations: [docs/SELF-AUDIT.md](docs/SELF-AUDIT.md). Interface: [docs/CONTRACT.md](docs/CONTRACT.md).

## Requirements
- Linux x86-64 (developed on Ubuntu 24.04), bash, Python 3 (tests only).
- Rust stable toolchain (Cargo). `./setup.sh` finds an existing one (`PATH`, `~/.cargo/bin`,
  `/opt/rust/cargo/bin`) or installs one via rustup (needs internet). No apt packages.

## Install
```sh
./setup.sh            # builds target/release/evosim; idempotent
./evosim --help       # list commands
./evosim version      # {"name":"evosim","version":"0.1.0","contract":1}
```
`./evosim` works from any directory and needs no network.

## Configuration
JSON files (docs/CONTRACT.md §3); only `seed`, `world`, `initial` are required, everything else has a default.
Full reference, ranges and presets: [docs/CONFIG.md](docs/CONFIG.md).

Minimal file (the contract example; every other parameter takes its default):
```json
{ "seed": 42, "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 } }
```

| Group | Required | Main parameters (defaults; full list with ranges in docs/CONFIG.md) |
|---|---|---|
| `seed` | yes | integer; overridden by `--seed` |
| `world` | yes | `width`, `height` (cells, ≥ 1); the grid wraps left/right and top/bottom |
| `initial` | yes | `plants`, `herbivores`, `carnivores` (individuals at tick 0, ≥ 0) |
| `name`, `description` | no | free text |
| `climate` | no | `equator_temperature` 28, `pole_temperature` −25, `max_precipitation` 1.0, `year_length` 400, `seasonal_amplitude` 8, `weather_enabled` true, `weather_temperature_sd` 2, noise/weather scales |
| `plants` | no | `growth_rate` 1.5, `resource_regen` 1.0, `resource_cap` 15, `seed_rate` 0.5, `dispersal_radius` 3, `pollination_enabled` true, `max_age` 300, `max_per_cell` 2, `mutation_rate` 0.05, `species_threshold` 0.15 |
| `herbivores` | no | `max_speed` 2, `max_vision` 6, `max_litter` 3, `mating_cooldown` 40, `reproduction_threshold` 70, `graze_reserve` 0.35, `max_age` 1500, `mutation_rate` 0.05, … |
| `carnivores` | no | `max_speed` 3, `max_vision` 8, `max_litter` 1, `mating_cooldown` 120, `reproduction_threshold` 110, `max_age` 2000, `mutation_rate` 0.05, … |
| `hunting` | no | `base_success` 0.33, `prey_density_half` 40, `handling_time` 15, `cover_protection` 0.6, `attack_cost` 1.0 |

Unknown keys are an error; `./evosim config schema` prints every key with type, default and range.
```sh
./evosim config presets                 # default, lush, harsh, plants-only
./evosim config show --preset harsh     # full JSON of a preset
./evosim config validate my.json        # exit 0 if valid, 2 + message naming the key otherwise
```

## Demo scenario

```sh
./evosim ui --config scenarios/demo.json      # the demo: open the printed http://127.0.0.1:8765/ address
```
`scenarios/demo.json` is a 128×96 world with 1,600 plants, 480 herbivores and 80 carnivores (the contract example's
densities on four times the area; all other parameters are the defaults). Headless:
`./evosim run --config scenarios/demo.json --ticks 10000 --seed 1 --out demo.json` (about 2–3 minutes).

**Measured coexistence** (10,000 ticks, no forced anti-extinction; details docs/VERIFICATION.md §4):

| Configuration | Seeds | All three kinds alive at tick 10,000 | Median coexistence | Shortest |
|---|---|---|---|---|
| `scenarios/demo.json` (128×96) | 1–5 and 11–15 | **10 / 10** | 10,000 ticks | 10,000 ticks |
| contract example (64×48, defaults) | 1–5 | 3 / 5 | 10,000 ticks | 1,987 ticks (carnivores die out) |
| contract example (64×48, defaults) | 1001–1010 (TASK-027) | 3 / 10 | 2,208.5 ticks | 1,080 ticks |

On the small contract world the carnivores usually die out first; the larger demo world offers enough room for
regional crashes to be recolonised. Reproduce: `scripts/long-runs.sh`.

## Run headless
```sh
./evosim run --config my.json --ticks 1000 --out result.json --seed 7
./evosim run --config my.json --ticks 1000 --out result.json --sample-every 50
```
Needs no display. Simulates exactly `--ticks` ticks (also after every organism has died out; `0` is valid)
and writes the result JSON of docs/CONTRACT.md §4 to `--out`: `contract`, `seed`, `tick_start`, `tick_end`,
`world`, `final` (living individuals + living species per kind), `totals` (`births`, `deaths`, plus
`initial` and `deaths_by_cause`), `series` (counts at the start, every `--sample-every` ticks — default
max(1, N/100) — and at the end), `state_hash` (SHA-256 of the complete simulation state), `elapsed_seconds`,
`ticks_per_second`, and the extras `name`, `version`, `sample_every`, `extinction_tick` and `config` (the full
effective configuration). The same configuration, seed and tick count always give the same result (except
the timing fields). stdout stays empty; a summary line goes to stderr. Bad arguments or an invalid
configuration give exit status 2, a message on stderr and no result file.

Evolution metrics: add `--metrics metrics.json` to also write, at every series tick, population, births/deaths
(interval and total), deaths by cause, living species, generation max/mean and mean/sd/min/max of every trait,
energy and age per kind. Format: [docs/METRICS.md](docs/METRICS.md). The result and `state_hash` are unchanged.

## Batch runs and parameter sweeps
```sh
./evosim batch --config my.json --seeds 1,2,3 --ticks 1000 --out-dir out/
./evosim batch --config my.json --seeds 1,2 --ticks 1000 --out-dir sweep/ \
               --param plants.growth_rate=0.8,1.2 [--param initial.carnivores=10,20] [--jobs 4]
```
Writes `seed-<s>.json` per run (same schema as `run`; with `--param` under `combo-<c>/`), `summary.json`
(every run with seed, parameters, ticks, final counts, extinction; aggregates mean/min/max/sd/median of the final
population per kind and extinction counts, over all runs and per parameter combination), `summary.csv` (one row
per run) and `aggregates.csv`. Several `--param` flags form the cartesian product. The same batch gives the same
summary apart from the time keys (`timing`, `runs[].elapsed_seconds`, `runs[].ticks_per_second`), for any
`--jobs`. Details: [docs/BATCH.md](docs/BATCH.md).

## Performance
```
./evosim perf    # ticks/s benchmark: contract example, seed 42, 1000 warm-up + 1000 measured ticks, median of 3 (JSON)
```
Numbers, profile and the equivalence check (`scripts/perf-equivalence.sh`): [docs/PERFORMANCE.md](docs/PERFORMANCE.md).

## Build the distributable
```sh
./build.sh            # creates dist/evosim
dist/evosim version
```
`dist/` is self-contained: `dist/evosim` is a single release binary that links only to base-system
libraries (glibc, libgcc_s); all assets are embedded. Copy the folder anywhere and run it.
`dist/` and `target/` are ignored by Git.

## Test
```sh
./test.sh
```
Runs the whole suite (one command, exit 0 = all green, under a minute on 12 cores after the first build): `cargo test --workspace --release --locked`
(unit + integration tests, including the seeded randomised invariant tests
`crates/evosim-core/tests/randomized_invariants.rs`: birth/death accounting, value ranges, no replenishment,
wrapping, determinism and checkpoint equivalence over many random seeds and configurations), the UI JavaScript tests
(`node --test`) and `scripts/check-entrypoints.sh` (every command and required behaviour of docs/CONTRACT.md:
setup, version, help, exit status 2 for bad arguments/configs/checkpoints, run/batch/checkpoints, `initial.plants=0`
extinction, demo scenario, build, self-contained `dist/` incl. a minimal-chroot run, UI smoke test and screenshots).

Long runs (not part of `./test.sh`, about 8 minutes on 12 cores): `scripts/long-runs.sh` runs the contract example and the demo
scenario for 10,000 ticks with seeds 1–5 and prints the coexistence table (`scripts/coexistence.py`).

## Layout
- `crates/evosim-core` — simulation engine (no UI dependency)
- `crates/evosim-ui` — local browser UI (world view, run controls, inspector)
- `crates/evosim-cli` — the `evosim` binary
- `setup.sh`, `evosim`, `build.sh`, `test.sh`, `scripts/` — entry points and helpers

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/decisions/](docs/decisions/).

Climate zones/biomes and how latitude is folded onto the wrapping world: [docs/CLIMATE.md](docs/CLIMATE.md); inspect with `./evosim climate map [--format text|json|ppm] [--out FILE]`.

## User interface

```
./setup.sh                      # once: builds the binary
./evosim ui [--config FILE] [--port N]
```

`./evosim ui` starts a local web server (same engine as `./evosim run`) and prints its address,
by default `http://127.0.0.1:8765/` (a free port is used if 8765 is busy). Open it in a browser.
Without `--config` the `default` preset (contract example world) is used.

- World view: every cell is coloured by its biome; plants are green squares, herbivores cream
  circles, carnivores red triangles (brighter = more energy). The legend is in the sidebar.
- Pan: drag with the mouse (or arrow keys). Zoom: mouse wheel (about the cursor), `+`/`−`
  buttons or keys, `Fit`/`0` shows the whole world. The world wraps at every edge.
- Run controls (sidebar card + keyboard): **Run/Pause** (`Space`), **Step** exactly one tick
  (`.` or `N`; pauses first), **Reset** to tick 0 of the current configuration and seed (`R`;
  the same starting world every time, stays paused), **speed** `−`/`+` (`[`/`]`) over 8 levels
  1×, 2×, 5×, 10×, 20×, 50×, 200× ticks/s and Max (clamped, never below 1 tick/s). The top bar
  always shows tick, year/season, the three populations, Running/Paused and the speed.
- Inspector: click an organism (a click that moves < 4 px; dragging still pans) to select it —
  animals take priority in a cell, an empty cell picks the nearest organism within 1 cell. The
  card shows ID, kind, species (code, name, parent species), age, generation, birth tick,
  position, energy/health bars, mating cooldown, all 11 traits with range bars, the genome as one
  bar per locus (height = value 0–1, white mark = founder value, colour = trait group, grey =
  neutral marker; hover for the name) and parents (click a living parent to jump to it). The
  selection follows the organism while the simulation runs (`F` / ◎ Follow keeps the camera on
  it; a ring and its vision square mark it in the world). When it dies the card greys out and
  shows “Died at tick T (cause)”. `Esc` closes it.
- Checkpoints from the UI: type a path (relative to the directory `evosim ui` was started in)
  and press **Save** (`Ctrl+S`) / **Load**; or **Download** the current state / **Upload…** a
  file from the browser. Files are the same `evosim-checkpoint` JSON as `evosim run --save`, so
  `evosim run --load FILE` continues a world saved in the UI and vice versa. Loading pauses the
  sim; a later Reset rebuilds tick 0 of the loaded world's configuration and seed.
- New world (**✦ New world…** in the Scenario card, or `W`): pick a preset card (default, lush,
  harsh, plants-only), then edit seed (any unsigned 64-bit number; 🎲 = random), world width and
  height, the three initial populations, 12 key parameters (year length, equator/pole
  temperature, seasonal amplitude, weather on/off, plant resource regeneration, mutation rates of
  all three kinds, plant and herbivore max age, hunting base success) and, under *Advanced*, every
  other configuration key. Each invalid value is marked red with its message directly under the
  field (the server re-checks with the same rules as `evosim run`, including cross-field rules);
  **Start** stays disabled and the running world is untouched until all fields are valid. A UI-only
  limit of 1,048,576 cells (e.g. 1024×1024) keeps the browser responsive; `evosim run` has no such limit.
- Configuration files: **Export JSON** in the dialog (the form) or **⇩ Export config** (the running
  world) download the full configuration; **Import JSON…** / **⇧ Import config…** load such a file
  into the form (invalid entries are marked at their fields). The files are ordinary `--config`
  files for `./evosim run`; export followed by import gives exactly the same configuration.
- Charts (dock under the world, **⤢ Expand** or `C` for full size): population per kind (log
  scale), births and deaths per 100 ticks (solid = births, dashed = deaths, log scale), living
  species per kind, the mean ± sd of a selectable trait over time (one kind or all three) and the
  current distribution of the selected trait for a selectable kind (dashed line = mean). All charts
  update while the simulation runs; history is kept for the whole run (thinned to ≤ 600 points).
- Automation: `./evosim ui --smoke-test` (headless chromium, exits 0 after ≥10 ticks and
  rendered frames) and `./evosim ui --screenshots DIR` (after ≥300 ticks writes `DIR/main.png`
  (full interface with charts), `DIR/charts.png` (expanded charts), `DIR/setup.png` (New world
  dialog with two invalid fields), `DIR/world-zoomed.png` and `DIR/inspector.png` (a selected
  carnivore)). Headless chromium paints only ~813 of the 900 px, so the last ~88 px are empty. Chromium is taken from `$CHROME_BIN` or `chromium`.
- End-to-end UI checks: `scripts/ui-checks.sh` (also part of `./test.sh`).

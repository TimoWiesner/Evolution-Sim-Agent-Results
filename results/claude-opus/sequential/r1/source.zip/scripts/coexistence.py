#!/usr/bin/env python3
"""Coexistence table of an `evosim batch` summary.json (TASK-028, ADR-031).

Usage: python3 scripts/coexistence.py DIR/summary.json [--markdown]
Coexistence of a run = first tick at which any kind is extinct (batch
extinction_tick, sampled at --sample-every), or the run length if all three
kinds are alive at the end. Also checks initial + births - deaths = final."""
import json, os, statistics, sys
from collections import defaultdict

s = json.load(open(sys.argv[1]))
md = "--markdown" in sys.argv
groups = defaultdict(list)
ok = True
for r in s["runs"]:
    et, ticks = r["extinction_tick"], r["ticks"]
    co = min(t if t is not None else ticks for t in et.values())
    first = "-" if all(v is None for v in et.values()) else min(et, key=lambda k: et[k] if et[k] is not None else 10**12)
    d = json.load(open(os.path.join(os.path.dirname(sys.argv[1]), r["file"])))
    t = d["totals"]
    for k in ("plants", "herbivores", "carnivores"):
        if t["initial"][k] + t["births"][k] - t["deaths"][k] != d["final"][k] or d["tick_end"] != r["ticks"]:
            ok = False
            print(f"ACCOUNTING/TICKS MISMATCH seed {r['seed']} {k}", file=sys.stderr)
    groups[json.dumps(r["params"])].append((r, co, first))
for key, rows in groups.items():
    if md:
        print(f"| seed | plants | herbivores | carnivores | extinction ticks (p/h/c) | coexistence | first extinct | elapsed s |")
        print("|---|---|---|---|---|---|---|---|")
    else:
        print("params", key)
    for r, co, first in rows:
        f, et = r["final"], r["extinction_tick"]
        ets = "/".join("-" if et[k] is None else str(et[k]) for k in ("plants", "herbivores", "carnivores"))
        if md:
            print(f"| {r['seed']} | {f['plants']} | {f['herbivores']} | {f['carnivores']} | {ets} | {co:,} | {first} | {r['elapsed_seconds']:.0f} |")
        else:
            print(f"  seed {r['seed']}: final {f['plants']}/{f['herbivores']}/{f['carnivores']} ext {ets} coexistence {co} first {first} elapsed {r['elapsed_seconds']:.1f}s tps {r['ticks_per_second']:.0f}")
    cs = [co for _, co, _ in rows]
    full = sum(1 for _, co, _ in rows if co >= rows[0][0]["ticks"])
    print(f"{'' if not md else chr(10)}median coexistence {statistics.median(cs):g} ticks (min {min(cs)}, max {max(cs)}); "
          f"{full}/{len(cs)} runs with all three kinds at tick {rows[0][0]['ticks']}; "
          f"max elapsed {max(r['elapsed_seconds'] for r, _, _ in rows):.1f} s")
print("accounting initial+births-deaths=final and tick_end: " + ("OK" if ok else "MISMATCH"))
sys.exit(0 if ok else 1)

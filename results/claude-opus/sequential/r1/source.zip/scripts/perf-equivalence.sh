#!/usr/bin/env bash
# TASK-026 / ADR-029 §4: behaviour-equivalence check for optimisations.
# Re-runs every golden row of scripts/perf-equivalence.txt (preset, seed, ticks)
# and compares the result's state_hash with the recorded one.
# Usage: scripts/perf-equivalence.sh [EVOSIM_BINARY]   (default: ./evosim)
# Exit 0 = all rows equal, 1 = a mismatch, 2 = setup error.
# Not part of ./test.sh: the list is tied to the current ecology parameters and
# must be re-recorded after intentional behaviour changes.
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
BIN="${1:-$ROOT/evosim}"
LIST="$ROOT/scripts/perf-equivalence.txt"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
fail=0
while read -r preset seed ticks want; do
    case "$preset" in ''|'#'*) continue ;; esac
    "$BIN" config show --preset "$preset" > "$TMP/$preset.json" || { echo "cannot show preset $preset" >&2; exit 2; }
    "$BIN" run --config "$TMP/$preset.json" --seed "$seed" --ticks "$ticks" --out "$TMP/out.json" 2>/dev/null || { echo "run failed: $preset $seed $ticks" >&2; exit 2; }
    got="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["state_hash"])' "$TMP/out.json")"
    if [ "$got" = "$want" ]; then
        echo "OK       $preset seed=$seed ticks=$ticks $got"
    else
        echo "MISMATCH $preset seed=$seed ticks=$ticks got $got want $want"
        fail=1
    fi
done < "$LIST"
[ "$fail" = 0 ] && echo "perf-equivalence: all rows equal" || echo "perf-equivalence: MISMATCH"
exit "$fail"

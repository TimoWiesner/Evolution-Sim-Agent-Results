#!/usr/bin/env bash
# TASK-018 extinction report: runs the default parameters (contract example
# configuration, only fixed keys) for 10,000 ticks with seeds 1-5 and prints,
# per seed and kind, the extinction tick or "survived". Extra arguments are
# passed to `evosim ecology survival` (e.g. --json, --ticks N, --seeds 1,2,3).
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
exec "$ROOT/evosim" ecology survival "$@"

#!/usr/bin/env bash
# CONTRACT §6 self-containment (ADR-031 D3): runs dist/evosim inside a minimal
# chroot that contains only dist/ and the shared libraries ldd reports (libc,
# libm, libgcc_s, loader) - no shell, no Python/Rust/Node, no project files.
# Prints PASS:/FAIL:/SKIP: lines; exit 1 only on FAIL (SKIP if chroot is not permitted).
set -uo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
DIST="${1:-$ROOT/dist}"
[ -x "$DIST/evosim" ] || { echo "FAIL: chroot: $DIST/evosim missing (run ./build.sh)"; exit 1; }
CHROOT="$(command -v chroot)" || { echo "SKIP: chroot: chroot command not available"; exit 0; }
R="$(mktemp -d)"; trap 'rm -rf "$R"' EXIT
mkdir -p "$R/dist" "$R/work" "$R/tmp"
cp -r "$DIST/." "$R/dist/"
for lib in $(ldd "$DIST/evosim" | grep -oE '/[^ ]+'); do
    mkdir -p "$R$(dirname "$lib")"; cp -L "$lib" "$R$lib"
done
printf '{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}' >"$R/work/example.json"
if ! chroot "$R" /dist/evosim version >"$R/v.out" 2>"$R/v.err"; then
    if grep -qiE 'operation not permitted|permission denied' "$R/v.err"; then
        echo "SKIP: chroot: not permitted here ($(head -1 "$R/v.err"))"; exit 0
    fi
    echo "FAIL: chroot: dist/evosim version failed: $(head -3 "$R/v.err")"; exit 1
fi
FAIL=0
if python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["contract"]==1' "$R/v.out"; then
    echo "PASS: chroot (only dist/ + $(ldd "$DIST/evosim" | grep -c '/') libs): dist/evosim version prints contract JSON"
else
    echo "FAIL: chroot: version output: $(cat "$R/v.out")"; FAIL=1
fi
if env -i "$CHROOT" "$R" /dist/evosim run --config /work/example.json --ticks 200 --out /work/r.json 2>"$R/r.err" \
    && python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["tick_end"]==200 and len(d["state_hash"])>=32' "$R/work/r.json"; then
    echo "PASS: chroot: dist/evosim run (contract example, 200 ticks) writes result JSON"
else
    echo "FAIL: chroot: dist/evosim run: $(tail -3 "$R/r.err")"; FAIL=1
fi
exit $FAIL

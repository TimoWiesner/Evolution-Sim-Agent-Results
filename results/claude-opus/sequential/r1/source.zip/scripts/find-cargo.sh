# Sourced helper: make a *working* `cargo` available on PATH.
# Searches PATH and common install locations; sets CARGO_HOME/RUSTUP_HOME for
# the /opt/rust layout of the benchmark container if they are unset.
# Returns 1 if no working cargo can be found.
evosim_cargo_works() { cargo --version >/dev/null 2>&1; }
evosim_find_cargo() {
    if [ -z "${RUSTUP_HOME:-}" ] && [ -d /opt/rust/rustup ] && [ ! -d "$HOME/.rustup" ]; then
        export RUSTUP_HOME=/opt/rust/rustup
    fi
    if [ -z "${CARGO_HOME:-}" ] && [ -d /opt/rust/cargo ] && [ ! -d "$HOME/.cargo" ]; then
        export CARGO_HOME=/opt/rust/cargo
    fi
    if command -v cargo >/dev/null 2>&1 && evosim_cargo_works; then return 0; fi
    local d
    for d in "${CARGO_HOME:-}/bin" "$HOME/.cargo/bin" /opt/rust/cargo/bin /usr/local/cargo/bin; do
        if [ "$d" != "/bin" ] && [ -x "$d/cargo" ]; then
            export PATH="$d:$PATH"
            if evosim_cargo_works; then return 0; fi
        fi
    done
    # cargo exists via rustup but no default toolchain: try to select stable.
    if command -v rustup >/dev/null 2>&1; then
        rustup default stable >&2 && evosim_cargo_works && return 0
    fi
    return 1
}

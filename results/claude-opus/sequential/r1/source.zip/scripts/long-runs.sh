#!/usr/bin/env bash
# TASK-028 long runs (ADR-031 D5): 10,000 ticks, seeds 1-5, for the CONTRACT §3
# example configuration and scenarios/demo.json, plus one `dist/evosim run` of
# 10,000 ticks compared with the batch result of the same seed.
# Usage: scripts/long-runs.sh [OUTDIR] [SEEDS]   (default tasks/TASK-028/data/long-runs, 1,2,3,4,5)
# Not part of ./test.sh (about 8 minutes on 12 cores with --jobs 4).
set -uo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
OUT="${1:-$ROOT/tasks/TASK-028/data/long-runs}"
SEEDS="${2:-1,2,3,4,5}"
mkdir -p "$OUT"
EX="$OUT/contract-example.json"
printf '{\n  "seed": 42,\n  "world": { "width": 64, "height": 48 },\n  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }\n}\n' >"$EX"
FAIL=0
for name in contract-example demo; do
    cfg="$EX"; [ $name = demo ] && cfg="$ROOT/scenarios/demo.json"
    rm -rf "$OUT/$name"
    start=$(date +%s)
    if "$ROOT/evosim" batch --config "$cfg" --seeds "$SEEDS" --ticks 10000 --sample-every 100 --out-dir "$OUT/$name" --jobs 4 2>"$OUT/$name.log"; then
        echo "== $name: batch exit 0, wall $(( $(date +%s) - start )) s (4 parallel runs)"
    else
        echo "== $name: batch FAILED (see $OUT/$name.log)"; FAIL=1; continue
    fi
    python3 "$ROOT/scripts/coexistence.py" "$OUT/$name/summary.json" || FAIL=1
done
if [ -x "$ROOT/dist/evosim" ]; then
    s1="${SEEDS%%,*}"
    if "$ROOT/dist/evosim" run --config "$ROOT/scenarios/demo.json" --seed "$s1" --ticks 10000 --out "$OUT/dist-demo-seed-$s1.json" 2>"$OUT/dist-run.log" \
        && python3 -c 'import json,sys
a,b=(json.load(open(f)) for f in sys.argv[1:3])
assert a["state_hash"]==b["state_hash"] and a["final"]==b["final"] and a["totals"]==b["totals"]
print("== dist/evosim run demo seed %d, 10000 ticks: exit 0, %.1f s, identical to batch seed file" % (a["seed"], a["elapsed_seconds"]))' \
            "$OUT/dist-demo-seed-$s1.json" "$OUT/demo/seed-$s1.json"; then :; else echo "== dist/evosim long run FAILED"; FAIL=1; fi
fi
[ $FAIL = 0 ] && echo "long-runs: ALL OK" || echo "long-runs: FAILURES"
exit $FAIL

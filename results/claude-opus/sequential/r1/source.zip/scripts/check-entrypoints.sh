#!/usr/bin/env bash
# Contract-level checks of ./setup.sh, ./evosim, ./build.sh and dist/evosim.
set -uo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
FAIL=0
pass() { echo "PASS: $*"; }
fail() { echo "FAIL: $*"; FAIL=1; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cd "$TMP"   # run everything from an unrelated cwd

for f in setup.sh evosim build.sh test.sh; do
    [ -x "$ROOT/$f" ] && pass "$f exists and is executable" || fail "$f missing or not executable"
done

check_version() { # $1 = label, rest = command
    local label="$1"; shift
    local out
    if out="$("$@" 2>"$TMP/err")"; then
        if printf '%s' "$out" | python3 -c 'import json,sys
d=json.loads(sys.stdin.read())
assert set(d)=={"name","version","contract"}, d
assert d["contract"]==1 and isinstance(d["name"],str) and isinstance(d["version"],str)'; then
            pass "$label version prints contract JSON: $out"
        else
            fail "$label version output is not contract JSON: $out"
        fi
    else
        fail "$label version exited non-zero"
    fi
}

"$ROOT/setup.sh" >"$TMP/setup.log" 2>&1 && pass "setup.sh exit 0" || { fail "setup.sh failed"; cat "$TMP/setup.log"; }
check_version "./evosim" "$ROOT/evosim" version

if out="$("$ROOT/evosim" --help)"; then
    ok=1; for c in version run batch ui; do printf '%s' "$out" | grep -qw "$c" || ok=0; done
    [ $ok = 1 ] && pass "--help exit 0 and lists commands" || fail "--help misses commands"
else
    fail "--help exit status non-zero"
fi
"$ROOT/evosim" frobnicate >/dev/null 2>&1; rc=$?
[ $rc = 2 ] && pass "unknown command exit 2" || fail "unknown command exit $rc (want 2)"
"$ROOT/evosim" >/dev/null 2>&1; rc=$?
[ $rc = 2 ] && pass "no command exit 2" || fail "no command exit $rc (want 2)"

# Configuration (TASK-003): fixed-keys-only file valid, invalid value names key, presets round-trip.
printf '{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}' >"$TMP/fixed.json"
"$ROOT/evosim" config validate "$TMP/fixed.json" >/dev/null 2>&1 && pass "config validate fixed-keys-only exit 0" || fail "config validate fixed-keys-only failed"
printf '{"seed":1,"world":{"width":0,"height":5},"initial":{"plants":0,"herbivores":0,"carnivores":0}}' >"$TMP/bad.json"
"$ROOT/evosim" config validate "$TMP/bad.json" >"$TMP/bad.out" 2>"$TMP/bad.err"; rc=$?
if [ $rc = 2 ] && grep -q 'world.width' "$TMP/bad.err" && [ ! -s "$TMP/bad.out" ]; then
    pass "config validate width 0 exit 2, stderr names world.width"
else
    fail "config validate width 0: exit $rc, stderr: $(cat "$TMP/bad.err")"
fi
npre=0
for p in $("$ROOT/evosim" config presets | cut -f1); do
    npre=$((npre+1))
    if "$ROOT/evosim" config show --preset "$p" >"$TMP/p.json" && python3 -c 'import json,sys; json.load(open(sys.argv[1]))' "$TMP/p.json" \
        && "$ROOT/evosim" config validate "$TMP/p.json" >/dev/null 2>&1; then
        pass "preset $p: valid JSON and re-validates"
    else
        fail "preset $p does not round-trip"
    fi
done
[ $npre -ge 3 ] && pass "$npre presets listed" || fail "only $npre presets"

# Climate map export (TASK-006): JSON parses with the configured size; PPM header.
if "$ROOT/evosim" climate map --format json >"$TMP/clim.json" 2>"$TMP/clim.err" && python3 -c 'import json,sys
d=json.load(open(sys.argv[1]))
assert d["width"]==64 and d["height"]==48 and len(d["rows"])==48 and all(len(r)==64 for r in d["rows"])' "$TMP/clim.json"; then
    pass "climate map --format json exit 0, 64x48 rows"
else
    fail "climate map --format json: $(cat "$TMP/clim.err")"
fi
"$ROOT/evosim" climate map --format ppm --out "$TMP/clim.ppm" 2>/dev/null && [ "$(head -c 2 "$TMP/clim.ppm")" = "P6" ] \
    && pass "climate map --format ppm writes P6 image" || fail "climate map ppm export failed"

# Climate series (TASK-007): with weather off, year 2 repeats year 1 exactly; values within bounds.
if "$ROOT/evosim" climate series --x 3 --y 2 --no-weather --ticks 800 >"$TMP/series.json" 2>"$TMP/series.err" && python3 -c 'import json,sys
d=json.load(open(sys.argv[1])); s=d["series"]; b=d["bounds"]; Y=d["year_length"]
assert len(s)==800 and Y==400
assert all(s[t]["temperature"]==s[t+Y]["temperature"] and s[t]["precipitation"]==s[t+Y]["precipitation"] for t in range(Y))
assert all(b["t_min"]<=r["temperature"]<=b["t_max"] and b["p_min"]<=r["precipitation"]<=b["p_max"] for r in s)' "$TMP/series.json"; then
    pass "climate series --no-weather: year repeats exactly, within bounds"
else
    fail "climate series: $(cat "$TMP/series.err")"
fi

# TASK-019: headless run, end-to-end with the real launcher (contract example config).
cat >"$TMP/example.json" <<'JSON'
{"seed": 42, "world": {"width": 64, "height": 48},
 "initial": {"plants": 400, "herbivores": 120, "carnivores": 20}}
JSON
run_ok=1
for tag in a b; do
    env -u DISPLAY -u WAYLAND_DISPLAY "$ROOT/evosim" run --config "$TMP/example.json" --ticks 300 --seed 7 \
        --out "$TMP/run-$tag.json" >"$TMP/run-$tag.out" 2>"$TMP/run-$tag.err" || run_ok=0
    [ -s "$TMP/run-$tag.out" ] && run_ok=0
done
"$ROOT/evosim" run --config "$TMP/example.json" --ticks 300 --seed 8 --out "$TMP/run-c.json" 2>/dev/null || run_ok=0
if [ $run_ok = 1 ] && python3 -c 'import json,sys
a,b,c=(json.load(open(f)) for f in sys.argv[1:4])
for k in ("final","totals","series","state_hash"): assert a[k]==b[k], k
assert a["state_hash"]!=c["state_hash"]
assert a["seed"]==7 and a["tick_start"]==0 and a["tick_end"]==300 and a["contract"]==1
assert [p["tick"] for p in a["series"]]==list(range(0,301,3))
for k in ("plants","herbivores","carnivores"):
    t=a["totals"]; assert t["initial"][k]+t["births"][k]-t["deaths"][k]==a["final"][k]' "$TMP/run-a.json" "$TMP/run-b.json" "$TMP/run-c.json"; then
    pass "evosim run: same seed twice identical (final/totals/series/state_hash), other seed differs, no DISPLAY"
else
    fail "evosim run determinism: $(cat "$TMP/run-a.err")"
fi
if "$ROOT/evosim" run --config "$TMP/example.json" --ticks 0 --out "$TMP/run-0.json" 2>/dev/null \
    && python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["tick_end"]==0 and len(d["series"])==1' "$TMP/run-0.json"; then
    pass "evosim run --ticks 0"
else
    fail "evosim run --ticks 0"
fi
# TASK-020: --metrics writes the metrics document and leaves the result/state_hash unchanged.
if "$ROOT/evosim" run --config "$TMP/example.json" --ticks 300 --seed 7 --out "$TMP/run-m.json" \
        --metrics "$TMP/metrics.json" 2>"$TMP/run-m.err" \
    && python3 -c 'import json,sys
a,r,m=(json.load(open(f)) for f in sys.argv[1:4])
for k in ("final","totals","series","state_hash"): assert a[k]==r[k], k
assert m["format"]=="evosim-metrics" and m["format_version"]==1
assert [s["tick"] for s in m["samples"]]==[p["tick"] for p in r["series"]]
for s,p in zip(m["samples"],r["series"]):
    for k in ("plants","herbivores","carnivores"):
        assert s[k]["count"]==p[k]
        assert len(s[k]["traits"])==11 and len(s[k]["deaths_by_cause"])==6
for k in ("plants","herbivores","carnivores"):
    assert m["samples"][-1][k]["births_total"]==r["totals"]["births"][k]
    assert m["samples"][-1][k]["species"]["living"]==r["final"]["species"][k]' "$TMP/run-a.json" "$TMP/run-m.json" "$TMP/metrics.json"; then
    pass "evosim run --metrics: metrics file valid, same state_hash/series/totals as without"
else
    fail "evosim run --metrics: $(cat "$TMP/run-m.err")"
fi
"$ROOT/evosim" run --config "$TMP/example.json" --ticks 5 --out "$TMP/run-bad.json" --bogus >/dev/null 2>"$TMP/run-bad.err"
rc=$?
if [ $rc = 2 ] && [ -s "$TMP/run-bad.err" ] && [ ! -e "$TMP/run-bad.json" ]; then
    pass "evosim run bad flag: exit 2, stderr, no result file"
else
    fail "evosim run bad flag: rc=$rc"
fi
# TASK-022: checkpoints. 300 ticks uninterrupted (run-a) == 120 + --save, --load + 180.
cp_ok=1
"$ROOT/evosim" run --config "$TMP/example.json" --ticks 120 --seed 7 --out "$TMP/cp-1.json" --save "$TMP/cp.ckpt" 2>"$TMP/cp.err" || cp_ok=0
"$ROOT/evosim" run --load "$TMP/cp.ckpt" --ticks 180 --out "$TMP/cp-2.json" 2>>"$TMP/cp.err" || cp_ok=0
if [ $cp_ok = 1 ] && python3 -c 'import json,sys
a,b,c=(json.load(open(f)) for f in sys.argv[1:4])
assert c["format"]=="evosim-checkpoint" and c["version"]==1 and c["tick"]==120
assert b["tick_start"]==120 and b["tick_end"]==300
assert all(a[k]==b[k] for k in ("final","totals","state_hash")), "resumed run differs"' "$TMP/run-a.json" "$TMP/cp-2.json" "$TMP/cp.ckpt"; then
    pass "evosim run --save/--load: 120 + 180 ticks == 300 uninterrupted (final/totals/state_hash)"
else
    fail "evosim run --save/--load: $(cat "$TMP/cp.err")"
fi
head -c 1000 "$TMP/cp.ckpt" >"$TMP/cp-trunc.ckpt"
"$ROOT/evosim" run --load "$TMP/cp-trunc.ckpt" --ticks 5 --out "$TMP/cp-bad.json" >/dev/null 2>"$TMP/cp-bad.err"
rc=$?
if [ $rc = 2 ] && [ -s "$TMP/cp-bad.err" ] && [ ! -e "$TMP/cp-bad.json" ]; then
    pass "evosim run --load truncated checkpoint: exit 2, stderr, no result file"
else
    fail "evosim run --load truncated checkpoint: rc=$rc"
fi

# TASK-028: CONTRACT §5.3 no replenishment - initial.plants = 0: herbivores, then carnivores die out and stay 0;
# extinction is not an error (exit 0).
printf '{"seed":3,"world":{"width":32,"height":24},"initial":{"plants":0,"herbivores":60,"carnivores":10}}' >"$TMP/noplants.json"
if "$ROOT/evosim" run --config "$TMP/noplants.json" --ticks 3000 --sample-every 10 --out "$TMP/noplants-r.json" 2>"$TMP/np.err" \
    && python3 -c 'import json,sys
d=json.load(open(sys.argv[1])); s=d["series"]
def ext(k): return next(p["tick"] for p in s if p[k]==0)
h,c=ext("herbivores"),ext("carnivores")
for k,t in (("herbivores",h),("carnivores",c),("plants",0)):
    assert all(p[k]==0 for p in s if p["tick"]>=t), k+" replenished"
assert d["final"]["herbivores"]==0 and d["final"]["carnivores"]==0 and d["final"]["plants"]==0
assert d["totals"]["births"]["plants"]==0
print(h,c)' "$TMP/noplants-r.json" >"$TMP/np.out"; then
    pass "initial.plants=0: herbivores (tick $(cut -d" " -f1 "$TMP/np.out")) and carnivores (tick $(cut -d" " -f2 "$TMP/np.out")) die out, stay 0, exit 0"
else
    fail "initial.plants=0 run: $(tail -2 "$TMP/np.err")"
fi
# TASK-028: CONTRACT §5.4 invalid configurations given to run: exit 2, stderr, no result file.
printf '{"seed":"x","world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}' >"$TMP/e-type.json"
printf '{"seed":1,"world":{"width":64},"initial":{"plants":1,"herbivores":1,"carnivores":1}}' >"$TMP/e-missing.json"
printf '{"seed":1,"world":{"width":64,"height":48},"initial":{"plants":-1,"herbivores":1,"carnivores":1}}' >"$TMP/e-range.json"
printf '{"seed":1,"world":' >"$TMP/e-syntax.json"
for e in type missing range syntax unreadable; do
    f="$TMP/e-$e.json"; [ $e = unreadable ] && f="$TMP/does-not-exist.json"
    "$ROOT/evosim" run --config "$f" --ticks 5 --out "$TMP/e-$e.out.json" >"$TMP/e.stdout" 2>"$TMP/e.err"; rc=$?
    if [ $rc = 2 ] && [ -s "$TMP/e.err" ] && [ ! -s "$TMP/e.stdout" ] && [ ! -e "$TMP/e-$e.out.json" ]; then
        pass "run with config error ($e): exit 2, stderr '$(head -c 80 "$TMP/e.err" | tr '\n' ' ')', no result file"
    else
        fail "run with config error ($e): rc=$rc"
    fi
done
"$ROOT/evosim" run --config "$TMP/example.json" --ticks -5 --out "$TMP/e-neg.json" >/dev/null 2>"$TMP/e.err"; rc=$?
[ $rc = 2 ] && [ -s "$TMP/e.err" ] && [ ! -e "$TMP/e-neg.json" ] && pass "run --ticks -5: exit 2, no result file" || fail "run --ticks -5: rc=$rc"
"$ROOT/evosim" run --ticks 5 --out "$TMP/e-noconf.json" >/dev/null 2>"$TMP/e.err"; rc=$?
[ $rc = 2 ] && [ ! -e "$TMP/e-noconf.json" ] && pass "run without --config/--load: exit 2" || fail "run without --config: rc=$rc"
# TASK-028: CONTRACT §4 series/tick fields for a non-divisible N and explicit --sample-every.
if "$ROOT/evosim" run --config "$TMP/example.json" --ticks 250 --sample-every 40 --out "$TMP/s.json" 2>/dev/null \
    && python3 -c 'import json,sys
d=json.load(open(sys.argv[1])); t=[p["tick"] for p in d["series"]]
assert t==[0,40,80,120,160,200,240,250], t
assert d["world"]=={"width":64,"height":48} and d["tick_end"]==d["tick_start"]+250
assert d["elapsed_seconds"]>=0 and d["ticks_per_second"]>=0
assert all(set(p)>={"tick","plants","herbivores","carnivores"} for p in d["series"])
assert set(d["final"]["species"])=={"plants","herbivores","carnivores"}
assert all(c in "0123456789abcdef" for c in d["state_hash"])' "$TMP/s.json"; then
    pass "run --ticks 250 --sample-every 40: series 0..240 + 250, schema keys, lowercase hex hash"
else
    fail "run series with --sample-every"
fi
# TASK-028: CONTRACT §7 demo scenario accepted by config validate, run and batch.
DEMO="$ROOT/scenarios/demo.json"
"$ROOT/evosim" config validate "$DEMO" >/dev/null 2>&1 && pass "scenarios/demo.json validates" || fail "scenarios/demo.json invalid"
if "$ROOT/evosim" run --config "$DEMO" --ticks 50 --seed 5 --out "$TMP/demo-run.json" 2>/dev/null \
    && "$ROOT/evosim" batch --config "$DEMO" --seeds 1,2 --ticks 20 --out-dir "$TMP/demo-batch" 2>/dev/null \
    && [ -f "$TMP/demo-batch/seed-1.json" ] && [ -f "$TMP/demo-batch/seed-2.json" ] && [ -f "$TMP/demo-batch/summary.json" ]; then
    pass "scenarios/demo.json accepted by run (--seed 5) and batch"
else
    fail "scenarios/demo.json with run/batch"
fi

# TASK-021: evosim batch (CONTRACT §2): per-seed files + summary, reproducible apart from time keys, sweep.
if "$ROOT/evosim" batch --config "$TMP/example.json" --seeds 1,2,3 --ticks 50 --out-dir "$TMP/b1" 2>"$TMP/b1.err" \
    && "$ROOT/evosim" batch --config "$TMP/example.json" --seeds 1,2,3 --ticks 50 --out-dir "$TMP/b2" --jobs 1 2>"$TMP/b2.err" \
    && python3 -c 'import json,sys,os
a,b=sys.argv[1:3]
for d in (a,b):
    for f in ("seed-1.json","seed-2.json","seed-3.json","summary.json","summary.csv","aggregates.csv"): assert os.path.isfile(os.path.join(d,f)), f
def strip(s):
    s.pop("timing")
    for r in s["runs"]: r.pop("elapsed_seconds"); r.pop("ticks_per_second")
    return s
sa,sb=(strip(json.load(open(os.path.join(d,"summary.json")))) for d in (a,b))
assert sa==sb
assert [r["seed"] for r in sa["runs"]]==[1,2,3] and all(r["ticks"]==50 for r in sa["runs"])
r1=json.load(open(os.path.join(a,"seed-1.json"))); assert r1["seed"]==1 and r1["tick_end"]==50 and r1["contract"]==1
assert sa["runs"][0]["state_hash"]==r1["state_hash"]
assert set(sa["aggregates"]["all"]["kinds"]["plants"]["final"])>={"mean","min","max"}' "$TMP/b1" "$TMP/b2"; then
    pass "evosim batch: seed-<s>.json + summary.json/csv, same summary twice (--jobs 1 vs default) apart from time"
else
    fail "evosim batch: $(cat "$TMP/b1.err" "$TMP/b2.err" 2>/dev/null | tail -3)"
fi
if "$ROOT/evosim" batch --config "$TMP/example.json" --seeds 1,2 --ticks 30 --out-dir "$TMP/b3" \
        --param plants.growth_rate=0.8,1.2 2>"$TMP/b3.err" \
    && python3 -c 'import json,sys
s=json.load(open(sys.argv[1]+"/summary.json"))
assert len(s["runs"])==4 and [r["params"]["plants.growth_rate"] for r in s["runs"]]==[0.8,0.8,1.2,1.2]
assert len(open(sys.argv[1]+"/summary.csv").read().splitlines())==5
for r in s["runs"]: assert json.load(open(sys.argv[1]+"/"+r["file"]))["config"]["plants"]["growth_rate"]==r["params"]["plants.growth_rate"]' "$TMP/b3"; then
    pass "evosim batch --param: 2 values x 2 seeds = 4 runs"
else
    fail "evosim batch --param: $(tail -3 "$TMP/b3.err")"
fi
"$ROOT/evosim" batch --config "$TMP/example.json" --seeds 1 --ticks 5 --out-dir "$TMP/b4" --param nope.key=1,2 >/dev/null 2>"$TMP/b4.err"
rc=$?
if [ $rc = 2 ] && [ -s "$TMP/b4.err" ] && [ ! -e "$TMP/b4" ]; then
    pass "evosim batch bad --param: exit 2, stderr, nothing written"
else
    fail "evosim batch bad --param: rc=$rc"
fi

"$ROOT/build.sh" >"$TMP/build.log" 2>&1 && pass "build.sh exit 0" || { fail "build.sh failed"; cat "$TMP/build.log"; }
[ -x "$ROOT/dist/evosim" ] && pass "dist/evosim exists" || fail "dist/evosim missing"
check_version "dist/evosim" "$ROOT/dist/evosim" version

# Self-containment: only base-system shared libraries, runs from a copy with empty env.
if command -v ldd >/dev/null 2>&1; then
    bad="$(ldd "$ROOT/dist/evosim" 2>&1 | grep -vE 'linux-vdso|libc\.so|libm\.so|libgcc_s\.so|ld-linux|libpthread\.so|libdl\.so|librt\.so|statically linked' || true)"
    [ -z "$bad" ] && pass "dist/evosim links only base system libs" || fail "unexpected libs: $bad"
fi
mkdir -p "$TMP/copy" && cp -r "$ROOT/dist/." "$TMP/copy/"
check_version "copied dist (env -i)" env -i PATH=/usr/bin:/bin "$TMP/copy/evosim" version
if env -i PATH=/usr/bin:/bin "$TMP/copy/evosim" run --config "$TMP/example.json" --ticks 300 --seed 7 --out "$TMP/run-dist.json" 2>/dev/null \
    && python3 -c 'import json,sys
a,b=(json.load(open(f)) for f in sys.argv[1:3])
assert all(a[k]==b[k] for k in ("final","totals","series","state_hash"))' "$TMP/run-a.json" "$TMP/run-dist.json"; then
    pass "copied dist/evosim run (env -i) matches ./evosim run"
else
    fail "copied dist/evosim run"
fi
if env -i PATH=/usr/bin:/bin "$TMP/copy/evosim" run --load "$TMP/cp.ckpt" --ticks 180 --out "$TMP/cp-dist.json" 2>/dev/null \
    && python3 -c 'import json,sys
a,b=(json.load(open(f)) for f in sys.argv[1:3])
assert all(a[k]==b[k] for k in ("final","totals","state_hash"))' "$TMP/cp-2.json" "$TMP/cp-dist.json"; then
    pass "copied dist/evosim run --load matches ./evosim run --load"
else
    fail "copied dist/evosim run --load"
fi

while IFS= read -r line; do
    case "$line" in PASS:*) pass "${line#PASS: }";; FAIL:*) fail "${line#FAIL: }";; SKIP:*) echo "$line";; esac
done < <("$ROOT/scripts/check-dist-chroot.sh" 2>&1)
if env -i PATH=/usr/bin:/bin "$TMP/copy/evosim" run --config "$ROOT/scenarios/demo.json" --ticks 50 --seed 5 --out "$TMP/demo-dist.json" 2>/dev/null \
    && python3 -c 'import json,sys
a,b=(json.load(open(f)) for f in sys.argv[1:3])
assert a["state_hash"]==b["state_hash"]' "$TMP/demo-run.json" "$TMP/demo-dist.json"; then
    pass "copied dist/evosim run on scenarios/demo.json matches ./evosim"
else
    fail "copied dist/evosim run on demo"
fi

if (cd "$ROOT" && git check-ignore -q dist/evosim && git check-ignore -q target/); then
    pass "dist/ and target/ are git-ignored"
else
    fail "dist/ or target/ not git-ignored"
fi

# UI (TASK-023): smoke test, screenshots, 1,000-organism view.
while IFS= read -r line; do
    case "$line" in PASS:*) pass "${line#PASS: }";; FAIL:*) fail "${line#FAIL: }";; esac
done < <("$ROOT/scripts/ui-checks.sh" 2>&1)

# TASK-028: CONTRACT §7 demo scenario accepted by ui --config (smoke test).
if timeout 90 "$ROOT/evosim" ui --smoke-test --config "$ROOT/scenarios/demo.json" >/dev/null 2>"$TMP/ui-demo.err"; then
    pass "ui --smoke-test --config scenarios/demo.json exit 0"
else
    fail "ui --smoke-test --config scenarios/demo.json: $(tail -2 "$TMP/ui-demo.err")"
fi

[ $FAIL = 0 ] && echo "check-entrypoints: ALL PASS" || echo "check-entrypoints: FAILURES"
exit $FAIL

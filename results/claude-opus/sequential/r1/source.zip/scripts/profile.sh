#!/usr/bin/env bash
# TASK-026 / ADR-029 §2: callgrind profile of the benchmark setup.
# Warms up the contract example (seed 42) with `evosim run --save`, then
# profiles `evosim perf --load CK --warmup 0 --ticks M --repeat 1` under
# callgrind and prints the top inclusive and self entries.
# Usage: scripts/profile.sh [WARMUP_TICKS=1700] [MEASURED_TICKS=60] [OUT_DIR=target/profile]
# Needs valgrind (optional dependency: apt-get install -y valgrind); exit 2 without it.
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
W="${1:-1700}"; M="${2:-60}"; OUT="${3:-$ROOT/target/profile}"
command -v valgrind >/dev/null || { echo "profile: valgrind not found; install with: apt-get install -y valgrind" >&2; exit 2; }
mkdir -p "$OUT"
EVOSIM="$ROOT/evosim"
"$EVOSIM" config show --preset default > "$OUT/default.json"
"$EVOSIM" run --config "$OUT/default.json" --seed 42 --ticks "$W" --out "$OUT/warm.json" --save "$OUT/warm.ckpt.json" 2>/dev/null
rm -f "$OUT"/callgrind.out.*
valgrind --tool=callgrind --callgrind-out-file="$OUT/callgrind.out.perf" \
    "$ROOT/target/release/evosim" perf --load "$OUT/warm.ckpt.json" --warmup 0 --ticks "$M" --repeat 1 --out "$OUT/perf.json" 2>"$OUT/valgrind.log"
echo "== inclusive (top 25) =="
callgrind_annotate --inclusive=yes "$OUT/callgrind.out.perf" 2>/dev/null | grep -v '^-' | sed -n '1,60p' | grep -E '^\s*[0-9,]+ \(' | head -25
echo "== self (top 20) =="
callgrind_annotate "$OUT/callgrind.out.perf" 2>/dev/null | grep -E '^\s*[0-9,]+ \(' | head -20

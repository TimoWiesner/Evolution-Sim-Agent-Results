#!/usr/bin/env bash
# End-to-end UI checks (TASK-023): smoke test on a virtual display, screenshots,
# 1,000-organism view fps. Uses the container chromium; sourced or run standalone.
# Usage: scripts/ui-checks.sh   (exit 0 = all pass)
set -u
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")/.." && pwd)"
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
F=0
ok() { echo "PASS: $*"; }
ko() { echo "FAIL: $*"; F=1; }
if command -v xvfb-run >/dev/null; then
    s=$(date +%s); timeout 70 xvfb-run -a "$ROOT/evosim" ui --smoke-test >"$T/smoke.out" 2>"$T/smoke.err"; rc=$?; e=$(( $(date +%s) - s ))
    [ $rc = 0 ] && [ $e -lt 60 ] && grep -q '"smoke":"ok"' "$T/smoke.out" && ok "ui --smoke-test under xvfb-run exit 0 in ${e}s: $(cat "$T/smoke.out")" || ko "ui --smoke-test xvfb rc=$rc ${e}s $(cat "$T/smoke.err")"
fi
s=$(date +%s); timeout 70 "$ROOT/evosim" ui --smoke-test >"$T/smoke2.out" 2>"$T/smoke2.err"; rc=$?; e=$(( $(date +%s) - s ))
[ $rc = 0 ] && [ $e -lt 60 ] && ok "ui --smoke-test (no DISPLAY needed) exit 0 in ${e}s" || ko "ui --smoke-test rc=$rc $(cat "$T/smoke2.err")"
mkdir -p "$T/shots"
s=$(date +%s); timeout 130 "$ROOT/evosim" ui --screenshots "$T/shots" >/dev/null 2>"$T/shots.err"; rc=$?; e=$(( $(date +%s) - s ))
if [ $rc = 0 ] && [ $e -lt 120 ] && python3 -c '
import struct,sys
b=open(sys.argv[1],"rb").read(24); assert b[:8]==b"\x89PNG\r\n\x1a\n"; w,h=struct.unpack(">II",b[16:24]); assert w>=1280 and h>=720, (w,h)' "$T/shots/main.png"; then
    ok "ui --screenshots exit 0 in ${e}s, main.png >= 1280x720"
else
    ko "ui --screenshots rc=$rc ${e}s $(cat "$T/shots.err")"
fi
timeout 70 "$ROOT/evosim" ui --smoke-test --config "$ROOT/crates/evosim-ui/tests/fixtures/ui-1000.json" >"$T/perf.out" 2>"$T/perf.err"; rc=$?
if [ $rc = 0 ] && python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); assert d["fps"]>=4 and d["ticks"]>=10, d' "$T/perf.out"; then
    ok "1,000-organism fixture view: $(cat "$T/perf.out")"
else
    ko "1,000-organism fixture rc=$rc $(cat "$T/perf.out" "$T/perf.err")"
fi
"$ROOT/evosim" ui --screenshots "$T/missing-dir" >/dev/null 2>&1; rc=$?
[ $rc = 2 ] && ok "ui --screenshots missing DIR exit 2" || ko "ui --screenshots missing DIR exit $rc"
exit $F

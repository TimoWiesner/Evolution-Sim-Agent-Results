#!/usr/bin/env bash
# Installs and builds everything evosim needs (docs/CONTRACT.md section 1).
# Idempotent; may use the network only to install a Rust toolchain if missing.
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$ROOT"
. "$ROOT/scripts/find-cargo.sh"

if ! evosim_find_cargo; then
    echo "setup: cargo not found, installing Rust toolchain via rustup" >&2
    if ! command -v curl >/dev/null 2>&1; then
        echo "setup: curl missing; installing via apt-get" >&2
        apt-get update >&2 && apt-get install -y curl ca-certificates >&2
    fi
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal >&2
    evosim_find_cargo || { echo "setup: cargo still not found after rustup install" >&2; exit 1; }
fi

echo "setup: using $(cargo --version)" >&2
cargo build --release --locked --bin evosim >&2
test -x "$ROOT/target/release/evosim"
echo "setup: done; try ./evosim --help" >&2

#!/usr/bin/env bash
# Runs the whole test suite: Rust unit/integration tests + contract entry-point checks.
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$ROOT"
. "$ROOT/scripts/find-cargo.sh"
evosim_find_cargo || { echo "test: cargo not found; run ./setup.sh first" >&2; exit 1; }
cargo test --workspace --release --locked
node --test "$ROOT/crates/evosim-ui/web/test/"
"$ROOT/scripts/check-entrypoints.sh"

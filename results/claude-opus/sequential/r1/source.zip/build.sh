#!/usr/bin/env bash
# Produces the self-contained distributable dist/evosim (docs/CONTRACT.md section 6).
set -euo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$ROOT"
. "$ROOT/scripts/find-cargo.sh"
evosim_find_cargo || { echo "build: cargo not found; run ./setup.sh first" >&2; exit 1; }

cargo build --release --locked --bin evosim >&2
rm -rf "$ROOT/dist"
mkdir -p "$ROOT/dist"
cp "$ROOT/target/release/evosim" "$ROOT/dist/evosim"
if command -v strip >/dev/null 2>&1; then strip "$ROOT/dist/evosim" || true; fi
chmod +x "$ROOT/dist/evosim"
"$ROOT/dist/evosim" version >/dev/null
echo "build: wrote dist/evosim" >&2

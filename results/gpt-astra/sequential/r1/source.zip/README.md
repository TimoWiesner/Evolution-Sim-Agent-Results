# Evolution Simulation

A grid-world ecological evolution game under development. The current bootstrap
supports `version`, `help`, `--help` and `-h`. Simulation (`run`, `batch`, `ui`)
will be introduced by later tasks; these commands currently fail with status 2.

Install on Ubuntu 24.04 x86-64 with build tools and internet access:

```sh
./setup.sh
./evosim version
./evosim --help
```

Setup installs the pinned Rust 1.100.0 toolchain with rustfmt/Clippy through rustup
and builds the release executable using Cargo.lock. It can be rerun. If rustup
is absent it downloads the HTTPS installer using curl or wget (installing curl
and CA certificates through apt as root if neither downloader exists). An unmanaged
Rust installation is left intact and reported as an error: install rustup first.
Standard C build tools/linker must be installed, as in the benchmark container.
No additional system packages are needed in that container.

Run the entire test suite and quality gates with one command after setup:

```sh
./test.sh
```

This checks formatting, Clippy, Rust CLI integration tests, Python 3.12+ archive
validation tests, repeat setup, packaging,
foreign working directories, version output and error propagation. Rust tests parse
the version as JSON and check help, invalid arguments and non-Unicode arguments.
The test-only serde_json dependency is pinned by Cargo.lock.

Create the distributable:

```sh
./build.sh
./dist/evosim version
```

Copy `dist/` to an Ubuntu 24.04 x86-64 machine. Its native executable needs only
base-system libc/libgcc and the ELF loader, with no Rust, Python, Node, Cargo or
project source at runtime. Both launchers work offline; setup/build may download
toolchains or locked dependencies. Root scripts work from any working directory
when called by their path; `evosim` executes the existing release binary without
rebuilding it. Run setup again after source changes. Build outputs in `target/`
and `dist/` are ignored by Git. Cross-distro portability is not promised.

Version writes one JSON object to stdout. Invalid commands, extra arguments and
no arguments write a diagnostic to stderr and exit 2. Help lists only implemented
commands. See `docs/ARCHITECTURE.md` and `docs/decisions/` for the future engine
design, and `docs/CONTRACT.md` for the external interface.

To check provisioning in a genuinely fresh Ubuntu userspace, run the separate,
networked environment acceptance check (Python 3.12+, curl, util-linux, root and
permission to create mount/PID/network namespaces, mount proc/tmpfs and create
minimal device nodes are required):

```sh
./tests/fresh-container.sh
```

It downloads the official Ubuntu Base 24.04.5 amd64 archive, checks its pinned
SHA-256 against Ubuntu's published checksum, and extracts two new root filesystems
under `target/fresh-container.*`. It copies an explicit source allowlist, provisions
build-essential/CA certificates/curl/Python/Node with apt, and runs setup with Rust
initially absent, version, repeat setup from a foreign directory, the regular test
suite, and build. It then checks the packaged version in the untouched second
rootfs with no language runtimes and a private network namespace. Build downloads
share the host network, using explicit DNS 1.1.1.1; no host homes or caches are
mounted. This is userspace isolation on the host kernel, not a separate VM. It uses
privileged mount/PID namespaces: a single-UID user namespace is insufficient for
apt package ownership changes and device creation.

Logs, package inventories, command statuses and source hashes stay in the printed
ignored evidence directory. The outer timeout is 20 minutes; failures are nonzero,
including unavailable isolation (never treated as a skip/pass). Namespace teardown
removes its private mounts and children; evidence is retained for diagnosis.
Restricted environments may permit namespace creation but deny proc mounts or
device creation. Such a failure does not establish fresh-container acceptance.
This check is deliberately separate from `./test.sh` to avoid downloading and
provisioning an operating system on each development run. Its archive validation
regression tests run without network or mount privileges:

```sh
python3 -m unittest discover -s tests -p 'test_fresh_container.py' -v
```

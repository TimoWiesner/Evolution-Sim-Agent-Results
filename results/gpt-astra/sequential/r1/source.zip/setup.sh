#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
# Toolchains belong to the invoking user's standard rustup installation.
if ! command -v rustup >/dev/null 2>&1; then
    if [ -x "${CARGO_HOME:-$HOME/.cargo}/bin/rustup" ]; then
        PATH="${CARGO_HOME:-$HOME/.cargo}/bin:$PATH"
        export PATH
    else
        if command -v rustc >/dev/null 2>&1; then
            echo 'setup: unmanaged Rust found; install rustup or put it on PATH first' >&2
            exit 1
        fi
        mkdir -p "$ROOT/target"
        INSTALLER=$(mktemp "$ROOT/target/rustup-init.XXXXXX")
        trap 'rm -f "$INSTALLER"' EXIT HUP INT TERM
        if command -v curl >/dev/null 2>&1; then
            curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o "$INSTALLER"
        elif command -v wget >/dev/null 2>&1; then
            wget -q https://sh.rustup.rs -O "$INSTALLER"
        else
            apt-get update
            apt-get install -y --no-install-recommends ca-certificates curl
            curl --proto '=https' --tlsv1.2 -fsSL https://sh.rustup.rs -o "$INSTALLER"
        fi
        sh "$INSTALLER" -y --no-modify-path --profile minimal --default-toolchain none
        PATH="${CARGO_HOME:-$HOME/.cargo}/bin:$PATH"
        export PATH
    fi
fi
rustup toolchain install 1.100.0 --profile minimal --component rustfmt --component clippy
cargo +1.100.0 build --release --locked --target-dir "$ROOT/target"

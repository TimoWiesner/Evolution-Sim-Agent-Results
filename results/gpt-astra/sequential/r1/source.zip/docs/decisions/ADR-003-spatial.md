# ADR-003: Toroidal uniform cell buckets

Status: Accepted in TASK-001 IMPLEMENT cycle 1 (2026-11-21).
Originally proposed in PLAN cycle 1; runtime validation belongs to later tasks.

## Context and alternatives
Movement is cell-to-cell and perception must cross both world seams.
Alternatives considered:
- Brute-force entity scans: simplest correctness oracle, O(n) per perception query
  and potentially O(n²) each tick.
- Quadtree/k-d tree: useful for irregular continuous worlds, but seam copies and
  frequent moves complicate maintenance and correctness on this integer grid.
- Uniform buckets indexed by occupied grid cell (choice): matches movement and
  local interaction and is straightforward to test against brute force.

## Decision and interfaces
Store sparse occupied buckets keyed by row-major cell index in an ordered map,
with IDs ordered inside each bucket. Organism storage is authoritative; index is
a rebuildable cache. Support insert(id, cell), remove(id), move(id, destination),
and query(cell, integer_radius, optional_kind) returning sorted unique living IDs.
Multiple organisms may occupy one cell. Coordinates use Euclidean modulo,
including negative proposed moves. Use wrapped Chebyshev distance for discrete
perception; dx=min(abs(x1-x2), width-abs(x1-x2)), analogously dy. Movement takes
one adjacent cell step per movement action; accumulated speed can permit multiple
such actions, never a teleport. Later ecology tasks decide diagonal movement costs.

For a query, enumerate each distinct wrapped x/y coordinate at most once. When
2r+1 spans a dimension, enumerate that dimension once rather than modulo-looping
repeated cells. If the candidate rectangle is larger than occupied bucket count,
scan occupied keys and filter by wrapped distance instead. This avoids pathological
loops in huge empty worlds or tiny worlds with large radii. Sort/unique final IDs.
Update buckets immediately after a move or death; enqueue newborn insertion at
end of tick. Reset/load rebuilds from ordered organism state.

## Consequences: performance, tests and distribution
Sparse buckets avoid allocating width*height slots for empty worlds. Ordered maps
cost O(log occupied_cells) per update/lookup; dense arrays may outperform them at
high occupancy. Benchmark before changing representation. Climate/resource arrays
have separate memory costs and must use checked dimension arithmetic and report
allocation errors cleanly; sparse indexing does not imply arbitrary-size worlds
fit in RAM. Queries cost visited buckets plus candidates and sorting; globally
large radii can still approach O(n²) over all entities.
Property-style seeded tests compare query results with brute force across seams,
1x1/1xN grids, radii larger than dimensions, multi-occupancy and random move/death
sequences. Test no duplicate candidates and exact cache reconstruction after load.
This uses Rust standard collections and adds no native/runtime dependency to dist.

# ADR-002: Local browser UI

Status: Accepted in TASK-001 IMPLEMENT cycle 1 (2026-11-21).
Originally proposed in PLAN cycle 1; runtime validation belongs to later tasks.

## Context and alternatives
Live controls, climate maps, inspection and charts must use the headless engine.
Alternatives considered:
- Native Rust egui: direct engine access and a convenient inspector, but graphics
  libraries/display setup complicate portable packaging and automated screenshots.
- Python Qt: mature widgets but requires a sizable Python/Qt runtime and native
  platform plugins in dist.
- Local browser, HTML/CSS/JavaScript Canvas (choice): available Chromium automation,
  flexible map rendering and minimal application dependencies.

## Decision and interfaces
Embed static browser assets in the Rust binary, serve on loopback only and run one
engine instance per UI session. Browser uses JSON commands for run/pause, bounded
step, reset/configuration and inspect; it receives read-only snapshots and metrics.
A serialized session controller owns engine mutation. The browser never implements
ecological rules or consumes simulation RNG. A server adapter uses the same engine
advance operation as CLI. Speed changes pacing, not tick semantics. Use Canvas for
the map and ordinary DOM controls/charts, with no CDN or network dependency.
Transport (HTTP polling initially) may be replaced without changing the engine;
cap snapshots/pacing and keep request ordering explicit. Bind an ephemeral port,
print local URL to stderr, and reject cross-origin mutation requests. Detailed
endpoint schemas belong to the UI task.

## Consequences: performance, tests and distribution
Canvas should handle the target population, but snapshot encoding and browser
rendering require separate profiling. Throttle rendering independently from engine
ticks; avoid sending full history every frame. Test controls and inspection against
engine snapshots. Smoke/screenshot automation must start the actual server/browser,
advance >=10/>=100 ticks respectively, render, and terminate child processes within
60/120 seconds. main.png is a real UI capture at least 1280x720, never a substitute
renderer. Use container Chromium; automation dependencies will be chosen and
installed by setup.sh in the owning task.
The binary embeds frontend files, so no Node or frontend server runtime is shipped.
A local browser is needed to view UI, while dist version/run require neither a
browser nor language runtimes, as the contract explicitly tests. If a broader
browser-free UI distribution is needed later, shipping Chromium greatly increases
size and must be decided then. Offline UI assets are mandatory. No UI code or
system dependencies are installed in TASK-001.

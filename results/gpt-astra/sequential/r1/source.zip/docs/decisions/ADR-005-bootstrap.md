# ADR-005: Bootstrap, quality gates and native distribution

Status: Accepted in TASK-002 IMPLEMENT cycle 1 (2026-11-21).

## Context and alternatives
TASK-002 introduces executable entry points and version/help only. ADR-001 already
selects Rust. Use one Cargo package rather than a multi-crate workspace: the latter
adds coordination without any engine implementation yet. Use Rust's built-in test
framework rather than pytest or a shell-only suite, so tests exercise compiled CLI
processes without installing another testing runtime. A small shell gate also
checks the public wrappers and packaged artifact that Cargo alone would miss.

## Decision
Use package/binary `evosim`, initial version `0.1.0`, Rust edition 2024,
compiler pinned to `1.100.0` (observed installed), minimal toolchain profile with
rustfmt and clippy components. Commit Cargo.lock; all builds use --locked.
Start with no third-party production crates. Version emits a fixed JSON shape
with package version taken from Cargo metadata; command parsing uses std::env.
No JSON input parsing exists yet. Integration tests use serde_json 1.0.154 as a dev dependency to validate stdout
semantically; Cargo.lock pins all transitive dependencies. No production crate
dependencies are present.

Root setup.sh installs the pinned toolchain/components through existing rustup
when needed, builds release, and is idempotent. If rustup is absent, bootstrap it
non-interactively via HTTPS using a temporary installer and explicit error checks;
never overwrite an existing unrelated Rust installation silently. Use curl or wget
already available; if both missing, root may install ca-certificates and curl via
apt. Record any such actual system install and exact command in STATE. Launcher
executes target/release/evosim directly, never cargo, and gives an actionable error
if setup has not completed. build.sh performs a locked release build and copies
only the executable into dist/evosim. Each script resolves its own directory,
quotes paths, works from any cwd, propagates errors, and has executable mode.

Use x86_64-unknown-linux-gnu on Ubuntu 24.04, consistent with ADR-001. Native Rust
needs no Rust runtime installed on the target. Allow only standard Ubuntu base
libraries; audit actual linkage and symbol versions, avoiding -C target-cpu=native.
Do not bundle a compiler, Cargo, source, or build cache. If non-base shared libraries
appear, change dependencies or bundle them with an origin-relative loader path
before claiming portability. Static musl is an alternative if native dependency
constraints cannot be met, but would need an explicit amended decision and setup
prerequisites. Cross-distro portability is not a TASK-002 requirement.

## Consequences and verification
A hand-written parser is adequate for version/help but should be revisited when
run/batch/ui arguments arrive. No simulation API or placeholder successful commands
are introduced. Cargo's ordinary unit/integration/doc tests and fmt/clippy form
one documented ./test.sh gate, followed by wrapper and distribution checks.
Building in the gate costs time but catches stale launcher artifacts. Product
version execution must be offline and independent of cargo/rustup or cwd.
Performance is startup/build cost only; no simulation throughput claim is made.
Record real clean-environment evidence separately from current-container smoke
checks: a restricted PATH alone does not prove missing-runtime portability.

## Implementation evidence
`./test.sh` passes formatting, warning-free Clippy, four Rust process tests and
public wrapper/package checks. A separate clean-source copy in a path containing
spaces builds without target/dist artifacts; missing launcher, compile-error
propagation and output-symlink rejection were verified. Existing .gitignore already
covers target/dist, so it was retained. No engine placeholders were introduced.
`ldd`/`readelf` show only libgcc_s.so.1, libc.so.6 and the ELF loader; maximum
required GLIBC symbol version is 2.34. Copied distribution runs with a restricted
PATH. Docker/Podman are unavailable; a genuinely fresh OS and absent-rustup
bootstrap path have not been tested. This is linkage and current-container evidence,
not a claim of clean-container execution. Re-audit as dependencies are added.

## Cycle 2 verification plan (not executed)
R002-01 requires actual fresh-container evidence, not another restricted-PATH test.
Use an official checksum-verified Ubuntu 24.04 rootfs with user/mount/PID namespace
isolation and a source-only copy; keep host Rust/build caches unavailable. An explicit
tests/fresh-container.sh check will record setup, parsed version, repeat setup and
packaging results. Prefer a separate untouched, network-isolated runtime rootfs.
This retains the accepted production design and avoids a Docker daemon dependency;
namespace creation alone has passed, not the acceptance test. Full sequence and
closure criteria are in tasks/TASK-002/handoffs/plan-cycle2.md.

## Cycle 2 implementation outcome and amendment
Added the explicit environment acceptance runner and six archive regression tests;
./test.sh remains the whole ordinary suite and now also invokes Python 3.12+ unittest
(available in the Ubuntu benchmark). The slow OS provisioning command is separate.
The official Ubuntu Base 24.04.5 archive checksum verified and validated extraction
succeeded, but the planned user namespace could not mount proc or create devices.
A single root UID mapping is also unsuitable for general apt package ownership.
Amend the test-only namespace design to require root with privileged mount/PID
namespaces and, for runtime, a network namespace. No host filesystem/cache mounts
are used; proc and minimal temporary dev are mounted inside the guest rootfs.
The current runtime denies this privileged namespace probe, so the runner exits
nonzero before provisioning. R002-01 stays open. This changes verification tooling,
not product deployment dependencies or accepted Rust/native packaging choices.
Fresh setup, absent-rustup installation and plain offline runtime remain unverified.

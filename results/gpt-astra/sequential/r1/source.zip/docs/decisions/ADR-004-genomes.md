# ADR-004: Bounded diploid traits and immutable species representatives

Status: Accepted in TASK-001 IMPLEMENT cycle 1 (2026-11-21).
Originally proposed in PLAN cycle 1; runtime validation belongs to later tasks.

## Context and alternatives
Traits must be heritable, mutate, and produce stable explicit species identities.
Alternatives considered:
- One scalar trait vector with parental averaging: cheap but loses heterozygosity
  and quickly narrows variation.
- Bit-string/program genomes: flexible evolution but hard to map to bounded,
  explainable behaviors and expensive to validate.
- Fixed diploid bounded numeric loci (choice): interpretable inheritance and cheap
  phenotype/distance calculations at a small fixed number of loci.

## Decision: representation, inheritance and mutation
Each kind has a versioned ordered locus schema. Each locus stores two u16 alleles;
normalized mean allele value maps through a documented bounded phenotype range.
Include speed, strength, maximum health, fertility, lifespan, energy/metabolic
traits, climate tolerances and behavior such as aggression/risk. Kind-specific
loci and physiological bounds will be specified by ecology tasks; schema changes
require checkpoint versioning. Plants may use the same diploid storage even when
reproducing clonally. Phenotypes are derived, never an independent mutable genome.

Sexual reproduction requires two distinct living parents of the same kind/species
and eligible local energy/age conditions. At every locus choose one allele from
each parent's pair using engine RNG (independent assortment); no averaging of
parental genotypes. Plants initially clone both alleles. For either reproductive
path, each transmitted allele independently mutates with configured probability
by a nonzero signed integer step, clamped to u16 range. Rate/step/bounds are
explicit versioned parameters; clamping can make a boundary mutation neutral.
Founders alone use initialization draws; all later organisms come from reproduction.
No global population-dependent creation or protection is allowed.

## Stable species rule
Compare genomes only within one kind. Sort each locus's two raw u16 alleles,
then compute the sum of absolute differences between corresponding sorted
alleles divided by (2 * locus_count * 65535), using raw integer alleles. This
defines a distance in [0, 1] with equal weight per locus; schemas must be nonempty
and match within a kind. This is insensitive to allele order but preserves heterozygosity. A species has an immutable representative
genome and monotonic ID, never a moving centroid. Configure a positive threshold
(default proposal 0.10 in normalized units; tune in later ecology tasks).
At initialization and each birth, assign to the nearest representative whose
distance is <= threshold, breaking ties by species ID. If none qualifies, allocate
a new species ID with this genome as representative. Register offspring in stable
birth order. Membership is fixed for life; never merge or relabel existing members.
Retain extinct representatives in the registry so boundaries do not change on
death; final species counts include only IDs with living members. A lineage may
later return to an old classification by mutation; a kind with zero living members
cannot regrow without parents. An extinct
species label can reappear through offspring of another species of the same kind;
that is classification of a real birth, never spontaneous replenishment. Sexual
offspring may form a new species and then lack mates;
this is a consequence to measure, not to repair through forced replenishment.

## Consequences: performance, tests and distribution
O(loci) inheritance and phenotype decoding is cheap; naive classification costs
O(species*loci) per birth and a retained registry can grow on long runs. Profile
before adding an exact candidate index; do not silently drop old representatives
or change the species rule for performance. Bound/normalize phenotype effects and
account for physiological costs in ecology tasks. The simplified species criterion
is operational, not a claim of biological taxonomy.
Tests cover allele provenance with mutation disabled, seeded mutation replay,
bounds, clonal plants, two-parent eligibility, swapped-allele distance invariance,
threshold equality, stable ties, new species, fixed membership and extinct-species
counting. Checkpoints/hash include schema, both alleles, representative registry,
threshold and next species ID. Numeric structs and standard serialization require
no additional runtime or native library in dist. Ecological coexistence and useful
speciation rates are unmeasured and outside this architecture task.

# ADR-001: Simulation language, runtime and determinism

Status: Accepted in TASK-001 IMPLEMENT cycle 1 (2026-11-21).
Originally proposed in PLAN cycle 1; runtime validation belongs to later tasks.

## Context and alternatives
The engine must support 1,000–5,000 organisms, aim for 100 ticks/s at 2,000,
share behavior with UI, and ship without a separately installed language runtime.
Alternatives considered:
- Python 3 with NumPy: fast development and strong test tooling, but per-organism
  control flow is expensive and bundling Python/native extensions enlarges dist.
- TypeScript/Node: convenient browser integration, but headless packaging requires
  bundling Node and serializable deterministic RNG needs explicit implementation.
- Rust native executable (choice): explicit state ownership, predictable memory,
  fast loops, built-in unit testing and no garbage collector/runtime distribution.

## Decision
Use stable Rust, Cargo, a library engine and thin CLI binary. Pin the selected
compiler in rust-toolchain.toml and dependency versions in Cargo.lock in the later
scaffold task. Favor serde/serde_json for data and a cryptographic digest crate
for state hashing; select exact versions then. No product files are added here.
Use a single-threaded simulation; independent batch seeds may run in parallel.
No dependency from the engine to HTTP, UI, filesystem or wall-clock services.

### Determinism contract
Use a specified, versioned PCG32 implementation with explicit u64 state and odd
stream increment; seed expansion and bounded integer sampling must have test
vectors. Reject biased modulo sampling; draw floating samples using a documented
fixed conversion. All stochastic choices use this engine-owned generator. Save
its exact state, not just the seed. Do not depend on a library's unspecified default
RNG. No OS entropy after initialization, wall time, thread scheduling or hash-map
iteration may influence simulation decisions.
Initialize kinds in plants/herbivores/carnivores order, assign increasing u64 IDs,
and visit cells row-major. At each tick, advance clock/climate/resources, then
process a snapshot of living IDs in ascending order. Apply actions sequentially,
skip organisms killed earlier in the tick and enqueue offspring in parent/action
order; newborns become eligible next tick. Reserve reproduction costs and mark
both sexual parents as having reproduced when the birth is accepted; commit
accepted offspring, IDs, species assignments and birth counters at tick end, even
if a parent dies later in that tick. Checkpoints are taken only at tick boundaries,
so no pending action queue is omitted from saved state. Check partner eligibility at action
time and prevent repeated reproduction within a tick. This ordering has potential
age/ID bias but is reproducible; later changes require an explicit version change.
Sort spatial candidates by ID; resolve equal scores with ID or explicit RNG draws.
Never let unordered storage determine draw order. Use finite f64 values and
stable arithmetic ordering; same-build/same-machine reproducibility is required,
not cross-platform bit equality. Reject NaN/infinite inputs and derived state.

Canonical state encoding has a schema/version, fixed field order, sorted ID
collections, exact float bit encoding and all future-affecting state: effective
configuration, initial counts, totals, organisms/genomes, species registry,
resources, climate/weather, clock, next IDs and RNG state. Hash those bytes;
exclude timing, UI settings and derived spatial caches. Checkpoints preserve the
same state and rebuild caches in deterministic order. Hash and checkpoint
consistency tests must detect omitted fields. Interval sampling cannot consume RNG.

## Consequences: performance, tests and distribution
Rust compilation and ownership add development effort. Avoid premature parallelism;
profile real ecological runs before optimizing. The throughput target remains
unmeasured, not a promise. Unit tests cover RNG vectors and tick ordering;
integration tests compare repeated runs, differing seeds, sample intervals and
split checkpoint runs, including zero organisms and zero ticks.
Build on the Ubuntu 24.04 baseline with native code and no external native library
dependencies beyond base-system libraries. Later build.sh copies binary/assets
into dist; audit linkage and test version/run in a clean Ubuntu image without
Rust, Python or Node. If a dependency introduces extra shared libraries, bundle
those or change the build before release. Engine needs no system packages today.

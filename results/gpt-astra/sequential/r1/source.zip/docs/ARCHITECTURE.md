# Architecture ledger

TASK-002 IMPLEMENT cycle 1: runnable Rust scaffold; engine remains planned.
ADRs 001 through 004 in docs/decisions/ were validated and accepted in this phase.
Runtime verification belongs to later tasks; task completion is controlled by the harness.

## Planned boundaries and dependency direction
Paths below describe the future engine. Only src/main.rs exists today, providing
version/help dispatch; its simulation adapter responsibilities remain planned.
An arrow means the left module may depend on the right module.

| Module / future path | Responsibilities | Allowed dependencies |
| --- | --- | --- |
| model / src/model.rs | IDs, kinds, coordinates, clocks, state records | standard library, serialization |
| config / src/config.rs | JSON fixed keys, defaults, strict types/ranges, effective parameters | model |
| rng / src/rng.rs | versioned PCG32, bounded draws, state | model |
| genetics / src/genetics.rs | genomes, phenotype, inheritance, species registry | model, rng |
| spatial / src/spatial.rs | wrap operations, occupied buckets, query/update | model |
| climate / src/climate.rs | periodic temperature/rainfall, seasons/weather, cell resources | model, rng, config |
| ecology / src/ecology/ | plant/animal local actions, energy, reproduction/death proposals | model, genetics, spatial, climate, rng, config |
| engine / src/engine.rs | authoritative world, initialization, ordered tick actions, counters, snapshots | preceding core modules |
| persistence / src/persistence.rs | versioned checkpoints, canonical state encoding/hash, validation/cache rebuild | model, config, engine state interfaces |
| metrics / src/metrics.rs | living/species counts, samples, trends, result records | model, engine read-only snapshot |
| CLI / src/main.rs | arguments, exit codes, run/batch, file I/O, wall-clock measurement | config, engine, persistence, metrics, UI adapter |
| UI adapter / src/ui.rs | loopback server, ordered session commands, pacing, embedded assets | config, engine, persistence, metrics |
| frontend / web/ | map, controls, inspector/charts, config editor | UI JSON protocol only |

Core is model/config/rng/genetics/spatial/climate/ecology/engine. It has no UI,
HTTP, disk, process, wall-clock or browser dependency. Ecology functions receive
explicit state/context views, not an engine import, avoiding dependency cycles.
CLI and UI orchestrate the same engine; browser rendering cannot alter ecology.

## Planned public interfaces and ownership
- Config::parse/validate -> effective Config; reject missing fixed keys, noninteger
  integer fields, invalid ranges and overflow. Defaults cover every additional key.
- Engine::new(config), advance(ticks), snapshot(), export_state(),
  from_state(validated_state). Advance always executes exactly the requested ticks,
  even for an empty world. A command invocation's tick count is additional ticks.
- WorldState owns effective config, initial counts, clock, RNG, next IDs, organisms,
  genomes/species registry, resources/climate/weather and cumulative birth/death
  counters. An Engine additionally owns the derived spatial cache.
- Spatial query returns deterministic unique IDs; ecology performs current-state
  eligibility checks. Births join at tick end; dead organisms cannot act later. Accepted births reserve
  parental costs immediately and survive subsequent parental death (ADR-001).
  Checkpoints/snapshots expose complete tick boundaries, not partially applied ticks.
- Persistence validates version, dimensions, IDs, genome/state invariants and
  counters before constructing an engine. Hash covers complete authoritative state
  using canonical encoding; derived caches rebuild deterministically (ADR-001).
- Metrics samples invocation start, every K additional ticks, and end without
  duplicates. Loaded runs retain absolute ticks and totals since original tick 0.
  Timing lives only in adapters, outside hashed state; zero-tick throughput is 0.
- Invalid arguments/config/checkpoints exit 2 with stderr and no new result file.
  Validate before opening outputs. Result JSON and all external entry points follow
  docs/CONTRACT.md; only commands belonging to completed later tasks are required.

## Topology and climate plan
Integer grid coordinates wrap in both dimensions. Climate uses periodic functions
of normalized coordinates, with a warm equatorial band and cooler opposing band
rather than two discontinuous cold poles. Temperature/rainfall use periodic spatial
and seasonal terms; weather state is engine-owned and saved. This is a toroidal
latitude analogue, not literal Earth geometry. Evaluate continuity in continuous
coordinates across seams; neighboring discrete cells need not have equal values.
Width/height one must remain valid. Resource regeneration uses documented local
sources and capacity; no global population count can authorize survival/births.

## Packaging and validation boundary
Future root setup.sh/evosim/build.sh resolve paths relative to themselves and work
from any cwd. Setup pins dependencies; distribution embeds browser assets in a
native executable and audits dynamic linkage on Ubuntu 24.04. Offline version/run
must work without language runtimes. UI display uses an installed browser.
No package installs, runtime prototypes or product code are part of TASK-001.
Later tests must cover deterministic replay, checkpoint splits, torus edge cases,
genetic inheritance/speciation, extinction accounting, actual UI capture and clean
packaging. Measured throughput and ecological tuning belong to later tasks.

## Implemented TASK-002 bootstrap

Single Cargo package evosim 0.1.0, edition 2024, Rust 1.100.0 with rustfmt/Clippy.
Cargo.lock pins serde_json 1.0.154 and transitive test dependencies; production
currently uses only std. src/main.rs implements version/help and strict errors.
Root setup.sh provisions Rust and builds release; evosim execs target/release/evosim;
build.sh rebuilds and installs a native executable into dist/evosim, rejecting
output symlinks. All resolve paths relative to themselves. No run/batch/ui yet.

The ./test.sh gate runs setup, formatting, Clippy, Cargo integration tests, repeat
setup from a foreign cwd, packaging and copied-distribution checks. tests/cli.rs
checks semantic JSON, help, error streams/status and non-Unicode arguments.
README documents install/build/test and runtime assumptions. Existing .gitignore
covers target/dist; the lockfile is deliberately not ignored.

Current native linkage is libc.so.6, libgcc_s.so.1 and the ELF loader, maximum
GLIBC requirement 2.34. Restricted-PATH copied execution and clean-source rebuild
passed; fresh OS/container testing remains unperformed (no Docker/Podman).
No additional apt/system dependencies were installed. Later tasks must re-audit
linkage and implement the shared engine rather than duplicating simulation in UI.

## Cycle 2 provisioning verification implementation
No product architecture change. tests/fresh-container.sh invokes a bounded Python
runner that verifies a pinned official Ubuntu rootfs, validates extraction paths
and links, copies a source allowlist, records hashes/statuses and is designed to
exercise setup/version/repeat setup/test/build in a clean guest. A second untouched
rootfs is intended to run the copied dist with a private network namespace.
All backing files remain under /workspace/target. Ordinary ./test.sh now includes
six Python archive-validation tests in addition to four Rust CLI tests; the OS
provisioning check remains an explicit separate command.

The planned single-UID user namespace failed at private proc mount; device creation
also failed. The final runner instead requires privileged mount/PID namespaces so
apt can use ordinary ownership and device setup; this environment rejects that
namespace creation too. Thus guest provisioning and offline runtime execution are
UNVERIFIED, R002-01 remains open, and the helper's end-to-end success path awaits a
capable runtime. Extraction/unit tests and ordinary CLI gates passed. No production
change or extra system package installed. See implement-cycle2 handoffs.

## Cycle 3 verification plan
Production architecture and ADR-005 remain unchanged. The privileged namespace
probe still fails; no alternative working isolation route has been established.
plan-cycle3.md requires runtime capability qualification before rootfs downloads,
then the existing fresh-container runner and durable final-source evidence.
R002-01 remains open; conditional reporting improvements must distinguish fresh
setup evidence from the second untouched runtime check without hiding failures.
No new runner or production implementation is part of this PLAN.

## Cycle 3 implementation outcome
The plan's capability gate failed before guest execution: privileged mount/PID and
network namespace creation each returned Operation not permitted (exit 1).
No production, runner, test or ADR change was justified. Ordinary ./test.sh passed
four Rust and six Python tests plus quality/wrapper/package gates. Fresh setup and
untouched offline Ubuntu execution remain unverified; R002-01 stays OPEN. Runtime
capabilities must be provided before rerunning the existing acceptance runner.
No system dependencies installed. Exact durable evidence is in implement-cycle3
handoffs; no ignored log directory is required to understand the blocker.

## Cycle 4 verification plan
No production architecture or ADR change. Bounded mount/PID and network namespace
probes still fail before guest execution; all 14 source hashes/modes match cycle 3.
plan-cycle4.md retains the existing verified-rootfs acceptance runner and makes
fresh setup evidence and untouched offline runtime outcomes separate claims.
R002-01 stays open until successful final-source fresh setup/version/repeat evidence
exists. No implementation, guest execution or system package install in this PLAN.

## Cycle 4 implementation outcome
Architecture and ADRs unchanged. The initial mount/PID and separate network probes
both returned exit 1, Operation not permitted, before child creation. Following the
plan, no mount/device or guest attempt followed. Fresh setup and untouched runtime
remain unverified; R002-01 stays OPEN. Ordinary ./test.sh passed 4 Rust and 6 Python
tests plus quality/wrapper/package checks. No source or system dependency changes.
Durable commands, statuses and final hashes/modes are in implement-cycle4 handoffs.

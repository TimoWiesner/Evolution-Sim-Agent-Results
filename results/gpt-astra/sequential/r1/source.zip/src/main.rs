use std::{env, process::ExitCode};

const HELP: &str = "Evolution Simulation\n\nUsage: evosim <command>\n\nCommands:\n  version    Print version and interface contract as JSON\n  help       Show this help (also --help, -h)";

fn main() -> ExitCode {
    let args: Vec<_> = env::args_os().skip(1).collect();
    if args.len() == 1 {
        match args[0].to_str() {
            Some("version") => {
                println!(
                    "{{\"name\":\"evosim\",\"version\":\"{}\",\"contract\":1}}",
                    env!("CARGO_PKG_VERSION")
                );
                return ExitCode::SUCCESS;
            }
            Some("--help" | "-h" | "help") => {
                println!("{HELP}");
                return ExitCode::SUCCESS;
            }
            _ => {}
        }
    }
    eprintln!("evosim: expected exactly one supported command\n\n{HELP}");
    ExitCode::from(2)
}

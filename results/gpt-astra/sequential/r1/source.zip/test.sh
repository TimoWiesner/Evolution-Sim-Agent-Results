#!/bin/sh
# Single gate for all tests, code quality, public wrappers and packaging.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
PATH="${CARGO_HOME:-$HOME/.cargo}/bin:$PATH"
export PATH
mkdir -p "$ROOT/target"
CHECK=$(mktemp -d "$ROOT/target/entrypoint-check.XXXXXX")
trap 'rm -rf "$CHECK"' EXIT HUP INT TERM
for entry in setup.sh evosim build.sh; do
    test -x "$ROOT/$entry"
done
"$ROOT/setup.sh"
cargo fmt --all -- --check
cargo clippy --locked --all-targets --target-dir "$ROOT/target" -- -D warnings
cargo test --locked --target-dir "$ROOT/target"
python3 -m unittest discover -s "$ROOT/tests" -p 'test_fresh_container.py' -v
"$ROOT/evosim" version > "$CHECK/expected.json"
# Foreign cwd includes spaces; all wrappers must resolve their own root.
mkdir "$CHECK/foreign cwd"
cd "$CHECK/foreign cwd"
"$ROOT/setup.sh"
"$ROOT/build.sh"
"$ROOT/evosim" version > "$CHECK/launcher.json"
cmp "$CHECK/expected.json" "$CHECK/launcher.json"
mkdir "$CHECK/copied dist"
cp "$ROOT/dist/evosim" "$CHECK/copied dist/evosim"
for binary in "$ROOT/evosim" "$ROOT/dist/evosim" "$CHECK/copied dist/evosim"; do
    PATH=/usr/bin:/bin "$binary" version > "$CHECK/version.json" 2> "$CHECK/stderr"
    cmp "$CHECK/expected.json" "$CHECK/version.json"
    test ! -s "$CHECK/stderr"
    "$binary" --help > "$CHECK/help"
    status=0
    "$binary" unknown > "$CHECK/stdout" 2> "$CHECK/stderr" || status=$?
    test "$status" -eq 2
    test ! -s "$CHECK/stdout"
    test -s "$CHECK/stderr"
done
printf '%s\n' 'PASS: quality gates, CLI tests, idempotent setup, foreign cwd, copied distribution and error status'

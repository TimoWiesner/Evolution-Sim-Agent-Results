# TASK-001 PLAN cycle 1

## Entry evidence and scope
Verified /workspace/AGENTS.md and docs/STATE.md exist; read all requested project,
contract, architecture, task and PLAN instructions plus decisions/README.md.
Inventory found only benchmark documents: no product code, ADRs or prior handoffs.
TASK-001 has no dependencies, hence no dependent handoffs to read. Git started
clean at 4505234, with no remotes. No network Git action or commit was performed.
This phase writes proposed architecture and planning documents only.

## Ordered IMPLEMENT plan (documentation only)
1. Re-read required entry documents, this handoff and the IMPLEMENT skill supplied
   by the phase runner. Preserve contract/task/harness files. Confirm no review gaps
   have appeared; none existed in cycle 1 PLAN.
2. Validate and finalize docs/decisions/ADR-001-core-runtime.md: Rust choice versus
   Python/Node; exact deterministic ordering, RNG state and canonical hashing;
   verify packaging obligations are realistic. No toolchain or Cargo files yet.
3. Validate and finalize ADR-002-ui.md: local browser versus egui/Qt; shared engine,
   embedded offline assets, actual UI automation, browser packaging distinction.
4. Validate and finalize ADR-003-spatial.md: sparse ordered cell buckets versus
   brute force/tree; wrap metric, small-world deduplication, cache maintenance,
   large-radius cost. Do not add an algorithm prototype in this task.
5. Validate and finalize ADR-004-genomes.md: fixed diploid loci versus scalar/program
   genomes; two-parent inheritance, clonal plants, bounded mutation, immutable
   representative rule and living-species counts. Keep future tuning explicit.
6. Resolve inconsistencies across the four records, then mark accepted with task/
   phase provenance. Update docs/ARCHITECTURE.md to match, retaining module paths,
   allowed dependencies, state ownership and CLI/UI independence. Update STATE.md.
7. Run documentation checks below, record exact output, and write the runner's
   IMPLEMENT JSON handoff. Do not create setup.sh, evosim, build.sh, src/, web/,
   scenarios or tests in this task. Do not transition to REVIEW or commit.

## Acceptance-to-evidence map
| Acceptance | Files and verification |
| --- | --- |
| Four decision records | List docs/decisions/ADR-*.md, require exactly the four topics above |
| Alternatives/choice/reasons, performance/tests/dist | Read all four ADRs; each has at least two rejected realistic alternatives plus choice, tradeoffs, verification and packaging consequences |
| Determinism | ADR-001: named RNG/state, stable IDs, action/birth order, tie handling, prohibited nondeterministic inputs and full-state encoding |
| Modules/dependencies, UI-independent core | ARCHITECTURE module table and core boundary, inspect for cycles and ownership ambiguity |
| No product code | git diff --name-only plus git ls-files --others --exclude-standard; only docs and task-local handoff documents allowed |

## Verification commands for IMPLEMENT and REVIEW
- `git diff --check`: whitespace errors must be absent.
- `git status --short` and `git diff --name-only`: inspect all tracked changes.
- `git ls-files --others --exclude-standard`: inspect newly created documents.
- `rg -n 'Status:|alternatives|performance|dist|Tests|tests' docs/decisions/ADR-*.md`:
  navigation aid only; human review must substantiate each acceptance point.
- `cat docs/decisions/ADR-*.md docs/ARCHITECTURE.md`: perform substantive consistency
  review, including 1x1 torus behavior, offspring species identity and load replay.
- `python3 -m json.tool <handoff-path>`: validate the actual phase JSON file.

No runtime tests exist or are appropriate to TASK-001's prohibition on product
implementation. Future runtime test strategies are recorded in each ADR, not
claimed as executed. No system dependencies installed; no install command needed.

## Risks and deferred decisions
Rust performance is plausible but unmeasured; single-thread order can bias old IDs.
Browser snapshots may bottleneck rendering. Species registry grows without bound;
measure long runs before selecting exact acceleration. Genomic thresholds and
trait schemas are proposed architecture with ecology calibration deferred. Climate
storage may limit huge configurations even with sparse entity indexing. Packaging
must be proven in a plain Ubuntu environment later; compiler availability here is
not distribution evidence. These are follow-up risks, not omitted TASK-001 criteria.

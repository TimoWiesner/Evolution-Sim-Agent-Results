# TASK-001 IMPLEMENT cycle 1

## Outcome and scope
Finalized and accepted the four planned ADRs. Read the required entry documents,
both plan handoffs and the IMPLEMENT skill. No dependent tasks or previous review
handoffs exist. No product files or runtime tests were added: task-specific scope
and the ordered plan explicitly prohibit them. No deviation from the plan.

## Acceptance evidence and substantive inspection
- Four records: ADR-001 core/runtime, ADR-002 UI, ADR-003 spatial, ADR-004 genomes.
  Each compares the chosen design with two realistic alternatives, and discusses
  performance, future tests and self-contained distribution consequences.
- ADR-001 chooses Rust versus Python/NumPy and TypeScript/Node; explicit PCG32 state,
  sorted stable IDs, sequential actions, deferred births and canonical complete
  state encoding make replay/checkpoints feasible. Wall time, unordered traversal
  and scheduling cannot affect decisions. Cost reservation and tick-boundary
  checkpoints now remove ambiguity about births whose parents die in the same tick.
- ADR-002 chooses embedded browser assets versus egui and Qt. UI commands reach the
  same engine as headless runs; snapshots are read-only. Actual Chromium captures
  and shutdown deadlines are specified. Browser availability is needed for viewing
  UI; plain-Ubuntu version/run must work without it or a language runtime.
- ADR-003 chooses occupied cell buckets versus brute force and trees. Wrapped
  Chebyshev distance and unique coordinate enumeration cover 1x1 and oversized
  radii; scanning occupied keys avoids empty-area loops. Cache updates/rebuilds
  preserve deterministic candidates. Worst-case query cost remains documented.
- ADR-004 chooses diploid numeric loci versus averaging and program genomes.
  Two-parent allele provenance, bounded mutation and immutable representatives
  define inheritance/speciation. Clarified the exact distance denominator and
  that reappearance of an extinct species label requires a real birth in its kind.
- ARCHITECTURE lists modules, responsibilities and allowed dependencies. The core
  does not import adapters; ecology receives explicit context rather than importing
  engine, preventing a cycle. Persistence operates on state interfaces; UI/CLI
  share engine advance. Hash includes authoritative state and excludes only derived
  caches and presentation/timing data.
- Changed-file inspection permits only docs and this task's handoffs; no source,
  entry points, dependency manifests, benchmark files or task specs changed.

## Validation and limitations
Exact commands, exit codes and observations are in implement-cycle1.json.
Structural ADR checks supplement the substantive inspection above; they do not
prove runtime behavior. No runtime tests exist or ran. Throughput, linkage, ecology
and browser performance await owning tasks. No packages installed, no system
install commands required, no remotes configured, and no commits made.

## Next phase context
The harness may initiate REVIEW; this phase does not do so. Review the acceptance
map and accepted ADRs. Future implementation tasks must pin compiler/crates, test
PCG vectors and checkpoint replay, measure species-registry/query growth, and prove
offline native packaging on plain Ubuntu. Trait ranges and ecological tuning remain
explicitly deferred to their owning tasks, not omitted architecture criteria.

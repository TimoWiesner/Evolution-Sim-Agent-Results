# TASK-002 PLAN cycle 3

## Outcome and scope
Documentation-only replan. R002-01 is explicitly addressed below but remains OPEN
and environmentally BLOCKED. A plan cannot truthfully close an execution-evidence
gap. No fresh setup/version succeeded in this phase. The PLAN skill's instruction
to close every review gap is satisfied only when the closure evidence below exists;
this handoff does not assert that it does. No task requirement is waived.

Read required project/task documents, current PLAN skill, all prior TASK-002 and
TASK-001 handoffs, ADRs 001–005, and inspected current source/scripts/tests/README.
TASK-001 review PASS has no gaps. Both TASK-002 reviews identify only R002-01;
cycle-2 review independently passed the ordinary suite (4 Rust + 6 Python tests).
Those are prior results, not tests rerun in this PLAN. Entry tree clean, no remotes.
No code, dependency, protected file, task-state, commit or phase changes.

## Current feasibility and decision
A bounded subprocess probe reconfirmed:
- `unshare --mount --pid --fork true`: exit 1, Operation not permitted.
- `unshare --user --map-root-user --mount --pid --fork true`: exit 0.
- PATH inventory via Python shutil.which: docker, podman, newuidmap, bwrap, proot,
  qemu-system-x86_64 absent; unshare and chroot available.

The second probe only creates namespaces; cycle 2 already proved its proc mount
and device setup insufficient. Do not repeat the failed single-UID design or infer
usable isolation from this exit 0. No alternate genuine-container route has been
established. Installing Docker, proot or QEMU is not selected as speculative work:
a command's presence does not establish permissions, and emulated/chroot execution
must not be silently relabeled as the required fresh container evidence.

Retain ADR-005 production design and existing tests/fresh-container.sh interface.
The concrete prerequisite is an orchestrator-provided runtime for this same local
workspace that permits mount/PID/network namespaces, private proc/tmpfs mounts and
character device creation. The agent must not alter host security configuration,
read host files outside /workspace, use external hosting or upload the repository.
This phase cannot provision that prerequisite with the available permissions. No
interactive permission question is requested. If it remains absent in IMPLEMENT,
record the blocker promptly rather than consume 30 minutes repeating failed runs.

## Ordered implementation plan (only when assigned IMPLEMENT)
1. Read the assigned skill and handoffs. Preserve TASK-002 scope: no simulation,
   run/batch/ui, toolchain redesign or unrelated changes. Recheck local Git status
   and empty remotes. Allocate at most 3 minutes to capability qualification,
   20 minutes to fresh validation, and reserve 7 minutes for checks and handoff.
2. Qualify the runtime before OS downloads. The existing runner's first probe is
   necessary but not sufficient. In an owned directory under /workspace/target,
   use a child private mount/PID namespace to make mount propagation private,
   mount private proc and tmpfs, create null/zero/random/urandom devices and execute
   a trivial child. Probe network namespace creation separately. Use bounded
   commands and namespace teardown; verify no surviving child/mount. Record exact
   commands, exit codes and stderr. Do not read host /proc or /etc to diagnose it.
   If unavailable, stop the environment attempt, preserve OPEN R002-01, and write
   honest IMPLEMENT handoffs. No product patch can cure this runtime restriction.
3. If qualification succeeds, retain the current verified-rootfs algorithm in
   tests/fresh_container.py: pinned official Ubuntu Base archive and published
   checksum; safe extraction; explicit source allowlist; new guest home; no host
   target/dist/toolchain caches; clean environment; explicit guest DNS. Reuse only
   verified archive bytes if desired, never a previously provisioned guest. Record
   the final source hashes including executable modes, archive URL/hash, and guest
   OS/package/tool provenance. The existing archive pin is in ADR-005/history;
   validate it at execution time rather than assume a download still exists.
4. Run `/workspace/tests/fresh-container.sh` (20-minute outer timeout) and capture
   the printed evidence path. Guest-only prerequisites remain exactly:
   `apt-get update` and
   `apt-get install -y --no-install-recommends build-essential ca-certificates curl python3 nodejs`.
   No host apt install is planned. Setup installs Rust 1.100.0 itself; record this
   absent-Rust bootstrap variant, which is stronger than the benchmark baseline.
   Required guest command sequence already exists in GUEST:
   setup -> version -> foreign-cwd repeat setup -> version -> test -> build ->
   dist-version. Each must have recorded status, stdout and stderr. Parse sole JSON
   equal to {"name":"evosim","version":"0.1.0","contract":1}; stderr empty.
   Capture clean-entry assertions before setup and actual tool versions afterward.
5. Preserve successful evidence as soon as obtained. If an actual later failure
   obscures earlier success, amend tests/fresh_container.py reporting minimally:
   distinct setup/version/repeat-setup, suite/build and runtime outcomes; persist
   semantic assertions immediately after their corresponding stage, including
   timeouts and command statuses. Never change a failed overall exit to success.
   R002-01 evidence and the second-rootfs runtime evidence are separate claims;
   the latter's failure must remain reported even if the former succeeded.
   This reporting change is conditional, not a prerequisite for running existing
   tooling. Add focused Python tests only if new report logic is implemented,
   covering failed setup, invalid JSON and later failure preserving earlier facts.
6. Fix only defects reproduced by real guest execution. Candidate files are
   tests/fresh_container.py and tests/fresh-container.sh for runner defects,
   setup.sh/build.sh only for actual product provisioning/package failures, and
   README.md for accurate invocation/requirements. Keep production pins and CLI
   semantics unless evidence justifies an explicit ADR amendment. After any source
   change, regenerate hashes and rerun against a newly extracted guest; a passing
   result for old hashes does not certify final code. If time cannot accommodate
   the rerun, record incomplete verification rather than claim closure.
7. Run ./test.sh on final sources (expect 4 Rust and 6 existing Python tests plus
   any meaningful added tests, fmt/Clippy and wrapper/package gates). Complete the
   runner's second untouched Ubuntu rootfs execution of copied dist, with no
   runtimes and private network namespace, when possible. Record package inventory,
   linkage and parsed version. Do not install libraries into the runtime rootfs
   and then call it untouched; fix distribution contents if a dependency is absent.
8. Write durable material evidence into the assigned implement-cycle3.json/md:
   successful/failing commands and statuses, sole parsed JSON, source hashes and
   modes, rootfs provenance, guest dependency versions/install commands, elapsed
   time and isolation/cache facts. Ignored log paths alone are insufficient.
   Update STATE and ARCHITECTURE with actual outcomes; amend ADR-005 only for a
   real design change. Run git diff --check, JSON/schema/scope checks, inspect
   ignored output and leave phase transitions and commits to the orchestrator.

## Acceptance and review gap closure
| Requirement | Planned final evidence |
| --- | --- |
| Executable setup/launcher/build, cwd independence | ./test.sh and guest repeat setup from foreign cwd |
| Fresh setup/version: R002-01 | Qualified isolated fresh Ubuntu rootfs, source-only manifest, clean entry, setup exit 0, sole semantic version JSON/empty stderr, repeat setup/version exit 0, durable provenance |
| dist executable and version | ./build.sh, guest dist-version, ordinary copied artifact gate; second untouched runtime result reported separately |
| Help and unknown command exit 2 | Existing Rust CLI tests and shell wrapper checks in ./test.sh |
| One documented suite with passing tests | ./test.sh exit 0 and actual counts; environment check stays separately documented |
| README and ignored output | Read README against commands; git check-ignore target/probe dist/probe; git ls-files target dist empty |

There is exactly one existing review gap, R002-01. Steps 1–4 and 8 specify its
resolution; status stays OPEN until execution establishes every required fact.
Current-container tests, archive extraction, clean source copies, a successful
namespace-only probe or planned commands cannot close it. If infrastructure remains
unchanged, IMPLEMENT should report an environmental blocker and REVIEW must assess
the unmet criterion honestly. max_cycles=3 is harness-owned and grants no waiver.

## Risks and current validation
No system dependencies installed; no additional installation command is needed.
Current probes do not establish mount/device/network or guest download capability.
Even a capable runtime may reveal DNS, apt, rustup or helper defects; its success
path remains untested. Complete bounded attempts and preserve handoff time.
This PLAN ran only file/Git inspections, tool inventory, namespace probes and
planning-document checks. No product tests or fresh provisioning were run.

# TASK-002 PLAN cycle 1

## Entry findings and scope
Verified required entry files before reading. Read AGENTS, PROJECT, CONTRACT, STATE,
ARCHITECTURE, TASK-002 task.md/task.json, PLAN skill, all four accepted ADRs and all
six TASK-001 handoff files. TASK-002 handoffs directory was empty. TASK-001 review
is PASS with no gaps. Git entry was clean, HEAD 751ea22, no remotes. Only documents
exist: no Cargo project, README, entry points or tests. No code is added in PLAN.
No interactive questions, packages, Git network operations, commits or transitions.

Observed tools: rustc 1.100.0, Cargo 1.100.0, rustup 1.29.3; x86_64; cc, readelf,
ldd and chroot available. No clean-container capability has been established.
Prior architecture is accepted; ADR-005 proposes only bootstrap details.

## Ordered implementation plan
1. Read current phase instructions, this JSON/Markdown handoff and required docs.
   Recheck working tree and prerequisites. Accept or explicitly amend ADR-005 based
   on actual compiler/component/dependency availability. Stay within TASK-002.
2. Add Cargo.toml, Cargo.lock, rust-toolchain.toml and src/main.rs. Single evosim
   package version 0.1.0, edition 2024, Rust 1.100.0, minimal profile plus fmt/clippy.
   Do not create empty future engine modules merely to match architecture paths.
   Parse complete arguments (including non-Unicode handling without panic):
   - Exactly `version`: exit 0, one JSON object plus newline on stdout, fields
     name="evosim", version=CARGO_PKG_VERSION, contract=1; empty stderr.
   - `--help`, `-h`, or `help`: exit 0, readable usage listing only version/help.
   - No args: usage and diagnostic on stderr, exit 2 (explicit local choice).
   - Unknown commands/options, trailing arguments: exit 2, diagnostic on stderr,
     no stdout; run/batch/ui currently count as unsupported commands.
   Keep dispatch small; future adapters will call the shared library engine when
   it exists. No simulation, config, web UI or checkpoint placeholders.
3. Add executable setup.sh, evosim and build.sh with fail-fast shell behavior and
   script-relative root paths (spaces supported). Setup installs the pinned
   toolchain/components if missing, fetches locked dev dependencies as needed and
   builds release; rerunning succeeds. Handle absent rustup as ADR-005 describes.
   Launcher directly execs the built binary and forwards all arguments/status.
   Missing binary yields stderr guidance to run setup and nonzero exit.
   Build compiles release --locked, creates dist, and copies executable with mode
   preserved. Do not erase unrelated files or traverse symlinks destructively.
   No runtime network access or compilation in either product launcher.
4. Add tests/cli.rs using Rust process tests and CARGO_BIN_EXE_evosim. Validate
   JSON fields/types and sole-object stdout; help command list/status; empty args,
   unknown command, invalid flag and extra args => 2/stderr/no stdout. Use a locked
   serde_json dev dependency if needed for semantic JSON checking. Tests must fail
   for deliberately malformed version output or incorrect exit status.
5. Add executable test.sh as the sole documented whole-suite command. Resolve
   root; run cargo fmt --all -- --check, cargo clippy --locked --all-targets -- -D
   warnings, cargo test --locked, then build/package and public-entrypoint smoke
   checks. Store temporary check data under ignored target/, clean only owned temp
   paths. Cover two setup invocations, all three executable modes, root and foreign
   cwd calls, launcher/dist version equality and unknown-command status. Avoid
   recursion between test.sh and build.sh. Future tests join this same gate.
6. Add .gitignore for /target/, /dist/ and any actual generated scratch files;
   do not ignore Cargo.lock. Add README.md covering prerequisites, ./setup.sh,
   ./evosim version/--help, ./build.sh, ./dist/evosim version and ./test.sh;
   explain no simulation commands yet and offline execution after setup/build.
   State Ubuntu 24.04 x86-64 target and installed build tools versus runtime needs.
7. Execute acceptance checks below. Inspect linkage with ldd and readelf; run a
   copied dist outside the repo with PATH lacking toolchains. Prefer a genuinely
   plain Ubuntu 24.04 container if available, with network disabled and only copied
   dist mounted, and test version there. Any fixtures/work directories must stay
   inside /workspace under this task's access constraint. If clean-container
   execution is unavailable, record that limitation plus exact linkage evidence;
   do not claim fresh-container testing from a normal local run or stripped PATH.
   A clean source copy excluding target/dist proves rebuild independence, but is
   also not a fresh OS. Do not access benchmark reference checks.
8. Update STATE, ARCHITECTURE (distinguish implemented scaffold from planned core)
   and ADR-005 status. Record dependencies/install commands, exact test results,
   portability evidence and limitations in IMPLEMENT handoffs specified by runner.
   Do not modify task files, protected docs, benchmark tools/state, or commit.

## Acceptance-to-evidence map and planned commands
These commands have NOT run in PLAN; IMPLEMENT records exact invocations/results.

| Criterion | Evidence to produce |
| --- | --- |
| Three entry points per contract | `test -x setup.sh && test -x evosim && test -x build.sh`; run each via absolute paths from /workspace/target/foreign-cwd; rerun setup; demonstrate propagated nonzero build failures where practical |
| Version after setup | `./setup.sh` twice, `./evosim version`; integration test parses exactly one JSON object with expected fields/types; fresh-source and preferably fresh-container setup evidence |
| Self-contained dist | `./build.sh && ./dist/evosim version`; `ldd dist/evosim`; `readelf -d dist/evosim`; `readelf --version-info dist/evosim`; copy dist to target/package-check and execute there with restricted PATH, preferably plain Ubuntu offline |
| Help and errors | `./evosim --help`, `./evosim unknown` (expected 2); process tests assert streams/status and trailing-argument rejection on compiled CLI; repeat public error check for dist |
| Whole suite | `./test.sh` exit 0; capture test counts and fmt/clippy/package results; Cargo tests are real behavior checks, not only file-existence tests |
| README and ignores | Review commands against actual scripts; `git check-ignore target/probe dist/probe`; `git ls-files dist target` empty; Cargo.lock tracked for eventual harness commit |

Also run `git diff --check`, inspect `git status --short`, validate IMPLEMENT JSON
via `python3 -m json.tool <actual path>`. Keep timing/diagnostics out of version
stdout. README command examples must work without needing current shell cd tricks.

## Risks and follow-up
- Rustup/toolchain or crate retrieval can fail; fail visibly and report exact cause.
  Pin locally observed 1.100.0, not floating stable. No network probing needed in
  PLAN; IMPLEMENT verifies provisioning. Do not install UI dependencies yet.
- Existing compiler does not prove fresh-container setup or clean distro linkage.
  New native dependencies must be re-audited in later tasks; this gate initially
  certifies version only, with run explicitly owned by later tasks.
- Stale release binaries can hide source changes: test gate rebuilds first.
- Shell quoting, executable bits, cwd independence and exit propagation are public
  behavior, so Cargo tests alone are insufficient.
- No prior review gaps to close. No blockers identified; runtime acceptance remains
  entirely unverified until IMPLEMENT. Plan does not certify any product behavior.

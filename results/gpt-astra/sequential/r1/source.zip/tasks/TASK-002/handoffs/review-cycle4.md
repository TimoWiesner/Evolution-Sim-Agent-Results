# TASK-002 REVIEW cycle 4

Verdict: FAIL. R002-01 remains OPEN / environmentally BLOCKED. No new product
behavior defect reproduced. Inspected implementation diff aab4f02..2b3127f,
current scripts/CLI/tests, required documents, task/dependency handoffs and ADRs.
The implementation follows the plan's documentation-only blocked branch. All 14
source hashes/modes match its manifest. Entry tree clean; Git remotes empty.
Commit subjects saying PASS do not override substantive review verdicts.

## Acceptance evidence

| Must have | Independent review result |
| --- | --- |
| Executable setup/launcher/build, cwd independence | PASS in current container: modes and ./test.sh wrapper checks. |
| Version after setup in fresh container | FAIL: R002-01, no fresh guest setup/version executed. |
| Build produces dist/evosim and version works | PASS: ./test.sh builds and checks native/copied distribution. Fresh plain-OS runtime remains unverified. |
| Help and unknown-command exit 2 | PASS: Rust process tests and wrapper tests; also malformed/non-Unicode arguments. |
| One documented suite and passing tests | PASS: ./test.sh exit 0; 4 Rust and 6 Python tests, fmt/Clippy and packaging checks. |
| README install/build/test, ignored outputs | PASS: instructions match scripts; target/dist ignored and untracked. |

## Reproduced blocker and remediation

./tests/fresh-container.sh exited 1. Its initial command
`unshare --mount --pid --fork true` exited 1 with
`unshare: unshare failed: Operation not permitted`.
Report /workspace/target/fresh-container.nemdzja1/report.json records passed=false,
failure="namespace-probe: exit 1", elapsed_seconds=0.001. Material report is also
embedded in the JSON handoff. No download, extraction, guest apt/setup/version,
network-isolated runtime, child namespace or mount occurred. Configured rootfs
provenance is not evidence of a new download/checksum verification.

Next authorized PLAN must secure a capable fresh Ubuntu 24.04 environment. Existing
runner requires privileged mount/PID namespaces, private proc/tmpfs mounts and
character-device creation; its separate offline runtime uses network isolation.
Preserve final source hashes/modes, clean entry and cache isolation, environment
provenance, successful setup and foreign-cwd repeat setup, exact statuses/streams
and sole parsed version object with empty stderr. Report offline runtime separately.
Fix exposed defects only in authorized IMPLEMENT and rerun final-source checks.
Current-container, clean-source or restricted-PATH checks cannot close R002-01.

No product/tests/ADRs changed or system packages installed. Architecture remains
accurate; STATE and review handoffs record this outcome. Existing dependency install
commands remain current. No protected-file or task-state edits, commits, Git network
operations or phase transition. The explicit cycle-4 assignment was followed;
cycle limits and next workflow belong to the harness. External checks authoritative.

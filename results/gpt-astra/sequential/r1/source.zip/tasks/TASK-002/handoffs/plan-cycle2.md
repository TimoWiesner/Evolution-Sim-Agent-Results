# TASK-002 PLAN cycle 2

## Scope and entry findings
Documentation-only replan for R002-01. Read all required project/task documents,
all TASK-002 and dependency TASK-001 handoffs, ADRs 001–005, and PLAN skill.
Inspected every bootstrap source, script, test, README and ignore file. TASK-001
review has no gaps. The TASK-002 review JSON/Markdown says FAIL despite the
orchestrator commit subject ending PASS; use the substantive review finding.
Entry worktree clean, no remotes. No feature changes, installs or phase transition.

The one gap is missing fresh-container setup/version evidence. Four integration
tests and wrapper/package checks passed in prior IMPLEMENT and REVIEW; they were
not rerun in PLAN. Do not redesign the CLI or add simulation behavior.

## Feasibility established in PLAN
`command -v docker podman unshare chroot debootstrap proot bwrap curl wget || true`
found unshare, chroot, curl and wget; no Docker/Podman/debootstrap/proot/bwrap.
`unshare --user --map-root-user --mount --pid --fork true` exited 0. This is only
namespace capability evidence, not a container provisioning or acceptance test.
A fresh downloaded Ubuntu root filesystem plus user/mount/PID namespaces and
chroot can provide a real isolated userspace without a Docker daemon. All backing
files, downloads, scratch directories and evidence must stay under /workspace.
A plain chroot or source copy alone is not the selected proof.

## Ordered implementation plan
1. Re-read the assigned IMPLEMENT instructions and this handoff. Recheck namespace
   support and executable prerequisites. Budget about 5 minutes for provisioning
   feasibility, 15 for download/build/checks, 5 for regression, 5 for handoff.
   No long ecology or simulation runs belong here.
2. Add a reproducible acceptance script at `tests/fresh-container.sh` and document
   its explicit invocation in README. This is a provisioning integration check,
   separate from ordinary repeated `./test.sh` development runs; do not make the
   regular suite download an OS every time. Explain both commands and their scope.
   Script returns nonzero on provisioning/assertion failure, never success/skip
   when isolation is unavailable. Avoid recursion into itself from test.sh.
3. Obtain an official Ubuntu 24.04 amd64 minimal/base rootfs over HTTPS, resolving
   and recording the exact release URL and published checksum during IMPLEMENT.
   Verify checksum before use; record provenance, archive SHA-256, architecture,
   release and download command. Do not invent a checksum or rely only on a mutable
   latest URL. Store archive and rootfs beneath a newly created
   `/workspace/target/fresh-container.*` owned directory. Extract without importing
   host ownership or following archive paths outside that directory; inspect archive
   names/links before extraction. Use Ubuntu-provided rootfs, not host library copies.
4. Launch a private mount/PID/user namespace, make mounts private, chroot into that
   rootfs and mount a private proc filesystem there. Provide only the minimal
   device facilities needed by apt/Rust (null, zero, random, urandom); avoid host
   root/home/cache mounts. All mount targets and real filesystem paths reside under
   the owned workspace directory. Set up guest DNS explicitly, recording its source;
   do not read host configuration outside /workspace. Network may be shared for
   provisioning; document this. A new network namespace is required for the later
   offline runtime check, not for setup downloads. Use clean environment variables,
   no inherited RUSTUP_HOME/CARGO_HOME/toolchain/proxy cache paths. Establish a fresh
   guest home and no preexisting cargo/rustup or project target/dist caches.
5. Record guest OS release, architecture, tool versions, namespace invocation and
   package manifest. Provision only benchmark base dependencies inside the guest:
   `apt-get update` and
   `apt-get install -y --no-install-recommends build-essential ca-certificates curl python3 nodejs`.
   Rust may start absent so setup itself exercises its advertised rustup bootstrap;
   disclose this stronger bootstrap variant relative to benchmark's preinstalled
   Rust. Then setup's second run exercises its existing-rustup branch. Python/Node
   are base tooling, never required by the produced native runtime. Record exact
   commands and installed versions in STATE and evidence. If reproducing the exact
   benchmark Rust-present baseline additionally, bootstrap rustup in a second fresh
   rootfs without project artifacts and repeat the same acceptance sequence.
6. Copy only an explicit source allowlist into guest `/workspace/project`: Cargo.toml,
   Cargo.lock, rust-toolchain.toml, setup.sh, evosim, build.sh, test.sh, src/, tests/,
   README.md and .gitignore. No .git, target, dist, host homes or caches. Preserve
   executable modes and record source hashes. Guest paths are backed by the host
   workspace rootfs, not additional host project roots. Before setup assert no
   target/dist, release binary or Rust cache. Capture each command/status and stdout
   and stderr separately; avoid pipelines that hide failure. Run:
   - `./setup.sh`, then `./evosim version`;
   - parse exactly one JSON object equal to
     {"name":"evosim","version":"0.1.0","contract":1}, with empty stderr;
   - repeat `./setup.sh` then the same version assertion;
   - `./test.sh` (four integration tests plus formatting/Clippy/wrapper checks);
   - `./build.sh` then the same parsed assertion for `./dist/evosim version`.
   Use foreign working directory invocation for at least the second setup/version.
   Bound downloads and outer execution with timeouts and keep diagnostics available.
7. Prefer also a SECOND untouched rootfs from the verified archive for runtime:
   copy only dist, install no compiler/interpreter/project dependencies, execute
   version in a new network namespace with no external interface. Record package
   inventory showing no language runtimes and parsed version/status/streams. Inspect
   ELF linkage and GLIBC symbol requirements. If this extra runtime proof is blocked,
   record it separately; it does not erase successful setup evidence for R002-01.
8. Fix setup.sh/build.sh only if these checks reproduce a defect. Keep existing
   version/help behavior and Rust architecture. Changes to toolchain pins require
   evidence and a consistent manifest/lockfile/ADR update, not an arbitrary downgrade.
   Run `./test.sh` on the final workspace sources and repeat fresh-container checks
   after any setup/product change so source hashes identify the tested final code.
9. Persist concise evidence in `tasks/TASK-002/handoffs/implement-cycle2.md` and the
   runner-specified JSON: exact commands, statuses, parsed output, rootfs provenance,
   source digest, guest package/tool versions, elapsed time, bootstrap conditions,
   isolation/mount/cache/network facts. Keep raw logs under target while copying the
   material evidence into tracked handoffs; paths to disposable logs alone are not
   cross-phase evidence. Update STATE, ARCHITECTURE and ADR-005 with actual outcomes.
   Clean owned mounts/processes on failure/timeout before deleting owned scratch.
   Do not commit, change task states, read external host files or start REVIEW.

## Acceptance mapping and closure rule
| Criterion | Required evidence in IMPLEMENT |
| --- | --- |
| Executable setup/launcher/build, cwd independence | Existing ./test.sh rerun, mode checks and fresh guest repeat setup from foreign cwd |
| Fresh container setup/version (R002-01) | Verified Ubuntu rootfs, isolated clean userspace/source manifest, successful setup + semantic version assertion + repeat setup, exact commands/statuses |
| Build dist/version | Fresh build and parsed packaged version; linkage audit; preferably second plain offline rootfs |
| Help and unknown status 2 | Existing four CLI tests and wrapper gate, no change in command scope |
| One whole-suite command | ./test.sh exit 0; additional environment acceptance invocation clearly documented |
| README/ignored output | README install/build/test/container instructions; git check-ignore target/probe dist/probe; no tracked target/dist files |

R002-01 is explicitly addressed by steps 2–6 and 9, but remains OPEN until actual
fresh-container evidence exists. No review requirement is waived. If namespaces,
rootfs network, apt or Rust downloads prevent completion, preserve exact failure,
remaining time and remediation; return honest incomplete evidence rather than label
source-copy/restricted-PATH execution a fresh-container pass. Do not spend the whole
phase installing Docker or fall back to fabricated success.

## Decisions, risks and validation
Retain all accepted production ADR choices, layout, Cargo tests and native GNU/Linux
packaging. Extend ADR-005 only with the planned container evidence protocol.
No algorithm or simulation API changes. No packages installed in PLAN.
Namespace success does not guarantee mounts, apt networking or installer success;
IMPLEMENT must test those. Fresh Rust downloads can consume the phase budget.
Ubuntu base may omit libgcc needed by the binary: observe runtime failure and bundle
or explicitly resolve it if necessary, never assume host linkage proves portability.
Plan checks are required-file existence, namespace probe, whitespace and structured
handoff/scope validation. No product test result is claimed for this phase.

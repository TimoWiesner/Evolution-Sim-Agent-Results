# TASK-002 IMPLEMENT cycle 1

Implemented the approved bootstrap plan: Cargo manifest/lockfile/toolchain pin,
version/help CLI, executable setup/launcher/build scripts, four process tests,
whole-suite test.sh and README. ADR-005 accepted; architecture/state updated.
No simulation commands, engine placeholders, task-state edits or commits.

## Acceptance evidence

- setup.sh, evosim, build.sh executable modes are checked by ./test.sh. Setup runs
  twice in the gate, once from a foreign cwd; build and launcher also work there.
- Version stdout is semantically parsed by serde_json, exactly matching name
  evosim, version 0.1.0, contract 1. stderr is empty and status is 0.
- build.sh creates dist/evosim; native and copied binaries return the same JSON
  with restricted PATH. Unknown command status 2 propagates through both.
- Help aliases list version/help. Empty args, unknown flags/commands, trailing
  args and non-Unicode args return status 2 with stderr and empty stdout.
- ./test.sh passed: fmt, Clippy -D warnings, four integration tests (0 failures),
  idempotent setup, packaging and wrapper checks. Rust main has no unit tests;
  the process tests exercise the complete tiny command interface.
- README covers installation, build, whole-suite command, packaging and scope.
  Existing .gitignore already covers target/dist and was intentionally unchanged.
  git check-ignore confirms both; git ls-files dist target returned no files.

## Additional checks and limits

The JSON contains exact commands and results. A temporary source copy under
/workspace/target with spaces in its root built without existing artifacts. Its
missing launcher produced actionable status 1; deliberate bad Rust caused setup
and build to return nonzero. A dist/evosim symlink was rejected without modifying
its target. Temporary check paths were removed by their owning test only.

ldd/readelf identify libc.so.6, libgcc_s.so.1 and ld-linux-x86-64.so.2; maximum
required GLIBC version 2.34. No Docker or Podman found. No genuinely fresh OS test,
network-isolated container test, or missing-rustup installer test was performed.
Restricted PATH and clean source are narrower evidence and not substitutes.
No apt packages installed. Rustup downloaded the pinned toolchain/components;
serde_json 1.0.154 and locked test dependencies were downloaded by Cargo.
STATE records provisioning and optional apt fallback commands.

## Deviations and follow-up

No scope/design deviation. Reused existing ignore rules rather than editing them.
Fresh-container verification was unavailable through installed container tools,
as anticipated by the plan; preserve this limitation for review. Later dependency
changes must repeat linkage checks, and future tasks add engine tests to test.sh.
Review is harness-controlled; this phase does not initiate it or claim PASS.

# TASK-002 IMPLEMENT cycle 2

## Outcome
Implementation tooling added; required fresh-container evidence remains BLOCKED.
R002-01 is OPEN, not waived. No product defect reproduced and no production
setup/build/CLI code changed. No commits, Git network operations, task-state edits,
protected-file edits, or phase transitions. No interactive questions asked.

Read all required project documents, TASK-002 task and previous handoffs, dependency
TASK-001 handoffs, ADRs 001–005 and IMPLEMENT skill. Entry worktree clean; no remotes.

## Changes and tests
- tests/fresh-container.sh is executable and runs the Python acceptance helper with
  a 1200-second outer timeout and 15-second kill grace. Commands have captured logs,
  recorded exit status, and a 900-second subprocess ceiling; downloads cap at 180s.
- tests/fresh_container.py pins official Ubuntu Base 24.04.5 amd64 and verifies
  the published HTTPS checksum plus downloaded bytes. Before extraction it rejects
  traversal, writes through links, special files and invalid hardlink targets;
  converts guest absolute symlinks to equivalent rootfs-relative links; Python's
  data extraction filter strips archive ownership. All backing files stay in target.
- Source allowlist excludes .git, target/dist and host caches. The helper intends
  to provision apt dependencies, run setup/version/repeat/test/build and separately
  execute dist in an untouched network-isolated runtime. These guest steps DID NOT
  execute here. The success path is implemented but not end-to-end validated.
- Six regression tests exercise archive contents and rejected unsafe cases. They
  join the four Rust CLI integration tests in ./test.sh. Python 3.12.3 is preinstalled.
- README documents ordinary tests, explicit slow environment test and its privileges.
  STATE/ARCHITECTURE/ADR-005 record actual failures and the verification amendment.

Final `./test.sh`: exit 0, 4 Rust integration tests and 6 Python tests passed,
0 failures; formatting, Clippy -D warnings, repeat setup, foreign cwd, copied
native distribution, version/help/error status checks all passed. No simulation
commands or future engine behavior implemented or claimed.

## Fresh environment evidence and exact blockers
Official URL:
https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-amd64.tar.gz
Published checksum list:
https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/SHA256SUMS
SHA-256: e77b6f10c2590cef872b33ee9f635a0e3fd1f57fb074c0e52b5c7f56147a0c86

Downloads used `curl --proto =https -fL --connect-timeout 20 --max-time 180 URL -o PATH`,
exited 0, and both checksum assertions passed. Paths are under the printed owned
/workspace/target/fresh-container.* directory. No host DNS/configuration files read;
the intended guest resolver is explicitly 1.1.1.1, network shared only for downloads.
No DNS success inside the guest is claimed.

1. First runner attempt (`target/fresh-container._bpi2un6`): exit 1 because archive
   validation rejected a legitimate hard link usr/bin/perl5.38.2. Fixed by requiring
   hard links to name regular archive files; regression tests cover this case.
2. Revised user-namespace attempt (`target/fresh-container.v8cdt8vx`): extraction
   succeeded, build-container exited 32 on private proc mount, runner exit 1.
3. Further attempt (`target/fresh-container.gv__ilqc`, 3.122 seconds): same failure;
   `unshare --user --map-root-user --mount --pid --fork true` exits 0, but the actual
   namespace init's `mount -t proc proc "$rootfs/proc"` reports permission denied.
   Source manifest digest for this PRE-amendment attempt is
   0c6741725bd6f280e85188bb17212896fbb3d77abae5aeb090baea0b016fd78d.
   This is not a passing test or a final-code execution certificate.
4. Diagnostic `unshare --mount --pid --fork --kill-child sh -c 'mount --make-rprivate / && mount -t proc proc /workspace/target/fresh-container.v8cdt8vx/build-rootfs/proc'`
   exits 1: `unshare: unshare failed: Operation not permitted`.
5. Diagnostic user/mount/PID namespace could mount tmpfs on the owned rootfs/dev,
   but `mknod -m 666 .../dev/null c 1 3` exits 1: Operation not permitted.
   A multi-UID mapping probe also exited 127 because newuidmap is unavailable.
6. Final amended runner `./tests/fresh-container.sh` exits 1 immediately at
   `unshare --mount --pid --fork true`: Operation not permitted. Evidence directory
   `target/fresh-container.dsev510z`; report elapsed 0.001 seconds, passed=false.
   It fails before new downloads/guest apt/setup. Prior verified archive evidence
   remains valid but cannot establish fresh-container acceptance.

## Plan deviation and remaining work
The initial single-UID user namespace cannot supply the required device creation
and ordinary apt ownership operations. The final helper therefore explicitly
requires root with privileged mount/PID namespaces; its second runtime adds a
network namespace. It retains isolated rootfs/source-only data and private mounts,
without host homes/cache bindings. This is a documented amendment, not a covert
fallback to a current-container or plain source-copy test. The current runtime
also denies this mode; installing a container command/package cannot itself grant
missing runtime capabilities. No attempt was made to read host files outside the
workspace, change host security settings, or claim a successful guest run.

No system packages were installed. Guest commands planned but NOT reached:
`apt-get update` and
`apt-get install -y --no-install-recommends build-essential ca-certificates curl python3 nodejs`.
Rust bootstrap, guest tool/package inventory, repeat setup and runtime portability
remain unverified. No guest package versions or parsed guest version output exist.
All namespace processes exited; mountpoint checks confirm no surviving private
proc/dev mounts in created rootfs paths. Scratch/logs retained under ignored target.

Next authorized work must run the helper in a runtime granting the documented
namespace/mount/device permissions, fix any actual guest provisioning failure,
and record setup, parsed version, repeat setup and preferably offline runtime
results before closing R002-01. Harness owns review and subsequent workflow.

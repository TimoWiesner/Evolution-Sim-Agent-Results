# TASK-002 PLAN cycle 4

## Scope and outcome
Read AGENTS, PROJECT, CONTRACT, STATE, ARCHITECTURE, task.md/task.json, all prior
TASK-002 and dependency TASK-001 handoffs, ADRs 001–005 and the PLAN skill.
TASK-001 has no review gaps. TASK-002 has exactly one: R002-01. This plan addresses
its remediation explicitly; it cannot close missing execution evidence. Status
remains OPEN / environmentally BLOCKED. Verdict N/A. No feature code changed.
The explicit cycle-4 assignment governs this phase despite task.json max_cycles=3;
the harness owns that discrepancy, task status, commits and subsequent phases.

Entry tree clean; no Git remotes. All 14 source hashes and modes match the
implement-cycle3.json manifest. Prior REVIEW's 4 Rust and 6 Python passes remain
prior evidence only; no product suite or fresh guest ran during this PLAN.

## Current feasibility
Bounded Python subprocess calls (10-second timeout each) executed:
- `unshare --mount --pid --fork true`: exit 1.
- `unshare --net true`: exit 1.
Both had empty stdout and stderr `unshare: unshare failed: Operation not permitted`.
No child namespace, mount, download or guest setup was created. PATH inventory
found unshare and chroot; docker, podman, bwrap, proot and qemu-system-x86_64 absent.
Do not infer that another installed wrapper would grant missing kernel rights.
Cycle 2 already tested the inadequate single-UID user namespace route; repeating
it or a clean-source/restricted-PATH check cannot close R002-01.

Retain ADR-005, Cargo layout, native distribution, source allowlist, checksum and
archive validation algorithms, and tests/fresh-container.sh interface. No new ADR
is justified. The prerequisite is a capable local execution environment granting
privileged mount/PID namespaces, private proc/tmpfs mounts and device creation.
Network namespaces are needed for the separate offline runtime claim. The agent
must not change host security settings, upload sources, or inspect host files
outside /workspace. No working alternative container route is established.

## Ordered plan for the next assigned IMPLEMENT phase
1. Read its assigned skill and this handoff. Recheck source hashes, clean/known Git
   changes and empty remotes. Budget 3 minutes for capabilities, at most 20 minutes
   for the runner, 7 minutes for final checks and durable reporting. Remain within
   version/help bootstrap scope; no simulation, run/batch/ui or toolchain redesign.
2. Qualify capabilities before downloading. Repeat the bounded mount/PID probe;
   if successful, use an owned target/cycle4-capability.* directory and a private
   child namespace to mount proc/tmpfs and create null/zero/random/urandom devices.
   Use the exact cycle-3 capability script embedded in implement-cycle3.json as
   the template, updating only its owned scratch path. Test network separately.
   Capture commands, statuses and stderr; verify namespace teardown and no owned
   proc/dev mount remains. If mount/device capability fails, stop that attempt
   promptly and write an honest blocked handoff. No product patch remedies this.
   Network-only failure must be reported separately from build-container ability.
3. Once qualified, run `/workspace/tests/fresh-container.sh`, whose existing outer
   timeout is 1200 seconds plus 15 seconds kill grace. It uses a pinned official
   Ubuntu Base 24.04.5 archive and published checksum (constants in
   tests/fresh_container.py), validated extraction and new rootfs directories.
   Reverify downloaded bytes; never reuse a provisioned guest. Copy only ALLOW
   sources, no target/dist, .git, host toolchains or caches. Record SHA-256 AND
   executable modes of final copied sources, clean-entry checks, OS/architecture,
   packages/tool versions and explicit guest DNS/network choices.
4. Required guest prerequisites (not run in this PLAN) are `apt-get update` then
   `apt-get install -y --no-install-recommends build-essential ca-certificates curl python3 nodejs`.
   Setup itself installs Rust 1.100.0. Disclose this initially Rust-absent variant
   versus the benchmark's preinstalled Rust baseline. Run guest setup -> version
   -> foreign-cwd repeat setup -> version -> test -> build -> dist-version, as GUEST
   already specifies. Every command must succeed with recorded status/streams.
   Parse version as exactly one object equal to
   {"name":"evosim","version":"0.1.0","contract":1}, with empty stderr.
5. Preserve evidence by stage. The current runner performs version assertions
   after build-container returns; if a later step fails, inspect already captured
   guest evidence and validate completed version outputs independently. Never
   infer success from files merely existing or from an overall report field.
   If actual failure makes reporting inadequate, minimally amend
   tests/fresh_container.py to persist per-stage results/timeouts and semantic
   assertions, retaining nonzero overall failure. Add focused tests in
   tests/test_fresh_container.py for failed setup, invalid JSON, and a later
   failure preserving earlier verified results. No speculative rewrite required.
6. Execute the second untouched rootfs check of copied dist with no runtimes and
   a private network namespace. Keep its result separate from fresh setup. Do not
   install dependencies into it and call it untouched. If real guest execution
   reveals defects, fix only implicated setup.sh/build.sh/runner files; update
   README and ADR-005 only where behavior/design changes. Rerun with new guest
   roots and final source hashes after any relevant edit. Do not certify old code.
7. Run ./test.sh on final sources and record actual counts/status (baseline: 4 Rust
   CLI tests, 6 Python archive tests, fmt/Clippy and wrapper/package checks). Check
   executable modes, README commands, `git check-ignore target/probe dist/probe`,
   and `git ls-files target dist` empty. No new tests for documentation-only outcome.
8. Write assigned IMPLEMENT JSON/Markdown with material evidence, not only ignored
   log paths: exact commands/statuses/streams, semantic version assertions,
   provenance, source hashes/modes, clean guest/cache facts and elapsed times.
   Update STATE/ARCHITECTURE with actual results and every installed system package
   plus exact install command. Validate JSON, scope and `git diff --check`.
   Leave unresolved facts explicit and phase transitions to the harness.

## Acceptance and closure map
| Must have | Evidence in next IMPLEMENT |
| --- | --- |
| Three executable entry points and cwd independence | ./test.sh, executable modes, guest foreign-cwd repeat setup |
| Fresh setup/version (R002-01) | Fresh verified Ubuntu guest, final source manifest, clean entry, setup exit 0, semantic version JSON/empty stderr, repeat setup/version success, durable environment provenance |
| dist/evosim and working version | ./build.sh, parsed dist-version, ordinary copied artifact check; untouched offline runtime reported separately |
| Help and unknown-command exit 2 | Existing Rust CLI and wrapper tests in ./test.sh |
| One documented test command and passing test | ./test.sh exit 0 with observed counts, README consistency |
| README installation/build/test and ignored outputs | Read README against commands; ignore and tracked-output checks |

R002-01 closes only upon actual successful fresh setup/version/repeat evidence for
final sources. Steps 2–5 and 8 supply the closure procedure; it is not satisfied
here. No acceptance waiver is granted. If capabilities remain absent, IMPLEMENT
must retain OPEN and report the prerequisite, not consume its full time repeating
known failures. No current-container result can replace the missing evidence.

## Risks and validation
The existing runner success path remains unverified: DNS, downloads, apt, rustup,
archive behavior or packaging may fail even after capabilities are supplied.
Budget permits one bounded attempt, not unlimited repair/reprovision loops.
No system dependencies installed in PLAN; existing STATE install commands stand.
Validation in this phase consists of file/Git inspections, bounded capability
probes, manifest comparison and final documentation/JSON checks. Product tests
were deliberately not rerun for this documentation-only replan.

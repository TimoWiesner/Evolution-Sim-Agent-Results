# TASK-002 REVIEW cycle 2

Verdict: FAIL. Existing gap R002-01 remains open; no additional product defect
was reproduced. Inspected cycle-2 diff 1eb5fc9..e41ba38, current production
scripts/CLI, tests, README, all task/dependency handoffs and ADRs. Entry tree clean,
HEAD e41ba38, no Git remotes. Commit subjects saying PASS do not override the
substantive earlier review FAIL or the implementation's explicit open gap.

## Acceptance mapping

| Must have | Independent evidence and result |
| --- | --- |
| Three executable entry points | Git modes 100755 and ./test.sh mode/cwd checks pass; setup is idempotent in current environment. |
| Version after setup in fresh container | FAIL / R002-01: runner exits 1 before guest provisioning; no fresh setup/version evidence. |
| Build creates dist and version works | ./test.sh builds, compares launcher/native/copied version output and checks empty stderr; passes. |
| Help and unknown-command status 2 | Four Rust CLI integration tests and shell wrapper/native checks pass, including extra/non-Unicode arguments. |
| Documented whole-suite command and passing tests | ./test.sh exits 0: four Rust tests, six Python archive tests, fmt/Clippy and wrapper/package checks. Separate OS acceptance check is documented as planned. |
| README and ignored build output | Install/build/test instructions match scripts; target/dist ignored and no files tracked there. |

## Independent fresh-container attempt

Exact command: `./tests/fresh-container.sh`, exit 1. Its first command was
`unshare --mount --pid --fork true`, exit 1, stderr:
`unshare: unshare failed: Operation not permitted`.
The durable material result is failure before any download or guest command;
ignored diagnostic directory: `/workspace/target/fresh-container._dtoeyge`.
report.json records passed=false, failure="namespace-probe: exit 1", elapsed
0.001 seconds. No namespace was created, so this attempt left no guest process or
mount requiring cleanup. Earlier rootfs checksum/extraction evidence belongs to
IMPLEMENT, not this review. No fresh provisioning success can be inferred from it.

## Code and scope findings

Cycle 2 adds an explicit bounded OS runner, source allowlist, checksum verification,
archive validation and six regression tests. Production setup/build/CLI are unchanged.
Reviewed link/path validation, nonzero failure propagation, source/cache isolation,
version parsing and namespace teardown design. Tests cover traversal, escaping
symlinks, writes through symlink parents, hardlinks to symlinks, special files and
valid file/link extraction. Guest apt/setup and runtime success paths remain untested.
The privileged-namespace amendment is documented in ADR-005; it does not waive
acceptance. No further implementation is attempted during REVIEW.

Linkage remains libc.so.6, libgcc_s.so.1 and ELF loader; maximum required GLIBC
symbol version 2.34. This and copied execution support packaging but do not prove
plain-OS runtime execution. Simulation/run/batch/ui are expressly out of scope.
No new regression test was needed: the existing environment test independently
reproduces the sole blocking finding. No system packages installed.

## R002-01 remediation for next PLAN

Arrange a genuinely fresh Ubuntu 24.04 benchmark-equivalent environment that can
actually run setup. The current helper requires privileged mount/PID/network
namespaces, proc/tmpfs mounts and device creation; this runtime denies the first
probe. Installing another package alone does not grant those capabilities.
Use a capable runtime or plan another reproducible genuine container route.
Keep sources free of target/dist and inherited project/toolchain caches. Capture
rootfs provenance, source hashes, guest package/tool versions, exact commands and
statuses, successful setup, parsed sole version JSON with empty stderr, and repeat
setup from a foreign cwd. Fix any exposed provisioning failures in an authorized
IMPLEMENT phase and rerun ./test.sh. Prefer completing the separate untouched
network-isolated runtime proof too. Current-container or clean-source checks do
not substitute for the explicit fresh-container criterion.

Review changes only STATE and these handoffs. Architecture and ADRs already describe
the unchanged design and blocker accurately. No protected files, benchmark state,
commits, remotes or phase transitions were changed. Harness checks remain authoritative.

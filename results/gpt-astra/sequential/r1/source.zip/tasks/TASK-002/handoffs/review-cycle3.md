# TASK-002 REVIEW cycle 3

Verdict: FAIL. R002-01 remains OPEN / environmentally BLOCKED. No new product
behavior defect was reproduced. Reviewed current scripts, CLI, tests, README,
ADRs, project/task documents, prior task and dependency handoffs, and cycle-3
implementation diff b0c337d..a72df2c. That diff changes documentation only and
follows the plan's blocked branch. All 14 source hashes and modes match the
implementation manifest. Entry worktree was clean and Git remotes were empty.
Commit subjects containing PASS do not override the substantive review verdict.

## Acceptance mapping

| Must have | Independent review evidence |
| --- | --- |
| Executable setup/launcher/build | Git modes 100755; ./test.sh checks modes, repeat setup and foreign cwd successfully. |
| Version after setup in fresh container | FAIL: R002-01; fresh runner fails before download or guest setup. |
| Build produces dist/evosim; version works | ./test.sh builds and checks native and copied distribution output; passes. |
| Help and unknown-command status 2 | Four Rust tests and wrapper checks pass, including malformed/non-Unicode arguments. |
| Documented test command and passing tests | ./test.sh exits 0: four Rust tests, six Python archive tests, fmt/Clippy and wrapper/package gates. |
| README install/build/test; ignored outputs | Instructions match scripts; target/dist ignored and no files tracked there. |

## Fresh-container reproduction

`./tests/fresh-container.sh` exited 1. Its first subprocess,
`unshare --mount --pid --fork true`, exited 1 with stderr:
`unshare: unshare failed: Operation not permitted`.
Report: /workspace/target/fresh-container._8ky_ct2/report.json,
passed=false, failure="namespace-probe: exit 1", elapsed_seconds=0.002.
No download, extraction, guest apt, setup/version or offline runtime execution
occurred. No namespace child started or private mount was created. Rootfs URL/hash
in that report are configured metadata, not verification performed in this review.
Existing archive tests reproduce validation behavior but cannot close this gap.

## Required remediation

For R002-01, a subsequently authorized PLAN must arrange a genuinely fresh Ubuntu
24.04 benchmark-equivalent environment capable of executing setup. The existing
runner requires privileged mount/PID/network namespaces, proc/tmpfs mounts and
character-device creation. Use a capable runtime or a demonstrably equivalent
fresh-container route. Record final source hashes/modes, clean-entry/cache facts,
OS/package/tool provenance, exact successful setup and repeat-setup commands,
and sole parsed version JSON with empty stderr. Fix any exposed defects only in
an authorized IMPLEMENT phase and rerun tests on final sources. Prefer completing
the separate untouched offline runtime check; report its result separately.
Current-container or clean-source checks cannot substitute for this criterion.
The maximum cycle count is harness-owned and does not waive acceptance.

No new tests or production changes were needed: existing tests independently
reproduced the evidence gap. No system packages installed; dependency commands
remain in STATE. Architecture and ADRs already accurately describe the unchanged
implementation and blocker, so no architecture amendment is needed. Only STATE
and these review handoffs changed. No commits, Git network operations, task-state
or protected-file edits, or phase transition. External checks remain authoritative.

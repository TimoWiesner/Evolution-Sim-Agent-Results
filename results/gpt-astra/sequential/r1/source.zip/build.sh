#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
PATH="${CARGO_HOME:-$HOME/.cargo}/bin:$PATH"
export PATH
cargo +1.100.0 build --release --locked --target-dir "$ROOT/target"
# Refuse output symlinks so packaging cannot overwrite unrelated files.
if [ -L "$ROOT/dist" ] || [ -L "$ROOT/dist/evosim" ]; then
    echo 'build: dist and dist/evosim must not be symlinks' >&2
    exit 1
fi
mkdir -p "$ROOT/dist"
install -m 755 "$ROOT/target/release/evosim" "$ROOT/dist/evosim"

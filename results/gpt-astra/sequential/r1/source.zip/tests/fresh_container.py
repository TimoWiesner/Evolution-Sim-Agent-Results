"""Fresh Ubuntu acceptance runner. All persistent files stay below project target/."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
BASE = "https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/"
ARCHIVE = "ubuntu-base-24.04.5-base-amd64.tar.gz"
SHA256 = "e77b6f10c2590cef872b33ee9f635a0e3fd1f57fb074c0e52b5c7f56147a0c86"
EXPECTED = {"name": "evosim", "version": "0.1.0", "contract": 1}
ALLOW = ["Cargo.toml", "Cargo.lock", "rust-toolchain.toml", "setup.sh", "evosim",
         "build.sh", "test.sh", "src", "tests", "README.md", ".gitignore"]


def extract(archive, destination):
    # Inspect every member before extracting. Convert absolute guest symlinks to
    # equivalent relative links so even host-side inspection cannot leave rootfs.
    with tarfile.open(archive) as tar:
        members = tar.getmembers()
        links = set()
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError(f"Unsafe archive path: {path}")
            if not (member.isfile() or member.isdir() or member.issym() or member.islnk()):
                raise ValueError(f"Unsupported archive member: {path}")
            if member.islnk():
                target = PurePosixPath(member.linkname)
                if target.is_absolute() or ".." in target.parts:
                    raise ValueError(f"Unsafe hardlink: {path}")
            if member.issym():
                links.add(path)
                if member.linkname.startswith("/"):
                    member.linkname = os.path.relpath(
                        destination / member.linkname.lstrip("/"),
                        destination / str(path.parent))
                resolved = (destination / str(path.parent) / member.linkname).resolve()
                if not resolved.is_relative_to(destination):
                    raise ValueError(f"Escaping archive link: {path}")
        for member in members:
            if member.islnk() and not any(
                m.name == member.linkname and m.isfile() for m in members
            ):
                raise ValueError(f"Hardlink must target regular file: {member.name}")
            if any(p in links for p in PurePosixPath(member.name).parents):
                raise ValueError(f"Archive writes through symlink: {member.name}")
        destination.mkdir()
        # data filter rejects escapes/special files and strips imported ownership.
        tar.extractall(destination, members=members, filter="data")


GUEST = r'''#!/bin/sh
set -eu
export DEBIAN_FRONTEND=noninteractive
mkdir -p /evidence /workspace/foreign
run() {
    label=$1; shift
    printf '%s\n' "$*" > "/evidence/$label.command"
    status=0
    "$@" > "/evidence/$label.stdout" 2> "/evidence/$label.stderr" || status=$?
    printf '%s\n' "$status" > "/evidence/$label.status"
    if [ "$status" -ne 0 ]; then
        cat "/evidence/$label.stderr" >&2
        exit "$status"
    fi
}
cat /etc/os-release > /evidence/os-release
uname -m > /evidence/architecture
# No project artifacts, language toolchain, or inherited caches at entry.
test ! -e /workspace/project/target
test ! -e /workspace/project/dist
test ! -e /root/.cargo
test ! -e /root/.rustup
! command -v rustup
! command -v rustc
printf 'no target/dist/cargo/rustup at entry\n' > /evidence/clean-entry
run apt-update apt-get update
run apt-install apt-get install -y --no-install-recommends build-essential ca-certificates curl python3 nodejs
dpkg-query -W > /evidence/packages
cd /workspace/project
run setup ./setup.sh
run version ./evosim version
cd /workspace/foreign
run setup-repeat /workspace/project/setup.sh
run version-repeat /workspace/project/evosim version
run test /workspace/project/test.sh
run build /workspace/project/build.sh
run dist-version /workspace/project/dist/evosim version
/root/.cargo/bin/rustc --version > /evidence/rustc
/root/.cargo/bin/cargo --version > /evidence/cargo
/root/.cargo/bin/rustup --version > /evidence/rustup
cc --version > /evidence/cc
python3 --version > /evidence/python
node --version > /evidence/node
ldd /workspace/project/dist/evosim > /evidence/ldd
readelf --version-info /workspace/project/dist/evosim > /evidence/symbols
'''

# Namespace init holds no open host directory inside chroot. Private mounts are
# destroyed when the PID namespace exits (including timeout/child failure).
INIT = r'''
set -eu
rootfs=$1
mount --make-rprivate /
mount -t proc proc "$rootfs/proc"
mount -t tmpfs tmpfs "$rootfs/dev"
for spec in 'null 1 3' 'zero 1 5' 'random 1 8' 'urandom 1 9'; do
    set -- $spec
    mknod -m 666 "$rootfs/dev/$1" c "$2" "$3"
done
ln -s /proc/self/fd "$rootfs/dev/fd"
exec chroot "$rootfs" /usr/bin/env -i HOME=/root PATH=/usr/sbin:/usr/bin:/sbin:/bin LC_ALL=C /bin/sh /guest.sh
'''


def main():
    if os.geteuid() != 0:
        raise RuntimeError("Fresh provisioning requires root with mount/device capabilities")
    (ROOT / "target").mkdir(exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="fresh-container.", dir=ROOT / "target"))
    print(f"Evidence: {work}", flush=True)
    report = {"archive_url": BASE + ARCHIVE, "sha256": SHA256,
              "dns": "explicit public resolver 1.1.1.1; no host config read",
              "commands": [], "passed": False}
    started = time.monotonic()

    def run(label, command):
        print(f"Running {label}", flush=True)
        with (work / f"{label}.stdout").open("wb") as out, (work / f"{label}.stderr").open("wb") as err:
            result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, timeout=900)
        report["commands"].append({"label": label, "command": command, "exit_code": result.returncode})
        if result.returncode:
            print((work / f"{label}.stderr").read_text(errors="replace")[-8000:], flush=True)
            raise RuntimeError(f"{label}: exit {result.returncode}")

    try:
        run("namespace-probe", ["unshare", "--mount", "--pid", "--fork", "true"])
        for name in ["SHA256SUMS", ARCHIVE]:
            run("download-" + name, ["curl", "--proto", "=https", "-fL", "--connect-timeout", "20", "--max-time", "180", BASE + name, "-o", str(work / name)])
        assert f"{SHA256} *{ARCHIVE}" in (work / "SHA256SUMS").read_text().splitlines()
        assert hashlib.sha256((work / ARCHIVE).read_bytes()).hexdigest() == SHA256
        guest = work / "build-rootfs"
        extract(work / ARCHIVE, guest)
        project = guest / "workspace/project"
        project.mkdir(parents=True)
        for name in ALLOW:
            source = ROOT / name
            if source.is_dir():
                shutil.copytree(source, project / name, ignore=shutil.ignore_patterns("__pycache__"))
            else:
                shutil.copy2(source, project / name)
        manifest = {str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted(project.rglob("*")) if p.is_file()}
        (work / "source-sha256.json").write_text(json.dumps(manifest, indent=2) + "\n")
        report["source_manifest_sha256"] = hashlib.sha256((work / "source-sha256.json").read_bytes()).hexdigest()
        resolver = guest / "etc/resolv.conf"
        resolver.unlink(missing_ok=True)
        resolver.write_text("nameserver 1.1.1.1\noptions timeout:2 attempts:2\n")
        (guest / "guest.sh").write_text(GUEST)
        run("build-container", ["unshare", "--mount", "--pid", "--fork", "--kill-child", "sh", "-c", INIT, "init", str(guest)])
        evidence = guest / "evidence"
        for name in ["version", "version-repeat", "dist-version"]:
            assert json.loads((evidence / f"{name}.stdout").read_text()) == EXPECTED
            assert not (evidence / f"{name}.stderr").read_bytes()
        runtime = work / "runtime-rootfs"
        extract(work / ARCHIVE, runtime)
        shutil.copytree(project / "dist", runtime / "dist")
        (runtime / "guest.sh").write_text(r'''set -eu
mkdir /evidence
dpkg-query -W > /evidence/packages
for tool in rustc cargo rustup python3 node cc; do
    if command -v "$tool"; then exit 1; fi
done
cat /proc/net/dev > /evidence/network
/dist/evosim version > /evidence/version.stdout 2> /evidence/version.stderr
''')
        run("runtime-container", ["unshare", "--mount", "--pid", "--net", "--fork", "--kill-child", "sh", "-c", INIT, "init", str(runtime)])
        assert json.loads((runtime / "evidence/version.stdout").read_text()) == EXPECTED
        assert not (runtime / "evidence/version.stderr").read_bytes()
        report["passed"] = True
        print("PASS: fresh setup, repeat setup, suite, packaging and offline plain Ubuntu runtime", flush=True)
    except Exception as error:
        report["failure"] = str(error)
        raise
    finally:
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
        (work / "report.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()

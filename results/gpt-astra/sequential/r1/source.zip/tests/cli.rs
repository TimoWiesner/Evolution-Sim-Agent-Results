use std::process::{Command, Output};

fn run(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .output()
        .expect("CLI must execute")
}

#[test]
fn version_is_one_contract_object() {
    let output = run(&["version"]);
    assert!(output.status.success());
    assert!(output.stderr.is_empty());
    let value: serde_json::Value = serde_json::from_slice(&output.stdout).unwrap();
    assert_eq!(
        value,
        serde_json::json!({"name": "evosim", "version": env!("CARGO_PKG_VERSION"), "contract": 1})
    );
    assert!(output.stdout.ends_with(b"\n"));
}

#[test]
fn help_lists_available_commands() {
    for args in [["--help"], ["-h"], ["help"]] {
        let output = run(&args);
        assert!(output.status.success());
        assert!(output.stderr.is_empty());
        let help = String::from_utf8(output.stdout).unwrap();
        assert!(help.contains("Usage: evosim <command>"));
        assert!(help.contains("  version "));
        assert!(help.contains("  help "));
    }
}

#[test]
fn invalid_invocations_have_clean_error_status() {
    for args in [
        vec![],
        vec!["unknown"],
        vec!["--bad"],
        vec!["version", "extra"],
        vec!["--help", "extra"],
        vec!["run"],
        vec!["batch"],
        vec!["ui"],
    ] {
        let output = run(&args);
        assert_eq!(output.status.code(), Some(2), "{args:?}");
        assert!(output.stdout.is_empty());
        assert!(!output.stderr.is_empty());
    }
}

#[cfg(unix)]
#[test]
fn non_unicode_argument_is_an_error_not_a_panic() {
    use std::{ffi::OsStr, os::unix::ffi::OsStrExt};
    let output = Command::new(env!("CARGO_BIN_EXE_evosim"))
        .arg(OsStr::from_bytes(b"\xff"))
        .output()
        .unwrap();
    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(!output.stderr.is_empty());
}

"""Archive-boundary regression tests; fixtures never leave workspace target/."""
import io
from pathlib import Path
import tarfile
import tempfile
import unittest

from fresh_container import ROOT, extract


class ArchiveTests(unittest.TestCase):
    def setUp(self):
        (ROOT / "target").mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / "target")
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)

    def archive(self, entries):
        path = self.base / "fixture.tar"
        with tarfile.open(path, "w") as tar:
            for name, kind, target in entries:
                member = tarfile.TarInfo(name)
                member.type = kind
                if kind == tarfile.REGTYPE:
                    member.size = 4
                    tar.addfile(member, io.BytesIO(b"test"))
                else:
                    member.linkname = target
                    tar.addfile(member)
        return path

    def test_regular_files_and_both_link_types(self):
        archive = self.archive([
            ("usr/bin/tool", tarfile.REGTYPE, ""),
            ("usr/bin/hard", tarfile.LNKTYPE, "usr/bin/tool"),
            ("bin/tool", tarfile.SYMTYPE, "/usr/bin/tool"),
        ])
        root = self.base / "root"
        extract(archive, root)
        self.assertEqual((root / "bin/tool").read_bytes(), b"test")
        self.assertEqual((root / "usr/bin/hard").read_bytes(), b"test")
        self.assertTrue((root / "bin/tool").resolve().is_relative_to(root))
        self.assertEqual((root / "usr/bin/tool").stat().st_ino,
                         (root / "usr/bin/hard").stat().st_ino)

    def test_parent_traversal_rejected_before_extract(self):
        archive = self.archive([("../escape", tarfile.REGTYPE, "")])
        with self.assertRaises(ValueError):
            extract(archive, self.base / "root")
        self.assertFalse((self.base / "root").exists())

    def test_escaping_relative_symlink_rejected(self):
        archive = self.archive([("escape", tarfile.SYMTYPE, "../../escape")])
        with self.assertRaises(ValueError):
            extract(archive, self.base / "root")

    def test_write_through_symlink_rejected(self):
        archive = self.archive([
            ("link", tarfile.SYMTYPE, "/usr"),
            ("link/file", tarfile.REGTYPE, ""),
        ])
        with self.assertRaises(ValueError):
            extract(archive, self.base / "root")

    def test_hardlink_to_symlink_rejected(self):
        archive = self.archive([
            ("link", tarfile.SYMTYPE, "/usr"),
            ("hard", tarfile.LNKTYPE, "link"),
        ])
        with self.assertRaises(ValueError):
            extract(archive, self.base / "root")

    def test_special_file_rejected(self):
        archive = self.archive([("device", tarfile.CHRTYPE, "")])
        with self.assertRaises(ValueError):
            extract(archive, self.base / "root")


if __name__ == "__main__":
    unittest.main()

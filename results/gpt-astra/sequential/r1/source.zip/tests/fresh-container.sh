#!/bin/sh
# Explicit, networked acceptance check; never part of the fast development gate.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
for tool in python3 curl unshare chroot timeout; do
    command -v "$tool" >/dev/null
done
exec timeout --kill-after=15s 1200s python3 "$ROOT/tests/fresh_container.py"

#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")"
cargo build --release --target x86_64-unknown-linux-musl
mkdir -p dist
cp target/x86_64-unknown-linux-musl/release/evosim dist/evosim

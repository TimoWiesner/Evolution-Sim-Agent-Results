use evosim::{
    geometry::{Cell, Grid},
    organism::Kind,
    rng::SplitMix64,
    spatial::SpatialIndex,
};
use std::{hint::black_box, time::Instant};
fn main() {
    let grid = Grid::new(128, 128).unwrap();
    let mut rng = SplitMix64::new(42);
    let mut index = SpatialIndex::new(grid).unwrap();
    let mut items = Vec::new();
    for id in 0..2000 {
        let c = Cell {
            x: rng.next_u64() % 128,
            y: rng.next_u64() % 128,
        };
        index.insert(id, c, Kind::Plant).unwrap();
        items.push((id, c));
    }
    let queries: Vec<_> = (0..10000)
        .map(|_| Cell {
            x: rng.next_u64() % 128,
            y: rng.next_u64() % 128,
        })
        .collect();
    let brute = |c| {
        items
            .iter()
            .filter(|(_, p)| grid.distance(c, *p) <= 3)
            .map(|(id, _)| *id)
            .collect::<Vec<_>>()
    };
    for &c in &queries[..100] {
        assert_eq!(index.query(c, 3, None), brute(c));
    }
    for _ in 0..3 {
        let start = Instant::now();
        for &c in &queries {
            black_box(index.query(c, 3, None));
        }
        let indexed = start.elapsed();
        let start = Instant::now();
        for &c in &queries {
            black_box(brute(c));
        }
        println!("index {:?}, brute {:?}", indexed, start.elapsed());
    }
}

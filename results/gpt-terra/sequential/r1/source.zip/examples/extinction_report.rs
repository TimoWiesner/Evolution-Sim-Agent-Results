use evosim::{config::Config, organism::Kind, simulation::Simulation};
use std::time::Instant;
fn main() {
    for seed in 1..=5 {
        let mut config = Config::from_json(r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#).unwrap();
        config.seed = seed;
        let mut sim = Simulation::new(&config).unwrap();
        let start = Instant::now();
        let kinds = [Kind::Plant, Kind::Herbivore, Kind::Carnivore];
        let mut extinct = [None; 3];
        for _ in 0..10_000 {
            sim.advance_one_tick().unwrap();
            for (i, kind) in kinds.iter().enumerate() {
                if extinct[i].is_none() && !sim.living().values().any(|o| o.kind() == *kind) {
                    extinct[i] = Some(sim.tick());
                }
            }
        }
        let label = |v: Option<u64>| v.map_or_else(|| "survived".to_owned(), |n| n.to_string());
        println!(
            "seed={seed} plants={} herbivores={} carnivores={} elapsed_seconds={:.2}",
            label(extinct[0]),
            label(extinct[1]),
            label(extinct[2]),
            start.elapsed().as_secs_f64()
        );
    }
}

use evosim::{config::Config, organism::Kind, simulation::Simulation};
use std::time::{Duration, Instant};

fn main() {
    let config = Config::from_json(include_str!("performance_config.json")).unwrap();
    let mut sim = Simulation::new(&config).unwrap();
    for _ in 0..10 {
        sim.advance_one_tick().unwrap();
    }
    let start_hash = sim.state_hash();
    let mut elapsed = Duration::ZERO;
    let mut min = [usize::MAX; 3];
    let mut max = [0; 3];
    let mut sum = [0usize; 3];
    for _ in 0..100 {
        let start = Instant::now();
        sim.advance_one_tick().unwrap();
        elapsed += start.elapsed();
        let mut counts = [0; 3];
        for o in sim.living().values() {
            counts[match o.kind() {
                Kind::Plant => 0,
                Kind::Herbivore => 1,
                Kind::Carnivore => 2,
            }] += 1;
        }
        for i in 0..3 {
            min[i] = min[i].min(counts[i]);
            max[i] = max[i].max(counts[i]);
            sum[i] += counts[i];
        }
    }
    println!("ticks=100 warmup=10 seconds={:.6} ticks_per_second={:.3} min={min:?} max={max:?} mean={:?} start_hash={} end_hash={}", elapsed.as_secs_f64(), 100.0 / elapsed.as_secs_f64(), sum.map(|x| x as f64 / 100.0), start_hash, sim.state_hash());
    assert!(
        min.iter().sum::<usize>() >= 1900,
        "workload fell below 1900 organisms"
    );
}

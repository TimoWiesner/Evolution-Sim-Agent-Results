#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")"
command -v cargo >/dev/null || { echo 'cargo is required' >&2; exit 1; }
command -v rustup >/dev/null || { echo 'rustup is required to install the musl target' >&2; exit 1; }
if ! rustup target list --installed | grep -qx 'x86_64-unknown-linux-musl'; then
    rustup target add x86_64-unknown-linux-musl
fi
if ! command -v musl-gcc >/dev/null; then
    apt-get update
    DEBIAN_FRONTEND=noninteractive apt-get install -y musl-tools
fi
cargo build --release --target x86_64-unknown-linux-musl

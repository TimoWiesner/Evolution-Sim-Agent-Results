# Ecosystem balance (TASK-027)

## Baseline, recorded before ecology changes

The fixed-key contract example is `tasks/TASK-027/example.json`. After `./setup.sh`, the unmodified engine ran `./evosim batch --config tasks/TASK-027/example.json --seeds 1,2,3,4,5,6,7,8,9,10 --ticks 10000 --out-dir tasks/TASK-027/baseline-batch` (exit 0). Exact replay command: `for seed in 1 2 3 4 5 6 7 8 9 10; do ./evosim run --config tasks/TASK-027/example.json --seed "$seed" --ticks 10000 --sample-every 1 --out "tasks/TASK-027/baseline-exact/seed-$seed.json"; done`. `python3 tasks/TASK-027/extract.py tasks/TASK-027/baseline-batch tasks/TASK-027/baseline-exact tasks/TASK-027/baseline-summary.json` verified each replay's final, totals and state hash against batch, and recorded exact extinction, all per-tick population curves through first extinction, and death causes. Null means survival through tick 10000. Batch result files and compact summary retain evidence; large exact replay files are reproducible.

| Seed | Plant extinction | Herbivore extinction | Carnivore extinction | Herbivore predation deaths at first extinction | Populations at first extinction (P/H/C) |
|---:|---:|---:|---:|---:|---|
|1|1464|70|570|133|646/0/29|
|2|survived|73|573|128|648/0/28|
|3|1576|53|553|121|649/0/28|
|4|1587|64|557|129|651/0/27|
|5|survived|71|564|130|650/0/29|
|6|survived|61|561|127|649/0/27|
|7|survived|53|546|122|654/0/28|
|8|survived|66|566|128|648/0/27|
|9|1545|68|568|131|646/0/28|
|10|survived|57|557|125|652/0/28|

Herbivores died first in every seed, at ticks 53–73 (median 65); every recorded herbivore death by that point was predation except one age death in seed 2. The complete three-kind curves are in the compact summary. Plants rose from 400 to 646–654 while herbivores fell from 120 to zero and carnivores rose from 20 to 27–29. Predation is the recorded proximate cause; how much particular hunting behavior drives the collapse is a hypothesis requiring an intervention. A local satiation rule is a plausible trial: animals that have adequate energy may avoid unnecessary attacks, reducing predation pressure without referring to population sizes.

## Trial 1 and choice

One mechanism was tried, with no other trial: after maintenance and any pursuit movement, a carnivore attacks only when its own energy is below 600. It can still pursue while satiated; it pays no attack cost and draws no attack roll until hungry. This models satiation and avoids unnecessary kills; it uses only individual energy, never population counts. All energy gained still comes from prey. No organism is created outside initialization or reproduction. No serialized fields or checkpoint format change. Expected outcome was reduced predation and longer coexistence, with a risk of overgrazing.

Measured with `./setup.sh` and `./evosim batch --config tasks/TASK-027/example.json --seeds 1,2,3,4,5,6,7,8,9,10 --ticks 2000 --out-dir tasks/TASK-027/trial1-batch`, plus the same per-tick replay/extraction procedure as baseline with `--ticks 2000` and `trial1` paths. All replay final, totals and hashes matched batch. First extinction ticks on seeds 1–10 were 681, 673, 632, 543, 783, 821, 790, 652, 776, 363 (median 677); baseline paired median was 65. Plants died first on seeds 4 and 10; carnivores first on seeds 5, 6, 7 and 9. The full first-event curves, causes and hashes are in `tasks/TASK-027/trial1-summary.json`. This single measured intervention was selected because it improved every paired tuning seed; no claim is made that it is optimal. Stopped after one trial to avoid overfitting and preserve time for independent validation.

## Held-out validation

With the selected default, ran `./evosim batch --config tasks/TASK-027/example.json --seeds 101,102,103,104,105 --ticks 10000 --out-dir tasks/TASK-027/heldout-batch`, then per-tick replay with the same seed list, `--ticks 10000 --sample-every 1`, and `python3 tasks/TASK-027/extract.py tasks/TASK-027/heldout-batch tasks/TASK-027/heldout-exact tasks/TASK-027/heldout-summary.json`. All deterministic terminal fields matched. Extinction ticks:

| Seed | Plants | Herbivores | Carnivores | First extinction |
|---:|---:|---:|---:|---:|
|101|538|596|772|538|
|102|1001|723|772|723|
|103|1113|773|835|773|
|104|1000|618|807|618|
|105|1163|712|759|712|

Held-out coexistence lasted 538–773 ticks, median 712, versus 53–73, median 65, for the ten baseline seeds. These are different seed sets, not a paired causal estimate; the tuning runs supply the paired comparison. The goal of longer coexistence was improved but sustained long coexistence was not reached: all five held-out food chains collapsed by tick 773. Herbivore starvation and grazing deaths became prominent; e.g. seed 101 had 767 plant grazing deaths and 382 herbivore starvation deaths at plant extinction. Full per-tick first-event curves and causes are retained in the compact summaries. Initial clustering, competition, deterministic ordering, small seed samples and unbounded historical records remain limitations; the results do not guarantee other configurations or seeds. Exact replays can be regenerated using the recorded commands; their large transient outputs were removed after extraction.

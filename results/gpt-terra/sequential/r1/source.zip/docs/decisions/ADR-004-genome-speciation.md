# ADR-004: Genome, inheritance and species

Status: Accepted for planned implementation.

## Context and decision

Use a fixed set of named, bounded numeric loci mapped to documented phenotypes. Plants carry a haploid genome, copied for asexual offspring and independently mutated. Animals carry two alleles per locus; each offspring receives one allele sampled from each parent per locus, followed by independently sampled, bounded mutations using the simulation PRNG. Mutation rates, step sizes, trait bounds and phenotype mapping are explicit parameters to calibrate and test. Sexual reproduction always requires two living parents of the same kind; compatibility is not gated by species labels. Species assignment is descriptive, not an artificial reproduction or survival control.

For each kind retain immutable founder/reference genomes and stable species IDs, even after extinction. Define the representative value of a diploid locus as its two-allele mean, and the normalized genome distance as the mean over loci of the absolute difference in representative values divided by that locus's allowed range. Assign an offspring to the nearest same-kind reference whose distance is at most a fixed, documented per-kind threshold; break equal distances by lowest species ID. Otherwise create a new species with the offspring's genome as reference. The threshold and loci must be set explicitly when implemented, held fixed within a run, and persisted with references. Count only species with living members. Reference comparison is stable but can split a drifting lineage and merge convergent lineages; it is a practical classification rather than a biological claim.

## Alternatives

- Bit-string genomes allow compact storage and cheap Hamming distances, but numeric trait ranges and small continuous changes require encoding and decoding choices.
- Variable-length or neural genomes can express richer behaviors, but matching genes for inheritance and defining stable distances are more expensive and difficult to test and calibrate.

## Consequences and verification

Fixed loci bound memory and make inheritance, distance and mutation costs predictable, though reference lookup grows with historical species count and must be profiled. Store genomes, species references, thresholds and PRNG state in checkpoints and canonical hashes; no runtime beyond the compiled distribution is required. Unit and property tests should cover bounds, parental inheritance, seeded mutation, distance symmetry, threshold boundaries and tie breaks; integration tests should cover extinction counts, persistent references and checkpoint replay. Benchmark historical reference growth and calibrate ecological outcomes later; neither performance nor coexistence is established here.

## TASK-009 implementation

Genomes use integer alleles 0–1000 in locus order speed, strength, fertility, lifespan, health and (animals only) aggression. Plants have five haploid loci, stored as equal pairs; animals have six diploid pairs. The representative is the floored allele mean. Phenotypes use `min + representative * (max - min) / 1000`, integer division, with ranges respectively 0–10, 0–100, 0–100, 1–1,000,000, 1–1000 and 0–100. Founder representatives are 100, 500, 500, 1, 100, 500, producing traits 1, 50, 50, 1000, 100 and animal aggression 50.

One-parent inheritance copies all alleles; two-parent animal crossover independently selects one allele from each parent per locus. The generic genetic operator permits one animal parent, but lifecycle events now reject animal births and ecological reproduction requires two living parents. Two-parent plant crossover is rejected. Each inherited allele consumes a 53-bit probability draw, even at rate zero; on success and nonzero strength it receives a uniformly sampled integer step in ±ceil(1000 × strength), clamped to the allele bounds. Bounded integer draws use rejection sampling. Mutation settings and RNG belong to the simulation and event processing occurs on a transactional clone. Distance is the mean absolute difference between floored representatives divided by 1000; distinct heterozygous arrangements can consequently have zero distance. Species classification remains unimplemented. Checkpoints and canonical hashes must include genomes, genetic settings and RNG along with the existing complete state.

## TASK-017 implementation

The fixed threshold is 0.15 inclusive for every kind, tested using exact integer differences of floored representatives; nearest reference wins, with lowest ID resolving ties. Classification occurs once at birth, including founders. IDs are global and sequential; names are kind-prefixed IDs. A new reference stores the first parent's species at conception and its birth tick. Historical extinct references remain eligible: reuse clears extinction, and a later loss of the last member records a new extinction tick. This retains stable reference classification even when lineages converge; species labels do not change mating rules. Registry state must be checkpointed and hashed when those features are implemented.

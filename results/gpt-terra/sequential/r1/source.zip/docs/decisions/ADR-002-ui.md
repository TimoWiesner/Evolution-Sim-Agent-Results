# ADR-002: User interface technology

Status: Accepted for planned implementation.

## Context and decision

Serve a local browser UI from the Rust executable, embedding HTML, CSS and JavaScript assets in the binary. A local server owns the same simulation core as headless mode; browser commands request operations and receive snapshots. The browser renders the grid and controls, not an independent simulation. The UI binds locally. The contract-provided Chromium can automate smoke tests and screenshots.

## Alternatives

- A native Rust desktop toolkit could avoid a browser but adds platform libraries, packaging complexity and display integration dependencies.
- A Python desktop or browser stack offers quick UI development but introduces an interpreter and possibly native GUI dependencies to bundle or install, and creates a language boundary to the core.

## Consequences and verification

Canvas rendering and bounded snapshot transfer should support interactive maps, but serialization, redraw cost and high entity counts must be measured. The core remains testable without a display; integration tests can exercise server commands and real browser smoke and screenshot flows. Embedded assets make the distribution independent of project files and network; a browser is still required for interactive UI, while offline `dist/evosim version` and `run` require no browser or runtime. Validate those paths on a clean system and test real UI rendering using the contract's Chromium; no performance or automation claim is yet verified.

# ADR-003: Wrapped grid spatial lookup

Status: Accepted and implemented.

## Context and decision

Use a dense row-major array of cell buckets holding stable organism IDs. Canonicalize coordinates modulo width and height. Update membership on movement, birth and death; movement remains cell-to-cell. Enumerate wrapped query cells in a fixed order, deduplicating coordinates when dimensions are one or two or query radii span a dimension, and return candidates in stable ID order. Exact geometric filtering follows enumeration when required.

## Alternatives

- A global linear scan has simple ownership and minimal index memory, but repeated local queries cost O(number of organisms) each.
- A sparse spatial hash or tree reduces empty-cell storage in large sparse worlds, but adds indirection, allocation and ordering complexity; hash iteration must never determine simulation results.

## Consequences and verification

Dense lookup has O(width × height) bucket overhead and query work proportional to distinct visited cells plus candidates; crowded cells can still be expensive. Very large sparse worlds need allocation failure handling or a future alternative without silently violating valid configuration requirements. It is implementable inside the Rust binary without a distribution runtime; no external service or library is required. Differential tests against brute-force toroidal queries must cover seams, degenerate dimensions, oversized radii and index updates; performance and memory benchmarks must measure representative and sparse worlds. The index is derived state and must be rebuilt deterministically or serialized consistently on load.

Implementation uses a reverse ordered ID map and per-cell vectors; queries return globally sorted IDs. See the architecture ledger for lifecycle integration, allocation limits and measured local-query performance.

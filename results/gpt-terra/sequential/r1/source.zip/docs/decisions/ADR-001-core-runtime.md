# ADR-001: Simulation core language and runtime

Status: Accepted for planned implementation.

## Context and decision

Use Rust for the simulation core and command-line executable. Compile a native release binary; plan a statically linked x86-64 musl distribution, with the target and any build dependencies installed by setup. Verify static linkage and run the copied distribution on a clean system when packaging is implemented: Rust alone does not guarantee static linkage. The offline `version` and `run` commands must need no language runtime or network. The local browser UI is addressed separately in ADR-002.

## Alternatives

- Python offers rapid iteration and extensive testing libraries but interpreter and object overhead make the population throughput goal harder; a self-contained distribution requires bundling an interpreter and native dependencies.
- C++ offers native performance and static distribution, but memory safety and build portability require more manual discipline. It remains a viable choice with careful tooling.

## Consequences and verification

Rust's compiled performance and ownership model suit a long-running simulation, but compile times and ecosystem dependencies add build complexity. Benchmark the release build at the required populations and 10,000-tick scenarios; no performance target is established by this decision. Unit, integration and deterministic replay tests can exercise a core library directly. Package tests must inspect binary dependencies and execute `version` and `run` from a copied `dist/` without a runtime. No additional system package is installed by this decision.

## Determinism

Each simulation owns an explicitly specified seedable PRNG; initialize it from the configured seed and serialize its complete state. No OS randomness is used after initialization. Process a tick-start snapshot of living organism IDs in ascending order; resolve interactions and candidate ties in a specified stable order, and activate births on the next tick. Canonical serialization orders entities, cells and species by stable identifiers and includes the clock, climate, RNG, ID allocator, genomes and persistent species references. Do not let wall clock, unordered collection iteration, thread scheduling or nondeterministic floating-point reductions influence simulation state. Measure elapsed wall time outside state and hashes. Same-build replay and split checkpoint runs must match; minor cross-platform numeric differences remain possible.

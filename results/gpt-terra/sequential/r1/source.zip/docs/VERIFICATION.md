# Delivery verification and project audit

TASK-028 implementation cycle 1, Ubuntu 24.04 container, AMD Ryzen 5 7500F (12 CPUs visible), Rust release build. Commands below ran from `/workspace` unless stated. `./setup.sh` ran twice successfully, including once from `/workspace/target` by absolute path; no system packages were installed in this phase. Existing setup installs `musl-tools` via `apt-get update && apt-get install -y musl-tools` if missing and the target via `rustup target add x86_64-unknown-linux-musl`. The suite requires Python 3, Node, Chromium and xvfb-run in addition to Rust and Cargo.

## CONTRACT evidence matrix

| Section / behavior | Evidence and observed outcome |
|---|---|
| 1 setup, any cwd | `./setup.sh`, then `cd /workspace/target && /workspace/setup.sh && /workspace/evosim version && /workspace/build.sh`: exit 0. Setup was repeated successfully. |
| 2 version | The preceding version command printed only `{"name":"evosim","version":"0.1.0","contract":1}` to stdout; `tests/cli.rs` checks JSON. |
| 2, 3 run/config | `python3 tests/run_cli.py` in `./tests/all.sh`: exit 0; fixed keys, override, zero ticks, exact ticks, sample boundaries, schema, hash, totals and timing paths. `cargo test` includes invalid types, missing keys, ranges and defaults in `tests/config.rs`. |
| 2 batch | `python3 tests/batch_cli.py`: exit 0; per-seed files, direct-run equality, summary aggregates, sweep, CSV, deterministic output and errors. |
| 2 UI | `python3 tests/ui_browser.py`: exit 0, normal server startup and real Chromium interaction, world, controls, editor and charts. `xvfb-run -a ./evosim ui --smoke-test`: exit 0, real UI advances and renders. `./evosim ui --screenshots target/task028-screens --config scenarios/demo.json`: exit 0; main and charts are 1280×720 PNGs, main visually inspected with world and tick 101 visible. |
| 4 result | `tests/run_cli.py`: exit 0; initial/end and interval samples, populations and cumulative accounting, SHA-256 form. Six 10,000-tick runs also checked each tick boundary and final accounting; compact results in `task028-measurements.json`. Timings are machine-dependent. |
| 5 determinism | `tests/run_cli.py` and `tests/reliability.py`: exit 0; repeated configs agree in final, totals, series and hash; differing seeds differ. |
| 5 checkpoints | `tests/checkpoint_cli.py` and `tests/reliability.py`: exit 0; split and uninterrupted final, totals and hash agree; cumulative start/end and corruption cases tested. |
| 5 extinction | `tests/run_cli.py`: exit 0 on plant-free scenario with eventual animal extinction. `tests/reliability.py`: exit 0 checking no recovery after zero per sample. |
| 5 errors and stdout | `tests/run_cli.py`, `tests/checkpoint_cli.py`, `tests/batch_cli.py`: exit 0; invalid arguments/config/checkpoint cases assert status 2, stderr and no result. `tests/cli.rs` checks version output. Not every possible OS write failure is exhaustively enumerated. |
| 6 distribution, offline | `./build.sh`: exit 0. `readelf -l dist/evosim` showed no interpreter and `readelf -d dist/evosim` showed no NEEDED entries. `file dist/evosim` could not run: command absent (exit 127); readelf supplied ELF evidence. Copied only `dist/` into `target/task028-root/`, added in-root config, then `chroot target/task028-root /dist/evosim version` and `chroot target/task028-root /dist/evosim run --config /config.json --ticks 10 --out /result.json`: both exit 0 and result JSON tick 10. The chroot contained no runtime or project files. This exercises offline operation without available runtime files; network namespace isolation was not tested. |
| 7 demo | `scenarios/demo.json` is accepted by screenshot UI and all measurement runs; README provides launch command. The fixed example and demo each completed three 10,000-tick runs within limits, recorded below and in JSON. |

## Measurements

Tuning compared 400 and 700 initial plants on the same 64×48, 120 herbivore, 20 carnivore world, seeds 11 and 12, 1,000 ticks each. First zero ticks were 289 and 600 for 400 plants versus 363 and 511 for 700. The latter was chosen for its better worst of this small tuning set; it is not generally superior. Six held-out runs use seeds 101–103, 10,000 ticks and `--sample-every 1`. Each had exit 0, all 10,001 sample ticks present, accounting valid and all final populations zero. Exact configuration, command, elapsed and wall time, hashes and full finals are in `task028-measurements.json`; temporary config/output paths in the recorded commands have been removed; `python3 tests/measure_coexistence.py` recreates them and repeats all attempts. No run timed out. Example first zero ticks: 538, 723, 773; demo: 510, 743, 518. Coexistence means all three positive at each completed tick; completed ticks before first zero are first zero minus one, with tick zero also positive. No ecological mechanism was changed.

## PROJECT self-audit

| Requirement | Status and evidence / limitation |
|---|---|
| Toroidal finite grid, cell movement, wrap-aware perception | Met: `tests/geometry.rs`, `tests/spatial.rs` brute-force randomized queries and `tests/ecology.rs`; dense grid uses memory proportional to area. |
| Continuous torus climate, zones, seasons, weather and organism effects | Met: `tests/climate.rs`, `tests/ecology.rs`; README explains mirrored latitude compromise. |
| Plant resources, growth, reproduction, mutation, species; animal feeding, traits and costs | Met: `tests/ecology.rs`, `tests/genome.rs`, `tests/organism.rs`; biological model is simplified. |
| Two-parent animals, inheritance, behavior and speciation | Met: `tests/genome.rs`, `tests/ecology.rs`; species use stable reference distance rather than biological isolation. |
| Natural stabilization and no forced replenishment | Met: local resource renewal and satiation; extinction tests above. Long coexistence is only partly met: all six measured runs collapsed early. |
| 1,000–5,000 population and 100 ticks/s at 2,000 | Partly met: performance guard measured 252.269 ticks/s over 100 ticks at over 4,000 entities on this container; not a guarantee for every workload or machine. |
| Shared headless/UI engine, climate map, differentiation, pan/zoom, controls, inspection | Met: `tests/ui_browser.py` and real screenshot; UI snapshots and chart scans add overhead. |
| Parameter editing, presets, JSON import/export, seed, full state save/load | Met: browser and checkpoint tests; uploads limited to 64 MiB, browser integers limited to JavaScript precision. `resources.regrowth_rate` is reserved and does not affect the engine. |
| Multi-seed batch and comparative statistics; population, births/deaths, diversity, genetic and generation trends | Met: batch, run metrics and UI tests; UI chart window retains 1,000 samples and resets on load; mean speed and trait distributions represent genetics. |
| Unit, integration, regression, property-style, multi-thousand tick, repeatability tests | Met: `./tests/all.sh`, randomized reliability/spatial cases, and six 10,000-tick runs. Randomized testing is bounded rather than exhaustive. |
| Local entry points and self-contained distribution | Met in tested environment: chroot evidence above; a separate plain-host installation and explicit network namespace isolation were not tested. |

Extremely large valid grids may exceed memory; historical species/death records grow. Checkpoints are versioned and checksummed, not protected against malicious tampering. UI checkpoint loading starts a new chart history. See `docs/BALANCE.md` for ecological trials and `docs/ARCHITECTURE.md` for implementation details.

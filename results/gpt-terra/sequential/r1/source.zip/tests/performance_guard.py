#!/usr/bin/env python3
"""Release-only, intentionally generous guard against severe engine slowdowns."""
import re
import subprocess

result = subprocess.run(["cargo", "run", "--release", "--quiet", "--example", "performance_bench"], capture_output=True, text=True, timeout=120, check=True)
print(result.stdout, end="")
match = re.search(r"seconds=([0-9.]+)", result.stdout)
if not match or float(match.group(1)) > 15:
    raise SystemExit("100 measured ticks exceeded the generous 15 second limit or no timing was reported")

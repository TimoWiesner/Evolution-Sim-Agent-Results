use evosim::{
    config::{Config, Genetics},
    genome::Genome,
    geometry::Cell,
    organism::{Event, Kind},
    rng::SplitMix64,
    simulation::Simulation,
};
fn settings(rate: f64, strength: f64) -> Genetics {
    Genetics {
        mutation_rate: rate,
        mutation_strength: strength,
    }
}
#[test]
fn bounds_mapping_and_distance() {
    for kind in [Kind::Plant, Kind::Herbivore, Kind::Carnivore] {
        let n = if kind == Kind::Plant { 5 } else { 6 };
        let lo = Genome::new(kind, vec![[0, 0]; n]).unwrap();
        let hi = Genome::new(kind, vec![[1000, 1000]; n]).unwrap();
        assert_eq!(
            (
                lo.traits().speed(),
                lo.traits().max_lifespan(),
                lo.traits().max_health()
            ),
            (0, 1, 1)
        );
        assert_eq!(
            (
                hi.traits().speed(),
                hi.traits().max_lifespan(),
                hi.traits().max_health()
            ),
            (10, 1_000_000, 1000)
        );
        assert_eq!(lo.distance(&lo).unwrap(), 0.0);
        assert_eq!(lo.distance(&hi).unwrap(), 1.0);
        assert_eq!(lo.distance(&hi), hi.distance(&lo));
        assert!(Genome::new(kind, vec![[1001, 1001]; n]).is_err());
        let founder = Genome::founder(kind).traits();
        assert_eq!(
            (
                founder.speed(),
                founder.strength(),
                founder.fertility(),
                founder.max_lifespan(),
                founder.max_health()
            ),
            (1, 50, 50, 1000, 100)
        );
    }
    assert!(Genome::new(Kind::Plant, vec![[0, 1]; 5]).is_err());
    let a = Genome::new(Kind::Herbivore, vec![[0, 1000]; 6]).unwrap();
    let b = Genome::new(Kind::Herbivore, vec![[500, 500]; 6]).unwrap();
    assert_eq!(a.distance(&b).unwrap(), 0.0);
    assert!(a.distance(&Genome::founder(Kind::Carnivore)).is_err());
}
#[test]
fn inheritance_and_mutation_are_seeded_and_bounded() {
    let a = Genome::new(Kind::Herbivore, vec![[0, 100]; 6]).unwrap();
    let b = Genome::new(Kind::Herbivore, vec![[900, 1000]; 6]).unwrap();
    let mut r = SplitMix64::new(71);
    assert_eq!(
        Genome::inherit(&a, None, &settings(0.0, 1.0), &mut r).unwrap(),
        a
    );
    let mut r1 = SplitMix64::new(42);
    let mut r2 = r1;
    for _ in 0..100 {
        let c = Genome::inherit(&a, Some(&b), &settings(0.0, 1.0), &mut r1).unwrap();
        let d = Genome::inherit(&a, Some(&b), &settings(0.0, 1.0), &mut r2).unwrap();
        assert_eq!(c, d);
        for x in c.alleles() {
            assert!([0, 100].contains(&x[0]));
            assert!([900, 1000].contains(&x[1]));
        }
    }
    let mut changes = 0;
    for _ in 0..100 {
        let c = Genome::inherit(&a, None, &settings(1.0, 1.0), &mut r).unwrap();
        assert!(c.alleles().iter().flatten().all(|v| *v <= 1000));
        if c != a {
            changes += 1;
        }
    }
    assert!(changes > 0);
    assert_eq!(
        Genome::inherit(&a, None, &settings(1.0, 0.0), &mut r).unwrap(),
        a
    );
    assert!(Genome::inherit(&a, None, &settings(f64::NAN, 0.1), &mut r).is_err());
    assert!(Genome::inherit(
        &a,
        Some(&Genome::founder(Kind::Carnivore)),
        &settings(0.0, 0.0),
        &mut r
    )
    .is_err());
}
#[test]
fn births_inherit_configuration_and_roll_back_rng() {
    let mut config = Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#).unwrap();
    config.genetics = settings(0.0, 1.0);
    let mut sim = Simulation::new(&config).unwrap();
    let birth = Event::Birth {
        kind: Kind::Plant,
        position: Cell { x: 0, y: 0 },
        parents: [Some(0), None],
    };
    let before = sim.clone();
    let invalid = Event::Birth {
        kind: Kind::Plant,
        position: Cell { x: 1, y: 0 },
        parents: [Some(0), None],
    };
    assert!(sim.advance_with_events(&[birth.clone(), invalid]).is_err());
    assert_eq!(sim, before);
    sim.advance_with_events(&[birth.clone()]).unwrap();
    assert_eq!(sim.living()[&0].genome(), sim.living()[&1].genome());
    for o in sim.living().values() {
        assert_eq!(o.traits(), &o.genome().traits());
    }
    config.genetics = settings(1.0, 1.0);
    let mut changed = Simulation::new(&config).unwrap();
    changed.advance_with_events(&[birth]).unwrap();
    assert_ne!(changed.living()[&0].genome(), changed.living()[&1].genome());
}

#!/usr/bin/env python3
import json, pathlib, subprocess, tempfile

root = pathlib.Path(__file__).resolve().parents[1]
exe = root / 'evosim'
def call(*args, ok=True):
    p = subprocess.run([str(exe), 'run', *map(str,args)], capture_output=True, text=True)
    assert p.returncode == (0 if ok else 2), (p.args,p.returncode,p.stderr)
    if not ok: assert p.stderr
    return p
with tempfile.TemporaryDirectory() as d:
    d = pathlib.Path(d)
    config = d/'config.json'
    config.write_text(json.dumps({'seed': 42, 'world': {'width': 20, 'height': 16}, 'initial': {'plants': 80, 'herbivores': 25, 'carnivores': 5}}))
    full = d/'full.json'
    call('--config',config,'--seed',-17,'--ticks',180,'--out',full)
    expected = json.loads(full.read_text())
    for split in (0, 75):
        cp, first, result = d/'state', d/'first.json', d/'result.json'
        call('--config',config,'--seed',-17,'--ticks',split,'--out',first,'--save',cp)
        call('--load',cp,'--ticks',180-split,'--out',result,'--sample-every',13,'--save',d/'state2')
        got = json.loads(result.read_text())
        for key in ('final','totals','state_hash','seed'): assert got[key] == expected[key], key
        assert got['tick_start'] == split and got['tick_end'] == 180
        assert got['series'][0]['tick'] == split and got['series'][-1]['tick'] == 180
        call('--load',d/'state2','--ticks',0,'--out',result)
        assert json.loads(result.read_text())['state_hash'] == expected['state_hash']
    original = (d/'state').read_bytes()
    for name, content in [('truncated', original[:-1]), ('damaged',original[:-1]+bytes([original[-1]^1])), ('version', original[:8]+(2).to_bytes(4,'little')+original[12:]), ('trailing',original+b'x')]:
        path = d/name; path.write_bytes(content); out=d/'bad.json'
        if out.exists(): out.unlink()
        call('--load',path,'--ticks',1,'--out',out,ok=False); assert not out.exists()
        out.write_text('preserved'); call('--load',path,'--ticks',1,'--out',out,ok=False); assert out.read_text() == 'preserved'
    out=d/'missing-result'; call('--load',d/'missing','--ticks',1,'--out',out,ok=False); assert not out.exists()
    call('--load',d/'state','--seed',1,'--ticks',1,'--out',out,ok=False)
    call('--load',d/'state','--config',config,'--ticks',1,'--out',out,ok=False)
    call('--load',d/'state','--ticks',1,'--out',d/'state',ok=False)
    call('--load',d/'state','--ticks',1,'--out',out,'--save',d/'state',ok=False)
print('checkpoint CLI checks passed')

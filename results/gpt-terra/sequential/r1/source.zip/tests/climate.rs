use evosim::{
    climate::{Biome, ClimateField},
    config::Config,
    geometry::{Cell, Grid},
    simulation::Simulation,
};
use std::{fs, process::Command};

#[test]
fn ordered_bands_and_scalar_formula() {
    let f = ClimateField::new(Grid::new(3, 1000).unwrap());
    let mut bands = Vec::new();
    for y in 0..500 {
        let c = f.at(Cell { x: 0, y });
        if bands.last() != Some(&c.biome) {
            bands.push(c.biome);
        }
        let w = (c.base_temperature + 25.0) / 55.0;
        let anchors = [
            (0.0, 100.0),
            (0.12, 250.0),
            (0.28, 700.0),
            (0.55, 350.0),
            (0.78, 1400.0),
            (1.0, 2200.0),
        ];
        let p = anchors.windows(2).find(|p| w <= p[1].0).unwrap();
        let expected = p[0].1 + (w - p[0].0) / (p[1].0 - p[0].0) * (p[1].1 - p[0].1);
        assert!((c.base_precipitation - expected).abs() < 1e-9);
        assert!((-25.0..=30.0).contains(&c.base_temperature));
        assert!((100.0..=2200.0).contains(&c.base_precipitation));
    }
    assert_eq!(
        bands,
        [
            Biome::Polar,
            Biome::Tundra,
            Biome::Temperate,
            Biome::Dry,
            Biome::Tropical
        ]
    );
}

#[test]
fn seams_and_small_worlds() {
    for width in 1..=9 {
        for height in 1..=64 {
            let f = ClimateField::new(Grid::new(width, height).unwrap());
            let at = |x, y| f.at(Cell { x, y });
            for y in 0..height {
                assert_eq!(at(0, y), at(width - 1, y));
                assert_eq!(at(0, y), at(width, y + height));
            }
            assert_eq!(at(0, 0), at(width - 1, height - 1));
            for get in [
                |c: evosim::climate::ClimateCell| c.base_temperature,
                |c: evosim::climate::ClimateCell| c.base_precipitation,
            ] {
                let seam = (get(at(0, 0)) - get(at(0, height - 1))).abs();
                let max_interior = (1..height)
                    .map(|y| (get(at(0, y)) - get(at(0, y - 1))).abs())
                    .fold(0.0, f64::max);
                assert!(seam <= max_interior);
            }
        }
    }
    let f = ClimateField::new(Grid::new(u64::MAX, u64::MAX).unwrap());
    assert_eq!(
        f.at(Cell { x: 0, y: 0 }),
        f.at(Cell {
            x: u64::MAX - 1,
            y: u64::MAX - 1
        })
    );
    assert!(f
        .at(Cell {
            x: 0,
            y: u64::MAX / 2
        })
        .base_temperature
        .is_finite());
}

#[test]
fn simulation_climate_is_static_and_does_not_consume_rng() {
    let mut config = Config::preset("temperate").unwrap();
    config.initial.plants = 0;
    config.initial.carnivores = 0;
    config.initial.herbivores = 0;
    config.climate.weather_strength = 0.0;
    let mut sim = Simulation::new(&config).unwrap();
    let before = sim.climate().at(Cell { x: 0, y: 0 });
    let rng = *sim.rng();
    for _ in 0..100 {
        sim.advance_one_tick().unwrap();
    }
    assert_eq!(before, sim.climate().at(Cell { x: 0, y: 0 }));
    assert_eq!(rng, *sim.rng());
}

#[test]
fn map_command_and_errors() {
    let path = std::env::temp_dir().join(format!("evosim-climate-{}.json", std::process::id()));
    fs::write(&path, r#"{"seed":42,"world":{"width":4,"height":12},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let exe = env!("CARGO_BIN_EXE_evosim");
    let out = Command::new(exe)
        .current_dir("/")
        .args(["climate-map", "--config"])
        .arg(&path)
        .output()
        .unwrap();
    assert!(out.status.success());
    let text = String::from_utf8(out.stdout).unwrap();
    let f = ClimateField::new(Grid::new(4, 12).unwrap());
    let expected: String = (0..12)
        .map(|y| {
            format!(
                "{}\n",
                f.at(Cell { x: 0, y }).biome.code().to_string().repeat(4)
            )
        })
        .collect();
    assert_eq!(text, expected);
    fs::write(&path, "invalid").unwrap();
    let bad = Command::new(exe)
        .args(["climate-map", "--config"])
        .arg(&path)
        .output()
        .unwrap();
    assert_eq!(bad.status.code(), Some(2));
    assert!(bad.stdout.is_empty());
    assert!(!bad.stderr.is_empty());
    let missing = Command::new(exe).arg("climate-map").output().unwrap();
    assert_eq!(missing.status.code(), Some(2));
    assert!(missing.stdout.is_empty());
    assert!(!missing.stderr.is_empty());
    fs::remove_file(path).unwrap();
}

#[test]
fn seasons_repeat_exactly_and_vary_by_latitude() {
    for year in [1, 2, 12, 37] {
        let mut config = Config::preset("temperate").unwrap();
        config.climate.year_ticks = year;
        config.climate.seasonal_strength = 1.0;
        config.climate.weather_strength = 0.0;
        config.world.width = 3;
        config.world.height = 12;
        let mut sim = Simulation::new(&config).unwrap();
        let mut first = Vec::new();
        for _ in 0..year {
            first.push(
                (0..12)
                    .flat_map(|y| (0..3).map(move |x| Cell { x, y }))
                    .map(|c| sim.climate_at(c))
                    .collect::<Vec<_>>(),
            );
            sim.advance_one_tick().unwrap();
        }
        for expected in &first {
            let actual: Vec<_> = (0..12)
                .flat_map(|y| (0..3).map(move |x| Cell { x, y }))
                .map(|cell| sim.climate_at(cell))
                .collect();
            assert_eq!(&actual, expected);
            sim.advance_one_tick().unwrap();
        }
        if year == 12 {
            assert_ne!(first[0][0].temperature, first[3][0].temperature);
            assert_ne!(first[0][0].precipitation, first[3][0].precipitation);
            let cold =
                first[0][0].temperature - sim.climate().at(Cell { x: 0, y: 0 }).base_temperature;
            let hot =
                first[0][15].temperature - sim.climate().at(Cell { x: 0, y: 5 }).base_temperature;
            assert!(cold > hot);
        }
    }
}

#[test]
fn weather_is_seeded_bounded_and_owned() {
    let mut config = Config::preset("temperate").unwrap();
    config.initial.plants = 0;
    config.initial.carnivores = 0;
    config.climate.seasonal_strength = 1.0;
    config.climate.weather_strength = 1.0;
    let mut a = Simulation::new(&config).unwrap();
    let mut b = a.clone();
    config.seed += 1;
    let mut other = Simulation::new(&config).unwrap();
    let cell = Cell { x: 0, y: 10 };
    assert_eq!(a.climate_at(cell), other.climate_at(cell));
    let before = a.clone();
    a.climate_at(cell);
    assert_eq!(a, before);
    let mut rng = *a.rng();
    rng.next_u64();
    rng.next_u64();
    a.advance_one_tick().unwrap();
    b.advance_one_tick().unwrap();
    other.advance_one_tick().unwrap();
    assert_eq!(*a.rng(), rng);
    assert_eq!(a, b);
    assert_ne!(a.climate_at(cell), other.climate_at(cell));
    for _ in 0..1000 {
        for y in 0..48 {
            let c = a.climate_at(Cell { x: 0, y });
            assert!((-60.0..=60.0).contains(&c.temperature));
            assert!((0.0..=3000.0).contains(&c.precipitation));
            assert_eq!(c, a.climate_at(Cell { x: 64, y: y + 48 }));
            assert_eq!(
                a.climate_at(Cell { x: 0, y: 0 }),
                a.climate_at(Cell { x: 63, y: 47 })
            );
        }
        a.advance_one_tick().unwrap();
        b.advance_one_tick().unwrap();
    }
    assert_eq!(a, b);
}

use evosim::{
    config::Config,
    geometry::{Cell, Grid},
    organism::{DeathCause, Event, Kind},
    rng::SplitMix64,
    simulation::Simulation,
    spatial::SpatialIndex,
};
use std::collections::BTreeMap;

#[test]
fn randomized_updates_and_queries_match_brute_force() {
    let mut rng = SplitMix64::new(71);
    for (w, h) in [(1, 1), (1, 7), (2, 2), (7, 3), (32, 25)] {
        let grid = Grid::new(w, h).unwrap();
        let mut index = SpatialIndex::new(grid).unwrap();
        let mut items = BTreeMap::new();
        for step in 0..600 {
            let id = rng.next_u64() % 100;
            let c = Cell {
                x: rng.next_u64() % w,
                y: rng.next_u64() % h,
            };
            let kind = if id % 2 == 0 {
                Kind::Plant
            } else {
                Kind::Herbivore
            };
            match step % 3 {
                0 => {
                    let actual = index.insert(id, c, kind);
                    if let std::collections::btree_map::Entry::Vacant(e) = items.entry(id) {
                        e.insert((c, kind));
                        assert!(actual.is_ok());
                    } else {
                        assert!(actual.is_err());
                    }
                }
                1 => {
                    let actual = index.move_to(id, c);
                    if let Some(v) = items.get_mut(&id) {
                        v.0 = c;
                        assert!(actual.is_ok());
                    } else {
                        assert!(actual.is_err());
                    }
                }
                _ => {
                    assert_eq!(index.remove(id).is_ok(), items.remove(&id).is_some());
                }
            }
            let center = Cell {
                x: rng.next_u64() % (w * 2),
                y: rng.next_u64() % (h * 2),
            };
            let radius = if step % 31 == 0 {
                u64::MAX
            } else {
                rng.next_u64() % 40
            };
            let filter = if step % 2 == 0 {
                Some(Kind::Plant)
            } else {
                None
            };
            let expected: Vec<_> = items
                .iter()
                .filter(|(_, (p, k))| {
                    let x = center.x % w;
                    let y = center.y % h;
                    let dx = x.abs_diff(p.x);
                    let dy = y.abs_diff(p.y);
                    dx.min(w - dx).max(dy.min(h - dy)) <= radius && filter.is_none_or(|f| f == *k)
                })
                .map(|(&id, _)| id)
                .collect();
            assert_eq!(index.query(center, radius, filter), expected);
        }
    }
}
#[test]
fn lifecycle_keeps_index_in_sync() {
    let mut sim = Simulation::new(&Config::preset("temperate").unwrap()).unwrap();
    let old = sim.living()[&0].position();
    assert!(sim.query(old, 0, None).contains(&0));
    let dest = Cell {
        x: old.x + 1,
        y: old.y,
    };
    sim.move_organism(0, dest).unwrap();
    assert!(!sim.query(old, 0, None).contains(&0));
    assert!(sim.query(dest, 0, Some(Kind::Plant)).contains(&0));
    let before = sim.clone();
    assert!(sim.move_organism(u64::MAX, dest).is_err());
    assert!(sim
        .advance_with_events(&[
            Event::Death {
                id: 0,
                cause: DeathCause::External
            },
            Event::Birth {
                kind: Kind::Plant,
                position: dest,
                parents: [Some(0), None]
            }
        ])
        .is_err());
    assert_eq!(sim, before);
    sim.advance_with_events(&[
        Event::Birth {
            kind: Kind::Plant,
            position: dest,
            parents: [Some(0), None],
        },
        Event::Death {
            id: 0,
            cause: DeathCause::External,
        },
    ])
    .unwrap();
    let id = sim
        .living()
        .values()
        .find(|o| o.parents() == [Some(0), None] && o.position() == dest)
        .unwrap()
        .id();
    assert!(!sim.query(dest, 0, None).contains(&0));
    assert!(sim.query(dest, 0, None).contains(&id));
    sim.advance_with_events(&[Event::Adjust {
        id,
        energy: -1000,
        health: 0,
    }])
    .unwrap();
    assert!(!sim.query(dest, 0, None).contains(&id));
}

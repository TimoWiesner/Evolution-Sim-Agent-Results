import csv, json, os, pathlib, subprocess, tempfile

root = pathlib.Path(__file__).resolve().parents[1]
env = dict(os.environ); env.pop('DISPLAY', None)
def call(*args):
    return subprocess.run([str(root/'evosim'), *map(str,args)], cwd='/', env=env, capture_output=True, text=True)
def read(p): return json.loads(p.read_text())
with tempfile.TemporaryDirectory() as tmp:
    d = pathlib.Path(tmp); cfg = d/'config.json'
    cfg.write_text(json.dumps({'seed': 1, 'world': {'width': 4, 'height': 4}, 'initial': {'plants': 1, 'herbivores': 0, 'carnivores': 0}}))
    common = ['--config', cfg, '--seeds', '-2,3', '--ticks', '2']
    a, b = d/'a', d/'b'
    for out in (a,b):
        p = call('batch', *common, '--out-dir', out, '--sweep-initial-plants', '0,2', '--csv', out/'summary.csv')
        assert p.returncode == 0, p.stderr
    assert (a/'summary.json').read_bytes() == (b/'summary.json').read_bytes()
    summary = read(a/'summary.json'); runs = summary['runs']; assert len(runs) == 4
    assert [(r['parameters']['initial']['plants'],r['seed']) for r in runs] == [(0,-2),(0,3),(2,-2),(2,3)]
    for r in runs:
        result = read(a/r['result']); assert result['final'] == r['final'] and result['state_hash'] == r['state_hash'] and r['ticks'] == 2
        other = read(b/r['result']); assert all(result[k] == other[k] for k in result if k not in ('elapsed_seconds','ticks_per_second'))
    for kind in ('plants','herbivores','carnivores'):
        vals = [r['final'][kind] for r in runs]; agg = summary['aggregates'][kind]
        assert agg == {'mean':sum(vals)/len(vals),'min':min(vals),'max':max(vals),'extinct_runs':vals.count(0)}
    assert summary['aggregates']['herbivores']['extinct_runs'] == 4
    rows = list(csv.DictReader((a/'summary.csv').open())); assert len(rows) == 7
    for row, r in zip(rows, runs):
        assert row['type'] == 'run' and int(row['seed']) == r['seed'] and json.loads(row['parameters']) == r['parameters'] and int(row['ticks']) == r['ticks'] and row['result'] == r['result'] and json.loads(row['final']) == r['final'] and row['state_hash'] == r['state_hash']
    for row in rows[4:]:
        agg = summary['aggregates'][row['kind']]; assert row['type'] == 'aggregate' and float(row['mean']) == agg['mean'] and all(int(row[k]) == agg[k] for k in ('min','max','extinct_runs'))
    plain = d/'plain'; p = call('batch','--config',cfg,'--seeds','-2,3','--ticks','0','--out-dir',plain); assert p.returncode == 0, p.stderr
    direct = d/'direct.json'; p = call('run','--config',cfg,'--seed','-2','--ticks','0','--out',direct); assert p.returncode == 0, p.stderr
    x, y = read(plain/'seed--2.json'), read(direct); assert all(x[k] == y[k] for k in x if k not in ('elapsed_seconds','ticks_per_second'))
    for extra in (['--seeds','1,1'], ['--seeds',''], ['--seeds','x'], ['--sweep-initial-plants','1,1'], ['--foo','x'], ['--ticks','1']):
        out = d/'invalid'; p = call('batch',*common,'--out-dir',out,*extra); assert p.returncode == 2 and p.stderr and not (out/'summary.json').exists()
    p = call('batch',*common,'--out-dir',d/'collision','--csv',d/'collision'/'summary.json'); assert p.returncode == 2 and p.stderr and not (d/'collision').exists()
    p = call('batch',*common,'--out-dir',cfg); assert p.returncode == 2 and p.stderr
    p = call('batch','--config',d/'missing','--seeds','1','--ticks','0','--out-dir',d/'bad'); assert p.returncode == 2 and p.stderr and not (d/'bad').exists()
print('batch CLI checks passed')

import json, os, pathlib, subprocess, tempfile
root = pathlib.Path(__file__).resolve().parent.parent
exe = str(root / 'evosim')
with tempfile.TemporaryDirectory() as d:
    p = pathlib.Path(d)
    config = p / 'config.json'
    config.write_text(json.dumps({'seed': 42, 'world': {'width': 8, 'height': 8}, 'initial': {'plants': 8, 'herbivores': 2, 'carnivores': 1}}))
    env = os.environ.copy(); env.pop('DISPLAY', None)
    def call(*args):
        return subprocess.run([exe, 'run', *map(str, args)], cwd=d, env=env, capture_output=True)
    def run(ticks, *extra):
        out = p / 'result.json'
        result = call('--config', config, '--ticks', ticks, '--out', out, *extra)
        assert result.returncode == 0, result.stderr
        return json.loads(out.read_text())
    a, b = run(13, '--sample-every', 5), run(13, '--sample-every', 5)
    for key in ('final', 'totals', 'series', 'state_hash'): assert a[key] == b[key]
    assert [x['tick'] for x in a['series']] == [0, 5, 10, 13]
    for sample in a['series']:
        m = sample['metrics']
        for kind, initial in [('plants',8),('herbivores',2),('carnivores',1)]:
            assert sample[kind] == initial + m['births'][kind] - m['deaths'][kind]
            assert sum(m['deaths_by_cause'][kind].values()) == m['deaths'][kind]
            assert set(m['deaths_by_cause'][kind]) == {'age','starvation','injury','grazing','predation','external'}
            assert set(m['traits'][kind]) == {'speed','strength','fertility','max_lifespan','max_health','aggression'}
        assert m['traits']['plants']['aggression'] is None
    assert a['series'][-1]['metrics']['births'] == a['totals']['births']
    assert a['series'][-1]['metrics']['deaths'] == a['totals']['deaths']
    assert len(a['state_hash']) == 64 and all(c in '0123456789abcdef' for c in a['state_hash'])
    assert a['tick_end'] == 13 and a['contract'] == 1
    for kind, initial in [('plants',8),('herbivores',2),('carnivores',1)]:
        assert initial + a['totals']['births'][kind] - a['totals']['deaths'][kind] == a['final'][kind]
    assert [x['tick'] for x in run(0)['series']] == [0]
    assert [x['tick'] for x in run(3, '--sample-every', 9)['series']] == [0,3]
    assert [x['tick'] for x in run(3)['series']] == [0,1,2,3]
    overridden = run(13, '--seed', 43)
    assert overridden['state_hash'] != a['state_hash']
    original = json.loads(config.read_text()); original['seed'] = 43; config.write_text(json.dumps(original))
    assert run(13)['state_hash'] == overridden['state_hash']
    r = call('--config',config,'--ticks',1,'--out',p/'missing-dir'/'out.json'); assert r.returncode == 2 and r.stderr
    config.write_text(json.dumps({'seed': 0, 'world': {'width': 1, 'height': 1}, 'initial': {'plants': 0, 'herbivores': 0, 'carnivores': 0}}))
    assert run(20)['tick_end'] == 20
    config.write_text(json.dumps({'seed': 0, 'world': {'width': 1, 'height': 1}, 'initial': {'plants': 0, 'herbivores': 1, 'carnivores': 1}}))
    extinct = run(1200)['final']; assert extinct['herbivores'] == extinct['carnivores'] == 0
    out = p / 'missing.json'
    for args in [('--config',config,'--ticks',-1,'--out',out), ('--config',config,'--ticks',1,'--out',out,'--sample-every',0), ('--config',config,'--ticks',1,'--out',out,'--seed',1,'--seed',2), ('--config',config,'--ticks',1,'--out',out,'--load','x'), ('--config',p/'absent','--ticks',1,'--out',out), ('--config',config,'--out',out)]:
        r = call(*args); assert r.returncode == 2 and r.stderr and not out.exists(), (args,r.stderr)
    config.write_text('{}'); r = call('--config',config,'--ticks',1,'--out',out); assert r.returncode == 2 and r.stderr and not out.exists()
    out.write_text('preserve'); r = call('--config',config,'--ticks',1,'--out',out); assert r.returncode == 2 and out.read_text() == 'preserve'
print('run CLI integration checks passed')

use evosim::{
    config::Config,
    geometry::Cell,
    organism::{DeathCause, Event, Kind, Traits},
    simulation::Simulation,
};

fn config() -> Config {
    Config::from_json(r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#).unwrap()
}
fn birth(kind: Kind, parent: u64, _lifespan: u32) -> Event {
    Event::Birth {
        kind,
        position: Cell { x: 0, y: 0 },
        parents: [Some(parent), None],
    }
}
#[test]
fn traits_validate_bounds_and_kinds() {
    assert!(Traits::new(Kind::Plant, 0, 0, 0, 1, 1, None).is_ok());
    assert!(Traits::new(Kind::Herbivore, 10, 100, 100, 1_000_000, 1000, Some(100)).is_ok());
    for t in [
        Traits::new(Kind::Plant, 11, 0, 0, 1, 1, None),
        Traits::new(Kind::Plant, 0, 101, 0, 1, 1, None),
        Traits::new(Kind::Plant, 0, 0, 101, 1, 1, None),
        Traits::new(Kind::Plant, 0, 0, 0, 0, 1, None),
        Traits::new(Kind::Plant, 0, 0, 0, 1_000_001, 1, None),
        Traits::new(Kind::Plant, 0, 0, 0, 1, 0, None),
        Traits::new(Kind::Plant, 0, 0, 0, 1, 1001, None),
        Traits::new(Kind::Plant, 0, 0, 0, 1, 1, Some(0)),
        Traits::new(Kind::Carnivore, 0, 0, 0, 1, 1, None),
        Traits::new(Kind::Carnivore, 0, 0, 0, 1, 1, Some(101)),
    ] {
        assert!(t.is_err());
    }
}
#[test]
fn founders_deferred_births_deaths_and_accounting() {
    let mut sim = Simulation::new(&config()).unwrap();
    for (id, kind) in [(0, Kind::Plant), (1, Kind::Herbivore), (2, Kind::Carnivore)] {
        let o = &sim.living()[&id];
        assert_eq!(
            (
                o.id(),
                o.kind(),
                o.position(),
                o.age(),
                o.energy(),
                o.health(),
                o.parents(),
                o.generation()
            ),
            (id, kind, Cell { x: 0, y: 0 }, 0, 1000, 100, [None, None], 0)
        );
    }
    let events = [
        birth(Kind::Plant, 0, 1),
        Event::Death {
            id: 0,
            cause: DeathCause::External,
        },
        Event::Death {
            id: 0,
            cause: DeathCause::Injury,
        },
        Event::Adjust {
            id: 1,
            energy: -5000,
            health: 0,
        },
        Event::Adjust {
            id: 2,
            energy: 0,
            health: -5000,
        },
    ];
    sim.advance_with_events(&events).unwrap();
    assert_eq!(sim.living().keys().copied().collect::<Vec<_>>(), vec![3]);
    assert_eq!(sim.living()[&3].age(), 0);
    assert_eq!(sim.living()[&3].parents(), [Some(0), None]);
    assert_eq!(sim.living()[&3].generation(), 1);
    assert_eq!(
        sim.death_records()
            .iter()
            .map(|r| r.cause)
            .collect::<Vec<_>>(),
        vec![
            DeathCause::External,
            DeathCause::Starvation,
            DeathCause::Injury
        ]
    );
    assert_eq!(
        (
            sim.births().plants,
            sim.births().herbivores,
            sim.births().carnivores
        ),
        (1, 0, 0)
    );
    assert_eq!(
        (
            sim.deaths().plants,
            sim.deaths().herbivores,
            sim.deaths().carnivores
        ),
        (1, 1, 1)
    );
    sim.advance_one_tick().unwrap();
    assert!(sim.living().contains_key(&3));
    assert!(sim
        .advance_with_events(&[birth(Kind::Plant, 3, 3)])
        .is_err());
    for kind in [Kind::Plant, Kind::Herbivore, Kind::Carnivore] {
        let living = sim.living().values().filter(|o| o.kind() == kind).count() as u64;
        let (b, d) = match kind {
            Kind::Plant => (sim.births().plants, sim.deaths().plants),
            Kind::Herbivore => (sim.births().herbivores, sim.deaths().herbivores),
            Kind::Carnivore => (sim.births().carnivores, sim.deaths().carnivores),
        };
        assert_eq!(1 + b - d, living);
    }
}
#[test]
fn invalid_events_are_atomic_and_extinction_advances() {
    let mut sim = Simulation::new(&config()).unwrap();
    let before = sim.clone();
    assert!(sim
        .advance_with_events(&[
            Event::Death {
                id: 0,
                cause: DeathCause::External
            },
            birth(Kind::Plant, 0, 1)
        ])
        .is_err());
    assert_eq!(sim, before);
    sim.advance_with_events(
        &(0..3)
            .map(|id| Event::Death {
                id,
                cause: DeathCause::External,
            })
            .collect::<Vec<_>>(),
    )
    .unwrap();
    sim.advance_one_tick().unwrap();
    assert_eq!(sim.tick(), 2);
    assert!(sim.living().is_empty());
}

#[test]
fn event_birth_transfers_energy_and_cannot_manufacture_energy() {
    let mut sim = Simulation::new(&config()).unwrap();
    let before = sim.clone();
    assert!(sim
        .advance_with_events(&[Event::Adjust {
            id: 0,
            energy: 1,
            health: 0
        }])
        .is_err());
    assert_eq!(sim, before);
    sim.advance_with_events(&[birth(Kind::Plant, 0, 0)])
        .unwrap();
    assert_eq!(sim.living()[&3].energy(), 400);
    assert!(sim.living()[&0].energy() <= 607);
    let before = sim.clone();
    assert!(sim
        .advance_with_events(&[birth(Kind::Plant, 0, 0)])
        .is_err());
    assert_eq!(sim, before);
}

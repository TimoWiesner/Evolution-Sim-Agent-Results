#!/usr/bin/env python3
"""Deterministic randomized public CLI accounting, extinction and replay checks."""
import json, random, subprocess, tempfile
from pathlib import Path

rng = random.Random(2801)
with tempfile.TemporaryDirectory() as d:
    d = Path(d)
    for case in range(16):
        initial = dict(zip(('plants','herbivores','carnivores'), (rng.randrange(0, 9) for _ in range(3))))
        cfg = {'seed': rng.randrange(100000), 'world': {'width': rng.choice((1,2,3,7)), 'height': rng.choice((1,2,4,8))}, 'initial': initial}
        (d/'cfg').write_text(json.dumps(cfg))
        def run(name, extra):
            subprocess.run(['./evosim','run',*extra,'--out',str(d/name),'--sample-every','1'], check=True, capture_output=True)
            return json.loads((d/name).read_text())
        a = run('a', ['--config',str(d/'cfg'),'--ticks','30','--save',str(d/'save')])
        b = run('b', ['--config',str(d/'cfg'),'--ticks','30'])
        assert all(a[k] == b[k] for k in ('final','totals','series','state_hash')), (case,cfg)
        c = run('c', ['--load',str(d/'save'),'--ticks','10'])
        full = run('full', ['--config',str(d/'cfg'),'--ticks','40'])
        assert all(c[k] == full[k] for k in ('final','totals','state_hash')), (case,cfg)
        gone = set()
        for sample in a['series']:
            for kind in initial:
                n = sample[kind]
                assert n >= 0 and initial[kind] + sample['metrics']['births'][kind] - sample['metrics']['deaths'][kind] == n, (case, sample['tick'], kind)
                assert kind not in gone or n == 0, (case, sample['tick'], kind)
                if n == 0: gone.add(kind)
        other = run('other', ['--config',str(d/'cfg'),'--seed',str(cfg['seed']+1),'--ticks','30'])
        assert a['state_hash'] != other['state_hash'], case
print('16 randomized configurations: accounting, extinction, determinism and checkpoint replay passed')

use std::process::Command;

fn run(args: &[&str]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .output()
        .unwrap()
}

#[test]
fn version_is_clean_contract_json() {
    let out = run(&["version"]);
    assert!(out.status.success());
    assert_eq!(
        out.stdout,
        b"{\"name\":\"evosim\",\"version\":\"0.1.0\",\"contract\":1}\n"
    );
    assert!(out.stderr.is_empty());
}

#[test]
fn help_lists_available_command() {
    let out = run(&["--help"]);
    assert!(out.status.success());
    assert!(String::from_utf8(out.stdout).unwrap().contains("version"));
    assert!(out.stderr.is_empty());
}

#[test]
fn invalid_commands_fail_cleanly() {
    for args in [vec!["unknown"], vec![], vec!["version", "extra"]] {
        let out = run(&args);
        assert_eq!(out.status.code(), Some(2));
        assert!(out.stdout.is_empty());
        assert!(!out.stderr.is_empty());
    }
}

// Execute the production renderer extracted from the embedded page without a display.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const page = fs.readFileSync('src/ui/index.html', 'utf8');
const source = page.slice(page.indexOf('function chart('), page.indexOf('function drawCharts('));
const context = {palette:['red','green','blue']};
vm.createContext(context); vm.runInContext(source, context);
const render = (values, labels, positions) => context.chart('Test', [{name:'Plants',values}], labels, positions);
let svg = render([1,2,3,4], [0,10], [0,1,2,10]);
assert.deepStrictEqual([...svg.match(/points="([^"]+)"/)[1].matchAll(/([\d.]+),[\d.]+/g)].map(x=>+x[1]), [45,93,141,525]);
assert(svg.includes('>0</text>') && svg.includes('>10</text>'));
svg = render([], ['—','—'], []); assert(!/NaN|Infinity|polyline|circle/.test(svg));
svg = render([2], [7,7], [7]); assert(svg.includes('cx="45"') && !/NaN|Infinity/.test(svg));
svg = render([1,null,2,3,null,4], [0,10], [0,1,2,3,4,10]);
assert.equal((svg.match(/<circle/g)||[]).length, 2); assert.equal((svg.match(/<polyline/g)||[]).length, 1);
svg = render([1,2,3,4], ['0','100']);
assert.deepStrictEqual([...svg.match(/points="([^"]+)"/)[1].matchAll(/([\d.]+),[\d.]+/g)].map(x=>+x[1]), [45,205,365,525]);
console.log('Production chart renderer: uneven ticks, empty, singleton, null gaps and bins passed');

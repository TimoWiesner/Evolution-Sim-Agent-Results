"""Exercise the real UI through Chromium DevTools, with only Python's standard library."""
import base64, json, os, socket, struct, subprocess, tempfile, time, urllib.request
from pathlib import Path
root = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as tmp:
    config = Path(tmp) / 'config.json'
    config.write_text(json.dumps({'seed':42,'world':{'width':100,'height':100},'initial':{'plants':3000,'herbivores':0,'carnivores':0}}))
    server = subprocess.Popen([str(root/'evosim'),'ui','--config',str(config)],stderr=subprocess.PIPE, text=True, env={**os.environ,'PATH':'/usr/bin:/bin'})
    chrome = None
    try:
        url=server.stderr.readline().strip().split()[-1]
        port=socket.socket(); port.bind(('127.0.0.1',0)); number=port.getsockname()[1]; port.close()
        chrome=subprocess.Popen([os.environ.get('CHROME_BIN','chromium'),'--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage',f'--remote-debugging-port={number}',f'--user-data-dir={tmp}/profile','--window-size=1280,720',url],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:
                pages=json.load(urllib.request.urlopen(f'http://127.0.0.1:{number}/json',timeout=1)); break
            except OSError: time.sleep(.1)
        ws=pages[0]['webSocketDebuggerUrl']; hostport,path=ws[5:].split('/',1); host,port=hostport.split(':'); s=socket.create_connection((host,int(port)))
        key=base64.b64encode(os.urandom(16)).decode(); s.sendall(f'GET /{path} HTTP/1.1\r\nHost: {hostport}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n'.encode()); assert b'101' in s.recv(4096)
        seq=0
        def read(n):
            b=b''
            while len(b)<n: b+=s.recv(n-len(b))
            return b
        def call(method,params):
            global seq
            seq+=1; payload=json.dumps({'id':seq,'method':method,'params':params}).encode(); mask=os.urandom(4); n=len(payload); header=bytes([0x81,0x80|n]) if n<126 else bytes([0x81,0x80|126])+struct.pack('!H',n)
            s.sendall(header+mask+bytes(c^mask[i%4] for i,c in enumerate(payload)))
            while True:
                a,b=read(2); n=b&127
                if n==126:n=struct.unpack('!H',read(2))[0]
                if n==127:n=struct.unpack('!Q',read(8))[0]
                msg=json.loads(read(n))
                if msg.get('id')==seq: return msg
        call('Emulation.setDeviceMetricsOverride',{'width':1280,'height':720,'deviceScaleFactor':1,'mobile':False})
        def evaluate(expr): return call('Runtime.evaluate',{'expression':expr,'returnByValue':True})['result']['result'].get('value')
        for _ in range(100):
            first=evaluate('window.uiEvidence || null')
            if first and first['population']>=1000: break
            time.sleep(.05)
        assert first and first['population']>=1000, first
        time.sleep(3)
        last=evaluate('window.uiEvidence')
        assert last['population']>=1000 and last['tick']>first['tick'] and last['rendered']-first['rendered']>=9,(first,last)
        evaluate("canvas.dispatchEvent(new WheelEvent('wheel',{deltaY:-200,clientX:300,clientY:300,cancelable:true}))")
        evaluate("canvas.dispatchEvent(new PointerEvent('pointerdown',{pointerId:1,clientX:100,clientY:100})); canvas.dispatchEvent(new PointerEvent('pointermove',{pointerId:1,clientX:140,clientY:130})); canvas.dispatchEvent(new PointerEvent('pointerup',{pointerId:1}))")
        after=evaluate('window.uiEvidence'); assert after['zoom']!=last['zoom'] and after['panX']!=last['panX'], (last,after)
        assert evaluate("document.querySelector('aside').innerText.includes('Carnivores') && document.querySelector('aside').innerText.includes('Tropical')")
        evaluate("document.querySelector('#pause').click()")
        time.sleep(.5)
        paused=evaluate('data.tick'); time.sleep(.3); assert evaluate('data.tick')==paused
        evaluate("document.querySelector('#step').click()")
        time.sleep(.4); assert evaluate('data.tick')==paused+1
        # Select a rendered organism using the same coordinates as the canvas.
        def click_organism():
            point=evaluate("(()=>{let p=points.find(p=>p.cx>0&&p.cy>0&&p.cx<canvas.clientWidth&&p.cy<canvas.clientHeight),r=canvas.getBoundingClientRect();return p?{x:r.left+p.cx,y:r.top+p.cy}:null})()")
            assert point
            call('Input.dispatchMouseEvent',{'type':'mousePressed','x':point['x'],'y':point['y'],'button':'left','clickCount':1})
            call('Input.dispatchMouseEvent',{'type':'mouseReleased','x':point['x'],'y':point['y'],'button':'left','clickCount':1})
        click_organism()
        time.sleep(.4); assert evaluate("document.querySelector('#inspector').textContent.includes('Genome')")
        # Verify actual viewport geometry, clipping and stacking, including after scrolling.
        def visible(selector):
            return evaluate("""(()=>{let e=document.querySelector(%s),r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+Math.min(r.height/2,8),hit=document.elementFromPoint(x,y);return r.width>0&&r.height>0&&r.left>=0&&r.right<=innerWidth&&r.top>=0&&r.bottom<=innerHeight&&getComputedStyle(e).visibility==='visible'&&(hit===e||e.contains(hit));})()""" % json.dumps(selector))
        assert evaluate('innerWidth===1280 && innerHeight===720'), evaluate('[innerWidth,innerHeight]')
        def summary_visible():
            return all(visible(x) for x in ['#tick','#n0','#n1','#n2'])
        assert summary_visible() and visible('#inspector-heading') and visible('#inspector')
        assert all(evaluate("document.querySelector('#inspector').textContent.includes(%s)" % json.dumps(x)) for x in ['ID:', 'Kind:', 'Species:', 'Age:', 'Energy:', 'Health:', 'Parents:', 'Traits:', 'Genome'])
        evaluate("document.querySelector('#inspector').scrollTop=9999;document.querySelector('.sidebar-scroll').scrollTop=9999")
        assert summary_visible()
        click_organism()
        time.sleep(.4)
        assert summary_visible() and visible('#inspector-heading') and visible('#inspector')
        selected_id=evaluate('selected')
        before_age=evaluate('data.detail.age')
        evaluate("document.querySelector('#run').click()")
        for _ in range(100):
            time.sleep(.1)
            if evaluate("data.detail && (data.detail.status!=='alive' || data.detail.age>"+str(before_age)+")"): break
        assert evaluate("data.detail && (data.detail.status!=='alive' || data.detail.age>"+str(before_age)+")")
        # Follow the same real organism until its inevitable death, bounded by its founder lifespan.
        for _ in range(300):
            if evaluate("data.detail && data.detail.status==='dead'"): break
            time.sleep(.1)
        assert evaluate("selected === "+json.dumps(selected_id)+" && data.detail && data.detail.status==='dead' && document.querySelector('#inspector').textContent.includes('DEAD')")
        assert summary_visible() and visible('#inspector-heading') and visible('#inspector')
        evaluate("document.querySelector('#pause').click()")
        time.sleep(.4)
        paused=evaluate('data.tick')-1
        # Exercise the same checkpoint HTTP operations used by Save and Load.
        checkpoint=evaluate("fetch('/checkpoint').then(r=>r.arrayBuffer()).then(b=>{window.savedCheckpoint=b;return b.byteLength})")
        # Runtime.evaluate awaits promises only when explicitly requested; use an asynchronous page task.
        evaluate("fetch('/checkpoint').then(r=>r.arrayBuffer()).then(b=>window.savedCheckpoint=b)")
        time.sleep(.4)
        evaluate("document.querySelector('#step').click()")
        time.sleep(.4)
        evaluate("command('/load',window.savedCheckpoint)")
        time.sleep(.5); assert evaluate('data.tick')==paused+1
        evaluate("document.querySelector('#reset').click()")
        time.sleep(.4); assert evaluate('data.tick')==0
        assert evaluate("document.querySelector('#inspector').textContent.includes('Select')")
        # Exercise the experiment editor and chart presentation in the real page.
        evaluate("document.querySelector('#setup-open').click(); document.querySelector('#preset').value='lush';document.querySelector('#preset').dispatchEvent(new Event('change'))")
        time.sleep(.4)
        assert evaluate("document.querySelectorAll('#fields input').length===12")
        call('Browser.setDownloadBehavior', {'behavior':'allow','downloadPath':tmp})
        expected=evaluate('JSON.stringify(formConfig())')
        evaluate("document.querySelector('#export-config').click()")
        exported=Path(tmp)/'evosim-config.json'
        for _ in range(100):
            if exported.exists(): break
            time.sleep(.05)
        assert json.loads(exported.read_text())==json.loads(expected)
        evaluate("document.querySelector('[data-key=\"seed\"]').value='99'")
        node=call('DOM.getDocument',{})['result']['root']['nodeId']
        input_node=call('DOM.querySelector',{'nodeId':node,'selector':'#config-file'})['result']['nodeId']
        call('DOM.setFileInputFiles',{'nodeId':input_node,'files':[str(exported)]})
        time.sleep(.4)
        assert json.loads(evaluate('JSON.stringify(formConfig())'))==json.loads(expected)
        evaluate("document.querySelector('[data-key=\"world.width\"]').value='0'; document.querySelector('#start-world').click()")
        time.sleep(.4)
        assert evaluate("document.querySelector('[data-error=\"world.width\"]').textContent.length>0 && data.tick===0")
        evaluate("document.querySelector('[data-key=\"world.width\"]').value='32';document.querySelector('#start-world').click()")
        time.sleep(.6)
        assert evaluate("!document.querySelector('#panel').classList.contains('open') && data.width===32")
        evaluate("document.querySelector('#charts-open').click()")
        time.sleep(.3)
        assert evaluate("document.querySelectorAll('#charts svg').length===4 && document.querySelector('#charts').textContent.includes('Tick') && document.querySelector('#charts').textContent.includes('births')")
        # Mix single-step samples with the scheduled ten-tick sample, then inspect actual SVG points.
        evaluate("document.querySelector('#reset').click()")
        time.sleep(.4)  # Let reset complete and its snapshot arrive before stepping.
        for _ in range(100):
            if evaluate('!busy && data.tick===0 && data.history.length===1'): break
            time.sleep(.05)
        for tick in (1, 2):
            evaluate("document.querySelector('#step').click()")
            for _ in range(100):
                if evaluate('data.tick==='+str(tick)): break
                time.sleep(.05)
            assert evaluate('data.tick')==tick
        evaluate("document.querySelector('#run').click()")
        for _ in range(200):
            if evaluate('data.history.some(x=>x.tick>=10)'): break
            time.sleep(.05)
        assert evaluate('data.history.some(x=>x.tick>=10)')
        evaluate("document.querySelector('#pause').click()")
        time.sleep(.4)
        evidence=evaluate("""(()=>{let ticks=data.history.map(x=>x.tick), svgs=[...document.querySelectorAll('#charts svg')];return {ticks, points:svgs.map(svg=>svg.querySelector('polyline')?.getAttribute('points'))}})()""")
        assert evidence['ticks'][:4]==[0,1,2,10], evidence
        for points in evidence['points']:
            assert points, evidence
            xs=[float(point.split(',')[0]) for point in points.split()]
            expected_x=[45+480*(tick-evidence['ticks'][0])/(evidence['ticks'][-1]-evidence['ticks'][0]) for tick in evidence['ticks']]
            assert len(xs)==len(expected_x) and all(abs(a-b)<1e-6 for a,b in zip(xs,expected_x)), evidence
        evaluate("document.querySelector('#trait').value='fertility';document.querySelector('#trait').dispatchEvent(new Event('change'))")
        assert evaluate("document.querySelector('#distribution').textContent.includes('fertility')")
        print('3-second browser evidence:', first, last, 'after interaction:', after)
    finally:
        if chrome: chrome.terminate(); chrome.wait(timeout=10)
        server.terminate(); server.wait(timeout=10)

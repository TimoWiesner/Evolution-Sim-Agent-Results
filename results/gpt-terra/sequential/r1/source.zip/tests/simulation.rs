use evosim::config::Config;
use evosim::rng::SplitMix64;
use evosim::simulation::Simulation;

#[test]
fn splitmix_known_vectors_and_restore() {
    let mut zero = SplitMix64::new(0);
    assert_eq!(zero.next_u64(), 0xe220a8397b1dcdaf);
    assert_eq!(zero.next_u64(), 0x6e789e6aa1b965f4);
    let mut negative = SplitMix64::new(-1);
    assert_eq!(negative.next_u64(), 0xe4d971771b652c20);
    let state = negative.state();
    let mut restored = SplitMix64::from_state(state);
    for _ in 0..100 {
        assert_eq!(negative.next_u64(), restored.next_u64());
    }
    assert_eq!(SplitMix64::from_state(0), SplitMix64::new(0));
}

fn trace(seed: i64) -> Vec<(u64, u64, u64, u64)> {
    let mut config = Config::preset("temperate").unwrap();
    config.seed = seed;
    let mut sim = Simulation::new(&config).unwrap();
    let mut trace = Vec::new();
    for _ in 0..120 {
        sim.advance_one_tick().unwrap();
        let value = sim.rng_mut().next_u64();
        trace.push((sim.tick(), sim.world().width(), sim.world().height(), value));
    }
    trace
}

#[test]
fn seeded_tick_traces_repeat_and_differ() {
    assert_eq!(trace(42), trace(42));
    assert_ne!(trace(42), trace(43));
    assert_eq!(trace(42).last().unwrap().0, 120);
}

#[test]
fn construction_validation_and_ticks() {
    let mut config = Config::preset("temperate").unwrap();
    config.initial.plants = 0;
    config.initial.carnivores = 0;
    config.initial.herbivores = 0;
    config.climate.weather_strength = 0.0;
    let mut sim = Simulation::new(&config).unwrap();
    assert_eq!(sim.tick(), 0);
    assert_eq!((sim.world().width(), sim.world().height()), (64, 48));
    let rng_before = sim.rng().state();
    sim.advance_one_tick().unwrap();
    assert_eq!(sim.tick(), 1);
    for _ in 1..100 {
        sim.advance_one_tick().unwrap();
    }
    assert_eq!(sim.tick(), 100);
    assert_eq!(sim.rng().state(), rng_before);
    config.world.width = 0;
    assert!(Simulation::new(&config).is_err());
}

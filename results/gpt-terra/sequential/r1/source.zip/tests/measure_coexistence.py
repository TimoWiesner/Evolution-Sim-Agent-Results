import json, subprocess, tempfile, time
from pathlib import Path
base={'seed':42,'world':{'width':64,'height':48},'initial':{'plants':400,'herbivores':120,'carnivores':20}}
records=[]
with tempfile.TemporaryDirectory(dir='target') as tmp:
 p=Path(tmp)
 for label,plants,herbs,carns,seeds,ticks in [('baseline',400,120,20,[11,12],1000),('candidate',700,120,20,[11,12],1000),('example',400,120,20,[101,102,103],10000),('demo',700,120,20,[101,102,103],10000)]:
  cfg={**base,'initial':{'plants':plants,'herbivores':herbs,'carnivores':carns}}
  (p/'cfg.json').write_text(json.dumps(cfg))
  for seed in seeds:
   command=['./evosim','run','--config',str(p/'cfg.json'),'--seed',str(seed),'--ticks',str(ticks),'--sample-every','1','--out',str(p/'out.json')]
   started=time.monotonic()
   try:
    proc=subprocess.run(command,capture_output=True,text=True,timeout=300 if label=='example' else 900)
    rec={'label':label,'config':cfg,'seed':seed,'ticks':ticks,'command':' '.join(command),'exit_code':proc.returncode,'wall_seconds':round(time.monotonic()-started,3)}
    if proc.returncode==0:
     v=json.loads((p/'out.json').read_text()); s=v['series']; assert [x['tick'] for x in s]==list(range(ticks+1))
     for k,n in cfg['initial'].items(): assert n+v['totals']['births'][k]-v['totals']['deaths'][k]==v['final'][k]
     rec.update(first_zero=next((x['tick'] for x in s if any(x[k]==0 for k in cfg['initial'])),None),final=v['final'],state_hash=v['state_hash'],elapsed_seconds=v['elapsed_seconds'])
    else: rec['stderr']=proc.stderr
   except subprocess.TimeoutExpired: rec={'label':label,'seed':seed,'timeout':True}
   records.append(rec); Path('docs/task028-measurements.json').write_text(json.dumps(records,indent=2)+'\n'); print(label,seed,rec.get('first_zero'),rec.get('wall_seconds'),flush=True)

#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
cargo test
python3 tests/run_cli.py
python3 tests/batch_cli.py
python3 tests/checkpoint_cli.py
python3 tests/reliability.py
node tests/chart_render.js
python3 tests/ui_browser.py
xvfb-run -a ./evosim ui --smoke-test
python3 tests/performance_guard.py

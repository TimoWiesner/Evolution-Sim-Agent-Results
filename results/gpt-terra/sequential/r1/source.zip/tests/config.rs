use evosim::config::Config;
use serde_json::{json, Value};

fn base() -> Value {
    json!({"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}})
}
fn parse(v: &Value) -> Result<Config, String> {
    Config::from_json(&v.to_string()).map_err(|e| e.to_string())
}
fn set(v: &mut Value, path: &str, value: Value) {
    let mut parts = path.split('.').peekable();
    let mut current = v;
    while let Some(part) = parts.next() {
        if parts.peek().is_none() {
            current[part] = value;
            return;
        }
        current = &mut current[part];
    }
}
#[test]
fn fixed_defaults_and_round_trip() {
    let c = parse(&base()).unwrap();
    assert_eq!(
        (
            c.climate.year_ticks,
            c.climate.seasonal_strength,
            c.genetics.mutation_rate,
            c.genetics.mutation_strength,
            c.resources.regrowth_rate
        ),
        (360, 0.25, 0.02, 0.05, 0.05)
    );
    let mut v = base();
    v["seed"] = json!(-7);
    v["world"] = json!({"width":1,"height":1});
    v["initial"] = json!({"plants":0,"herbivores":0,"carnivores":0});
    v["climate"] = json!({"year_ticks":10});
    v["genetics"] = json!({"mutation_strength":0.31});
    v["resources"] = json!({});
    let c = parse(&v).unwrap();
    assert_eq!(c.climate.seasonal_strength, 0.25);
    assert_eq!(c.genetics.mutation_rate, 0.02);
    assert_eq!(c.resources.regrowth_rate, 0.05);
    assert_eq!(Config::from_json(&c.to_json().unwrap()).unwrap(), c);
}
#[test]
fn required_keys_and_invalid_types_have_paths() {
    for path in [
        "seed",
        "world",
        "world.width",
        "world.height",
        "initial",
        "initial.plants",
        "initial.herbivores",
        "initial.carnivores",
    ] {
        let mut v = base();
        let parts: Vec<_> = path.split('.').collect();
        if parts.len() == 1 {
            v.as_object_mut().unwrap().remove(parts[0]);
        } else {
            v[parts[0]].as_object_mut().unwrap().remove(parts[1]);
        }
        assert!(parse(&v).unwrap_err().contains(path), "{path}");
    }
    for (path, value) in [
        ("seed", json!(true)),
        ("world", json!([])),
        ("world.width", json!(1.2)),
        ("world.height", json!(-1)),
        ("initial", json!(null)),
        ("initial.plants", json!(-1)),
        ("initial.herbivores", json!("1")),
        ("initial.carnivores", json!(false)),
        ("climate", json!(null)),
        ("genetics", json!([])),
        ("resources", json!(1)),
    ] {
        let mut v = base();
        set(&mut v, path, value);
        assert!(parse(&v).unwrap_err().contains(path), "{path}");
    }
    assert!(Config::from_json("[]")
        .unwrap_err()
        .to_string()
        .contains('$'));
    assert!(Config::from_json("{")
        .unwrap_err()
        .to_string()
        .contains('$'));
    for (path, raw) in [
        ("seed", "9223372036854775808"),
        ("world.width", "18446744073709551616"),
    ] {
        let mut v = base();
        set(&mut v, path, serde_json::from_str(raw).unwrap());
        assert!(parse(&v).unwrap_err().contains(path));
    }
}
#[test]
fn ranges_unknown_keys_and_nonfinite() {
    for path in ["world.width", "world.height"] {
        let mut v = base();
        set(&mut v, path, json!(0));
        assert!(parse(&v).unwrap_err().contains(path));
    }
    for (path, low, high) in [
        ("climate.year_ticks", json!(0), json!(1000001)),
        ("climate.seasonal_strength", json!(-0.1), json!(1.1)),
        ("climate.weather_strength", json!(-0.1), json!(1.1)),
        ("genetics.mutation_rate", json!(-0.1), json!(1.1)),
        ("genetics.mutation_strength", json!(-0.1), json!(1.1)),
        ("resources.regrowth_rate", json!(-0.1), json!(1.1)),
    ] {
        for value in [low, high, json!("bad")] {
            let mut v = base();
            let group = path.split('.').next().unwrap();
            v[group] = json!({});
            set(&mut v, path, value);
            assert!(parse(&v).unwrap_err().contains(path), "{path}");
        }
        for value in if path.ends_with("year_ticks") {
            vec![json!(1), json!(1000000)]
        } else {
            vec![json!(0), json!(1)]
        } {
            let mut v = base();
            let group = path.split('.').next().unwrap();
            v[group] = json!({});
            set(&mut v, path, value);
            assert!(parse(&v).is_ok(), "{path}");
        }
    }
    for path in [
        "extra",
        "world.extra",
        "initial.extra",
        "climate.extra",
        "genetics.extra",
        "resources.extra",
    ] {
        let mut v = base();
        if path.contains('.') {
            let group = path.split('.').next().unwrap();
            if v.get(group).is_none() {
                v[group] = json!({});
            }
        }
        set(&mut v, path, json!(1));
        assert!(parse(&v).unwrap_err().contains(path));
    }
    let mut c = parse(&base()).unwrap();
    c.genetics.mutation_rate = f64::NAN;
    assert!(c
        .to_json()
        .unwrap_err()
        .to_string()
        .contains("genetics.mutation_rate"));
    c.genetics.mutation_rate = 0.0;
    c.resources.regrowth_rate = f64::INFINITY;
    assert!(c
        .validate()
        .unwrap_err()
        .to_string()
        .contains("resources.regrowth_rate"));
}
#[test]
fn presets_are_distinct_valid_and_round_trip() {
    let presets: Vec<_> = ["temperate", "lush", "harsh"]
        .iter()
        .map(|n| Config::preset(n).unwrap())
        .collect();
    for c in &presets {
        c.validate().unwrap();
        assert_eq!(*c, Config::from_json(&c.to_json().unwrap()).unwrap());
    }
    assert!(
        presets[0].initial.plants != presets[1].initial.plants
            && presets[1].resources.regrowth_rate > presets[0].resources.regrowth_rate
            && presets[2].climate.seasonal_strength > presets[0].climate.seasonal_strength
    );
    assert!(Config::preset("Lush")
        .unwrap_err()
        .to_string()
        .contains("preset"));
}

use evosim::{config::Config, geometry::Cell, rng::SplitMix64, simulation::Simulation};

#[test]
fn randomized_world_values_remain_bounded() {
    let mut rng = SplitMix64::new(2801);
    for case in 0..24 {
        let mut config = Config::preset("temperate").unwrap();
        config.seed = rng.next_u64() as i64;
        config.world.width = 1 + rng.next_u64() % 8;
        config.world.height = 1 + rng.next_u64() % 8;
        config.initial.plants = rng.next_u64() % 12;
        config.initial.herbivores = rng.next_u64() % 8;
        config.initial.carnivores = rng.next_u64() % 5;
        let mut sim = Simulation::new(&config).unwrap();
        for tick in 0..40 {
            for organism in sim.living().values() {
                let p = organism.position();
                assert!(
                    p.x < config.world.width && p.y < config.world.height,
                    "case {case} tick {tick}"
                );
                assert!(organism
                    .genome()
                    .alleles()
                    .iter()
                    .flatten()
                    .all(|a| *a <= 1000));
                let t = organism.traits();
                assert!(t.speed() <= 10 && t.strength() <= 100 && t.fertility() <= 100);
                assert!(
                    (1..=1_000_000).contains(&t.max_lifespan())
                        && (1..=1000).contains(&t.max_health())
                );
                assert!(organism.health() <= t.max_health());
            }
            for y in 0..config.world.height {
                for x in 0..config.world.width {
                    assert!(sim.resources().at(Cell { x, y }) <= 100);
                }
            }
            sim.advance_one_tick().unwrap();
        }
    }
}

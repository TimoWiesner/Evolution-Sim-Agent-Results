use evosim::{config::Config, organism::Kind, simulation::Simulation};

fn config(plants: u64, herbivores: u64, carnivores: u64) -> Config {
    Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":64,"height":48}},"initial":{{"plants":{plants},"herbivores":{herbivores},"carnivores":{carnivores}}}}}"#)).unwrap()
}
fn counts(sim: &Simulation) -> [u64; 3] {
    let mut n = [0; 3];
    for o in sim.living().values() {
        n[match o.kind() {
            Kind::Plant => 0,
            Kind::Herbivore => 1,
            Kind::Carnivore => 2,
        }] += 1;
    }
    n
}
fn run(c: Config, ticks: u64) -> Simulation {
    let initial = [c.initial.plants, c.initial.herbivores, c.initial.carnivores];
    let mut sim = Simulation::new(&c).unwrap();
    let mut extinct = initial.map(|n| n == 0);
    for _ in 0..ticks {
        sim.advance_one_tick().unwrap();
        let n = counts(&sim);
        let births = sim.births();
        let deaths = sim.deaths();
        let b = [births.plants, births.herbivores, births.carnivores];
        let d = [deaths.plants, deaths.herbivores, deaths.carnivores];
        for i in 0..3 {
            assert_eq!(initial[i] + b[i] - d[i], n[i]);
            if extinct[i] {
                assert_eq!(n[i], 0, "kind {i} revived at tick {}", sim.tick());
            }
            extinct[i] |= n[i] == 0;
        }
    }
    sim
}
#[test]
fn fixed_keys_and_extinction_scenarios() {
    run(config(400, 120, 20), 1000);
    let no_plants = run(config(0, 120, 20), 2000);
    assert_eq!(counts(&no_plants), [0, 0, 0]);
    let last_herbivore = no_plants
        .death_records()
        .iter()
        .filter(|r| r.kind == Kind::Herbivore)
        .map(|r| r.tick)
        .max()
        .unwrap();
    let last_carnivore = no_plants
        .death_records()
        .iter()
        .filter(|r| r.kind == Kind::Carnivore)
        .map(|r| r.tick)
        .max()
        .unwrap();
    assert!(last_herbivore < last_carnivore);
    let no_herbivores = run(config(400, 0, 20), 2000);
    assert_eq!(counts(&no_herbivores)[2], 0);
}
#[test]
fn plants_and_well_fed_herbivores_reproduce() {
    let plants = run(config(400, 0, 0), 500);
    assert!(counts(&plants)[0] > 0 && plants.births().plants > 0);
    let herbivores = run(config(2000, 40, 0), 500);
    assert!(
        counts(&herbivores)[1] > 0 && herbivores.births().herbivores > 0,
        "counts {:?}, births {:?}",
        counts(&herbivores),
        herbivores.births()
    );
}

use evosim::geometry::{Cell, Displacement, Grid};
use std::collections::HashSet;

#[test]
fn wrapping_edges_corners_and_extreme_coordinates() {
    let g = Grid::new(7, 4).unwrap();
    assert_eq!(g.cell(-1, 0), Cell { x: 6, y: 0 });
    assert_eq!(g.cell(7, 0), Cell { x: 0, y: 0 });
    assert_eq!(g.cell(0, -1), Cell { x: 0, y: 3 });
    assert_eq!(g.cell(0, 4), Cell { x: 0, y: 0 });
    assert_eq!(g.cell(-15, 13), Cell { x: 6, y: 1 });
    assert_eq!(g.cell(-1, -1), Cell { x: 6, y: 3 });
    assert_eq!(
        g.cell(i128::MIN, i128::MAX),
        Cell {
            x: i128::MIN.rem_euclid(7) as u64,
            y: 3
        }
    );
    let huge = Grid::new(u64::MAX, u64::MAX).unwrap();
    assert_eq!(
        huge.cell(-1, -1),
        Cell {
            x: u64::MAX - 1,
            y: u64::MAX - 1
        }
    );
    assert_eq!(
        huge.cells_within(huge.cell(0, 0), u64::MAX).take(2).count(),
        2
    );
    assert!(Grid::new(0, 1).is_none());
    assert!(Grid::new(1, 0).is_none());
}

#[test]
fn shortest_directions_and_ties() {
    let g = Grid::new(7, 4).unwrap();
    let a = g.cell(0, 0);
    for (b, d) in [
        ((6, 0), (-1, 0)),
        ((1, 0), (1, 0)),
        ((0, 3), (0, -1)),
        ((0, 1), (0, 1)),
        ((6, 3), (-1, -1)),
    ] {
        assert_eq!(
            g.displacement(a, g.cell(b.0, b.1)),
            Displacement { dx: d.0, dy: d.1 }
        );
        assert_eq!(g.distance(a, g.cell(b.0, b.1)), 1);
    }
    assert_eq!(g.displacement(a, g.cell(0, 2)).dy, 2);
    assert_eq!(g.displacement(g.cell(0, 2), a).dy, 2);
    assert_eq!(
        Grid::new(2, 1)
            .unwrap()
            .displacement(Cell { x: 1, y: 0 }, Cell { x: 0, y: 0 })
            .dx,
        1
    );
    assert_eq!(g.distance(Cell { x: 7, y: 4 }, Cell { x: 6, y: 3 }), 1);
}

#[test]
fn degenerate_and_oversized_radius() {
    let one = Grid::new(1, 1).unwrap();
    assert_eq!(
        one.cells_within(one.cell(-5, 99), u64::MAX)
            .collect::<Vec<_>>(),
        vec![Cell { x: 0, y: 0 }]
    );
    assert_eq!(one.distance(one.cell(0, 0), one.cell(5, -9)), 0);
    for (w, h) in [(1, 5), (5, 1)] {
        let g = Grid::new(w, h).unwrap();
        assert_eq!(g.cells_within(g.cell(0, 0), u64::MAX).count(), 5);
        assert_eq!(
            g.cells_within(g.cell(0, 0), 0).collect::<Vec<_>>(),
            vec![g.cell(0, 0)]
        );
    }
}

#[test]
fn exhaustive_small_worlds_match_independent_brute_force() {
    for w in 1..=7u64 {
        for h in 1..=6u64 {
            let g = Grid::new(w, h).unwrap();
            for x in 0..w {
                for y in 0..h {
                    let center = g.cell(x as i128, y as i128);
                    assert_eq!(
                        center,
                        g.cell(x as i128 - 3 * w as i128, y as i128 + 4 * h as i128)
                    );
                    for radius in 0..=9u64 {
                        let actual: Vec<_> = g.cells_within(center, radius).collect();
                        assert_eq!(actual, g.cells_within(center, radius).collect::<Vec<_>>());
                        let set: HashSet<_> = actual.iter().copied().collect();
                        assert_eq!(set.len(), actual.len());
                        let mut expected = HashSet::new();
                        for xx in 0..w {
                            for yy in 0..h {
                                let ax = x.abs_diff(xx);
                                let ay = y.abs_diff(yy);
                                let distance = ax.min(w - ax).max(ay.min(h - ay));
                                let cell = Cell { x: xx, y: yy };
                                assert_eq!(g.distance(center, cell), distance);
                                assert_eq!(g.distance(center, cell), g.distance(cell, center));
                                let d = g.displacement(center, cell);
                                assert_eq!(
                                    d.dx.unsigned_abs().max(d.dy.unsigned_abs()),
                                    distance as u128
                                );
                                if distance <= radius {
                                    expected.insert(cell);
                                }
                            }
                        }
                        assert_eq!(set, expected);
                    }
                }
            }
        }
    }
}

# Evolution Simulation

A locally runnable grid-world ecological simulation with a headless command line.

From the project directory, install build prerequisites and build the launcher binary:

```sh
./setup.sh
./evosim version
```

Setup uses Rust and Cargo supplied by the environment, installs the Rust musl target and, if necessary, installs `musl-tools` using apt (requiring root), then compiles a static executable. It can be run again safely.

After setup, run the complete test suite (requires Python 3, Node, Chromium and xvfb-run) with:

```sh
./tests/all.sh
```

Create the standalone distribution with:

```sh
./build.sh
./dist/evosim version
```

The distribution is a statically linked Linux x86-64 binary and requires no Rust runtime. `./evosim --help` lists the available commands. All three root entry points work from any current directory when invoked by path.

## Configuration

The shared Rust library provides `config::Config::from_json`, `to_json`, `validate`, and `preset`. JSON is the supported format. Required keys are `seed` (signed 64-bit integer), `world.width` and `world.height` (unsigned 64-bit integers at least 1), and `initial.plants`, `initial.herbivores`, `initial.carnivores` (unsigned 64-bit integers, including zero). These integer widths are representation limits; feasible world sizes will also depend on available resources.

Every optional field defaults independently, even in a partially specified group:

| Key | Type | Inclusive range | Default | Meaning |
| --- | --- | --- | --- | --- |
| `climate.year_ticks` | integer | 1–1,000,000 | 360 | seasonal cycle length |
| `climate.seasonal_strength` | number | 0–1 | 0.25 | seasonal amplitude |
| `climate.weather_strength` | number | 0–1 | 1 | seeded weather amplitude |
| `genetics.mutation_rate` | number | 0–1 | 0.02 | per-locus mutation probability |
| `genetics.mutation_strength` | number | 0–1 | 0.05 | mutation step fraction |
| `resources.regrowth_rate` | number | 0–1 | 0.05 | reserved; currently has no effect |

For example, `{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}` is valid. Unknown keys are rejected to catch mistakes. Duplicate JSON object keys use the last value, as in serde_json's value parser. Invalid values are reported with their key path. The case-sensitive presets `temperate`, `lush`, and `harsh` are available by name through the library. Temperate uses the example and defaults; lush starts with 700 plants, regrowth 0.1, seasonal strength 0.1; harsh starts with 200 plants, regrowth 0.02, seasonal strength 0.7. These values are initial design choices, not calibrated survival guarantees. The current resource regrowth setting is reserved and does not yet change the engine’s fixed resource cycle.

## Headless simulation

For example, create a configuration and run 1,000 ticks:

```sh
printf '%s\n' '{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}' > config.json
./evosim run --config config.json --ticks 1000 --out result.json --seed 42 --sample-every 10
```

`--seed` overrides the configuration; `--sample-every` defaults to one hundredth of the requested ticks, at least one. The initial and final ticks are always included. Zero ticks is valid. Invalid arguments, configuration and output errors return status 2 with a message on stderr; output is replaced only after a successful run. The result includes a SHA-256 digest of the complete simulation state and elapsed timing. Checkpoint continuation and batch commands are described below.

Run the launcher integration checks after `./setup.sh` with `python3 tests/run_cli.py`.

## Climate map

`./evosim climate-map --config path/to/config.json` prints one row per grid row, with one character per cell: `P` polar, `U` tundra, `M` temperate, `D` dry and `T` tropical. It runs without a UI and streams its output. Large worlds produce correspondingly large maps.

The static climate uses a cell-centered cosine latitude, with a cold belt at the top/bottom seam and a hot belt halfway around the world. Thus the torus has two mirrored sequences of latitude zones, a compromise for Earth's poles and equator on a world with no edges. Temperature and precipitation are continuous fields; the displayed biome categories have discrete boundaries. Longitude is uniform. Small worlds sample fewer zones; a 1×1 world samples the hot midpoint.

Climate configuration optionally accepts `climate.year_ticks` (default 360), `climate.seasonal_strength` (default 0.25), and `climate.weather_strength` (default 1). Both strengths range from 0 to 1; set weather strength to zero for exactly repeating years. Current temperatures are bounded to -60–60 °C and precipitation rates to 0–3000 mm/year-equivalent. Seasons and spatially uniform seeded weather affect plant growth and herbivore maintenance.

### Plant energy

Plants draw energy from a shared cell reserve, supplied initially and replenished by a simplified sunlight and nutrient cycle. Current temperature, precipitation and genome-derived strength limit assimilation; maintenance consumes energy, and plants die from age or starvation. Cell reserves and plant energy are capped, so plants compete locally. Plants reproduce asexually by transferring energy to a seed in a nearby unoccupied, resource-bearing cell, including across wrapped edges. Seeds inherit mutated genomes and first act on the next tick.

The simulation core models herbivores seeking visible plants and taking a limited, conserved bite from their own or an adjacent wrapped cell. Temperature affects their maintenance cost, and less aggressive herbivores pause near visible carnivores. These ecological parameters are provisional.

Carnivores pursue visible herbivores and hunt within one cell. Strength, speed and seeded chance determine success; maintenance, movement and attack costs can cause starvation. Hunting parameters are provisional.

### Sampled evolution metrics

`evosim run --config FILE --ticks N --out FILE [--sample-every K]` writes metrics inside every `series` entry in the result JSON. The existing `tick`, `plants`, `herbivores`, and `carnivores` fields are the population at that completed tick. Sampling includes the initial and final ticks once; the default interval is `max(1, floor(N/100))`.

Each sample's `metrics` object contains:

- `births` and `deaths`: counts by `plants`, `herbivores`, and `carnivores`, cumulative from tick zero (initial individuals are not births).
- `deaths_by_cause`: per kind, cumulative `age`, `starvation`, `injury`, `grazing`, `predation`, and `external` counts, including zero counts.
- `species`: living species counts per kind.
- `traits`: per kind, `speed`, `strength`, `fertility`, `max_lifespan`, `max_health`, and `aggression`. Each applicable trait is an object with `mean` and `stddev` among living individuals. Spread is population standard deviation (divide by population size), computed in floating point. These are inherited phenotypes, not current health or energy. A trait is `null` for an empty kind; plant aggression is always `null`.
- `generation`: per kind, `highest` and `mean` among living individuals; both are `null` for an empty kind. Founders are generation zero.

Counts reflect committed births and deaths at each sample; subtract successive cumulative values for interval counts. Sampling is read-only and does not consume simulation randomness. Frequent sampling increases computation and output size.

### Batch runs and CSV

Run one simulation per signed seed, sequentially:

```sh
./evosim batch --config scenarios/demo.json --seeds 1,2,3 --ticks 1000 --out-dir results
./evosim batch --config scenarios/demo.json --seeds 1,2 --ticks 1000 --out-dir sweep --sweep-initial-plants 100,200 --csv sweep/summary.csv
```

Lists are comma-separated, nonempty, and cannot contain duplicates. Without a sweep, results are `seed-<seed>.json` in the output directory. A sweep varies `initial.plants` and writes `plants-<value>/seed-<seed>.json`; values are the outer loop and seeds the inner loop. Each result has the same schema and default sampling as `run`. The output directory is created as needed.

`summary.json` is the authoritative manifest: `runs` contains seed, full effective `parameters` including defaults, requested `ticks`, relative `result` path, `final` counts and species, and `state_hash`. `aggregates` contains `plants`, `herbivores`, and `carnivores`, each with final population `mean`, `min`, `max`, and `extinct_runs`. The latter counts final zero populations, including kinds absent at tick zero. Means use a wide integer sum converted to floating point. No timing appears in the summary, so identical batches produce identical summaries.

The optional CSV contains the columns `type,seed,parameters,ticks,result,final,state_hash,kind,mean,min,max,extinct_runs`. Run rows have type `run` and JSON-encoded parameters and final fields; aggregate rows have type `aggregate` and populate the last five fields. CSV follows standard quoting. The CSV path's parent must exist; it cannot collide with a result or summary. Completed results may remain if a later run or write fails, and existing unrelated files are not removed; use the summary as the manifest rather than directory contents. Existing outputs may be replaced on success.

### Checkpoints

Save and continue a headless run with:

```sh
./evosim run --config config.json --ticks 100 --out first.json --save world.evo
./evosim run --load world.evo --ticks 900 --out continued.json --save later.evo
```

A loaded run advances the requested additional ticks, reports absolute tick numbers and cumulative totals, and preserves the effective seed. `--seed` applies only to configuration runs. Input, result and checkpoint paths must be distinct; existing paths and parent directories are resolved to detect aliases. Invalid checkpoints fail without writing a result. Each output is replaced atomically, but writing the checkpoint and result is not a single transaction: a checkpoint can be published if the subsequent result write fails.

Checkpoints are uncompressed versioned binary files with a SHA-256 damage check and complete simulation state. They are intended for the same build and version; incompatible format versions are rejected. The checksum detects accidental corruption, not malicious tampering. Files and memory use grow with world size and retained history.

### Live world view

Run `./evosim ui` to start the local browser interface, or `./evosim ui --config scenarios/demo.json` to use a configuration. The program prints a loopback URL and attempts to open the default browser; open that URL manually if it does not. Stop the server with Ctrl+C. The simulation runs in the same engine as headless mode. Drag the map to pan and use the mouse wheel to zoom; the sidebar identifies biome colors and organism symbols. Each organism is drawn, including organisms sharing a cell. The world wraps on both axes.

Chromium is required for `xvfb-run -a ./evosim ui --smoke-test` and `./evosim ui --screenshots EXISTING_DIRECTORY`; set `CHROME_BIN` if it is not named `chromium`. These commands render the real interface and exit automatically. Interactive use requires a modern browser; no external web assets are loaded.

The world view starts running. Use Run, Pause, Step, Reset and the speed selector to control time; Step pauses and advances one tick. Reset restores the startup configuration and seed. Click an organism to inspect its current traits, named genome alleles and parents; repeated clicks cycle overlapping organisms. Its death is shown in the inspector. Save downloads a checkpoint and Load opens one; loading pauses and clears the selection. Checkpoint uploads are limited to 64 MiB.

### Experiments and charts

In the UI, **New experiment** loads a preset and lets you edit the seed, dimensions, initial populations, year length, seasonal and weather strengths, mutation rate and strength, and resource regrowth. Start creates a paused world; Reset returns to the most recently started configuration. Export JSON saves the effective form configuration, and Import JSON validates and fills the form without starting a world. The browser editor requires integers representable exactly by JavaScript (within ±2^53−1); the engine remains the authoritative validator. Checkpoint Save/Load is separate.

**Charts** displays populations, cumulative births and deaths, living species and mean speed, with a current speed, strength or fertility distribution by kind. Trait bins cover 0–10 for speed and 0–100 for strength and fertility, with the upper endpoint in the last bin. Samples are taken at tick zero, every 10 ticks and on single-step; the latest 1,000 are retained. Reset, starting a world and loading a checkpoint begin a new chart window, so prior checkpoint history is not shown. Empty populations have no mean. Charts are observational and do not change simulation state.

## Demo and measured coexistence

Start the demo with `./evosim ui --config scenarios/demo.json`. It uses a 64×48 grid and starts 700 plants, 120 herbivores and 20 carnivores. In 10,000-tick runs on this container, seeds 101, 102 and 103 first lost a kind at ticks 510, 743 and 518 respectively. The contract's 400/120/20 example first lost a kind at ticks 538, 723 and 773 for the same seeds. All three kinds were present through the preceding tick, so completed coexistence lasted respectively 509, 742 and 517 ticks for the demo and 537, 722 and 772 for the example. These are measurements, not survival guarantees. See [verification](docs/VERIFICATION.md) and [measurement records](docs/task028-measurements.json) for methods, timings and hashes.

mod batch;
mod run;
mod ui;
use evosim::{
    climate::ClimateField,
    config::Config,
    geometry::{Cell, Grid},
};
use std::{
    env,
    io::{self, Write},
    process::ExitCode,
};

fn climate_map(path: &std::ffi::OsStr) -> Result<(), String> {
    let contents = std::fs::read_to_string(path).map_err(|e| format!("Cannot read config: {e}"))?;
    let config = Config::from_json(&contents).map_err(|e| format!("Invalid config: {e}"))?;
    let grid = Grid::new(config.world.width, config.world.height).expect("validated dimensions");
    let field = ClimateField::new(grid);
    let stdout = io::stdout();
    let mut out = io::BufWriter::new(stdout.lock());
    for y in 0..grid.height() {
        for x in 0..grid.width() {
            write!(out, "{}", field.at(Cell { x, y }).biome.code()).map_err(|e| e.to_string())?;
        }
        writeln!(out).map_err(|e| e.to_string())?;
    }
    out.flush().map_err(|e| e.to_string())
}
fn main() -> ExitCode {
    let args: Vec<_> = env::args_os().skip(1).collect();
    match args.as_slice() {
        [command, rest @ ..] if command == "ui" => match ui::ui(rest) {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("{e}");
                ExitCode::from(2)
            }
        },
        [command, rest @ ..] if command == "batch" => match batch::batch(rest) {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("{e}");
                ExitCode::from(2)
            }
        },
        [command, rest @ ..] if command == "run" => match run::run(rest) {
            Ok(()) => ExitCode::SUCCESS,
            Err(e) => {
                eprintln!("{e}");
                ExitCode::from(2)
            }
        },
        [command] if command == "version" => {
            println!(
                "{{\"name\":\"evosim\",\"version\":\"{}\",\"contract\":1}}",
                env!("CARGO_PKG_VERSION")
            );
            ExitCode::SUCCESS
        }
        [command] if command == "--help" || command == "-h" => {
            println!("Usage: evosim <COMMAND>\n\nCommands:\n  run --config FILE --ticks N --out FILE  Run headlessly\n  batch --config FILE --seeds LIST --ticks N --out-dir DIR  Run a batch\n  ui [--config FILE]  Open the live world view\n  version  Print version information\n  climate-map --config FILE  Print biome map\n\nOptions:\n  -h, --help  Print help");
            ExitCode::SUCCESS
        }
        [command, flag, path] if command == "climate-map" && flag == "--config" => {
            match climate_map(path) {
                Ok(()) => ExitCode::SUCCESS,
                Err(e) => {
                    eprintln!("{e}");
                    ExitCode::from(2)
                }
            }
        }
        _ => {
            eprintln!("Invalid command or arguments. Use --help for usage.");
            ExitCode::from(2)
        }
    }
}

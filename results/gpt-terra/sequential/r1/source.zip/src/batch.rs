use crate::run::{execute, number, write_atomic};
use evosim::config::Config;
use serde_json::json;
use std::{
    collections::HashSet,
    ffi::OsString,
    fs,
    path::{Path, PathBuf},
    str::FromStr,
};

fn list<T: FromStr + Eq + std::hash::Hash + Copy>(s: &std::ffi::OsStr) -> Result<Vec<T>, String> {
    let s = s.to_str().ok_or("Invalid list")?;
    let mut seen = HashSet::new();
    s.split(',')
        .map(|v| {
            let n = v.parse::<T>().map_err(|_| "Invalid list value")?;
            if !seen.insert(n) {
                return Err("Duplicate list value".into());
            }
            Ok(n)
        })
        .collect()
}
// Resolve existing ancestors, so aliases and symlinks cannot overwrite generated files.
fn resolved(path: &Path) -> Result<PathBuf, String> {
    let absolute = if path.is_absolute() {
        path.to_owned()
    } else {
        std::env::current_dir()
            .map_err(|e| e.to_string())?
            .join(path)
    };
    let mut ancestor = absolute.as_path();
    let mut tail = Vec::new();
    while !ancestor.exists() {
        tail.push(
            ancestor
                .file_name()
                .ok_or("Invalid output path")?
                .to_owned(),
        );
        ancestor = ancestor.parent().ok_or("Invalid output path")?;
    }
    let mut result = fs::canonicalize(ancestor).map_err(|e| e.to_string())?;
    for part in tail.iter().rev() {
        result.push(part);
    }
    Ok(result)
}
fn csv_field(s: &str) -> String {
    format!("\"{}\"", s.replace('"', "\"\""))
}

pub fn batch(args: &[OsString]) -> Result<(), String> {
    let (mut config, mut seeds, mut ticks, mut out, mut sweep, mut csv) =
        (None, None, None, None, None, None);
    let mut iter = args.iter();
    while let Some(flag) = iter.next() {
        let v = iter.next().ok_or("Missing flag value")?;
        match flag.to_str() {
            Some("--config") if config.is_none() => config = Some(PathBuf::from(v)),
            Some("--seeds") if seeds.is_none() => seeds = Some(list::<i64>(v)?),
            Some("--ticks") if ticks.is_none() => ticks = Some(number::<u64>(v, "ticks")?),
            Some("--out-dir") if out.is_none() => out = Some(PathBuf::from(v)),
            Some("--sweep-initial-plants") if sweep.is_none() => sweep = Some(list::<u64>(v)?),
            Some("--csv") if csv.is_none() => csv = Some(PathBuf::from(v)),
            _ => return Err("Unknown or duplicate flag".into()),
        }
    }
    let config = fs::read_to_string(config.ok_or("Missing --config")?)
        .map_err(|e| format!("Cannot read config: {e}"))?;
    let config = Config::from_json(&config).map_err(|e| format!("Invalid config: {e}"))?;
    let seeds = seeds.ok_or("Missing --seeds")?;
    let ticks = ticks.ok_or("Missing --ticks")?;
    let out = out.ok_or("Missing --out-dir")?;
    let swept = sweep.is_some();
    let values = sweep.unwrap_or_else(|| vec![config.initial.plants]);
    let mut matrix = Vec::new();
    let mut destinations = HashSet::new();
    destinations.insert(resolved(&out.join("summary.json"))?);
    for plants in values {
        for &seed in &seeds {
            let mut c = config.clone();
            c.seed = seed;
            c.initial.plants = plants;
            c.validate().map_err(|e| e.to_string())?;
            // Catch founder count overflow before any output is created.
            c.initial
                .plants
                .checked_add(c.initial.herbivores)
                .and_then(|x| x.checked_add(c.initial.carnivores))
                .ok_or("Initial population overflow")?;
            let relative = if swept {
                format!("plants-{plants}/seed-{seed}.json")
            } else {
                format!("seed-{seed}.json")
            };
            if !destinations.insert(resolved(&out.join(&relative))?) {
                return Err("Output path collision".into());
            }
            matrix.push((c, relative));
        }
    }
    if let Some(path) = &csv {
        if !destinations.insert(resolved(path)?) {
            return Err("CSV path collides with batch output".into());
        }
    }
    fs::create_dir_all(&out).map_err(|e| format!("Cannot create output directory: {e}"))?;
    let mut runs = Vec::new();
    for (c, relative) in matrix {
        let path = out.join(&relative);
        fs::create_dir_all(path.parent().unwrap()).map_err(|e| e.to_string())?;
        let result = execute(&c, ticks, (ticks / 100).max(1))?;
        write_atomic(
            &path,
            &serde_json::to_vec(&result).map_err(|e| e.to_string())?,
        )?;
        runs.push(json!({"seed":c.seed,"parameters":c,"ticks":ticks,"result":relative,"final":result["final"],"state_hash":result["state_hash"]}));
    }
    let mut aggregates = serde_json::Map::new();
    for kind in ["plants", "herbivores", "carnivores"] {
        let counts: Vec<u64> = runs
            .iter()
            .map(|r| r["final"][kind].as_u64().unwrap())
            .collect();
        let sum: u128 = counts.iter().map(|&n| n as u128).sum();
        aggregates.insert(kind.into(), json!({"mean":sum as f64 / counts.len() as f64,"min":counts.iter().min().unwrap(),"max":counts.iter().max().unwrap(),"extinct_runs":counts.iter().filter(|&&n| n == 0).count()}));
    }
    let summary = json!({"runs":runs,"aggregates":aggregates});
    if let Some(path) = csv {
        let mut text = String::from(
            "type,seed,parameters,ticks,result,final,state_hash,kind,mean,min,max,extinct_runs\n",
        );
        for r in summary["runs"].as_array().unwrap() {
            let fields = [
                "run".to_string(),
                r["seed"].to_string(),
                r["parameters"].to_string(),
                r["ticks"].to_string(),
                r["result"].as_str().unwrap().to_string(),
                r["final"].to_string(),
                r["state_hash"].as_str().unwrap().to_string(),
                String::new(),
                String::new(),
                String::new(),
                String::new(),
                String::new(),
            ];
            text.push_str(
                &fields
                    .iter()
                    .map(|s| csv_field(s))
                    .collect::<Vec<_>>()
                    .join(","),
            );
            text.push('\n');
        }
        for kind in ["plants", "herbivores", "carnivores"] {
            let a = &summary["aggregates"][kind];
            let fields = [
                "aggregate".to_string(),
                String::new(),
                String::new(),
                String::new(),
                String::new(),
                String::new(),
                String::new(),
                kind.to_string(),
                a["mean"].to_string(),
                a["min"].to_string(),
                a["max"].to_string(),
                a["extinct_runs"].to_string(),
            ];
            text.push_str(
                &fields
                    .iter()
                    .map(|s| csv_field(s))
                    .collect::<Vec<_>>()
                    .join(","),
            );
            text.push('\n');
        }
        write_atomic(&path, text.as_bytes())?;
    }
    write_atomic(
        &out.join("summary.json"),
        &serde_json::to_vec(&summary).map_err(|e| e.to_string())?,
    )
}

//! Toroidal grid geometry. Distances use Chebyshev (eight-neighbor) steps.
//! Coordinates are representable `i128` integers; cells are canonical `u64` pairs.

/// A canonical cell returned by a grid.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, serde::Serialize, serde::Deserialize)]
pub struct Cell {
    pub x: u64,
    pub y: u64,
}

/// Shortest signed axis displacements; signs give the direction of one step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Displacement {
    pub dx: i128,
    pub dy: i128,
}

/// A rectangular torus with nonzero dimensions. Construction allocates no cells.
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Grid {
    width: u64,
    height: u64,
}

impl Grid {
    /// Returns `None` if either dimension is zero.
    pub fn new(width: u64, height: u64) -> Option<Self> {
        (width != 0 && height != 0).then_some(Self { width, height })
    }

    pub fn width(&self) -> u64 {
        self.width
    }
    pub fn height(&self) -> u64 {
        self.height
    }

    /// Wrap arbitrary representable signed coordinates into the grid.
    pub fn cell(&self, x: i128, y: i128) -> Cell {
        Cell {
            x: x.rem_euclid(self.width as i128) as u64,
            y: y.rem_euclid(self.height as i128) as u64,
        }
    }

    /// Shortest displacement from `from` to `to`. Inputs are normalized first.
    /// At an even-sized axis's antipode the positive direction wins the tie.
    pub fn displacement(&self, from: Cell, to: Cell) -> Displacement {
        fn axis(from: u64, to: u64, size: u64) -> i128 {
            let forward = (to as i128 - from as i128).rem_euclid(size as i128);
            if forward * 2 <= size as i128 {
                forward
            } else {
                forward - size as i128
            }
        }
        let from = self.cell(from.x as i128, from.y as i128);
        let to = self.cell(to.x as i128, to.y as i128);
        Displacement {
            dx: axis(from.x, to.x, self.width),
            dy: axis(from.y, to.y, self.height),
        }
    }

    /// Chebyshev distance using shortest wrapped displacements.
    pub fn distance(&self, from: Cell, to: Cell) -> u64 {
        let d = self.displacement(from, to);
        d.dx.unsigned_abs().max(d.dy.unsigned_abs()) as u64
    }

    /// Iterate the Chebyshev ball, including its center, without duplicates.
    /// Axis coordinates start at center minus radius and advance in wrapped order;
    /// x varies fastest. Each axis is capped at its dimension. No allocation occurs.
    pub fn cells_within(&self, center: Cell, radius: u64) -> CellsWithin {
        let center = self.cell(center.x as i128, center.y as i128);
        let span = |size: u64| ((radius as u128 * 2 + 1).min(size as u128)) as u64;
        let start = |value: u64, size: u64| {
            (value as i128 - radius as i128).rem_euclid(size as i128) as u64
        };
        CellsWithin {
            grid: *self,
            start_x: start(center.x, self.width),
            count_x: span(self.width),
            count_y: span(self.height),
            x: 0,
            y: 0,
            current_x: start(center.x, self.width),
            current_y: start(center.y, self.height),
            done: false,
        }
    }
}

/// Lazy row-major traversal of distinct cells in a wrapped radius.
pub struct CellsWithin {
    grid: Grid,
    start_x: u64,
    count_x: u64,
    count_y: u64,
    x: u64,
    y: u64,
    current_x: u64,
    current_y: u64,
    done: bool,
}

impl Iterator for CellsWithin {
    type Item = Cell;
    fn next(&mut self) -> Option<Cell> {
        if self.done {
            return None;
        }
        let cell = Cell {
            x: self.current_x,
            y: self.current_y,
        };
        if self.x == self.count_x - 1 {
            self.x = 0;
            self.current_x = self.start_x;
            if self.y == self.count_y - 1 {
                self.done = true;
            } else {
                self.y += 1;
                self.current_y = if self.current_y == self.grid.height - 1 {
                    0
                } else {
                    self.current_y + 1
                };
            }
        } else {
            self.x += 1;
            self.current_x = if self.current_x == self.grid.width - 1 {
                0
            } else {
                self.current_x + 1
            };
        }
        Some(cell)
    }
}

#[cfg(test)]
mod iteration_equivalence {
    use super::*;
    #[test]
    fn wrapped_iteration_matches_wide_modulo_oracle() {
        for width in [1, 2, 3, 8, u64::MAX] {
            for height in [1, 2, 5, u64::MAX] {
                let grid = Grid::new(width, height).unwrap();
                for x in [0, 1, u64::MAX] {
                    for y in [0, 1, u64::MAX] {
                        for radius in [0, 1, 2, 7, u64::MAX] {
                            // Bound huge grids while still checking extreme starts and wrapping.
                            let center = grid.cell(x as i128, y as i128);
                            let sx = (center.x as i128 - radius as i128).rem_euclid(width as i128)
                                as u64;
                            let sy = (center.y as i128 - radius as i128).rem_euclid(height as i128)
                                as u64;
                            let nx = (radius as u128 * 2 + 1).min(width as u128) as u64;
                            let ny = (radius as u128 * 2 + 1).min(height as u128) as u64;
                            let expected = (0..ny.min(12))
                                .flat_map(|dy| {
                                    (0..nx.min(12)).map(move |dx| Cell {
                                        x: ((sx as u128 + dx as u128) % width as u128) as u64,
                                        y: ((sy as u128 + dy as u128) % height as u128) as u64,
                                    })
                                })
                                .collect::<Vec<_>>();
                            if nx <= 12 {
                                assert_eq!(
                                    grid.cells_within(Cell { x, y }, radius)
                                        .take(expected.len())
                                        .collect::<Vec<_>>(),
                                    expected
                                );
                            } else {
                                let actual = grid
                                    .cells_within(Cell { x, y }, radius)
                                    .take(12)
                                    .collect::<Vec<_>>();
                                assert_eq!(actual, expected[..12]);
                            }
                        }
                    }
                }
            }
        }
    }
}

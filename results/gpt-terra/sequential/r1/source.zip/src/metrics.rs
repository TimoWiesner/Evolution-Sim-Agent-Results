//! Read-only, per-run metrics collector. Samples must belong to one simulation
//! and be requested in nondecreasing tick order.
use crate::{
    organism::{Counts, DeathCause, Kind, Traits},
    simulation::Simulation,
};
use serde::Serialize;

#[derive(Clone, Default, Serialize)]
struct Causes {
    age: u64,
    starvation: u64,
    injury: u64,
    grazing: u64,
    predation: u64,
    external: u64,
}
impl Causes {
    fn add(&mut self, cause: DeathCause) {
        *match cause {
            DeathCause::Age => &mut self.age,
            DeathCause::Starvation => &mut self.starvation,
            DeathCause::Injury => &mut self.injury,
            DeathCause::Grazing => &mut self.grazing,
            DeathCause::Predation => &mut self.predation,
            DeathCause::External => &mut self.external,
        } += 1;
    }
}
#[derive(Clone, Serialize)]
struct ByKind<T> {
    plants: T,
    herbivores: T,
    carnivores: T,
}
impl<T: Default> Default for ByKind<T> {
    fn default() -> Self {
        Self {
            plants: T::default(),
            herbivores: T::default(),
            carnivores: T::default(),
        }
    }
}
impl<T> ByKind<T> {
    fn get_mut(&mut self, kind: Kind) -> &mut T {
        match kind {
            Kind::Plant => &mut self.plants,
            Kind::Herbivore => &mut self.herbivores,
            Kind::Carnivore => &mut self.carnivores,
        }
    }
}
#[derive(Clone, Serialize)]
struct Statistic {
    mean: f64,
    stddev: f64,
}
#[derive(Default)]
struct Acc {
    n: u64,
    mean: f64,
    m2: f64,
}
impl Acc {
    fn add(&mut self, x: f64) {
        self.n += 1;
        let d = x - self.mean;
        self.mean += d / self.n as f64;
        self.m2 += d * (x - self.mean);
    }
    fn result(&self) -> Option<Statistic> {
        (self.n > 0).then(|| Statistic {
            mean: self.mean,
            stddev: (self.m2 / self.n as f64).max(0.0).sqrt(),
        })
    }
}
#[derive(Default)]
struct Aggregate {
    traits: [Acc; 6],
    generation: Acc,
    highest: Option<u64>,
}
impl Aggregate {
    fn add(&mut self, t: &Traits, generation: u64) {
        for (acc, value) in self.traits.iter_mut().zip([
            Some(t.speed() as f64),
            Some(t.strength() as f64),
            Some(t.fertility() as f64),
            Some(t.max_lifespan() as f64),
            Some(t.max_health() as f64),
            t.aggression().map(f64::from),
        ]) {
            if let Some(v) = value {
                acc.add(v);
            }
        }
        self.generation.add(generation as f64);
        self.highest = Some(self.highest.map_or(generation, |v| v.max(generation)));
    }
    fn traits(&self) -> TraitStats {
        TraitStats {
            speed: self.traits[0].result(),
            strength: self.traits[1].result(),
            fertility: self.traits[2].result(),
            max_lifespan: self.traits[3].result(),
            max_health: self.traits[4].result(),
            aggression: self.traits[5].result(),
        }
    }
    fn generation(&self) -> Generation {
        Generation {
            highest: self.highest,
            mean: self.generation.result().map(|s| s.mean),
        }
    }
}
#[derive(Serialize)]
struct TraitStats {
    speed: Option<Statistic>,
    strength: Option<Statistic>,
    fertility: Option<Statistic>,
    max_lifespan: Option<Statistic>,
    max_health: Option<Statistic>,
    aggression: Option<Statistic>,
}
#[derive(Serialize)]
struct Generation {
    highest: Option<u64>,
    mean: Option<f64>,
}
#[derive(Serialize)]
pub struct Metrics {
    births: Counts,
    deaths: Counts,
    deaths_by_cause: ByKind<Causes>,
    species: ByKind<usize>,
    traits: ByKind<TraitStats>,
    generation: ByKind<Generation>,
}

/// Construct a fresh collector for each simulation; do not reuse after rewind or for another world.
#[derive(Default)]
pub struct Collector {
    cursor: usize,
    causes: ByKind<Causes>,
    last_tick: Option<u64>,
}
impl Collector {
    pub fn sample(&mut self, sim: &Simulation) -> Metrics {
        assert!(
            self.last_tick.is_none_or(|tick| sim.tick() >= tick)
                && sim.death_records().len() >= self.cursor,
            "collector cannot sample a rewound simulation"
        );
        for record in &sim.death_records()[self.cursor..] {
            self.causes.get_mut(record.kind).add(record.cause);
        }
        self.cursor = sim.death_records().len();
        self.last_tick = Some(sim.tick());
        let mut a: ByKind<Aggregate> = ByKind::default();
        for o in sim.living().values() {
            a.get_mut(o.kind()).add(o.traits(), o.generation());
        }
        Metrics {
            births: sim.births().clone(),
            deaths: sim.deaths().clone(),
            deaths_by_cause: self.causes.clone(),
            species: ByKind {
                plants: sim.species().living_count(Kind::Plant),
                herbivores: sim.species().living_count(Kind::Herbivore),
                carnivores: sim.species().living_count(Kind::Carnivore),
            },
            traits: ByKind {
                plants: a.plants.traits(),
                herbivores: a.herbivores.traits(),
                carnivores: a.carnivores.traits(),
            },
            generation: ByKind {
                plants: a.plants.generation(),
                herbivores: a.herbivores.generation(),
                carnivores: a.carnivores.generation(),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn hand_calculated_statistics_and_causes() {
        let mut a = Aggregate::default();
        a.add(
            &Traits::new(Kind::Herbivore, 2, 20, 30, 100, 80, Some(10)).unwrap(),
            1,
        );
        a.add(
            &Traits::new(Kind::Herbivore, 4, 40, 50, 300, 100, Some(30)).unwrap(),
            3,
        );
        let v = serde_json::to_value(a.traits()).unwrap();
        for (key, mean, spread) in [
            ("speed", 3., 1.),
            ("strength", 30., 10.),
            ("fertility", 40., 10.),
            ("max_lifespan", 200., 100.),
            ("max_health", 90., 10.),
            ("aggression", 20., 10.),
        ] {
            assert_eq!(v[key]["mean"], mean);
            assert_eq!(v[key]["stddev"], spread);
        }
        let g = serde_json::to_value(a.generation()).unwrap();
        assert_eq!(g["highest"], 3);
        assert_eq!(g["mean"], 2.);
        let mut p = Aggregate::default();
        p.add(&Traits::founder(Kind::Plant), 0);
        assert!(serde_json::to_value(p.traits()).unwrap()["aggression"].is_null());
        assert!(serde_json::to_value(Aggregate::default().generation()).unwrap()["mean"].is_null());
        let mut c = Causes::default();
        for cause in [
            DeathCause::Age,
            DeathCause::Starvation,
            DeathCause::Injury,
            DeathCause::Grazing,
            DeathCause::Predation,
            DeathCause::External,
        ] {
            c.add(cause);
        }
        assert!(serde_json::to_value(c)
            .unwrap()
            .as_object()
            .unwrap()
            .values()
            .all(|v| *v == 1));
    }
    #[test]
    fn real_events_and_observation_are_independent() {
        use crate::{config::Config, geometry::Cell, organism::Event};
        let config = Config::from_json(r#"{"seed":7,"world":{"width":8,"height":8},"initial":{"plants":2,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut observed = Simulation::new(&config).unwrap();
        let mut control = observed.clone();
        let mut collector = Collector::default();
        let first = serde_json::to_value(collector.sample(&observed)).unwrap();
        assert_eq!(first["species"]["plants"], 1);
        assert_eq!(first["traits"]["plants"]["speed"]["mean"], 1.0);
        assert!(first["traits"]["herbivores"]["speed"].is_null());
        let events = [
            Event::Birth {
                kind: Kind::Plant,
                position: Cell { x: 1, y: 1 },
                parents: [Some(0), None],
            },
            Event::Death {
                id: 1,
                cause: DeathCause::External,
            },
        ];
        observed.advance_with_events(&events).unwrap();
        control.advance_with_events(&events).unwrap();
        let later = serde_json::to_value(collector.sample(&observed)).unwrap();
        assert_eq!(later["births"]["plants"], 1);
        assert_eq!(later["deaths"]["plants"], 1);
        assert_eq!(later["deaths_by_cause"]["plants"]["external"], 1);
        assert_eq!(later["deaths_by_cause"]["plants"]["age"], 0);
        assert_eq!(later["generation"]["plants"]["highest"], 1);
        assert_eq!(later["generation"]["plants"]["mean"], 0.5);
        assert_eq!(
            later,
            serde_json::to_value(collector.sample(&observed)).unwrap()
        );
        assert_eq!(observed.state_hash(), control.state_hash());
        for _ in 0..30 {
            observed.advance_one_tick().unwrap();
            control.advance_one_tick().unwrap();
            let _ = collector.sample(&observed);
            assert_eq!(observed.state_hash(), control.state_hash());
        }
        let mut fresh = Collector::default();
        assert_eq!(
            serde_json::to_value(collector.sample(&observed)).unwrap(),
            serde_json::to_value(fresh.sample(&observed)).unwrap()
        );
    }
}

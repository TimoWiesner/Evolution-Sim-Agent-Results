//! Versioned, checksummed complete simulation snapshots.
use crate::simulation::Simulation;
use bincode::Options;
use sha2::{Digest, Sha256};

const MAGIC: &[u8; 8] = b"EVOSIMCP";
const VERSION: u32 = 1;
const HEADER: usize = 8 + 4 + 8 + 32;

pub fn encode(seed: i64, sim: &Simulation) -> Result<Vec<u8>, String> {
    let payload = bincode::DefaultOptions::new()
        .with_fixint_encoding()
        .serialize(&(seed, sim))
        .map_err(|e| e.to_string())?;
    let mut data = Vec::with_capacity(HEADER + payload.len());
    data.extend_from_slice(MAGIC);
    data.extend_from_slice(&VERSION.to_le_bytes());
    data.extend_from_slice(&(payload.len() as u64).to_le_bytes());
    let mut hash = Sha256::new();
    hash.update(b"evosim-checkpoint-v1");
    hash.update(&data[8..]);
    hash.update(&payload);
    data.extend_from_slice(&hash.finalize());
    data.extend_from_slice(&payload);
    Ok(data)
}

pub fn decode(data: &[u8]) -> Result<(i64, Simulation), String> {
    if data.len() < HEADER || &data[..8] != MAGIC {
        return Err("Invalid checkpoint header".into());
    }
    if u32::from_le_bytes(data[8..12].try_into().unwrap()) != VERSION {
        return Err("Unsupported checkpoint version".into());
    }
    let len = u64::from_le_bytes(data[12..20].try_into().unwrap());
    if usize::try_from(len)
        .ok()
        .and_then(|n| n.checked_add(HEADER))
        != Some(data.len())
    {
        return Err("Invalid checkpoint length".into());
    }
    let mut hash = Sha256::new();
    hash.update(b"evosim-checkpoint-v1");
    hash.update(&data[8..20]);
    hash.update(&data[HEADER..]);
    if hash.finalize().as_slice() != &data[20..HEADER] {
        return Err("Checkpoint checksum mismatch".into());
    }
    let (seed, sim): (i64, Simulation) = bincode::DefaultOptions::new()
        .with_fixint_encoding()
        .with_limit(len)
        .reject_trailing_bytes()
        .deserialize(&data[HEADER..])
        .map_err(|e| format!("Invalid checkpoint: {e}"))?;
    sim.validate_checkpoint()?;
    Ok((seed, sim))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;
    #[test]
    fn complete_round_trip_and_corruption() {
        let config = Config::from_json(r#"{"seed":42,"world":{"width":16,"height":12},"initial":{"plants":60,"herbivores":15,"carnivores":3}}"#).unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        for _ in 0..120 {
            sim.advance_one_tick().unwrap();
        }
        let bytes = encode(-7, &sim).unwrap();
        let (seed, restored) = decode(&bytes).unwrap();
        assert_eq!(seed, -7);
        assert_eq!(sim, restored);
        assert_eq!(sim.state_hash(), restored.state_hash());
        let mut corrupt = bytes.clone();
        *corrupt.last_mut().unwrap() ^= 1;
        assert!(decode(&corrupt).is_err());
        assert!(decode(&bytes[..bytes.len() - 1]).is_err());
        let mut extra = bytes.clone();
        extra.push(0);
        assert!(decode(&extra).is_err());
        let mut version = bytes;
        version[8] = 2;
        assert!(decode(&version).is_err());
    }
}

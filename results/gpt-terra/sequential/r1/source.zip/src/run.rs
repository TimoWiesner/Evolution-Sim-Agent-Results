use evosim::{
    checkpoint, config::Config, metrics::Collector, organism::Kind, simulation::Simulation,
};
use serde_json::{json, Value};
use std::{
    ffi::OsString,
    fs::{self, OpenOptions},
    io::Write,
    path::{Path, PathBuf},
    time::Instant,
};

fn sample(sim: &Simulation, collector: &mut Collector) -> Value {
    let mut counts = [0u64; 3];
    for o in sim.living().values() {
        counts[match o.kind() {
            Kind::Plant => 0,
            Kind::Herbivore => 1,
            Kind::Carnivore => 2,
        }] += 1;
    }
    json!({"tick":sim.tick(),"plants":counts[0],"herbivores":counts[1],"carnivores":counts[2],"metrics":collector.sample(sim)})
}
pub(crate) fn number<T: std::str::FromStr>(s: &std::ffi::OsStr, name: &str) -> Result<T, String> {
    s.to_str()
        .and_then(|s| s.parse().ok())
        .ok_or_else(|| format!("Invalid {name}"))
}
pub(crate) fn write_atomic(path: &Path, bytes: &[u8]) -> Result<(), String> {
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let mut temp = None;
    for n in 0..1000 {
        let p = parent.join(format!(".evosim-{}-{n}.tmp", std::process::id()));
        match OpenOptions::new().write(true).create_new(true).open(&p) {
            Ok(f) => {
                temp = Some((p, f));
                break;
            }
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(format!("Cannot create output: {e}")),
        }
    }
    let (p, mut f) = temp.ok_or("Cannot create temporary output")?;
    let result = (|| {
        f.write_all(bytes)?;
        f.flush()?;
        drop(f);
        fs::rename(&p, path)
    })();
    if result.is_err() {
        let _ = fs::remove_file(&p);
    }
    result.map_err(|e| format!("Cannot write output: {e}"))
}
pub fn run(args: &[OsString]) -> Result<(), String> {
    let mut config = None;
    let mut load = None;
    let mut save = None;
    let mut ticks = None;
    let mut out = None;
    let mut seed = None;
    let mut spacing = None;
    let mut iter = args.iter();
    while let Some(flag) = iter.next() {
        let value = iter.next().ok_or("Missing flag value")?;
        match flag.to_str() {
            Some("--config") if config.is_none() => config = Some(PathBuf::from(value)),
            Some("--load") if load.is_none() => load = Some(PathBuf::from(value)),
            Some("--save") if save.is_none() => save = Some(PathBuf::from(value)),
            Some("--ticks") if ticks.is_none() => ticks = Some(number::<u64>(value, "ticks")?),
            Some("--out") if out.is_none() => out = Some(PathBuf::from(value)),
            Some("--seed") if seed.is_none() => seed = Some(number::<i64>(value, "seed")?),
            Some("--sample-every") if spacing.is_none() => {
                spacing = Some(number::<u64>(value, "sample-every")?)
            }
            _ => return Err("Unknown or duplicate flag".into()),
        }
    }
    if config.is_some() == load.is_some() {
        return Err("Specify exactly one of --config or --load".into());
    }
    if load.is_some() && seed.is_some() {
        return Err("--seed cannot be used with --load".into());
    }
    let ticks = ticks.ok_or("Missing --ticks")?;
    let out = out.ok_or("Missing --out")?;
    let spacing = spacing.unwrap_or((ticks / 100).max(1));
    if spacing == 0 {
        return Err("sample-every must be positive".into());
    }
    // Canonicalize parents as well as existing paths to catch aliases before writing.
    fn identity(path: &Path) -> Result<PathBuf, String> {
        if path.exists() {
            return fs::canonicalize(path).map_err(|e| e.to_string());
        }
        let parent = path
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .unwrap_or(Path::new("."));
        Ok(fs::canonicalize(parent)
            .map_err(|e| e.to_string())?
            .join(path.file_name().ok_or("Invalid path")?))
    }
    let out_id = identity(&out)?;
    let input = config.as_ref().or(load.as_ref()).unwrap();
    let input_id = identity(input)?;
    if out_id == input_id {
        return Err("Output collides with input".into());
    }
    if let Some(path) = &save {
        let id = identity(path)?;
        if id == out_id || id == input_id {
            return Err("Save path collides with input or output".into());
        }
    }
    let (effective_seed, sim) = if let Some(path) = load {
        let bytes = fs::read(path).map_err(|e| format!("Cannot read checkpoint: {e}"))?;
        checkpoint::decode(&bytes)?
    } else {
        let text =
            fs::read_to_string(config.unwrap()).map_err(|e| format!("Cannot read config: {e}"))?;
        let mut config = Config::from_json(&text).map_err(|e| format!("Invalid config: {e}"))?;
        if let Some(seed) = seed {
            config.seed = seed;
        }
        (
            config.seed,
            Simulation::new(&config).map_err(|e| format!("Cannot create simulation: {e}"))?,
        )
    };
    let (result, sim) = execute_sim(sim, effective_seed, ticks, spacing)?;
    let bytes = serde_json::to_vec(&result).map_err(|e| e.to_string())?;
    if let Some(path) = save {
        let checkpoint = checkpoint::encode(effective_seed, &sim)?;
        write_atomic(&path, &checkpoint)?;
    }
    write_atomic(&out, &bytes)
}

pub(crate) fn execute(config: &Config, ticks: u64, spacing: u64) -> Result<Value, String> {
    let sim = Simulation::new(config).map_err(|e| format!("Cannot create simulation: {e}"))?;
    execute_sim(sim, config.seed, ticks, spacing).map(|(result, _)| result)
}
fn execute_sim(
    mut sim: Simulation,
    seed: i64,
    ticks: u64,
    spacing: u64,
) -> Result<(Value, Simulation), String> {
    let tick_start = sim.tick();
    tick_start
        .checked_add(ticks)
        .ok_or("simulation tick overflow")?;
    let mut collector = Collector::default();
    let mut series = vec![sample(&sim, &mut collector)];
    let start = Instant::now();
    for n in 1..=ticks {
        sim.advance_one_tick().map_err(|e| e.to_string())?;
        if n % spacing == 0 || n == ticks {
            series.push(sample(&sim, &mut collector));
        }
    }
    let elapsed = start.elapsed().as_secs_f64();
    let mut final_counts = sample(&sim, &mut collector);
    final_counts.as_object_mut().unwrap().remove("metrics");
    final_counts.as_object_mut().unwrap().remove("tick");
    final_counts["species"] = json!({"plants":sim.species().living_count(Kind::Plant),"herbivores":sim.species().living_count(Kind::Herbivore),"carnivores":sim.species().living_count(Kind::Carnivore)});
    let result = json!({"contract":1,"seed":seed,"tick_start":tick_start,"tick_end":sim.tick(),"world":{"width":sim.world().width(),"height":sim.world().height()},"final":final_counts,"totals":{"births":sim.births(),"deaths":sim.deaths()},"series":series,"state_hash":sim.state_hash(),"elapsed_seconds":elapsed,"ticks_per_second":if elapsed > 0.0 {ticks as f64 / elapsed} else {0.0}});
    Ok((result, sim))
}

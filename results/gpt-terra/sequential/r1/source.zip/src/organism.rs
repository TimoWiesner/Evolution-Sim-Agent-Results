//! Genome-derived phenotypes and lifecycle records.
use crate::genome::Genome;
use crate::geometry::Cell;

#[derive(
    Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, serde::Serialize, serde::Deserialize,
)]
pub enum Kind {
    Plant,
    Herbivore,
    Carnivore,
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Traits {
    speed: u8,
    strength: u8,
    fertility: u8,
    max_lifespan: u32,
    max_health: u16,
    aggression: Option<u8>,
}
impl Traits {
    pub fn new(
        kind: Kind,
        speed: u8,
        strength: u8,
        fertility: u8,
        max_lifespan: u32,
        max_health: u16,
        aggression: Option<u8>,
    ) -> Result<Self, &'static str> {
        if speed > 10
            || strength > 100
            || fertility > 100
            || !(1..=1_000_000).contains(&max_lifespan)
            || !(1..=1000).contains(&max_health)
            || match (kind, aggression) {
                (Kind::Plant, None) => false,
                (Kind::Herbivore | Kind::Carnivore, Some(a)) => a > 100,
                _ => true,
            }
        {
            return Err("invalid traits");
        }
        Ok(Self {
            speed,
            strength,
            fertility,
            max_lifespan,
            max_health,
            aggression,
        })
    }
    pub fn founder(kind: Kind) -> Self {
        Self::new(
            kind,
            1,
            50,
            50,
            1000,
            100,
            if kind == Kind::Plant { None } else { Some(50) },
        )
        .unwrap()
    }
    pub fn speed(&self) -> u8 {
        self.speed
    }
    pub fn strength(&self) -> u8 {
        self.strength
    }
    pub fn fertility(&self) -> u8 {
        self.fertility
    }
    pub fn max_lifespan(&self) -> u32 {
        self.max_lifespan
    }
    pub fn max_health(&self) -> u16 {
        self.max_health
    }
    pub fn aggression(&self) -> Option<u8> {
        self.aggression
    }
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Organism {
    pub(crate) id: u64,
    pub(crate) kind: Kind,
    pub(crate) species_id: u64,
    pub(crate) position: Cell,
    pub(crate) age: u32,
    pub(crate) energy: u16,
    pub(crate) health: u16,
    pub(crate) traits: Traits,
    pub(crate) genome: Genome,
    pub(crate) parents: [Option<u64>; 2],
    pub(crate) generation: u64,
    pub(crate) next_mating_tick: u64,
}
impl Organism {
    pub(crate) fn new(
        id: u64,
        kind: Kind,
        position: Cell,
        species_id: u64,
        genome: Genome,
        parents: [Option<u64>; 2],
        generation: u64,
    ) -> Self {
        assert_eq!(genome.kind(), kind);
        let traits = genome.traits();
        let health = traits.max_health;
        Self {
            id,
            kind,
            species_id,
            position,
            age: 0,
            energy: 1000,
            health,
            traits,
            genome,
            parents,
            generation,
            next_mating_tick: 0,
        }
    }
    pub fn id(&self) -> u64 {
        self.id
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    pub fn species_id(&self) -> u64 {
        self.species_id
    }
    pub fn position(&self) -> Cell {
        self.position
    }
    pub fn age(&self) -> u32 {
        self.age
    }
    pub fn energy(&self) -> u16 {
        self.energy
    }
    pub fn health(&self) -> u16 {
        self.health
    }
    pub fn genome(&self) -> &Genome {
        &self.genome
    }
    pub fn traits(&self) -> &Traits {
        &self.traits
    }
    pub fn parents(&self) -> [Option<u64>; 2] {
        self.parents
    }
    pub fn next_mating_tick(&self) -> u64 {
        self.next_mating_tick
    }
    pub fn generation(&self) -> u64 {
        self.generation
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub enum DeathCause {
    Age,
    Starvation,
    Injury,
    Grazing,
    Predation,
    External,
}
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct DeathRecord {
    pub id: u64,
    pub kind: Kind,
    pub tick: u64,
    pub cause: DeathCause,
}
#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Counts {
    pub plants: u64,
    pub herbivores: u64,
    pub carnivores: u64,
}
impl Counts {
    pub(crate) fn get_mut(&mut self, kind: Kind) -> &mut u64 {
        match kind {
            Kind::Plant => &mut self.plants,
            Kind::Herbivore => &mut self.herbivores,
            Kind::Carnivore => &mut self.carnivores,
        }
    }
}

/// Events are applied in order at the start of a tick; plant births are deferred.
/// Plant events require a living parent with at least 800 energy and transfer 400;
/// animal births must occur through ecological mating. Energy adjustments cannot add energy.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Event {
    Birth {
        kind: Kind,
        position: Cell,
        parents: [Option<u64>; 2],
    },
    Death {
        id: u64,
        cause: DeathCause,
    },
    Adjust {
        id: u64,
        energy: i32,
        health: i32,
    },
}

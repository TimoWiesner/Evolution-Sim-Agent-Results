//! Static, cell-centered latitude climate on a torus. No random draws or storage per cell.
use crate::geometry::{Cell, Grid};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Biome {
    Polar,
    Tundra,
    Temperate,
    Dry,
    Tropical,
}
impl Biome {
    pub fn code(self) -> char {
        match self {
            Self::Polar => 'P',
            Self::Tundra => 'U',
            Self::Temperate => 'M',
            Self::Dry => 'D',
            Self::Tropical => 'T',
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ClimateCell {
    pub biome: Biome,
    /// Annual base temperature in degrees Celsius.
    pub base_temperature: f64,
    /// Annual base precipitation in millimetres.
    pub base_precipitation: f64,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct ClimateField {
    grid: Grid,
}
impl ClimateField {
    pub fn new(grid: Grid) -> Self {
        Self { grid }
    }
    /// Normalize the input and sample the periodic cell-centered latitude field.
    pub fn at(&self, cell: Cell) -> ClimateCell {
        let y = cell.y % self.grid.height();
        // Mirror the integer row before conversion so seam partners are exactly equal,
        // including when large integers cannot be represented exactly as f64.
        let row = y.min(self.grid.height() - 1 - y);
        let phase = (row as f64 + 0.5) / self.grid.height() as f64;
        let warmth = ((1.0 - (std::f64::consts::TAU * phase).cos()) / 2.0).clamp(0.0, 1.0);
        let biome = if warmth < 0.12 {
            Biome::Polar
        } else if warmth < 0.28 {
            Biome::Tundra
        } else if warmth < 0.55 {
            Biome::Temperate
        } else if warmth < 0.78 {
            Biome::Dry
        } else {
            Biome::Tropical
        };
        let anchors = [
            (0.0, 100.0),
            (0.12, 250.0),
            (0.28, 700.0),
            (0.55, 350.0),
            (0.78, 1400.0),
            (1.0, 2200.0),
        ];
        let pair = anchors.windows(2).find(|p| warmth <= p[1].0).unwrap();
        let precipitation =
            pair[0].1 + (warmth - pair[0].0) / (pair[1].0 - pair[0].0) * (pair[1].1 - pair[0].1);
        ClimateCell {
            biome,
            base_temperature: -25.0 + 55.0 * warmth,
            base_precipitation: precipitation,
        }
    }
}

/// Current climate; precipitation is a millimetres-per-year equivalent rate.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CurrentClimate {
    pub biome: Biome,
    pub temperature: f64,
    pub precipitation: f64,
}

impl ClimateField {
    pub(crate) fn current(
        &self,
        cell: Cell,
        tick: u64,
        settings: &crate::config::Climate,
        weather: (f64, f64),
    ) -> CurrentClimate {
        let base = self.at(cell);
        let warmth = (base.base_temperature + 25.0) / 55.0;
        let phase = std::f64::consts::TAU
            * ((tick % settings.year_ticks) as f64 / settings.year_ticks as f64);
        CurrentClimate {
            biome: base.biome,
            temperature: (base.base_temperature
                + settings.seasonal_strength * (4.0 + 16.0 * (1.0 - warmth)) * phase.cos()
                + weather.0)
                .clamp(-60.0, 60.0),
            precipitation: (base.base_precipitation
                + settings.seasonal_strength * (100.0 + 300.0 * warmth) * phase.sin()
                + weather.1)
                .clamp(0.0, 3000.0),
        }
    }
}

//! Persistent, deterministic genetic reference species.
use crate::{genome::Genome, organism::Kind};

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Species {
    pub id: u64,
    pub kind: Kind,
    pub name: String,
    pub reference: Genome,
    pub parent: Option<u64>,
    pub arose_tick: u64,
    pub extinct_tick: Option<u64>,
    pub living: u64,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct SpeciesRegistry {
    records: Vec<Species>,
}
impl SpeciesRegistry {
    pub fn records(&self) -> &[Species] {
        &self.records
    }
    pub fn living_count(&self, kind: Kind) -> usize {
        self.records
            .iter()
            .filter(|s| s.kind == kind && s.living > 0)
            .count()
    }
    pub(crate) fn add(&mut self, genome: &Genome, parent: Option<u64>, tick: u64) -> u64 {
        let kind = genome.kind();
        let nearest = self
            .records
            .iter()
            .filter(|s| s.kind == kind)
            .map(|s| (genome.distance_sum(&s.reference).unwrap(), s.id))
            .filter(|(sum, _)| u64::from(*sum) * 100 <= genome.alleles().len() as u64 * 1000 * 15)
            .min();
        let id = match nearest {
            Some((_, id)) => id,
            None => {
                // At most one species is created per allocated organism, so this
                // index cannot exhaust before the organism allocator does.
                let id = self.records.len() as u64;
                let prefix = match kind {
                    Kind::Plant => "plant",
                    Kind::Herbivore => "herbivore",
                    Kind::Carnivore => "carnivore",
                };
                self.records.push(Species {
                    id,
                    kind,
                    name: format!("{prefix}-{id}"),
                    reference: genome.clone(),
                    parent,
                    arose_tick: tick,
                    extinct_tick: None,
                    living: 0,
                });
                id
            }
        };
        let species = &mut self.records[id as usize];
        species.living += 1;
        species.extinct_tick = None;
        id
    }
    pub(crate) fn remove(&mut self, id: u64, tick: u64) {
        let species = &mut self.records[id as usize];
        species.living -= 1;
        if species.living == 0 {
            species.extinct_tick = Some(tick);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn plant(v: u16) -> Genome {
        Genome::new(Kind::Plant, vec![[v, v]; 5]).unwrap()
    }
    #[test]
    fn threshold_nearest_ties_extinction_and_revival() {
        let mut r = SpeciesRegistry::default();
        assert_eq!(r.add(&plant(0), None, 0), 0);
        assert_eq!(r.add(&plant(149), Some(0), 1), 0);
        assert_eq!(r.add(&plant(150), Some(0), 1), 0);
        assert_eq!(r.add(&plant(151), Some(0), 2), 1);
        assert_eq!(r.records()[1].parent, Some(0));
        assert_eq!(r.records()[1].arose_tick, 2);
        assert_eq!(r.add(&plant(75), Some(1), 3), 0);
        assert_eq!(r.add(&plant(100), Some(0), 3), 1);
        for _ in 0..4 {
            r.remove(0, 4);
        }
        assert_eq!(r.records()[0].extinct_tick, Some(4));
        assert_eq!(r.living_count(Kind::Plant), 1);
        assert_eq!(r.add(&plant(0), Some(1), 5), 0);
        assert_eq!(r.records()[0].extinct_tick, None);
        r.remove(0, 6);
        assert_eq!(r.records()[0].extinct_tick, Some(6));
    }
    #[test]
    fn equal_distance_uses_lowest_id() {
        let mut r = SpeciesRegistry::default();
        r.add(&plant(0), None, 0);
        r.add(&plant(200), Some(0), 1);
        assert_eq!(r.add(&plant(100), Some(1), 2), 0);
    }
}

use evosim::{config::Config, geometry::Cell, organism::Kind, simulation::Simulation};
use serde_json::json;
use std::{
    ffi::OsString,
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    path::PathBuf,
    process::{Command, Stdio},
    sync::{
        atomic::{AtomicBool, AtomicU64, Ordering},
        Arc, Mutex,
    },
    thread,
    time::{Duration, Instant},
};

const MAX_BODY: usize = 64 * 1024 * 1024;
struct Controller {
    sim: Simulation,
    config: Config,
    seed: i64,
    running: bool,
    speed: u64,
    error: Option<String>,
    collector: evosim::metrics::Collector,
    history: std::collections::VecDeque<serde_json::Value>,
}
impl Controller {
    fn new(config: Config) -> Result<Self, String> {
        let sim = Simulation::new(&config).map_err(|e| e.to_string())?;
        let mut controller = Self {
            seed: config.seed,
            config,
            sim,
            running: true,
            speed: 50,
            error: None,
            collector: Default::default(),
            history: Default::default(),
        };
        controller.sample();
        Ok(controller)
    }
    fn sample(&mut self) {
        let m = self.collector.sample(&self.sim);
        let mut counts = [0usize; 3];
        for o in self.sim.living().values() {
            counts[match o.kind() {
                Kind::Plant => 0,
                Kind::Herbivore => 1,
                Kind::Carnivore => 2,
            }] += 1;
        }
        let v = json!({"tick":self.sim.tick(), "population":counts, "metrics":m});
        if self.history.back().is_some_and(|p| p["tick"] == v["tick"]) {
            self.history.pop_back();
        }
        self.history.push_back(v);
        if self.history.len() > 1000 {
            self.history.pop_front();
        }
    }
    fn clear_history(&mut self) {
        self.collector = Default::default();
        self.history.clear();
        self.sample();
    }
    fn start(&mut self, data: &str) -> Result<(), String> {
        let config = Config::from_json(data).map_err(|e| e.to_string())?;
        let sim = Simulation::new(&config).map_err(|e| e.to_string())?;
        self.seed = config.seed;
        self.config = config;
        self.sim = sim;
        self.running = false;
        self.error = None;
        self.clear_history();
        Ok(())
    }
    fn tick(&mut self) {
        if let Err(e) = self.sim.advance_one_tick() {
            self.running = false;
            self.error = Some(e.to_string());
        } else if self.sim.tick() % 10 == 0 {
            self.sample();
        }
    }
    fn scheduled_tick(&mut self) {
        if self.running {
            self.tick();
        }
    }
    fn command(&mut self, cmd: &str) -> Result<(), String> {
        match cmd {
            "run" => self.running = true,
            "pause" => self.running = false,
            "step" => {
                self.running = false;
                self.tick();
                self.sample();
            }
            "reset" => {
                self.sim = Simulation::new(&self.config).map_err(|e| e.to_string())?;
                self.seed = self.config.seed;
                self.running = false;
                self.error = None;
                self.clear_history();
            }
            "speed/5" => self.speed = 5,
            "speed/20" => self.speed = 20,
            "speed/50" => self.speed = 50,
            _ => return Err("Invalid command".into()),
        }
        Ok(())
    }
    fn load(&mut self, data: &[u8]) -> Result<(), String> {
        let (seed, sim) = evosim::checkpoint::decode(data)?;
        self.sim = sim;
        self.seed = seed;
        self.running = false;
        self.error = None;
        self.clear_history();
        Ok(())
    }
}
fn snapshot(state: &Controller, selected: Option<u64>) -> String {
    let sim = &state.sim;
    let grid = sim.world();
    let biome: Vec<String> = (0..grid.height())
        .map(|y| {
            (0..grid.width())
                .map(|x| sim.climate().at(Cell { x, y }).biome.code())
                .collect()
        })
        .collect();
    let organisms: Vec<_> = sim
        .living()
        .values()
        .map(|o| {
            let p = o.position();
            json!([
                p.x,
                p.y,
                match o.kind() {
                    Kind::Plant => 0,
                    Kind::Herbivore => 1,
                    Kind::Carnivore => 2,
                },
                o.id().to_string()
            ])
        })
        .collect();
    let detail = selected.map(|id| {
        if let Some(o) = sim.living().get(&id) {
            let species = sim.species().records().iter().find(|s| s.id == o.species_id()).map(|s| s.name.clone()).unwrap_or_default();
            let names = ["speed", "strength", "fertility", "lifespan", "health", "aggression"];
            let genome: Vec<_> = o.genome().alleles().iter().enumerate().map(|(i,a)| json!({"locus":names[i],"alleles":a})).collect();
            json!({"status":"alive", "id":id.to_string(),"kind":format!("{:?}",o.kind()),"species":species,"species_id":o.species_id().to_string(),"age":o.age(),"energy":o.energy(),"health":o.health(),"traits":o.traits(),"genome":genome,"ploidy":if o.kind()==Kind::Plant {"haploid"} else {"diploid"},"parents":o.parents().map(|p| p.map(|v|v.to_string()))})
        } else if let Some(d) = sim.death_records().iter().find(|d| d.id == id) { json!({"status":"dead","id":id.to_string(),"kind":format!("{:?}",d.kind),"tick":d.tick,"cause":format!("{:?}",d.cause)}) } else { json!({"status":"unknown","id":id.to_string()}) }
    });
    let mut distribution = [[[0u64; 10]; 3]; 3];
    for o in sim.living().values() {
        let kind = match o.kind() {
            Kind::Plant => 0,
            Kind::Herbivore => 1,
            Kind::Carnivore => 2,
        };
        let t = o.traits();
        for (i, value) in [
            t.speed() as usize * 10,
            t.strength() as usize,
            t.fertility() as usize,
        ]
        .into_iter()
        .enumerate()
        {
            distribution[i][kind][(value / 10).min(9)] += 1;
        }
    }
    json!({"history":state.history,"distribution":distribution,"width":grid.width(),"height":grid.height(),"biome":biome,"organisms":organisms,"tick":sim.tick(),"running":state.running,"speed":state.speed,"error":state.error,"detail":detail}).to_string()
}
fn reply(
    mut stream: TcpStream,
    state: Arc<Mutex<Controller>>,
    ready: Arc<AtomicU64>,
    target: u64,
    host: String,
) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
    let mut bytes = Vec::new();
    let mut chunk = [0; 8192];
    let header_end = loop {
        match stream.read(&mut chunk) {
            Ok(0) | Err(_) => return,
            Ok(n) => bytes.extend_from_slice(&chunk[..n]),
        }
        if let Some(i) = bytes.windows(4).position(|w| w == b"\r\n\r\n") {
            break i + 4;
        }
        if bytes.len() > 16384 {
            return;
        }
    };
    let header = match std::str::from_utf8(&bytes[..header_end]) {
        Ok(h) => h,
        Err(_) => return,
    };
    let mut lines = header.split("\r\n");
    let mut first = lines.next().unwrap_or("").split_whitespace();
    let method = first.next().unwrap_or("").to_string();
    let path = first.next().unwrap_or("").to_string();
    let mut length = 0usize;
    let mut req_host = "";
    let mut origin = None;
    let mut invalid = false;
    for line in lines {
        if let Some((k, v)) = line.split_once(':') {
            let v = v.trim();
            if k.eq_ignore_ascii_case("content-length") {
                match v.parse::<usize>() {
                    Ok(n) => length = n,
                    Err(_) => invalid = true,
                }
            } else if k.eq_ignore_ascii_case("host") {
                req_host = v;
            } else if k.eq_ignore_ascii_case("origin") {
                origin = Some(v);
            } else if k.eq_ignore_ascii_case("transfer-encoding") {
                invalid = true;
            }
        }
    }
    if req_host != host
        || origin.is_some_and(|o| o != format!("http://{host}"))
        || length > MAX_BODY
        || invalid
    {
        return;
    }
    while bytes.len() - header_end < length {
        match stream.read(&mut chunk) {
            Ok(0) | Err(_) => return,
            Ok(n) => bytes.extend_from_slice(&chunk[..n]),
        }
    }
    let payload = &bytes[header_end..header_end + length];
    let (status, mime, body): (&str, &str, Vec<u8>) = if method == "GET" && path == "/" {
        (
            "200 OK",
            "text/html; charset=utf-8",
            include_str!("ui/index.html").as_bytes().to_vec(),
        )
    } else if method == "GET" && (path == "/snapshot" || path.starts_with("/snapshot?selected=")) {
        let id = path
            .strip_prefix("/snapshot?selected=")
            .and_then(|v| v.parse().ok());
        (
            "200 OK",
            "application/json",
            snapshot(&state.lock().unwrap(), id).into_bytes(),
        )
    } else if method == "GET" && path == "/config" {
        (
            "200 OK",
            "application/json",
            serde_json::to_vec(&state.lock().unwrap().config).unwrap(),
        )
    } else if method == "GET" && path.starts_with("/preset/") {
        match Config::preset(&path[8..]) {
            Ok(c) => (
                "200 OK",
                "application/json",
                serde_json::to_vec(&c).unwrap(),
            ),
            Err(e) => ("400 Bad Request", "text/plain", e.to_string().into_bytes()),
        }
    } else if method == "POST" && path == "/validate-config" {
        match std::str::from_utf8(payload)
            .map_err(|e| e.to_string())
            .and_then(|s| Config::from_json(s).map_err(|e| e.to_string()))
        {
            Ok(c) => (
                "200 OK",
                "application/json",
                serde_json::to_vec(&c).unwrap(),
            ),
            Err(e) => ("400 Bad Request", "text/plain", e.into_bytes()),
        }
    } else if method == "POST" && path == "/start" {
        match std::str::from_utf8(payload)
            .map_err(|e| e.to_string())
            .and_then(|s| state.lock().unwrap().start(s))
        {
            Ok(()) => ("200 OK", "text/plain", b"ok".to_vec()),
            Err(e) => ("400 Bad Request", "text/plain", e.into_bytes()),
        }
    } else if method == "GET" && path == "/checkpoint" {
        let s = state.lock().unwrap();
        match evosim::checkpoint::encode(s.seed, &s.sim) {
            Ok(b) => ("200 OK", "application/octet-stream", b),
            Err(e) => ("500 Internal Server Error", "text/plain", e.into_bytes()),
        }
    } else if method == "POST" && path == "/load" {
        match state.lock().unwrap().load(payload) {
            Ok(()) => ("200 OK", "text/plain", b"ok".to_vec()),
            Err(e) => ("400 Bad Request", "text/plain", e.into_bytes()),
        }
    } else if method == "POST" && path.starts_with("/control/") {
        match state.lock().unwrap().command(&path[9..]) {
            Ok(()) => ("200 OK", "text/plain", b"ok".to_vec()),
            Err(e) => ("400 Bad Request", "text/plain", e.into_bytes()),
        }
    } else if method == "GET" && path.starts_with("/rendered/") {
        if let Ok(t) = path[10..].parse() {
            ready.fetch_max(t, Ordering::Relaxed);
        }
        ("200 OK", "text/plain", b"ok".to_vec())
    } else if method == "GET" && path == "/gate" {
        let start = Instant::now();
        while ready.load(Ordering::Relaxed) < target && start.elapsed() < Duration::from_secs(45) {
            thread::sleep(Duration::from_millis(30));
        }
        (
            "200 OK",
            "image/svg+xml",
            b"<svg xmlns='http://www.w3.org/2000/svg'/>".to_vec(),
        )
    } else {
        ("404 Not Found", "text/plain", b"not found".to_vec())
    };
    let _=write!(stream,"HTTP/1.1 {status}\r\nContent-Type: {mime}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\nX-Content-Type-Options: nosniff\r\n\r\n",body.len());
    let _ = stream.write_all(&body);
}
pub fn ui(args: &[OsString]) -> Result<(), String> {
    let mut config = None;
    let mut smoke = false;
    let mut screenshots: Option<PathBuf> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].to_str() {
            Some("--config") if config.is_none() && i + 1 < args.len() => {
                i += 1;
                config = Some(PathBuf::from(&args[i]));
            }
            Some("--smoke-test") if !smoke => smoke = true,
            Some("--screenshots") if screenshots.is_none() && i + 1 < args.len() => {
                i += 1;
                screenshots = Some(PathBuf::from(&args[i]));
            }
            _ => return Err("Invalid UI arguments".into()),
        };
        i += 1;
    }
    if smoke && screenshots.is_some() {
        return Err("UI automation modes conflict".into());
    }
    if let Some(p) = &screenshots {
        if !p.is_dir() {
            return Err("Screenshot directory must exist".into());
        }
    }
    let config = match config {
        Some(p) => Config::from_json(&std::fs::read_to_string(p).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?,
        None => Config::preset("temperate").map_err(|e| e.to_string())?,
    };
    let state = Arc::new(Mutex::new(Controller::new(config)?));
    let listener = TcpListener::bind("127.0.0.1:0").map_err(|e| e.to_string())?;
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let addr = listener.local_addr().map_err(|e| e.to_string())?;
    let stop = Arc::new(AtomicBool::new(false));
    let ready = Arc::new(AtomicU64::new(0));
    let s = state.clone();
    let done = stop.clone();
    let engine = thread::spawn(move || {
        while !done.load(Ordering::Relaxed) {
            let speed = {
                let mut c = s.lock().unwrap();
                c.scheduled_tick();
                c.speed
            };
            thread::sleep(Duration::from_millis(1000 / speed));
        }
    });
    let target = if screenshots.is_some() {
        100
    } else if smoke {
        10
    } else {
        0
    };
    let s = state.clone();
    let done = stop.clone();
    let r = ready.clone();
    let server = thread::spawn(move || {
        while !done.load(Ordering::Relaxed) {
            match listener.accept() {
                Ok((stream, _)) => {
                    let s = s.clone();
                    let r = r.clone();
                    let host = addr.to_string();
                    thread::spawn(move || reply(stream, s, r, target, host));
                }
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    thread::sleep(Duration::from_millis(5))
                }
                Err(_) => break,
            }
        }
    });
    let url = format!("http://{addr}/");
    eprintln!("Evolution Simulation: {url}");
    let result = if smoke || screenshots.is_some() {
        let file = screenshots
            .as_ref()
            .map(|p| p.join("main.png"))
            .unwrap_or_else(|| {
                std::env::temp_dir().join(format!("evosim-smoke-{}.png", std::process::id()))
            });
        if file.exists() {
            std::fs::remove_file(&file).map_err(|e| format!("Cannot replace screenshot: {e}"))?;
        }
        let chrome = std::env::var_os("CHROME_BIN").unwrap_or_else(|| "chromium".into());
        let child = Command::new(&chrome)
            .args([
                "--headless",
                "--no-sandbox",
                "--disable-gpu",
                "--disable-dev-shm-usage",
                "--hide-scrollbars",
                "--window-size=1280,720",
            ])
            .arg(format!("--screenshot={}", file.display()))
            .arg(&url)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn();
        let main_result = match child {
            Err(e) => Err(format!("Cannot start Chromium: {e}")),
            Ok(mut child) => {
                let start = Instant::now();
                loop {
                    match child.try_wait() {
                        Ok(Some(status)) => {
                            break if status.success()
                                && ready.load(Ordering::Relaxed) >= target
                                && file.is_file()
                            {
                                Ok(())
                            } else {
                                Err(format!("Browser did not render tick {target}"))
                            }
                        }
                        Ok(None) if start.elapsed() < Duration::from_secs(55) => {
                            thread::sleep(Duration::from_millis(50))
                        }
                        _ => {
                            let _ = child.kill();
                            let _ = child.wait();
                            break Err("Browser timed out".into());
                        }
                    }
                }
            }
        };
        if main_result.is_ok() && screenshots.is_some() {
            let chart_file = screenshots.as_ref().unwrap().join("charts.png");
            let status = Command::new(&chrome)
                .args([
                    "--headless",
                    "--no-sandbox",
                    "--disable-gpu",
                    "--disable-dev-shm-usage",
                    "--hide-scrollbars",
                    "--window-size=1280,720",
                    "--virtual-time-budget=3000",
                ])
                .arg(format!("--screenshot={}", chart_file.display()))
                .arg(format!("{url}#charts"))
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
            match status {
                Ok(s) if s.success() && chart_file.is_file() => Ok(()),
                _ => Err("Chart screenshot failed".into()),
            }
        } else {
            main_result
        }
    } else {
        let _ = Command::new("xdg-open")
            .arg(&url)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn();
        loop {
            thread::park();
        }
    };
    stop.store(true, Ordering::Relaxed);
    let _ = server.join();
    let _ = engine.join();
    if smoke {
        let _ = std::fs::remove_file(
            std::env::temp_dir().join(format!("evosim-smoke-{}.png", std::process::id())),
        );
    }
    result
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn config_and_chart_history_are_transactional() {
        let mut c = Controller::new(Config::preset("temperate").unwrap()).unwrap();
        let before = c.sim.state_hash();
        assert!(c.start("{invalid").is_err());
        assert_eq!(before, c.sim.state_hash());
        let mut config = Config::preset("lush").unwrap();
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        let json = serde_json::to_string(&config).unwrap();
        assert_eq!(Config::from_json(&json).unwrap(), config);
        c.start(&json).unwrap();
        assert_eq!(c.history.len(), 1);
        let sample = &c.history[0];
        assert_eq!(sample["population"], json!([0, 0, 0]));
        assert!(sample["metrics"]["traits"]["plants"]["speed"].is_null());
        let hash = c.sim.state_hash();
        let snapshot: serde_json::Value = serde_json::from_str(&snapshot(&c, None)).unwrap();
        assert_eq!(
            snapshot["distribution"][0][0],
            json!([0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        );
        assert_eq!(hash, c.sim.state_hash());
        for _ in 0..1005 {
            c.command("step").unwrap();
        }
        assert_eq!(c.history.len(), 1000);
        assert!(c
            .history
            .iter()
            .zip(c.history.iter().skip(1))
            .all(|(a, b)| a["tick"].as_u64() < b["tick"].as_u64()));
        c.command("reset").unwrap();
        c.command("step").unwrap();
        assert_eq!(c.history.back().unwrap()["tick"], 1);
        c.command("reset").unwrap();
        assert_eq!(c.history.len(), 1);
        assert_eq!(c.sim.tick(), 0);
    }
    #[test]
    fn controls_and_checkpoint() {
        let config = Config::preset("temperate").unwrap();
        let mut c = Controller::new(config).unwrap();
        let initial = c.sim.state_hash();
        c.command("pause").unwrap();
        c.scheduled_tick();
        assert_eq!(c.sim.tick(), 0);
        c.command("step").unwrap();
        c.scheduled_tick();
        assert_eq!(c.sim.tick(), 1);
        c.command("step").unwrap();
        assert_eq!(c.sim.tick(), 2);
        assert!(c.command("speed/-1").is_err());
        for speed in ["speed/5", "speed/20", "speed/50"] {
            c.command(speed).unwrap();
        }
        let saved = evosim::checkpoint::encode(c.seed, &c.sim).unwrap();
        let hash = c.sim.state_hash();
        assert!(c.load(b"bad").is_err());
        assert_eq!(hash, c.sim.state_hash());
        c.command("step").unwrap();
        c.load(&saved).unwrap();
        assert_eq!(hash, c.sim.state_hash());
        c.command("reset").unwrap();
        assert_eq!(initial, c.sim.state_hash());
        let before = c.sim.state_hash();
        let id = *c.sim.living().keys().next().unwrap();
        let view = snapshot(&c, Some(id));
        assert!(view.contains("genome"));
        assert_eq!(before, c.sim.state_hash());
        c.command("run").unwrap();
        c.scheduled_tick();
        assert_eq!(c.sim.tick(), 1);
    }
    #[test]
    fn selected_death_is_reported_and_observation_is_read_only() {
        use evosim::organism::{DeathCause, Event};
        let mut c = Controller::new(Config::preset("temperate").unwrap()).unwrap();
        let id = *c.sim.living().keys().next().unwrap();
        c.sim
            .advance_with_events(&[Event::Death {
                id,
                cause: DeathCause::External,
            }])
            .unwrap();
        let before = c.sim.state_hash();
        let value: serde_json::Value = serde_json::from_str(&snapshot(&c, Some(id))).unwrap();
        assert_eq!(value["detail"]["status"], "dead");
        assert_eq!(value["detail"]["cause"], "External");
        assert_eq!(before, c.sim.state_hash());
    }
}

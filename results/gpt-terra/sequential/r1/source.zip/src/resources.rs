//! Bounded cell-local environmental energy reserves.
use crate::geometry::{Cell, Grid};

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Resources {
    grid: Grid,
    reserves: Vec<u16>,
}
impl Resources {
    pub(crate) fn valid_for(&self, grid: Grid) -> bool {
        self.grid == grid
            && grid
                .width()
                .checked_mul(grid.height())
                .and_then(|n| usize::try_from(n).ok())
                == Some(self.reserves.len())
            && self.reserves.iter().all(|&r| r <= 100)
    }
    pub fn new(grid: Grid) -> Result<Self, &'static str> {
        let size = grid
            .width()
            .checked_mul(grid.height())
            .and_then(|n| usize::try_from(n).ok())
            .ok_or("grid too large")?;
        let mut reserves = Vec::new();
        reserves
            .try_reserve_exact(size)
            .map_err(|_| "resource allocation failed")?;
        reserves.resize(size, 100);
        Ok(Self { grid, reserves })
    }
    fn offset(&self, cell: Cell) -> usize {
        let c = self.grid.cell(cell.x as i128, cell.y as i128);
        (c.y * self.grid.width() + c.x) as usize
    }
    pub fn at(&self, cell: Cell) -> u16 {
        self.reserves[self.offset(cell)]
    }
    pub(crate) fn regenerate(&mut self) {
        for reserve in &mut self.reserves {
            *reserve = (*reserve + 2).min(100);
        }
    }
    pub(crate) fn withdraw(&mut self, cell: Cell, amount: u16) -> u16 {
        let i = self.offset(cell);
        let taken = amount.min(self.reserves[i]);
        self.reserves[i] -= taken;
        taken
    }
}

//! SplitMix64: deterministic, non-cryptographic randomness owned by a simulation.
//! The exported state is the raw accumulator, not the most recent output.

#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct SplitMix64 {
    state: u64,
}

impl SplitMix64 {
    /// Preserve the signed seed's two's-complement bit pattern.
    pub fn new(seed: i64) -> Self {
        Self::from_state(seed as u64)
    }

    pub fn from_state(state: u64) -> Self {
        Self { state }
    }

    pub fn state(&self) -> u64 {
        self.state
    }

    pub fn next_u64(&mut self) -> u64 {
        self.state = self.state.wrapping_add(0x9e3779b97f4a7c15);
        let mut z = self.state;
        z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
        z ^ (z >> 31)
    }
}

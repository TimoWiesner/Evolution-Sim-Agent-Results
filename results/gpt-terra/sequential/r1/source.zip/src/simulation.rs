//! Deterministic tick scheduler and organism lifecycle storage.
//! Future stages update the world, snapshot living IDs, act in ascending ID
//! order, and commit deferred changes before advancing the clock. Candidate ties
//! use ascending IDs; dead IDs cannot act and births become active next tick.
use crate::climate::{ClimateField, CurrentClimate};
use crate::config::{Climate, Config, ConfigError, Genetics};
use crate::genome::Genome;
use crate::geometry::{Cell, Grid};
use crate::organism::{Counts, DeathCause, DeathRecord, Event, Kind, Organism};
use crate::resources::Resources;
use crate::rng::SplitMix64;
use crate::spatial::SpatialIndex;
use crate::species::SpeciesRegistry;
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct Simulation {
    tick: u64,
    world: Grid,
    climate: ClimateField,
    rng: SplitMix64,
    climate_settings: Climate,
    genetics: Genetics,
    weather: (f64, f64),
    living: BTreeMap<u64, Organism>,
    species: SpeciesRegistry,
    spatial: SpatialIndex,
    resources: Resources,
    next_id: u64,
    births: Counts,
    deaths: Counts,
    death_records: Vec<DeathRecord>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct TickOverflow;
impl fmt::Display for TickOverflow {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("simulation tick overflow")
    }
}
impl std::error::Error for TickOverflow {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Stage {
    UpdateWorld,
    SnapshotLivingIds,
    Act,
    CommitDeferred,
}

impl Simulation {
    pub fn new(config: &Config) -> Result<Self, ConfigError> {
        config.validate()?;
        let world = Grid::new(config.world.width, config.world.height)
            .expect("validated dimensions are nonzero");
        let total = config
            .initial
            .plants
            .checked_add(config.initial.herbivores)
            .and_then(|n| n.checked_add(config.initial.carnivores))
            .ok_or_else(|| ConfigError("initial population exceeds ID capacity".into()))?;
        // Bound the initial allocation before inserting into the infallible BTreeMap.
        let mut reservation = Vec::<Organism>::new();
        reservation
            .try_reserve_exact(
                usize::try_from(total)
                    .map_err(|_| ConfigError("initial population too large".into()))?,
            )
            .map_err(|_| ConfigError("initial population allocation failed".into()))?;
        drop(reservation);
        let mut living = BTreeMap::new();
        let mut species = SpeciesRegistry::default();
        let mut spatial = SpatialIndex::new(world).map_err(|e| ConfigError(e.into()))?;
        let mut id = 0u64;
        for (kind, count) in [
            (Kind::Plant, config.initial.plants),
            (Kind::Herbivore, config.initial.herbivores),
            (Kind::Carnivore, config.initial.carnivores),
        ] {
            for _ in 0..count {
                let position = Cell {
                    x: id % world.width(),
                    y: ((id / world.width()) + world.height() / 4) % world.height(),
                };
                spatial
                    .insert(id, position, kind)
                    .expect("unique founder ID");
                let genome = Genome::founder(kind);
                let species_id = species.add(&genome, None, 0);
                living.insert(
                    id,
                    Organism::new(id, kind, position, species_id, genome, [None, None], 0),
                );
                id += 1;
            }
        }
        Ok(Self {
            tick: 0,
            world,
            climate: ClimateField::new(world),
            rng: SplitMix64::new(config.seed),
            climate_settings: config.climate.clone(),
            genetics: config.genetics.clone(),
            weather: (0.0, 0.0),
            living,
            species,
            spatial,
            resources: Resources::new(world).map_err(|e| ConfigError(e.into()))?,
            next_id: total,
            births: Counts::default(),
            deaths: Counts::default(),
            death_records: Vec::new(),
        })
    }

    pub(crate) fn validate_checkpoint(&self) -> Result<(), String> {
        let invalid = || "Invalid checkpoint state".to_string();
        let w = self.world.width();
        let h = self.world.height();
        if w == 0
            || h == 0
            || w.checked_mul(h).is_none()
            || self.climate != ClimateField::new(self.world)
            || !self.weather.0.is_finite()
            || !self.weather.1.is_finite()
            || !self.resources.valid_for(self.world)
        {
            return Err(invalid());
        }
        let config = crate::config::Config {
            seed: 0,
            world: crate::config::World {
                width: w,
                height: h,
            },
            initial: crate::config::Initial {
                plants: 0,
                herbivores: 0,
                carnivores: 0,
            },
            climate: self.climate_settings.clone(),
            genetics: self.genetics.clone(),
            resources: crate::config::Resources { regrowth_rate: 0.0 },
        };
        config.validate().map_err(|_| invalid())?;
        let mut counts = vec![0u64; self.species.records().len()];
        for (id, o) in &self.living {
            if *id != o.id
                || *id >= self.next_id
                || o.position.x >= w
                || o.position.y >= h
                || o.genome.kind() != o.kind
                || Genome::new(o.kind, o.genome.alleles().to_vec()).is_err()
                || o.genome.traits() != o.traits
                || o.health == 0
                || o.energy == 0
            {
                return Err(invalid());
            }
            let i = usize::try_from(o.species_id).map_err(|_| invalid())?;
            let sp = self.species.records().get(i).ok_or_else(invalid)?;
            if sp.kind != o.kind {
                return Err(invalid());
            }
            counts[i] += 1;
        }
        for (i, sp) in self.species.records().iter().enumerate() {
            if sp.id != i as u64
                || sp.living != counts[i]
                || (sp.living == 0) != sp.extinct_tick.is_some()
                || sp.reference.kind() != sp.kind
                || Genome::new(sp.kind, sp.reference.alleles().to_vec()).is_err()
                || sp.arose_tick > self.tick
                || sp.extinct_tick.is_some_and(|t| t > self.tick)
                || sp.parent.is_some_and(|p| p >= sp.id)
            {
                return Err(invalid());
            }
        }
        if !self.spatial.valid_for(self.world, &self.living) {
            return Err(invalid());
        }
        let mut deaths = Counts::default();
        let mut ids = BTreeSet::new();
        for d in &self.death_records {
            if d.id >= self.next_id
                || d.tick > self.tick
                || self.living.contains_key(&d.id)
                || !ids.insert(d.id)
            {
                return Err(invalid());
            }
            *deaths.get_mut(d.kind) += 1;
        }
        if deaths != self.deaths
            || self.next_id
                != (self.living.len() as u64)
                    .checked_add(self.death_records.len() as u64)
                    .ok_or_else(invalid)?
        {
            return Err(invalid());
        }
        Ok(())
    }
    pub fn tick(&self) -> u64 {
        self.tick
    }
    pub fn world(&self) -> &Grid {
        &self.world
    }
    pub fn climate(&self) -> &ClimateField {
        &self.climate
    }
    /// Query the current tick without changing state or consuming randomness.
    pub fn climate_at(&self, cell: Cell) -> CurrentClimate {
        self.climate
            .current(cell, self.tick, &self.climate_settings, self.weather)
    }
    pub fn resources(&self) -> &Resources {
        &self.resources
    }
    pub fn rng(&self) -> &SplitMix64 {
        &self.rng
    }
    pub fn rng_mut(&mut self) -> &mut SplitMix64 {
        &mut self.rng
    }

    pub fn species(&self) -> &SpeciesRegistry {
        &self.species
    }
    pub fn living(&self) -> &BTreeMap<u64, Organism> {
        &self.living
    }
    /// Find living IDs within a wrapped Chebyshev radius.
    pub fn query(&self, center: Cell, radius: u64, kind: Option<Kind>) -> Vec<u64> {
        self.spatial.query(center, radius, kind)
    }
    /// Perceive all other living organisms within 1 + speed Chebyshev cells.
    /// Results are sorted by ID, including organisms sharing the observer's cell.
    pub fn perceive(&self, id: u64) -> Result<Vec<u64>, &'static str> {
        let animal = self.living.get(&id).ok_or("unknown ID")?;
        if animal.kind == Kind::Plant {
            return Err("plant cannot perceive");
        }
        let mut ids =
            self.spatial
                .query(animal.position, 1 + u64::from(animal.traits.speed()), None);
        ids.retain(|other| *other != id);
        Ok(ids)
    }

    fn act_animal(&mut self, id: u64, tick: u64) {
        let animal = &self.living[&id];
        let kind = animal.kind;
        let speed = animal.traits.speed();
        let origin = animal.position;
        if kind == Kind::Herbivore {
            let temperature = self.climate_at(origin).temperature;
            let cost = 2 + (((temperature - 20.0).abs() - 10.0).max(0.0) / 10.0).floor() as u16;
            let animal = self.living.get_mut(&id).unwrap();
            animal.energy = animal.energy.saturating_sub(cost);
            if animal.energy == 0 {
                self.kill(id, DeathCause::Starvation, tick)
                    .expect("death count cannot exceed allocated IDs");
                return;
            }
        }
        if kind == Kind::Carnivore {
            let animal = self.living.get_mut(&id).unwrap();
            animal.energy = animal.energy.saturating_sub(2);
            if animal.energy == 0 {
                self.kill(id, DeathCause::Starvation, tick)
                    .expect("death count cannot exceed allocated IDs");
                return;
            }
        }
        let visible = self.perceive(id).expect("living animal");
        if kind == Kind::Herbivore
            && self.living[&id].traits.aggression().unwrap() < 50
            && visible.iter().any(|other| {
                self.living[other].kind == Kind::Carnivore
                    && self.world.distance(origin, self.living[other].position) <= 2
            })
        {
            return;
        }
        let target_kind = if kind == Kind::Herbivore {
            Kind::Plant
        } else {
            Kind::Herbivore
        };
        let target = visible
            .into_iter()
            .filter(|candidate| self.living[candidate].kind == target_kind)
            .min_by_key(|candidate| {
                (
                    self.world.distance(origin, self.living[candidate].position),
                    *candidate,
                )
            });
        if let Some(target_id) = target {
            let target_position = self.living[&target_id].position;
            let reach = 1;
            for _ in 0..speed {
                let position = self.living[&id].position;
                if self.world.distance(position, target_position) <= reach {
                    break;
                }
                let delta = self.world.displacement(position, target_position);
                let next = self.world.cell(
                    position.x as i128 + delta.dx.signum(),
                    position.y as i128 + delta.dy.signum(),
                );
                self.move_organism(id, next)
                    .expect("living index invariant");
                let animal = self.living.get_mut(&id).unwrap();
                animal.energy = animal.energy.saturating_sub(1 + u16::from(speed));
                if animal.energy == 0 {
                    self.kill(id, DeathCause::Starvation, tick)
                        .expect("death count cannot exceed allocated IDs");
                    return;
                }
            }
            if kind == Kind::Herbivore
                && self
                    .world
                    .distance(self.living[&id].position, target_position)
                    <= 1
            {
                let bite = 20
                    .min(self.living[&target_id].energy)
                    .min(1000 - self.living[&id].energy);
                self.living.get_mut(&target_id).unwrap().energy -= bite;
                self.living.get_mut(&id).unwrap().energy += bite;
                if self.living[&target_id].energy == 0 {
                    self.kill(target_id, DeathCause::Grazing, tick)
                        .expect("death count cannot exceed allocated IDs");
                }
            }
            if kind == Kind::Carnivore
                && self.living[&id].energy < 600
                && self.living.contains_key(&target_id)
                && self
                    .world
                    .distance(self.living[&id].position, self.living[&target_id].position)
                    <= 1
            {
                let hunter = self.living.get_mut(&id).unwrap();
                hunter.energy = hunter.energy.saturating_sub(5);
                if hunter.energy == 0 {
                    self.kill(id, DeathCause::Starvation, tick)
                        .expect("death count cannot exceed allocated IDs");
                    return;
                }
                let hunter = &self.living[&id];
                let prey = &self.living[&target_id];
                let probability = (50 + i32::from(hunter.traits.strength())
                    - i32::from(prey.traits.strength())
                    + 2 * (i32::from(hunter.traits.speed()) - i32::from(prey.traits.speed())))
                .clamp(5, 95) as u64;
                // Rejection sampling avoids modulo bias, using only the simulation RNG.
                let threshold = 100u64.wrapping_neg() % 100;
                let roll = loop {
                    let draw = self.rng.next_u64();
                    if draw >= threshold {
                        break draw % 100;
                    }
                };
                if roll < probability {
                    let energy = self.living[&target_id]
                        .energy
                        .min(1000 - self.living[&id].energy);
                    self.living.get_mut(&id).unwrap().energy += energy;
                    self.kill(target_id, DeathCause::Predation, tick)
                        .expect("death count cannot exceed allocated IDs");
                }
            }
        }
    }

    fn try_mate(
        &mut self,
        id: u64,
        tick: u64,
        plant_pending: u64,
        event_count: u64,
        pending: &mut Vec<(Kind, Cell, Genome, [Option<u64>; 2], u64, u64)>,
    ) {
        let parent = &self.living[&id];
        let eligible = |o: &Organism| o.age >= 50 && o.energy >= 600 && tick >= o.next_mating_tick;
        if !eligible(parent) {
            return;
        }
        let kind = parent.kind;
        let position = parent.position;
        let Some(cooldown) = tick.checked_add(51) else {
            return;
        };
        let count = pending
            .iter()
            .filter(|(k, _, _, _, _, _)| *k == kind)
            .count() as u64;
        let births = match kind {
            Kind::Herbivore => self.births.herbivores,
            Kind::Carnivore => self.births.carnivores,
            Kind::Plant => return,
        };
        if plant_pending
            .checked_add(event_count)
            .and_then(|n| n.checked_add(pending.len() as u64))
            .and_then(|n| n.checked_add(1))
            .and_then(|n| self.next_id.checked_add(n))
            .is_none()
            || count
                .checked_add(1)
                .and_then(|n| births.checked_add(n))
                .is_none()
        {
            return;
        }
        let mate = self
            .spatial
            .query(position, 1, Some(kind))
            .into_iter()
            .filter(|other| *other != id)
            .filter_map(|other| self.living.get(&other))
            .filter(|other| {
                eligible(other)
                    && parent
                        .genome
                        .distance(&other.genome)
                        .is_ok_and(|d| d <= 0.15)
            })
            .min_by_key(|other| (self.world.distance(position, other.position), other.id))
            .map(|other| other.id);
        let Some(mate) = mate else {
            return;
        };
        let other = &self.living[&mate];
        let Some(generation) = parent.generation.max(other.generation).checked_add(1) else {
            return;
        };
        let probability =
            (u64::from(parent.traits.fertility()) + u64::from(other.traits.fertility())) / 2;
        let threshold = 100u64.wrapping_neg() % 100;
        let roll = loop {
            let draw = self.rng.next_u64();
            if draw >= threshold {
                break draw % 100;
            }
        };
        if roll >= probability {
            return;
        }
        let genome = Genome::inherit(
            &self.living[&id].genome,
            Some(&self.living[&mate].genome),
            &self.genetics,
            &mut self.rng,
        )
        .expect("valid animal inheritance");
        for parent_id in [id, mate] {
            let parent = self.living.get_mut(&parent_id).unwrap();
            parent.energy -= 200;
            parent.next_mating_tick = cooldown;
        }
        pending.push((
            kind,
            position,
            genome,
            [Some(id), Some(mate)],
            generation,
            self.living[&id].species_id,
        ));
    }

    /// Relocate a living organism; movement policy belongs to ecology.
    pub fn move_organism(&mut self, id: u64, cell: Cell) -> Result<(), &'static str> {
        if !self.living.contains_key(&id) {
            return Err("unknown ID");
        }
        let cell = self.world.cell(cell.x as i128, cell.y as i128);
        self.spatial.move_to(id, cell)?;
        self.living.get_mut(&id).unwrap().position = cell;
        Ok(())
    }
    pub fn births(&self) -> &Counts {
        &self.births
    }
    pub fn deaths(&self) -> &Counts {
        &self.deaths
    }
    pub fn death_records(&self) -> &[DeathRecord] {
        &self.death_records
    }

    fn kill(&mut self, id: u64, cause: DeathCause, tick: u64) -> Result<(), &'static str> {
        if let Some(o) = self.living.get(&id) {
            let kind = o.kind;
            let species_id = o.species_id;
            let count = self.deaths.get_mut(kind);
            *count = count.checked_add(1).ok_or("death counter exhausted")?;
            self.species.remove(species_id, tick);
            self.living.remove(&id);
            self.spatial.remove(id).expect("living index invariant");
            self.death_records.push(DeathRecord {
                id,
                kind,
                tick,
                cause,
            });
        }
        Ok(())
    }

    /// Transactional tick with externally supplied lifecycle events. Invalid events
    /// leave the entire simulation unchanged. Duplicate deaths are no-ops.
    pub fn advance_with_events(&mut self, events: &[Event]) -> Result<(), &'static str> {
        let mut next = self.clone();
        next.apply_events_and_tick(events)?;
        *self = next;
        Ok(())
    }
    fn apply_events_and_tick(&mut self, events: &[Event]) -> Result<(), &'static str> {
        let tick = self.tick.checked_add(1).ok_or("tick overflow")?;
        let mut pending = Vec::new();
        for event in events {
            match event {
                Event::Death { id, cause } => self.kill(*id, *cause, tick)?,
                Event::Adjust { id, energy, health } => {
                    if *energy > 0 {
                        return Err("energy cannot be externally created");
                    }
                    if let Some(o) = self.living.get_mut(id) {
                        o.energy = (i64::from(o.energy) + i64::from(*energy)).clamp(0, 1000) as u16;
                        o.health = (i64::from(o.health) + i64::from(*health))
                            .clamp(0, i64::from(o.traits.max_health()))
                            as u16;
                        let cause = if o.energy == 0 {
                            Some(DeathCause::Starvation)
                        } else if o.health == 0 {
                            Some(DeathCause::Injury)
                        } else {
                            None
                        };
                        if let Some(cause) = cause {
                            self.kill(*id, cause, tick)?;
                        }
                    }
                }
                Event::Birth {
                    kind,
                    position,
                    parents,
                } => {
                    if *kind != Kind::Plant {
                        return Err("animal births require mating");
                    }
                    if parents[0].is_none()
                        || parents[1].is_some()
                        || parents[0] == parents[1]
                        || position.x >= self.world.width()
                        || position.y >= self.world.height()
                    {
                        return Err("invalid birth");
                    }
                    let mut generation = 0;
                    for id in parents.iter().flatten() {
                        let parent = self.living.get(id).ok_or("parent is not living")?;
                        if parent.kind != *kind {
                            return Err("parent kind mismatch");
                        }
                        generation = generation.max(
                            parent
                                .generation
                                .checked_add(1)
                                .ok_or("generation exhausted")?,
                        );
                    }
                    let parent_id = parents[0].unwrap();
                    if self.living[&parent_id].energy < 800 {
                        return Err("parent lacks reproductive energy");
                    }
                    self.living.get_mut(&parent_id).unwrap().energy -= 400;
                    let first = &self.living[&parent_id].genome;
                    let second = parents[1].map(|id| &self.living[&id].genome);
                    let genome = Genome::inherit(first, second, &self.genetics, &mut self.rng)?;
                    pending.push((
                        *kind,
                        *position,
                        genome,
                        *parents,
                        generation,
                        self.living[&parents[0].unwrap()].species_id,
                    ));
                }
            }
        }
        let reserved: BTreeSet<_> = pending
            .iter()
            .filter(|(kind, _, _, _, _, _)| *kind == Kind::Plant)
            .map(|(_, cell, _, _, _, _)| (cell.x, cell.y))
            .collect();
        let event_count = pending.len() as u64;
        let plant_events = pending
            .iter()
            .filter(|(kind, _, _, _, _, _)| *kind == Kind::Plant)
            .count() as u64;
        self.advance_inner(|_| {}, reserved, event_count, plant_events)
            .map_err(|_| "tick overflow")?;
        for (kind, position, genome, parents, generation, parent_species) in pending {
            let id = self.next_id;
            self.next_id = id.checked_add(1).ok_or("ID exhausted")?;
            let count = self.births.get_mut(kind);
            *count = count.checked_add(1).ok_or("birth counter exhausted")?;
            self.spatial
                .insert(id, position, kind)
                .expect("unique birth ID");
            let species_id = self.species.add(&genome, Some(parent_species), tick);
            let mut child =
                Organism::new(id, kind, position, species_id, genome, parents, generation);
            child.energy = 400;
            self.living.insert(id, child);
        }
        Ok(())
    }

    /// Advance exactly one tick, or return an error without changing state.
    pub fn advance_one_tick(&mut self) -> Result<(), TickOverflow> {
        self.advance_with(|_| {})
    }

    fn advance_with(&mut self, mut stage: impl FnMut(Stage)) -> Result<(), TickOverflow> {
        self.advance_inner(&mut stage, BTreeSet::new(), 0, 0)
    }

    fn advance_inner(
        &mut self,
        mut stage: impl FnMut(Stage),
        mut reserved: BTreeSet<(u64, u64)>,
        event_count: u64,
        plant_events: u64,
    ) -> Result<(), TickOverflow> {
        let next = self.tick.checked_add(1).ok_or(TickOverflow)?;
        let mut pending = Vec::new();
        let mut animal_pending: Vec<(Kind, Cell, Genome, [Option<u64>; 2], u64, u64)> = Vec::new();
        // Weather precedes the ordered lifecycle stages.
        for step in [
            Stage::UpdateWorld,
            Stage::SnapshotLivingIds,
            Stage::Act,
            Stage::CommitDeferred,
        ] {
            if step == Stage::UpdateWorld && self.climate_settings.weather_strength != 0.0 {
                let mut draw =
                    || (self.rng.next_u64() >> 11) as f64 / (1u64 << 53) as f64 * 2.0 - 1.0;
                self.weather = (
                    6.0 * self.climate_settings.weather_strength * draw(),
                    200.0 * self.climate_settings.weather_strength * draw(),
                );
            }
            if step == Stage::UpdateWorld {
                self.resources.regenerate();
            }
            if step == Stage::Act {
                let ids: Vec<_> = self.living.keys().copied().collect();
                for id in ids {
                    let Some(o) = self.living.get_mut(&id) else {
                        continue;
                    };
                    o.age += 1;
                    if o.age >= o.traits.max_lifespan() {
                        self.kill(id, DeathCause::Age, next)
                            .expect("death count cannot exceed allocated IDs");
                        continue;
                    }
                    if o.kind == Kind::Plant {
                        if o.energy <= 2 {
                            self.kill(id, DeathCause::Starvation, next)
                                .expect("death count cannot exceed allocated IDs");
                            continue;
                        }
                        o.energy -= 2;
                        let position = o.position;
                        let strength = o.traits.strength();
                        let missing = 1000 - o.energy;
                        let climate = self.climate_at(position);
                        let potential =
                            plant_potential(strength, climate.temperature, climate.precipitation);
                        let gain = self.resources.withdraw(position, potential.min(missing));
                        self.living.get_mut(&id).unwrap().energy += gain;
                        let parent = &self.living[&id];
                        // Exhausted representation capacity prevents a birth without changing
                        // energy or RNG, keeping ordinary ticks atomic without a full clone.
                        let capacity = ((pending.len() + animal_pending.len()) as u64)
                            .checked_add(event_count)
                            .and_then(|n| n.checked_add(1))
                            .is_some_and(|n| self.next_id.checked_add(n).is_some())
                            && (pending.len() as u64)
                                .checked_add(plant_events)
                                .and_then(|n| n.checked_add(1))
                                .is_some_and(|n| self.births.plants.checked_add(n).is_some());
                        if parent.energy >= 800 && capacity {
                            if let Some(generation) = parent.generation.checked_add(1) {
                                let destination =
                                    self.world.cells_within(position, 2).find(|cell| {
                                        *cell != position
                                            && !reserved.contains(&(cell.x, cell.y))
                                            && self.resources.at(*cell) >= 10
                                            && !self.spatial.contains_kind(*cell, Kind::Plant)
                                    });
                                if let Some(cell) = destination {
                                    let genome = Genome::inherit(
                                        &parent.genome,
                                        None,
                                        &self.genetics,
                                        &mut self.rng,
                                    )
                                    .expect("valid plant inheritance");
                                    self.living.get_mut(&id).unwrap().energy -= 400;
                                    reserved.insert((cell.x, cell.y));
                                    pending.push((
                                        cell,
                                        genome,
                                        id,
                                        generation,
                                        self.living[&id].species_id,
                                    ));
                                }
                            }
                        }
                    } else {
                        self.act_animal(id, next);
                        if self.living.contains_key(&id) {
                            self.try_mate(
                                id,
                                next,
                                pending.len() as u64,
                                event_count,
                                &mut animal_pending,
                            );
                        }
                    }
                }
            }
            if step == Stage::CommitDeferred {
                for (position, genome, parent, generation, parent_species) in pending.drain(..) {
                    let id = self.next_id;
                    self.next_id += 1;
                    self.births.plants += 1;
                    let species_id = self.species.add(&genome, Some(parent_species), next);
                    let mut child = Organism::new(
                        id,
                        Kind::Plant,
                        position,
                        species_id,
                        genome,
                        [Some(parent), None],
                        generation,
                    );
                    child.energy = 400;
                    self.spatial
                        .insert(id, position, Kind::Plant)
                        .expect("unique birth ID");
                    self.living.insert(id, child);
                }
                for (kind, position, genome, parents, generation, parent_species) in
                    animal_pending.drain(..)
                {
                    let id = self.next_id;
                    self.next_id += 1;
                    *self.births.get_mut(kind) += 1;
                    let species_id = self.species.add(&genome, Some(parent_species), next);
                    let mut child =
                        Organism::new(id, kind, position, species_id, genome, parents, generation);
                    child.energy = 400;
                    self.spatial
                        .insert(id, position, kind)
                        .expect("unique birth ID");
                    self.living.insert(id, child);
                }
            }
            stage(step);
        }
        self.tick = next;
        Ok(())
    }
}

fn plant_potential(strength: u8, temperature: f64, precipitation: f64) -> u16 {
    let temperature_factor = (1.0 - (temperature - 20.0).abs() / 35.0).clamp(0.0, 1.0);
    let water_factor = (precipitation / 1000.0).clamp(0.0, 1.0);
    ((4 + strength / 10) as f64 * temperature_factor * water_factor).floor() as u16
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mating_fixture(kind: Kind, n: u64, fertility: u16) -> Simulation {
        let mut c = Config::preset("temperate").unwrap();
        c.world.width = 10;
        c.world.height = 10;
        c.initial.plants = 0;
        c.initial.herbivores = if kind == Kind::Herbivore { n } else { 0 };
        c.initial.carnivores = if kind == Kind::Carnivore { n } else { 0 };
        c.climate.weather_strength = 0.0;
        c.genetics.mutation_rate = 0.0;
        let mut s = Simulation::new(&c).unwrap();
        for o in s.living.values_mut() {
            let mut a = o.genome.alleles().to_vec();
            a[2] = [fertility, fertility];
            o.genome = Genome::new(kind, a).unwrap();
            o.traits = o.genome.traits();
            o.age = 50;
            o.energy = 1000;
        }
        s
    }

    #[test]
    fn sexual_mating_costs_inheritance_cooldown_and_deferred_birth() {
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            let mut s = mating_fixture(kind, 3, 1000);
            s.move_organism(0, Cell { x: 0, y: 0 }).unwrap();
            s.move_organism(1, Cell { x: 9, y: 0 }).unwrap();
            s.move_organism(2, Cell { x: 0, y: 0 }).unwrap();
            s.living.get_mut(&0).unwrap().generation = 3;
            let mut pending = Vec::new();
            s.try_mate(0, 10, 0, 0, &mut pending);
            assert_eq!(pending.len(), 1);
            assert_eq!(pending[0].3, [Some(0), Some(2)]); // closest beats lower ID
            assert_eq!(pending[0].4, 4);
            assert_eq!(s.living[&0].energy, 800);
            assert_eq!(s.living[&2].energy, 800);
            assert_eq!(s.living[&0].next_mating_tick, 61);
            assert_eq!(pending[0].2.alleles(), s.living[&0].genome.alleles());
            s.try_mate(2, 10, 0, 0, &mut pending);
            s.try_mate(0, 60, 0, 0, &mut pending);
            assert_eq!(pending.len(), 1);
            s.try_mate(0, 61, 0, 0, &mut pending);
            assert_eq!(pending.len(), 2);
            assert_eq!(pending[1].3, [Some(0), Some(2)]);
            let mut actual = mating_fixture(kind, 2, 1000);
            actual.advance_one_tick().unwrap();
            let child = &actual.living[&2];
            assert_eq!(
                (child.age, child.energy, child.parents),
                (0, 400, [Some(0), Some(1)])
            );
            assert_eq!(*actual.births.get_mut(kind), 1);
        }
    }

    #[test]
    fn mating_eligibility_fertility_and_capacity() {
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            let mut single = mating_fixture(kind, 1, 1000);
            for _ in 0..100 {
                single.advance_one_tick().unwrap();
            }
            assert_eq!(*single.births.get_mut(kind), 0);
            let base = mating_fixture(kind, 2, 1000);
            for case in 0..7 {
                let mut s = base.clone();
                match case {
                    0 => s.living.get_mut(&1).unwrap().age = 49,
                    1 => s.living.get_mut(&1).unwrap().energy = 599,
                    2 => s.move_organism(1, Cell { x: 4, y: 0 }).unwrap(),
                    3 => {
                        let o = s.living.get_mut(&1).unwrap();
                        o.genome = Genome::new(kind, vec![[0, 0]; 6]).unwrap();
                    }
                    4 => s.living.get_mut(&1).unwrap().next_mating_tick = 2,
                    5 => s.next_id = u64::MAX,
                    _ => s.living.get_mut(&1).unwrap().generation = u64::MAX,
                }
                let rng = s.rng;
                let mut pending = Vec::new();
                s.try_mate(0, 1, 0, 0, &mut pending);
                assert!(pending.is_empty(), "case {case}");
                assert_eq!(s.rng, rng);
                assert_eq!(s.living[&0].energy, 1000);
            }
            let mut zero = mating_fixture(kind, 2, 0);
            let mut pending = Vec::new();
            zero.try_mate(0, 1, 0, 0, &mut pending);
            assert!(pending.is_empty());
            let before = base.clone();
            let mut event = base;
            assert!(event
                .advance_with_events(&[Event::Birth {
                    kind,
                    position: Cell { x: 0, y: 0 },
                    parents: [Some(0), Some(1)]
                }])
                .is_err());
            assert_eq!(event, before);
        }
    }

    #[test]
    fn mating_crossover_mutation_replay_and_reservations() {
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            let mut s = mating_fixture(kind, 2, 1000);
            let mut a = s.living[&0].genome.alleles().to_vec();
            a[1] = [400, 450];
            let mut b = a.clone();
            b[1] = [550, 600];
            for (id, alleles) in [(0, a.clone()), (1, b.clone())] {
                let o = s.living.get_mut(&id).unwrap();
                o.genome = Genome::new(kind, alleles).unwrap();
                o.traits = o.genome.traits();
            }
            let mut p = Vec::new();
            s.try_mate(0, 1, 0, 0, &mut p);
            for (i, allele) in p[0].2.alleles().iter().enumerate() {
                assert!(a[i].contains(&allele[0]));
                assert!(b[i].contains(&allele[1]));
            }
            let mut m = mating_fixture(kind, 2, 1000);
            m.genetics.mutation_rate = 1.0;
            m.genetics.mutation_strength = 0.1;
            let mut replay = m.clone();
            let mut first = Vec::new();
            let mut second = Vec::new();
            m.try_mate(0, 1, 0, 0, &mut first);
            replay.try_mate(0, 1, 0, 0, &mut second);
            assert_eq!(first, second);
            assert_ne!(first[0].2, m.living[&0].genome);
            assert_eq!(m, replay);
            let mut blocked = mating_fixture(kind, 2, 1000);
            *blocked.births.get_mut(kind) = u64::MAX;
            let rng = blocked.rng;
            let mut pending = Vec::new();
            blocked.try_mate(0, 1, 0, 0, &mut pending);
            assert!(pending.is_empty());
            assert_eq!(blocked.rng, rng);
            blocked.kill(1, DeathCause::External, 1).unwrap();
            *blocked.births.get_mut(kind) = 0;
            blocked.try_mate(0, 1, 0, 0, &mut pending);
            assert!(pending.is_empty());
        }
    }

    fn animal_fixture(width: u64, height: u64) -> Simulation {
        let mut config = Config::preset("temperate").unwrap();
        config.world.width = width;
        config.world.height = height;
        config.initial.plants = 2;
        config.initial.herbivores = 2;
        config.initial.carnivores = 1;
        config.climate.weather_strength = 0.0;
        let mut sim = Simulation::new(&config).unwrap();
        for o in sim.living.values_mut() {
            o.energy = 500;
        }
        sim
    }

    fn speed(sim: &mut Simulation, id: u64, value: u16) {
        let o = sim.living.get_mut(&id).unwrap();
        let mut loci = vec![[500, 500]; 6];
        loci[0] = [value * 100, value * 100];
        o.genome = Genome::new(o.kind, loci).unwrap();
        o.traits = o.genome.traits();
    }

    fn hunt_fixture() -> Simulation {
        let mut sim = animal_fixture(20, 20);
        for (id, cell) in [
            (0, (10, 10)),
            (1, (10, 11)),
            (2, (19, 19)),
            (3, (10, 0)),
            (4, (0, 0)),
        ] {
            sim.move_organism(
                id,
                Cell {
                    x: cell.0,
                    y: cell.1,
                },
            )
            .unwrap();
        }
        sim
    }

    #[test]
    fn hunting_randomness_traits_and_energy() {
        let base = hunt_fixture();
        let mut kills = 0;
        let mut escapes = 0;
        for seed in 0..200 {
            let mut sim = base.clone();
            sim.rng = SplitMix64::new(seed);
            sim.living.get_mut(&2).unwrap().energy = 100;
            sim.act_animal(4, 1);
            if sim.living.contains_key(&2) {
                escapes += 1;
                assert_eq!(sim.living[&4].energy, 493);
            } else {
                kills += 1;
                assert_eq!(sim.living[&4].energy, 593);
                assert_eq!(sim.deaths.herbivores, 1);
                assert_eq!(
                    sim.death_records.last().unwrap().cause,
                    DeathCause::Predation
                );
                assert!(!sim.query(Cell { x: 19, y: 19 }, 0, None).contains(&2));
            }
        }
        assert!(kills > 0 && escapes > 0);
        // Identical draws, varying each participant's strength or speed, alter outcomes.
        for (id, locus) in [(4, 0), (4, 1), (2, 0), (2, 1)] {
            let mut different = 0;
            for seed in 0..200 {
                let mut low = base.clone();
                let mut high = base.clone();
                for (sim, allele) in [(&mut low, 0), (&mut high, 1000)] {
                    let o = sim.living.get_mut(&id).unwrap();
                    let mut loci = o.genome.alleles().to_vec();
                    loci[locus] = [allele, allele];
                    o.genome = Genome::new(o.kind, loci).unwrap();
                    o.traits = o.genome.traits();
                    sim.rng = SplitMix64::new(seed);
                    sim.act_animal(4, 1);
                }
                different +=
                    usize::from(low.living.contains_key(&2) != high.living.contains_key(&2));
            }
            assert!(different > 0, "id {id} locus {locus}");
        }
    }

    #[test]
    fn hunting_reach_cost_starvation_and_competition() {
        let mut far = hunt_fixture();
        far.move_organism(2, Cell { x: 4, y: 0 }).unwrap();
        let rng = far.rng;
        far.act_animal(4, 1);
        assert_eq!(far.living[&4].position, Cell { x: 0, y: 0 });
        assert_eq!(far.living[&4].energy, 498);
        assert_eq!(far.rng, rng);
        far.move_organism(2, Cell { x: 2, y: 0 }).unwrap();
        far.act_animal(4, 1);
        assert_eq!(far.living[&4].position, Cell { x: 1, y: 0 });
        let mut lethal = hunt_fixture();
        lethal.living.get_mut(&4).unwrap().energy = 7;
        let rng = lethal.rng;
        lethal.act_animal(4, 1);
        assert!(!lethal.living.contains_key(&4));
        assert!(lethal.living.contains_key(&2));
        assert_eq!(lethal.rng, rng);
        assert_eq!(
            lethal
                .death_records
                .iter()
                .find(|r| r.id == 4)
                .unwrap()
                .cause,
            DeathCause::Starvation
        );
        let mut starving = hunt_fixture();
        starving.move_organism(2, Cell { x: 10, y: 10 }).unwrap();
        starving.living.get_mut(&4).unwrap().energy = 4;
        starving.act_animal(4, 1);
        starving.act_animal(4, 2);
        assert!(!starving.living.contains_key(&4));
        // Reusing the action after a kill cannot consume the removed prey again.
        let mut sim = hunt_fixture();
        sim.living.get_mut(&4).unwrap().energy = 599;
        sim.rng = SplitMix64::new(
            (0..1000)
                .find(|seed| {
                    let mut r = SplitMix64::new(*seed);
                    r.next_u64() % 100 < 50
                })
                .unwrap(),
        );
        sim.act_animal(4, 1);
        assert_eq!(sim.living[&4].energy, 1000);
        assert_eq!(sim.deaths.herbivores, 1);
        sim.act_animal(4, 1);
        assert_eq!(sim.deaths.herbivores, 1);
        assert_eq!(sim.living[&4].energy, 998);
    }

    #[test]
    fn satiated_hunter_does_not_attack_or_consume_prey() {
        let mut sim = hunt_fixture();
        sim.living.get_mut(&4).unwrap().energy = 602;
        let rng = sim.rng;
        let prey_energy = sim.living[&2].energy;
        sim.act_animal(4, 1);
        assert_eq!(sim.living[&4].energy, 600);
        assert_eq!(sim.living[&2].energy, prey_energy);
        assert_eq!(sim.deaths.herbivores, 0);
        assert_eq!(sim.rng, rng);
        // Hunger is local to the hunter, independent of population totals.
        sim.living.get_mut(&4).unwrap().energy = 601;
        sim.act_animal(4, 2);
        assert!(sim.living[&4].energy <= 1000);
        assert_ne!(sim.rng, rng);
    }

    #[test]
    fn competing_hunters_observe_immediate_death_and_replay() {
        let mut config = Config::preset("temperate").unwrap();
        config.world.width = 20;
        config.world.height = 20;
        config.initial.plants = 0;
        config.initial.herbivores = 1;
        config.initial.carnivores = 2;
        config.climate.weather_strength = 0.0;
        let mut sim = Simulation::new(&config).unwrap();
        for id in 0..3 {
            sim.move_organism(id, Cell { x: 0, y: 0 }).unwrap();
        }
        sim.living.get_mut(&0).unwrap().energy = 100;
        sim.living.get_mut(&1).unwrap().energy = 500;
        sim.living.get_mut(&2).unwrap().energy = 500;
        let success = (0..1000)
            .find(|seed| {
                let mut r = SplitMix64::new(*seed);
                r.next_u64() % 100 < 50
            })
            .unwrap();
        sim.rng = SplitMix64::new(success);
        let mut replay = sim.clone();
        sim.act_animal(1, 1);
        sim.act_animal(2, 1);
        replay.act_animal(1, 1);
        replay.act_animal(2, 1);
        assert_eq!(sim, replay);
        assert_eq!(sim.deaths.herbivores, 1);
        assert_eq!(sim.living[&1].energy, 593);
        assert_eq!(sim.living[&2].energy, 498);
        let failure = (0..1000)
            .find(|seed| {
                let mut r = SplitMix64::new(*seed);
                r.next_u64() % 100 >= 50
            })
            .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        for id in 0..3 {
            sim.move_organism(id, Cell { x: 0, y: 0 }).unwrap();
        }
        sim.living.get_mut(&1).unwrap().energy = 500;
        sim.living.get_mut(&2).unwrap().energy = 500;
        sim.rng = SplitMix64::new(failure);
        sim.act_animal(1, 1);
        assert!(sim.living.contains_key(&0));
        let before = sim.rng;
        sim.act_animal(2, 1);
        assert_ne!(sim.rng, before);
    }

    #[test]
    fn perception_wraps_and_respects_trait_radius_and_sharing() {
        let mut sim = animal_fixture(20, 20);
        for (id, cell) in [
            (0, (19, 19)),
            (1, (3, 0)),
            (2, (0, 0)),
            (3, (0, 19)),
            (4, (19, 0)),
        ] {
            sim.move_organism(
                id,
                Cell {
                    x: cell.0,
                    y: cell.1,
                },
            )
            .unwrap();
        }
        assert_eq!(sim.perceive(2).unwrap(), vec![0, 3, 4]);
        speed(&mut sim, 2, 2);
        assert_eq!(sim.perceive(2).unwrap(), vec![0, 1, 3, 4]);
        assert!(sim.perceive(0).is_err());
        assert!(sim.perceive(99).is_err());
        let tiny = animal_fixture(1, 1);
        assert_eq!(tiny.perceive(2).unwrap(), vec![0, 1, 3, 4]);
        let thin = animal_fixture(1, 20);
        assert_eq!(thin.perceive(2).unwrap(), vec![0, 1, 3, 4]);
    }

    #[test]
    fn movement_targets_wraps_costs_and_updates_index() {
        let mut sim = animal_fixture(20, 20);
        for (id, cell) in [
            (0, (17, 17)),
            (1, (10, 10)),
            (2, (0, 0)),
            (3, (10, 0)),
            (4, (9, 0)),
        ] {
            sim.move_organism(
                id,
                Cell {
                    x: cell.0,
                    y: cell.1,
                },
            )
            .unwrap();
        }
        speed(&mut sim, 2, 2);
        sim.advance_one_tick().unwrap();
        assert_eq!(sim.living[&2].position, Cell { x: 18, y: 18 });
        assert_eq!(sim.living[&2].energy, 510);
        assert!(!sim.query(Cell { x: 0, y: 0 }, 0, None).contains(&2));
        assert!(sim.query(Cell { x: 18, y: 18 }, 0, None).contains(&2));
        assert_eq!(sim.living[&4].position, Cell { x: 9, y: 0 });
        assert_eq!(sim.living[&4].energy, 989);
        assert!(!sim.living.contains_key(&3));
    }

    #[test]
    fn speed_distance_cost_and_antipodal_direction() {
        let mut base = animal_fixture(8, 1);
        for (id, x) in [(0, 4), (1, 4), (2, 0), (3, 4), (4, 4)] {
            base.move_organism(id, Cell { x, y: 0 }).unwrap();
        }
        let mut slow = base.clone();
        let mut fast = base.clone();
        speed(&mut slow, 2, 1);
        speed(&mut fast, 2, 3);
        // Place target inside both vision ranges for the speed comparison.
        slow.move_organism(0, Cell { x: 2, y: 0 }).unwrap();
        fast.move_organism(0, Cell { x: 2, y: 0 }).unwrap();
        slow.advance_one_tick().unwrap();
        fast.advance_one_tick().unwrap();
        assert_eq!(
            (slow.living[&2].position.x, slow.living[&2].energy),
            (1, 516)
        );
        assert_eq!(
            (fast.living[&2].position.x, fast.living[&2].energy),
            (1, 514)
        );
        let mut near = base.clone();
        speed(&mut near, 2, 3);
        near.move_organism(0, Cell { x: 1, y: 0 }).unwrap();
        near.advance_one_tick().unwrap();
        assert_eq!(near.living[&2].energy, 518);
        speed(&mut base, 2, 3);
        base.advance_one_tick().unwrap();
        assert_eq!(base.living[&2].position.x, 3); // positive antipodal tie
    }

    #[test]
    fn movement_ties_stationary_death_and_replay() {
        let mut sim = animal_fixture(12, 12);
        for (id, cell) in [
            (0, (11, 0)),
            (1, (1, 0)),
            (2, (0, 0)),
            (3, (6, 6)),
            (4, (6, 6)),
        ] {
            sim.move_organism(
                id,
                Cell {
                    x: cell.0,
                    y: cell.1,
                },
            )
            .unwrap();
        }
        sim.move_organism(4, Cell { x: 3, y: 6 }).unwrap();
        let mut replay = sim.clone();
        sim.advance_one_tick().unwrap();
        replay.advance_one_tick().unwrap();
        assert_eq!(sim, replay);
        assert_eq!(sim.living[&2].position, Cell { x: 0, y: 0 });
        assert_eq!(sim.living[&2].energy, 516);
        assert_eq!(sim.living[&4].energy, 498);
        let mut lethal = animal_fixture(12, 12);
        lethal.move_organism(0, Cell { x: 11, y: 11 }).unwrap();
        lethal.move_organism(2, Cell { x: 0, y: 0 }).unwrap();
        lethal.living.get_mut(&2).unwrap().energy = 2;
        lethal.advance_one_tick().unwrap();
        assert!(!lethal.living.contains_key(&2));
        assert!(!lethal.query(Cell { x: 11, y: 11 }, 0, None).contains(&2));
        assert_eq!(
            lethal
                .death_records
                .iter()
                .find(|r| r.id == 2)
                .unwrap()
                .cause,
            DeathCause::Starvation
        );
        let mut stationary = animal_fixture(12, 12);
        stationary.move_organism(4, Cell { x: 6, y: 6 }).unwrap();
        speed(&mut stationary, 2, 0);
        let before = stationary.living[&2].position;
        stationary.advance_one_tick().unwrap();
        assert_eq!(stationary.living[&2].position, before);
        assert_eq!(stationary.living[&2].energy, 518);
    }

    #[test]
    fn grazing_reach_conservation_capacity_and_death() {
        let mut sim = animal_fixture(20, 20);
        for (id, cell) in [
            (0, (19, 19)),
            (1, (10, 10)),
            (2, (0, 0)),
            (3, (10, 0)),
            (4, (10, 1)),
        ] {
            sim.move_organism(
                id,
                Cell {
                    x: cell.0,
                    y: cell.1,
                },
            )
            .unwrap();
        }
        let cost = 2
            + (((sim.climate_at(Cell { x: 0, y: 0 }).temperature - 20.0).abs() - 10.0).max(0.0)
                / 10.0)
                .floor() as u16;
        sim.act_animal(2, 1);
        assert_eq!(sim.living[&0].energy, 480);
        assert_eq!(sim.living[&2].energy, 500 - cost + 20);
        sim.living.get_mut(&2).unwrap().energy = 1000;
        let before = sim.living[&0].energy;
        sim.act_animal(2, 1);
        assert_eq!(before - sim.living[&0].energy, cost);
        sim.living.get_mut(&0).unwrap().energy = 5;
        sim.living.get_mut(&2).unwrap().energy = 500;
        sim.act_animal(2, 1);
        assert!(!sim.living.contains_key(&0));
        assert_eq!(sim.deaths.plants, 1);
        assert_eq!(sim.death_records.last().unwrap().cause, DeathCause::Grazing);
        assert!(!sim.query(Cell { x: 19, y: 19 }, 0, None).contains(&0));
        let mut far = animal_fixture(20, 20);
        far.move_organism(0, Cell { x: 4, y: 0 }).unwrap();
        far.move_organism(1, Cell { x: 10, y: 10 }).unwrap();
        far.move_organism(2, Cell { x: 0, y: 0 }).unwrap();
        far.act_animal(2, 1);
        assert_eq!(far.living[&0].energy, 500); // outside vision
        assert_eq!(far.living[&2].position.x, 0);
    }

    #[test]
    fn aggression_climate_and_snapshot_death() {
        let mut cautious = animal_fixture(20, 20);
        for (id, x) in [(0, 1), (1, 10), (2, 0), (3, 10), (4, 2)] {
            cautious.move_organism(id, Cell { x, y: 0 }).unwrap();
        }
        let mut bold = cautious.clone();
        let o = cautious.living.get_mut(&2).unwrap();
        let mut loci = o.genome.alleles().to_vec();
        loci[5] = [0, 0];
        o.genome = Genome::new(Kind::Herbivore, loci).unwrap();
        o.traits = o.genome.traits();
        cautious.act_animal(2, 1);
        bold.act_animal(2, 1);
        assert_eq!(cautious.living[&0].energy, 500);
        assert_eq!(bold.living[&0].energy, 480);
        let mut cold = animal_fixture(20, 20);
        let mut mild = cold.clone();
        cold.weather.0 = -80.0;
        mild.weather.0 = 30.0;
        cold.act_animal(3, 1);
        mild.act_animal(3, 1);
        assert!(cold.living[&3].energy < mild.living[&3].energy);
        let mut sim = animal_fixture(1, 1);
        // Higher-ID plant is killed before its snapshot turn.
        sim.living.get_mut(&0).unwrap().energy = 800;
        sim.advance_with_events(&[Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(0), None],
        }])
        .unwrap();
        let plant = sim.next_id - 1;
        sim.living.get_mut(&0).unwrap().energy = 1;
        sim.living.get_mut(&1).unwrap().energy = 1;
        sim.living.get_mut(&plant).unwrap().energy = 5;
        sim.living.get_mut(&2).unwrap().energy = 500;
        sim.advance_one_tick().unwrap();
        assert!(!sim.living.contains_key(&plant));
        assert_eq!(
            sim.death_records.iter().filter(|r| r.id == plant).count(),
            1
        );
    }

    #[test]
    fn stage_order_and_overflow_are_atomic() {
        let config = Config::preset("temperate").unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        let mut stages = Vec::new();
        sim.advance_with(|s| stages.push(s)).unwrap();
        assert_eq!(
            stages,
            [
                Stage::UpdateWorld,
                Stage::SnapshotLivingIds,
                Stage::Act,
                Stage::CommitDeferred
            ]
        );
        assert_eq!(sim.tick(), 1);
        sim.tick = u64::MAX;
        let before = sim.clone();
        stages.clear();
        assert_eq!(sim.advance_with(|s| stages.push(s)), Err(TickOverflow));
        assert!(stages.is_empty());
        assert_eq!(sim, before);
    }
    #[test]
    fn age_death_uses_derived_lifespan() {
        let mut sim = Simulation::new(&Config::preset("temperate").unwrap()).unwrap();
        let o = sim.living.get_mut(&0).unwrap();
        o.genome = Genome::new(Kind::Plant, vec![[0, 0]; 5]).unwrap();
        o.traits = o.genome.traits();
        sim.advance_one_tick().unwrap();
        assert!(!sim.living.contains_key(&0));
        assert!(!sim.query(Cell { x: 0, y: 0 }, u64::MAX, None).contains(&0));
        assert_eq!(
            sim.death_records.iter().find(|r| r.id == 0).unwrap().cause,
            DeathCause::Age
        );
    }
    fn plant_fixture(count: u64) -> Simulation {
        let mut config = Config::preset("temperate").unwrap();
        config.world.width = 1;
        config.world.height = 1;
        config.initial.plants = count;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.climate.weather_strength = 0.0;
        config.climate.seasonal_strength = 0.0;
        let mut sim = Simulation::new(&config).unwrap();
        for o in sim.living.values_mut() {
            o.energy = 500;
        }
        sim
    }

    #[test]
    fn climate_and_genome_control_growth() {
        let mut favorable = plant_fixture(1);
        let mut cold = favorable.clone();
        let mut dry = favorable.clone();
        cold.weather.0 = -80.0;
        dry.weather.1 = -3000.0;
        for sim in [&mut favorable, &mut cold, &mut dry] {
            sim.advance_one_tick().unwrap();
        }
        assert!(favorable.living[&0].energy > cold.living[&0].energy);
        assert!(favorable.living[&0].energy > dry.living[&0].energy);
        assert_eq!(cold.living[&0].energy, 498);
        assert_eq!(dry.living[&0].energy, 498);
        let mut weak = plant_fixture(1);
        let mut strong = weak.clone();
        for (sim, allele) in [(&mut weak, 0), (&mut strong, 1000)] {
            let o = sim.living.get_mut(&0).unwrap();
            let mut loci = vec![[500, 500]; 5];
            loci[1] = [allele, allele];
            o.genome = Genome::new(Kind::Plant, loci).unwrap();
            o.traits = o.genome.traits();
            sim.advance_one_tick().unwrap();
        }
        assert!(strong.living[&0].energy > weak.living[&0].energy);
    }

    #[test]
    fn shared_reserves_regenerate_and_conserve_energy() {
        let mut sim = plant_fixture(20);
        let cell = Cell { x: 0, y: 0 };
        sim.advance_one_tick().unwrap();
        let gained: u16 = sim.living.values().map(|o| o.energy - 498).sum();
        assert_eq!(gained + sim.resources.at(cell), 100);
        assert_eq!(sim.resources.at(cell), 0);
        assert!(sim.living[&0].energy > sim.living[&19].energy);
        sim.advance_one_tick().unwrap();
        assert_eq!(sim.resources.at(cell), 0);
        assert_eq!(sim.resources.at(Cell { x: 2, y: 3 }), 0);
        let mut resources = Resources::new(*sim.world()).unwrap();
        assert_eq!(resources.withdraw(cell, 99), 99);
        resources.regenerate();
        assert_eq!(resources.at(cell), 3);
        for _ in 0..100 {
            resources.regenerate();
        }
        assert_eq!(resources.at(cell), 100);
    }

    #[test]
    fn hostile_starvation_deferred_birth_and_rollback() {
        let mut sim = plant_fixture(1);
        sim.weather.0 = -80.0;
        sim.living.get_mut(&0).unwrap().energy = 800;
        let event = Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(0), None],
        };
        sim.advance_with_events(&[
            event,
            Event::Adjust {
                id: 0,
                energy: -396,
                health: 0,
            },
        ])
        .unwrap();
        assert_eq!(sim.living[&1].age, 0);
        assert_eq!(sim.living[&1].energy, 400);
        let before = sim.clone();
        let bad = Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(99), None],
        };
        assert!(sim.advance_with_events(&[bad]).is_err());
        assert_eq!(sim, before);
        sim.advance_one_tick().unwrap();
        assert!(!sim.living.contains_key(&0));
        assert_eq!(sim.deaths.plants, 1);
        assert_eq!(
            sim.death_records.last().unwrap().cause,
            DeathCause::Starvation
        );
        assert!(!sim.query(Cell { x: 0, y: 0 }, 0, None).contains(&0));
        let mut replay = sim.clone();
        for _ in 0..10 {
            sim.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
        }
        assert_eq!(sim, replay);
    }

    fn reproduction_fixture(width: u64, plants: u64) -> Simulation {
        let mut config = Config::preset("temperate").unwrap();
        config.world.width = width;
        config.world.height = 1;
        config.initial.plants = plants;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.climate.weather_strength = 0.0;
        config.climate.seasonal_strength = 0.0;
        config.genetics.mutation_rate = 0.0;
        let mut sim = Simulation::new(&config).unwrap();
        sim.weather.0 = -80.0;
        sim
    }

    #[test]
    fn reproduction_threshold_conservation_wrapping_and_inheritance() {
        let mut sim = reproduction_fixture(8, 1);
        sim.living.get_mut(&0).unwrap().energy = 801;
        let rng = *sim.rng();
        sim.advance_one_tick().unwrap();
        assert_eq!(sim.births.plants, 0);
        assert_eq!(*sim.rng(), rng);
        sim.living.get_mut(&0).unwrap().energy = 802;
        sim.advance_one_tick().unwrap();
        let child = &sim.living[&1];
        assert_eq!(child.position, Cell { x: 6, y: 0 });
        assert_eq!(
            sim.world.distance(sim.living[&0].position, child.position),
            2
        );
        assert_eq!(sim.living[&0].energy + child.energy, 800);
        assert_eq!(
            (child.energy, child.age, child.generation, child.parents),
            (400, 0, 1, [Some(0), None])
        );
        assert_eq!(child.genome, sim.living[&0].genome);
        assert_eq!(sim.query(child.position, 0, Some(Kind::Plant)), vec![1]);
    }

    #[test]
    fn reproduction_reservations_resources_and_events() {
        let mut sim = reproduction_fixture(3, 2);
        sim.advance_one_tick().unwrap();
        assert_eq!(sim.births.plants, 1);
        assert_eq!(sim.living[&2].position, Cell { x: 2, y: 0 });
        assert_eq!(sim.living[&2].parents, [Some(0), None]);
        assert_eq!(sim.living[&1].energy, 998);
        let mut blocked = reproduction_fixture(2, 1);
        blocked.resources.withdraw(Cell { x: 1, y: 0 }, 100);
        let rng = *blocked.rng();
        blocked.advance_one_tick().unwrap();
        assert_eq!(blocked.births.plants, 0);
        assert_eq!(blocked.living[&0].energy, 998);
        assert_eq!(*blocked.rng(), rng);
        let mut event_sim = reproduction_fixture(2, 1);
        let event = Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 1, y: 0 },
            parents: [Some(0), None],
        };
        event_sim.advance_with_events(&[event]).unwrap();
        assert_eq!(event_sim.births.plants, 1);
        assert_eq!(event_sim.living[&1].energy, 400);
        assert_eq!(event_sim.living[&0].energy, 598);
    }

    #[test]
    fn mutation_replay_extinction_and_capacity() {
        let mut sim = reproduction_fixture(8, 1);
        sim.genetics.mutation_rate = 1.0;
        sim.genetics.mutation_strength = 1.0;
        let mut replay = sim.clone();
        sim.advance_one_tick().unwrap();
        replay.advance_one_tick().unwrap();
        assert_eq!(sim, replay);
        assert_ne!(sim.living[&0].genome, sim.living[&1].genome);
        let mut empty = reproduction_fixture(8, 0);
        for _ in 0..100 {
            empty.advance_one_tick().unwrap();
        }
        assert_eq!(empty.births.plants, 0);
        assert!(empty.living.is_empty());
        let mut full = reproduction_fixture(8, 1);
        full.next_id = u64::MAX;
        let rng = *full.rng();
        full.advance_one_tick().unwrap();
        assert_eq!(full.births.plants, 0);
        assert_eq!(full.living[&0].energy, 998);
        assert_eq!(*full.rng(), rng);
    }

    #[test]
    fn lifecycle_exhaustion_is_atomic() {
        let config = Config::preset("temperate").unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        let event = Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(0), None],
        };
        sim.next_id = u64::MAX;
        let before = sim.clone();
        assert!(sim.advance_with_events(&[event.clone()]).is_err());
        assert_eq!(sim, before);
        sim.next_id = 1000;
        sim.births.plants = u64::MAX;
        let before = sim.clone();
        assert!(sim.advance_with_events(&[event]).is_err());
        assert_eq!(sim, before);
        sim.deaths.plants = u64::MAX;
        let before = sim.clone();
        assert!(sim
            .advance_with_events(&[Event::Death {
                id: 0,
                cause: DeathCause::External
            }])
            .is_err());
        assert_eq!(sim, before);
    }
}

#[cfg(test)]
mod species_lifecycle_tests {
    use super::*;
    #[test]
    fn membership_parent_death_revival_and_rollback() {
        let mut c = Config::preset("temperate").unwrap();
        c.world.width = 1;
        c.world.height = 1;
        c.initial.plants = 1;
        c.initial.herbivores = 0;
        c.initial.carnivores = 0;
        c.genetics.mutation_rate = 0.0;
        let mut s = Simulation::new(&c).unwrap();
        assert_eq!(s.species().living_count(Kind::Plant), 1);
        assert_eq!(s.species().living_count(Kind::Herbivore), 0);
        let birth = Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(0), None],
        };
        let death = Event::Death {
            id: 0,
            cause: DeathCause::External,
        };
        s.advance_with_events(&[birth.clone(), death.clone(), death])
            .unwrap();
        assert_eq!(s.living[&1].species_id(), 0);
        assert_eq!(s.species().records()[0].living, 1);
        assert_eq!(s.species().records()[0].extinct_tick, None);
        let before = s.clone();
        assert!(s.advance_with_events(&[birth]).is_err());
        assert_eq!(s, before);
        s.advance_with_events(&[Event::Death {
            id: 1,
            cause: DeathCause::External,
        }])
        .unwrap();
        assert_eq!(s.species().records()[0].extinct_tick, Some(2));
    }
    #[test]
    fn mutated_offspring_creates_descendant_species() {
        let mut c = Config::preset("temperate").unwrap();
        c.world.width = 1;
        c.world.height = 1;
        c.initial.plants = 1;
        c.initial.herbivores = 0;
        c.initial.carnivores = 0;
        c.genetics.mutation_rate = 1.0;
        c.genetics.mutation_strength = 1.0;
        let mut s = Simulation::new(&c).unwrap();
        s.advance_with_events(&[Event::Birth {
            kind: Kind::Plant,
            position: Cell { x: 0, y: 0 },
            parents: [Some(0), None],
        }])
        .unwrap();
        let child = &s.living[&1];
        assert_ne!(child.species_id(), 0);
        let record = &s.species.records()[child.species_id() as usize];
        assert_eq!((record.parent, record.arose_tick), (Some(0), 1));
    }
    #[test]
    fn seeded_runs_have_equal_species_and_membership() {
        let c = Config::preset("temperate").unwrap();
        let mut a = Simulation::new(&c).unwrap();
        let mut b = Simulation::new(&c).unwrap();
        for _ in 0..30 {
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
        }
        assert_eq!(a.species, b.species);
        assert_eq!(a.living, b.living);
        for o in a.living.values() {
            assert_eq!(a.species.records()[o.species_id as usize].kind, o.kind);
        }
        for record in a.species.records() {
            assert_eq!(
                record.living as usize,
                a.living
                    .values()
                    .filter(|o| o.species_id == record.id)
                    .count()
            );
        }
    }
}

impl Simulation {
    /// SHA-256 of the versioned deterministic binary representation of the full state.
    pub fn state_hash(&self) -> String {
        use sha2::{Digest, Sha256};
        let mut digest = Sha256::new();
        digest.update(b"evosim-state-v1\0");
        // The state consists solely of infallibly serializable in-memory values.
        digest.update(bincode::serialize(self).expect("state serialization"));
        format!("{:x}", digest.finalize())
    }
}

#[cfg(test)]
mod hash_tests {
    use super::*;
    #[test]
    fn hash_covers_independent_state() {
        let c = Config::from_json(r#"{"seed":1,"world":{"width":3,"height":3},"initial":{"plants":1,"herbivores":1,"carnivores":0}}"#).unwrap();
        let a = Simulation::new(&c).unwrap();
        let hash = a.state_hash();
        assert_eq!(hash, a.clone().state_hash());
        let mut b = a.clone();
        b.rng.next_u64();
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.weather.0 = 1.0;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.climate_settings.year_ticks += 1;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.next_id += 1;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.births.plants += 1;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.living.get_mut(&0).unwrap().energy -= 1;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.living.get_mut(&1).unwrap().next_mating_tick += 1;
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.living.get_mut(&0).unwrap().parents[0] = Some(1);
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.resources.withdraw(Cell { x: 0, y: 0 }, 1);
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.species.remove(0, 1);
        assert_ne!(hash, b.state_hash());
        let mut b = a.clone();
        b.advance_one_tick().unwrap();
        assert_ne!(hash, b.state_hash());
    }
}

#[cfg(test)]
mod checkpoint_validation_tests {
    use super::*;
    #[test]
    fn rejects_checksummed_inconsistent_state() {
        let config = Config::from_json(r#"{"seed":1,"world":{"width":4,"height":4},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.next_id = 0;
        let bytes = crate::checkpoint::encode(1, &sim).unwrap();
        assert!(crate::checkpoint::decode(&bytes).is_err());
    }
}

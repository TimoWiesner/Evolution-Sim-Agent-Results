//! Dense toroidal cell buckets. Queries return IDs in ascending order.
use crate::geometry::{Cell, Grid};
use crate::organism::Kind;
use std::collections::BTreeMap;

#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct SpatialIndex {
    grid: Grid,
    buckets: Vec<Vec<u64>>,
    entries: BTreeMap<u64, (Cell, Kind)>,
}
impl SpatialIndex {
    pub(crate) fn valid_for(
        &self,
        grid: Grid,
        living: &BTreeMap<u64, crate::organism::Organism>,
    ) -> bool {
        if self.grid != grid
            || grid
                .width()
                .checked_mul(grid.height())
                .and_then(|n| usize::try_from(n).ok())
                != Some(self.buckets.len())
            || self.entries.len() != living.len()
        {
            return false;
        }
        let mut seen = std::collections::BTreeSet::new();
        for (i, bucket) in self.buckets.iter().enumerate() {
            for id in bucket {
                let Some(o) = living.get(id) else {
                    return false;
                };
                if !seen.insert(*id)
                    || self.entries.get(id) != Some(&(o.position, o.kind))
                    || (o.position.y * grid.width() + o.position.x) as usize != i
                {
                    return false;
                }
            }
        }
        seen.len() == living.len()
    }
    /// Allocation is proportional to world area; fails if the bucket array cannot be allocated.
    pub fn new(grid: Grid) -> Result<Self, &'static str> {
        let size = grid
            .width()
            .checked_mul(grid.height())
            .and_then(|n| usize::try_from(n).ok())
            .ok_or("grid too large")?;
        let mut buckets = Vec::new();
        buckets
            .try_reserve_exact(size)
            .map_err(|_| "grid allocation failed")?;
        buckets.resize_with(size, Vec::new);
        Ok(Self {
            grid,
            buckets,
            entries: BTreeMap::new(),
        })
    }
    fn normalize(&self, c: Cell) -> Cell {
        self.grid.cell(c.x as i128, c.y as i128)
    }
    fn offset(&self, c: Cell) -> usize {
        (c.y * self.grid.width() + c.x) as usize
    }
    /// Duplicate IDs are rejected; coordinates are wrapped.
    pub fn insert(&mut self, id: u64, cell: Cell, kind: Kind) -> Result<(), &'static str> {
        if self.entries.contains_key(&id) {
            return Err("duplicate ID");
        }
        let cell = self.normalize(cell);
        let i = self.offset(cell);
        self.buckets[i].push(id);
        self.entries.insert(id, (cell, kind));
        Ok(())
    }
    /// Missing IDs are rejected. Same-cell moves do nothing.
    pub fn move_to(&mut self, id: u64, cell: Cell) -> Result<(), &'static str> {
        let (old, kind) = *self.entries.get(&id).ok_or("unknown ID")?;
        let cell = self.normalize(cell);
        if old != cell {
            let old_i = self.offset(old);
            let pos = self.buckets[old_i]
                .iter()
                .position(|&v| v == id)
                .expect("index invariant");
            self.buckets[old_i].swap_remove(pos);
            let new_i = self.offset(cell);
            self.buckets[new_i].push(id);
            self.entries.insert(id, (cell, kind));
        }
        Ok(())
    }
    pub fn remove(&mut self, id: u64) -> Result<(), &'static str> {
        let (cell, _) = self.entries.remove(&id).ok_or("unknown ID")?;
        let i = self.offset(cell);
        let pos = self.buckets[i]
            .iter()
            .position(|&v| v == id)
            .expect("index invariant");
        self.buckets[i].swap_remove(pos);
        Ok(())
    }
    /// Whether a canonical cell contains an organism of this kind.
    pub(crate) fn contains_kind(&self, cell: Cell, kind: Kind) -> bool {
        self.buckets[self.offset(cell)]
            .iter()
            .any(|id| self.entries[id].1 == kind)
    }
    /// Chebyshev radius, optional kind filter; output is sorted by stable ID.
    pub fn query(&self, center: Cell, radius: u64, kind: Option<Kind>) -> Vec<u64> {
        let mut result = Vec::new();
        for cell in self.grid.cells_within(center, radius) {
            for &id in &self.buckets[self.offset(cell)] {
                if kind.is_none_or(|k| self.entries[&id].1 == k) {
                    result.push(id);
                }
            }
        }
        result.sort_unstable();
        result
    }
}

#[cfg(test)]
mod contains_tests {
    use super::*;
    #[test]
    fn cell_presence_matches_sorted_query() {
        let grid = Grid::new(3, 2).unwrap();
        let mut index = SpatialIndex::new(grid).unwrap();
        for id in 0..30 {
            index
                .insert(
                    id,
                    Cell {
                        x: id % 3,
                        y: (id / 3) % 2,
                    },
                    if id % 2 == 0 {
                        Kind::Plant
                    } else {
                        Kind::Herbivore
                    },
                )
                .unwrap();
        }
        for y in 0..2 {
            for x in 0..3 {
                for kind in [Kind::Plant, Kind::Herbivore, Kind::Carnivore] {
                    let cell = Cell { x, y };
                    assert_eq!(
                        index.contains_kind(cell, kind),
                        !index.query(cell, 0, Some(kind)).is_empty()
                    );
                }
            }
        }
    }
}

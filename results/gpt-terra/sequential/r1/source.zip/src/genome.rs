//! Fixed bounded loci and deterministic inheritance.
use crate::{
    config::Genetics,
    organism::{Kind, Traits},
    rng::SplitMix64,
};

pub const LOCI: usize = 6;
pub const MAX_ALLELE: u16 = 1000;
#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct Genome {
    kind: Kind,
    alleles: Vec<[u16; 2]>,
}
impl Genome {
    /// Plants use five haploid loci (the second entry must equal the first);
    /// animals use six diploid loci. Order: speed, strength, fertility, lifespan, health, aggression.
    pub fn new(kind: Kind, alleles: Vec<[u16; 2]>) -> Result<Self, &'static str> {
        if alleles.len() != if kind == Kind::Plant { 5 } else { 6 }
            || alleles
                .iter()
                .any(|a| a.iter().any(|v| *v > MAX_ALLELE) || (kind == Kind::Plant && a[0] != a[1]))
        {
            return Err("invalid genome");
        }
        Ok(Self { kind, alleles })
    }
    pub fn founder(kind: Kind) -> Self {
        let values = [100, 500, 500, 1, 100, 500];
        Self::new(
            kind,
            values[..if kind == Kind::Plant { 5 } else { 6 }]
                .iter()
                .map(|&v| [v, v])
                .collect(),
        )
        .unwrap()
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    pub fn alleles(&self) -> &[[u16; 2]] {
        &self.alleles
    }
    fn representative(a: [u16; 2]) -> u32 {
        (u32::from(a[0]) + u32::from(a[1])) / 2
    }
    pub fn traits(&self) -> Traits {
        let v: Vec<u32> = self
            .alleles
            .iter()
            .map(|&a| Self::representative(a))
            .collect();
        let map = |i: usize, min: u32, max: u32| min + v[i] * (max - min) / 1000;
        Traits::new(
            self.kind,
            map(0, 0, 10) as u8,
            map(1, 0, 100) as u8,
            map(2, 0, 100) as u8,
            map(3, 1, 1_000_000),
            map(4, 1, 1000) as u16,
            if self.kind == Kind::Plant {
                None
            } else {
                Some(map(5, 0, 100) as u8)
            },
        )
        .unwrap()
    }
    pub fn distance(&self, other: &Self) -> Result<f64, &'static str> {
        Ok(f64::from(self.distance_sum(other)?) / (self.alleles.len() as f64 * 1000.0))
    }
    pub(crate) fn distance_sum(&self, other: &Self) -> Result<u32, &'static str> {
        if self.kind != other.kind {
            return Err("genome kind mismatch");
        }
        let sum: u32 = self
            .alleles
            .iter()
            .zip(&other.alleles)
            .map(|(&a, &b)| Self::representative(a).abs_diff(Self::representative(b)))
            .sum();
        Ok(sum)
    }
    /// One parent copies its genome; two parents contribute one animal allele each.
    /// Two-parent plant crossover is rejected; plant reproduction is asexual here.
    pub fn inherit(
        first: &Self,
        second: Option<&Self>,
        settings: &Genetics,
        rng: &mut SplitMix64,
    ) -> Result<Self, &'static str> {
        if !settings.mutation_rate.is_finite()
            || !(0.0..=1.0).contains(&settings.mutation_rate)
            || !settings.mutation_strength.is_finite()
            || !(0.0..=1.0).contains(&settings.mutation_strength)
        {
            return Err("invalid mutation settings");
        }
        if let Some(p) = second {
            if p.kind != first.kind || first.kind == Kind::Plant {
                return Err("incompatible parents");
            }
        }
        let mut child = first.clone();
        if let Some(p) = second {
            for (i, a) in child.alleles.iter_mut().enumerate() {
                *a = [
                    first.alleles[i][bounded(rng, 2) as usize],
                    p.alleles[i][bounded(rng, 2) as usize],
                ];
            }
        }
        let max_step = (settings.mutation_strength * 1000.0).ceil() as i32;
        for a in &mut child.alleles {
            let n = if first.kind == Kind::Plant { 1 } else { 2 };
            for allele in a.iter_mut().take(n) {
                // Always consume a probability draw, even at rate zero or one.
                let draw = (rng.next_u64() >> 11) as f64 / ((1u64 << 53) as f64);
                if draw < settings.mutation_rate && max_step > 0 {
                    let step = bounded(rng, (2 * max_step + 1) as u64) as i32 - max_step;
                    *allele = (i32::from(*allele) + step).clamp(0, 1000) as u16;
                }
            }
            if n == 1 {
                a[1] = a[0];
            }
        }
        Ok(child)
    }
}
fn bounded(rng: &mut SplitMix64, bound: u64) -> u64 {
    let threshold = bound.wrapping_neg() % bound;
    loop {
        let x = rng.next_u64();
        if x >= threshold {
            return x % bound;
        }
    }
}

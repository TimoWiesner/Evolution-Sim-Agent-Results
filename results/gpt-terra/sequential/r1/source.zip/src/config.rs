//! Typed configuration shared by future engine and adapters.
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};
use std::fmt;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Config {
    pub seed: i64,
    pub world: World,
    pub initial: Initial,
    pub climate: Climate,
    pub genetics: Genetics,
    pub resources: Resources,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct World {
    pub width: u64,
    pub height: u64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Initial {
    pub plants: u64,
    pub herbivores: u64,
    pub carnivores: u64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Climate {
    pub year_ticks: u64,
    pub seasonal_strength: f64,
    pub weather_strength: f64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Genetics {
    pub mutation_rate: f64,
    pub mutation_strength: f64,
}
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Resources {
    pub regrowth_rate: f64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfigError(pub String);
impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}
impl std::error::Error for ConfigError {}
fn error(key: &str, message: &str) -> ConfigError {
    ConfigError(format!("{key}: {message}"))
}
fn object<'a>(
    v: &'a Value,
    path: &str,
    allowed: &[&str],
) -> Result<&'a Map<String, Value>, ConfigError> {
    let obj = v
        .as_object()
        .ok_or_else(|| error(path, "expected object"))?;
    for key in obj.keys() {
        if !allowed.contains(&key.as_str()) {
            return Err(error(
                &if path == "$" {
                    key.clone()
                } else {
                    format!("{path}.{key}")
                },
                "unknown key",
            ));
        }
    }
    Ok(obj)
}
fn required<'a>(
    obj: &'a Map<String, Value>,
    key: &str,
    path: &str,
) -> Result<&'a Value, ConfigError> {
    obj.get(key)
        .ok_or_else(|| error(path, "missing required key"))
}
fn uint(v: &Value, path: &str) -> Result<u64, ConfigError> {
    v.as_u64()
        .ok_or_else(|| error(path, "expected unsigned 64-bit integer"))
}
fn optional_uint(
    obj: &Map<String, Value>,
    key: &str,
    path: &str,
    default: u64,
) -> Result<u64, ConfigError> {
    obj.get(key).map_or(Ok(default), |v| uint(v, path))
}
fn optional_float(
    obj: &Map<String, Value>,
    key: &str,
    path: &str,
    default: f64,
) -> Result<f64, ConfigError> {
    obj.get(key).map_or(Ok(default), |v| {
        v.as_f64().ok_or_else(|| error(path, "expected number"))
    })
}
fn optional_object<'a>(
    root: &'a Map<String, Value>,
    key: &str,
    allowed: &[&str],
) -> Result<Option<&'a Map<String, Value>>, ConfigError> {
    root.get(key).map(|v| object(v, key, allowed)).transpose()
}

impl Config {
    pub fn from_json(input: &str) -> Result<Self, ConfigError> {
        let value: Value =
            serde_json::from_str(input).map_err(|e| error("$", &format!("invalid JSON: {e}")))?;
        let root = object(
            &value,
            "$",
            &[
                "seed",
                "world",
                "initial",
                "climate",
                "genetics",
                "resources",
            ],
        )?;
        let seed = required(root, "seed", "seed")?
            .as_i64()
            .ok_or_else(|| error("seed", "expected signed 64-bit integer"))?;
        let world = object(
            required(root, "world", "world")?,
            "world",
            &["width", "height"],
        )?;
        let initial = object(
            required(root, "initial", "initial")?,
            "initial",
            &["plants", "herbivores", "carnivores"],
        )?;
        let climate = optional_object(
            root,
            "climate",
            &["year_ticks", "seasonal_strength", "weather_strength"],
        )?;
        let genetics = optional_object(root, "genetics", &["mutation_rate", "mutation_strength"])?;
        let resources = optional_object(root, "resources", &["regrowth_rate"])?;
        let empty = Map::new();
        let c = climate.unwrap_or(&empty);
        let g = genetics.unwrap_or(&empty);
        let r = resources.unwrap_or(&empty);
        let result = Self {
            seed,
            world: World {
                width: uint(required(world, "width", "world.width")?, "world.width")?,
                height: uint(required(world, "height", "world.height")?, "world.height")?,
            },
            initial: Initial {
                plants: uint(
                    required(initial, "plants", "initial.plants")?,
                    "initial.plants",
                )?,
                herbivores: uint(
                    required(initial, "herbivores", "initial.herbivores")?,
                    "initial.herbivores",
                )?,
                carnivores: uint(
                    required(initial, "carnivores", "initial.carnivores")?,
                    "initial.carnivores",
                )?,
            },
            climate: Climate {
                year_ticks: optional_uint(c, "year_ticks", "climate.year_ticks", 360)?,
                seasonal_strength: optional_float(
                    c,
                    "seasonal_strength",
                    "climate.seasonal_strength",
                    0.25,
                )?,
                weather_strength: optional_float(
                    c,
                    "weather_strength",
                    "climate.weather_strength",
                    1.0,
                )?,
            },
            genetics: Genetics {
                mutation_rate: optional_float(g, "mutation_rate", "genetics.mutation_rate", 0.02)?,
                mutation_strength: optional_float(
                    g,
                    "mutation_strength",
                    "genetics.mutation_strength",
                    0.05,
                )?,
            },
            resources: Resources {
                regrowth_rate: optional_float(r, "regrowth_rate", "resources.regrowth_rate", 0.05)?,
            },
        };
        result.validate()?;
        Ok(result)
    }
    pub fn validate(&self) -> Result<(), ConfigError> {
        if self.world.width == 0 {
            return Err(error("world.width", "must be at least 1"));
        }
        if self.world.height == 0 {
            return Err(error("world.height", "must be at least 1"));
        }
        if !(1..=1_000_000).contains(&self.climate.year_ticks) {
            return Err(error("climate.year_ticks", "must be between 1 and 1000000"));
        }
        for (key, value) in [
            ("climate.seasonal_strength", self.climate.seasonal_strength),
            ("climate.weather_strength", self.climate.weather_strength),
            ("genetics.mutation_rate", self.genetics.mutation_rate),
            (
                "genetics.mutation_strength",
                self.genetics.mutation_strength,
            ),
            ("resources.regrowth_rate", self.resources.regrowth_rate),
        ] {
            if !value.is_finite() || !(0.0..=1.0).contains(&value) {
                return Err(error(key, "must be finite and between 0 and 1"));
            }
        }
        Ok(())
    }
    pub fn to_json(&self) -> Result<String, ConfigError> {
        self.validate()?;
        serde_json::to_string_pretty(self).map_err(|e| error("$", &e.to_string()))
    }
    pub fn preset(name: &str) -> Result<Self, ConfigError> {
        let mut c = Self::from_json(
            r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#,
        )?;
        match name {
            "temperate" => {}
            "lush" => {
                c.initial.plants = 700;
                c.resources.regrowth_rate = 0.1;
                c.climate.seasonal_strength = 0.1;
            }
            "harsh" => {
                c.initial.plants = 200;
                c.resources.regrowth_rate = 0.02;
                c.climate.seasonal_strength = 0.7;
            }
            _ => return Err(error("preset", &format!("unknown preset {name:?}"))),
        }
        c.validate()?;
        Ok(c)
    }
}

import json, pathlib, sys
root = pathlib.Path(sys.argv[1]); exact = pathlib.Path(sys.argv[2]); dest = pathlib.Path(sys.argv[3])
kinds = ('plants', 'herbivores', 'carnivores')
out = []
for path in sorted(root.glob('seed-*.json'), key=lambda p: int(p.stem.split('-')[1])):
    batch = json.loads(path.read_text()); replay = json.loads((exact / path.name).read_text())
    assert all(batch[k] == replay[k] for k in ('final', 'totals', 'state_hash'))
    series = replay['series']; extinction = {k: next((s['tick'] for s in series if s[k] == 0), None) for k in kinds}
    first = min((v for v in extinction.values() if v is not None), default=series[-1]['tick'])
    sample = series[first-series[0]['tick']]
    out.append({'seed':batch['seed'], 'extinction':extinction, 'first_extinction':first, 'causes_at_first':sample['metrics']['deaths_by_cause'], 'curves_to_first':[[s['tick'], *[s[k] for k in kinds]] for s in series if s['tick'] <= first], 'state_hash':batch['state_hash']})
dest.write_text(json.dumps(out, indent=2)+'\n')

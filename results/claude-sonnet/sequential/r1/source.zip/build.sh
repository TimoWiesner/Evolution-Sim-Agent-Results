#!/usr/bin/env bash
# Produces dist/evosim (single self-contained executable; links only glibc).
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
export PATH="$HOME/.cargo/bin:$PATH"
cargo build --release --locked >&2
mkdir -p dist
cp target/release/evosim dist/evosim.tmp
chmod +x dist/evosim.tmp
mv -f dist/evosim.tmp dist/evosim
echo "build: dist/evosim ready" >&2

//! `evosim batch` (ADR-0025): seeds x parameter sweeps, parallel but reproducible, JSON + CSV summary.

use crate::{run_config, write_atomic};
use evosim_core::config::{Config, Kind as PKind, Num};
use evosim_core::hash::sha256_hex;
use evosim_core::json::{format_float, Value};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Mutex;
use std::time::Instant;

pub const MAX_RUNS: usize = 100_000;
const KINDS: [&str; 3] = ["plants", "herbivores", "carnivores"];

#[derive(Clone, Debug, PartialEq)]
pub struct BatchArgs {
    pub config: String,
    pub seeds: Vec<i64>,
    pub ticks: u64,
    pub out_dir: String,
    pub params: Vec<(String, Vec<Num>)>,
    pub sample_every: Option<u64>,
    pub jobs: Option<usize>,
    pub quiet: bool,
}

const FLAGS: [&str; 8] = ["--config", "--seeds", "--ticks", "--out-dir", "--param", "--sample-every", "--jobs", "--quiet"];

fn parse_u64(flag: &str, v: &str) -> Result<u64, String> {
    if v.is_empty() || !v.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("{flag}: `{v}` is not a non-negative integer"));
    }
    v.parse::<u64>().map_err(|_| format!("{flag}: `{v}` is out of range"))
}

/// `1,5,10..12` -> [1,5,10,11,12]. Inclusive ranges, no duplicates, at most `MAX_RUNS` seeds.
pub fn parse_seeds(text: &str) -> Result<Vec<i64>, String> {
    let mut out: Vec<i64> = Vec::new();
    if text.is_empty() {
        return Err("--seeds: empty list".into());
    }
    for item in text.split(',') {
        let int = |t: &str| t.trim().parse::<i64>().map_err(|_| format!("--seeds: `{t}` is not an integer"));
        let (a, b) = match item.split_once("..") {
            Some((a, b)) => (int(a)?, int(b)?),
            None => {
                let v = int(item)?;
                (v, v)
            }
        };
        if b < a {
            return Err(format!("--seeds: range `{item}` is descending"));
        }
        if (b as i128 - a as i128 + 1) + out.len() as i128 > MAX_RUNS as i128 {
            return Err(format!("--seeds: more than {MAX_RUNS} seeds"));
        }
        for s in a..=b {
            if out.contains(&s) {
                return Err(format!("--seeds: duplicate seed {s}"));
            }
            out.push(s);
        }
    }
    Ok(out)
}

/// `PATH=V1,V2,...` typed by the configuration key table.
pub fn parse_param(text: &str) -> Result<(String, Vec<Num>), String> {
    let (path, vals) = text.split_once('=').ok_or_else(|| format!("--param: `{text}` must look like PATH=V1,V2"))?;
    if path == "seed" {
        return Err("--param: `seed` cannot be swept, use --seeds".into());
    }
    let def = Config::param_defs().into_iter().find(|d| d.path == path).ok_or_else(|| format!("--param: unknown configuration key `{path}`"))?;
    if vals.is_empty() {
        return Err(format!("--param {path}: no values"));
    }
    let mut out: Vec<Num> = Vec::new();
    for v in vals.split(',') {
        let n = match def.kind {
            PKind::Int => Num::I(v.parse::<i64>().map_err(|_| format!("--param {path}: `{v}` is not an integer"))?),
            PKind::Float => {
                let f = v.parse::<f64>().map_err(|_| format!("--param {path}: `{v}` is not a number"))?;
                if !f.is_finite() {
                    return Err(format!("--param {path}: `{v}` is not finite"));
                }
                Num::F(f)
            }
            PKind::Bool => match v {
                "true" => Num::B(true),
                "false" => Num::B(false),
                _ => return Err(format!("--param {path}: `{v}` is not true/false")),
            },
        };
        let x = match n {
            Num::I(i) => i as f64,
            Num::F(f) => f,
            Num::B(_) => 0.0,
        };
        if def.kind != PKind::Bool && (x < def.min || x > def.max) {
            return Err(format!("--param {path}: `{v}` is outside the allowed range {} .. {}", format_float(def.min), format_float(def.max)));
        }
        if out.iter().any(|o| num_text(*o) == num_text(n)) {
            return Err(format!("--param {path}: duplicate value `{v}`"));
        }
        out.push(n);
    }
    Ok((path.to_string(), out))
}

fn num_text(n: Num) -> String {
    match n {
        Num::I(i) => i.to_string(),
        Num::F(f) => format_float(f),
        Num::B(b) => b.to_string(),
    }
}

fn num_value(n: Num) -> Value {
    match n {
        Num::I(i) => Value::Int(i),
        Num::F(f) => Value::Float(f),
        Num::B(b) => Value::Bool(b),
    }
}

impl BatchArgs {
    pub fn parse(args: &[String]) -> Result<BatchArgs, String> {
        let (mut config, mut seeds, mut ticks, mut out_dir, mut sample, mut jobs) = (None, None, None, None, None, None);
        let mut params: Vec<(String, Vec<Num>)> = Vec::new();
        let mut quiet = false;
        let mut seen: Vec<String> = Vec::new();
        let mut i = 0;
        while i < args.len() {
            let a = &args[i];
            i += 1;
            if !a.starts_with("--") {
                return Err(format!("unexpected argument `{a}`"));
            }
            let (flag, inline) = match a.split_once('=') {
                Some((f, v)) => (f.to_string(), Some(v.to_string())),
                None => (a.clone(), None),
            };
            if !FLAGS.contains(&flag.as_str()) {
                return Err(format!("unknown option `{flag}`"));
            }
            if flag != "--param" && seen.contains(&flag) {
                return Err(format!("option `{flag}` given twice"));
            }
            seen.push(flag.clone());
            if flag == "--quiet" {
                if inline.is_some() {
                    return Err("--quiet takes no value".into());
                }
                quiet = true;
                continue;
            }
            let value = match inline {
                Some(v) => v,
                None => {
                    let v = args.get(i).ok_or_else(|| format!("option `{flag}` needs a value"))?;
                    i += 1;
                    v.clone()
                }
            };
            match flag.as_str() {
                "--config" => config = Some(value),
                "--out-dir" => out_dir = Some(value),
                "--seeds" => seeds = Some(parse_seeds(&value)?),
                "--ticks" => ticks = Some(parse_u64(&flag, &value)?),
                "--sample-every" => {
                    let k = parse_u64(&flag, &value)?;
                    if k == 0 {
                        return Err("--sample-every must be at least 1".into());
                    }
                    sample = Some(k);
                }
                "--jobs" => {
                    let j = parse_u64(&flag, &value)?;
                    if j == 0 || j > 4096 {
                        return Err("--jobs must be between 1 and 4096".into());
                    }
                    jobs = Some(j as usize);
                }
                "--param" => {
                    let p = parse_param(&value)?;
                    if params.iter().any(|q| q.0 == p.0) {
                        return Err(format!("--param {}: given twice", p.0));
                    }
                    params.push(p);
                }
                _ => unreachable!(),
            }
        }
        let seeds = seeds.ok_or("missing required option --seeds")?;
        let points: usize = params.iter().map(|p| p.1.len()).try_fold(1usize, |a, b| a.checked_mul(b)).unwrap_or(usize::MAX);
        if points.checked_mul(seeds.len()).map_or(true, |n| n > MAX_RUNS) {
            return Err(format!("more than {MAX_RUNS} runs requested"));
        }
        Ok(BatchArgs {
            config: config.ok_or("missing required option --config")?,
            seeds,
            ticks: ticks.ok_or("missing required option --ticks")?,
            out_dir: out_dir.ok_or("missing required option --out-dir")?,
            params,
            sample_every: sample,
            jobs,
            quiet,
        })
    }
}

/// One parameter point of the sweep: values in the order of `BatchArgs::params`.
#[derive(Clone, Debug, PartialEq)]
pub struct Point {
    pub values: Vec<Num>,
    pub label: String,
}

/// Cartesian product, first parameter slowest.
pub fn plan_points(params: &[(String, Vec<Num>)]) -> Vec<Point> {
    let mut pts = vec![Vec::<Num>::new()];
    for (_, vals) in params {
        let mut next = Vec::with_capacity(pts.len() * vals.len());
        for p in &pts {
            for v in vals {
                let mut q = p.clone();
                q.push(*v);
                next.push(q);
            }
        }
        pts = next;
    }
    pts.into_iter()
        .map(|values| {
            let label = params.iter().zip(&values).map(|((p, _), v)| format!("{}={}", p, num_text(*v))).collect::<Vec<_>>().join("_");
            Point { values, label }
        })
        .collect()
}

/// Everything the summary keeps of one finished run.
#[derive(Clone, Debug)]
pub struct RunInfo {
    pub index: usize,
    pub point: usize,
    pub seed: i64,
    pub file: String,
    pub tick_start: u64,
    pub tick_end: u64,
    pub fin: [u64; 3],
    pub species: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    pub first_zero: [Option<u64>; 3],
    pub hash: String,
    pub elapsed: f64,
    pub tps: f64,
}

fn u(v: &Value, path: &[&str]) -> Result<u64, String> {
    let mut c = v;
    for k in path {
        c = c.get(k).ok_or_else(|| format!("internal: result lacks `{}`", path.join(".")))?;
    }
    match c {
        Value::Int(i) if *i >= 0 => Ok(*i as u64),
        _ => Err(format!("internal: `{}` is not a count", path.join("."))),
    }
}

fn f(v: &Value, key: &str) -> f64 {
    match v.get(key) {
        Some(Value::Float(x)) => *x,
        Some(Value::Int(i)) => *i as f64,
        _ => 0.0,
    }
}

fn kinds3(v: &Value, group: &[&str]) -> Result<[u64; 3], String> {
    let mut out = [0u64; 3];
    for (i, k) in KINDS.iter().enumerate() {
        let mut p = group.to_vec();
        p.push(k);
        out[i] = u(v, &p)?;
    }
    Ok(out)
}

/// Extracts the summary data from a `run` result object.
pub fn extract(result: &Value, index: usize, point: usize, seed: i64, file: String) -> Result<RunInfo, String> {
    let mut first_zero = [None; 3];
    if let Some(Value::Array(series)) = result.get("series") {
        for s in series {
            for (i, k) in KINDS.iter().enumerate() {
                if first_zero[i].is_none() && u(s, &[k])? == 0 {
                    first_zero[i] = Some(u(s, &["tick"])?);
                }
            }
        }
    }
    Ok(RunInfo {
        index,
        point,
        seed,
        file,
        tick_start: u(result, &["tick_start"])?,
        tick_end: u(result, &["tick_end"])?,
        fin: kinds3(result, &["final"])?,
        species: kinds3(result, &["final", "species"])?,
        births: kinds3(result, &["totals", "births"])?,
        deaths: kinds3(result, &["totals", "deaths"])?,
        first_zero,
        hash: match result.get("state_hash") {
            Some(Value::Str(s)) => s.clone(),
            _ => String::new(),
        },
        elapsed: f(result, "elapsed_seconds"),
        tps: f(result, "ticks_per_second"),
    })
}

/// Statistics of a list of counts (accumulated in the given order, so reproducible).
pub struct Stats {
    pub mean: f64,
    pub min: u64,
    pub max: u64,
    pub sd: f64,
    pub median: f64,
}

pub fn stats(xs: &[u64]) -> Stats {
    if xs.is_empty() {
        return Stats { mean: 0.0, min: 0, max: 0, sd: 0.0, median: 0.0 };
    }
    let n = xs.len() as f64;
    let sum: u128 = xs.iter().map(|&x| x as u128).sum();
    let mean = sum as f64 / n;
    let var = xs.iter().map(|&x| (x as f64 - mean) * (x as f64 - mean)).sum::<f64>() / n;
    let mut s = xs.to_vec();
    s.sort_unstable();
    let m = s.len() / 2;
    let median = if s.len() % 2 == 1 { s[m] as f64 } else { (s[m - 1] as f64 + s[m] as f64) / 2.0 };
    Stats { mean, min: s[0], max: s[s.len() - 1], sd: var.sqrt(), median }
}

fn iv(x: u64) -> Value {
    Value::Int(x.min(i64::MAX as u64) as i64)
}

fn kind_obj(f: impl Fn(usize) -> Value) -> Value {
    Value::Object(KINDS.iter().enumerate().map(|(i, k)| (k.to_string(), f(i))).collect())
}

/// Aggregate body over a set of runs (all runs, or one parameter point).
pub fn aggregate(runs: &[&RunInfo]) -> Value {
    let n = runs.len() as f64;
    let per: Vec<Stats> = (0..3).map(|k| stats(&runs.iter().map(|r| r.fin[k]).collect::<Vec<_>>())).collect();
    let ext: Vec<u64> = (0..3).map(|k| runs.iter().filter(|r| r.fin[k] == 0).count() as u64).collect();
    let frac = |c: u64| if runs.is_empty() { 0.0 } else { c as f64 / n };
    let all_alive = runs.iter().filter(|r| r.fin.iter().all(|&c| c > 0)).count() as u64;
    Value::Object(vec![
        ("runs".into(), iv(runs.len() as u64)),
        (
            "final".into(),
            kind_obj(|k| {
                Value::Object(vec![
                    ("mean".into(), Value::Float(per[k].mean)),
                    ("min".into(), iv(per[k].min)),
                    ("max".into(), iv(per[k].max)),
                    ("sd".into(), Value::Float(per[k].sd)),
                    ("median".into(), Value::Float(per[k].median)),
                ])
            }),
        ),
        ("extinct_count".into(), kind_obj(|k| iv(ext[k]))),
        ("extinct_fraction".into(), kind_obj(|k| Value::Float(frac(ext[k])))),
        ("species_mean".into(), kind_obj(|k| Value::Float(if runs.is_empty() { 0.0 } else { runs.iter().map(|r| r.species[k] as u128).sum::<u128>() as f64 / n }))),
        ("all_kinds_alive".into(), iv(all_alive)),
    ])
}

fn params_obj(params: &[(String, Vec<Num>)], values: &[Num]) -> Value {
    Value::Object(params.iter().zip(values).map(|((p, _), v)| (p.clone(), num_value(*v))).collect())
}

/// Builds `summary.json` (without the batch wall time, added by the caller).
pub fn summarize(args: &BatchArgs, base_hash: &str, sample_every: u64, points: &[Point], runs: &[RunInfo]) -> Value {
    let opt = |o: Option<u64>| o.map_or(Value::Null, iv);
    let run_values: Vec<Value> = runs
        .iter()
        .map(|r| {
            let p = &points[r.point];
            Value::Object(vec![
                ("index".into(), iv(r.index as u64)),
                ("seed".into(), Value::Int(r.seed)),
                ("params".into(), params_obj(&args.params, &p.values)),
                ("label".into(), Value::Str(p.label.clone())),
                ("file".into(), Value::Str(r.file.clone())),
                ("ticks".into(), iv(args.ticks)),
                ("tick_start".into(), iv(r.tick_start)),
                ("tick_end".into(), iv(r.tick_end)),
                ("final".into(), kind_obj(|k| iv(r.fin[k]))),
                ("species".into(), kind_obj(|k| iv(r.species[k]))),
                ("extinct".into(), kind_obj(|k| Value::Bool(r.fin[k] == 0))),
                ("first_zero_tick".into(), kind_obj(|k| opt(r.first_zero[k]))),
                ("births".into(), kind_obj(|k| iv(r.births[k]))),
                ("deaths".into(), kind_obj(|k| iv(r.deaths[k]))),
                ("state_hash".into(), Value::Str(r.hash.clone())),
                ("elapsed_seconds".into(), Value::Float(r.elapsed)),
                ("ticks_per_second".into(), Value::Float(r.tps)),
            ])
        })
        .collect();
    let all: Vec<&RunInfo> = runs.iter().collect();
    let groups: Vec<Value> = points
        .iter()
        .enumerate()
        .map(|(pi, p)| {
            let rs: Vec<&RunInfo> = runs.iter().filter(|r| r.point == pi).collect();
            let mut items = vec![("params".to_string(), params_obj(&args.params, &p.values)), ("label".to_string(), Value::Str(p.label.clone()))];
            if let Value::Object(body) = aggregate(&rs) {
                items.extend(body);
            }
            Value::Object(items)
        })
        .collect();
    Value::Object(vec![
        ("contract".into(), Value::Int(1)),
        ("kind".into(), Value::Str("batch".into())),
        ("config_file".into(), Value::Str(args.config.clone())),
        ("config_hash".into(), Value::Str(base_hash.to_string())),
        ("ticks".into(), iv(args.ticks)),
        ("sample_every".into(), iv(sample_every)),
        ("seeds".into(), Value::Array(args.seeds.iter().map(|s| Value::Int(*s)).collect())),
        (
            "sweep".into(),
            Value::Array(
                args.params
                    .iter()
                    .map(|(p, vs)| Value::Object(vec![("param".into(), Value::Str(p.clone())), ("values".into(), Value::Array(vs.iter().map(|v| num_value(*v)).collect()))]))
                    .collect(),
            ),
        ),
        ("run_count".into(), iv(runs.len() as u64)),
        ("runs".into(), Value::Array(run_values)),
        ("aggregate".into(), aggregate(&all)),
        ("groups".into(), Value::Array(groups)),
    ])
}

fn csv_field(s: &str) -> String {
    if s.contains(|c| c == ',' || c == '"' || c == '\n' || c == '\r') {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}

fn csv_row(fields: &[String]) -> String {
    let mut s = fields.iter().map(|f| csv_field(f)).collect::<Vec<_>>().join(",");
    s.push('\n');
    s
}

/// `summary.csv`: one row per run. The last two columns are the time measurements.
pub fn runs_csv(args: &BatchArgs, points: &[Point], runs: &[RunInfo]) -> String {
    let mut head: Vec<String> = vec!["index".into(), "seed".into()];
    head.extend(args.params.iter().map(|p| p.0.clone()));
    for h in ["ticks", "tick_end", "plants", "herbivores", "carnivores", "species_plants", "species_herbivores", "species_carnivores", "extinct_plants", "extinct_herbivores", "extinct_carnivores", "state_hash", "elapsed_seconds", "ticks_per_second"] {
        head.push(h.into());
    }
    let mut out = csv_row(&head);
    for r in runs {
        let mut row = vec![r.index.to_string(), r.seed.to_string()];
        row.extend(points[r.point].values.iter().map(|v| num_text(*v)));
        row.push(args.ticks.to_string());
        row.push(r.tick_end.to_string());
        row.extend(r.fin.iter().map(|x| x.to_string()));
        row.extend(r.species.iter().map(|x| x.to_string()));
        row.extend(r.fin.iter().map(|&x| (x == 0).to_string().replace("true", "1").replace("false", "0")));
        row.push(r.hash.clone());
        row.push(format_float(r.elapsed));
        row.push(format_float(r.tps));
        out.push_str(&csv_row(&row));
    }
    out
}

/// `aggregates.csv`: one row per (parameter point, kind).
pub fn aggregates_csv(args: &BatchArgs, points: &[Point], runs: &[RunInfo]) -> String {
    let mut head: Vec<String> = args.params.iter().map(|p| p.0.clone()).collect();
    for h in ["kind", "runs", "final_mean", "final_min", "final_max", "final_sd", "final_median", "extinct_count", "extinct_fraction"] {
        head.push(h.into());
    }
    let mut out = csv_row(&head);
    for (pi, p) in points.iter().enumerate() {
        let rs: Vec<&RunInfo> = runs.iter().filter(|r| r.point == pi).collect();
        for (k, name) in KINDS.iter().enumerate() {
            let st = stats(&rs.iter().map(|r| r.fin[k]).collect::<Vec<_>>());
            let ext = rs.iter().filter(|r| r.fin[k] == 0).count();
            let mut row: Vec<String> = p.values.iter().map(|v| num_text(*v)).collect();
            row.push(name.to_string());
            row.push(rs.len().to_string());
            row.push(format_float(st.mean));
            row.push(st.min.to_string());
            row.push(st.max.to_string());
            row.push(format_float(st.sd));
            row.push(format_float(st.median));
            row.push(ext.to_string());
            row.push(format_float(if rs.is_empty() { 0.0 } else { ext as f64 / rs.len() as f64 }));
            out.push_str(&csv_row(&row));
        }
    }
    out
}

/// Executes the whole batch and writes all files. Errors are messages for stderr.
pub fn run_batch(args: &BatchArgs) -> Result<Value, String> {
    let base = Config::load_file(&args.config).map_err(|e| e.to_string())?;
    let base_hash = sha256_hex(base.to_json().as_bytes());
    // Build and validate every parameter point before simulating anything.
    let points = plan_points(&args.params);
    let mut cfgs: Vec<Config> = Vec::with_capacity(points.len());
    for p in &points {
        let mut c = base.clone();
        for ((path, _), v) in args.params.iter().zip(&p.values) {
            c.set_num(path, *v).map_err(|e| e.to_string())?;
        }
        c.validate().map_err(|e| format!("{}: {}", if p.label.is_empty() { "configuration" } else { &p.label }, e))?;
        cfgs.push(c);
    }
    let dir = std::path::Path::new(&args.out_dir);
    std::fs::create_dir_all(dir).map_err(|e| format!("cannot create `{}`: {e}", args.out_dir))?;
    if !args.params.is_empty() {
        for p in &points {
            let sub = dir.join(&p.label);
            std::fs::create_dir_all(&sub).map_err(|e| format!("cannot create `{}`: {e}", sub.display()))?;
        }
    }
    let total = points.len() * args.seeds.len();
    let jobs = args.jobs.unwrap_or_else(|| std::thread::available_parallelism().map_or(1, |n| n.get())).clamp(1, total.max(1));
    let sample_every = args.sample_every.unwrap_or_else(|| crate::args::default_sample_every(args.ticks));
    let slots: Mutex<Vec<Option<RunInfo>>> = Mutex::new((0..total).map(|_| None).collect());
    let next = AtomicUsize::new(0);
    let abort = AtomicBool::new(false);
    let errors: Mutex<Vec<(usize, String)>> = Mutex::new(Vec::new());
    let done = AtomicUsize::new(0);
    let t0 = Instant::now();
    let worker = || loop {
        let idx = next.fetch_add(1, Ordering::SeqCst);
        if idx >= total || abort.load(Ordering::SeqCst) {
            break;
        }
        let (pi, si) = (idx / args.seeds.len(), idx % args.seeds.len());
        let seed = args.seeds[si];
        let res = (|| -> Result<RunInfo, String> {
            let mut cfg = cfgs[pi].clone();
            cfg.seed = seed;
            let (result, _) = run_config(cfg, args.ticks, Some(sample_every), None)?;
            let rel = if args.params.is_empty() { format!("seed-{seed}.json") } else { format!("{}/seed-{seed}.json", points[pi].label) };
            let path = dir.join(&rel);
            write_atomic(&path.to_string_lossy(), &result.to_pretty())?;
            extract(&result, idx, pi, seed, rel)
        })();
        match res {
            Ok(info) => {
                if !args.quiet {
                    let n = done.fetch_add(1, Ordering::SeqCst) + 1;
                    eprintln!("evosim: batch run {}/{} done (seed {}{}{})", n, total, seed, if points[pi].label.is_empty() { "" } else { ", " }, points[pi].label);
                }
                slots.lock().unwrap()[idx] = Some(info);
            }
            Err(m) => {
                abort.store(true, Ordering::SeqCst);
                errors.lock().unwrap().push((idx, m));
            }
        }
    };
    let panicked = std::thread::scope(|s| {
        let hs: Vec<_> = (0..jobs).map(|_| s.spawn(&worker)).collect();
        hs.into_iter().map(|h| h.join().is_err()).any(|p| p)
    });
    if panicked {
        return Err("internal error: a simulation thread panicked".into());
    }
    let mut errs = errors.into_inner().unwrap();
    errs.sort();
    if let Some((idx, m)) = errs.into_iter().next() {
        return Err(format!("run {idx} (seed {}): {m}", args.seeds[idx % args.seeds.len()]));
    }
    let runs: Vec<RunInfo> = slots.into_inner().unwrap().into_iter().collect::<Option<Vec<_>>>().ok_or("internal error: missing run result")?;
    let mut summary = summarize(args, &base_hash, sample_every, &points, &runs);
    if let Value::Object(items) = &mut summary {
        items.push(("elapsed_seconds".into(), Value::Float(t0.elapsed().as_secs_f64())));
    }
    write_atomic(&dir.join("summary.csv").to_string_lossy(), &runs_csv(args, &points, &runs))?;
    write_atomic(&dir.join("aggregates.csv").to_string_lossy(), &aggregates_csv(args, &points, &runs))?;
    write_atomic(&dir.join("summary.json").to_string_lossy(), &summary.to_pretty())?;
    Ok(summary)
}

/// Entry point for `evosim batch <args>`; exit status 0 or 2; stdout stays empty.
pub fn batch_command(argv: &[String]) -> i32 {
    let go = || -> Result<(), String> {
        let args = BatchArgs::parse(argv)?;
        let summary = run_batch(&args)?;
        if !args.quiet {
            eprintln!("evosim: batch finished: {} runs; wrote {}/summary.json", summary.get("run_count").map(|v| v.to_compact()).unwrap_or_default(), args.out_dir);
        }
        Ok(())
    };
    match go() {
        Ok(()) => 0,
        Err(m) => {
            eprintln!("evosim: {m}");
            2
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(a: &[&str]) -> Vec<String> {
        a.iter().map(|x| x.to_string()).collect()
    }

    #[test]
    fn seeds_lists_and_ranges() {
        assert_eq!(parse_seeds("1,5,10..12").unwrap(), vec![1, 5, 10, 11, 12]);
        assert_eq!(parse_seeds("-2..0").unwrap(), vec![-2, -1, 0]);
        assert_eq!(parse_seeds("7").unwrap(), vec![7]);
        for bad in ["", "1,1", "3..1", "a", "1,,2", "1..2,2", "1.5", "0..100000"] {
            assert!(parse_seeds(bad).is_err(), "{bad}");
        }
    }

    #[test]
    fn param_parsing() {
        let (p, v) = parse_param("initial.herbivores=0,60").unwrap();
        assert_eq!((p.as_str(), v), ("initial.herbivores", vec![Num::I(0), Num::I(60)]));
        let (_, v) = parse_param("plants.growth_rate=0.5,1").unwrap();
        assert_eq!(v, vec![Num::F(0.5), Num::F(1.0)]);
        for bad in ["initial.herbivores", "initial.herbivores=", "initial.herbivores=1.5", "initial.herbivores=1,1", "seed=1,2", "no.such=1", "plants.growth_rate=x", "plants.growth_rate=nan", "initial.herbivores=-1", "plants.growth_rate=1,1.0"] {
            assert!(parse_param(bad).is_err(), "{bad}");
        }
    }

    #[test]
    fn args_and_run_order() {
        let a = BatchArgs::parse(&s(&["--config", "c", "--seeds", "1,2", "--ticks", "5", "--out-dir", "d", "--param", "initial.carnivores=0,5", "--param", "initial.herbivores=10,20,30"])).unwrap();
        let pts = plan_points(&a.params);
        assert_eq!(pts.len(), 6);
        assert_eq!(pts[0].label, "initial.carnivores=0_initial.herbivores=10");
        assert_eq!(pts[1].label, "initial.carnivores=0_initial.herbivores=20");
        assert_eq!(pts[3].label, "initial.carnivores=5_initial.herbivores=10");
        assert_eq!(plan_points(&[]).len(), 1);
        assert_eq!(plan_points(&[])[0].label, "");
        for bad in [
            vec!["--config", "c", "--seeds", "1", "--ticks", "5"],
            vec!["--config", "c", "--seeds", "1", "--ticks", "5", "--out-dir", "d", "--jobs", "0"],
            vec!["--config", "c", "--seeds", "1", "--ticks", "5", "--out-dir", "d", "--bogus"],
            vec!["--config", "c", "--config", "c", "--seeds", "1", "--ticks", "5", "--out-dir", "d"],
            vec!["--config", "c", "--seeds", "1", "--ticks", "5", "--out-dir", "d", "--param", "initial.carnivores=1", "--param", "initial.carnivores=2"],
        ] {
            assert!(BatchArgs::parse(&s(&bad)).is_err(), "{bad:?}");
        }
    }

    #[test]
    fn stats_by_hand() {
        let st = stats(&[2, 4, 4, 4, 5, 5, 7, 9]);
        assert_eq!((st.mean, st.min, st.max, st.sd, st.median), (5.0, 2, 9, 2.0, 4.5));
        let one = stats(&[3]);
        assert_eq!((one.mean, one.sd, one.median), (3.0, 0.0, 3.0));
        assert_eq!(stats(&[1, 5, 2]).median, 2.0);
    }

    fn info(point: usize, fin: [u64; 3]) -> RunInfo {
        RunInfo { index: 0, point, seed: 0, file: String::new(), tick_start: 0, tick_end: 1, fin, species: [1, 1, 1], births: [0; 3], deaths: [0; 3], first_zero: [None; 3], hash: "h".into(), elapsed: 0.0, tps: 0.0 }
    }

    #[test]
    fn aggregate_counts_extinctions() {
        let rs = [info(0, [10, 0, 0]), info(0, [20, 4, 0]), info(0, [30, 8, 2])];
        let refs: Vec<&RunInfo> = rs.iter().collect();
        let a = aggregate(&refs);
        let get = |p: &[&str]| p.iter().fold(&a, |c, k| c.get(k).unwrap()).to_compact();
        assert_eq!(get(&["final", "plants", "mean"]), "20.0");
        assert_eq!(get(&["final", "plants", "min"]), "10");
        assert_eq!(get(&["final", "herbivores", "max"]), "8");
        assert_eq!(get(&["extinct_count", "herbivores"]), "1");
        assert_eq!(get(&["extinct_count", "carnivores"]), "2");
        assert_eq!(get(&["all_kinds_alive"]), "1");
    }

    #[test]
    fn csv_quoting() {
        assert_eq!(csv_row(&s(&["a", "b,c", "d\"e"])), "a,\"b,c\",\"d\"\"e\"\n");
    }
}

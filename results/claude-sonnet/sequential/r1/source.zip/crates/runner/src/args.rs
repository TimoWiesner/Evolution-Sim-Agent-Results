//! Argument parser of `evosim run` (ADR-0023). Every error is a message for stderr; exit status 2.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RunArgs {
    /// Exactly one of `config` / `load` is set.
    pub config: Option<String>,
    pub load: Option<String>,
    pub save: Option<String>,
    pub ticks: u64,
    pub out: String,
    pub seed: Option<i64>,
    pub sample_every: Option<u64>,
    pub quiet: bool,
    pub metrics: Option<String>,
}

const FLAGS: [&str; 9] = ["--metrics", "--config", "--ticks", "--out", "--seed", "--sample-every", "--save", "--load", "--quiet"];

fn parse_u64(flag: &str, v: &str) -> Result<u64, String> {
    if v.is_empty() || !v.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("{flag}: `{v}` is not a non-negative integer"));
    }
    v.parse::<u64>().map_err(|_| format!("{flag}: `{v}` is out of range"))
}

impl RunArgs {
    /// Parses the arguments after `run`. Accepts `--flag value` and `--flag=value`.
    pub fn parse(args: &[String]) -> Result<RunArgs, String> {
        let mut config = None;
        let mut ticks = None;
        let mut out = None;
        let mut seed = None;
        let mut sample = None;
        let mut quiet = false;
        let mut metrics = None;
        let mut save = None;
        let mut load = None;
        let mut seen: Vec<String> = Vec::new();
        let mut i = 0;
        while i < args.len() {
            let a = &args[i];
            i += 1;
            if !a.starts_with("--") {
                return Err(format!("unexpected argument `{a}`"));
            }
            let (flag, inline) = match a.split_once('=') {
                Some((f, v)) => (f.to_string(), Some(v.to_string())),
                None => (a.clone(), None),
            };
            if !FLAGS.contains(&flag.as_str()) {
                return Err(format!("unknown option `{flag}`"));
            }
            if seen.contains(&flag) {
                return Err(format!("option `{flag}` given twice"));
            }
            seen.push(flag.clone());
            if flag == "--quiet" {
                if inline.is_some() {
                    return Err("--quiet takes no value".to_string());
                }
                quiet = true;
                continue;
            }
            let value = match inline {
                Some(v) => v,
                None => {
                    let v = args.get(i).ok_or_else(|| format!("option `{flag}` needs a value"))?;
                    i += 1;
                    v.clone()
                }
            };
            match flag.as_str() {
                "--config" => config = Some(value),
                "--out" => out = Some(value),
                "--metrics" => metrics = Some(value),
                "--ticks" => ticks = Some(parse_u64(&flag, &value)?),
                "--sample-every" => {
                    let k = parse_u64(&flag, &value)?;
                    if k == 0 {
                        return Err("--sample-every must be at least 1".to_string());
                    }
                    sample = Some(k);
                }
                "--seed" => {
                    seed = Some(value.parse::<i64>().map_err(|_| format!("--seed: `{value}` is not an integer"))?);
                }
                "--save" => save = Some(value),
                "--load" => load = Some(value),
                _ => unreachable!(),
            }
        }
        match (&config, &load) {
            (None, None) => return Err("missing required option --config (or --load)".to_string()),
            (Some(_), Some(_)) => return Err("--config and --load cannot be combined (a checkpoint carries its configuration)".to_string()),
            _ => {}
        }
        if load.is_some() && seed.is_some() {
            return Err("--seed cannot be combined with --load (a checkpoint carries its seed)".to_string());
        }
        Ok(RunArgs {
            config,
            load,
            save,
            ticks: ticks.ok_or("missing required option --ticks")?,
            out: out.ok_or("missing required option --out")?,
            seed,
            sample_every: sample,
            quiet,
            metrics,
        })
    }
}

/// Default `--sample-every`: 1/100 of `n`, at least 1.
pub fn default_sample_every(n: u64) -> u64 {
    (n / 100).max(1)
}

/// Series ticks: `start`, then `start + k*i` while `k*i < n`, then `start + n`; ascending, no duplicates.
pub fn series_ticks(start: u64, n: u64, k: u64) -> Vec<u64> {
    let k = k.max(1);
    let mut v = Vec::new();
    let mut off = 0u64;
    while off < n {
        v.push(start + off);
        off = match off.checked_add(k) {
            Some(x) => x,
            None => break,
        };
    }
    v.push(start + n);
    v
}

#[cfg(test)]
mod tests {
    use super::*;

    fn p(a: &[&str]) -> Result<RunArgs, String> {
        RunArgs::parse(&a.iter().map(|s| s.to_string()).collect::<Vec<_>>())
    }

    #[test]
    fn ok_forms() {
        let a = p(&["--config", "c.json", "--ticks", "10", "--out", "o.json"]).unwrap();
        assert_eq!((a.config.as_deref(), a.ticks, a.out.as_str(), a.seed, a.sample_every, a.quiet), (Some("c.json"), 10, "o.json", None, None, false));
        let b = p(&["--config=c", "--ticks=0", "--out=o", "--seed=-5", "--sample-every=3", "--quiet"]).unwrap();
        assert_eq!((b.ticks, b.seed, b.sample_every, b.quiet), (0, Some(-5), Some(3), true));
    }

    #[test]
    fn every_error_class() {
        let base = ["--config", "c", "--ticks", "1", "--out", "o"];
        let with = |extra: &[&str]| {
            let mut v: Vec<&str> = base.to_vec();
            v.extend_from_slice(extra);
            p(&v)
        };
        for bad in [
            vec!["--bogus", "1"],
            vec!["positional"],
            vec!["--seed", "x"],
            vec!["--seed", "1.5"],
            vec!["--sample-every", "0"],
            vec!["--sample-every", "-1"],
            vec!["--seed", "1", "--seed", "2"],
            vec!["--quiet=1"],
            vec!["--load", "x"],
            vec!["--save"],
            vec!["--seed"],
        ] {
            assert!(with(&bad).is_err(), "{bad:?}");
        }
        for bad in [
            vec!["--ticks", "1", "--out", "o"],
            vec!["--config", "c", "--out", "o"],
            vec!["--config", "c", "--ticks", "1"],
            vec!["--config", "c", "--ticks", "-1", "--out", "o"],
            vec!["--config", "c", "--ticks", "abc", "--out", "o"],
            vec!["--config", "c", "--ticks", "", "--out", "o"],
            vec!["--config", "c", "--ticks", "99999999999999999999999", "--out", "o"],
            vec!["--config", "c", "--ticks", "1.0", "--out", "o"],
            vec!["--config", "c", "--ticks"],
            vec![],
        ] {
            assert!(p(&bad).is_err(), "{bad:?}");
        }
    }

    #[test]
    fn save_and_load() {
        let a = p(&["--config", "c", "--ticks", "1", "--out", "o", "--save", "s.ckpt"]).unwrap();
        assert_eq!((a.save.as_deref(), a.load.as_deref()), (Some("s.ckpt"), None));
        let b = p(&["--load", "s.ckpt", "--ticks", "1", "--out", "o", "--save=t"]).unwrap();
        assert_eq!((b.config, b.load.as_deref(), b.save.as_deref()), (None, Some("s.ckpt"), Some("t")));
        assert!(p(&["--load", "s", "--seed", "1", "--ticks", "1", "--out", "o"]).is_err());
        assert!(p(&["--load", "s", "--config", "c", "--ticks", "1", "--out", "o"]).is_err());
        assert!(p(&["--ticks", "1", "--out", "o"]).is_err());
    }

    #[test]
    fn series() {
        assert_eq!(series_ticks(0, 0, 1), vec![0]);
        assert_eq!(series_ticks(0, 0, 50), vec![0]);
        assert_eq!(series_ticks(0, 10, 3), vec![0, 3, 6, 9, 10]);
        assert_eq!(series_ticks(0, 10, 5), vec![0, 5, 10]);
        assert_eq!(series_ticks(0, 10, 100), vec![0, 10]);
        assert_eq!(series_ticks(0, 3, 1), vec![0, 1, 2, 3]);
        assert_eq!(series_ticks(7, 4, 2), vec![7, 9, 11]);
        assert_eq!(series_ticks(0, 5, u64::MAX), vec![0, 5]);
    }

    #[test]
    fn default_k() {
        assert_eq!(default_sample_every(0), 1);
        assert_eq!(default_sample_every(50), 1);
        assert_eq!(default_sample_every(199), 1);
        assert_eq!(default_sample_every(1000), 10);
    }
}

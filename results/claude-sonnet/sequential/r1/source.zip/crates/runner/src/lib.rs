//! Headless `evosim run` (ADR-0023): argument parsing, simulation loop, result JSON, atomic output.
//! The only crate part that reads the clock or touches files besides the config loader.

pub mod args;
pub mod batch;

pub use batch::batch_command;

use args::{default_sample_every, series_ticks, RunArgs};
use evosim_core::config::Config;
use evosim_core::hash::sha256_hex;
use evosim_core::json::Value;
use evosim_core::metrics::MetricsRecorder;
use evosim_core::organism::{DeathCause, Kind};
use evosim_core::sim::Simulation;
use std::time::Instant;

fn int(v: u64) -> Value {
    Value::Int(v.min(i64::MAX as u64) as i64)
}

fn per_kind(f: impl Fn(Kind) -> u64) -> Value {
    Value::Object(vec![
        ("plants".into(), int(f(Kind::Plant))),
        ("herbivores".into(), int(f(Kind::Herbivore))),
        ("carnivores".into(), int(f(Kind::Carnivore))),
    ])
}

fn per_kind_obj(f: impl Fn(Kind) -> Value) -> Value {
    Value::Object(vec![("plants".into(), f(Kind::Plant)), ("herbivores".into(), f(Kind::Herbivore)), ("carnivores".into(), f(Kind::Carnivore))])
}

fn sample(sim: &Simulation) -> Value {
    Value::Object(vec![
        ("tick".into(), int(sim.tick)),
        ("plants".into(), int(sim.organisms.count(Kind::Plant) as u64)),
        ("herbivores".into(), int(sim.organisms.count(Kind::Herbivore) as u64)),
        ("carnivores".into(), int(sim.organisms.count(Kind::Carnivore) as u64)),
        ("species_plants".into(), int(sim.living_species(Kind::Plant) as u64)),
        ("species_herbivores".into(), int(sim.living_species(Kind::Herbivore) as u64)),
        ("species_carnivores".into(), int(sim.living_species(Kind::Carnivore) as u64)),
    ])
}

/// Runs the simulation described by `args` and returns the result object (no file I/O besides the config).
pub fn run_headless(args: &RunArgs) -> Result<Value, String> {
    run_headless_full(args).map(|r| r.0)
}

/// Like `run_headless`; the second value is the metrics document when `args.metrics` is set.
pub fn run_headless_full(args: &RunArgs) -> Result<(Value, Option<Value>), String> {
    run_with_sim(args).map(|(r, m, _)| (r, m))
}

/// Runs and also returns the final simulation (for `--save`).
fn run_with_sim(args: &RunArgs) -> Result<(Value, Option<Value>, Simulation), String> {
    let sim = match (&args.load, &args.config) {
        (Some(path), _) => {
            let bytes = std::fs::read(path).map_err(|e| format!("cannot read checkpoint `{path}`: {e}"))?;
            Simulation::from_checkpoint(&bytes).map_err(|e| format!("`{path}`: {e}"))?
        }
        (None, Some(path)) => {
            let mut cfg = Config::load_file(path).map_err(|e| e.to_string())?;
            if let Some(s) = args.seed {
                cfg.seed = s;
            }
            Simulation::new(&cfg).map_err(|e| e.to_string())?
        }
        (None, None) => return Err("neither --config nor --load given".to_string()),
    };
    run_simulation(sim, args.ticks, args.sample_every, args.metrics.as_deref())
}

/// Runs an already built configuration for `n` ticks. `metrics_name` (Some = also record metrics) is only echoed
/// as `metrics_file`. Shared by `run` and `batch`.
pub fn run_config(cfg: Config, n: u64, sample_every: Option<u64>, metrics_name: Option<&str>) -> Result<(Value, Option<Value>), String> {
    let sim = Simulation::new(&cfg).map_err(|e| e.to_string())?;
    run_simulation(sim, n, sample_every, metrics_name).map(|(r, m, _)| (r, m))
}

/// Advances `sim` by `n` ticks (from wherever it stands) and builds the result document.
pub fn run_simulation(mut sim: Simulation, n: u64, sample_every: Option<u64>, metrics_name: Option<&str>) -> Result<(Value, Option<Value>, Simulation), String> {
    let k = sample_every.unwrap_or_else(|| default_sample_every(n));
    let tick_start = sim.tick;
    let marks = series_ticks(tick_start, n, k);
    let mut series = Vec::with_capacity(marks.len());
    let mut mi = 0;
    let mut recorder = metrics_name.map(|_| MetricsRecorder::new());
    let t0 = Instant::now();
    // Exactly n ticks, never stopping early when everything is extinct.
    loop {
        while mi < marks.len() && marks[mi] == sim.tick {
            series.push(sample(&sim));
            if let Some(r) = recorder.as_mut() {
                r.record(&sim);
            }
            mi += 1;
        }
        if sim.tick >= tick_start + n {
            break;
        }
        sim.step();
    }
    let elapsed = t0.elapsed().as_secs_f64();
    debug_assert_eq!(mi, marks.len());
    sim.ledger_check().map_err(|m| format!("internal invariant violated: {m}"))?;
    let st = &sim.organisms.stats;
    let tps = if elapsed > 0.0 && n > 0 { n as f64 / elapsed } else { 0.0 };
    let canonical = sim.config.to_json();
    let w = &sim.config.world;
    let metrics = recorder.map(|r| r.to_json(sim.config.seed, tick_start, sim.tick, k));
    let result = Value::Object(vec![
        ("contract".into(), Value::Int(1)),
        ("seed".into(), Value::Int(sim.config.seed)),
        ("tick_start".into(), int(tick_start)),
        ("tick_end".into(), int(sim.tick)),
        ("world".into(), Value::Object(vec![("width".into(), int(w.width as u64)), ("height".into(), int(w.height as u64))])),
        (
            "final".into(),
            Value::Object(vec![
                ("plants".into(), int(sim.organisms.count(Kind::Plant) as u64)),
                ("herbivores".into(), int(sim.organisms.count(Kind::Herbivore) as u64)),
                ("carnivores".into(), int(sim.organisms.count(Kind::Carnivore) as u64)),
                (
                    "species".into(),
                    per_kind(|k| sim.living_species(k) as u64),
                ),
            ]),
        ),
        (
            "totals".into(),
            Value::Object(vec![
                ("births".into(), per_kind(|k| st.births[k.index()])),
                ("deaths".into(), per_kind(|k| st.deaths[k.index()])),
                ("initial".into(), per_kind(|k| st.founded[k.index()])),
                (
                    "deaths_by_cause".into(),
                    per_kind_obj(|k| Value::Object(DeathCause::ALL.iter().map(|c| (c.name().to_string(), int(st.deaths_by_cause[k.index()][c.index()]))).collect())),
                ),
            ]),
        ),
        ("series".into(), Value::Array(series)),
        ("state_hash".into(), Value::Str(sim.state_hash())),
        ("elapsed_seconds".into(), Value::Float(elapsed)),
        ("ticks_per_second".into(), Value::Float(tps)),
        ("config_hash".into(), Value::Str(sha256_hex(canonical.as_bytes()))),
        ("sample_every".into(), int(k)),
        ("ticks_simulated".into(), int(n)),
        (
            "species_ever".into(),
            per_kind(|kind| sim.species.records().iter().filter(|r| r.kind == kind).count() as u64),
        ),
        ("metrics_file".into(), metrics_name.map_or(Value::Null, |m| Value::Str(m.to_string()))),
    ]);
    Ok((result, metrics, sim))
}

/// Writes `text` to `out` through a temporary file in the same directory and a rename.
pub fn write_atomic(out: &str, text: &str) -> Result<(), String> {
    write_atomic_bytes(out, text.as_bytes())
}

/// Binary variant of `write_atomic` (checkpoints).
pub fn write_atomic_bytes(out: &str, data: &[u8]) -> Result<(), String> {
    let tmp = format!("{}.tmp.{}", out, std::process::id());
    if let Err(e) = std::fs::write(&tmp, data) {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("cannot write `{out}`: {e}"));
    }
    if let Err(e) = std::fs::rename(&tmp, out) {
        let _ = std::fs::remove_file(&tmp);
        return Err(format!("cannot write `{out}`: {e}"));
    }
    Ok(())
}

/// Entry point for `evosim run <args>`; returns the process exit status (0 or 2). stdout stays empty.
pub fn run_command(argv: &[String]) -> i32 {
    let go = || -> Result<(), String> {
        let args = RunArgs::parse(argv)?;
        // Fail early on an unwritable destination so no time is wasted simulating.
        for path in std::iter::once(&args.out).chain(args.metrics.iter()).chain(args.save.iter()) {
            let probe = format!("{}.tmp.{}", path, std::process::id());
            std::fs::File::create(&probe).map_err(|e| format!("cannot write `{path}`: {e}"))?;
            let _ = std::fs::remove_file(&probe);
        }
        let (result, metrics, sim) = run_with_sim(&args)?;
        if let Some(path) = args.save.as_ref() {
            write_atomic_bytes(path, &sim.to_checkpoint())?;
        }
        if let (Some(path), Some(m)) = (args.metrics.as_ref(), metrics.as_ref()) {
            write_atomic(path, &m.to_pretty())?;
        }
        write_atomic(&args.out, &result.to_pretty())?;
        if !args.quiet {
            let f = |k: &str| result.get("final").and_then(|v| v.get(k)).map(|v| v.to_compact()).unwrap_or_default();
            eprintln!(
                "evosim: ran {} ticks (tick_end {}): plants {}, herbivores {}, carnivores {}; wrote {}",
                args.ticks,
                result.get("tick_end").map(|v| v.to_compact()).unwrap_or_default(),
                f("plants"),
                f("herbivores"),
                f("carnivores"),
                args.out
            );
        }
        Ok(())
    };
    match go() {
        Ok(()) => 0,
        Err(m) => {
            eprintln!("evosim: {m}");
            2
        }
    }
}

//! TASK-019: end-to-end tests of `evosim run` (CONTRACT sections 2, 4, 5).
use evosim_core::json::{parse, Value};
use std::path::PathBuf;
use std::process::{Command, Output};

fn tmp(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-run-{}-{}", std::process::id(), name));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).args(args).env_remove("DISPLAY").env_remove("WAYLAND_DISPLAY").output().unwrap()
}

fn small_cfg(dir: &PathBuf, name: &str, seed: i64, p: u32, h: u32, c: u32) -> String {
    let path = dir.join(name);
    std::fs::write(
        &path,
        format!(r#"{{"seed": {seed}, "world": {{"width": 24, "height": 16}}, "initial": {{"plants": {p}, "herbivores": {h}, "carnivores": {c}}}}}"#),
    )
    .unwrap();
    path.to_str().unwrap().to_string()
}

fn run_ok(args: &[&str], out: &PathBuf) -> Value {
    let mut a: Vec<&str> = vec!["run"];
    a.extend_from_slice(args);
    a.extend_from_slice(&["--out", out.to_str().unwrap()]);
    let o = evosim(&a);
    assert_eq!(o.status.code(), Some(0), "stderr: {}", String::from_utf8_lossy(&o.stderr));
    assert!(o.stdout.is_empty(), "stdout must stay empty");
    parse(&std::fs::read_to_string(out).unwrap()).unwrap()
}

fn u(v: &Value, path: &[&str]) -> i64 {
    let mut c = v;
    for k in path {
        c = c.get(k).unwrap_or_else(|| panic!("missing {path:?}"));
    }
    match c {
        Value::Int(i) => *i,
        o => panic!("{path:?} is {}", o.type_name()),
    }
}

fn strip_timing(v: &Value) -> String {
    match v {
        Value::Object(items) => Value::Object(items.iter().filter(|(k, _)| k != "elapsed_seconds" && k != "ticks_per_second").cloned().collect()).to_compact(),
        _ => panic!(),
    }
}

#[test]
fn same_seed_twice_identical_and_schema() {
    let d = tmp("det");
    let cfg = small_cfg(&d, "c.json", 7, 80, 20, 5);
    let (o1, o2) = (d.join("a.json"), d.join("b.json"));
    let a = run_ok(&["--config", &cfg, "--ticks", "120", "--sample-every", "40"], &o1);
    let b = run_ok(&["--config", &cfg, "--ticks", "120", "--sample-every", "40"], &o2);
    for k in ["final", "totals", "series", "state_hash"] {
        assert_eq!(a.get(k).unwrap(), b.get(k).unwrap(), "{k}");
    }
    assert_eq!(strip_timing(&a), strip_timing(&b));
    // schema
    assert_eq!(u(&a, &["contract"]), 1);
    assert_eq!(u(&a, &["seed"]), 7);
    assert_eq!((u(&a, &["tick_start"]), u(&a, &["tick_end"])), (0, 120));
    assert_eq!((u(&a, &["world", "width"]), u(&a, &["world", "height"])), (24, 16));
    let Some(Value::Str(h)) = a.get("state_hash") else { panic!() };
    assert_eq!(h.len(), 64);
    assert!(h.bytes().all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c)));
    for k in ["elapsed_seconds", "ticks_per_second"] {
        assert!(matches!(a.get(k), Some(Value::Float(f)) if f.is_finite() && *f >= 0.0), "{k}");
    }
    for kind in ["plants", "herbivores", "carnivores"] {
        let ini = u(&a, &["totals", "initial", kind]);
        assert_eq!(ini + u(&a, &["totals", "births", kind]) - u(&a, &["totals", "deaths", kind]), u(&a, &["final", kind]), "{kind}");
        u(&a, &["final", "species", kind]);
    }
    assert_eq!(u(&a, &["totals", "initial", "plants"]), 80);
    let Some(Value::Array(s)) = a.get("series") else { panic!() };
    let ticks: Vec<i64> = s.iter().map(|e| u(e, &["tick"])).collect();
    assert_eq!(ticks, vec![0, 40, 80, 120]);
    assert_eq!((u(&s[0], &["plants"]), u(&s[0], &["herbivores"]), u(&s[0], &["carnivores"])), (80, 20, 5));
    let last = s.last().unwrap();
    for kind in ["plants", "herbivores", "carnivores"] {
        assert_eq!(u(last, &[kind]), u(&a, &["final", kind]));
    }
}

#[test]
fn seed_override_and_different_seeds_differ() {
    let d = tmp("seed");
    let cfg = small_cfg(&d, "c.json", 1, 80, 20, 5);
    let a = run_ok(&["--config", &cfg, "--ticks", "30"], &d.join("a.json"));
    let b = run_ok(&["--config", &cfg, "--ticks", "30", "--seed", "2"], &d.join("b.json"));
    let cfg2 = small_cfg(&d, "c2.json", 2, 80, 20, 5);
    let c = run_ok(&["--config", &cfg2, "--ticks", "30"], &d.join("rc.json"));
    assert_eq!(u(&b, &["seed"]), 2);
    assert_ne!(a.get("state_hash"), b.get("state_hash"));
    assert_eq!(b.get("state_hash"), c.get("state_hash"), "--seed 2 equals seed 2 in the file");
    // seed 0 and negative seeds are accepted
    run_ok(&["--config", &cfg, "--ticks", "1", "--seed", "-3"], &d.join("e.json"));
    run_ok(&["--config", &cfg, "--ticks", "1", "--seed=0"], &d.join("f.json"));
}

#[test]
fn ticks_zero_and_sample_every() {
    let d = tmp("zero");
    let cfg = small_cfg(&d, "c.json", 3, 30, 10, 3);
    let z = run_ok(&["--config", &cfg, "--ticks", "0"], &d.join("z.json"));
    assert_eq!((u(&z, &["tick_start"]), u(&z, &["tick_end"])), (0, 0));
    let Some(Value::Array(s)) = z.get("series") else { panic!() };
    assert_eq!(s.len(), 1);
    assert_eq!(u(&s[0], &["plants"]), 30);
    assert_eq!(u(&z, &["final", "herbivores"]), 10);
    assert_eq!(u(&z, &["totals", "births", "plants"]), 0);
    assert!(z.get("state_hash").is_some());
    let t = run_ok(&["--config", &cfg, "--ticks", "10", "--sample-every", "3"], &d.join("t.json"));
    let Some(Value::Array(s)) = t.get("series") else { panic!() };
    assert_eq!(s.iter().map(|e| u(e, &["tick"])).collect::<Vec<_>>(), vec![0, 3, 6, 9, 10]);
    let t = run_ok(&["--config", &cfg, "--ticks", "10", "--sample-every", "5"], &d.join("t2.json"));
    let Some(Value::Array(s)) = t.get("series") else { panic!() };
    assert_eq!(s.iter().map(|e| u(e, &["tick"])).collect::<Vec<_>>(), vec![0, 5, 10]);
    // default K for N=250 is 2
    let t = run_ok(&["--config", &cfg, "--ticks", "250"], &d.join("t3.json"));
    let Some(Value::Array(s)) = t.get("series") else { panic!() };
    assert_eq!((s.len(), u(&t, &["sample_every"])), (126, 2));
    // n < 100: K = 1
    let t = run_ok(&["--config", &cfg, "--ticks", "7"], &d.join("t4.json"));
    let Some(Value::Array(s)) = t.get("series") else { panic!() };
    assert_eq!(s.len(), 8);
}

#[test]
fn extinct_world_still_runs_exactly_n_ticks() {
    let d = tmp("extinct");
    let cfg = small_cfg(&d, "c.json", 4, 0, 0, 0);
    let a = run_ok(&["--config", &cfg, "--ticks", "300", "--sample-every", "100"], &d.join("a.json"));
    assert_eq!((u(&a, &["tick_start"]), u(&a, &["tick_end"])), (0, 300));
    for k in ["plants", "herbivores", "carnivores"] {
        assert_eq!(u(&a, &["final", k]), 0);
        assert_eq!(u(&a, &["totals", "births", k]), 0);
    }
    let b = run_ok(&["--config", &cfg, "--ticks", "299"], &d.join("b.json"));
    let z = run_ok(&["--config", &cfg, "--ticks", "0"], &d.join("z.json"));
    assert_ne!(a.get("state_hash"), b.get("state_hash"));
    assert_ne!(a.get("state_hash"), z.get("state_hash"));
}

#[test]
fn no_plants_animals_die_out_and_stay_dead() {
    let d = tmp("noplants");
    let cfg = small_cfg(&d, "c.json", 5, 0, 20, 6);
    let a = run_ok(&["--config", &cfg, "--ticks", "400", "--sample-every", "10"], &d.join("a.json"));
    assert_eq!(u(&a, &["tick_end"]), 400);
    assert_eq!((u(&a, &["final", "plants"]), u(&a, &["final", "herbivores"]), u(&a, &["final", "carnivores"])), (0, 0, 0));
    assert_eq!(u(&a, &["totals", "births", "plants"]), 0);
    let Some(Value::Array(s)) = a.get("series") else { panic!() };
    for kind in ["plants", "herbivores", "carnivores"] {
        let v: Vec<i64> = s.iter().map(|e| u(e, &[kind])).collect();
        if let Some(first_zero) = v.iter().position(|&x| x == 0) {
            assert!(v[first_zero..].iter().all(|&x| x == 0), "{kind} revived: {v:?}");
        }
    }
    // herbivores go extinct before or when carnivores do
    let zero_at = |kind: &str| s.iter().position(|e| u(e, &[kind]) == 0).unwrap();
    assert!(zero_at("herbivores") <= zero_at("carnivores"));
}

fn expect_error(args: &[&str], out: &PathBuf, preexisting: bool) {
    let before = std::fs::read(out).ok();
    assert_eq!(before.is_some(), preexisting);
    let o = evosim(args);
    assert_eq!(o.status.code(), Some(2), "{args:?}: {}", String::from_utf8_lossy(&o.stderr));
    assert!(!o.stderr.is_empty(), "{args:?}: stderr empty");
    assert!(o.stdout.is_empty(), "{args:?}: stdout not empty");
    assert_eq!(std::fs::read(out).ok(), before, "{args:?}: result file created or changed");
    let dir = out.parent().unwrap();
    for e in std::fs::read_dir(dir).unwrap() {
        let n = e.unwrap().file_name().to_string_lossy().to_string();
        assert!(!n.contains(".tmp."), "{args:?}: temp file left: {n}");
    }
}

#[test]
fn errors_exit_2_without_result_file() {
    let d = tmp("err");
    let good = small_cfg(&d, "good.json", 1, 5, 2, 1);
    let out = d.join("out.json");
    let o = out.to_str().unwrap();
    let write = |name: &str, text: &str| {
        let p = d.join(name);
        std::fs::write(&p, text).unwrap();
        p.to_str().unwrap().to_string()
    };
    let bad_json = write("bad.json", "{ not json");
    let wrong_type = write("type.json", r#"{"seed":"x","world":{"width":8,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let missing_key = write("missing.json", r#"{"seed":1,"world":{"width":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let zero_w = write("zero.json", r#"{"seed":1,"world":{"width":0,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let neg_n = write("neg.json", r#"{"seed":1,"world":{"width":8,"height":8},"initial":{"plants":-1,"herbivores":1,"carnivores":1}}"#);
    let unknown = write("unk.json", r#"{"seed":1,"bogus":1,"world":{"width":8,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    let nodir = d.join("nodir").join("out.json");
    let nodir = nodir.to_str().unwrap();
    let missing = d.join("nope.json");
    let cases: Vec<Vec<&str>> = vec![
        vec!["run"],
        vec!["run", "--ticks", "1", "--out", o],
        vec!["run", "--config", &good, "--out", o],
        vec!["run", "--config", &good, "--ticks", "1"],
        vec!["run", "--config", &good, "--ticks", "1", "--out", o, "--bogus"],
        vec!["run", "--config", &good, "--ticks", "-1", "--out", o],
        vec!["run", "--config", &good, "--ticks", "abc", "--out", o],
        vec!["run", "--config", &good, "--ticks", "1", "--out", o, "--sample-every", "0"],
        vec!["run", "--config", &good, "--ticks", "1", "--out", o, "--seed", "x"],
        vec!["run", "--config", missing.to_str().unwrap(), "--ticks", "1", "--out", o],
        vec!["run", "--config", &bad_json, "--ticks", "1", "--out", o],
        vec!["run", "--config", &wrong_type, "--ticks", "1", "--out", o],
        vec!["run", "--config", &missing_key, "--ticks", "1", "--out", o],
        vec!["run", "--config", &zero_w, "--ticks", "1", "--out", o],
        vec!["run", "--config", &neg_n, "--ticks", "1", "--out", o],
        vec!["run", "--config", &unknown, "--ticks", "1", "--out", o],
        vec!["run", "--config", &good, "--ticks", "1", "--out", nodir],
        vec!["run", "--load", "/nonexistent/x.ckpt", "--ticks", "1", "--out", o],
        vec!["run", "--config", &good, "--load", "x.ckpt", "--ticks", "1", "--out", o],
    ];
    for c in &cases {
        expect_error(c, &out, false);
    }
    // a pre-existing result is left untouched
    std::fs::write(&out, "previous").unwrap();
    for c in &cases {
        if c.iter().any(|a| *a == nodir) {
            continue;
        }
        expect_error(c, &out, true);
    }
    assert!(!d.join("nodir").exists());
}

#[test]
fn help_and_version_still_work_and_example_config_runs() {
    let d = tmp("example");
    let ex = concat!(env!("CARGO_MANIFEST_DIR"), "/../../examples/minimal.json");
    let a = run_ok(&["--config", ex, "--ticks", "20", "--quiet"], &d.join("r.json"));
    assert_eq!((u(&a, &["world", "width"]), u(&a, &["world", "height"]), u(&a, &["seed"])), (64, 48, 42));
    assert_eq!(u(&a, &["totals", "initial", "plants"]), 400);
}

// ---- TASK-020: --metrics ----

fn arr<'a>(v: &'a Value, k: &str) -> &'a Vec<Value> {
    match v.get(k) {
        Some(Value::Array(a)) => a,
        _ => panic!("{k} not array"),
    }
}

#[test]
fn metrics_file_written_matches_series_and_ledger_and_hash_unchanged() {
    let d = tmp("metrics");
    let cfg = small_cfg(&d, "c.json", 11, 80, 20, 5);
    let base = run_ok(&["--config", &cfg, "--ticks", "120", "--sample-every", "40"], &d.join("a.json"));
    let mpath = d.join("m.json");
    let with = run_ok(&["--config", &cfg, "--ticks", "120", "--sample-every", "40", "--metrics", mpath.to_str().unwrap()], &d.join("b.json"));
    assert_eq!(base.get("state_hash"), with.get("state_hash"), "recording must not change the simulation");
    assert_eq!(base.get("series"), with.get("series"));
    assert_eq!(with.get("metrics_file"), Some(&Value::Str(mpath.to_str().unwrap().to_string())));
    assert_eq!(base.get("metrics_file"), Some(&Value::Null));
    let m = parse(&std::fs::read_to_string(&mpath).unwrap()).unwrap();
    assert_eq!(m.get("format"), Some(&Value::Str("evosim-metrics".into())));
    let series = arr(&with, "series");
    let samples = arr(&m, "samples");
    assert_eq!(samples.len(), series.len());
    let ticks = |v: &Vec<Value>| v.iter().map(|s| u(s, &["tick"])).collect::<Vec<_>>();
    assert_eq!(ticks(samples), ticks(series));
    for (s, p) in samples.iter().zip(series) {
        for k in ["plants", "herbivores", "carnivores"] {
            assert_eq!(u(s, &[k, "population"]), u(p, &[k]));
            let init = u(&with, &["totals", "initial", k]);
            assert_eq!(init + u(s, &[k, "births"]) - u(s, &[k, "deaths"]), u(s, &[k, "population"]), "ledger {k}");
            let by: i64 = ["old_age", "starvation", "injury", "predation", "other", "climate"].iter().map(|c| u(s, &[k, "deaths_by_cause", c])).sum();
            assert_eq!(by, u(s, &[k, "deaths"]));
        }
    }
    let last = samples.last().unwrap();
    for k in ["plants", "herbivores", "carnivores"] {
        assert_eq!(u(last, &[k, "deaths"]), u(&with, &["totals", "deaths", k]));
        let by: i64 = ["old_age", "starvation", "injury", "predation", "other", "climate"].iter().map(|c| u(&with, &["totals", "deaths_by_cause", k, c])).sum();
        assert_eq!(by, u(&with, &["totals", "deaths", k]));
    }
}

#[test]
fn metrics_errors_leave_no_files() {
    let d = tmp("metrics-err");
    let cfg = small_cfg(&d, "c.json", 1, 10, 2, 1);
    let out = d.join("r.json");
    let bad = d.join("no-such-dir").join("m.json");
    let o = evosim(&["run", "--config", &cfg, "--ticks", "5", "--out", out.to_str().unwrap(), "--metrics", bad.to_str().unwrap()]);
    assert_eq!(o.status.code(), Some(2));
    assert!(!out.exists());
    let m = d.join("m.json");
    let ms = m.to_str().unwrap();
    let o = evosim(&["run", "--config", &cfg, "--ticks", "5", "--out", out.to_str().unwrap(), "--metrics", ms, "--metrics", ms]);
    assert_eq!(o.status.code(), Some(2));
    let o = evosim(&["run", "--config", &cfg, "--ticks", "5", "--out", out.to_str().unwrap(), "--metrics"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(!out.exists() && !m.exists());
}

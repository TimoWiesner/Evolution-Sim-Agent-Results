//! TASK-028: the demo scenario and the section-3 example config are accepted by run and batch.
use std::path::PathBuf;
use std::process::Command;

fn root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..")
}

fn tmp(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-demo-{}-{}", std::process::id(), name));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn evosim(args: &[&str]) -> std::process::Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).args(args).env_remove("DISPLAY").output().unwrap()
}

#[test]
fn demo_and_example_configs_run_and_batch() {
    for cfg in ["scenarios/demo.json", "examples/contract-example.json"] {
        let path = root().join(cfg);
        let path = path.to_str().unwrap();
        let d = tmp(&cfg.replace('/', "_"));
        let out = d.join("r.json");
        let o = evosim(&["run", "--config", path, "--ticks", "200", "--out", out.to_str().unwrap(), "--quiet"]);
        assert_eq!(o.status.code(), Some(0), "{cfg}: {}", String::from_utf8_lossy(&o.stderr));
        let r = evosim_core::json::parse(&std::fs::read_to_string(&out).unwrap()).unwrap();
        assert_eq!(r.get("tick_end"), Some(&evosim_core::json::Value::Int(200)));
        let bd = d.join("b");
        std::fs::create_dir_all(&bd).unwrap();
        let o = evosim(&["batch", "--config", path, "--seeds", "1,2", "--ticks", "30", "--out-dir", bd.to_str().unwrap(), "--quiet"]);
        assert_eq!(o.status.code(), Some(0), "{cfg}: {}", String::from_utf8_lossy(&o.stderr));
        assert!(bd.join("seed-1.json").exists() && bd.join("seed-2.json").exists() && bd.join("summary.json").exists());
    }
}

#[test]
fn demo_config_only_uses_known_keys_and_fixed_keys() {
    let text = std::fs::read_to_string(root().join("scenarios/demo.json")).unwrap();
    let c = evosim_core::config::Config::from_json(&text).unwrap();
    assert!(c.world.width >= 1 && c.world.height >= 1);
}

//! TASK-022: `evosim run --save/--load` end to end (CONTRACT 2, 5.2, 5.4).
use evosim_core::json::{parse, Value};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

fn tmp(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-ck-{}-{}", std::process::id(), name));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).args(args).env_remove("DISPLAY").output().unwrap()
}

fn p(path: &Path) -> &str {
    path.to_str().unwrap()
}

fn cfg(d: &Path) -> String {
    let path = d.join("c.json");
    std::fs::write(&path, r#"{"seed": 21, "world": {"width": 24, "height": 16}, "initial": {"plants": 150, "herbivores": 40, "carnivores": 8}}"#).unwrap();
    p(&path).to_string()
}

fn run(args: &[&str]) -> Value {
    let o = evosim(&[&["run", "--quiet"], args].concat());
    assert_eq!(o.status.code(), Some(0), "stderr: {}", String::from_utf8_lossy(&o.stderr));
    assert!(o.stdout.is_empty());
    let out = args.iter().position(|a| *a == "--out").map(|i| args[i + 1]).unwrap();
    parse(&std::fs::read_to_string(out).unwrap()).unwrap()
}

fn key(v: &Value, k: &str) -> String {
    v.get(k).unwrap().to_compact()
}

fn series_tail(v: &Value, from: i64) -> Vec<String> {
    match v.get("series") {
        Some(Value::Array(a)) => a.iter().filter(|s| matches!(s.get("tick"), Some(Value::Int(t)) if *t >= from)).map(|s| s.to_compact()).collect(),
        _ => panic!(),
    }
}

fn same_result(full: &Value, part: &Value) {
    for k in ["final", "totals", "state_hash", "tick_end", "seed", "world", "config_hash", "species_ever"] {
        assert_eq!(key(full, k), key(part, k), "{k}");
    }
}

#[test]
fn resume_matches_uninterrupted_at_split_points() {
    let d = tmp("split");
    let c = cfg(&d);
    let total = 200;
    let full = run(&["--config", &c, "--ticks", "200", "--sample-every", "10", "--out", p(&d.join("full.json"))]);
    for split in [0u64, 40, 130, 200] {
        let (a, b) = (d.join(format!("a{split}.json")), d.join(format!("b{split}.json")));
        let ck = d.join(format!("s{split}.ckpt"));
        let s = split.to_string();
        let r = (total - split).to_string();
        run(&["--config", &c, "--ticks", &s, "--out", p(&a), "--save", p(&ck)]);
        let part = run(&["--load", p(&ck), "--ticks", &r, "--sample-every", "10", "--out", p(&b)]);
        assert_eq!(key(&part, "tick_start"), s);
        same_result(&full, &part);
        // the series of the resumed run is the tail of the uninterrupted series
        assert_eq!(series_tail(&full, split as i64), series_tail(&part, split as i64), "split {split}");
    }
    assert!(key(&full, "totals").contains("births"));
}

#[test]
fn chain_of_three_segments_and_resave() {
    let d = tmp("chain");
    let c = cfg(&d);
    let full = run(&["--config", &c, "--ticks", "150", "--out", p(&d.join("full.json"))]);
    let (s1, s2, s3) = (d.join("1.ckpt"), d.join("2.ckpt"), d.join("3.ckpt"));
    run(&["--config", &c, "--ticks", "50", "--out", p(&d.join("o1.json")), "--save", p(&s1)]);
    run(&["--load", p(&s1), "--ticks", "50", "--out", p(&d.join("o2.json")), "--save", p(&s2)]);
    let last = run(&["--load", p(&s2), "--ticks", "50", "--out", p(&d.join("o3.json")), "--save", p(&s3)]);
    same_result(&full, &last);
    assert_eq!(key(&last, "tick_start"), "100");
    // zero further ticks reproduce the loaded state and the same file
    let z = run(&["--load", p(&s3), "--ticks", "0", "--out", p(&d.join("z.json")), "--save", p(&d.join("4.ckpt"))]);
    assert_eq!(key(&z, "state_hash"), key(&full, "state_hash"));
    assert_eq!(std::fs::read(&s3).unwrap(), std::fs::read(d.join("4.ckpt")).unwrap());
}

fn expect_fail(args: &[&str], out: &Path, save: Option<&Path>) -> String {
    let o = evosim(&[&["run", "--out", p(out)], args].concat());
    assert_eq!(o.status.code(), Some(2), "{args:?}");
    assert!(o.stdout.is_empty());
    let e = String::from_utf8_lossy(&o.stderr).to_string();
    assert!(e.starts_with("evosim: "), "{e}");
    assert!(!out.exists(), "result file must not exist for {args:?}");
    if let Some(s) = save {
        assert!(!s.exists(), "save file must not exist for {args:?}");
    }
    let leftovers: Vec<_> = std::fs::read_dir(out.parent().unwrap()).unwrap().filter_map(|e| e.ok()).filter(|e| e.file_name().to_string_lossy().contains(".tmp.")).collect();
    assert!(leftovers.is_empty(), "temporary files left: {leftovers:?}");
    e
}

#[test]
fn damaged_files_give_exit_2_and_no_result() {
    let d = tmp("bad");
    let c = cfg(&d);
    let good = d.join("good.ckpt");
    run(&["--config", &c, "--ticks", "20", "--out", p(&d.join("o.json")), "--save", p(&good)]);
    let bytes = std::fs::read(&good).unwrap();
    let mut files: Vec<(&str, Vec<u8>)> = vec![("empty", vec![]), ("garbage", b"hello world, not a checkpoint at all".to_vec())];
    files.push(("truncated_half", bytes[..bytes.len() / 2].to_vec()));
    files.push(("truncated_one", bytes[..bytes.len() - 1].to_vec()));
    files.push(("header_only", bytes[..20].to_vec()));
    let mut flip = bytes.clone();
    let mid = flip.len() / 2;
    flip[mid] ^= 0x01;
    files.push(("bitflip", flip));
    let mut ver = bytes.clone();
    ver[8..12].copy_from_slice(&2u32.to_le_bytes());
    files.push(("wrong_version", ver));
    let mut extra = bytes.clone();
    extra.extend_from_slice(b"xx");
    files.push(("trailing", extra));
    for (name, data) in &files {
        let f = d.join(format!("{name}.ckpt"));
        std::fs::write(&f, data).unwrap();
        let out = d.join(format!("{name}.out.json"));
        let save = d.join(format!("{name}.save"));
        let e = expect_fail(&["--load", p(&f), "--ticks", "5", "--save", p(&save)], &out, Some(&save));
        if *name == "wrong_version" {
            assert!(e.contains("version"), "{e}");
        }
    }
    // missing file and a directory
    expect_fail(&["--load", p(&d.join("missing.ckpt")), "--ticks", "5"], &d.join("m.json"), None);
    expect_fail(&["--load", p(&d), "--ticks", "5"], &d.join("dir.json"), None);
    // a pre-existing result stays untouched
    let out = d.join("keep.json");
    std::fs::write(&out, "previous").unwrap();
    let o = evosim(&["run", "--load", p(&d.join("bitflip.ckpt")), "--ticks", "5", "--out", p(&out)]);
    assert_eq!(o.status.code(), Some(2));
    assert_eq!(std::fs::read_to_string(&out).unwrap(), "previous");
}

#[test]
fn argument_rules_and_unwritable_save() {
    let d = tmp("args");
    let c = cfg(&d);
    let ck = d.join("a.ckpt");
    run(&["--config", &c, "--ticks", "5", "--out", p(&d.join("o.json")), "--save", p(&ck)]);
    expect_fail(&["--load", p(&ck), "--seed", "3", "--ticks", "1"], &d.join("x1.json"), None);
    expect_fail(&["--load", p(&ck), "--config", &c, "--ticks", "1"], &d.join("x2.json"), None);
    expect_fail(&["--ticks", "1"], &d.join("x3.json"), None);
    let bad_save = d.join("nodir").join("s.ckpt");
    expect_fail(&["--config", &c, "--ticks", "3", "--save", p(&bad_save)], &d.join("x4.json"), Some(&bad_save));
}

//! TASK-021: end-to-end tests of `evosim batch` (CONTRACT section 2, ADR-0025).
use evosim_core::json::{parse, Value};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

fn tmp(name: &str) -> PathBuf {
    let d = std::env::temp_dir().join(format!("evosim-batch-{}-{}", std::process::id(), name));
    let _ = std::fs::remove_dir_all(&d);
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).args(args).env_remove("DISPLAY").env_remove("WAYLAND_DISPLAY").output().unwrap()
}

fn cfg(dir: &Path) -> String {
    let p = dir.join("c.json");
    std::fs::write(&p, r#"{"seed": 1, "world": {"width": 16, "height": 12}, "initial": {"plants": 60, "herbivores": 12, "carnivores": 3}}"#).unwrap();
    p.to_str().unwrap().to_string()
}

fn batch_ok(args: &[&str]) -> Output {
    let mut a = vec!["batch", "--quiet"];
    a.extend_from_slice(args);
    let o = evosim(&a);
    assert_eq!(o.status.code(), Some(0), "stderr: {}", String::from_utf8_lossy(&o.stderr));
    assert!(o.stdout.is_empty());
    o
}

fn read(p: &Path) -> Value {
    parse(&std::fs::read_to_string(p).unwrap()).unwrap()
}

fn strip(v: &Value) -> Value {
    match v {
        Value::Object(items) => Value::Object(items.iter().filter(|(k, _)| k != "elapsed_seconds" && k != "ticks_per_second").map(|(k, v)| (k.clone(), strip(v))).collect()),
        Value::Array(a) => Value::Array(a.iter().map(strip).collect()),
        o => o.clone(),
    }
}

fn int(v: &Value, path: &[&str]) -> i64 {
    let mut c = v;
    for k in path {
        c = c.get(k).unwrap_or_else(|| panic!("missing {path:?}"));
    }
    match c {
        Value::Int(i) => *i,
        o => panic!("{path:?} is {}", o.type_name()),
    }
}

fn num(v: &Value) -> f64 {
    match v {
        Value::Int(i) => *i as f64,
        Value::Float(f) => *f,
        _ => panic!(),
    }
}

fn arr(v: &Value) -> &Vec<Value> {
    match v {
        Value::Array(a) => a,
        _ => panic!("not an array"),
    }
}

const K: [&str; 3] = ["plants", "herbivores", "carnivores"];

#[test]
fn matrix_two_values_two_seeds() {
    let d = tmp("matrix");
    let c = cfg(&d);
    let out = d.join("out");
    batch_ok(&["--config", &c, "--seeds", "1,2", "--ticks", "80", "--out-dir", out.to_str().unwrap(), "--param", "initial.carnivores=0,5"]);
    let s = read(&out.join("summary.json"));
    assert_eq!(int(&s, &["run_count"]), 4);
    let runs = arr(s.get("runs").unwrap());
    assert_eq!(runs.len(), 4);
    let expect = [(1, 0), (2, 0), (1, 5), (2, 5)];
    for (r, (seed, carn)) in runs.iter().zip(expect) {
        assert_eq!(int(r, &["seed"]), seed);
        assert_eq!(int(r, &["params", "initial.carnivores"]), carn);
        assert_eq!(int(r, &["ticks"]), 80);
        let file = match r.get("file").unwrap() {
            Value::Str(f) => f.clone(),
            _ => panic!(),
        };
        assert_eq!(file, format!("initial.carnivores={carn}/seed-{seed}.json"));
        let sf = read(&out.join(&file));
        assert_eq!(int(&sf, &["seed"]), seed);
        assert_eq!(int(&sf, &["tick_end"]), 80);
        for k in K {
            assert_eq!(int(&sf, &["final", k]), int(r, &["final", k]));
        }
    }
    // Aggregates recomputed from the seed files.
    let agg = s.get("aggregate").unwrap();
    for k in K {
        let xs: Vec<i64> = runs.iter().map(|r| int(r, &["final", k])).collect();
        let mean = xs.iter().sum::<i64>() as f64 / 4.0;
        assert_eq!(num(agg.get("final").unwrap().get(k).unwrap().get("mean").unwrap()), mean);
        assert_eq!(int(agg, &["final", k, "min"]), *xs.iter().min().unwrap());
        assert_eq!(int(agg, &["final", k, "max"]), *xs.iter().max().unwrap());
        assert_eq!(int(agg, &["extinct_count", k]), xs.iter().filter(|&&x| x == 0).count() as i64);
    }
    // Zero initial carnivores: extinct in both runs of that group, regardless of seed.
    let groups = arr(s.get("groups").unwrap());
    assert_eq!(groups.len(), 2);
    assert_eq!(int(&groups[0], &["extinct_count", "carnivores"]), 2);
    assert_eq!(int(&groups[0], &["runs"]), 2);
    assert_eq!(int(&groups[0], &["params", "initial.carnivores"]), 0);
    assert_eq!(int(&groups[1], &["params", "initial.carnivores"]), 5);
    assert_eq!(int(&groups[1], &["final", "carnivores", "max"]), runs[2..].iter().map(|r| int(r, &["final", "carnivores"])).max().unwrap());
    assert!(int(agg, &["extinct_count", "carnivores"]) >= 2);
    // CSV exports.
    let csv = std::fs::read_to_string(out.join("summary.csv")).unwrap();
    let lines: Vec<&str> = csv.lines().collect();
    assert_eq!(lines.len(), 5);
    assert_eq!(lines[0].split(',').take(3).collect::<Vec<_>>(), ["index", "seed", "initial.carnivores"]);
    for (i, r) in runs.iter().enumerate() {
        let f: Vec<&str> = lines[i + 1].split(',').collect();
        assert_eq!(f[1], int(r, &["seed"]).to_string());
        assert_eq!(f[2], int(r, &["params", "initial.carnivores"]).to_string());
        assert_eq!(f[5], int(r, &["final", "plants"]).to_string());
        assert_eq!(f[7], int(r, &["final", "carnivores"]).to_string());
    }
    let ag = std::fs::read_to_string(out.join("aggregates.csv")).unwrap();
    assert_eq!(ag.lines().count(), 1 + 2 * 3);
    let first: Vec<&str> = ag.lines().nth(3).unwrap().split(',').collect();
    assert_eq!((first[0], first[1], first[2]), ("0", "carnivores", "2"));
    assert_eq!(first[8], "2");
}

#[test]
fn no_sweep_layout_matches_run() {
    let d = tmp("plain");
    let c = cfg(&d);
    let out = d.join("o");
    batch_ok(&["--config", &c, "--seeds", "3..4", "--ticks", "60", "--out-dir", out.to_str().unwrap()]);
    let s = read(&out.join("summary.json"));
    assert_eq!(arr(s.get("groups").unwrap()).len(), 1);
    for seed in [3, 4] {
        let single = d.join(format!("run{seed}.json"));
        let o = evosim(&["run", "--config", &c, "--seed", &seed.to_string(), "--ticks", "60", "--out", single.to_str().unwrap(), "--quiet"]);
        assert_eq!(o.status.code(), Some(0));
        let a = read(&out.join(format!("seed-{seed}.json")));
        let b = read(&single);
        assert_eq!(strip(&a), strip(&b), "seed file must equal `run` output");
    }
    let runs = arr(s.get("runs").unwrap());
    assert_eq!(int(&runs[0], &["seed"]), 3);
    assert_eq!(int(&runs[1], &["seed"]), 4);
}

#[test]
fn deterministic_across_repeats_and_job_counts() {
    let d = tmp("det");
    let c = cfg(&d);
    let mut sums = Vec::new();
    let mut csvs = Vec::new();
    for (name, jobs) in [("a", "1"), ("b", "1"), ("c", "4")] {
        let out = d.join(name);
        batch_ok(&["--config", &c, "--seeds", "1,2,3", "--ticks", "70", "--out-dir", out.to_str().unwrap(), "--param", "plants.growth_rate=0.5,1.5", "--jobs", jobs]);
        sums.push(strip(&read(&out.join("summary.json"))).to_pretty());
        let csv = std::fs::read_to_string(out.join("summary.csv")).unwrap();
        csvs.push(csv.lines().map(|l| l.rsplitn(3, ',').last().unwrap().to_string()).collect::<Vec<_>>());
    }
    assert_eq!(sums[0], sums[1]);
    assert_eq!(sums[0], sums[2]);
    assert_eq!(csvs[0], csvs[1]);
    assert_eq!(csvs[0], csvs[2]);
    let s = parse(&sums[0]).unwrap();
    assert_eq!(int(&s, &["run_count"]), 6);
    // different seeds give different hashes
    let runs = arr(s.get("runs").unwrap());
    let h = |i: usize| runs[i].get("state_hash").unwrap().to_compact();
    assert_ne!(h(0), h(1));
}

#[test]
fn errors_exit_2_and_write_nothing() {
    let d = tmp("err");
    let c = cfg(&d);
    let out = d.join("o");
    let o = out.to_str().unwrap();
    let base = ["--config", c.as_str(), "--seeds", "1,2", "--ticks", "5", "--out-dir", o];
    let cases: Vec<Vec<&str>> = vec![
        vec!["--seeds", "1", "--ticks", "5", "--out-dir", o],
        vec!["--config", &c, "--ticks", "5", "--out-dir", o],
        vec!["--config", &c, "--seeds", "1", "--out-dir", o],
        vec!["--config", &c, "--seeds", "1", "--ticks", "5"],
        vec!["--config", &c, "--seeds", "", "--ticks", "5", "--out-dir", o],
        vec!["--config", &c, "--seeds", "1,1", "--ticks", "5", "--out-dir", o],
        vec!["--config", &c, "--seeds", "x", "--ticks", "5", "--out-dir", o],
        vec!["--config", "/nonexistent.json", "--seeds", "1", "--ticks", "5", "--out-dir", o],
        vec!["--config", &c, "--seeds", "1", "--ticks", "-5", "--out-dir", o],
    ];
    for case in cases {
        let mut a = vec!["batch"];
        a.extend(case.iter());
        let r = evosim(&a);
        assert_eq!(r.status.code(), Some(2), "{case:?}");
        assert!(r.stdout.is_empty());
        assert!(!r.stderr.is_empty());
    }
    let extras: Vec<Vec<&str>> = vec![
        vec!["--bogus", "1"],
        vec!["--ticks", "6"],
        vec!["--param", "nope.x=1"],
        vec!["--param", "initial.herbivores=a"],
        vec!["--param", "initial.herbivores=1.5"],
        vec!["--param", "initial.herbivores=-3,4"],
        vec!["--param", "plants.growth_rate=1e9"],
        vec!["--param", "seed=1,2"],
        vec!["--param", "initial.herbivores=1,2", "--param", "initial.herbivores=3"],
        vec!["--jobs", "0"],
        vec!["--sample-every", "0"],
        vec!["stray"],
    ];
    for extra in extras {
        let mut a = vec!["batch"];
        a.extend(base.iter());
        a.extend(extra.iter());
        let r = evosim(&a);
        assert_eq!(r.status.code(), Some(2), "{extra:?}: {}", String::from_utf8_lossy(&r.stderr));
        assert!(r.stdout.is_empty(), "{extra:?}");
        assert!(!out.join("summary.json").exists(), "{extra:?}");
        assert!(!out.join("seed-1.json").exists(), "{extra:?}");
    }
}

#[test]
fn bool_float_sweep_and_zero_ticks() {
    let d = tmp("misc");
    let c = cfg(&d);
    let out = d.join("o");
    batch_ok(&["--config", &c, "--seeds", "5", "--ticks", "0", "--out-dir", out.to_str().unwrap(), "--param", "initial.plants=10,20"]);
    let s = read(&out.join("summary.json"));
    let runs = arr(s.get("runs").unwrap());
    assert_eq!(int(&runs[0], &["final", "plants"]), 10);
    assert_eq!(int(&runs[1], &["final", "plants"]), 20);
    assert_eq!(int(&runs[0], &["tick_end"]), 0);
}

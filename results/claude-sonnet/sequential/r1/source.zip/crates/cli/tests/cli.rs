use std::process::{Command, Output};

fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim")).args(args).output().unwrap()
}

#[test]
fn version_prints_contract_json() {
    let o = evosim(&["version"]);
    assert_eq!(o.status.code(), Some(0));
    let s = String::from_utf8(o.stdout).unwrap();
    assert_eq!(s, "{\"name\":\"evosim\",\"version\":\"0.1.0\",\"contract\":1}\n");
}

#[test]
fn help_lists_commands() {
    for flag in ["--help", "-h", "help"] {
        let o = evosim(&[flag]);
        assert_eq!(o.status.code(), Some(0));
        let s = String::from_utf8(o.stdout).unwrap();
        for c in ["version", "run", "batch", "ui"] {
            assert!(s.contains(c), "{flag}: missing {c}");
        }
    }
}

#[test]
fn unknown_command_exits_2() {
    let o = evosim(&["bogus"]);
    assert_eq!(o.status.code(), Some(2));
    assert!(o.stdout.is_empty());
    assert!(!o.stderr.is_empty());
}

#[test]
fn no_args_and_bad_version_args_exit_2() {
    assert_eq!(evosim(&[]).status.code(), Some(2));
    assert_eq!(evosim(&["version", "extra"]).status.code(), Some(2));
}

#[test]
fn bare_run_and_batch_exit_2() {
    // `ui` is a real server now: a bare `evosim ui` never exits, so only a
    // bad argument is tested for it (never start a long-lived UI here).
    for c in ["run", "batch"] {
        assert_eq!(evosim(&[c]).status.code(), Some(2));
    }
    assert_eq!(evosim(&["ui", "--bogus"]).status.code(), Some(2));
}

#[test]
fn works_from_other_cwd() {
    let o = Command::new(env!("CARGO_BIN_EXE_evosim"))
        .arg("version")
        .current_dir("/")
        .output()
        .unwrap();
    assert_eq!(o.status.code(), Some(0));
}

//! `evosim` command line entry point.
use std::io::Write;

const USAGE: &str = "Usage: evosim <command> [options]

Commands:
  version   Print name, version and contract number as JSON
  run       Run a headless simulation and write the result JSON
  batch     Run a configuration for several seeds / parameter values and summarize
  ui        Start the user interface (local web server + browser page)
  help      Show this help

run options: (--config FILE [--seed N] | --load FILE) --ticks N --out FILE [--sample-every K] [--save FILE] [--metrics FILE] [--quiet]

batch options: --config FILE --seeds 1,2,5..8 --ticks N --out-dir DIR [--param PATH=V1,V2]... [--sample-every K] [--jobs J] [--quiet]

ui options: [--config FILE] [--port N] [--no-open] [--ticks-per-second T] | --smoke-test | --screenshots DIR

Exit status: 0 success, 2 invalid usage/configuration.
";

fn run(args: &[String]) -> i32 {
    let Some(cmd) = args.first() else {
        eprint!("{USAGE}");
        return 2;
    };
    match cmd.as_str() {
        "--help" | "-h" | "help" => {
            print!("{USAGE}");
            let _ = std::io::stdout().flush();
            0
        }
        "version" => {
            if args.len() > 1 {
                eprintln!("evosim: version takes no arguments");
                return 2;
            }
            println!("{}", evosim_core::version_json());
            0
        }
        "run" => evosim_runner::run_command(&args[1..]),
        "batch" => evosim_runner::batch_command(&args[1..]),
        "ui" => evosim_ui::ui_command(&args[1..]),
        other => {
            eprintln!("evosim: unknown command '{other}'\n");
            eprint!("{USAGE}");
            2
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    std::process::exit(run(&args));
}

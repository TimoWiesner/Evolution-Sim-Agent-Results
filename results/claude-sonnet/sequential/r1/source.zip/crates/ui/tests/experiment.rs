//! Setup/validation/import-export tests (TASK-025): no display, no HTTP.
use evosim_core::config::{Config, PRESET_NAMES};
use evosim_core::sim::Simulation;
use evosim_ui::experiment::*;
use evosim_ui::session::Session;

fn edit(c: &Config, changes: &[(&str, &str)]) -> Vec<(String, String)> {
    let mut v = values(c);
    for (k, t) in changes {
        v.iter_mut().find(|(p, _)| p == k).unwrap_or_else(|| panic!("no field {k}")).1 = t.to_string();
    }
    v
}

fn err_paths(r: Result<Config, Vec<FieldError>>) -> Vec<String> {
    r.unwrap_err().into_iter().map(|e| e.path).collect()
}

#[test]
fn presets_have_cards_and_round_trip() {
    assert_eq!(PRESETS.len(), PRESET_NAMES.len());
    for n in PRESET_NAMES {
        assert!(PRESETS.iter().any(|(p, d)| *p == n && !d.is_empty()), "card for {n}");
    }
    for (n, _) in PRESETS {
        let c = Config::preset(n).unwrap();
        assert_eq!(build(&values(&c)).unwrap(), c, "values -> build for {n}");
        let text = export(&c);
        let back = import(&text).unwrap();
        assert_eq!(back, c);
        assert_eq!(export(&back), text, "byte-identical text for {n}");
    }
    assert!(core_preset_names().len() == 5);
}

#[test]
fn edited_config_exports_and_imports_identically() {
    let base = Config::default();
    let c = build(&edit(
        &base,
        &[
            ("seed", "-12345"),
            ("world.width", "80"),
            ("world.height", "60"),
            ("initial.plants", "321"),
            ("initial.herbivores", "77"),
            ("initial.carnivores", "9"),
            ("climate.equator_temp", "31.25"),
            ("climate.precip_mean", "0.8123456789"),
            ("plants.growth_rate", "1.3"),
            ("herbivores.max_age", "777"),
            ("carnivores.speed", "1.7"),
            ("genetics.mutation_sigma", "0.0123"),
        ],
    ))
    .unwrap();
    assert_eq!((c.seed, c.world.width, c.world.height, c.initial.plants), (-12345, 80, 60, 321));
    let text = export(&c);
    let back = import(&text).unwrap();
    assert_eq!(back, c);
    assert_eq!(export(&back), text);
    // through the form text as well
    assert_eq!(build(&values(&back)).unwrap(), c);
    // the file is accepted by the engine
    assert!(Simulation::new(&back).is_ok());
}

#[test]
fn import_errors_name_the_key() {
    let mut t = export(&Config::default());
    t = t.replace("\"width\"", "\"widht\"");
    let e = import(&t).unwrap_err();
    assert!(e[0].message.contains("widht"), "{:?}", e);
    let t2 = export(&Config::default()).replace("\"seed\": 42", "\"seed\": \"x\"");
    assert_eq!(import(&t2).unwrap_err()[0].path, "seed");
    assert!(import("not json").is_err());
    assert!(import("").is_err());
}

#[test]
fn field_errors_are_per_field_and_all_reported() {
    let c = Config::default();
    for (k, t) in [("world.width", "0"), ("world.width", "abc"), ("world.width", "1.5"), ("seed", ""), ("plants.growth_rate", "-1"), ("plants.growth_rate", "nan"), ("plants.growth_rate", "1e999")] {
        let p = err_paths(build(&edit(&c, &[(k, t)])));
        assert_eq!(p, vec![k.to_string()], "{k}={t:?}");
    }
    let r = build(&edit(&c, &[("world.width", "0"), ("seed", "x"), ("plants.growth_rate", "-1")]));
    let mut p = err_paths(r);
    p.sort();
    assert_eq!(p, vec!["plants.growth_rate", "seed", "world.width"]);
    let mut v = values(&c);
    v.push(("nope.key".into(), "1".into()));
    assert_eq!(err_paths(build(&v)), vec!["nope.key"]);
    let e = build(&edit(&c, &[("world.width", "0")])).unwrap_err();
    assert!(e[0].message.contains("between"), "{}", e[0].message);
}

#[test]
fn cross_field_error_maps_to_a_field() {
    let c = Config::default();
    let p = err_paths(build(&edit(&c, &[("climate.pole_temp", "30"), ("climate.equator_temp", "10")])));
    assert_eq!(p, vec!["climate.pole_temp"]);
}

#[test]
fn ui_size_guard() {
    let c = Config::default();
    let p = err_paths(build(&edit(&c, &[("world.width", "2000"), ("world.height", "2000")])));
    assert_eq!(p, vec!["world.width"]);
    let p = err_paths(build(&edit(&c, &[("initial.plants", "190000"), ("initial.herbivores", "20000")])));
    assert_eq!(p, vec!["initial.plants"]);
}

#[test]
fn errors_and_values_json_parse() {
    let e = build(&edit(&Config::default(), &[("world.width", "0")])).unwrap_err();
    let v = evosim_core::json::parse(&errors_json(&e)).unwrap();
    assert_eq!(v.get("ok"), Some(&evosim_core::json::Value::Bool(false)));
    let s = evosim_core::json::parse(&setup_json(&Config::default())).unwrap();
    match s.get("params") {
        Some(evosim_core::json::Value::Array(a)) => assert!(a.len() >= 70, "{}", a.len()),
        _ => panic!(),
    }
    match s.get("presets") {
        Some(evosim_core::json::Value::Array(a)) => assert_eq!(a.len(), 5),
        _ => panic!(),
    }
    let edits = edits_from_body("{\"values\":{\"seed\":\"7\",\"world.width\":64,\"x\":true}}").unwrap();
    assert_eq!(edits.len(), 3);
    assert!(edits_from_body("[1]").is_err());
}

#[test]
fn new_world_starts_only_with_valid_config() {
    let mut s = Session::new(&Config::default(), false).unwrap();
    s.step(7);
    let (tick, hash, epoch) = (s.sim.tick, s.sim.state_hash(), s.epoch);
    // an invalid form never produces a config, so new_world cannot be reached
    assert!(build(&edit(&Config::default(), &[("world.width", "0")])).is_err());
    assert_eq!((s.sim.tick, s.sim.state_hash(), s.epoch), (tick, hash.clone(), epoch));
    // an invalid config handed to new_world directly leaves the world unchanged
    let mut bad = Config::default();
    bad.world.width = 0;
    assert!(s.new_world(&bad).is_err());
    assert_eq!((s.sim.tick, s.sim.state_hash(), s.epoch), (tick, hash.clone(), epoch));
    assert!(!s.running);
}

#[test]
fn edits_change_the_world() {
    let base = Config::default();
    let mut b = Simulation::new(&base).unwrap();
    for _ in 0..60 {
        b.step();
    }
    let base_hash = b.state_hash();
    let changes: &[(&str, &str)] = &[
        ("seed", "43"),
        ("world.width", "50"),
        ("initial.plants", "123"),
        ("initial.herbivores", "33"),
        ("initial.carnivores", "4"),
        ("climate.equator_temp", "28.5"),
        ("climate.precip_mean", "0.9"),
        ("plants.growth_rate", "1.9"),
        ("herbivores.max_age", "555"),
        ("carnivores.speed", "1.9"),
        ("genetics.mutation_sigma", "0.07"),
    ];
    for (k, t) in changes {
        let c = build(&edit(&base, &[(k, t)])).unwrap();
        let mut s = Session::new(&Config::default(), false).unwrap();
        s.step(3);
        s.new_world(&c).unwrap();
        s.advance(60);
        assert_eq!(s.config, c);
        assert!(s.running && s.epoch == 1 && s.history.samples().len() >= 12, "{k}");
        let mut plain = Simulation::new(&c).unwrap();
        for _ in 0..60 {
            plain.step();
        }
        assert_eq!(s.sim.state_hash(), plain.state_hash(), "same engine for {k}");
        assert_ne!(s.sim.state_hash(), base_hash, "{k}={t} changes the world");
    }
    let c = build(&edit(&base, &[("world.width", "50"), ("world.height", "40"), ("initial.plants", "123"), ("initial.herbivores", "33"), ("initial.carnivores", "4")])).unwrap();
    let s = Simulation::new(&c).unwrap();
    assert_eq!(s.world.climate.width, 50);
    assert_eq!(s.world.climate.height, 40);
    assert_eq!([s.organisms.plants.len(), s.organisms.herbivores.len(), s.organisms.carnivores.len()], [123, 33, 4]);
}

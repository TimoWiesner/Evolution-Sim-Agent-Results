//! Display-free tests of the UI control logic (ADR-0028): no HTTP, no threads, no browser.
use evosim_core::config::Config;
use evosim_core::json::Value;
use evosim_core::sim::Simulation;
use evosim_ui::session::*;

fn cfg() -> Config {
    let mut c = Config::default();
    c.initial.plants = 300;
    c.initial.herbivores = 40;
    c.initial.carnivores = 8;
    c
}

trait J {
    fn as_f64(&self) -> Option<f64>;
    fn as_str(&self) -> Option<&str>;
    fn as_bool(&self) -> Option<bool>;
    fn as_array(&self) -> Option<&Vec<Value>>;
}
impl J for Value {
    fn as_f64(&self) -> Option<f64> {
        match self {
            Value::Int(i) => Some(*i as f64),
            Value::Float(f) => Some(*f),
            _ => None,
        }
    }
    fn as_str(&self) -> Option<&str> {
        if let Value::Str(s) = self { Some(s) } else { None }
    }
    fn as_bool(&self) -> Option<bool> {
        if let Value::Bool(b) = self { Some(*b) } else { None }
    }
    fn as_array(&self) -> Option<&Vec<Value>> {
        if let Value::Array(a) = self { Some(a) } else { None }
    }
}

fn tmp(name: &str) -> String {
    std::env::temp_dir().join(format!("evosim-sess-{}-{}", std::process::id(), name)).to_string_lossy().into_owned()
}

#[test]
fn step_advances_exactly_one_tick() {
    let mut s = Session::new(&cfg(), true).unwrap();
    assert_eq!(s.tick(), 0);
    s.step(1);
    assert_eq!(s.tick(), 1);
    assert!(!s.running, "step pauses");
    s.step(1);
    assert_eq!(s.tick(), 2);
    s.step(3);
    assert_eq!(s.tick(), 5);
    s.step(0); // n < 1 is treated as one step
    assert_eq!(s.tick(), 6);
}

#[test]
fn run_pause_toggle() {
    let mut s = Session::new(&cfg(), false).unwrap();
    assert!(!s.running);
    s.run();
    assert!(s.running);
    s.pause();
    assert!(!s.running);
    s.toggle();
    assert!(s.running);
    s.toggle();
    assert!(!s.running);
}

#[test]
fn session_matches_plain_simulation() {
    let c = cfg();
    let mut s = Session::new(&c, false).unwrap();
    s.step(20);
    s.select_at(5, 5, 50);
    s.step(5);
    let mut p = Simulation::new(&c).unwrap();
    for _ in 0..25 {
        p.step();
    }
    assert_eq!(s.sim.state_hash(), p.state_hash(), "selection and inspection are hash-neutral");
}

#[test]
fn reset_restores_the_initial_world() {
    let c = cfg();
    let mut s = Session::new(&c, true).unwrap();
    let h0 = s.sim.state_hash();
    s.step(50);
    assert_ne!(s.sim.state_hash(), h0);
    s.select_at(1, 1, 64);
    s.set_speed_level(4);
    s.run();
    s.reset().unwrap();
    assert_eq!(s.tick(), 0);
    assert_eq!(s.sim.state_hash(), h0, "same configuration and seed give the same starting world");
    assert!(!s.running && s.selected.is_none());
    assert_eq!(s.speed_level(), 4, "speed is kept");
    assert_eq!(s.epoch, 1);
    // and again after more ticks
    s.step(7);
    s.reset().unwrap();
    assert_eq!(s.sim.state_hash(), h0);
    assert_eq!(Session::new(&c, false).unwrap().sim.state_hash(), h0);
}

#[test]
fn speed_has_levels_and_is_never_non_positive() {
    assert!(SPEED_LEVELS.len() >= 3);
    assert!(SPEED_LEVELS.windows(2).all(|w| w[0] < w[1]));
    let mut s = Session::new(&cfg(), false).unwrap();
    for i in [-1_000_000_000i64, -5, -1, 0, 1, 2, 3, 4, 5, 99, i64::MAX, i64::MIN] {
        s.set_speed_level(i);
        assert!(s.tps() > 0.0 && s.speed_level() < SPEED_LEVELS.len(), "level {i}");
    }
    s.set_speed_level(0);
    s.slower();
    s.slower();
    assert_eq!((s.speed_level(), s.tps()), (0, SPEED_LEVELS[0]));
    for _ in 0..20 {
        s.faster();
    }
    assert_eq!(s.speed_level(), SPEED_LEVELS.len() - 1);
    for t in [-5.0, 0.0, -0.0, 1e-9, f64::NEG_INFINITY, f64::INFINITY, 1e12] {
        assert!(s.set_tps(t));
        assert!(s.tps() > 0.0 && s.tps().is_finite(), "tps {t}");
    }
    let before = s.tps();
    assert!(!s.set_tps(f64::NAN));
    assert_eq!(s.tps(), before);
}

fn first_animal(s: &Session) -> (u64, i32, i32) {
    let o = s.sim.organisms.herbivores.iter().find(|o| o.alive).unwrap();
    (o.id, o.pos.x, o.pos.y)
}

#[test]
fn select_by_id_and_by_cell() {
    let mut s = Session::new(&cfg(), false).unwrap();
    s.step(3);
    let (id, x, y) = first_animal(&s);
    assert!(s.select_id(id));
    assert_eq!(s.selected.as_ref().unwrap().id, id);
    s.deselect();
    assert!(s.selected.is_none());
    // by cell: an animal wins over plants on the same cell; wrapped coordinates select the same organism
    let picked = s.pick(x as i64, y as i64, 0).unwrap();
    let po = s.sim.organisms.find(picked).unwrap();
    assert!(po.pos.x == x && po.pos.y == y);
    let (w, h) = (s.sim.world.climate.width as i64, s.sim.world.climate.height as i64);
    assert_eq!(s.pick(x as i64 + w, y as i64 - h, 0), Some(picked));
    assert_eq!(s.pick(x as i64, y as i64, 0), s.pick(x as i64, y as i64, 0), "deterministic");
    if s.sim.organisms.get(evosim_core::organism::Kind::Herbivore, picked).is_some() || s.sim.organisms.get(evosim_core::organism::Kind::Carnivore, picked).is_some() {
        // animal chosen when present
    } else {
        assert!(!s.sim.organisms.herbivores.iter().any(|o| o.alive && o.pos.x == x && o.pos.y == y));
    }
    assert!(s.select_at(x as i64, y as i64, 0).is_some());
    // unknown id leaves the selection unchanged
    let keep = s.selected.as_ref().unwrap().id;
    assert!(!s.select_id(u64::MAX));
    assert_eq!(s.selected.as_ref().unwrap().id, keep);
}

#[test]
fn inspector_json_has_all_required_fields() {
    let mut s = Session::new(&cfg(), false).unwrap();
    s.step(30);
    // choose an organism with parents if there is one, else any
    let id = s.sim.organisms.herbivores.iter().find(|o| o.alive && o.parents[0] != 0).map(|o| o.id).unwrap_or_else(|| first_animal(&s).0);
    assert!(s.select_id(id));
    let j = s.inspect_json().unwrap();
    let v = evosim_core::json::parse(&j).expect("valid JSON");
    let get = |k: &str| v.get(k).unwrap_or_else(|| panic!("missing {k} in {j}"));
    assert_eq!(get("id").as_f64().unwrap() as u64, id);
    assert_eq!(get("kind").as_str().unwrap(), "herbivore");
    assert_eq!(get("alive").as_bool(), Some(true));
    for k in ["age", "energy", "health", "max_lifespan", "max_energy", "max_health", "generation", "birth_tick", "pos", "species", "parents"] {
        get(k);
    }
    assert!(get("species").get("name").unwrap().as_str().unwrap().len() > 1, "species name");
    assert!(get("species").get("id").unwrap().as_f64().unwrap() >= 1.0);
    let traits = get("traits");
    for k in ["speed", "strength", "fertility", "max_health", "max_lifespan", "max_energy", "metabolism", "vision", "aggression", "risk_tolerance"] {
        assert!(traits.get(k).unwrap().as_f64().unwrap().is_finite(), "{k}");
    }
    let genes = get("genes").as_array().unwrap();
    assert_eq!(genes.len(), 10);
    for g in genes {
        let (a0, a1) = (g.get("a0").unwrap().as_f64().unwrap(), g.get("a1").unwrap().as_f64().unwrap());
        assert!((0.0..=1.0).contains(&a0) && (0.0..=1.0).contains(&a1));
        g.get("name").unwrap().as_str().unwrap();
    }
    assert!(s.sim.organisms.find(id).unwrap().parents.iter().filter(|p| **p != 0).count() == get("parents").as_array().unwrap().len());
}

#[test]
fn inspector_follows_the_organism_and_marks_death() {
    let mut c = cfg();
    c.initial.carnivores = 0;
    let mut s = Session::new(&c, false).unwrap();
    let (id, _, _) = first_animal(&s);
    assert!(s.select_id(id));
    let age0 = s.selected.as_ref().unwrap().view.age;
    s.step(5);
    let t = s.selected.as_ref().unwrap();
    assert!(t.alive);
    assert_eq!(t.view.age, age0 + 5, "age follows the organism");
    // kill it: mark dead, step, the Deaths phase removes it
    let tick = s.sim.tick;
    s.sim.organisms.mark_dead(id, evosim_core::organism::DeathCause::Starvation, tick);
    s.step(1);
    let t = s.selected.as_ref().unwrap();
    assert!(!t.alive, "death detected");
    assert!(t.died_tick.is_some());
    let last_age = t.view.age;
    let j = s.inspect_json().unwrap();
    assert!(j.contains("\"alive\":false") && j.contains(&format!("\"id\":{id},")));
    s.step(3);
    assert_eq!(s.selected.as_ref().unwrap().view.age, last_age, "last values are kept");
    assert!(!s.select_id(id), "a dead organism cannot be selected again");
}

#[test]
fn checkpoint_roundtrip_and_failures() {
    let c = cfg();
    let mut s = Session::new(&c, false).unwrap();
    s.step(40);
    let p = tmp("a.ckpt");
    let n = s.save_checkpoint(&p).unwrap();
    assert!(n > 100);
    let h = s.sim.state_hash();
    s.step(10);
    assert_ne!(s.sim.state_hash(), h);
    s.select_at(3, 3, 64);
    s.load_checkpoint(&p).unwrap();
    assert_eq!(s.sim.state_hash(), h, "load restores the saved state");
    assert_eq!(s.tick(), 40);
    assert!(s.selected.is_none() && !s.running);
    // the loaded simulation continues like an uninterrupted one
    let mut plain = Simulation::new(&c).unwrap();
    for _ in 0..45 {
        plain.step();
    }
    s.step(5);
    assert_eq!(s.sim.state_hash(), plain.state_hash());
    // errors leave everything untouched
    let before = s.sim.state_hash();
    let tick = s.tick();
    assert!(s.load_checkpoint(&tmp("missing.ckpt")).is_err());
    std::fs::write(tmp("bad.ckpt"), b"not a checkpoint").unwrap();
    assert!(s.load_checkpoint(&tmp("bad.ckpt")).is_err());
    assert!(s.load_checkpoint("").is_err());
    assert!(s.load_checkpoint(std::env::temp_dir().to_str().unwrap()).is_err());
    assert!(s.save_checkpoint("").is_err());
    assert!(s.save_checkpoint(std::env::temp_dir().to_str().unwrap()).is_err());
    assert_eq!((s.sim.state_hash(), s.tick()), (before, tick));
    let _ = std::fs::remove_file(p);
    let _ = std::fs::remove_file(tmp("bad.ckpt"));
}

#[test]
fn load_replaces_the_reset_target() {
    let mut other = cfg();
    other.seed = 777;
    let mut a = Session::new(&other, false).unwrap();
    a.step(5);
    let p = tmp("other.ckpt");
    a.save_checkpoint(&p).unwrap();
    let h_other0 = Session::new(&other, false).unwrap().sim.state_hash();
    let mut s = Session::new(&cfg(), false).unwrap();
    s.load_checkpoint(&p).unwrap();
    assert_eq!(s.config.seed, 777);
    s.reset().unwrap();
    assert_eq!(s.sim.state_hash(), h_other0, "reset rebuilds the checkpoint's configuration");
    let _ = std::fs::remove_file(p);
}

//! Chart-data tests (TASK-025): history recorder and histogram, no display.
use evosim_core::config::Config;
use evosim_core::json::{self, Value};
use evosim_core::metrics::{trait_values, TRAIT_NAMES};
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;
use evosim_ui::charts::*;
use evosim_ui::session::Session;

fn small() -> Config {
    let mut c = Config::default();
    c.initial.plants = 300;
    c.initial.herbivores = 60;
    c.initial.carnivores = 10;
    c
}

#[test]
fn samples_follow_the_interval_and_match_the_simulation() {
    let mut sim = Simulation::new(&small()).unwrap();
    let mut h = History::new();
    h.observe(&sim);
    let mut births = [0u64; 3];
    let b0 = sim.organisms.stats.births;
    for _ in 0..100 {
        sim.step();
        h.observe(&sim);
        if sim.tick % 5 == 0 {
            let s = h.samples().last().unwrap();
            assert_eq!(s.tick, sim.tick);
            for k in Kind::ALL {
                let i = k.index();
                assert_eq!(s.pop[i] as usize, sim.organisms.vec(k).len());
                assert_eq!(s.species[i] as usize, sim.living_species(k));
                let orgs = sim.organisms.vec(k);
                if orgs.is_empty() {
                    assert!(s.mean[i].iter().all(|m| m.is_none()));
                } else {
                    for t in 0..10 {
                        let m: f64 = orgs.iter().map(|o| trait_values(&o.traits)[t]).sum::<f64>() / orgs.len() as f64;
                        assert_eq!(s.mean[i][t], Some(m));
                    }
                }
            }
        }
    }
    assert_eq!(h.samples().len(), 21);
    assert_eq!(h.samples()[0].tick, 0);
    for s in h.samples() {
        for i in 0..3 {
            births[i] += s.births[i];
        }
    }
    let st = &sim.organisms.stats;
    for i in 0..3 {
        assert_eq!(births[i], st.births[i] - b0[i]);
    }
    let deaths: u64 = h.samples().iter().map(|s| s.deaths.iter().sum::<u64>()).sum();
    assert_eq!(deaths, st.deaths.iter().sum::<u64>());
    assert!(births.iter().sum::<u64>() > 0);
}

#[test]
fn decimation_bounds_samples_and_keeps_totals() {
    let mut c = small();
    c.initial.plants = 100;
    let mut sim = Simulation::new(&c).unwrap();
    let mut h = History::with_max(40);
    h.observe(&sim);
    let b0 = sim.organisms.stats.births;
    for _ in 0..900 {
        sim.step();
        h.observe(&sim);
    }
    assert!(h.samples().len() <= 40, "{}", h.samples().len());
    assert!(h.interval() > BASE_INTERVAL);
    let total: u64 = h.samples().iter().map(|s| s.births.iter().sum::<u64>()).sum();
    let t2 = sim.organisms.stats.births.iter().sum::<u64>() - b0.iter().sum::<u64>();
    // everything up to the last sample is counted exactly
    assert!(total <= t2 && total > 0);
    let last = h.samples().last().unwrap().tick;
    // the births up to the last sample are exact: compare with a plain run to that tick
    let mut again = Simulation::new(&c).unwrap();
    while again.tick < last {
        again.step();
    }
    assert_eq!(total, again.organisms.stats.births.iter().sum::<u64>() - b0.iter().sum::<u64>());
    assert_eq!(MAX_SAMPLES, 1000);
    assert!(h.samples().windows(2).all(|w| w[0].tick < w[1].tick));
}

#[test]
fn observing_is_hash_neutral_and_cleared_on_new_world() {
    let c = small();
    let mut s = Session::new(&c, false).unwrap();
    s.advance(80);
    let mut plain = Simulation::new(&c).unwrap();
    for _ in 0..80 {
        plain.step();
    }
    assert_eq!(s.sim.state_hash(), plain.state_hash());
    assert!(s.history.samples().len() > 10);
    let v = s.history.version();
    s.reset().unwrap();
    assert_eq!(s.history.samples().len(), 1);
    assert!(s.history.version() > v);
    s.advance(20);
    s.new_world(&c).unwrap();
    assert_eq!(s.history.samples().len(), 1);
    assert_eq!(s.history.samples()[0].tick, 0);
    s.advance_to(50);
    assert_eq!(s.sim.tick, 50);
    assert_eq!(s.history.samples().last().unwrap().tick, 50);
}

#[test]
fn json_parses_and_has_all_series() {
    let mut s = Session::new(&small(), false).unwrap();
    s.advance(60);
    let v = json::parse(&s.history.to_json(3)).unwrap();
    let n = s.history.samples().len();
    let len = |x: &Value| match x {
        Value::Array(a) => a.len(),
        _ => panic!("not an array"),
    };
    assert_eq!(len(v.get("ticks").unwrap()), n);
    for series in ["pop", "births", "deaths", "species"] {
        for k in ["plants", "herbivores", "carnivores"] {
            assert_eq!(len(v.get(series).unwrap().get(k).unwrap()), n, "{series}.{k}");
        }
    }
    for k in ["plants", "herbivores", "carnivores"] {
        for t in TRAIT_NAMES {
            assert_eq!(len(v.get("trait_mean").unwrap().get(k).unwrap().get(t).unwrap()), n);
        }
    }
    assert_eq!(len(v.get("trait_names").unwrap()), 10);
    assert_eq!(v.get("epoch"), Some(&Value::Int(3)));
}

#[test]
fn histogram_counts_and_bounds() {
    let mut sim = Simulation::new(&small()).unwrap();
    for _ in 0..30 {
        sim.step();
    }
    for k in 0..3 {
        for t in 0..10 {
            let h = histogram(&sim, k, t, 12);
            assert_eq!(h.counts.len(), 12);
            assert_eq!(h.counts.iter().sum::<u32>() as usize, sim.organisms.vec(Kind::ALL[k]).len(), "kind {k} trait {t}");
            assert_eq!(h.n, sim.organisms.vec(Kind::ALL[k]).len());
            assert!(h.min < h.max);
            let j = json::parse(&h.to_json()).unwrap();
            assert_eq!(j.get("name"), Some(&Value::Str(TRAIT_NAMES[t].into())));
        }
    }
    assert_eq!(histogram(&sim, 1, 0, 1).counts.len(), 2);
    assert_eq!(histogram(&sim, 1, 0, 10_000).counts.len(), 100);
    assert_eq!(histogram(&sim, 9, 99, 5).kind, 2);
}

#[test]
fn histogram_equal_values_and_empty_kind() {
    let mut c = small();
    c.initial.carnivores = 0;
    c.genetics.founder_variation = 0.0;
    let sim = Simulation::new(&c).unwrap();
    let h = histogram(&sim, 2, 0, 10);
    assert_eq!((h.n, h.counts.iter().sum::<u32>()), (0, 0));
    assert!(json::parse(&h.to_json()).is_ok());
    let h = histogram(&sim, 1, 0, 10);
    assert_eq!(h.counts.iter().sum::<u32>() as usize, 60);
    assert_eq!(h.counts.iter().filter(|c| **c > 0).count(), 1, "all equal values land in one bin");
    assert!(h.min < h.max);
}

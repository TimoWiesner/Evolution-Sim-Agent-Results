//! UI backend tests: snapshot encoding, controller determinism, HTTP API, 1,000-organism update rate.
use evosim_core::config::Config;
use evosim_core::sim::Simulation;
use evosim_ui::controller::{wait_for_tick, Cmd, Controller};
use evosim_ui::server::Server;
use evosim_ui::snapshot::*;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::time::{Duration, Instant};

fn cfg(p: u32, h: u32, c: u32) -> Config {
    let mut c2 = Config::default();
    c2.initial.plants = p;
    c2.initial.herbivores = h;
    c2.initial.carnivores = c;
    c2
}

fn http(addr: std::net::SocketAddr, method: &str, path: &str, body: &str) -> (u16, Vec<u8>) {
    let mut s = TcpStream::connect(addr).unwrap();
    s.set_read_timeout(Some(Duration::from_secs(5))).unwrap();
    write!(s, "{method} {path} HTTP/1.1\r\nHost: x\r\nContent-Length: {}\r\n\r\n{body}", body.len()).unwrap();
    raw_read(s)
}

fn raw_read(mut s: TcpStream) -> (u16, Vec<u8>) {
    let mut buf = Vec::new();
    let _ = s.read_to_end(&mut buf);
    let p = buf.windows(4).position(|w| w == b"\r\n\r\n").expect("no header end");
    let head = String::from_utf8_lossy(&buf[..p]).to_string();
    let code: u16 = head.split(' ').nth(1).unwrap().parse().unwrap();
    (code, buf[p + 4..].to_vec())
}

#[test]
fn frame_roundtrip_and_ordering() {
    let sim = Simulation::new(&cfg(300, 40, 10)).unwrap();
    let f = encode_frame(&sim, true);
    let d = decode_frame(&f).unwrap();
    assert_eq!(d.counts, [300, 40, 10]);
    assert_eq!(d.records.len(), 350);
    assert_eq!(f.len(), HEADER_LEN + 350 * RECORD_LEN);
    assert!(d.running && d.tick == 0);
    let kinds: Vec<u8> = d.records.iter().map(|r| r.2).collect();
    assert!(kinds.windows(2).all(|w| w[0] <= w[1]), "plants first, carnivores drawn last");
    let (w, h) = (sim.world.climate.width as u16, sim.world.climate.height as u16);
    assert!(d.records.iter().all(|r| r.0 < w && r.1 < h));
    assert!(decode_frame(&f[..f.len() - 1]).is_none());
}

#[test]
fn terrain_matches_biomes() {
    let sim = Simulation::new(&cfg(10, 1, 1)).unwrap();
    let t = encode_terrain(&sim);
    let n = sim.world.climate.biome.len();
    assert_eq!(t.len(), 2 * n);
    for (i, b) in sim.world.climate.biome.iter().enumerate() {
        assert_eq!(t[i], biome_index(*b));
    }
}

fn dist(a: [u8; 3], b: [u8; 3]) -> f64 {
    a.iter().zip(b.iter()).map(|(x, y)| (*x as f64 - *y as f64).powi(2)).sum::<f64>().sqrt()
}

#[test]
fn kind_colors_differ_from_biomes_and_each_other() {
    for k in KIND_COLORS {
        for b in evosim_core::climate::Biome::ALL {
            assert!(dist(k, biome_style(b)) > 60.0, "{k:?} vs {b:?}");
        }
    }
    for i in 0..3 {
        for j in i + 1..3 {
            assert!(dist(KIND_COLORS[i], KIND_COLORS[j]) > 150.0);
        }
    }
}

#[test]
fn controller_runs_the_same_engine() {
    let c = cfg(200, 30, 6);
    let ctl = Controller::start(&c, 1.0, false).unwrap();
    ctl.shared.send(Cmd::AdvanceTo(50));
    assert!(wait_for_tick(&ctl.shared, 50, Duration::from_secs(20)));
    let snap = ctl.shared.latest();
    let mut plain = Simulation::new(&c).unwrap();
    for _ in 0..50 {
        plain.step();
    }
    assert_eq!(snap.state_hash, plain.state_hash());
    assert_eq!(snap.frame, encode_frame(&plain, false));
}

#[test]
fn pause_stops_and_step_is_exact() {
    let ctl = Controller::start(&cfg(50, 5, 1), 200.0, true).unwrap();
    assert!(wait_for_tick(&ctl.shared, 5, Duration::from_secs(10)));
    ctl.shared.send(Cmd::Pause);
    std::thread::sleep(Duration::from_millis(150));
    let t = ctl.shared.latest().tick;
    std::thread::sleep(Duration::from_millis(200));
    assert_eq!(ctl.shared.latest().tick, t, "paused");
    ctl.shared.send(Cmd::Step(3));
    assert!(wait_for_tick(&ctl.shared, t + 3, Duration::from_secs(5)));
    std::thread::sleep(Duration::from_millis(100));
    assert_eq!(ctl.shared.latest().tick, t + 3);
}

#[test]
fn http_api() {
    let ctl = Controller::start(&cfg(100, 10, 2), 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    assert!(srv.addr.ip().is_loopback());
    let (c, b) = http(srv.addr, "GET", "/", "");
    assert_eq!(c, 200);
    let html = String::from_utf8(b).unwrap();
    assert!(html.contains("<canvas") && html.contains("id=\"panel-legend\"") && html.contains("panel-inspector") && html.contains("panel-charts"));
    let (c, b) = http(srv.addr, "GET", "/api/info", "");
    assert_eq!(c, 200);
    let info = String::from_utf8(b).unwrap();
    assert!(info.contains("\"width\":64") && info.contains("tropical_rainforest"));
    let (c, b) = http(srv.addr, "GET", "/api/terrain", "");
    assert_eq!((c, b.len()), (200, 2 * 64 * 48));
    let (c, b) = http(srv.addr, "GET", "/api/frame", "");
    assert_eq!(c, 200);
    assert!(decode_frame(&b).is_some());
    let (c, b) = http(srv.addr, "GET", "/api/frame?since=0", "");
    assert_eq!((c, b.len()), (204, 0));
    assert_eq!(http(srv.addr, "GET", "/nope", "").0, 404);
    assert_eq!(http(srv.addr, "POST", "/api/terrain", "").0, 405);
    assert_eq!(http(srv.addr, "GET", "/api/cmd", "").0, 405);
    assert_eq!(http(srv.addr, "POST", "/api/cmd", "{bad").0, 400);
    assert_eq!(http(srv.addr, "POST", "/api/cmd", "{\"cmd\":\"step\",\"n\":4}").0, 200);
    assert!(wait_for_tick(&ctl.shared, 4, Duration::from_secs(5)));
    assert_eq!(http(srv.addr, "POST", "/api/rendered", "{\"tick\":4}").0, 400);
    assert_eq!(http(srv.addr, "POST", "/api/rendered", "{\"tick\":4,\"frames\":1,\"organisms\":9}").0, 200);
    assert_eq!(ctl.shared.rendered.lock().unwrap().clone().unwrap().organisms, 9);
    // oversized header
    let mut s = TcpStream::connect(srv.addr).unwrap();
    let _ = write!(s, "GET / HTTP/1.1\r\nX: {}\r\n\r\n", "a".repeat(20000));
    assert_eq!(raw_read(s).0, 431);
}

#[test]
fn thousand_organisms_update_several_times_per_second() {
    let ctl = Controller::start(&cfg(900, 80, 20), 40.0, true).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let t0 = Instant::now();
    let mut ticks = std::collections::BTreeSet::new();
    let mut max_len = 0;
    while t0.elapsed() < Duration::from_secs(2) {
        let (c, b) = http(srv.addr, "GET", "/api/frame", "");
        assert_eq!(c, 200);
        let d = decode_frame(&b).unwrap();
        assert!(d.records.len() >= 900);
        ticks.insert(d.tick);
        max_len = max_len.max(b.len());
        std::thread::sleep(Duration::from_millis(20));
    }
    assert!(ticks.len() >= 5, "only {} distinct ticks in 2 s", ticks.len());
    assert!(max_len < 100_000, "frame {max_len} bytes");
}

#[test]
fn args() {
    let a = |v: &[&str]| evosim_ui::parse_args(&v.iter().map(|s| s.to_string()).collect::<Vec<_>>());
    assert!(a(&["--smoke-test"]).unwrap().smoke);
    assert_eq!(a(&["--screenshots", "d"]).unwrap().screenshots.as_deref(), Some("d"));
    assert!(a(&["--bogus"]).is_err());
    assert!(a(&["--port"]).is_err());
    assert!(a(&["--smoke-test", "--screenshots", "d"]).is_err());
}

#[test]
fn readme_documents_ui() {
    let r = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/../../README.md")).unwrap();
    assert!(r.contains("./evosim ui") && r.contains("--smoke-test") && r.contains("--screenshots"));
}

#[test]
fn js_camera_and_decoder() {
    if std::process::Command::new("node").arg("--version").output().is_err() {
        eprintln!("SKIP: node missing");
        return;
    }
    let sim = Simulation::new(&cfg(20, 5, 2)).unwrap();
    let dir = std::env::temp_dir().join(format!("evosim-uitest-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let frame = dir.join("frame.bin");
    std::fs::write(&frame, encode_frame(&sim, false)).unwrap();
    let app = concat!(env!("CARGO_MANIFEST_DIR"), "/web/app.js");
    let test = concat!(env!("CARGO_MANIFEST_DIR"), "/web/test/camera.test.js");
    let out = std::process::Command::new("node").arg(test).arg(app).arg(&frame).arg("20").arg("5").arg("2").output().unwrap();
    let _ = std::fs::remove_dir_all(&dir);
    assert!(out.status.success(), "{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr));
}

fn post(addr: std::net::SocketAddr, body: &str) -> (u16, String) {
    let (c, b) = http(addr, "POST", "/api/cmd", body);
    (c, String::from_utf8(b).unwrap())
}

fn state(addr: std::net::SocketAddr) -> evosim_core::json::Value {
    let (c, b) = http(addr, "GET", "/api/state", "");
    assert_eq!(c, 200);
    evosim_core::json::parse(&String::from_utf8(b).unwrap()).unwrap()
}

fn num(v: &evosim_core::json::Value, k: &str) -> f64 {
    match v.get(k).unwrap() {
        evosim_core::json::Value::Int(i) => *i as f64,
        evosim_core::json::Value::Float(f) => *f,
        o => panic!("{k}: {o:?}"),
    }
}

#[test]
fn http_controls_step_reset_speed() {
    let c = cfg(100, 10, 2);
    let h0 = Simulation::new(&c).unwrap().state_hash();
    let ctl = Controller::start(&c, 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let a = srv.addr;
    // a single step advances exactly one tick, and the reply already reflects it
    let (code, body) = post(a, "{\"cmd\":\"step\"}");
    assert_eq!(code, 200);
    assert!(body.contains("\"tick\":1"), "{body}");
    assert_eq!(num(&state(a), "tick"), 1.0);
    post(a, "{\"cmd\":\"step\",\"n\":1}");
    assert_eq!(num(&state(a), "tick"), 2.0);
    // reset: tick 0, same hash as the very first world, paused
    post(a, "{\"cmd\":\"run\"}");
    post(a, "{\"cmd\":\"reset\"}");
    let s = state(a);
    assert_eq!(num(&s, "tick"), 0.0);
    assert_eq!(s.get("running"), Some(&evosim_core::json::Value::Bool(false)));
    assert_eq!(num(&s, "epoch"), 1.0);
    assert!(ctl.shared.latest().state_hash == h0, "reset gives the initial world again");
    // counts in the state equal the counts in the frame
    let (_, fb) = http(a, "GET", "/api/frame", "");
    let d = decode_frame(&fb).unwrap();
    assert_eq!([num(&s, "plants") as u32, num(&s, "herbivores") as u32, num(&s, "carnivores") as u32], d.counts);
    assert_eq!(d.counts, [100, 10, 2]);
    // speed levels clamp; negative never gives a non-positive speed
    for (lvl, want) in [(-7, 0.0), (0, 0.0), (2, 2.0), (4, 4.0), (99, 4.0)] {
        let (code, _) = post(a, &format!("{{\"cmd\":\"speed\",\"level\":{lvl}}}"));
        assert_eq!(code, 200);
        let s = state(a);
        assert_eq!(num(&s, "speed_level"), want);
        assert!(num(&s, "tps") > 0.0);
        assert!(num(&s, "speed_levels") >= 3.0);
    }
    assert_eq!(post(a, "{\"cmd\":\"speed\",\"tps\":-5}").0, 200);
    assert!(num(&state(a), "tps") > 0.0);
    assert_eq!(post(a, "{\"cmd\":\"speed\"}").0, 400);
    assert_eq!(post(a, "{\"cmd\":\"speed\",\"level\":\"x\"}").0, 400);
}

#[test]
fn http_select_inspect_and_follow() {
    let ctl = Controller::start(&cfg(100, 10, 0), 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let a = srv.addr;
    assert_eq!(http(a, "GET", "/api/inspect", "").0, 204, "nothing selected");
    let (_, fb) = http(a, "GET", "/api/frame", "");
    let d = decode_frame(&fb).unwrap();
    let herb = d.records.iter().find(|r| r.2 == 1).unwrap();
    let (code, body) = post(a, &format!("{{\"cmd\":\"select\",\"x\":{},\"y\":{}}}", herb.0, herb.1));
    assert_eq!(code, 200);
    assert!(body.contains("\"ok\":true"), "{body}");
    let (code, b) = http(a, "GET", "/api/inspect", "");
    assert_eq!(code, 200);
    let v = evosim_core::json::parse(&String::from_utf8(b).unwrap()).unwrap();
    let id = num(&v, "id");
    assert_eq!(num(&state(a), "selected"), id);
    for k in ["kind", "species", "age", "energy", "health", "traits", "genes", "parents", "alive"] {
        assert!(v.get(k).is_some(), "{k}");
    }
    let age0 = num(&v, "age");
    post(a, "{\"cmd\":\"step\",\"n\":4}");
    let (_, b) = http(a, "GET", "/api/inspect", "");
    let v = evosim_core::json::parse(&String::from_utf8(b).unwrap()).unwrap();
    assert_eq!(num(&v, "id"), id);
    assert_eq!(num(&v, "tick"), 4.0);
    assert!(num(&v, "age") >= age0, "follows while the simulation runs");
    // by id; an unknown id changes nothing; deselect clears
    let (code, body) = post(a, "{\"cmd\":\"select\",\"id\":999999999}");
    assert_eq!(code, 200);
    assert!(body.contains("\"ok\":false"));
    assert_eq!(num(&state(a), "selected"), id);
    assert_eq!(post(a, "{\"cmd\":\"select\"}").0, 400);
    post(a, "{\"cmd\":\"deselect\"}");
    assert_eq!(http(a, "GET", "/api/inspect", "").0, 204);
    // reset clears the selection too
    post(a, &format!("{{\"cmd\":\"select\",\"id\":{id}}}"));
    post(a, "{\"cmd\":\"reset\"}");
    assert_eq!(http(a, "GET", "/api/inspect", "").0, 204);
}

#[test]
fn http_save_and_load_checkpoint() {
    let dir = std::env::temp_dir().join(format!("evosim-uick-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("s.ckpt").to_string_lossy().into_owned();
    let ctl = Controller::start(&cfg(100, 10, 2), 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let a = srv.addr;
    post(a, "{\"cmd\":\"step\",\"n\":15}");
    let h = ctl.shared.latest().state_hash.clone();
    let (code, body) = post(a, &format!("{{\"cmd\":\"save\",\"path\":\"{path}\"}}"));
    assert_eq!(code, 200, "{body}");
    assert!(std::path::Path::new(&path).is_file());
    post(a, "{\"cmd\":\"step\",\"n\":5}");
    assert_ne!(ctl.shared.latest().state_hash, h);
    let (code, body) = post(a, &format!("{{\"cmd\":\"load\",\"path\":\"{path}\"}}"));
    assert_eq!(code, 200, "{body}");
    assert_eq!(ctl.shared.latest().state_hash, h);
    assert_eq!(num(&state(a), "tick"), 15.0);
    // failures: 400 and nothing changes
    let missing = dir.join("nope.ckpt").to_string_lossy().into_owned();
    assert_eq!(post(a, &format!("{{\"cmd\":\"load\",\"path\":\"{missing}\"}}")).0, 400);
    assert_eq!(post(a, "{\"cmd\":\"load\",\"path\":\"\"}").0, 400);
    assert_eq!(post(a, "{\"cmd\":\"load\"}").0, 400);
    assert_eq!(post(a, &format!("{{\"cmd\":\"save\",\"path\":\"{}\"}}", dir.display())).0, 400);
    assert_eq!(ctl.shared.latest().state_hash, h);
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn page_has_controls_and_inspector() {
    let html = evosim_ui::assets::INDEX_HTML;
    for id in ["b-run", "b-pause", "b-step", "b-reset", "b-slower", "b-faster", "speed-label", "b-save", "b-load", "ckpt-path", "panel-inspector", "s-tick", "s-plants", "s-herb", "s-carn"] {
        assert!(html.contains(&format!("id=\"{id}\"")), "{id}");
    }
}

#[test]
fn js_controls_and_inspector_helpers() {
    if std::process::Command::new("node").arg("--version").output().is_err() {
        eprintln!("SKIP: node missing");
        return;
    }
    let app = concat!(env!("CARGO_MANIFEST_DIR"), "/web/app.js");
    let test = concat!(env!("CARGO_MANIFEST_DIR"), "/web/test/ui.test.js");
    let out = std::process::Command::new("node").arg(test).arg(app).output().unwrap();
    assert!(out.status.success(), "{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr));
}

// ---- TASK-025: setup, config files, charts over HTTP ----

fn get_json(addr: std::net::SocketAddr, path: &str) -> (u16, evosim_core::json::Value) {
    let (c, b) = http(addr, "GET", path, "");
    (c, evosim_core::json::parse(&String::from_utf8(b).unwrap()).unwrap())
}

fn post_path(addr: std::net::SocketAddr, path: &str, body: &str) -> (u16, String) {
    let (c, b) = http(addr, "POST", path, body);
    (c, String::from_utf8(b).unwrap())
}

fn values_body(c: &Config, changes: &[(&str, &str)]) -> String {
    use evosim_core::json::Value;
    let mut v = evosim_ui::experiment::values(c);
    for (k, t) in changes {
        v.iter_mut().find(|(p, _)| p == k).unwrap().1 = t.to_string();
    }
    Value::Object(vec![("values".into(), Value::Object(v.into_iter().map(|(k, x)| (k, Value::Str(x))).collect()))]).to_compact()
}

#[test]
fn http_setup_start_invalid_export_import() {
    use evosim_core::json::Value;
    let c = cfg(100, 10, 2);
    let ctl = Controller::start(&c, 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let a = srv.addr;
    let (code, s) = get_json(a, "/api/setup");
    assert_eq!(code, 200);
    match (s.get("params"), s.get("presets")) {
        (Some(Value::Array(p)), Some(Value::Array(pr))) => assert!(p.len() >= 70 && pr.len() == 5),
        _ => panic!("setup shape"),
    }
    post(a, "{\"cmd\":\"step\",\"n\":3}");
    let epoch0 = num(&state(a), "epoch");
    // invalid input: 400 with the field path, world untouched
    let (code, body) = post_path(a, "/api/config/start", &values_body(&c, &[("world.width", "0"), ("plants.growth_rate", "-1")]));
    assert_eq!(code, 400, "{body}");
    let v = evosim_core::json::parse(&body).unwrap();
    let paths: Vec<String> = match v.get("errors") {
        Some(Value::Array(e)) => e.iter().map(|x| match x.get("path") { Some(Value::Str(p)) => p.clone(), _ => panic!() }).collect(),
        _ => panic!("{body}"),
    };
    assert!(paths.contains(&"world.width".to_string()) && paths.contains(&"plants.growth_rate".to_string()), "{paths:?}");
    let s1 = state(a);
    assert_eq!((num(&s1, "tick"), num(&s1, "epoch")), (3.0, epoch0));
    assert_eq!(post_path(a, "/api/config/check", &values_body(&c, &[("seed", "x")])).0, 400);
    assert_eq!(post_path(a, "/api/config/start", "not json").0, 400);
    assert_eq!(num(&state(a), "tick"), 3.0);
    // valid input starts a new world of the chosen size
    let (code, body) = post_path(a, "/api/config/start", &values_body(&c, &[("seed", "-9"), ("world.width", "50"), ("world.height", "40"), ("initial.plants", "77")]));
    assert_eq!(code, 200, "{body}");
    let s2 = state(a);
    assert!(num(&s2, "epoch") > epoch0);
    assert_eq!(num(&s2, "plants") as u32, 77);
    assert!(num(&s2, "tick") < 3.0 + 1.0 || num(&s2, "tick") <= 60.0);
    let (_, info) = get_json(a, "/api/info");
    assert_eq!((num(&info, "width"), num(&info, "height")), (50.0, 40.0));
    // export of the running world -> import gives the same values and the same Config
    let (code, text) = {
        let (c, b) = http(a, "GET", "/api/config", "");
        (c, String::from_utf8(b).unwrap())
    };
    assert_eq!(code, 200);
    let exported = Config::from_json(&text).unwrap();
    assert_eq!((exported.seed, exported.world.width), (-9, 50));
    let (code, body) = post_path(a, "/api/config/import", &text);
    assert_eq!(code, 200, "{body}");
    let imp = evosim_core::json::parse(&body).unwrap();
    let vals = match imp.get("values") { Some(Value::Object(o)) => o.clone(), _ => panic!() };
    let want = evosim_ui::experiment::values(&exported);
    assert_eq!(vals.len(), want.len());
    for (k, t) in &want {
        assert_eq!(vals.iter().find(|(p, _)| p == k).map(|(_, v)| v), Some(&Value::Str(t.clone())), "{k}");
    }
    // export of form values equals the imported text
    let (code, text2) = post_path(a, "/api/config/export", &values_body(&exported, &[]));
    assert_eq!(code, 200);
    assert_eq!(text2, text);
    // bad import: error names the key
    let (code, body) = post_path(a, "/api/config/import", &text.replace("\"width\"", "\"widht\""));
    assert_eq!(code, 400);
    assert!(body.contains("widht"), "{body}");
    assert_eq!(http(a, "GET", "/api/config/start", "").0, 405);
}

#[test]
fn http_charts_grow_and_histogram_matches() {
    use evosim_core::json::Value;
    let c = cfg(200, 40, 6);
    let ctl = Controller::start(&c, 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    let a = srv.addr;
    let n0 = match get_json(a, "/api/charts").1.get("n") { Some(Value::Int(n)) => *n, o => panic!("{o:?}") };
    assert_eq!(n0, 1);
    post(a, "{\"cmd\":\"step\",\"n\":40}");
    let (code, d) = get_json(a, "/api/charts");
    assert_eq!(code, 200);
    assert_eq!(d.get("n"), Some(&Value::Int(9)));
    for key in ["ticks", "pop", "births", "deaths", "species", "trait_mean", "trait_names", "interval", "epoch"] {
        assert!(d.get(key).is_some(), "{key}");
    }
    let s = state(a);
    let pop = match d.get("pop").unwrap().get("herbivores") { Some(Value::Array(p)) => p.clone(), _ => panic!() };
    assert_eq!(pop.last(), Some(&Value::Int(num(&s, "herbivores") as i64)));
    for kind in 0..3 {
        let (code, body) = post(a, &format!("{{\"cmd\":\"hist\",\"kind\":{kind},\"trait\":7,\"bins\":10}}"));
        assert_eq!(code, 200, "{body}");
        let h = evosim_core::json::parse(&body).unwrap();
        let counts: i64 = match h.get("bins") { Some(Value::Array(b)) => b.iter().map(|x| match x { Value::Int(i) => *i, _ => panic!() }).sum(), _ => panic!() };
        let want = [num(&s, "plants"), num(&s, "herbivores"), num(&s, "carnivores")][kind as usize] as i64;
        assert_eq!(counts, want);
    }
    // a new world restarts the history
    post_path(a, "/api/config/start", &values_body(&c, &[]));
    assert_eq!(get_json(a, "/api/charts").1.get("n"), Some(&Value::Int(1)));
}

#[test]
fn page_has_setup_and_chart_elements() {
    let html = evosim_ui::assets::INDEX_HTML;
    for id in ["b-new", "setup", "su-presets", "su-basic", "su-key", "su-start", "su-check", "su-export", "su-import", "su-file", "ch-pop", "ch-bd", "ch-species", "ch-trait", "ch-hist", "sel-trait", "sel-htrait", "sel-hkind"] {
        assert!(html.contains(&format!("id=\"{id}\"")), "{id}");
    }
    let js = evosim_ui::assets::CHARTS_JS;
    for s in ["xLabel: 'tick'", "yLabel: 'individuals'", "'number of individuals'", "legendItems", "'species'"] {
        assert!(js.contains(s) || evosim_ui::assets::APP_JS.contains(s), "{s}");
    }
    let (a, _) = (http_get_static("/charts.js"), 0);
    assert_eq!(a, 200);
    assert_eq!(http_get_static("/setup.js"), 200);
}

fn http_get_static(path: &str) -> u16 {
    let ctl = Controller::start(&cfg(10, 2, 1), 20.0, false).unwrap();
    let srv = Server::start(ctl.shared.clone(), 0).unwrap();
    http(srv.addr, "GET", path, "").0
}

#[test]
fn js_chart_and_setup_helpers() {
    if std::process::Command::new("node").arg("--version").output().is_err() {
        eprintln!("SKIP: node missing");
        return;
    }
    let root = env!("CARGO_MANIFEST_DIR");
    let out = std::process::Command::new("node")
        .arg(format!("{root}/web/test/charts.test.js"))
        .arg(format!("{root}/web/charts.js"))
        .arg(format!("{root}/web/setup.js"))
        .output()
        .unwrap();
    assert!(out.status.success(), "{}{}", String::from_utf8_lossy(&out.stdout), String::from_utf8_lossy(&out.stderr));
}

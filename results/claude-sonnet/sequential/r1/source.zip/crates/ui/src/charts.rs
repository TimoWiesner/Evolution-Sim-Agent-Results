//! Chart data of the UI (TASK-025, ADR-0029): a bounded history recorder and trait histograms.
//! Read-only observers of a `Simulation` (they never change it); pure, so they are tested without a display.
use evosim_core::json;
use evosim_core::metrics::{kind_key, trait_values, TRAIT_NAMES};
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;

/// Samples are taken every this many ticks at first.
pub const BASE_INTERVAL: u64 = 5;
/// Upper bound of stored samples; beyond it every second sample is merged away and the interval doubles.
pub const MAX_SAMPLES: usize = 1000;

#[derive(Clone, Debug, PartialEq)]
pub struct Sample {
    pub tick: u64,
    pub pop: [u32; 3],
    /// Births / deaths since the previous sample.
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    /// Living species per kind.
    pub species: [u32; 3],
    /// Mean of each trait per kind (None when the kind is extinct).
    pub mean: [[Option<f64>; 10]; 3],
}

#[derive(Clone, Debug)]
pub struct History {
    max_samples: usize,
    interval: u64,
    samples: Vec<Sample>,
    prev_births: [u64; 3],
    prev_deaths: [u64; 3],
    started: bool,
    /// Increases on every change (never reset), so a cache can tell when to rebuild.
    version: u64,
}

impl Default for History {
    fn default() -> Self {
        History::new()
    }
}

impl History {
    pub fn new() -> History {
        History::with_max(MAX_SAMPLES)
    }
    /// A history that decimates above `max` samples (>= 4); tests use small values.
    pub fn with_max(max: usize) -> History {
        History { max_samples: max.max(4), interval: BASE_INTERVAL, samples: Vec::new(), prev_births: [0; 3], prev_deaths: [0; 3], started: false, version: 0 }
    }
    pub fn interval(&self) -> u64 {
        self.interval
    }
    pub fn samples(&self) -> &[Sample] {
        &self.samples
    }
    pub fn version(&self) -> u64 {
        self.version
    }
    /// Forgets everything (new world); the version keeps counting.
    pub fn clear(&mut self) {
        let v = self.version + 1;
        *self = History::new();
        self.version = v;
    }

    /// Call after every tick (and once at the start): samples when `tick % interval == 0` and not yet sampled.
    pub fn observe(&mut self, sim: &Simulation) {
        if sim.tick % self.interval != 0 || self.samples.last().map(|s| s.tick == sim.tick).unwrap_or(false) {
            return;
        }
        let st = &sim.organisms.stats;
        if !self.started {
            self.prev_births = st.births;
            self.prev_deaths = st.deaths;
            self.started = true;
        }
        let mut s = Sample { tick: sim.tick, pop: [0; 3], births: [0; 3], deaths: [0; 3], species: [0; 3], mean: [[None; 10]; 3] };
        for k in Kind::ALL {
            let i = k.index();
            let orgs = sim.organisms.vec(k);
            s.pop[i] = orgs.len() as u32;
            s.births[i] = st.births[i].saturating_sub(self.prev_births[i]);
            s.deaths[i] = st.deaths[i].saturating_sub(self.prev_deaths[i]);
            s.species[i] = sim.living_species(k) as u32;
            if !orgs.is_empty() {
                let mut sum = [0.0f64; 10];
                for o in orgs {
                    for (a, v) in sum.iter_mut().zip(trait_values(&o.traits)) {
                        *a += v;
                    }
                }
                for t in 0..10 {
                    s.mean[i][t] = Some(sum[t] / orgs.len() as f64);
                }
            }
        }
        self.prev_births = st.births;
        self.prev_deaths = st.deaths;
        self.samples.push(s);
        self.version += 1;
        if self.samples.len() > self.max_samples {
            self.decimate();
        }
    }

    /// Keeps the first sample and the later one of each following pair; the births/deaths of a dropped sample are
    /// added to the kept one, so totals stay exact. The sampling interval doubles.
    fn decimate(&mut self) {
        let old = std::mem::take(&mut self.samples);
        let mut it = old.into_iter();
        if let Some(first) = it.next() {
            self.samples.push(first);
        }
        loop {
            let Some(a) = it.next() else { break };
            match it.next() {
                Some(mut b) => {
                    for k in 0..3 {
                        b.births[k] += a.births[k];
                        b.deaths[k] += a.deaths[k];
                    }
                    self.samples.push(b);
                }
                None => self.samples.push(a),
            }
        }
        self.interval *= 2;
    }

    /// JSON for `GET /api/charts`: parallel arrays per series.
    pub fn to_json(&self, epoch: u64) -> String {
        let n = self.samples.len();
        let mut o = String::with_capacity(64 + n * 120);
        o.push_str(&format!("{{\"epoch\":{epoch},\"interval\":{},\"n\":{n},\"ticks\":[", self.interval));
        push_list(&mut o, self.samples.iter().map(|s| s.tick.to_string()));
        o.push(']');
        type Get = fn(&Sample, usize) -> String;
        let blocks: [(&str, Get); 4] = [
            ("pop", |s, k| s.pop[k].to_string()),
            ("births", |s, k| s.births[k].to_string()),
            ("deaths", |s, k| s.deaths[k].to_string()),
            ("species", |s, k| s.species[k].to_string()),
        ];
        for (name, get) in blocks {
            o.push_str(&format!(",\"{name}\":{{"));
            for (ki, k) in Kind::ALL.iter().enumerate() {
                if ki > 0 {
                    o.push(',');
                }
                o.push_str(&format!("\"{}\":[", kind_key(*k)));
                push_list(&mut o, self.samples.iter().map(|s| get(s, ki)));
                o.push(']');
            }
            o.push('}');
        }
        o.push_str(",\"trait_names\":[");
        push_list(&mut o, TRAIT_NAMES.iter().map(|t| format!("\"{t}\"")));
        o.push_str("],\"trait_mean\":{");
        for (ki, k) in Kind::ALL.iter().enumerate() {
            if ki > 0 {
                o.push(',');
            }
            o.push_str(&format!("\"{}\":{{", kind_key(*k)));
            for (ti, t) in TRAIT_NAMES.iter().enumerate() {
                if ti > 0 {
                    o.push(',');
                }
                o.push_str(&format!("\"{t}\":["));
                push_list(&mut o, self.samples.iter().map(|s| s.mean[ki][ti].map(json::format_float).unwrap_or_else(|| "null".into())));
                o.push(']');
            }
            o.push('}');
        }
        o.push_str("}}");
        o
    }
}

fn push_list(o: &mut String, items: impl Iterator<Item = String>) {
    for (i, x) in items.enumerate() {
        if i > 0 {
            o.push(',');
        }
        o.push_str(&x);
    }
}

/// Distribution of one trait of one kind in the current population.
#[derive(Clone, Debug, PartialEq)]
pub struct Hist {
    pub kind: usize,
    pub trait_idx: usize,
    pub tick: u64,
    pub n: usize,
    pub min: f64,
    pub max: f64,
    pub counts: Vec<u32>,
}

pub const MIN_BINS: usize = 2;
pub const MAX_BINS: usize = 100;

/// Histogram of trait `trait_idx` (0..10, `TRAIT_NAMES` order) over the living organisms of kind `kind` (0..3).
/// Out-of-range indices are clamped; `bins` is clamped to 2..=100. The range is the observed min..max
/// (one unit wide, centred on the value, when all values are equal; 0..1 when the kind is extinct).
pub fn histogram(sim: &Simulation, kind: usize, trait_idx: usize, bins: usize) -> Hist {
    let kind = kind.min(2);
    let trait_idx = trait_idx.min(9);
    let bins = bins.clamp(MIN_BINS, MAX_BINS);
    let vals: Vec<f64> = sim.organisms.vec(Kind::ALL[kind]).iter().map(|o| trait_values(&o.traits)[trait_idx]).collect();
    let mut counts = vec![0u32; bins];
    if vals.is_empty() {
        return Hist { kind, trait_idx, tick: sim.tick, n: 0, min: 0.0, max: 1.0, counts };
    }
    let mut lo = vals.iter().cloned().fold(f64::INFINITY, f64::min);
    let mut hi = vals.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    if hi <= lo {
        lo -= 0.5;
        hi += 0.5;
    }
    for v in &vals {
        let b = (((v - lo) / (hi - lo)) * bins as f64).floor();
        counts[(b.max(0.0) as usize).min(bins - 1)] += 1;
    }
    Hist { kind, trait_idx, tick: sim.tick, n: vals.len(), min: lo, max: hi, counts }
}

impl Hist {
    pub fn to_json(&self) -> String {
        let bins = self.counts.len();
        let w = (self.max - self.min) / bins as f64;
        let edges: Vec<String> = (0..=bins).map(|i| json::format_float(self.min + w * i as f64)).collect();
        format!(
            "{{\"kind\":{},\"kind_name\":\"{}\",\"trait\":{},\"name\":\"{}\",\"tick\":{},\"n\":{},\"min\":{},\"max\":{},\"bins\":[{}],\"edges\":[{}]}}",
            self.kind,
            kind_key(Kind::ALL[self.kind]),
            self.trait_idx,
            TRAIT_NAMES[self.trait_idx],
            self.tick,
            self.n,
            json::format_float(self.min),
            json::format_float(self.max),
            self.counts.iter().map(|c| c.to_string()).collect::<Vec<_>>().join(","),
            edges.join(",")
        )
    }
}

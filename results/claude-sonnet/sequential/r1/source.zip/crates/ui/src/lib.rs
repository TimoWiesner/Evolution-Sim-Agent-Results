//! `evosim ui`: local web interface (ADR-0027). Same engine as `run`; see docs/UI.md.
pub mod assets;
pub mod browser;
pub mod charts;
pub mod controller;
pub mod experiment;
pub mod server;
pub mod session;
pub mod snapshot;

use controller::{wait_for_tick, Cmd, Controller};
use evosim_core::config::Config;
use server::Server;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

#[derive(Debug, Default, PartialEq)]
pub struct UiArgs {
    pub config: Option<String>,
    pub port: Option<u16>,
    pub no_open: bool,
    pub smoke: bool,
    pub screenshots: Option<String>,
    pub tps: Option<f64>,
}

pub fn parse_args(args: &[String]) -> Result<UiArgs, String> {
    let mut a = UiArgs::default();
    let mut i = 0;
    let val = |i: &mut usize, name: &str| -> Result<String, String> {
        *i += 1;
        args.get(*i).cloned().ok_or(format!("{name} needs a value"))
    };
    while i < args.len() {
        match args[i].as_str() {
            "--config" => a.config = Some(val(&mut i, "--config")?),
            "--port" => a.port = Some(val(&mut i, "--port")?.parse().map_err(|_| "--port needs an integer 0..65535".to_string())?),
            "--no-open" => a.no_open = true,
            "--smoke-test" => a.smoke = true,
            "--screenshots" => a.screenshots = Some(val(&mut i, "--screenshots")?),
            "--ticks-per-second" => {
                let v: f64 = val(&mut i, "--ticks-per-second")?.parse().map_err(|_| "--ticks-per-second needs a number".to_string())?;
                if !(v.is_finite() && v > 0.0) {
                    return Err("--ticks-per-second must be > 0".into());
                }
                a.tps = Some(v)
            }
            other => return Err(format!("unknown ui option `{other}`")),
        }
        i += 1;
    }
    if a.smoke && a.screenshots.is_some() {
        return Err("--smoke-test and --screenshots cannot be combined".into());
    }
    Ok(a)
}

fn load_config(a: &UiArgs) -> Result<Config, String> {
    match &a.config {
        Some(p) => Config::load_file(p).map_err(|e| format!("{e}")),
        None => Ok(Config::default()),
    }
}

pub fn ui_command(args: &[String]) -> i32 {
    let a = match parse_args(args) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("evosim ui: {e}");
            return 2;
        }
    };
    let cfg = match load_config(&a) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("evosim ui: {e}");
            return 2;
        }
    };
    if let Some(d) = &a.screenshots {
        if !PathBuf::from(d).is_dir() {
            eprintln!("evosim ui: --screenshots directory `{d}` does not exist");
            return 2;
        }
    }
    let tps = a.tps.unwrap_or(20.0);
    let batch_mode = a.smoke || a.screenshots.is_some();
    let ctl = match Controller::start(&cfg, tps, !batch_mode) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("evosim ui: {e}");
            return 2;
        }
    };
    let port = a.port.unwrap_or(if batch_mode { 0 } else { 8765 });
    let srv = match Server::start(ctl.shared.clone(), port).or_else(|e| if a.port.is_none() { Server::start(ctl.shared.clone(), 0) } else { Err(e) }) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("evosim ui: {e}");
            return 2;
        }
    };
    let url = format!("http://{}/", srv.addr);
    if a.smoke {
        return finish(smoke(&ctl, &url), "smoke test");
    }
    if let Some(d) = &a.screenshots {
        return finish(screenshots(&ctl, &url, d), "screenshots");
    }
    eprintln!("evosim ui: {url} (Ctrl-C to stop)");
    if !a.no_open && (std::env::var_os("DISPLAY").is_some() || std::env::var_os("WAYLAND_DISPLAY").is_some()) {
        let _ = std::process::Command::new("xdg-open")
            .arg(&url)
            .stdin(std::process::Stdio::null())
            .stdout(std::process::Stdio::null())
            .stderr(std::process::Stdio::null())
            .spawn();
    }
    let never = AtomicBool::new(false);
    while !never.load(Ordering::Relaxed) {
        std::thread::sleep(Duration::from_secs(3600));
    }
    0
}

fn finish(r: Result<String, String>, what: &str) -> i32 {
    match r {
        Ok(m) => {
            eprintln!("evosim ui: {what} passed: {m}");
            0
        }
        Err(e) => {
            eprintln!("evosim ui: {what} FAILED: {e}");
            1
        }
    }
}

fn smoke(ctl: &Controller, url: &str) -> Result<String, String> {
    let bin = browser::find_chromium().ok_or("chromium not found (set CHROME_BIN or install chromium)")?;
    ctl.shared.send(Cmd::AdvanceTo(10));
    if !wait_for_tick(&ctl.shared, 10, Duration::from_secs(20)) {
        return Err("simulation did not reach tick 10".into());
    }
    let page = browser::open_page(&bin, &format!("{url}?smoke=1"))?;
    let t0 = Instant::now();
    let res = loop {
        if let Some(r) = ctl.shared.rendered.lock().unwrap().clone() {
            if r.frames >= 1 && r.tick >= 10 {
                break Ok(r);
            }
        }
        if t0.elapsed() > Duration::from_secs(40) {
            break Err("the page did not report a rendered frame within 40 s".to_string());
        }
        std::thread::sleep(Duration::from_millis(50));
    };
    drop(page);
    let r = res?;
    Ok(format!("rendered {} frame(s), tick {}, {} organisms drawn in {:.1} s", r.frames, r.tick, r.organisms, t0.elapsed().as_secs_f64()))
}

/// Tick at which the screenshots are taken (enough history for the charts).
const SHOT_TICK: u64 = 400;

fn screenshots(ctl: &Controller, url: &str, dir: &str) -> Result<String, String> {
    let bin = browser::find_chromium().ok_or("chromium not found (set CHROME_BIN or install chromium)")?;
    ctl.shared.send(Cmd::AdvanceTo(SHOT_TICK));
    if !wait_for_tick(&ctl.shared, SHOT_TICK, Duration::from_secs(150)) {
        return Err(format!("simulation did not reach tick {SHOT_TICK}"));
    }
    ctl.shared.send(Cmd::Pause);
    std::thread::sleep(Duration::from_millis(100));
    let out = PathBuf::from(dir).join("main.png");
    let _ = std::fs::remove_file(&out);
    browser::screenshot(&bin, &format!("{url}?shot=1&hkind=2"), &out, 1600, 988, Duration::from_secs(60))?;
    let (w, h) = browser::png_size(&out)?;
    let mut msg = format!("{} ({w}x{h}) at tick {}", out.display(), ctl.shared.latest().tick);
    for (name, query) in [("charts.png", "?shot=1&view=charts&trait=0&hkind=2"), ("setup.png", "?shot=1&view=setup&bad=1")] {
        let o = PathBuf::from(dir).join(name);
        let _ = std::fs::remove_file(&o);
        browser::screenshot(&bin, &format!("{url}{query}"), &o, 1600, 988, Duration::from_secs(60))?;
        let (w, h) = browser::png_size(&o)?;
        msg.push_str(&format!("; {} ({w}x{h})", o.display()));
    }
    // Inspector image: select the first herbivore (else carnivore, else plant) of the frame, deterministic.
    let snap = ctl.shared.latest();
    let dec = snapshot::decode_frame(&snap.frame).ok_or("bad frame")?;
    let pick = [1u8, 2, 0].iter().find_map(|k| dec.records.iter().find(|r| r.2 == *k)).ok_or("no organism to inspect")?;
    let r = ctl.shared.call(Cmd::SelectCell { x: pick.0 as i64, y: pick.1 as i64 });
    if !r.ok {
        return Err(format!("could not select an organism for inspector.png: {}", r.message));
    }
    let out2 = PathBuf::from(dir).join("inspector.png");
    let _ = std::fs::remove_file(&out2);
    browser::screenshot(&bin, &format!("{url}?shot=1&inspect=1"), &out2, 1600, 988, Duration::from_secs(60))?;
    let (w2, h2) = browser::png_size(&out2)?;
    msg.push_str(&format!("; {} ({w2}x{h2}), organism #{}", out2.display(), r.selected.unwrap_or(0)));
    Ok(msg)
}


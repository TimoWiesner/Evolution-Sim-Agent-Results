//! Controller thread: sole owner of the `Session` (ADR-0027 section 2, ADR-0028). Wall clock only paces ticks.
use crate::session::Session;
use crate::snapshot;
use evosim_core::config::Config;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{channel, RecvTimeoutError, Sender};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

#[derive(Debug, Clone)]
pub enum Cmd {
    Run,
    Pause,
    /// Advance exactly n ticks (regardless of pacing), then publish. Pauses.
    Step(u64),
    /// Advance eagerly until the tick counter is at least this value.
    AdvanceTo(u64),
    /// Raw ticks per second (clamped to > 0).
    SetSpeed(f64),
    /// Speed level index (clamped to the level table).
    SpeedLevel(i64),
    Reset,
    SelectCell { x: i64, y: i64 },
    SelectId(u64),
    Deselect,
    Save(String),
    Load(String),
    /// Start a new experiment (configuration already validated by `experiment::build`).
    NewWorld(Box<Config>),
    /// Trait histogram; the reply message is JSON.
    Hist { kind: usize, trait_idx: usize, bins: usize },
}

/// Answer to a command sent with `Shared::call`; reflects the state after the command.
#[derive(Debug, Clone, PartialEq)]
pub struct Reply {
    pub ok: bool,
    pub message: String,
    pub tick: u64,
    pub selected: Option<u64>,
}

/// Immutable published state of one tick.
#[derive(Debug)]
pub struct Snapshot {
    pub tick: u64,
    pub running: bool,
    pub frame: Vec<u8>,
    pub counts: [u32; 3],
    pub state_hash: String,
    pub epoch: u64,
    pub speed_level: usize,
    pub tps: f64,
    pub selected: Option<u64>,
    pub inspect: Option<String>,
}

/// What the page reported after drawing (`POST /api/rendered`).
#[derive(Debug, Clone, Default)]
pub struct Rendered {
    pub tick: u64,
    pub frames: u64,
    pub organisms: u64,
}

pub struct Shared {
    pub snapshot: Mutex<Arc<Snapshot>>,
    /// Replaced when the world is replaced (reset/load).
    pub terrain: Mutex<Arc<Vec<u8>>>,
    pub info: Mutex<Arc<String>>,
    /// Chart history JSON, rebuilt only when the history changed: (history version, epoch, json).
    pub charts: Mutex<(u64, u64, Arc<String>)>,
    /// Configuration of the running world (for export / the setup form).
    pub config: Mutex<Arc<Config>>,
    pub rendered: Mutex<Option<Rendered>>,
    pub stop: AtomicBool,
    tx: Mutex<Sender<(Cmd, Option<Sender<Reply>>)>>,
}

impl Shared {
    pub fn send(&self, c: Cmd) {
        let _ = self.tx.lock().unwrap().send((c, None));
    }
    /// Sends a command and waits for the answer (state after the command).
    pub fn call(&self, c: Cmd) -> Reply {
        let (rt, rr) = channel();
        let _ = self.tx.lock().unwrap().send((c, Some(rt)));
        rr.recv_timeout(Duration::from_secs(60)).unwrap_or(Reply { ok: false, message: "controller not answering".into(), tick: 0, selected: None })
    }
    pub fn latest(&self) -> Arc<Snapshot> {
        self.snapshot.lock().unwrap().clone()
    }
    pub fn terrain(&self) -> Arc<Vec<u8>> {
        self.terrain.lock().unwrap().clone()
    }
    pub fn info(&self) -> Arc<String> {
        self.info.lock().unwrap().clone()
    }
    pub fn charts(&self) -> Arc<String> {
        self.charts.lock().unwrap().2.clone()
    }
    pub fn config(&self) -> Arc<Config> {
        self.config.lock().unwrap().clone()
    }
}

pub struct Controller {
    pub shared: Arc<Shared>,
    handle: Option<JoinHandle<()>>,
}

fn snapshot_of(s: &Session, with_hash: bool) -> Snapshot {
    let frame = snapshot::encode_frame(&s.sim, s.running);
    let counts = snapshot::decode_frame(&frame).map(|d| d.counts).unwrap_or([0; 3]);
    Snapshot {
        tick: s.sim.tick,
        running: s.running,
        frame,
        counts,
        state_hash: if with_hash { s.sim.state_hash() } else { String::new() },
        epoch: s.epoch,
        speed_level: s.speed_level(),
        tps: s.tps(),
        selected: s.selected.as_ref().map(|t| t.id),
        inspect: s.inspect_json(),
    }
}

fn publish(s: &Session, shared: &Shared, with_hash: bool) {
    {
        let mut c = shared.charts.lock().unwrap();
        if c.0 != s.history.version() || c.1 != s.epoch {
            *c = (s.history.version(), s.epoch, Arc::new(s.history.to_json(s.epoch)));
        }
    }
    *shared.snapshot.lock().unwrap() = Arc::new(snapshot_of(s, with_hash));
}

/// Applies one command to the session; returns (ok, message).
pub fn apply(s: &mut Session, c: Cmd) -> (bool, String) {
    match c {
        Cmd::Run => s.run(),
        Cmd::Pause => s.pause(),
        Cmd::SetSpeed(v) => {
            if !s.set_tps(v) {
                return (false, "speed must be a number".into());
            }
        }
        Cmd::SpeedLevel(i) => s.set_speed_level(i),
        Cmd::Step(n) => s.step(n),
        Cmd::AdvanceTo(t) => s.advance_to(t),
        Cmd::NewWorld(c) => {
            if let Err(e) = s.new_world(&c) {
                return (false, e);
            }
        }
        Cmd::Hist { kind, trait_idx, bins } => return (true, crate::charts::histogram(&s.sim, kind, trait_idx, bins).to_json()),
        Cmd::Reset => {
            if let Err(e) = s.reset() {
                return (false, e);
            }
        }
        Cmd::SelectCell { x, y } => {
            if s.select_at(x, y, 1).is_none() {
                return (false, "no organism there".into());
            }
        }
        Cmd::SelectId(id) => {
            if !s.select_id(id) {
                return (false, format!("organism {id} does not exist or is dead"));
            }
        }
        Cmd::Deselect => s.deselect(),
        Cmd::Save(p) => match s.save_checkpoint(&p) {
            Ok(n) => return (true, format!("saved {n} bytes to {p}")),
            Err(e) => return (false, e),
        },
        Cmd::Load(p) => {
            if let Err(e) = s.load_checkpoint(&p) {
                return (false, e);
            }
            return (true, format!("loaded {p} at tick {}", s.sim.tick));
        }
    }
    (true, String::new())
}

impl Controller {
    /// Starts the thread. `ticks_per_second` is the base pacing; `start_running` selects the initial mode.
    pub fn start(config: &Config, ticks_per_second: f64, start_running: bool) -> Result<Controller, String> {
        let mut sess = Session::new(config, start_running)?;
        sess.set_tps(ticks_per_second);
        let (tx, rx) = channel::<(Cmd, Option<Sender<Reply>>)>();
        let first = Arc::new(snapshot_of(&sess, false));
        let shared = Arc::new(Shared {
            snapshot: Mutex::new(first),
            terrain: Mutex::new(Arc::new(snapshot::encode_terrain(&sess.sim))),
            info: Mutex::new(Arc::new(snapshot::info_json(&sess.sim, sess.epoch))),
            charts: Mutex::new((u64::MAX, 0, Arc::new(String::new()))),
            config: Mutex::new(Arc::new(sess.config.clone())),
            rendered: Mutex::new(None),
            stop: AtomicBool::new(false),
            tx: Mutex::new(tx),
        });
        publish(&sess, &shared, false);
        let sh = shared.clone();
        let handle = std::thread::spawn(move || {
            let mut credit = 0.0f64;
            let mut last = Instant::now();
            while !sh.stop.load(Ordering::Relaxed) {
                let mut dirty = false;
                match rx.recv_timeout(Duration::from_millis(8)) {
                    Ok(first) => {
                        let mut cmds = vec![first];
                        while let Ok(c) = rx.try_recv() {
                            cmds.push(c);
                        }
                        for (c, reply) in cmds {
                            let epoch = sess.epoch;
                            let (ok, message) = apply(&mut sess, c);
                            if sess.epoch != epoch {
                                *sh.terrain.lock().unwrap() = Arc::new(snapshot::encode_terrain(&sess.sim));
                                *sh.info.lock().unwrap() = Arc::new(snapshot::info_json(&sess.sim, sess.epoch));
                                *sh.config.lock().unwrap() = Arc::new(sess.config.clone());
                            }
                            publish(&sess, &sh, true);
                            if let Some(r) = reply {
                                let _ = r.send(Reply { ok, message, tick: sess.sim.tick, selected: sess.selected.as_ref().map(|t| t.id) });
                            }
                            dirty = false;
                        }
                        last = Instant::now();
                        credit = 0.0;
                    }
                    Err(RecvTimeoutError::Timeout) => {}
                    Err(RecvTimeoutError::Disconnected) => break,
                }
                if sess.running {
                    let now = Instant::now();
                    credit += now.duration_since(last).as_secs_f64() * sess.tps();
                    last = now;
                    let due = credit.floor().min(200.0) as u64;
                    if credit > 200.0 {
                        credit = 0.0;
                    }
                    if due > 0 {
                        credit -= due as f64;
                        sess.advance(due);
                        dirty = true;
                    }
                } else {
                    last = Instant::now();
                }
                if dirty {
                    publish(&sess, &sh, true);
                }
            }
        });
        Ok(Controller { shared, handle: Some(handle) })
    }

    pub fn stop(&mut self) {
        self.shared.stop.store(true, Ordering::Relaxed);
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }
}

impl Drop for Controller {
    fn drop(&mut self) {
        self.stop();
    }
}

/// Blocks until the published tick reaches `tick` or the timeout elapses.
pub fn wait_for_tick(shared: &Shared, tick: u64, timeout: Duration) -> bool {
    let t0 = Instant::now();
    while t0.elapsed() < timeout {
        if shared.latest().tick >= tick {
            return true;
        }
        std::thread::sleep(Duration::from_millis(10));
    }
    false
}

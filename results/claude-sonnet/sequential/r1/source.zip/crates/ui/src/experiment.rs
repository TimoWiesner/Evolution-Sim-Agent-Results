//! Experiment setup logic of the UI (TASK-025, ADR-0029): presets, form model, per-field validation,
//! export/import of configuration files. Pure: no threads, HTTP or display.
use evosim_core::config::{Config, Kind, Num, ParamDef, PRESET_NAMES};
use evosim_core::json::{self, Value};

/// Presets with the one-line description shown on the cards (same names as `Config::preset`).
pub const PRESETS: [(&str, &str); 5] = [
    ("default", "Balanced reference world: plants, herbivores and carnivores can coexist for a long time."),
    ("lush", "Wet, warm and fertile: fast plant growth and many plants; herbivores boom."),
    ("harsh", "Dry with strong seasons and weather noise; food is scarce, survival is hard."),
    ("predator-rich", "Many herbivores and carnivores, fast far-seeing predators, more hiding cover."),
    ("large", "A 160x120 world with large starting populations for long, spatially rich runs."),
];

/// UI limits (the controller thread must stay responsive); the config file itself allows more for headless runs.
pub const MAX_CELLS: u64 = 1_000_000;
pub const MAX_ORGANISMS: u64 = 200_000;

/// Problem with one form field. `path` is the dotted key, or `_` for a problem not tied to a field.
#[derive(Clone, Debug, PartialEq)]
pub struct FieldError {
    pub path: String,
    pub message: String,
}

fn fe(path: &str, message: impl Into<String>) -> FieldError {
    FieldError { path: path.to_string(), message: message.into() }
}

fn num_text(n: Num) -> String {
    match n {
        Num::I(i) => i.to_string(),
        Num::F(f) => json::format_float(f),
        Num::B(b) => b.to_string(),
    }
}

fn bound(x: f64, kind: Kind) -> String {
    if kind == Kind::Int {
        format!("{}", x as i64)
    } else {
        json::format_float(x)
    }
}

/// Text of every parameter (in `param_defs` order); parsing it again gives the same configuration.
pub fn values(c: &Config) -> Vec<(String, String)> {
    Config::param_defs().into_iter().map(|d| (d.path.clone(), num_text(c.get_num(&d.path).unwrap_or(d.default)))).collect()
}

fn parse_field(d: &ParamDef, text: &str) -> Result<Num, String> {
    let t = text.trim();
    if t.is_empty() {
        return Err("a value is required".into());
    }
    match d.kind {
        Kind::Bool => match t {
            "true" => Ok(Num::B(true)),
            "false" => Ok(Num::B(false)),
            _ => Err("must be true or false".into()),
        },
        Kind::Int => {
            let v: i64 = t.parse().map_err(|_| "must be a whole number".to_string())?;
            if d.path != "seed" && ((v as f64) < d.min || (v as f64) > d.max) {
                return Err(format!("must be between {} and {}", bound(d.min, d.kind), bound(d.max, d.kind)));
            }
            Ok(Num::I(v))
        }
        Kind::Float => {
            let v: f64 = t.parse().map_err(|_| "must be a number".to_string())?;
            if !v.is_finite() {
                return Err("must be a finite number".into());
            }
            if v < d.min || v > d.max {
                return Err(format!("must be between {} and {}", bound(d.min, d.kind), bound(d.max, d.kind)));
            }
            Ok(Num::F(v))
        }
    }
}

/// Builds a configuration from form text. Paths missing from `edits` keep their default; unknown paths and every
/// bad value are reported together (all errors, not only the first). `Ok` means the world may be started.
pub fn build(edits: &[(String, String)]) -> Result<Config, Vec<FieldError>> {
    let defs = Config::param_defs();
    let mut cfg = Config::default();
    let mut errs: Vec<FieldError> = Vec::new();
    for (path, text) in edits {
        match defs.iter().find(|d| &d.path == path) {
            None => errs.push(fe(path, "unknown parameter")),
            Some(d) => match parse_field(d, text) {
                Ok(n) => {
                    if cfg.set_num(path, n).is_err() {
                        errs.push(fe(path, "unknown parameter"));
                    }
                }
                Err(m) => errs.push(fe(path, m)),
            },
        }
    }
    let bad = |errs: &[FieldError], p: &str| errs.iter().any(|e| e.path == p);
    if !bad(&errs, "world.width") && !bad(&errs, "world.height") {
        let cells = cfg.world.width as u64 * cfg.world.height as u64;
        if cells > MAX_CELLS {
            errs.push(fe("world.width", format!("the UI limits the world to {MAX_CELLS} cells (width x height = {cells}); use `evosim run` for larger worlds")));
        }
    }
    let total = cfg.initial.plants as u64 + cfg.initial.herbivores as u64 + cfg.initial.carnivores as u64;
    if total > MAX_ORGANISMS && !bad(&errs, "initial.plants") && !bad(&errs, "initial.herbivores") && !bad(&errs, "initial.carnivores") {
        errs.push(fe("initial.plants", format!("the UI limits the initial population to {MAX_ORGANISMS} organisms in total (now {total})")));
    }
    if errs.is_empty() {
        if let Err(e) = cfg.validate() {
            let path = if defs.iter().any(|d| d.path == e.key) { e.key.clone() } else { "_".to_string() };
            errs.push(fe(&path, e.message));
        }
    }
    if errs.is_empty() {
        Ok(cfg)
    } else {
        Err(errs)
    }
}

/// Configuration file text (`evosim run --config` accepts it).
pub fn export(c: &Config) -> String {
    c.to_json()
}

/// Reads a configuration file text; errors name the offending key.
pub fn import(text: &str) -> Result<Config, Vec<FieldError>> {
    Config::from_json(text).map_err(|e| {
        let known = Config::param_defs().iter().any(|d| d.path == e.key);
        vec![fe(if known { &e.key } else { "_" }, if known { e.message.clone() } else { format!("{}: {}", e.key, e.message) })]
    })
}

/// Form values from a request body `{"values": {path: text|number|bool}}` (or the bare map).
pub fn edits_from_body(text: &str) -> Result<Vec<(String, String)>, String> {
    let v = json::parse(text).map_err(|e| e.to_string())?;
    let obj = v.get("values").unwrap_or(&v);
    let Value::Object(items) = obj else { return Err("expected an object of values".into()) };
    let mut out = Vec::new();
    for (k, x) in items {
        let t = match x {
            Value::Str(s) => s.clone(),
            Value::Int(i) => i.to_string(),
            Value::Float(f) => json::format_float(*f),
            Value::Bool(b) => b.to_string(),
            _ => return Err(format!("value of `{k}` must be text, a number or a boolean")),
        };
        out.push((k.clone(), t));
    }
    Ok(out)
}

fn values_obj(c: &Config) -> Value {
    Value::Object(values(c).into_iter().map(|(k, v)| (k, Value::Str(v))).collect())
}

/// `{"values": {...}}` for a configuration.
pub fn values_json(c: &Config) -> String {
    Value::Object(vec![("ok".into(), Value::Bool(true)), ("values".into(), values_obj(c))]).to_compact()
}

/// `{"ok":false,"errors":[{path,message}]}`
pub fn errors_json(errs: &[FieldError]) -> String {
    let arr = errs
        .iter()
        .map(|e| Value::Object(vec![("path".into(), Value::Str(e.path.clone())), ("message".into(), Value::Str(e.message.clone()))]))
        .collect();
    Value::Object(vec![("ok".into(), Value::Bool(false)), ("errors".into(), Value::Array(arr))]).to_compact()
}

/// Everything the setup form needs: parameter table, presets with values, and the current world's values.
pub fn setup_json(current: &Config) -> String {
    let params: Vec<Value> = Config::param_defs()
        .iter()
        .map(|d| {
            let group = d.path.split_once('.').map(|g| g.0).unwrap_or("seed");
            let kind = match d.kind {
                Kind::Int => "int",
                Kind::Float => "float",
                Kind::Bool => "bool",
            };
            Value::Object(vec![
                ("path".into(), Value::Str(d.path.clone())),
                ("group".into(), Value::Str(group.into())),
                ("kind".into(), Value::Str(kind.into())),
                ("min".into(), Value::Str(bound(d.min, d.kind))),
                ("max".into(), Value::Str(bound(d.max, d.kind))),
                ("default".into(), Value::Str(num_text(d.default))),
                ("doc".into(), Value::Str(d.doc.into())),
                ("fixed".into(), Value::Bool(d.fixed)),
            ])
        })
        .collect();
    let presets: Vec<Value> = PRESETS
        .iter()
        .map(|(name, desc)| {
            let c = Config::preset(name).unwrap_or_default();
            Value::Object(vec![("name".into(), Value::Str((*name).into())), ("description".into(), Value::Str((*desc).into())), ("values".into(), values_obj(&c))])
        })
        .collect();
    Value::Object(vec![
        ("params".into(), Value::Array(params)),
        ("presets".into(), Value::Array(presets)),
        ("current".into(), values_obj(current)),
        ("limits".into(), Value::Object(vec![("cells".into(), Value::Int(MAX_CELLS as i64)), ("organisms".into(), Value::Int(MAX_ORGANISMS as i64))])),
    ])
    .to_compact()
}

/// Names of the presets known to the core (for tests).
pub fn core_preset_names() -> &'static [&'static str] {
    &PRESET_NAMES
}

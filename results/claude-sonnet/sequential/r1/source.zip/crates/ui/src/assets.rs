//! Embedded frontend files (crates/ui/web).
pub const INDEX_HTML: &str = include_str!("../web/index.html");
pub const APP_JS: &str = include_str!("../web/app.js");
pub const STYLE_CSS: &str = include_str!("../web/style.css");
pub const CHARTS_JS: &str = include_str!("../web/charts.js");
pub const SETUP_JS: &str = include_str!("../web/setup.js");

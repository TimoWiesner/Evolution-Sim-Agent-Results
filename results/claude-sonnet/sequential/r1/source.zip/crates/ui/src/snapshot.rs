//! Binary snapshot encoding (ADR-0027 section 4). Pure functions of the simulation state.
use evosim_core::climate::Biome;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;

pub const FRAME_MAGIC: u32 = 0x3146_5645; // "EVF1" little endian
pub const HEADER_LEN: usize = 32;
pub const RECORD_LEN: usize = 8;

/// Biome colours shared by canvas and legend (`/api/info`).
pub fn biome_style(b: Biome) -> [u8; 3] {
    match b {
        Biome::Polar => [0xe8, 0xf1, 0xf5],
        Biome::Tundra => [0xa9, 0xb8, 0xa0],
        Biome::TemperateForest => [0x2f, 0x6b, 0x3a],
        Biome::TemperateGrassland => [0x8f, 0xb5, 0x5a],
        Biome::Savanna => [0xc9, 0xb4, 0x58],
        Biome::Desert => [0xdc, 0xc4, 0x8a],
        Biome::TropicalRainforest => [0x1b, 0x5e, 0x3f],
    }
}

/// Organism colours (plants, herbivores, carnivores); also used by the page.
pub const KIND_COLORS: [[u8; 3]; 3] = [[0x7d, 0xff, 0x3a], [0x2f, 0x7b, 0xff], [0xff, 0x2d, 0x55]];

pub fn biome_index(b: Biome) -> u8 {
    Biome::ALL.iter().position(|x| *x == b).unwrap_or(0) as u8
}

/// Frame: header (magic, tick, running, counts[3], n) then n records x,y (u16), kind, energy pct, age pct, species hue.
pub fn encode_frame(sim: &Simulation, running: bool) -> Vec<u8> {
    let kinds = [Kind::Plant, Kind::Herbivore, Kind::Carnivore];
    let mut counts = [0u32; 3];
    let mut n = 0u32;
    for k in kinds {
        for o in sim.organisms.vec(k) {
            if o.alive {
                counts[k.index()] += 1;
                n += 1;
            }
        }
    }
    let mut out = Vec::with_capacity(HEADER_LEN + n as usize * RECORD_LEN);
    out.extend_from_slice(&FRAME_MAGIC.to_le_bytes());
    out.extend_from_slice(&sim.tick.to_le_bytes());
    out.push(running as u8);
    out.extend_from_slice(&[0, 0, 0]);
    for c in counts {
        out.extend_from_slice(&c.to_le_bytes());
    }
    out.extend_from_slice(&n.to_le_bytes());
    for k in kinds {
        for o in sim.organisms.vec(k) {
            if !o.alive {
                continue;
            }
            let max_e = (o.traits.max_energy as f64).max(1e-9);
            let e = ((o.energy() / max_e).clamp(0.0, 1.0) * 255.0).round() as u8;
            let age = ((o.age as f64 / (o.traits.max_lifespan as f64).max(1.0)).clamp(0.0, 1.0) * 255.0).round() as u8;
            out.extend_from_slice(&(o.pos.x.max(0) as u16).to_le_bytes());
            out.extend_from_slice(&(o.pos.y.max(0) as u16).to_le_bytes());
            out.push(k.index() as u8);
            out.push(e);
            out.push(age);
            out.push((o.species % 256) as u8);
        }
    }
    out
}

/// Terrain: `W*H` bytes biome index followed by `W*H` bytes zone.
pub fn encode_terrain(sim: &Simulation) -> Vec<u8> {
    let c = &sim.world.climate;
    let mut out: Vec<u8> = c.biome.iter().map(|b| biome_index(*b)).collect();
    out.extend(c.zone.iter().copied());
    out
}

pub fn info_json(sim: &Simulation, epoch: u64) -> String {
    let c = &sim.world.climate;
    let mut counts = [0usize; 7];
    for b in &c.biome {
        counts[biome_index(*b) as usize] += 1;
    }
    let biomes: Vec<String> = Biome::ALL
        .iter()
        .enumerate()
        .map(|(i, b)| {
            let s = biome_style(*b);
            format!("{{\"name\":\"{}\",\"letter\":\"{}\",\"color\":[{},{},{}],\"cells\":{}}}", b.name(), b.letter(), s[0], s[1], s[2], counts[i])
        })
        .collect();
    let kinds: Vec<String> = ["plant", "herbivore", "carnivore"]
        .iter()
        .zip(KIND_COLORS.iter())
        .map(|(n, c)| format!("{{\"name\":\"{}\",\"color\":[{},{},{}]}}", n, c[0], c[1], c[2]))
        .collect();
    format!(
        "{{\"width\":{},\"height\":{},\"seed\":{},\"tick\":{},\"epoch\":{},\"biomes\":[{}],\"kinds\":[{}]}}",
        c.width,
        c.height,
        sim.config.seed,
        sim.tick,
        epoch,
        biomes.join(","),
        kinds.join(",")
    )
}

/// Decoded frame (mirrors the JS decoder; used by tests).
#[derive(Debug, PartialEq)]
pub struct Decoded {
    pub tick: u64,
    pub running: bool,
    pub counts: [u32; 3],
    pub records: Vec<(u16, u16, u8, u8, u8, u8)>,
}

pub fn decode_frame(b: &[u8]) -> Option<Decoded> {
    if b.len() < HEADER_LEN || u32::from_le_bytes(b[0..4].try_into().ok()?) != FRAME_MAGIC {
        return None;
    }
    let tick = u64::from_le_bytes(b[4..12].try_into().ok()?);
    let running = b[12] != 0;
    let mut counts = [0u32; 3];
    for (i, c) in counts.iter_mut().enumerate() {
        *c = u32::from_le_bytes(b[16 + 4 * i..20 + 4 * i].try_into().ok()?);
    }
    decode_records(b, tick, running, counts)
}

fn decode_records(b: &[u8], tick: u64, running: bool, counts: [u32; 3]) -> Option<Decoded> {
    let n = u32::from_le_bytes(b[28..32].try_into().ok()?) as usize;
    if b.len() != 32 + n * RECORD_LEN {
        return None;
    }
    let records = (0..n)
        .map(|i| {
            let r = &b[32 + i * RECORD_LEN..];
            (u16::from_le_bytes([r[0], r[1]]), u16::from_le_bytes([r[2], r[3]]), r[4], r[5], r[6], r[7])
        })
        .collect();
    Some(Decoded { tick, running, counts, records })
}

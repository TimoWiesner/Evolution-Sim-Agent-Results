//! Minimal HTTP/1.1 server (127.0.0.1 only, `Connection: close`, thread per connection). ADR-0027 section 3.
use crate::assets;
use crate::experiment;
use crate::controller::{Cmd, Rendered, Shared};
use std::io::{Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;

pub const MAX_HEAD: usize = 16 * 1024;
pub const MAX_BODY: usize = 64 * 1024;

pub struct Server {
    pub addr: SocketAddr,
    handle: Option<std::thread::JoinHandle<()>>,
    shared: Arc<Shared>,
}

impl Server {
    pub fn start(shared: Arc<Shared>, port: u16) -> Result<Server, String> {
        let l = TcpListener::bind(("127.0.0.1", port)).map_err(|e| format!("cannot bind 127.0.0.1:{port}: {e}"))?;
        l.set_nonblocking(true).map_err(|e| e.to_string())?;
        let addr = l.local_addr().map_err(|e| e.to_string())?;
        let sh = shared.clone();
        let handle = std::thread::spawn(move || {
            while !sh.stop.load(Ordering::Relaxed) {
                match l.accept() {
                    Ok((s, _)) => {
                        let sh2 = sh.clone();
                        std::thread::spawn(move || {
                            let _ = handle_conn(s, &sh2);
                        });
                    }
                    Err(_) => std::thread::sleep(Duration::from_millis(5)),
                }
            }
        });
        Ok(Server { addr, handle: Some(handle), shared })
    }
    pub fn stop(&mut self) {
        self.shared.stop.store(true, Ordering::Relaxed);
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }
}

impl Drop for Server {
    fn drop(&mut self) {
        self.stop();
    }
}

struct Resp {
    status: u16,
    ctype: &'static str,
    body: Vec<u8>,
}

fn resp(status: u16, ctype: &'static str, body: impl Into<Vec<u8>>) -> Resp {
    Resp { status, ctype, body: body.into() }
}

fn reason(s: u16) -> &'static str {
    match s {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        404 => "Not Found",
        405 => "Method Not Allowed",
        413 => "Payload Too Large",
        431 => "Request Header Fields Too Large",
        _ => "Error",
    }
}

fn handle_conn(mut s: TcpStream, sh: &Shared) -> std::io::Result<()> {
    s.set_read_timeout(Some(Duration::from_secs(5)))?;
    s.set_write_timeout(Some(Duration::from_secs(10)))?;
    let r = match read_request(&mut s) {
        Ok((method, path, body)) => route(&method, &path, &body, sh),
        Err(code) => resp(code, "text/plain", reason(code)),
    };
    let head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n",
        r.status,
        reason(r.status),
        r.ctype,
        r.body.len()
    );
    s.write_all(head.as_bytes())?;
    s.write_all(&r.body)?;
    s.flush()?;
    let _ = s.shutdown(std::net::Shutdown::Write);
    Ok(())
}

fn read_request(s: &mut TcpStream) -> Result<(String, String, Vec<u8>), u16> {
    let mut buf: Vec<u8> = Vec::new();
    let mut tmp = [0u8; 4096];
    let end = loop {
        if let Some(p) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            if p > MAX_HEAD {
                return Err(431);
            }
            break p;
        }
        if buf.len() > MAX_HEAD {
            return Err(431);
        }
        let n = s.read(&mut tmp).map_err(|_| 400u16)?;
        if n == 0 {
            return Err(400);
        }
        buf.extend_from_slice(&tmp[..n]);
    };
    let head = std::str::from_utf8(&buf[..end]).map_err(|_| 400u16)?.to_string();
    let mut lines = head.split("\r\n");
    let mut parts = lines.next().ok_or(400u16)?.split(' ');
    let method = parts.next().ok_or(400u16)?.to_string();
    let path = parts.next().ok_or(400u16)?.to_string();
    if !parts.next().map(|v| v.starts_with("HTTP/1.")).unwrap_or(false) {
        return Err(400);
    }
    let mut clen = 0usize;
    for l in lines {
        if let Some((k, v)) = l.split_once(':') {
            if k.eq_ignore_ascii_case("content-length") {
                clen = v.trim().parse().map_err(|_| 400u16)?;
            }
        }
    }
    if clen > MAX_BODY {
        return Err(413);
    }
    let mut body = buf[end + 4..].to_vec();
    while body.len() < clen {
        let n = s.read(&mut tmp).map_err(|_| 400u16)?;
        if n == 0 {
            return Err(400);
        }
        body.extend_from_slice(&tmp[..n]);
    }
    body.truncate(clen);
    Ok((method, path, body))
}

fn query_u64(q: &str, key: &str) -> Option<u64> {
    q.split('&').find_map(|kv| kv.split_once('=').filter(|(k, _)| *k == key).and_then(|(_, v)| v.parse().ok()))
}

fn json_num(body: &str, key: &str) -> Option<f64> {
    let i = body.find(&format!("\"{key}\""))?;
    let rest = body[i + key.len() + 2..].trim_start().strip_prefix(':')?.trim_start();
    let end = rest.find(|c: char| !(c.is_ascii_digit() || c == '.' || c == '-' || c == 'e' || c == 'E' || c == '+')).unwrap_or(rest.len());
    rest[..end].parse().ok()
}

fn json_str<'a>(body: &'a str, key: &str) -> Option<&'a str> {
    let i = body.find(&format!("\"{key}\""))?;
    let rest = body[i + key.len() + 2..].trim_start().strip_prefix(':')?.trim_start().strip_prefix('"')?;
    Some(&rest[..rest.find('"')?])
}

fn route(method: &str, target: &str, body: &[u8], sh: &Shared) -> Resp {
    let (path, query) = target.split_once('?').unwrap_or((target, ""));
    let is_post = matches!(path, "/api/cmd" | "/api/rendered" | "/api/config/check" | "/api/config/start" | "/api/config/import" | "/api/config/export");
    if method != "GET" && method != "POST" {
        return resp(405, "text/plain", "method not allowed");
    }
    if is_post && method != "POST" || !is_post && method != "GET" {
        return resp(405, "text/plain", "method not allowed");
    }
    match path {
        "/" | "/index.html" => resp(200, "text/html; charset=utf-8", assets::INDEX_HTML),
        "/app.js" => resp(200, "text/javascript; charset=utf-8", assets::APP_JS),
        "/charts.js" => resp(200, "text/javascript; charset=utf-8", assets::CHARTS_JS),
        "/setup.js" => resp(200, "text/javascript; charset=utf-8", assets::SETUP_JS),
        "/style.css" => resp(200, "text/css; charset=utf-8", assets::STYLE_CSS),
        "/api/setup" => resp(200, "application/json", experiment::setup_json(&sh.config())),
        "/api/config" => resp(200, "application/json", experiment::export(&sh.config())),
        "/api/charts" => resp(200, "application/json", sh.charts().as_bytes().to_vec()),
        "/api/config/check" | "/api/config/start" | "/api/config/export" => {
            let Ok(text) = std::str::from_utf8(body) else { return resp(400, "text/plain", "bad body") };
            let built = experiment::edits_from_body(text).map_err(|m| vec![experiment::FieldError { path: "_".into(), message: m }]).and_then(|e| experiment::build(&e));
            match built {
                Err(errs) => resp(400, "application/json", experiment::errors_json(&errs)),
                Ok(cfg) => match path {
                    "/api/config/export" => resp(200, "application/json", experiment::export(&cfg)),
                    "/api/config/check" => resp(200, "application/json", "{\"ok\":true}"),
                    _ => {
                        let r = sh.call(Cmd::NewWorld(Box::new(cfg)));
                        if r.ok {
                            resp(200, "application/json", format!("{{\"ok\":true,\"tick\":{}}}", r.tick))
                        } else {
                            resp(400, "application/json", experiment::errors_json(&[experiment::FieldError { path: "_".into(), message: r.message }]))
                        }
                    }
                },
            }
        }
        "/api/config/import" => {
            let Ok(text) = std::str::from_utf8(body) else { return resp(400, "text/plain", "bad body") };
            match experiment::import(text) {
                Ok(c) => resp(200, "application/json", experiment::values_json(&c)),
                Err(errs) => resp(400, "application/json", experiment::errors_json(&errs)),
            }
        }
        "/api/info" => resp(200, "application/json", sh.info().as_bytes().to_vec()),
        "/api/terrain" => resp(200, "application/octet-stream", sh.terrain().as_ref().clone()),
        "/api/inspect" => match &sh.latest().inspect {
            Some(j) => resp(200, "application/json", j.clone()),
            None => resp(204, "application/json", Vec::new()),
        },
        "/api/frame" => {
            let snap = sh.latest();
            if let Some(since) = query_u64(query, "since") {
                if since == snap.tick && query_u64(query, "run").map(|r| r == snap.running as u64).unwrap_or(true) {
                    return resp(204, "application/octet-stream", Vec::new());
                }
            }
            resp(200, "application/octet-stream", snap.frame.clone())
        }
        "/api/state" => {
            let s = sh.latest();
            resp(
                200,
                "application/json",
                format!(
                    "{{\"tick\":{},\"running\":{},\"plants\":{},\"herbivores\":{},\"carnivores\":{},\"state_hash\":\"{}\",\"epoch\":{},\"speed_level\":{},\"speed_levels\":{},\"tps\":{},\"selected\":{}}}",
                    s.tick,
                    s.running,
                    s.counts[0],
                    s.counts[1],
                    s.counts[2],
                    s.state_hash,
                    s.epoch,
                    s.speed_level,
                    crate::session::SPEED_LEVELS.len(),
                    s.tps,
                    s.selected.map(|i| i.to_string()).unwrap_or_else(|| "null".into())
                ),
            )
        }
        "/api/cmd" => {
            let Ok(text) = std::str::from_utf8(body) else { return resp(400, "text/plain", "bad body") };
            let cmd = match json_str(text, "cmd") {
                Some("run") => Cmd::Run,
                Some("pause") => Cmd::Pause,
                Some("step") => Cmd::Step(json_num(text, "n").filter(|v| v.is_finite()).unwrap_or(1.0).clamp(1.0, 100_000.0) as u64),
                Some("reset") => Cmd::Reset,
                Some("deselect") => Cmd::Deselect,
                Some("hist") => Cmd::Hist {
                    kind: json_num(text, "kind").filter(|v| v.is_finite()).unwrap_or(1.0).clamp(0.0, 2.0) as usize,
                    trait_idx: json_num(text, "trait").filter(|v| v.is_finite()).unwrap_or(0.0).clamp(0.0, 9.0) as usize,
                    bins: json_num(text, "bins").filter(|v| v.is_finite()).unwrap_or(20.0).clamp(2.0, 100.0) as usize,
                },
                Some("speed") => match (json_num(text, "level"), json_num(text, "tps")) {
                    (Some(l), _) if l.is_finite() => Cmd::SpeedLevel(l.clamp(-1e9, 1e9) as i64),
                    (None, Some(v)) if v.is_finite() => Cmd::SetSpeed(v),
                    _ => return resp(400, "text/plain", "speed needs level or tps"),
                },
                Some("select") => match (json_num(text, "id"), json_num(text, "x"), json_num(text, "y")) {
                    (Some(id), _, _) if id >= 0.0 && id.is_finite() => Cmd::SelectId(id as u64),
                    (None, Some(x), Some(y)) if x.is_finite() && y.is_finite() => Cmd::SelectCell { x: x.floor() as i64, y: y.floor() as i64 },
                    _ => return resp(400, "text/plain", "select needs id or x and y"),
                },
                Some(c @ ("save" | "load")) => {
                    let Some(path) = json_str(text, "path") else { return resp(400, "text/plain", "needs path") };
                    if path.contains('\\') {
                        return resp(400, "text/plain", "backslashes are not supported in paths");
                    }
                    if c == "save" {
                        Cmd::Save(path.to_string())
                    } else {
                        Cmd::Load(path.to_string())
                    }
                }
                _ => return resp(400, "text/plain", "unknown or missing cmd"),
            };
            let is_hist = matches!(cmd, Cmd::Hist { .. });
            let r = sh.call(cmd);
            if is_hist {
                return resp(200, "application/json", r.message);
            }
            let body = format!("{{\"ok\":{},\"tick\":{},\"selected\":{},\"message\":\"{}\"}}", r.ok, r.tick, r.selected.map(|i| i.to_string()).unwrap_or_else(|| "null".into()), r.message.replace('\\', "/").replace('"', "'"));
            let status = if r.ok || json_str(text, "cmd") == Some("select") { 200 } else { 400 };
            resp(status, "application/json", body)
        }
        "/api/rendered" => {
            let Ok(text) = std::str::from_utf8(body) else { return resp(400, "text/plain", "bad body") };
            let (Some(t), Some(f), Some(o)) = (json_num(text, "tick"), json_num(text, "frames"), json_num(text, "organisms")) else {
                return resp(400, "text/plain", "need tick, frames, organisms");
            };
            *sh.rendered.lock().unwrap() = Some(Rendered { tick: t as u64, frames: f as u64, organisms: o as u64 });
            resp(200, "application/json", "{\"ok\":true}")
        }
        _ => resp(404, "text/plain", "not found"),
    }
}

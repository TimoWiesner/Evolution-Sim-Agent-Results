//! Pure control logic of the UI (ADR-0028): run/pause/step/reset/speed, selection, inspector, checkpoints.
//! No threads, no HTTP, no wall clock: everything here is testable without a display.
use crate::charts::History;
use evosim_core::config::Config;
use evosim_core::genome::{Gene, Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::organism::{Id, Kind, Organism};
use evosim_core::sim::Simulation;

/// Ticks per second for each speed level (index 0..=4).
pub const SPEED_LEVELS: [f64; 5] = [1.0, 5.0, 20.0, 60.0, 200.0];
pub const DEFAULT_SPEED_LEVEL: usize = 2;
pub const GENE_NAMES: [&str; N_GENES] =
    ["speed", "strength", "fertility", "max_health", "max_lifespan", "max_energy", "metabolism", "vision", "aggression", "risk_tolerance"];

/// Snapshot of one organism as the inspector shows it.
#[derive(Clone, Debug, PartialEq)]
pub struct InspectorView {
    pub id: Id,
    pub kind: Kind,
    pub species: u32,
    pub species_name: String,
    pub species_parent: u32,
    pub age: u32,
    pub max_lifespan: u32,
    pub energy: f64,
    pub max_energy: f64,
    pub health: f64,
    pub max_health: f64,
    pub pos: Pos,
    pub generation: u32,
    pub birth_tick: u64,
    pub cooldown: u32,
    pub traits: [f64; 10],
    pub alleles: [[f32; 2]; N_GENES],
    /// Species reference alleles (None when the species is unknown).
    pub reference: Option<[[f32; 2]; N_GENES]>,
    /// (id, alive now, kind name); id 0 = none.
    pub parents: Vec<(Id, bool, &'static str)>,
}

fn num(x: f64) -> String {
    if x.is_finite() {
        format!("{}", x)
    } else {
        "0".into()
    }
}

fn esc(s: &str) -> String {
    let mut o = String::new();
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            c if (c as u32) < 0x20 => o.push(' '),
            c => o.push(c),
        }
    }
    o
}

pub fn trait_values(o: &Organism) -> [f64; 10] {
    let t = &o.traits;
    [t.speed, t.strength, t.fertility, t.max_health, t.max_lifespan as f64, t.max_energy, t.metabolism, t.vision, t.aggression, t.risk_tolerance]
}

impl InspectorView {
    pub fn of(sim: &Simulation, o: &Organism) -> InspectorView {
        let rec = sim.species.get(o.species);
        let parents = o
            .parents
            .iter()
            .filter(|p| **p != 0)
            .map(|p| match sim.organisms.find(*p) {
                Some(po) => (*p, po.alive, po.kind.name()),
                None => (*p, false, "unknown"),
            })
            .collect();
        InspectorView {
            id: o.id,
            kind: o.kind,
            species: o.species,
            species_name: rec.map(|r| r.name.clone()).unwrap_or_default(),
            species_parent: rec.map(|r| r.parent).unwrap_or(0),
            age: o.age,
            max_lifespan: o.traits.max_lifespan,
            energy: o.energy(),
            max_energy: o.traits.max_energy,
            health: o.health(),
            max_health: o.traits.max_health,
            pos: o.pos,
            generation: o.generation,
            birth_tick: o.birth_tick,
            cooldown: o.cooldown,
            traits: trait_values(o),
            alleles: *o.genome().alleles(),
            reference: rec.map(|r: &evosim_core::species::SpeciesRecord| *Genome::alleles(&r.reference)),
            parents,
        }
    }
}

/// The organism being followed. `view` keeps the last values seen while it was alive.
#[derive(Clone, Debug)]
pub struct Tracked {
    pub id: Id,
    pub view: InspectorView,
    pub alive: bool,
    pub died_tick: Option<u64>,
    /// "unknown" unless the death record was still readable.
    pub cause: String,
}

pub struct Session {
    pub sim: Simulation,
    /// Configuration Reset rebuilds from (the started config, or the one stored in a loaded checkpoint).
    pub config: Config,
    pub running: bool,
    speed_idx: usize,
    tps: f64,
    pub selected: Option<Tracked>,
    /// Incremented when the world is replaced (reset/load): the page re-fetches terrain and info.
    pub epoch: u64,
    /// Chart data (ADR-0029); cleared whenever the world is replaced.
    pub history: History,
}

/// Clamps a raw ticks-per-second request to a usable positive value; NaN gives `None`.
pub fn clamp_tps(t: f64) -> Option<f64> {
    if t.is_nan() {
        None
    } else {
        Some(t.clamp(0.1, 10_000.0))
    }
}

impl Session {
    pub fn new(config: &Config, running: bool) -> Result<Session, String> {
        let sim = Simulation::new(config).map_err(|e| format!("{e}"))?;
        let mut history = History::new();
        history.observe(&sim);
        Ok(Session { sim, config: config.clone(), running, speed_idx: DEFAULT_SPEED_LEVEL, tps: SPEED_LEVELS[DEFAULT_SPEED_LEVEL], selected: None, epoch: 0, history })
    }

    pub fn tick(&self) -> u64 {
        self.sim.tick
    }
    pub fn run(&mut self) {
        self.running = true;
    }
    pub fn pause(&mut self) {
        self.running = false;
    }
    pub fn toggle(&mut self) {
        self.running = !self.running;
    }
    pub fn speed_level(&self) -> usize {
        self.speed_idx
    }
    pub fn tps(&self) -> f64 {
        self.tps
    }
    pub fn levels() -> usize {
        SPEED_LEVELS.len()
    }

    /// Sets the speed level, clamped to the table: the speed is always > 0.
    pub fn set_speed_level(&mut self, i: i64) {
        let i = i.clamp(0, SPEED_LEVELS.len() as i64 - 1) as usize;
        self.speed_idx = i;
        self.tps = SPEED_LEVELS[i];
    }
    pub fn faster(&mut self) {
        self.set_speed_level(self.speed_idx as i64 + 1);
    }
    pub fn slower(&mut self) {
        self.set_speed_level(self.speed_idx as i64 - 1);
    }
    /// Raw rate (legacy `speed` command). Returns false for NaN (ignored).
    pub fn set_tps(&mut self, t: f64) -> bool {
        match clamp_tps(t) {
            Some(v) => {
                self.tps = v;
                // keep the level label meaningful: nearest level
                let mut best = 0;
                for (i, l) in SPEED_LEVELS.iter().enumerate() {
                    if (l - v).abs() < (SPEED_LEVELS[best] - v).abs() {
                        best = i;
                    }
                }
                self.speed_idx = best;
                true
            }
            None => false,
        }
    }

    /// Pauses and advances exactly `n` ticks (n >= 1), then refreshes the inspector.
    pub fn step(&mut self, n: u64) {
        self.running = false;
        for _ in 0..n.max(1) {
            self.sim.step();
            self.history.observe(&self.sim);
        }
        self.refresh();
    }

    /// Advances `n` ticks without changing the running flag (used by pacing).
    pub fn advance(&mut self, n: u64) {
        for _ in 0..n {
            self.sim.step();
            self.history.observe(&self.sim);
        }
        self.refresh();
    }

    /// Advances eagerly until the tick counter is at least `t`.
    pub fn advance_to(&mut self, t: u64) {
        while self.sim.tick < t {
            self.sim.step();
            self.history.observe(&self.sim);
        }
        self.refresh();
    }

    /// Starts a new experiment: builds the world first (an error changes nothing), then replaces the simulation and
    /// the Reset target, clears selection and chart history, bumps the epoch and starts running.
    pub fn new_world(&mut self, config: &Config) -> Result<(), String> {
        let sim = Simulation::new(config).map_err(|e| format!("{e}"))?;
        self.sim = sim;
        self.config = config.clone();
        self.running = true;
        self.replaced();
        Ok(())
    }

    /// Bookkeeping after the simulation object was replaced.
    fn replaced(&mut self) {
        self.selected = None;
        self.epoch += 1;
        self.history.clear();
        self.history.observe(&self.sim);
    }

    /// Rebuilds the world from the session configuration: same seed => same starting world. Pauses, clears the selection.
    pub fn reset(&mut self) -> Result<(), String> {
        let sim = Simulation::new(&self.config).map_err(|e| format!("{e}"))?;
        self.sim = sim;
        self.running = false;
        self.replaced();
        Ok(())
    }

    // ---- selection ----

    /// Selects an organism by id; false if it does not exist (selection unchanged).
    pub fn select_id(&mut self, id: Id) -> bool {
        match self.sim.organisms.find(id) {
            Some(o) if o.alive => {
                let view = InspectorView::of(&self.sim, o);
                self.selected = Some(Tracked { id, view, alive: true, died_tick: None, cause: String::new() });
                true
            }
            _ => false,
        }
    }

    /// Picks the organism at a world cell: animals before plants, then lowest id; when the cell is empty the
    /// nearest organism within `radius` cells (Chebyshev, wrapped) is used. Coordinates wrap.
    pub fn pick(&self, x: i64, y: i64, radius: i64) -> Option<Id> {
        let c = self.sim.spatial.grid().wrap(x, y);
        let mut best: Option<(u32, u8, Id)> = None;
        for h in self.sim.spatial.query(c, radius.max(0), None) {
            let d = h.dist;
            let rank = if h.kind.is_animal() { 0 } else { 1 };
            let key = (d, rank, h.id);
            if best.map(|b| key < b).unwrap_or(true) {
                best = Some(key);
            }
        }
        best.map(|b| b.2)
    }

    pub fn select_at(&mut self, x: i64, y: i64, radius: i64) -> Option<Id> {
        let id = self.pick(x, y, radius)?;
        if self.select_id(id) {
            Some(id)
        } else {
            None
        }
    }

    pub fn deselect(&mut self) {
        self.selected = None;
    }

    /// Updates the followed organism after the simulation changed.
    pub fn refresh(&mut self) {
        let Some(t) = self.selected.as_mut() else { return };
        if !t.alive {
            return;
        }
        match self.sim.organisms.find(t.id) {
            Some(o) if o.alive => t.view = InspectorView::of(&self.sim, o),
            Some(o) => {
                t.alive = false;
                t.died_tick = Some(o.death.map(|d| d.tick).unwrap_or(self.sim.tick));
                t.cause = o.death.map(|d| d.cause.name().to_string()).unwrap_or_else(|| "unknown".into());
            }
            None => {
                t.alive = false;
                t.died_tick = Some(self.sim.tick);
                t.cause = "unknown".into();
            }
        }
    }

    pub fn inspect_json(&self) -> Option<String> {
        let t = self.selected.as_ref()?;
        let v = &t.view;
        let tr: Vec<String> = ["speed", "strength", "fertility", "max_health", "max_lifespan", "max_energy", "metabolism", "vision", "aggression", "risk_tolerance"]
            .iter()
            .zip(v.traits.iter())
            .map(|(n, x)| format!("\"{n}\":{}", num(*x)))
            .collect();
        let genes: Vec<String> = (0..N_GENES)
            .map(|i| {
                let r = v.reference.map(|r| format!("[{},{}]", num(r[i][0] as f64), num(r[i][1] as f64))).unwrap_or_else(|| "null".into());
                format!(
                    "{{\"name\":\"{}\",\"a0\":{},\"a1\":{},\"value\":{},\"ref\":{}}}",
                    GENE_NAMES[i],
                    num(v.alleles[i][0] as f64),
                    num(v.alleles[i][1] as f64),
                    num((v.alleles[i][0] as f64 + v.alleles[i][1] as f64) / 2.0),
                    r
                )
            })
            .collect();
        let _ = Gene::ALL;
        let parents: Vec<String> = v.parents.iter().map(|(id, a, k)| format!("{{\"id\":{id},\"alive\":{a},\"kind\":\"{k}\"}}")).collect();
        Some(format!(
            "{{\"id\":{},\"kind\":\"{}\",\"alive\":{},\"tick\":{},\"died_tick\":{},\"death_cause\":\"{}\",\"species\":{{\"id\":{},\"name\":\"{}\",\"parent\":{}}},\"age\":{},\"max_lifespan\":{},\"energy\":{},\"max_energy\":{},\"health\":{},\"max_health\":{},\"pos\":{{\"x\":{},\"y\":{}}},\"generation\":{},\"birth_tick\":{},\"cooldown\":{},\"parents\":[{}],\"traits\":{{{}}},\"genes\":[{}]}}",
            v.id,
            v.kind.name(),
            t.alive,
            self.sim.tick,
            t.died_tick.map(|d| d.to_string()).unwrap_or_else(|| "null".into()),
            esc(&t.cause),
            v.species,
            esc(&v.species_name),
            v.species_parent,
            v.age,
            v.max_lifespan,
            num(v.energy),
            num(v.max_energy),
            num(v.health),
            num(v.max_health),
            v.pos.x,
            v.pos.y,
            v.generation,
            v.birth_tick,
            v.cooldown,
            parents.join(","),
            tr.join(","),
            genes.join(",")
        ))
    }

    // ---- checkpoints ----

    pub fn save_checkpoint(&self, path: &str) -> Result<usize, String> {
        check_path(path)?;
        let bytes = self.sim.to_checkpoint();
        let tmp = format!("{}.tmp.{}", path, std::process::id());
        std::fs::write(&tmp, &bytes).map_err(|e| {
            let _ = std::fs::remove_file(&tmp);
            format!("cannot write `{path}`: {e}")
        })?;
        std::fs::rename(&tmp, path).map_err(|e| {
            let _ = std::fs::remove_file(&tmp);
            format!("cannot write `{path}`: {e}")
        })?;
        Ok(bytes.len())
    }

    /// Replaces the simulation (and the Reset target) by the checkpoint's; on error nothing changes.
    pub fn load_checkpoint(&mut self, path: &str) -> Result<(), String> {
        check_path(path)?;
        let bytes = std::fs::read(path).map_err(|e| format!("cannot read `{path}`: {e}"))?;
        let sim = Simulation::from_checkpoint(&bytes).map_err(|e| format!("`{path}`: {e}"))?;
        self.config = sim.config.clone();
        self.sim = sim;
        self.running = false;
        self.replaced();
        Ok(())
    }
}

pub fn check_path(path: &str) -> Result<(), String> {
    if path.trim().is_empty() {
        return Err("empty path".into());
    }
    if path.contains('\0') {
        return Err("invalid path".into());
    }
    if std::path::Path::new(path).is_dir() {
        return Err(format!("`{path}` is a directory"));
    }
    Ok(())
}

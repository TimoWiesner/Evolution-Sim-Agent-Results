//! Chromium driver for `--smoke-test` and `--screenshots` (ADR-0027 sections 9 and 10).
use std::path::{Path, PathBuf};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

pub fn find_chromium() -> Option<String> {
    for var in ["CHROME_BIN", "PUPPETEER_EXECUTABLE_PATH"] {
        if let Ok(v) = std::env::var(var) {
            if !v.is_empty() && Path::new(&v).exists() {
                return Some(v);
            }
        }
    }
    let path = std::env::var("PATH").unwrap_or_default();
    for name in ["chromium", "chromium-browser", "google-chrome"] {
        for d in path.split(':') {
            let p = Path::new(d).join(name);
            if p.is_file() {
                return Some(p.to_string_lossy().into_owned());
            }
        }
    }
    None
}

/// A running chromium plus its temp profile; killed and cleaned on drop.
pub struct Browser {
    child: Child,
    profile: PathBuf,
}

impl Drop for Browser {
    fn drop(&mut self) {
        let _ = self.child.kill();
        let _ = self.child.wait();
        let _ = std::fs::remove_dir_all(&self.profile);
    }
}

fn profile_dir(tag: &str) -> PathBuf {
    let t = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    std::env::temp_dir().join(format!("evosim-ui-{}-{}-{}", tag, std::process::id(), t))
}

fn base_command(bin: &str, profile: &Path) -> Command {
    let mut c = Command::new(bin);
    c.arg("--headless=new")
        .arg("--no-sandbox")
        .arg("--disable-gpu")
        .arg("--disable-dev-shm-usage")
        .arg("--no-first-run")
        .arg("--disable-extensions")
        .arg(format!("--user-data-dir={}", profile.display()))
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null());
    c
}

/// Opens the page in headless chromium and keeps it alive until dropped.
pub fn open_page(bin: &str, url: &str) -> Result<Browser, String> {
    let profile = profile_dir("smoke");
    let child = base_command(bin, &profile).arg("--window-size=1280,800").arg(url).spawn().map_err(|e| format!("cannot start `{bin}`: {e}"))?;
    Ok(Browser { child, profile })
}

/// Takes a screenshot via `--screenshot`; kills chromium after `timeout`. Returns Ok when a PNG of at least `min_w x min_h` exists.
pub fn screenshot(bin: &str, url: &str, out: &Path, w: u32, h: u32, timeout: Duration) -> Result<(), String> {
    let profile = profile_dir("shot");
    let child = base_command(bin, &profile)
        .arg("--hide-scrollbars")
        .arg(format!("--window-size={w},{h}"))
        .arg("--virtual-time-budget=6000")
        .arg(format!("--screenshot={}", out.display()))
        .arg(url)
        .spawn()
        .map_err(|e| format!("cannot start `{bin}`: {e}"))?;
    let mut b = Browser { child, profile };
    let t0 = Instant::now();
    loop {
        match b.child.try_wait() {
            Ok(Some(_)) => break,
            Ok(None) => {}
            Err(e) => return Err(e.to_string()),
        }
        if t0.elapsed() > timeout {
            // some chromium builds write the file but never exit
            if out.exists() {
                std::thread::sleep(Duration::from_millis(300));
                break;
            }
            return Err(format!("chromium did not finish within {timeout:?}"));
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    let (pw, ph) = png_size(out)?;
    if pw < 1280 || ph < 720 {
        return Err(format!("{} is {pw}x{ph}, need at least 1280x720", out.display()));
    }
    Ok(())
}

/// Reads width and height from the PNG IHDR.
pub fn png_size(p: &Path) -> Result<(u32, u32), String> {
    let b = std::fs::read(p).map_err(|e| format!("cannot read {}: {e}", p.display()))?;
    if b.len() < 24 || b[..8] != [0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a] {
        return Err(format!("{} is not a PNG", p.display()));
    }
    Ok((u32::from_be_bytes(b[16..20].try_into().unwrap()), u32::from_be_bytes(b[20..24].try_into().unwrap())))
}

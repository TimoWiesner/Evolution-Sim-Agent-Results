'use strict';
// Experiment setup form (ADR-0029): pure helpers (tested with node) + DOM builder. Validation is done by the server.
const KEY_PARAMS = ['climate.equator_temp', 'climate.seasonal_amplitude', 'climate.precip_mean', 'climate.resource_regen', 'plants.growth_rate', 'plants.seed_range', 'herbivores.max_age', 'carnivores.speed', 'genetics.mutation_sigma', 'genetics.species_threshold'];
const BASIC_PARAMS = ['seed', 'world.width', 'world.height', 'initial.plants', 'initial.herbivores', 'initial.carnivores'];

// errors [{path,message}] -> {byPath: {path: message}, general: [message]} (paths that are not form fields go to general).
function mapErrors(errors, knownPaths) {
  const byPath = {}, general = [];
  for (const e of errors || []) {
    if (knownPaths.indexOf(e.path) >= 0) byPath[e.path] = byPath[e.path] ? byPath[e.path] + '; ' + e.message : e.message;
    else general.push((e.path && e.path !== '_' ? e.path + ': ' : '') + e.message);
  }
  return { byPath, general };
}
function groupParams(params) {
  const groups = {};
  for (const p of params) (groups[p.group] = groups[p.group] || []).push(p);
  return groups;
}
if (typeof module !== 'undefined') module.exports = { mapErrors, groupParams, KEY_PARAMS, BASIC_PARAMS };

if (typeof document !== 'undefined') window.EvoSetup = (function () {
  const $ = (id) => document.getElementById(id);
  let setup = null; const inputs = {};
  const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

  function field(p) {
    const d = document.createElement('div'); d.className = 'field'; d.dataset.path = p.path;
    const lab = document.createElement('label'); lab.textContent = p.path; lab.title = p.doc;
    const inp = document.createElement('input'); inp.type = 'text'; inp.spellcheck = false; inp.id = 'f-' + p.path; inp.dataset.path = p.path;
    inp.setAttribute('aria-label', p.path);
    const hint = document.createElement('span'); hint.className = 'hint'; hint.textContent = p.kind === 'bool' ? 'true / false' : p.kind + ' ' + p.min + ' .. ' + p.max;
    const err = document.createElement('div'); err.className = 'err'; err.id = 'e-' + p.path; err.setAttribute('role', 'alert');
    const doc = document.createElement('div'); doc.className = 'doc'; doc.textContent = p.doc;
    d.append(lab, inp, hint, err, doc); inputs[p.path] = inp;
    inp.addEventListener('input', () => showErrors([]));
    return d;
  }
  function build() {
    for (const k of Object.keys(inputs)) delete inputs[k];
    const byPath = {}; for (const p of setup.params) byPath[p.path] = p;
    const basic = $('su-basic'), key = $('su-key'), groups = $('su-groups');
    basic.textContent = ''; key.textContent = ''; groups.textContent = '';
    for (const path of BASIC_PARAMS) if (byPath[path]) basic.append(field(byPath[path]));
    for (const path of KEY_PARAMS) if (byPath[path]) key.append(field(byPath[path]));
    const shown = new Set(BASIC_PARAMS.concat(KEY_PARAMS));
    const g = groupParams(setup.params.filter((p) => !shown.has(p.path)));
    for (const name of Object.keys(g)) {
      const det = document.createElement('details'); const sum = document.createElement('summary'); sum.textContent = name + ' (' + g[name].length + ' more parameters)';
      det.append(sum); for (const p of g[name]) det.append(field(p)); groups.append(det);
    }
    const cards = $('su-presets'); cards.textContent = '';
    for (const pr of setup.presets) {
      const b = document.createElement('button'); b.className = 'card'; b.type = 'button'; b.dataset.preset = pr.name;
      b.innerHTML = '<b>' + esc(pr.name) + '</b><span>' + esc(pr.description) + '</span>';
      b.onclick = () => { fill(pr.values); for (const c of cards.children) c.classList.toggle('sel', c === b); msg('preset "' + pr.name + '" loaded - edit values, then press Start'); };
      cards.append(b);
    }
  }
  function fill(values) { for (const p of Object.keys(values)) if (inputs[p]) inputs[p].value = values[p]; showErrors([]); }
  function read() { const v = {}; for (const p of Object.keys(inputs)) v[p] = inputs[p].value; return v; }
  function msg(t, bad) { const m = $('su-msg'); m.textContent = t; m.className = bad ? 'bad' : 'ok'; }
  function showErrors(errors) {
    const known = Object.keys(inputs); const m = mapErrors(errors, known);
    for (const p of known) { const e = $('e-' + p); e.textContent = m.byPath[p] || ''; inputs[p].classList.toggle('bad', !!m.byPath[p]); }
    const first = errors.find((e) => m.byPath[e.path] !== undefined);
    if (first) { const el = inputs[first.path]; const det = el.closest('details'); if (det) det.open = true; }
    if (m.general.length) msg(m.general.join(' | '), true);
    else if (errors.length) msg(errors.length + ' invalid field' + (errors.length > 1 ? 's' : '') + ' - the world was not started', true);
    return first ? first.path : null;
  }
  async function post(url, body, raw) {
    const r = await fetch(url, { method: 'POST', body: raw ? body : JSON.stringify({ values: body }) });
    const text = await r.text();
    return { ok: r.ok, text, json: (() => { try { return JSON.parse(text); } catch (e) { return null; } })() };
  }
  async function load() {
    setup = await (await fetch('/api/setup')).json(); build(); fill(setup.current);
    $('su-count').textContent = setup.params.length + ' parameters';
  }
  async function check() { const r = await post('/api/config/check', read()); if (r.ok) { showErrors([]); msg('configuration is valid'); return true; } showErrors((r.json && r.json.errors) || [{ path: '_', message: r.text }]); return false; }
  async function start() {
    const r = await post('/api/config/start', read());
    if (r.ok) { showErrors([]); msg('world started'); return true; }
    showErrors((r.json && r.json.errors) || [{ path: '_', message: r.text }]); return false;
  }
  async function exportFile() {
    const r = await post('/api/config/export', read());
    if (!r.ok) { showErrors((r.json && r.json.errors) || []); return; }
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([r.text], { type: 'application/json' })); a.download = 'evosim-config.json';
    document.body.append(a); a.click(); a.remove(); msg('exported evosim-config.json');
  }
  async function importText(text) {
    const r = await post('/api/config/import', text, true);
    if (r.ok) { fill(r.json.values); msg('configuration imported - press Start to run it'); return true; }
    showErrors((r.json && r.json.errors) || [{ path: '_', message: r.text }]); return false;
  }
  function importFile(file) { const fr = new FileReader(); fr.onload = () => importText(String(fr.result)); fr.onerror = () => msg('cannot read the file', true); fr.readAsText(file); }
  return { load, check, start, exportFile, importText, importFile, fill, read, showErrors, msg, isBuilt: () => !!setup };
})();

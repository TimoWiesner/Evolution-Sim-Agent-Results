'use strict';
// usage: node charts.test.js charts.js setup.js  (chart helpers and setup error mapping, ADR-0029)
const assert = require('assert');
const path = require('path');
const c = require(path.resolve(process.argv[2]));
const s = require(path.resolve(process.argv[3]));
// ticks
assert.deepStrictEqual(c.niceTicks(0, 100, 5), [0, 20, 40, 60, 80, 100]);
assert.deepStrictEqual(c.niceTicks(0, 1, 4), [0, 0.5, 1]);
const t = c.niceTicks(3, 97, 5); assert.ok(t[0] >= 3 && t[t.length - 1] <= 97 && t.length >= 3);
assert.deepStrictEqual(c.niceTicks(5, 5, 3).length > 0, true);
assert.ok(c.niceTicks(0, 1, 5, true).every((v) => Number.isInteger(v)));
assert.strictEqual(c.formatTick(0), '0'); assert.strictEqual(c.formatTick(25000), '25k'); assert.strictEqual(c.formatTick(1500000), '1.5M'); assert.strictEqual(c.formatTick(0.25), '0.25');
// scale
const sc = c.buildScale(0, 10, 100, 200);
assert.strictEqual(sc.map(0), 100); assert.strictEqual(sc.map(10), 200); assert.strictEqual(sc.map(5), 150);
assert.strictEqual(c.buildScale(3, 3, 0, 10).map(3), 5);
const inv = c.buildScale(0, 10, 100, 0); assert.strictEqual(inv.map(10), 0);
// series path with gaps
const segs = c.seriesPath([0, 1, 2, 3, 4], [1, 2, null, 4, 5], c.buildScale(0, 4, 0, 40), c.buildScale(0, 10, 100, 0));
assert.strictEqual(segs.length, 2); assert.deepStrictEqual(segs[0], [[0, 90], [10, 80]]); assert.deepStrictEqual(segs[1], [[30, 60], [40, 50]]);
assert.strictEqual(c.seriesPath([0, 1], [null, NaN], sc, sc).length, 0);
// legend and bars
assert.deepStrictEqual(c.legendItems([{ label: 'a', color: 'red', dash: true, ys: [] }]), [{ label: 'a', color: 'red', dash: true }]);
assert.deepStrictEqual(c.histBars([0, 1, 2], [3, 0]), [[0, 1, 3], [1, 2, 0]]);
assert.deepStrictEqual(c.dataRange([{ ys: [null, 5, 2] }], true), [0, 5]);
// chart specs have titles, axis labels and legends for every kind
const k = { plants: [1, 2], herbivores: [3, 4], carnivores: [null, 1] };
const tm = {}; for (const kk of Object.keys(k)) tm[kk] = { speed: [1, 2] };
const d = { interval: 5, ticks: [0, 5], pop: k, births: k, deaths: k, species: k, trait_mean: tm, trait_names: ['speed'] };
const sp = c.chartSpecs(d, ['g', 'b', 'r'], 'speed');
for (const key of ['pop', 'bd', 'species', 'trait']) { assert.ok(sp[key].title && sp[key].xLabel === 'tick' && sp[key].yLabel); assert.ok(sp[key].series.length >= 3); }
assert.strictEqual(sp.bd.series.length, 6); assert.ok(sp.bd.series.slice(3).every((x) => x.dash));
assert.strictEqual(sp.trait.yLabel, 'mean speed');
// setup error mapping
const m = s.mapErrors([{ path: 'world.width', message: 'bad' }, { path: 'world.width', message: 'worse' }, { path: '_', message: 'general' }, { path: 'zzz', message: 'x' }], ['world.width']);
assert.strictEqual(m.byPath['world.width'], 'bad; worse'); assert.deepStrictEqual(m.general, ['general', 'zzz: x']);
assert.deepStrictEqual(s.mapErrors(null, []), { byPath: {}, general: [] });
assert.deepStrictEqual(Object.keys(s.groupParams([{ group: 'a' }, { group: 'b' }, { group: 'a' }])), ['a', 'b']);
assert.ok(s.KEY_PARAMS.length >= 5 && s.BASIC_PARAMS.length === 6);
console.log('charts/setup helper tests ok');

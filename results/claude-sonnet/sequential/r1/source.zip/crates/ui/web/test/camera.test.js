'use strict';
// usage: node camera.test.js app.js frame.bin plants herbivores carnivores
const assert = require('assert');
const fs = require('fs');
const a = require(require('path').resolve(process.argv[2]));
const b = fs.readFileSync(process.argv[3]);
const buf = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
const f = a.decodeFrame(buf);
assert(f, 'decode');
assert.deepStrictEqual(f.counts, [20, 5, 2].map(Number));
assert.strictEqual(f.n, 27);
assert.strictEqual(f.tick, 0);
const kinds = []; for (let i = 0; i < f.n; i++) kinds.push(a.record(f, i).kind);
assert.deepStrictEqual(kinds.slice(0, 20), Array(20).fill(0));
assert.strictEqual(kinds[26], 2);
assert.strictEqual(a.decodeFrame(buf.slice(0, buf.byteLength - 1)), null);
// zoom keeps the world point under the cursor fixed
let cam = a.fitCamera(64, 48, 1000, 700);
for (const [px, py, k] of [[100, 50, 1.15], [900, 600, 1.15], [500, 350, 1 / 1.15], [20, 690, 1.15]]) {
  const before = a.screenToWorld(cam, px, py, 1000, 700);
  cam = a.zoomAt(cam, px, py, k, 1000, 700);
  const after = a.screenToWorld(cam, px, py, 1000, 700);
  assert(Math.abs(before.x - after.x) < 1e-9 && Math.abs(before.y - after.y) < 1e-9);
}
// clamp
let c2 = a.fitCamera(64, 48, 1000, 700);
for (let i = 0; i < 100; i++) c2 = a.zoomAt(c2, 10, 10, 1.15, 1000, 700);
assert.strictEqual(c2.s, 64);
for (let i = 0; i < 100; i++) c2 = a.zoomAt(c2, 10, 10, 1 / 1.15, 1000, 700);
assert.strictEqual(c2.s, 1);
// pan and wrap
const p = a.panBy({ s: 10, cx: 5, cy: 5 }, 100, 0);
assert(Math.abs(p.cx - -5) < 1e-9);
const w = a.wrapCamera(p, 64, 48);
assert(Math.abs(w.cx - 59) < 1e-9);
console.log('ok');

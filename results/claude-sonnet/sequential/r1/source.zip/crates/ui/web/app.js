'use strict';
// Evolution Simulation web view (ADR-0027). Pure helpers first (testable with node), DOM code at the bottom.
const MAGIC = 0x31465645, HEADER = 32, REC = 8;

function decodeFrame(buf) {
  const dv = new DataView(buf);
  if (buf.byteLength < HEADER || dv.getUint32(0, true) !== MAGIC) return null;
  const n = dv.getUint32(28, true);
  if (buf.byteLength !== HEADER + n * REC) return null;
  return {
    tick: Number(dv.getBigUint64(4, true)), running: dv.getUint8(12) !== 0,
    counts: [dv.getUint32(16, true), dv.getUint32(20, true), dv.getUint32(24, true)],
    n, view: dv, base: HEADER,
  };
}
function record(f, i) {
  const o = f.base + i * REC, d = f.view;
  return { x: d.getUint16(o, true), y: d.getUint16(o + 2, true), kind: d.getUint8(o + 4), energy: d.getUint8(o + 5), age: d.getUint8(o + 6), species: d.getUint8(o + 7) };
}
const MINS = 1, MAXS = 64;
function mod(a, n) { return ((a % n) + n) % n; }
function screenToWorld(cam, px, py, cw, ch) { return { x: cam.cx + (px - cw / 2) / cam.s, y: cam.cy + (py - ch / 2) / cam.s }; }
function zoomAt(cam, px, py, factor, cw, ch) {
  const w = screenToWorld(cam, px, py, cw, ch);
  const s = Math.min(MAXS, Math.max(MINS, cam.s * factor));
  return { s, cx: w.x - (px - cw / 2) / s, cy: w.y - (py - ch / 2) / s };
}
function panBy(cam, dxPx, dyPx) { return { s: cam.s, cx: cam.cx - dxPx / cam.s, cy: cam.cy - dyPx / cam.s }; }
function fitCamera(W, H, cw, ch) { const s = Math.min(MAXS, Math.max(MINS, Math.min(cw / W, ch / H))); return { s, cx: W / 2, cy: H / 2 }; }
function wrapCamera(cam, W, H) { return { s: cam.s, cx: mod(cam.cx, W), cy: mod(cam.cy, H) }; }
// --- control / inspector helpers (ADR-0028) ---
function worldCellFromPointer(cam, px, py, cw, ch, W, H) {
  const w = screenToWorld(cam, px, py, cw, ch);
  return { x: mod(Math.floor(w.x), W), y: mod(Math.floor(w.y), H) };
}
function speedLabel(level, levels, tps) {
  const l = Math.max(0, Math.min(levels - 1, level | 0));
  return 'level ' + (l + 1) + '/' + levels + ' (' + (tps >= 10 ? Math.round(tps) : +Number(tps).toFixed(1)) + ' ticks/s)';
}
function fmt(x, d) { return (typeof x === 'number' && isFinite(x)) ? x.toFixed(d === undefined ? 2 : d) : '-'; }
function pct(v, lo, hi) { return Math.max(0, Math.min(100, hi > lo ? (v - lo) / (hi - lo) * 100 : 0)); }
function esc(t) { return String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]); }
function meter(p, cls, ref) { return '<div class="meter"><i class="' + cls + '" style="width:' + p.toFixed(1) + '%"></i>' + (ref === null || ref === undefined ? '' : '<u style="left:' + ref.toFixed(1) + '%"></u>') + '</div>'; }
// Inspector HTML from the /api/inspect JSON (a table so it is readable as text, too).
function inspectorHTML(d) {
  let h = '<div class="hd"><b>#' + d.id + '</b> <span>' + esc(d.kind) + '</span> <span class="dim">' + (d.species.name ? esc(d.species.name) : 'species ' + d.species.id) + '</span></div>';
  if (!d.alive) h += '<div class="banner" id="insp-dead">DEAD at tick ' + d.died_tick + ' (cause: ' + esc(d.death_cause) + '). Last known values:</div>';
  h += '<table><tr><th>species</th><td colspan="2">' + esc(d.species.name || '-') + ' (id ' + d.species.id + (d.species.parent ? ', from ' + d.species.parent : '') + ')</td></tr>';
  h += '<tr><th>age</th><td class="n">' + d.age + ' / ' + d.max_lifespan + '</td><td>' + meter(pct(d.age, 0, d.max_lifespan), 'a') + '</td></tr>';
  h += '<tr><th>energy</th><td class="n">' + fmt(d.energy, 1) + ' / ' + fmt(d.max_energy, 1) + '</td><td>' + meter(pct(d.energy, 0, d.max_energy), 'e') + '</td></tr>';
  h += '<tr><th>health</th><td class="n">' + fmt(d.health, 1) + ' / ' + fmt(d.max_health, 1) + '</td><td>' + meter(pct(d.health, 0, d.max_health), 'h') + '</td></tr>';
  h += '<tr><th>position</th><td colspan="2">' + d.pos.x + ', ' + d.pos.y + ' &middot; generation ' + d.generation + ' &middot; born ' + d.birth_tick + '</td></tr>';
  h += '<tr><th>parents</th><td colspan="2">';
  const ps = d.parents.map((p) => p.alive ? '<a class="par" data-id="' + p.id + '">#' + p.id + '</a>' : '<span class="dim">#' + p.id + ' (dead)</span>');
  h += ps.length ? ps.join(', ') : '<span class="dim">none (founder)</span>';
  h += '</td></tr></table><h3>Traits</h3><table>';
  for (const k of Object.keys(d.traits)) h += '<tr><th>' + k + '</th><td class="n">' + fmt(d.traits[k], 2) + '</td></tr>';
  h += '</table><h3>Genome (two alleles per gene, 0..1; white mark = species reference)</h3><table><tr><th>gene</th><th>allele A</th><th>allele B</th></tr>';
  for (const g of d.genes) {
    const het = Math.abs(g.a0 - g.a1) > 0.05;
    h += '<tr' + (het ? ' class="het"' : '') + ' title="' + g.name + ': ' + fmt(g.a0, 3) + ' / ' + fmt(g.a1, 3) + '"><th>' + g.name + '</th>' +
      '<td>' + meter(g.a0 * 100, 'a', g.ref ? g.ref[0] * 100 : null) + '</td><td>' + meter(g.a1 * 100, 'a', g.ref ? g.ref[1] * 100 : null) + '</td><td class="n">' + fmt(g.a0, 2) + ' / ' + fmt(g.a1, 2) + '</td></tr>';
  }
  return h + '</table>';
}
if (typeof module !== 'undefined') module.exports = { decodeFrame, record, screenToWorld, zoomAt, panBy, fitCamera, wrapCamera, MAGIC, worldCellFromPointer, speedLabel, fmt, pct, inspectorHTML };

if (typeof document !== 'undefined') (function () {
  const q = new URLSearchParams(location.search);
  const mode = q.has('smoke') ? 'smoke' : q.has('shot') ? 'shot' : 'live';
  const $ = (id) => document.getElementById(id);
  if (q.has('inspect')) document.body.classList.add('inspect-shot');
  const canvas = $('world'), ctx = canvas.getContext('2d');
  const stats = window.__evosim = { frames: 0, lastTick: -1, organisms: 0, fps: 0, fetches: 0, ready: false };
  let info = null, terrainCanvas = null, frame = null, cam = null, dirty = true, cw = 0, ch = 0, dpr = 1;
  let reported = false;
  let insp = null, st = null, epoch = 0, down = null, lastInspTick = -1;
  const kindRGB = (i) => 'rgb(' + info.kinds[i].color.join(',') + ')';

  function resize() {
    const r = canvas.getBoundingClientRect();
    dpr = window.devicePixelRatio || 1;
    cw = Math.max(1, Math.round(r.width)); ch = Math.max(1, Math.round(r.height));
    canvas.width = Math.round(cw * dpr); canvas.height = Math.round(ch * dpr);
    if (info && !cam) cam = fitCamera(info.width, info.height, cw, ch);
    dirty = true;
  }

  function drawGlyph(c, kind, x, y, s, energy) {
    // kind 0 plant: small round dot; 1 herbivore: big disc with light ring; 2 carnivore: red diamond with light ring.
    const a = 0.5 + 0.5 * (energy / 255);
    if (s < 3) {
      c.globalAlpha = kind === 0 ? 0.85 : 1;
      c.fillStyle = kindRGB(kind);
      const z = kind === 0 ? 1 : kind === 1 ? 3 : 4;
      if (kind !== 0) { c.fillStyle = '#fff'; c.fillRect(x - z / 2 - 0.5, y - z / 2 - 0.5, z + 1, z + 1); c.fillStyle = kindRGB(kind); }
      c.fillRect(x - z / 2, y - z / 2, z, z);
      return;
    }
    c.globalAlpha = kind === 0 ? 0.55 + 0.4 * (energy / 255) : a;
    const r = kind === 0 ? 0.22 * s : kind === 1 ? 0.38 * s : 0.46 * s;
    c.beginPath();
    if (kind === 2) { c.moveTo(x, y - r); c.lineTo(x + r, y); c.lineTo(x, y + r); c.lineTo(x - r, y); c.closePath(); }
    else c.arc(x, y, r, 0, 6.2832);
    c.fillStyle = kindRGB(kind); c.fill();
    c.lineWidth = kind === 0 ? 0.6 : Math.max(1, s * 0.09);
    c.strokeStyle = kind === 0 ? '#0b3d12' : '#fff'; c.stroke();
  }

  function draw() {
    dirty = false;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalAlpha = 1; ctx.fillStyle = '#05080c'; ctx.fillRect(0, 0, cw, ch);
    if (!info || !terrainCanvas || !cam) return;
    const W = info.width, H = info.height, s = cam.s;
    const left = cam.cx - cw / 2 / s, top = cam.cy - ch / 2 / s, right = cam.cx + cw / 2 / s, bottom = cam.cy + ch / 2 / s;
    const tx0 = Math.floor(left / W), tx1 = Math.floor((right - 1e-9) / W), ty0 = Math.floor(top / H), ty1 = Math.floor((bottom - 1e-9) / H);
    ctx.imageSmoothingEnabled = false;
    for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
      const sx = cw / 2 + (tx * W - cam.cx) * s, sy = ch / 2 + (ty * H - cam.cy) * s;
      ctx.drawImage(terrainCanvas, Math.round(sx), Math.round(sy), Math.ceil(W * s), Math.ceil(H * s));
      if (s >= 14) { // faint grid when zoomed in
        ctx.globalAlpha = 0.12; ctx.strokeStyle = '#000'; ctx.lineWidth = 1; ctx.beginPath();
        for (let i = 0; i <= W; i++) { const x = Math.round(sx + i * s) + 0.5; ctx.moveTo(x, sy); ctx.lineTo(x, sy + H * s); }
        for (let j = 0; j <= H; j++) { const y = Math.round(sy + j * s) + 0.5; ctx.moveTo(sx, y); ctx.lineTo(sx + W * s, y); }
        ctx.stroke(); ctx.globalAlpha = 1;
      }
    }
    if (frame) {
      let drawn = 0;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const ox = cw / 2 + (tx * W - cam.cx + 0.5) * s, oy = ch / 2 + (ty * H - cam.cy + 0.5) * s;
        for (let i = 0; i < frame.n; i++) {
          const o = frame.base + i * REC, d = frame.view;
          const x = ox + d.getUint16(o, true) * s, y = oy + d.getUint16(o + 2, true) * s;
          if (x < -s || y < -s || x > cw + s || y > ch + s) continue;
          drawGlyph(ctx, d.getUint8(o + 4), x, y, s, d.getUint8(o + 5)); drawn++;
        }
      }
      ctx.globalAlpha = 1;
      stats.organisms = frame.n; stats.drawn = drawn;
    }
    if (insp && info) {
      const t = performance.now() / 1000;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const x = cw / 2 + (tx * W - cam.cx + 0.5 + insp.pos.x) * s, y = ch / 2 + (ty * H - cam.cy + 0.5 + insp.pos.y) * s;
        if (x < -300 || y < -300 || x > cw + 300 || y > ch + 300) continue;
        if (insp.alive && $('c-vision').checked) {
          ctx.globalAlpha = 0.9; ctx.strokeStyle = '#ffe14a'; ctx.setLineDash([5, 4]); ctx.lineWidth = 1.5; ctx.beginPath();
          const v = (insp.traits.vision + 0.5) * s; ctx.rect(x - v, y - v, 2 * v, 2 * v); ctx.stroke(); ctx.setLineDash([]);
        }
        const r = Math.max(7, 0.7 * s) + (insp.alive ? 2 * Math.sin(t * 5) : 0);
        ctx.globalAlpha = 1; ctx.lineWidth = 3; ctx.strokeStyle = insp.alive ? '#ffe14a' : '#ff2d55';
        ctx.beginPath(); ctx.arc(x, y, r, 0, 6.2832); ctx.stroke();
        ctx.lineWidth = 1; ctx.strokeStyle = '#000'; ctx.beginPath(); ctx.arc(x, y, r + 2, 0, 6.2832); ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    stats.frames++;
    $('zoominfo').textContent = 'cell size ' + s.toFixed(1) + ' px';
    if (!reported && frame && terrainCanvas && mode !== 'live') report();
  }

  function report() {
    reported = true;
    fetch('/api/rendered', { method: 'POST', body: JSON.stringify({ tick: frame.tick, frames: stats.frames, organisms: frame.n }) }).catch(() => {});
  }

  function buildTerrain(buf) {
    const W = info.width, H = info.height, c = document.createElement('canvas');
    c.width = W; c.height = H;
    const g = c.getContext('2d'), img = g.createImageData(W, H), b = new Uint8Array(buf);
    for (let i = 0; i < W * H; i++) { const col = info.biomes[b[i]].color; img.data[i * 4] = col[0]; img.data[i * 4 + 1] = col[1]; img.data[i * 4 + 2] = col[2]; img.data[i * 4 + 3] = 255; }
    g.putImageData(img, 0, 0);
    terrainCanvas = c;
  }

  function buildLegend() {
    const lk = $('legend-kinds'), lb = $('legend-biomes');
    const names = ['Plant (small green dot)', 'Herbivore (blue disc)', 'Carnivore (red diamond)'];
    info.kinds.forEach((k, i) => {
      const li = document.createElement('li'), c = document.createElement('canvas');
      c.width = 22; c.height = 22; const g = c.getContext('2d');
      g.fillStyle = '#6b7f5a'; g.fillRect(0, 0, 22, 22);
      drawGlyph(g, i, 11, 11, i === 0 ? 24 : 22, 255);
      li.appendChild(c); li.appendChild(document.createTextNode(names[i])); lk.appendChild(li);
    });
    info.biomes.forEach((b) => {
      const li = document.createElement('li'), sw = document.createElement('span');
      sw.className = 'sw'; sw.style.background = 'rgb(' + b.color.join(',') + ')';
      li.appendChild(sw); li.appendChild(document.createTextNode(b.name.replace(/_/g, ' ') + ' (' + b.letter + ')')); lb.appendChild(li);
    });
  }

  function updateStats(f) {
    $('s-tick').textContent = f.tick; $('s-plants').textContent = f.counts[0]; $('s-herb').textContent = f.counts[1]; $('s-carn').textContent = f.counts[2];
    $('s-run').textContent = f.running ? 'running' : 'paused';
  }

  let fpsT = performance.now(), fpsN = 0;
  async function pollLoop() {
    for (;;) {
      try {
        const r = await fetch('/api/frame?since=' + stats.lastTick + (frame ? '&run=' + (frame.running ? 1 : 0) : ''));
        stats.fetches++;
        if (r.status === 200) {
          const f = decodeFrame(await r.arrayBuffer());
          if (f) {
            frame = f; stats.lastTick = f.tick; updateStats(f); dirty = true; fpsN++;
            if (st && st.selected !== null && f.tick !== lastInspTick) await refreshInspect(); 
            if (mode !== 'live') draw();
            const now = performance.now();
            if (now - fpsT > 1000) { stats.fps = fpsN * 1000 / (now - fpsT); fpsN = 0; fpsT = now; }
            $('status').textContent = 'tick ' + f.tick + ' - ' + f.n + ' organisms - ' + stats.fps.toFixed(1) + ' updates/s';
          }
          await new Promise((res) => setTimeout(res, 15));
        } else await new Promise((res) => setTimeout(res, 40));
      } catch (e) { $('status').textContent = 'disconnected'; await new Promise((res) => setTimeout(res, 500)); }
      if (mode === 'shot' && frame) return;
    }
  }

  function loop() { if (dirty || (insp && insp.alive)) draw(); requestAnimationFrame(loop); }

  // interaction
  let drag = null;
  const apply = (c) => { cam = wrapCamera(c, info.width, info.height); dirty = true; };
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault(); if (!cam) return;
    const r = canvas.getBoundingClientRect();
    apply(zoomAt(cam, e.clientX - r.left, e.clientY - r.top, e.deltaY < 0 ? 1.15 : 1 / 1.15, cw, ch));
  }, { passive: false });
  canvas.addEventListener('pointerdown', (e) => { drag = { x: e.clientX, y: e.clientY }; down = { x: e.clientX, y: e.clientY, moved: 0 }; canvas.setPointerCapture(e.pointerId); canvas.classList.add('drag'); });
  canvas.addEventListener('pointermove', (e) => {
    if (!drag || !cam) return;
    if (down) down.moved = Math.max(down.moved, Math.abs(e.clientX - down.x) + Math.abs(e.clientY - down.y));
    if (down && down.moved < 4) return; // below the threshold it is a click, not a pan
    apply(panBy(cam, e.clientX - drag.x, e.clientY - drag.y)); drag = { x: e.clientX, y: e.clientY };
  });
  const end = () => { drag = null; canvas.classList.remove('drag'); };
  canvas.addEventListener('pointerup', (e) => {
    const wasClick = down && down.moved < 4 && cam && info;
    down = null; end();
    if (wasClick) {
      const r = canvas.getBoundingClientRect();
      const c = worldCellFromPointer(cam, e.clientX - r.left, e.clientY - r.top, cw, ch, info.width, info.height);
      select({ x: c.x, y: c.y });
    }
  });
  canvas.addEventListener('pointercancel', () => { down = null; end(); });
  canvas.addEventListener('dblclick', () => { if (info) apply(fitCamera(info.width, info.height, cw, ch)); });
  window.addEventListener('keydown', (e) => {
    const tag = (e.target && e.target.tagName) || '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || e.ctrlKey || e.metaKey || e.altKey) return;
    if (!$('setup').hidden) { if (e.key === 'Escape') closeSetup(); return; }
    let handled = true;
    if (e.key === 'n') openSetup();
    else if (e.key === 'c') toggleCharts();
    else if (e.key === ' ') cmd(st && st.running ? 'pause' : 'run');
    else if (e.key === '.') cmd('step');
    else if (e.key === 'r') cmd('reset');
    else if (e.key === '[') cmd('speed', { level: (st ? st.speed_level : 2) - 1 });
    else if (e.key === ']') cmd('speed', { level: (st ? st.speed_level : 2) + 1 });
    else if (e.key === 's') cmd('save', { path: $('ckpt-path').value });
    else if (e.key === 'l') cmd('load', { path: $('ckpt-path').value });
    else if (e.key === 'Escape') cmd('deselect');
    else handled = false;
    if (handled) { e.preventDefault(); return; }
    if (!cam) return;
    const pan = 40;
    if (e.key === '+' || e.key === '=') apply(zoomAt(cam, cw / 2, ch / 2, 1.25, cw, ch));
    else if (e.key === '-') apply(zoomAt(cam, cw / 2, ch / 2, 1 / 1.25, cw, ch));
    else if (e.key === '0') apply(fitCamera(info.width, info.height, cw, ch));
    else if (e.key === 'ArrowLeft') apply(panBy(cam, pan, 0)); else if (e.key === 'ArrowRight') apply(panBy(cam, -pan, 0));
    else if (e.key === 'ArrowUp') apply(panBy(cam, 0, pan)); else if (e.key === 'ArrowDown') apply(panBy(cam, 0, -pan));
    else return;
    e.preventDefault();
  });
  window.addEventListener('resize', () => { resize(); drawCharts(); });
  if (window.ResizeObserver) new ResizeObserver(() => { resize(); drawCharts(); }).observe($('world-wrap'));
  stats.zoom = (f) => { if (cam) apply(zoomAt(cam, cw / 2, ch / 2, f, cw, ch)); };
  stats.pan = (dx, dy) => { if (cam) apply(panBy(cam, dx, dy)); };
  stats.camera = () => cam;

  // ---- controls and inspector (ADR-0028) ----
  async function cmd(name, extra) {
    try {
      const r = await fetch('/api/cmd', { method: 'POST', body: JSON.stringify(Object.assign({ cmd: name }, extra || {})) });
      const j = await r.json();
      if (name === 'save' || name === 'load' || name === 'reset' || !j.ok) $('ctl-msg').textContent = j.ok ? (j.message || name + ' done') : (j.message || 'failed');
      await refreshState();
      if (name === 'deselect' || name === 'reset' || name === 'load') { insp = null; renderInspector(); }
      return j;
    } catch (e) { $('ctl-msg').textContent = 'error: ' + e; }
  }
  async function select(arg) {
    const j = await cmd('select', arg);
    if (j && j.ok) { lastInspTick = -1; await refreshInspect(); } else if (j) $('ctl-msg').textContent = 'no organism at that spot';
  }
  stats.cmd = cmd; stats.select = select;
  function renderInspector() {
    const box = $('insp');
    $('insp-empty').hidden = !!insp; box.hidden = !insp;
    if (insp) box.innerHTML = inspectorHTML(insp);
    box.querySelectorAll('a.par').forEach((a) => a.addEventListener('click', () => select({ id: Number(a.dataset.id) })));
    dirty = true;
  }
  async function refreshInspect() {
    const r = await fetch('/api/inspect');
    if (r.status === 200) {
      insp = await r.json(); lastInspTick = insp.tick; stats.inspected = insp.id; renderInspector();
      if ($('c-follow').checked && insp.alive && cam) apply({ s: cam.s, cx: insp.pos.x, cy: insp.pos.y });
    } else if (insp) { insp = null; renderInspector(); }
  }
  async function refreshState() {
    const r = await fetch('/api/state');
    st = await r.json();
    $('speed-label').textContent = speedLabel(st.speed_level, st.speed_levels, st.tps);
    $('b-run').classList.toggle('on', st.running); $('b-pause').classList.toggle('on', !st.running);
    $('b-slower').disabled = st.speed_level <= 0; $('b-faster').disabled = st.speed_level >= st.speed_levels - 1;
    $('s-tick').textContent = st.tick; $('s-plants').textContent = st.plants; $('s-herb').textContent = st.herbivores; $('s-carn').textContent = st.carnivores;
    $('s-run').textContent = st.running ? 'running' : 'paused';
    if (st.epoch !== epoch) { await loadWorld(); await refreshCharts(); }
    if (st.selected === null && insp) { insp = null; renderInspector(); }
  }
  async function loadWorld() {
    const ni = await (await fetch('/api/info')).json();
    const sizeChanged = !info || ni.width !== info.width || ni.height !== info.height;
    info = ni; epoch = ni.epoch;
    buildTerrain(await (await fetch('/api/terrain')).arrayBuffer());
    if (sizeChanged) { cam = fitCamera(info.width, info.height, cw, ch); }
    frame = null; stats.lastTick = -1; dirty = true;
  }
  $('b-run').onclick = () => cmd('run'); $('b-pause').onclick = () => cmd('pause'); $('b-step').onclick = () => cmd('step');
  $('b-reset').onclick = () => cmd('reset');
  $('b-slower').onclick = () => cmd('speed', { level: (st ? st.speed_level : 2) - 1 });
  $('b-faster').onclick = () => cmd('speed', { level: (st ? st.speed_level : 2) + 1 });
  $('b-save').onclick = () => cmd('save', { path: $('ckpt-path').value });
  $('b-load').onclick = () => cmd('load', { path: $('ckpt-path').value });
  setInterval(() => { if (mode === 'live') refreshState().catch(() => {}); }, 250);

  // ---- charts and setup (ADR-0029) ----
  let chartData = null, hist = null, chartKey = '', histKey = '';
  const chartIds = { pop: 'ch-pop', bd: 'ch-bd', species: 'ch-species', trait: 'ch-trait' };
  const kindColors = () => (info ? info.kinds.map((k) => 'rgb(' + k.color.join(',') + ')') : ['#7dff3a', '#2f7bff', '#ff2d55']);
  function fillTraitSelects(names) {
    for (const id of ['sel-trait', 'sel-htrait']) {
      const s = $(id); if (s.options.length === names.length) continue;
      s.textContent = ''; names.forEach((n, i) => { const o = document.createElement('option'); o.value = i; o.textContent = n; s.append(o); });
      s.value = id === 'sel-trait' ? '0' : '0';
    }
  }
  function drawCharts() {
    if (!chartData || document.body.classList.contains('no-charts')) return;
    const trait = chartData.trait_names[+$('sel-trait').value || 0];
    const specs = chartSpecs(chartData, kindColors(), trait);
    for (const k of Object.keys(chartIds)) drawLineChart($(chartIds[k]), specs[k]);
    if (hist) {
      const colors = kindColors();
      drawHistogram($('ch-hist'), { title: 'Distribution of ' + hist.name + ' (' + hist.kind_name + ', tick ' + hist.tick + ')', xLabel: hist.name, yLabel: 'number of individuals', edges: hist.edges, counts: hist.bins, color: colors[hist.kind], label: hist.kind_name + ' (n=' + hist.n + ')' });
    }
  }
  async function refreshHist() {
    const r = await fetch('/api/cmd', { method: 'POST', body: JSON.stringify({ cmd: 'hist', kind: +$('sel-hkind').value, trait: +$('sel-htrait').value, bins: 24 }) });
    if (r.ok) hist = await r.json();
  }
  async function refreshCharts() {
    if (document.body.classList.contains('no-charts') || !info) return;
    const d = await (await fetch('/api/charts')).json();
    const key = d.epoch + ':' + d.n + ':' + (d.ticks.length ? d.ticks[d.ticks.length - 1] : -1);
    const tick = st ? st.tick : 0;
    const hk = key + ':' + tick + ':' + $('sel-hkind').value + ':' + $('sel-htrait').value;
    if (key !== chartKey) { chartKey = key; chartData = d; fillTraitSelects(d.trait_names); }
    if (hk !== histKey) { histKey = hk; await refreshHist(); }
    drawCharts(); stats.charts = (stats.charts || 0) + 1;
  }
  function toggleCharts(force) {
    const on = force === undefined ? document.body.classList.contains('no-charts') : force;
    document.body.classList.toggle('no-charts', !on); $('b-charts').classList.toggle('on', on);
    resize(); if (on) { chartKey = ''; refreshCharts().catch(() => {}); }
  }
  for (const id of ['sel-trait', 'sel-htrait', 'sel-hkind']) $(id).addEventListener('change', () => { histKey = ''; refreshCharts().catch(() => {}); });
  $('b-charts').onclick = () => toggleCharts();
  async function openSetup() {
    $('setup').hidden = false;
    if (!EvoSetup.isBuilt()) await EvoSetup.load().catch((e) => EvoSetup.msg('cannot load the setup form: ' + e, true));
  }
  function closeSetup() { $('setup').hidden = true; }
  $('b-new').onclick = openSetup; $('su-cancel').onclick = closeSetup;
  $('su-check').onclick = () => EvoSetup.check();
  $('su-start').onclick = async () => { if (await EvoSetup.start()) { closeSetup(); await refreshState().catch(() => {}); await refreshCharts().catch(() => {}); } };
  $('su-export').onclick = () => EvoSetup.exportFile();
  $('su-import').onclick = () => $('su-file').click();
  $('su-file').onchange = (e) => { if (e.target.files[0]) EvoSetup.importFile(e.target.files[0]); e.target.value = ''; };
  stats.charts = 0;
  setInterval(() => { if (mode === 'live') refreshCharts().catch(() => {}); }, 500);

  (async function init() {
    info = await (await fetch('/api/info')).json();
    buildTerrain(await (await fetch('/api/terrain')).arrayBuffer());
    epoch = info.epoch;
    buildLegend();
    resize();
    await refreshState().catch(() => {});
    await refreshInspect().catch(() => {});
    if (mode === 'shot' && q.has('inspect') && insp && cam) { apply({ s: 18, cx: insp.pos.x, cy: insp.pos.y }); }
    const view = q.get('view');
    if (view === 'charts') document.body.classList.add('view-charts');
    resize();
    if (q.has('hkind')) $('sel-hkind').value = q.get('hkind');
    if (q.has('trait')) { await refreshCharts().catch(() => {}); $('sel-trait').value = q.get('trait'); $('sel-htrait').value = q.get('trait'); chartKey = ''; histKey = ''; }
    await refreshCharts().catch(() => {});
    if (view === 'setup') {
      await openSetup();
      if (q.has('bad')) { EvoSetup.fill({ 'world.width': '0', 'plants.growth_rate': '-1' }); await EvoSetup.start(); }
    }
    stats.ready = true;
    requestAnimationFrame(loop);
    pollLoop();
  })().catch((e) => { $('status').textContent = 'error: ' + e; });
})();

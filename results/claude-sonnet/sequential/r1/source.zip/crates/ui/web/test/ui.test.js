'use strict';
// usage: node ui.test.js app.js  (control and inspector helpers, ADR-0028)
const assert = require('assert');
const a = require(require('path').resolve(process.argv[2]));
// pointer -> world cell, with wrap-around
let cam = a.fitCamera(64, 48, 1280, 960); // 20 px per cell, centred
assert.deepStrictEqual(a.worldCellFromPointer(cam, 640, 480, 1280, 960, 64, 48), { x: 32, y: 24 });
assert.deepStrictEqual(a.worldCellFromPointer(cam, 0, 0, 1280, 960, 64, 48), { x: 0, y: 0 });
assert.deepStrictEqual(a.worldCellFromPointer(cam, 1279, 959, 1280, 960, 64, 48), { x: 63, y: 47 });
const off = { s: 20, cx: 0, cy: 0 }; // camera at the seam: left of the origin wraps to the far edge
assert.deepStrictEqual(a.worldCellFromPointer(off, 640 - 10, 480 - 10, 1280, 960, 64, 48), { x: 63, y: 47 });
// labels
assert.strictEqual(a.speedLabel(0, 5, 1), 'level 1/5 (1 ticks/s)');
assert.strictEqual(a.speedLabel(4, 5, 200), 'level 5/5 (200 ticks/s)');
assert.strictEqual(a.speedLabel(-3, 5, 5), 'level 1/5 (5 ticks/s)');
assert.strictEqual(a.speedLabel(99, 5, 5), 'level 5/5 (5 ticks/s)');
assert.strictEqual(a.fmt(1.2345, 2), '1.23');
assert.strictEqual(a.fmt(NaN), '-');
assert.strictEqual(a.pct(5, 0, 10), 50);
assert.strictEqual(a.pct(-5, 0, 10), 0);
assert.strictEqual(a.pct(50, 0, 10), 100);
// inspector HTML contains the required fields
const gene = (n) => ({ name: n, a0: 0.4, a1: 0.7, value: 0.55, ref: [0.5, 0.5] });
const d = {
  id: 42, kind: 'herbivore', alive: true, tick: 10, died_tick: null, death_cause: '', species: { id: 3, name: 'Baus ba', parent: 1 },
  age: 12, max_lifespan: 300, energy: 50, max_energy: 100, health: 8, max_health: 10, pos: { x: 3, y: 4 }, generation: 2, birth_tick: 0,
  parents: [{ id: 7, alive: true, kind: 'herbivore' }, { id: 9, alive: false, kind: 'unknown' }],
  traits: { speed: 1, strength: 1, fertility: 0.5, max_health: 10, max_lifespan: 300, max_energy: 100, metabolism: 1, vision: 4, aggression: 0.3, risk_tolerance: 0.4 },
  genes: ['speed', 'strength', 'fertility', 'max_health', 'max_lifespan', 'max_energy', 'metabolism', 'vision', 'aggression', 'risk_tolerance'].map(gene),
};
let h = a.inspectorHTML(d);
for (const t of ['#42', 'herbivore', 'Baus ba', 'age', 'energy', 'health', 'Genome', 'data-id="7"', '#9 (dead)', 'risk_tolerance']) assert(h.includes(t), t);
assert(!h.includes('DEAD'));
d.alive = false; d.died_tick = 11; d.death_cause = 'unknown';
h = a.inspectorHTML(d);
assert(h.includes('DEAD at tick 11'));
d.species.name = '<b>x</b>';
assert(!a.inspectorHTML(d).includes('<b>x</b>'), 'escaped');
console.log('ok');

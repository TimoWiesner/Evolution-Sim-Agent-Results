'use strict';
// Own chart drawing code (ADR-0029): pure helpers (tested with node) + canvas 2D drawing. No library.
const KIND_NAMES = ['plants', 'herbivores', 'carnivores'];

// "Nice" tick values covering [lo, hi] with about `count` ticks.
function niceTicks(lo, hi, count, integer) {
  count = count || 5;
  if (!isFinite(lo) || !isFinite(hi)) return [0, 1];
  if (hi < lo) { const t = lo; lo = hi; hi = t; }
  if (hi === lo) { hi = lo + 1; }
  const raw = (hi - lo) / Math.max(1, count);
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const f = raw / p;
  let step = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
  if (integer && step < 1) step = 1;
  const out = [];
  const start = Math.ceil(lo / step - 1e-9) * step;
  for (let v = start; v <= hi + step * 1e-9; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : +v.toPrecision(12));
  return out;
}
function formatTick(v) {
  const a = Math.abs(v);
  if (v === 0) return '0';
  if (a >= 1e6) return (v / 1e6).toFixed(a >= 1e7 ? 0 : 1).replace(/\.0$/, '') + 'M';
  if (a >= 1e4) return (v / 1e3).toFixed(a >= 1e5 ? 0 : 1).replace(/\.0$/, '') + 'k';
  if (a >= 100) return String(Math.round(v));
  if (a >= 1) return String(+v.toFixed(2));
  return String(+v.toPrecision(2));
}
// Linear scale from data [d0,d1] to pixels [r0,r1]; a degenerate domain maps to the middle.
function buildScale(d0, d1, r0, r1) {
  return { d0, d1, r0, r1, map(v) { return d1 === d0 ? (r0 + r1) / 2 : r0 + (v - d0) / (d1 - d0) * (r1 - r0); } };
}
// Polyline segments; null / NaN values break the line (gaps for extinct kinds).
function seriesPath(xs, ys, sx, sy) {
  const segs = []; let cur = null;
  for (let i = 0; i < xs.length; i++) {
    const y = ys[i];
    if (y === null || y === undefined || !isFinite(y)) { cur = null; continue; }
    if (!cur) { cur = []; segs.push(cur); }
    cur.push([sx.map(xs[i]), sy.map(y)]);
  }
  return segs;
}
function legendItems(series) { return series.map((s) => ({ label: s.label, color: s.color, dash: !!s.dash })); }
function dataRange(series, zeroBased) {
  let lo = Infinity, hi = -Infinity;
  for (const s of series) for (const v of s.ys) if (v !== null && v !== undefined && isFinite(v)) { if (v < lo) lo = v; if (v > hi) hi = v; }
  if (lo === Infinity) { lo = 0; hi = 1; }
  if (zeroBased) lo = Math.min(0, lo);
  if (hi === lo) hi = lo + 1;
  else if (!zeroBased) { const pad = (hi - lo) * 0.08; lo -= pad; hi += pad; }
  return [lo, hi];
}
// Histogram bars as rectangles in data space: [x0, x1, count].
function histBars(edges, counts) { return counts.map((c, i) => [edges[i], edges[i + 1], c]); }

const COL = { axis: '#8a9bb0', grid: '#2a3646', text: '#dbe4ee', bg: '#0c1218' };

function prepare(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const r = canvas.getBoundingClientRect();
  const w = Math.max(60, Math.round(r.width)), h = Math.max(50, Math.round(r.height));
  if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) { canvas.width = Math.round(w * dpr); canvas.height = Math.round(h * dpr); }
  const c = canvas.getContext('2d');
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.fillStyle = COL.bg; c.fillRect(0, 0, w, h);
  return { c, w, h };
}
function drawFrame(c, w, h, spec, xTicks, yTicks, sx, sy, box) {
  c.font = '11px system-ui, sans-serif'; c.lineWidth = 1;
  c.fillStyle = COL.text; c.textAlign = 'left'; c.textBaseline = 'top';
  c.font = 'bold 12px system-ui, sans-serif'; c.fillText(spec.title, 8, 5);
  c.font = '11px system-ui, sans-serif';
  c.strokeStyle = COL.grid; c.fillStyle = COL.axis;
  c.textAlign = 'right'; c.textBaseline = 'middle';
  for (const t of yTicks) { const y = Math.round(sy.map(t)) + 0.5; c.beginPath(); c.moveTo(box.l, y); c.lineTo(box.r, y); c.stroke(); c.fillText(formatTick(t), box.l - 4, y); }
  c.textAlign = 'center'; c.textBaseline = 'top';
  for (const t of xTicks) { const x = Math.round(sx.map(t)) + 0.5; c.beginPath(); c.moveTo(x, box.t); c.lineTo(x, box.b); c.stroke(); c.fillText(formatTick(t), x, box.b + 3); }
  c.strokeStyle = COL.axis; c.beginPath(); c.moveTo(box.l + 0.5, box.t); c.lineTo(box.l + 0.5, box.b + 0.5); c.lineTo(box.r, box.b + 0.5); c.stroke();
  c.fillStyle = COL.text; c.textAlign = 'center'; c.textBaseline = 'bottom';
  c.fillText(spec.xLabel, (box.l + box.r) / 2, h - 2);
  c.save(); c.translate(11, (box.t + box.b) / 2); c.rotate(-Math.PI / 2); c.textBaseline = 'top'; c.fillText(spec.yLabel, 0, 0); c.restore();
}
// Legend rows (wrapped to the available width); each row is a list of {it, w}.
function legendRows(c, items, avail) {
  c.font = '11px system-ui, sans-serif';
  const rows = [[]]; let used = 0;
  for (const it of items) {
    const w = c.measureText(it.label).width + 30;
    if (used + w > avail && rows[rows.length - 1].length) { rows.push([]); used = 0; }
    rows[rows.length - 1].push({ it, w }); used += w;
  }
  return rows;
}
function drawLegend(c, rows, right, top) {
  c.font = '11px system-ui, sans-serif'; c.textAlign = 'left'; c.textBaseline = 'middle';
  rows.forEach((row, ri) => {
    let x = right - row.reduce((a, b) => a + b.w, 0); const y = top + ri * 13;
    for (const { it, w } of row) {
      c.strokeStyle = it.color; c.lineWidth = 2; c.setLineDash(it.dash ? [4, 3] : []);
      c.beginPath(); c.moveTo(x, y); c.lineTo(x + 18, y); c.stroke(); c.setLineDash([]);
      c.fillStyle = COL.text; c.fillText(it.label, x + 22, y); x += w;
    }
  });
  c.lineWidth = 1;
}
// spec: {title, xLabel, yLabel, xs, series:[{label,color,dash,ys}], zeroBased, empty}
function drawLineChart(canvas, spec) {
  const { c, w, h } = prepare(canvas);
  const rows = legendRows(c, legendItems(spec.series), w - 16);
  const box = { l: 52, r: w - 10, t: 26 + rows.length * 13, b: h - 34 };
  const xs = spec.xs;
  const x0 = xs.length ? xs[0] : 0; let x1 = xs.length ? xs[xs.length - 1] : 1; if (x1 === x0) x1 = x0 + 1;
  const [y0, y1] = dataRange(spec.series, spec.zeroBased !== false);
  const yt = niceTicks(y0, y1, Math.max(2, Math.floor((box.b - box.t) / 38)), spec.integer), xt = niceTicks(x0, x1, Math.max(2, Math.floor((box.r - box.l) / 80)));
  const sx = buildScale(x0, x1, box.l, box.r);
  const sy = buildScale(yt[0] < y0 ? yt[0] : y0, Math.max(y1, yt[yt.length - 1]), box.b, box.t);
  drawFrame(c, w, h, spec, xt, yt, sx, sy, box);
  c.save(); c.beginPath(); c.rect(box.l, box.t - 2, box.r - box.l + 2, box.b - box.t + 4); c.clip();
  for (const s of spec.series) {
    c.strokeStyle = s.color; c.lineWidth = 1.6; c.setLineDash(s.dash ? [4, 3] : []);
    for (const seg of seriesPath(xs, s.ys, sx, sy)) {
      c.beginPath(); seg.forEach((p, i) => (i ? c.lineTo(p[0], p[1]) : c.moveTo(p[0], p[1]))); if (seg.length === 1) c.lineTo(seg[0][0] + 0.1, seg[0][1]); c.stroke();
    }
  }
  c.restore(); c.setLineDash([]);
  drawLegend(c, rows, w - 8, 25);
  if (!xs.length) { c.fillStyle = COL.axis; c.textAlign = 'center'; c.fillText('no data yet', (box.l + box.r) / 2, (box.t + box.b) / 2); }
}
// spec: {title, xLabel, yLabel, edges, counts, color, label}
function drawHistogram(canvas, spec) {
  const { c, w, h } = prepare(canvas);
  const box = { l: 52, r: w - 10, t: 39, b: h - 34 };
  const lrows = legendRows(c, [{ label: spec.label, color: spec.color, dash: false }], w - 16);
  const bars = histBars(spec.edges, spec.counts);
  const x0 = spec.edges[0], x1 = spec.edges[spec.edges.length - 1];
  const cmax = Math.max(1, ...spec.counts);
  const yt = niceTicks(0, cmax, Math.max(2, Math.floor((box.b - box.t) / 38)), true), xt = niceTicks(x0, x1, Math.max(2, Math.floor((box.r - box.l) / 80)));
  const sx = buildScale(x0, x1, box.l, box.r), sy = buildScale(0, Math.max(cmax, yt[yt.length - 1]), box.b, box.t);
  drawFrame(c, w, h, spec, xt, yt, sx, sy, box);
  c.fillStyle = spec.color;
  for (const [a, b, n] of bars) { if (n > 0) { const xa = sx.map(a), xb = sx.map(b); c.fillRect(xa + 0.5, sy.map(n), Math.max(1, xb - xa - 1), sy.map(0) - sy.map(n)); } }
  drawLegend(c, lrows, w - 8, 25);
  if (!spec.counts.some((n) => n > 0)) { c.fillStyle = COL.axis; c.textAlign = 'center'; c.fillText('no individuals of this kind', (box.l + box.r) / 2, (box.t + box.b) / 2); }
}
// Chart specifications from the /api/charts document (pure; colors = 3 css colors for plants/herbivores/carnivores).
function chartSpecs(d, colors, trait) {
  const mk = (block, dash) => KIND_NAMES.map((k, i) => ({ label: k + (dash ? ' deaths' : ''), color: colors[i], dash, ys: d[block][k] }));
  const births = KIND_NAMES.map((k, i) => ({ label: k + ' births', color: colors[i], dash: false, ys: d.births[k] }));
  return {
    pop: { title: 'Population per kind', xLabel: 'tick', yLabel: 'individuals', xs: d.ticks, series: mk('pop', false) },
    bd: { title: 'Births (solid) and deaths (dashed)', xLabel: 'tick', yLabel: 'per ' + d.interval + ' ticks', xs: d.ticks, series: births.concat(mk('deaths', true)) },
    species: { title: 'Living species per kind', xLabel: 'tick', yLabel: 'species', integer: true, xs: d.ticks, series: mk('species', false) },
    trait: { title: 'Mean ' + trait + ' per kind', xLabel: 'tick', yLabel: 'mean ' + trait, xs: d.ticks, zeroBased: false, series: KIND_NAMES.map((k, i) => ({ label: k, color: colors[i], dash: false, ys: d.trait_mean[k][trait] })) },
  };
}
if (typeof module !== 'undefined') module.exports = { niceTicks, formatTick, buildScale, seriesPath, legendItems, histBars, dataRange, chartSpecs, KIND_NAMES };

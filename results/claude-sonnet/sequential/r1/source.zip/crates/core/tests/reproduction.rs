//! TASK-016: animal reproduction (ADR-0020). Most tests call the phase directly so no movement interferes.
use evosim_core::config::Config;
use evosim_core::genome::{Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::organism::{Id, Kind, NewBorn};
use evosim_core::reproduction::{run_reproduction_phase, ReproductionStats, REPRO_PARENT_SHARE};
use evosim_core::rng::Rng;
use evosim_core::sim::{EventKind, Simulation};

fn p(x: i32, y: i32) -> Pos {
    Pos { x, y }
}

fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 9;
    c.world.width = 20;
    c.world.height = 20;
    c.initial.plants = 1;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    for a in [&mut c.herbivores, &mut c.carnivores] {
        a.maturity_age = 10;
        a.max_age = 1_000_000;
        a.reproduction_energy = 50.0;
        a.reproduction_cooldown = 5;
        a.mate_range = 2;
        a.offspring_energy = 20.0;
        a.litter_size = 1;
        a.mutation_rate = 0.0;
        a.base_metabolism = 0.0;
        a.move_cost = 0.0;
    }
    c.plants.max_age = 1_000_000;
    c.plants.maintenance = 0.0;
    c.plants.growth_rate = 0.0;
    c.plants.reproduction_threshold = c.plants.max_energy;
    c.genetics.species_threshold = 10.0;
    c
}

struct T {
    s: Simulation,
    founder: Id,
}

impl T {
    fn new(c: &Config) -> T {
        let s = Simulation::new(c).unwrap();
        let founder = s.organisms.vec(Kind::Plant)[0].id;
        T { s, founder }
    }
    fn add(&mut self, kind: Kind, pos: Pos, allele: f32, fertility: f64) -> Id {
        let g = Genome::from_alleles([[allele; 2]; N_GENES]);
        assert!(self.s.organisms.queue_birth(NewBorn { kind, pos, parents: [self.founder, 0], genome: g, energy: 100.0 }));
        let id = self.s.organisms.resolve_births(0).last().unwrap().0;
        let o = self.s.organisms.get_mut(kind, id).unwrap();
        o.age = 100;
        o.traits.fertility = fertility;
        o.traits.max_energy = 100.0;
        o.set_energy(100.0);
        id
    }
    fn animal(&mut self, kind: Kind, pos: Pos) -> Id {
        self.add(kind, pos, 0.5, 1.0)
    }
    fn fin(&mut self) {
        let f = self.founder;
        self.s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != f);
        self.s.rebuild_index();
    }
    /// One reproduction phase + birth resolution; returns the stats.
    fn mate(&mut self, rng: &mut Rng) -> ReproductionStats {
        let st = run_reproduction_phase(&mut self.s.organisms, &self.s.spatial, &self.s.config, 0, rng);
        for (id, kind) in self.s.organisms.resolve_births(0) {
            let pos = self.s.organisms.get(kind, id).unwrap().pos;
            self.s.spatial.insert(id, kind, pos).unwrap();
        }
        st
    }
    fn o(&self, kind: Kind, id: Id) -> &evosim_core::organism::Organism {
        self.s.organisms.get(kind, id).unwrap()
    }
}

fn births_for(c: &Config, f: impl FnOnce(&mut T)) -> u64 {
    let mut t = T::new(c);
    f(&mut t);
    t.fin();
    t.mate(&mut Rng::new(1)).offspring
}

#[test]
fn single_animal_never_reproduces() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        let mut c = cfg();
        c.herbivores.base_metabolism = 0.0;
        c.carnivores.base_metabolism = 0.0;
        let mut t = T::new(&c);
        t.animal(kind, p(3, 3));
        t.fin();
        let mut s = t.s;
        let id = s.organisms.vec(kind)[0].id;
        s.organisms.get_mut(kind, id).unwrap().traits.max_lifespan = 1_000_000;
        let births0 = s.organisms.stats.births[kind.index()]; // the helper's own spawn
        for _ in 0..1500 {
            s.step();
            let o = s.organisms.vec(kind).first().map(|o| o.id);
            if let Some(i) = o {
                s.organisms.get_mut(kind, i).unwrap().set_energy(100.0);
            }
            assert_eq!(s.last_births, [0; 3], "tick {} kind {:?} pop {:?}", s.tick, kind, (s.organisms.count(Kind::Plant), s.organisms.count(Kind::Herbivore), s.organisms.count(Kind::Carnivore)));
            assert_eq!(s.last_reproduction_stats.matings, 0);
        }
        assert_eq!(s.organisms.stats.births[kind.index()], births0);
    }
}

#[test]
fn never_self_mates_and_two_needed() {
    let c = cfg();
    // second animal immature -> the first has no partner
    let n = births_for(&c, |t| {
        t.animal(Kind::Herbivore, p(3, 3));
        let b = t.animal(Kind::Herbivore, p(3, 3));
        t.s.organisms.get_mut(Kind::Herbivore, b).unwrap().age = 0;
    });
    assert_eq!(n, 0);
    // many animals: parents always differ and are of the right kind
    let mut t = T::new(&c);
    for i in 0..30 {
        t.animal(Kind::Herbivore, p(i % 6, i / 6));
    }
    t.fin();
    let mut rng = Rng::new(2);
    t.mate(&mut rng);
    let mut seen = 0;
    for o in t.s.organisms.vec(Kind::Herbivore) {
        if o.parents[0] != 0 && o.parents[0] != t.founder {
            seen += 1;
            assert_ne!(o.parents[0], o.parents[1]);
            assert!(t.s.organisms.get(Kind::Herbivore, o.parents[0]).is_some());
            assert!(t.s.organisms.get(Kind::Herbivore, o.parents[1]).is_some());
        }
    }
    assert!(seen > 0);
}

#[test]
fn needs_same_kind() {
    let c = cfg();
    let n = births_for(&c, |t| {
        t.animal(Kind::Herbivore, p(3, 3));
        t.animal(Kind::Carnivore, p(3, 3));
    });
    assert_eq!(n, 0);
}

#[test]
fn needs_closeness_incl_wrap() {
    let c = cfg();
    let r = c.herbivores.mate_range as i32;
    assert_eq!(births_for(&c, |t| { t.animal(Kind::Herbivore, p(5, 5)); t.animal(Kind::Herbivore, p(5 + r + 1, 5)); }), 0);
    assert_eq!(births_for(&c, |t| { t.animal(Kind::Herbivore, p(5, 5)); t.animal(Kind::Herbivore, p(5 + r, 5)); }), 1);
    // across the wrap seam (width 20)
    assert_eq!(births_for(&c, |t| { t.animal(Kind::Herbivore, p(19, 5)); t.animal(Kind::Herbivore, p(0, 5)); }), 1);
    let mut c0 = cfg();
    c0.herbivores.mate_range = 0;
    assert_eq!(births_for(&c0, |t| { t.animal(Kind::Herbivore, p(5, 5)); t.animal(Kind::Herbivore, p(6, 5)); }), 0);
    assert_eq!(births_for(&c0, |t| { t.animal(Kind::Herbivore, p(5, 5)); t.animal(Kind::Herbivore, p(5, 5)); }), 1);
}

#[test]
fn needs_maturity_and_energy_of_each_parent() {
    let c = cfg();
    for which in 0..2 {
        let n = births_for(&c, |t| {
            let a = t.animal(Kind::Herbivore, p(3, 3));
            let b = t.animal(Kind::Herbivore, p(3, 4));
            let x = if which == 0 { a } else { b };
            t.s.organisms.get_mut(Kind::Herbivore, x).unwrap().age = c.herbivores.maturity_age - 1;
        });
        assert_eq!(n, 0, "immature parent {}", which);
        let n = births_for(&c, |t| {
            let a = t.animal(Kind::Herbivore, p(3, 3));
            let b = t.animal(Kind::Herbivore, p(3, 4));
            let x = if which == 0 { a } else { b };
            t.s.organisms.get_mut(Kind::Herbivore, x).unwrap().set_energy(c.herbivores.reproduction_energy - 0.5);
        });
        assert_eq!(n, 0, "hungry parent {}", which);
    }
    // exactly at the thresholds -> allowed
    let n = births_for(&c, |t| {
        let a = t.animal(Kind::Herbivore, p(3, 3));
        let b = t.animal(Kind::Herbivore, p(3, 4));
        for x in [a, b] {
            let o = t.s.organisms.get_mut(Kind::Herbivore, x).unwrap();
            o.age = c.herbivores.maturity_age;
            o.set_energy(c.herbivores.reproduction_energy);
        }
    });
    assert_eq!(n, 1);
}

#[test]
fn incompatible_genomes_do_not_mate() {
    let mut c = cfg();
    c.genetics.species_threshold = 0.2; // alleles 0.2 vs 0.5 -> distance 0.3
    let far = births_for(&c, |t| { t.add(Kind::Herbivore, p(3, 3), 0.2, 1.0); t.add(Kind::Herbivore, p(3, 3), 0.5, 1.0); });
    assert_eq!(far, 0);
    let near = births_for(&c, |t| { t.add(Kind::Herbivore, p(3, 3), 0.35, 1.0); t.add(Kind::Herbivore, p(3, 3), 0.5, 1.0); });
    assert_eq!(near, 1);
    let mut t = T::new(&c);
    t.add(Kind::Herbivore, p(3, 3), 0.2, 1.0);
    t.add(Kind::Herbivore, p(3, 3), 0.5, 1.0);
    t.fin();
    assert!(t.mate(&mut Rng::new(1)).incompatible_seen > 0);
}

#[test]
fn offspring_genome_is_crossover_of_both_parents() {
    let c = cfg();
    let mut t = T::new(&c);
    let mut ga = [[0.0f32; 2]; N_GENES];
    let mut gb = [[0.0f32; 2]; N_GENES];
    for i in 0..N_GENES {
        ga[i] = [0.30 + 0.01 * i as f32, 0.40 + 0.01 * i as f32];
        gb[i] = [0.55 + 0.01 * i as f32, 0.65 + 0.01 * i as f32];
    }
    let mk = |t: &mut T, g: [[f32; 2]; N_GENES], pos| {
        let id = t.add(Kind::Herbivore, pos, 0.5, 1.0);
        let b = NewBorn { kind: Kind::Herbivore, pos, parents: [t.founder, 0], genome: Genome::from_alleles(g), energy: 100.0 };
        assert!(t.s.organisms.queue_birth(b));
        let nid = t.s.organisms.resolve_births(0).last().unwrap().0;
        t.s.organisms.vec_mut(Kind::Herbivore).retain(|o| o.id != id);
        let o = t.s.organisms.get_mut(Kind::Herbivore, nid).unwrap();
        o.age = 100;
        o.traits.fertility = 1.0;
        nid
    };
    let a = mk(&mut t, ga, p(2, 2));
    let b = mk(&mut t, gb, p(2, 2));
    let ga_s = t.o(Kind::Herbivore, a).genome().clone();
    let gb_s = t.o(Kind::Herbivore, b).genome().clone();
    t.fin();
    let mut mixed_a = false;
    for seed in 0..40 {
        let mut t2 = T { s: t.s.clone(), founder: t.founder };
        for id in [a, b] {
            t2.s.organisms.get_mut(Kind::Herbivore, id).unwrap().set_energy(100.0);
        }
        t2.mate(&mut Rng::new(seed as i64));
        let child = t2.s.organisms.vec(Kind::Herbivore).iter().find(|o| o.parents == [a, b]).expect("child of a,b");
        for i in 0..N_GENES {
            let [c0, c1] = child.genome().alleles()[i];
            assert!(ga_s.alleles()[i].contains(&c0), "slot0 from A at {}", i);
            assert!(gb_s.alleles()[i].contains(&c1), "slot1 from B at {}", i);
            if c0 == ga_s.alleles()[i][1] {
                mixed_a = true;
            }
        }
    }
    assert!(mixed_a, "crossover must pick both of A's alleles over many births");
    // mutation on: child differs from both gametes
    let mut cm = cfg();
    cm.herbivores.mutation_rate = 1.0;
    cm.genetics.mutation_sigma = 0.1;
    let mut t3 = T::new(&cm);
    let a = t3.animal(Kind::Herbivore, p(1, 1));
    let b = t3.animal(Kind::Herbivore, p(1, 1));
    t3.fin();
    let (g1, g2) = (t3.o(Kind::Herbivore, a).genome().clone(), t3.o(Kind::Herbivore, b).genome().clone());
    t3.mate(&mut Rng::new(4));
    let child = t3.s.organisms.vec(Kind::Herbivore).iter().find(|o| o.parents == [a, b]).unwrap();
    let diff = (0..N_GENES).filter(|&i| child.genome().alleles()[i] != [g1.alleles()[i][0], g2.alleles()[i][1]]).count();
    assert!(diff > 0, "mutation must change alleles");
}

#[test]
fn records_parents_and_generation() {
    let c = cfg();
    let mut t = T::new(&c);
    let a = t.animal(Kind::Carnivore, p(4, 4));
    let b = t.animal(Kind::Carnivore, p(4, 5));
    t.s.organisms.get_mut(Kind::Carnivore, b).unwrap().generation = 3;
    t.fin();
    t.s.record_events = true;
    t.mate(&mut Rng::new(1));
    let ch: Vec<_> = t.s.organisms.vec(Kind::Carnivore).iter().filter(|o| o.parents[0] != t.founder).collect();
    let kid = ch.iter().find(|o| o.id != a && o.id != b).unwrap();
    assert_eq!(kid.parents, [a, b]);
    assert_ne!(kid.parents[0], kid.parents[1]);
    assert_eq!(kid.generation, 4);
    assert_eq!(kid.energy(), c.carnivores.offspring_energy);
    assert_eq!(kid.pos, p(4, 4));
    // event through the real scheduler
    let mut c2 = cfg();
    c2.herbivores.reproduction_energy = 50.0;
    let mut t = T::new(&c2);
    t.animal(Kind::Herbivore, p(4, 4));
    t.animal(Kind::Herbivore, p(4, 4));
    t.fin();
    t.s.record_events = true;
    let rep = t.s.step();
    assert!(rep.events.iter().any(|e| matches!(e.kind, EventKind::Born { kind: Kind::Herbivore, .. })));
    assert_eq!(t.s.last_births[Kind::Herbivore.index()], 1);
}

#[test]
fn costs_both_parents_energy() {
    let mut c = cfg();
    c.herbivores.litter_size = 3;
    let mut t = T::new(&c);
    let a = t.animal(Kind::Herbivore, p(4, 4));
    let b = t.animal(Kind::Herbivore, p(4, 4));
    t.fin();
    let before = t.s.organisms.vec(Kind::Herbivore).iter().map(|o| o.energy()).sum::<f64>();
    let st = t.mate(&mut Rng::new(3));
    assert_eq!(st.matings, 1);
    let n = st.offspring as f64;
    assert!(n >= 1.0);
    let cost = REPRO_PARENT_SHARE * n * c.herbivores.offspring_energy;
    for id in [a, b] {
        assert!((t.o(Kind::Herbivore, id).energy() - (100.0 - cost)).abs() < 1e-9);
    }
    assert!(st.energy_to_offspring <= st.energy_paid + 1e-9);
    let after = t.s.organisms.vec(Kind::Herbivore).iter().map(|o| o.energy()).sum::<f64>();
    assert!(after <= before + 1e-9, "no energy created");
}

#[test]
fn cooldown_blocks_then_allows() {
    let mut c = cfg();
    c.herbivores.reproduction_cooldown = 4;
    let mut t = T::new(&c);
    let a = t.animal(Kind::Herbivore, p(4, 4));
    let b = t.animal(Kind::Herbivore, p(4, 4));
    t.fin();
    let mut rng = Rng::new(1);
    assert_eq!(t.mate(&mut rng).matings, 1);
    // children are immature (age 0) so only a and b may mate again
    for tick in 1..=4 {
        for id in [a, b] {
            t.s.organisms.get_mut(Kind::Herbivore, id).unwrap().set_energy(100.0);
        }
        assert_eq!(t.mate(&mut rng).matings, 0, "blocked at tick +{}", tick);
    }
    for id in [a, b] {
        t.s.organisms.get_mut(Kind::Herbivore, id).unwrap().set_energy(100.0);
    }
    assert_eq!(t.mate(&mut rng).matings, 1, "eligible again after cooldown");
    // cooldown 0: every tick
    let mut c0 = cfg();
    c0.herbivores.reproduction_cooldown = 0;
    let mut t = T::new(&c0);
    let a = t.animal(Kind::Herbivore, p(4, 4));
    let b = t.animal(Kind::Herbivore, p(4, 4));
    t.fin();
    for _ in 0..3 {
        for id in [a, b] {
            t.s.organisms.get_mut(Kind::Herbivore, id).unwrap().set_energy(100.0);
        }
        assert_eq!(t.mate(&mut rng).matings, 1);
    }
}

fn count_births(fert: f64, litter: u32, trials: u64) -> (u64, u64) {
    let mut c = cfg();
    c.herbivores.litter_size = litter;
    c.herbivores.offspring_energy = 5.0;
    let mut matings = 0;
    let mut kids = 0;
    for seed in 0..trials {
        let mut t = T::new(&c);
        t.add(Kind::Herbivore, p(1, 1), 0.5, fert);
        t.add(Kind::Herbivore, p(1, 1), 0.5, fert);
        t.fin();
        let st = t.mate(&mut Rng::new(seed as i64));
        matings += st.matings;
        kids += st.offspring;
    }
    (matings, kids)
}

#[test]
fn fertility_affects_births() {
    let n = 400;
    let (m0, k0) = count_births(0.0, 1, n);
    assert_eq!((m0, k0), (0, 0), "fertility 0 never conceives");
    let (m1, _) = count_births(1.0, 1, n);
    assert_eq!(m1, n);
    let (m3, _) = count_births(0.3, 1, n);
    // Each partner may initiate once, so a pair gets two attempts: p = 1-(0.7)^2 = 0.51;
    // Binomial(400, 0.51): mean 204, sigma 10; 4 sigma = 40
    assert!((m3 as f64 - 204.0).abs() < 40.0, "m3={}", m3);
    assert!(m3 < n && m3 > 0);
    // litters
    let (mf, kf) = count_births(1.0, 4, 50);
    assert_eq!((mf, kf), (50, 200));
    let (mh, kh) = count_births(0.5, 4, 600);
    assert!(mh > 0);
    let mean = kh as f64 / mh as f64; // 1 + 3*0.5 = 2.5
    assert!((mean - 2.5).abs() < 0.2, "mean litter {}", mean);
}

#[test]
fn litter_capped_by_energy() {
    let mut c = cfg();
    c.herbivores.litter_size = 8;
    c.herbivores.offspring_energy = 20.0; // unit 12 per child per parent
    let mut t = T::new(&c);
    let a = t.animal(Kind::Herbivore, p(1, 1));
    let b = t.animal(Kind::Herbivore, p(1, 1));
    t.s.organisms.get_mut(Kind::Herbivore, a).unwrap().set_energy(50.0);
    t.fin();
    let st = t.mate(&mut Rng::new(1));
    assert_eq!(st.offspring, 4); // floor((50-1)/12)
    assert!(t.o(Kind::Herbivore, a).energy() >= 1.0);
    assert!(t.o(Kind::Herbivore, b).energy() >= 1.0);
    // too poor for even one
    let mut c2 = cfg();
    c2.herbivores.reproduction_energy = 5.0;
    c2.herbivores.offspring_energy = 20.0;
    let mut t = T::new(&c2);
    let a = t.animal(Kind::Herbivore, p(1, 1));
    t.animal(Kind::Herbivore, p(1, 1));
    t.s.organisms.get_mut(Kind::Herbivore, a).unwrap().set_energy(8.0);
    t.fin();
    let st = t.mate(&mut Rng::new(1));
    assert_eq!(st.offspring, 0);
    assert!(st.blocked_energy > 0);
    assert_eq!(t.o(Kind::Herbivore, a).energy(), 8.0);
    assert_eq!(t.o(Kind::Herbivore, a).cooldown, 0);
}

#[test]
fn mate_choice_nearest_then_similar_and_once_per_tick() {
    let c = cfg();
    let mut t = T::new(&c);
    let a = t.add(Kind::Herbivore, p(5, 5), 0.5, 1.0);
    let near = t.add(Kind::Herbivore, p(5, 6), 0.9, 1.0); // dist 1, dissimilar
    let _far = t.add(Kind::Herbivore, p(5, 7), 0.5, 1.0); // dist 2, identical
    t.fin();
    let st = t.mate(&mut Rng::new(1));
    assert_eq!(st.matings, 1, "three animals -> one pair per tick");
    let kid = t.s.organisms.vec(Kind::Herbivore).iter().find(|o| o.parents[0] == a).unwrap();
    assert_eq!(kid.parents[1], near, "nearest wins over most similar");
    // equal distance: most similar
    let mut t = T::new(&c);
    let a = t.add(Kind::Herbivore, p(5, 5), 0.5, 1.0);
    let _x = t.add(Kind::Herbivore, p(6, 5), 0.8, 1.0);
    let y = t.add(Kind::Herbivore, p(4, 5), 0.55, 1.0);
    t.fin();
    t.mate(&mut Rng::new(1));
    let kid = t.s.organisms.vec(Kind::Herbivore).iter().find(|o| o.parents[0] == a).unwrap();
    assert_eq!(kid.parents[1], y);
}

#[test]
fn determinism_and_cooldown_in_digest() {
    let build = || {
        let mut c = Config::default();
        c.seed = 77;
        c.world.width = 32;
        c.world.height = 32;
        c.initial.herbivores = 80;
        c.initial.carnivores = 10;
        Simulation::new(&c).unwrap()
    };
    let (mut a, mut b) = (build(), build());
    a.run(150);
    b.run(150);
    assert_eq!(a.digest(), b.digest());
    let mut t = T::new(&cfg());
    let x = t.animal(Kind::Herbivore, p(1, 1));
    t.fin();
    let d0 = t.s.digest();
    t.s.organisms.get_mut(Kind::Herbivore, x).unwrap().cooldown = 3;
    assert_ne!(d0, t.s.digest());
}

#[test]
fn integration_seeded_run_breeds_and_stays_consistent() {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = 64;
    c.world.height = 64;
    c.initial.plants = 4000;
    c.initial.herbivores = 150;
    c.initial.carnivores = 10;
    c.herbivores.mate_range = 6;
    c.carnivores.mate_range = 12;
    let mut s = Simulation::new(&c).unwrap();
    s.run(100);
    assert!(s.organisms.stats.births[Kind::Herbivore.index()] > 0, "herbivores bred");
    for k in [Kind::Herbivore, Kind::Carnivore] {
        let st = &s.organisms.stats;
        assert_eq!(st.founded[k.index()] + st.births[k.index()] - st.deaths[k.index()], s.organisms.count(k) as u64);
        for o in s.organisms.vec(k) {
            if o.parents[0] != 0 {
                assert_ne!(o.parents[0], o.parents[1]);
                assert!(o.parents[0] < o.id && o.parents[1] < o.id);
                if let Some(pp) = s.organisms.find(o.parents[0]) {
                    assert_eq!(pp.kind, k);
                }
            }
        }
    }
    s.check_index().unwrap();
}

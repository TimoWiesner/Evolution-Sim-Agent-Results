//! TASK-008 acceptance tests: kinds, fields, ids, traits, ranges, death, counters, same-tick rule.
use evosim_core::config::Config;
use evosim_core::genome::Genome;
use evosim_core::grid::Pos;
use evosim_core::organism::*;
use evosim_core::rng::Rng;
use evosim_core::sim::{EventKind, Simulation};
use std::collections::HashSet;

fn cfg(seed: i64, p: u32, h: u32, c: u32) -> Config {
    let mut c0 = Config::default();
    c0.seed = seed;
    c0.world.width = 20;
    c0.world.height = 12;
    c0.initial.plants = p;
    c0.initial.herbivores = h;
    c0.initial.carnivores = c;
    c0.genetics.founder_variation = 0.0; // exact baseline traits (these tests count exact ages)
    c0
}

fn sim(p: u32, h: u32, c: u32) -> Simulation {
    Simulation::new(&cfg(3, p, h, c)).unwrap()
}

fn nb(kind: Kind, parents: [Id; 2], cfg: &Config) -> NewBorn {
    NewBorn { kind, pos: Pos { x: 1, y: 2 }, parents, genome: Genome::from_traits(kind, &Traits::baseline(kind, cfg), &Traits::baseline(kind, cfg)), energy: 10.0 }
}

fn total(s: &Simulation) -> usize {
    Kind::ALL.iter().map(|&k| s.organisms.count(k)).sum()
}

#[test]
fn three_kinds_and_counts() {
    let s = sim(7, 4, 2);
    assert_eq!(Kind::ALL.len(), 3);
    assert_eq!(s.organisms.count(Kind::Plant), 7);
    assert_eq!(s.organisms.count(Kind::Herbivore), 4);
    assert_eq!(s.organisms.count(Kind::Carnivore), 2);
    let z = sim(0, 0, 0);
    assert_eq!(total(&z), 0);
    assert!(!Kind::Plant.is_animal() && Kind::Herbivore.is_animal() && Kind::Carnivore.is_animal());
}

#[test]
fn every_organism_has_all_fields() {
    let mut s = sim(5, 5, 5);
    let c = s.config.clone();
    for k in Kind::ALL {
        for o in s.organisms.vec(k) {
            assert_eq!(o.kind, k);
            assert!(s.world.grid.contains(o.pos));
            assert_eq!(o.age, 0);
            assert_eq!(o.parents, [0, 0]);
            assert_eq!(o.generation, 0);
            assert!(o.energy() > 0.0 && o.energy() <= o.traits.max_energy);
            assert!(o.health() > 0.0 && o.health() <= o.traits.max_health);
            assert!(o.alive && o.death.is_none());
        }
    }
    let p1 = s.organisms.active_ids(Kind::Herbivore)[0];
    let p2 = s.organisms.active_ids(Kind::Herbivore)[1];
    assert!(s.organisms.queue_birth(nb(Kind::Herbivore, [p1, p2], &c)));
    s.organisms.resolve_births(0);
    let child = s.organisms.vec(Kind::Herbivore).last().unwrap();
    assert_eq!(child.parents, [p1, p2]);
    assert_eq!(child.generation, 1);
    let cid = child.id;
    // grandchild generation = max(parent gens)+1
    assert!(s.organisms.queue_birth(nb(Kind::Herbivore, [cid, p1], &c)));
    s.organisms.resolve_births(1);
    assert_eq!(s.organisms.vec(Kind::Herbivore).last().unwrap().generation, 2);
    // plant: single parent
    let pp = s.organisms.active_ids(Kind::Plant)[0];
    assert!(s.organisms.queue_birth(nb(Kind::Plant, [pp, 0], &c)));
    s.organisms.resolve_births(1);
    assert_eq!(s.organisms.vec(Kind::Plant).last().unwrap().parents, [pp, 0]);
    // rejected: no parent, unknown parent
    assert!(!s.organisms.queue_birth(nb(Kind::Plant, [0, 0], &c)));
    assert!(!s.organisms.queue_birth(nb(Kind::Plant, [99999, 0], &c)));
}

#[test]
fn ids_unique_never_reused() {
    let mut c = cfg(5, 40, 20, 10);
    c.herbivores.maturity_age = 30;
    c.herbivores.max_age = 30;
    c.carnivores.maturity_age = 50;
    c.carnivores.max_age = 50;
    c.plants.max_age = 40;
    let mut s = Simulation::new(&c).unwrap();
    let mut ever: HashSet<Id> = HashSet::new();
    let mut dead: HashSet<Id> = HashSet::new();
    let mut rng = Rng::new(1);
    let mut last_next = s.organisms.next_id();
    for k in Kind::ALL {
        for o in s.organisms.vec(k) {
            assert!(ever.insert(o.id));
        }
    }
    for _ in 0..500 {
        // scripted births: a random living parent of each kind
        for k in Kind::ALL {
            let ids = s.organisms.active_ids(k);
            if !ids.is_empty() && rng.chance(0.7) {
                let p = ids[rng.below(ids.len() as u64) as usize];
                s.organisms.queue_birth(nb(k, [p, 0], &c));
            }
        }
        s.step();
        assert!(s.organisms.next_id() >= last_next);
        last_next = s.organisms.next_id();
        let mut now: HashSet<Id> = HashSet::new();
        for k in Kind::ALL {
            for o in s.organisms.vec(k) {
                assert!(now.insert(o.id), "duplicate id");
                assert!(!dead.contains(&o.id), "dead id reappeared");
            }
        }
        for id in &ever {
            if !now.contains(id) {
                dead.insert(*id);
            }
        }
        for id in now {
            ever.insert(id);
        }
    }
    assert!(!dead.is_empty());
    assert!(ever.iter().all(|&i| i < s.organisms.next_id()));
}

#[test]
fn traits_present_and_in_range() {
    for name in ["default", "lush", "harsh", "predator_heavy", "large"] {
        let c = match Config::preset(name) {
            Ok(c) => c,
            Err(_) => continue,
        };
        for k in Kind::ALL {
            let t = Traits::baseline(k, &c);
            assert_eq!(t, t.clamped(k), "{} {:?}", name, k);
            let g = Traits::range(k);
            assert!(t.speed >= g.speed.lo && t.speed <= g.speed.hi);
            assert!(t.strength >= 0.0 && t.fertility >= 0.0 && t.fertility <= 1.0);
            assert!(t.max_health > 0.0 && t.max_lifespan >= 1);
            if k.is_animal() {
                assert!(t.speed >= 0.1);
                assert!((0.0..=1.0).contains(&t.aggression) && (0.0..=1.0).contains(&t.risk_tolerance));
            } else {
                assert_eq!(t.speed, 0.0);
            }
        }
    }
    let mut t = Traits::baseline(Kind::Carnivore, &Config::default());
    t.speed = f64::INFINITY;
    t.strength = -3.0;
    t.fertility = f64::NAN;
    t.max_health = 1e12;
    t.max_lifespan = 0;
    t.aggression = f64::NAN;
    t.risk_tolerance = 9.0;
    let t = t.clamped(Kind::Carnivore);
    assert_eq!((t.speed, t.strength, t.fertility, t.max_health, t.max_lifespan), (16.0, 0.0, 0.0, 10000.0, 1));
    assert_eq!((t.aggression, t.risk_tolerance), (0.0, 1.0));
}

#[test]
fn energy_and_health_stay_in_range() {
    let s = sim(1, 1, 1);
    let mut rng = Rng::new(9);
    let specials = [f64::NAN, f64::INFINITY, f64::NEG_INFINITY, 1e300, -1e300, 0.0, -0.0];
    for k in Kind::ALL {
        let mut o = s.organisms.vec(k)[0].clone();
        for i in 0..5000 {
            let v = if i % 7 == 0 { specials[(i / 7) % specials.len()] } else { (rng.next_f64() - 0.5) * 500.0 };
            match rng.below(5) {
                0 => {
                    o.add_energy(v);
                }
                1 => o.set_energy(v),
                2 => {
                    o.damage(v);
                }
                3 => {
                    o.heal(v);
                }
                _ => {
                    o.add_energy(-v);
                }
            }
            assert!(o.energy() >= 0.0 && o.energy() <= o.traits.max_energy);
            assert!(o.health() >= 0.0 && o.health() <= o.traits.max_health);
        }
        o.set_energy(5.0);
        let applied = o.add_energy(1e9);
        assert_eq!(o.energy(), o.traits.max_energy);
        assert_eq!(applied, o.traits.max_energy - 5.0);
        assert_eq!(o.add_energy(f64::NAN), 0.0);
    }
    // newborn with oversize energy is clamped
    let mut s = sim(1, 0, 0);
    let c = s.config.clone();
    let p = s.organisms.active_ids(Kind::Plant)[0];
    let mut n = nb(Kind::Plant, [p, 0], &c);
    n.energy = 1e9;
    assert!(s.organisms.queue_birth(n));
    s.organisms.resolve_births(0);
    let o = s.organisms.vec(Kind::Plant).last().unwrap();
    assert_eq!(o.energy(), o.traits.max_energy);
}

#[test]
fn death_removes_and_records_cause() {
    let mut s = sim(0, 3, 0);
    let ids = s.organisms.active_ids(Kind::Herbivore);
    let id = ids[1];
    assert!(s.organisms.mark_dead(id, DeathCause::Predation, 0));
    assert!(!s.organisms.mark_dead(id, DeathCause::Other, 0), "second mark is a no-op");
    assert!(!s.organisms.active_ids(Kind::Herbivore).contains(&id));
    assert_eq!(s.organisms.get(Kind::Herbivore, id).unwrap().death.unwrap().cause, DeathCause::Predation);
    // dead organism cannot become a parent
    let c = s.config.clone();
    assert!(!s.organisms.queue_birth(nb(Kind::Herbivore, [id, 0], &c)));
    s.record_events = true;
    let r = s.step();
    assert!(s.organisms.get(Kind::Herbivore, id).is_none());
    assert_eq!(s.organisms.stats.deaths_by_cause[1][DeathCause::Predation.index()], 1);
    assert_eq!(s.organisms.stats.deaths_by_cause[1][DeathCause::Other.index()], 0);
    assert!(r.events.iter().any(|e| e.kind == EventKind::Died { id, kind: Kind::Herbivore, cause: DeathCause::Predation }));
    for _ in 0..50 {
        s.step();
        assert!(!s.organisms.active_ids(Kind::Herbivore).contains(&id));
        assert!(s.organisms.find(id).is_none());
    }
    assert!(!s.organisms.mark_dead(id, DeathCause::Other, 5), "removed organism cannot die again");
}

#[test]
fn automatic_causes_and_priority() {
    let mut c = cfg(2, 0, 0, 0);
    c.herbivores.maturity_age = 0;
    c.herbivores.max_age = 3;
    let mut s = Simulation::new(&c).unwrap();
    // create founders via the birth primitive
    let mut o = Organisms::populate(&cfg(2, 0, 4, 0), &s.world.grid);
    let ids = o.active_ids(Kind::Herbivore);
    // 0: old age only (age 3 reached), 1: starve, 2: injured, 3: all three -> Injury
    for &i in &ids {
        o.get_mut(Kind::Herbivore, i).unwrap().age = 2;
    }
    o.get_mut(Kind::Herbivore, ids[1]).unwrap().set_energy(0.0);
    o.get_mut(Kind::Herbivore, ids[2]).unwrap().damage(1e9);
    {
        let x = o.get_mut(Kind::Herbivore, ids[3]).unwrap();
        x.set_energy(0.0);
        x.damage(1e9);
    }
    // founders from populate use the other config (max_age 800): set lifespan manually
    for &i in &ids {
        o.get_mut(Kind::Herbivore, i).unwrap().traits.max_lifespan = 3;
    }
    let gone = o.resolve_deaths(0);
    let causes: Vec<DeathCause> = gone.iter().map(|g| g.death.unwrap().cause).collect();
    assert_eq!(causes, vec![DeathCause::OldAge, DeathCause::Starvation, DeathCause::Injury, DeathCause::Injury]);
    assert_eq!(o.stats.deaths[1], 4);
    s.organisms = o;
    s.rebuild_index();
    assert_eq!(s.organisms.count(Kind::Herbivore), 0);
}

#[test]
fn old_age_via_simulation() {
    let mut c = cfg(4, 3, 3, 3);
    c.plants.max_age = 10;
    // TASK-015: carnivores start full and never lose energy, so they never hunt (these tests count exact deaths)
    c.carnivores.initial_energy = c.carnivores.max_energy;
    c.carnivores.satiation_limit = 0.1;
    c.carnivores.base_metabolism = 0.0;
    c.carnivores.move_cost = 0.0;
    c.herbivores.bite_size = 0.0; // TASK-014: herbivores must not eat the plants this test counts
    // TASK-018: default plants reproduce at a low threshold; this test counts exact deaths
    c.plants.growth_rate = 0.0;
    c.plants.reproduction_threshold = c.plants.max_energy;
    // TASK-016: maturity = max_age keeps these exact-death tests free of births
    c.herbivores.maturity_age = 20;
    c.herbivores.max_age = 20;
    c.carnivores.maturity_age = 30;
    c.carnivores.max_age = 30;
    let mut s = Simulation::new(&c).unwrap();
    s.run(9);
    assert_eq!(total(&s), 9);
    s.step();
    assert_eq!(s.organisms.count(Kind::Plant), 0);
    s.run(10);
    assert_eq!(s.organisms.count(Kind::Herbivore), 0);
    assert_eq!(s.organisms.count(Kind::Carnivore), 3);
    s.run(10);
    assert_eq!(total(&s), 0);
    assert_eq!(s.organisms.stats.deaths_by_cause[2][DeathCause::OldAge.index()], 3);
}

#[test]
fn counters_cumulative_and_consistent() {
    let mut s = sim(10, 6, 4);
    let c = s.config.clone();
    for k in Kind::ALL {
        for o in s.organisms.vec(k).iter().map(|o| o.id).collect::<Vec<_>>() {
            s.organisms.get_mut(k, o).unwrap().traits.max_lifespan = 40 + o as u32;
        }
    }
    let mut prev_b = [0u64; 3];
    let mut prev_d = [0u64; 3];
    let mut rng = Rng::new(77);
    for t in 0..300 {
        for k in Kind::ALL {
            let ids = s.organisms.active_ids(k);
            if !ids.is_empty() && t % 3 == 0 {
                s.organisms.queue_birth(nb(k, [ids[0], 0], &c));
            }
            if ids.len() > 2 && rng.chance(0.3) {
                s.organisms.mark_dead(ids[ids.len() - 1], DeathCause::Other, t);
            }
        }
        let before: Vec<usize> = Kind::ALL.iter().map(|&k| s.organisms.stored(k)).collect();
        let marked: Vec<usize> = Kind::ALL.iter().map(|&k| s.organisms.stored(k) - s.organisms.count(k)).collect();
        s.step();
        let st = &s.organisms.stats;
        for k in Kind::ALL {
            let i = k.index();
            assert!(st.births[i] >= prev_b[i] && st.deaths[i] >= prev_d[i]);
            assert_eq!(st.births[i] - prev_b[i], s.last_births[i]);
            assert_eq!(st.deaths[i] - prev_d[i], s.last_deaths[i]);
            assert_eq!(s.organisms.count(k) as u64, st.founded[i] + st.births[i] - st.deaths[i]);
            assert_eq!(s.organisms.count(k) as u64, before[i] as u64 - s.last_deaths[i] + s.last_births[i]);
            assert!(s.last_deaths[i] >= marked[i] as u64);
            prev_b[i] = st.births[i];
            prev_d[i] = st.deaths[i];
        }
    }
    assert!(prev_b.iter().all(|&b| b > 0) && prev_d.iter().all(|&d| d > 0));
}

#[test]
fn same_tick_births_and_deaths_rule() {
    let mut s = sim(0, 4, 0);
    let c = s.config.clone();
    let ids = s.organisms.active_ids(Kind::Herbivore);
    let (a, b, d) = (ids[0], ids[1], ids[2]);
    let max_before = s.organisms.next_id() - 1;
    // birth queued first with parent a, then a is killed the same tick
    assert!(s.organisms.queue_birth(nb(Kind::Herbivore, [a, b], &c)));
    assert!(s.organisms.mark_dead(a, DeathCause::Predation, 0));
    // queueing after the mark is rejected
    assert!(!s.organisms.queue_birth(nb(Kind::Herbivore, [a, b], &c)));
    assert!(s.organisms.queue_birth(nb(Kind::Herbivore, [b, 0], &c)));
    assert!(s.organisms.mark_dead(d, DeathCause::Other, 0));
    s.record_events = true;
    let r = s.step();
    let st = &s.organisms.stats;
    assert_eq!((st.births[1], st.deaths[1]), (2, 2));
    assert_eq!(s.organisms.count(Kind::Herbivore), 4);
    // newborns: ids in queue order, greater than every earlier id, parents recorded even though a died
    let news: Vec<&Organism> = s.organisms.vec(Kind::Herbivore).iter().filter(|o| o.id > max_before).collect();
    assert_eq!(news.len(), 2);
    assert_eq!(news[0].id + 1, news[1].id);
    assert_eq!(news[0].parents, [a, b]);
    assert!(s.organisms.get(Kind::Herbivore, a).is_none());
    // newborns neither aged nor died in their birth tick
    assert!(news.iter().all(|o| o.age == 0 && o.alive));
    // event order inside the tick: all Died before all Born
    let pos_last_died = r.events.iter().rposition(|e| matches!(e.kind, EventKind::Died { .. })).unwrap();
    let pos_first_born = r.events.iter().position(|e| matches!(e.kind, EventKind::Born { .. })).unwrap();
    assert!(pos_last_died < pos_first_born);
    // a newborn marked dead before the next Deaths phase is the only way it dies; it then ages next tick
    s.step();
    assert!(s.organisms.vec(Kind::Herbivore).iter().filter(|o| o.id > max_before).all(|o| o.age == 1));
}

#[test]
fn deaths_and_births_commute_in_counts() {
    // order of mark_dead vs queue_birth calls (legal ones) cannot change the counts
    let run = |kill_first: bool| {
        let mut s = sim(0, 5, 0);
        let c = s.config.clone();
        let ids = s.organisms.active_ids(Kind::Herbivore);
        if kill_first {
            s.organisms.mark_dead(ids[4], DeathCause::Other, 0);
            s.organisms.queue_birth(nb(Kind::Herbivore, [ids[0], 0], &c));
        } else {
            s.organisms.queue_birth(nb(Kind::Herbivore, [ids[0], 0], &c));
            s.organisms.mark_dead(ids[4], DeathCause::Other, 0);
        }
        s.step();
        (s.organisms.stats.births, s.organisms.stats.deaths, s.organisms.count(Kind::Herbivore))
    };
    assert_eq!(run(true), run(false));
}

#[test]
fn determinism_and_digest_sensitivity() {
    let run = |seed: i64| {
        let mut s = Simulation::new(&cfg(seed, 30, 10, 5)).unwrap();
        s.run(300);
        s.digest()
    };
    assert_eq!(run(1), run(1));
    assert_ne!(run(1), run(2));
    let s = sim(5, 5, 5);
    let d = s.digest();
    let mut t = s.clone();
    let id = t.organisms.active_ids(Kind::Plant)[0];
    t.organisms.get_mut(Kind::Plant, id).unwrap().add_energy(-0.5);
    assert_ne!(t.digest(), d);
    let mut u = s.clone();
    let id = u.organisms.active_ids(Kind::Carnivore)[0];
    u.organisms.mark_dead(id, DeathCause::Other, 0);
    assert_ne!(u.digest(), d);
}

#[test]
fn sim_events_match_counters() {
    let mut c = cfg(8, 6, 4, 2);
    c.plants.max_age = 5;
    c.plants.growth_rate = 0.0; // TASK-018: no plant seeding, no herbivore births (exact death count)
    c.plants.reproduction_threshold = c.plants.max_energy;
    c.herbivores.maturity_age = c.herbivores.max_age;
    // TASK-015: carnivores start full and never lose energy, so they never hunt (these tests count exact deaths)
    c.carnivores.initial_energy = c.carnivores.max_energy;
    c.carnivores.satiation_limit = 0.1;
    c.carnivores.base_metabolism = 0.0;
    c.carnivores.move_cost = 0.0;
    let mut s = Simulation::new(&c).unwrap();
    s.record_events = true;
    let (mut born, mut died) = (0u64, 0u64);
    for _ in 0..12 {
        let cc = s.config.clone();
        if let Some(&p) = s.organisms.active_ids(Kind::Herbivore).first() {
            s.organisms.queue_birth(nb(Kind::Herbivore, [p, 0], &cc));
        }
        for e in s.step().events {
            match e.kind {
                EventKind::Born { .. } => born += 1,
                EventKind::Died { .. } => died += 1,
                _ => {}
            }
        }
    }
    assert_eq!(born, s.organisms.stats.births.iter().sum::<u64>());
    assert_eq!(died, s.organisms.stats.deaths.iter().sum::<u64>());
    assert_eq!(died, 6);
}

use evosim_core::config::*;
use evosim_core::json::{self, Value};

const MIN: &str = r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#;

fn err(text: &str) -> ConfigError {
    Config::from_json(text).expect_err(text)
}

/// Replace the value at a dotted path in the minimal config and return JSON text.
fn with(path: &str, v: Value) -> String {
    let mut root = json::parse(MIN).unwrap();
    set(&mut root, &path.split('.').collect::<Vec<_>>(), v);
    root.to_compact()
}
fn set(node: &mut Value, p: &[&str], v: Value) {
    if let Value::Object(items) = node {
        if let Some(e) = items.iter_mut().find(|(k, _)| k == p[0]) {
            if p.len() == 1 { e.1 = v } else { set(&mut e.1, &p[1..], v) }
        } else if p.len() == 1 {
            items.push((p[0].to_string(), v));
        } else {
            let mut sub = Value::Object(vec![]);
            set(&mut sub, &p[1..], v);
            items.push((p[0].to_string(), sub));
        }
    }
}
fn remove(path: &str) -> String {
    let mut root = json::parse(MIN).unwrap();
    let parts: Vec<&str> = path.split('.').collect();
    if let Value::Object(items) = &mut root {
        if parts.len() == 1 {
            items.retain(|(k, _)| k != parts[0]);
        } else if let Some((_, Value::Object(sub))) = items.iter_mut().find(|(k, _)| k == parts[0]) {
            sub.retain(|(k, _)| k != parts[1]);
        }
    }
    root.to_compact()
}
fn num_value(d: &ParamDef, x: f64) -> Value {
    match d.kind {
        Kind::Int => Value::Int(x as i64),
        _ => Value::Float(x),
    }
}

#[test]
fn minimal_fixed_keys_valid_and_rest_default() {
    let c = Config::from_json(MIN).unwrap();
    assert_eq!(c.seed, 42);
    assert_eq!((c.world.width, c.world.height), (64, 48));
    assert_eq!((c.initial.plants, c.initial.herbivores, c.initial.carnivores), (400, 120, 20));
    let mut d = Config::default();
    d.seed = 42;
    assert_eq!(c, d);
    assert_eq!(c, Config::preset("default").unwrap());
}

#[test]
fn every_non_fixed_param_has_default_in_range() {
    let defs = Config::param_defs();
    assert!(defs.len() > 60);
    let d = Config::default();
    for p in &defs {
        assert_eq!(d.get_num(&p.path), Some(p.default), "{}", p.path);
        assert!(!p.doc.is_empty(), "{}", p.path);
        if p.path != "seed" {
            let x = match p.default {
                Num::I(i) => i as f64,
                Num::F(f) => f,
                Num::B(b) => b as u8 as f64,
            };
            assert!(x >= p.min && x <= p.max, "{} default out of range", p.path);
        }
    }
    assert_eq!(defs.iter().filter(|p| p.fixed).count(), 6);
    d.validate().unwrap();
}

#[test]
fn zero_initial_populations_accepted() {
    for keys in [vec!["plants"], vec!["herbivores"], vec!["carnivores"], vec!["plants", "herbivores", "carnivores"]] {
        let mut t = MIN.to_string();
        for k in &keys {
            t = with(&format!("initial.{}", k), Value::Int(0));
        }
        if keys.len() == 3 {
            let mut root = json::parse(MIN).unwrap();
            for k in &keys {
                set(&mut root, &["initial", k], Value::Int(0));
            }
            t = root.to_compact();
        }
        let c = Config::from_json(&t).unwrap();
        for k in &keys {
            assert_eq!(c.get_num(&format!("initial.{}", k)), Some(Num::I(0)));
        }
    }
}

#[test]
fn missing_fixed_key_names_it() {
    for k in FIXED_KEYS {
        let e = err(&remove(k));
        assert_eq!(e.kind, ErrorKind::MissingKey, "{}", k);
        assert_eq!(e.key, k);
        assert!(e.to_string().contains(k), "{}", e);
    }
    // whole group missing
    let e = err(r#"{"seed":1,"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#);
    assert!(e.to_string().contains("world.width"), "{}", e);
}

#[test]
fn wrong_types_name_the_key() {
    let cases: Vec<(&str, Value)> = vec![
        ("seed", Value::Str("1".into())),
        ("seed", Value::Float(1.5)),
        ("seed", Value::Null),
        ("world.width", Value::Str("64".into())),
        ("world.width", Value::Float(64.5)),
        ("world.width", Value::Float(64.0)),
        ("world.height", Value::Bool(true)),
        ("world.height", Value::Array(vec![])),
        ("initial.plants", Value::Null),
        ("initial.herbivores", Value::Object(vec![])),
        ("initial.carnivores", Value::Str("many".into())),
        ("world", Value::Int(5)),
        ("initial", Value::Array(vec![])),
        ("climate", Value::Str("x".into())),
        ("plants.growth_rate", Value::Str("fast".into())),
        ("plants.growth_rate", Value::Bool(false)),
        ("plants.max_age", Value::Float(10.5)),
        ("genetics.species_min_size", Value::Null),
    ];
    for (k, v) in cases {
        let e = err(&with(k, v.clone()));
        assert_eq!(e.kind, ErrorKind::WrongType, "{} {:?}", k, v);
        assert_eq!(e.key, k);
        assert!(e.to_string().contains(k));
    }
    let e = err("[1,2]");
    assert_eq!(e.kind, ErrorKind::WrongType);
    assert!(Config::from_json("42").is_err());
}

#[test]
fn out_of_range_fixed_keys() {
    for (k, v) in [
        ("world.width", 0),
        ("world.height", 0),
        ("world.width", -3),
        ("world.width", 4097),
        ("initial.plants", -1),
        ("initial.herbivores", -1),
        ("initial.carnivores", i64::MIN),
        ("initial.plants", 4_000_001),
        ("initial.plants", i64::MAX),
    ] {
        let e = err(&with(k, Value::Int(v)));
        assert_eq!(e.kind, ErrorKind::OutOfRange, "{}={}", k, v);
        assert_eq!(e.key, k);
        assert!(e.to_string().contains(k));
    }
    // huge integers beyond i64 are floats -> wrong type for int keys, still naming the key
    let e = err(&MIN.replace("\"plants\":400", "\"plants\":99999999999999999999999"));
    assert!(e.to_string().contains("initial.plants"));
    // area limit
    let e = err(&MIN.replace("\"width\":64,\"height\":48", "\"width\":4096,\"height\":4096"));
    assert!(e.to_string().contains("world.width"), "{}", e);
}

#[test]
fn every_param_rejects_just_outside_range_and_accepts_bounds() {
    for d in Config::param_defs() {
        if d.path == "seed" || d.kind == Kind::Bool {
            continue;
        }
        let step = if d.kind == Kind::Int { 1.0 } else { (d.max - d.min).abs() * 1e-6 + 1e-9 };
        for bad in [d.min - step, d.max + step] {
            let e = err(&with(&d.path, num_value(&d, bad)));
            assert_eq!(e.kind, ErrorKind::OutOfRange, "{} {}", d.path, bad);
            assert_eq!(e.key, d.path);
            assert!(e.to_string().contains(&d.path));
        }
        // bounds individually may violate cross-field rules, only check via typed set + parse of the key's own range
        let mut c = Config::default();
        for b in [d.min, d.max] {
            let n = if d.kind == Kind::Int { Num::I(b as i64) } else { Num::F(b) };
            c.set_num(&d.path, n).unwrap();
            if let Err(e) = c.validate() {
                // only cross-field/area errors are acceptable at bounds
                assert!(e.kind == ErrorKind::OutOfRange);
            }
            c.set_num(&d.path, d.default).unwrap();
        }
    }
}

#[test]
fn cross_field_constraints() {
    for (k, v, named) in [
        ("climate.pole_temp", Value::Float(50.0), "climate.pole_temp"),
        ("plants.initial_energy", Value::Float(60.0), "plants.initial_energy"),
        ("plants.reproduction_threshold", Value::Float(60.0), "plants.reproduction_threshold"),
        ("herbivores.maturity_age", Value::Int(900), "herbivores.maturity_age"),
        ("carnivores.reproduction_energy", Value::Float(250.0), "carnivores.reproduction_energy"),
        ("herbivores.initial_energy", Value::Float(101.0), "herbivores.initial_energy"),
    ] {
        let e = err(&with(k, v));
        assert_eq!(e.kind, ErrorKind::OutOfRange);
        assert!(e.to_string().contains(named), "{}", e);
    }
}

#[test]
fn unknown_and_malformed() {
    let e = err(&with("plants.growht_rate", Value::Float(1.0)));
    assert_eq!(e.kind, ErrorKind::UnknownKey);
    assert!(e.to_string().contains("plants.growht_rate"));
    let e = err(&with("bogus", Value::Int(1)));
    assert_eq!(e.kind, ErrorKind::UnknownKey);
    assert_eq!(e.key, "bogus");
    assert_eq!(err("{").kind, ErrorKind::Syntax);
    assert_eq!(err("").kind, ErrorKind::Syntax);
    let e = err(r#"{"seed":1,"seed":2}"#);
    assert!(e.to_string().contains("seed"));
    let e = Config::load_file("/nonexistent/dir/cfg.json").unwrap_err();
    assert_eq!(e.kind, ErrorKind::Io);
}

#[test]
fn round_trip_default_presets_and_text_stable() {
    for name in PRESET_NAMES {
        let c = Config::preset(name).unwrap();
        let t = c.to_json();
        let back = Config::from_json(&t).unwrap();
        assert_eq!(c, back, "{}", name);
        assert_eq!(back.to_json(), t, "{}", name);
    }
}

#[test]
fn round_trip_extreme_values_and_awkward_floats() {
    let mut c = Config::default();
    c.seed = i64::MIN;
    for d in Config::param_defs() {
        if d.path == "seed" || d.kind != Kind::Float {
            continue;
        }
        c.set_num(&d.path, Num::F(d.max)).unwrap();
    }
    c.set_num("plants.mutation_rate", Num::F(0.1 + 0.2)).unwrap();
    c.set_num("genetics.species_threshold", Num::F(1.0 / 3.0)).unwrap();
    c.set_num("climate.weather_noise", Num::F(5e-324)).unwrap();
    // the extreme set violates cross rules only if they exist; ensure still valid or adjust
    c.climate.pole_temp = 40.0;
    c.climate.equator_temp = 60.0;
    c.plants.initial_energy = 10000.0;
    c.validate().unwrap();
    assert_eq!(Config::from_json(&c.to_json()).unwrap(), c);
    c.seed = i64::MAX;
    assert_eq!(Config::from_json(&c.to_json()).unwrap(), c);
}

struct Rng(u64);
impl Rng {
    fn next(&mut self) -> u64 {
        self.0 ^= self.0 << 13;
        self.0 ^= self.0 >> 7;
        self.0 ^= self.0 << 17;
        self.0
    }
    fn unit(&mut self) -> f64 {
        (self.next() >> 11) as f64 / (1u64 << 53) as f64
    }
}

#[test]
fn property_random_valid_configs_round_trip() {
    let mut r = Rng(0x9E3779B97F4A7C15);
    let defs = Config::param_defs();
    let mut accepted = 0;
    for _ in 0..500 {
        let mut c = Config::default();
        c.seed = r.next() as i64;
        for d in &defs {
            if d.path == "seed" || d.kind == Kind::Bool {
                continue;
            }
            let hi = d.max.min(1e4);
            let x = d.min + r.unit() * (hi - d.min);
            let n = if d.kind == Kind::Int { Num::I(x as i64) } else { Num::F(x) };
            c.set_num(&d.path, n).unwrap();
        }
        c.world.width = (c.world.width % 1000).max(1);
        c.world.height = (c.world.height % 1000).max(1);
        // repair cross-field rules so that the sample is valid
        if c.climate.pole_temp > c.climate.equator_temp {
            std::mem::swap(&mut c.climate.pole_temp, &mut c.climate.equator_temp);
        }
        c.plants.initial_energy = c.plants.initial_energy.min(c.plants.max_energy);
        c.plants.reproduction_threshold = c.plants.reproduction_threshold.min(c.plants.max_energy);
        for a in [&mut c.herbivores, &mut c.carnivores] {
            a.initial_energy = a.initial_energy.min(a.max_energy);
            a.reproduction_energy = a.reproduction_energy.min(a.max_energy);
            a.maturity_age = a.maturity_age.min(a.max_age);
        }
        if c.validate().is_err() {
            continue;
        }
        accepted += 1;
        assert_eq!(Config::from_json(&c.to_json()).unwrap(), c);
    }
    assert!(accepted > 450, "only {} valid samples", accepted);
}

#[test]
fn property_single_key_corruption_is_rejected_with_key() {
    let mut r = Rng(12345);
    let defs: Vec<ParamDef> = Config::param_defs().into_iter().filter(|d| d.path != "seed").collect();
    for _ in 0..300 {
        let d = &defs[(r.next() % defs.len() as u64) as usize];
        let bad = match r.next() % 3 {
            0 => Value::Str("x".into()),
            1 => Value::Null,
            _ => match d.kind {
                Kind::Bool => Value::Int(1),
                _ => num_value(d, d.max + 1.0 + r.unit() * 100.0),
            },
        };
        let e = err(&with(&d.path, bad));
        assert!(e.to_string().contains(&d.path), "{} -> {}", d.path, e);
    }
}

#[test]
fn presets_valid_distinct_selectable() {
    assert!(PRESET_NAMES.len() >= 3);
    let all: Vec<Config> = PRESET_NAMES.iter().map(|n| Config::preset(n).unwrap()).collect();
    for c in &all {
        c.validate().unwrap();
    }
    for i in 0..all.len() {
        for j in i + 1..all.len() {
            assert_ne!(all[i], all[j]);
            let diffs = Config::param_defs()
                .iter()
                .filter(|p| all[i].get_num(&p.path) != all[j].get_num(&p.path))
                .count();
            assert!(diffs >= 3, "{} vs {}: only {} differences", PRESET_NAMES[i], PRESET_NAMES[j], diffs);
        }
    }
    let e = Config::preset("nope").unwrap_err();
    assert!(e.message.contains("lush") && e.message.contains("harsh") && e.message.contains("nope"));
    // meaningful differences
    let lush = Config::preset("lush").unwrap();
    let harsh = Config::preset("harsh").unwrap();
    assert!(lush.climate.precip_mean > harsh.climate.precip_mean);
    assert!(Config::preset("large").unwrap().world.width > 64);
    assert!(Config::preset("predator-rich").unwrap().initial.carnivores > 20);
}

#[test]
fn file_load_and_docs_in_sync() {
    let dir = std::env::temp_dir().join(format!("evosim-cfg-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let p = dir.join("c.json");
    std::fs::write(&p, MIN).unwrap();
    assert_eq!(Config::load_file(p.to_str().unwrap()).unwrap().seed, 42);
    std::fs::remove_dir_all(&dir).ok();

    let doc = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/../../docs/CONFIG.md")).unwrap();
    assert!(doc.contains(&describe()), "docs/CONFIG.md is out of date; regenerate the table with config::describe()");
}

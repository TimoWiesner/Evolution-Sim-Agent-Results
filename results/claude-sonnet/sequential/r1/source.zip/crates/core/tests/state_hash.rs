//! TASK-019: `Simulation::state_hash` (ADR-0023) covers the complete state.
use evosim_core::climate::Weather;
use evosim_core::config::Config;
use evosim_core::grid::Pos;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;

fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 9;
    c.world.width = 16;
    c.world.height = 12;
    c.initial.plants = 60;
    c.initial.herbivores = 12;
    c.initial.carnivores = 4;
    c
}

fn sim(ticks: u64) -> Simulation {
    let mut s = Simulation::new(&cfg()).unwrap();
    s.run(ticks);
    s
}

#[test]
fn format_and_repeatability() {
    let a = sim(25);
    let h = a.state_hash();
    assert_eq!(h.len(), 64);
    assert!(h.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)));
    assert_eq!(h, sim(25).state_hash());
    assert_eq!(h, a.clone().state_hash());
    assert_eq!(h, a.state_hash(), "hash has no side effects");
    assert_ne!(h, sim(24).state_hash());
    assert_ne!(sim(0).state_hash(), sim(1).state_hash());
}

#[test]
fn different_seed_differs() {
    let mut c = cfg();
    c.seed = 10;
    let mut b = Simulation::new(&c).unwrap();
    b.run(25);
    assert_ne!(sim(25).state_hash(), b.state_hash());
    let mut b0 = Simulation::new(&c).unwrap();
    b0.run(0);
    assert_ne!(sim(0).state_hash(), b0.state_hash());
}

#[test]
fn digest_and_hash_move_together() {
    let a = sim(10);
    let mut b = a.clone();
    assert_eq!((a.digest(), a.state_hash()), (b.digest(), b.state_hash()));
    b.step();
    assert_ne!(a.digest(), b.digest());
    assert_ne!(a.state_hash(), b.state_hash());
}

fn changed(base: &Simulation, name: &str, f: impl FnOnce(&mut Simulation)) {
    let mut m = base.clone();
    f(&mut m);
    assert_ne!(base.state_hash(), m.state_hash(), "state_hash ignores: {name}");
}

#[test]
fn every_state_part_changes_the_hash() {
    let base = sim(30);
    assert!(base.organisms.count(Kind::Herbivore) > 0 && base.organisms.count(Kind::Plant) > 0);
    changed(&base, "tick", |s| s.tick += 1);
    changed(&base, "acc", |s| s.acc ^= 1);
    changed(&base, "rng", |s| {
        let mut st = s.export_rng();
        st[3] ^= 1;
        assert!(s.restore_rng(st));
    });
    changed(&base, "weather", |s| {
        let mut w = s.world.weather.state_words();
        let n = w.len();
        w[n - 1] ^= 1;
        s.world.weather = Weather::from_state_words(&w).unwrap();
    });
    for k in Kind::ALL {
        let nm = format!("{k:?}");
        changed(&base, &format!("{nm}.pos"), |s| {
            let g = s.world.grid;
            let o = &mut s.organisms.vec_mut(k)[0];
            o.pos = g.wrap(o.pos.x as i64 + 1, o.pos.y as i64);
        });
        changed(&base, &format!("{nm}.age"), |s| s.organisms.vec_mut(k)[0].age += 1);
        changed(&base, &format!("{nm}.energy 1ulp"), |s| {
            let o = &mut s.organisms.vec_mut(k)[0];
            let e = o.energy();
            o.set_energy(f64::from_bits(e.to_bits() + 1));
            assert_ne!(o.energy().to_bits(), e.to_bits());
        });
        changed(&base, &format!("{nm}.parents"), |s| s.organisms.vec_mut(k)[0].parents[1] += 1);
        changed(&base, &format!("{nm}.generation"), |s| s.organisms.vec_mut(k)[0].generation += 1);
        changed(&base, &format!("{nm}.move_credit"), |s| s.organisms.vec_mut(k)[0].move_credit += 0.125);
        changed(&base, &format!("{nm}.heading"), |s| {
            let o = &mut s.organisms.vec_mut(k)[0];
            o.heading = (o.heading + 1) % 9;
        });
        changed(&base, &format!("{nm}.rest"), |s| s.organisms.vec_mut(k)[0].rest += 1);
        changed(&base, &format!("{nm}.cooldown"), |s| s.organisms.vec_mut(k)[0].cooldown += 1);
        changed(&base, &format!("{nm}.species"), |s| s.organisms.vec_mut(k)[0].species += 1);
        changed(&base, &format!("{nm}.alive"), |s| s.organisms.vec_mut(k)[0].alive = false);
        changed(&base, &format!("{nm}.trait"), |s| {
            let o = &mut s.organisms.vec_mut(k)[0];
            o.traits.speed += 0.5;
        });
    }
    changed(&base, "stats.births", |s| s.organisms.stats.births[0] += 1);
    changed(&base, "stats.deaths_by_cause", |s| s.organisms.stats.deaths_by_cause[1][0] += 1);
    changed(&base, "resource cell", |s| {
        let p = Pos { x: 3, y: 4 };
        let v = s.world.resource_at(p);
        s.world.set_resource(p, if v > 0.5 { v - 0.25 } else { v + 0.25 });
    });
    changed(&base, "climate temp", |s| s.world.climate.temp[5] += 0.01);
    changed(&base, "climate precip", |s| s.world.climate.precip[5] += 0.01);
    changed(&base, "climate elevation", |s| s.world.climate.elevation[7] += 0.01);
    changed(&base, "climate zone", |s| s.world.climate.zone[7] ^= 1);
    changed(&base, "config value", |s| s.config.plants.maintenance += 0.001);
    changed(&base, "config seed", |s| s.config.seed += 1);
    changed(&base, "species registry", |s| {
        assert!(!s.species.records().is_empty());
        s.species = Default::default();
    });
}

/// Golden value of a short fixed run: detects accidental semantic or format changes.
/// Regenerate (run with `-- --nocapture`) whenever simulation semantics are changed on purpose.
#[test]
fn golden_hash() {
    let h = sim(40).state_hash();
    eprintln!("golden: {h}");
    assert_eq!(h, GOLDEN, "state_hash of the fixed run changed (regenerate GOLDEN if intended)");
}
const GOLDEN: &str = "585b1425c23e89016d557c29de058ca149c8aa4e20b31033e0ce00db0ad4c575";

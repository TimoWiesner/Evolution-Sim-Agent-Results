//! TASK-018: ecology integration, extinction finality, ledger, scenarios, defaults (ADR-0022).
use evosim_core::config::Config;
use evosim_core::ecology::{format_reports, run_survival};
use evosim_core::organism::Kind;
use evosim_core::sim::{EventKind, Phase, Simulation};

/// Configuration with only the six fixed keys (everything else default).
fn fixed(seed: i64, w: u32, h: u32, p: u32, hb: u32, c: u32) -> Config {
    let text = format!(
        r#"{{"seed":{seed},"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{p},"herbivores":{hb},"carnivores":{c}}}}}"#
    );
    Config::from_json(&text).unwrap()
}

fn counts(s: &Simulation) -> [usize; 3] {
    [s.organisms.count(Kind::Plant), s.organisms.count(Kind::Herbivore), s.organisms.count(Kind::Carnivore)]
}

#[test]
fn tick_order_documented() {
    assert_eq!(
        Phase::ORDER.map(|p| p.name()),
        ["climate", "plants", "herbivores", "carnivores", "deaths", "births", "index"]
    );
    let mut s = Simulation::new(&fixed(3, 32, 24, 100, 30, 6)).unwrap();
    s.record_events = true;
    for _ in 0..150 {
        let ev = s.step().events;
        let mut last = 0usize;
        let mut saw_born = false;
        for e in &ev {
            let idx = Phase::ORDER.iter().position(|&p| p == e.phase).unwrap();
            assert!(idx >= last, "events out of phase order");
            last = idx;
            match e.kind {
                EventKind::Died { .. } => assert_eq!(e.phase, Phase::Deaths),
                EventKind::Born { .. } => {
                    assert_eq!(e.phase, Phase::Births);
                    saw_born = true;
                }
                _ => {}
            }
        }
        // all deaths are listed before any birth of the same tick
        if saw_born {
            let first_born = ev.iter().position(|e| matches!(e.kind, EventKind::Born { .. })).unwrap();
            assert!(ev[first_born..].iter().all(|e| !matches!(e.kind, EventKind::Died { .. })));
        }
    }
}

#[test]
fn fixed_keys_only_runs_1000_ticks_with_ledger() {
    let mut s = Simulation::new(&fixed(1, 64, 48, 400, 120, 20)).unwrap();
    let init = counts(&s);
    let mut cum_b = [0i64; 3];
    let mut cum_d = [0i64; 3];
    for _ in 0..1000 {
        s.step();
        for k in 0..3 {
            cum_b[k] += s.last_births[k] as i64;
            cum_d[k] += s.last_deaths[k] as i64;
        }
        // independent bookkeeping from the per-tick numbers
        let now = counts(&s);
        for k in 0..3 {
            assert_eq!(init[k] as i64 + cum_b[k] - cum_d[k], now[k] as i64, "kind {k} tick {}", s.tick);
        }
        s.ledger_check().unwrap();
        s.check_index().unwrap();
    }
    assert_eq!(s.tick, 1000);
}

#[test]
fn ledger_check_detects_corruption() {
    let mut s = Simulation::new(&fixed(2, 16, 16, 20, 5, 1)).unwrap();
    s.run(5);
    s.ledger_check().unwrap();
    s.organisms.stats.deaths[0] += 1;
    assert!(s.ledger_check().is_err());
}

/// Counts may only grow in a tick when that kind had births in the tick.
fn no_creation(mut s: Simulation, ticks: u64) -> Simulation {
    for _ in 0..ticks {
        let before = counts(&s);
        s.step();
        let after = counts(&s);
        for k in 0..3 {
            if after[k] > before[k] {
                assert!(s.last_births[k] > 0);
            }
            if before[k] == 0 {
                assert_eq!(after[k], 0, "kind {k} came back from zero at tick {}", s.tick);
                assert_eq!(s.last_births[k], 0);
            }
        }
    }
    s
}

#[test]
fn zero_stays_zero_with_other_kinds_alive() {
    // no plants, no herbivores, no carnivores respectively
    for (p, h, c) in [(0, 60, 10), (300, 0, 10), (300, 60, 0)] {
        let s = no_creation(Simulation::new(&fixed(5, 40, 30, p, h, c)).unwrap(), 400);
        let n = counts(&s);
        if p == 0 {
            assert_eq!(n[0], 0);
        }
        if h == 0 {
            assert_eq!(n[1], 0);
        }
        if c == 0 {
            assert_eq!(n[2], 0);
        }
    }
}

#[test]
fn extinct_kind_stays_extinct_in_a_real_run() {
    // the default world loses herbivores at some point; afterwards they never return
    let mut s = Simulation::new(&fixed(2, 64, 48, 400, 120, 20)).unwrap();
    let mut died_out: [Option<u64>; 3] = [None; 3];
    for _ in 0..1500 {
        s.step();
        let n = counts(&s);
        for k in 0..3 {
            if n[k] == 0 && died_out[k].is_none() {
                died_out[k] = Some(s.tick);
            }
            if died_out[k].is_some() {
                assert_eq!(n[k], 0);
            }
        }
    }
}

#[test]
fn no_plants_herbivores_then_carnivores_die_out() {
    for seed in 1..=3 {
        let mut s = Simulation::new(&fixed(seed, 64, 48, 0, 120, 20)).unwrap();
        let mut herb_gone = None;
        let mut carn_gone = None;
        for _ in 0..3000 {
            s.step();
            let n = counts(&s);
            assert_eq!(n[0], 0, "plants appeared from nothing");
            if n[1] == 0 && herb_gone.is_none() {
                herb_gone = Some(s.tick);
            }
            if n[2] == 0 && carn_gone.is_none() {
                carn_gone = Some(s.tick);
            }
        }
        let (h, c) = (herb_gone.expect("herbivores must die out"), carn_gone.expect("carnivores must die out"));
        assert!(h <= c, "seed {seed}: herbivores {h} before carnivores {c}");
        s.ledger_check().unwrap();
    }
}

#[test]
fn no_herbivores_carnivores_die_out() {
    for seed in 1..=3 {
        let mut s = Simulation::new(&fixed(seed, 64, 48, 400, 0, 20)).unwrap();
        s.run(3000);
        assert_eq!(s.organisms.count(Kind::Carnivore), 0, "seed {seed}");
        assert_eq!(s.organisms.count(Kind::Herbivore), 0);
        assert!(s.organisms.count(Kind::Plant) > 0, "plants unaffected by carnivores");
        s.ledger_check().unwrap();
    }
}

#[test]
fn plants_alone_persist_and_reproduce() {
    for seed in 1..=3 {
        let mut s = Simulation::new(&fixed(seed, 64, 48, 400, 0, 0)).unwrap();
        s.run(2500);
        assert!(s.organisms.count(Kind::Plant) > 0, "seed {seed}");
        assert!(s.organisms.stats.births[0] > 100, "seed {seed}: plants reproduce on their own");
        s.ledger_check().unwrap();
    }
}

#[test]
fn herbivores_with_plenty_of_plants_survive_and_reproduce() {
    for seed in 1..=3 {
        // the example configuration without carnivores: 120 herbivores, 400 plants
        let mut s = Simulation::new(&fixed(seed, 64, 48, 400, 120, 0)).unwrap();
        s.run(800);
        assert!(s.organisms.count(Kind::Herbivore) > 0, "seed {seed}");
        assert!(s.organisms.stats.births[1] >= 20, "seed {seed}: births {}", s.organisms.stats.births[1]);
        assert!(s.organisms.count(Kind::Plant) > 0);
    }
}

#[test]
fn default_example_config_herbivores_live_several_hundred_ticks() {
    // the measured example configuration (with carnivores): each seed keeps herbivores for >= 300 ticks
    for seed in 1..=3 {
        let r = run_survival(&fixed(seed, 64, 48, 400, 120, 20), 400).unwrap();
        assert!(r.outcomes[0].extinct_at.is_none());
        assert!(r.outcomes[1].extinct_at.is_none(), "seed {seed}: herbivores died at {:?}", r.outcomes[1].extinct_at);
        assert!(r.outcomes[1].births > 0);
        assert_eq!(r.ledger_errors, 0);
    }
}

#[test]
fn grazing_never_kills_plants_with_reserve() {
    let mut s = Simulation::new(&fixed(4, 40, 30, 300, 100, 0)).unwrap();
    for _ in 0..300 {
        s.step();
        assert_eq!(s.last_herbivore_stats.plants_killed, 0);
    }
}

#[test]
fn survival_report_is_deterministic_and_well_formed() {
    let c = fixed(7, 32, 24, 150, 40, 8);
    let a = run_survival(&c, 120).unwrap();
    let b = run_survival(&c, 120).unwrap();
    assert_eq!(a, b);
    assert_eq!(a.ticks, 120);
    assert_eq!(a.ledger_errors, 0);
    for o in &a.outcomes {
        assert_eq!(o.final_count == 0, o.extinct_at.is_some());
    }
    let none = run_survival(&fixed(7, 32, 24, 0, 0, 0), 5).unwrap();
    assert!(none.outcomes.iter().all(|o| o.extinct_at == Some(0)));
    let text = format_reports(&[a]);
    assert!(text.contains("seed 7") && text.contains("Plant") && text.contains("Carnivore"));
}

#[test]
fn only_reproduction_creates_organisms_in_source() {
    // grep-style guard: the only callers that create organisms are populate (tick 0) and queue_birth by plants/reproduction.
    let src = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
    let mut users = Vec::new();
    for e in std::fs::read_dir(&src).unwrap() {
        let p = e.unwrap().path();
        let t = std::fs::read_to_string(&p).unwrap();
        if t.contains(".queue_birth(") {
            users.push(p.file_name().unwrap().to_string_lossy().to_string());
        }
    }
    users.sort();
    assert_eq!(users, vec!["plants.rs".to_string(), "reproduction.rs".to_string()]);
}

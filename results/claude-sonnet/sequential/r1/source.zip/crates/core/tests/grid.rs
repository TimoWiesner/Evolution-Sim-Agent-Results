//! Integration tests for toroidal grid geometry (ADR-0008). The reference
//! implementation here is independent of `Grid::delta/dist`.
use evosim_core::grid::{Delta, Grid, Pos};
use std::collections::BTreeSet;

fn p(x: i32, y: i32) -> Pos {
    Pos { x, y }
}
fn d(dx: i32, dy: i32) -> Delta {
    Delta { dx, dy }
}
fn grid(w: u32, h: u32) -> Grid {
    Grid::new(w, h).unwrap()
}
fn all_cells(g: &Grid) -> Vec<Pos> {
    let mut v = Vec::new();
    for y in 0..g.height() as i32 {
        for x in 0..g.width() as i32 {
            v.push(p(x, y));
        }
    }
    v
}
/// Independent per-axis shortest absolute distance over the image offsets.
fn axis_ref(a: i32, b: i32, n: u32) -> i64 {
    let (a, b, n) = (a as i64, b as i64, n as i64);
    let dd = b - a;
    [dd.abs(), (dd - n).abs(), (dd + n).abs()].into_iter().min().unwrap()
}
fn dist_ref(g: &Grid, a: Pos, b: Pos) -> i64 {
    axis_ref(a.x, b.x, g.width()).max(axis_ref(a.y, b.y, g.height()))
}
fn brute_within(g: &Grid, c: Pos, r: i64) -> BTreeSet<Pos> {
    all_cells(g).into_iter().filter(|q| dist_ref(g, c, *q) <= r).collect()
}

const SIZES: [(u32, u32); 14] = [
    (1, 1), (1, 2), (2, 1), (1, 5), (5, 1), (2, 2), (3, 3),
    (5, 3), (6, 4), (7, 2), (4, 9), (7, 5), (1, 6), (6, 1),
];

#[test]
fn cells_within_matches_bruteforce() {
    for (w, h) in SIZES {
        let g = grid(w, h);
        let maxr = 2 * w.max(h) as i64 + 2;
        for c in all_cells(&g) {
            for r in 0..=maxr {
                let v = g.cells_within(c, r);
                let set: BTreeSet<Pos> = v.iter().copied().collect();
                assert_eq!(v.len(), set.len(), "duplicates {}x{} c={:?} r={}", w, h, c, r);
                assert!(v.iter().all(|q| g.contains(*q)));
                assert_eq!(set, brute_within(&g, c, r), "{}x{} c={:?} r={}", w, h, c, r);
                assert_eq!(g.count_within(r), v.len());
            }
            assert!(g.cells_within(c, -1).is_empty());
            assert_eq!(g.count_within(-1), 0);
            for r in [1000i64, i64::MAX / 4] {
                let v = g.cells_within(c, r);
                let set: BTreeSet<Pos> = v.iter().copied().collect();
                assert_eq!(v.len(), (w * h) as usize);
                assert_eq!(set.len(), (w * h) as usize);
            }
        }
    }
}

#[test]
fn radius_larger_than_world_covers_each_cell_once() {
    for (w, h) in [(3u32, 3u32), (4, 2)] {
        let g = grid(w, h);
        let v = g.cells_within(p(1, 1), 10);
        let set: BTreeSet<Pos> = v.iter().copied().collect();
        assert_eq!(v.len(), (w * h) as usize);
        assert_eq!(set.len(), v.len());
    }
}

#[test]
fn deterministic_order() {
    let g = grid(5, 4);
    let c = p(0, 0);
    assert_eq!(g.cells_within(c, 2), g.cells_within(c, 2));
    assert_eq!(g.cells_within(c, 1)[0], p(4, 3));
}

#[test]
fn edges_and_corners_nonsquare() {
    for (w, h) in [(7u32, 5u32), (6, 4)] {
        let g = grid(w, h);
        let (mx, my) = (w as i32 - 1, h as i32 - 1);
        // left/right edges
        for y in 0..h as i32 {
            assert_eq!(g.delta(p(0, y), p(mx, y)), d(-1, 0));
            assert_eq!(g.delta(p(mx, y), p(0, y)), d(1, 0));
            assert_eq!(g.dist(p(0, y), p(mx, y)), 1);
        }
        // top/bottom edges
        for x in 0..w as i32 {
            assert_eq!(g.delta(p(x, 0), p(x, my)), d(0, -1));
            assert_eq!(g.delta(p(x, my), p(x, 0)), d(0, 1));
            assert_eq!(g.dist(p(x, 0), p(x, my)), 1);
        }
        // corners
        assert_eq!(g.delta(p(0, 0), p(mx, my)), d(-1, -1));
        assert_eq!(g.delta(p(mx, my), p(0, 0)), d(1, 1));
        assert_eq!(g.delta(p(mx, 0), p(0, my)), d(1, -1));
        assert_eq!(g.delta(p(0, my), p(mx, 0)), d(-1, 1));
        for (a, b) in [(p(0, 0), p(mx, my)), (p(mx, 0), p(0, my))] {
            assert_eq!(g.dist(a, b), 1);
            assert_eq!(g.dist(b, a), 1);
        }
        // longer span across both edges
        // (odd sizes only: on even sizes dy=2 of 4 is a half-way tie -> +2)
        if w % 2 == 1 && h % 2 == 1 {
            assert_eq!(g.delta(p(0, 0), p(mx - 1, my - 1)), d(-2, -2));
            assert_eq!(g.dist(p(0, 0), p(mx - 1, my - 1)), 2);
        }
        assert_eq!(g.delta(p(0, 0), p(mx - 1, 0)), d(-2, 0));
    }
}

#[test]
fn delta_dist_properties() {
    for (w, h) in SIZES {
        let g = grid(w, h);
        let cells = all_cells(&g);
        for &a in &cells {
            for &b in &cells {
                let dl = g.delta(a, b);
                assert_eq!(g.offset(a, dl.dx as i64, dl.dy as i64), b);
                assert!(dl.dx.unsigned_abs() <= w / 2 && dl.dy.unsigned_abs() <= h / 2);
                assert_eq!(g.dist(a, b), g.dist(b, a));
                assert_eq!(g.dist(a, b) as i64, dist_ref(&g, a, b));
                let back = g.delta(b, a);
                if w % 2 == 1 {
                    assert_eq!(back.dx, -dl.dx);
                } else if dl.dx.unsigned_abs() == w / 2 {
                    assert_eq!((dl.dx, back.dx), ((w / 2) as i32, (w / 2) as i32));
                }
                if h % 2 == 1 {
                    assert_eq!(back.dy, -dl.dy);
                } else if dl.dy.unsigned_abs() == h / 2 {
                    assert_eq!((dl.dy, back.dy), ((h / 2) as i32, (h / 2) as i32));
                }
            }
        }
    }
}

#[test]
fn wrap_negative_multiple_extreme() {
    let g = grid(7, 5);
    assert_eq!(g.wrap(-1, -1), p(6, 4));
    assert_eq!(g.wrap(-7, -5), p(0, 0));
    assert_eq!(g.wrap(-8, -6), p(6, 4));
    assert_eq!(g.wrap(7, 5), p(0, 0));
    for k in [-1000i64, 1000] {
        for c in 0..5i64 {
            assert_eq!(g.wrap(7 * k + c, 5 * k + c), p(c as i32, c as i32));
        }
    }
    for v in [i64::MIN, i64::MAX, i64::MIN + 1, i64::MAX - 1] {
        let q = g.wrap(v, v);
        assert!(g.contains(q));
        assert_eq!(q.x as i128, (v as i128).rem_euclid(7));
        assert_eq!(q.y as i128, (v as i128).rem_euclid(5));
    }
}

#[test]
fn one_by_one() {
    let g = grid(1, 1);
    for v in [-3i64, -1, 0, 1, 99, i64::MIN, i64::MAX] {
        assert_eq!(g.wrap(v, -v.wrapping_add(1)), p(0, 0));
    }
    assert_eq!(g.delta(p(0, 0), p(0, 0)), d(0, 0));
    assert_eq!(g.dist(p(0, 0), p(0, 0)), 0);
    assert_eq!(g.step_toward(p(0, 0), p(0, 0)), d(0, 0));
    for r in [0i64, 5] {
        assert_eq!(g.cells_within(p(0, 0), r), vec![p(0, 0)]);
    }
    assert!(g.neighbors8(p(0, 0)).is_empty());
    assert_eq!(g.index(p(0, 0)), 0);
    assert_eq!(g.pos_of(0), p(0, 0));
    assert_eq!(g.cell_count(), 1);
}

#[test]
fn one_by_n_and_n_by_one() {
    let g = grid(1, 6);
    assert_eq!(g.wrap(-5, -1), p(0, 5));
    assert_eq!(g.delta(p(0, 0), p(0, 5)), d(0, -1));
    assert_eq!(g.delta(p(0, 5), p(0, 0)), d(0, 1));
    assert_eq!(g.dist(p(0, 0), p(0, 5)), 1);
    assert_eq!(g.dist(p(0, 0), p(0, 3)), 3);
    let g2 = grid(6, 1);
    assert_eq!(g2.wrap(-1, 9), p(5, 0));
    assert_eq!(g2.delta(p(0, 0), p(5, 0)), d(-1, 0));
    assert_eq!(g2.dist(p(0, 0), p(5, 0)), 1);
    // x axis of a 1xN world never moves
    for a in all_cells(&g) {
        for b in all_cells(&g) {
            assert_eq!(g.delta(a, b).dx, 0);
        }
    }
    for ((w, h), n) in [((1u32, 6u32), 2usize), ((6, 1), 2), ((1, 2), 1), ((2, 1), 1), ((2, 2), 3), ((1, 3), 2)] {
        let g = grid(w, h);
        for c in all_cells(&g) {
            let nb = g.neighbors8(c);
            let set: BTreeSet<Pos> = nb.iter().copied().collect();
            assert_eq!(nb.len(), set.len(), "{}x{}", w, h);
            assert!(!set.contains(&c));
            assert_eq!(nb.len(), n, "{}x{}", w, h);
        }
    }
}

#[test]
fn new_rejects_zero() {
    assert!(Grid::new(0, 5).is_err());
    assert!(Grid::new(5, 0).is_err());
    assert!(Grid::new(0, 0).is_err());
}

#[test]
fn step_toward_signs() {
    for (w, h) in [(7u32, 5u32), (6, 4)] {
        let g = grid(w, h);
        let (mx, my) = (w as i32 - 1, h as i32 - 1);
        assert_eq!(g.step_toward(p(2, 2), p(2, 2)), d(0, 0));
        assert_eq!(g.step_toward(p(0, 1), p(mx, 1)), d(-1, 0));
        assert_eq!(g.step_toward(p(1, my), p(1, 0)), d(0, 1));
        assert_eq!(g.step_toward(p(0, 0), p(mx, my)), d(-1, -1));
    }
    // even size tie goes positive
    assert_eq!(grid(6, 4).step_toward(p(0, 0), p(3, 2)), d(1, 1));
    // exhaustive: components in {-1,0,1}, distance strictly decreases
    for (w, h) in SIZES {
        let g = grid(w, h);
        let cells = all_cells(&g);
        for &a in &cells {
            for &b in &cells {
                let s = g.step_toward(a, b);
                assert!((-1..=1).contains(&s.dx) && (-1..=1).contains(&s.dy));
                if a != b {
                    let n = g.offset(a, s.dx as i64, s.dy as i64);
                    assert!(g.dist(n, b) < g.dist(a, b), "{}x{} {:?}->{:?}", w, h, a, b);
                } else {
                    assert_eq!(s, d(0, 0));
                }
            }
        }
    }
}

//! TASK-014: herbivore feeding, running costs, climate and gene-driven decisions (ADR-0018).
use evosim_core::config::Config;
use evosim_core::genome::{Gene, Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::herbivore::{bite_size, climate_mult, score_plant, upkeep_cost, DANGER_W, FEED_REACH};
use evosim_core::movement::vision_cells;
use evosim_core::organism::{DeathCause, Id, Kind, NewBorn};
use evosim_core::sim::Simulation;

fn p(x: i32, y: i32) -> Pos {
    Pos { x, y }
}

fn cfg(w: u32, h: u32) -> Config {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = w;
    c.world.height = h;
    c.initial.plants = 1; // helper founder (parent for queue_birth)
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.equator_temp = 18.0;
    c.climate.pole_temp = 18.0;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.seasonal_precip_amplitude = 0.0;
    c.climate.precip_mean = 1.0;
    c.climate.precip_latitude_variation = 0.0;
    c.climate.weather_noise = 0.0;
    c.climate.terrain_noise = 0.0;
    c.plants.maintenance = 0.0;
    c.plants.growth_rate = 0.0;
    c.plants.max_age = 1_000_000;
    c.plants.max_energy = 200.0;
    c.plants.reproduction_threshold = 200.0;
    c.plants.reproduction_cost = 50.0;
    c.herbivores.max_age = 1_000_000;
    c.carnivores.max_age = 1_000_000;
    c.herbivores.base_metabolism = 0.0;
    c.herbivores.move_cost = 0.0;
    c.herbivores.bite_size = 4.0;
    c.herbivores.digestion_efficiency = 0.6;
    c.plants.graze_reserve = 0.0; // these tests eat plants down to zero (ADR-0022 default keeps a reserve)
    c
}

struct Setup {
    s: Simulation,
    founder: Id,
}

fn setup(c: &Config) -> Setup {
    let s = Simulation::new(c).unwrap();
    let founder = s.organisms.vec(Kind::Plant)[0].id;
    Setup { s, founder }
}

fn alleles(aggr: f32, risk: f32, vision: f32) -> Genome {
    let mut a = [[0.5f32; 2]; N_GENES];
    a[Gene::Aggression.index()] = [aggr, aggr];
    a[Gene::RiskTolerance.index()] = [risk, risk];
    a[Gene::Vision.index()] = [vision, vision];
    Genome::from_alleles(a)
}

impl Setup {
    fn birth(&mut self, kind: Kind, pos: Pos, genome: Genome, energy: f64) -> Id {
        assert!(self.s.organisms.queue_birth(NewBorn { kind, pos, parents: [self.founder, 0], genome, energy }));
        self.s.organisms.resolve_births(0).last().unwrap().0
    }
    fn plant(&mut self, pos: Pos, energy: f64) -> Id {
        let id = self.birth(Kind::Plant, pos, Genome::from_alleles([[0.5f32; 2]; N_GENES]), energy);
        self.s.organisms.get_mut(Kind::Plant, id).unwrap().set_energy(energy);
        id
    }
    /// Herbivore with trait overrides: speed, vision, aggression 0.5 (bite = bite_size), energy.
    fn herb(&mut self, pos: Pos, speed: f64, vision: f64, energy: f64) -> Id {
        let id = self.birth(Kind::Herbivore, pos, alleles(0.5, 0.5, 0.5), energy);
        let o = self.s.organisms.get_mut(Kind::Herbivore, id).unwrap();
        o.traits.speed = speed;
        o.traits.vision = vision;
        o.traits.metabolism = 1.0;
        o.traits.aggression = 0.5;
        o.traits.max_energy = 100.0;
        o.set_energy(energy);
        id
    }
    fn finish(mut self) -> Simulation {
        let f = self.founder;
        self.s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != f);
        self.s.rebuild_index();
        self.s.check_index().unwrap();
        self.s
    }
}

fn pen(s: &Simulation, id: Id) -> f64 {
    s.organisms.get(Kind::Plant, id).map(|o| o.energy()).unwrap_or(0.0)
}
fn hen(s: &Simulation, id: Id) -> f64 {
    s.organisms.get(Kind::Herbivore, id).unwrap().energy()
}
fn hpos(s: &Simulation, id: Id) -> Pos {
    s.organisms.get(Kind::Herbivore, id).unwrap().pos
}

#[test]
fn reach_own_and_adjacent_only() {
    assert_eq!(FEED_REACH, 1);
    // speed 0.1: no step in the first ticks, so only plants within reach can be eaten
    for (pos, eaten) in [(p(5, 5), true), (p(6, 5), true), (p(4, 4), true), (p(7, 5), false), (p(5, 8), false)] {
        let mut st = setup(&cfg(10, 10));
        let h = st.herb(p(5, 5), 0.1, 4.0, 50.0);
        let pl = st.plant(pos, 50.0);
        let mut s = st.finish();
        s.step();
        assert_eq!(hpos(&s, h), p(5, 5));
        assert_eq!(pen(&s, pl) < 50.0, eaten, "plant at {:?}", pos);
    }
    // across the seams (wrap): distance 1 is eaten, distance 2 is not
    for (pos, eaten) in [(p(9, 0), true), (p(9, 9), true), (p(0, 9), true), (p(8, 0), false), (p(0, 8), false)] {
        let mut st = setup(&cfg(10, 10));
        let h = st.herb(p(0, 0), 0.1, 4.0, 50.0);
        let pl = st.plant(pos, 50.0);
        let mut s = st.finish();
        s.step();
        assert_eq!(hpos(&s, h), p(0, 0));
        assert_eq!(pen(&s, pl) < 50.0, eaten, "plant at {:?}", pos);
    }
    // a plant at distance 2 is only eaten after the herbivore walked up to it (8 ticks of credit at speed 0.125)
    let mut st = setup(&cfg(10, 10));
    let h = st.herb(p(2, 5), 0.125, 4.0, 50.0);
    let pl = st.plant(p(4, 5), 50.0);
    let mut s = st.finish();
    for t in 0..7 {
        s.step();
        assert_eq!(pen(&s, pl), 50.0, "tick {}", t);
        assert_eq!(hpos(&s, h), p(2, 5));
    }
    s.step();
    assert_eq!(hpos(&s, h), p(3, 5));
    assert!(pen(&s, pl) < 50.0);
}

#[test]
fn bite_limit_and_conservation() {
    let c = cfg(6, 6);
    let mut st = setup(&c);
    let h = st.herb(p(2, 2), 0.1, 3.0, 20.0);
    let pl = st.plant(p(2, 2), 50.0);
    let mut s = st.finish();
    let bite = bite_size(&c, s.organisms.get(Kind::Herbivore, h).unwrap());
    assert!((bite - 4.0).abs() < 1e-12);
    s.step();
    assert!((pen(&s, pl) - 46.0).abs() < 1e-12, "plant loses exactly one bite");
    assert!((hen(&s, h) - (20.0 + 4.0 * 0.6)).abs() < 1e-12);
    let (mut eaten, mut gained) = (s.last_herbivore_stats.eaten_energy, s.last_herbivore_stats.gained_energy);
    assert!((eaten - 4.0).abs() < 1e-12 && gained <= eaten);
    for _ in 0..300 {
        s.step();
        let st = s.last_herbivore_stats;
        assert!(st.gained_energy <= st.eaten_energy + 1e-12);
        eaten += st.eaten_energy;
        gained += st.gained_energy;
    }
    assert!((eaten - 50.0).abs() < 1e-9, "the whole plant was eaten, nothing more: {}", eaten);
    assert!((gained - 0.6 * eaten).abs() < 1e-9);
    assert!((hen(&s, h) - (20.0 + gained)).abs() < 1e-9);
}

#[test]
fn plant_dies_when_eaten() {
    let mut st = setup(&cfg(6, 6));
    let a = st.herb(p(3, 3), 0.1, 3.0, 20.0);
    let b = st.herb(p(3, 3), 0.1, 3.0, 20.0);
    let pl = st.plant(p(3, 3), 2.0); // less than one bite
    let mut s = st.finish();
    s.step();
    let stats = s.last_herbivore_stats;
    assert_eq!((stats.bites, stats.plants_killed), (1, 1), "second animal cannot eat the dead plant");
    assert!((stats.eaten_energy - 2.0).abs() < 1e-12 && (stats.gained_energy - 1.2).abs() < 1e-12);
    assert!((hen(&s, a) - 21.2).abs() < 1e-12);
    assert_eq!(hen(&s, b), 20.0);
    assert!(s.organisms.get(Kind::Plant, pl).is_none(), "removed in the Deaths phase");
    assert_eq!(s.organisms.stats.deaths_by_cause[0][DeathCause::Predation.index()], 1);
    s.check_index().unwrap();
}

#[test]
fn no_overfeeding() {
    // satiated: does not eat and wanders
    let mut st = setup(&cfg(10, 10));
    let h = st.herb(p(5, 5), 1.0, 3.0, 95.0);
    let pl = st.plant(p(5, 5), 50.0);
    let mut s = st.finish();
    s.step();
    assert_eq!(pen(&s, pl), 50.0);
    assert_eq!(s.last_herbivore_stats.satiated, 1);
    assert_ne!(s.organisms.get(Kind::Herbivore, h).unwrap().heading, 0, "wandered");
    // room limit: never above max_energy, gain bounded by room
    let mut c = cfg(10, 10);
    c.herbivores.satiation_limit = 1.0;
    let mut st = setup(&c);
    let h = st.herb(p(5, 5), 0.1, 3.0, 99.0);
    let pl = st.plant(p(5, 5), 50.0);
    let mut s = st.finish();
    s.step();
    assert!((hen(&s, h) - 100.0).abs() < 1e-9);
    assert!((50.0 - pen(&s, pl) - 1.0 / 0.6).abs() < 1e-9, "only what fits is taken");
}

#[test]
fn upkeep_every_tick_and_starvation() {
    let mut c = cfg(8, 8);
    c.herbivores.base_metabolism = 0.5;
    let mut st = setup(&c);
    let h = st.herb(p(4, 4), 0.1, 2.0, 5.0);
    let mut s = st.finish();
    for k in 1..=9 {
        let before = hen(&s, h);
        s.step();
        assert!((before - hen(&s, h) - 0.5).abs() < 1e-12, "tick {}", k);
        assert!((s.last_herbivore_stats.upkeep_paid - 0.5).abs() < 1e-12);
    }
    assert!((hen(&s, h) - 0.5).abs() < 1e-12);
    assert_eq!(s.organisms.count(Kind::Herbivore), 1);
    s.step(); // energy hits 0 in tick 10
    assert_eq!(s.organisms.count(Kind::Herbivore), 0);
    assert_eq!(s.organisms.stats.deaths_by_cause[1][DeathCause::Starvation.index()], 1);
    s.check_index().unwrap();
}

fn drop_at(temp: f64) -> f64 {
    let mut c = cfg(6, 6);
    c.climate.equator_temp = temp;
    c.climate.pole_temp = temp;
    c.herbivores.base_metabolism = 0.4;
    let mut st = setup(&c);
    let h = st.herb(p(3, 3), 0.1, 2.0, 50.0);
    let mut s = st.finish();
    s.step();
    50.0 - hen(&s, h)
}

#[test]
fn climate_cost() {
    let c = cfg(6, 6);
    // formula: comfort 18, tolerance 14, cost 0.5; capped at 1 + 4 * cost
    assert_eq!(climate_mult(&c.herbivores, 18.0), 1.0);
    assert_eq!(climate_mult(&c.herbivores, 18.0 + 14.0), 1.0);
    assert!((climate_mult(&c.herbivores, 18.0 + 21.0) - 1.25).abs() < 1e-12);
    assert!((climate_mult(&c.herbivores, -20.0) - (1.0 + 0.5 * 24.0 / 14.0)).abs() < 1e-12);
    assert!((climate_mult(&c.herbivores, 1000.0) - 3.0).abs() < 1e-12);
    assert!((climate_mult(&c.herbivores, -1000.0) - 3.0).abs() < 1e-12);
    let (mild, cold, hot) = (drop_at(18.0), drop_at(-20.0), drop_at(40.0));
    assert!((mild - 0.4).abs() < 1e-9);
    assert!((cold - 0.4 * climate_mult(&c.herbivores, -20.0)).abs() < 1e-9);
    assert!((hot - 0.4 * climate_mult(&c.herbivores, 40.0)).abs() < 1e-9);
    assert!(cold > hot && hot > mild, "{} {} {}", cold, hot, mild);
    // upkeep_cost uses the metabolism trait
    let mut st = setup(&cfg(6, 6));
    let h = st.herb(p(1, 1), 1.0, 2.0, 50.0);
    let mut s = st.finish();
    s.organisms.get_mut(Kind::Herbivore, h).unwrap().traits.metabolism = 2.0;
    let mut c2 = cfg(6, 6);
    c2.herbivores.base_metabolism = 0.3;
    assert!((upkeep_cost(&c2.herbivores, s.organisms.get(Kind::Herbivore, h).unwrap(), 18.0) - 0.6).abs() < 1e-12);
    // seasons: the cost changes with the temperature over the year
    let mut c3 = cfg(6, 6);
    c3.climate.equator_temp = 40.0;
    c3.climate.pole_temp = 40.0;
    c3.climate.seasonal_amplitude = 20.0;
    c3.herbivores.base_metabolism = 0.2;
    let mut st = setup(&c3);
    st.herb(p(3, 3), 0.1, 2.0, 100.0);
    let mut s = st.finish();
    let mut costs = Vec::new();
    for _ in 0..400 {
        s.step();
        costs.push(s.last_herbivore_stats.upkeep_paid);
    }
    let (lo, hi) = costs.iter().fold((f64::MAX, f64::MIN), |a, &c| (a.0.min(c), a.1.max(c)));
    assert!(hi > lo + 0.01, "seasonal temperature changes the cost: {} {}", lo, hi);
    assert!(s.last_herbivore_stats.climate_extra_paid >= 0.0);
}

#[test]
fn genes_change_decisions() {
    // (a) risk tolerance: near plant next to a carnivore, farther plant safe
    let run_risk = |risk: f32| {
        let mut st = setup(&cfg(30, 30));
        let h = st.birth(Kind::Herbivore, p(10, 10), alleles(0.5, risk, 0.5), 50.0);
        {
            let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
            o.traits.speed = 1.0;
            o.traits.max_energy = 100.0;
            o.set_energy(50.0);
        }
        let near = st.plant(p(11, 10), 50.0);
        let far = st.plant(p(8, 10), 50.0);
        st.birth(Kind::Carnivore, p(12, 10), alleles(0.5, 0.5, 0.5), 50.0);
        let mut s = st.finish();
        assert_eq!(s.organisms.get(Kind::Herbivore, h).unwrap().traits.risk_tolerance, risk as f64);
        s.step();
        (hpos(&s, h), pen(&s, near), pen(&s, far))
    };
    let (pos0, near0, far0) = run_risk(0.0);
    let (pos1, near1, far1) = run_risk(1.0);
    assert_eq!(pos0, p(9, 10));
    assert!(far0 < 50.0 && near0 == 50.0, "cautious: eats the safe plant");
    assert_eq!(pos1, p(10, 10));
    assert!(near1 < 50.0 && far1 == 50.0, "bold: eats the plant next to the carnivore");

    // (b) aggression: a competitor on the near plant; also changes the bite
    let run_aggr = |aggr: f32| {
        let mut st = setup(&cfg(30, 30));
        let h = st.birth(Kind::Herbivore, p(10, 10), alleles(aggr, 0.5, 0.5), 50.0);
        {
            let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
            o.traits.speed = 1.0;
            o.traits.max_energy = 100.0;
            o.set_energy(50.0);
        }
        let near = st.plant(p(11, 10), 50.0);
        let far = st.plant(p(8, 10), 50.0);
        let rival = st.herb(p(11, 10), 0.1, 2.0, 99.0); // satiated, only a competitor
        let mut s = st.finish();
        let bite = bite_size(&s.config, s.organisms.get(Kind::Herbivore, h).unwrap());
        s.step();
        assert_eq!(hen(&s, rival), 99.0);
        (hpos(&s, h), 50.0 - pen(&s, near), 50.0 - pen(&s, far), bite)
    };
    let (pos0, near0, far0, bite0) = run_aggr(0.0);
    let (pos1, near1, far1, bite1) = run_aggr(1.0);
    assert_eq!((pos0, near0 == 0.0, far0), (p(9, 10), true, bite0), "timid avoids the crowded plant");
    assert_eq!((pos1, far1 == 0.0, near1), (p(10, 10), true, bite1), "aggressive takes the crowded plant");
    assert!(bite1 > bite0);

    // (c) vision gene: same situation, one sees the plant and walks, the other wanders
    let run_vis = |v: f32| {
        let mut st = setup(&cfg(30, 30));
        let h = st.birth(Kind::Herbivore, p(10, 10), alleles(0.5, 0.5, v), 50.0);
        {
            let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
            o.traits.speed = 1.0;
            o.traits.max_energy = 100.0;
            o.set_energy(50.0);
        }
        st.plant(p(10, 13), 50.0);
        let s0 = st.finish();
        let vis = vision_cells(s0.organisms.get(Kind::Herbivore, h).unwrap());
        let mut s = s0;
        s.step();
        (vis, hpos(&s, h), s.organisms.get(Kind::Herbivore, h).unwrap().heading)
    };
    let (vlo, _, hlo) = run_vis(0.0);
    let (vhi, phi, hhi) = run_vis(0.5);
    assert!(vlo < 3 && vhi >= 3, "{} {}", vlo, vhi);
    assert_eq!((phi, hhi), (p(10, 11), 0), "sees the plant: walks toward it");
    assert_ne!(hlo, 0, "does not see it: wanders");
}

#[test]
fn score_is_monotone_in_genes() {
    let s = |a: f64, r: f64, others: u32, danger: f64, dist: u32| score_plant(4.0, 0.6, 50.0, dist, a, r, others, danger);
    assert!(s(0.5, 0.5, 0, 0.0, 1) > s(0.5, 0.5, 0, 0.0, 2));
    assert!(s(1.0, 0.5, 2, 0.0, 1) > s(0.0, 0.5, 2, 0.0, 1));
    assert!(s(0.5, 1.0, 0, 0.5, 1) > s(0.5, 0.0, 0, 0.5, 1));
    assert_eq!(s(0.5, 1.0, 0, 5.0, 1), s(0.5, 1.0, 0, 0.0, 1));
    assert!(DANGER_W > 0.0);
}

#[test]
fn index_and_determinism() {
    let mk = || {
        let mut c = Config::default();
        c.seed = 21;
        c.world.width = 30;
        c.world.height = 30;
        c.initial.plants = 300;
        c.initial.herbivores = 60;
        c.initial.carnivores = 5;
        Simulation::new(&c).unwrap()
    };
    let (mut a, mut b) = (mk(), mk());
    let (mut eaten, mut gained) = (0.0, 0.0);
    for _ in 0..300 {
        a.step();
        b.step();
        a.check_index().unwrap();
        eaten += a.last_herbivore_stats.eaten_energy;
        gained += a.last_herbivore_stats.gained_energy;
        for k in Kind::ALL {
            for o in a.organisms.vec(k) {
                assert!(o.energy().is_finite() && o.energy() >= 0.0);
            }
        }
    }
    assert_eq!(a.digest(), b.digest());
    assert!(eaten > 0.0 && gained <= eaten);
    for k in Kind::ALL {
        let i = k.index();
        let st = &a.organisms.stats;
        assert_eq!(a.organisms.count(k) as u64, st.founded[i] + st.births[i] - st.deaths[i]);
    }
}

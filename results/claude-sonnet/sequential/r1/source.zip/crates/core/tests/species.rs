//! TASK-017: species and family tree (ADR-0021).
use evosim_core::config::Config;
use evosim_core::genome::Genome;
use evosim_core::grid::Pos;
use evosim_core::organism::{Id, Kind, NewBorn};
use evosim_core::sim::Simulation;
use evosim_core::species::syllable_word;

fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = 20;
    c.world.height = 20;
    c.initial.plants = 0;
    c.initial.herbivores = 1;
    c.initial.carnivores = 0;
    c.genetics.founder_variation = 0.0;
    c.genetics.species_threshold = 0.25;
    c.genetics.species_min_size = 3;
    c.genetics.species_check_interval = 10;
    c.herbivores.max_age = 1_000_000;
    c
}

/// Genome with every allele of `g` shifted by `delta` (distance = |delta| when no clamping).
fn shifted(g: &Genome, delta: f32) -> Genome {
    let mut a = *g.alleles();
    for l in a.iter_mut() {
        l[0] += delta;
        l[1] += delta;
    }
    Genome::from_alleles(a)
}

fn founder_id(sim: &Simulation) -> Id {
    sim.organisms.herbivores[0].id
}

fn spawn(sim: &mut Simulation, parent: Id, g: Genome, n: usize) -> Vec<Id> {
    for _ in 0..n {
        assert!(sim.organisms.queue_birth(NewBorn { kind: Kind::Herbivore, pos: Pos { x: 1, y: 1 }, parents: [parent, 0], genome: g, energy: 10.0 }));
    }
    let t = sim.tick;
    sim.organisms.resolve_births(t).into_iter().map(|b| b.0).collect()
}

fn species_of(sim: &Simulation, id: Id) -> u32 {
    sim.organisms.get(Kind::Herbivore, id).unwrap().species
}

#[test]
fn founders_all_have_species_of_their_kind() {
    let mut c = Config::default();
    c.initial.plants = 50;
    c.initial.herbivores = 20;
    c.initial.carnivores = 5;
    let sim = Simulation::new(&c).unwrap();
    for k in Kind::ALL {
        for o in sim.organisms.vec(k) {
            assert_ne!(o.species, 0);
            let r = sim.species.get(o.species).unwrap();
            assert_eq!(r.kind, k);
            assert_eq!(r.arose, 0);
            assert_eq!(r.parent, 0);
        }
        assert!(sim.living_species(k) >= 1);
        assert_eq!(sim.species.living_at(k, 0), sim.living_species(k));
    }
}

#[test]
fn determinism_ids_and_names() {
    let mut c = Config::default();
    c.seed = 3;
    c.initial.plants = 300;
    c.initial.herbivores = 40;
    c.initial.carnivores = 8;
    c.genetics.founder_variation = 0.3;
    c.genetics.species_threshold = 0.05;
    let run = |seed: i64| {
        let mut cc = c.clone();
        cc.seed = seed;
        let mut s = Simulation::new(&cc).unwrap();
        s.run(120);
        (s.species.records().iter().map(|r| (r.id, r.name.clone(), r.parent, r.arose, r.extinct)).collect::<Vec<_>>(), s.digest())
    };
    let (a, da) = run(3);
    let (b, db) = run(3);
    assert_eq!(a, b);
    assert_eq!(da, db);
    let (_, dc) = run(4);
    assert_ne!(da, dc);
    let mut names: Vec<(Kind, String)> = Vec::new();
    let s = Simulation::new(&{
        let mut cc = c.clone();
        cc.seed = 3;
        cc
    })
    .unwrap();
    for r in s.species.records() {
        assert!(!names.contains(&(r.kind, r.name.clone())), "duplicate {}", r.name);
        names.push((r.kind, r.name.clone()));
    }
    assert!(s.species.records().len() > 3);
}

#[test]
fn syllable_words_are_injective() {
    let mut seen = std::collections::HashSet::new();
    for n in 0..5000u64 {
        assert!(seen.insert(syllable_word(n)));
    }
}

#[test]
fn divergence_splits_species_with_parent_and_tick() {
    let c = cfg();
    let mut sim = Simulation::new(&c).unwrap();
    sim.tick = 7;
    let f = founder_id(&sim);
    let fg = *sim.organisms.herbivores[0].genome();
    let root = species_of(&sim, f);
    assert_eq!(sim.living_species(Kind::Herbivore), 1);
    // distance 0.4 > 0.25: three diverged newborns (inherit the founder's species first)
    let far = shifted(&fg, 4.0 * 0.1);
    assert!(Genome::distance(&fg, &far) > 0.25);
    let ids = spawn(&mut sim, f, far, 3);
    for &i in &ids {
        assert_eq!(species_of(&sim, i), root);
    }
    sim.species.classify(&mut sim.organisms, &sim.config, 7);
    sim.species.finish_tick(&sim.organisms, 7);
    assert_eq!(sim.living_species(Kind::Herbivore), 2);
    let ns = species_of(&sim, ids[0]);
    assert_ne!(ns, root);
    assert!(ids.iter().all(|&i| species_of(&sim, i) == ns));
    assert_eq!(species_of(&sim, f), root);
    let r = sim.species.get(ns).unwrap();
    assert_eq!((r.parent, r.arose, r.extinct, r.founded_by), (root, 7, None, ids[0]));
    assert_eq!(sim.species.lineage(ns), vec![ns, root]);
    assert_eq!(sim.species.children(root), vec![ns]);
    assert_eq!(sim.species.members(ns), 3);
    assert_eq!(sim.species.living_at(Kind::Herbivore, 6), 1);
    assert_eq!(sim.species.living_at(Kind::Herbivore, 7), 2);
    assert!(r.name.split(' ').next() == sim.species.get(root).unwrap().name.split(' ').next());
    assert_ne!(r.name, sim.species.get(root).unwrap().name);
}

#[test]
fn cluster_below_min_size_does_not_split() {
    let c = cfg();
    let mut sim = Simulation::new(&c).unwrap();
    let f = founder_id(&sim);
    let fg = *sim.organisms.herbivores[0].genome();
    let root = species_of(&sim, f);
    let ids = spawn(&mut sim, f, shifted(&fg, 0.4), 2);
    sim.species.classify(&mut sim.organisms, &sim.config, 1);
    assert_eq!(sim.living_species(Kind::Herbivore), 1);
    assert!(ids.iter().all(|&i| species_of(&sim, i) == root));
    // a third member tips it
    let more = spawn(&mut sim, f, shifted(&fg, 0.4), 1);
    sim.species.classify(&mut sim.organisms, &sim.config, 2);
    assert_eq!(sim.living_species(Kind::Herbivore), 2);
    assert_ne!(species_of(&sim, more[0]), root);
    assert_eq!(species_of(&sim, ids[0]), species_of(&sim, more[0]));
}

#[test]
fn threshold_is_inclusive() {
    let mut c = cfg();
    let probe = Simulation::new(&c).unwrap();
    let fg = *probe.organisms.herbivores[0].genome();
    let far = shifted(&fg, 0.5);
    let d = Genome::distance(&fg, &far);
    assert!(d > 0.0);
    for (thr, splits) in [(d, false), (f64::from_bits(d.to_bits() - 1), true)] {
        c.genetics.species_threshold = thr;
        let mut sim = Simulation::new(&c).unwrap();
        let f = founder_id(&sim);
        let ids = spawn(&mut sim, f, far, 3);
        sim.species.classify(&mut sim.organisms, &sim.config, 1);
        assert_eq!(sim.living_species(Kind::Herbivore), if splits { 2 } else { 1 }, "thr {thr}");
        assert_eq!(species_of(&sim, ids[0]) != species_of(&sim, f), splits);
    }
}

#[test]
fn split_only_on_check_ticks_in_sim() {
    let mut c = cfg();
    c.herbivores.base_metabolism = 0.0;
    c.herbivores.move_cost = 0.0;
    c.herbivores.reproduction_energy = 100.0;
    let mut sim = Simulation::new(&c).unwrap();
    let f = founder_id(&sim);
    let fg = *sim.organisms.herbivores[0].genome();
    sim.run(3); // tick = 3, next check at tick 10
    let ids = spawn(&mut sim, f, shifted(&fg, 0.4), 3);
    sim.run(6); // ticks 3..8 computed
    assert_eq!(sim.living_species(Kind::Herbivore), 1);
    sim.run(5); // tick 10 computed
    let _ = ids;
    assert_eq!(sim.living_species(Kind::Herbivore), 2);
    let r = &sim.species.records()[1];
    assert_eq!(r.arose, 10);
}

#[test]
fn extinction_is_recorded_and_final() {
    let c = cfg();
    let mut sim = Simulation::new(&c).unwrap();
    let f = founder_id(&sim);
    let fg = *sim.organisms.herbivores[0].genome();
    let ids = spawn(&mut sim, f, shifted(&fg, 0.4), 3);
    sim.species.classify(&mut sim.organisms, &sim.config, 0);
    let ns = species_of(&sim, ids[0]);
    assert_eq!(sim.living_species(Kind::Herbivore), 2);
    for &i in &ids {
        assert!(sim.organisms.mark_dead(i, evosim_core::organism::DeathCause::Other, 0));
    }
    sim.run(1); // tick 0 computed
    let r = sim.species.get(ns).unwrap();
    assert_eq!(r.extinct, Some(0));
    assert_eq!(sim.living_species(Kind::Herbivore), 1);
    assert_eq!(sim.species.living_at(Kind::Herbivore, 0), 1);
    // later checks never revive it
    sim.run(30);
    assert_eq!(sim.species.get(ns).unwrap().extinct, Some(0));
    assert_eq!(sim.species.members(ns), 0);
}

#[test]
fn grandparent_chain_and_nested_split() {
    let c = cfg();
    let mut sim = Simulation::new(&c).unwrap();
    let f = founder_id(&sim);
    let fg = *sim.organisms.herbivores[0].genome();
    let root = species_of(&sim, f);
    let g1 = shifted(&fg, 0.4);
    let a = spawn(&mut sim, f, g1, 3);
    sim.species.classify(&mut sim.organisms, &sim.config, 1);
    let s1 = species_of(&sim, a[0]);
    let g2 = shifted(&fg, -0.4);
    let b = spawn(&mut sim, a[0], g2, 3);
    assert_eq!(species_of(&sim, b[0]), s1);
    sim.species.classify(&mut sim.organisms, &sim.config, 2);
    let s2 = species_of(&sim, b[0]);
    assert_eq!(sim.species.lineage(s2), vec![s2, s1, root]);
    assert_eq!(sim.species.parent_of(s2), Some(s1));
    assert_eq!(sim.living_species(Kind::Herbivore), 3);
    // names: same genus
    let genus = |id| sim.species.get(id).unwrap().name.split(' ').next().unwrap().to_string();
    assert_eq!(genus(root), genus(s2));
}

#[test]
fn newborn_plant_inherits_species_even_if_parent_dies() {
    let mut c = cfg();
    c.initial.plants = 1;
    c.initial.herbivores = 0;
    let mut sim = Simulation::new(&c).unwrap();
    let p = sim.organisms.plants[0].id;
    let sp = sim.organisms.plants[0].species;
    assert_ne!(sp, 0);
    let g = *sim.organisms.plants[0].genome();
    assert!(sim.organisms.queue_birth(NewBorn { kind: Kind::Plant, pos: Pos { x: 2, y: 2 }, parents: [p, 0], genome: g, energy: 5.0 }));
    assert!(sim.organisms.mark_dead(p, evosim_core::organism::DeathCause::Other, 0));
    sim.organisms.resolve_deaths(0);
    let born = sim.organisms.resolve_births(0);
    assert_eq!(sim.organisms.get(Kind::Plant, born[0].0).unwrap().species, sp);
}

#[test]
fn unassigned_organisms_are_classified_at_next_check() {
    let c = cfg();
    let mut sim = Simulation::new(&c).unwrap();
    for o in sim.organisms.herbivores.iter_mut() {
        o.species = 0;
    }
    sim.species.classify(&mut sim.organisms, &sim.config, 4);
    assert_ne!(sim.organisms.herbivores[0].species, 0);
    // joined the existing living species instead of founding another
    assert_eq!(sim.species.records().len(), 1);
}

#[test]
fn forced_evolution_run_produces_valid_tree() {
    let mut c = Config::default();
    c.seed = 11;
    c.world.width = 40;
    c.world.height = 40;
    c.initial.plants = 600;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.plants.mutation_rate = 0.5;
    c.genetics.mutation_sigma = 0.02;
    c.genetics.species_threshold = 0.03;
    c.genetics.species_min_size = 3;
    c.genetics.species_check_interval = 5;
    let mut sim = Simulation::new(&c).unwrap();
    sim.run(600);
    let recs = sim.species.records();
    assert!(recs.len() > 1, "no speciation in 600 ticks");
    for (i, r) in recs.iter().enumerate() {
        assert_eq!(r.id as usize, i + 1);
        if r.parent != 0 {
            let p = sim.species.get(r.parent).unwrap();
            assert!(p.arose <= r.arose && p.id < r.id && p.kind == r.kind);
        }
        if let Some(e) = r.extinct {
            assert!(e >= r.arose);
        }
    }
    assert!(recs.iter().any(|r| r.parent != 0), "no daughter species");
    assert_eq!(sim.living_species(Kind::Plant), recs.iter().filter(|r| r.extinct.is_none()).count());
    // every living organism is in a living species of its kind
    for o in sim.organisms.vec(Kind::Plant) {
        let r = sim.species.get(o.species).unwrap();
        assert!(r.extinct.is_none() && r.kind == Kind::Plant);
    }
}

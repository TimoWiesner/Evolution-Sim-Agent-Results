//! TASK-006 climate/biome tests.
use evosim_core::climate::{ClimateMap, ELEV_COOLING};
use evosim_core::config::Config;
use evosim_core::json;
use evosim_core::sim::Simulation;

fn cfg(w: u32, h: u32, seed: i64) -> Config {
    let mut c = Config::default();
    c.world.width = w;
    c.world.height = h;
    c.seed = seed;
    c
}

fn gen(w: u32, h: u32, seed: i64) -> ClimateMap {
    ClimateMap::generate(&cfg(w, h, seed))
}

#[test]
fn every_cell_has_finite_climate_in_range() {
    let c = cfg(64, 48, 42);
    let m = ClimateMap::generate(&c);
    assert_eq!(m.temp.len(), 64 * 48);
    assert_eq!(m.biome.len(), 64 * 48);
    for i in 0..m.temp.len() {
        assert!(m.temp[i].is_finite() && m.precip[i].is_finite() && m.precip[i] >= 0.0);
        assert!(m.temp[i] >= c.climate.pole_temp - ELEV_COOLING - 1e-9);
        assert!(m.temp[i] <= c.climate.equator_temp + ELEV_COOLING + 1e-9);
    }
}

#[test]
fn deterministic_and_seeded() {
    let a = gen(40, 30, 7);
    let b = gen(40, 30, 7);
    assert_eq!(a.temp, b.temp);
    assert_eq!(a.precip, b.precip);
    assert_eq!(a.biome, b.biome);
    let c = gen(40, 30, 8);
    assert_ne!(a.temp, c.temp);
}

#[test]
fn world_owns_climate_and_sim_rng_untouched() {
    let c = cfg(32, 24, 3);
    let s = Simulation::new(&c).unwrap();
    assert_eq!(s.world.climate.temp, ClimateMap::generate(&c).temp);
}

#[test]
fn zone_order_without_noise() {
    for h in [24u32, 48, 200] {
        let mut c = cfg(16, h, 1);
        c.climate.terrain_noise = 0.0;
        let m = ClimateMap::generate(&c);
        let row = |y: u32| m.zone[(y * 16) as usize];
        let mut seen = [false; 5];
        let mut prev = 0;
        for y in 0..=(h - 1) / 2 {
            let z = row(y);
            assert!(z >= prev, "zone decreased at h={} y={}", h, y);
            prev = z;
            seen[z as usize] = true;
        }
        assert!(seen.iter().all(|&s| s), "h={} missing zone: {:?}", h, seen);
        for y in 0..h {
            assert_eq!(row(y), row(h - 1 - y), "mirror symmetry");
            let i = (y * 16) as usize;
            let j = ((h - 1 - y) * 16) as usize;
            assert!((m.temp[i] - m.temp[j]).abs() < 1e-9);
        }
    }
}

#[test]
fn row_means_increase_toward_equator_with_noise() {
    for seed in [1, 2, 3] {
        let (w, h) = (64u32, 48u32);
        let m = gen(w, h, seed);
        let mean = |y: u32| {
            (0..w).map(|x| m.temp[(y * w + x) as usize]).sum::<f64>() / w as f64
        };
        for y in 1..=(h - 1) / 2 {
            assert!(mean(y) > mean(y - 1) - 1.5, "seed {} y {}", seed, y);
        }
        assert!(mean(h / 2) > mean(0) + 30.0);
        // Row-mode zone is non-decreasing from the seam to the equator.
        let mut prev = 0;
        for y in 0..=(h - 1) / 2 {
            let mut cnt = [0usize; 5];
            for x in 0..w {
                cnt[m.zone[(y * w + x) as usize] as usize] += 1;
            }
            let mode = (0..5).max_by_key(|&z| (cnt[z], z)).unwrap();
            assert!(mode >= prev, "seed {} y {}", seed, y);
            prev = mode;
        }
    }
}

/// (max, mean) absolute difference over neighbour pairs. `seam` selects the wrap pairs.
fn diffs(v: &[f64], w: usize, h: usize, vertical: bool, seam: bool) -> (f64, f64) {
    let mut mx = 0.0f64;
    let mut sum = 0.0;
    let mut n = 0usize;
    let (xs, ys) = if vertical { (w, h) } else { (w, h) };
    let _ = (xs, ys);
    for y in 0..h {
        for x in 0..w {
            let (x2, y2, is_seam) = if vertical {
                ((x), (y + 1) % h, y + 1 == h)
            } else {
                ((x + 1) % w, y, x + 1 == w)
            };
            if is_seam != seam || (vertical && h < 2) || (!vertical && w < 2) {
                continue;
            }
            let d = (v[y * w + x] - v[y2 * w + x2]).abs();
            mx = mx.max(d);
            sum += d;
            n += 1;
        }
    }
    (mx, if n == 0 { 0.0 } else { sum / n as f64 })
}

fn seam_ok(v: &[f64], w: usize, h: usize) -> bool {
    for vertical in [true, false] {
        let (imax, imean) = diffs(v, w, h, vertical, false);
        let (smax, smean) = diffs(v, w, h, vertical, true);
        if smax > imax + 1e-12 || smean > 1.5 * imean + 1e-12 {
            return false;
        }
    }
    true
}

#[test]
fn no_seam_in_temperature_or_precipitation() {
    for (w, h) in [(64u32, 48u32), (100, 37), (17, 9), (200, 120), (5, 40)] {
        for seed in [1i64, 42, -9] {
            let m = gen(w, h, seed);
            assert!(seam_ok(&m.temp, w as usize, h as usize), "temp {}x{} seed {}", w, h, seed);
            assert!(seam_ok(&m.precip, w as usize, h as usize), "precip {}x{} seed {}", w, h, seed);
        }
    }
}

#[test]
fn seam_check_has_teeth() {
    // A plain linear north-south gradient has a hard jump at the y-seam and must be rejected.
    let (w, h) = (20usize, 20usize);
    let v: Vec<f64> = (0..w * h).map(|i| (i / w) as f64).collect();
    assert!(!seam_ok(&v, w, h));
    let hx: Vec<f64> = (0..w * h).map(|i| (i % w) as f64).collect();
    assert!(!seam_ok(&hx, w, h));
}

#[test]
fn small_and_odd_worlds() {
    for (w, h) in [(1u32, 1u32), (1, 7), (7, 1), (2, 2), (3, 5), (4096, 1), (1, 4096)] {
        let m = gen(w, h, 5);
        assert_eq!(m.biome.len(), (w * h) as usize);
        assert!(m.temp.iter().chain(m.precip.iter()).all(|v| v.is_finite()));
        assert!(m.precip.iter().all(|&p| p >= 0.0));
        let _ = m.to_ascii();
    }
    // A zero precip_mean must not produce NaN.
    let mut c = cfg(8, 8, 1);
    c.climate.precip_mean = 0.0;
    assert!(ClimateMap::generate(&c).precip.iter().all(|&p| p == 0.0));
    // Equal pole/equator temperature is valid.
    let mut c = cfg(8, 8, 1);
    c.climate.pole_temp = 10.0;
    c.climate.equator_temp = 10.0;
    assert!(ClimateMap::generate(&c).temp.iter().all(|t| t.is_finite()));
}

#[test]
fn ascii_and_json_export() {
    let (w, h) = (64u32, 48u32);
    let m = gen(w, h, 42);
    let a = m.to_ascii();
    let lines: Vec<&str> = a.lines().collect();
    assert_eq!(lines.len(), h as usize + 1);
    for l in &lines[..h as usize] {
        assert_eq!(l.chars().count(), w as usize);
    }
    assert!(lines[0].chars().all(|c| c == 'P' || c == 'T'));
    assert!(lines[h as usize / 2].chars().any(|c| c == 'R'));
    assert!(lines[h as usize].starts_with("legend:"));
    let v = json::parse(&m.to_json()).expect("valid json");
    for k in ["biome", "zone", "temp", "precip"] {
        match v.get(k) {
            Some(json::Value::Array(a)) => assert_eq!(a.len(), (w * h) as usize),
            _ => panic!("missing {}", k),
        }
    }
}

#[test]
fn documentation_explains_seam_compromise() {
    let d = include_str!("../../../docs/CLIMATE.md");
    assert!(d.contains("seam"));
    assert!(d.contains("compromise"));
}

//! TASK-010 acceptance tests: spatial index vs brute force, mutations, seams, order, determinism.
use evosim_core::config::Config;
use evosim_core::grid::{Grid, Pos};
use evosim_core::organism::{Id, Kind};
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;
use evosim_core::spatial::{Hit, SpatialError, SpatialIndex};
use std::collections::HashSet;

type Model = Vec<(Id, Kind, Pos)>;

fn axis(a: i32, b: i32, n: u32) -> u32 {
    let d = (a - b).unsigned_abs();
    d.min(n - d)
}

/// Independent brute force with its own toroidal distance.
fn brute(model: &Model, w: u32, h: u32, c: Pos, r: i64, kind: Option<Kind>) -> Vec<Hit> {
    let mut v: Vec<Hit> = model
        .iter()
        .filter(|(_, k, _)| kind.map_or(true, |kk| kk == *k))
        .map(|&(id, k, p)| Hit { id, kind: k, pos: p, dist: axis(c.x, p.x, w).max(axis(c.y, p.y, h)) })
        .filter(|hit| (hit.dist as i64) <= r)
        .collect();
    v.sort_by_key(|h| (h.dist, h.kind.index(), h.id));
    v
}

fn rnd_pos(rng: &mut Rng, w: u32, h: u32) -> Pos {
    Pos { x: rng.below(w as u64) as i32, y: rng.below(h as u64) as i32 }
}

fn rnd_kind(rng: &mut Rng) -> Kind {
    Kind::ALL[rng.below(3) as usize]
}

fn rnd_kind_opt(rng: &mut Rng) -> Option<Kind> {
    let i = rng.below(4) as usize;
    if i == 3 { None } else { Some(Kind::ALL[i]) }
}

fn no_dups(v: &[Hit]) {
    let s: HashSet<Id> = v.iter().map(|h| h.id).collect();
    assert_eq!(s.len(), v.len(), "duplicate ids in result");
}

const SIZES: [(u32, u32); 9] = [(1, 1), (1, 7), (6, 1), (2, 2), (3, 5), (7, 7), (10, 4), (40, 30), (16, 16)];

#[test]
fn randomized_vs_brute_force_at_least_1000_queries() {
    let mut rng = Rng::new(12345);
    let mut queries = 0;
    for &(w, h) in SIZES.iter() {
        let grid = Grid::new(w, h).unwrap();
        let mut idx = SpatialIndex::new(grid);
        let mut model: Model = Vec::new();
        let n = rng.below(60) as u64 + 5;
        for id in 1..=n {
            let (k, p) = (rnd_kind(&mut rng), rnd_pos(&mut rng, w, h));
            idx.insert(id, k, p).unwrap();
            model.push((id, k, p));
        }
        let maxr = 2 * w.max(h) as i64 + 3;
        for _ in 0..400 {
            let c = rnd_pos(&mut rng, w, h);
            let r = rng.below(maxr as u64 + 1) as i64;
            let k = rnd_kind_opt(&mut rng);
            let got = idx.query(c, r, k);
            no_dups(&got);
            assert_eq!(got, brute(&model, w, h, c, r, k), "{}x{} c={:?} r={} k={:?}", w, h, c, r, k);
            assert_eq!(idx.count(c, r, k), got.len());
            assert_eq!(idx.nearest(c, r, k), got.first().copied());
            queries += 1;
        }
    }
    assert!(queries >= 1000, "only {} queries", queries);
}

#[test]
fn randomized_mutations_vs_model() {
    let mut rng = Rng::new(777);
    for &(w, h) in SIZES.iter() {
        let grid = Grid::new(w, h).unwrap();
        let mut idx = SpatialIndex::new(grid);
        let mut model: Model = Vec::new();
        let mut next: Id = 1;
        for step in 0..600 {
            match rng.below(4) {
                0 => {
                    // ids may also be inserted out of order
                    let id = if rng.below(3) == 0 { next + rng.below(50) } else { next };
                    next = next.max(id) + 1;
                    let (k, p) = (rnd_kind(&mut rng), rnd_pos(&mut rng, w, h));
                    idx.insert(id, k, p).unwrap();
                    model.push((id, k, p));
                }
                1 if !model.is_empty() => {
                    let i = rng.below(model.len() as u64) as usize;
                    // step across the seam: wrapped neighbour or random cell
                    let np = if rng.below(2) == 0 {
                        Grid::new(w, h).unwrap().offset(model[i].2, rng.range_i64(-2, 2), rng.range_i64(-2, 2))
                    } else {
                        rnd_pos(&mut rng, w, h)
                    };
                    let old = model[i].2;
                    idx.move_to(model[i].0, np).unwrap();
                    model[i].2 = np;
                    if old != np {
                        let q = idx.query(old, 0, Some(model[i].1));
                        assert!(!q.iter().any(|x| x.id == model[i].0), "moved id still at old cell");
                    }
                }
                2 if !model.is_empty() => {
                    let i = rng.below(model.len() as u64) as usize;
                    let (id, _, p) = model.remove(i);
                    idx.remove(id).unwrap();
                    assert!(!idx.query(p, 2 * w.max(h) as i64, None).iter().any(|x| x.id == id), "removed id returned");
                    assert!(!idx.contains(id));
                }
                _ => {}
            }
            if step % 3 == 0 {
                let c = rnd_pos(&mut rng, w, h);
                let r = rng.below(2 * w.max(h) as u64 + 4) as i64;
                let k = rnd_kind_opt(&mut rng);
                let got = idx.query(c, r, k);
                no_dups(&got);
                assert_eq!(got, brute(&model, w, h, c, r, k));
            }
            assert_eq!(idx.len(), model.len());
        }
    }
}

#[test]
fn moved_and_removed_never_returned_from_old_place() {
    let mut idx = SpatialIndex::new(Grid::new(10, 10).unwrap());
    idx.insert(1, Kind::Herbivore, Pos { x: 2, y: 2 }).unwrap();
    idx.insert(2, Kind::Herbivore, Pos { x: 2, y: 2 }).unwrap();
    idx.move_to(1, Pos { x: 8, y: 8 }).unwrap();
    let at_old: Vec<Id> = idx.query(Pos { x: 2, y: 2 }, 0, None).iter().map(|h| h.id).collect();
    assert_eq!(at_old, vec![2]);
    assert_eq!(idx.query(Pos { x: 8, y: 8 }, 0, None)[0].id, 1);
    idx.remove(2).unwrap();
    assert!(idx.query(Pos { x: 2, y: 2 }, 0, None).is_empty());
    assert_eq!(idx.query(Pos { x: 0, y: 0 }, 100, None).len(), 1);
}

#[test]
fn seams_wrap_in_both_axes() {
    let mut idx = SpatialIndex::new(Grid::new(10, 8).unwrap());
    idx.insert(1, Kind::Plant, Pos { x: 9, y: 0 }).unwrap();
    idx.insert(2, Kind::Plant, Pos { x: 0, y: 7 }).unwrap();
    idx.insert(3, Kind::Plant, Pos { x: 9, y: 7 }).unwrap();
    let h = idx.query(Pos { x: 0, y: 0 }, 1, None);
    assert_eq!(h.iter().map(|x| (x.id, x.dist)).collect::<Vec<_>>(), vec![(1, 1), (2, 1), (3, 1)]);
    let h = idx.query(Pos { x: 9, y: 7 }, 0, None);
    assert_eq!(h.len(), 1);
    assert_eq!(h[0].id, 3);
}

#[test]
fn errors_leave_state_unchanged() {
    let mut idx = SpatialIndex::new(Grid::new(5, 5).unwrap());
    idx.insert(1, Kind::Plant, Pos { x: 1, y: 1 }).unwrap();
    assert_eq!(idx.insert(1, Kind::Plant, Pos { x: 2, y: 2 }), Err(SpatialError::Duplicate(1)));
    assert_eq!(idx.insert(2, Kind::Plant, Pos { x: 5, y: 0 }), Err(SpatialError::OutOfGrid(Pos { x: 5, y: 0 })));
    assert_eq!(idx.insert(2, Kind::Plant, Pos { x: -1, y: 0 }), Err(SpatialError::OutOfGrid(Pos { x: -1, y: 0 })));
    assert_eq!(idx.move_to(9, Pos { x: 0, y: 0 }), Err(SpatialError::Unknown(9)));
    assert_eq!(idx.move_to(1, Pos { x: 0, y: 5 }), Err(SpatialError::OutOfGrid(Pos { x: 0, y: 5 })));
    assert_eq!(idx.remove(9), Err(SpatialError::Unknown(9)));
    assert_eq!(idx.len(), 1);
    assert_eq!(idx.get(1), Some((Kind::Plant, Pos { x: 1, y: 1 })));
    assert!(idx.query(Pos { x: 1, y: 1 }, -1, None).is_empty());
    assert!(idx.query(Pos { x: 9, y: 9 }, 3, None).is_empty());
}

#[test]
fn order_is_dist_kind_id_and_independent_of_insertion_order() {
    let items: Model = vec![
        (5, Kind::Carnivore, Pos { x: 3, y: 3 }),
        (2, Kind::Herbivore, Pos { x: 3, y: 3 }),
        (9, Kind::Plant, Pos { x: 3, y: 3 }),
        (1, Kind::Plant, Pos { x: 4, y: 3 }),
        (7, Kind::Plant, Pos { x: 3, y: 3 }),
        (3, Kind::Herbivore, Pos { x: 0, y: 0 }),
    ];
    let build = |order: &[usize]| {
        let mut idx = SpatialIndex::new(Grid::new(8, 8).unwrap());
        for &i in order {
            let (id, k, p) = items[i];
            idx.insert(id, k, p).unwrap();
        }
        idx.query(Pos { x: 3, y: 3 }, 5, None)
    };
    let a = build(&[0, 1, 2, 3, 4, 5]);
    let b = build(&[5, 4, 3, 2, 1, 0]);
    let c = build(&[2, 0, 5, 1, 4, 3]);
    assert_eq!(a, b);
    assert_eq!(a, c);
    let ids: Vec<Id> = a.iter().map(|h| h.id).collect();
    assert_eq!(ids, vec![7, 9, 2, 5, 1, 3]);
}

#[test]
fn rebuild_from_simulation_matches_brute_force_and_skips_dead() {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = 30;
    c.world.height = 20;
    c.initial.plants = 120;
    c.initial.herbivores = 40;
    c.initial.carnivores = 15;
    let s = Simulation::new(&c).unwrap();
    let grid = Grid::new(30, 20).unwrap();
    let mut idx = SpatialIndex::new(grid);
    idx.rebuild(&s.organisms);
    let model: Model = Kind::ALL.iter().flat_map(|&k| s.organisms.vec(k).iter().map(|o| (o.id, o.kind, o.pos))).collect();
    assert_eq!(idx.len(), 175);
    let mut rng = Rng::new(9);
    for _ in 0..200 {
        let (cc, r, k) = (rnd_pos(&mut rng, 30, 20), rng.below(40) as i64, rnd_kind_opt(&mut rng));
        assert_eq!(idx.query(cc, r, k), brute(&model, 30, 20, cc, r, k));
    }
    // rebuilding twice is idempotent
    let before = idx.query(Pos { x: 0, y: 0 }, 50, None);
    idx.rebuild(&s.organisms);
    assert_eq!(idx.query(Pos { x: 0, y: 0 }, 50, None), before);
}

#[test]
fn query_into_reuses_buffer() {
    let mut idx = SpatialIndex::new(Grid::new(5, 5).unwrap());
    idx.insert(1, Kind::Plant, Pos { x: 0, y: 0 }).unwrap();
    let mut buf = vec![Hit { id: 99, kind: Kind::Plant, pos: Pos { x: 0, y: 0 }, dist: 7 }];
    idx.query_into(Pos { x: 0, y: 0 }, 1, None, &mut buf);
    assert_eq!(buf.len(), 1);
    assert_eq!(buf[0].id, 1);
}

//! Prey refuge (TASK-027, ADR-0031): static, deterministic, independent of population counts.
use evosim_core::config::Config;
use evosim_core::world::World;

fn cfg(seed: i64, frac: f64) -> Config {
    let mut c = Config::default();
    c.seed = seed;
    c.climate.cover_fraction = frac;
    c
}

#[test]
fn cover_is_deterministic_and_follows_fraction() {
    let a = World::new(&cfg(7, 0.3)).unwrap();
    let b = World::new(&cfg(7, 0.3)).unwrap();
    let n = a.grid.cell_count();
    let mut cnt = 0;
    for i in 0..n {
        let p = a.grid.pos_of(i);
        assert_eq!(a.has_cover(p), b.has_cover(p));
        cnt += a.has_cover(p) as usize;
    }
    let f = cnt as f64 / n as f64;
    assert!(f > 0.1 && f < 0.5, "fraction {f}");
}

#[test]
fn cover_extremes() {
    let none = World::new(&cfg(7, 0.0)).unwrap();
    let all = World::new(&cfg(7, 1.0)).unwrap();
    for i in 0..none.grid.cell_count() {
        assert!(!none.has_cover(none.grid.pos_of(i)));
        assert!(all.has_cover(all.grid.pos_of(i)));
    }
}

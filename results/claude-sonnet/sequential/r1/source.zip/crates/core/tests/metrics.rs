//! TASK-020: metrics recorder (ADR-0024) checked against a tiny hand-computed world.
use evosim_core::config::Config;
use evosim_core::json::{parse, Value};
use evosim_core::metrics::{stats, MetricsRecorder, TRAIT_NAMES};
use evosim_core::organism::{DeathCause, Kind};
use evosim_core::sim::Simulation;

fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 3;
    c.world.width = 3;
    c.world.height = 1;
    c.initial.plants = 0;
    c.initial.herbivores = 3;
    c.initial.carnivores = 0;
    c.genetics.founder_variation = 0.0;
    c
}

fn f(v: &Value, path: &[&str]) -> Value {
    let mut c = v;
    for k in path {
        c = c.get(k).unwrap_or_else(|| panic!("missing {path:?}"));
    }
    c.clone()
}

fn num(v: &Value, path: &[&str]) -> f64 {
    match f(v, path) {
        Value::Int(i) => i as f64,
        Value::Float(x) => x,
        o => panic!("{path:?} is {}", o.type_name()),
    }
}

#[test]
fn stats_hand_values() {
    let s = stats(&[1.0, 3.0]).unwrap();
    assert_eq!((s.mean, s.sd, s.min, s.max), (2.0, 1.0, 1.0, 3.0));
    let s = stats(&[5.0]).unwrap();
    assert_eq!((s.mean, s.sd), (5.0, 0.0));
    assert!(stats(&[]).is_none());
}

#[test]
fn hand_verified_small_world() {
    let mut sim = Simulation::new(&cfg()).unwrap();
    assert_eq!(sim.organisms.count(Kind::Herbivore), 3);
    let ids: Vec<_> = sim.organisms.herbivores.iter().map(|o| o.id).collect();
    // Known generations 0, 2, 4 and speeds 1, 3, 5 (third one dies below).
    for (i, o) in sim.organisms.herbivores.iter_mut().enumerate() {
        o.generation = 2 * i as u32;
        o.traits.speed = 1.0 + 2.0 * i as f64;
        o.set_energy(10.0 * (i as f64 + 1.0));
        o.age = 4 * i as u32;
    }
    let mut rec = MetricsRecorder::new();
    rec.record(&sim);
    // Sample 1: all alive; generations {0,2,4}: max 4, mean 2; speed {1,3,5}: mean 3, sd sqrt(8/3).
    let s1 = &rec.samples()[0];
    assert_eq!(num(s1, &["herbivores", "population"]), 3.0);
    assert_eq!(num(s1, &["herbivores", "generation_max"]), 4.0);
    assert_eq!(num(s1, &["herbivores", "generation_mean"]), 2.0);
    assert_eq!(num(s1, &["herbivores", "mean_energy"]), 20.0);
    assert_eq!(num(s1, &["herbivores", "mean_age"]), 4.0);
    assert_eq!(num(s1, &["herbivores", "traits", "speed", "mean"]), 3.0);
    assert!((num(s1, &["herbivores", "traits", "speed", "sd"]) - (8.0f64 / 3.0).sqrt()).abs() < 1e-12);
    assert_eq!(num(s1, &["herbivores", "traits", "speed", "min"]), 1.0);
    assert_eq!(num(s1, &["herbivores", "traits", "speed", "max"]), 5.0);
    assert_eq!(num(s1, &["herbivores", "births"]), 0.0);
    assert_eq!(num(s1, &["herbivores", "deaths"]), 0.0);
    assert_eq!(num(s1, &["herbivores", "species"]), sim.living_species(Kind::Herbivore) as f64);
    // Empty kinds: counts 0, everything else null.
    assert_eq!(num(s1, &["plants", "population"]), 0.0);
    assert_eq!(f(s1, &["plants", "generation_max"]), Value::Null);
    assert_eq!(f(s1, &["carnivores", "traits", "speed", "mean"]), Value::Null);
    assert_eq!(f(s1, &["carnivores", "traits", "vision", "sd"]), Value::Null);

    // Kill the generation-4 one (starvation) and the generation-0 one (injury) before the Deaths phase.
    assert!(sim.organisms.mark_dead(ids[2], DeathCause::Starvation, sim.tick));
    assert!(sim.organisms.mark_dead(ids[0], DeathCause::Injury, sim.tick));
    let t = sim.tick;
    let removed = sim.organisms.resolve_deaths(t);
    assert_eq!(removed.len(), 2);
    rec.record(&sim);
    let s2 = &rec.samples()[1];
    assert_eq!(num(s2, &["herbivores", "population"]), 1.0);
    assert_eq!(num(s2, &["herbivores", "deaths"]), 2.0);
    assert_eq!(num(s2, &["herbivores", "deaths_interval"]), 2.0);
    assert_eq!(num(s2, &["herbivores", "deaths_by_cause", "starvation"]), 1.0);
    assert_eq!(num(s2, &["herbivores", "deaths_by_cause", "injury"]), 1.0);
    assert_eq!(num(s2, &["herbivores", "deaths_by_cause", "old_age"]), 0.0);
    assert_eq!(num(s2, &["herbivores", "deaths_by_cause_interval", "injury"]), 1.0);
    assert_eq!(num(s2, &["herbivores", "generation_max"]), 2.0);
    assert_eq!(num(s2, &["herbivores", "generation_mean"]), 2.0);
    assert_eq!(num(s2, &["herbivores", "traits", "speed", "mean"]), 3.0);
    assert_eq!(num(s2, &["herbivores", "traits", "speed", "sd"]), 0.0);

    // Third sample without events: cumulative stays, interval is 0.
    rec.record(&sim);
    let s3 = &rec.samples()[2];
    assert_eq!(num(s3, &["herbivores", "deaths"]), 2.0);
    assert_eq!(num(s3, &["herbivores", "deaths_interval"]), 0.0);
    assert_eq!(num(s3, &["herbivores", "deaths_by_cause_interval", "starvation"]), 0.0);

    // Last herbivore dies of old age: extinct kind gives nulls again.
    let last = sim.organisms.herbivores[0].id;
    sim.organisms.mark_dead(last, DeathCause::OldAge, t);
    sim.organisms.resolve_deaths(t);
    rec.record(&sim);
    let s4 = &rec.samples()[3];
    assert_eq!(num(s4, &["herbivores", "population"]), 0.0);
    assert_eq!(f(s4, &["herbivores", "generation_mean"]), Value::Null);
    assert_eq!(f(s4, &["herbivores", "mean_energy"]), Value::Null);
    assert_eq!(num(s4, &["herbivores", "deaths_by_cause_interval", "old_age"]), 1.0);
}

#[test]
fn every_trait_present_and_document_roundtrips() {
    let mut c = cfg();
    c.initial.plants = 5;
    c.initial.herbivores = 4;
    c.initial.carnivores = 2;
    c.world.width = 10;
    c.world.height = 10;
    let mut sim = Simulation::new(&c).unwrap();
    let mut rec = MetricsRecorder::new();
    for _ in 0..30 {
        rec.record(&sim);
        sim.step();
    }
    let doc = rec.to_json(c.seed, 0, 30, 1);
    let back = parse(&doc.to_pretty()).unwrap();
    assert_eq!(back, doc);
    assert!(!doc.to_compact().contains("NaN") && !doc.to_compact().contains("inf"));
    let samples = match f(&back, &["samples"]) {
        Value::Array(a) => a,
        _ => panic!(),
    };
    assert_eq!(samples.len(), 30);
    let first = &samples[0];
    for k in ["plants", "herbivores", "carnivores"] {
        for t in TRAIT_NAMES {
            for s in ["mean", "sd", "min", "max"] {
                f(first, &[k, "traits", t, s]);
            }
        }
        assert_eq!(num(first, &[k, "births_interval"]), 0.0);
    }
    // Ledger at every sample: initial + births - deaths = population (cumulative counters).
    let st = &sim.organisms.stats;
    for (i, s) in samples.iter().enumerate() {
        assert_eq!(num(s, &["tick"]), i as f64);
    }
    let last = samples.last().unwrap();
    for k in Kind::ALL {
        let key = evosim_core::metrics::kind_key(k);
        let pop = num(last, &[key, "population"]) as u64;
        assert_eq!(pop, st.founded[k.index()] + num(last, &[key, "births"]) as u64 - num(last, &[key, "deaths"]) as u64, "ledger {key}");
    }
}

#[test]
fn recording_does_not_change_state_hash() {
    let mut c = Config::default();
    c.world.width = 24;
    c.world.height = 16;
    c.initial.plants = 80;
    c.initial.herbivores = 20;
    c.initial.carnivores = 5;
    let mut a = Simulation::new(&c).unwrap();
    let mut b = Simulation::new(&c).unwrap();
    let mut rec = MetricsRecorder::new();
    for _ in 0..200 {
        rec.record(&b);
        a.step();
        b.step();
    }
    rec.record(&b);
    assert_eq!(a.state_hash(), b.state_hash());
    assert_eq!(a.digest(), b.digest());
}

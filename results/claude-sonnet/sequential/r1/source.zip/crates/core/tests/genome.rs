//! TASK-009 acceptance tests: genome, traits mapping, copy/crossover, mutation, distance.
use evosim_core::config::Config;
use evosim_core::genome::*;
use evosim_core::grid::{Grid, Pos};
use evosim_core::organism::*;
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;

fn rand_genome(rng: &mut Rng) -> Genome {
    let mut a = [[0.0f32; 2]; N_GENES];
    for l in a.iter_mut() {
        l[0] = rng.next_f32();
        l[1] = rng.next_f32();
    }
    Genome::from_alleles(a)
}

fn flat(v: f32) -> Genome {
    Genome::from_alleles([[v; 2]; N_GENES])
}

fn in_range(t: &Traits, k: Kind) -> bool {
    let r = Traits::range(k);
    let ok = |v: f64, g: Range| v >= g.lo && v <= g.hi;
    ok(t.speed, r.speed)
        && ok(t.strength, r.strength)
        && ok(t.fertility, r.fertility)
        && ok(t.max_health, r.max_health)
        && ok(t.max_lifespan as f64, r.max_lifespan)
        && ok(t.max_energy, r.max_energy)
        && ok(t.metabolism, r.metabolism)
        && ok(t.vision, r.vision)
        && ok(t.aggression, r.aggression)
        && ok(t.risk_tolerance, r.risk_tolerance)
}

#[test]
fn every_organism_has_genome_and_traits_derive_from_it() {
    for name in ["default", "lush", "harsh", "predator-rich"] {
        let mut c = Config::preset(name).unwrap();
        c.initial.plants = 50;
        c.initial.herbivores = 30;
        c.initial.carnivores = 20;
        let g = Grid::new(c.world.width, c.world.height).unwrap();
        let o = Organisms::populate(&c, &g);
        for k in Kind::ALL {
            assert!(!o.vec(k).is_empty());
            for org in o.vec(k) {
                assert_eq!(org.traits, org.genome().traits(k, o.baseline(k)), "{name}");
                assert!(in_range(&org.traits, k));
            }
        }
    }
}

#[test]
fn mapping_in_range_deterministic_and_extreme() {
    let c = Config::default();
    let mut rng = Rng::new(1);
    for k in Kind::ALL {
        let b = Traits::baseline(k, &c);
        let mut gs: Vec<Genome> = (0..10_000).map(|_| rand_genome(&mut rng)).collect();
        gs.push(flat(0.0));
        gs.push(flat(1.0));
        gs.push(flat(0.5));
        let mut nan = [[0.3f32; 2]; N_GENES];
        nan[0][0] = f32::NAN;
        gs.push(Genome::from_alleles(nan));
        for g in &gs {
            let t = g.traits(k, &b);
            assert_eq!(t, g.traits(k, &b));
            assert!(in_range(&t, k), "{k:?} {t:?}");
        }
    }
    // baseline sits at g = 0.5
    let b = Traits::baseline(Kind::Herbivore, &c);
    assert_eq!(flat(0.5).traits(Kind::Herbivore, &b).max_energy, b.max_energy);
    assert!(flat(1.0).traits(Kind::Herbivore, &b).speed > flat(0.0).traits(Kind::Herbivore, &b).speed);
}

#[test]
fn from_traits_round_trip_and_founder_zero_variation() {
    let c = Config::default();
    for k in Kind::ALL {
        let b = Traits::baseline(k, &c);
        let g = Genome::from_traits(k, &b, &b);
        let t = g.traits(k, &b);
        assert!((t.max_energy - b.max_energy).abs() < 1e-3 * b.max_energy.max(1.0));
        assert!((t.aggression - b.aggression).abs() < 1e-6);
        let mut rng = Rng::new(3);
        let before = rng.state();
        let f = Genome::founder(k, &b, &mut rng, 0.0);
        assert_eq!(rng.state(), before);
        assert_eq!(f, g);
        // a scaled trait round-trips
        let mut t2 = b;
        t2.max_energy = b.max_energy * 2.0;
        let t3 = Genome::from_traits(k, &b, &t2).traits(k, &b);
        assert!((t3.max_energy - t2.max_energy).abs() < 1e-3 * t2.max_energy);
    }
    for s in [0.25, 0.5, 1.0, 2.0, 4.0] {
        assert!((scale_factor(scale_factor_inverse(s)) - s).abs() < 1e-12);
    }
}

#[test]
fn copy_with_rate_zero_is_exact() {
    let mut rng = Rng::new(5);
    let p = rand_genome(&mut rng);
    let before = rng.state();
    let c = Genome::child_of_one(&p, &Mutation { rate: 0.0, sigma: 0.5 }, &mut rng);
    assert_eq!(c, p);
    assert_eq!(rng.state(), before, "rate 0 must not draw");
}

#[test]
fn crossover_only_parental_material() {
    let mut rng = Rng::new(6);
    let a = rand_genome(&mut rng);
    let b = rand_genome(&mut rng);
    for rate in [0.0, 0.5, 1.0] {
        for _ in 0..2000 {
            let c = Genome::child_of_two(&a, &b, rate, &Mutation { rate: 0.0, sigma: 0.3 }, &mut rng);
            for i in 0..N_GENES {
                assert!(a.alleles()[i].contains(&c.alleles()[i][0]));
                assert!(b.alleles()[i].contains(&c.alleles()[i][1]));
            }
        }
    }
}

#[test]
fn crossover_rate_controls_strand_switching() {
    // parent a has distinct strands: slot0 all 0.1, slot1 all 0.9
    let mut al = [[0.0f32; 2]; N_GENES];
    for l in al.iter_mut() {
        *l = [0.1, 0.9];
    }
    let a = Genome::from_alleles(al);
    let mut rng = Rng::new(7);
    let (mut seen0, mut seen1, mut mixed) = (false, false, false);
    for _ in 0..500 {
        let c = Genome::child_of_two(&a, &a, 0.0, &Mutation::NONE, &mut rng);
        let s: Vec<f32> = c.alleles().iter().map(|l| l[0]).collect();
        assert!(s.iter().all(|&v| v == s[0]), "rate 0 keeps a whole strand");
        if s[0] == 0.1 { seen0 = true } else { seen1 = true }
    }
    assert!(seen0 && seen1);
    for _ in 0..500 {
        let c = Genome::child_of_two(&a, &a, 0.5, &Mutation::NONE, &mut rng);
        let s: Vec<f32> = c.alleles().iter().map(|l| l[0]).collect();
        if s.iter().any(|&v| v != s[0]) { mixed = true }
    }
    assert!(mixed, "rate 0.5 recombines");
    // rate 1 alternates strictly
    let c = Genome::child_of_two(&a, &a, 1.0, &Mutation::NONE, &mut rng);
    for i in 1..N_GENES {
        assert_ne!(c.alleles()[i][0], c.alleles()[i - 1][0]);
    }
}

#[test]
fn mutation_rate_zero_none_positive_some() {
    let mut rng = Rng::new(8);
    let a = rand_genome(&mut rng);
    let b = rand_genome(&mut rng);
    let parental = |c: &Genome| (0..N_GENES).all(|i| a.alleles()[i].contains(&c.alleles()[i][0]) && b.alleles()[i].contains(&c.alleles()[i][1]));
    let mut diff = 0usize;
    let mut changed_total = 0usize;
    for _ in 0..2000 {
        let c = Genome::child_of_two(&a, &b, 0.5, &Mutation { rate: 0.05, sigma: 0.1 }, &mut rng);
        if !parental(&c) {
            diff += 1;
        }
        // count changed alleles via a separate mutation of a copy
        let mut d = a;
        changed_total += d.mutate(&Mutation { rate: 0.05, sigma: 0.1 }, &mut rng);
    }
    assert!(diff > 0, "differences appear");
    let mean = changed_total as f64 / 2000.0;
    assert!(mean > 0.5 && mean < 1.5, "expected ~1.0 changed of 20 alleles, got {mean}");
    // rate 0 over many offspring: all parental
    for _ in 0..2000 {
        let c = Genome::child_of_two(&a, &b, 0.5, &Mutation { rate: 0.0, sigma: 0.1 }, &mut rng);
        assert!(parental(&c));
    }
}

#[test]
fn mutation_extremes_bounds_and_rng_use() {
    let mut rng = Rng::new(9);
    let g = rand_genome(&mut rng);
    let mut h = g;
    let st = rng.state();
    assert_eq!(h.mutate(&Mutation { rate: 1.0, sigma: 0.0 }, &mut rng), 0);
    assert_eq!(h, g);
    assert_eq!(rng.state(), st);
    let mut h = flat(0.5);
    assert_eq!(h.mutate(&Mutation { rate: 1.0, sigma: 0.2 }, &mut rng), 2 * N_GENES);
    // sigma 1: stay in [0,1]
    let mut h = rand_genome(&mut rng);
    for _ in 0..500 {
        h.mutate(&Mutation { rate: 1.0, sigma: 1.0 }, &mut rng);
        assert!(h.alleles().iter().flatten().all(|&a| (0.0..=1.0).contains(&a)));
    }
    // step std ~ sigma
    let sigma = 0.05;
    let (mut s, mut s2, mut n) = (0.0f64, 0.0f64, 0.0f64);
    for _ in 0..2000 {
        let mut h = flat(0.5);
        h.mutate(&Mutation { rate: 1.0, sigma }, &mut rng);
        for a in h.alleles().iter().flatten() {
            let d = *a as f64 - 0.5;
            s += d;
            s2 += d * d;
            n += 1.0;
        }
    }
    let var = s2 / n - (s / n) * (s / n);
    assert!((var.sqrt() - sigma).abs() < 0.005, "std {}", var.sqrt());
    // uses supplied generator: reproducible, seed-dependent, advances
    let p = rand_genome(&mut Rng::new(1));
    let m = Mutation { rate: 0.5, sigma: 0.1 };
    let (mut r1, mut r2, mut r3) = (Rng::new(11), Rng::new(11), Rng::new(12));
    let (c1, c2, c3) = (Genome::child_of_one(&p, &m, &mut r1), Genome::child_of_one(&p, &m, &mut r2), Genome::child_of_one(&p, &m, &mut r3));
    assert_eq!(c1, c2);
    assert_ne!(c1, c3);
    assert_ne!(r1.state(), Rng::new(11).state());
}

#[test]
fn distance_properties() {
    let mut rng = Rng::new(10);
    let g = rand_genome(&mut rng);
    assert_eq!(Genome::distance(&g, &g), 0.0);
    assert_eq!(Genome::trait_distance(&g, &g), 0.0);
    // swapping alleles within a locus is invisible
    let mut sw = *g.alleles();
    for l in sw.iter_mut() {
        l.swap(0, 1);
    }
    assert_eq!(Genome::distance(&g, &Genome::from_alleles(sw)), 0.0);
    for _ in 0..1000 {
        let (a, b, c) = (rand_genome(&mut rng), rand_genome(&mut rng), rand_genome(&mut rng));
        let (ab, ba) = (Genome::distance(&a, &b), Genome::distance(&b, &a));
        assert_eq!(ab, ba);
        assert!((0.0..=1.0).contains(&ab));
        assert!(Genome::distance(&a, &c) <= ab + Genome::distance(&b, &c) + 1e-12);
        assert_eq!(Genome::trait_distance(&a, &b), Genome::trait_distance(&b, &a));
        assert!(Genome::trait_distance(&a, &c) <= Genome::trait_distance(&a, &b) + Genome::trait_distance(&b, &c) + 1e-12);
    }
    assert_eq!(Genome::distance(&flat(0.0), &flat(1.0)), 1.0);
    assert_eq!(Genome::trait_distance(&flat(0.0), &flat(1.0)), 1.0);
    // monotone in one gene
    let base = flat(0.2);
    let mut prev = 0.0;
    for step in 1..=8 {
        let mut a = *base.alleles();
        a[3] = [0.2 + 0.1 * step as f32; 2];
        let d = Genome::distance(&base, &Genome::from_alleles(a));
        assert!(d > prev);
        prev = d;
    }
    // stronger mutation -> farther on average
    let avg = |sigma: f64, rng: &mut Rng| {
        let mut s = 0.0;
        for _ in 0..300 {
            let c = Genome::child_of_one(&flat(0.5), &Mutation { rate: 1.0, sigma }, rng);
            s += Genome::distance(&flat(0.5), &c);
        }
        s / 300.0
    };
    assert!(avg(0.02, &mut rng) < avg(0.2, &mut rng));
}

#[test]
fn simulation_integration() {
    let mut c = Config::default();
    c.initial.plants = 10;
    c.initial.herbivores = 5;
    c.initial.carnivores = 3;
    let s1 = Simulation::new(&c).unwrap();
    let s2 = Simulation::new(&c).unwrap();
    assert_eq!(s1.digest(), s2.digest());
    // different founder variation -> different genomes -> different digest
    let mut c2 = c.clone();
    c2.genetics.founder_variation = 0.2;
    assert_ne!(Simulation::new(&c2).unwrap().digest(), s1.digest());
    // founder genomes vary (variation 0.05) but variation 0 makes them identical
    let mut c0 = c.clone();
    c0.genetics.founder_variation = 0.0;
    let g = Grid::new(c0.world.width, c0.world.height).unwrap();
    let o = Organisms::populate(&c0, &g);
    assert!(o.plants.windows(2).all(|w| w[0].genome() == w[1].genome()));
    let o = Organisms::populate(&c, &g);
    assert!(o.plants.windows(2).any(|w| w[0].genome() != w[1].genome()));
    // newborn gets traits from its genome
    let mut o = Organisms::populate(&c, &g);
    let parent = o.herbivores[0].id;
    let pg = *o.herbivores[0].genome();
    let mut rng = Rng::new(2);
    let child = Genome::child_of_one(&pg, &Mutation::for_kind(&c, Kind::Herbivore), &mut rng);
    assert!(o.queue_birth(NewBorn { kind: Kind::Herbivore, pos: Pos { x: 0, y: 0 }, parents: [parent, 0], genome: child, energy: 5.0 }));
    let born = o.resolve_births(1);
    let nb = o.get(Kind::Herbivore, born[0].0).unwrap();
    assert_eq!(nb.traits, child.traits(Kind::Herbivore, o.baseline(Kind::Herbivore)));
    assert_eq!(nb.parents, [parent, 0]);
    // digest sees alleles: tweak one allele of a newborn clone
    let mut o2 = Organisms::populate(&c, &g);
    let mut a = *pg.alleles();
    a[0][0] = if a[0][0] > 0.5 { 0.1 } else { 0.9 };
    o2.queue_birth(NewBorn { kind: Kind::Herbivore, pos: Pos { x: 0, y: 0 }, parents: [parent, 0], genome: Genome::from_alleles(a), energy: 5.0 });
    o2.resolve_births(1);
    let mut o3 = Organisms::populate(&c, &g);
    o3.queue_birth(NewBorn { kind: Kind::Herbivore, pos: Pos { x: 0, y: 0 }, parents: [parent, 0], genome: pg, energy: 5.0 });
    o3.resolve_births(1);
    let words = |o: &Organisms| {
        let mut v = Vec::new();
        o.state_words(&mut |w| v.push(w));
        v
    };
    assert_ne!(words(&o2), words(&o3));
}

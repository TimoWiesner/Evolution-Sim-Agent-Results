//! TASK-013: animal sensing and movement (ADR-0017, docs/MOVEMENT.md).
use evosim_core::config::Config;
use evosim_core::genome::{Genome, N_GENES};
use evosim_core::grid::{Grid, Pos};
use evosim_core::movement::{can_enter, move_cost, perceive, plan_path, step_allowance, vision_cells, SPRINT};
use evosim_core::organism::{cell_limit, Id, Kind, NewBorn};
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;

fn p(x: i32, y: i32) -> Pos {
    Pos { x, y }
}

fn cfg(w: u32, h: u32) -> Config {
    let mut c = Config::default();
    c.seed = 11;
    c.world.width = w;
    c.world.height = h;
    c.initial.plants = 1; // helper founder (parent for queue_birth), removed by `finish`
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.equator_temp = 20.0;
    c.climate.pole_temp = 20.0;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.seasonal_precip_amplitude = 0.0;
    c.climate.precip_mean = 1.0;
    c.climate.precip_latitude_variation = 0.0;
    c.climate.weather_noise = 0.0;
    c.climate.terrain_noise = 0.0;
    c.plants.maintenance = 0.0;
    c.plants.growth_rate = 0.0;
    c.plants.max_age = 1_000_000;
    c.plants.reproduction_threshold = 50.0;
    c.plants.reproduction_cost = 50.0;
    c.herbivores.max_age = 1_000_000;
    c.carnivores.max_age = 1_000_000;
    c.herbivores.move_cost = 0.5;
    c.herbivores.base_metabolism = 0.0; // TASK-014: herbivores pay running costs and eat; neutralised here
    c.herbivores.bite_size = 1e-6;
    c.herbivores.climate_cost = 0.0;
    c.carnivores.move_cost = 0.5;
    c
}

struct Setup {
    s: Simulation,
    founder: Id,
}

fn setup(c: &Config) -> Setup {
    let s = Simulation::new(c).unwrap();
    let founder = s.organisms.vec(Kind::Plant)[0].id;
    Setup { s, founder }
}

impl Setup {
    fn add(&mut self, kind: Kind, pos: Pos) -> Id {
        let g = Genome::from_alleles([[0.5f32; 2]; N_GENES]);
        assert!(self.s.organisms.queue_birth(NewBorn { kind, pos, parents: [self.founder, 0], genome: g, energy: 1e6 }));
        let r = self.s.organisms.resolve_births(0);
        let id = r.last().unwrap().0;
        if kind == Kind::Plant {
            self.s.organisms.get_mut(kind, id).unwrap().set_energy(10.0); // below the reproduction threshold
        }
        id
    }
    fn animal(&mut self, kind: Kind, pos: Pos, speed: f64, vision: f64) -> Id {
        let id = self.add(kind, pos);
        let o = self.s.organisms.get_mut(kind, id).unwrap();
        o.traits.speed = speed;
        o.traits.vision = vision;
        o.traits.metabolism = 1.0;
        o.traits.max_energy = 1000.0;
        o.set_energy(if kind == Kind::Herbivore { 800.0 } else { 1000.0 }); // herbivores below satiation (0.9 * max)
        id
    }
    fn finish(mut self) -> Simulation {
        let f = self.founder;
        self.s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != f);
        self.s.rebuild_index();
        self.s.check_index().unwrap();
        self.s
    }
}

fn pos_of(s: &Simulation, k: Kind, id: Id) -> Pos {
    s.organisms.get(k, id).unwrap().pos
}

fn axis(a: i32, b: i32, n: u32) -> u32 {
    let d = (a - b).unsigned_abs();
    d.min(n - d)
}

fn cheb(a: Pos, b: Pos, w: u32, h: u32) -> u32 {
    axis(a.x, b.x, w).max(axis(a.y, b.y, h))
}

#[test]
fn perceive_matches_bruteforce() {
    let mut rng = Rng::new(99);
    for &(w, h) in &[(1u32, 9u32), (7, 1), (5, 5), (12, 8), (20, 20)] {
        let mut st = setup(&cfg(w, h));
        let mut model: Vec<(Id, Kind, Pos)> = Vec::new();
        for _ in 0..40 {
            let k = Kind::ALL[rng.below(3) as usize];
            let pos = p(rng.below(w as u64) as i32, rng.below(h as u64) as i32);
            let id = if k == Kind::Plant { st.add(k, pos) } else { st.animal(k, pos, 1.0, 1.0 + rng.below(8) as f64) };
            model.push((id, k, pos));
        }
        let s = st.finish();
        for &(id, k, pos) in &model {
            let o = s.organisms.get(k, id).unwrap();
            let r = vision_cells(o);
            let got: Vec<(Id, u32)> = perceive(&s.spatial, &s.organisms, id).iter().map(|h| (h.id, h.dist)).collect();
            let mut want: Vec<(u32, usize, Id)> = model
                .iter()
                .filter(|&&(i, _, q)| i != id && (cheb(pos, q, w, h) as i64) <= r)
                .map(|&(i, kk, q)| (cheb(pos, q, w, h), kk.index(), i))
                .collect();
            want.sort();
            let want: Vec<(Id, u32)> = want.iter().map(|t| (t.2, t.0)).collect();
            assert_eq!(got, want, "world {}x{} organism {}", w, h, id);
        }
    }
}

#[test]
fn perceive_across_edge_exact() {
    let mut st = setup(&cfg(10, 10));
    let a = st.animal(Kind::Herbivore, p(0, 0), 1.0, 1.0);
    let right = st.add(Kind::Plant, p(9, 0)); // across the x seam, distance 1
    let diag = st.add(Kind::Plant, p(9, 9)); // across the corner, distance 1
    let top = st.add(Kind::Plant, p(0, 9)); // across the y seam
    let far = st.add(Kind::Plant, p(8, 0)); // distance 2: outside vision 1
    let s = st.finish();
    let seen: Vec<Id> = perceive(&s.spatial, &s.organisms, a).iter().map(|h| h.id).collect();
    assert!(seen.contains(&right) && seen.contains(&diag) && seen.contains(&top));
    assert!(!seen.contains(&far) && !seen.contains(&a));
    // dead organisms are not perceived even if the index still lists them
    let mut s = s;
    s.organisms.mark_dead(right, evosim_core::organism::DeathCause::Other, 0);
    let seen: Vec<Id> = perceive(&s.spatial, &s.organisms, a).iter().map(|h| h.id).collect();
    assert!(!seen.contains(&right));
}

#[test]
fn vision_follows_trait() {
    let mut st = setup(&cfg(30, 30));
    let short = st.animal(Kind::Herbivore, p(0, 0), 1.0, 2.0);
    let long = st.animal(Kind::Herbivore, p(1, 1), 1.0, 6.0);
    let plant = st.add(Kind::Plant, p(27, 0)); // wrapped distance 3 from short, 4 from long
    let s = st.finish();
    assert!(!perceive(&s.spatial, &s.organisms, short).iter().any(|h| h.id == plant));
    assert!(perceive(&s.spatial, &s.organisms, long).iter().any(|h| h.id == plant));
    // the trait derives from the genome: higher vision allele -> larger radius
    let c = cfg(30, 30);
    let mut s2 = Simulation::new(&c).unwrap();
    let f = s2.organisms.vec(Kind::Plant)[0].id;
    let mut ids = Vec::new();
    for a in [0.1f32, 0.9] {
        let mut al = [[0.5f32; 2]; N_GENES];
        al[evosim_core::genome::Gene::Vision.index()] = [a, a];
        s2.organisms.queue_birth(NewBorn { kind: Kind::Herbivore, pos: p(3, 3), parents: [f, 0], genome: Genome::from_alleles(al), energy: 10.0 });
        ids.push(s2.organisms.resolve_births(0)[0].0);
    }
    let v: Vec<i64> = ids.iter().map(|&i| vision_cells(s2.organisms.get(Kind::Herbivore, i).unwrap())).collect();
    assert!(v[0] < v[1], "{:?}", v);
}

#[test]
fn speed_limits_distance() {
    for speed in [0.5f64, 1.0, 1.5, 3.0] {
        let mut st = setup(&cfg(40, 40));
        let a = st.animal(Kind::Herbivore, p(5, 5), speed, 1.0);
        let mut s = st.finish();
        let mut total = 0u32;
        let mut prev = p(5, 5);
        for _ in 0..100 {
            s.step();
            let o = s.organisms.get(Kind::Herbivore, a).unwrap();
            let d = cheb(prev, o.pos, 40, 40);
            assert!(d as f64 <= speed.ceil(), "speed {} moved {}", speed, d);
            assert!((0.0..1.0).contains(&o.move_credit));
            total += d;
            prev = o.pos;
        }
        assert!(total as f64 <= speed * 100.0 + 1e-9, "speed {} total {}", speed, total);
        assert!(speed > 1.0 || total as f64 >= speed * 100.0 * 0.4, "speed {} total {} too small", speed, total);
    }
}

#[test]
fn step_allowance_credit() {
    let mut st = setup(&cfg(5, 5));
    let a = st.animal(Kind::Herbivore, p(0, 0), 0.4, 1.0);
    let mut s = st.finish();
    let o = s.organisms.get_mut(Kind::Herbivore, a).unwrap();
    let seq: Vec<u32> = (0..5).map(|_| step_allowance(o)).collect();
    assert_eq!(seq, vec![0, 0, 1, 0, 1]); // 0.4 0.8 1.2 0.6->? (0.2+0.4=0.6) 1.0
}

#[test]
fn moves_are_cell_to_cell_across_edges() {
    let mut st = setup(&cfg(6, 6));
    let a = st.animal(Kind::Carnivore, p(0, 0), 1.0, 1.0);
    let mut s = st.finish();
    let mut prev = p(0, 0);
    let mut crossed = false;
    for _ in 0..400 {
        s.step();
        let q = pos_of(&s, Kind::Carnivore, a);
        assert!(cheb(prev, q, 6, 6) <= 1);
        assert!(s.world.grid.contains(q));
        crossed |= (prev.x - q.x).abs() > 1 || (prev.y - q.y).abs() > 1;
        prev = q;
        s.check_index().unwrap();
    }
    assert!(crossed, "random walk never crossed an edge in 400 ticks");
}

#[test]
fn cost_scales() {
    let c = cfg(20, 20);
    let mut st = setup(&c);
    let a = st.animal(Kind::Herbivore, p(0, 0), 1.0, 1.0);
    let s = st.finish();
    let o = s.organisms.get(Kind::Herbivore, a).unwrap();
    let one = move_cost(&c, o, 1);
    assert_eq!(one, 0.5);
    assert_eq!(move_cost(&c, o, 0), 0.0);
    assert!(move_cost(&c, o, 2) > 2.0 * one); // faster costs more per cell
    assert!((move_cost(&c, o, 3) - 0.5 * 3.0 * (1.0 + SPRINT * 2.0)).abs() < 1e-12);
    assert!(move_cost(&c, o, 4) > move_cost(&c, o, 3));
    // actual energy drop equals the formula; a speed-3 animal chasing a distant plant pays more per cell
    let mut drops = Vec::new();
    for speed in [1.0f64, 3.0] {
        let mut st = setup(&c);
        let a = st.animal(Kind::Herbivore, p(0, 0), speed, 10.0);
        st.add(Kind::Plant, p(9, 0));
        let mut s = st.finish();
        let e0 = s.organisms.get(Kind::Herbivore, a).unwrap().energy();
        s.step();
        let o = s.organisms.get(Kind::Herbivore, a).unwrap();
        assert_eq!(o.pos, p(speed as i32, 0));
        let spent = e0 - o.energy();
        assert!((spent - move_cost(&c, o, speed as u32)).abs() < 1e-9);
        drops.push(spent / speed);
    }
    assert!(drops[1] > drops[0]);
}

#[test]
fn unaffordable_move_stays_and_energy_never_negative() {
    let c = cfg(10, 10);
    let mut st = setup(&c);
    let a = st.animal(Kind::Herbivore, p(2, 2), 1.0, 8.0);
    st.add(Kind::Plant, p(6, 2));
    let mut s = st.finish();
    s.organisms.get_mut(Kind::Herbivore, a).unwrap().set_energy(0.3); // < move cost 0.5
    s.run(1);
    let o = s.organisms.get(Kind::Herbivore, a);
    // it starves in the Deaths phase of that tick (energy not driven below 0 by moving); it did not move
    assert!(o.is_none() || (o.unwrap().pos == p(2, 2) && o.unwrap().energy() == 0.3));
    let mut st = setup(&c);
    let a = st.animal(Kind::Herbivore, p(2, 2), 3.0, 8.0);
    st.add(Kind::Plant, p(6, 2));
    let mut s = st.finish();
    s.organisms.get_mut(Kind::Herbivore, a).unwrap().set_energy(1.5);
    s.run(1);
    let o = s.organisms.get(Kind::Herbivore, a).unwrap();
    assert_eq!(o.pos, p(4, 2)); // 3 steps cost 1.95 > 1.5, 2 steps cost 1.1 <= 1.5
    assert!(o.energy() >= 0.0);
}

#[test]
fn shortest_way_across_edge() {
    let g = Grid::new(10, 10).unwrap();
    assert_eq!(plan_path(&g, p(9, 4), p(1, 4), 5), vec![p(0, 4), p(1, 4)]); // 2 steps via the seam, not 8
    assert_eq!(plan_path(&g, p(1, 4), p(9, 4), 5), vec![p(0, 4), p(9, 4)]);
    assert_eq!(plan_path(&g, p(3, 0), p(3, 8), 5), vec![p(3, 9), p(3, 8)]);
    assert_eq!(plan_path(&g, p(0, 0), p(9, 9), 3), vec![p(9, 9)]); // corner diagonal
    assert_eq!(plan_path(&g, p(8, 8), p(1, 1), 9), vec![p(9, 9), p(0, 0), p(1, 1)]);
    assert_eq!(plan_path(&g, p(0, 0), p(5, 0), 9).len(), 5); // exact tie goes positive, deterministic
    assert_eq!(plan_path(&g, p(0, 0), p(5, 0), 2), vec![p(1, 0), p(2, 0)]);
    // random check: path length == Chebyshev distance, steps adjacent
    let mut rng = Rng::new(3);
    for _ in 0..300 {
        let (a, b) = (p(rng.below(10) as i32, rng.below(10) as i32), p(rng.below(10) as i32, rng.below(10) as i32));
        let path = plan_path(&g, a, b, 100);
        assert_eq!(path.len() as u32, g.dist(a, b));
        let mut prev = a;
        for q in &path {
            assert_eq!(g.dist(prev, *q), 1);
            prev = *q;
        }
        assert_eq!(path.last().copied().unwrap_or(a), b);
    }
}

#[test]
fn animal_heads_for_target_via_wrap_and_stops_on_it() {
    let mut st = setup(&cfg(12, 12));
    let h = st.animal(Kind::Herbivore, p(11, 11), 1.0, 5.0);
    let plant = st.add(Kind::Plant, p(2, 1)); // 3 steps via the corner (dx +3, dy +2)
    let carn = st.animal(Kind::Carnivore, p(5, 11), 4.0, 6.0); // sees herbivore at wrapped distance 6? (5->11 = 6)
    let mut s = st.finish();
    let _ = carn;
    let target = s.organisms.get(Kind::Plant, plant).unwrap().pos;
    s.run(1);
    assert_eq!(pos_of(&s, Kind::Herbivore, h), p(0, 0));
    s.run(1);
    s.run(1);
    // TASK-014: herbivores stop once the plant is within feeding reach (distance 1)
    let stop = pos_of(&s, Kind::Herbivore, h);
    assert_eq!(stop, p(1, 1));
    assert_eq!(cheb(stop, target, 12, 12), 1);
    s.run(5); // within reach: stays
    assert_eq!(pos_of(&s, Kind::Herbivore, h), stop);
    s.check_index().unwrap();
}

#[test]
fn no_overshoot_with_high_speed() {
    let mut st = setup(&cfg(20, 20));
    let h = st.animal(Kind::Herbivore, p(0, 0), 8.0, 10.0);
    st.add(Kind::Plant, p(18, 19)); // distance 2 across the corner
    let mut s = st.finish();
    s.run(1);
    assert_eq!(pos_of(&s, Kind::Herbivore, h), p(18, 19));
}

#[test]
fn wander_when_alone() {
    let run = |seed: i64| {
        let mut c = cfg(16, 16);
        c.seed = seed;
        let mut st = setup(&c);
        let a = st.animal(Kind::Herbivore, p(0, 0), 3.0, 2.0); // speed 3 but cruising = 1 step
        let mut s = st.finish();
        let mut path = vec![p(0, 0)];
        let mut same_dir = 0;
        let mut moves = 0;
        let mut last = (0, 0);
        let e0 = s.organisms.get(Kind::Herbivore, a).unwrap().energy();
        for _ in 0..300 {
            s.step();
            let q = pos_of(&s, Kind::Herbivore, a);
            let pr = *path.last().unwrap();
            assert_eq!(cheb(pr, q, 16, 16), 1, "exactly one step per tick when wandering");
            let d = (s.world.grid.delta(pr, q).dx, s.world.grid.delta(pr, q).dy);
            moves += 1;
            if d == last {
                same_dir += 1;
            }
            last = d;
            path.push(q);
        }
        let e1 = s.organisms.get(Kind::Herbivore, a).unwrap().energy();
        assert!((e0 - e1 - 300.0 * 0.5).abs() < 1e-6);
        (path, same_dir as f64 / moves as f64)
    };
    let (p1, persist) = run(5);
    let (p2, _) = run(5);
    let (p3, _) = run(6);
    assert_eq!(p1, p2);
    assert_ne!(p1, p3);
    assert!(persist > 0.7 && persist < 0.95, "heading persistence {}", persist);
}

#[test]
fn cell_sharing_rule() {
    let mut c = cfg(5, 5);
    c.plants.cell_capacity = 3;
    assert_eq!(cell_limit(&c, Kind::Plant), Some(3));
    assert_eq!(cell_limit(&c, Kind::Herbivore), None);
    assert_eq!(cell_limit(&c, Kind::Carnivore), None);
    assert!(can_enter(&c, Kind::Plant, 2) && !can_enter(&c, Kind::Plant, 3));
    assert!(can_enter(&c, Kind::Herbivore, 1000) && can_enter(&c, Kind::Carnivore, 1000));
    // many animals and a plant converge on one cell; nobody is blocked
    let mut st = setup(&c);
    let mut ids = Vec::new();
    for i in 0..6 {
        ids.push(st.animal(Kind::Herbivore, p(i % 5, 4), 1.0, 5.0));
    }
    st.add(Kind::Plant, p(2, 2));
    let mut s = st.finish();
    s.run(10);
    for id in ids {
        assert!(cheb(pos_of(&s, Kind::Herbivore, id), p(2, 2), 5, 5) <= 1); // within feeding reach (TASK-014)
    }
    s.check_index().unwrap();
    // plants: seeding never exceeds the cap (single rule via cell_limit)
    let mut c = cfg(3, 3);
    c.plants.cell_capacity = 2;
    c.plants.reproduction_threshold = 5.0;
    c.plants.reproduction_cost = 1.0;
    c.plants.seed_range = 1;
    c.plants.initial_energy = 50.0;
    c.initial.plants = 6;
    let mut s = Simulation::new(&c).unwrap();
    for _ in 0..30 {
        s.step();
        let mut cnt = [0u32; 9];
        for o in s.organisms.vec(Kind::Plant) {
            cnt[s.world.grid.index(o.pos)] += 1;
        }
        assert!(cnt.iter().all(|&n| n <= 2), "{:?}", cnt);
    }
}

#[test]
fn index_in_sync_through_births_and_deaths() {
    let mut c = cfg(24, 24);
    c.initial.plants = 120;
    c.initial.herbivores = 30;
    c.initial.carnivores = 8;
    c.plants.growth_rate = 2.0;
    c.plants.maintenance = 0.05;
    c.plants.max_age = 60;
    c.plants.reproduction_threshold = 8.0;
    c.plants.reproduction_cost = 4.0;
    c.plants.initial_energy = 30.0;
    c.plants.establish_resource = 0.1;
    c.herbivores.max_age = 100;
    c.carnivores.max_age = 120;
    c.herbivores.initial_energy = 12.0;
    c.carnivores.initial_energy = 12.0;
    let mut s = Simulation::new(&c).unwrap();
    s.check_index().unwrap();
    let (mut births, mut deaths) = (0, 0);
    let mut rng = Rng::new(4);
    for t in 0..300 {
        if t % 5 == 0 {
            // inject births (founder genomes are not adapted to the test climate, so seeding alone is unreliable)
            let parent = [Kind::Plant, Kind::Herbivore, Kind::Carnivore].iter().find_map(|&k| s.organisms.vec(k).iter().find(|o| o.is_active()).map(|o| o.id));
            if let Some(parent) = parent {
                for k in Kind::ALL {
                    let pos = p(rng.below(24) as i32, rng.below(24) as i32);
                    let g = Genome::from_alleles([[0.5f32; 2]; N_GENES]);
                    s.organisms.queue_birth(NewBorn { kind: k, pos, parents: [parent, 0], genome: g, energy: 12.0 });
                }
            }
        }
        s.step();
        births += s.last_births.iter().sum::<u64>();
        deaths += s.last_deaths.iter().sum::<u64>();
        s.check_index().unwrap();
    }
    assert!(births > 0 && deaths > 0, "births {} deaths {}", births, deaths);
    // negative control: a manual desync is detected
    let id = s.organisms.vec(Kind::Plant)[0].id;
    s.spatial.remove(id).unwrap();
    assert!(s.check_index().is_err());
    s.rebuild_index();
    assert!(s.check_index().is_ok());
    let a = s.organisms.vec(Kind::Herbivore).first().map(|o| o.id);
    if let Some(a) = a {
        s.organisms.get_mut(Kind::Herbivore, a).unwrap().pos = p(0, 0);
        let moved = s.spatial.get(a).unwrap().1 != p(0, 0);
        assert_eq!(s.check_index().is_err(), moved);
    }
}

#[test]
fn determinism() {
    let mut c = cfg(20, 20);
    c.initial.plants = 80;
    c.initial.herbivores = 20;
    c.initial.carnivores = 5;
    let run = || {
        let mut s = Simulation::new(&c).unwrap();
        s.run(100);
        s.digest()
    };
    assert_eq!(run(), run());
}

//! TASK-012: plant reproduction and dispersal (docs/PLANTS.md, ADR-0016).
use evosim_core::config::Config;
use evosim_core::genome::{Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::organism::{Kind, NewBorn};
use evosim_core::plants::{seed_target, SEED_ENERGY_FRACTION};
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;

/// Uniform lush climate, one founder plant (energy `e`) at `pos`.
fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = 9;
    c.world.height = 9;
    c.initial.plants = 1;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.equator_temp = 20.0;
    c.climate.pole_temp = 20.0;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.seasonal_precip_amplitude = 0.0;
    c.climate.precip_mean = 1.0;
    c.climate.precip_latitude_variation = 0.0;
    c.climate.weather_noise = 0.0;
    c.climate.terrain_noise = 0.0;
    c.plants.maintenance = 0.0;
    c.plants.growth_rate = 0.0; // energy only changes by reproduction
    c.plants.max_age = 1_000_000;
    c.plants.mutation_rate = 0.0;
    c.plants.reproduction_threshold = 20.0;
    c.plants.reproduction_cost = 10.0;
    c.plants.seed_range = 2;
    c.plants.cell_capacity = 4;
    c
}

/// Simulation with one plant (neutral genome, tuned to the uniform 20 deg C climate) at `pos` with energy `e`.
/// The random founder is replaced because founder genomes are not adapted to the test climate.
fn sim(c: &Config, pos: Pos, e: f64) -> (Simulation, u64) {
    let mut s = Simulation::new(c).unwrap();
    let founder = s.organisms.vec(Kind::Plant)[0].id;
    let g = Genome::from_alleles([[0.5f32; 2]; N_GENES]);
    assert!(s.organisms.queue_birth(NewBorn { kind: Kind::Plant, pos, parents: [founder, 0], genome: g, energy: e }));
    s.organisms.resolve_births(0);
    s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != founder);
    let id = s.organisms.vec(Kind::Plant)[0].id;
    (s, id)
}

/// Seeds born by reproduction (the test setup itself counts one birth).
fn seeds(s: &Simulation) -> u64 {
    s.organisms.stats.births[0] - 1
}

fn plants(s: &Simulation) -> usize {
    s.organisms.count(Kind::Plant)
}

#[test]
fn below_threshold_never_reproduces() {
    let (mut s, id) = sim(&cfg(), Pos { x: 4, y: 4 }, 19.9);
    s.run(200);
    assert_eq!(plants(&s), 1);
    assert_eq!(seeds(&s), 0);
    assert_eq!(s.organisms.get(Kind::Plant, id).unwrap().energy(), 19.9);
    assert_eq!(s.last_plant_stats.attempts, 0);
}

#[test]
fn at_threshold_reproduces_and_costs_energy() {
    let (mut s, id) = sim(&cfg(), Pos { x: 4, y: 4 }, 20.0);
    s.step();
    let st = s.last_plant_stats;
    assert_eq!(st.born, 1);
    assert_eq!(s.last_births[0], 1);
    assert_eq!(plants(&s), 2);
    let parent = s.organisms.get(Kind::Plant, id).unwrap();
    assert_eq!(parent.energy(), 10.0, "parent pays exactly the cost");
    assert_eq!(st.repro_spent, 10.0);
    let child = s.organisms.vec(Kind::Plant).iter().find(|o| o.id != id).unwrap();
    assert_eq!(child.energy(), 10.0 * SEED_ENERGY_FRACTION);
    assert!(st.seed_energy <= st.repro_spent);
    // now below threshold: no more seeds
    s.run(20);
    assert_eq!(seeds(&s), 1);
}

#[test]
fn seed_target_distribution_and_distance() {
    let grid = evosim_core::grid::Grid::new(30, 30).unwrap();
    let mut rng = Rng::new(1);
    let from = Pos { x: 15, y: 15 };
    let mut seen = std::collections::BTreeSet::new();
    for _ in 0..5000 {
        let t = seed_target(&grid, from, 5, &mut rng);
        let d = grid.dist(from, t);
        assert!((1..=5).contains(&d));
        seen.insert(d);
    }
    assert_eq!(seen.len(), 5, "all distances 1..=5 occur");
    assert_eq!(seed_target(&grid, from, 0, &mut rng), from);
}

#[test]
fn ring_covers_all_cells_of_chebyshev_ring() {
    let grid = evosim_core::grid::Grid::new(40, 40).unwrap();
    let from = Pos { x: 20, y: 20 };
    let mut rng = Rng::new(2);
    let mut cells = std::collections::BTreeSet::new();
    for _ in 0..20000 {
        let t = seed_target(&grid, from, 1, &mut rng);
        cells.insert((t.x, t.y));
    }
    assert_eq!(cells.len(), 8, "radius 1 has exactly the 8 neighbours");
}

#[test]
fn offspring_within_seed_range_in_simulation() {
    let mut c = cfg();
    c.world.width = 21;
    c.world.height = 21;
    c.plants.seed_range = 3;
    c.plants.cell_capacity = 1000;
    c.plants.reproduction_cost = 0.5; // seedlings get 0.25 energy and survive (no upkeep)
    let origin = Pos { x: 10, y: 10 };
    let (mut s, id) = sim(&c, origin, 50.0);
    // Parent keeps its energy (cost 0); stop descendants by checking only first generation.
    s.run(60);
    let mut n = 0;
    for o in s.organisms.vec(Kind::Plant) {
        if o.parents[0] == id {
            n += 1;
            let d = s.world.grid.dist(origin, o.pos);
            assert!((1..=3).contains(&d), "child at distance {d}");
        }
    }
    assert!(n > 20);
}

#[test]
fn offspring_wrap_across_edges() {
    let mut c = cfg();
    c.plants.seed_range = 2;
    c.plants.cell_capacity = 1000;
    c.plants.reproduction_cost = 0.5; // seedlings get 0.25 energy and survive (no upkeep)
    let origin = Pos { x: 0, y: 0 };
    let (mut s, id) = sim(&c, origin, 50.0);
    s.run(80);
    let (w, h) = (9, 9);
    let mut wrapped = 0;
    for o in s.organisms.vec(Kind::Plant) {
        if o.parents[0] == id {
            assert!(s.world.grid.dist(origin, o.pos) <= 2);
            if o.pos.x >= w - 2 || o.pos.y >= h - 2 {
                wrapped += 1; // across the edge: raw coordinate distance would be >= 7
            }
        }
    }
    assert!(wrapped > 5, "seeds must cross the world edge, got {wrapped}");
}

#[test]
fn child_genome_inherited_and_parent_recorded() {
    let mut c = cfg();
    c.plants.mutation_rate = 0.0;
    c.plants.reproduction_cost = 0.5; // seedlings get 0.25 energy and survive (no upkeep)
    let (mut s, id) = sim(&c, Pos { x: 4, y: 4 }, 50.0);
    let pg = *s.organisms.get(Kind::Plant, id).unwrap().genome();
    s.step();
    let child = s.organisms.vec(Kind::Plant).iter().find(|o| o.id != id).unwrap();
    assert_eq!(*child.genome(), pg, "no mutation -> exact copy");
    assert_eq!(child.parents, [id, 0]);
    assert_eq!(child.generation, s.organisms.get(Kind::Plant, id).unwrap().generation + 1);
    assert_eq!(child.birth_tick, 0);
}

#[test]
fn child_genome_mutated_and_generations_count() {
    let mut c = cfg();
    c.plants.mutation_rate = 1.0;
    c.genetics.mutation_sigma = 0.1;
    c.plants.reproduction_cost = 0.5; // seedlings get 0.25 energy and survive (no upkeep)
    let (mut s, id) = sim(&c, Pos { x: 4, y: 4 }, 50.0);
    let pg = *s.organisms.get(Kind::Plant, id).unwrap().genome();
    s.run(30);
    let kids: Vec<_> = s.organisms.vec(Kind::Plant).iter().filter(|o| o.parents[0] == id).collect();
    assert!(!kids.is_empty());
    for k in &kids {
        assert_ne!(*k.genome(), pg);
        assert!(Genome::distance(&pg, k.genome()) > 0.0);
        for a in k.genome().alleles() {
            assert!(a[0] >= 0.0 && a[0] <= 1.0 && a[1] >= 0.0 && a[1] <= 1.0);
        }
    }
    let max_gen = s.organisms.vec(Kind::Plant).iter().map(|o| o.generation).max().unwrap();
    assert!(max_gen >= 2, "grandchildren appear with generation 2+");
    for o in s.organisms.vec(Kind::Plant) {
        if o.id != id {
            let p = s.organisms.find(o.parents[0]);
            if let Some(p) = p {
                assert_eq!(o.generation, p.generation + 1);
            }
        }
    }
    let _ = N_GENES;
}

#[test]
fn no_room_no_offspring_and_capacity_respected() {
    let mut c = cfg();
    c.plants.cell_capacity = 1;
    c.plants.seed_range = 1;
    let origin = Pos { x: 4, y: 4 };
    let (mut s, id) = sim(&c, origin, 20.0);
    // Fill all 8 neighbours with plants (queued as children of the founder), low energy.
    let g = *s.organisms.get(Kind::Plant, id).unwrap().genome();
    for p in s.world.grid.neighbors8(origin) {
        assert!(s.organisms.queue_birth(NewBorn { kind: Kind::Plant, pos: p, parents: [id, 0], genome: g, energy: 1.0 }));
    }
    s.organisms.resolve_births(0);
    let before = plants(&s);
    s.step();
    assert_eq!(plants(&s), before);
    assert_eq!(s.last_plant_stats.born, 0);
    assert!(s.last_plant_stats.blocked_room > 0);
    assert_eq!(s.organisms.get(Kind::Plant, id).unwrap().energy(), 20.0, "blocked attempt is free");

    // Strict check from a founder-free start: single founder.
    let mut c = cfg();
    c.plants.cell_capacity = 2;
    c.plants.reproduction_cost = 1.0;
    c.plants.reproduction_threshold = 5.0;
    c.plants.growth_rate = 0.5;
    c.plants.max_energy = 50.0;
    let (mut s, _) = sim(&c, Pos { x: 4, y: 4 }, 30.0);
    for _ in 0..300 {
        s.step();
        let mut cnt = vec![0u32; 81];
        for o in s.organisms.vec(Kind::Plant) {
            cnt[s.world.grid.index(o.pos)] += 1;
        }
        assert!(cnt.iter().all(|&n| n <= 2), "cell_capacity exceeded");
    }
    assert!(plants(&s) > 10);
}

#[test]
fn no_resources_no_offspring() {
    let mut c = cfg();
    c.climate.resource_regen = 0.0;
    c.plants.seed_range = 1;
    let origin = Pos { x: 4, y: 4 };
    let (mut s, id) = sim(&c, origin, 20.0);
    for i in 0..81 {
        let p = s.world.grid.pos_of(i);
        s.world.set_resource(p, 0.0);
    }
    s.step();
    assert_eq!(s.last_plant_stats.born, 0);
    assert!(s.last_plant_stats.blocked_resource > 0);
    assert_eq!(plants(&s), 1);
    assert_eq!(s.organisms.get(Kind::Plant, id).unwrap().energy(), 20.0);

    // Only one cell holds resources: every offspring lands exactly there.
    let target = Pos { x: 5, y: 3 };
    s.world.set_resource(target, 5.0);
    s.run(40);
    let kids: Vec<_> = s.organisms.vec(Kind::Plant).iter().filter(|o| o.id != id).collect();
    assert!(!kids.is_empty(), "the one fertile cell receives a seed");
    assert!(kids.iter().all(|o| o.pos == target));
}

#[test]
fn hostile_climate_blocks_seeds() {
    let mut c = cfg();
    c.climate.precip_mean = 0.0; // too dry everywhere for the child (water factor 0)
    let (mut s, id) = sim(&c, Pos { x: 4, y: 4 }, 20.0);
    s.step();
    assert_eq!(s.last_plant_stats.born, 0);
    assert!(s.last_plant_stats.blocked_climate + s.last_plant_stats.blocked_resource > 0);
    assert_eq!(s.organisms.get(Kind::Plant, id).map(|o| o.energy()), Some(20.0));
}

#[test]
fn zero_plants_stay_zero() {
    for seed in [1i64, 77] {
        let mut c = cfg();
        c.seed = seed;
        c.initial.plants = 0;
        c.initial.herbivores = 20;
        c.initial.carnivores = 5;
        c.plants.initial_energy = 40.0;
        let mut s = Simulation::new(&c).unwrap();
        for _ in 0..500 {
            s.step();
            assert_eq!(plants(&s), 0);
            assert_eq!(s.last_births[0], 0);
            assert_eq!(s.last_plant_stats.attempts, 0);
        }
        assert_eq!(s.organisms.stats.births[0], 0);
        assert_eq!(s.organisms.stats.founded[0], 0);
    }
    // And without any organism at all.
    let mut c = cfg();
    c.initial.plants = 0;
    let mut s = Simulation::new(&c).unwrap();
    s.run(300);
    assert_eq!(plants(&s), 0);
}

#[test]
fn zero_plants_plant_phase_draws_no_rng() {
    // With 0 plants the Plants phase must not draw: compare with a world with one sub-threshold plant.
    let mut c = cfg();
    c.initial.plants = 0;
    let mut a = Simulation::new(&c).unwrap();
    c.initial.plants = 1;
    c.plants.initial_energy = 1.0;
    let mut b = Simulation::new(&c).unwrap();
    a.run(50);
    b.run(50);
    assert_eq!(a.export_rng(), b.export_rng());
}

#[test]
fn energy_never_created_by_reproduction() {
    let mut c = cfg();
    c.plants.growth_rate = 0.5;
    c.plants.reproduction_threshold = 10.0;
    c.plants.reproduction_cost = 4.0;
    let (mut s, _) = sim(&c, Pos { x: 4, y: 4 }, 30.0);
    for _ in 0..200 {
        s.step();
        let st = s.last_plant_stats;
        assert!(st.seed_energy <= st.repro_spent + 1e-12);
        assert!((st.repro_spent - 4.0 * st.born as f64).abs() < 1e-9);
    }
}

#[test]
fn deterministic_and_grows_with_reproduction() {
    let mut c = cfg();
    c.plants.growth_rate = 0.8;
    c.plants.maintenance = 0.05;
    c.plants.reproduction_threshold = 10.0;
    c.plants.mutation_rate = 0.1;
    let (mut a, _) = sim(&c, Pos { x: 4, y: 4 }, 30.0);
    let (mut b, _) = sim(&c, Pos { x: 4, y: 4 }, 30.0);
    a.run(300);
    b.run(300);
    assert_eq!(a.digest(), b.digest());
    assert!(plants(&a) > 5, "population should spread, got {}", plants(&a));
}

#[test]
fn default_config_long_run_is_bounded() {
    let mut c = Config::default();
    c.world.width = 40;
    c.world.height = 40;
    c.herbivores.bite_size = 0.0; // TASK-014: plant test, no grazing
    let mut s = Simulation::new(&c).unwrap();
    let max = 1600 * c.plants.cell_capacity as usize;
    for _ in 0..1500 {
        s.step();
        assert!(plants(&s) <= max + c.initial.plants as usize);
    }
    assert!(s.organisms.stats.births[0] > 0, "default world must have some seeding");
}

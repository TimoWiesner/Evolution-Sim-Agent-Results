//! Slowdown guard (ADR-0030). Threshold is >10x below the measured speed so it is stable on slow
//! machines; the golden state hash makes sure a "speed-up" never changes behaviour.
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;
use std::time::Instant;

const GOLDEN_HASH: &str = "17654f5742b510c9cb098f05840e1cad47656b2cee49a53944ab6a6d3f8ee705";

fn cfg() -> Config {
    let mut c = Config::default();
    c.seed = 42;
    c.world.width = 48;
    c.world.height = 32;
    c.initial.plants = 300;
    c.initial.herbivores = 80;
    c.initial.carnivores = 12;
    c
}

fn run_once() -> (f64, String, usize) {
    let mut s = Simulation::new(&cfg()).unwrap();
    s.run(50);
    let t = Instant::now();
    s.run(100);
    let e = t.elapsed().as_secs_f64().max(1e-9);
    let n: usize = Kind::ALL.iter().map(|k| s.organisms.count(*k)).sum();
    (100.0 / e, s.state_hash(), n)
}

#[test]
fn tick_rate_guard_and_behaviour_hash() {
    let mut best = 0.0f64;
    for _ in 0..3 {
        let (r, h, n) = run_once();
        assert_eq!(h, GOLDEN_HASH, "behaviour changed (organisms {n}); regenerate only on intended semantic changes");
        assert!(n >= 100, "bench population too small: {n}");
        best = best.max(r);
    }
    let min = if cfg!(debug_assertions) { 1.0 } else { 15.0 };
    assert!(best >= min, "{best:.1} ticks/s is below the guard of {min} ticks/s");
}

//! TASK-028: randomised invariant tests over many seeds and configurations.
//! Meta-seed fixed, so any failure reproduces; `EVOSIM_FUZZ_SEEDS=N` raises the number of cases (default 40).
use evosim_core::config::{Config, Kind as PKind, Num};
use evosim_core::organism::{Kind, Traits};
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;
use std::collections::HashMap;

fn cases() -> u64 {
    std::env::var("EVOSIM_FUZZ_SEEDS").ok().and_then(|v| v.parse().ok()).unwrap_or(40)
}

/// Random valid configuration: random world (incl. 1xN, Nx1, odd), random populations (incl. 0),
/// preset or default, and ~12 randomly jittered parameters. Returns None if the combination is rejected.
fn random_config(rng: &mut Rng) -> Option<Config> {
    let presets = ["default", "lush", "harsh", "predator-rich", "large"];
    let mut c = Config::preset(presets[rng.below(5) as usize]).unwrap();
    c.seed = rng.next_u64() as i64 >> 8;
    let dims = [1u64, 2, 3, 5, 7, 12, 17, 24];
    let (mut w, mut h) = (dims[rng.below(8) as usize], dims[rng.below(8) as usize]);
    if rng.chance(0.15) {
        w = 1 + rng.below(40);
        h = 1;
    }
    c.set_num("world.width", Num::I(w as i64)).ok()?;
    c.set_num("world.height", Num::I(h as i64)).ok()?;
    let cells = (w * h) as i64;
    for (k, mult) in [("initial.plants", 3), ("initial.herbivores", 2), ("initial.carnivores", 1)] {
        let n = if rng.chance(0.15) { 0 } else { rng.below((cells * mult + 3) as u64) as i64 };
        c.set_num(k, Num::I(n)).ok()?;
    }
    let defs = Config::param_defs();
    let free: Vec<_> = defs.iter().filter(|d| !d.fixed && !d.path.starts_with("world.") && !d.path.starts_with("initial.")).collect();
    for _ in 0..12 {
        let d = free[rng.below(free.len() as u64) as usize];
        let n = match (d.kind, d.default) {
            (PKind::Bool, _) => Num::B(rng.chance(0.5)),
            (PKind::Int, Num::I(v)) => {
                let lo = ((v as f64) * 0.5).max(d.min).ceil() as i64;
                let hi = ((v as f64) * 2.0 + 1.0).min(d.max).floor() as i64;
                if hi < lo { continue }
                Num::I(rng.range_i64(lo, hi))
            }
            (_, Num::F(v)) => {
                let lo = (v * 0.5).max(d.min);
                let hi = (v * 2.0).min(d.max).max(lo);
                Num::F(lo + (hi - lo) * rng.next_f64())
            }
            _ => continue,
        };
        let _ = c.set_num(&d.path, n);
    }
    c.validate().ok()?;
    Some(c)
}

fn counts(s: &Simulation) -> [i64; 3] {
    Kind::ALL.map(|k| s.organisms.count(k) as i64)
}

fn in_range(kind: Kind, t: &Traits) -> Result<(), String> {
    let g = Traits::range(kind);
    let chk = |name: &str, v: f64, lo: f64, hi: f64| {
        if v.is_finite() && v >= lo - 1e-9 && v <= hi + 1e-9 { Ok(()) } else { Err(format!("{name}={v} outside [{lo},{hi}]")) }
    };
    chk("speed", t.speed, g.speed.lo, g.speed.hi)?;
    chk("strength", t.strength, g.strength.lo, g.strength.hi)?;
    chk("fertility", t.fertility, g.fertility.lo, g.fertility.hi)?;
    chk("max_health", t.max_health, g.max_health.lo, g.max_health.hi)?;
    chk("max_lifespan", t.max_lifespan as f64, g.max_lifespan.lo, g.max_lifespan.hi)?;
    chk("max_energy", t.max_energy, g.max_energy.lo, g.max_energy.hi)?;
    chk("metabolism", t.metabolism, g.metabolism.lo, g.metabolism.hi)?;
    chk("vision", t.vision, g.vision.lo, g.vision.hi)?;
    chk("aggression", t.aggression, g.aggression.lo, g.aggression.hi)?;
    chk("risk_tolerance", t.risk_tolerance, g.risk_tolerance.lo, g.risk_tolerance.hi)
}

/// Checks one state; `prev` maps id -> position at the previous tick (for the wrapping/step-length check).
fn check_state(s: &Simulation, init: [i64; 3], cum_b: [i64; 3], cum_d: [i64; 3], prev: &mut HashMap<u64, (i32, i32)>, ctx: &str) {
    s.ledger_check().unwrap_or_else(|e| panic!("{ctx}: ledger {e}"));
    s.check_index().unwrap_or_else(|e| panic!("{ctx}: index {e}"));
    let now = counts(s);
    let grid = s.world.grid;
    let mut seen = HashMap::new();
    let mut next = HashMap::new();
    for k in Kind::ALL {
        let i = k.index();
        assert_eq!(init[i] + cum_b[i] - cum_d[i], now[i], "{ctx}: accounting {k:?}");
        let mut species = std::collections::HashSet::new();
        for o in s.organisms.vec(k).iter().filter(|o| o.is_active()) {
            assert!(grid.contains(o.pos), "{ctx}: {:?} id {} outside the grid at {:?}", k, o.id, o.pos);
            assert!(seen.insert(o.id, k).is_none(), "{ctx}: duplicate id {}", o.id);
            in_range(k, &o.traits).unwrap_or_else(|e| panic!("{ctx}: {k:?} id {}: {e}", o.id));
            assert!(o.energy().is_finite() && o.energy() >= 0.0 && o.energy() <= o.traits.max_energy + 1e-6, "{ctx}: energy {}", o.energy());
            assert!(o.health().is_finite() && o.health() >= 0.0 && o.health() <= o.traits.max_health + 1e-6, "{ctx}: health {}", o.health());
            species.insert(o.species);
            if k.is_animal() {
                if let Some(&(px, py)) = prev.get(&o.id) {
                    // wrap-aware step length: at most one speed credit's worth (+1 for the carried fraction)
                    let d = grid.dist(evosim_core::grid::Pos { x: px, y: py }, o.pos) as f64;
                    assert!(d <= o.traits.speed.ceil() + 1.0, "{ctx}: id {} moved {} cells with speed {}", o.id, d, o.traits.speed);
                }
                next.insert(o.id, (o.pos.x, o.pos.y));
            }
        }
        assert!(species.len() as i64 <= now[i], "{ctx}: more species than individuals");
        assert_eq!(s.living_species(k), species.len(), "{ctx}: living_species {k:?}");
    }
    *prev = next;
}

fn run_case(case: u64, ticks: u64) -> bool {
    let mut meta = Rng::stream(0x5EED_F00D, case);
    let Some(cfg) = random_config(&mut meta) else { return false };
    let ctx = format!("case {case} seed {} {}x{}", cfg.seed, cfg.world.width, cfg.world.height);
    let mut s = Simulation::new(&cfg).unwrap_or_else(|e| panic!("{ctx}: {e:?}"));
    let init = counts(&s);
    let (mut cb, mut cd) = ([0i64; 3], [0i64; 3]);
    let mut prev = HashMap::new();
    let mut zero_seen = [false; 3];
    let cp_at = 1 + meta.below(ticks - 1);
    let mut twin = Simulation::new(&cfg).unwrap();
    let mut restored: Option<Simulation> = None;
    check_state(&s, init, cb, cd, &mut prev, &ctx);
    for t in 1..=ticks {
        s.step();
        twin.step();
        for k in 0..3 {
            cb[k] += s.last_births[k] as i64;
            cd[k] += s.last_deaths[k] as i64;
        }
        let c = ctx.clone() + &format!(" tick {t}");
        check_state(&s, init, cb, cd, &mut prev, &c);
        let now = counts(&s);
        for k in 0..3 {
            if zero_seen[k] {
                assert_eq!(now[k], 0, "{c}: kind {k} came back from zero");
            }
            zero_seen[k] |= now[k] == 0;
        }
        assert_eq!(s.digest(), twin.digest(), "{c}: determinism (digest)");
        if t == cp_at {
            restored = Some(Simulation::from_checkpoint(&s.to_checkpoint()).unwrap_or_else(|e| panic!("{c}: checkpoint {e:?}")));
            assert_eq!(restored.as_ref().unwrap().state_hash(), s.state_hash(), "{c}: restore hash");
        } else if let Some(r) = restored.as_mut() {
            r.step();
            assert_eq!(r.digest(), s.digest(), "{c}: checkpoint continuation diverged");
        }
    }
    assert_eq!(s.state_hash(), twin.state_hash(), "{ctx}: determinism (hash)");
    if let Some(r) = restored {
        assert_eq!(r.state_hash(), s.state_hash(), "{ctx}: checkpoint run equals uninterrupted run");
    }
    true
}

#[test]
fn random_configurations_keep_all_invariants() {
    let n = cases();
    let mut ran = 0;
    for case in 0..n * 3 {
        if ran >= n {
            break;
        }
        if run_case(case, 150) {
            ran += 1;
        }
    }
    assert!(ran >= n, "only {ran} of {n} random configurations were valid");
}

#[test]
fn different_seeds_give_different_hashes_and_same_seed_same_hash() {
    for case in 0..(cases() / 4).max(5) {
        let mut meta = Rng::stream(77, case);
        let Some(mut cfg) = random_config(&mut meta) else { continue };
        for k in ["initial.plants", "initial.herbivores"] {
            let v = cfg.get_num(k).unwrap();
            if matches!(v, Num::I(0)) { cfg.set_num(k, Num::I(10)).unwrap(); }
        }
        if cfg.world.width * cfg.world.height < 6 { continue }
        let h = |seed: i64| {
            let mut c = cfg.clone();
            c.seed = seed;
            let mut s = Simulation::new(&c).unwrap();
            s.run(30);
            s.state_hash()
        };
        assert_eq!(h(1), h(1));
        assert_ne!(h(1), h(2), "case {case}");
    }
}

#[test]
fn wrapping_on_degenerate_worlds_keeps_animals_inside() {
    // 1xN and Nx1 worlds: every wrapped neighbour is on the same row/column; run with animals only fed by plants
    for (w, h) in [(1u32, 1u32), (1, 9), (9, 1), (2, 2), (3, 1)] {
        let text = format!(r#"{{"seed":5,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":20,"herbivores":10,"carnivores":3}}}}"#);
        let mut s = Simulation::new(&Config::from_json(&text).unwrap()).unwrap();
        for _ in 0..300 {
            s.step();
            for k in Kind::ALL {
                for o in s.organisms.vec(k).iter().filter(|o| o.is_active()) {
                    assert!(s.world.grid.contains(o.pos), "{w}x{h}: {:?}", o.pos);
                }
            }
        }
        s.ledger_check().unwrap();
        s.check_index().unwrap();
    }
}

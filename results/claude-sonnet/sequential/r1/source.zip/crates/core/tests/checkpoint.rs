//! TASK-022: checkpoint round trip, resume equality and rejection of damaged files (ADR-0026).
use evosim_core::checkpoint::{decode, encode, FORMAT_VERSION};
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;

fn cfg(seed: i64) -> Config {
    let mut c = Config::default();
    c.seed = seed;
    c.world.width = 24;
    c.world.height = 16;
    c.initial.plants = 150;
    c.initial.herbivores = 40;
    c.initial.carnivores = 8;
    c
}

fn all_equal(a: &Simulation, b: &Simulation) {
    assert_eq!(a.state_hash(), b.state_hash());
    assert_eq!(a.digest(), b.digest());
    assert_eq!(a.tick, b.tick);
    assert_eq!(a.organisms.stats, b.organisms.stats);
    assert_eq!(a.species.records(), b.species.records());
    for k in Kind::ALL {
        assert_eq!(a.organisms.vec(k), b.organisms.vec(k), "{k:?}");
    }
    assert_eq!(a.organisms.next_id(), b.organisms.next_id());
}

#[test]
fn roundtrip_is_exact_at_several_ticks() {
    for ticks in [0u64, 1, 25, 150] {
        let mut s = Simulation::new(&cfg(3)).unwrap();
        s.run(ticks);
        let l = Simulation::from_checkpoint(&s.to_checkpoint()).unwrap();
        all_equal(&s, &l);
        assert_eq!(l.to_checkpoint(), s.to_checkpoint(), "file image is canonical");
    }
}

#[test]
fn resume_equals_uninterrupted() {
    let total = 200u64;
    let mut full = Simulation::new(&cfg(11)).unwrap();
    full.run(total);
    let mut speciated = false;
    for split in [0u64, 1, 37, 120, 200] {
        let mut a = Simulation::new(&cfg(11)).unwrap();
        a.run(split);
        let mut b = Simulation::from_checkpoint(&a.to_checkpoint()).unwrap();
        b.run(total - split);
        all_equal(&full, &b);
        // original continues too
        a.run(total - split);
        all_equal(&a, &b);
        speciated |= b.species.records().len() > 3;
    }
    assert!(full.organisms.stats.births.iter().sum::<u64>() > 0, "births must happen");
    let _ = speciated;
}

#[test]
fn chain_of_three_segments() {
    let mut full = Simulation::new(&cfg(5)).unwrap();
    full.run(90);
    let mut s = Simulation::new(&cfg(5)).unwrap();
    for _ in 0..3 {
        s.run(30);
        s = Simulation::from_checkpoint(&s.to_checkpoint()).unwrap();
    }
    all_equal(&full, &s);
}

#[test]
fn edge_worlds() {
    let mut c = cfg(1);
    c.initial.plants = 0;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    let mut s = Simulation::new(&c).unwrap();
    s.run(5);
    all_equal(&s, &Simulation::from_checkpoint(&s.to_checkpoint()).unwrap());
    let mut c = cfg(2);
    c.world.width = 1;
    c.world.height = 1;
    c.initial.plants = 1;
    c.initial.herbivores = 1;
    c.initial.carnivores = 1;
    let mut s = Simulation::new(&c).unwrap();
    s.run(30);
    let mut l = Simulation::from_checkpoint(&s.to_checkpoint()).unwrap();
    all_equal(&s, &l);
    s.run(30);
    l.run(30);
    all_equal(&s, &l);
}

#[test]
fn config_json_roundtrip_is_lossless() {
    let mut c = cfg(9);
    c.climate.weather_noise = 0.123456789012345;
    let j = c.to_json();
    assert_eq!(Config::from_json(&j).unwrap().to_json(), j);
}

fn small_file() -> Vec<u8> {
    let mut c = cfg(4);
    c.world.width = 3;
    c.world.height = 2;
    c.initial.plants = 3;
    c.initial.herbivores = 2;
    c.initial.carnivores = 1;
    let mut s = Simulation::new(&c).unwrap();
    s.run(4);
    s.to_checkpoint()
}

#[test]
fn every_truncation_is_rejected() {
    let f = small_file();
    assert!(Simulation::from_checkpoint(&f).is_ok());
    for n in 0..f.len() {
        assert!(Simulation::from_checkpoint(&f[..n]).is_err(), "prefix {n}");
    }
}

#[test]
fn every_bit_flip_is_rejected() {
    let f = small_file();
    for i in 0..f.len() {
        for bit in [0u8, 7] {
            let mut g = f.clone();
            g[i] ^= 1 << bit;
            assert!(Simulation::from_checkpoint(&g).is_err(), "byte {i} bit {bit}");
        }
    }
}

#[test]
fn trailing_bytes_and_wrong_versions() {
    let f = small_file();
    let mut g = f.clone();
    g.push(0);
    assert!(Simulation::from_checkpoint(&g).is_err());
    for v in [0u32, FORMAT_VERSION + 1, u32::MAX] {
        let mut g = f.clone();
        g[8..12].copy_from_slice(&v.to_le_bytes());
        let e = Simulation::from_checkpoint(&g).err().unwrap().to_string();
        assert!(e.contains("version"), "{e}");
    }
    assert!(Simulation::from_checkpoint(b"").is_err());
    assert!(Simulation::from_checkpoint(&[0u8; 100]).is_err());
}

#[test]
fn valid_container_with_bad_content_is_rejected() {
    // correct checksum but nonsense payloads must give errors, not panics
    for payload in [vec![], vec![1u8, 2, 3], vec![0xffu8; 64], vec![0u8; 4096]] {
        let f = encode(&payload);
        assert_eq!(decode(&f).unwrap(), &payload[..]);
        assert!(Simulation::from_checkpoint(&f).is_err());
    }
    // re-encode a real payload with one semantic change (tick) so only the stored hash can notice
    let f = small_file();
    let mut p = decode(&f).unwrap().to_vec();
    let cfg_len = u64::from_le_bytes(p[0..8].try_into().unwrap()) as usize;
    let tick_at = 8 + cfg_len;
    p[tick_at] ^= 1;
    assert!(Simulation::from_checkpoint(&encode(&p)).is_err());
}

#[test]
fn payload_fuzz_never_panics() {
    // Flip every payload byte and re-seal with a valid checksum: the loader must return (Ok or Err), never panic
    // or allocate wildly; flips of hashed state must be errors.
    let f = small_file();
    let p = decode(&f).unwrap().to_vec();
    let mut rejected = 0;
    for i in 0..p.len() {
        let mut q = p.clone();
        q[i] ^= 0x5a;
        if Simulation::from_checkpoint(&encode(&q)).is_err() {
            rejected += 1;
        }
    }
    assert!(rejected * 10 >= p.len() * 9, "only {rejected} of {} flips rejected", p.len());
}

//! TASK-015: carnivore hunting (ADR-0019).
use evosim_core::carnivore::{attack_probability, ATTACK_REACH, P_MAX, P_MIN};
use evosim_core::config::Config;
use evosim_core::genome::{Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::organism::{DeathCause, Id, Kind, NewBorn};
use evosim_core::sim::{EventKind, Simulation};

fn p(x: i32, y: i32) -> Pos {
    Pos { x, y }
}

fn cfg(w: u32, h: u32) -> Config {
    let mut c = Config::default();
    c.seed = 5;
    c.world.width = w;
    c.world.height = h;
    c.climate.cover_protection = 0.0; // unit tests assume no prey refuge (ADR-0031)
    c.initial.plants = 1; // helper founder (parent for queue_birth)
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.equator_temp = 18.0;
    c.climate.pole_temp = 18.0;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.seasonal_precip_amplitude = 0.0;
    c.climate.precip_mean = 1.0;
    c.climate.precip_latitude_variation = 0.0;
    c.climate.weather_noise = 0.0;
    c.climate.terrain_noise = 0.0;
    c.plants.maintenance = 0.0;
    c.plants.growth_rate = 0.0;
    c.plants.max_age = 1_000_000;
    c.plants.max_energy = 200.0;
    c.plants.reproduction_threshold = 200.0;
    c.herbivores.max_age = 1_000_000;
    c.carnivores.max_age = 1_000_000;
    c.herbivores.base_metabolism = 0.0;
    c.herbivores.move_cost = 0.0;
    c.herbivores.bite_size = 0.0;
    c.carnivores.base_metabolism = 0.0;
    c.carnivores.move_cost = 0.0;
    c.carnivores.attack_cost = 0.0;
    c.carnivores.handling_time = 0;
    c.carnivores.satiation_limit = 1.0;
    c.carnivores.digestion_efficiency = 1.0;
    c
}

struct Setup {
    s: Simulation,
    founder: Id,
}

fn setup(c: &Config) -> Setup {
    let s = Simulation::new(c).unwrap();
    let founder = s.organisms.vec(Kind::Plant)[0].id;
    Setup { s, founder }
}

impl Setup {
    fn birth(&mut self, kind: Kind, pos: Pos, energy: f64) -> Id {
        let g = Genome::from_alleles([[0.5f32; 2]; N_GENES]);
        assert!(self.s.organisms.queue_birth(NewBorn { kind, pos, parents: [self.founder, 0], genome: g, energy }));
        self.s.organisms.resolve_births(0).last().unwrap().0
    }
    /// Herbivore: speed 0.1 (stays put), given strength/energy, metabolism 1.
    fn herb(&mut self, pos: Pos, energy: f64) -> Id {
        let id = self.birth(Kind::Herbivore, pos, energy);
        let o = self.s.organisms.get_mut(Kind::Herbivore, id).unwrap();
        o.traits.speed = 0.1;
        o.traits.vision = 1.0;
        o.traits.metabolism = 1.0;
        o.traits.max_energy = 100.0;
        o.set_energy(energy);
        id
    }
    fn carn(&mut self, pos: Pos, speed: f64, vision: f64, energy: f64) -> Id {
        let id = self.birth(Kind::Carnivore, pos, energy);
        let o = self.s.organisms.get_mut(Kind::Carnivore, id).unwrap();
        o.traits.speed = speed;
        o.traits.vision = vision;
        o.traits.metabolism = 1.0;
        o.traits.max_energy = 200.0;
        o.set_energy(energy);
        id
    }
    fn finish(mut self) -> Simulation {
        let f = self.founder;
        self.s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != f);
        self.s.rebuild_index();
        self.s.check_index().unwrap();
        self.s
    }
}

fn cpos(s: &Simulation, id: Id) -> Pos {
    s.organisms.get(Kind::Carnivore, id).unwrap().pos
}
fn cen(s: &Simulation, id: Id) -> f64 {
    s.organisms.get(Kind::Carnivore, id).unwrap().energy()
}

/// Runs one tick on a single-carnivore/single-herbivore setup and returns whether an attack happened.
fn attacked_at(c: &Config, cp: Pos, hp: Pos, vision: f64, speed: f64) -> (bool, Pos) {
    let mut st = setup(c);
    st.herb(hp, 50.0);
    let car = st.carn(cp, speed, vision, 100.0);
    let mut s = st.finish();
    s.step();
    (s.last_carnivore_stats.attacks > 0, cpos(&s, car))
}

#[test]
fn attack_only_from_same_or_adjacent_cell() {
    assert_eq!(ATTACK_REACH, 1);
    let mut c = cfg(10, 10);
    c.carnivores.attack_cost = 1.0;
    // speed 0.1: the carnivore cannot move this tick, so only reach decides
    for (hp, expect) in [(p(5, 5), true), (p(6, 5), true), (p(4, 4), true), (p(7, 5), false), (p(5, 8), false)] {
        let (att, pos) = attacked_at(&c, p(5, 5), hp, 4.0, 0.1);
        assert_eq!(att, expect, "prey at {:?}", hp);
        assert_eq!(pos, p(5, 5));
    }
    // across the wrap seams
    for (hp, expect) in [(p(9, 0), true), (p(9, 9), true), (p(0, 9), true), (p(8, 0), false), (p(0, 8), false)] {
        let (att, _) = attacked_at(&c, p(0, 0), hp, 4.0, 0.1);
        assert_eq!(att, expect, "seam prey at {:?}", hp);
    }
    // a fast carnivore at distance 2 steps adjacent and attacks in the same tick
    let (att, pos) = attacked_at(&c, p(3, 5), p(5, 5), 4.0, 1.0);
    assert!(att);
    assert_eq!(pos, p(4, 5));
}

#[test]
fn pursues_prey_within_vision_not_beyond() {
    let c = cfg(30, 30);
    // within vision: walks straight at the prey
    let mut st = setup(&c);
    st.herb(p(10, 5), 50.0);
    let car = st.carn(p(5, 5), 1.0, 6.0, 100.0);
    let mut s = st.finish();
    s.step();
    assert_eq!(cpos(&s, car), p(6, 5));
    s.run(3);
    assert_eq!(cpos(&s, car), p(9, 5));
    // beyond vision: wanders (ignores the prey direction deterministically? at least no targeted step guarantee)
    let mut dist_after = Vec::new();
    for seed in 0..20 {
        let mut c2 = c.clone();
        c2.seed = seed;
        let mut st = setup(&c2);
        st.herb(p(15, 5), 50.0);
        let car = st.carn(p(5, 5), 1.0, 4.0, 100.0);
        let mut s = st.finish();
        s.step();
        assert_eq!(s.last_carnivore_stats.attacks, 0);
        dist_after.push(cpos(&s, car));
    }
    // a pursuer would always be at (6,5); a wanderer takes several different cells
    let mut uniq = dist_after.clone();
    uniq.sort_by_key(|q| (q.x, q.y));
    uniq.dedup();
    assert!(uniq.len() > 2, "wandering expected, got {:?}", uniq);
}

#[test]
fn carnivores_ignore_plants_and_carnivores() {
    let mut c = cfg(10, 10);
    c.carnivores.attack_cost = 1.0;
    let mut st = setup(&c);
    let car = st.carn(p(5, 5), 0.1, 3.0, 100.0);
    let other = st.carn(p(5, 5), 0.1, 3.0, 100.0);
    let _pl = st.birth(Kind::Plant, p(5, 5), 50.0);
    let mut s = st.finish();
    s.run(5);
    assert_eq!(s.last_carnivore_stats.attacks, 0);
    assert!(s.organisms.get(Kind::Carnivore, other).unwrap().is_active());
    assert!((cen(&s, car) - 100.0).abs() < 1e-12);
}

fn animal_pair(c_str: f64, c_spd: f64, c_agg: f64, h_str: f64, h_spd: f64, h_hp: f64) -> f64 {
    let mut st = setup(&cfg(10, 10));
    let h = st.herb(p(5, 5), 50.0);
    let car = st.carn(p(5, 5), 1.0, 3.0, 100.0);
    {
        let o = st.s.organisms.get_mut(Kind::Carnivore, car).unwrap();
        o.traits.strength = c_str;
        o.traits.speed = c_spd;
        o.traits.aggression = c_agg;
    }
    {
        let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
        o.traits.strength = h_str;
        o.traits.speed = h_spd;
        o.damage(o.traits.max_health * (1.0 - h_hp));
    }
    let s = st.finish();
    attack_probability(s.organisms.get(Kind::Carnivore, car).unwrap(), s.organisms.get(Kind::Herbivore, h).unwrap())
}

#[test]
fn attack_probability_depends_on_both_animals_monotonically() {
    let base = animal_pair(3.0, 1.5, 0.6, 1.0, 1.0, 1.0);
    assert!((base - 11.0 / 19.0).abs() < 0.02, "default matchup ~0.58, got {}", base);
    assert!(animal_pair(5.0, 1.5, 0.6, 1.0, 1.0, 1.0) > base);
    assert!(animal_pair(3.0, 2.5, 0.6, 1.0, 1.0, 1.0) > base);
    assert!(animal_pair(3.0, 1.5, 0.9, 1.0, 1.0, 1.0) > base);
    assert!(animal_pair(3.0, 1.5, 0.6, 3.0, 1.0, 1.0) < base);
    assert!(animal_pair(3.0, 1.5, 0.6, 1.0, 2.0, 1.0) < base);
    assert!(animal_pair(3.0, 1.5, 0.6, 1.0, 1.0, 0.2) > base, "weak prey is easier");
    assert_eq!(animal_pair(0.0, 0.1, 0.0, 100.0, 16.0, 1.0), P_MIN);
    assert_eq!(animal_pair(100.0, 16.0, 1.0, 0.0, 0.1, 0.0), P_MAX);
    for cs in [0.0, 1.0, 50.0] {
        for hs in [0.0, 2.0, 80.0] {
            let v = animal_pair(cs, 1.0, 0.5, hs, 1.0, 1.0);
            assert!((P_MIN..=P_MAX).contains(&v));
        }
    }
}

#[test]
fn many_attacks_kills_and_escapes_both_occur() {
    // One carnivore and a herbivore re-spawned after every kill: >= 3000 attacks in one small sim.
    let mut c = cfg(8, 8);
    c.carnivores.attack_cost = 0.0;
    let mut st = setup(&c);
    st.herb(p(4, 4), 50.0);
    let car = st.carn(p(4, 4), 0.1, 2.0, 100.0);
    let mut s = st.finish();
    let expected = {
        let cc = s.organisms.get(Kind::Carnivore, car).unwrap();
        let hh = s.organisms.vec(Kind::Herbivore)[0].clone();
        attack_probability(cc, &hh)
    };
    let (mut attacks, mut kills, mut escapes) = (0u64, 0u64, 0u64);
    while attacks < 3000 {
        if s.organisms.count(Kind::Herbivore) == 0 {
            // refill: new prey with the same traits as the first
            let f = s.organisms.vec(Kind::Carnivore)[0].id;
            assert!(s.organisms.queue_birth(NewBorn {
                kind: Kind::Herbivore,
                pos: p(4, 4),
                parents: [f, 0],
                genome: Genome::from_alleles([[0.5f32; 2]; N_GENES]),
                energy: 50.0
            }));
            let id = s.organisms.resolve_births(s.tick).last().unwrap().0;
            let o = s.organisms.get_mut(Kind::Herbivore, id).unwrap();
            o.traits.speed = 0.1;
            o.traits.metabolism = 1.0;
            o.traits.max_energy = 100.0;
            o.set_energy(50.0);
            s.spatial.insert(id, Kind::Herbivore, p(4, 4)).unwrap();
        }
        s.step();
        let st = s.last_carnivore_stats;
        attacks += st.attacks;
        kills += st.kills;
        escapes += st.escapes;
        assert_eq!(st.attacks, st.kills + st.escapes);
        let o = s.organisms.get_mut(Kind::Carnivore, car).unwrap();
        o.set_energy(100.0); // keep it hunting
    }
    assert!(kills > 0 && escapes > 0, "kills {} escapes {}", kills, escapes);
    let rate = kills as f64 / attacks as f64;
    let sigma = (expected * (1.0 - expected) / attacks as f64).sqrt();
    assert!((rate - expected).abs() < 4.0 * sigma, "rate {} expected {} sigma {}", rate, expected, sigma);
}

#[test]
fn outcomes_differ_between_seeds_and_repeat_for_same_seed() {
    let run = |seed: i64| -> Vec<u64> {
        let mut c = cfg(8, 8);
        c.seed = seed;
        let mut st = setup(&c);
        for i in 0..40 {
            st.herb(p(i % 8, (i / 8) % 8), 50.0);
        }
        st.carn(p(0, 0), 0.1, 1.0, 100.0);
        for i in 0..40 {
            st.carn(p(i % 8, (i / 8) % 8), 0.1, 1.0, 100.0);
        }
        let mut s = st.finish();
        let mut v = Vec::new();
        for _ in 0..5 {
            s.step();
            v.push(s.last_carnivore_stats.kills);
        }
        v
    };
    assert_eq!(run(1), run(1));
    assert!((2..12).any(|sd| run(sd) != run(1)));
}

#[test]
fn kill_exactly_once_predation_and_not_eaten_twice() {
    let mut c = cfg(10, 10);
    c.carnivores.strength = 100.0;
    c.carnivores.speed = 16.0;
    let mut st = setup(&c);
    let h = st.herb(p(5, 5), 40.0);
    let a = st.carn(p(5, 5), 0.1, 2.0, 100.0);
    let b = st.carn(p(5, 5), 0.1, 2.0, 100.0);
    for id in [a, b] {
        let o = st.s.organisms.get_mut(Kind::Carnivore, id).unwrap();
        o.traits.strength = 100.0;
        o.traits.speed = 16.0;
        o.traits.aggression = 1.0;
    }
    st.s.organisms.get_mut(Kind::Herbivore, h).unwrap().traits.strength = 0.0;
    let mut s = st.finish();
    s.record_events = true;
    let mut died = 0;
    let mut cause = None;
    let mut kills = 0;
    for _ in 0..30 {
        let r = s.step();
        kills += s.last_carnivore_stats.kills;
        for e in r.events {
            if let EventKind::Died { id, cause: c, .. } = e.kind {
                assert_eq!(id, h);
                died += 1;
                cause = Some(c);
            }
        }
    }
    assert_eq!(kills, 1);
    assert_eq!(died, 1);
    assert_eq!(cause, Some(DeathCause::Predation));
    assert_eq!(s.organisms.stats.deaths_by_cause[Kind::Herbivore.index()][DeathCause::Predation as usize], 1);
    assert_eq!(s.organisms.count(Kind::Herbivore), 0);
    assert!(s.organisms.get(Kind::Herbivore, h).is_none());
    // exactly one carnivore gained, the other did not (earlier id wins)
    assert!((cen(&s, a) - 100.0 - 40.0 * 1.0).abs() < 1e-9 || cen(&s, a) >= 100.0);
    assert!((cen(&s, b) - 100.0).abs() < 1e-9);
}

#[test]
fn dead_prey_cannot_be_killed_again_and_is_not_perceived() {
    let mut st = setup(&cfg(10, 10));
    let h = st.herb(p(5, 5), 40.0);
    let a = st.carn(p(5, 5), 0.1, 2.0, 100.0);
    assert!(st.s.organisms.mark_dead(h, DeathCause::Predation, 0));
    assert!(!st.s.organisms.mark_dead(h, DeathCause::Predation, 0));
    let mut s = st.finish();
    let e0 = cen(&s, a);
    s.step();
    assert_eq!(s.last_carnivore_stats.attacks, 0);
    assert!((cen(&s, a) - e0).abs() < 1e-12);
}

#[test]
fn energy_gain_never_exceeds_prey_energy() {
    for digestion in [1.0, 0.7, 0.3] {
        for prey_e in [0.0, 0.5, 10.0, 77.0, 100.0] {
            for room_e in [200.0, 150.0, 99.0] {
                let mut c = cfg(6, 6);
                c.carnivores.digestion_efficiency = digestion;
                let mut st = setup(&c);
                let h = st.herb(p(3, 3), prey_e);
                let car = st.carn(p(3, 3), 0.1, 2.0, room_e);
                {
                    let o = st.s.organisms.get_mut(Kind::Carnivore, car).unwrap();
                    o.traits.strength = 100.0;
                    o.traits.speed = 16.0;
                    o.traits.aggression = 1.0;
                    o.traits.speed = 0.1;
                }
                st.s.organisms.get_mut(Kind::Herbivore, h).unwrap().traits.strength = 0.0;
                let mut s = st.finish();
                let mut gained = 0.0;
                for _ in 0..200 {
                    let before = cen(&s, car);
                    s.step();
                    let st = s.last_carnivore_stats;
                    assert!(st.gained_energy <= st.prey_energy_taken + 1e-12);
                    assert!(cen(&s, car) - before <= st.prey_energy_taken + 1e-9);
                    gained += st.gained_energy;
                    if st.kills > 0 {
                        assert!((st.prey_energy_taken - prey_e).abs() < 1e-9);
                        break;
                    }
                }
                assert!(gained <= prey_e + 1e-9, "gained {} prey {}", gained, prey_e);
                assert!(gained <= (prey_e * digestion) + 1e-9);
            }
        }
    }
}

#[test]
fn hunting_costs_energy_on_success_and_failure() {
    for (str_, spd, agg, h_str, want_kill) in [(100.0, 16.0, 1.0, 0.0, true), (0.0, 0.1, 0.0, 100.0, false)] {
        let mut hit = 0;
        let mut miss = 0;
        for seed in 0..40 {
            let mut c = cfg(6, 6);
            c.seed = seed;
            c.carnivores.attack_cost = 2.0;
            let mut st = setup(&c);
            let h = st.herb(p(3, 3), 10.0);
            let car = st.carn(p(3, 3), 0.1, 2.0, 100.0);
            {
                let o = st.s.organisms.get_mut(Kind::Carnivore, car).unwrap();
                o.traits.strength = str_;
                o.traits.speed = spd;
                o.traits.aggression = agg;
            }
            st.s.organisms.get_mut(Kind::Herbivore, h).unwrap().traits.strength = h_str;
            let mut s = st.finish();
            s.step();
            let stt = s.last_carnivore_stats;
            assert_eq!(stt.attacks, 1);
            assert!((stt.attack_energy_paid - 2.0).abs() < 1e-12);
            if stt.kills == 1 {
                hit += 1;
                assert!((cen(&s, car) - (100.0 - 2.0 + 10.0)).abs() < 1e-9);
            } else {
                miss += 1;
                assert!((cen(&s, car) - 98.0).abs() < 1e-9);
            }
        }
        if want_kill {
            assert!(hit > 30, "hit {}", hit);
        } else {
            assert!(miss > 30, "miss {}", miss);
        }
    }
}

#[test]
fn carnivore_without_prey_starves() {
    let mut c = cfg(10, 10);
    c.carnivores.base_metabolism = 2.0;
    let mut st = setup(&c);
    let car = st.carn(p(2, 2), 1.0, 4.0, 10.0);
    st.s.organisms.get_mut(Kind::Carnivore, car).unwrap().traits.metabolism = 1.0;
    let mut s = st.finish();
    let mut last = cen(&s, car);
    let mut ticks = 0;
    while s.organisms.get(Kind::Carnivore, car).is_some() {
        s.step();
        ticks += 1;
        if let Some(o) = s.organisms.get(Kind::Carnivore, car) {
            assert!(o.energy() < last, "energy must fall every tick");
            last = o.energy();
        }
        assert!(ticks < 20);
    }
    assert_eq!(ticks, 5, "10 energy / 2 per tick");
    assert_eq!(s.organisms.stats.deaths_by_cause[Kind::Carnivore.index()][DeathCause::Starvation as usize], 1);
}

#[test]
fn rest_is_part_of_the_digest() {
    let mut st = setup(&cfg(10, 10));
    let car = st.carn(p(5, 5), 0.1, 2.0, 50.0);
    let s = st.finish();
    let mut t = s.clone();
    assert_eq!(t.digest(), s.digest());
    t.organisms.get_mut(Kind::Carnivore, car).unwrap().rest += 1;
    assert_ne!(t.digest(), s.digest());
}

#[test]
fn handling_time_blocks_next_attack_exactly() {
    let mut c = cfg(10, 10);
    c.carnivores.handling_time = 3;
    c.carnivores.attack_cost = 0.0;
    let mut st = setup(&c);
    let car = st.carn(p(5, 5), 0.1, 2.0, 50.0);
    {
        let o = st.s.organisms.get_mut(Kind::Carnivore, car).unwrap();
        o.traits.strength = 100.0;
        o.traits.aggression = 1.0;
    }
    for _ in 0..40 {
        let h = st.herb(p(5, 5), 5.0);
        let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
        o.traits.strength = 0.0;
        o.traits.speed = 0.1;
    }
    let mut s = st.finish();
    let mut last_kill: Option<u64> = None;
    for t in 0..40u64 {
        s.step();
        if s.last_carnivore_stats.attacks > 0 {
            if let Some(k) = last_kill {
                assert!(t >= k + 4, "attack at {} after kill at {}", t, k);
            }
        }
        if s.last_carnivore_stats.kills > 0 {
            last_kill = Some(t);
        }
        let o = s.organisms.get_mut(Kind::Carnivore, car).unwrap();
        o.set_energy(50.0);
        if last_kill.is_some() {
            // after a kill the rest counter is exactly handling_time and then counts down
            assert!(s.organisms.get(Kind::Carnivore, car).unwrap().rest <= 3);
        }
    }
    assert!(last_kill.is_some());
}

#[test]
fn multi_carnivore_later_one_retargets() {
    let mut st = setup(&cfg(12, 12));
    let h1 = st.herb(p(5, 5), 30.0);
    let h2 = st.herb(p(6, 5), 30.0);
    let mut cars = Vec::new();
    for _ in 0..2 {
        let car = st.carn(p(5, 5), 0.1, 3.0, 50.0);
        let o = st.s.organisms.get_mut(Kind::Carnivore, car).unwrap();
        o.traits.strength = 100.0;
        o.traits.aggression = 1.0;
        cars.push(car);
    }
    for h in [h1, h2] {
        let o = st.s.organisms.get_mut(Kind::Herbivore, h).unwrap();
        o.traits.strength = 0.0;
    }
    let mut s = st.finish();
    s.step();
    // both carnivores attacked in the same tick; kills never exceed prey and each prey dies at most once
    assert_eq!(s.last_carnivore_stats.attacks, 2);
    assert!(s.last_carnivore_stats.kills <= 2);
    let dead = s.organisms.stats.deaths_by_cause[Kind::Herbivore.index()][DeathCause::Predation as usize];
    assert_eq!(dead, s.last_carnivore_stats.kills);
}

#[test]
fn determinism_and_full_run_invariants() {
    let mut c = Config::default();
    c.world.width = 40;
    c.world.height = 40;
    c.initial.plants = 300;
    c.initial.herbivores = 80;
    c.initial.carnivores = 15;
    let run = || {
        let mut s = Simulation::new(&c).unwrap();
        let mut kills = 0;
        let mut taken = 0.0;
        let mut gained = 0.0;
        for _ in 0..300 {
            s.step();
            let st = s.last_carnivore_stats;
            kills += st.kills;
            taken += st.prey_energy_taken;
            gained += st.gained_energy;
            assert!(st.gained_energy <= st.prey_energy_taken + 1e-9);
            s.check_index().unwrap();
        }
        assert!(gained <= taken + 1e-6);
        (s.digest(), kills)
    };
    let (d1, k1) = run();
    let (d2, k2) = run();
    assert_eq!((d1, k1), (d2, k2));
    assert!(k1 > 0, "some kills over 300 ticks in a populated world");
}

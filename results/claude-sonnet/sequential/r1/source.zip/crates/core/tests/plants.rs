//! TASK-011: plant growth, resources, competition, deaths, genome influence (docs/PLANTS.md).
use evosim_core::config::Config;
use evosim_core::genome::{Gene, Genome, N_GENES};
use evosim_core::grid::Pos;
use evosim_core::organism::{DeathCause, Kind, NewBorn};
use evosim_core::plants::{temp_factor, PlantTraits};
use evosim_core::sim::Simulation;

/// Uniform climate: constant temperature `t`, flat precipitation `precip`, no seasons/noise.
fn cfg(t: f64, precip: f64) -> Config {
    let mut c = Config::default();
    c.seed = 3;
    c.world.width = 4;
    c.world.height = 4;
    c.initial.plants = 1; // one founder: the parent of the test plants (removed by `setup`)
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.equator_temp = t;
    c.climate.pole_temp = t;
    c.climate.seasonal_amplitude = 0.0;
    c.climate.seasonal_precip_amplitude = 0.0;
    c.climate.precip_mean = precip;
    c.climate.precip_latitude_variation = 0.0;
    c.climate.weather_noise = 0.0;
    c.climate.terrain_noise = 0.0;
    c.plants.maintenance = 0.0;
    c.plants.initial_energy = 1.0;
    c.plants.growth_rate = 0.8; // pinned: exact expectations below (defaults were retuned in TASK-018)
    c.plants.resource_uptake = 1.0;
    c.climate.resource_regen = 0.5;
    // These tests are about growth only: no seed can ever establish (reproduction is tested in plant_repro.rs).
    c.plants.establish_resource = 10_000.0;
    c
}

fn genome(edits: &[(Gene, f32)]) -> Genome {
    let mut a = [[0.5f32; 2]; N_GENES];
    for (g, v) in edits {
        a[g.index()] = [*v, *v];
    }
    Genome::from_alleles(a)
}

/// Creates the plants (pos, genome, energy) and removes the founder; returns their ids.
fn setup(c: &Config, plants: &[(Pos, Genome, f64)]) -> (Simulation, Vec<u64>) {
    let mut s = Simulation::new(c).unwrap();
    let parent = s.organisms.active_ids(Kind::Plant)[0];
    for (pos, g, e) in plants {
        assert!(s.organisms.queue_birth(NewBorn { kind: Kind::Plant, pos: *pos, parents: [parent, 0], genome: *g, energy: *e }));
    }
    s.organisms.resolve_births(0);
    s.organisms.vec_mut(Kind::Plant).retain(|o| o.id != parent);
    let ids = s.organisms.vec(Kind::Plant).iter().map(|o| o.id).collect();
    (s, ids)
}

fn energy(s: &Simulation, id: u64) -> f64 {
    s.organisms.get(Kind::Plant, id).map(|o| o.energy()).unwrap_or(f64::NAN)
}

/// Energy gained by one default plant over `n` ticks in a uniform climate (no upkeep).
fn gain_in(t: f64, precip: f64, n: u64) -> f64 {
    let (mut s, ids) = setup(&cfg(t, precip), &[(Pos { x: 1, y: 1 }, genome(&[]), 1.0)]);
    s.run(n);
    energy(&s, ids[0]) - 1.0
}

#[test]
fn factors_are_bounded_and_peak_at_optimum() {
    assert_eq!(temp_factor(20.0, 20.0, 12.0), 1.0);
    assert_eq!(temp_factor(32.0, 20.0, 12.0), 0.0);
    assert_eq!(temp_factor(-50.0, 20.0, 12.0), 0.0);
    assert!(temp_factor(26.0, 20.0, 12.0) > 0.0 && temp_factor(26.0, 20.0, 12.0) < 1.0);
}

#[test]
fn too_cold_or_too_dry_grows_less_than_favourable() {
    let fav = gain_in(20.0, 1.0, 10);
    let cold = gain_in(-10.0, 1.0, 10);
    let hot = gain_in(38.0, 1.0, 10);
    let dry = gain_in(20.0, 0.09, 10); // water factor 0.3
    let desert = gain_in(20.0, 0.0, 10);
    assert!(fav > 5.0, "favourable growth {fav}");
    assert_eq!(cold, 0.0, "no growth outside the temperature range");
    assert_eq!(hot, 0.0);
    assert!(dry > 0.0 && dry < fav * 0.5, "dry {dry} vs fav {fav}");
    assert_eq!(desert, 0.0);
    // intermediate temperature: slower than the optimum, faster than none
    let cool = gain_in(14.0, 1.0, 10);
    assert!(cool > 0.0 && cool < fav);
}

#[test]
fn world_temperature_is_the_driver() {
    let (s, _) = setup(&cfg(20.0, 1.0), &[]);
    assert!((s.world.temp_at(Pos { x: 0, y: 0 }) - 20.0).abs() < 1e-6);
}

#[test]
fn competition_limits_growth() {
    // all plants in one cell, regeneration the only inflow: total gain <= initial stock + regen
    let mut c = cfg(20.0, 1.0);
    c.climate.resource_regen = 0.2;
    c.climate.resource_max = 3.0;
    c.plants.cell_capacity = 1000;
    let cell = Pos { x: 2, y: 2 };
    let n = 10;
    let (mut s, ids) = setup(&c, &vec![(cell, genome(&[]), 1.0); n]);
    let (mut one, id1) = setup(&c, &[(cell, genome(&[]), 1.0)]);
    let stock0 = s.world.resource_at(cell);
    assert!(stock0 > 0.0);
    let ticks = 50u64;
    s.run(ticks);
    one.run(ticks);
    let total: f64 = ids.iter().map(|&i| energy(&s, i) - 1.0).sum();
    let regen_total = c.climate.resource_regen * ticks as f64; // W = 1 at precip 1.0 with need 0.3
    assert!(total <= stock0 + regen_total + 1e-9, "total {total} exceeds {}", stock0 + regen_total);
    let mean = total / n as f64;
    let solo = energy(&one, id1[0]) - 1.0;
    assert!(mean < solo, "crowded mean {mean} should be below solo {solo}");
    assert!(total >= solo, "more plants still use at least as much");
}

#[test]
fn crowding_slows_growth_when_over_capacity() {
    let mut c = cfg(20.0, 1.0);
    c.plants.cell_capacity = 2;
    let cell = Pos { x: 0, y: 0 };
    let (mut s, ids) = setup(&c, &vec![(cell, genome(&[]), 1.0); 8]);
    s.step();
    // 8 plants, capacity 2 -> crowd 0.25: each wants 0.8*0.25
    assert!((energy(&s, ids[0]) - 1.0 - 0.2).abs() < 1e-9);
}

#[test]
fn bounded_and_conserved_over_long_run() {
    let mut c = cfg(20.0, 1.0);
    c.world.width = 6;
    c.world.height = 6;
    c.plants.maintenance = 0.05;
    c.plants.max_age = 100_000;
    let plants: Vec<_> = (0..30).map(|i| (Pos { x: i % 6, y: (i / 6) % 6 }, genome(&[]), 5.0)).collect();
    let (mut s, _) = setup(&c, &plants);
    let n0 = s.organisms.count(Kind::Plant);
    let cap_total: f64 = (0..36).map(|i| s.world.resource_cap_at(s.world.grid.pos_of(i))).sum();
    for _ in 0..3000 {
        let before_stock = s.world.resource_total();
        let before_energy: f64 = s.organisms.vec(Kind::Plant).iter().map(|o| o.energy()).sum();
        s.step();
        let st = s.last_plant_stats;
        // stock accounting: delta = regen - removed
        let after_stock = s.world.resource_total();
        assert!((after_stock - (before_stock + st.regen - st.stock_removed)).abs() < 1e-6);
        // plants gain exactly what was removed (deaths are removed after; compare gain only)
        assert!((st.gain - st.stock_removed).abs() < 1e-9);
        assert!(st.upkeep >= 0.0);
        // energy accounting incl. removal of dead plants
        let after_energy: f64 = s.organisms.vec(Kind::Plant).iter().map(|o| o.energy()).sum();
        if s.last_deaths[0] == 0 {
            assert!((after_energy - (before_energy + st.gain - st.upkeep)).abs() < 1e-6);
        }
        assert!(after_stock >= -1e-12 && after_stock <= cap_total + 1e-9);
        assert!(s.organisms.count(Kind::Plant) <= n0, "reproduction is disabled in this helper config");
        for o in s.organisms.vec(Kind::Plant) {
            assert!(o.energy() >= 0.0 && o.energy() <= o.traits.max_energy);
        }
    }
}

#[test]
fn no_free_energy_without_resources() {
    let mut c = cfg(20.0, 1.0);
    c.climate.resource_regen = 0.0;
    c.plants.maintenance = 0.2;
    let cell = Pos { x: 1, y: 0 };
    let (mut s, ids) = setup(&c, &[(cell, genome(&[]), 3.0)]);
    s.world.set_resource(cell, 0.0);
    for _ in 0..40 {
        s.step();
        assert_eq!(s.last_plant_stats.gain, 0.0);
        assert_eq!(s.last_plant_stats.regen, 0.0);
    }
    assert!(s.organisms.get(Kind::Plant, ids[0]).is_none(), "plant must have starved");
    assert_eq!(s.organisms.stats.deaths_by_cause[0][DeathCause::Starvation.index()], 1);
}

#[test]
fn dies_of_old_age() {
    let mut c = cfg(20.0, 1.0);
    c.plants.max_age = 30;
    let (mut s, ids) = setup(&c, &[(Pos { x: 0, y: 0 }, genome(&[]), 10.0)]);
    s.run(60);
    assert!(s.organisms.get(Kind::Plant, ids[0]).is_none());
    assert_eq!(s.organisms.stats.deaths_by_cause[0][DeathCause::OldAge.index()], 1);
}

#[test]
fn dies_of_hostile_climate() {
    for (t, p) in [(-20.0, 1.0), (20.0, 0.0)] {
        let mut c = cfg(t, p);
        c.plants.max_age = 100_000;
        let (mut s, ids) = setup(&c, &[(Pos { x: 0, y: 0 }, genome(&[]), 40.0)]);
        s.run(200);
        assert!(s.organisms.get(Kind::Plant, ids[0]).is_none(), "t={t} p={p}");
        assert_eq!(s.organisms.stats.deaths_by_cause[0][DeathCause::Climate.index()], 1, "t={t} p={p}");
    }
    // a plant in a good climate never takes damage
    let (mut s, ids) = setup(&cfg(20.0, 1.0), &[(Pos { x: 0, y: 0 }, genome(&[]), 10.0)]);
    s.run(100);
    let o = s.organisms.get(Kind::Plant, ids[0]).unwrap();
    assert_eq!(o.health(), o.traits.max_health);
}

#[test]
fn genome_changes_growth_and_tolerance() {
    let at = |t: f64, p: f64, edits: &[(Gene, f32)]| {
        let (mut s, ids) = setup(&cfg(t, p), &[(Pos { x: 1, y: 1 }, genome(edits), 1.0)]);
        s.run(10);
        energy(&s, ids[0]) - 1.0
    };
    // thermal locus shifts the optimum: warm-adapted beats cold-adapted when hot, and vice versa
    let warm = [(Gene::Aggression, 1.0)];
    let cold = [(Gene::Aggression, 0.0)];
    assert!(at(28.0, 1.0, &warm) > at(28.0, 1.0, &cold));
    assert!(at(12.0, 1.0, &cold) > at(12.0, 1.0, &warm));
    // tolerance locus: a generalist survives a temperature a specialist cannot use
    let wide = [(Gene::RiskTolerance, 1.0)];
    let narrow = [(Gene::RiskTolerance, 0.0)];
    assert!(at(38.0, 1.0, &wide) > 0.0);
    assert_eq!(at(38.0, 1.0, &narrow), 0.0);
    // ...but the specialist peaks higher at the optimum (trade-off)
    assert!(at(20.0, 1.0, &narrow) > at(20.0, 1.0, &wide));
    // drought locus: low water need grows in dry cells where the default plant is limited
    let tough = [(Gene::Vision, 0.0)];
    assert!(at(20.0, 0.06, &tough) > at(20.0, 0.06, &[]));
    // size trait scales growth
    assert!(at(20.0, 1.0, &[(Gene::MaxEnergy, 1.0)]) > at(20.0, 1.0, &[]));
    // traits derived are pure functions of the genome
    let c = cfg(20.0, 1.0);
    let a = PlantTraits::from_genome(&genome(&warm), &c);
    assert!(a.temp_opt > c.plants.temp_optimum);
    assert_eq!(PlantTraits::from_genome(&genome(&[]), &c).temp_opt, c.plants.temp_optimum);
}

#[test]
fn drought_tolerance_costs_upkeep() {
    let mut c = cfg(20.0, 1.0);
    c.plants.maintenance = 0.1;
    c.climate.resource_regen = 0.0;
    let cell = Pos { x: 0, y: 0 };
    let (mut s, ids) = setup(&c, &[(cell, genome(&[(Gene::Vision, 0.0)]), 10.0), (Pos { x: 1, y: 0 }, genome(&[]), 10.0)]);
    s.world.set_resource(cell, 0.0);
    s.world.set_resource(Pos { x: 1, y: 0 }, 0.0);
    s.step();
    assert!(energy(&s, ids[0]) < energy(&s, ids[1]));
}

#[test]
fn deterministic_and_resources_in_digest() {
    let mk = |seed: i64| {
        let mut c = Config::default();
        c.seed = seed;
        c.world.width = 16;
        c.world.height = 16;
        c.initial.plants = 100;
        c.initial.herbivores = 5;
        c.initial.carnivores = 2;
        let mut s = Simulation::new(&c).unwrap();
        s.run(300);
        s
    };
    assert_eq!(mk(1).digest(), mk(1).digest());
    assert_ne!(mk(1).digest(), mk(2).digest());
    let mut a = mk(1);
    let d = a.digest();
    let p = Pos { x: 0, y: 0 };
    let v = a.world.resource_at(p);
    a.world.set_resource(p, if v > 1.0 { v - 1.0 } else { v + 0.5 });
    assert_ne!(a.digest(), d);
}

#[test]
fn seam_cells_use_same_rules() {
    // cells at x=0 and x=W-1 in a uniform climate grow identically
    let c = cfg(20.0, 1.0);
    let (mut s, ids) = setup(&c, &[(Pos { x: 0, y: 2 }, genome(&[]), 1.0), (Pos { x: 3, y: 2 }, genome(&[]), 1.0)]);
    s.run(20);
    assert!((energy(&s, ids[0]) - energy(&s, ids[1])).abs() < 1e-9);
}

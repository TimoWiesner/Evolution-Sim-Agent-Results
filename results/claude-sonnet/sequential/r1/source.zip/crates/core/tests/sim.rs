use evosim_core::config::Config;
use evosim_core::rng::Rng;
use evosim_core::sim::{tie_break_min, Phase, Simulation};

fn cfg(seed: i64) -> Config {
    let mut c = Config::default();
    c.seed = seed;
    c
}

fn trace(seed: i64, n: u64) -> Vec<u64> {
    let mut s = Simulation::new(&cfg(seed)).unwrap();
    (0..n).map(|_| { s.step(); s.digest() }).collect()
}

#[test]
fn same_seed_same_trace_200_ticks() {
    let a = trace(42, 200);
    let b = trace(42, 200);
    assert_eq!(a.len(), 200);
    assert_eq!(a, b);
}

#[test]
fn different_seed_different_trace() {
    let a = trace(1, 200);
    let b = trace(2, 200);
    assert_ne!(a[0], b[0]);
    assert_ne!(a[199], b[199]);
    // seed override on the config equals a fresh config with that seed
    let mut c = Config::default();
    c.seed = 99;
    c.seed = 2;
    let mut s = Simulation::new(&c).unwrap();
    let t: Vec<u64> = (0..200).map(|_| { s.step(); s.digest() }).collect();
    assert_eq!(t, b);
}

#[test]
fn step_advances_exactly_one_tick() {
    let mut s = Simulation::new(&cfg(5)).unwrap();
    assert_eq!(s.tick, 0);
    let r = s.step();
    assert_eq!((r.tick, s.tick), (0, 1));
    let r = s.step();
    assert_eq!((r.tick, s.tick), (1, 2));
    s.run(10);
    assert_eq!(s.tick, 12);
}

#[test]
fn phase_order_fixed() {
    use Phase::*;
    assert_eq!(Phase::ORDER, [Climate, Plants, Herbivores, Carnivores, Deaths, Births, Index]);
    let mut s = Simulation::new(&cfg(5)).unwrap();
    assert!(s.step().events.is_empty());
    s.record_events = true;
    for t in 1..4 {
        let r = s.step();
        let phases: Vec<Phase> = r.events.iter().filter(|e| e.kind == evosim_core::sim::EventKind::PhaseRun).map(|e| e.phase).collect(); // Born/Died events may also appear
        assert_eq!(phases, Phase::ORDER.to_vec());
        assert!(r.events.iter().all(|e| e.tick == t));
    }
}

#[test]
fn rng_checkpoint_resume() {
    let mut full = Simulation::new(&cfg(7)).unwrap();
    full.run(100);
    let mut a = Simulation::new(&cfg(7)).unwrap();
    a.run(50);
    let (st, tick, acc, wx) = (a.export_rng(), a.tick, a.acc, a.world.weather.clone());
    let mut b = Simulation::new(&cfg(7)).unwrap();
    assert!(b.restore_rng(st));
    b.tick = tick;
    b.acc = acc;
    b.world = a.world.clone(); // weather and per-cell resources are part of the state
    let _ = wx;
    b.organisms = a.organisms.clone();
    b.species = a.species.clone();
    b.rebuild_index();
    b.run(50);
    assert_eq!(b.digest(), full.digest());
    assert!(!b.restore_rng([0; 4]));
    // hex round trip too
    assert_eq!(Rng::from_hex(&a.rng.to_hex()).unwrap().state(), st);
}

#[test]
fn act_order_and_ties() {
    let s = Simulation::new(&cfg(1)).unwrap();
    assert_eq!(s.act_order(&[9, 2, 7, 2, 1]), vec![1, 2, 2, 7, 9]);
    assert_eq!(tie_break_min(&[(5, 2.0), (3, 1.0), (4, 1.0)]), Some(3));
    assert_eq!(tie_break_min(&[(8, 1u32), (6, 1), (7, 1)]), Some(6));
    assert_eq!(tie_break_min::<u32>(&[]), None);
}

#[test]
fn invalid_config_rejected() {
    let mut c = Config::default();
    c.world.width = 0;
    assert!(Simulation::new(&c).is_err());
}

#[test]
fn no_wall_clock_or_global_rng() {
    let dir = concat!(env!("CARGO_MANIFEST_DIR"), "/src");
    for e in std::fs::read_dir(dir).unwrap() {
        let p = e.unwrap().path();
        let text = std::fs::read_to_string(&p).unwrap();
        for bad in ["SystemTime", "Instant", "thread_rng", "rand::", "HashMap", "HashSet", "evosim_ui", "evosim_cli"] {
            assert!(!text.contains(bad), "{} contains {}", p.display(), bad);
        }
    }
    let toml = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/Cargo.toml")).unwrap();
    let deps = toml.split("[dependencies]").nth(1).unwrap();
    assert!(deps.lines().all(|l| l.trim().is_empty() || l.trim().starts_with('#')), "{}", deps);
}

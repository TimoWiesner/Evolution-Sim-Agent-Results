use evosim_core::climate::ClimateBounds;
use evosim_core::config::Config;
use evosim_core::grid::Pos;
use evosim_core::rng::Rng;
use evosim_core::sim::Simulation;

fn cfg(w: u32, h: u32, seed: i64, len: u32, noise: f64) -> Config {
    let mut c = Config::default();
    c.world.width = w;
    c.world.height = h;
    c.seed = seed;
    c.climate.season_length = len;
    c.climate.weather_noise = noise;
    c
}

fn cells(s: &Simulation) -> Vec<Pos> {
    let (w, h) = (s.world.grid.width() as i32, s.world.grid.height() as i32);
    (0..h).flat_map(|y| (0..w).map(move |x| Pos { x, y })).collect()
}

#[test]
fn weather_off_year_repeats_exactly() {
    for len in [2u32, 7, 50, 200] {
        let c = cfg(20, 12, 5, len, 0.0);
        let mut s = Simulation::new(&c).unwrap();
        let ps = cells(&s);
        let mut series: Vec<Vec<(f64, f64)>> = Vec::new();
        for _ in 0..(3 * len) {
            s.step();
            series.push(ps.iter().map(|&p| (s.world.temp_at(p), s.world.precip_at(p))).collect());
        }
        let l = len as usize;
        for t in 0..l {
            assert_eq!(series[t], series[t + l], "len {} t {}", len, t);
            assert_eq!(series[t], series[t + 2 * l]);
            // the pure function agrees too
            for &p in &ps {
                assert_eq!(s.world.climate.seasonal_temp_at(p, t as u64), s.world.climate.seasonal_temp_at(p, (t + 3 * l) as u64));
                assert_eq!(s.world.climate.seasonal_precip_at(p, t as u64), s.world.climate.seasonal_precip_at(p, (t + l) as u64));
            }
        }
        assert_eq!(s.world.climate_tick(), 3 * l as u64 - 1);
    }
}

fn series(c: &Config, n: u64) -> Vec<f64> {
    let mut s = Simulation::new(c).unwrap();
    let p = Pos { x: 3, y: 4 };
    (0..n).map(|_| { s.step(); s.world.temp_at(p) + s.world.precip_at(p) }).collect()
}

#[test]
fn weather_on_differs_and_is_seeded() {
    let c = cfg(20, 12, 5, 30, 0.3);
    let a = series(&c, 90);
    assert_ne!(a[0..30], a[30..60]);
    assert_eq!(a, series(&c, 90));
    let mut d = c.clone();
    d.seed = 6;
    assert_ne!(a, series(&d, 90));
    let (mut s1, mut s2) = (Simulation::new(&c).unwrap(), Simulation::new(&c).unwrap());
    s1.run(100);
    s2.run(100);
    assert_eq!(s1.digest(), s2.digest());
}

#[test]
fn bounds_hold() {
    for (w, h, seed) in [(1, 1, 1), (1, 17, 2), (23, 1, 3), (40, 30, 4)] {
        let mut c = cfg(w, h, seed, 40, 1.0);
        c.climate.seasonal_amplitude = 40.0;
        c.climate.seasonal_precip_amplitude = 0.95;
        c.climate.terrain_noise = 1.0;
        c.climate.weather_period = 3;
        c.climate.precip_mean = 5.0;
        c.climate.precip_latitude_variation = 1.0;
        let b = ClimateBounds::from_config(&c);
        let mut s = Simulation::new(&c).unwrap();
        let ps = cells(&s);
        for _ in 0..3000 {
            s.step();
            for &p in &ps {
                let (t, pr) = (s.world.temp_at_raw(p), s.world.precip_at_raw(p));
                assert!(t >= b.temp_min && t <= b.temp_max, "temp {} {:?}", t, b);
                assert!(pr >= 0.0 && pr <= b.precip_max, "precip {}", pr);
                assert_eq!(s.world.temp_at(p), t);
                assert_eq!(s.world.precip_at(p), pr);
            }
        }
    }
}

#[test]
fn seasonal_cycle_shape() {
    let c = cfg(8, 48, 1, 100, 0.0);
    let s = Simulation::new(&c).unwrap();
    let m = &s.world.climate;
    let swing = |y: i32| {
        let p = Pos { x: 0, y };
        let v: Vec<f64> = (0..100).map(|t| m.seasonal_temp_at(p, t)).collect();
        let (mn, mx) = v.iter().fold((f64::MAX, f64::MIN), |a, &x| (a.0.min(x), a.1.max(x)));
        let mean = v.iter().sum::<f64>() / 100.0;
        assert!((mean - m.temp_at(p)).abs() < 1e-9);
        let argmin = v.iter().position(|&x| x == mn).unwrap();
        let argmax = v.iter().position(|&x| x == mx).unwrap();
        assert_eq!((argmin, argmax), (0, 50));
        mx - mn
    };
    assert!(swing(0) > swing(24));
    let pswing = |y: i32| {
        let p = Pos { x: 0, y };
        let v: Vec<f64> = (0..100).map(|t| m.seasonal_precip_at(p, t) / m.precip_at(p)).collect();
        assert!((v.iter().sum::<f64>() / 100.0 - 1.0).abs() < 1e-9);
        v.iter().cloned().fold(f64::MIN, f64::max) - v.iter().cloned().fold(f64::MAX, f64::min)
    };
    assert!(pswing(24) > pswing(0));
    let mut z = c.clone();
    z.climate.seasonal_amplitude = 0.0;
    z.climate.seasonal_precip_amplitude = 0.0;
    let s0 = Simulation::new(&z).unwrap();
    let p = Pos { x: 2, y: 5 };
    for t in [0u64, 13, 77] {
        assert_eq!(s0.world.climate.seasonal_temp_at(p, t), s0.world.climate.temp_at(p));
        assert_eq!(s0.world.climate.seasonal_precip_at(p, t), s0.world.climate.precip_at(p));
    }
}

#[test]
fn weather_is_seam_smooth() {
    let c = cfg(64, 48, 11, 100, 1.0);
    let mut s = Simulation::new(&c).unwrap();
    s.run(30);
    let (w, h) = (64i32, 48i32);
    let d = |a: Pos, b: Pos| (s.world.temp_at_raw(a) - s.world.temp_at_raw(b)).abs();
    let (mut seam_x, mut seam_y, mut interior) = (0f64, 0f64, 0f64);
    for y in 0..h {
        seam_x = seam_x.max(d(Pos { x: w - 1, y }, Pos { x: 0, y }));
        for x in 0..w - 1 {
            interior = interior.max(d(Pos { x, y }, Pos { x: x + 1, y }));
        }
    }
    for x in 0..w {
        // the base climate is mirrored at the y seam, so the weather part is what we compare
        let a = Pos { x, y: h - 1 };
        let b = Pos { x, y: 0 };
        let dw = |p: Pos| s.world.temp_at_raw(p) - s.world.climate.seasonal_temp_at(p, s.world.climate_tick());
        seam_y = seam_y.max((dw(a) - dw(b)).abs());
    }
    assert!(seam_x <= interior * 1.5 + 1e-9, "{} {}", seam_x, interior);
    assert!(seam_y <= 6.0 * 0.6, "{}", seam_y);
}

#[test]
fn state_carries_over() {
    let c = cfg(30, 20, 8, 40, 0.5);
    let mut a = Simulation::new(&c).unwrap();
    a.run(37);
    let mut b = a.clone();
    a.run(60);
    b.run(60);
    assert_eq!(a.digest(), b.digest());
    // perturbing one weather node changes the digest and later weather
    let mut p = a.clone();
    let d0 = p.digest();
    p.world.weather.t[0] += 0.5;
    assert_ne!(p.digest(), d0);
    let mut q = a.clone();
    p.run(5);
    q.run(5);
    assert_ne!(p.digest(), q.digest());
    // state words round trip lets a fresh sim continue identically
    let words = a.world.weather.state_words();
    let mut r = Simulation::new(&c).unwrap();
    r.world.weather = evosim_core::climate::Weather::from_state_words(&words).unwrap();
    assert!(r.restore_rng(a.export_rng()));
    r.tick = a.tick;
    r.acc = a.acc;
    r.organisms = a.organisms.clone();
    r.species = a.species.clone();
    r.rebuild_index();
    r.world.copy_resources_from(&a.world);
    assert_eq!(r.digest(), a.digest());
    r.run(20);
    a.run(20);
    assert_eq!(r.digest(), a.digest());
}

#[test]
fn query_any_tick() {
    let c = cfg(16, 16, 2, 123, 0.2);
    let s = Simulation::new(&c).unwrap();
    let b = ClimateBounds::from_config(&c);
    let big = (1u64 << 40) + 12345;
    for p in cells(&s) {
        for t in [0u64, 1, 122, 123, big, u64::MAX] {
            let (tt, pp) = (s.world.climate.seasonal_temp_at(p, t), s.world.climate.seasonal_precip_at(p, t));
            assert!(tt.is_finite() && tt >= b.temp_min && tt <= b.temp_max);
            assert!(pp.is_finite() && pp >= 0.0 && pp <= b.precip_max);
        }
    }
    // current query follows the stepped tick
    let mut s = s;
    let p = Pos { x: 1, y: 2 };
    s.run(10);
    assert_eq!(s.world.climate_tick(), 9);
    assert!(s.world.temp_at(p).is_finite());
}

#[test]
fn weather_strength_does_not_shift_rng() {
    // No organisms: plant seeding (TASK-012) legitimately draws RNG depending on weather-driven state.
    let mut ca = cfg(24, 16, 3, 50, 0.0);
    let mut cb = cfg(24, 16, 3, 50, 0.5);
    for c in [&mut ca, &mut cb] {
        c.initial.plants = 0;
        c.initial.herbivores = 0;
        c.initial.carnivores = 0;
    }
    let mut a = Simulation::new(&ca).unwrap();
    let mut b = Simulation::new(&cb).unwrap();
    a.run(100);
    b.run(100);
    assert_eq!(a.export_rng(), b.export_rng());
    let _ = Rng::new(1);
}

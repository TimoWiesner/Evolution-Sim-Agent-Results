//! Scratch trace: example trace -- config.json ticks every
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;
fn main() {
    let a: Vec<String> = std::env::args().skip(1).collect();
    let c = Config::from_json(&std::fs::read_to_string(&a[0]).unwrap()).unwrap();
    let n: u64 = a[1].parse().unwrap();
    let ev: u64 = a[2].parse().unwrap();
    let mut s = Simulation::new(&c).unwrap();
    for t in 0..=n {
        if t % ev == 0 {
            let p = s.last_plant_stats;
            let pl: f64 = s.organisms.vec(Kind::Plant).iter().map(|o| o.energy()).sum::<f64>() / (s.organisms.count(Kind::Plant).max(1) as f64);
            println!("{} P{} H{} C{} | pe {:.1} regen {:.1} gain {:.1} up {:.1} stressed {} att {} born {} room {} res {} clim {} | hb {} cb {}", t, s.organisms.count(Kind::Plant), s.organisms.count(Kind::Herbivore), s.organisms.count(Kind::Carnivore), pl, p.regen, p.gain, p.upkeep, p.stressed, p.attempts, p.born, p.blocked_room, p.blocked_resource, p.blocked_climate, s.organisms.stats.births[1], s.organisms.stats.births[2]);
        }
        s.step();
    }
}

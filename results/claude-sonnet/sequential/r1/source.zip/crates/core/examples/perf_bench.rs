//! Reproducible tick-rate benchmark (ADR-0030, docs/PERFORMANCE.md).
//! `cargo run --release -p evosim-core --example perf_bench -- [--config FILE] [--warmup N] [--ticks N] [--repeat R] [--profile] [--allow-small]`
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::sim::{Phase, Simulation};
use std::time::Instant;

#[derive(Default)]
struct PhaseTimes {
    nanos: [u64; 7],
    ticks: u64,
}

fn main() {
    let mut path = "examples/perf.json".to_string();
    let (mut warmup, mut ticks, mut repeat) = (300u64, 1000u64, 3usize);
    let (mut profile, mut allow_small) = (false, false);
    let a: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < a.len() {
        match a[i].as_str() {
            "--config" => { i += 1; path = a[i].clone(); }
            "--warmup" => { i += 1; warmup = a[i].parse().expect("--warmup"); }
            "--ticks" => { i += 1; ticks = a[i].parse().expect("--ticks"); }
            "--repeat" => { i += 1; repeat = a[i].parse().expect("--repeat"); }
            "--profile" => profile = true,
            "--allow-small" => allow_small = true,
            o => { eprintln!("unknown argument {o}"); std::process::exit(2); }
        }
        i += 1;
    }
    let text = std::fs::read_to_string(&path).expect("read config");
    let cfg = Config::from_json(&text).expect("config");
    let mut rates = Vec::new();
    let (mut omin, mut omax, mut osum, mut on) = (usize::MAX, 0usize, 0u64, 0u64);
    let mut hash = String::new();
    let mut times = PhaseTimes::default();
    for _ in 0..repeat {
        let mut s = Simulation::new(&cfg).unwrap();
        s.run(warmup);
        let mut t = PhaseTimes::default();
        let start = Instant::now();
        for _ in 0..ticks {
            if profile {
                let mut st = Instant::now();
                s.step_hooked(&mut |p, before| {
                    if before { st = Instant::now(); } else { t.nanos[p as usize] += st.elapsed().as_nanos() as u64; }
                });
                t.ticks += 1;
            } else {
                s.step();
            }
            let n: usize = Kind::ALL.iter().map(|k| s.organisms.count(*k)).sum();
            omin = omin.min(n);
            omax = omax.max(n);
            osum += n as u64;
            on += 1;
        }
        let e = start.elapsed().as_secs_f64();
        rates.push(ticks as f64 / e);
        if profile { for k in 0..7 { times.nanos[k] += t.nanos[k]; } times.ticks += t.ticks; }
        hash = s.state_hash();
    }
    let mut sorted = rates.clone();
    sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let median = sorted[sorted.len() / 2];
    let r: Vec<String> = rates.iter().map(|x| format!("{x:.1}")).collect();
    println!(
        "{{\"config\":\"{}\",\"warmup\":{},\"ticks\":{},\"repeat\":{},\"ticks_per_second\":[{}],\"median_ticks_per_second\":{:.1},\"organisms_min\":{},\"organisms_mean\":{:.0},\"organisms_max\":{},\"state_hash\":\"{}\"}}",
        path, warmup, ticks, repeat, r.join(","), median, omin, osum as f64 / on as f64, omax, hash
    );
    if profile {
        let total: u64 = times.nanos.iter().sum();
        for (k, p) in Phase::ORDER.iter().enumerate() {
            println!("  {:<11}{:>6.1}%  {:>9.1} us/tick", p.name(), 100.0 * times.nanos[k] as f64 / total as f64, times.nanos[k] as f64 / times.ticks as f64 / 1000.0);
        }
    }
    if omin < 2000 && !allow_small {
        eprintln!("min organisms {omin} < 2000 (use --allow-small)");
        std::process::exit(1);
    }
}

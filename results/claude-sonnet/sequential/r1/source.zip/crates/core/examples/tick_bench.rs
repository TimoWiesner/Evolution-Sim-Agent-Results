//! Tick-rate check: `cargo run --release -p evosim-core --example tick_bench`
use evosim_core::config::Config;
use evosim_core::sim::Simulation;
fn main() {
    let mut c = Config::default();
    c.world.width = 128;
    c.world.height = 128;
    c.initial.plants = 1500;
    c.initial.herbivores = 400;
    c.initial.carnivores = 100;
    let mut s = Simulation::new(&c).unwrap();
    let t = std::time::Instant::now();
    s.run(300);
    let e = t.elapsed().as_secs_f64();
    println!("300 ticks in {:.3}s ({:.0} ticks/s), plants {} herb {} carn {}", e, 300.0 / e, s.organisms.count(evosim_core::organism::Kind::Plant), s.organisms.count(evosim_core::organism::Kind::Herbivore), s.organisms.count(evosim_core::organism::Kind::Carnivore));
}

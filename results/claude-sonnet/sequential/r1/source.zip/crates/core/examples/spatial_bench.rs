//! Release-mode timing: spatial index vs brute force (~2,000 organisms).
//! Run: cargo run --release -p evosim-core --example spatial_bench
use evosim_core::grid::{Grid, Pos};
use evosim_core::organism::Kind;
use evosim_core::rng::Rng;
use evosim_core::spatial::SpatialIndex;
use std::hint::black_box;
use std::time::Instant;

fn main() {
    let (w, h, n, queries) = (128u32, 128u32, 2000u64, 20000usize);
    let grid = Grid::new(w, h).unwrap();
    let mut rng = Rng::new(1);
    let mut idx = SpatialIndex::new(grid);
    let mut list = Vec::new();
    for id in 1..=n {
        let k = Kind::ALL[rng.below(3) as usize];
        let p = Pos { x: rng.below(w as u64) as i32, y: rng.below(h as u64) as i32 };
        idx.insert(id, k, p).unwrap();
        list.push((id, k, p));
    }
    let centers: Vec<Pos> = (0..queries).map(|_| Pos { x: rng.below(w as u64) as i32, y: rng.below(h as u64) as i32 }).collect();
    println!("organisms={} grid={}x{} queries/radius={}", n, w, h, queries);
    for r in [3i64, 5, 8, 16] {
        let t = Instant::now();
        let mut tot = 0usize;
        let mut buf = Vec::new();
        for &c in &centers {
            idx.query_into(c, r, None, &mut buf);
            tot += black_box(buf.len());
        }
        let ti = t.elapsed();
        let t = Instant::now();
        let mut tot2 = 0usize;
        for &c in &centers {
            let mut v: Vec<(u32, usize, u64)> = list
                .iter()
                .map(|&(id, k, p)| (grid.dist(c, p), k.index(), id))
                .filter(|x| x.0 as i64 <= r)
                .collect();
            v.sort_unstable();
            tot2 += black_box(v.len());
        }
        let tb = t.elapsed();
        assert_eq!(tot, tot2);
        println!(
            "radius={:>2} index={:>8.2}ms brute={:>8.2}ms speedup={:>6.1}x hits/query={:.1}",
            r,
            ti.as_secs_f64() * 1e3,
            tb.as_secs_f64() * 1e3,
            tb.as_secs_f64() / ti.as_secs_f64(),
            tot as f64 / queries as f64
        );
    }
}

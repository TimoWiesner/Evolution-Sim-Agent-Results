//! Sanity run for TASK-014: `cargo run --release -p evosim-core --example herb_sanity`
use evosim_core::config::Config;
use evosim_core::organism::Kind;
use evosim_core::sim::Simulation;
fn main() {
    let mut c = Config::default();
    c.world.width = 64;
    c.world.height = 64;
    c.initial.plants = 1500;
    c.initial.herbivores = 150;
    c.initial.carnivores = 0;
    if let Some(b) = std::env::args().nth(1) { c.herbivores.bite_size = b.parse().unwrap(); }
    let mut s = Simulation::new(&c).unwrap();
    println!("tick plants herbivores eaten gained upkeep");
    for t in 0..=1000u64 {
        if t % 100 == 0 {
            let h = s.last_herbivore_stats;
            println!("{} {} {} {:.1} {:.1} {:.1}", t, s.organisms.count(Kind::Plant), s.organisms.count(Kind::Herbivore), h.eaten_energy, h.gained_energy, h.upkeep_paid);
        }
        s.step();
    }
}

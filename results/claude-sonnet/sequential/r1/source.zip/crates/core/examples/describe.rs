fn main() {
    print!("{}", evosim_core::config::describe());
}

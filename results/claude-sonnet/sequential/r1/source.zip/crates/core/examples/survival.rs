//! Survival report: `cargo run --release -p evosim-core --example survival -- [ticks=10000] [seeds=5] [config.json]`
//! Runs the default parameters (or the given config; fixed keys only is fine) with seeds 1..=seeds.
use evosim_core::config::Config;
use evosim_core::ecology::{format_reports, run_survival};

fn main() {
    let a: Vec<String> = std::env::args().skip(1).collect();
    let ticks: u64 = a.first().map(|v| v.parse().expect("ticks")).unwrap_or(10000);
    let seeds: i64 = a.get(1).map(|v| v.parse().expect("seeds")).unwrap_or(5);
    let base = match a.get(2) {
        Some(p) => Config::from_json(&std::fs::read_to_string(p).expect("read config")).expect("config"),
        None => Config::default(),
    };
    let mut reports = Vec::new();
    for seed in 1..=seeds {
        let mut c = base.clone();
        c.seed = seed;
        reports.push(run_survival(&c, ticks).expect("run"));
    }
    print!("{}", format_reports(&reports));
}

//! Print the base biome map without a UI: `biome_map W H SEED [--json]`.
use evosim_core::climate::ClimateMap;
use evosim_core::config::Config;

fn main() {
    let a: Vec<String> = std::env::args().skip(1).collect();
    let num = |i: usize, d: i64| a.get(i).and_then(|s| s.parse::<i64>().ok()).unwrap_or(d);
    let mut cfg = Config::default();
    cfg.world.width = num(0, 64).clamp(1, 4096) as u32;
    cfg.world.height = num(1, 48).clamp(1, 4096) as u32;
    cfg.seed = num(2, 42);
    let m = ClimateMap::generate(&cfg);
    if a.iter().any(|s| s == "--json") {
        println!("{}", m.to_json());
    } else {
        print!("{}", m.to_ascii());
    }
}

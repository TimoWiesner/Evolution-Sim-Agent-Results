//! Organisms and the shared life cycle (ADR-0012).
//!
//! # Same-tick birth/death rule (the one documented rule)
//! Behaviour phases only *defer*: `mark_dead` flags an organism dead at once (it never acts again,
//! `active_ids` skips it, `queue_birth` rejects it as parent) and `queue_birth` records a newborn.
//! Deaths phase (`resolve_deaths`): age +1, automatic death checks, then every dead organism is removed
//! and counted exactly once. Births phase (`resolve_births`): queued newborns get fresh ids in queue order,
//! are appended and counted. Hence deaths are evaluated before births, newborns neither age nor die in
//! their birth tick, and a parent that dies in the same tick still appears in the newborn's `parents`.

use crate::config::Config;
use crate::genome::Genome;
use crate::grid::{Grid, Pos};
use crate::rng::Rng;

pub type Id = u64;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Kind {
    Plant,
    Herbivore,
    Carnivore,
}

impl Kind {
    pub const ALL: [Kind; 3] = [Kind::Plant, Kind::Herbivore, Kind::Carnivore];
    pub fn index(self) -> usize {
        self as usize
    }
    pub fn name(self) -> &'static str {
        match self {
            Kind::Plant => "plant",
            Kind::Herbivore => "herbivore",
            Kind::Carnivore => "carnivore",
        }
    }
    pub fn from_index(i: u8) -> Option<Kind> {
        Kind::ALL.get(i as usize).copied()
    }
    pub fn is_animal(self) -> bool {
        self != Kind::Plant
    }
}

/// Append-only list of causes of death.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DeathCause {
    OldAge,
    Starvation,
    Injury,
    Predation,
    Other,
    Climate,
}

pub const N_CAUSES: usize = 6;

impl DeathCause {
    pub const ALL: [DeathCause; N_CAUSES] =
        [DeathCause::OldAge, DeathCause::Starvation, DeathCause::Injury, DeathCause::Predation, DeathCause::Other, DeathCause::Climate];
    pub fn index(self) -> usize {
        self as usize
    }
    pub fn from_index(i: u8) -> Option<DeathCause> {
        DeathCause::ALL.get(i as usize).copied()
    }
    pub fn name(self) -> &'static str {
        match self {
            DeathCause::OldAge => "old_age",
            DeathCause::Starvation => "starvation",
            DeathCause::Injury => "injury",
            DeathCause::Predation => "predation",
            DeathCause::Other => "other",
            DeathCause::Climate => "climate",
        }
    }
}

/// Inclusive trait range.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Range {
    pub lo: f64,
    pub hi: f64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TraitRanges {
    pub speed: Range,
    pub strength: Range,
    pub fertility: Range,
    pub max_health: Range,
    pub max_lifespan: Range,
    pub max_energy: Range,
    pub metabolism: Range,
    pub vision: Range,
    pub aggression: Range,
    pub risk_tolerance: Range,
}

const fn r(lo: f64, hi: f64) -> Range {
    Range { lo, hi }
}

const PLANT_RANGES: TraitRanges = TraitRanges {
    speed: r(0.0, 0.0),
    strength: r(0.0, 100.0),
    fertility: r(0.0, 1.0),
    max_health: r(0.1, 10000.0),
    max_lifespan: r(1.0, 1_000_000.0),
    max_energy: r(0.1, 10000.0),
    metabolism: r(0.25, 4.0),
    vision: r(0.0, 0.0),
    aggression: r(0.0, 0.0),
    risk_tolerance: r(0.0, 0.0),
};

const ANIMAL_RANGES: TraitRanges = TraitRanges {
    speed: r(0.1, 16.0),
    strength: r(0.0, 100.0),
    fertility: r(0.0, 1.0),
    max_health: r(0.1, 10000.0),
    max_lifespan: r(1.0, 1_000_000.0),
    max_energy: r(0.1, 10000.0),
    metabolism: r(0.25, 4.0),
    vision: r(1.0, 64.0),
    aggression: r(0.0, 1.0),
    risk_tolerance: r(0.0, 1.0),
};

fn clamp(v: f64, rg: Range) -> f64 {
    if v.is_nan() {
        rg.lo
    } else {
        v.max(rg.lo).min(rg.hi)
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Traits {
    pub speed: f64,
    pub strength: f64,
    pub fertility: f64,
    pub max_health: f64,
    pub max_lifespan: u32,
    pub max_energy: f64,
    pub metabolism: f64,
    pub vision: f64,
    pub aggression: f64,
    pub risk_tolerance: f64,
}

impl Traits {
    pub fn range(kind: Kind) -> TraitRanges {
        if kind.is_animal() {
            ANIMAL_RANGES
        } else {
            PLANT_RANGES
        }
    }

    /// Forces every trait into the range of `kind` (NaN -> range minimum).
    pub fn clamped(mut self, kind: Kind) -> Traits {
        let g = Traits::range(kind);
        self.speed = clamp(self.speed, g.speed);
        self.strength = clamp(self.strength, g.strength);
        self.fertility = clamp(self.fertility, g.fertility);
        self.max_health = clamp(self.max_health, g.max_health);
        self.max_lifespan = clamp(self.max_lifespan as f64, g.max_lifespan) as u32;
        self.max_energy = clamp(self.max_energy, g.max_energy);
        self.metabolism = clamp(self.metabolism, g.metabolism);
        self.vision = clamp(self.vision, g.vision);
        self.aggression = clamp(self.aggression, g.aggression);
        self.risk_tolerance = clamp(self.risk_tolerance, g.risk_tolerance);
        self
    }

    /// Founder traits from the config keys of the kind.
    pub fn baseline(kind: Kind, cfg: &Config) -> Traits {
        let t = match kind {
            Kind::Plant => Traits {
                speed: 0.0,
                strength: 0.0,
                fertility: 0.5,
                max_health: 10.0,
                max_lifespan: cfg.plants.max_age,
                max_energy: cfg.plants.max_energy,
                metabolism: 1.0,
                vision: 0.0,
                aggression: 0.0,
                risk_tolerance: 0.0,
            },
            _ => {
                let a = if kind == Kind::Herbivore { &cfg.herbivores } else { &cfg.carnivores };
                Traits {
                    speed: a.speed,
                    strength: a.strength,
                    fertility: 0.5,
                    max_health: a.health,
                    max_lifespan: a.max_age,
                    max_energy: a.max_energy,
                    metabolism: 1.0,
                    vision: a.vision as f64,
                    aggression: a.aggression,
                    risk_tolerance: a.risk_tolerance,
                }
            }
        };
        t.clamped(kind)
    }

    fn words(&self, f: &mut dyn FnMut(u64)) {
        for v in [
            self.speed,
            self.strength,
            self.fertility,
            self.max_health,
            self.max_energy,
            self.metabolism,
            self.vision,
            self.aggression,
            self.risk_tolerance,
        ] {
            f(v.to_bits());
        }
        f(self.max_lifespan as u64);
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Death {
    pub tick: u64,
    pub cause: DeathCause,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Organism {
    pub id: Id,
    pub kind: Kind,
    pub pos: Pos,
    pub age: u32,
    energy: f64,
    health: f64,
    pub traits: Traits,
    genome: Genome,
    /// 0 = none. Founders [0,0]; plants/asexual use only parents[0].
    pub parents: [Id; 2],
    pub generation: u32,
    pub birth_tick: u64,
    pub alive: bool,
    pub death: Option<Death>,
    /// Fractional movement allowance carried between ticks, in [0,1) (TASK-013).
    pub move_credit: f64,
    /// Wander heading: 0 none, 1..=8 king directions (see `movement::DIRS`).
    pub heading: u8,
    /// Ticks left of handling time after a kill (TASK-015); a resting carnivore neither hunts nor moves.
    pub rest: u32,
    /// Ticks until the animal may reproduce again (TASK-016).
    pub cooldown: u32,
    /// Species id (TASK-017, ADR-0021); 0 = unassigned.
    pub species: u32,
}

/// The single cell-sharing rule (ADR-0017): max organisms of `kind` per cell, `None` = unlimited.
pub fn cell_limit(cfg: &Config, kind: Kind) -> Option<u32> {
    match kind {
        Kind::Plant => Some(cfg.plants.cell_capacity),
        _ => None,
    }
}

impl Organism {
    #[allow(clippy::too_many_arguments)]
    fn new(id: Id, kind: Kind, pos: Pos, genome: Genome, baseline: &Traits, energy: f64, parents: [Id; 2], generation: u32, tick: u64) -> Organism {
        let traits = genome.traits(kind, baseline);
        let mut o = Organism {
            id,
            kind,
            pos,
            age: 0,
            energy: 0.0,
            health: traits.max_health,
            traits,
            genome,
            parents,
            generation,
            birth_tick: tick,
            alive: true,
            death: None,
            move_credit: 0.0,
            heading: 0,
            rest: 0,
            cooldown: 0,
            species: 0,
        };
        o.set_energy(energy);
        o
    }

    /// Heritable genome (immutable after birth); `traits` are always derived from it.
    pub fn genome(&self) -> &Genome {
        &self.genome
    }

    pub fn energy(&self) -> f64 {
        self.energy
    }
    pub fn health(&self) -> f64 {
        self.health
    }
    pub fn is_active(&self) -> bool {
        self.alive
    }

    /// Sets energy clamped to [0, max_energy]; NaN -> 0.
    pub fn set_energy(&mut self, e: f64) {
        self.energy = if e.is_nan() { 0.0 } else { e.max(0.0).min(self.traits.max_energy) };
    }

    /// Adds (or with a negative delta removes) energy; returns the change actually applied.
    pub fn add_energy(&mut self, delta: f64) -> f64 {
        if delta.is_nan() {
            return 0.0;
        }
        let before = self.energy;
        self.set_energy(before + delta);
        self.energy - before
    }

    /// Reduces health (non-positive amounts ignored); returns the amount actually removed.
    pub fn damage(&mut self, amount: f64) -> f64 {
        if amount.is_nan() || amount <= 0.0 {
            return 0.0;
        }
        let before = self.health;
        self.health = (before - amount).max(0.0).min(self.traits.max_health);
        before - self.health
    }

    /// Restores health (non-positive amounts ignored); returns the amount actually restored.
    pub fn heal(&mut self, amount: f64) -> f64 {
        if amount.is_nan() || amount <= 0.0 {
            return 0.0;
        }
        let before = self.health;
        self.health = (before + amount).min(self.traits.max_health);
        self.health - before
    }
}

/// A birth queued by a behaviour phase.
#[derive(Clone, Debug, PartialEq)]
pub struct NewBorn {
    pub kind: Kind,
    pub pos: Pos,
    pub parents: [Id; 2],
    pub genome: Genome,
    pub energy: f64,
}

#[derive(Clone, Debug, PartialEq)]
struct Pending {
    nb: NewBorn,
    generation: u32,
    species: u32,
}

/// Cumulative counters since tick 0.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct LifeStats {
    pub founded: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    pub deaths_by_cause: [[u64; N_CAUSES]; 3],
}

#[derive(Clone, Debug)]
pub struct Organisms {
    next_id: Id,
    pub plants: Vec<Organism>,
    pub herbivores: Vec<Organism>,
    pub carnivores: Vec<Organism>,
    pending: Vec<Pending>,
    pub stats: LifeStats,
    baselines: [Traits; 3],
}

pub const STREAM_ORGANISMS: u64 = 2;
/// Founder genome stream (separate so founder placement is unaffected).
pub const STREAM_GENOMES: u64 = 3;

impl Organisms {
    pub fn empty() -> Organisms {
        Organisms {
            next_id: 1,
            plants: Vec::new(),
            herbivores: Vec::new(),
            carnivores: Vec::new(),
            pending: Vec::new(),
            stats: LifeStats::default(),
            baselines: [Traits::baseline(Kind::Plant, &Config::default()), Traits::baseline(Kind::Herbivore, &Config::default()), Traits::baseline(Kind::Carnivore, &Config::default())],
        }
    }

    /// Founders from `initial.*`, placed uniformly (own RNG stream); ids ascending plants, herbivores, carnivores.
    pub fn populate(cfg: &Config, grid: &Grid) -> Organisms {
        let mut o = Organisms::empty();
        o.baselines = [Traits::baseline(Kind::Plant, cfg), Traits::baseline(Kind::Herbivore, cfg), Traits::baseline(Kind::Carnivore, cfg)];
        let mut rng = Rng::stream(cfg.seed, STREAM_ORGANISMS);
        let mut grng = Rng::stream(cfg.seed, STREAM_GENOMES);
        let counts = [cfg.initial.plants, cfg.initial.herbivores, cfg.initial.carnivores];
        let energies = [cfg.plants.initial_energy, cfg.herbivores.initial_energy, cfg.carnivores.initial_energy];
        for k in Kind::ALL {
            let base = o.baselines[k.index()];
            for _ in 0..counts[k.index()] {
                let i = rng.below(grid.cell_count() as u64) as usize;
                let id = o.take_id();
                let genome = Genome::founder(k, &base, &mut grng, cfg.genetics.founder_variation);
                let org = Organism::new(id, k, grid.pos_of(i), genome, &base, energies[k.index()], [0, 0], 0, 0);
                o.vec_mut(k).push(org);
                o.stats.founded[k.index()] += 1;
            }
        }
        o
    }

    fn take_id(&mut self) -> Id {
        let id = self.next_id;
        self.next_id += 1;
        id
    }

    /// Founder baseline traits of a kind (genes map relative to these).
    pub fn baseline(&self, k: Kind) -> &Traits {
        &self.baselines[k.index()]
    }

    pub fn next_id(&self) -> Id {
        self.next_id
    }

    pub fn vec(&self, k: Kind) -> &Vec<Organism> {
        match k {
            Kind::Plant => &self.plants,
            Kind::Herbivore => &self.herbivores,
            Kind::Carnivore => &self.carnivores,
        }
    }

    pub fn vec_mut(&mut self, k: Kind) -> &mut Vec<Organism> {
        match k {
            Kind::Plant => &mut self.plants,
            Kind::Herbivore => &mut self.herbivores,
            Kind::Carnivore => &mut self.carnivores,
        }
    }

    /// Organisms physically stored (alive and marked-dead awaiting the Deaths phase).
    pub fn stored(&self, k: Kind) -> usize {
        self.vec(k).len()
    }

    /// Living organisms of the kind.
    pub fn count(&self, k: Kind) -> usize {
        self.vec(k).iter().filter(|o| o.alive).count()
    }

    pub fn pending_births(&self) -> usize {
        self.pending.len()
    }

    /// Ids of organisms that may act, ascending.
    pub fn active_ids(&self, k: Kind) -> Vec<Id> {
        self.vec(k).iter().filter(|o| o.is_active()).map(|o| o.id).collect()
    }

    pub fn get(&self, k: Kind, id: Id) -> Option<&Organism> {
        let v = self.vec(k);
        v.binary_search_by_key(&id, |o| o.id).ok().map(|i| &v[i])
    }

    pub fn get_mut(&mut self, k: Kind, id: Id) -> Option<&mut Organism> {
        let v = self.vec_mut(k);
        match v.binary_search_by_key(&id, |o| o.id) {
            Ok(i) => Some(&mut v[i]),
            Err(_) => None,
        }
    }

    pub fn find(&self, id: Id) -> Option<&Organism> {
        Kind::ALL.iter().find_map(|&k| self.get(k, id))
    }

    pub fn find_mut(&mut self, id: Id) -> Option<&mut Organism> {
        let k = Kind::ALL.iter().copied().find(|&k| self.get(k, id).is_some())?;
        self.get_mut(k, id)
    }

    /// Marks an organism dead now (it never acts again); removal and counting happen in the Deaths phase.
    /// Returns false (no change, first cause wins) if it is unknown or already dead.
    pub fn mark_dead(&mut self, id: Id, cause: DeathCause, tick: u64) -> bool {
        match self.find_mut(id) {
            Some(o) if o.alive => {
                o.alive = false;
                o.death = Some(Death { tick, cause });
                true
            }
            _ => false,
        }
    }

    /// Queues a birth for the Births phase. Rejected (false) if parents[0] is 0 or a non-zero parent
    /// does not exist or is already marked dead. Parents that die *later* in the tick are fine.
    pub fn queue_birth(&mut self, nb: NewBorn) -> bool {
        if nb.parents[0] == 0 {
            return false;
        }
        let mut generation = 0;
        let species = self.find(nb.parents[0]).map_or(0, |o| o.species);
        for p in nb.parents {
            if p == 0 {
                continue;
            }
            match self.find(p) {
                Some(o) if o.alive => generation = generation.max(o.generation + 1),
                _ => return false,
            }
        }
        self.pending.push(Pending { nb, generation, species });
        true
    }

    /// Deaths phase: age, automatic causes, removal. Returns removed organisms in order Plant, Herbivore, Carnivore, id ascending.
    pub fn resolve_deaths(&mut self, tick: u64) -> Vec<Organism> {
        let mut removed = Vec::new();
        for k in Kind::ALL {
            for o in self.vec_mut(k).iter_mut() {
                if !o.alive {
                    continue;
                }
                o.age = o.age.saturating_add(1);
                let cause = if o.health <= 0.0 {
                    Some(DeathCause::Injury)
                } else if o.energy <= 0.0 {
                    Some(DeathCause::Starvation)
                } else if o.age >= o.traits.max_lifespan {
                    Some(DeathCause::OldAge)
                } else {
                    None
                };
                if let Some(c) = cause {
                    o.alive = false;
                    o.death = Some(Death { tick, cause: c });
                }
            }
            let v = self.vec_mut(k);
            if v.iter().all(|o| o.alive) {
                continue; // nothing died: avoid moving every organism (ADR-0030)
            }
            let (dead, live): (Vec<Organism>, Vec<Organism>) = std::mem::take(v).into_iter().partition(|o| !o.alive);
            *v = live;
            for o in dead {
                self.stats.deaths[k.index()] += 1;
                let c = o.death.map(|d| d.cause).unwrap_or(DeathCause::Other);
                self.stats.deaths_by_cause[k.index()][c.index()] += 1;
                removed.push(o);
            }
        }
        removed
    }

    /// Births phase: materialises queued newborns in queue order. Returns (id, kind) of each.
    pub fn resolve_births(&mut self, tick: u64) -> Vec<(Id, Kind)> {
        let pending = std::mem::take(&mut self.pending);
        let mut out = Vec::with_capacity(pending.len());
        for p in pending {
            let id = self.take_id();
            let k = p.nb.kind;
            let o = Organism::new(id, k, p.nb.pos, p.nb.genome, &self.baselines[k.index()], p.nb.energy, p.nb.parents, p.generation, tick);
            let mut o = o;
            o.species = p.species;
            self.vec_mut(k).push(o);
            self.stats.births[k.index()] += 1;
            out.push((id, k));
        }
        out
    }

    /// Checkpoint: next id, counters, every stored organism. Pending births must not exist.
    pub fn write_state(&self, w: &mut crate::checkpoint::Writer) {
        assert!(self.pending.is_empty(), "checkpoint between ticks only");
        w.u64(self.next_id);
        for k in 0..3 {
            w.u64(self.stats.founded[k]);
            w.u64(self.stats.births[k]);
            w.u64(self.stats.deaths[k]);
            for c in 0..N_CAUSES {
                w.u64(self.stats.deaths_by_cause[k][c]);
            }
        }
        for k in Kind::ALL {
            let v = self.vec(k);
            w.u64(v.len() as u64);
            for o in v {
                w.u64(o.id);
                w.u8(o.kind.index() as u8);
                w.u32(o.pos.x as u32);
                w.u32(o.pos.y as u32);
                w.u32(o.age);
                w.f64(o.energy);
                w.f64(o.health);
                w.u64(o.parents[0]);
                w.u64(o.parents[1]);
                w.u32(o.generation);
                w.u64(o.birth_tick);
                w.u8(o.alive as u8);
                match o.death {
                    None => w.u8(0),
                    Some(d) => {
                        w.u8(1);
                        w.u64(d.tick);
                        w.u8(d.cause.index() as u8);
                    }
                }
                w.f64(o.move_credit);
                w.u8(o.heading);
                w.u32(o.rest);
                w.u32(o.cooldown);
                w.u32(o.species);
                o.genome.write_state(w);
            }
        }
    }

    /// Reads and validates organisms; traits and baselines are recomputed from the genome and config.
    pub fn read_state(r: &mut crate::checkpoint::Reader, cfg: &Config, grid: &Grid) -> crate::checkpoint::Res<Organisms> {
        use crate::checkpoint::err;
        let mut o = Organisms::empty();
        o.baselines = [Traits::baseline(Kind::Plant, cfg), Traits::baseline(Kind::Herbivore, cfg), Traits::baseline(Kind::Carnivore, cfg)];
        o.next_id = r.u64()?;
        if o.next_id == 0 {
            return err("next id is zero");
        }
        for k in 0..3 {
            o.stats.founded[k] = r.u64()?;
            o.stats.births[k] = r.u64()?;
            o.stats.deaths[k] = r.u64()?;
            for c in 0..N_CAUSES {
                o.stats.deaths_by_cause[k][c] = r.u64()?;
            }
        }
        for kind in Kind::ALL {
            // Smallest record: 8+1+4+4+4+8+8+8+8+4+8+1+1+8+1+4+4+4+80.
            let n = r.count(150)?;
            let mut v = Vec::with_capacity(n);
            let baseline = o.baselines[kind.index()];
            for _ in 0..n {
                let id = r.u64()?;
                if id == 0 || id >= o.next_id || (!v.is_empty() && id <= last_id_of(&v)) {
                    return err("organism ids are not strictly ascending below next id");
                }
                match Kind::from_index(r.u8()?) {
                    Some(k2) if k2 == kind => {}
                    _ => return err("organism stored under the wrong kind"),
                }
                let (x, y) = (r.u32()? as i32, r.u32()? as i32);
                let pos = Pos { x, y };
                if x < 0 || y < 0 || !grid.contains(pos) {
                    return err("organism outside the world");
                }
                let age = r.u32()?;
                let energy = r.finite("energy")?;
                let health = r.finite("health")?;
                let parents = [r.u64()?, r.u64()?];
                let generation = r.u32()?;
                let birth_tick = r.u64()?;
                let alive = match r.u8()? {
                    0 => false,
                    1 => true,
                    _ => return err("bad alive flag"),
                };
                let death = match r.u8()? {
                    0 => None,
                    1 => {
                        let tick = r.u64()?;
                        match DeathCause::from_index(r.u8()?) {
                            Some(cause) => Some(Death { tick, cause }),
                            None => return err("unknown cause of death"),
                        }
                    }
                    _ => return err("bad death flag"),
                };
                let move_credit = r.finite("move credit")?;
                let heading = r.u8()?;
                let (rest, cooldown, species) = (r.u32()?, r.u32()?, r.u32()?);
                if heading > 8 || !(0.0..1.0).contains(&move_credit) {
                    return err("movement state out of range");
                }
                let genome = Genome::read_state(r)?;
                let traits = genome.traits(kind, &baseline);
                if energy < 0.0 || energy > traits.max_energy || health < 0.0 || health > traits.max_health {
                    return err("energy or health outside its limits");
                }
                v.push(Organism {
                    id,
                    kind,
                    pos,
                    age,
                    energy,
                    health,
                    traits,
                    genome,
                    parents,
                    generation,
                    birth_tick,
                    alive,
                    death,
                    move_credit,
                    heading,
                    rest,
                    cooldown,
                    species,
                });
            }
            *o.vec_mut(kind) = v;
        }
        Ok(o)
    }

    /// Feeds the full organism state (for the digest) in a fixed order.
    pub fn state_words(&self, f: &mut dyn FnMut(u64)) {
        f(self.next_id);
        for k in 0..3 {
            f(self.stats.founded[k]);
            f(self.stats.births[k]);
            f(self.stats.deaths[k]);
            for c in 0..N_CAUSES {
                f(self.stats.deaths_by_cause[k][c]);
            }
        }
        for k in Kind::ALL {
            f(self.vec(k).len() as u64);
            for o in self.vec(k) {
                f(o.id);
                f(o.kind.index() as u64);
                f(((o.pos.x as u32 as u64) << 32) | o.pos.y as u32 as u64);
                f(o.age as u64);
                f(o.energy.to_bits());
                f(o.health.to_bits());
                f(o.parents[0]);
                f(o.parents[1]);
                f(o.generation as u64);
                f(o.alive as u64);
                f(o.move_credit.to_bits());
                f(o.heading as u64);
                f(o.rest as u64);
                f(o.cooldown as u64);
                f(o.species as u64);
                o.traits.words(f);
                o.genome.state_words(f);
            }
        }
        f(self.pending.len() as u64);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cfg() -> Config {
        let mut c = Config::default();
        c.initial.plants = 5;
        c.initial.herbivores = 3;
        c.initial.carnivores = 2;
        c
    }

    #[test]
    fn populate_counts_and_ids() {
        let c = cfg();
        let g = Grid::new(c.world.width, c.world.height).unwrap();
        let o = Organisms::populate(&c, &g);
        assert_eq!((o.count(Kind::Plant), o.count(Kind::Herbivore), o.count(Kind::Carnivore)), (5, 3, 2));
        assert_eq!(o.next_id(), 11);
    }

    #[test]
    fn clamped_fixes_nan() {
        let mut t = Traits::baseline(Kind::Herbivore, &cfg());
        t.speed = f64::NAN;
        t.aggression = 5.0;
        let t = t.clamped(Kind::Herbivore);
        assert_eq!(t.speed, 0.1);
        assert_eq!(t.aggression, 1.0);
    }
}

#[cfg(test)]
mod hash_tests {
    use super::*;
    use crate::sim::Simulation;

    #[test]
    fn single_allele_changes_state_hash() {
        let mut c = Config::default();
        c.world.width = 8;
        c.world.height = 8;
        c.initial.plants = 3;
        c.initial.herbivores = 3;
        c.initial.carnivores = 3;
        let base = Simulation::new(&c).unwrap();
        for k in Kind::ALL {
            let mut m = base.clone();
            let o = &mut m.organisms.vec_mut(k)[0];
            let mut a = *o.genome.alleles();
            a[0][1] = f32::from_bits(a[0][1].to_bits() + 1);
            o.genome = Genome::from_alleles(a);
            assert_ne!(base.state_hash(), m.state_hash(), "{k:?}");
        }
    }
}

fn last_id_of(v: &[Organism]) -> u64 {
    v.last().map_or(0, |o| o.id)
}

//! Typed simulation configuration: parameters with type, range and default, JSON I/O, presets.
//!
//! Decisions (ADR-0007): unknown keys are an error; types are strict (integer keys need JSON
//! integers); only the contract's fixed keys are required; every other key has a default.
//! The parameters are not yet used by the simulation (later tasks reuse these keys).

use crate::json::{self, Value};
use std::fmt;

// ---------------------------------------------------------------- errors

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ErrorKind {
    Syntax,
    MissingKey,
    WrongType,
    OutOfRange,
    UnknownKey,
    Io,
}

/// Configuration error; `key` is the dotted path of the offending key (`<json>`/`<file>` for
/// syntax and I/O problems). The CLI maps every ConfigError to exit status 2.
#[derive(Clone, Debug, PartialEq)]
pub struct ConfigError {
    pub key: String,
    pub kind: ErrorKind,
    pub message: String,
}

impl ConfigError {
    fn new(key: &str, kind: ErrorKind, message: String) -> Self {
        ConfigError { key: key.to_string(), kind, message }
    }
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid configuration: key `{}`: {}", self.key, self.message)
    }
}

impl std::error::Error for ConfigError {}

// ---------------------------------------------------------------- parameter model

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Kind {
    Int,
    Float,
    Bool,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Num {
    I(i64),
    F(f64),
    B(bool),
}

impl Num {
    fn as_f64(self) -> f64 {
        match self {
            Num::I(i) => i as f64,
            Num::F(f) => f,
            Num::B(b) => b as u8 as f64,
        }
    }
    fn to_value(self) -> Value {
        match self {
            Num::I(i) => Value::Int(i),
            Num::F(f) => Value::Float(f),
            Num::B(b) => Value::Bool(b),
        }
    }
}

trait Field: Copy {
    const KIND: Kind;
    fn to_num(self) -> Num;
    fn from_num(n: Num) -> Self;
}
impl Field for f64 {
    const KIND: Kind = Kind::Float;
    fn to_num(self) -> Num {
        Num::F(self)
    }
    fn from_num(n: Num) -> Self {
        n.as_f64()
    }
}
impl Field for u32 {
    const KIND: Kind = Kind::Int;
    fn to_num(self) -> Num {
        Num::I(self as i64)
    }
    fn from_num(n: Num) -> Self {
        n.as_f64() as u32
    }
}
impl Field for bool {
    const KIND: Kind = Kind::Bool;
    fn to_num(self) -> Num {
        Num::B(self)
    }
    fn from_num(n: Num) -> Self {
        matches!(n, Num::B(true))
    }
}

/// Static description of one key inside a group.
#[derive(Clone, Copy, Debug)]
pub struct Key {
    pub name: &'static str,
    pub kind: Kind,
    pub min: f64,
    pub max: f64,
    pub doc: &'static str,
}

trait GroupOps {
    fn keys(&self) -> &'static [Key];
    fn get(&self, name: &str) -> Option<Num>;
    fn set(&mut self, name: &str, n: Num) -> bool;
}

macro_rules! group {
    ($sname:ident; $( $f:ident : $t:ty = $d:expr, $lo:expr, $hi:expr, $doc:expr; )*) => {
        #[derive(Clone, Debug, PartialEq)]
        pub struct $sname { $( pub $f: $t, )* }
        impl $sname {
            pub const KEYS: &'static [Key] = &[ $( Key {
                name: stringify!($f), kind: <$t as Field>::KIND,
                min: $lo as f64, max: $hi as f64, doc: $doc }, )* ];
            fn base() -> Self { $sname { $( $f: $d, )* } }
        }
        impl GroupOps for $sname {
            fn keys(&self) -> &'static [Key] { Self::KEYS }
            fn get(&self, name: &str) -> Option<Num> {
                $( if name == stringify!($f) { return Some(Field::to_num(self.$f)); } )*
                None
            }
            fn set(&mut self, name: &str, n: Num) -> bool {
                $( if name == stringify!($f) { self.$f = <$t as Field>::from_num(n); return true; } )*
                false
            }
        }
    };
}

group! { World;
    width: u32 = 64, 1, 4096, "grid width in cells (fixed key)";
    height: u32 = 48, 1, 4096, "grid height in cells (fixed key)";
}

group! { Initial;
    plants: u32 = 400, 0, 4_000_000, "plants at tick 0 (fixed key, 0 allowed)";
    herbivores: u32 = 120, 0, 4_000_000, "herbivores at tick 0 (fixed key, 0 allowed)";
    carnivores: u32 = 20, 0, 4_000_000, "carnivores at tick 0 (fixed key, 0 allowed)";
}

group! { Climate;
    equator_temp: f64 = 28.0, -20.0, 60.0, "mean annual temperature at the equator (deg C)";
    pole_temp: f64 = -15.0, -60.0, 40.0, "mean annual temperature at the poles (deg C); must be <= equator_temp";
    seasonal_amplitude: f64 = 8.0, 0.0, 40.0, "seasonal temperature swing (deg C)";
    seasonal_precip_amplitude: f64 = 0.3, 0.0, 0.95, "relative seasonal swing of precipitation (wet/dry seasons)";
    season_length: u32 = 200, 2, 100_000, "ticks per year";
    precip_mean: f64 = 1.0, 0.0, 5.0, "average precipitation (relative units)";
    precip_latitude_variation: f64 = 0.6, 0.0, 1.0, "strength of wet/dry latitude bands";
    weather_noise: f64 = 0.15, 0.0, 1.0, "amplitude of random weather fluctuations";
    weather_period: u32 = 25, 1, 10_000, "typical weather change period (ticks)";
    terrain_noise: f64 = 0.2, 0.0, 1.0, "spatial unevenness of local climate";
    cover_fraction: f64 = 0.3, 0.0, 1.0, "fraction of cells offering cover (refuge) to prey";
    cover_protection: f64 = 0.8, 0.0, 0.95, "fraction by which cover cells cut the success chance of an attack on a herbivore standing there (ADR-0031)";
    resource_regen: f64 = 2.0, 0.0, 100.0, "cell resource regeneration per tick";
    resource_max: f64 = 20.0, 0.1, 10_000.0, "cell resource capacity";
}

group! { Plants;
    initial_energy: f64 = 25.0, 0.1, 10_000.0, "energy of a starting plant; must be <= max_energy";
    max_energy: f64 = 50.0, 0.1, 10_000.0, "maximum stored energy/biomass";
    growth_rate: f64 = 1.5, 0.0, 100.0, "energy gained per tick at optimal conditions";
    resource_uptake: f64 = 2.0, 0.0, 100.0, "max cell resource taken per tick";
    water_need: f64 = 0.3, 0.0, 10.0, "precipitation needed for full growth";
    temp_optimum: f64 = 20.0, -20.0, 50.0, "optimal temperature (deg C)";
    temp_tolerance: f64 = 12.0, 0.1, 60.0, "temperature deviation at which growth falls off";
    seed_range: u32 = 3, 0, 50, "seed dispersal distance (cells)";
    pollination_range: u32 = 2, 0, 50, "reserved, unused (plants reproduce asexually, ADR-0016)";
    reproduction_threshold: f64 = 8.0, 0.1, 10_000.0, "energy needed to reproduce; must be <= max_energy";
    reproduction_cost: f64 = 4.0, 0.0, 10_000.0, "energy spent on an offspring";
    establish_resource: f64 = 1.0, 0.0, 10_000.0, "minimum cell fertility stock for a seed to establish";
    max_age: u32 = 400, 1, 1_000_000, "lifespan in ticks";
    cell_capacity: u32 = 4, 1, 1000, "max plants per cell (density limit)";
    mutation_rate: f64 = 0.05, 0.0, 1.0, "per-gene mutation probability at reproduction";
    maintenance: f64 = 0.1, 0.0, 100.0, "energy a plant spends per tick on upkeep (times its metabolism trait)";
    graze_reserve: f64 = 6.0, 0.0, 10_000.0, "energy a plant keeps in its roots: herbivores can only eat the energy above it, so grazing alone never kills a plant (a local refuge)";
    stress_damage: f64 = 0.05, 0.0, 1.0, "fraction of max health lost per tick in hostile climate (too cold/hot or too dry)";
}

group! { Animal;
    initial_energy: f64 = 30.0, 0.1, 10_000.0, "starting energy; must be <= max_energy";
    max_energy: f64 = 100.0, 0.1, 10_000.0, "energy capacity";
    base_metabolism: f64 = 0.4, 0.0, 100.0, "energy cost per tick";
    move_cost: f64 = 0.15, 0.0, 100.0, "extra energy per cell moved";
    speed: f64 = 1.0, 0.1, 16.0, "cells per tick (base value of the trait)";
    vision: u32 = 4, 1, 64, "perception radius (cells)";
    strength: f64 = 1.0, 0.0, 100.0, "base strength";
    health: f64 = 10.0, 0.1, 10_000.0, "base health";
    max_age: u32 = 800, 1, 1_000_000, "lifespan in ticks; must be >= maturity_age";
    maturity_age: u32 = 80, 0, 1_000_000, "age at which reproduction becomes possible";
    reproduction_energy: f64 = 60.0, 0.0, 10_000.0, "energy needed to mate; must be <= max_energy";
    reproduction_cooldown: u32 = 40, 0, 100_000, "ticks between births";
    mate_range: u32 = 2, 0, 64, "distance to find a mate (cells)";
    offspring_energy: f64 = 25.0, 0.0, 10_000.0, "energy given to a newborn";
    litter_size: u32 = 1, 1, 16, "maximum offspring per birth";
    satiation_limit: f64 = 0.9, 0.1, 1.0, "energy fraction above which the animal stops eating";
    digestion_efficiency: f64 = 0.6, 0.01, 1.0, "fraction of food energy gained";
    handling_time: u32 = 2, 0, 1000, "ticks spent eating after a meal/kill";
    aggression: f64 = 0.3, 0.0, 1.0, "initial behavioural tendency to attack/compete";
    risk_tolerance: f64 = 0.4, 0.0, 1.0, "initial tendency to accept danger";
    mutation_rate: f64 = 0.05, 0.0, 1.0, "per-gene mutation probability at reproduction";
    bite_size: f64 = 4.0, 0.0, 1000.0, "max plant energy taken per tick before the aggression factor (0.5 + aggression)";
    temp_comfort: f64 = 18.0, -20.0, 50.0, "temperature (C) with no climate cost";
    temp_tolerance: f64 = 14.0, 0.1, 60.0, "distance from temp_comfort (C) before the climate cost starts";
    climate_cost: f64 = 0.5, 0.0, 10.0, "extra upkeep fraction per tolerance width beyond the comfort band (capped at 4 widths)";
    attack_cost: f64 = 0.5, 0.0, 1000.0, "energy paid per attack (hit or miss), times the metabolism trait; used by carnivores";
}

group! { Genetics;
    mutation_sigma: f64 = 0.05, 0.0, 1.0, "standard deviation of a gene mutation step";
    crossover_rate: f64 = 0.5, 0.0, 1.0, "probability a gene comes from the other parent allele";
    founder_variation: f64 = 0.05, 0.0, 0.5, "half-width of the uniform noise added to each founder allele";
    species_threshold: f64 = 0.25, 0.001, 10.0, "genetic distance beyond which lineages are separate species";
    species_min_size: u32 = 3, 1, 10_000, "minimum members for a species to be recorded";
    species_check_interval: u32 = 50, 1, 100_000, "ticks between speciation checks";
}

// ---------------------------------------------------------------- Config

#[derive(Clone, Debug, PartialEq)]
pub struct Config {
    pub seed: i64,
    pub world: World,
    pub initial: Initial,
    pub climate: Climate,
    pub plants: Plants,
    pub herbivores: Animal,
    pub carnivores: Animal,
    pub genetics: Genetics,
}

/// Group names in serialization order (after the scalar `seed`).
pub const GROUPS: [&str; 7] = ["world", "initial", "climate", "plants", "herbivores", "carnivores", "genetics"];

/// Keys that must appear in every configuration file.
pub const FIXED_KEYS: [&str; 6] =
    ["seed", "world.width", "world.height", "initial.plants", "initial.herbivores", "initial.carnivores"];

impl Default for Config {
    fn default() -> Self {
        // Balanced defaults (TASK-018, ADR-0022, docs/ECOLOGY.md).
        let mut herb = Animal::base();
        herb.initial_energy = 50.0;
        herb.base_metabolism = 0.3;
        herb.bite_size = 3.0;
        herb.maturity_age = 50;
        herb.mate_range = 4;
        herb.reproduction_energy = 60.0;
        herb.reproduction_cooldown = 50;
        herb.offspring_energy = 25.0;
        let mut carn = Animal::base();
        carn.initial_energy = 60.0;
        carn.max_energy = 200.0;
        carn.base_metabolism = 0.9;
        carn.move_cost = 0.2;
        carn.speed = 1.2;
        carn.vision = 4;
        carn.strength = 2.0;
        carn.health = 20.0;
        carn.max_age = 1000;
        carn.maturity_age = 120;
        carn.reproduction_energy = 170.0;
        carn.reproduction_cooldown = 150;
        carn.offspring_energy = 60.0;
        carn.satiation_limit = 0.8;
        carn.digestion_efficiency = 0.7;
        carn.handling_time = 20;
        carn.attack_cost = 3.0;
        carn.aggression = 0.6;
        carn.risk_tolerance = 0.5;
        Config {
            seed: 42,
            world: World::base(),
            initial: Initial::base(),
            climate: Climate::base(),
            plants: Plants::base(),
            herbivores: herb,
            carnivores: carn,
            genetics: Genetics::base(),
        }
    }
}

/// Description of one configuration key (the table behind parsing, validation and docs/UI).
#[derive(Clone, Debug)]
pub struct ParamDef {
    /// dotted path, e.g. `plants.growth_rate`
    pub path: String,
    pub kind: Kind,
    pub min: f64,
    pub max: f64,
    pub default: Num,
    pub doc: &'static str,
    pub fixed: bool,
}

fn type_err(path: &str, want: &str, v: &Value) -> ConfigError {
    ConfigError::new(path, ErrorKind::WrongType, format!("expected {}, found {}", want, v.type_name()))
}

impl Config {
    fn group(&self, name: &str) -> Option<&dyn GroupOps> {
        Some(match name {
            "world" => &self.world,
            "initial" => &self.initial,
            "climate" => &self.climate,
            "plants" => &self.plants,
            "herbivores" => &self.herbivores,
            "carnivores" => &self.carnivores,
            "genetics" => &self.genetics,
            _ => return None,
        })
    }
    fn group_mut(&mut self, name: &str) -> Option<&mut dyn GroupOps> {
        Some(match name {
            "world" => &mut self.world,
            "initial" => &mut self.initial,
            "climate" => &mut self.climate,
            "plants" => &mut self.plants,
            "herbivores" => &mut self.herbivores,
            "carnivores" => &mut self.carnivores,
            "genetics" => &mut self.genetics,
            _ => return None,
        })
    }

    /// All parameters including `seed`, in serialization order.
    pub fn param_defs() -> Vec<ParamDef> {
        let d = Config::default();
        let mut v = vec![ParamDef {
            path: "seed".into(),
            kind: Kind::Int,
            min: i64::MIN as f64,
            max: i64::MAX as f64,
            default: Num::I(d.seed),
            doc: "random seed (fixed key)",
            fixed: true,
        }];
        for g in GROUPS {
            let grp = d.group(g).unwrap();
            for k in grp.keys() {
                let path = format!("{}.{}", g, k.name);
                v.push(ParamDef {
                    fixed: FIXED_KEYS.contains(&path.as_str()),
                    path,
                    kind: k.kind,
                    min: k.min,
                    max: k.max,
                    default: grp.get(k.name).unwrap(),
                    doc: k.doc,
                });
            }
        }
        v
    }

    /// Current value of a parameter by dotted path.
    pub fn get_num(&self, path: &str) -> Option<Num> {
        if path == "seed" {
            return Some(Num::I(self.seed));
        }
        let (g, k) = path.split_once('.')?;
        self.group(g)?.get(k)
    }

    /// Set a parameter by dotted path without validating (call `validate` afterwards).
    pub fn set_num(&mut self, path: &str, n: Num) -> Result<(), ConfigError> {
        let ok = if path == "seed" {
            if let Num::I(i) = n {
                self.seed = i;
            }
            true
        } else {
            match path.split_once('.') {
                Some((g, k)) => self.group_mut(g).map_or(false, |grp| grp.set(k, n)),
                None => false,
            }
        };
        if ok {
            Ok(())
        } else {
            Err(ConfigError::new(path, ErrorKind::UnknownKey, "unknown configuration key".into()))
        }
    }

    /// Check ranges and cross-field constraints. Errors name the offending key.
    pub fn validate(&self) -> Result<(), ConfigError> {
        for g in GROUPS {
            let grp = self.group(g).unwrap();
            for k in grp.keys() {
                let path = format!("{}.{}", g, k.name);
                let n = grp.get(k.name).unwrap();
                check_range(&path, k, n)?;
            }
        }
        let area = self.world.width as u64 * self.world.height as u64;
        if area > 4_000_000 {
            return Err(ConfigError::new(
                "world.width",
                ErrorKind::OutOfRange,
                format!("world area {} cells exceeds the maximum of 4000000", area),
            ));
        }
        let le = |a: f64, b: f64, ka: &str, kb: &str| -> Result<(), ConfigError> {
            if a <= b {
                Ok(())
            } else {
                Err(ConfigError::new(ka, ErrorKind::OutOfRange, format!("must be <= {} ({} > {})", kb, a, b)))
            }
        };
        le(self.climate.pole_temp, self.climate.equator_temp, "climate.pole_temp", "climate.equator_temp")?;
        let p = &self.plants;
        le(p.initial_energy, p.max_energy, "plants.initial_energy", "plants.max_energy")?;
        le(p.reproduction_threshold, p.max_energy, "plants.reproduction_threshold", "plants.max_energy")?;
        for (name, a) in [("herbivores", &self.herbivores), ("carnivores", &self.carnivores)] {
            let k = |s: &str| format!("{}.{}", name, s);
            le(a.initial_energy, a.max_energy, &k("initial_energy"), &k("max_energy"))?;
            le(a.reproduction_energy, a.max_energy, &k("reproduction_energy"), &k("max_energy"))?;
            le(a.maturity_age as f64, a.max_age as f64, &k("maturity_age"), &k("max_age"))?;
        }
        Ok(())
    }

    // ------------------------------------------------------------ JSON

    pub fn to_value(&self) -> Value {
        let mut items = vec![("seed".to_string(), Value::Int(self.seed))];
        for g in GROUPS {
            let grp = self.group(g).unwrap();
            let fields = grp.keys().iter().map(|k| (k.name.to_string(), grp.get(k.name).unwrap().to_value())).collect();
            items.push((g.to_string(), Value::Object(fields)));
        }
        Value::Object(items)
    }

    /// Full explicit JSON (every key), two-space indented.
    pub fn to_json(&self) -> String {
        self.to_value().to_pretty()
    }

    pub fn from_json(text: &str) -> Result<Config, ConfigError> {
        let v = json::parse(text).map_err(|e| match &e.key {
            Some(k) => ConfigError::new(k, ErrorKind::Syntax, format!("{} (line {}, column {})", e.msg, e.line, e.col)),
            None => ConfigError::new("<json>", ErrorKind::Syntax, e.to_string()),
        })?;
        Config::from_value(&v)
    }

    pub fn from_value(v: &Value) -> Result<Config, ConfigError> {
        let top = match v {
            Value::Object(o) => o,
            other => return Err(type_err("<root>", "object", other)),
        };
        let mut cfg = Config::default();
        for (k, val) in top {
            if k == "seed" {
                match val {
                    Value::Int(i) => cfg.seed = *i,
                    other => return Err(type_err("seed", "integer", other)),
                }
                continue;
            }
            let grp = cfg
                .group_mut(k)
                .ok_or_else(|| ConfigError::new(k, ErrorKind::UnknownKey, "unknown configuration key".into()))?;
            let obj = match val {
                Value::Object(o) => o,
                other => return Err(type_err(k, "object", other)),
            };
            for (name, fv) in obj {
                let path = format!("{}.{}", k, name);
                let key = grp
                    .keys()
                    .iter()
                    .find(|d| d.name == name)
                    .ok_or_else(|| ConfigError::new(&path, ErrorKind::UnknownKey, "unknown configuration key".into()))?;
                let n = match (key.kind, fv) {
                    (Kind::Int, Value::Int(i)) => Num::I(*i),
                    (Kind::Int, other) => return Err(type_err(&path, "integer", other)),
                    (Kind::Float, Value::Int(i)) => Num::F(*i as f64),
                    (Kind::Float, Value::Float(f)) => Num::F(*f),
                    (Kind::Float, other) => return Err(type_err(&path, "number", other)),
                    (Kind::Bool, Value::Bool(b)) => Num::B(*b),
                    (Kind::Bool, other) => return Err(type_err(&path, "boolean", other)),
                };
                check_range(&path, key, n)?; // before narrowing into the typed field
                grp.set(name, n);
            }
        }
        for fixed in FIXED_KEYS {
            let present = match fixed.split_once('.') {
                None => v.get(fixed).is_some(),
                Some((g, k)) => v.get(g).and_then(|o| o.get(k)).is_some(),
            };
            if !present {
                return Err(ConfigError::new(fixed, ErrorKind::MissingKey, "required key is missing".into()));
            }
        }
        cfg.validate()?;
        Ok(cfg)
    }

    pub fn load_file(path: &str) -> Result<Config, ConfigError> {
        let text = std::fs::read_to_string(path)
            .map_err(|e| ConfigError::new("<file>", ErrorKind::Io, format!("cannot read `{}`: {}", path, e)))?;
        Config::from_json(&text)
    }

    // ------------------------------------------------------------ presets

    /// Built-in preset by exact name; unknown names list the valid ones.
    pub fn preset(name: &str) -> Result<Config, ConfigError> {
        let mut c = Config::default();
        let edits: &[(&str, Num)] = match name {
            "default" => &[],
            "lush" => &[
                ("climate.precip_mean", Num::F(1.8)),
                ("climate.seasonal_amplitude", Num::F(4.0)),
                ("climate.resource_regen", Num::F(3.0)),
                ("plants.growth_rate", Num::F(2.0)),
                ("plants.cell_capacity", Num::I(6)),
                ("initial.plants", Num::I(700)),
                ("herbivores.base_metabolism", Num::F(0.25)),
            ],
            "harsh" => &[
                ("climate.precip_mean", Num::F(0.5)),
                ("climate.seasonal_amplitude", Num::F(18.0)),
                ("climate.seasonal_precip_amplitude", Num::F(0.6)),
                ("climate.weather_noise", Num::F(0.4)),
                ("climate.resource_regen", Num::F(0.6)),
                ("plants.growth_rate", Num::F(1.0)),
                ("herbivores.move_cost", Num::F(0.25)),
                ("herbivores.base_metabolism", Num::F(0.4)),
                ("initial.plants", Num::I(300)),
            ],
            "predator-rich" => &[
                ("initial.herbivores", Num::I(180)),
                ("initial.carnivores", Num::I(60)),
                ("climate.cover_fraction", Num::F(0.3)),
                ("carnivores.speed", Num::F(2.0)),
                ("carnivores.vision", Num::I(8)),
                ("carnivores.aggression", Num::F(0.8)),
                ("herbivores.risk_tolerance", Num::F(0.2)),
            ],
            "large" => &[
                ("world.width", Num::I(160)),
                ("world.height", Num::I(120)),
                ("initial.plants", Num::I(2500)),
                ("initial.herbivores", Num::I(500)),
                ("initial.carnivores", Num::I(80)),
            ],
            _ => {
                return Err(ConfigError::new(
                    "<preset>",
                    ErrorKind::UnknownKey,
                    format!("unknown preset `{}`; valid presets: {}", name, PRESET_NAMES.join(", ")),
                ))
            }
        };
        for (p, n) in edits {
            c.set_num(p, *n)?;
        }
        c.validate()?;
        Ok(c)
    }
}

pub const PRESET_NAMES: [&str; 5] = ["default", "lush", "harsh", "predator-rich", "large"];

fn check_range(path: &str, k: &Key, n: Num) -> Result<(), ConfigError> {
    let x = n.as_f64();
    if k.kind == Kind::Bool {
        return Ok(());
    }
    if !x.is_finite() || x < k.min || x > k.max {
        return Err(ConfigError::new(
            path,
            ErrorKind::OutOfRange,
            format!("value {} out of range [{}, {}]", x, k.min, k.max),
        ));
    }
    Ok(())
}

/// Human-readable table of all keys (used for docs/CONFIG.md).
pub fn describe() -> String {
    let mut s = String::from("| key | type | min | max | default | description |\n|---|---|---|---|---|---|\n");
    for d in Config::param_defs() {
        let ty = match d.kind {
            Kind::Int => "int",
            Kind::Float => "float",
            Kind::Bool => "bool",
        };
        let def = match d.default {
            Num::I(i) => i.to_string(),
            Num::F(f) => json::format_float(f),
            Num::B(b) => b.to_string(),
        };
        let (mn, mx) = if d.path == "seed" { ("any".to_string(), "any".to_string()) } else { (fmt_g(d.min), fmt_g(d.max)) };
        let fixed = if d.fixed { " **(required)**" } else { "" };
        s.push_str(&format!("| `{}` | {} | {} | {} | {} | {}{} |\n", d.path, ty, mn, mx, def, d.doc, fixed));
    }
    s
}

fn fmt_g(f: f64) -> String {
    if f.fract() == 0.0 && f.abs() < 1e15 {
        format!("{}", f as i64)
    } else {
        format!("{}", f)
    }
}

//! Spatial index (ADR-0014): incremental per-kind cell buckets on the toroidal grid.
//!
//! Derived state: not part of the digest or checkpoint; rebuild it from `Organisms` with `rebuild`.
//! Query results are ordered by `(dist, kind index, id)`, a total order independent of insertion
//! order or scan order, so they are deterministic and reproducible by a brute-force search.

use crate::grid::{Grid, Pos};
use crate::organism::{Id, Kind, Organisms};
use std::collections::BTreeMap;
use std::fmt;

/// One search result. `dist` is the Chebyshev toroidal distance to the query centre.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Hit {
    pub id: Id,
    pub kind: Kind,
    pub pos: Pos,
    pub dist: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SpatialError {
    Duplicate(Id),
    Unknown(Id),
    OutOfGrid(Pos),
}

impl fmt::Display for SpatialError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SpatialError::Duplicate(i) => write!(f, "organism {} is already indexed", i),
            SpatialError::Unknown(i) => write!(f, "organism {} is not indexed", i),
            SpatialError::OutOfGrid(p) => write!(f, "position ({},{}) is outside the grid", p.x, p.y),
        }
    }
}

impl std::error::Error for SpatialError {}

#[derive(Clone, Debug)]
pub struct SpatialIndex {
    grid: Grid,
    /// Per kind: bucket per cell (row-major), each sorted ascending by id.
    cells: [Vec<Vec<Id>>; 3],
    /// Id -> (kind, pos) lookup (ordered map: deterministic).
    loc: BTreeMap<Id, (Kind, Pos)>,
}

impl SpatialIndex {
    pub fn new(grid: Grid) -> SpatialIndex {
        let n = grid.cell_count();
        SpatialIndex { grid, cells: [vec![Vec::new(); n], vec![Vec::new(); n], vec![Vec::new(); n]], loc: BTreeMap::new() }
    }

    pub fn grid(&self) -> &Grid {
        &self.grid
    }

    pub fn len(&self) -> usize {
        self.loc.len()
    }

    pub fn is_empty(&self) -> bool {
        self.loc.is_empty()
    }

    pub fn contains(&self, id: Id) -> bool {
        self.loc.contains_key(&id)
    }

    /// Kind and position of an indexed organism.
    pub fn get(&self, id: Id) -> Option<(Kind, Pos)> {
        self.loc.get(&id).copied()
    }

    pub fn clear(&mut self) {
        for k in self.cells.iter_mut() {
            for b in k.iter_mut() {
                b.clear();
            }
        }
        self.loc.clear();
    }

    fn bucket_insert(&mut self, kind: Kind, pos: Pos, id: Id) {
        let b = &mut self.cells[kind.index()][self.grid.index(pos)];
        match b.last() {
            Some(&l) if l > id => {
                let at = b.binary_search(&id).unwrap_or_else(|e| e);
                b.insert(at, id);
            }
            _ => b.push(id),
        }
    }

    fn bucket_remove(&mut self, kind: Kind, pos: Pos, id: Id) {
        let b = &mut self.cells[kind.index()][self.grid.index(pos)];
        if let Ok(at) = b.binary_search(&id) {
            b.remove(at);
        }
    }

    pub fn insert(&mut self, id: Id, kind: Kind, pos: Pos) -> Result<(), SpatialError> {
        if !self.grid.contains(pos) {
            return Err(SpatialError::OutOfGrid(pos));
        }
        if self.loc.contains_key(&id) {
            return Err(SpatialError::Duplicate(id));
        }
        self.bucket_insert(kind, pos, id);
        self.loc.insert(id, (kind, pos));
        Ok(())
    }

    /// Move an indexed organism to `new_pos` (canonical, in-grid; the caller wraps).
    pub fn move_to(&mut self, id: Id, new_pos: Pos) -> Result<(), SpatialError> {
        if !self.grid.contains(new_pos) {
            return Err(SpatialError::OutOfGrid(new_pos));
        }
        let (kind, old) = *self.loc.get(&id).ok_or(SpatialError::Unknown(id))?;
        if old == new_pos {
            return Ok(());
        }
        self.bucket_remove(kind, old, id);
        self.bucket_insert(kind, new_pos, id);
        self.loc.insert(id, (kind, new_pos));
        Ok(())
    }

    pub fn remove(&mut self, id: Id) -> Result<(), SpatialError> {
        let (kind, pos) = self.loc.remove(&id).ok_or(SpatialError::Unknown(id))?;
        self.bucket_remove(kind, pos, id);
        Ok(())
    }

    /// Replace the contents with the organisms of `orgs` that are alive (not marked dead).
    pub fn rebuild(&mut self, orgs: &Organisms) {
        self.clear();
        for k in Kind::ALL {
            for o in orgs.vec(k) {
                if o.alive {
                    // Positions of organisms are always canonical; ignore (impossible) invalid ones.
                    let _ = self.insert(o.id, o.kind, o.pos);
                }
            }
        }
    }

    /// All indexed organisms within Chebyshev toroidal distance `radius` of `center`
    /// (optionally one kind), sorted by `(dist, kind, id)`. Negative radius or off-grid centre -> empty.
    pub fn query(&self, center: Pos, radius: i64, kind: Option<Kind>) -> Vec<Hit> {
        let mut out = Vec::new();
        self.query_into(center, radius, kind, &mut out);
        out
    }

    /// Like `query` but reuses `out` (cleared first).
    pub fn query_into(&self, center: Pos, radius: i64, kind: Option<Kind>, out: &mut Vec<Hit>) {
        out.clear();
        if radius < 0 || !self.grid.contains(center) || self.loc.is_empty() {
            return;
        }
        let r = radius.min(self.grid.width().max(self.grid.height()) as i64);
        let kinds: &[Kind] = match kind {
            Some(Kind::Plant) => &[Kind::Plant],
            Some(Kind::Herbivore) => &[Kind::Herbivore],
            Some(Kind::Carnivore) => &[Kind::Carnivore],
            None => &Kind::ALL,
        };
        let grid = self.grid;
        let cells = &self.cells;
        grid.for_each_cell_within(center, r, |p| {
            let ci = grid.index(p);
            let mut d = None;
            for &k in kinds {
                for &id in &cells[k.index()][ci] {
                    let dist = *d.get_or_insert_with(|| grid.dist(center, p));
                    out.push(Hit { id, kind: k, pos: p, dist });
                }
            }
        });
        out.sort_unstable_by_key(|h| (h.dist, h.kind.index(), h.id));
    }

    pub fn count(&self, center: Pos, radius: i64, kind: Option<Kind>) -> usize {
        self.query(center, radius, kind).len()
    }

    /// First hit of `query` (closest; ties by kind then id).
    pub fn nearest(&self, center: Pos, radius: i64, kind: Option<Kind>) -> Option<Hit> {
        self.query(center, radius, kind).into_iter().next()
    }
}

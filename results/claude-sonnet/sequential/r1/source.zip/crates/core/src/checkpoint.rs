//! Checkpoint container and byte helpers (TASK-022, ADR-0026).
//!
//! File: `EVOSIMCK` | u32 version | u64 payload length | payload | SHA-256(payload). Little-endian,
//! floats as bit patterns, no compression. `Simulation::to_checkpoint` / `from_checkpoint` live in this module.
//! Rule: when you add simulation state, write/read it in the owning module, bump `FORMAT_VERSION`.

use crate::config::Config;
use crate::hash::Sha256;
use crate::organism::Organisms;
use crate::rng::Rng;
use crate::sim::Simulation;
use crate::spatial::SpatialIndex;
use crate::species::SpeciesRegistry;
use crate::world::World;

pub const FORMAT_VERSION: u32 = 1;
pub const MAGIC: &[u8; 8] = b"EVOSIMCK";
const HEADER: usize = 8 + 4 + 8;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CheckpointError(pub String);

impl std::fmt::Display for CheckpointError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid checkpoint: {}", self.0)
    }
}

impl std::error::Error for CheckpointError {}

pub type Res<T> = Result<T, CheckpointError>;

pub fn err<T>(m: impl Into<String>) -> Res<T> {
    Err(CheckpointError(m.into()))
}

#[derive(Default)]
pub struct Writer {
    pub buf: Vec<u8>,
}

impl Writer {
    pub fn new() -> Writer {
        Writer { buf: Vec::with_capacity(1 << 16) }
    }
    pub fn u8(&mut self, v: u8) {
        self.buf.push(v);
    }
    pub fn u32(&mut self, v: u32) {
        self.buf.extend_from_slice(&v.to_le_bytes());
    }
    pub fn u64(&mut self, v: u64) {
        self.buf.extend_from_slice(&v.to_le_bytes());
    }
    pub fn f32(&mut self, v: f32) {
        self.u32(v.to_bits());
    }
    pub fn f64(&mut self, v: f64) {
        self.u64(v.to_bits());
    }
    pub fn str(&mut self, s: &str) {
        self.u64(s.len() as u64);
        self.buf.extend_from_slice(s.as_bytes());
    }
}

pub struct Reader<'a> {
    data: &'a [u8],
    pos: usize,
}

impl<'a> Reader<'a> {
    pub fn new(data: &'a [u8]) -> Reader<'a> {
        Reader { data, pos: 0 }
    }
    pub fn remaining(&self) -> usize {
        self.data.len() - self.pos
    }
    fn take(&mut self, n: usize) -> Res<&'a [u8]> {
        if n > self.remaining() {
            return err("unexpected end of data");
        }
        let s = &self.data[self.pos..self.pos + n];
        self.pos += n;
        Ok(s)
    }
    pub fn u8(&mut self) -> Res<u8> {
        Ok(self.take(1)?[0])
    }
    pub fn u32(&mut self) -> Res<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    pub fn u64(&mut self) -> Res<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    pub fn f32(&mut self) -> Res<f32> {
        Ok(f32::from_bits(self.u32()?))
    }
    pub fn f64(&mut self) -> Res<f64> {
        Ok(f64::from_bits(self.u64()?))
    }
    /// A finite f64.
    pub fn finite(&mut self, what: &str) -> Res<f64> {
        let v = self.f64()?;
        if !v.is_finite() {
            return err(format!("{what} is not finite"));
        }
        Ok(v)
    }
    /// An element count that is plausible: `n * min_elem_bytes` must fit into the remaining data.
    pub fn count(&mut self, min_elem_bytes: usize) -> Res<usize> {
        let n = self.u64()?;
        let need = (n as u128) * (min_elem_bytes.max(1) as u128);
        if need > self.remaining() as u128 {
            return err(format!("count {n} exceeds the remaining data"));
        }
        Ok(n as usize)
    }
    pub fn str(&mut self) -> Res<String> {
        let n = self.count(1)?;
        let b = self.take(n)?;
        String::from_utf8(b.to_vec()).or_else(|_| err("text is not valid UTF-8"))
    }
    pub fn finish(&self) -> Res<()> {
        if self.remaining() != 0 {
            return err(format!("{} unexpected trailing bytes", self.remaining()));
        }
        Ok(())
    }
}

/// Wraps a payload into the file container.
pub fn encode(payload: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(HEADER + payload.len() + 32);
    out.extend_from_slice(MAGIC);
    out.extend_from_slice(&FORMAT_VERSION.to_le_bytes());
    out.extend_from_slice(&(payload.len() as u64).to_le_bytes());
    out.extend_from_slice(payload);
    let mut h = Sha256::new();
    h.update(payload);
    out.extend_from_slice(&h.finalize());
    out
}

/// Validates the container and returns the payload.
pub fn decode(bytes: &[u8]) -> Res<&[u8]> {
    if bytes.is_empty() {
        return err("file is empty");
    }
    if bytes.len() < HEADER {
        return err("file is truncated (shorter than the header)");
    }
    if &bytes[..8] != MAGIC {
        return err("not an evosim checkpoint (bad magic)");
    }
    let version = u32::from_le_bytes(bytes[8..12].try_into().unwrap());
    if version != FORMAT_VERSION {
        return err(format!("unsupported checkpoint version {version} (this build reads version {FORMAT_VERSION})"));
    }
    let len = u64::from_le_bytes(bytes[12..20].try_into().unwrap());
    let rest = (bytes.len() - HEADER) as u64;
    if rest < 32 || len != rest - 32 {
        return if rest < 32 || len > rest - 32 { err("file is truncated") } else { err("unexpected trailing bytes") };
    }
    let payload = &bytes[HEADER..HEADER + len as usize];
    let mut h = Sha256::new();
    h.update(payload);
    if h.finalize()[..] != bytes[HEADER + len as usize..] {
        return err("checksum mismatch (file is damaged)");
    }
    Ok(payload)
}

impl Simulation {
    /// Complete state as a checkpoint file image. Only valid between ticks.
    pub fn to_checkpoint(&self) -> Vec<u8> {
        assert_eq!(self.organisms.pending_births(), 0, "checkpoint between ticks only");
        let mut w = Writer::new();
        w.str(&self.config.to_json());
        w.u64(self.tick);
        w.u64(self.acc);
        for s in self.rng.state() {
            w.u64(s);
        }
        self.world.write_state(&mut w);
        self.organisms.write_state(&mut w);
        self.species.write_state(&mut w);
        w.str(&self.state_hash());
        encode(&w.buf)
    }

    /// Rebuilds a simulation from a checkpoint image; every inconsistency is an error.
    pub fn from_checkpoint(bytes: &[u8]) -> Res<Simulation> {
        let payload = decode(bytes)?;
        let mut r = Reader::new(payload);
        let cfg = Config::from_json(&r.str()?).or_else(|e| err(format!("stored configuration: {e}")))?;
        cfg.validate().or_else(|e| err(format!("stored configuration: {e}")))?;
        let tick = r.u64()?;
        let acc = r.u64()?;
        let mut st = [0u64; 4];
        for s in st.iter_mut() {
            *s = r.u64()?;
        }
        let rng = match Rng::from_state(st) {
            Some(x) => x,
            None => return err("random generator state is all zero"),
        };
        let mut world = World::new(&cfg).or_else(|m| err(format!("world: {m}")))?;
        world.read_state(&mut r)?;
        let organisms = Organisms::read_state(&mut r, &cfg, &world.grid)?;
        let species = SpeciesRegistry::read_state(&mut r, &organisms)?;
        let stored_hash = r.str()?;
        r.finish()?;
        let mut spatial = SpatialIndex::new(world.grid);
        spatial.rebuild(&organisms);
        let sim = Simulation {
            organisms,
            species,
            spatial,
            last_births: [0; 3],
            last_deaths: [0; 3],
            last_plant_stats: Default::default(),
            last_herbivore_stats: Default::default(),
            last_carnivore_stats: Default::default(),
            last_reproduction_stats: Default::default(),
            config: cfg,
            world,
            rng,
            tick,
            acc,
            record_events: false,
        };
        sim.ledger_check().or_else(|m| err(format!("counters: {m}")))?;
        sim.check_index().or_else(|m| err(format!("index: {m}")))?;
        if sim.state_hash() != stored_hash {
            return err("restored state does not match the stored state hash");
        }
        Ok(sim)
    }
}

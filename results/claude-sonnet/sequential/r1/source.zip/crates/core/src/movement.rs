//! Animal sensing and movement (TASK-013, ADR-0017, docs/MOVEMENT.md).

use crate::config::Config;
use crate::grid::{Grid, Pos};
use crate::organism::{cell_limit, Id, Kind, Organism, Organisms};
use crate::rng::Rng;
use crate::spatial::{Hit, SpatialIndex};

/// Extra cost fraction per additional step taken in one tick (sprinting is superlinear).
pub const SPRINT: f64 = 0.1;
/// Probability that a wandering animal keeps its heading.
pub const KEEP_HEADING: f64 = 0.75;
/// King directions; heading h in 1..=8 maps to DIRS[h-1].
pub const DIRS: [(i32, i32); 8] = [(0, -1), (1, -1), (1, 0), (1, 1), (0, 1), (-1, 1), (-1, 0), (-1, -1)];

/// Vision radius in cells: floor(vision), at least 1.
pub fn vision_cells(o: &Organism) -> i64 {
    (o.traits.vision.floor() as i64).max(1)
}

/// Active organisms within vision (self and organisms marked dead excluded), ordered (dist, kind, id).
pub fn perceive(spatial: &SpatialIndex, orgs: &Organisms, id: Id) -> Vec<Hit> {
    let o = match orgs.find(id) {
        Some(o) => o,
        None => return Vec::new(),
    };
    spatial
        .query(o.pos, vision_cells(o), None)
        .into_iter()
        .filter(|h| h.id != id && orgs.get(h.kind, h.id).is_some_and(|x| x.is_active()))
        .collect()
}

/// Adds the speed to the credit and returns the whole steps allowed this tick; credit stays in [0,1).
pub fn step_allowance(o: &mut Organism) -> u32 {
    o.move_credit += o.traits.speed;
    let n = o.move_credit.floor();
    o.move_credit -= n;
    n as u32
}

/// Cells visited when walking up to `n` king steps from `from` toward `to` along the shortest wrapped way.
pub fn plan_path(grid: &Grid, from: Pos, to: Pos, n: u32) -> Vec<Pos> {
    let mut v = Vec::new();
    let mut p = from;
    for _ in 0..n {
        if p == to {
            break;
        }
        let d = grid.step_toward(p, to);
        p = grid.offset(p, d.dx as i64, d.dy as i64);
        v.push(p);
    }
    v
}

fn base_move_cost(cfg: &Config, kind: Kind) -> f64 {
    match kind {
        Kind::Carnivore => cfg.carnivores.move_cost,
        _ => cfg.herbivores.move_cost,
    }
}

/// Energy for `n` steps in one tick: move_cost * metabolism * n * (1 + SPRINT*(n-1)).
pub fn move_cost(cfg: &Config, o: &Organism, n: u32) -> f64 {
    if n == 0 {
        return 0.0;
    }
    base_move_cost(cfg, o.kind) * o.traits.metabolism * n as f64 * (1.0 + SPRINT * (n as f64 - 1.0))
}

/// Cell-sharing rule: may another organism of `kind` enter a cell already holding `present` of that kind?
pub fn can_enter(cfg: &Config, kind: Kind, present: u32) -> bool {
    cell_limit(cfg, kind).is_none_or(|l| present < l)
}

/// Reduces `n` until affordable with the current energy.
fn affordable_steps(cfg: &Config, o: &Organism, mut n: u32) -> u32 {
    while n > 0 && move_cost(cfg, o, n) > o.energy() {
        n -= 1;
    }
    n
}

/// Moves `o` along `path` (already limited), pays energy, updates the index. Returns steps taken.
pub(crate) fn apply_path(cfg: &Config, o: &mut Organism, path: &[Pos], spatial: &mut SpatialIndex) -> u32 {
    let n = affordable_steps(cfg, o, path.len() as u32);
    if n == 0 {
        return 0;
    }
    let dest = path[n as usize - 1];
    o.add_energy(-move_cost(cfg, o, n));
    o.pos = dest;
    let _ = spatial.move_to(o.id, dest);
    n
}

/// Moves toward `target` for at most `allowance` steps (no overshoot). Returns steps taken.
pub fn move_toward(cfg: &Config, o: &mut Organism, target: Pos, allowance: u32, grid: &Grid, spatial: &mut SpatialIndex) -> u32 {
    let path = plan_path(grid, o.pos, target, allowance);
    apply_path(cfg, o, &path, spatial)
}

/// What an animal of `kind` heads for.
fn target_kind(kind: Kind) -> Option<Kind> {
    match kind {
        Kind::Herbivore => Some(Kind::Plant),
        Kind::Carnivore => Some(Kind::Herbivore),
        Kind::Plant => None,
    }
}

/// Behaviour phase of all active animals of `kind`, ascending id.
pub fn run_animal_phase(kind: Kind, grid: &Grid, orgs: &mut Organisms, spatial: &mut SpatialIndex, cfg: &Config, rng: &mut Rng) {
    let want = match target_kind(kind) {
        Some(k) => k,
        None => return,
    };
    for id in orgs.active_ids(kind) {
        let hits = perceive(spatial, orgs, id);
        let target = hits.iter().find(|h| h.kind == want).copied();
        let o = match orgs.get_mut(kind, id) {
            Some(o) if o.is_active() => o,
            _ => continue,
        };
        let allowance = step_allowance(o);
        match target {
            Some(h) => {
                if h.dist > 0 {
                    move_toward(cfg, o, h.pos, allowance, grid, spatial);
                }
            }
            None => wander(cfg, o, allowance, grid, spatial, rng),
        }
    }
}

/// Correlated random walk: at most one step per tick, keeps the heading with p = KEEP_HEADING.
pub fn wander(cfg: &Config, o: &mut Organism, allowance: u32, grid: &Grid, spatial: &mut SpatialIndex, rng: &mut Rng) {
    if allowance == 0 {
        return;
    }
    if o.heading == 0 || rng.next_f64() >= KEEP_HEADING {
        o.heading = 1 + rng.below(8) as u8;
    }
    let (dx, dy) = DIRS[o.heading as usize - 1];
    let dest = grid.offset(o.pos, dx as i64, dy as i64);
    apply_path(cfg, o, &[dest], spatial);
}

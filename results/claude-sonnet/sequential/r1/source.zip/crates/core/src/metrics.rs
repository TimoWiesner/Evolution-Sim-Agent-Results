//! Metrics recorder (TASK-020, ADR-0024): a read-only observer of a `Simulation`.
//! Pure: no I/O, no clock, no RNG. It only holds its own previous counters (for interval values).
use crate::json::Value;
use crate::organism::{DeathCause, Kind, Organism, Traits, N_CAUSES};
use crate::sim::Simulation;

/// Trait names in file order.
pub const TRAIT_NAMES: [&str; 10] =
    ["speed", "strength", "fertility", "max_health", "max_lifespan", "max_energy", "metabolism", "vision", "aggression", "risk_tolerance"];

/// Trait values of `t` in `TRAIT_NAMES` order.
pub fn trait_values(t: &Traits) -> [f64; 10] {
    [t.speed, t.strength, t.fertility, t.max_health, t.max_lifespan as f64, t.max_energy, t.metabolism, t.vision, t.aggression, t.risk_tolerance]
}

/// Mean, population standard deviation, min, max. `None` for an empty slice.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Stats {
    pub mean: f64,
    pub sd: f64,
    pub min: f64,
    pub max: f64,
}

pub fn stats(values: &[f64]) -> Option<Stats> {
    if values.is_empty() {
        return None;
    }
    let n = values.len() as f64;
    let mean = values.iter().sum::<f64>() / n;
    let var = values.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / n;
    let min = values.iter().cloned().fold(f64::INFINITY, f64::min);
    let max = values.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    Some(Stats { mean, sd: var.sqrt(), min, max })
}

/// Plural key used in the file ("plants", "herbivores", "carnivores").
pub fn kind_key(k: Kind) -> &'static str {
    match k {
        Kind::Plant => "plants",
        Kind::Herbivore => "herbivores",
        Kind::Carnivore => "carnivores",
    }
}

fn int(v: u64) -> Value {
    Value::Int(v.min(i64::MAX as u64) as i64)
}

fn fl(v: f64) -> Value {
    if v.is_finite() {
        Value::Float(v)
    } else {
        Value::Null
    }
}

fn stats_json(s: Option<Stats>) -> Value {
    match s {
        Some(s) => Value::Object(vec![("mean".into(), fl(s.mean)), ("sd".into(), fl(s.sd)), ("min".into(), fl(s.min)), ("max".into(), fl(s.max))]),
        None => Value::Object(vec![("mean".into(), Value::Null), ("sd".into(), Value::Null), ("min".into(), Value::Null), ("max".into(), Value::Null)]),
    }
}

fn causes_json(c: &[u64; N_CAUSES]) -> Value {
    Value::Object(DeathCause::ALL.iter().map(|d| (d.name().to_string(), int(c[d.index()]))).collect())
}

/// Records one sample per call; samples are JSON objects (see docs/METRICS.md).
#[derive(Clone, Debug, Default)]
pub struct MetricsRecorder {
    prev: Option<Prev>,
    samples: Vec<Value>,
}

#[derive(Clone, Debug)]
struct Prev {
    births: [u64; 3],
    deaths: [u64; 3],
    causes: [[u64; N_CAUSES]; 3],
}

impl MetricsRecorder {
    pub fn new() -> MetricsRecorder {
        MetricsRecorder::default()
    }

    pub fn samples(&self) -> &[Value] {
        &self.samples
    }

    /// Records the state of `sim` as it is now. Interval values are 0 for the first sample.
    pub fn record(&mut self, sim: &Simulation) {
        let st = &sim.organisms.stats;
        let prev = self.prev.clone().unwrap_or(Prev { births: st.births, deaths: st.deaths, causes: st.deaths_by_cause });
        let mut items = vec![("tick".to_string(), int(sim.tick))];
        for k in Kind::ALL {
            let i = k.index();
            let orgs: &Vec<Organism> = sim.organisms.vec(k);
            let n = orgs.len();
            let mut ci = [0u64; N_CAUSES];
            for c in 0..N_CAUSES {
                ci[c] = st.deaths_by_cause[i][c] - prev.causes[i][c];
            }
            let gens: Vec<f64> = orgs.iter().map(|o| o.generation as f64).collect();
            let gs = stats(&gens);
            let energy: Vec<f64> = orgs.iter().map(|o| o.energy()).collect();
            let ages: Vec<f64> = orgs.iter().map(|o| o.age as f64).collect();
            let mut traits = Vec::new();
            for (ti, name) in TRAIT_NAMES.iter().enumerate() {
                let vals: Vec<f64> = orgs.iter().map(|o| trait_values(&o.traits)[ti]).collect();
                traits.push((name.to_string(), stats_json(stats(&vals))));
            }
            let opt = |s: Option<Stats>, f: fn(&Stats) -> f64| s.map(|s| fl(f(&s))).unwrap_or(Value::Null);
            items.push((
                kind_key(k).to_string(),
                Value::Object(vec![
                    ("population".into(), int(n as u64)),
                    ("births".into(), int(st.births[i])),
                    ("births_interval".into(), int(st.births[i] - prev.births[i])),
                    ("deaths".into(), int(st.deaths[i])),
                    ("deaths_interval".into(), int(st.deaths[i] - prev.deaths[i])),
                    ("deaths_by_cause".into(), causes_json(&st.deaths_by_cause[i])),
                    ("deaths_by_cause_interval".into(), causes_json(&ci)),
                    ("species".into(), int(sim.living_species(k) as u64)),
                    ("species_ever".into(), int(sim.species.records().iter().filter(|r| r.kind == k).count() as u64)),
                    ("generation_max".into(), opt(gs, |s| s.max)),
                    ("generation_mean".into(), opt(gs, |s| s.mean)),
                    ("mean_energy".into(), opt(stats(&energy), |s| s.mean)),
                    ("mean_age".into(), opt(stats(&ages), |s| s.mean)),
                    ("traits".into(), Value::Object(traits)),
                ]),
            ));
        }
        self.prev = Some(Prev { births: st.births, deaths: st.deaths, causes: st.deaths_by_cause });
        self.samples.push(Value::Object(items));
    }

    /// The whole metrics document (docs/METRICS.md).
    pub fn to_json(&self, seed: i64, tick_start: u64, tick_end: u64, sample_every: u64) -> Value {
        Value::Object(vec![
            ("format".into(), Value::Str("evosim-metrics".into())),
            ("version".into(), Value::Int(1)),
            ("seed".into(), Value::Int(seed)),
            ("tick_start".into(), int(tick_start)),
            ("tick_end".into(), int(tick_end)),
            ("sample_every".into(), int(sample_every)),
            ("kinds".into(), Value::Array(Kind::ALL.iter().map(|k| Value::Str(kind_key(*k).into())).collect())),
            ("traits".into(), Value::Array(TRAIT_NAMES.iter().map(|s| Value::Str((*s).into())).collect())),
            ("causes".into(), Value::Array(DeathCause::ALL.iter().map(|c| Value::Str(c.name().into())).collect())),
            ("samples".into(), Value::Array(self.samples.clone())),
        ])
    }
}

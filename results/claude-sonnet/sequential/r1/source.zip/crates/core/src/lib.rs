//! evosim-core: the simulation library (config, grid, rng, world, tick scheduler). No UI dependency.

pub mod carnivore;
pub mod checkpoint;
pub mod climate;
pub mod config;
pub mod genome;
pub mod grid;
pub mod hash;
pub mod herbivore;
pub mod json;
pub mod metrics;
pub mod movement;
pub mod organism;
pub mod plants;
pub mod reproduction;
pub mod rng;
pub mod sim;
pub mod ecology;
pub mod species;
pub mod spatial;
pub mod world;

pub const NAME: &str = "evosim";
pub const VERSION: &str = "0.1.0";
pub const CONTRACT_VERSION: u32 = 1;

/// The JSON object printed by `evosim version`.
pub fn version_json() -> String {
    format!(
        "{{\"name\":\"{}\",\"version\":\"{}\",\"contract\":{}}}",
        NAME, VERSION, CONTRACT_VERSION
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_json_is_exact() {
        assert_eq!(version_json(), r#"{"name":"evosim","version":"0.1.0","contract":1}"#);
    }

    #[test]
    fn contract_is_one() {
        assert_eq!(CONTRACT_VERSION, 1);
    }
}

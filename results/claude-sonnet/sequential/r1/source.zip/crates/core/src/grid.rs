//! Toroidal grid geometry (ADR-0008). Pure integer math, no dependencies.
//!
//! * Distance measure: **Chebyshev** of the shortest toroidal delta.
//! * Delta per axis lies in `(-N/2, N/2]`; an exact half-way tie goes positive.
//! * Radius queries visit every cell at most once, also when `r` exceeds the world.

/// A valid cell coordinate (construct through [`Grid`] to guarantee range).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Pos {
    pub x: i32,
    pub y: i32,
}

/// Shortest signed displacement between two cells.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct Delta {
    pub dx: i32,
    pub dy: i32,
}

/// A W x H torus, W,H >= 1.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Grid {
    w: u32,
    h: u32,
}

fn wrap_axis(v: i64, n: u32) -> i32 {
    v.rem_euclid(n as i64) as i32
}

fn delta_axis(a: i32, b: i32, n: u32) -> i32 {
    let n = n as i64;
    let d = (b as i64 - a as i64).rem_euclid(n);
    (if d > n / 2 { d - n } else { d }) as i32
}

/// Offsets visited on one axis for radius `r >= 0`: `(lo, count)`.
fn span(r: i64, n: u32) -> (i64, i64) {
    let n = n as i64;
    if 2 * r + 1 <= n {
        (-r, 2 * r + 1)
    } else {
        (-((n - 1) / 2), n)
    }
}

impl Grid {
    pub fn new(w: u32, h: u32) -> Result<Grid, String> {
        if w == 0 || h == 0 {
            return Err(format!("grid size must be >= 1x1, got {}x{}", w, h));
        }
        if w > i32::MAX as u32 || h > i32::MAX as u32 {
            return Err(format!("grid dimension too large: {}x{}", w, h));
        }
        match (w as u64).checked_mul(h as u64) {
            Some(c) if c <= u32::MAX as u64 && c <= usize::MAX as u64 => Ok(Grid { w, h }),
            _ => Err(format!("grid {}x{} has too many cells", w, h)),
        }
    }
    pub fn width(&self) -> u32 {
        self.w
    }
    pub fn height(&self) -> u32 {
        self.h
    }
    pub fn cell_count(&self) -> usize {
        self.w as usize * self.h as usize
    }
    pub fn wrap_x(&self, x: i64) -> i32 {
        wrap_axis(x, self.w)
    }
    pub fn wrap_y(&self, y: i64) -> i32 {
        wrap_axis(y, self.h)
    }
    /// Map any integer coordinate to a valid cell.
    pub fn wrap(&self, x: i64, y: i64) -> Pos {
        Pos { x: self.wrap_x(x), y: self.wrap_y(y) }
    }
    pub fn contains(&self, p: Pos) -> bool {
        p.x >= 0 && p.y >= 0 && (p.x as u32) < self.w && (p.y as u32) < self.h
    }
    /// Row-major cell index `y*W + x`; `p` must be valid.
    pub fn index(&self, p: Pos) -> usize {
        debug_assert!(self.contains(p));
        p.y as usize * self.w as usize + p.x as usize
    }
    pub fn pos_of(&self, i: usize) -> Pos {
        debug_assert!(i < self.cell_count());
        Pos { x: (i % self.w as usize) as i32, y: (i / self.w as usize) as i32 }
    }
    /// Move by an arbitrary offset, wrapping.
    pub fn offset(&self, p: Pos, dx: i64, dy: i64) -> Pos {
        self.wrap(p.x as i64 + dx, p.y as i64 + dy)
    }
    /// Shortest displacement a -> b.
    pub fn delta(&self, a: Pos, b: Pos) -> Delta {
        Delta { dx: delta_axis(a.x, b.x, self.w), dy: delta_axis(a.y, b.y, self.h) }
    }
    /// Chebyshev distance along the shortest way.
    pub fn dist(&self, a: Pos, b: Pos) -> u32 {
        let d = self.delta(a, b);
        d.dx.unsigned_abs().max(d.dy.unsigned_abs())
    }
    /// Unit step (-1/0/1 per axis) along the shortest way from a toward b.
    pub fn step_toward(&self, a: Pos, b: Pos) -> Delta {
        let d = self.delta(a, b);
        Delta { dx: d.dx.signum(), dy: d.dy.signum() }
    }
    /// Number of cells `cells_within` yields for radius `r`.
    pub fn count_within(&self, r: i64) -> usize {
        if r < 0 {
            return 0;
        }
        (span(r, self.w).1 * span(r, self.h).1) as usize
    }
    /// Call `f` for each distinct cell with distance <= r, row-major by offset
    /// (dy ascending, then dx ascending). Negative `r` visits nothing.
    pub fn for_each_cell_within<F: FnMut(Pos)>(&self, center: Pos, r: i64, mut f: F) {
        if r < 0 {
            return;
        }
        let (xlo, xn) = span(r, self.w);
        let (ylo, yn) = span(r, self.h);
        for j in 0..yn {
            let y = self.wrap_y(center.y as i64 + ylo + j);
            for i in 0..xn {
                f(Pos { x: self.wrap_x(center.x as i64 + xlo + i), y });
            }
        }
    }
    pub fn cells_within(&self, center: Pos, r: i64) -> Vec<Pos> {
        let mut v = Vec::with_capacity(self.count_within(r));
        self.for_each_cell_within(center, r, |p| v.push(p));
        v
    }
    /// Distinct cells at distance 1 (centre excluded; fewer than 8 on tiny worlds).
    pub fn neighbors8(&self, center: Pos) -> Vec<Pos> {
        self.cells_within(center, 1).into_iter().filter(|p| *p != center).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn g(w: u32, h: u32) -> Grid {
        Grid::new(w, h).unwrap()
    }
    fn p(x: i32, y: i32) -> Pos {
        Pos { x, y }
    }

    #[test]
    fn new_rejects_bad_sizes() {
        assert!(Grid::new(0, 5).is_err());
        assert!(Grid::new(5, 0).is_err());
        assert!(Grid::new(u32::MAX, u32::MAX).is_err());
        assert!(Grid::new(1, 1).is_ok());
    }

    #[test]
    fn wrap_negative_and_multiple() {
        let gr = g(7, 5);
        assert_eq!(gr.wrap(-1, -1), p(6, 4));
        assert_eq!(gr.wrap(-7, -5), p(0, 0));
        assert_eq!(gr.wrap(-8, -6), p(6, 4));
        assert_eq!(gr.wrap(7 * 1000 + 3, -5 * 1000 + 2), p(3, 2));
        assert_eq!(gr.wrap(i64::MIN, i64::MAX).x, i64::MIN.rem_euclid(7) as i32);
        assert!(gr.contains(gr.wrap(i64::MAX, i64::MIN)));
    }

    #[test]
    fn edges_and_corners() {
        let gr = g(6, 4);
        assert_eq!(gr.dist(p(0, 1), p(5, 1)), 1);
        assert_eq!(gr.delta(p(0, 1), p(5, 1)), Delta { dx: -1, dy: 0 });
        assert_eq!(gr.delta(p(5, 1), p(0, 1)), Delta { dx: 1, dy: 0 });
        assert_eq!(gr.delta(p(2, 0), p(2, 3)), Delta { dx: 0, dy: -1 });
        assert_eq!(gr.delta(p(2, 3), p(2, 0)), Delta { dx: 0, dy: 1 });
        assert_eq!(gr.delta(p(0, 0), p(5, 3)), Delta { dx: -1, dy: -1 });
        assert_eq!(gr.dist(p(0, 0), p(5, 3)), 1);
        assert_eq!(gr.dist(p(5, 0), p(0, 3)), 1);
        assert_eq!(gr.offset(p(5, 3), 1, 1), p(0, 0));
    }

    #[test]
    fn tie_goes_positive() {
        let gr = g(4, 4);
        assert_eq!(gr.delta(p(0, 0), p(2, 2)), Delta { dx: 2, dy: 2 });
        assert_eq!(gr.delta(p(2, 2), p(0, 0)), Delta { dx: 2, dy: 2 });
    }

    #[test]
    fn one_by_one() {
        let gr = g(1, 1);
        assert_eq!(gr.wrap(-123456789, 987654321), p(0, 0));
        assert_eq!(gr.dist(p(0, 0), p(0, 0)), 0);
        assert_eq!(gr.delta(p(0, 0), p(0, 0)), Delta { dx: 0, dy: 0 });
        assert_eq!(gr.cells_within(p(0, 0), 0), vec![p(0, 0)]);
        assert_eq!(gr.cells_within(p(0, 0), 50), vec![p(0, 0)]);
        assert!(gr.neighbors8(p(0, 0)).is_empty());
        assert_eq!(gr.index(p(0, 0)), 0);
    }

    #[test]
    fn within_negative_and_order() {
        let gr = g(5, 5);
        assert!(gr.cells_within(p(2, 2), -1).is_empty());
        let v = gr.cells_within(p(0, 0), 1);
        assert_eq!(v[0], p(4, 4));
        assert_eq!(v[1], p(0, 4));
        assert_eq!(v[2], p(1, 4));
        assert_eq!(v.len(), 9);
    }

    #[test]
    fn index_roundtrip() {
        let gr = g(3, 4);
        for i in 0..gr.cell_count() {
            assert_eq!(gr.index(gr.pos_of(i)), i);
        }
    }
}

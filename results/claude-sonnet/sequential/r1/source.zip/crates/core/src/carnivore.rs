//! Carnivore hunting (TASK-015, ADR-0019, docs/CARNIVORES.md).

use crate::config::Config;
use crate::herbivore::upkeep_cost;
use crate::movement::{move_toward, perceive, step_allowance, wander};
use crate::organism::{DeathCause, Id, Kind, Organism, Organisms};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;
use crate::world::World;

/// A carnivore attacks only prey within this Chebyshev distance (own or adjacent cell).
pub const ATTACK_REACH: u32 = 1;
/// Prey advantage factor in the attack formula.
pub const ESCAPE_BIAS: f64 = 2.0;
pub const P_MIN: f64 = 0.02;
pub const P_MAX: f64 = 0.95;

/// Energy accounting of one Carnivores phase.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct CarnivoreStats {
    pub attacks: u64,
    pub kills: u64,
    pub escapes: u64,
    /// Energy paid for attacks (hit or miss).
    pub attack_energy_paid: f64,
    /// Energy the killed prey had.
    pub prey_energy_taken: f64,
    /// Energy gained by carnivores (<= prey_energy_taken).
    pub gained_energy: f64,
    pub upkeep_paid: f64,
    pub climate_extra_paid: f64,
    /// Carnivore-ticks spent resting (handling time).
    pub rests: u64,
    /// Carnivores that were full and did not hunt.
    pub satiated: u64,
}

/// Success probability of an attack of carnivore `c` on herbivore `h` (ADR-0019 item 4).
pub fn attack_probability(c: &Organism, h: &Organism) -> f64 {
    let a = (1.0 + c.traits.strength) * (1.0 + c.traits.speed) * (0.5 + c.traits.aggression);
    let hp = if h.traits.max_health > 0.0 { h.health() / h.traits.max_health } else { 1.0 };
    let d = ESCAPE_BIAS * (1.0 + h.traits.strength) * (1.0 + h.traits.speed) * (0.5 + 0.5 * hp);
    (a / (a + d)).clamp(P_MIN, P_MAX)
}

/// Behaviour phase of all active carnivores, ascending id.
pub fn run_carnivore_phase(world: &World, orgs: &mut Organisms, spatial: &mut SpatialIndex, cfg: &Config, tick: u64, rng: &mut Rng) -> CarnivoreStats {
    let mut st = CarnivoreStats::default();
    let grid = &world.grid;
    let a = &cfg.carnivores;
    for id in orgs.active_ids(Kind::Carnivore) {
        // (a) running cost
        {
            let o = match orgs.get_mut(Kind::Carnivore, id) {
                Some(o) if o.is_active() => o,
                _ => continue,
            };
            let t = world.temp_at(o.pos);
            let cost = upkeep_cost(a, o, t);
            let base = a.base_metabolism * o.traits.metabolism;
            let paid = -o.add_energy(-cost);
            st.upkeep_paid += paid;
            st.climate_extra_paid += if cost > 0.0 { paid * (cost - base) / cost } else { 0.0 };
            // (b) handling time
            if o.rest > 0 {
                o.rest -= 1;
                st.rests += 1;
                continue;
            }
            // (c) satiated
            if o.energy() >= a.satiation_limit * o.traits.max_energy {
                st.satiated += 1;
                let allowance = step_allowance(o);
                wander(cfg, o, allowance, grid, spatial, rng);
                continue;
            }
        }
        // (d) choose the best prey: energy / (1 + dist) * p_est
        let hits = perceive(spatial, orgs, id);
        let mut target: Option<(Id, f64, u32)> = None;
        {
            let me = orgs.get(Kind::Carnivore, id).unwrap();
            for h in hits.iter().filter(|h| h.kind == Kind::Herbivore) {
                let prey = match orgs.get(Kind::Herbivore, h.id) {
                    Some(p) if p.is_active() => p,
                    _ => continue,
                };
                let s = prey.energy() / (1.0 + h.dist as f64) * attack_probability(me, prey);
                // hits are ordered (dist, kind, id): strict > keeps nearest, then lowest id
                if target.is_none_or(|t| s > t.1) {
                    target = Some((h.id, s, h.dist));
                }
            }
        }
        let (pid, _, _) = match target {
            Some(t) => t,
            None => {
                let o = orgs.get_mut(Kind::Carnivore, id).unwrap();
                let allowance = step_allowance(o);
                wander(cfg, o, allowance, grid, spatial, rng);
                continue;
            }
        };
        // (e) move toward the prey unless already in reach
        let ppos = orgs.get(Kind::Herbivore, pid).unwrap().pos;
        {
            let o = orgs.get_mut(Kind::Carnivore, id).unwrap();
            let allowance = step_allowance(o);
            if grid.dist(o.pos, ppos) > ATTACK_REACH {
                move_toward(cfg, o, ppos, allowance, grid, spatial);
            }
            // (f) one attack if in reach
            if grid.dist(o.pos, ppos) > ATTACK_REACH {
                continue;
            }
        }
        let cost = a.attack_cost * orgs.get(Kind::Carnivore, id).unwrap().traits.metabolism;
        let p = {
            let c = orgs.get(Kind::Carnivore, id).unwrap();
            if c.energy() <= 0.0 {
                continue;
            }
            let h = orgs.get(Kind::Herbivore, pid).unwrap();
            let base = attack_probability(c, h);
            if world.has_cover(h.pos) { base * (1.0 - cfg.climate.cover_protection) } else { base }
        };
        let paid = -orgs.get_mut(Kind::Carnivore, id).unwrap().add_energy(-cost);
        st.attack_energy_paid += paid;
        st.attacks += 1;
        if rng.next_f64() < p {
            // exactly-once guard: only the first successful mark_dead counts
            let prey_energy = orgs.get(Kind::Herbivore, pid).unwrap().energy();
            if orgs.mark_dead(pid, DeathCause::Predation, tick) {
                orgs.get_mut(Kind::Herbivore, pid).unwrap().set_energy(0.0);
                let c = orgs.get_mut(Kind::Carnivore, id).unwrap();
                let gain = c.add_energy(prey_energy * a.digestion_efficiency);
                c.rest = a.handling_time;
                st.kills += 1;
                st.prey_energy_taken += prey_energy;
                st.gained_energy += gain;
            }
        } else {
            st.escapes += 1;
        }
    }
    st
}

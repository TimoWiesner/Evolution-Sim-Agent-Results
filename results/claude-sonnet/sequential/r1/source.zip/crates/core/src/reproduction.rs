//! Animal sexual reproduction (TASK-016, ADR-0020, docs/REPRODUCTION.md).

use crate::config::{Animal, Config};
use crate::genome::{Genome, Mutation};
use crate::organism::{Id, Kind, NewBorn, Organism, Organisms};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;

/// Share of `n * offspring_energy` each parent pays (two parents pay 1.2x in total).
pub const REPRO_PARENT_SHARE: f64 = 0.6;
/// Energy a parent must keep after paying.
pub const MIN_KEEP: f64 = 1.0;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct ReproductionStats {
    pub eligible: u64,
    pub no_mate: u64,
    pub incompatible_seen: u64,
    pub conceptions_failed: u64,
    pub matings: u64,
    pub offspring: u64,
    pub energy_paid: f64,
    pub energy_to_offspring: f64,
    pub blocked_energy: u64,
}

fn group(cfg: &Config, kind: Kind) -> Option<&Animal> {
    match kind {
        Kind::Herbivore => Some(&cfg.herbivores),
        Kind::Carnivore => Some(&cfg.carnivores),
        Kind::Plant => None,
    }
}

/// Mature, fed, alive and off cooldown.
pub fn is_eligible(o: &Organism, a: &Animal) -> bool {
    o.alive && o.cooldown == 0 && o.age >= a.maturity_age && o.energy() >= a.reproduction_energy
}

/// Chance that a pair conceives: mean fertility.
pub fn conception_chance(a: &Organism, b: &Organism) -> f64 {
    ((a.traits.fertility + b.traits.fertility) / 2.0).clamp(0.0, 1.0)
}

/// Compatible iff the genetic distance does not exceed `genetics.species_threshold`.
pub fn compatible(a: &Organism, b: &Organism, cfg: &Config) -> bool {
    Genome::distance(a.genome(), b.genome()) <= cfg.genetics.species_threshold
}

/// Runs mate search and conception for both animal kinds; queues births (resolved afterwards).
pub fn run_reproduction_phase(orgs: &mut Organisms, spatial: &SpatialIndex, cfg: &Config, tick: u64, rng: &mut Rng) -> ReproductionStats {
    let _ = tick;
    let mut st = ReproductionStats::default();
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        let a = group(cfg, kind).unwrap();
        // pass 1: cooldown countdown (an animal that counts down is ineligible this tick)
        let ready: Vec<bool> = orgs
            .vec_mut(kind)
            .iter_mut()
            .map(|o| {
                if o.cooldown > 0 {
                    o.cooldown -= 1;
                    false
                } else {
                    true
                }
            })
            .collect();
        let mut mated: Vec<Id> = Vec::new(); // each animal mates at most once per tick
        let ids: Vec<Id> = orgs.vec(kind).iter().zip(ready).filter(|(o, r)| *r && o.alive).map(|(o, _)| o.id).collect();
        for id in ids {
            if mated.contains(&id) {
                continue;
            }
            let me = match orgs.get(kind, id) {
                Some(o) if is_eligible(o, a) => o,
                _ => continue,
            };
            st.eligible += 1;
            // mate choice: min (cell dist, genetic dist, id)
            let mut best: Option<(u32, f64, Id)> = None;
            for h in spatial.query(me.pos, a.mate_range as i64, Some(kind)) {
                if h.id == id || mated.contains(&h.id) {
                    continue;
                }
                let other = match orgs.get(kind, h.id) {
                    Some(o) if is_eligible(o, a) => o,
                    _ => continue,
                };
                let d = Genome::distance(me.genome(), other.genome());
                if d > cfg.genetics.species_threshold {
                    st.incompatible_seen += 1;
                    continue;
                }
                let key = (h.dist, d, h.id);
                let better = match best {
                    None => true,
                    Some(b) => key.0 < b.0 || (key.0 == b.0 && (key.1 < b.1 || (key.1 == b.1 && key.2 < b.2))),
                };
                if better {
                    best = Some(key);
                }
            }
            let mid = match best {
                Some(b) => b.2,
                None => {
                    st.no_mate += 1;
                    continue;
                }
            };
            let (pa, pb) = (orgs.get(kind, id).unwrap(), orgs.get(kind, mid).unwrap());
            let fert = conception_chance(pa, pb);
            if !(rng.next_f64() < fert) {
                st.conceptions_failed += 1;
                continue;
            }
            // litter: 1 + Binomial(litter_size - 1, fertility)
            let mut n = 1u32;
            for _ in 1..a.litter_size {
                if rng.next_f64() < fert {
                    n += 1;
                }
            }
            // affordability: each parent keeps at least MIN_KEEP
            let poorer = pa.energy().min(pb.energy());
            let unit = REPRO_PARENT_SHARE * a.offspring_energy;
            if unit > 0.0 {
                let max_n = ((poorer - MIN_KEEP) / unit).floor();
                if max_n < 1.0 {
                    st.blocked_energy += 1;
                    continue;
                }
                n = n.min(max_n as u32);
            }
            let pos = pa.pos;
            let (ga, gb) = (pa.genome().clone(), pb.genome().clone());
            let mutation = Mutation::for_kind(cfg, kind);
            let cost = unit * n as f64;
            let mut born = 0;
            let mut to_off = 0.0;
            for _ in 0..n {
                let genome = Genome::child_of_two(&ga, &gb, cfg.genetics.crossover_rate, &mutation, rng);
                let nb = NewBorn { kind, pos, parents: [id, mid], genome, energy: a.offspring_energy };
                if orgs.queue_birth(nb) {
                    born += 1;
                    to_off += a.offspring_energy;
                }
            }
            if born == 0 {
                continue;
            }
            let cost = cost * born as f64 / n as f64;
            for pid in [id, mid] {
                let p = orgs.get_mut(kind, pid).unwrap();
                let paid = -p.add_energy(-cost);
                st.energy_paid += paid;
                p.cooldown = a.reproduction_cooldown;
            }
            mated.push(id);
            mated.push(mid);
            st.matings += 1;
            st.offspring += born as u64;
            st.energy_to_offspring += to_off;
        }
    }
    st
}

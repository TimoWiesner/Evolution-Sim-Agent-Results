//! Minimal strict JSON (RFC 8259) parser and deterministic writer.
//! Integers without fraction/exponent that fit i64 are `Int`; everything else numeric is `Float`.
//! Duplicate object keys are an error. Object key order is preserved.

use std::fmt;

#[derive(Clone, Debug, PartialEq)]
pub enum Value {
    Null,
    Bool(bool),
    Int(i64),
    Float(f64),
    Str(String),
    Array(Vec<Value>),
    Object(Vec<(String, Value)>),
}

#[derive(Clone, Debug, PartialEq)]
pub struct JsonError {
    pub line: usize,
    pub col: usize,
    pub msg: String,
    /// Set for duplicate-key errors.
    pub key: Option<String>,
}

impl fmt::Display for JsonError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid JSON at line {}, column {}: {}", self.line, self.col, self.msg)
    }
}

const MAX_DEPTH: usize = 64;

pub fn parse(text: &str) -> Result<Value, JsonError> {
    let mut p = Parser { s: text.as_bytes(), text, i: 0 };
    p.ws();
    let v = p.value(0)?;
    p.ws();
    if p.i < p.s.len() {
        return Err(p.err("trailing characters after JSON value"));
    }
    Ok(v)
}

struct Parser<'a> {
    s: &'a [u8],
    text: &'a str,
    i: usize,
}

impl<'a> Parser<'a> {
    fn err(&self, msg: &str) -> JsonError {
        let before = &self.s[..self.i.min(self.s.len())];
        let line = before.iter().filter(|&&b| b == b'\n').count() + 1;
        let col = before.iter().rev().take_while(|&&b| b != b'\n').count() + 1;
        JsonError { line, col, msg: msg.to_string(), key: None }
    }
    fn ws(&mut self) {
        while self.i < self.s.len() && matches!(self.s[self.i], b' ' | b'\t' | b'\n' | b'\r') {
            self.i += 1;
        }
    }
    fn peek(&self) -> Option<u8> {
        self.s.get(self.i).copied()
    }
    fn lit(&mut self, word: &str, v: Value) -> Result<Value, JsonError> {
        if self.s[self.i..].starts_with(word.as_bytes()) {
            self.i += word.len();
            Ok(v)
        } else {
            Err(self.err("invalid literal"))
        }
    }
    fn value(&mut self, depth: usize) -> Result<Value, JsonError> {
        if depth > MAX_DEPTH {
            return Err(self.err("nesting too deep"));
        }
        match self.peek() {
            None => Err(self.err("unexpected end of input")),
            Some(b'{') => self.object(depth),
            Some(b'[') => self.array(depth),
            Some(b'"') => Ok(Value::Str(self.string()?)),
            Some(b't') => self.lit("true", Value::Bool(true)),
            Some(b'f') => self.lit("false", Value::Bool(false)),
            Some(b'n') => self.lit("null", Value::Null),
            Some(b'-') | Some(b'0'..=b'9') => self.number(),
            Some(_) => Err(self.err("unexpected character")),
        }
    }
    fn object(&mut self, depth: usize) -> Result<Value, JsonError> {
        self.i += 1;
        let mut items: Vec<(String, Value)> = Vec::new();
        self.ws();
        if self.peek() == Some(b'}') {
            self.i += 1;
            return Ok(Value::Object(items));
        }
        loop {
            self.ws();
            if self.peek() != Some(b'"') {
                return Err(self.err("expected string key"));
            }
            let kpos = self.i;
            let k = self.string()?;
            if items.iter().any(|(e, _)| *e == k) {
                self.i = kpos;
                let mut e = self.err(&format!("duplicate key `{}`", k));
                e.key = Some(k);
                return Err(e);
            }
            self.ws();
            if self.peek() != Some(b':') {
                return Err(self.err("expected ':'"));
            }
            self.i += 1;
            self.ws();
            let v = self.value(depth + 1)?;
            items.push((k, v));
            self.ws();
            match self.peek() {
                Some(b',') => self.i += 1,
                Some(b'}') => {
                    self.i += 1;
                    return Ok(Value::Object(items));
                }
                _ => return Err(self.err("expected ',' or '}'")),
            }
        }
    }
    fn array(&mut self, depth: usize) -> Result<Value, JsonError> {
        self.i += 1;
        let mut items = Vec::new();
        self.ws();
        if self.peek() == Some(b']') {
            self.i += 1;
            return Ok(Value::Array(items));
        }
        loop {
            self.ws();
            items.push(self.value(depth + 1)?);
            self.ws();
            match self.peek() {
                Some(b',') => self.i += 1,
                Some(b']') => {
                    self.i += 1;
                    return Ok(Value::Array(items));
                }
                _ => return Err(self.err("expected ',' or ']'")),
            }
        }
    }
    fn hex4(&mut self) -> Result<u32, JsonError> {
        if self.i + 4 > self.s.len() {
            return Err(self.err("truncated \\u escape"));
        }
        let h = std::str::from_utf8(&self.s[self.i..self.i + 4]).map_err(|_| self.err("bad \\u escape"))?;
        if !h.bytes().all(|b| b.is_ascii_hexdigit()) {
            return Err(self.err("bad \\u escape"));
        }
        self.i += 4;
        Ok(u32::from_str_radix(h, 16).unwrap())
    }
    fn string(&mut self) -> Result<String, JsonError> {
        self.i += 1;
        let mut out = String::new();
        loop {
            let start = self.i;
            while self.i < self.s.len() && self.s[self.i] != b'"' && self.s[self.i] != b'\\' && self.s[self.i] >= 0x20 {
                self.i += 1;
            }
            out.push_str(&self.text[start..self.i]);
            match self.peek() {
                None => return Err(self.err("unterminated string")),
                Some(b'"') => {
                    self.i += 1;
                    return Ok(out);
                }
                Some(b'\\') => {
                    self.i += 1;
                    let c = self.peek().ok_or_else(|| self.err("unterminated string"))?;
                    self.i += 1;
                    match c {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let mut cp = self.hex4()?;
                            if (0xD800..0xDC00).contains(&cp) {
                                if self.s[self.i..].starts_with(b"\\u") {
                                    self.i += 2;
                                    let lo = self.hex4()?;
                                    if !(0xDC00..0xE000).contains(&lo) {
                                        return Err(self.err("invalid surrogate pair"));
                                    }
                                    cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                                } else {
                                    return Err(self.err("lone surrogate"));
                                }
                            }
                            out.push(char::from_u32(cp).ok_or_else(|| self.err("invalid code point"))?);
                        }
                        _ => return Err(self.err("invalid escape")),
                    }
                }
                Some(_) => return Err(self.err("control character in string")),
            }
        }
    }
    fn number(&mut self) -> Result<Value, JsonError> {
        let start = self.i;
        if self.peek() == Some(b'-') {
            self.i += 1;
        }
        match self.peek() {
            Some(b'0') => self.i += 1,
            Some(b'1'..=b'9') => self.digits(),
            _ => return Err(self.err("invalid number")),
        }
        let mut is_float = false;
        if self.peek() == Some(b'.') {
            is_float = true;
            self.i += 1;
            if !matches!(self.peek(), Some(b'0'..=b'9')) {
                return Err(self.err("digits expected after '.'"));
            }
            self.digits();
        }
        if matches!(self.peek(), Some(b'e') | Some(b'E')) {
            is_float = true;
            self.i += 1;
            if matches!(self.peek(), Some(b'+') | Some(b'-')) {
                self.i += 1;
            }
            if !matches!(self.peek(), Some(b'0'..=b'9')) {
                return Err(self.err("digits expected in exponent"));
            }
            self.digits();
        }
        let t = &self.text[start..self.i];
        if !is_float {
            if let Ok(n) = t.parse::<i64>() {
                return Ok(Value::Int(n));
            }
        }
        let f: f64 = t.parse().map_err(|_| self.err("invalid number"))?;
        if !f.is_finite() {
            return Err(self.err("number out of range"));
        }
        Ok(Value::Float(f))
    }
    fn digits(&mut self) {
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.i += 1;
        }
    }
}

impl Value {
    pub fn get(&self, key: &str) -> Option<&Value> {
        match self {
            Value::Object(items) => items.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }

    pub fn type_name(&self) -> &'static str {
        match self {
            Value::Null => "null",
            Value::Bool(_) => "boolean",
            Value::Int(_) => "integer",
            Value::Float(_) => "float",
            Value::Str(_) => "string",
            Value::Array(_) => "array",
            Value::Object(_) => "object",
        }
    }

    pub fn to_compact(&self) -> String {
        let mut s = String::new();
        self.write(&mut s, None, 0);
        s
    }

    /// Two-space indented output, trailing newline.
    pub fn to_pretty(&self) -> String {
        let mut s = String::new();
        self.write(&mut s, Some(2), 0);
        s.push('\n');
        s
    }

    fn write(&self, out: &mut String, indent: Option<usize>, level: usize) {
        match self {
            Value::Null => out.push_str("null"),
            Value::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
            Value::Int(n) => out.push_str(&n.to_string()),
            Value::Float(f) => out.push_str(&format_float(*f)),
            Value::Str(s) => write_str(out, s),
            Value::Array(a) => {
                if a.is_empty() {
                    out.push_str("[]");
                    return;
                }
                out.push('[');
                for (i, v) in a.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    newline(out, indent, level + 1);
                    v.write(out, indent, level + 1);
                }
                newline(out, indent, level);
                out.push(']');
            }
            Value::Object(o) => {
                if o.is_empty() {
                    out.push_str("{}");
                    return;
                }
                out.push('{');
                for (i, (k, v)) in o.iter().enumerate() {
                    if i > 0 {
                        out.push(',');
                    }
                    newline(out, indent, level + 1);
                    write_str(out, k);
                    out.push(':');
                    if indent.is_some() {
                        out.push(' ');
                    }
                    v.write(out, indent, level + 1);
                }
                newline(out, indent, level);
                out.push('}');
            }
        }
    }
}

fn newline(out: &mut String, indent: Option<usize>, level: usize) {
    if let Some(n) = indent {
        out.push('\n');
        for _ in 0..n * level {
            out.push(' ');
        }
    }
}

/// Shortest round-trip representation, always recognisable as a float (contains '.').
/// Non-finite values (not representable in JSON) are written as 0.0.
pub fn format_float(f: f64) -> String {
    if !f.is_finite() {
        return "0.0".to_string();
    }
    let s = format!("{}", f);
    if s.contains('.') || s.contains('e') || s.contains('E') {
        s
    } else {
        format!("{}.0", s)
    }
}

fn write_str(out: &mut String, s: &str) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_scalars_and_containers() {
        let v = parse(r#" {"a":1,"b":-2.5e1,"c":[true,false,null],"d":"x\n\u00e9\ud83d\ude00","e":{}} "#).unwrap();
        assert_eq!(v.get("a"), Some(&Value::Int(1)));
        assert_eq!(v.get("b"), Some(&Value::Float(-25.0)));
        assert_eq!(v.get("c"), Some(&Value::Array(vec![Value::Bool(true), Value::Bool(false), Value::Null])));
        assert_eq!(v.get("d"), Some(&Value::Str("x\né😀".into())));
        assert_eq!(v.get("e"), Some(&Value::Object(vec![])));
    }

    #[test]
    fn int_vs_float() {
        assert_eq!(parse("64").unwrap(), Value::Int(64));
        assert_eq!(parse("64.0").unwrap(), Value::Float(64.0));
        assert_eq!(parse("1e2").unwrap(), Value::Float(100.0));
        assert_eq!(parse("99999999999999999999").unwrap(), Value::Float(1e20));
        assert!(matches!(parse("-0").unwrap(), Value::Int(0)));
    }

    #[test]
    fn rejects_invalid() {
        for bad in [
            "", "{", "[1,]", "{\"a\":1,}", "01", "1.", ".5", "+1", "1e", "nul", "\"abc", "\"\\x\"", "{\"a\" 1}",
            "[1 2]", "1 2", "\"a\nb\"", "{1:2}", "\"\\ud800\"", "1e999", "NaN", "Infinity", "'a'",
        ] {
            assert!(parse(bad).is_err(), "should reject {:?}", bad);
        }
    }

    #[test]
    fn duplicate_key_error_names_key() {
        let e = parse(r#"{"seed":1,"seed":2}"#).unwrap_err();
        assert_eq!(e.key.as_deref(), Some("seed"));
        assert!(e.to_string().contains("seed"));
    }

    #[test]
    fn error_position() {
        let e = parse("{\n  \"a\": ?\n}").unwrap_err();
        assert_eq!((e.line, e.col), (2, 8));
    }

    #[test]
    fn depth_limit() {
        let deep = "[".repeat(100) + &"]".repeat(100);
        assert!(parse(&deep).is_err());
        let ok = "[".repeat(30) + &"]".repeat(30);
        assert!(parse(&ok).is_ok());
    }

    #[test]
    fn write_parse_round_trip() {
        let v = Value::Object(vec![
            ("s".into(), Value::Str("q\"\\\n\t\u{1}é".into())),
            ("f".into(), Value::Float(0.1)),
            ("g".into(), Value::Float(3.0)),
            ("i".into(), Value::Int(i64::MIN)),
            ("a".into(), Value::Array(vec![Value::Null, Value::Bool(true), Value::Array(vec![])])),
        ]);
        assert_eq!(parse(&v.to_compact()).unwrap(), v);
        assert_eq!(parse(&v.to_pretty()).unwrap(), v);
    }

    #[test]
    fn floats_round_trip_exactly() {
        for f in [0.1, 1e-300, 1e300, 5e-324, 1.7976931348623157e308, -0.0, 123456.789, 3.0, 1.0 / 3.0] {
            let s = format_float(f);
            match parse(&s).unwrap() {
                Value::Float(g) => assert_eq!(f.to_bits(), g.to_bits(), "{}", s),
                other => panic!("{} parsed as {:?}", s, other),
            }
        }
    }
}

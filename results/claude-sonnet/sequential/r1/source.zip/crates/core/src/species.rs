//! Species recognition and family tree (TASK-017, ADR-0021).
//!
//! Rule: organism O belongs to species S (same kind) iff `Genome::distance(O.genome, S.reference) <= genetics.species_threshold`.
//! `reference` is frozen at founding. Never draws from the RNG; nothing in the simulation reads it.
use crate::config::Config;
use crate::genome::Genome;
use crate::organism::{Id, Kind, Organisms};

pub type SpeciesId = u32;

#[derive(Clone, Debug, PartialEq)]
pub struct SpeciesRecord {
    pub id: SpeciesId,
    pub kind: Kind,
    pub name: String,
    /// 0 = founder species (no parent).
    pub parent: SpeciesId,
    pub arose: u64,
    pub extinct: Option<u64>,
    pub reference: Genome,
    pub founded_by: Id,
    genus: u32,
}

#[derive(Clone, Debug, Default)]
pub struct SpeciesRegistry {
    records: Vec<SpeciesRecord>,
    counts: Vec<u64>,
    roots: [u32; 3],
    /// Epithets handed out per (kind, genus).
    epithets: Vec<(usize, u32, u32)>,
}

const CONS: &[u8] = b"bdfgklmnprstvz";
const VOW: &[u8] = b"aeiou";

/// Bijective syllable word for n >= 0 (consonant-vowel pairs): injective in n.
pub fn syllable_word(n: u64) -> String {
    let base = (CONS.len() * VOW.len()) as u64;
    let mut m = n + 1;
    let mut out = Vec::new();
    while m > 0 {
        let d = ((m - 1) % base) as usize;
        out.push(d);
        m = (m - 1) / base;
    }
    let mut s = String::new();
    for d in out.into_iter().rev() {
        s.push(CONS[d / VOW.len()] as char);
        s.push(VOW[d % VOW.len()] as char);
    }
    s
}

fn genus_name(kind: Kind, n: u64) -> String {
    let w = syllable_word(n);
    let mut c = w.chars();
    let first = c.next().map(|f| f.to_ascii_uppercase()).unwrap_or('X');
    let end = match kind {
        Kind::Plant => "a",
        Kind::Herbivore => "us",
        Kind::Carnivore => "ax",
    };
    format!("{}{}{}", first, c.as_str(), end)
}

impl SpeciesRegistry {
    pub fn new() -> SpeciesRegistry {
        SpeciesRegistry::default()
    }

    pub fn records(&self) -> &[SpeciesRecord] {
        &self.records
    }
    pub fn get(&self, id: SpeciesId) -> Option<&SpeciesRecord> {
        if id == 0 {
            return None;
        }
        self.records.get(id as usize - 1)
    }
    pub fn parent_of(&self, id: SpeciesId) -> Option<SpeciesId> {
        self.get(id).map(|r| r.parent)
    }
    /// Ancestor chain starting with `id` itself, ending at the founder species.
    pub fn lineage(&self, id: SpeciesId) -> Vec<SpeciesId> {
        let mut v = Vec::new();
        let mut cur = id;
        while let Some(r) = self.get(cur) {
            v.push(cur);
            cur = r.parent;
        }
        v
    }
    pub fn children(&self, id: SpeciesId) -> Vec<SpeciesId> {
        self.records.iter().filter(|r| r.parent == id && r.id != id).map(|r| r.id).collect()
    }
    /// Living members of a species as of the last `finish_tick`.
    pub fn members(&self, id: SpeciesId) -> u64 {
        if id == 0 {
            return 0;
        }
        self.counts.get(id as usize - 1).copied().unwrap_or(0)
    }
    /// Living (not extinct) species of a kind now.
    pub fn living(&self, kind: Kind) -> usize {
        self.records.iter().filter(|r| r.kind == kind && r.extinct.is_none()).count()
    }
    /// Species of `kind` that existed at the end of tick `t`.
    pub fn living_at(&self, kind: Kind, t: u64) -> usize {
        self.records.iter().filter(|r| r.kind == kind && r.arose <= t && r.extinct.map_or(true, |e| e > t)).count()
    }

    fn found(&mut self, kind: Kind, parent: SpeciesId, tick: u64, reference: Genome, founded_by: Id) -> SpeciesId {
        let id = self.records.len() as u32 + 1;
        let ki = kind.index();
        let (genus, name) = if parent == 0 {
            let g = self.roots[ki];
            self.roots[ki] += 1;
            self.epithets.push((ki, g, 1));
            (g, format!("{} {}", genus_name(kind, g as u64), syllable_word(0)))
        } else {
            let g = self.get(parent).map(|r| r.genus).unwrap_or(0);
            let slot = self.epithets.iter_mut().find(|e| e.0 == ki && e.1 == g);
            let n = match slot {
                Some(e) => {
                    let n = e.2;
                    e.2 += 1;
                    n
                }
                None => {
                    self.epithets.push((ki, g, 1));
                    0
                }
            };
            (g, format!("{} {}", genus_name(kind, g as u64), syllable_word(n as u64)))
        };
        self.records.push(SpeciesRecord { id, kind, name, parent, arose: tick, extinct: None, reference, founded_by, genus });
        self.counts.push(0);
        id
    }

    /// Re-classifies every living organism (see ADR-0021). Run on check ticks.
    pub fn classify(&mut self, orgs: &mut Organisms, cfg: &Config, tick: u64) {
        let thr = cfg.genetics.species_threshold;
        let min_size = cfg.genetics.species_min_size as usize;
        for kind in Kind::ALL {
            let cands: Vec<SpeciesId> = self.records.iter().filter(|r| r.kind == kind && r.extinct.is_none()).map(|r| r.id).collect();
            let mut unassigned: Vec<usize> = Vec::new();
            let mut outliers: Vec<usize> = Vec::new();
            let n = orgs.vec(kind).len();
            for i in 0..n {
                let (alive, sp, g) = {
                    let o = &orgs.vec(kind)[i];
                    (o.alive, o.species, *o.genome())
                };
                if !alive {
                    continue;
                }
                if sp != 0 {
                    if let Some(r) = self.get(sp) {
                        if r.kind == kind && r.extinct.is_none() && Genome::distance(&g, &r.reference) <= thr {
                            continue;
                        }
                    }
                }
                let mut best: Option<(f64, SpeciesId)> = None;
                for &c in &cands {
                    let d = Genome::distance(&g, &self.records[c as usize - 1].reference);
                    if d <= thr && best.map_or(true, |(bd, _)| d < bd) {
                        best = Some((d, c));
                    }
                }
                match best {
                    Some((_, c)) => orgs.vec_mut(kind)[i].species = c,
                    None if sp == 0 => unassigned.push(i),
                    None => outliers.push(i),
                }
            }
            // Unassigned: every cluster founds a root species, regardless of size.
            for cl in Self::cluster(orgs, kind, &unassigned, thr) {
                let seed = &orgs.vec(kind)[cl[0]];
                let (sg, sid) = (*seed.genome(), seed.id);
                let id = self.found(kind, 0, tick, sg, sid);
                for i in cl {
                    orgs.vec_mut(kind)[i].species = id;
                }
            }
            // Outliers of an existing species: only clusters of >= min_size split off.
            for cl in Self::cluster(orgs, kind, &outliers, thr) {
                if cl.len() < min_size {
                    continue;
                }
                let seed = &orgs.vec(kind)[cl[0]];
                let (sg, sid, parent) = (*seed.genome(), seed.id, seed.species);
                let id = self.found(kind, parent, tick, sg, sid);
                for i in cl {
                    orgs.vec_mut(kind)[i].species = id;
                }
            }
        }
    }

    /// Greedy clustering in index (= id) order: first cluster whose seed is within `thr`.
    fn cluster(orgs: &Organisms, kind: Kind, idx: &[usize], thr: f64) -> Vec<Vec<usize>> {
        let mut cl: Vec<Vec<usize>> = Vec::new();
        for &i in idx {
            let g = orgs.vec(kind)[i].genome();
            let hit = cl.iter().position(|c| Genome::distance(g, orgs.vec(kind)[c[0]].genome()) <= thr);
            match hit {
                Some(k) => cl[k].push(i),
                None => cl.push(vec![i]),
            }
        }
        cl
    }

    /// Counts living members and records extinctions. Run at the end of every Births phase.
    pub fn finish_tick(&mut self, orgs: &Organisms, tick: u64) {
        for c in self.counts.iter_mut() {
            *c = 0;
        }
        for k in Kind::ALL {
            for o in orgs.vec(k) {
                if o.alive && o.species != 0 {
                    if let Some(c) = self.counts.get_mut(o.species as usize - 1) {
                        *c += 1;
                    }
                }
            }
        }
        for (r, &c) in self.records.iter_mut().zip(self.counts.iter()) {
            if c == 0 && r.extinct.is_none() {
                r.extinct = Some(tick);
            }
        }
    }

    /// Checkpoint: records (incl. the private genus), member counts, genus counters and epithet slots.
    pub fn write_state(&self, w: &mut crate::checkpoint::Writer) {
        w.u64(self.records.len() as u64);
        for r in &self.records {
            w.u32(r.id);
            w.u8(r.kind.index() as u8);
            w.str(&r.name);
            w.u32(r.parent);
            w.u64(r.arose);
            match r.extinct {
                None => w.u8(0),
                Some(t) => {
                    w.u8(1);
                    w.u64(t);
                }
            }
            r.reference.write_state(w);
            w.u64(r.founded_by);
            w.u32(r.genus);
        }
        for c in &self.counts {
            w.u64(*c);
        }
        for x in self.roots {
            w.u32(x);
        }
        w.u64(self.epithets.len() as u64);
        for e in &self.epithets {
            w.u8(e.0 as u8);
            w.u32(e.1);
            w.u32(e.2);
        }
    }

    pub fn read_state(r: &mut crate::checkpoint::Reader, orgs: &Organisms) -> crate::checkpoint::Res<SpeciesRegistry> {
        use crate::checkpoint::err;
        let mut reg = SpeciesRegistry::new();
        let n = r.count(4 + 1 + 8 + 4 + 8 + 1 + 80 + 8 + 4 + 8)?;
        for i in 0..n {
            let id = r.u32()?;
            if id as usize != i + 1 {
                return err("species ids are not consecutive");
            }
            let kind = match Kind::from_index(r.u8()?) {
                Some(k) => k,
                None => return err("unknown kind in species record"),
            };
            let name = r.str()?;
            let parent = r.u32()?;
            if parent as usize > n {
                return err("species parent out of range");
            }
            let arose = r.u64()?;
            let extinct = match r.u8()? {
                0 => None,
                1 => Some(r.u64()?),
                _ => return err("bad extinct flag"),
            };
            let reference = Genome::read_state(r)?;
            let founded_by = r.u64()?;
            let genus = r.u32()?;
            reg.records.push(SpeciesRecord { id, kind, name, parent, arose, extinct, reference, founded_by, genus });
        }
        if r.remaining() < n.saturating_mul(8) {
            return err("unexpected end of data");
        }
        for _ in 0..n {
            reg.counts.push(r.u64()?);
        }
        for x in reg.roots.iter_mut() {
            *x = r.u32()?;
        }
        let m = r.count(9)?;
        for _ in 0..m {
            let k = r.u8()? as usize;
            if k > 2 {
                return err("bad epithet kind");
            }
            reg.epithets.push((k, r.u32()?, r.u32()?));
        }
        for k in Kind::ALL {
            if orgs.vec(k).iter().any(|o| o.species as usize > n) {
                return err("organism refers to an unknown species");
            }
        }
        Ok(reg)
    }

    pub fn state_words(&self, f: &mut dyn FnMut(u64)) {
        f(self.records.len() as u64);
        for r in &self.records {
            f(r.id as u64);
            f(r.kind.index() as u64);
            f(r.parent as u64);
            f(r.arose);
            f(r.extinct.map_or(u64::MAX, |e| e));
            f(r.founded_by);
            r.reference.state_words(f);
        }
    }
}

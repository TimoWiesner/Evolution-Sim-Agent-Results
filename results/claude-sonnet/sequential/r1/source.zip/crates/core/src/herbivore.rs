//! Herbivore feeding, running costs and decisions (TASK-014, ADR-0018, docs/HERBIVORES.md).

use crate::config::{Animal, Config};
use crate::grid::Pos;
use crate::movement::{move_toward, perceive, step_allowance, wander};
use crate::organism::{DeathCause, Id, Kind, Organism, Organisms};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;
use crate::world::World;

/// A herbivore eats only plants within this Chebyshev distance (own cell and the 8 neighbours).
pub const FEED_REACH: u32 = 1;
/// Weight of nearby carnivores in the food score.
pub const DANGER_W: f64 = 4.0;
/// The climate excess is capped at this many tolerance widths.
pub const MAX_EXCESS: f64 = 4.0;

/// Energy accounting of one Herbivores phase.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct HerbivoreStats {
    /// Energy removed from plants.
    pub eaten_energy: f64,
    /// Energy gained by herbivores (<= eaten_energy).
    pub gained_energy: f64,
    pub bites: u64,
    pub plants_killed: u64,
    /// Running cost actually paid (includes the climate extra).
    pub upkeep_paid: f64,
    /// Part of `upkeep_paid` caused by climate.
    pub climate_extra_paid: f64,
    /// Herbivores that were full and did not eat.
    pub satiated: u64,
}

/// Upkeep multiplier for temperature `t`: 1 + climate_cost * min(excess, 4), excess = max(0, |t - comfort| - tolerance) / tolerance.
pub fn climate_mult(a: &Animal, t: f64) -> f64 {
    let excess = ((t - a.temp_comfort).abs() - a.temp_tolerance).max(0.0) / a.temp_tolerance;
    1.0 + a.climate_cost * excess.min(MAX_EXCESS)
}

/// Running cost per tick at temperature `t`: base_metabolism * metabolism * climate_mult.
pub fn upkeep_cost(a: &Animal, o: &Organism, t: f64) -> f64 {
    a.base_metabolism * o.traits.metabolism * climate_mult(a, t)
}

/// Maximum plant energy taken in one tick: bite_size * (0.5 + aggression).
pub fn bite_size(cfg: &Config, o: &Organism) -> f64 {
    cfg.herbivores.bite_size * (0.5 + o.traits.aggression)
}

/// Food score of a plant (see ADR-0018 item 7). Higher is better.
#[allow(clippy::too_many_arguments)]
pub fn score_plant(bite: f64, digestion: f64, plant_energy: f64, dist: u32, aggression: f64, risk_tolerance: f64, others: u32, danger: f64) -> f64 {
    let value = bite.min(plant_energy) * digestion;
    value / (1.0 + dist as f64) / (1.0 + (1.0 - aggression) * others as f64) / (1.0 + (1.0 - risk_tolerance) * DANGER_W * danger)
}

struct Cand {
    id: Id,
    pos: Pos,
    energy: f64,
}

/// Behaviour phase of all active herbivores, ascending id.
pub fn run_herbivore_phase(world: &World, orgs: &mut Organisms, spatial: &mut SpatialIndex, cfg: &Config, tick: u64, rng: &mut Rng) -> HerbivoreStats {
    let mut st = HerbivoreStats::default();
    let grid = &world.grid;
    let digestion = cfg.herbivores.digestion_efficiency;
    for id in orgs.active_ids(Kind::Herbivore) {
        // (a) running cost, paid every tick
        {
            let o = match orgs.get_mut(Kind::Herbivore, id) {
                Some(o) if o.is_active() => o,
                _ => continue,
            };
            let t = world.temp_at(o.pos);
            let cost = upkeep_cost(&cfg.herbivores, o, t);
            let base = cfg.herbivores.base_metabolism * o.traits.metabolism;
            let paid = -o.add_energy(-cost);
            st.upkeep_paid += paid;
            st.climate_extra_paid += if cost > 0.0 { paid * (cost - base) / cost } else { 0.0 };
        }
        let (aggr, risk, bite, satiated, pos0) = {
            let o = orgs.get(Kind::Herbivore, id).unwrap();
            (
                o.traits.aggression,
                o.traits.risk_tolerance,
                bite_size(cfg, o),
                o.energy() >= cfg.herbivores.satiation_limit * o.traits.max_energy,
                o.pos,
            )
        };
        // (b) perceive
        let hits = perceive(spatial, orgs, id);
        let mut cands: Vec<Cand> = Vec::new();
        let mut herbs: Vec<Pos> = Vec::new();
        let mut carns: Vec<Pos> = Vec::new();
        for h in &hits {
            match h.kind {
                Kind::Plant => {
                    if let Some(p) = orgs.get(Kind::Plant, h.id) {
                        // only the energy above the root reserve is edible (ADR-0022)
                        let edible = p.energy() - cfg.plants.graze_reserve;
                        if edible > 0.0 {
                            cands.push(Cand { id: h.id, pos: h.pos, energy: edible });
                        }
                    }
                }
                Kind::Herbivore => herbs.push(h.pos),
                Kind::Carnivore => carns.push(h.pos),
            }
        }
        let score_at = |from: Pos, c: &Cand| -> f64 {
            let others = herbs.iter().filter(|&&q| q == c.pos).count() as u32;
            let danger: f64 = carns.iter().map(|&q| 1.0 / (1.0 + grid.dist(q, c.pos) as f64)).sum();
            score_plant(bite, digestion, c.energy, grid.dist(from, c.pos), aggr, risk, others, danger)
        };
        // (c) choose target
        let mut target: Option<usize> = None;
        if satiated {
            st.satiated += 1;
        } else {
            let mut best = 0.0;
            for (i, c) in cands.iter().enumerate() {
                let s = score_at(pos0, c);
                if s > best {
                    best = s;
                    target = Some(i);
                }
            }
        }
        // (d) move
        let o = orgs.get_mut(Kind::Herbivore, id).unwrap();
        let allowance = step_allowance(o);
        match target {
            Some(i) => {
                if grid.dist(o.pos, cands[i].pos) > FEED_REACH {
                    move_toward(cfg, o, cands[i].pos, allowance, grid, spatial);
                }
            }
            None => wander(cfg, o, allowance, grid, spatial, rng),
        }
        // (e) eat: best plant within reach of the (new) position
        if target.is_none() {
            continue;
        }
        let from = o.pos;
        let room = o.traits.max_energy - o.energy();
        let mut pick: Option<usize> = None;
        let mut best = 0.0;
        for (i, c) in cands.iter().enumerate() {
            if grid.dist(from, c.pos) <= FEED_REACH {
                let s = score_at(from, c);
                if s > best {
                    best = s;
                    pick = Some(i);
                }
            }
        }
        let i = match pick {
            Some(i) => i,
            None => continue,
        };
        let pid = cands[i].id;
        let avail = match orgs.get(Kind::Plant, pid) {
            Some(p) if p.is_active() => (p.energy() - cfg.plants.graze_reserve).max(0.0),
            _ => continue,
        };
        let amount = bite.min(avail).min(room / digestion);
        if amount <= 0.0 {
            continue;
        }
        let taken = -orgs.get_mut(Kind::Plant, pid).unwrap().add_energy(-amount);
        let gained = orgs.get_mut(Kind::Herbivore, id).unwrap().add_energy(taken * digestion);
        st.eaten_energy += taken;
        st.gained_energy += gained;
        st.bites += 1;
        if orgs.get(Kind::Plant, pid).is_some_and(|p| p.energy() <= 0.0) && orgs.mark_dead(pid, DeathCause::Predation, tick) {
            st.plants_killed += 1;
        }
    }
    st
}

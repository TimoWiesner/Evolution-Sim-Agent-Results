//! Base climate and biomes (TASK-006, ADR-0010, docs/CLIMATE.md).
//!
//! Every cell gets a base temperature, base precipitation, elevation and biome. The map is a pure
//! function of the config and seed (own RNG stream; the simulation RNG is never touched).
//! North-south: "mirrored double hemisphere" (both the top and bottom edge are polar, the equator
//! is the middle row), so the y-seam is as smooth as any other row boundary. East-west: periodic.

use crate::config::Config;
use crate::grid::{Grid, Pos};
use crate::json::Value;
use crate::rng::Rng;

/// Rng stream id of the climate noise lattices.
pub const STREAM_CLIMATE: u64 = 0xC11A_7E01;
/// Maximum cooling/warming (deg C) from elevation noise at `terrain_noise == 1`.
pub const ELEV_COOLING: f64 = 6.0;
/// Approximate noise lattice spacing in grid cells.
pub const NOISE_CELL: f64 = 8.0;
/// Upper bounds (on normalised warmth `tau`) of the polar, tundra, temperate and dry zones.
pub const ZONE_LIMITS: [f64; 4] = [0.07, 0.25, 0.62, 0.88];
/// Precipitation ratio (P / precip_mean) below which a dry-zone cell is desert, not savanna.
pub const DESERT_RATIO: f64 = 0.45;
/// Precipitation ratio below which a temperate cell is grassland, not forest.
pub const GRASSLAND_RATIO: f64 = 0.8;
/// Precipitation ratio below which a tropical cell is savanna, not rainforest.
pub const SAVANNA_RATIO: f64 = 0.5;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Biome {
    Polar,
    Tundra,
    TemperateForest,
    TemperateGrassland,
    Savanna,
    Desert,
    TropicalRainforest,
}

impl Biome {
    pub const ALL: [Biome; 7] = [
        Biome::Polar,
        Biome::Tundra,
        Biome::TemperateForest,
        Biome::TemperateGrassland,
        Biome::Savanna,
        Biome::Desert,
        Biome::TropicalRainforest,
    ];
    pub fn name(self) -> &'static str {
        match self {
            Biome::Polar => "polar",
            Biome::Tundra => "tundra",
            Biome::TemperateForest => "temperate_forest",
            Biome::TemperateGrassland => "temperate_grassland",
            Biome::Savanna => "savanna",
            Biome::Desert => "desert",
            Biome::TropicalRainforest => "tropical_rainforest",
        }
    }
    pub fn letter(self) -> char {
        match self {
            Biome::Polar => 'P',
            Biome::Tundra => 'T',
            Biome::TemperateForest => 'F',
            Biome::TemperateGrassland => 'G',
            Biome::Savanna => 'S',
            Biome::Desert => 'D',
            Biome::TropicalRainforest => 'R',
        }
    }
}

/// Weather lattice node spacing in cells (same rule as the terrain noise).
pub const WEATHER_CELL: f64 = NOISE_CELL;
/// Weather anomalies are clamped to +-WEATHER_CLAMP (roughly unit variance, so +-2 sigma).
pub const WEATHER_CLAMP: f64 = 2.0;
/// Temperature deviation (deg C) per unit anomaly at `weather_noise == 1`.
pub const WEATHER_TEMP_SCALE: f64 = 6.0;
/// Relative precipitation change per unit anomaly at `weather_noise == 1`.
pub const WEATHER_PRECIP_SCALE: f64 = 0.5;
/// Wet season peak lags the warm peak by this fraction of a year.
pub const PRECIP_LAG: f64 = 0.125;

/// Zone names indexed by zone number (0 = coldest .. 4 = hottest).
pub const ZONE_NAMES: [&str; 5] = ["polar", "tundra", "temperate", "dry", "tropical"];

/// Latitude warmth fraction in [0,1] for row `y` of `h`: 0 at the y-seam (poles), 1 at the equator.
pub fn warmth(y: u32, h: u32) -> f64 {
    let u = (y as f64 + 0.5) / h as f64;
    let s = (1.0 - (2.0 * std::f64::consts::PI * u).cos()) / 2.0;
    s.clamp(0.0, 1.0)
}

/// Zone number for a normalised warmth value.
pub fn zone_of(tau: f64) -> u8 {
    ZONE_LIMITS.iter().position(|&l| tau < l).unwrap_or(4) as u8
}

/// Lattice size (nodes) for a w x h world; wraps in both axes.
fn lattice_dims(w: u32, h: u32) -> (usize, usize) {
    let nx = ((w as f64 / NOISE_CELL).round() as usize).max(1);
    let ny = ((h as f64 / NOISE_CELL).round() as usize).max(1);
    (nx, ny)
}

/// Smoothstep bilinear interpolation (wrapping) of lattice `v` (nx x ny) at the centre of cell (x,y).
fn interp(v: &[f64], nx: usize, ny: usize, x: u32, y: u32, w: u32, h: u32) -> f64 {
    let fx = (x as f64 + 0.5) / w as f64 * nx as f64;
    let fy = (y as f64 + 0.5) / h as f64 * ny as f64;
    let (ix, iy) = (fx.floor(), fy.floor());
    let (tx, ty) = (smooth(fx - ix), smooth(fy - iy));
    let x0 = (ix as usize) % nx;
    let y0 = (iy as usize) % ny;
    let x1 = (x0 + 1) % nx;
    let y1 = (y0 + 1) % ny;
    let g = |xx: usize, yy: usize| v[yy * nx + xx];
    let a = g(x0, y0) + (g(x1, y0) - g(x0, y0)) * tx;
    let b = g(x0, y1) + (g(x1, y1) - g(x0, y1)) * tx;
    a + (b - a) * ty
}

/// Periodic value noise on a lattice that wraps in both axes.
struct Noise {
    nx: usize,
    ny: usize,
    v: Vec<f64>,
}

impl Noise {
    fn new(rng: &mut Rng, w: u32, h: u32) -> Noise {
        let (nx, ny) = lattice_dims(w, h);
        let v = (0..nx * ny).map(|_| rng.next_f64()).collect();
        Noise { nx, ny, v }
    }
    /// Value in [0,1] at cell centre (x,y) of a w x h world.
    fn at(&self, x: u32, y: u32, w: u32, h: u32) -> f64 {
        interp(&self.v, self.nx, self.ny, x, y, w, h).clamp(0.0, 1.0)
    }
}

fn smooth(t: f64) -> f64 {
    t * t * (3.0 - 2.0 * t)
}

/// Per-cell base climate, row-major (`Grid::index`).
#[derive(Clone, Debug)]
pub struct ClimateMap {
    pub width: u32,
    pub height: u32,
    pub temp: Vec<f64>,
    pub precip: Vec<f64>,
    pub elevation: Vec<f64>,
    pub zone: Vec<u8>,
    pub biome: Vec<Biome>,
    /// Latitude warmth per row (`warmth`), used by the seasonal terms.
    pub warmth_row: Vec<f64>,
    /// Season parameters copied from the config (TASK-007).
    pub season: SeasonParams,
}

impl ClimateMap {
    /// Builds the map for a validated config (any size >= 1x1).
    pub fn generate(cfg: &Config) -> ClimateMap {
        let (w, h) = (cfg.world.width, cfg.world.height);
        let c = &cfg.climate;
        let mut rng = Rng::stream(cfg.seed, STREAM_CLIMATE);
        let elev_n = Noise::new(&mut rng, w, h);
        let wet_n = Noise::new(&mut rng, w, h);
        let n = w as usize * h as usize;
        let mut m = ClimateMap {
            width: w,
            height: h,
            temp: Vec::with_capacity(n),
            precip: Vec::with_capacity(n),
            elevation: Vec::with_capacity(n),
            zone: Vec::with_capacity(n),
            biome: Vec::with_capacity(n),
            warmth_row: (0..h).map(|y| warmth(y, h)).collect(),
            season: SeasonParams::from_config(cfg),
        };
        let range = c.equator_temp - c.pole_temp;
        for y in 0..h {
            let s = warmth(y, h);
            let u = (y as f64 + 0.5) / h as f64;
            let lat_p = (1.0
                + c.precip_latitude_variation * (3.0 * std::f64::consts::PI * (1.0 - 2.0 * u)).cos())
            .max(0.0);
            for x in 0..w {
                let elev = elev_n.at(x, y, w, h);
                let wet = wet_n.at(x, y, w, h);
                let dt = -c.terrain_noise * ELEV_COOLING * (elev - 0.5) * 2.0;
                let t = c.pole_temp + range * s + dt;
                let p = (c.precip_mean * lat_p * (1.0 + c.terrain_noise * (wet - 0.5))).max(0.0);
                let tau = if range > 0.0 { s + dt / range } else { s };
                let ratio = if c.precip_mean > 0.0 { p / c.precip_mean } else { 0.0 };
                let zone = zone_of(tau);
                let biome = match zone {
                    0 => Biome::Polar,
                    1 => Biome::Tundra,
                    2 if ratio < GRASSLAND_RATIO => Biome::TemperateGrassland,
                    2 => Biome::TemperateForest,
                    3 if ratio < DESERT_RATIO => Biome::Desert,
                    3 => Biome::Savanna,
                    _ if ratio < SAVANNA_RATIO => Biome::Savanna,
                    _ => Biome::TropicalRainforest,
                };
                m.temp.push(t);
                m.precip.push(p);
                m.elevation.push(elev);
                m.zone.push(zone);
                m.biome.push(biome);
            }
        }
        m
    }

    fn idx(&self, p: Pos) -> usize {
        debug_assert!(p.x >= 0 && p.y >= 0);
        p.y as usize * self.width as usize + p.x as usize
    }
    pub fn grid(&self) -> Grid {
        Grid::new(self.width, self.height).expect("valid size")
    }
    pub fn temp_at(&self, p: Pos) -> f64 {
        self.temp[self.idx(p)]
    }
    pub fn precip_at(&self, p: Pos) -> f64 {
        self.precip[self.idx(p)]
    }
    pub fn biome_at(&self, p: Pos) -> Biome {
        self.biome[self.idx(p)]
    }
    pub fn zone_at(&self, p: Pos) -> u8 {
        self.zone[self.idx(p)]
    }

    /// One text line per world row (top row first), one biome letter per cell, then a legend.
    pub fn to_ascii(&self) -> String {
        let mut s = String::new();
        for y in 0..self.height as usize {
            for x in 0..self.width as usize {
                s.push(self.biome[y * self.width as usize + x].letter());
            }
            s.push('\n');
        }
        s.push_str("legend:");
        for b in Biome::ALL {
            s.push_str(&format!(" {}={}", b.letter(), b.name()));
        }
        s.push('\n');
        s
    }

    /// JSON with width, height and row-major `biome` (names), `zone`, `temp`, `precip` arrays.
    pub fn to_json(&self) -> String {
        let round = |f: f64| Value::Float((f * 1000.0).round() / 1000.0);
        let v = Value::Object(vec![
            ("width".into(), Value::Int(self.width as i64)),
            ("height".into(), Value::Int(self.height as i64)),
            ("zone_names".into(), Value::Array(ZONE_NAMES.iter().map(|n| Value::Str(n.to_string())).collect())),
            ("biome".into(), Value::Array(self.biome.iter().map(|b| Value::Str(b.name().into())).collect())),
            ("zone".into(), Value::Array(self.zone.iter().map(|&z| Value::Int(z as i64)).collect())),
            ("temp".into(), Value::Array(self.temp.iter().map(|&t| round(t)).collect())),
            ("precip".into(), Value::Array(self.precip.iter().map(|&p| round(p)).collect())),
        ]);
        v.to_compact()
    }
}

/// Season parameters (subset of `Climate` config).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SeasonParams {
    pub length: u32,
    pub temp_amp: f64,
    pub precip_amp: f64,
}

impl SeasonParams {
    pub fn from_config(cfg: &Config) -> SeasonParams {
        SeasonParams {
            length: cfg.climate.season_length,
            temp_amp: cfg.climate.seasonal_amplitude,
            precip_amp: cfg.climate.seasonal_precip_amplitude,
        }
    }
    /// Season phase in radians for `tick`; integer modulo first so tick and tick+length agree exactly.
    pub fn phase(&self, tick: u64) -> f64 {
        2.0 * std::f64::consts::PI * ((tick % self.length as u64) as f64) / self.length as f64
    }
}

/// Documented hard bounds of the effective climate (see docs/CLIMATE.md).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ClimateBounds {
    pub temp_min: f64,
    pub temp_max: f64,
    pub precip_min: f64,
    pub precip_max: f64,
}

impl ClimateBounds {
    pub fn from_config(cfg: &Config) -> ClimateBounds {
        let c = &cfg.climate;
        let wt = WEATHER_TEMP_SCALE * WEATHER_CLAMP * c.weather_noise;
        ClimateBounds {
            temp_min: c.pole_temp - ELEV_COOLING - c.seasonal_amplitude - wt,
            temp_max: c.equator_temp + ELEV_COOLING + c.seasonal_amplitude + wt,
            precip_min: 0.0,
            precip_max: c.precip_mean
                * (1.0 + c.precip_latitude_variation)
                * (1.0 + c.terrain_noise / 2.0)
                * (1.0 + c.seasonal_precip_amplitude)
                * (1.0 + WEATHER_PRECIP_SCALE * WEATHER_CLAMP * c.weather_noise),
        }
    }
}

impl ClimateMap {
    /// Seasonal temperature offset (deg C) of row warmth `s` at `tick`. Pure; weather-free.
    pub fn season_temp_offset(&self, s: f64, tick: u64) -> f64 {
        let k = 0.25 + 0.75 * (1.0 - s);
        self.season.temp_amp * k * (-self.season.phase(tick).cos())
    }
    /// Seasonal precipitation factor (mean 1 over a year) of row warmth `s` at `tick`.
    pub fn season_precip_factor(&self, s: f64, tick: u64) -> f64 {
        let k = 0.3 + 0.7 * s;
        let ph = self.season.phase(tick) - 2.0 * std::f64::consts::PI * PRECIP_LAG;
        1.0 + self.season.precip_amp * k * (-ph.cos())
    }
    /// Weather-free temperature of a cell at any tick (base + season).
    pub fn seasonal_temp_at(&self, p: Pos, tick: u64) -> f64 {
        self.temp_at(p) + self.season_temp_offset(self.warmth_row[p.y as usize], tick)
    }
    /// Weather-free precipitation of a cell at any tick (base * season), >= 0.
    pub fn seasonal_precip_at(&self, p: Pos, tick: u64) -> f64 {
        (self.precip_at(p) * self.season_precip_factor(self.warmth_row[p.y as usize], tick)).max(0.0)
    }
}

/// Weather state carried between ticks: two anomaly fields on a wrapping coarse lattice.
#[derive(Clone, Debug, PartialEq)]
pub struct Weather {
    /// Tick whose Climate phase last ran (0 before the first step).
    pub tick: u64,
    pub nx: usize,
    pub ny: usize,
    /// Temperature anomaly nodes in [-WEATHER_CLAMP, WEATHER_CLAMP].
    pub t: Vec<f64>,
    /// Precipitation anomaly nodes in [-WEATHER_CLAMP, WEATHER_CLAMP].
    pub p: Vec<f64>,
}

/// Approx N(0,1) from 4 uniforms (Irwin-Hall): only + - * / sqrt, so portable.
fn approx_normal(rng: &mut Rng) -> f64 {
    let s = rng.next_f64() + rng.next_f64() + rng.next_f64() + rng.next_f64();
    (s - 2.0) * 3.0_f64.sqrt()
}

impl Weather {
    pub fn new(cfg: &Config) -> Weather {
        let (nx, ny) = lattice_dims(cfg.world.width, cfg.world.height);
        Weather { tick: 0, nx, ny, t: vec![0.0; nx * ny], p: vec![0.0; nx * ny] }
    }

    /// Sets the weather tick to `tick` and evolves every node (AR(1)); always draws 8 values per
    /// node pair, independent of `weather_noise`. At tick 0 the state is drawn stationary.
    pub fn advance(&mut self, tick: u64, c: &crate::config::Climate, rng: &mut Rng) {
        self.tick = tick;
        let phi = (-1.0 / c.weather_period as f64).exp();
        let sd = (1.0 - phi * phi).sqrt();
        for field in [&mut self.t, &mut self.p] {
            for a in field.iter_mut() {
                let z = approx_normal(rng);
                let next = if tick == 0 { z } else { phi * *a + sd * z };
                *a = next.clamp(-WEATHER_CLAMP, WEATHER_CLAMP);
            }
        }
    }

    /// Interpolated (temperature, precipitation) anomalies at a cell.
    pub fn anomalies(&self, x: u32, y: u32, w: u32, h: u32) -> (f64, f64) {
        (interp(&self.t, self.nx, self.ny, x, y, w, h), interp(&self.p, self.nx, self.ny, x, y, w, h))
    }

    /// State as f64 bit patterns: tick, nx, ny, then t nodes, then p nodes.
    pub fn state_words(&self) -> Vec<u64> {
        let mut v = vec![self.tick, self.nx as u64, self.ny as u64];
        v.extend(self.t.iter().map(|x| x.to_bits()));
        v.extend(self.p.iter().map(|x| x.to_bits()));
        v
    }

    pub fn from_state_words(w: &[u64]) -> Option<Weather> {
        if w.len() < 3 {
            return None;
        }
        let (nx, ny) = (w[1] as usize, w[2] as usize);
        let n = nx.checked_mul(ny)?;
        if n == 0 || w.len() != 3 + 2 * n {
            return None;
        }
        let f = |s: &[u64]| s.iter().map(|&b| f64::from_bits(b)).collect::<Vec<f64>>();
        Some(Weather { tick: w[0], nx, ny, t: f(&w[3..3 + n]), p: f(&w[3 + n..]) })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn warmth_symmetric_and_bounded() {
        for h in [1u32, 2, 3, 7, 48] {
            for y in 0..h {
                let a = warmth(y, h);
                assert!((0.0..=1.0).contains(&a));
                assert!((a - warmth(h - 1 - y, h)).abs() < 1e-12);
            }
        }
    }

    #[test]
    fn weather_state_roundtrip_and_clamp() {
        let mut cfg = Config::default();
        cfg.world.width = 40;
        cfg.world.height = 24;
        let mut w = Weather::new(&cfg);
        let mut rng = Rng::new(3);
        for t in 0..500 {
            w.advance(t, &cfg.climate, &mut rng);
            assert!(w.t.iter().chain(w.p.iter()).all(|a| a.abs() <= WEATHER_CLAMP));
        }
        assert_eq!(Weather::from_state_words(&w.state_words()).unwrap(), w);
        assert!(Weather::from_state_words(&[1, 2]).is_none());
    }

    #[test]
    fn ar1_variance_roughly_one() {
        let mut cfg = Config::default();
        cfg.world.width = 80;
        cfg.world.height = 80;
        let mut w = Weather::new(&cfg);
        let mut rng = Rng::new(9);
        let (mut sum, mut n) = (0.0, 0.0);
        for t in 0..400 {
            w.advance(t, &cfg.climate, &mut rng);
            if t > 50 {
                sum += w.t.iter().map(|a| a * a).sum::<f64>();
                n += w.t.len() as f64;
            }
        }
        let var = sum / n;
        assert!((0.6..1.2).contains(&var), "var {}", var);
    }

    #[test]
    fn zone_of_order() {
        assert_eq!(zone_of(0.0), 0);
        assert_eq!(zone_of(0.1), 1);
        assert_eq!(zone_of(0.4), 2);
        assert_eq!(zone_of(0.7), 3);
        assert_eq!(zone_of(1.0), 4);
    }
}

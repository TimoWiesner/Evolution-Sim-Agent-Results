//! Plant growth and cell resources (TASK-011, ADR-0015, docs/PLANTS.md).
//!
//! Plant energy comes ONLY from the per-cell fertility stock (`World::resources`), which refills
//! slowly (`climate.resource_regen`, scaled by current precipitation) up to a climate-set cap.
//! A plant gains exactly what it removes from the stock; upkeep and stress are the sinks.

use crate::config::Config;
use crate::genome::{scale_factor, Gene, Genome, Mutation};
use crate::grid::{Grid, Pos};
use crate::organism::{DeathCause, Kind, NewBorn, Organisms};
use crate::rng::Rng;
use crate::world::{water_factor, World};

/// Maximum shift (deg C) of the optimal temperature by the thermal locus (Aggression locus, see GENOME.md).
pub const THERMAL_SHIFT: f64 = 10.0;
/// Below this water factor a plant is stressed.
pub const STRESS_WATER_FLOOR: f64 = 0.1;
/// Health fraction restored per tick in a tolerable climate.
pub const STRESS_HEAL: f64 = 0.02;
/// Fraction of the reproduction cost that ends up as the seedling's starting energy (rest is lost overhead).
pub const SEED_ENERGY_FRACTION: f64 = 0.5;

/// Picks the target cell of a seed: distance `r = 1 + floor(R*u^2)` (clipped to R; R = 0 -> own cell),
/// then a uniform cell on the Chebyshev ring of radius `r` (8r cells), wrapped. Draws 2 values when R > 0.
pub fn seed_target(grid: &Grid, from: Pos, range: u32, rng: &mut Rng) -> Pos {
    if range == 0 {
        return from;
    }
    let u = rng.next_f64();
    let r = (1 + (range as f64 * u * u) as i64).min(range as i64);
    let k = rng.below(8 * r as u64) as i64;
    let side = k / (2 * r);
    let o = k % (2 * r);
    let (dx, dy) = match side {
        0 => (-r + o, -r),
        1 => (r, -r + o),
        2 => (r - o, r),
        _ => (-r, r - o),
    };
    grid.offset(from, dx, dy)
}

/// Heritable growth/tolerance parameters derived from a genome (not stored).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PlantTraits {
    /// Optimal temperature (deg C).
    pub temp_opt: f64,
    /// Half-width of the temperature range with growth (deg C).
    pub temp_tol: f64,
    /// Precipitation needed for full growth.
    pub water_need: f64,
    /// Peak-height multiplier trading against tolerance: sqrt(base_tol / tol).
    pub breadth: f64,
    /// Upkeep multiplier of drought tolerance (>= 1).
    pub drought_cost: f64,
    /// Growth multiplier from the size (max_energy) trait.
    pub size_scale: f64,
}

impl PlantTraits {
    pub fn from_genome(g: &Genome, cfg: &Config) -> PlantTraits {
        let base_tol = cfg.plants.temp_tolerance;
        let temp_opt = cfg.plants.temp_optimum + (g.locus_value(Gene::Aggression) - 0.5) * 2.0 * THERMAL_SHIFT;
        let temp_tol = base_tol * scale_factor(g.locus_value(Gene::RiskTolerance));
        let water_need = cfg.plants.water_need * scale_factor(g.locus_value(Gene::Vision));
        let rel = if cfg.plants.water_need > 0.0 { (water_need / cfg.plants.water_need).min(1.0) } else { 1.0 };
        PlantTraits {
            temp_opt,
            temp_tol,
            water_need,
            breadth: (base_tol / temp_tol).sqrt(),
            drought_cost: 1.0 + 0.5 * (1.0 - rel),
            size_scale: scale_factor(g.locus_value(Gene::MaxEnergy)).sqrt(),
        }
    }
}

/// `max(0, 1 - ((t - opt)/tol)^2)`: 1 at the optimum, 0 at and beyond `opt +- tol`.
pub fn temp_factor(t: f64, opt: f64, tol: f64) -> f64 {
    let d = (t - opt) / tol;
    (1.0 - d * d).max(0.0)
}

/// Re-export of the water factor `clamp(p/need, 0, 1)`.
pub fn water_factor_of(p: f64, need: f64) -> f64 {
    water_factor(p, need)
}

/// Per-tick totals of the Plants phase (energy accounting; not part of the digest).
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct PlantPhaseStats {
    /// Stock added by regeneration.
    pub regen: f64,
    /// Stock removed by plants (== energy gained by plants).
    pub stock_removed: f64,
    /// Energy gained by plants.
    pub gain: f64,
    /// Energy actually paid as upkeep.
    pub upkeep: f64,
    /// Plants that took stress damage this tick.
    pub stressed: u32,
    /// Seeding attempts by eligible plants.
    pub attempts: u32,
    /// Seeds queued (offspring to be born in the Births phase).
    pub born: u32,
    /// Attempts blocked because the target cell was full.
    pub blocked_room: u32,
    /// Attempts blocked because the target cell had too little fertility stock.
    pub blocked_resource: u32,
    /// Attempts blocked because the climate at the target is hostile for the child genome.
    pub blocked_climate: u32,
    /// Energy paid by parents.
    pub repro_spent: f64,
    /// Energy given to seedlings (<= repro_spent).
    pub seed_energy: f64,
}

/// Runs the Plants phase: regeneration, then growth/upkeep/stress per plant in ascending id.
/// Deaths (climate) are marked here; old age and starvation are resolved in the Deaths phase.
pub fn run_plants_phase(world: &mut World, orgs: &mut Organisms, cfg: &Config, tick: u64, rng: &mut Rng) -> PlantPhaseStats {
    let mut st = PlantPhaseStats { regen: world.regen_resources(cfg), ..Default::default() };
    let ncell = world.grid.cell_count();
    let mut counts = vec![0u32; ncell];
    for o in orgs.vec(Kind::Plant) {
        if o.is_active() {
            counts[world.grid.index(o.pos)] += 1;
        }
    }
    let mut dead = Vec::new();
    let mut seeds: Vec<NewBorn> = Vec::new();
    // Per-cell climate cache for this tick (pure functions of cell and tick; ADR-0030). NaN = not yet computed.
    let mut climate_cache = vec![(f64::NAN, f64::NAN); ncell];
    let mutation = Mutation::for_kind(cfg, Kind::Plant);
    let threshold = cfg.plants.reproduction_threshold.max(cfg.plants.reproduction_cost);
    for o in orgs.vec_mut(Kind::Plant).iter_mut() {
        if !o.is_active() {
            continue;
        }
        let ci = world.grid.index(o.pos);
        if climate_cache[ci].0.is_nan() {
            climate_cache[ci] = (world.temp_at(o.pos), world.precip_at(o.pos));
        }
        let (t, p) = climate_cache[ci];
        let pt = PlantTraits::from_genome(o.genome(), cfg);
        let ft = temp_factor(t, pt.temp_opt, pt.temp_tol);
        let fw = water_factor(p, pt.water_need);
        let crowd = (cfg.plants.cell_capacity as f64 / counts[ci].max(1) as f64).min(1.0);
        let want = cfg.plants.growth_rate * ft * fw * crowd * pt.size_scale * pt.breadth;
        let room = (o.traits.max_energy - o.energy()).max(0.0);
        let take = world.take_resource(ci, want.min(cfg.plants.resource_uptake).min(room));
        let gained = o.add_energy(take);
        // Everything removed from the stock must land in the plant (take <= room guarantees it).
        st.stock_removed += take;
        st.gain += gained;
        let up = cfg.plants.maintenance * o.traits.metabolism * pt.drought_cost;
        st.upkeep += -o.add_energy(-up);
        if ft <= 0.0 || fw < STRESS_WATER_FLOOR {
            o.damage(cfg.plants.stress_damage * o.traits.max_health);
            st.stressed += 1;
            if o.health() <= 0.0 {
                dead.push(o.id);
            }
        } else {
            o.heal(STRESS_HEAL * o.traits.max_health);
        }
        if o.health() <= 0.0 || o.energy() < threshold {
            continue;
        }
        // Reproduction: one seeding attempt; blocked attempts cost nothing.
        st.attempts += 1;
        let target = seed_target(&world.grid, o.pos, cfg.plants.seed_range, rng);
        let ti = world.grid.index(target);
        if crate::organism::cell_limit(cfg, Kind::Plant).is_some_and(|l| counts[ti] >= l) {
            st.blocked_room += 1;
            continue;
        }
        if world.resource_at(target) < cfg.plants.establish_resource {
            st.blocked_resource += 1;
            continue;
        }
        let genome = Genome::child_of_one(o.genome(), &mutation, rng);
        let ct = PlantTraits::from_genome(&genome, cfg);
        if temp_factor(world.temp_at(target), ct.temp_opt, ct.temp_tol) <= 0.0
            || water_factor(world.precip_at(target), ct.water_need) < STRESS_WATER_FLOOR
        {
            st.blocked_climate += 1;
            continue;
        }
        let paid = -o.add_energy(-cfg.plants.reproduction_cost);
        let energy = paid * SEED_ENERGY_FRACTION;
        counts[ti] += 1;
        st.born += 1;
        st.repro_spent += paid;
        st.seed_energy += energy;
        seeds.push(NewBorn { kind: Kind::Plant, pos: target, parents: [o.id, 0], genome, energy });
    }
    for nb in seeds {
        let ok = orgs.queue_birth(nb);
        debug_assert!(ok, "seed parent must be alive");
    }
    for id in dead {
        orgs.mark_dead(id, DeathCause::Climate, tick);
    }
    st
}

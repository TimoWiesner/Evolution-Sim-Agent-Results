//! The world: geometry and climate now; per-cell resources and the spatial index arrive in later tasks.

use crate::climate::{ClimateBounds, ClimateMap, Weather, WEATHER_PRECIP_SCALE, WEATHER_TEMP_SCALE};
use crate::config::Config;
use crate::grid::{Grid, Pos};
use crate::rng::Rng;

#[derive(Clone, Debug)]
pub struct World {
    pub grid: Grid,
    /// Base (annual mean) climate and biomes per cell (TASK-006); static.
    pub climate: ClimateMap,
    /// Weather state carried between ticks (TASK-007); part of the simulation state.
    pub weather: Weather,
    /// `weather_noise` and the documented bounds, copied from the config.
    weather_noise: f64,
    bounds: ClimateBounds,
    /// Per-cell fertility stock (row-major): the only energy source of plants (ADR-0015).
    resources: Vec<f64>,
    /// Static per-cell capacity of `resources`, set by the base climate.
    resource_cap: Vec<f64>,
    /// Static per-cell prey refuge flags (ADR-0031): clumped 3x3 blocks, a pure function of seed and `cover_fraction`.
    cover: Vec<bool>,
}

/// `clamp(p / need, 0, 1)`: water availability factor (1 if no water is needed).
pub fn water_factor(p: f64, need: f64) -> f64 {
    if need <= 0.0 {
        1.0
    } else {
        (p / need).clamp(0.0, 1.0)
    }
}

impl World {
    /// Builds the world from a validated config.
    pub fn new(cfg: &Config) -> Result<World, String> {
        let grid = Grid::new(cfg.world.width, cfg.world.height)?;
        let climate = ClimateMap::generate(cfg);
        let resource_cap: Vec<f64> = (0..grid.cell_count())
            .map(|i| cfg.climate.resource_max * water_factor(climate.precip_at(grid.pos_of(i)), cfg.plants.water_need))
            .collect();
        let cover: Vec<bool> = (0..grid.cell_count())
            .map(|i| {
                let p = grid.pos_of(i);
                let mut st = (cfg.seed as u64) ^ 0xC0DE_C0DE_5EED_0001 ^ (((p.x / 3) as u64) << 32) ^ ((p.y / 3) as u64);
                let u = (crate::rng::splitmix64(&mut st) >> 11) as f64 / (1u64 << 53) as f64;
                u < cfg.climate.cover_fraction
            })
            .collect();
        Ok(World {
            grid,
            cover,
            climate,
            weather: Weather::new(cfg),
            weather_noise: cfg.climate.weather_noise,
            bounds: ClimateBounds::from_config(cfg),
            resources: resource_cap.clone(),
            resource_cap,
        })
    }

    /// Climate phase: moves the climate to `tick` and evolves the weather using the simulation RNG.
    pub fn advance_weather(&mut self, tick: u64, cfg: &Config, rng: &mut Rng) {
        self.weather.advance(tick, &cfg.climate, rng);
    }

    /// Tick the current climate state describes (the tick whose Climate phase last ran).
    pub fn climate_tick(&self) -> u64 {
        self.weather.tick
    }

    pub fn bounds(&self) -> ClimateBounds {
        self.bounds
    }

    /// Effective temperature (deg C) of a cell at the current climate tick, within `bounds()`.
    pub fn temp_at(&self, p: Pos) -> f64 {
        self.temp_at_raw(p).clamp(self.bounds.temp_min, self.bounds.temp_max)
    }

    /// Effective precipitation of a cell at the current climate tick, within `bounds()`.
    pub fn precip_at(&self, p: Pos) -> f64 {
        self.precip_at_raw(p).clamp(self.bounds.precip_min, self.bounds.precip_max)
    }

    /// Temperature before the safety clamp (tests show the clamp never changes it).
    pub fn temp_at_raw(&self, p: Pos) -> f64 {
        let (at, _) = self.weather.anomalies(p.x as u32, p.y as u32, self.grid.width(), self.grid.height());
        self.climate.seasonal_temp_at(p, self.weather.tick) + self.weather_noise * WEATHER_TEMP_SCALE * at
    }

    pub fn precip_at_raw(&self, p: Pos) -> f64 {
        let (_, ap) = self.weather.anomalies(p.x as u32, p.y as u32, self.grid.width(), self.grid.height());
        self.climate.seasonal_precip_at(p, self.weather.tick) * (1.0 + self.weather_noise * WEATHER_PRECIP_SCALE * ap)
    }

    /// Current resource stock of a cell.
    pub fn resource_at(&self, p: Pos) -> f64 {
        self.resources[self.grid.index(p)]
    }

    /// Capacity of a cell's resource stock.
    pub fn resource_cap_at(&self, p: Pos) -> f64 {
        self.resource_cap[self.grid.index(p)]
    }

    /// Sets a stock (clamped to [0, cap]); used by tests and scenarios.
    pub fn set_resource(&mut self, p: Pos, v: f64) {
        let i = self.grid.index(p);
        self.resources[i] = if v.is_nan() { 0.0 } else { v.max(0.0).min(self.resource_cap[i]) };
    }

    /// Removes up to `amount` from a cell's stock; returns what was removed.
    pub fn take_resource(&mut self, i: usize, amount: f64) -> f64 {
        let t = amount.max(0.0).min(self.resources[i]);
        self.resources[i] -= t;
        t
    }

    /// Copies all stocks from another world of the same size (checkpoint-style restore in tests).
    pub fn copy_resources_from(&mut self, other: &World) {
        self.resources.clone_from(&other.resources);
    }

    /// Sum of all stocks.
    pub fn resource_total(&self) -> f64 {
        self.resources.iter().sum()
    }

    /// Regeneration (the only inflow): `stock = min(cap, stock + regen * W(P_now))` per cell.
    /// Returns the amount actually added. Uses the current weather precipitation; draws no RNG.
    pub fn regen_resources(&mut self, cfg: &Config) -> f64 {
        let mut added = 0.0;
        for i in 0..self.resources.len() {
            let p = self.precip_at(self.grid.pos_of(i));
            let inc = cfg.climate.resource_regen * water_factor(p, cfg.plants.water_need);
            let new = (self.resources[i] + inc).min(self.resource_cap[i]);
            added += new - self.resources[i];
            self.resources[i] = new;
        }
        added
    }

    /// Checkpoint: weather and resource stocks (climate map and capacity are rebuilt from the config).
    pub fn write_state(&self, w: &mut crate::checkpoint::Writer) {
        let wt = &self.weather;
        w.u64(wt.tick);
        w.u64(wt.nx as u64);
        w.u64(wt.ny as u64);
        for v in wt.t.iter().chain(wt.p.iter()) {
            w.f64(*v);
        }
        w.u64(self.resources.len() as u64);
        for v in &self.resources {
            w.f64(*v);
        }
    }

    /// Restores weather and stocks into a freshly built world of the same config.
    pub fn read_state(&mut self, r: &mut crate::checkpoint::Reader) -> crate::checkpoint::Res<()> {
        use crate::checkpoint::err;
        let tick = r.u64()?;
        let (nx, ny) = (r.u64()?, r.u64()?);
        if nx != self.weather.nx as u64 || ny != self.weather.ny as u64 {
            return err("weather grid does not match the configuration");
        }
        let n = self.weather.t.len();
        let mut t = Vec::with_capacity(n);
        let mut p = Vec::with_capacity(n);
        if r.remaining() < n.saturating_mul(16) {
            return err("unexpected end of data");
        }
        for _ in 0..n {
            t.push(r.finite("weather")?);
        }
        for _ in 0..n {
            p.push(r.finite("weather")?);
        }
        let cells = r.u64()?;
        if cells != self.resources.len() as u64 {
            return err("resource count does not match the world");
        }
        if r.remaining() < self.resources.len().saturating_mul(8) {
            return err("unexpected end of data");
        }
        for i in 0..self.resources.len() {
            let v = r.finite("resource")?;
            if v < 0.0 || v > self.resource_cap[i] {
                return err("resource stock outside [0, capacity]");
            }
            self.resources[i] = v;
        }
        self.weather.tick = tick;
        self.weather.t = t;
        self.weather.p = p;
        Ok(())
    }

    /// True if the cell offers cover (refuge) to prey.
    pub fn has_cover(&self, p: crate::grid::Pos) -> bool {
        self.cover[self.grid.index(p)]
    }

    /// Feeds the static per-cell resource capacity (state hash, ADR-0023).
    pub fn cap_words(&self, f: &mut dyn FnMut(u64)) {
        f(self.resource_cap.len() as u64);
        for v in &self.resource_cap {
            f(v.to_bits());
        }
    }

    /// Feeds the resource state into the digest.
    pub fn resource_words(&self, f: &mut dyn FnMut(u64)) {
        for v in &self.resources {
            f(v.to_bits());
        }
    }
}

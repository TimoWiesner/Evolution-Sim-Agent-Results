//! Survival report (TASK-018, ADR-0022, docs/ECOLOGY.md): runs a configuration for N ticks and
//! records, per kind, the tick at which the kind first had zero living organisms (final, because
//! nothing but reproduction creates organisms) or that it survived.

use crate::config::{Config, ConfigError};
use crate::organism::Kind;
use crate::sim::Simulation;

#[derive(Clone, Debug, PartialEq)]
pub struct KindOutcome {
    pub kind: Kind,
    /// Tick count (completed ticks) after which the kind was first at 0 living; `None` = survived.
    pub extinct_at: Option<u64>,
    pub final_count: usize,
    pub peak_count: usize,
    pub births: u64,
    pub deaths: u64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct SeedReport {
    pub seed: i64,
    pub ticks: u64,
    pub outcomes: [KindOutcome; 3],
    /// Ticks (of `ticks`) in which all three kinds were alive at the end of the tick.
    pub coexist_ticks: u64,
    /// Ledger violations seen (must be 0).
    pub ledger_errors: u64,
}

/// Runs `cfg` (with `cfg.seed`) for `ticks` ticks, checking the ledger every tick.
pub fn run_survival(cfg: &Config, ticks: u64) -> Result<SeedReport, ConfigError> {
    let mut sim = Simulation::new(cfg)?;
    let mut extinct: [Option<u64>; 3] = [None; 3];
    let mut peak = [0usize; 3];
    let mut coexist = 0u64;
    let mut ledger_errors = 0u64;
    for k in Kind::ALL {
        let c = sim.organisms.count(k);
        peak[k.index()] = c;
        if c == 0 {
            extinct[k.index()] = Some(0);
        }
    }
    for _ in 0..ticks {
        sim.step();
        if sim.ledger_check().is_err() {
            ledger_errors += 1;
        }
        let mut all = true;
        for k in Kind::ALL {
            let c = sim.organisms.count(k);
            let i = k.index();
            peak[i] = peak[i].max(c);
            if c == 0 {
                all = false;
                if extinct[i].is_none() {
                    extinct[i] = Some(sim.tick);
                }
            }
        }
        if all {
            coexist += 1;
        }
    }
    let mk = |k: Kind| KindOutcome {
        kind: k,
        extinct_at: extinct[k.index()],
        final_count: sim.organisms.count(k),
        peak_count: peak[k.index()],
        births: sim.organisms.stats.births[k.index()],
        deaths: sim.organisms.stats.deaths[k.index()],
    };
    Ok(SeedReport { seed: cfg.seed, ticks, outcomes: [mk(Kind::Plant), mk(Kind::Herbivore), mk(Kind::Carnivore)], coexist_ticks: coexist, ledger_errors })
}

/// Human-readable table of seed reports.
pub fn format_reports(reports: &[SeedReport]) -> String {
    let mut s = String::new();
    for r in reports {
        s.push_str(&format!("seed {} ({} ticks, all three alive for {} ticks, ledger errors {})\n", r.seed, r.ticks, r.coexist_ticks, r.ledger_errors));
        for o in &r.outcomes {
            let res = match o.extinct_at {
                Some(t) => format!("extinct at tick {}", t),
                None => "survived".to_string(),
            };
            s.push_str(&format!("  {:<10} {:<20} final {:>6} peak {:>6} births {:>7} deaths {:>7}\n", format!("{:?}", o.kind), res, o.final_count, o.peak_count, o.births, o.deaths));
        }
    }
    s
}

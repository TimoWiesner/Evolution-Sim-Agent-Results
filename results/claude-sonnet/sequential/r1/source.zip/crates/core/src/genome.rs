//! Diploid real-valued genome, gene->trait mapping, inheritance, mutation, distance (ADR-0013).
//!
//! Alleles are f32 in [0,1], locus-major: `alleles[locus] = [slot0, slot1]`. All arithmetic uses only
//! basic operations (+ - * / compare) so results are identical across platforms.

use crate::config::Config;
use crate::organism::{Kind, Traits};
use crate::rng::Rng;

/// Append-only gene list (index = locus).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Gene {
    Speed,
    Strength,
    Fertility,
    MaxHealth,
    MaxLifespan,
    MaxEnergy,
    Metabolism,
    Vision,
    Aggression,
    RiskTolerance,
}

pub const N_GENES: usize = 10;

impl Gene {
    pub const ALL: [Gene; N_GENES] = [
        Gene::Speed,
        Gene::Strength,
        Gene::Fertility,
        Gene::MaxHealth,
        Gene::MaxLifespan,
        Gene::MaxEnergy,
        Gene::Metabolism,
        Gene::Vision,
        Gene::Aggression,
        Gene::RiskTolerance,
    ];
    pub fn index(self) -> usize {
        self as usize
    }
}

/// Mutation parameters: per-allele probability and step standard deviation.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Mutation {
    pub rate: f64,
    pub sigma: f64,
}

impl Mutation {
    pub fn for_kind(cfg: &Config, kind: Kind) -> Mutation {
        let rate = match kind {
            Kind::Plant => cfg.plants.mutation_rate,
            Kind::Herbivore => cfg.herbivores.mutation_rate,
            Kind::Carnivore => cfg.carnivores.mutation_rate,
        };
        Mutation { rate, sigma: cfg.genetics.mutation_sigma }
    }
    pub const NONE: Mutation = Mutation { rate: 0.0, sigma: 0.0 };
}

/// Piecewise-linear scale factor: f(0)=0.25, f(0.5)=1, f(1)=4.
pub fn scale_factor(g: f64) -> f64 {
    if g <= 0.5 {
        0.25 + 0.75 * (2.0 * g)
    } else {
        1.0 + 3.0 * (2.0 * g - 1.0)
    }
}

/// Inverse of `scale_factor` (input clamped to [0.25, 4]).
pub fn scale_factor_inverse(s: f64) -> f64 {
    let s = if s.is_nan() { 1.0 } else { s.max(0.25).min(4.0) };
    if s <= 1.0 {
        (s - 0.25) / 0.75 / 2.0
    } else {
        ((s - 1.0) / 3.0 + 1.0) / 2.0
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Genome {
    alleles: [[f32; 2]; N_GENES],
}

fn sane(a: f32) -> f32 {
    if a.is_nan() {
        0.5
    } else {
        a.max(0.0).min(1.0)
    }
}

impl Genome {
    /// Builds a genome from raw alleles (clamped to [0,1], NaN -> 0.5).
    pub fn from_alleles(mut alleles: [[f32; 2]; N_GENES]) -> Genome {
        for l in alleles.iter_mut() {
            l[0] = sane(l[0]);
            l[1] = sane(l[1]);
        }
        Genome { alleles }
    }

    pub fn alleles(&self) -> &[[f32; 2]; N_GENES] {
        &self.alleles
    }

    /// Codominant locus value (mean of the two alleles), in [0,1].
    pub fn locus_value(&self, gene: Gene) -> f64 {
        let a = self.alleles[gene.index()];
        (a[0] as f64 + a[1] as f64) / 2.0
    }

    /// Deterministic gene -> trait mapping relative to the kind's baseline; always within `Traits::range(kind)`.
    pub fn traits(&self, kind: Kind, baseline: &Traits) -> Traits {
        let v = |g: Gene| self.locus_value(g);
        let sc = |g: Gene| scale_factor(v(g));
        let t = Traits {
            speed: baseline.speed * sc(Gene::Speed),
            strength: baseline.strength * sc(Gene::Strength),
            fertility: v(Gene::Fertility),
            max_health: baseline.max_health * sc(Gene::MaxHealth),
            max_lifespan: (baseline.max_lifespan as f64 * sc(Gene::MaxLifespan) + 0.5).floor().min(4.0e9) as u32,
            max_energy: baseline.max_energy * sc(Gene::MaxEnergy),
            metabolism: baseline.metabolism * sc(Gene::Metabolism),
            vision: baseline.vision * sc(Gene::Vision),
            aggression: v(Gene::Aggression),
            risk_tolerance: v(Gene::RiskTolerance),
        };
        t.clamped(kind)
    }

    /// Approximate (clamped) inverse of `traits`: both alleles of a locus get the same value.
    pub fn from_traits(_kind: Kind, baseline: &Traits, t: &Traits) -> Genome {
        let ratio = |val: f64, base: f64| if base > 0.0 { scale_factor_inverse(val / base) } else { 0.5 };
        let vals = [
            ratio(t.speed, baseline.speed),
            ratio(t.strength, baseline.strength),
            t.fertility,
            ratio(t.max_health, baseline.max_health),
            ratio(t.max_lifespan as f64, baseline.max_lifespan as f64),
            ratio(t.max_energy, baseline.max_energy),
            ratio(t.metabolism, baseline.metabolism),
            ratio(t.vision, baseline.vision),
            t.aggression,
            t.risk_tolerance,
        ];
        let mut a = [[0.5f32; 2]; N_GENES];
        for (l, v) in a.iter_mut().zip(vals) {
            *l = [v as f32, v as f32];
        }
        Genome::from_alleles(a)
    }

    /// Founder genome: `from_traits(baseline)` plus uniform(-variation, +variation) noise on each allele.
    /// variation 0 draws nothing.
    pub fn founder(kind: Kind, baseline: &Traits, rng: &mut Rng, variation: f64) -> Genome {
        let mut g = Genome::from_traits(kind, baseline, baseline);
        if variation > 0.0 {
            for l in g.alleles.iter_mut() {
                for a in l.iter_mut() {
                    let u = rng.next_f32() as f64 * 2.0 - 1.0;
                    *a = sane(*a + (u * variation) as f32);
                }
            }
        }
        g
    }

    /// Asexual child: exact copy, then mutation.
    pub fn child_of_one(parent: &Genome, m: &Mutation, rng: &mut Rng) -> Genome {
        let mut c = *parent;
        c.mutate(m, rng);
        c
    }

    /// One gamete (an allele per locus): starts on a random strand, switches strand after each locus
    /// with probability `crossover_rate`.
    fn gamete(&self, crossover_rate: f64, rng: &mut Rng) -> [f32; N_GENES] {
        let mut slot = rng.below(2) as usize;
        let mut out = [0.0f32; N_GENES];
        for (i, o) in out.iter_mut().enumerate() {
            if i > 0 && rng.chance(crossover_rate) {
                slot = 1 - slot;
            }
            *o = self.alleles[i][slot];
        }
        out
    }

    /// Sexual child: slot 0 from a gamete of `a`, slot 1 from a gamete of `b`; then mutation.
    pub fn child_of_two(a: &Genome, b: &Genome, crossover_rate: f64, m: &Mutation, rng: &mut Rng) -> Genome {
        let ga = a.gamete(crossover_rate, rng);
        let gb = b.gamete(crossover_rate, rng);
        let mut alleles = [[0.0f32; 2]; N_GENES];
        for i in 0..N_GENES {
            alleles[i] = [ga[i], gb[i]];
        }
        let mut c = Genome { alleles };
        c.mutate(m, rng);
        c
    }

    /// Mutates in place; returns the number of alleles that changed. Rate <= 0 or sigma <= 0 draws nothing.
    /// Step = sigma*sqrt(3)*(u1+u2+u3+u4-2) (Irwin-Hall, std = sigma), result clamped to [0,1].
    pub fn mutate(&mut self, m: &Mutation, rng: &mut Rng) -> usize {
        if !(m.rate > 0.0) || !(m.sigma > 0.0) {
            return 0;
        }
        let mut changed = 0;
        for l in self.alleles.iter_mut() {
            for a in l.iter_mut() {
                if rng.chance(m.rate) {
                    let s = rng.next_f32() + rng.next_f32() + rng.next_f32() + rng.next_f32() - 2.0;
                    let step = (m.sigma * 1.732_050_807_568_877_2) as f32 * s;
                    let n = sane(*a + step);
                    if n != *a {
                        changed += 1;
                    }
                    *a = n;
                }
            }
        }
        changed
    }

    /// Genetic distance in [0,1]: mean over loci of the better of the two allele pairings (L1, halved).
    /// 0 iff the allele multisets agree at every locus; symmetric; satisfies the triangle inequality.
    pub fn distance(a: &Genome, b: &Genome) -> f64 {
        let mut sum = 0.0;
        for i in 0..N_GENES {
            let [a0, a1] = a.alleles[i];
            let [b0, b1] = b.alleles[i];
            let (a0, a1, b0, b1) = (a0 as f64, a1 as f64, b0 as f64, b1 as f64);
            let straight = (a0 - b0).abs() + (a1 - b1).abs();
            let crossed = (a0 - b1).abs() + (a1 - b0).abs();
            sum += straight.min(crossed) / 2.0;
        }
        sum / N_GENES as f64
    }

    /// Phenotype-level distance: mean |locus value difference|, in [0,1].
    pub fn trait_distance(a: &Genome, b: &Genome) -> f64 {
        let mut sum = 0.0;
        for g in Gene::ALL {
            sum += (a.locus_value(g) - b.locus_value(g)).abs();
        }
        sum / N_GENES as f64
    }

    /// Checkpoint: 20 f32 bit patterns.
    pub fn write_state(&self, w: &mut crate::checkpoint::Writer) {
        for l in &self.alleles {
            w.f32(l[0]);
            w.f32(l[1]);
        }
    }

    /// Reads a genome; alleles must already be valid (finite, in [0,1]) so bits are preserved exactly.
    pub fn read_state(r: &mut crate::checkpoint::Reader) -> crate::checkpoint::Res<Genome> {
        let mut a = [[0f32; 2]; N_GENES];
        for l in a.iter_mut() {
            for v in l.iter_mut() {
                *v = r.f32()?;
                if !(0.0..=1.0).contains(v) || (*v == 0.0 && v.is_sign_negative()) {
                    return crate::checkpoint::err("allele outside [0,1]");
                }
            }
        }
        Ok(Genome { alleles: a })
    }

    /// Feeds allele bit patterns for the state digest.
    pub fn state_words(&self, f: &mut dyn FnMut(u64)) {
        for l in &self.alleles {
            f(((l[0].to_bits() as u64) << 32) | l[1].to_bits() as u64);
        }
    }
}

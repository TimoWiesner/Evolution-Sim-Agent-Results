//! Deterministic PRNG: xoshiro256++ seeded through SplitMix64 (ADR-0005, ADR-0009).
//! No OS entropy, no clock, no dependencies. State is exportable and restorable exactly.

const GOLDEN: u64 = 0x9E37_79B9_7F4A_7C15;

/// One SplitMix64 step: advances `x` and returns the mixed output.
pub fn splitmix64(x: &mut u64) -> u64 {
    *x = x.wrapping_add(GOLDEN);
    let mut z = *x;
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Rng {
    s: [u64; 4],
}

impl Rng {
    /// Seeds from a config seed. The `i64` is cast `as u64` (two's complement), so any integer works.
    pub fn new(seed: i64) -> Rng {
        Rng::from_u64_seed(seed as u64)
    }

    fn from_u64_seed(seed: u64) -> Rng {
        let mut x = seed;
        let mut s = [0u64; 4];
        for w in s.iter_mut() {
            *w = splitmix64(&mut x);
        }
        if s == [0; 4] {
            s[0] = GOLDEN;
        }
        Rng { s }
    }

    /// Independent per-purpose stream derived from the seed and a stream id.
    pub fn stream(seed: i64, id: u64) -> Rng {
        let mut x = (seed as u64) ^ id.wrapping_mul(GOLDEN);
        let mixed = splitmix64(&mut x);
        Rng::from_u64_seed(mixed)
    }

    pub fn next_u64(&mut self) -> u64 {
        let s = &mut self.s;
        let result = s[0].wrapping_add(s[3]).rotate_left(23).wrapping_add(s[0]);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        result
    }

    pub fn next_u32(&mut self) -> u32 {
        (self.next_u64() >> 32) as u32
    }

    /// Uniform in [0,1) from the top 24 bits.
    pub fn next_f32(&mut self) -> f32 {
        (self.next_u64() >> 40) as f32 / 16_777_216.0
    }

    /// Uniform in [0,1) from the top 53 bits.
    pub fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 / 9_007_199_254_740_992.0
    }

    /// Unbiased uniform integer in [0,n) (Lemire multiply-shift with rejection). n=0 returns 0.
    pub fn below(&mut self, n: u64) -> u64 {
        if n == 0 {
            return 0;
        }
        let mut m = (self.next_u64() as u128) * (n as u128);
        let mut lo = m as u64;
        if lo < n {
            let thresh = n.wrapping_neg() % n;
            while lo < thresh {
                m = (self.next_u64() as u128) * (n as u128);
                lo = m as u64;
            }
        }
        (m >> 64) as u64
    }

    /// Uniform integer in [lo,hi] inclusive (lo>hi returns lo).
    pub fn range_i64(&mut self, lo: i64, hi: i64) -> i64 {
        if hi <= lo {
            return lo;
        }
        let span = (hi as i128 - lo as i128 + 1) as u128;
        if span > u64::MAX as u128 {
            return self.next_u64() as i64;
        }
        (lo as i128 + self.below(span as u64) as i128) as i64
    }

    /// True with probability p (p<=0 never, p>=1 always). Always consumes one draw.
    pub fn chance(&mut self, p: f64) -> bool {
        self.next_f64() < p
    }

    /// Exports the full state.
    pub fn state(&self) -> [u64; 4] {
        self.s
    }

    /// Restores an exported state; the all-zero state is invalid and rejected.
    pub fn from_state(s: [u64; 4]) -> Option<Rng> {
        if s == [0; 4] {
            None
        } else {
            Some(Rng { s })
        }
    }

    /// 64 lowercase hex chars (4 words, big-endian digits each) for JSON checkpoints.
    pub fn to_hex(&self) -> String {
        self.s.iter().map(|w| format!("{:016x}", w)).collect()
    }

    pub fn from_hex(h: &str) -> Option<Rng> {
        if h.len() != 64 || !h.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)) {
            return None;
        }
        let mut s = [0u64; 4];
        for (i, w) in s.iter_mut().enumerate() {
            *w = u64::from_str_radix(&h[i * 16..i * 16 + 16], 16).ok()?;
        }
        Rng::from_state(s)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn xoshiro_reference_vector() {
        // Verified against an independent Python implementation of xoshiro256++.
        let mut r = Rng::from_state([1, 2, 3, 4]).unwrap();
        let got: Vec<u64> = (0..5).map(|_| r.next_u64()).collect();
        assert_eq!(got, vec![41943041, 58720359, 3588806011781223, 3591011842654386, 9228616714210784205]);
    }

    #[test]
    fn splitmix_reference_vector() {
        let mut x = 0u64;
        assert_eq!(splitmix64(&mut x), 0xE220A8397B1DCDAF);
        assert_eq!(splitmix64(&mut x), 0x6E789E6AA1B965F4);
        assert_eq!(splitmix64(&mut x), 0x06C45D188009454F);
    }

    #[test]
    fn export_restore_continues() {
        let mut a = Rng::new(7);
        for _ in 0..10 {
            a.next_u64();
        }
        let mut b = Rng::from_state(a.state()).unwrap();
        let mut c = Rng::from_hex(&a.to_hex()).unwrap();
        for _ in 0..100 {
            let v = a.next_u64();
            assert_eq!(v, b.next_u64());
            assert_eq!(v, c.next_u64());
        }
    }

    #[test]
    fn hex_rejects_bad() {
        assert!(Rng::from_hex(&"0".repeat(64)).is_none());
        assert!(Rng::from_hex("abc").is_none());
        assert!(Rng::from_hex(&"G".repeat(64)).is_none());
        assert!(Rng::from_state([0; 4]).is_none());
        assert_eq!(Rng::from_hex(&Rng::new(1).to_hex()).unwrap(), Rng::new(1));
    }

    #[test]
    fn below_in_range_and_uniform() {
        let mut r = Rng::new(3);
        let mut b = [0u32; 6];
        for _ in 0..60000 {
            b[r.below(6) as usize] += 1;
        }
        for c in b {
            assert!((9500..=10500).contains(&c), "{:?}", b);
        }
        assert_eq!(r.below(0), 0);
        assert_eq!(r.below(1), 0);
        for _ in 0..1000 {
            let v = r.range_i64(-3, 3);
            assert!((-3..=3).contains(&v));
        }
        assert_eq!(r.range_i64(5, 5), 5);
    }

    #[test]
    fn floats_in_unit_interval() {
        let mut r = Rng::new(9);
        for _ in 0..10000 {
            let a = r.next_f32();
            let b = r.next_f64();
            assert!((0.0..1.0).contains(&a) && (0.0..1.0).contains(&b));
        }
    }

    #[test]
    fn seeds_and_streams_differ() {
        assert_ne!(Rng::new(1).state(), Rng::new(2).state());
        assert_ne!(Rng::new(-1).state(), Rng::new(1).state());
        assert_ne!(Rng::stream(1, 1).state(), Rng::stream(1, 2).state());
        assert_eq!(Rng::stream(1, 1), Rng::stream(1, 1));
        let _ = Rng::new(i64::MIN);
    }
}

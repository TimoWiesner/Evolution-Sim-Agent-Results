//! Simulation state and the tick scheduler (ADR-0009).
//!
//! # Tick order (fixed)
//! `Phase::ORDER`: Climate, Plants, Herbivores, Carnivores, Deaths, Births, Index.
//! Within a phase organisms act in ascending id (ids monotonic, never reused). Conflicts and
//! candidate ties are resolved by lowest id, then lowest row-major cell index (`tie_break_min`).
//! Deaths and births are deferred and applied sorted by id; newborn ids follow processing order.
//! Hash-based collections are never iterated. `tick` is incremented at the END of `step`:
//! during phases `tick` is the index of the tick being computed (first tick = 0).

use crate::config::{Config, ConfigError};
use crate::organism::{DeathCause, Id, Kind, Organisms};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;
use crate::world::World;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Climate,
    Plants,
    Herbivores,
    Carnivores,
    Deaths,
    Births,
    Index,
}

impl Phase {
    pub const ORDER: [Phase; 7] = [
        Phase::Climate,
        Phase::Plants,
        Phase::Herbivores,
        Phase::Carnivores,
        Phase::Deaths,
        Phase::Births,
        Phase::Index,
    ];

    pub fn name(self) -> &'static str {
        match self {
            Phase::Climate => "climate",
            Phase::Plants => "plants",
            Phase::Herbivores => "herbivores",
            Phase::Carnivores => "carnivores",
            Phase::Deaths => "deaths",
            Phase::Births => "births",
            Phase::Index => "index",
        }
    }
}

/// Extensible event kinds (Born/Died... are added by later tasks).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EventKind {
    PhaseRun,
    Born { id: Id, kind: Kind },
    Died { id: Id, kind: Kind, cause: DeathCause },
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Event {
    pub tick: u64,
    pub phase: Phase,
    pub kind: EventKind,
}

/// Output of one tick. Events are output only and never read back into state.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TickReport {
    /// Index of the tick that was just computed.
    pub tick: u64,
    /// Empty unless `Simulation::record_events` is set.
    pub events: Vec<Event>,
}

#[derive(Clone, Debug)]
pub struct Simulation {
    pub config: Config,
    pub world: World,
    pub rng: Rng,
    /// Number of completed ticks.
    pub tick: u64,
    /// TASK-005 placeholder trace accumulator (one RNG draw per phase except Climate, which evolves the weather); remove when phases get real behaviour.
    pub acc: u64,
    pub record_events: bool,
    pub organisms: Organisms,
    /// Derived spatial index (ADR-0014/0017); kept in sync incrementally, not in the digest.
    pub spatial: SpatialIndex,
    /// Births / deaths of the tick computed last (per kind index); reset every tick.
    pub last_births: [u64; 3],
    pub last_deaths: [u64; 3],
    /// Energy accounting of the Plants phase of the tick computed last (not part of the digest).
    pub last_plant_stats: crate::plants::PlantPhaseStats,
    /// Energy accounting of the Herbivores phase of the tick computed last (not part of the digest).
    pub last_herbivore_stats: crate::herbivore::HerbivoreStats,
    /// Energy accounting of the Carnivores phase of the tick computed last (not part of the digest).
    pub last_carnivore_stats: crate::carnivore::CarnivoreStats,
    /// Mating accounting of the Births phase of the tick computed last (not part of the digest).
    pub last_reproduction_stats: crate::reproduction::ReproductionStats,
    /// Species and family tree (ADR-0021); part of the digest.
    pub species: crate::species::SpeciesRegistry,
}

impl Simulation {
    /// Validates the config and builds the initial state. `--seed` overrides are applied to the config by the caller.
    pub fn new(config: &Config) -> Result<Simulation, ConfigError> {
        config.validate()?;
        let world = World::new(config).map_err(|m| ConfigError {
            key: "world".to_string(),
            kind: crate::config::ErrorKind::OutOfRange,
            message: m,
        })?;
        let mut organisms = Organisms::populate(config, &world.grid);
        let mut species = crate::species::SpeciesRegistry::new();
        species.classify(&mut organisms, config, 0);
        species.finish_tick(&organisms, 0);
        let mut spatial = SpatialIndex::new(world.grid);
        spatial.rebuild(&organisms);
        Ok(Simulation {
            organisms,
            species,
            spatial,
            last_births: [0; 3],
            last_deaths: [0; 3],
            last_plant_stats: Default::default(),
            last_herbivore_stats: Default::default(),
            last_carnivore_stats: Default::default(),
            last_reproduction_stats: Default::default(),
            config: config.clone(),
            world,
            rng: Rng::new(config.seed),
            tick: 0,
            acc: 0,
            record_events: false,
        })
    }

    /// Advances exactly one tick.
    pub fn step(&mut self) -> TickReport {
        self.step_inner(None)
    }

    /// Like `step`, calling `hook(phase, true)` before and `hook(phase, false)` after each phase
    /// (ADR-0030). The core never reads a clock; profilers time the calls outside. The hook cannot
    /// touch the simulation, so state evolves exactly as with `step`.
    pub fn step_hooked(&mut self, hook: &mut dyn FnMut(Phase, bool)) -> TickReport {
        self.step_inner(Some(hook))
    }

    fn step_inner(&mut self, mut hook: Option<&mut dyn FnMut(Phase, bool)>) -> TickReport {
        let tick = self.tick;
        let mut events = Vec::new();
        self.last_births = [0; 3];
        self.last_deaths = [0; 3];
        for phase in Phase::ORDER {
            if self.record_events {
                events.push(Event { tick, phase, kind: EventKind::PhaseRun });
            }
            if let Some(h) = hook.as_deref_mut() {
                h(phase, true);
            }
            self.run_phase(phase, &mut events);
            if let Some(h) = hook.as_deref_mut() {
                h(phase, false);
            }
        }
        self.tick += 1;
        TickReport { tick, events }
    }

    pub fn run(&mut self, n: u64) {
        for _ in 0..n {
            self.step();
        }
    }

    fn run_phase(&mut self, phase: Phase, events: &mut Vec<Event>) {
        if phase == Phase::Climate {
            let tick = self.tick;
            self.world.advance_weather(tick, &self.config, &mut self.rng);
            return;
        }
        let tick = self.tick;
        if phase == Phase::Plants {
            self.last_plant_stats = crate::plants::run_plants_phase(&mut self.world, &mut self.organisms, &self.config, tick, &mut self.rng);
        } else if phase == Phase::Herbivores {
            self.last_herbivore_stats = crate::herbivore::run_herbivore_phase(&self.world, &mut self.organisms, &mut self.spatial, &self.config, tick, &mut self.rng);
            return;
        } else if phase == Phase::Carnivores {
            self.last_carnivore_stats = crate::carnivore::run_carnivore_phase(&self.world, &mut self.organisms, &mut self.spatial, &self.config, tick, &mut self.rng);
            return;
        } else if phase == Phase::Index {
            debug_assert!(self.check_index().is_ok(), "{:?}", self.check_index());
        } else if phase == Phase::Deaths {
            for o in self.organisms.resolve_deaths(tick) {
                let _ = self.spatial.remove(o.id);
                self.last_deaths[o.kind.index()] += 1;
                if self.record_events {
                    let cause = o.death.map(|d| d.cause).unwrap_or(DeathCause::Other);
                    events.push(Event { tick, phase, kind: EventKind::Died { id: o.id, kind: o.kind, cause } });
                }
            }
        } else if phase == Phase::Births {
            self.last_reproduction_stats = crate::reproduction::run_reproduction_phase(&mut self.organisms, &self.spatial, &self.config, tick, &mut self.rng);
            for (id, kind) in self.organisms.resolve_births(tick) {
                self.last_births[kind.index()] += 1;
                if let Some(o) = self.organisms.get(kind, id) {
                    let _ = self.spatial.insert(id, kind, o.pos);
                }
                if self.record_events {
                    events.push(Event { tick, phase, kind: EventKind::Born { id, kind } });
                }
            }
            if tick % self.config.genetics.species_check_interval as u64 == 0 {
                self.species.classify(&mut self.organisms, &self.config, tick);
            }
            self.species.finish_tick(&self.organisms, tick);
        }
        // TASK-005 placeholder: remove when a phase gets real behaviour.
        // Each stub phase consumes one draw, so the trace depends on seed and phase order.
        let _ = phase;
        let d = self.rng.next_u64();
        self.acc = self.acc.rotate_left(5) ^ d;
    }

    /// Ledger invariant (ADR-0022): per kind `founded + births - deaths == living count`, and the
    /// stored (not yet removed) organisms equal the living ones between ticks.
    pub fn ledger_check(&self) -> Result<(), String> {
        let st = &self.organisms.stats;
        for k in Kind::ALL {
            let i = k.index();
            let expect = (st.founded[i] + st.births[i]) as i64 - st.deaths[i] as i64;
            let have = self.organisms.count(k) as i64;
            if expect != have {
                return Err(format!("{:?}: founded {} + births {} - deaths {} = {} but {} alive", k, st.founded[i], st.births[i], st.deaths[i], expect, have));
            }
            if self.organisms.stored(k) as i64 != have {
                return Err(format!("{:?}: {} stored but {} alive", k, self.organisms.stored(k), have));
            }
        }
        Ok(())
    }

    /// Number of living species of `kind` now.
    pub fn living_species(&self, kind: Kind) -> usize {
        self.species.living(kind)
    }

    /// Rebuilds the spatial index from `organisms` (call after replacing `organisms` wholesale).
    pub fn rebuild_index(&mut self) {
        self.spatial.rebuild(&self.organisms);
    }

    /// Verifies that the index holds exactly the alive organisms at their positions.
    pub fn check_index(&self) -> Result<(), String> {
        let mut n = 0usize;
        for k in Kind::ALL {
            for o in self.organisms.vec(k) {
                if !o.alive {
                    continue;
                }
                n += 1;
                match self.spatial.get(o.id) {
                    Some((ik, ip)) if ik == o.kind && ip == o.pos => {}
                    other => return Err(format!("organism {} at {:?} indexed as {:?}", o.id, o.pos, other)),
                }
            }
        }
        if n != self.spatial.len() {
            return Err(format!("index holds {} entries, {} organisms alive", self.spatial.len(), n));
        }
        Ok(())
    }

    /// FNV-1a 64 over LE bytes of tick, acc, the 4 RNG words, weather state words, grid width/height.
    pub fn digest(&self) -> u64 {
        let mut h: u64 = 0xcbf2_9ce4_8422_2325;
        let mut feed = |v: u64| {
            for b in v.to_le_bytes() {
                h ^= b as u64;
                h = h.wrapping_mul(0x0000_0100_0000_01b3);
            }
        };
        feed(self.tick);
        feed(self.acc);
        for w in self.rng.state() {
            feed(w);
        }
        for w in self.world.weather.state_words() {
            feed(w);
        }
        self.organisms.state_words(&mut feed);
        self.species.state_words(&mut feed);
        self.world.resource_words(&mut feed);
        feed(self.world.grid.width() as u64);
        feed(self.world.grid.height() as u64);
        h
    }

    /// SHA-256 (lowercase hex, 64 chars) over the complete state (ADR-0023): clock, rng, weather,
    /// all organisms with genomes and counters, species registry, resource stocks and capacity,
    /// the static climate map and the canonical configuration. Sections are length-prefixed.
    pub fn state_hash(&self) -> String {
        debug_assert_eq!(self.organisms.pending_births(), 0, "state_hash between ticks only");
        let mut h = crate::hash::Sha256::new();
        let mut buf: Vec<u8> = Vec::with_capacity(1 << 16);
        fn flush(h: &mut crate::hash::Sha256, buf: &mut Vec<u8>) {
            if buf.len() >= 1 << 16 {
                h.update(buf);
                buf.clear();
            }
        }
        {
            let mut feed = |v: u64| buf.extend_from_slice(&v.to_le_bytes());
            feed(0x4556_4f53_494d_5348); // domain tag "EVOSIMSH"
            feed(1); // format version
            feed(self.tick);
            feed(self.acc);
            for w in self.rng.state() {
                feed(w);
            }
        }
        // Variable-length sections: collect words, prefix with the count.
        let sections: [Box<dyn Fn(&mut dyn FnMut(u64)) + '_>; 5] = [
            Box::new(|f| {
                let w = self.world.weather.state_words();
                f(w.len() as u64);
                for x in w {
                    f(x);
                }
            }),
            Box::new(|f| self.organisms.state_words(f)),
            Box::new(|f| self.species.state_words(f)),
            Box::new(|f| {
                self.world.resource_words(f);
                self.world.cap_words(f);
            }),
            Box::new(|f| {
                let c = &self.world.climate;
                f(c.width as u64);
                f(c.height as u64);
                for v in c.temp.iter().chain(&c.precip).chain(&c.elevation).chain(&c.warmth_row) {
                    f(v.to_bits());
                }
                for z in &c.zone {
                    f(*z as u64);
                }
                for b in &c.biome {
                    f(*b as u8 as u64);
                }
            }),
        ];
        for sec in sections.iter() {
            let mut words: Vec<u64> = Vec::new();
            sec(&mut |w| words.push(w));
            buf.extend_from_slice(&(words.len() as u64).to_le_bytes());
            for w in words {
                buf.extend_from_slice(&w.to_le_bytes());
                flush(&mut h, &mut buf);
            }
        }
        buf.extend_from_slice(&(self.world.grid.width() as u64).to_le_bytes());
        buf.extend_from_slice(&(self.world.grid.height() as u64).to_le_bytes());
        let cfg = self.config.to_json();
        buf.extend_from_slice(&(cfg.len() as u64).to_le_bytes());
        buf.extend_from_slice(cfg.as_bytes());
        h.update(&buf);
        crate::hash::hex(&h.finalize())
    }

    /// Order in which organisms act: ascending id.
    pub fn act_order(&self, ids: &[u64]) -> Vec<u64> {
        let mut v = ids.to_vec();
        v.sort_unstable();
        v
    }

    pub fn export_rng(&self) -> [u64; 4] {
        self.rng.state()
    }

    /// Restores RNG state; returns false (state unchanged) for the invalid all-zero state.
    pub fn restore_rng(&mut self, s: [u64; 4]) -> bool {
        match Rng::from_state(s) {
            Some(r) => {
                self.rng = r;
                true
            }
            None => false,
        }
    }
}

/// Tie-break rule: among `(id, key)` candidates pick the lowest key; equal keys -> lowest id.
pub fn tie_break_min<K: PartialOrd + Copy>(items: &[(u64, K)]) -> Option<u64> {
    let mut best: Option<(u64, K)> = None;
    for &(id, k) in items {
        best = match best {
            None => Some((id, k)),
            Some((bid, bk)) => {
                if k < bk || (k == bk && id < bid) {
                    Some((id, k))
                } else {
                    Some((bid, bk))
                }
            }
        };
    }
    best.map(|b| b.0)
}

# Evolution Simulation

A grid-world ecological evolution game: a toroidal world with latitude climate zones, seasons and weather, in which plants, herbivores and carnivores grow, eat, reproduce with heritable DNA, mutate and split into species. One Rust engine drives the headless CLI and the browser UI. Everything is deterministic for a given configuration and seed.

**Honest summary of the outcome:** all features are implemented and verified (`docs/VERIFICATION.md`, `docs/AUDIT.md`), but a food chain of all three kinds that lasts 10,000 ticks was **not** reached: see [Coexistence results](#coexistence-results).

## Install
Requirements: Ubuntu 24.04 x86-64, internet access once. `chromium` (browser UI screenshots, already present in the benchmark container) and Python 3 (tests only) are used if available.
```
./setup.sh        # installs rustup/cargo if missing and builds the release binary; idempotent
```
No third-party crates are used. `./evosim` rebuilds automatically if sources changed.

## Demo (one command)
```
./evosim ui --config scenarios/demo.json
```
Starts the local UI server (prints `http://127.0.0.1:8765/`, opens a browser when a display exists) with the demo world (96x64 cells, 900 plants, 200 herbivores, 14 carnivores). Headless equivalent: `./evosim run --config scenarios/demo.json --ticks 10000 --out demo.json`.

## Commands
```
./evosim version
./evosim run   --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--save FILE] [--metrics FILE]
./evosim run   --load FILE   --ticks N --out FILE [--sample-every K] [--save FILE]
./evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR [--param PATH=V1,V2]... [--jobs J]
./evosim ui    [--config FILE] [--port N] [--no-open] | --smoke-test | --screenshots DIR
```
- **run**: headless; writes the result JSON (final counts and species, births/deaths totals, time series, `state_hash`, speed). Same config + seed + ticks give identical results; `--save`/`--load` continue a run bit-exactly. Errors exit 2 with a message on stderr and no result file. Details: `docs/CLI.md`, `docs/CHECKPOINT.md`, `docs/METRICS.md`.
- **batch**: one run per seed (`DIR/seed-<seed>.json`) plus `summary.json`/CSV with mean/min/max/sd/median per parameter combination; `--param` sweeps any configuration key (cartesian product), `--jobs` runs in parallel with reproducible results. `docs/CLI.md`.
- **ui**: browser UI on `127.0.0.1`. Climate-coloured map (plants green dots, herbivores blue discs, carnivores red diamonds), wheel zoom / drag pan, Run/Pause, Step, Reset, 5 speed levels, save/load checkpoints, click an organism to inspect (traits, genome, parents), "New world..." form with presets and JSON import/export, five live charts (population, births/deaths, species, mean trait, trait distribution). `--smoke-test` and `--screenshots DIR` drive headless chromium. Details: `docs/UI.md`.

Example:
```
./evosim run --config examples/minimal.json --ticks 1000 --out result.json
./evosim batch --config scenarios/demo.json --seeds 1,2,3 --ticks 2000 --out-dir out --param plants.growth_rate=0.5,1.0
```

## Configuration
JSON. Only `seed`, `world.width/height` and `initial.plants/herbivores/carnivores` are required (`examples/minimal.json`, `examples/contract-example.json`); every other key has a default. Unknown keys, wrong types and out-of-range values are rejected (exit 2). 96 parameters in groups (full table with ranges, defaults and meaning: `docs/CONFIG.md`, generated from the code):

| group | what it controls |
|---|---|
| `seed`, `world`, `initial` | RNG seed, grid size (>=1x1, wraps left/right and top/bottom), founder counts (0 allowed) |
| `climate` | equator/pole temperature, precipitation, seasons and weather amplitude, resource regeneration, prey cover (`cover_fraction`, `cover_protection`) |
| `plants` | growth, upkeep, seeding/dispersal, cell capacity, climate stress, graze reserve |
| `herbivores`, `carnivores` | energy, metabolism, speed, vision, strength, health, lifespan, maturity, reproduction, handling time, satiation, climate comfort, attack cost, behaviour (aggression, risk tolerance), mutation rate |
| `genetics` | mutation size, founder variation, species threshold, reclassification interval |

Built-in presets (UI "New world" and `Config::preset`): default, lush, harsh, predator-rich, large.

## Test, build, verify
```
./test.sh                         # THE test command: cargo test (unit, integration, randomised invariants) + contract checks
EVOSIM_FUZZ_SEEDS=400 cargo test --release -p evosim-core --test invariants   # more random cases (default 40)
scripts/verify_contract.sh ./evosim --ui     # every CONTRACT item incl. ui smoke test and screenshots
./build.sh && scripts/verify_contract.sh dist/evosim   # distributable
scripts/reliability.sh 1,2,3 10000           # 10,000-tick reliability runs (several minutes)
```
`./build.sh` writes `dist/evosim`, one executable linked only against glibc/libgcc/libm (the web page is embedded), runnable on a plain Ubuntu 24.04 x86-64 system; `dist/` is git-ignored. Evidence: `docs/VERIFICATION.md`.

## Coexistence results
Measured with `./evosim batch --ticks 10000 --sample-every 10` (full tables, per-kind extinction ticks and speeds: `docs/VERIFICATION.md`; raw JSON in `experiments/delivery/results/`). "Coexistence" = ticks until the first of the three kinds died out (all three alive).

| configuration | seeds | all three alive until (ticks) | 10,000 reached |
|---|---|---|---|
| Example of CONTRACT section 3 (64x48, 400/120/20, all defaults) `examples/contract-example.json` | 1-5 | 2250, 1980, 1580, 2970, 2620 (median 2250, mean 2280) | 0/5 |
| Demo scenario `scenarios/demo.json` (96x64, 900/200/14, weaker carnivore metabolism) | 1, 2, 4, 5 | 2980, 1440, 4990, 1940 (median 2460, mean 2838) | 0/4 |

Plants survived all 10,000 ticks in every run. The carnivores died out first in 5 of 9 runs (they overshoot their prey and starve); in the other 4 the herbivores died first and the carnivores followed 60-230 ticks later. In 3 runs the herbivores survived to the end without carnivores. The goal of a 10,000-tick food chain is therefore **not met**; mechanisms and the trials are described in `docs/BALANCE.md` (prey refuge, ADR-0031) and `docs/VERIFICATION.md` (demo search). The seed-3 demo run was still running when this README was written (see VERIFICATION.md). No organism is ever created outside reproduction and nothing reads population counts.

## Topology compromise
A torus has no poles, but Earth-like zones need a cold-to-hot gradient. The world uses a **mirrored double hemisphere**: both the top and bottom rows are polar, the middle row is the equator, so the climate is continuous across the wrap seam in x and y (proved by a test with a negative control). Cost: one equator, one polar band, no oceans. See `docs/CLIMATE.md`.

## Performance
`cargo run --release -p evosim-core --example perf_bench`: about 300 ticks/s at ~1,800 organisms (target >= 100) on the 12-core build container. Long runs with large surviving animal populations are slower; see `docs/PERFORMANCE.md` and the ticks/s columns in `docs/VERIFICATION.md`.

## Known limitations
Self-audit of every requirement: `docs/AUDIT.md`. In short: the 10,000-tick coexistence goal is not reached (carnivores typically starve after overshooting their prey, plants almost always survive); plants reproduce asexually only (no pollination); config format is JSON only; no dedicated generation-trend chart; the inspector shows death cause `unknown` for most deaths (exact causes are in the metrics file); the headless screenshot has a blank strip at the bottom; speed numbers come from one machine; coexistence figures rest on 5 seeds per configuration.

## Layout
`crates/core` (simulation library), `crates/runner` (`run`, `batch`), `crates/ui` (server and web page), `crates/cli` (`evosim` binary), `scenarios/` (demo), `examples/`, `scripts/` (verification), `experiments/` (balance and delivery trials), `docs/` (contract, architecture, ADRs, evidence), `tasks/`.

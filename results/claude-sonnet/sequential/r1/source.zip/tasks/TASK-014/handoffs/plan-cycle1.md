# TASK-014 plan (cycle 1)

Read: AGENTS.md, STATE, ARCHITECTURE, ORGANISMS, MOVEMENT, PLANTS, GENOME, ADR-0017, movement.rs, config Animal group, TASK-013 handoffs. Design = docs/decisions/ADR-0018 (read it first).

## Ordered steps
1. config.rs Animal group: add `bite_size` (f64, 4.0, 0..1000, max plant energy taken per tick before the aggression factor), `temp_comfort` (18, -20..50), `temp_tolerance` (14, 0.1..60), `climate_cost` (0.5, 0..10). Regenerate docs/CONFIG.md (`cargo run -q --release -p evosim-core --example describe`), keep doc-sync test green; fix any test that counts keys. Validate nothing special.
2. movement.rs: make `apply_path` pub(crate); extract the wander branch into `pub fn wander(cfg, o, allowance, grid, spatial, rng)`; `run_animal_phase` still used for carnivores (behaviour identical).
3. New herbivore.rs (+ lib.rs mod): `FEED_REACH`, `DANGER_W`, `climate_mult(cfg, T)`, `upkeep_cost(cfg, o, T)`, `bite_amount`, `score_plant(...)`, `run_herbivore_phase`. Algorithm per ADR-0018 items 2-9. Plant data via `orgs.get(Plant,id)`; eaten: `get_mut(Plant,id).add_energy(-amount)`, `mark_dead(id, Predation, tick)` when energy <= 0 (tick passed in). Herbivore gain via `add_energy(amount*digestion)` (returned actual gain recorded).
4. sim.rs: Herbivores phase calls it (needs `self.tick`, `&self.world`), stores `last_herbivore_stats`; no stub RNG draw for it.
5. Fix existing tests (tests/movement.rs cfg helper: herbivores.base_metabolism=0, bite_size=1e-6; check tests/sim.rs, organisms.rs, weather.rs, plants.rs, plant_repro.rs still green; herbivores now die/eat in long runs).
6. tests/herbivore.rs (below). 7. docs: new docs/HERBIVORES.md, update MOVEMENT.md ("Idle metabolism is NOT charged" -> herbivores charged), PLANTS.md ("Not yet" line), ORGANISMS.md if needed, ARCHITECTURE.md, STATE.md, ADR README untouched.
8. `./test.sh`, optional `tick_bench`/short 2000-tick run for a sanity table (herbivore count over time) recorded in HERBIVORES.md; do not tune long-term balance.

## Tests (crates/core/tests/herbivore.rs; helpers like movement.rs: flat climate, manual placement, `rebuild_index`, maintenance/growth 0 for plants)
- reach_own_and_adjacent_only: plants at dist 0, 1 (incl. across the wrap seam) are eaten when speed allowance is 0 (speed 0.1, first tick); a plant at dist 2 untouched in that tick, gets eaten only after approaching.
- bite_limit_and_conservation: plant 50, bite fixed -> plant loses exactly bite*(0.5+aggr); animal gain == loss*digestion <= loss; also over a 300-tick run total gain <= total loss (stats).
- plant_dies_when_eaten: plant energy < bite -> dead, cause Predation, gain <= its energy; other animal in same tick cannot eat it.
- no_overfeeding: room limit; satiated animal doesn't eat (plant unchanged) and wanders.
- upkeep_every_tick_and_starvation: no plants, energy E, cost c -> dies exactly at expected tick with cause Starvation; energy decreases each tick even when not moving.
- climate_cost: identical animals at 18 C vs -30 C vs +45 C; extra cost ordering, mult formula exact, capped at 1+4*climate_cost; seasons: change in temp changes cost.
- genes_change_decisions: (a) risk_tolerance 0.0 vs 1.0 with a carnivore next to the near plant and a safe farther plant -> different chosen target/position; (b) aggression 0 vs 1 with a competitor in the cell (and bite size differs); (c) vision gene 1 vs 6 -> one sees the plant and walks, other wanders (genomes built via Genome::from_alleles on Aggression/RiskTolerance/Vision loci so the difference comes from genes, traits derived by the constructor).
- index_and_determinism: 300-tick populated run twice -> equal digest; `check_index` Ok every tick; no negative or NaN energy; counts == founded+births-deaths.
- carnivores_unchanged: carnivore phase still behaves as in movement tests.

## Risks
- Existing tests (movement.rs) depend on herbivores not eating/paying: adapt helpers (bite 1e-6, base_metabolism 0); verify nothing else fails.
- Balance: default herbivores may starve fast (base_metabolism 0.4, bite 4*0.8=3.2*0.6 digestion ~1.9/tick vs plants regrowth 0.8); long-run coexistence is measured in TASK-018/027, only a sanity run here.
- New Animal keys affect carnivore config docs and preset tables; CONFIG.md must be regenerated.
- Per-tick cost: scoring loops over perceived plants (vision 4 -> up to 81 cells x capacity); acceptable, check tick_bench does not regress >2x.

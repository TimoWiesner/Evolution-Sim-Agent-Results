# TASK-013 plan (cycle 1) — see docs/decisions/ADR-0017-animal-sensing-and-movement.md

## Ordered steps
1. `organism.rs`: add `Organism.move_credit: f64`, `Organism.heading: u8` (init 0, in `state_words`); add `pub fn cell_limit(cfg:&Config, kind:Kind)->Option<u32>`. `plants.rs` (line ~169 `counts[ti] >= cell_capacity`) uses `cell_limit`.
2. New `crates/core/src/movement.rs` (+ `pub mod movement` in lib.rs): `vision_cells(&Organism)`, `perceive(spatial, orgs, id) -> Vec<Hit>` (self & inactive filtered), `step_allowance(&mut Organism)`, `plan_path`, `move_cost(cfg,o,n)`, `can_enter`, `run_animal_phase(kind, world, orgs, spatial, cfg, rng)`.
3. `sim.rs`: field `spatial: SpatialIndex`; init via rebuild; Herbivores/Carnivores phases call `run_animal_phase` (drop stub draw for them); Deaths removes, Births inserts; Index phase `debug_assert!(check_index())`; `check_index`, `rebuild_index` helpers. Update tests/sim.rs, weather.rs, organisms.rs (lines 79/179/268) to call `rebuild_index` after replacing `organisms`; adapt stub-trace assertions.
4. Tests `crates/core/tests/movement.rs` (names suggested):
   - perceive_matches_bruteforce (random worlds incl. 1xN, radii; independent toroidal brute force; includes across x and y seams and corners)
   - perceive_across_edge_exact (animal at x=0, plant at x=W-1 seen with vision 1; not seen when vision too small); dead/self excluded
   - vision_follows_trait (higher vision gene sees farther)
   - speed_limits_distance (speed 0.5/1/1.5/3: per-tick steps <= ceil(speed), total over 100 ticks <= speed*100, credit in [0,1))
   - moves_are_cell_to_cell (every step adjacent incl. across edges)
   - cost_scales (energy lost = formula; more steps > cost; n steps cost > n*one-step cost; longer distance costs more; cannot go below 0/unaffordable stays)
   - shortest_way_across_edge (target at distance 2 across seam reached in 2 steps via wrap, not W-2; also y seam and corner diagonal; tie N/2 deterministic)
   - no_overshoot_stops_on_target
   - wander_when_alone (heading persistence statistics, 1 step/tick, deterministic by seed, crosses edges, energy decreases)
   - cell_sharing_rule (many animals + plant share a cell; plants capped by cell_capacity; seeding uses same `cell_limit`; movement never blocked)
   - index_in_sync (run 300 ticks with plants, animals, births, deaths: `check_index` OK every tick; negative control: manual desync detected)
   - determinism (same seed => same digest; checkpoint-free)
5. Docs: new `docs/MOVEMENT.md` (rules, formulas, cell-sharing rule), update docs/SPATIAL.md note ("now wired"), ARCHITECTURE.md, STATE.md, ORGANISMS.md (new fields).
6. Run `./test.sh`; record command/result in implement handoff.

## Risks
- Digest/golden changes across existing tests; fix tests, not semantics.
- Index lag for marked-dead organisms: filter by `is_active`.
- Without TASK-014, herbivores park on plants and are never fed; energy only drains through moves (stationary animals cost nothing). Idle metabolism is deferred to TASK-014.
- Performance: vision up to 64 → (129)^2 cells query; baseline vision 4–6 fine. Run a quick 2,000-organism tick-rate check.

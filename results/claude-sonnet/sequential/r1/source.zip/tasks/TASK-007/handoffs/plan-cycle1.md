# TASK-007 plan (cycle 1) — see docs/decisions/ADR-0011-seasons-and-weather.md for formulas

## Steps
1. config.rs: add `seasonal_precip_amplitude: f64 = 0.3, 0.0, 0.95` to group Climate (after `seasonal_amplitude`); optionally set in `harsh` preset (0.6) and `lush` (0.2). Regenerate docs/CONFIG.md (`cargo run -q --release -p evosim-core --example describe`); fix any test counting keys/params.
2. climate.rs: refactor Noise lattice dims + interpolation into reusable helpers (keep ClimateMap::generate output bit-identical: tests/climate.rs must still pass). Add constants (WEATHER_CELL=8, WEATHER_CLAMP=2, WEATHER_TEMP_SCALE=6, PRECIP_LAG=0.125), `ClimateMap.warmth_row: Vec<f64>`, `Weather {tick,nx,ny,t:Vec<f64>,p:Vec<f64>}` with `new(cfg)`, `advance(tick,&cfg.climate,&mut Rng)`, `state_words/from_state_words`, `ClimateBounds`, seasonal fns and `temp_at/precip_at`.
3. world.rs: `World.weather`, `temp_at`, `precip_at`, `climate_tick`, `bounds`.
4. sim.rs: Phase::Climate runs `world.advance_weather(tick,&config,&mut rng)` instead of the stub draw (other phases keep stubs); `digest` feeds weather words. Update sim tests expecting old trace.
5. Docs: CLIMATE.md "Seasons and weather" section (formulas, bounds table, how to query), STATE.md, ARCHITECTURE.md; example `climate_series` (optional): prints temp/precip of a cell over a year.
## Tests (crates/core/tests/weather.rs)
- weather_off_year_repeats_exactly: weather_noise=0, L in {2,7,50,200}; every cell, t in 0..L: temp/precip(t) == (t+L) == (t+3L) (assert_eq on f64 via Sim stepping AND pure seasonal fn).
- weather_on_year_differs; same_seed_same_weather (digest + sampled series); different_seed_differs.
- bounds_hold: extreme config (amp 40, weather 1, precip amps max, terrain_noise 1, several sizes incl 1x1, 1xN) 3000 ticks x all cells within ClimateBounds and pre-clamp value inside too; precip >= 0.
- seasonal_cycle: warmest at mid-year, coldest tick 0; pole swing > equator swing; yearly mean = base (1e-9); amplitude 0 => constant; wet/dry swing larger in tropics than poles.
- seam_smooth: weather temp diff across x and y seams <= interior max diff scale (like climate.rs seam test).
- state_carries_over: clone sim at tick k, step both -> equal digest; digest differs when a weather node is perturbed; state_words roundtrip makes continued run identical.
- query_any_tick: pure fns at huge t (u64 near 2^40) finite, in bounds.
- weather_off_does_not_shift_rng: rng state after N ticks identical for weather_noise 0 and 0.5.
- unit tests: AR(1) stationary variance ~1 (loose), clamp respected.
Commands: `./test.sh`; plus a multi-thousand-tick run in tests.
## Risks
RNG consumption change breaks existing sim tests/golden values; float equality for year-repeat requires integer modulo before trig (done); cos/sin cross-platform; per-tick cost on huge worlds (nodes = area/64, 8 draws each); config key count tests.

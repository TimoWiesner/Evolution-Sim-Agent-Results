# TASK-015 plan (cycle 1) - see docs/decisions/ADR-0019-carnivore-hunting.md

## Ordered steps
1. config.rs: add Animal key `attack_cost` (base 0.5; carnivore default 1.5); regenerate docs/CONFIG.md; update any test asserting key counts.
2. organism.rs: add `pub rest: u32` (init 0), include in digest (next to heading). Fix literals/constructors.
3. herbivore.rs: make `climate_mult`/`upkeep_cost` take `&Animal` (update callers in herbivore.rs and tests/herbivore.rs).
4. New crates/core/src/carnivore.rs (+ `pub mod carnivore` in lib.rs): constants, `attack_probability`, `CarnivoreStats`, `run_carnivore_phase` per ADR-0019 item 3-8.
5. sim.rs: Carnivores phase calls it, store `last_carnivore_stats`; remove carnivore arm of movement `target_kind` if unused.
6. Existing tests: tests/movement.rs carnivore tests set `carnivores.base_metabolism=0`, `attack_cost=0`, `handling_time=0` as needed (they relied on no upkeep/attack); other tests with carnivores (sim.rs/organisms.rs) check for starvation changes; fix.
7. New tests/carnivore.rs (helper pattern from tests/herbivore.rs):
   - attack_only_from_same_or_adjacent_cell (prey at dist 2 not attacked in that tick, attacker walks; adjacent across a wrap seam is attacked; dist 0 attacked)
   - pursues_prey_within_vision_not_beyond (vision gene; beyond -> wander)
   - attack_probability monotone: more carnivore strength/speed/aggression up, more prey strength/speed/health down; clamped in [P_MIN,P_MAX]
   - many_attacks_kills_and_escapes: >=2000 independent trials (fresh sims or repeated with refilled prey), both outcomes occur; empirical kill rate within 4 sigma of formula; two seeds differ
   - kill_exactly_once: Predation cause, `deaths_by_cause` +1, prey not active, not perceivable, two carnivores same prey same tick => one kill, one gain, event Died once after full step
   - energy_gain_le_prey_energy: sweep prey energies, digestion 1.0 and low room; gain <= prey energy; stats invariant gained <= prey_energy_taken
   - hunt_costs_energy_success_and_failure: attack_cost paid on both (force p via traits at P_MIN / P_MAX with many seeds, or compare energy deltas)
   - carnivore_without_prey_starves: no herbivores, upkeep drains, Starvation death at known tick; idle energy strictly decreasing
   - handling_time_rest: after kill no attack for `handling_time` ticks
   - determinism: same seed same digest; digest changes when `rest` differs
   - multi-carnivore: later carnivore retargets after first kill
8. docs: new docs/CARNIVORES.md (formula, order, costs, multi-carnivore rule, stats), update docs/STATE.md, ARCHITECTURE.md, MOVEMENT.md/HERBIVORES.md notes (carnivore upkeep now charged), set ADR-0019 to Accepted.
9. Run `./test.sh`; record exact result. Optional sanity example `carn_sanity` (64x64, herbs+carns 1000 ticks) for docs; balance NOT required.

## Risks
Tests with forced probability need trait overrides (traits are pub mut on Organism as in herbivore tests). Digest-affecting `rest` field; time limit 30 min per phase so keep tests small (statistical test uses a small world and many ticks, not many sims). Default balance will be untuned.

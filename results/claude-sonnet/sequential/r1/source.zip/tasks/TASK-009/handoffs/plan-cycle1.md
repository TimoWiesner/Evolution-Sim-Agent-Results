# TASK-009 plan, cycle 1
Design: docs/decisions/ADR-0013-genome-implementation.md (read first). Read: ADR-0004/0005/0012, organism.rs, config.rs (existing keys `*.mutation_rate`, `genetics.mutation_sigma`, `genetics.crossover_rate`), rng.rs.

## Steps
1. `crates/core/src/genome.rs` (+ `pub mod genome;` in lib.rs): `Gene` enum + N_GENES, `Genome`, `Mutation`, `scale_factor`/inverse, `traits`, `from_traits`, `founder`, `child_of_one`, `child_of_two`, `mutate`, `distance`, `trait_distance`, `state_words`.
2. config.rs: add `genetics.founder_variation` (f64, default 0.05, 0..0.5); regenerate docs/CONFIG.md (`cargo run -q --release -p evosim-core --example describe > docs/CONFIG.md`, check how the sync test expects it); keep presets valid.
3. organism.rs: `Organism.genome` (private + getter), constructor takes genome + baseline and derives traits; `NewBorn.genome` replaces `traits`; `Organisms.baselines`; `populate` uses `Rng::stream(seed, STREAM_GENOMES=3)` for founder genomes (placement stream unchanged); `state_words` adds allele bits. Update existing tests/organisms.rs and unit tests that build NewBorn/Organism::new.
4. docs: docs/GENOME.md (genes, mapping, operators, distance), update ORGANISMS.md, ARCHITECTURE.md, STATE.md.
5. Tests `crates/core/tests/genome.rs` + unit tests.

## Tests (map to acceptance)
- every organism has genome; traits == genome.traits(...) and in `Traits::range(kind)` for all founders of all presets, and for 10k random genomes (alleles uniform in [0,1], extremes 0/1, NaN) for each kind; mapping deterministic (same call twice, bitwise); from_traits round-trip close (|g diff|<1e-6 within unclamped range); founder with variation 0 equals baseline traits.
- copy: child_of_one with rate 0 == parent exactly. crossover: rate 0 mutation, 2000 children: every child allele at every locus equals one of the parent's alleles at that locus, slot0 from `a`, slot1 from `b`; crossover_rate 0 -> each gamete is a whole strand (all slot 0 or all slot 1 of the parent); 0.5 -> both strands observed with switches; with homozygous distinct parents all genes still parental.
- mutation: rate 0 -> zero draws from RNG (rng state unchanged) and `mutate` returns 0; rate 0.05 over 2000 offspring -> some children differ from parents, mean number of changed alleles ~ rate*20 (loose bound); rate 1 -> all alleles change (sigma>0); sigma 0 -> no change even at rate 1; alleles stay in [0,1] with sigma 1; step std approx sigma (loose bound); uses the supplied Rng (same seed -> same child; different seed -> differs; RNG state advances).
- distance: d(g,g)=0; symmetric on 1000 random pairs; allele swap within a locus gives 0; triangle inequality on random triples; monotone: moving one gene farther increases it; bigger mutated copy (sigma larger) is farther on average; range [0,1]; max =1 for all-0 vs all-1; trait_distance likewise.
- integration: Simulation digest changes if a genome allele changes; same seed same digest; newborn via `queue_birth` gets traits from its genome and parents recorded; `./test.sh` still passes (existing sim/weather/organism tests updated).
Commands: `cargo test --release -p evosim-core --locked genome` then `./test.sh`.

## Risks
- Touching `Organism::new`/`NewBorn` signatures breaks existing tests (update them). - CONFIG.md sync test: must regenerate. - f32 arithmetic: use only basic ops. - Baseline-relative mapping means `Traits::baseline` must be stored with Organisms (not state). - Clamping at ranges hides gene differences at extremes (acceptable, documented).

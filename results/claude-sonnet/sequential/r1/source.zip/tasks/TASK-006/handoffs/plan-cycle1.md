# TASK-006 plan, cycle 1

Design: docs/decisions/ADR-0010-climate-zones.md (read first).

## Ordered steps
1. `crates/core/src/climate.rs` (+ `pub mod climate;` in lib.rs): `enum Biome {Polar,Tundra,TemperateForest,TemperateGrassland,Savanna,Desert,TropicalRainforest}` with `name()`, `letter()`, `zone()` (0 polar,1 tundra,2 temperate,3 dry,4 tropical; Savanna/Desert -> 3 only when in the dry band; define `zone` from the latitude band, not from the subtype); `struct ClimateMap{width,height,temp:Vec<f64>,precip:Vec<f64>,elevation:Vec<f64>,biome:Vec<Biome>}` row-major (Grid::index); `ClimateMap::generate(&Config)`, accessors `at(Pos)`, `warmth(y,h)` helper, `to_ascii()`, `to_json()`. Wrapping value-noise helper with lattice dims max(1,round(n/8)).
2. `World` gets `pub climate: ClimateMap` built in `World::new` (noise stream id constant `STREAM_CLIMATE`, via `Rng::stream`; do NOT consume the main sim RNG so TASK-005 trace tests stay valid).
3. `crates/core/examples/biome_map.rs` (W H SEED [--json]; builds Config with defaults).
4. `docs/CLIMATE.md`: formulas, zone table, thresholds, torus compromise (mirrored double hemisphere, polar band at seam, one equator), how to print the map, small-world behaviour. Update STATE.md, ARCHITECTURE.md rows.
5. Tests `crates/core/tests/climate.rs`:
   - every cell has finite T, P>=0, biome; T within [pole-6, equator+6]; function of (config,seed): same seed identical, different seed differs when terrain_noise>0.
   - zone order: with terrain_noise=0 walking from y=0 to the middle gives non-decreasing zone, covering all 5 zones for H=48 (default) and H=200; mirror symmetry rows y and H-1-y; with default noise, per-row mean temperature increases monotonically from seam to equator and row-mode zone is non-decreasing in strict-order tolerance.
   - seam: for several sizes/seeds (64x48, 100x37, 17x9, 200x120) max |dT| and |dP| between vertically adjacent cells across y-seam (row H-1 vs 0) and horizontally across x-seam (col W-1 vs 0) <= max over the interior neighbour pairs of the same axis (and mean seam diff <= 1.5 * mean interior diff). Also test a deliberately seamed reference (linear gradient) fails the check, proving the test has teeth.
   - small worlds: 1x1, 1xN, Nx1, 2x2, 3x5, 4096x1 (cheap: 4096x1 only) generate without panic and all values finite; 1xN/Nx1 documented.
   - ASCII export: line count == H, line length == W, golden-ish: row 0 contains only polar/tundra letters at default; JSON parses with `core::json` and has W*H entries.
   - ADR/doc check: docs/CLIMATE.md exists and mentions "seam" (cheap test reading file via include_str!).
   - Existing `tests/sim.rs`, config docs-sync tests must still pass (no new config keys).
6. Run `./test.sh`; record command + exit code in implement handoff.

## Risks
Thresholds may leave a zone absent at tiny heights (e.g. H<=5): acceptance only needs ordering monotone, not all five zones, for tiny worlds — test only the full-5-zone claim for H>=24. Noise can add jitter at zone boundaries: keep terrain_noise perturbation small relative to threshold gaps and test order on noise-free + row-average. Avoid platform libm differences by only using f64 sin/cos; golden hashes on climate should be avoided in tests. Do not change CONFIG keys (docs-sync test) and do not touch the main RNG stream.

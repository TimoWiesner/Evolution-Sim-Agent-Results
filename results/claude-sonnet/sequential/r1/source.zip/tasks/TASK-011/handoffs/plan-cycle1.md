# TASK-011 plan (cycle 1) — see docs/decisions/ADR-0015-plant-growth-and-resources.md

Files (implement):
1. `crates/core/src/plants.rs` (new; `pub mod plants;` in lib.rs): `PlantTraits{temp_opt,temp_tol,water_need,breadth,drought_cost,size_scale}` + `from_genome`; pure `temp_factor`, `water_factor`; `run_plants_phase(&mut World, &mut Organisms, &Config, tick)` doing: regen -> per-cell counts -> per-plant growth/upkeep/stress in ascending id; returns a `PlantPhaseStats{gain,upkeep,regen,stock_removed}` stored on Simulation (`last_plant_stats`, not in digest).
2. `world.rs`: `resources`, `resource_cap` (init in `World::new`), `regen_resources(cfg)`, accessors, `state_words` (included in `Simulation::digest`). Clone derive must still work (tests copy worlds).
3. `organism.rs`: `DeathCause::Climate` appended (N_CAUSES=6, name "climate"); fix arrays/tests that assume 5. `config.rs`: keys `plants.maintenance`, `plants.stress_damage`; regenerate docs/CONFIG.md (`cargo run -q --release -p evosim-core --example describe`); presets unaffected (harsh may raise stress_damage).
4. `sim.rs`: in `run_phase` for `Phase::Plants` call plants phase before the placeholder RNG draw (leave the draw).
5. Docs: `docs/PLANTS.md` (where plant energy comes from, what limits it, formulas, traits, death causes, tuning numbers), update GENOME.md (reuse of loci for plants), ORGANISMS.md (Climate cause), ARCHITECTURE.md, STATE.md.
6. Tests `crates/core/tests/plants.rs` (default test set, small worlds, plain `Simulation::new` + manual organism setup via populate with initial.plants=0 then `queue_birth`/`resolve_births`, or cfg with 1 plant):
   - cold/dry/favourable: same genome plant in cell with T far from opt (fT=0) -> zero gain; dry (P<<need) -> less gain than favourable; strict ordering gain(fav) > gain(dry) and > gain(cold); use `plants::temp_factor/water_factor` + real sim runs on a world forced via config (equator/pole temps, precip_mean) and direct gain measurement over N ticks.
   - competition: 1 vs 10 plants in one cell with regen limited -> total gain <= cumulative regen + initial stock; per-plant mean gain lower.
   - boundedness: 3000-tick run, stock in [0,cap], energy in [0,max_energy], plant count never grows (no reproduction), total plant energy <= sum.
   - conservation: each tick `sum(plant energy change) + upkeep paid (clamped part) == stock removed` (use stats from phase; verify stock delta == regen - removed independently).
   - no free energy: resource_regen=0 and initial stock drained -> plants gain 0 and starve/die (cause starvation).
   - deaths: old age (max_age small), starvation (maintenance>0, no resource), climate (hostile cell: T beyond tolerance -> cause Climate within bounded ticks).
   - genome influence: two plants differing only in locus Aggression (thermal) grow differently at T above/below; tolerance gene widens range; drought gene.
   - determinism: same seed twice -> same digest after 300 ticks; different seeds differ; digest changes with resources.
   - seam: growth identical for cells at x=0 and x=W-1 given same climate? (climate continuity already tested) -> skip.
   Run `./test.sh` (exit 0 expected); report exact commands.
Risks: existing tests copying `Simulation` fields or asserting digests/N_CAUSES/key counts (CONFIG.md sync test) need updates; tuning so default preset plants persist for ~thousands of ticks without reproduction is not required (TASK-012); keep draws unchanged to avoid shifting streams; f64 only `sqrt`/arith (no transcendental) for determinism.

# TASK-016 plan (cycle 1) - ADR-0020 (docs/decisions/ADR-0020-animal-reproduction.md)

## Ordered steps
1. organism.rs: add `pub cooldown: u32` to `Organism` (init 0), digest it next to `rest`; fix all literals/constructors.
2. New `crates/core/src/reproduction.rs` (+ `pub mod reproduction` in lib.rs): consts `REPRO_PARENT_SHARE=0.6`; `ReproductionStats`; pure helpers `is_eligible(o, cfg_group) -> bool`, `conception_chance(a,b)`, `compatible(a,b,cfg)`; `run_reproduction_phase` per ADR-0020 items 2-9. Verify `SpatialIndex::query` signature/kind filter before coding (spatial.rs).
3. sim.rs: in the Births phase call it before `resolve_births`; store `last_reproduction_stats`; do NOT consume the stub RNG draw differently (the Births arm already skips it? check: phases that `return` early skip the stub draw; Births currently falls through to the stub draw - keep that behaviour unchanged to limit digest churn, or return early consistently and update golden tests).
4. Fix existing tests that now see births: tests/organisms.rs, sim.rs, herbivore.rs, carnivore.rs, movement.rs, plant tests with animals (disable via `reproduction_energy = max_energy` and low initial_energy, or `maturity_age = max_age`).
5. New tests/reproduction.rs (helper pattern from tests/carnivore.rs, place organisms via `Organisms` + `rebuild_index`):
   - single_animal_never_reproduces (both kinds, energy full, mature, 1500 ticks, births 0, stats matings 0)
   - never_self_mates (two animals at same cell where one is immature: no birth; ids of parents always differ across a many-animal run)
   - needs_same_kind (herbivore + carnivore adjacent, both ready: 0 births)
   - needs_closeness (dist = mate_range+1 no birth; = mate_range birth; across wrap seam birth; mate_range 0 same cell only)
   - needs_maturity, needs_energy (each of the two parents separately)
   - incompatible_genomes (distance > species_threshold: none; just below: births)
   - offspring_genome_is_crossover (mutation 0: every child allele at locus i slot0 in A.alleles[i], slot1 in B.alleles[i]; with mutation_rate 1 sigma>0 child differs; both mutation and crossover observed over many births)
   - records_parents_and_generation (parents [A,B] distinct, generation max+1, birth tick, event Born)
   - costs_both_parents (both energies drop by 0.6*n*offspring_energy; newborn energy total <= paid; no energy created; parents stay > 0)
   - cooldown_blocks_then_allows (exactly C ticks blocked, eligible at C+1; cooldown 0 allowed each tick)
   - fertility_affects_births (fertility 0 -> no births in N trials; fertility 1 > fertility 0.3 count; litter_size 4 with fertility 1 -> litter 4, with 0.5 smaller mean; statistical, 4 sigma)
   - litter_capped_by_energy (poor parents get smaller litter or none, never negative energy)
   - chooses_nearest_then_most_similar mate; each animal mates at most once per tick (three animals in range -> one pair, one births)
   - determinism: same seed same digest incl. cooldown; digest differs when cooldown differs
   - integration: seeded 64x64 default config 600 ticks, herbivores births > 0 and every animal's parents refer to same-kind ids; counts invariant founded+births-deaths
6. Docs: docs/REPRODUCTION.md (rules, formulas, stats), docs/STATE.md, ARCHITECTURE.md section, ORGANISMS.md (cooldown), ADR-0020 -> Accepted. No new config keys (docs/CONFIG.md unchanged; note that the keys are now used; update descriptions only if the doc-sync test allows - description strings live in config.rs and CONFIG.md is generated).
7. Run `./test.sh`; record exact command and result.

## Risks
- Digest/golden churn from the new field and births in existing tests (step 4).
- Mate density: without mate-seeking, sparse populations may not meet; balance is TASK-018/027. Optional sanity example may print births in 1000 ticks.
- Statistical tests: keep them small (4-sigma bounds, single world with many animals) for the 30-minute phase limit.
- Compatibility via species_threshold: if TASK-017 changes species semantics, revisit.

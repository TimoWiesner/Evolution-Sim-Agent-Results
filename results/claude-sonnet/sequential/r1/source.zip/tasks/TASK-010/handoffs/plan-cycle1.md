# TASK-010 plan (cycle 1) — see docs/decisions/ADR-0014-spatial-index.md

Files: crates/core/src/spatial.rs (new), lib.rs (`pub mod spatial;`), crates/core/tests/spatial.rs (new), crates/core/examples/spatial_bench.rs (new, release timing), docs/SPATIAL.md (new; interface, order, benchmark numbers), docs/ARCHITECTURE.md + STATE.md updates. No sim.rs changes; no new deps/config keys.

Steps
1. Implement spatial.rs per ADR (Hit, SpatialError, SpatialIndex{grid, cells:[Vec<Vec<Id>>;3], loc, }), `rebuild(&Organisms)`.
   Query: collect via for_each_cell_within (dedup guaranteed), look up pos via loc for Hit (or store (id,) and fetch pos from the cell index: pos = grid.pos_of(cell)), sort_unstable by (dist,kind,id).
2. Tests (tests/spatial.rs), independent brute force using own toroidal distance (min(|d|,N-|d|) Chebyshev) over a model list:
   - randomized differential test >= 1,000 queries (aim 3,000) on grids incl. 1x1, 1xN, Nx1, 2x2, 3x5, 7x7, 40x30; radii 0..2*max(W,H)+3 incl. > world; kind None/each kind; exact Vec equality incl. order; assert no duplicate ids; assert counted queries >= 1000.
   - randomised mutation sequence (insert/move/remove interleaved with queries; moves across seams) vs model; old position never returns the moved/removed id (explicit test).
   - seam tests (x=0 vs W-1, y), error cases (dup insert, unknown id, out of grid), order test (dist, kind, id), determinism (two indexes built in different insertion orders give identical results), rebuild(&Organisms) from Simulation populated organisms matches brute force, nearest/count consistent.
3. Benchmark example: ~2,000 organisms (e.g. 128x128 grid, mix of 3 kinds, radius 3,5,8), N queries each, index vs brute force, print ms and speedup; run `cargo run --release -p evosim-core --example spatial_bench`; record numbers in docs/SPATIAL.md. Also a test asserting only correctness (no timing assertions, to avoid flakiness).
4. Docs: SPATIAL.md, ARCHITECTURE.md section, STATE.md, ADR status.
5. Run `./test.sh`.

Risks: perf for radius >= world (fast path); sorting cost for large results (acceptable); HashMap use must not be iterated (rebuild iterates Organisms vecs, ordered). Gaps: none known.

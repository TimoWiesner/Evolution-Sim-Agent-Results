# TASK-002: Project bootstrap and quality gates

## Depends on
TASK-001

## Goal
Create a runnable, still empty project skeleton with the three entry points and one command that runs all tests.

## Must have
The review passes only if every point is met and shown by a test or a recorded command.

- `./setup.sh`, `./evosim` and `./build.sh` exist as defined in `docs/CONTRACT.md` section 1
- `./evosim version` prints the contract JSON after `./setup.sh` in a fresh container
- `./build.sh` produces `dist/evosim` and `dist/evosim version` works
- `./evosim --help` lists the available commands; an unknown command gives exit status 2.
- One documented command runs the whole test suite; at least one test exists and passes.
- `README.md` explains how to install, build and test. `dist/` and other build output are ignored by Git.

## Your decisions
Decide these yourself and write down what you chose and why.

- Project layout, build tool, test framework.
- How `dist/` is made self-contained.

## Not part of this task
- Simulation behaviour.
- The `run`, `batch` and `ui` commands.

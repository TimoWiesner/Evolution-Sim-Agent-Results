# TASK-002 plan (cycle 1): project bootstrap and quality gates

No code exists yet; Cargo, Rust 1.100 present; no ~/.cargo registry (no deps fetched yet).

## Decisions
- Layout (ADR-0001/ARCHITECTURE): Cargo workspace at /workspace/Cargo.toml (resolver 2, members `crates/core`, `crates/cli`; runner/ui crates are added by their tasks, not now). Package names `evosim-core` (lib, one `version_info()` fn + `NAME`, `VERSION`, `CONTRACT_VERSION`) and `evosim-cli` (bin `evosim`).
- Zero third-party crates in this task: hand-written arg parsing and hand-written JSON for version output -> works offline, no Cargo.lock fetch, fast. Cargo.lock still committed (empty of deps). Later tasks add serde with `--locked`.
- Profile release: lto="fat", codegen-units=1, opt-level=3.
- Test framework: built-in `cargo test` (unit tests in core, integration tests in `crates/cli/tests/cli.rs` running the compiled binary via `env!("CARGO_BIN_EXE_evosim")`). proptest deferred (ADR-0005 fallback).
- The single test command: `./test.sh` (= `cargo test --release --workspace --locked`; also shell checks of the three entry points via `scripts/contract_check.sh`). Document in README as `./test.sh`.
- dist self-containment: `build.sh` runs `cargo build --release --locked`, copies `target/release/evosim` to `dist/evosim`. Binary is dynamically linked to glibc only (Ubuntu 24.04 target OK); verify with `ldd` (only libc/libm/libgcc_s allowed). UI assets will later be embedded with include_str!/include_bytes!, so dist stays a single file. No musl target (needs network/rustup target); noted as fallback.
- `setup.sh`: `set -euo pipefail`, cd to script dir, check cargo exists (else install rustup via curl if network, documented), `cargo build --release --locked`, optionally warn (not fail) if chromium missing. Idempotent. No apt needed.
- `./evosim` launcher: sh script resolving its own dir via `readlink -f "$0"`; if `target/release/evosim` missing or any source newer (use `find -newer`), runs `cargo build --release --locked --quiet` (to stderr); then `exec`s binary with "$@". Must not print anything to stdout from build. Works from any cwd.
- CLI behaviour: `version` -> stdout exactly `{"name":"evosim","version":"0.1.0","contract":1}\n`; `--help`/`-h`/`help`/no args -> usage listing commands version, run, batch, ui (stdout, exit 0 for explicit help; no-args -> usage on stderr exit 2); unknown command or bad extra args to `version` -> message on stderr, exit 2. `run`/`batch`/`ui` stubs: stderr "not implemented yet", exit 2 (out of scope for this task; later tasks replace). `--version` not required.
- .gitignore already ignores target/, dist/, build/; add `*.o`, `.cargo-home` no. Verify with `git check-ignore target dist`.

## Ordered steps
1. Root `Cargo.toml` (workspace + release profile), `rust-toolchain` not pinned (container has stable).
2. `crates/core/{Cargo.toml,src/lib.rs}` with version consts + `version_json()` and 2 unit tests (JSON exact string, contract==1).
3. `crates/cli/{Cargo.toml,src/main.rs}`: `fn run(args)->i32`, `main` calls `std::process::exit`. Output errors to stderr.
4. `crates/cli/tests/cli.rs`: tests: version JSON parses (check keys by string compare), help lists all four commands exit 0, unknown command exit 2 + empty stdout, no-args exit 2, `version extra` exit 2, stubs exit 2, run from another cwd.
5. `setup.sh`, `evosim`, `build.sh` (chmod +x), `test.sh`, `scripts/contract_check.sh` (runs ./evosim and dist/evosim version via python3 -c json check, help, unknown cmd exit 2; takes binary path arg).
6. README.md: overview, requirements, install (`./setup.sh`), run (`./evosim --help`, `version`), build (`./build.sh` -> dist/), test (`./test.sh`), layout, git hygiene, dependency note; mention commands run/batch/ui arrive in later tasks.
7. Update docs/STATE.md (commands, status, dependencies: none via apt), ARCHITECTURE.md status (skeleton exists: core, cli crates), and add `docs/decisions/ADR-0006-bootstrap-and-dist.md` for the build/dist/test choices.
8. Verify, record exact commands + results: `./setup.sh` (twice for idempotence), `./evosim version`, `./evosim --help; echo $?`, `./evosim bogus; echo $?` (2), `./build.sh && dist/evosim version`, copy dist/evosim to a temp dir and run with `env -i`, `ldd dist/evosim`, `./test.sh`, `git status --ignored` shows dist/target ignored, run `./evosim version` from `/tmp`.
9. Optionally simulate fresh container: `rm -rf target dist && ./setup.sh && ./evosim version`.

## Risks
- Launcher staleness check and printing build output to stdout would break `version` stdout cleanliness: route cargo output to stderr.
- Concurrent `./evosim` invocations triggering parallel builds: only rebuild when binary missing/stale; setup.sh is the normal build path.
- glibc dependency of dist: fine for Ubuntu 24.04 target.
- Fresh container needs cargo on PATH (/root/.cargo/bin may not be in non-login shells): scripts should `export PATH="$HOME/.cargo/bin:$PATH"`.
- Hand-written JSON: keep to constant strings; no escaping needed.

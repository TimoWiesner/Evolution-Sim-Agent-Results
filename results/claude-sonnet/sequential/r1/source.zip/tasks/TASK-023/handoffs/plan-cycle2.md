# TASK-023 plan, cycle 2 (replan after REVIEW FAIL)

Design unchanged (ADR-0027). Implementation is correct; only a stale test blocks.

## Close G1 (blocking)
`crates/cli/tests/cli.rs::stubs_and_bare_run_exit_2` (line ~42) loops over ["run","batch","ui"] calling `evosim <c>` with no args. `ui` is now a real server and never exits.
Fix:
1. Rename test to `bare_run_and_batch_exit_2`; loop over ["run","batch"] only.
2. Add test `ui_bad_args_exit_2`: `evosim ui --bogus` -> exit 2, and `evosim ui --screenshots /nonexistent-dir` -> exit 2 (both return before any server starts; verified in ui_command: parse_args error and is_dir check come first). Check that `--screenshots /nonexistent` is checked before Controller start (yes, line ~78).
3. Grep all tests/scripts (`grep -rn '"ui"\|evosim ui' crates scripts test.sh`) for any other invocation of bare `evosim ui`; scripts/contract_check.sh had no match. Also ensure every spawned `ui` in tests uses a timeout or --smoke-test.
4. Run the full `./test.sh` to completion (use `timeout 900`, run in background with log if slow; phase budget 30 min, so start early) and record exit code. Also update any docs/CLI.md wording claiming ui is a stub if left.

## Close G2 (optional, cosmetic)
Blank ~88 px strip: headless chromium `--screenshot` window-size height includes ~88 px chrome. Preferred: keep 1600x988 but make the page fill the actual viewport (CSS height:100vh; check that window.innerHeight is 900) — the strip is outside the viewport, so instead crop is impossible without image tooling. Alternative: use `--window-size=1600,900` (PNG then 1600x~812, still >= 1280x720 as required). Choose this: change browser.rs call in lib.rs:171 to 1600,900 and min-size check accordingly; confirm PNG >= 1280x720 and no blank strip by viewing main.png.

## Close G3 (optional)
In `?shot=1`/smoke mode have the page include `window.__evosim.fps` and frame count in the POST /api/rendered payload; run the smoke test with a 1,000-organism config and record the value. If trivial, assert fps>0 in smoke. Record the number in docs/UI.md.

## Verification commands (IMPLEMENT must record)
- `cargo test --release -p evosim-cli` (new tests), `./test.sh` (exit code), `xvfb-run -a ./evosim ui --smoke-test`, `mkdir -p /tmp/shots && ./evosim ui --screenshots /tmp/shots` + view main.png.

## Risks
- test.sh duration; start it first and in background.
- Port conflicts: none, tests use no server.

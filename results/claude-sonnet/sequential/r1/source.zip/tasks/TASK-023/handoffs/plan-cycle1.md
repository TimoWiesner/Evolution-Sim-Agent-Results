# TASK-023 plan, cycle 1

Design: docs/decisions/ADR-0027-ui-server-and-world-view.md (read it first). Browser UI per ADR-0002.

## Facts found
- `./evosim ui` is a stub in crates/cli/src/main.rs (exit 2, "not implemented yet"); USAGE text says so.
- Engine API: `Simulation::new(&Config)`, `step()`, `tick`, `organisms.{plants,herbivores,carnivores}: Vec<Organism>` (pos, kind, energy(), traits.max_energy, species, alive), `world.climate.biome: Vec<Biome>` row-major (`Grid::index`), `Biome::ALL` (7), `Biome::name/letter`, `Config::load_file`, `Config::default`. Climate map is static; seasons and weather change live temperature only.
- chromium is at /usr/local/bin/chromium, xvfb-run at /usr/bin/xvfb-run. No system packages to install. `setup.sh` already warns when chromium is missing.
- Workspace has no third-party crates; keep it that way.

## Ordered steps
1. `crates/ui` crate (Cargo.toml, edition 2021, depends on evosim-core), add to workspace `Cargo.toml` members, add dependency in crates/cli; update Cargo.lock once (`cargo build --release`, then keep `--locked`).
2. `snapshot.rs`: `encode_frame(&Simulation, running) -> Vec<u8>`, `encode_terrain(&Simulation) -> Vec<u8>`, `biome_style()` table, `info_json()`. Unit tests: header/length, record decode round trip, ordering plants/herb/carn, energy pct clamp 0..255, terrain bytes equal biome indices, sizes for 1,000 organisms.
3. `controller.rs`: sim thread, `Cmd` channel, pacing (ticks/s), eager-advance helper `advance_to(tick)` for smoke/screenshots, latest-snapshot slot, frame counter, `rendered` report storage. Tests: pause stops ticks, step(n) advances exactly n, determinism (UI controller after N ticks has the same `state_hash` as a plain `Simulation` stepped N times: proves same engine, no perturbation).
4. `server.rs`: minimal HTTP/1.1 parser (request line, headers, Content-Length body), routes from ADR-0027 section 3, limits and timeouts, graceful shutdown flag (nonblocking accept loop + stop flag). Tests with TcpStream: `/` serves HTML containing `<canvas`, `/api/info`, `/api/terrain` length W*H*2, `/api/frame` magic and `since` handling, 404, 405, oversized header -> 431/400, POST cmd pause/run, malformed JSON -> 400, only binds 127.0.0.1.
5. Frontend `crates/ui/web/*` embedded by `assets.rs`: layout (header, world canvas, sidebar with legend + placeholder panels with documented ids for TASK-024/025), terrain offscreen canvas, camera (wheel zoom at cursor, drag pan, wrap tiling, reset), organism glyphs per kind (colour AND shape), energy brightness, legend DOM, fetch loop + rAF loop, `window.__evosim` counters, `?smoke=1` / `?shot=1` modes posting `/api/rendered`. Pure-logic JS (camera math, frame decoder) in `app.js` kept testable: a node test `crates/ui/web/test/camera.test.js` run via `node` from a Rust integration test (node 18 is available; skip with message if absent) checks decode of a Rust-produced frame fixture and camera zoom-about-cursor invariants (world point under cursor unchanged) and wrap.
6. `browser.rs` + `ui_command` in `lib.rs`: arg parsing (exit 2 on usage errors), normal mode, `--smoke-test`, `--screenshots DIR` (DIR must exist; else exit 2), chromium discovery (`CHROME_BIN`, `PUPPETEER_EXECUTABLE_PATH`, `chromium`), process kill on all paths (guard with Drop), watchdogs (50 s / 100 s), PNG header check, temp user-data-dir cleanup.
7. Wire `main.rs`: replace stub, update USAGE (`ui [--config FILE] [--port N] [--no-open] | --smoke-test | --screenshots DIR`). Update `scripts/contract_check.sh` only if it asserts the old stub behaviour (check; it must not be weakened).
8. Docs: README.md (Status line + "User interface" section: `./evosim ui`, URL, controls: wheel/drag/keys, `--smoke-test`, `--screenshots DIR`, needs chromium only for those two), docs/UI.md (API, frame format, layout panel ids, perf numbers), docs/ARCHITECTURE.md (crate table: ui implemented), docs/STATE.md entry, docs/CLI.md `ui` section.
9. Evidence runs (record exact commands/results in implement handoff): `./test.sh`; `xvfb-run -a ./evosim ui --smoke-test` (exit 0, time); `./evosim ui --smoke-test` without DISPLAY; `mkdir /tmp/shots && ./evosim ui --screenshots /tmp/shots` then check main.png dims and view the image (Read tool) for sanity: world visible, legend visible, kinds distinguishable; 1,000-organism run (config with initial 800/150/50 etc.; document actual populations) measuring frame counter via `window.__evosim` printed in the smoke log or a test; `dist/evosim` is not required to support ui, but must still build (`./build.sh`) with the new crate.

## Acceptance mapping
| Criterion | Evidence |
|---|---|
| `evosim ui` same engine | controller test comparing `state_hash` with plain Simulation; code path uses `Simulation::step` |
| cells coloured + organisms distinguishable | terrain endpoint test; colour-distance test; screenshot viewed |
| legend | DOM test string check in served HTML/JS (ids) + screenshot |
| pan/zoom | node camera test + keyboard/wheel code; manual note |
| 1,000 organisms several updates/s | HTTP test counting distinct ticks in 2 s; `__evosim.fps` from browser run |
| smoke test | `xvfb-run -a ./evosim ui --smoke-test` exit 0 (+ ui_smoke integration test) |
| README | grep in a test (README mentions `./evosim ui`, `--smoke-test`) |

## Risks
- Chromium as root needs `--no-sandbox`; headless `--screenshot` with `--virtual-time-budget` may fire before fetch completes: the page must draw synchronously after the first fetch and virtual-time budget must be large enough; fall back to a poll loop (`--remote-debugging` not used). If screenshot comes out blank, increase budget or use `--timeout`.
- Chromium startup can hang: always kill with a deadline; temp profile dir per run.
- Thread-per-connection with keep-alive browsers: use `Connection: close` and read timeouts to avoid leaked threads.
- Port conflicts in parallel tests: always bind port 0 in tests.
- Time limit of a phase is 30 min: keep browser runs short (screenshots flow < 20 s).
- Adding a crate changes Cargo.lock; builds use `--locked`, so commit-ready lock file required (IMPLEMENT must run cargo build once without `--locked`).
- Plants are the majority of organisms (4,000 default): the viewport culling and 1-2 px dots at small zoom matter; unit sizes small.

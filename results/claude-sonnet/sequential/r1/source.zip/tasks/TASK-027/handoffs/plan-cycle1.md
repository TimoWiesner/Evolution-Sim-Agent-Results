# TASK-027 plan (cycle 1): Ecosystem balance

## Facts found
- Known earlier survival numbers (docs/ECOLOGY.md, seeds 1-5, 10k ticks): plants survive (~12,265, fill every cell cap); herbivores die at ticks 413-2706, carnivores 120-190 ticks after herbivores. Coexistence of all three: 412-2705 ticks. Herbivore boom to ~1000, then overgrazing/predation crash; carnivores starve after.
- `climate.cover_fraction` exists as a key (config.rs:173) but no code uses it: ready mechanism candidate (prey refuge).
- Tools: `./evosim batch` (jobs parallel, summary.json first_zero_tick at sample resolution), `run --metrics` (deaths_by_cause per kind + series), `perf_bench` example, `survival` example (~95 s for 5 seeds x 10k, single thread). No `scenarios/demo.json` exists yet (not this task's concern; use CONTRACT section 3 example config).
- Per-seed 10k tick run ~19 s; batch with 12 threads -> 10 seeds ~ 1 min. Trials of 3000 ticks are cheap.

## Ordered steps (IMPLEMENT)
1. Create `experiments/balance/` (scripts + configs; example config = exactly the section-3 JSON with only fixed keys, `baseline.json`). Script `scripts/balance_run.sh` (or python -I) wrapping `./evosim batch --ticks 10000 --sample-every 20` plus `run --metrics` per seed. Build release first (`cargo build --release --locked`, check `./evosim` uses release).
2. BASELINE before any code change: seeds 101..110 (ten; tuning seeds 101-110 only, held-out 201..205+ never touched until the end; choose 10 held-out for margin). Record per seed and kind: extinction tick or "survived" (use `--sample-every 1` metrics or series 10 for exact tick; extinction tick from metrics series), coexistence ticks (all three alive). Write to `docs/BALANCE.md` section "Baseline".
3. CAUSE ANALYSIS (before first change, written in BALANCE.md): from metrics for 3+ seeds: first-dying kind, its `deaths_by_cause` (starvation / predation / old age / ...) over time, population curves of all three (table at ~every 50 ticks around the crash). Hypothesis expected: herbivore overshoot -> plant depletion locally + predation -> herbivore collapse (starvation) -> carnivore starvation; or in seeds 2/3 (herbivores never peak above 120) carnivores/handling too strong or herbivores unable to reproduce in time. Let data decide; commit to the written cause before changing code.
4. TRIALS (log table in BALANCE.md: id, change, expectation, measurement, verdict; failures too). Screening on 5 tuning seeds x 3000-4000 ticks, promising ones to 10 tuning seeds x 10k. Stop after about 12-15 trials or when 3 consecutive give no improvement, leaving >=15 min for held-out, perf, docs.
   Parameter trials (cheap, `--param`): herbivore reproduction cooldown/maturity/bite, carnivore metabolism/handling/vision/offspring energy, plants.graze_reserve, resource_regen.
   MECHANISM trials (>=1 required, all local, never reading population counts):
   a. Prey cover refuge: use `climate.cover_fraction` - cells flagged (deterministic from terrain noise/seed) where carnivore success against a herbivore is reduced (e.g. p = A/(A+D) with D increased by a cover bonus) and/or carnivores cannot see a prey inside cover beyond distance 1. Expect: herbivores survive predator peaks, lowering predator-prey oscillation.
   b. Herbivore density-dependent local competition: bite limited by cell stock already (check); optionally herbivores flee depleted cells earlier (movement score uses local plant energy) to reduce overshoot.
   c. Carnivore prey-switch / satiation: carnivore skips attack when its energy is above a fraction of max (individual state, not population) - reduces overkill.
   d. Carnivore energy cost for hunting scales with distance (already attack_cost; test values).
   Each mechanism gets a config key with default OFF value in trials, then new default set from the best. New keys documented in docs/CONFIG.md, ADR (ADR-0031-ecosystem-balance), tests.
5. Held-out check: chosen defaults on 5-10 NEW seeds (201..210), full 10,000 ticks, via `./evosim batch` with the section-3 config; record per seed/kind. Also re-run baseline code? No: baseline numbers from step 2 are on seeds 101-110; ALSO run old defaults on held-out seeds (use git stash/worktree of baseline binary or `--param` with old values) for fair before/after.
6. Performance: `cargo run --release -p evosim-core --example perf_bench` (target >=100 ticks/s at ~2000 organisms); record before/after in docs/PERFORMANCE.md addendum; note perf bench window may now contain animals.
7. Tests: add/adjust `crates/core/tests/` for new mechanism (determinism, no population-size lookups, extinction stays final, ledger); re-record goldens (state_hash golden, perf golden, ecology tests, UI preset tests) with reasons in BALANCE.md. Run `./test.sh` or `cargo test --release --locked` (check test.sh) fully; record command + result. Update docs/ECOLOGY.md numbers, docs/CONFIG.md, presets (lush/harsh/predator-rich) for new defaults, UI preset values if they mirror defaults.
8. Final docs: `docs/BALANCE.md` (baseline, cause analysis, trial table, final defaults, held-out result, before/after coexistence, whether goal reached, limits), STATE.md, ARCHITECTURE.md, ADR.

## Rules to verify
No code branches on kind/species population counts (grep for `.len()`/`count` in decisions); no spawn outside births; extinction stays final (existing tests). Mechanisms use only individual/cell-local state.

## Risks
- Time: 60-min phase x timeout factor 2. 10-seed 10k batch ~1-2 min parallel; budget batches, run in background, keep trial seeds count low.
- Changing mechanisms shifts goldens (state_hash, perf golden, UI tests, preset tests): re-record with reasons.
- Overfitting to tuning seeds: held-out seeds fixed up front (201..210) and untouched.
- first_zero_tick has sample resolution: use `--sample-every 10` or metrics for exact baseline.
- Goal may not be reached; report honestly.

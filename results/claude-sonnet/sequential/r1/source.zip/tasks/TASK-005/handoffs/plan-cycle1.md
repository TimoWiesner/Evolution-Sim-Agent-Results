# TASK-005 plan, cycle 1

Existing: crates/core has config, grid, json; no rng, world or sim. Config `seed` is `i64`. `core` has zero dependencies. See ADR-0009 (written this phase) for all decisions.

## Ordered steps
1. `crates/core/src/rng.rs`: `Rng` (xoshiro256++, SplitMix64 seeding, `stream`, `next_u64/u32/f32/f64`, `below` (Lemire, unbiased), `range_i64`, `chance`, `state/from_state`, `to_hex/from_hex`). Unit tests: known xoshiro256++ reference vector (state [1,2,3,4] -> first outputs 41943041, 58720359, 3588806011781223, 3591011842654386, 9228616714210784205 — verify against a tiny independent Python implementation in the test comment before hardcoding); SplitMix64 reference (seed 0 -> 0xE220A8397B1DCDAF, 0x6E789E6AA1B965F4, 0x06C45D188009454F); export/restore continues identically; hex round trip; all-zero rejected; `below` stays in range and is roughly uniform (n=6, 60000 draws, each bucket within 5%); `f32/f64` in [0,1); different seeds differ; negative seed ok.
2. `crates/core/src/world.rs`: `World { grid: Grid }` + `World::new(&Config)`. (Resources etc. later.)
3. `crates/core/src/sim.rs`: `Phase` enum + `ORDER`, `Event/EventKind`, `TickReport`, `Simulation { config, world, rng, tick, acc, record_events }`, `new`, `step`, `run`, `digest`, `act_order`, `tie_break_min`, `export_rng/restore_rng` passthroughs. Stub phases per ADR-0009 (one RNG draw each, fixed order). Register modules in `lib.rs`; update the doc comment.
4. Integration tests `crates/core/tests/sim.rs`:
   - `same_seed_same_trace_200_ticks`: two sims, per-tick digest vectors equal over 200 ticks.
   - `different_seed_different_trace`: seeds 1 vs 2 differ at tick 1 and at the end; also `--seed`-style override (config.seed changed) equals fresh config with that seed.
   - `step_advances_exactly_one_tick` (tick 0->1, report.tick==0, run(n) == n steps).
   - `phase_order_fixed`: record_events on; events list equals `Phase::ORDER` each tick; `Phase::ORDER` literal asserted.
   - `rng_checkpoint_resume`: run 50 ticks, export rng+tick(+acc), build new sim, restore, run 50 more, digest equals uninterrupted 100-tick run.
   - `act_order_and_ties`: shuffled ids -> ascending; tie_break_min picks lowest id.
   - `no_wall_clock_or_global_rng`: source-scan test over crates/core/src for `SystemTime`, `Instant`, `thread_rng`, `rand::`, `HashMap`-iteration markers (allow `HashMap` only if absent); and `core` Cargo.toml has empty `[dependencies]`, no `evosim-` crates.
   - invalid config rejected by `Simulation::new`.
5. Docs: ADR-0009 (done), update `docs/ARCHITECTURE.md` (rng, world, sim implemented; tick order list), `docs/STATE.md`.
6. Run: `cargo test --release --workspace --locked` and `./test.sh`; record exact results.

## Risks
Stub RNG draws are placeholders and change golden traces when real phases land (no goldens are committed this task). `tick` incremented at end: document so later tasks don't misread. Seed i64->u64 cast must be documented (config seed any int).

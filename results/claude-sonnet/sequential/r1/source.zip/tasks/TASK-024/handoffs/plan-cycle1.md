# TASK-024 PLAN cycle 1
Design: docs/decisions/ADR-0028-ui-controls-and-inspector.md (read it first).

## Ordered steps
1. `crates/ui/src/session.rs`: `Session` (pure, no threads/HTTP) with run/pause/step/reset/speed levels/select/deselect/inspect/save/load; `InspectorView` + `to_json()`. Speed table [1,5,20,60,200]; clamps.
2. `controller.rs`: owns a `Session`; `Cmd` gains Reset, SpeedLevel, Select{x,y|id}, Deselect, Save(path), Load(path) with a reply channel (`Cmd::..` + `Sender<Reply>`) so HTTP answers reflect the post-command state. `Shared.terrain/info` -> `Mutex<Arc<Vec<u8>/String>>` plus `epoch`; snapshot gains `inspect_json`, `epoch`, `speed_level`, `tps`.
3. `server.rs`: new cmds (reset, speed level, select, deselect, save, load), GET `/api/inspect`, `/api/state` extra fields; keep EVF1 frame and existing endpoints/tests unchanged. JSON bodies: continue to use `json_num/json_str` (extend for string unescape of `\\`, `\"` in paths or reject paths containing a backslash/quote).
4. `web/index.html`, `app.js`, `style.css`: controls panel (buttons Run/Pause/Step/Reset, speed -, +, level label, Save/Load with path field, shortcuts), canvas click -> select (drag threshold 4 px to distinguish from pan), highlight ring, follow + vision toggles, inspector panel (id, kind, species name, age/lifespan, energy, health, traits, genome table with allele bars, clickable parents, DEAD banner). Epoch change re-fetches info/terrain. Export pure helpers for node tests.
5. `lib.rs` screenshots: also `inspector.png`; try `--window-size` compensation for the blank strip.
6. Docs: docs/UI.md (controls, API, inspector, checkpoints), README ui line, STATE.md.

## Tests (all display-free)
- `crates/ui/tests/session.rs`: step advances exactly 1 tick (also n=3); run/pause flags; reset gives equal `state_hash` to initial world after advancing 50 ticks (and same seed => same start; tick 0); speed never <= 0 for any index incl. usize::MAX and tps -5/NaN; >=3 levels; select by id and by cell (deterministic pick, wrap), inspector JSON fields present (id, kind, species, age, energy, health, 10 traits, 10 genes with 2 alleles, parents); following across ticks updates age; forced death (mark organism dead/step until removed or via config with tiny max_lifespan) -> `alive=false`, died_tick set, last values kept; select/inspect are hash-neutral vs a plain Simulation; save/load round-trip equal `state_hash`, load error leaves state untouched, load clears selection and resets reset-target config.
- `crates/ui/tests/ui.rs` additions (HTTP, free port): cmd step -> tick+1; reset; speed level clamps (negative -> 400/clamped); select + `/api/inspect`; save then load via temp dir; bad load path -> 400; counts in `/api/state` equal frame counts.
- `web/test/ui.test.js` (node): pointer->world cell with wrap, speed label, formatting helpers.
- Recorded commands: `./test.sh`, `xvfb-run -a ./evosim ui --smoke-test`, `./evosim ui --screenshots /tmp/shots` (check main.png and inspector.png exist).
- Rule from TASK-023: never start a long-lived `evosim ui` in a test.

## Risks
- Death cause may be unavailable after removal (document "unknown" or read `last_deaths`/events).
- Terrain swap on load of a different world size: page must rebuild camera.
- Click vs drag; plants dense on a cell: prefer animals.
- Tick published rate vs inspect polling load: inspect JSON built only when something selected, once per publish.
- Checkpoint file path from the browser: local-only server; reject NUL/empty/directories.

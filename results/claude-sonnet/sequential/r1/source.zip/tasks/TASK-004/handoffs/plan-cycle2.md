# TASK-004 plan (cycle 2) – replan closing REVIEW cycle 1 gaps G1–G3

Facts verified on entry: `crates/core/tests/grid.rs` is 0 bytes; `grid.rs` logic is correct (review ran an exhaustive throwaway check). Scope = tests + doc correction only; no logic change expected. If a new test exposes a bug, fix in grid.rs and record it.

## Steps (ordered)
1. **G1** – write `crates/core/tests/grid.rs` (integration, uses `evosim_core::grid::{Grid,Pos,Delta}`; check crate lib name in crates/core/Cargo.toml). No new crates.
   - Helper `brute_within(g, c, r) -> BTreeSet<Pos>`: scan ALL cells q, compute dist independently (per axis min over image offsets {d, d-N, d+N} of |.|, then max), keep dist<=r. Must not call `Grid::delta/dist`.
   - Test `cells_within_matches_bruteforce`: sizes (1,1),(1,2),(1,5),(5,1),(2,2),(3,3),(5,3),(6,4),(7,2),(4,9); r in 0..=2*max(w,h)+2; every centre. Assert: Vec len == set len (no duplicates), every cell `contains`, set == brute set, `count_within(r) == len`, `cells_within(c, r)` for r=-1 empty. Also `r = 1000` and `i64::MAX/4`-style huge radius returns exactly W*H cells.
   - Test `radius_larger_than_world_covers_each_cell_once` explicit 3x3 and 4x2, r=10.
   - Test `deterministic_order`: same call twice equal; first cell for r=1 is wrapped (cx-1,cy-1).
2. **G2** – in same file:
   - `edges_and_corners_nonsquare` on 7x5 (odd) and 6x4 (even): for each of the four edges, pairs across the seam: (0,y)<->(W-1,y) delta (-1,0)/(+1,0) dist 1; (x,0)<->(x,H-1) delta (0,-1)/(0,1); four corners: (0,0)<->(W-1,H-1) delta (-1,-1), reverse (+1,+1); (W-1,0)<->(0,H-1) delta (+1,-1) and reverse; all dist 1. Also a long span: (0,0)->(W-2,H-2) goes across edges (delta (-2,-2)).
   - `delta_dist_properties`: all pairs on several grids: dist symmetric; `offset(a, delta(a,b)) == b`; |dx|<=W/2, |dy|<=H/2; dist == brute (above); odd size: delta antisymmetric; even size tie: dx == +W/2 for both directions (positive convention).
   - `wrap_negative_multiple_extreme`: on 7x5: wrap(-1,-1)=(6,4); wrap(-7,-5)=(0,0); wrap(-8,-6)=(6,4); wrap(7k+c,5k+c) for k=±1000; i64::MIN/MAX produce valid cells (compare with i128 reference `rem_euclid`).
   - `one_by_one`: every wrap -> (0,0); delta 0; dist 0; step_toward 0; cells_within(r=0 and r=5) == [(0,0)]; neighbors8 empty; index/pos_of roundtrip.
   - `one_by_n_and_n_by_one` (1x6, 6x1, 1x2, 2x1): wrap, seam delta/dist (e.g. 1x6: (0,0)->(0,5) delta (0,-1)), x axis delta always 0, neighbors8 has no duplicates and excludes centre (1x6 → 2 neighbours; 1x2 → 1; 2x2 → 3; 1x3 → 2).
   - `new_rejects_zero`: 0xN, Nx0 are Err.
3. **G3** – step_toward: replace weak test with `step_toward_signs`: same cell → (0,0); across x seam (0→W-1) gives dx=-1; across y seam (H-1→0) gives dy=+1; diagonal across corner (0,0)→(W-1,H-1) gives (-1,-1); tie (even size) gives +1; result components always in {-1,0,1}; applying it via `offset` strictly reduces `dist` (when a≠b) on odd and even grids (all pairs). Check whether the weak assertion is in grid.rs unit tests (the `mod tests` there has no step_toward test; the "weak one" was claimed in tests/grid.rs which is empty — nothing to remove).
   - Correct docs: `docs/STATE.md` Grid section already points to tests/grid.rs; after implementing, make sure the sentence stays true and mention the exact test names. Also add a line in the implement handoff acknowledging the cycle-1 handoff misreport.
4. Run `cargo test --release --workspace --locked` (expect > 7 grid tests + new integration tests, tests/grid.rs must list non-zero tests) then `./test.sh`. Record exact commands, counts (`cargo test ... -- --list | grep -c` for grid) in the implement handoff.

## Gap closure map
- G1 → step 1 (bruteforce, no-dup, radius>world, non-square, 1xN).
- G2 → step 2 (four edges, four corners, both directions, 1xN/Nx1, neighbors8 dedup).
- G3 → step 3 (step_toward strengthened; STATE.md claim made true).

## Risks
- Brute force must be independent of `delta` or it tests nothing.
- Even-size tie: neighbors8 on 2xN yields fewer than 8 distinct cells; test expectation must use sets.
- Verify test count > 0 for tests/grid.rs (the cycle-1 failure mode was an empty file).

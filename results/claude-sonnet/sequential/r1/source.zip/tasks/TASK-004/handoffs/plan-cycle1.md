# TASK-004 plan (cycle 1)

Context: crates/core has config.rs, json.rs, lib.rs only (no grid yet). Chosen design in docs/decisions/ADR-0008-grid-geometry.md.

## Ordered steps
1. Create `crates/core/src/grid.rs`; add `pub mod grid;` in lib.rs.
   - `pub struct Grid { w: u32, h: u32 }`; `Grid::new(w,h) -> Result<Grid,String>` (>=1, w*h fits usize/u32).
   - `Pos {x:i32,y:i32}`, `Delta {dx:i32,dy:i32}` (derive Copy, Eq, Ord, Hash, Debug).
   - `wrap_x/wrap_y(i64)->i32`, `wrap(i64,i64)->Pos`, `index(Pos)->usize`, `pos_of(usize)->Pos`, `offset(Pos,dx,dy)->Pos` (wraps, i64 math).
   - `delta(a,b)->Delta` shortest, half-way tie -> positive; `dist(a,b)->u32` Chebyshev; `step_toward(a,b)->Delta` unit sign step.
   - `cells_within(center,r)->Vec<Pos>` and `for_each_cell_within(center,r,f)` per ADR (clamped span, no duplicates). `neighbors8` is just radius 1.
2. Tests: `#[cfg(test)]` unit tests in grid.rs + `crates/core/tests/grid.rs` (integration/property with in-house xorshift for random cases, no new crates):
   - wrap of negatives, multiples (-1, -W, -W-1, k*W+c for k=±1000, i64 extremes) on non-square grid.
   - all four edges and four corners: neighbours across seam (x=0 vs W-1, y=0 vs H-1, corner (0,0)<->(W-1,H-1) distance 1, delta (-1,-1)).
   - shortest delta/dist incl. even-size tie, odd size, antisymmetry (except tie), dist symmetric, delta applied by offset lands on target.
   - cells_within: no duplicates, count formula, r=0, r > W and H, r huge (1000) bounded by W*H, contains exactly the cells with brute-force dist<=r (brute force built independently by scanning all cells and computing min over wrap images).
   - 1x1 (everything maps to (0,0), dist 0, delta 0, within r returns 1 cell), 1xN and Nx1, 2x2, 2xN.
   - deterministic order test (row-major ascending offsets).
3. Docs: update docs/ARCHITECTURE.md (`core::grid` row, mention Chebyshev), STATE.md, mark ADR-0008 Accepted, note in ADR-0003 that grid.rs implements its geometry. (Do not touch CONTRACT/AGENTS.)
4. Run `./test.sh`; record exact result in implement handoff.

## Risks
Clamped-span ordering vs ADR-0003 spec; i32/i64 overflow on extreme inputs (use i64 + rem_euclid); even-size tie convention must be used consistently by climate/perception later.

## Out of scope
Organisms, spatial index (TASK-010), climate.

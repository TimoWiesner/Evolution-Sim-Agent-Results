# TASK-025 PLAN cycle 1
Design: docs/decisions/ADR-0029-ui-setup-and-charts.md (read first). Builds on crates/ui (Session, Controller, server, web/app.js).

## Ordered steps
1. `crates/ui/src/experiment.rs` (pure): `PRESETS` (name, description), `FieldError{path,message}`, `form_schema_json()`, `values(&Config) -> Vec<(String,String)>` (text per param_defs path), `build(&[(String,String)]) -> Result<Config, Vec<FieldError>>` (parse by kind, min/max, UI size guard 1,000,000 cells / 200,000 organisms, then `Config::validate()` mapped to a field), `export(&Config)->String` (= `to_json`), `import(&str)->Result<Config,Vec<FieldError>>`, `setup_json()` for GET /api/setup.
2. `crates/ui/src/charts.rs` (pure): `History { interval, samples }` with `observe(&Simulation)` (called when tick % interval == 0 and at start), decimation at 1,000 samples (interval doubles, births/deaths interval sums merged), `to_json(epoch)`, `clear()`, `histogram(&Simulation, kind, trait, bins) -> Hist` + `to_json`. Trait order/names from `core::metrics` (`trait_values`, `TRAIT_NAMES`, `kind_key`).
3. `session.rs`: `Session.history`; `advance/step/advance_to` call observe; `new_world(cfg)` (build first, then swap; running = true; clears selection+history; epoch++); reset/load clear history.
4. `controller.rs`: `Cmd::NewWorld(Box<Config>)`, `Cmd::Hist{kind,trait,bins}` (reply `message` = JSON); `Snapshot.charts: Arc<String>` rebuilt only when the sample count or epoch changed; `AdvanceTo` goes through `Session::advance_to`; terrain/info refresh on epoch change already exists.
5. `server.rs`: routes `/charts.js`, `/setup.js`, GET `/api/setup`, `/api/config`, `/api/charts`; POST `/api/config/check`, `/api/config/start`, `/api/config/import` (bodies parsed with `core::json`; errors 400 with `errors[]`); cmd `hist`. Keep EVF1 frame and existing endpoints/tests unchanged. Add the new POST paths to `is_post`.
6. Web: `web/charts.js` (pure helpers + canvas drawing), `web/setup.js` (form builder, error display next to field, preset cards, import via FileReader, export via Blob download), `index.html` (header "New world..." button, chart dock with 5 canvases + trait/kind selects, setup overlay), `style.css`, `app.js` hooks (poll /api/charts 2 Hz, redraw, epoch change, `?view=`/`bad=` shot params). `assets.rs` constants.
7. `lib.rs` screenshots: advance to 400, `main.png` (world + dock), `charts.png`, `setup.png`, keep `inspector.png`.
8. Docs: docs/UI.md (setup, config files, charts, API additions), README ui line, docs/STATE.md, docs/ARCHITECTURE.md rows; docs/CONFIG.md untouched.

## Tests (display-free unless noted)
- `crates/ui/tests/experiment.rs`: all presets resolve and have cards; `values -> build` round trip equals preset config for every preset; export -> import `Config ==` and identical text for presets and an edited config (seed negative, size 80x60, populations, 6 other params); import rejects unknown key / wrong type with the key path; per-field errors: width "0", width "abc", width "1.5", empty seed, plants.growth_rate "-1", unknown path, cross-field pole_temp > equator_temp mapped to climate.pole_temp, several errors returned together; size guard; `new_world` with invalid config leaves tick/state_hash unchanged (no start); valid edits of seed, size, 3 populations and 6 other params each change `state_hash` vs preset and the world has the edited size/populations; same config gives the same `state_hash` as a plain `Simulation::new`.
- `crates/ui/tests/charts.rs`: samples at the interval, tick-0 sample; pop equals counts of the sim at that tick; births/deaths interval sums equal cumulative `organisms.stats`; species equals `living_species`; trait mean equals a recomputation (and None for an empty kind); decimation keeps <= 1,000 samples and total births exact; history cleared by reset/new_world; observing is hash-neutral (Session vs plain Simulation after N ticks); histogram: counts sum to population, bins clamped, equal-values case, empty kind, selectable all 10 traits x 3 kinds; JSON parses with `core::json` and has all series keys.
- `crates/ui/tests/ui.rs` additions (HTTP, free port, no long-lived `evosim ui`): GET /api/setup lists >= 70 params and 5 presets; start with valid body changes size/epoch and tick restarts; invalid body -> 400 with `errors[].path` and tick unchanged; export (GET /api/config) -> POST import returns same values; /api/charts grows with ticks; `hist` cmd counts sum to population; page contains the new element ids and axis-label strings (`charts.js` has "tick" label code).
- `web/test/charts.test.js` (node 18): niceTicks, scale mapping, seriesPath with null gaps, legendItems, histogram scaling; `web/test/setup.test.js`: error-to-field mapping helper.
- Recorded commands: `./test.sh`; `xvfb-run -a ./evosim ui --smoke-test`; `mkdir -p /tmp/sh && ./evosim ui --screenshots /tmp/sh` then view main.png/charts.png/setup.png.

## Risks
- Large user worlds freeze the controller: mitigated by the UI size guard (documented).
- Chart polling cost with 1,000 samples x many series: JSON built only on change; decimation.
- Float text round trip in form: use shortest round-trip formatting; test covers it.
- Hand-rolled `json_str` in server.rs is not nested-aware: new endpoints parse with `core::json` instead.
- Screenshot blank strip (headless chrome) may remain: record as gap, not failure.
- Key names in step 2 of ADR (highlighted parameters) must be taken from docs/CONFIG.md; verify exist.
- Rule from TASK-023: no test may start a long-lived `evosim ui`.

## System dependencies
None new (chromium, node 18, xvfb-run already present).

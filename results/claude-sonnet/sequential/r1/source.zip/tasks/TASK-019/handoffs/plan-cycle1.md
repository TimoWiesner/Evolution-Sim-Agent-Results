# TASK-019 plan, cycle 1

Decisions: docs/decisions/ADR-0023-headless-run-and-state-hash.md. No feature code written in this phase.

## Ordered implementation steps
1. `crates/core/src/hash.rs`: `Sha256` (new/update/finalize -> [u8;32], `hex()`); `pub mod hash` in lib.rs. Unit tests: FIPS vectors "", "abc", 56-byte two-block message, 1e6 x 'a', chunked update equals one-shot.
2. `Simulation::state_hash(&self) -> String` in sim.rs per ADR-0023 section 3 (a `HashSink` helper with `u64`, `f64`, `bytes`, length-prefixed section). Add `ClimateMap::state_words` (check how the map stores fields; read-only accessors suffice) and `World::cap_words`. Test file `crates/core/tests/state_hash.rs`: equal runs equal; different seed differs; sensitivity: mutate one field at a time on a clone (tick, acc, rng word, weather, one organism's pos/age/energy(1 ulp)/health/parents/generation/move_credit/heading/rest/cooldown/species/one allele/one trait, a counter, a resource cell, resource_cap, species registry, config value e.g. `plants.maintenance`, climate cell) and assert the hash changes for each; hash is 64 lowercase hex; hash stable across `clone()`. Pin one golden hash of a short fixed run to detect accidental change (document that regenerating is allowed when sim semantics change).
3. `crates/runner` (`evosim-runner`, add to workspace members; no deps; Cargo.lock gets only the new package entry, so `--locked` needs the lock updated by one non-locked `cargo build` first, record this in STATE). Modules: `args.rs` (parser, `ArgError`), `result.rs` (JSON building), `lib.rs` (`run_headless`). Pure functions where possible: `series_ticks(start, n, k) -> Vec<u64>`, `default_sample_every(n)`.
4. `crates/cli/src/main.rs`: `run` dispatches to `evosim_runner::run_command(&args[1..]) -> i32`; update usage text (remove "not implemented" for run). batch/ui stay stubs. Update `crates/cli/tests/cli.rs` only if the usage assertions break.
5. `README.md`: replace status paragraph, add a `run` example (`./evosim run --config scenarios/demo.json --ticks 1000 --out result.json`; scenarios/demo.json does not exist yet, so the README example uses a config the task creates: add `examples/minimal.json` holding exactly the CONTRACT section 3 sample, and use it. Do not create scenarios/demo.json, it belongs to a later task). Document flags, the extra result keys and exit codes.
6. Docs: new `docs/CLI.md` (flags, result schema incl. extras, series rule, error table, hash definition); update docs/STATE.md, docs/ARCHITECTURE.md (runner crate), and `docs/decisions/README.md` index if it lists ADRs.

## Tests (run `./test.sh`)
- `crates/runner/tests/` unit tests for arg parser (every error class), `series_ticks` (N=0, K>N, N%K==0, N%K!=0, K=1), default K (N=0 -> 1, N=50 -> 1, N=1000 -> 10).
- `crates/cli/tests/run.rs` end-to-end using `CARGO_BIN_EXE_evosim` with temp dirs (std only, unique dir per test):
  - same seed twice: identical `final`, `totals`, `series`, `state_hash` (and byte-equal after dropping elapsed_seconds/ticks_per_second); different seeds: different `state_hash`; `--seed` overrides the config seed and `seed` in the result equals it.
  - schema: every CONTRACT key and type present, `contract==1`, `tick_end==tick_start+N`, `initial+births-deaths==final` per kind (initial from config / `totals.initial`), series first=0 last=N ascending and unique, hash 64 lowercase hex.
  - `--ticks 0` valid: series has one point, hash present, `tick_end==0`; `--sample-every` honoured (e.g. N=10,K=3 -> 0,3,6,9,10); default K.
  - extinction: `initial` all zeros and plants=0 with herbivores/carnivores >0 run N=300 ticks: `tick_end==300`, final all 0, no error exit 0; ticks counter really advanced (state_hash differs from `--ticks 0`... and from `--ticks 299`).
  - `initial.plants=0`: herbivores then carnivores die out and stay 0 (CONTRACT 5.3), series monotone at zero afterwards.
  - errors (each: exit 2, stderr non-empty, stdout empty, no OUT file, pre-existing OUT unchanged): missing --config/--ticks/--out, unknown flag, bad/negative/non-numeric --ticks, `--sample-every 0`, bad --seed, missing config file, invalid JSON, wrong type, missing fixed key, out-of-range value (width 0), unknown key, `--out` into a missing directory, `--load`/`--save` (not implemented).
  - runs with `DISPLAY` removed from the environment.
- Core hash tests as in step 2.
- Record a manual command in the implement handoff: `./evosim run --config examples/minimal.json --ticks 1000 --out /tmp/r.json` plus timing.

## Risks
- Adding a crate changes Cargo.lock; builds use `--locked`: update lock once, commit-ready, and check `./setup.sh` + `./build.sh` + `dist/evosim run` still work (dist is single binary from the cli crate).
- `state_hash` must not include anything nondeterministic (HashMap iteration, addresses, wall clock). Check that species registry / climate use ordered containers.
- Longer E2E tests in debug-free release test profile: keep ticks <= 300 on small worlds (<10 s total).
- Plain `digest()` and `state_hash()` could drift: add a test that equal digest implies equal state_hash on cloned sims and that both change together on perturbation.
- Float formatting: `json::format_float` must round-trip; NaN/inf never emitted (guard elapsed).
- The 10,000-tick default scenario runs ~95 s per 5 seeds (docs/ECOLOGY.md); benchmark performance is not a TASK-019 acceptance item.

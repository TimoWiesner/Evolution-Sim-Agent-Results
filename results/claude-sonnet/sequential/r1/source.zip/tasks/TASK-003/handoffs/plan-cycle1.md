# TASK-003 plan (cycle 1)

State: crates/core has only lib.rs (version_json); no deps; cli is a stub. See ADR-0007.

## Ordered steps
1. `crates/core/src/json.rs`: `Value`, `parse(&str)->Result<Value,JsonError{line,col,msg}>` (reject trailing garbage, duplicate keys -> error naming key, depth limit 64, ints->Int when no '.'/exp and fits i64 else Float, big ints -> Float flagged? -> keep as Int overflow => treat as Float and let range check fail), `Value::write(pretty)` with escape handling; float writing via `{}` + ".0" suffix when integral, exp forms accepted by parser. Tests: valid/invalid docs, escapes/unicode, round-trip, error positions.
2. `crates/core/src/config.rs` (+ `pub mod json; pub mod config;` in lib.rs):
   - structs `Config{seed:i64, world:World{width,height:u32}, initial:Initial{plants,herbivores,carnivores:u32}, climate:Climate, plants:Plants, herbivores:Animal, carnivores:Animal, genetics:Genetics, run:Run}` with `Default`.
   - Suggested parameters (~50, all with min/max/default/doc): climate{equator_temp, pole_temp, temp_range seasonal amplitude, season_length_ticks, precip_mean, precip_variation, weather_noise, weather_period, seam_smoothing}; plants{initial_energy, growth_rate, max_size, resource_uptake, water_need, temp_optimum, temp_tolerance, seed_range, reproduction_threshold, reproduction_cost, max_age, density_limit_per_cell, pollination_range, mutation_rate}; animals (herbivores & carnivores, same struct, different defaults){initial_energy, max_energy, base_metabolism, move_cost, speed, vision, strength, health, max_age, maturity_age, reproduction_energy, reproduction_cooldown, mate_range, offspring_energy, satiation_limit, aggression, risk_tolerance, handling_time, mutation_rate}; genetics{mutation_sigma, gene_mutation_rate, species_threshold, species_min_size, species_check_interval}; run{sample_every default optional? (skip, CLI)}.
     Final list is the implementer's call; keep each group <=20 keys, no key that references global population counts (forbidden mechanics).
   - `ParamDef` table + `Config::from_json_str(&str)->Result<Config,ConfigError>`, `from_value`, `to_value`, `to_json_string(pretty)`, `validate(&self)->Result<(),ConfigError>` (also cross-field: e.g. pole_temp<=equator_temp? maturity_age<=max_age, reproduction_energy<=max_energy, initial_energy<=max_energy; names the offending key).
   - `ConfigError`, `preset(name)`, `PRESET_NAMES`, `Config::load_file(path)` (io error -> ConfigError key `<file>`), documented unknown-key error.
3. Docs: `docs/CONFIG.md` generated-by-hand/or via `#[test]`-checked table of all keys (a test regenerates table text from PARAMS and compares to file, or skip and just have CLI-free `config::describe()`); README config section; update ARCHITECTURE (config module done) and STATE.
4. Presets also exported to `scenarios/` as full-json files? Only `scenarios/demo.json` is required later (not this task); export presets via a test `#[test] presets_files_in_sync` only if files are created. Decision: do NOT create scenario files now (avoid drift); expose `Config::preset`.
5. Do not touch cli run handling.

## Tests (crates/core/src/config.rs tests or crates/core/tests/config.rs)
- minimal file with only fixed keys valid; all non-fixed equal Default; zero initials ok (each individually and all zero).
- missing each of the 6 fixed keys -> error contains key name.
- wrong type per kind: string for int, float for int (`64.5`), bool for number, number for object (`"world": 5`), null, array; for a nested float param; error names key.
- out of range: width 0, width too large, negative initial, each ParamDef min-1/max+1 (loop over PARAMS), cross-field.
- unknown top-level and nested key -> error naming path; syntax error; duplicate key; non-object root.
- round trip: default, every preset, a mutated config with extreme-but-valid values (min/max of every param); also text-stable (to_json twice equal; reparse->to_json identical).
- presets: >=3 names, each validates, pairwise different, differing in several groups; `preset("nope")` errors listing names; case-insensitive? no - exact names.
- property-style: seeded in-house xorshift random valid configs (500) round-trip; random single-key corruption always rejected with that key in message.
- json module tests.
Commands: `cargo test --release --workspace --locked` and `./test.sh`.

## Risks
- Float formatting round trip: rely on Rust shortest repr + parse::<f64>() (exact); test with awkward values (0.1, 1e-300, 1e300, 5e-324).
- Parameters chosen now may need renaming; ADR says later tasks may add keys but should reuse.
- Hand-written JSON parser bugs: mitigate with tests; keep strict.
- Presets must stay valid when ranges tighten: test enforces.

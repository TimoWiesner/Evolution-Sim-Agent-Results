# TASK-008 plan, cycle 1

Design: docs/decisions/ADR-0012-organisms-and-life-cycle.md (read first). Existing code read: sim.rs (Phase::ORDER, EventKind, digest), world.rs, rng.rs (Rng::stream), config.rs (plants/herbivores/carnivores keys), ADR-0003/0004/0009.

## Ordered implementation steps
1. `crates/core/src/organism.rs` (+ `pub mod organism;` in lib.rs): Id, Kind, DeathCause (+ N_CAUSES, name()), TraitRanges/Traits (`range`, `clamped`, `baseline`), Organism (private energy/health, clamping mutators, getters), Death, NewBorn, LifeStats, Organisms (storage, populate, get/get_mut/find, active_ids, count, mark_dead, queue_birth, resolve_deaths, resolve_births, state_words/hash helper).
2. sim.rs: field `organisms`, create in `new` (populate with Rng::stream(seed,2)); Deaths/Births phases call resolve_*, keep the one placeholder RNG draw per phase; per-tick `last_births/last_deaths`; new EventKind::Born/Died (Copy); digest feeds organisms. Update tests/sim.rs & tests/weather.rs rebuild-from-parts tests to also copy `organisms`.
3. docs/ORGANISMS.md: trait table with ranges, rule of same-tick births/deaths, API summary. Update docs/ARCHITECTURE.md and STATE.md.
4. tests/organisms.rs (integration) plus unit tests in organism.rs.

## Tests (each acceptance criterion)
- kinds: three kinds exist, populate creates configured counts per kind (and 0 allowed).
- fields: every organism has id/kind/pos in grid/age/energy/health/traits/parents/generation; founders gen 0 parents [0,0]; child gen = max+1; parents recorded.
- ids: unique and never reused after deaths + births over 500 ticks (collect all ids ever seen in a HashSet in test; next_id strictly increasing; a dead id never reappears).
- traits: all traits in `Traits::range(kind)` for baseline of all presets; clamped() fixes out-of-range/NaN/inf; plants have speed 0 and animals have aggression and risk_tolerance in [0,1]; the 4 required traits exist.
- ranges: property loop with random deltas (add_energy/damage/heal/set_energy incl. NaN, inf, huge, negative) never leaves [0,max]; newborn with oversize energy clamped.
- death: marked organism is not in `active_ids`, second mark_dead no-op and keeps first cause, removed at Deaths phase, `get(id)` is None afterwards, never in later iterations; cause recorded in the returned Organism and in deaths_by_cause; automatic causes: OldAge (age >= max_lifespan), Starvation (energy 0), Injury (health 0), priority order test when several hold.
- counters: births/deaths per kind cumulative; population == founded + births - deaths at every tick of a scripted run; counters monotone.
- same-tick rule: scripted tick where an organism is marked dead and a birth queued with that organism as parent (queue before mark; queue after mark rejected), a newborn does not age/die in its birth tick, deaths resolved before births (ids of newborns > ids of any removed; population arithmetic), parents that die in the same tick still appear as parents of the newborn; two births in a tick get ids in queue order; order independence of deaths vs births cannot change counts.
- determinism: same config/seed -> same digest over 300 ticks; different seed -> different; digest changes when an organism's energy changes.
- sim integration: step() end-to-end with record_events yields Born/Died events matching counters.
Commands: `cargo test --release -p evosim-core --locked organism` then `./test.sh`.

## Risks
- Digest change breaks partial-rebuild tests (see ADR). - Placeholder RNG draws remain in Deaths/Births. - With no metabolism yet, founders only die of old age (max_age 400/800/1000) - intended; later tasks add drain. - Trait ranges may need widening when TASK-009 maps genes; ranges are a single const table.

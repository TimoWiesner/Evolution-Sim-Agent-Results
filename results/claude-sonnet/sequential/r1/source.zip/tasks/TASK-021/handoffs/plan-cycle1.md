# TASK-021 plan, cycle 1 (see ADR-0025 for the design)

Baseline: runner crate has `run_headless_full(&RunArgs)` (loads file, applies --seed, runs, builds result Value), `write_atomic`, `args.rs` parser. `Config::param_defs/set_num/get_num/validate/to_json` give typed sweeps by dotted path. `core::json::Value` has `get`, `to_pretty`, `format_float`. CLI `batch` is a stub (exit 2); `crates/cli/tests/cli.rs::stubs_and_bare_run_exit_2` still holds (bare `batch` exits 2 for missing args).

## Ordered steps
1. Refactor `crates/runner/src/lib.rs`: extract `pub fn run_config(cfg: Config, ticks, sample_every: Option<u64>, metrics: bool) -> Result<(Value, Option<Value>), String>`; `run_headless_full` = load + seed override + `run_config`. Existing run tests must stay green (output unchanged).
2. `crates/runner/src/batch.rs`: `BatchArgs::parse` (flags: --config --seeds --ticks --out-dir --param(repeat) --sample-every --jobs --quiet), `parse_seeds`, `parse_param` (typed through `Config::param_defs()`; ints for Int keys, floats for Float, true/false for Bool), `plan_runs(base, args) -> Vec<RunSpec{index,seed,params,label,cfg}>` (validates every point), `execute` (scoped threads, atomic counter, slot vector), `summarize` (runs[], aggregate, groups), `to_csv`, `batch_command(argv) -> i32`. Reuse `write_atomic`.
3. Wire `crates/cli/src/main.rs`: `batch` -> `evosim_runner::batch_command`; update USAGE text with batch options. `ui` stays stub.
4. Docs: append a "evosim batch" section to docs/CLI.md (flags, layout, summary keys, CSV columns, determinism note); update docs/ARCHITECTURE.md (runner/batch) and docs/STATE.md; README one-line example if README lists commands.
5. Tests (all must pass under `./test.sh`):
   - unit (batch.rs): seed list/range parsing and errors; param parsing (type errors, dup value, `seed` rejected, out-of-range); run order for 2x2 matrix; label text; aggregate arithmetic on hand-made numbers (mean/min/max/sd/median/extinct_count); CSV quoting.
   - `crates/cli/tests/batch.rs` (integration, small world e.g. 16x12, ~60-100 ticks so it is fast):
     a. 2 values x 2 seeds matrix (`--param initial.carnivores=0,5 --seeds 1,2`): 4 seed files in 2 subdirs, `summary.json` has 4 runs with seed, params, ticks; aggregates recomputed in the test from the seed files' `final` equal summary mean/min/max per kind; extinct_count for carnivores == 2 (the `initial.carnivores=0` runs) for the group, per-group counts correct.
     b. no sweep: `DIR/seed-<s>.json` for each seed, its `state_hash` equals that of `evosim run` with same config/seed.
     c. determinism: run twice (and once with `--jobs 1` vs `--jobs 4`), strip `elapsed_seconds`/`ticks_per_second` recursively, summaries equal; the CSV equal after dropping the last two columns.
     d. CSV: header, row count = runs, parsed values match summary.json; aggregates.csv has groups x 3 rows.
     e. error cases, each exit 2, empty stdout, no summary.json: missing flag, empty/dup/non-integer seeds, unknown flag, duplicate flag, bad param key, bad value type, out-of-range value (validated before running), `--param seed=..`, `--jobs 0`, unreadable config, run count over limit; `DISPLAY` removed.
6. Optionally extend `scripts/contract_check.sh` with a 2-seed `batch` call (config `examples/minimal.json`, ticks small) checking seed files + summary.json exist; also run against dist/evosim.
7. Verify: `./test.sh`; manual `./evosim batch --config examples/minimal.json --seeds 1,2 --ticks 200 --param initial.herbivores=0,60 --out-dir /tmp/b1` twice, `diff` after removing timing keys; record commands in the implement handoff.

## Risks
- Float formatting of param values in labels/paths (use json::format_float; reject values giving duplicate labels).
- Thread panics: join and convert to exit 2.
- Large run counts memory: only small per-run extracts kept; full result Value dropped after writing.
- Wall-clock test time: keep matrices tiny.
- `first_zero_tick` has sample resolution only (documented).

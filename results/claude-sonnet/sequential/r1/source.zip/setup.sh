#!/usr/bin/env bash
# Installs and builds everything evosim needs. Idempotent.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
export PATH="$HOME/.cargo/bin:$PATH"
if ! command -v cargo >/dev/null 2>&1; then
  echo "setup: cargo not found; installing rustup toolchain" >&2
  curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal >&2
  export PATH="$HOME/.cargo/bin:$PATH"
fi
cargo build --release --locked >&2
command -v chromium >/dev/null 2>&1 || echo "setup: warning: chromium not found (only needed for UI screenshots)" >&2
echo "setup: done" >&2

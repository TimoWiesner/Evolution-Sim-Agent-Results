#!/usr/bin/env bash
# Usage: scripts/contract_check.sh [BINARY...]  (default: ./evosim)
# Checks version JSON, --help and unknown-command exit status.
set -uo pipefail
cd "$(dirname "$(readlink -f "$0")")/.."
[ $# -eq 0 ] && set -- ./evosim
fail=0
for b in "$@"; do
  out=$("$b" version) || { echo "FAIL $b version exit"; fail=1; continue; }
  printf '%s' "$out" | python3 -I -c 'import json,sys; d=json.load(sys.stdin); assert set(d)=={"name","version","contract"} and d["contract"]==1' \
    || { echo "FAIL $b version json"; fail=1; }
  "$b" --help | grep -q batch || { echo "FAIL $b help"; fail=1; }
  "$b" bogus >/dev/null 2>&1; [ $? -eq 2 ] || { echo "FAIL $b unknown exit"; fail=1; }
  echo "checked $b"
done
exit $fail

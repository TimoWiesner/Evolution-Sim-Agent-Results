#!/usr/bin/env bash
# Usage: scripts/verify_contract.sh [BINARY] [--ui]   (default ./evosim)
# Verifies every command and required behaviour of docs/CONTRACT.md from a foreign cwd; prints one line per check.
# --ui adds `ui --smoke-test` and `ui --screenshots` (needs chromium; uses xvfb-run when present). Exit 0 = all passed.
set -uo pipefail
ROOT="$(cd "$(dirname "$(readlink -f "$0")")/.." && pwd)"
BIN="${1:-$ROOT/evosim}"; case "$BIN" in /*) ;; *) BIN="$(cd "$(dirname "$BIN")" && pwd)/$(basename "$BIN")";; esac
UI=0; [ "${2:-}" = "--ui" ] && UI=1
W="$(mktemp -d)"; trap 'rm -rf "$W"' EXIT; cd "$W"
fail=0
ok(){ echo "PASS $1"; }
bad(){ echo "FAIL $1"; fail=1; }
chk(){ local n=$1; shift; if "$@"; then ok "$n"; else bad "$n"; fi; }
py(){ python3 -I -c "$@"; }
printf '{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}' > c.json
printf '{"seed":1,"world":{"width":24,"height":16},"initial":{"plants":0,"herbivores":40,"carnivores":8}}' > noplants.json
printf '{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}' > empty.json

out=$("$BIN" version 2>err.txt); rc=$?
chk "version: exit 0, stdout exactly one JSON {name,version,contract:1}, stderr empty" bash -c "[ $rc -eq 0 ] && [ ! -s err.txt ] && printf '%s' '$out' | python3 -I -c 'import json,sys;d=json.load(sys.stdin);assert set(d)=={\"name\",\"version\",\"contract\"} and d[\"contract\"]==1'"

"$BIN" run --config c.json --ticks 500 --out a.json --quiet >so.txt 2>/dev/null; rc=$?
chk "run: exit 0, stdout empty" bash -c "[ $rc -eq 0 ] && [ ! -s so.txt ]"
chk "run: result keys, tick_end=tick_start+N, series ascending/no duplicates/default K=N/100, first=tick_start, last=tick_end" py '
import json
r=json.load(open("a.json"))
for k in ["contract","seed","tick_start","tick_end","world","final","totals","series","state_hash","elapsed_seconds","ticks_per_second"]: assert k in r,k
assert r["contract"]==1 and r["seed"]==42 and r["tick_start"]==0 and r["tick_end"]==500
assert r["world"]=={"width":64,"height":48}
assert set(r["final"]["species"])=={"plants","herbivores","carnivores"}
t=[p["tick"] for p in r["series"]]
assert t==sorted(set(t)) and t[0]==0 and t[-1]==500 and t[1]==5, t[:3]
assert len(r["state_hash"])>=32 and r["state_hash"]==r["state_hash"].lower() and all(c in "0123456789abcdef" for c in r["state_hash"])
assert r["elapsed_seconds"]>=0 and r["ticks_per_second"]>0
init={"plants":400,"herbivores":120,"carnivores":20}
for k in init: assert init[k]+r["totals"]["births"][k]-r["totals"]["deaths"][k]==r["final"][k],k
assert [r["series"][0][k] for k in init]==[400,120,20]
'
"$BIN" run --config c.json --ticks 500 --out a2.json --quiet 2>/dev/null
chk "determinism: same config/seed/ticks -> identical final, totals, series, state_hash" py '
import json
a=json.load(open("a.json"));b=json.load(open("a2.json"))
assert all(a[k]==b[k] for k in ["final","totals","series","state_hash"])'
"$BIN" run --config c.json --seed 43 --ticks 500 --out a3.json --quiet 2>/dev/null
chk "determinism: different seed -> different state_hash, --seed overrides config" py '
import json
a=json.load(open("a.json"));c=json.load(open("a3.json"));assert a["state_hash"]!=c["state_hash"] and c["seed"]==43'
"$BIN" run --config c.json --ticks 200 --sample-every 7 --out s.json --quiet 2>/dev/null
chk "run: --sample-every K spacing (0,7,...,196,200)" py '
import json;t=[p["tick"] for p in json.load(open("s.json"))["series"]];assert t==list(range(0,200,7))+[200],t'
"$BIN" run --config c.json --ticks 0 --out z.json --quiet 2>/dev/null; rc=$?
chk "run: --ticks 0 exit 0, tick_end=0, one series point" bash -c "[ $rc -eq 0 ] && python3 -I -c 'import json;r=json.load(open(\"z.json\"));assert r[\"tick_end\"]==0 and len(r[\"series\"])==1'"
"$BIN" run --config empty.json --ticks 25 --out e.json --quiet 2>/dev/null; rc=$?
chk "run: all extinct from start still advances exactly N ticks (exit 0)" bash -c "[ $rc -eq 0 ] && python3 -I -c 'import json;r=json.load(open(\"e.json\"));assert r[\"tick_end\"]==25 and r[\"final\"][\"plants\"]==0'"

"$BIN" run --config c.json --ticks 300 --save cp.bin --out A.json --quiet 2>/dev/null; rcA=$?
"$BIN" run --load cp.bin --ticks 200 --out B.json --quiet 2>/dev/null; rcB=$?
"$BIN" run --config c.json --ticks 500 --out U.json --quiet 2>/dev/null
chk "checkpoint: save 300 + load 200 == uninterrupted 500 (final, totals, state_hash); tick_start=300, tick_end=500" bash -c "[ $rcA -eq 0 ] && [ $rcB -eq 0 ] && python3 -I -c '
import json
b=json.load(open(\"B.json\"));u=json.load(open(\"U.json\"))
assert b[\"tick_start\"]==300 and b[\"tick_end\"]==500
assert all(b[k]==u[k] for k in [\"final\",\"totals\",\"state_hash\"])'"

"$BIN" run --config noplants.json --ticks 1500 --sample-every 5 --out np.json --quiet 2>/dev/null
chk "no replenishment: plants=0 -> plants stay 0, herbivores die out, then carnivores; zeros never recover" py '
import json
r=json.load(open("np.json"));s=r["series"]
for k in ["plants","herbivores","carnivores"]:
    z=[i for i,p in enumerate(s) if p[k]==0]
    if z: assert all(p[k]==0 for p in s[z[0]:]),k
assert all(p["plants"]==0 for p in s)
h=[p["tick"] for p in s if p["herbivores"]==0];c=[p["tick"] for p in s if p["carnivores"]==0]
assert h and c and h[0]<=c[0],(h[:1],c[:1])'

errs=0
expect2(){ local n=$1; shift; rm -f nores.json; "$@" >so.txt 2>se.txt; local rc=$?
  if [ $rc -eq 2 ] && [ -s se.txt ] && [ ! -e nores.json ] && [ ! -s so.txt ]; then ok "error: $n -> exit 2, message on stderr, no result file"; else bad "error: $n (rc=$rc)"; fi; }
printf '{"seed":"x","world":{"width":8,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}' > t1.json
printf '{"seed":1,"world":{"width":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}' > t2.json
printf '{"seed":1,"world":{"width":0,"height":8},"initial":{"plants":1,"herbivores":1,"carnivores":1}}' > t3.json
printf '{"seed":1,"world":{"width":8,"height":8},"initial":{"plants":-1,"herbivores":1,"carnivores":1}}' > t4.json
printf '{not json' > t5.json
head -c 100 cp.bin > trunc.bin; cp cp.bin bad.bin; printf 'X' | dd of=bad.bin bs=1 seek=60 conv=notrunc 2>/dev/null
expect2 "wrong type (seed string)" "$BIN" run --config t1.json --ticks 1 --out nores.json
expect2 "missing fixed key (world.height)" "$BIN" run --config t2.json --ticks 1 --out nores.json
expect2 "value out of range (width 0)" "$BIN" run --config t3.json --ticks 1 --out nores.json
expect2 "negative initial count" "$BIN" run --config t4.json --ticks 1 --out nores.json
expect2 "malformed JSON" "$BIN" run --config t5.json --ticks 1 --out nores.json
expect2 "missing config file" "$BIN" run --config nope.json --ticks 1 --out nores.json
expect2 "negative --ticks" "$BIN" run --config c.json --ticks -1 --out nores.json
expect2 "missing --out" "$BIN" run --config c.json --ticks 1
expect2 "unknown option" "$BIN" run --config c.json --ticks 1 --out nores.json --bogus
expect2 "truncated checkpoint" "$BIN" run --load trunc.bin --ticks 1 --out nores.json
expect2 "corrupted checkpoint" "$BIN" run --load bad.bin --ticks 1 --out nores.json
expect2 "missing checkpoint" "$BIN" run --load nope.bin --ticks 1 --out nores.json
expect2 "unknown command" "$BIN" bogus
expect2 "batch without seeds" "$BIN" batch --config c.json --ticks 1 --out-dir .
expect2 "ui bad option" "$BIN" ui --bogus

mkdir bd; "$BIN" batch --config c.json --seeds 1,2,3 --ticks 100 --out-dir bd --quiet >so.txt 2>/dev/null; rc=$?
chk "batch: exit 0, bd/seed-1.json, seed-2.json, seed-3.json (run schema, own seed) and summary.json" bash -c "[ $rc -eq 0 ] && python3 -I -c '
import json
for s in (1,2,3):
    r=json.load(open(\"bd/seed-%d.json\"%s));assert r[\"seed\"]==s and r[\"tick_end\"]==100 and \"state_hash\" in r
json.load(open(\"bd/summary.json\"))'"
chk "batch: seed 2 result equals the single run with --seed 2" bash -c "\"$BIN\" run --config c.json --seed 2 --ticks 100 --out one.json --quiet 2>/dev/null && python3 -I -c '
import json;a=json.load(open(\"one.json\"));b=json.load(open(\"bd/seed-2.json\"));assert a[\"state_hash\"]==b[\"state_hash\"] and a[\"series\"]==b[\"series\"]'"

if [ -f "$ROOT/scenarios/demo.json" ]; then
  "$BIN" run --config "$ROOT/scenarios/demo.json" --ticks 100 --out d.json --quiet 2>/dev/null; rc=$?
  chk "demo: scenarios/demo.json accepted by run (exit 0)" [ $rc -eq 0 ]
  mkdir bd2; "$BIN" batch --config "$ROOT/scenarios/demo.json" --seeds 1,2 --ticks 50 --out-dir bd2 --quiet 2>/dev/null; rc=$?
  chk "demo: accepted by batch (exit 0)" [ $rc -eq 0 ]
else bad "demo: scenarios/demo.json missing"; fi
"$BIN" run --config "$ROOT/examples/contract-example.json" --ticks 50 --out ce.json --quiet 2>/dev/null; chk "section 3 example config accepted" [ $? -eq 0 ]

if [ $UI -eq 1 ]; then
  XV=""; command -v xvfb-run >/dev/null && XV="xvfb-run -a"
  t0=$(date +%s); $XV "$BIN" ui --smoke-test --config c.json >so.txt 2>se.txt; rc=$?; el=$(( $(date +%s)-t0 ))
  chk "ui --smoke-test: exit 0 within 60 s (took ${el}s)" bash -c "[ $rc -eq 0 ] && [ $el -le 60 ]"
  [ -f "$ROOT/scenarios/demo.json" ] && { $XV "$BIN" ui --smoke-test --config "$ROOT/scenarios/demo.json" >/dev/null 2>&1; chk "ui --smoke-test --config scenarios/demo.json: exit 0" [ $? -eq 0 ]; }
  mkdir shots; t0=$(date +%s); $XV "$BIN" ui --screenshots shots --config c.json >so.txt 2>se.txt; rc=$?; el=$(( $(date +%s)-t0 ))
  chk "ui --screenshots: exit 0 within 120 s (took ${el}s), main.png is a PNG >= 1280x720" bash -c "[ $rc -eq 0 ] && [ $el -le 120 ] && python3 -I -c '
import struct
d=open(\"shots/main.png\",\"rb\").read(32);assert d[:8]==b\"\\x89PNG\\r\\n\\x1a\\n\"
w,h=struct.unpack(\">II\",d[16:24]);assert w>=1280 and h>=720,(w,h)'"
  echo "screenshots: $(ls shots | tr '\n' ' ')"
fi
[ $fail -eq 0 ] && echo "ALL CHECKS PASSED ($BIN)" || echo "SOME CHECKS FAILED ($BIN)"
exit $fail

#!/usr/bin/env bash
# Usage: scripts/reliability.sh [SEEDS] [TICKS]   (default 1,2,3 10000)
# 10,000-tick batch runs (exit status, JSON validity, ledger identity) for the section-3 example and the demo scenario.
# Results: experiments/delivery/results/{contract-example,demo}/ ; tables via experiments/delivery/summarize.py
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")/.."
S=${1:-1,2,3}; T=${2:-10000}
for pair in "contract-example:examples/contract-example.json" "demo:scenarios/demo.json"; do
  n=${pair%%:*}; c=${pair#*:}
  start=$(date +%s)
  ./evosim batch --config "$c" --seeds "$S" --ticks "$T" --sample-every 10 --jobs 3 --out-dir "experiments/delivery/results/$n" --quiet
  echo "$n: exit 0, $(( $(date +%s)-start )) s"
done
python3 -I experiments/delivery/summarize.py experiments/delivery/results/contract-example experiments/delivery/results/demo

# Herbivore feeding and behaviour (TASK-014, ADR-0018)

Code: `crates/core/src/herbivore.rs`; tests: `crates/core/tests/herbivore.rs`; sanity run: `cargo run --release -p evosim-core --example herb_sanity [bite_size]`.

## Per herbivore and tick (ascending id)
1. **Running cost** `base_metabolism * traits.metabolism * climate_mult(T)`, always paid (also when standing still). Energy 0 -> Starvation in the Deaths phase.
2. **Climate**: `excess = max(0, |T - temp_comfort| - temp_tolerance) / temp_tolerance`, `climate_mult = 1 + climate_cost * min(excess, 4)` (T = current effective temperature of the cell, so seasons and weather matter). Defaults 18 C / 14 C / 0.5; max factor 3.0.
3. **Perceive** (vision gene, docs/MOVEMENT.md). Candidates = perceived plants with energy > 0.
4. **Satiation**: energy >= `satiation_limit * max_energy` -> no eating, no food seeking, wander.
5. **Decision**: `score = min(bite, plant_energy) * digestion / (1+dist) / (1 + (1-aggression)*other_herbivores_in_plant_cell) / (1 + (1-risk_tolerance)*DANGER_W*danger)`, `danger = sum 1/(1+dist(carnivore, plant))`, `DANGER_W = 4`. Best score wins (ties: nearest, lowest id). Genes: vision, speed, aggression, risk_tolerance, metabolism, max_energy.
6. **Move**: if the target is farther than the feeding reach, walk toward it (speed allowance and cost from docs/MOVEMENT.md); else stay. No target -> `movement::wander`.
7. **Eat**: from ONE plant, the best-scoring one within `FEED_REACH = 1` (own + 8 neighbours, toroidal) of the position after moving. `amount = min(bite, plant.energy, room/digestion)`, `bite = bite_size * (0.5 + aggression)`; plant loses `amount`, herbivore gains `amount * digestion_efficiency` (never more than taken). Plant at energy 0 -> dead (Predation), invisible to later animals the same tick.

## Config (Animal group, shared with carnivores)
New: `bite_size` 4.0, `temp_comfort` 18, `temp_tolerance` 14, `climate_cost` 0.5. Not used yet: `handling_time`, reproduction keys (TASK-016), `strength`/health combat (TASK-015).

## Stats
`Simulation.last_herbivore_stats` (eaten, gained, bites, plants_killed, upkeep_paid, climate_extra_paid, satiated); not in the digest.

## Balance (untuned)
Default config has no balance tuning (TASK-018/027). Sanity (64x64, 1500 plants, 150 herbivores, no carnivores, 1000 ticks): plants and herbivores both gone by tick ~200 (herbivores overgraze; with `bite_size 0` plants settle at ~50-60 without grazing, which shows the plant side is also untuned). tick_bench (128x128): ~1290 ticks/s (before TASK-014: ~985; faster mostly because everything dies).

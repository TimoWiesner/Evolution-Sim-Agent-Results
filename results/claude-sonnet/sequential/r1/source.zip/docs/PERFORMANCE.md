# Performance (TASK-026, ADR-0030)

## Hardware / toolchain
AMD Ryzen 5 7500F (6 cores / 12 threads), 31 GB RAM, Linux, rustc 1.100.0, `--release` (single-threaded simulation).

## Command
```
cargo run --release -p evosim-core --example perf_bench -- [--config examples/perf.json] [--warmup 300] [--ticks 1000] [--repeat 3] [--profile]
```
Defaults: `examples/perf.json` (seed 42, 64x48, 400 plants/120 herbivores/20 carnivores), 300 warm-up ticks, 1000 measured ticks, 3 repeats (median reported). It prints one JSON line with ticks/s per repeat, the median, min/mean/max organisms in the measured window and the final `state_hash`; exit 1 if fewer than 2000 organisms are alive at any measured tick (`--allow-small` disables). `--profile` adds the per-phase share (`Simulation::step_hooked` with timers in the example (core never reads a clock), hash neutral).
In this window 2,304 to 4,337 organisms (mean 3,413) are alive. Herbivores/carnivores are extinct by then (plants only); the early window (`--warmup 0 --ticks 200 --allow-small`, 569-2,220 organisms) is the animal-heavy profile.

## Results (median of 3, ticks per second)
| Setup | Before | After |
|---|---|---|
| Main (warm-up 300, 1000 ticks, ~3,400 organisms) | 1,622 | 2,215 |
| Early / animal-heavy (warm-up 0, 200 ticks, ~1,800 organisms) | 1,166 | 1,280 |

Target >= 100 ticks/s at ~2,000 organisms: **met by 20x** (before and after). `state_hash` is identical before and after for both setups (`0239ee16...`, `da890148...`), so behaviour is unchanged.

## Profile (share of tick time, `--profile`)
| Phase | Main before | Main after | Early before | Early after |
|---|---|---|---|---|
| plants | 86.1% | 81.0% | 39.6% | 33.5% |
| herbivores | 0.2% | 0.2% | 52.6% | 57.9% |
| carnivores | 1.0% | 1.3% | 1.4% | 1.5% |
| deaths | 11.4% | 15.6% | 5.1% | 5.5% |
| births | 1.3% | 1.7% | 1.3% | 1.5% |
| climate/index | ~0.1% | ~0.1% | ~0.1% | ~0.1% |

## Changes (all bit-identical)
1. Plants phase: temperature/precipitation of a cell (a pure function of cell and tick, including cosine seasons and the weather lattice) is computed once per cell per tick instead of once per plant (`plants.rs`).
2. `Organisms::resolve_deaths`: skip the live/dead partition (which moves every organism with its genome) when nobody of that kind died (`organism.rs`).
3. Measurement tooling: `step_hooked`, `perf_bench`.

## Remaining bottleneck
Plants (per-plant `PlantTraits::from_genome` and the genome access) in plant-heavy states, the herbivore phase (vision queries and target scoring) in animal-heavy states, and `resolve_deaths` moving whole organisms when plants die each tick. Not pursued since the target is exceeded 20x and every change risks behaviour drift. No `perf`/valgrind in the container; the profile uses phase timers.

## Regression guard
`crates/core/tests/perf.rs`: 48x32 world, 50 warm-up + 100 ticks, best of 3, asserts >= 15 ticks/s in release (>= 1 in debug; measured ~2,000+, so >100x margin) and that the final `state_hash` equals the golden value (verified equal on the pre-optimisation code).

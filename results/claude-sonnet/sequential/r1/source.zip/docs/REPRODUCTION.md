# Animal reproduction (TASK-016, ADR-0020)

Module `core::reproduction`, called at the start of the Births phase (after Deaths); newborns appear in the same phase.

- **Eligible**: alive, `age >= maturity_age`, `energy >= reproduction_energy`, `cooldown == 0`.
- **Mate**: initiators in ascending id (herbivores, then carnivores) query `mate_range` (Chebyshev, wrapping) for same-kind, other, eligible, not-yet-mated-this-tick animals whose `Genome::distance <= genetics.species_threshold`. Choice: min (cell distance, genetic distance, id). No sexes; animals never mate with themselves. Animals do not walk toward mates (balance: TASK-018).
- **Conception**: p = mean fertility of the pair, one draw. A failed attempt costs nothing; the partner may then initiate itself (so a pair gets up to two attempts/tick). Litter = 1 + Binomial(litter_size-1, p), capped so each parent keeps >= 1 energy.
- **Cost**: each parent pays `0.6 * n * offspring_energy` (total 1.2x; 20% lost), each newborn gets `offspring_energy`. Not affordable: no birth (`blocked_energy`).
- **Cooldown**: both parents get `reproduction_cooldown` (field `Organism.cooldown`, digested); counted down once per tick, so blocked for exactly that many ticks.
- **Offspring**: `Genome::child_of_two` (crossover + mutation), born in the initiator's cell, `parents=[initiator, mate]`, `generation = max+1`.
- Stats: `Simulation.last_reproduction_stats` (`eligible, no_mate, incompatible_seen, conceptions_failed, matings, offspring, energy_paid, energy_to_offspring, blocked_energy`).
- No new config keys. Tests: `crates/core/tests/reproduction.rs` (15).

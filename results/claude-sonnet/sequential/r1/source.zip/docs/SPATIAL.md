# Spatial search (TASK-010, ADR-0014)

`core::spatial::SpatialIndex` finds organisms near a cell on the wrapping grid.

## Interface
- `SpatialIndex::new(grid)`; `insert(id, kind, pos)`, `move_to(id, new_pos)`, `remove(id)`, `clear()`, `rebuild(&Organisms)` (alive organisms only). Errors (`SpatialError::{Duplicate,Unknown,OutOfGrid}`) leave state unchanged; positions must be canonical (in-grid).
- `query(center, radius, Option<Kind>) -> Vec<Hit>`, `query_into(.., &mut Vec<Hit>)`, `count`, `nearest`. `Hit {id, kind, pos, dist}`; `dist` = Chebyshev toroidal distance. Negative radius or off-grid centre -> empty; radius larger than the world just covers it (each cell visited once, so no duplicates).
- Order: ascending `(dist, kind index, id)` — total, independent of insertion order.
- Structure: per-kind, per-cell buckets sorted by id + BTreeMap id->(kind,pos) for lookup (HashMap is banned in core by tests/sim.rs). Derived state: not in digest/checkpoint; wired into `Simulation` since TASK-013 (`Simulation::spatial`, kept incremental; see docs/MOVEMENT.md).

## Measurement (release, `cargo run --release -p evosim-core --example spatial_bench`)
2,000 organisms (3 kinds mixed), 128x128 grid, 20,000 random queries per radius, all kinds; brute force = scan all, filter, sort.

| radius | index | brute force | speedup | hits/query |
|---|---|---|---|---|
| 3 | 4.19 ms | 49.52 ms | 11.8x | 6.0 |
| 5 | 11.19 ms | 53.10 ms | 4.7x | 14.8 |
| 8 | 28.53 ms | 65.57 ms | 2.3x | 35.3 |
| 16 | 110.98 ms | 130.20 ms | 1.2x | 132.9 |

The index wins for the small/medium perception radii animals use; at radius 16 (~13% of the world queried) the gain is only ~1.2x (cost scales with (2r+1)^2 cells). Callers needing huge radii should keep r small. Numbers are machine-dependent; no test asserts timing.

## Tests
`crates/core/tests/spatial.rs`: 3,600 randomized queries vs independent brute force (sizes 1x1, 1xN, Nx1, 2x2, 3x5, 7x7, 10x4, 16x16, 40x30; radii up to 2*max(W,H)+3), randomized insert/move/remove sequences, seams, old-place checks, errors, order/determinism, rebuild from Simulation.

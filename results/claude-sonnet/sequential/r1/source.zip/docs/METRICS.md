# Metrics (TASK-020, ADR-0024)

Per-sample numbers about populations, births/deaths, species, generations and traits, so evolution is visible in numbers.

## Command line
`evosim run --config C --ticks N --out R.json --metrics M.json [--sample-every K]` writes the metrics document to `M.json` (atomic temp+rename; unwritable path, duplicate or valueless `--metrics` = exit 2, no result file). Samples are taken at the same ticks as `series` in the result (`tick_start`, every K, `tick_end`). The result gets two extras: `metrics_file` (path or null) and `totals.deaths_by_cause` (per kind, per cause, cumulative). Recording only reads the simulation: `state_hash` is identical with and without `--metrics` (tests: `crates/core/tests/metrics.rs`, `crates/cli/tests/run.rs`).

Library: `core::metrics::MetricsRecorder::new()`, `record(&Simulation)`, `samples()`, `to_json(seed, tick_start, tick_end, sample_every)`.

## Document
```
{"format":"evosim-metrics","version":1,"seed":S,"tick_start":T0,"tick_end":T1,"sample_every":K,
 "kinds":["plants","herbivores","carnivores"],
 "traits":[speed,strength,fertility,max_health,max_lifespan,max_energy,metabolism,vision,aggression,risk_tolerance],
 "causes":[old_age,starvation,injury,predation,other,climate],
 "samples":[{"tick":T,"plants":KIND,"herbivores":KIND,"carnivores":KIND}, ...]}
```
`KIND` object:

| key | meaning |
|---|---|
| `population` | living organisms |
| `births`, `deaths` | cumulative since tick 0 |
| `births_interval`, `deaths_interval` | since the previous sample (0 for the first sample of a run) |
| `deaths_by_cause` / `deaths_by_cause_interval` | object cause -> count (cumulative / interval); sums equal `deaths` / `deaths_interval` |
| `species` | living species of this kind; `species_ever`: all ever registered |
| `generation_max`, `generation_mean` | over living organisms (founders = generation 0) |
| `mean_energy`, `mean_age` | extra metrics, over living organisms |
| `traits` | object trait -> `{mean, sd, min, max}` over living organisms |

Rules: sd is the population standard deviation `sqrt(sum((x-mean)^2)/n)` (one organism: 0). For an empty kind (`population` 0) every mean/sd/min/max/generation/energy/age value is JSON `null` (never NaN or 0), so extinction is unambiguous. `max_lifespan` is reported as a number. Ledger per kind: `initial + births - deaths = population` (`initial` = `totals.initial` in the result).

Cost: O(population) per sample. Samples are held in memory until the run ends.

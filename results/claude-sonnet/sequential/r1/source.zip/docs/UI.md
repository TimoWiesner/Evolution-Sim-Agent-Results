# User interface (TASK-023, ADR-0027; controls and inspector TASK-024, ADR-0028; setup and charts TASK-025, ADR-0029)

`./evosim ui` starts a local HTTP server (127.0.0.1 only) and a browser page (vanilla JS + canvas, embedded in the binary from `crates/ui/web/`). The engine is the same `core::sim::Simulation` as `evosim run`; a controller thread owns it, wall clock only paces ticks (test `controller_runs_the_same_engine` compares `state_hash` with a plain Simulation).

## Options
`ui [--config FILE] [--port N] [--no-open] [--ticks-per-second T]`, `ui --smoke-test`, `ui --screenshots DIR`. Usage errors / bad config / missing DIR: exit 2. Failed smoke/screenshot check: exit 1. Port: default 8765, falls back to a free port; explicit `--port` that is taken is an error.

## Smoke test and screenshots
Both start the server on a free port, advance the simulation eagerly (10 / 100 ticks), then drive headless `chromium` (`CHROME_BIN`, `PUPPETEER_EXECUTABLE_PATH` or `chromium` on PATH; `--no-sandbox`, temp profile removed). Smoke: the page POSTs `/api/rendered` after its first drawn frame; the command exits 0 once it reports tick >= 10 and frames >= 1 (watchdog 40 s). Screenshots: simulation paused at tick >= 100, `chromium --screenshot` of `/?shot=1` (window 1600x988; headless chromium subtracts ~88 px of window chrome, so the page viewport is 1600x900 and the PNG has a blank dark strip at the bottom: known cosmetic gap). Works without DISPLAY.

## HTTP API
GET `/`, `/app.js`, `/style.css`; `/api/info` (size, seed, biome table with colours/cell counts, kind colours); `/api/terrain` (W*H biome indices then W*H zones); `/api/frame[?since=TICK&run=0|1]` (binary, 204 when unchanged); `/api/state` (JSON tick, populations, state_hash, epoch, speed_level, speed_levels, tps, selected); `/api/inspect` (inspector JSON, 204 when nothing is selected). POST `/api/cmd` and `/api/rendered`. Commands (answered after they took effect: `{"ok","tick","selected","message"}`): `run`, `pause`, `step` (`n`, default 1; pauses, exactly n ticks), `reset`, `speed` (`level` 0..4, clamped, or raw `tps`, clamped to >0.1), `select` (`x`,`y` cell, or `id`; not found = 200 with `ok:false`), `deselect`, `save`/`load` (`path`; failure = 400 and nothing changes). 404/405/400/413/431 for errors. Header cap 16 KiB, body 64 KiB.

## Frame format (little endian, magic "EVF1")
`u32 magic, u64 tick, u8 running, 3 reserved, u32 counts[3] (plants, herbivores, carnivores), u32 n`, then n records of 8 bytes: `u16 x, u16 y, u8 kind (0 plant,1 herbivore,2 carnivore), u8 energy 0..255, u8 age 0..255, u8 species id mod 256`. Plants first, carnivores last (drawn on top). 1,000 organisms = 8 KB.

## World view
Terrain is drawn once into an offscreen canvas (1 px per cell) and scaled by the camera; organisms are drawn per frame, culled to the viewport, with wrap-around tiling. Plants: small green dots; herbivores: blue discs with white ring; carnivores: red diamonds with white ring (colour and shape differ). Brightness = energy. Camera: wheel zoom about the cursor (x1.15, cell size 1..64 px), drag pan, double-click/`0` fit, arrows, `+`/`-`. `window.__evosim` exposes `{frames, lastTick, organisms, fps}`.

## Layout
Header (tick, populations, season placeholder `#s-season`, run state: always visible), world canvas, right sidebar with `#panel-legend`, `#panel-controls`, `#panel-inspector`, and hidden reserved `#panel-params`, `#panel-charts` (TASK-025), status bar.

## Tests
`crates/ui/tests/ui.rs` (frame/terrain encoding, colour distances, controller determinism, pause/step, HTTP API, 1,000 organisms >= 5 distinct ticks in 2 s through HTTP, README, node camera test `web/test/camera.test.js`).


## Controls (TASK-024, ADR-0028)
Logic is in `crates/ui/src/session.rs` (`Session`: pure, no threads/HTTP/display); the controller thread only adds wall-clock pacing and replies. Buttons and keys: Run/Pause (Space), Step (`.`, pauses, exactly one tick), Reset (`r`), speed `-`/`+` (`[`/`]`), Save/Load (`s`/`l`, path field, default `evosim-ui.ckpt` relative to the directory `evosim ui` was started in), Esc deselects. Keys are ignored while a text field has focus.
- **Reset** rebuilds the world from the session configuration (started config, or the one stored in the last loaded checkpoint): same seed => same `state_hash` as the first world. It pauses, clears the selection, keeps the speed level.
- **Speed**: 5 levels, 1/5/20/60/200 ticks per second (default level 3). Indices are clamped, so the speed is never <= 0.
- **Save/Load**: `core::checkpoint` (docs/CHECKPOINT.md), temp file + rename. Load replaces the simulation and the Reset target, pauses, clears the selection and bumps `epoch`, which makes the page re-fetch terrain/info (the size may differ). Errors (missing/corrupt file, directory, empty path) leave everything untouched and are shown in the controls panel.

## Inspector
Click an organism (a click moves < 4 px; larger movement pans). Picking: same cell first, animals before plants, lowest id; an empty cell falls back to Chebyshev radius 1. A pulsing yellow ring marks it; optional "follow with camera" and "show vision range" (square, Chebyshev radius = vision). The panel shows id, kind, species (name, id, parent species), age/lifespan, energy, health with meters, position, generation, birth tick, parents (clickable `#id` when alive, "(dead)" otherwise, "none (founder)"), the 10 traits, and the genome as a table: one row per gene with two allele bars (0..1; white mark = the species reference allele; dashed outline = heterozygous gene) plus numbers. The page re-fetches `/api/inspect` on every new tick, so it follows the organism while running. When the organism is gone the ring turns red and a "DEAD at tick T" banner is shown with the last known values; death cause is shown only if the organism object was still readable, otherwise `unknown` (the Deaths phase removes it). Selection lives in the Session, not in the simulation (hash-neutral, tested).

## Screenshots
`--screenshots DIR` advances to tick 400 and writes `main.png` (world + chart dock), `charts.png` (`?view=charts`, charts fill the main area), `setup.png` (`?view=setup&bad=1`, setup form with two visible field errors) and `inspector.png` (first herbivore, else carnivore, selected, zoom 18, legend hidden). The blank strip at the bottom is still there (headless chromium window chrome; `--headless=old` is not available in this chromium).

## Tests (TASK-024)
`crates/ui/tests/session.rs` (10 tests, no display, no HTTP), `crates/ui/tests/ui.rs` additions (HTTP controls, select/inspect, save/load, page ids, node helper test `web/test/ui.test.js`).


## New world: scenarios and presets (TASK-025, ADR-0029)
Header button "New world..." (key `n`, Esc closes) opens the setup form over the main area. It is built from `Config::param_defs()` (all 95 keys, so docs/CONFIG.md stays the single truth): preset cards (default, lush, harsh, predator-rich, large; descriptions in `experiment::PRESETS`), **Basic** block (seed, world width/height, initial plants/herbivores/carnivores), **Key parameters** (equator temperature, seasonal amplitude, precipitation, resource regeneration, plant growth rate and seed range, herbivore max age, carnivore speed, mutation sigma, species threshold) and collapsible groups with every other parameter. Each field shows its type and range; the focused field shows its description.
- **Start** posts the form values (text) to `POST /api/config/start`. The server validates *every* field (`experiment::build`: whole number / number / true|false, min..max from `param_defs`, UI size guard of 1,000,000 cells and 200,000 initial organisms, then `Config::validate()` cross-field checks mapped to a field). All problems are returned together (`400 {"ok":false,"errors":[{"path","message"}]}`); the page marks the inputs red and writes the message under each field. With any error no command reaches the controller and the running world is untouched. A valid configuration replaces the world (`Session::new_world`: builds first, then swaps; becomes the Reset target; selection and chart history cleared; `epoch` bumped; starts running). Same config => same `state_hash` as `evosim run`.
- **Check** validates without starting. **Export JSON** downloads the form values as `evosim-config.json` (full explicit config, `POST /api/config/export`; `GET /api/config` returns the running world's config). **Import JSON...** reads a file in the browser and sends it to `POST /api/config/import` (strict `Config::from_json`; a wrong key or type is shown with its key path), then fills the form; press Start to run it. Export followed by import yields the same `Config` and byte-identical text (tests). The files also work with `evosim run --config` and `evosim ui --config`.
- Not editable in the form: nothing; all `param_defs` keys are fields. The UI size guard is stricter than the 4,000,000-cell limit of the config file because a huge world would block the single controller thread.

## Charts
`c` or the "Charts" header button toggles the chart dock under the world view. All charts are own canvas code (`web/charts.js`, no library), have a title, x axis label `tick` (or the trait name), y axis label, tick labels, grid and a legend, and are redrawn on new data and on resize. Plants green, herbivores blue, carnivores red (same colours as the world view).
1. Population per kind over time. 2. Births (solid) and deaths (dashed) per sampling interval. 3. Living species per kind. 4. Mean of a selectable trait per kind over time (select; gaps while a kind is extinct). 5. Distribution (24-bin histogram) of a selectable trait (select) of a selectable kind in the current population.
Data: `charts::History` (owned by `Session`, read-only observer, hash-neutral) samples every 5 ticks (plus tick 0); at most 1,000 samples: when exceeded every second sample is merged away and the interval doubles (births/deaths of dropped samples are added to the kept one, totals stay exact). Cleared on new world, reset and checkpoint load (history is not stored in checkpoints). `GET /api/charts` -> `{epoch, interval, n, ticks[], pop|births|deaths|species:{plants,herbivores,carnivores}[], trait_names[], trait_mean:{kind:{trait:[..|null]}}}`, rebuilt by the controller only when the history changed; the page polls at 2 Hz. Histogram: `POST /api/cmd {"cmd":"hist","kind":0..2,"trait":0..9,"bins":2..100}` answers with `{kind,kind_name,trait,name,tick,n,min,max,bins[],edges[]}` (counts sum to the population; all-equal values land in the middle bin of a unit range).

## HTTP additions (TASK-025)
GET `/charts.js`, `/setup.js`, `/api/setup` (params with group/kind/min/max/default/doc, presets with values, current values, limits), `/api/config`, `/api/charts`. POST `/api/config/check|start|export` (body `{"values":{path:text}}`), `/api/config/import` (body = config file text). `hist` command in `/api/cmd`.

## Tests (TASK-025)
`crates/ui/tests/experiment.rs` (9: presets, round trip, per-field errors, cross-field, size guard, no start on invalid, edits change the world), `charts.rs` (6: sampling, decimation, hash neutrality, JSON, histogram), `ui.rs` additions (HTTP setup/start/invalid/export/import, charts + hist, page ids, node helper test `web/test/charts.test.js`). All run without a display.

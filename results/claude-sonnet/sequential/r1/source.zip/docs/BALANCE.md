# Ecosystem balance (TASK-027)

Configuration: CONTRACT section 3 example (`experiments/balance/baseline.json`, 64x48, 400/120/20), 10,000 ticks, `./evosim batch --sample-every 10` (extinction tick has 10-tick resolution). Tuning seeds 101-110, held-out seeds 201-205 (untouched until the final check). Scripts and raw results: `experiments/balance/` (`analyze.py`, `trial.sh`, `heldout.sh`, `results/`).

## Baseline (old defaults, seeds 101-110)
Plants survive in all seeds (~12,260). Herbivores die at 440-2030, carnivores 120-190 ticks later.

| seed | herb. extinct | carn. extinct |
|---|---|---|
|101|500|630|102|560|710|103|1600|1780|104|1740|1930|105|1910|2070|
|106|1630|1800|107|750|900|108|710|890|109|440|620|110|2030|2210|

Coexistence of all three (first extinction): median 1600, mean 1187 ticks, 0/10 reach 10,000. (Raw: `results/baseline.txt`.)

## Cause analysis (written before the first change; metrics of seeds 101 and 103)
- The herbivores die out first, every time; carnivores then starve (13-17 starvation deaths per 100 ticks right after). Plants are never limiting at the first extinction (2,000-4,500 plants).
- Seed 101: herbivores 120 -> 75 -> 61 -> 33 -> 13 -> 0 with 70-85 predation deaths per 100 ticks and only 40-54 births. No starvation among herbivores at all: the cause is predation.
- Seed 103: herbivores boom to ~870 at tick 1000 (starvation 150-500 per 100 ticks, plants crash to 115), then fall to 92 (tick 1300) while carnivores stay at 30-35 and kill 120-150 per 100 ticks; extinct at 1600. Carnivores keep a kill rate set by their own number (~20-35 predators, about one kill per 35 ticks each) and have no feedback from prey scarcity until the prey is gone: nothing gives prey a floor.
- Conclusion: predation without refuge drives the herbivores to zero (overshoot-and-collapse plus predation), carnivores follow.

## Trials (5 tuning seeds 101-105, 3000-4000 ticks; coexistence ticks = first extinction; baseline of these seeds: median 560, mean ~1000)
| id | change | expectation | measured | verdict |
|---|---|---|---|---|
|T1|MECHANISM: prey refuge, `climate.cover_protection` 0.5/0.8/0.95 (cover_fraction 0.15)|herbivores on cover cells survive predator peaks|median 570 / 2430 / 1870 (mean 956/2334/1808)|0.8 helps, 0.5 not|
|T2|cover_fraction 0.3/0.5 x protection 0.8/0.9|more refuge longer survival|0.3/0.8: median 3520 (mean 3308); 0.3/0.9: 1860; 0.5/0.8: 1500; 0.5/0.9: 980|0.3/0.8 best; too much cover starves carnivores first|
|T3|+ herbivores.reproduction_cooldown 20/30|faster prey recovery|median 1880/1810|worse than T2 best|
|T4|+ carnivores.handling_time 30/40|fewer kills|median 1880/2030|worse|
|T5|+ carnivores.base_metabolism 1.1/1.3|predators starve sooner when prey scarce|median 1580/1540|worse|
Results are noisy with 5 seeds; parameter-only trials on top of the refuge did not help, so the search stopped after 5 trial groups (time budget). Not tried for lack of time: carnivore vision-limited detection of covered prey, herbivore flight from depleted cells.

## Chosen defaults
Mechanism: `climate.cover_fraction` 0.3 (was 0.15, unused) and new `climate.cover_protection` 0.8 (ADR-0031). Nothing reads population counts; no spawning. Tuning seeds 101-110, 10,000 ticks (`results/final-tune.txt`): coexistence median 2870, mean 2717 (baseline median 1600 / mean 1187); 0/10 reach 10,000. Carnivores now die first in all 10 seeds (1080-4440); herbivores persist to the end in 7/10 seeds and plants in 9/10 (seed 104: all three extinct).

## Held-out check (seeds 201-205, 10,000 ticks)
| seed | new: herb / carn / coexist | old defaults: herb / carn |
|---|---|---|
|201|2900 / 3090 / 2900|460 / 630|
|202|survived / 3060 / 3060|2090 / 2290|
|203|730 / 870 / 730|1910 / 2090|
|204|survived / 2610 / 2610|2180 / 2360|
|205|3180 / 2530 / 2530|540 / 720|
New: median 2610, mean 2366; old: median 1910, mean 1436. Plants survive everywhere. (`results/heldout-*.txt`.)

## Outcome
Coexistence of all three kinds roughly doubled (mean 1187 -> 2717 on tuning seeds, 1436 -> 2366 on held-out seeds) but the goal (all three for the full 10,000 ticks) is NOT reached: 0/15 runs. Limits: carnivores (starting 20) die out at 1,000-4,500 ticks because with a refuge they overshoot their prey and starve; herbivores often survive without them. Two seeds (203, 109) still lose herbivores early (tick ~730-890). Only ten tuning/five held-out seeds, so differences between single parameter trials are within noise.

## Regression values re-recorded
State-hash golden (`tests/state_hash.rs`) and perf behaviour hash (`tests/perf.rs`): defaults changed on purpose. `tests/carnivore.rs` helper config sets `cover_protection = 0` (unit tests assume no refuge).

## Performance (TASK-026 target >=100 ticks/s at ~2000 organisms)
`cargo run --release -p evosim-core --example perf_bench`: median 299.8 ticks/s, organisms min 137 / mean 1806 / max 3399 (the window now contains fewer animals so the bench reports min < 2000 and exits non-zero without `--allow-small`; the speed is above the target; before TASK-027: 2,215 ticks/s at ~3,400 organisms with a different population mix, not directly comparable). Long runs with surviving populations are slower (10-seed 10k batch ~6 min vs 25 s at baseline, because the animals live on).

# Command line: `evosim run` (TASK-019, ADR-0023)

```
evosim run (--config FILE [--seed N] | --load FILE) --ticks N --out FILE [--sample-every K] [--save FILE] [--metrics FILE] [--quiet]
```
- `--ticks`, `--out` and exactly one of `--config` / `--load` are required. `--flag value` and `--flag=value` both work; duplicate flags, unknown flags, positional arguments, negative or non-numeric `--ticks`, `--sample-every 0`, non-integer `--seed` are errors.
- `--seed` overrides the seed of the configuration. `--ticks 0` is valid. Exactly N ticks are simulated even if everything is extinct.
- `--metrics FILE`: also write the metrics document (docs/METRICS.md, TASK-020); extras `metrics_file`, `totals.deaths_by_cause` in the result.
- `--quiet`: no summary line on stderr (extra flag, ours).
- `--save FILE`: checkpoint after the last tick (before the result is written, atomic); `--load FILE`: continue a checkpoint (`--config`/`--seed` not allowed with it; `tick_start` = checkpoint tick, `totals` cumulative). Format and rules: docs/CHECKPOINT.md, ADR-0026. Invalid checkpoint -> exit 2, no result.
- Exit status: 0 success; 2 for every error (usage, configuration, unwritable output, internal invariant). Message on stderr prefixed `evosim: `; stdout is always empty; the output file is written through `OUT.tmp.<pid>` + rename, so an error never creates or changes `OUT`.

## Result keys
CONTRACT keys: `contract, seed, tick_start, tick_end, world, final{plants,herbivores,carnivores,species{}}, totals{births,deaths}, series, state_hash, elapsed_seconds, ticks_per_second`.
Extras: `totals.initial` (founders per kind), `config_hash` (SHA-256 of the canonical config JSON), `sample_every`, `ticks_simulated`, `species_ever` (species ever recorded per kind), and per series point `species_plants/herbivores/carnivores` (living species).
`series` ticks: `tick_start`, every K ticks, `tick_end`, no duplicates; default K = max(1, N/100). `ticks_per_second` is 0 when N = 0 or elapsed is 0.

## state_hash
SHA-256 (in-house, `core::hash`), 64 lowercase hex chars, over a canonical little-endian byte stream: tag/version, tick, acc, RNG words, then length-prefixed sections: weather, all organisms (every field incl. genome alleles, traits, counters, next id), species registry, resource stocks + capacity, climate map (temp, precip, elevation, latitude warmth, zone, biome), then grid size and the canonical configuration JSON. Floats are hashed as bit patterns. `Simulation::digest()` (FNV-1a 64) remains the fast regression digest.
Tests: `crates/core/tests/state_hash.rs` perturbs each state part on a clone and asserts the hash changes; a golden value pins the format (regenerate when simulation semantics change on purpose).

## Tests
`crates/runner/src/args.rs` (parser, series), `crates/cli/tests/run.rs` (end-to-end: determinism twice with the same seed, schema, ledger, `--ticks 0`, extinction, no plants, 19 error cases without result file, `DISPLAY` removed).

## `evosim batch` (TASK-021, ADR-0025)

```
evosim batch --config FILE --seeds 1,2,5..8 --ticks N --out-dir DIR \
    [--param PATH=V1,V2,...]... [--sample-every K] [--jobs J] [--quiet]
```

- `--seeds`: comma list of integers and inclusive ranges `A..B`; no duplicates.
- `--param` (repeatable): sweep one configuration key (dotted path from docs/CONFIG.md, typed int/float/bool, range-checked, `seed` not allowed). Several `--param` give the cartesian product; first `--param` varies slowest, seeds innermost. Every point is validated before anything runs.
- `--jobs J`: worker threads (default: CPU count). Results do not depend on `J`.
- Output: without `--param` `DIR/seed-<seed>.json`; with it `DIR/<path=value[_path=value]>/seed-<seed>.json`. Each seed file is exactly what `evosim run` writes for the same effective configuration. Plus `DIR/summary.json`, `DIR/summary.csv` (one row per run; last two columns are timings), `DIR/aggregates.csv` (one row per parameter point and kind).
- `summary.json`: `config_hash`, `ticks`, `seeds`, `sweep`, `run_count`, `runs[]` (index, seed, params, label, file, ticks, tick_start/end, final, species, extinct, first_zero_tick (sample resolution; null if never zero), births, deaths, state_hash, timings), `aggregate` and `groups[]` (per parameter point) with `runs`, `final.{kind}.{mean,min,max,sd,median}`, `extinct_count`, `extinct_fraction`, `species_mean`, `all_kinds_alive`; top-level `elapsed_seconds`.
- Reproducibility: same inputs give identical `summary.json`/CSV except `elapsed_seconds` and `ticks_per_second` keys/columns.
- Errors (bad arguments, config, sweep values, unwritable dir) exit 2 with no summary; seed files of already finished runs may remain.

## ui
`evosim ui [--config FILE] [--port N] [--no-open] [--ticks-per-second T] | --smoke-test | --screenshots DIR`: see docs/UI.md. Exit 2 on usage errors, 1 when a smoke/screenshot check fails.

# Architecture ledger

Status: skeleton (TASK-002) + config/json modules (TASK-003, see docs/CONFIG.md) implemented: crates core + cli exist; others still planned. Decisions: `docs/decisions/ADR-0001..0007` (0007: config + in-house `core::json`).

## Technology
Rust Cargo workspace (ADR-0001); local browser UI served by the Rust binary with embedded vanilla-JS/canvas assets (ADR-0002); cell-bucket spatial index on the world grid (ADR-0003); real-valued diploid gene vectors + frozen-centroid species rule (ADR-0004); in-house xoshiro256++ and fixed phase/id ordering for determinism (ADR-0005).

## Planned crates / modules (dependency arrows: A -> B means A may depend on B)
| Module (crate) | Responsibility |
|---|---|
| `evosim-core` (`crates/core`) | The simulation. No I/O, no UI, no wall clock, no network. Sub-modules below. |
| `core::rng` | xoshiro256++/SplitMix64, serializable state. |
| `core::config` | Config structs, defaults, presets, validation (JSON; optional TOML), error type -> exit code 2. |
| `core::climate` | Latitudinal temperature/precipitation fields, seasons, weather, torus-continuous (periodic in x; latitude profile symmetric/periodic in y so the seam is smooth). Documented topology compromise. |
| `core::genome` | Gene layout, inheritance, mutation, genetic distance, species registry. |
| `core::grid` | Toroidal geometry (ADR-0008): `Grid`, `Pos`, `Delta`, wrap, shortest delta, Chebyshev `dist`, `cells_within` (no duplicates, any radius). Implemented. |
| `core::world` | Grid, per-cell resources, cell index buckets (ADR-0003), toroidal geometry helpers. |
| `core::organisms` | Plants, herbivores, carnivores: arenas, traits, energy, lifespan, behaviours. |
| `core::checkpoint` | Savegames (TASK-022, ADR-0026, docs/CHECKPOINT.md): byte Writer/Reader, container (magic, version, length, SHA-256), `Simulation::to_checkpoint/from_checkpoint`; `write_state/read_state` sit next to private fields in world/organism/species/genome. Runner: `run --save/--load`. |
| `core::sim` | Tick scheduler (fixed phase order), births/deaths bookkeeping, event/stat counters. |
| `core::stats` | Per-sample metrics: populations, births/deaths, species counts, gene means/distributions, generation depth. |
| `core::state` | Canonical serialization, checkpoint save/load, state hash. |
| `evosim-runner` (`crates/runner`) | Headless run/batch: result JSON, series sampling, multi-seed summary, timing. `batch.rs`: sweeps (`--param`), scoped worker threads writing index-ordered slots, summary.json/CSV (ADR-0025). Depends on core. |
| `evosim-ui` (`crates/ui`) | HTTP server, controller thread, snapshot encoding, embedded `web/` assets, smoke-test/screenshot driver (chromium). Depends on core, runner (for shared stats). |
| `web/` | Static frontend (HTML/JS/CSS): map canvas, pan/zoom, controls, parameter editor, inspector, charts. Talks only to the HTTP API. |
| `evosim-cli` (`crates/cli`) | `evosim` binary: arg parsing, `version/run/batch/ui`, exit codes (0 ok, 2 usage/config/checkpoint). Depends on runner, ui. |

Dependency rule: `cli -> {runner, ui} -> core`; `core` depends on nothing project-internal outside itself (only serde at most). `web/` is not Rust and never links to the core. Reverse dependencies (core -> ui/runner/cli) are forbidden.

## Root files and layout
- `setup.sh` (installs rust deps/`cargo fetch`, builds release, checks chromium; idempotent), `evosim` (shell launcher exec'ing `target/release/evosim`, building if missing), `build.sh` (release build, copy to `dist/evosim`).
- `scenarios/demo.json`, presets in `core::config` (also exported to `scenarios/`), `tests/` (integration/regression), `README.md`.

## Data ownership and flow
Simulation state is owned by `core::sim::Simulation`; one writer. Runner owns it in-process; UI controller thread owns it and publishes immutable snapshots to HTTP handlers. Index structures are derived and rebuilt, not serialized. Clock = integer tick counter; seasons derive from tick.

## Testing layout
`cargo test --release` : unit tests per module, property tests (spatial vs brute force, genome bounds, config validation), integration tests (CLI contract: determinism, checkpoint equivalence, no replenishment, error exit 2), regression golden hashes, multi-thousand-tick runs, HTTP API tests. `scripts/contract_check.sh` runs CONTRACT checks against `./evosim` and `dist/evosim`.

## Open items for later tasks
Exact gene list, energy model constants, climate formulas, checkpoint format (binary vs JSON), TOML/YAML choice (JSON mandatory).

## Tick scheduler (implemented in TASK-005, ADR-0009)
`core::rng` (xoshiro256++, exportable state), `core::world` (World{grid}), `core::sim` (Simulation{config,world,rng,tick}; `step()` = one tick; phases Climate, Plants, Herbivores, Carnivores, Deaths, Births, Index in `Phase::ORDER`; organisms act in ascending id, ties -> lowest id then row-major cell). Core has no dependencies.

## Climate (TASK-006, ADR-0010)
`core::climate` implemented: `ClimateMap` (temp, precip, elevation, zone, biome per cell) stored in `World::climate`, mirrored-double-hemisphere latitude profile, wrapping seeded noise; see docs/CLIMATE.md. Inspect with `cargo run -q --release -p evosim-core --example biome_map -- W H SEED [--json]`. Time variation (seasons, weather) is TASK-007.

## Organisms (TASK-008, ADR-0012, implemented; see docs/ORGANISMS.md)
`core::organism`: per-kind id-sorted arenas, shared Traits/ranges, clamped energy/health, deferred deaths/births resolved in Deaths then Births phases, cumulative `LifeStats`. Traits are derived from each organism's `core::genome::Genome` (TASK-009, docs/GENOME.md).

## Spatial index (TASK-010)
`core::spatial::SpatialIndex`: incremental per-kind cell buckets, query ordered by (dist, kind, id); derived state, rebuilt via `rebuild(&Organisms)`. See docs/SPATIAL.md, ADR-0014.

## Plants (TASK-011, ADR-0015, implemented)
`core::plants` (Plants phase: regen, growth, upkeep, stress) + `World::resources/resource_cap` (per-cell fertility stock, the only plant energy source; in the digest). See docs/PLANTS.md.

## Plant reproduction (TASK-012, ADR-0016, implemented)
Inside the Plants phase after each plant's growth: eligible plants pick a wrapped ring target (`plants::seed_target`), pass room/resource/climate checks, pay `reproduction_cost` and queue a `NewBorn` (parent id, generation+1) resolved in the same tick's Births phase. The Plants phase now takes the sim RNG. See docs/PLANTS.md.

## Animal movement (TASK-013, ADR-0017, implemented)
`core::movement` (perception through the now-wired `Simulation::spatial`, speed credit, shortest wrapped path, sprint-superlinear cost, correlated-random-walk wandering, cell-sharing rule). See docs/MOVEMENT.md.

## Herbivore phase (TASK-014)
`herbivore::run_herbivore_phase(&World, &mut Organisms, &mut SpatialIndex, &Config, tick, &mut Rng) -> HerbivoreStats` runs in the Herbivores phase (Carnivores still use `movement::run_animal_phase`). Plant energy is stored in plant organisms, so no world mutation is needed. See docs/HERBIVORES.md, ADR-0018.

## core::carnivore (TASK-015)
Carnivores phase: upkeep, handling-time rest, prey choice by energy/(1+dist)*p, one attack per tick from own/adjacent cell, exactly-once kill via `mark_dead(Predation)`. See docs/CARNIVORES.md and ADR-0019.

## core::reproduction (TASK-016)
Births phase start: eligibility (mature, fed, cooldown 0), mate search via SpatialIndex within `mate_range`, compatibility = genetic distance <= `genetics.species_threshold`, conception/litter from fertility, both parents pay, `Genome::child_of_two`, `queue_birth` (records both parents + generation). See docs/REPRODUCTION.md and ADR-0020.

## core::species (TASK-017, planned, ADR-0021)
`SpeciesRegistry` (records with parent/arose/extinct, frozen reference genome, deterministic names) owned by `Simulation`; updated at the end of the Births phase; `Organism.species`. See docs/SPECIES.md.

## Species (TASK-017)
`core::species::SpeciesRegistry` (owned by `Simulation.species`, digested, no RNG use): records with parent/arose/extinct, frozen reference genome; classification in the Births phase every `genetics.species_check_interval` ticks, extinction swept each Births phase. See docs/SPECIES.md and ADR-0021.

## Ecology integration (TASK-018)
Tick order is the contract in `Phase::ORDER` (climate, plants, herbivores, carnivores, deaths, births+species, index); see docs/ECOLOGY.md and ADR-0022. `Simulation::ledger_check` verifies `founded + births - deaths == living` per kind. `core::ecology::run_survival` / example `survival` produce the per-seed, per-kind extinction report. `plants.graze_reserve` is the grazing refuge.

`core::metrics::MetricsRecorder` (TASK-020, ADR-0024): read-only per-sample statistics; `evosim run --metrics FILE` writes it. See docs/METRICS.md.

## UI crate (TASK-023)
`crates/ui` (`evosim-ui`): web UI backend (controller thread owning the Simulation, std HTTP server, binary frames, chromium driver) and embedded page `crates/ui/web`. Setup/validation/import-export logic is `experiment.rs`, chart history and histograms `charts.rs` (both pure, display-free tests); the page draws charts with own canvas code (`web/charts.js`, `web/setup.js`). See docs/UI.md, ADR-0027..0029.

## Delivery and verification (TASK-028)
No engine change. Verification layer: `scripts/verify_contract.sh [BIN] [--ui]` (every CONTRACT item against any binary, from a temp cwd), `scripts/reliability.sh` (10,000-tick batches), `crates/core/tests/invariants.rs` (seeded random configurations, per-tick invariants), `crates/cli/tests/demo.rs`; `./test.sh` is the one test command. Delivery content: `scenarios/demo.json`, `examples/contract-example.json` (CONTRACT section 3 verbatim), `experiments/delivery/` (demo search, 10k results, `summarize.py`), `docs/VERIFICATION.md` (evidence), `docs/AUDIT.md` (requirement audit), `README.md`.

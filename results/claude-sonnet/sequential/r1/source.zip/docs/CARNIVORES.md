# Carnivores (TASK-015, ADR-0019)

Code: `crates/core/src/carnivore.rs`; tests: `crates/core/tests/carnivore.rs`.

Per carnivore, ascending id, in the Carnivores phase:
1. Pay upkeep `base_metabolism * metabolism * climate_mult` (same climate rule as herbivores); energy 0 -> Starvation (no prey = starves).
2. If `rest > 0`: decrement, do nothing else (no hunting, no moving).
3. If energy >= `satiation_limit * max_energy`: wander, no hunt.
4. Perceive; pick the active herbivore maximising `prey.energy / (1+dist) * attack_probability` (ties: nearest, lowest id). None: wander.
5. Walk toward it (normal speed allowance and move cost) unless within `ATTACK_REACH = 1` (Chebyshev, toroidal). If after moving dist <= 1: ONE attack.
6. Attack: pay `attack_cost * metabolism` (hit or miss; no attack at 0 energy), roll one `rng.next_f64() < p`.
   `p = clamp(A/(A+D), 0.02, 0.95)`, `A=(1+str)(1+speed)(0.5+aggression)` (carnivore), `D=2(1+str)(1+speed)(0.5+0.5*health/max_health)` (herbivore). Default matchup p ~ 0.58.
7. Kill: `mark_dead(Predation)` must return true (exactly-once guard); prey energy is zeroed; carnivore gains `min(prey_energy*digestion, room)` (<= prey energy) and gets `rest = handling_time`. Escape: nothing happens to the prey.
8. Several carnivores on one prey: ascending id; the first success kills and eats everything; later ones no longer see the dead prey and retarget; after failures the prey stays attackable (each pays, each rolls).

Stats: `Simulation.last_carnivore_stats` (`CarnivoreStats`, not digested). `Organism.rest` is digested. New key `carnivores.attack_cost` (default 1.5; base 0.5). Herbivores do not flee. Balance is untuned (TASK-018/027).

# Self-audit against docs/PROJECT.md (TASK-028)

Status per requirement: **met**, **partly met**, **missing**. Evidence = test, document or recorded command (`docs/VERIFICATION.md` holds the command outputs). Written from the state of the code, not from intent.

| # | Requirement (docs/PROJECT.md) | Status | Evidence / limitation |
|---|---|---|---|
| 1 | Finite toroidal grid, cell-by-cell animal movement | met | `core::grid` (ADR-0008), `core::movement`; tests/grid.rs, movement.rs, invariants.rs (wrap-aware step length) |
| 2 | Wrap-aware perception and spatial lookup | met | `core::spatial` (ADR-0014, brute-force reference test in tests/spatial.rs); degenerate 1xN worlds in tests/invariants.rs |
| 3 | User-configurable dimensions and initial populations | met | `world.*`, `initial.*`; UI setup form, JSON config (docs/CONFIG.md) |
| 4 | Climate with latitudinal zones, smooth seam, temperature and precipitation | met | `core::climate` (docs/CLIMATE.md); seam proof with negative control in tests/climate.rs |
| 5 | Seasons and weather vary over ticks and affect entities | met | ADR-0011, tests/weather.rs; plants take stress damage, animals pay climate-dependent upkeep |
| 6 | Explain world-topology compromise | met | docs/CLIMATE.md and README "Topology compromise": a torus has no poles, so the latitude profile is mirrored (warm in the middle, cold at the top/bottom edge which join smoothly) |
| 7 | Plants consume environmental resources, grow, reproduce, mutate, form species | met | docs/PLANTS.md, tests/plants.rs, plant_repro.rs, species.rs. Asexual seeding only; no pollination (allowed: "asexual and/or pollination") |
| 8 | Herbivores eat plants, carnivores eat herbivores | met | tests/herbivore.rs, carnivore.rs |
| 9 | Traits: speed, strength, health, fertility, genetic behaviour (aggression/risk) | met | `core::genome` (10 genes, ADR-0013), docs/GENOME.md |
| 10 | Lifespan, energy, nutrition, costs, reproduction controls, simplified but coherent | met | ledger check (`Simulation::ledger_check`, energy has documented sources only); docs/ECOLOGY.md. Simplified, not calibrated against real biology |
| 11 | Two-parent sexual reproduction, inherited DNA, mutations | met | `core::reproduction`, tests/reproduction.rs, genome.rs |
| 12 | Emergent species by an explicit stable criterion | met | `core::species` (ADR-0021: frozen reference genome, genetic distance threshold); tests/species.rs |
| 13 | No forced anti-extinction | met | no code reads population counts; zero stays zero (tests/ecology.rs, invariants.rs, scripts/verify_contract.sh). Only mechanism added for coexistence is a local refuge (prey cover, ADR-0031) |
| 14 | Long coexistence of plants, herbivores and carnivores (the goal) | **partly met** | measured in README / docs/VERIFICATION.md: 10,000 ticks of all three kinds is NOT reached in the measured runs; plants usually survive, carnivores usually die first |
| 15 | Population 1,000-5,000 entities | met | default and demo runs hold ~2,000-8,000 organisms (series in experiments/delivery/results); can be configured lower/higher |
| 16 | >= 100 ticks/s at 2,000 entities on disclosed hardware | met (one machine) | docs/PERFORMANCE.md (perf_bench: ~300 ticks/s at ~1,800 organisms, 12-core container); not verified on other hardware. Runs with large surviving animal populations are slower (see VERIFICATION.md for ticks/s) |
| 17 | Same engine for headless CLI and UI | met | UI controller steps the same `Simulation`; tests/ui.rs, crates/ui/tests/session.rs |
| 18 | UI: climate-coloured map, entity differentiation, pan/zoom, run/pause/reset/step, speed, inspect | met | docs/UI.md; screenshots via `ui --screenshots` (known cosmetic gap: blank strip at the bottom of the headless screenshot) |
| 19 | Edit initial parameters in UI, presets, JSON import/export, seed control | met | setup form (ADR-0029); JSON only (no TOML/YAML, which the brief makes optional) |
| 20 | Save/load full state with DNA, RNG, climate | met | `core::checkpoint` (ADR-0026), tests/checkpoint.rs, randomised round trip in tests/invariants.rs |
| 21 | Headless multi-seed and parameter batch with comparative statistics | met | `evosim batch` (ADR-0025): summary.json with per-group mean/min/max/sd/median, CSV |
| 22 | Visualisation: population, births/deaths, diversity, genetic means/distributions, generation trends | partly met | five live charts (population, births/deaths, species, mean trait, trait distribution). Generation depth is shown in the inspector and in `--metrics` output (generation max/mean) but has no dedicated chart |
| 23 | Unit, integration, regression, property-based and multi-thousand-tick tests | met | `./test.sh`: unit + integration + state-hash goldens (tests/state_hash.rs) + randomised invariants (tests/invariants.rs; EVOSIM_FUZZ_SEEDS) + 1,000-tick ecology tests. "Property-based" is implemented as seeded randomised tests, not with a property-testing crate (no third-party crates) |
| 24 | Seed-based repeatability | met | verify_contract.sh, tests/invariants.rs, tests/sim.rs |
| 25 | ADRs for language, spatial structure, DNA | met | docs/decisions/ADR-0001..0031 |
| 26 | Extinction mechanisms: only allowed, local, population-blind ones | met | ADR-0031 (cover refuge, a per-cell property), graze reserve, regenerating cell resource, satiation, handling time, density limits |

## Known limitations (stated openly)
- **Coexistence goal not reached:** see README/VERIFICATION.md tables; the measured median is a few thousand ticks, not 10,000. Typical failure: carnivores overshoot their prey and starve; sometimes herbivores die first.
- Topology compromise (mirrored latitude bands on a torus) means there is no pole-to-pole gradient and no oceans/land masses.
- Death cause shown in the inspector is often `unknown` (the organism is removed in the Deaths phase before the UI reads it); the metrics file has exact causes.
- Plants have only asexual seeding; no pollination.
- JSON is the only config format. No generation-trend chart.
- Performance numbers are from this container only. Runs where animals survive 10,000 ticks take minutes.
- `dist/evosim` supports `run`, `batch` and `ui` but `ui --smoke-test/--screenshots` are only verified for `./evosim`; both need `chromium` on the machine for the browser part (as allowed by CONTRACT section 2).
- Coexistence results come from 3-5 seeds per configuration, so they are noisy.

# ADR-0024: Metrics recorder and metrics file

Status: accepted (TASK-020 plan)

## Context
TASK-020 needs per-sample-tick numbers (population, births/deaths, deaths by cause, living species, trait mean/spread per kind, generation max/mean), a command-line way to write them, a documented format, no influence on the simulation, and hand-verifiable tests. All cumulative counters already exist (`Organisms.stats`: founded, births, deaths, deaths_by_cause; `Simulation.species`; `Organism.generation`, `.traits`).

## Decisions
1. **Module `core::metrics`** (pure, no I/O, no clock, no RNG). `MetricsRecorder::new(&Simulation)` and `record(&mut self, &Simulation)` take `&Simulation` (read-only), so recording cannot change state; `state_hash` equality with/without recording is also tested. Core stays I/O-free; the runner writes the file.
2. **Sample ticks = the `series` ticks** (tick_start, every K, tick_end; same `series_ticks`), so `--sample-every` governs both. Recording happens between ticks, next to `sample()`.
3. **Per kind (plants, herbivores, carnivores) per sample**: `population`; `births`/`deaths` = cumulative since tick 0 and `births_interval`/`deaths_interval` = since the previous sample (0 for the first sample of a run; derived by subtracting stored previous cumulative counters); `deaths_by_cause` (all 6 causes, names from `DeathCause::name`) cumulative and interval; `species` (living species, `Simulation::living_species`); `generation` {max, mean}; `traits` for each of the 10 traits (speed, strength, fertility, max_health, max_lifespan, max_energy, metabolism, vision, aggression, risk_tolerance): {mean, sd, min, max}. Extra metrics (our choice): `mean_energy`, `mean_age`, `species_ever` (registry size per kind), `mean_genetic_diversity` is NOT included (cost O(n^2)).
4. **Statistics**: mean = sum/n; sd = population standard deviation sqrt(sum((x-mean)^2)/n) (two-pass over the kind's id-sorted Vec, so the result is deterministic and exact for hand checks); empty kind: `count`=0 and all mean/sd/min/max/generation values are JSON `null` (not NaN, not 0), so extinction is visible and not confused with a real zero. Single organism: sd = 0.
5. **Generation** = `Organism.generation` of living organisms (founders 0).
6. **File**: new option `evosim run ... --metrics FILE` writing one JSON document (same atomic temp+rename writer, probed for writability up-front, exit 2 on errors, no file on error). JSON because the project already has a JSON writer, tooling reads it, and TASK-021/025 reuse it. Not written unless requested (no cost otherwise). The result JSON also gets a small extra key `metrics_file` (path or null) and, always, `deaths_by_cause` under `totals` (cheap, totals only). The full series is not inlined into the result (size).
7. **Layout** (documented in `docs/METRICS.md`): `{"format":"evosim-metrics","version":1,"seed","tick_start","tick_end","sample_every","kinds":["plants","herbivores","carnivores"],"traits":[names],"causes":[names],"samples":[{"tick":T,"plants":{...},"herbivores":{...},"carnivores":{...}}]}`. Row-per-sample (array of objects) keeps ticks ascending and is easy to stream/plot. Every number is integer or float via `json::format_float`.
8. **No influence on simulation**: recorder holds only its own previous counters; `Simulation` is not modified by it, and no sim code calls it. Test: same config/seed/ticks run with and without `--metrics` (and via the library with a recorder) gives identical `state_hash`.

## Alternatives rejected
CSV (nested per-trait columns, nulls awkward); recording inside `Simulation::step` (couples sim to observation, risks hash change, costs when unused); storing metrics in the checkpoint (TASK-022 concern).

## Consequences
O(population) per sample; with default K = N/100 this is ~100 passes per run, negligible. A later checkpoint-load run (TASK-022) starts with fresh `interval` baselines: first sample reports interval 0 and cumulative from the loaded counters.

# ADR-0018: Herbivore feeding, metabolism and decision rule (TASK-014)

Status: Accepted (planned in TASK-014 PLAN; implemented in TASK-014 IMPLEMENT)

## Context
TASK-013 gave animals sensing and movement, but animals only lose energy by moving and nothing is eaten. Herbivores must live off plants, pay running costs, feel the climate and act according to heritable behavioural genes. Hunting (TASK-015) and reproduction (TASK-016) are out of scope.

## Decisions
1. **Module** `core::herbivore` (`crates/core/src/herbivore.rs`): `run_herbivore_phase(world, orgs, spatial, cfg, rng) -> HerbivoreStats`, called by the Herbivores phase instead of `movement::run_animal_phase` (Carnivores keep it until TASK-015). Reuses `movement::{perceive, step_allowance, move_toward, wander}` (the wander branch of `run_animal_phase` is factored into a pub fn `wander`, `apply_path` becomes `pub(crate)`). The phase takes `&World` for climate (temperature) and `&mut World` is NOT needed: plant energy lives in the plant organisms.
2. **Per animal, ascending id, fixed order**: (a) pay running cost, (b) perceive, (c) choose target, (d) move (movement allowance and cost unchanged), (e) eat.
3. **Running cost** per tick: `base_metabolism * traits.metabolism * climate_mult`, taken with `add_energy(-cost)` (clamped at 0). Death at energy 0 is the existing Deaths-phase starvation rule. The cost is paid even when the animal does not move.
4. **Climate consequence**: `excess = max(0, |T - temp_comfort| - temp_tolerance) / temp_tolerance`, `climate_mult = 1 + climate_cost * min(excess, 4)`, T = `World::temp_at(pos)` (current season/weather). Comfort band is a config constant (no gene) so selection acts through `metabolism`/`max_energy`; extreme cold or heat makes the idle cost up to `1 + 4*climate_cost` times higher. New Animal keys (shared by carnivores, used by them from TASK-015): `temp_comfort` (18 C), `temp_tolerance` (14 C), `climate_cost` (0.5), plus `bite_size` (below).
5. **Feeding reach** = own cell and the 8 adjacent cells (Chebyshev distance <= 1, toroidal, so it wraps over edges); code constant `FEED_REACH = 1`. Plants farther away are never eaten, they are only perceived (vision) and walked toward.
6. **Bite**: per tick one herbivore eats from ONE plant (the best-scoring plant within reach, same score as in 7, restricted to dist <= 1). `amount = min(bite, plant.energy, room/digestion)` with `bite = herbivores.bite_size * (0.5 + aggression)`, `room = max_energy - energy`. The plant loses exactly `amount` (`add_energy(-amount)`); the herbivore gains `amount * digestion_efficiency` (<= amount; never more than taken, test asserts). A plant whose energy reaches 0 is `mark_dead(.., Predation)` (eaten) immediately, later animals in the same tick no longer see it. Plants in a cell are served in the order animals act (ascending id), so a cell can be stripped but plants regrow from their cell stock.
7. **Decision rule** (food vs danger vs crowding, heritable): candidate = every active perceived plant with energy > 0. `value = min(bite, plant.energy) * digestion_efficiency`, `score = value / (1 + dist) / (1 + (1 - aggression) * others_in_cell) / (1 + (1 - risk_tolerance) * DANGER_W * danger)`, with `others_in_cell` = other herbivores perceived in the plant's cell, `danger = sum over perceived carnivores of 1/(1 + chebyshev(carnivore, plant cell))`, `DANGER_W = 4`. Highest score wins, ties by (dist, id) = first in the hit order (strict `>`). Genes: `vision` (what is seen), `speed` (reach per tick), `aggression` (bigger bites, tolerates competitors), `risk_tolerance` (accepts food near carnivores), `metabolism`/`max_energy` (cost/capacity). Danger sensing is perception only; being attacked is TASK-015.
8. **Satiation**: an animal with `energy >= satiation_limit * max_energy` neither eats nor seeks food; it wanders (spreads grazing pressure and saves nothing but cannot overeat). Below the limit it seeks food.
9. **Nothing worthwhile visible** -> `movement::wander` (correlated random walk, unchanged).
10. `handling_time` stays unused (no per-animal state added; no digest field change). Keys not used yet are listed in docs/HERBIVORES.md.
11. **Statistics** `HerbivoreStats {eaten_energy, gained_energy, bites, plants_killed, upkeep_paid, climate_extra_paid, satiated}` kept in `Simulation.last_herbivore_stats` (not in the digest, like plant stats).
12. **No new RNG streams**: only `wander` draws (sim RNG, ascending id). Digest changes (behaviour), no golden constants exist.

## Consequences
Config gains 4 Animal keys (CONFIG.md regenerated; doc-sync test). Tests in tests/movement.rs that use herbivores must set `herbivores.base_metabolism = 0`, `bite_size = 1e-6` (so targets still count, eating negligible) or use carnivores. Idle metabolism is charged for herbivores only until TASK-015 does the same for carnivores.

## Alternatives rejected
Eating whole plants (stripping, no regrowth); eating from several plants per tick (hides the bite limit); a fixed comfort band by gene (more genes = layout change in ADR-0013); random choice among plants (not gene-driven).

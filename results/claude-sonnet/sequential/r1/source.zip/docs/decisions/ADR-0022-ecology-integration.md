# ADR-0022: Ecology integration, extinction and default balance (TASK-018)

Status: accepted (IMPLEMENT cycle 1). Implemented: ledger_check, ecology::run_survival, example survival, new key plants.graze_reserve (root reserve refuge), retuned defaults; results in docs/ECOLOGY.md.

## Tick order (fixed; already `Phase::ORDER`, now documented as the contract)
1. **Climate**: season + weather advance (RNG).
2. **Plants**: regen of cell stocks, growth, upkeep, stress, plant seeding (seeds queued).
3. **Herbivores**: upkeep, movement, eating plants (plants hit energy 0 -> marked dead, cause Predation).
4. **Carnivores**: upkeep, hunting; kills are marked dead.
5. **Deaths**: old age/starvation/climate/predation resolved; dead removed from arenas and spatial index.
6. **Births**: reproduction (animals, mate search) queues newborns; plant seeds + animal births resolved; **species updates** (classify every `species_check_interval`, extinction sweep every tick).
7. **Index**: debug consistency check.
Rationale: resources before consumers; prey eat before predators hunt (a herbivore that has just eaten is a richer target); all deaths are resolved at one point so the per-kind ledger is exact; births come after deaths so a newborn never dies in the tick it is born and can't be eaten in the tick it appears; species are updated last on the final population of the tick.

## Extinction is final
No code path creates organisms except `Organisms::populate` (tick 0) and `resolve_births` (queued by plant seeding / animal reproduction, which require a living parent). Tests prove it by (a) source-level test: only those callers of `queue_birth`/`push` exist (grep-style test over `crates/core/src`), (b) behaviour: a kind at 0 stays 0 for N ticks with any other kind alive.

## Ledger invariant
`founded[k] + births[k] - deaths[k] == count(k)` after every tick, checked via `Organisms::stats` (cumulative) against arena sizes; new `Simulation::ledger_check() -> Result<(),String>` (also per-tick `last_births/last_deaths` consistency).

## Stabilising mechanisms relied on (all local, none look at counts)
Cell fertility stock that regenerates to a cap (plants are resource-limited, density-capped by `cell_capacity`); herbivore limited bite + satiation + movement away from depleted cells; carnivore success p=A/(A+D), handling-time rest, attack cost, vision-limited search (prey must be found), `cover_fraction` refuges; climate zones give uneven world so grazed patches recover elsewhere; reproduction cooldown and energy thresholds. No new global rules. Tuning is by constants only (see plan for levers).

## Default balance
Measured before tuning (default config 64x48, 400/120/20, seed 42): plants alone shrink 400 -> ~12 by tick 675 and then recover slowly (not self-sustaining quickly); with 120 herbivores plants are extinct by tick ~150 and herbivores starve; carnivores follow. Defaults (`Config::default()`, thus the benchmark's fixed-key-only config) must be retuned by IMPLEMENT: plants first (self-sustaining alone), then herbivores (several hundred ticks with plants), then carnivores. Changing defaults requires regenerating docs/CONFIG.md and fixing any test that relies on the old numbers. Coexistence of all three for 10,000 ticks is NOT required in this task (TASK-027).

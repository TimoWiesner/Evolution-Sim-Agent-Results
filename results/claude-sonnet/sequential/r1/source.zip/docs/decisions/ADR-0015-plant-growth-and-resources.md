# ADR-0015: Plant growth and cell resources (TASK-011)

Status: accepted; implemented in TASK-011 IMPLEMENT cycle 1 (docs/PLANTS.md). Deviation: `water_factor` lives in `world.rs`; digest includes resource stocks.

## Context
Plants must live off their cell's environment (temperature, water), compete for limited resources, age and die, with genome-derived traits affecting growth/tolerance. No energy may appear without a source. Reproduction (TASK-012) and being eaten (TASK-014) are out of scope but must plug in later.

## Decision
**Resource model = one "fertility" stock per cell** (simplification of light+water+nutrients), `World::resources: Vec<f64>`, row-major, with a static per-cell cap `World::resource_cap`.
- Cap (climate-set, static): `cap = climate.resource_max * W(P_base, need_ref)` with `W(P,n)=clamp(P/n,0,1)`, `P_base` = annual-mean precipitation of the cell, `n_ref = plants.water_need`. Static so the cap never destroys stock when weather changes.
- Regeneration, the ONLY external energy source (stands for sunlight/water/nutrient influx): each tick, every cell `stock = min(cap, stock + climate.resource_regen * W(P_now, n_ref))` (current precip, so seasons/weather matter). No RNG. Initial stock = cap.
- Plants take energy ONLY by removing the same amount from their cell's stock. Gain 1:1 (conversion efficiency 1; losses happen through upkeep).

**Per-plant growth (Plants phase, ascending id, deterministic):** with the cell's current `T = world.temp_at`, `P = world.precip_at`:
- `fT = max(0, 1 - ((T - T_opt_i)/tol_i)^2)`  (zero outside optimum +- tol_i)
- `fW = clamp(P / need_i, 0, 1)`
- `crowd = min(1, plants.cell_capacity / n_plants_in_cell)` (shading; n counted at phase start)
- `want = growth_rate * fT * fW * crowd * size_scale_i * breadth_i`
- `take = min(want, resource_uptake, stock[cell], (max_energy_i - energy)`)`; stock -= take; energy += take.
- Upkeep: `energy -= maintenance * metabolism_i * drought_cost_i` each tick (never below 0; starvation by the existing Deaths-phase rule when energy hits 0).
- Because competition is by id order on a finite stock, plants in one cell share (older/lower ids first), growth is bounded by regen: sum of plant gain per cell per tick <= regen_cell + stock drawdown. Logistic-like carrying capacity.

**Hostile climate:** if `fT == 0` or `fW < stress_water_floor` (const 0.1) the plant takes `plants.stress_damage * max_health` health that tick; otherwise heals `0.02*max_health`(const `STRESS_HEAL`). Health 0 -> `mark_dead(id, DeathCause::Climate)`. New append-only cause `Climate` (N_CAUSES 5 -> 6, name "climate"). Old age = existing `max_lifespan` (from plants.max_age via genome) in Deaths phase; lack of energy = existing Starvation rule.

**Traits (no genome layout change):** ADR-0013 genes Speed/Vision/Aggression/RiskTolerance are fixed to 0 for plants, so their locus values are reused (documented in GENOME.md) through `plants::PlantTraits::from_genome(&Genome, &Config)` (pure, computed on demand, not stored):
- Aggression locus g_a -> `T_opt_i = temp_optimum + (g_a-0.5)*2*THERMAL_SHIFT` (THERMAL_SHIFT = 10 deg C): cold- vs warm-adapted.
- RiskTolerance locus g_r -> `tol_i = temp_tolerance * scale_factor(g_r)` (0.25x..4x); trade-off `breadth_i = sqrt(temp_tolerance/tol_i)` (specialists peak higher, generalists survive more climates).
- Vision locus g_v -> `need_i = water_need * scale_factor(g_v)`; drought-tolerant (small need) pays `drought_cost_i = 1 + 0.5*(1 - min(1, need_i/water_need))`.
- Existing trait mapping stays: `max_energy` (reserve size; also `size_scale_i = sqrt(max_energy_i/baseline)`), `metabolism` (upkeep), `max_lifespan`, `max_health` (stress resilience).
Mutation/inheritance already handles all of these (TASK-012 will call it).

**New config keys:** `plants.maintenance` (energy/tick, default 0.1; must be < growth_rate*... documented), `plants.stress_damage` (fraction of max_health per hostile tick, default 0.05). `docs/CONFIG.md` regenerated. Existing keys used: `plants.growth_rate/resource_uptake/water_need/temp_optimum/temp_tolerance/cell_capacity/max_age/max_energy/initial_energy`, `climate.resource_regen/resource_max`.

**Determinism:** Plants phase draws no RNG itself (the existing placeholder per-phase draw in `sim.rs` is untouched). Resources enter the digest (`World::state_words`). Per-cell counts use a reusable Vec indexed by cell, never a hash map.

## Alternatives rejected
- Separate light/water/nutrient fields: more state and tuning for no testable gain now.
- Stock cap following current weather: would delete energy when the weather dries.
- New genes: changes genome layout/digests/ADR-0013 tests; reuse of unused plant loci is free.

## Consequences
TASK-012 reproduces by spending `energy` (reproduction_cost) and places seedlings; TASK-014 grazing removes plant energy (not cell stock) and plants regrow from cell stock. Energy accounting is testable: `sum(plant gain) == sum(stock removed)`.

## Verification
tests/plants.rs (see tasks/TASK-011/handoffs/plan-cycle1.md).

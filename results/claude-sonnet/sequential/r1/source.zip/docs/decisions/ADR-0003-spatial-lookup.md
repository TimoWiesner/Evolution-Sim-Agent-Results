# ADR-0003: Neighbour search on the wrapping grid

Status: Accepted (TASK-001)

## Context
Animals perceive prey, mates, predators and food within a radius (a few cells) on a W x H torus; W,H >= 1 (including 1xN and tiny grids where wrapped neighbours coincide). 2,000-5,000 entities; 100+ ticks/s. Results must be independent of hash ordering.

## Alternatives
1. **k-d tree / quadtree**: rebuilt each tick, torus handling awkward (ghost copies), allocation heavy.
2. **Hash map of cell -> list**: simple but unordered iteration threatens determinism and is slower than arrays.
3. **Uniform grid = the world grid itself, with per-cell buckets in flat arrays** (chosen). Cell size = 1 world cell; the world is already a grid, so no separate structure is required.
4. Brute force O(n^2): ~4M-25M pair checks/tick, too slow at target.

## Decision
Per kind (plants, herbivores, carnivores) a **cell-indexed bucket structure**: `cell_head[idx]`/`next[]` intrusive linked lists, or CSR (counting sort: `cell_start[idx]`, `items[]`) rebuilt per tick in O(n + cells), items within a cell ordered by ascending organism id (counting sort is stable over id-ordered storage). Cell index = `y*W + x`. Plants additionally have at most one plant per cell *or* a small per-cell list (decided in the plant task) which also gives density-dependent growth for free.

Wrap: coordinates reduced via `rem_euclid`; a radius-r query iterates dy,dx in [-r,r] in fixed row-major order, wraps each, and **deduplicates when 2r+1 exceeds W or H** (clamp the span to the dimension so each cell is visited once). Distance uses toroidal delta `min(|d|, W-|d|)`; ties broken by organism id. Queries return organisms in deterministic order (row-major scan offset, then id). Radius is limited by a genome-derived perception cap (e.g. <=8) to bound cost.

## Consequences
- Performance: O(n * (2r+1)^2) with tiny constants, cache-friendly; rebuild is linear.
- Testability: property tests compare against brute-force toroidal search on random positions/sizes (incl. 1xN, radius > dimension); seam tests for entities at x=0/W-1.
- No dependency; trivially serialisable (index is derived, not saved; rebuilt on load, which keeps checkpoints simple and equal).
- Dist: pure in-core data structure, no files or libraries, so nothing extra ships in `dist/`.
- Verification: brute-force comparison property tests (above) plus the seam/tiny-grid cases; benchmark at 2,000 entities recorded in STATE.md once the engine exists.

# ADR-0011: Seasons and weather (TASK-007)

Status: accepted (plan). Extends `core::climate` (ADR-0010). Effects on organisms are NOT part of this task.

## Decision
Effective climate of cell `p` at tick `t` = base map (annual mean, TASK-006) + seasonal term (pure function of `t mod season_length`, row warmth) + weather term (state carried between ticks).

### Seasons
- `phase = 2*pi * (t mod L) / L`, `L = climate.season_length` (integer modulo first, so tick `t` and `t+L` give bit-identical values). Tick 0 = midwinter (coldest), mid-year = midsummer.
- Temperature: `T = T_base + A * k_T(s) * (-cos(phase))`, `A = seasonal_amplitude`, `s` = row warmth from `climate::warmth`. `k_T(s) = 0.25 + 0.75*(1-s)`: small swing in the tropics (0.25 A), full swing at the poles. Depends only on `s`, so it is seam-continuous and hemisphere-symmetric. No hemisphere phase offset (opposite seasons would put a phase jump on the y-seam; ADR-0010 mirrored double hemisphere).
- Precipitation: `P = P_base * (1 + a_P * k_P(s) * (-cos(phase - 2*pi*0.125)))`, `a_P` = new key `climate.seasonal_precip_amplitude` (default 0.3, range 0..0.95), `k_P(s) = 0.3 + 0.7*s` (monsoon-like wet/dry seasons strongest in tropics/dry zones, weak at the poles); wet peak lags the warm peak by 1/8 year.
- Mean over a full year equals the base value (cos integrates to 0, factors are linear in the cos term), so biomes (classified from base annual means) stay valid.

### Weather
- Coarse wrapping lattice (`nx = max(1,round(W/8))`, `ny` likewise, same dims rule as terrain noise) holding two anomaly fields `aT`, `aP`, each in `[-WEATHER_CLAMP, WEATHER_CLAMP]` (= +-2, unit-variance-ish). Cell value = smoothstep bilinear interpolation of nodes with wrap in x and y, so weather is spatially smooth and seam-free.
- Each tick (Climate phase) every node evolves as AR(1): `a <- phi*a + sqrt(1-phi^2)*z`, `phi = exp(-1/weather_period)`, `z` = (sum of 4 uniforms - 2)/sqrt(1/3) (approx N(0,1), only + - * / sqrt exp, no ln/cos). Result clamped to +-2. At tick 0 the state is drawn stationary (`a = z`).
- Draws come from the simulation RNG (`Simulation::rng`), a fixed number per tick (`2*nx*ny*4`) regardless of `weather_noise`, so switching weather off or changing strength does not shift the RNG stream seen by later phases. "Weather off" = `weather_noise == 0` (its contribution is exactly 0).
- Temperature deviation `weather_noise * WEATHER_TEMP_SCALE(=6 deg C) * aT_interp`; precipitation factor `1 + weather_noise * 0.5 * aP_interp` (>= 0 since |a|<=2 and noise<=1).
- Weather state (`nodes`, and the tick it describes) lives in `World::weather`, is part of the state digest, and exposes `state_words()/from_state_words()` (f64 bit patterns) for the later checkpoint task.

### Bounds (documented, enforced by clamp)
`ClimateBounds::from_config(cfg)`:
- `temp_min = pole_temp - ELEV_COOLING - A - 12*weather_noise`, `temp_max = equator_temp + ELEV_COOLING + A + 12*weather_noise`.
- `precip_min = 0`, `precip_max = precip_mean*(1+precip_latitude_variation)*(1+terrain_noise/2)*(1+a_P)*(1+weather_noise)`.
Query results are clamped to these; tests show clamping is never needed beyond float noise (value before clamp inside bounds).

### Queries
`World::temp_at(Pos)`, `World::precip_at(Pos)` (current tick of the climate state); `ClimateMap::seasonal_temp_at(pos,tick)` / `seasonal_precip_at(pos,tick)` (weather-free, any tick, pure); `World::climate_tick()`. Invariant: `world.weather.tick` is the tick whose Climate phase last ran; before the first step it is 0 with zero anomalies. Climate phase at tick t sets weather tick to t and then evolves the nodes, so all later phases of tick t see tick t's climate.

## Alternatives rejected
- Per-cell independent noise each tick: not smooth, O(cells) RNG draws.
- Separate RNG stream for weather: task says weather comes from the simulation generator.
- Opposite-hemisphere seasons: phase jump at the y-seam.
- Precomputing all-cell current fields each tick: O(cells) per tick for something only some consumers read; compute on demand (a bulk `fill_current` helper can be added for the UI).

## Consequences
New config key `climate.seasonal_precip_amplitude` (docs/CONFIG.md regenerate). Climate phase now consumes real RNG draws, so `tests/sim.rs` digest/trace expectations may change; `Simulation::digest` feeds weather state. Per-tick cost ~O(nodes).

# ADR-0014: Spatial index (implements ADR-0003)

Status: Accepted (implemented in TASK-010)

## Decision
`core::spatial::SpatialIndex` — incremental cell-bucket index on the world grid (cell size 1, as ADR-0003).
- Storage: per kind, `cells: Vec<Vec<Id>>` indexed by `Grid::index(pos)`; each bucket kept sorted ascending by id (insert by binary search; ids are mostly appended so it is O(1) typical). Plus `loc: BTreeMap<Id,(Kind,Pos)>` (HashMap banned in core source by tests/sim.rs; amended in TASK-010).
- Mutations: `insert(id,kind,pos)`, `move_to(id,new_pos)`, `remove(id)`, `clear()`, `rebuild(&Organisms)` (Index phase / after load; skips dead). Duplicate insert, unknown id, or out-of-grid pos -> `Err(SpatialError)` (no panic, no state change). Positions are wrapped through the grid on entry? No: out-of-grid is an error (callers hold canonical positions).
- Queries (all `&self`, allocation only for the result):
  - `query(center, radius, kind: Option<Kind>) -> Vec<Hit>`; `query_into(.., &mut Vec<Hit>)` reuses a buffer; `count(..)`; `nearest(center, radius, kind) -> Option<Hit>`.
  - `Hit { id, kind, pos, dist }`, `dist` = Chebyshev toroidal distance (ADR-0008).
  - Radius is i64 clamped to [0, max(W,H)] (anything larger covers the world). Negative -> empty.
- Algorithm: iterate the clamped span of cells with `Grid::for_each_cell_within` (each cell once even if 2r+1 > W or H, so no duplicates), collect bucket entries of the requested kind(s), then sort by `(dist, kind index, id)`. This order is total, independent of scan order, and also what a brute force can reproduce. (Refines ADR-0003's "scan offset then id": nearest-first is more useful for behaviour and equally deterministic.)
- Big radius fast path: if the span covers >= the whole grid, iterate all cells (still dedup'd) – or equivalently iterate all stored entries; chosen: iterate stored entries per kind (O(n)) when `count_within(r) >= cell_count`.
- The index is derived state, not in digest/checkpoint; Simulation does not use it for behaviour in this task (TASK-013+). Optionally Simulation gets a `spatial` field rebuilt in the Index phase — NOT in this task unless trivial; decided: do not touch sim.rs (keeps digests stable).

## Rejected
Hash cell->list (unordered), k-d/quadtree (torus ghosts), per-tick CSR only (no incremental API required by the task: add/move/remove).

# ADR-0004: Genome design, inheritance, mutation, species rule

Status: Accepted (TASK-001)

## Context
Plants need DNA, mutation, speciation (asexual and/or pollination). Animals need two-parent sexual reproduction, heritable behavioural tendencies, mutation, emergent species via an explicit stable criterion. State must serialize and hash exactly. No forced anti-extinction.

## Alternatives
1. **Bit-string/nucleotide DNA with a genotype->phenotype decoder**: biologically flavoured, but decoding is costly and hard to reason about/test; weak control of trait ranges.
2. **Neural-network genome (evolved weights)**: rich behaviour, but expensive, hard to test and hard to keep stable ecologically.
3. **Fixed-length vector of real-valued genes (diploid-style)** (chosen): each gene locus has two alleles (f32 in [0,1]); phenotype trait = mean of alleles mapped to a trait range. Plants use the same layout but a single haploid set (clonal) plus pollination recombination where applicable.

## Decision
- Representation: `Genome { alleles: [[f32;2]; N_GENES] }` for animals (diploid), `[f32; N_PLANT_GENES]` per parent-set for plants. Genes are indexed by an enum (animals: speed, strength, max_health, fertility, lifespan, metabolism, size/body-mass, perception, aggression, risk_aversion, mate_choosiness, satiation threshold, cover/refuge use, migration tendency, ...; plants: growth rate, seed range, resource uptake, drought/cold tolerance (optimal temperature and precipitation), height/cover, lifespan, reproduction threshold). Exact list is finalised in the entity tasks, extension by appending only.
- Inheritance: animals - each parent contributes one allele per locus chosen by RNG (free recombination, optional linkage groups later); offspring seeded from the two parents' streams in id order. Plants: asexual = copy; pollination = recombine with a neighbouring plant of compatible species within a radius.
- Mutation: per allele with probability `mut_rate`, add a Gaussian-ish perturbation (sum of uniforms, no `exp/ln`), clamp to [0,1]; rare larger jumps. Rates configurable and themselves not evolving initially.
- Species criterion (explicit, stable): each organism stores `species_id`. Species have a **founder centroid** (mean phenotype vector of the founders, frozen at creation, plus an updating running mean for display). A newborn joins the species of its parent(s) (for animals the mother's species) if the weighted genetic distance (L1 mean over trait genes, torus-independent) to that species' centroid is <= `species_threshold`; otherwise it is assigned to the nearest existing species of its kind within the threshold, else founds a new species with a new monotonically increasing id. Animals additionally require mate-compatibility: distance between parents <= `mate_threshold`, giving reproductive isolation that makes the split stable. A species is alive while it has living members; ids are never reused. Species counts in the result JSON are the number of ids with >=1 living member. Centroid is frozen (not drifting) to avoid chaining/oscillating labels; the rule uses no population counts.
- Serialization: genes as f32 bit patterns (hex or little-endian bytes) so checkpoints are bit-exact; the state hash walks organisms in id order.

## Consequences
- Performance: fixed-size arrays, no allocation per organism; distance is ~16 flops.
- Testability: inheritance (child allele is from a parent), mutation bounds, species assignment determinism and id stability, save/load round trip are all unit-/property-testable; the model is simple to document and visualise (gene means/distributions per tick for charts).
- Dist: no external data files.

# ADR-0002: UI technology

Status: Accepted (TASK-001)

## Context
Same engine for UI and headless; required features: climate-colored map, entity differentiation, pan/zoom, run/pause/reset/step, speed, inspector, parameter editing, presets, config import/export, save/load, charts. `evosim ui --smoke-test` and `--screenshots DIR` (>=1280x720 `main.png`) must work in the container and screenshots must come from the real UI. Container provides `chromium` (headless) and `xvfb-run`.

## Alternatives
1. **Native desktop (egui/eframe or SDL/winit)**: single process, no browser; but heavy crates, needs GL/X11 libs at setup, screenshots under Xvfb require capture hacks, software-rendering fragility, harder to test.
2. **Python Tk/Qt over a Rust core**: second language and FFI; packaging problems.
3. **Local browser UI** (chosen): Rust binary serves an embedded static HTML/JS/Canvas app on 127.0.0.1 and a small JSON/binary HTTP API; the browser is the display.
4. Electron/Tauri: heavy downloads, no benefit over plain chromium.

## Decision
Local web UI. `evosim ui` starts an HTTP server on 127.0.0.1 (port chosen free by default, `--port` optional), prints the URL to stderr, and opens no browser automatically unless a display/browser is found (non-fatal). Frontend: dependency-free vanilla JS + `<canvas>` (map rendered from a compact binary snapshot endpoint; charts drawn on canvas), assets embedded into the binary with `include_str!`/`include_bytes!` so `dist/` stays one file and works offline. The simulation runs in a Rust thread owned by a controller; HTTP handlers send commands (run/pause/step/reset/speed/load/save/config) over a channel and read the latest snapshot. UI never mutates engine state directly.

`--smoke-test`: start server, create world, step >=10 ticks via the controller, spawn headless `chromium` against the URL (with `--virtual-time-budget`/remote-debugging as needed) to confirm a frame render (page posts "frame rendered" to the server), shut down, exit 0. `--screenshots DIR`: same flow, advance >=100 ticks, then drive chromium (`--screenshot`, 1600x900 window, optionally via DevTools protocol over a websocket-less approach: separate URLs/hash routes select view such as `#chart`, `#inspect`) to write `main.png` and extras. Falls back to exit 0 only if screenshots were actually written; otherwise non-zero.

## Consequences
- Performance: rendering is client-side; only a ~W*H-byte-ish snapshot + entity list is sent per frame; throttled to ~30 fps.
- Testability: HTTP API testable with plain `cargo test` integration tests (no browser); a browser test via headless chromium in the smoke test.
- Distribution: no extra files; chromium is only required for screenshots/smoke-test (present in benchmark container), not for headless commands. Runs on `dist/evosim` too.
- Risk: chromium flags (`--no-sandbox` as root) must be handled; mitigated by using `CHROME_BIN` env and documented flags. Chromium missing -> smoke test falls back to the server-side checks and reports a clear error for screenshots.

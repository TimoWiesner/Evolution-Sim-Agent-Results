# ADR-0030: Performance measurement and optimisation (TASK-026)

Status: accepted (IMPLEMENT cycle 1)

## Context
Baseline measured in PLAN (AMD Ryzen 5 7500F, 12 threads, 31 GB, release build, `evosim run`): `examples/minimal.json` (seed 42, 64x48) runs at ~1,340 ticks/s over 1,500 ticks (organisms 500 -> ~4,700, herbivores extinct); ~2,750 organisms ran at ~360 ticks/s in a run that kept herbivores/carnivores alive. The target (>=100 ticks/s at ~2,000 organisms) is already met by a wide margin, so the work is: measurement tool, profile, targeted optimisations of the top phases only if safe, and a regression guard.

## Decisions
1. **Measurement command**: example `crates/core/examples/perf_bench.rs` (no change to the binding CLI contract):
   `cargo run --release -p evosim-core --example perf_bench -- [--config FILE] [--warmup N=300] [--ticks N=1000] [--repeat R=3] [--profile]`.
   Default config = `examples/perf.json` (fixed seed 42, 64x48, 400/120/20 founders (verified: >= 2,000 organisms from tick ~150, plants only after herbivores die out); chosen so >= 2,000 organisms are alive during the whole measured window; the tool prints min/mean/max organisms in the window and fails with exit 1 if the minimum is < 2,000 unless `--allow-small`). Prints one JSON line (ticks/s per repeat, median, organisms, state_hash at end) so before/after can be compared and behaviour equality checked by the hash.
2. **Profile**: `Simulation::step_profiled(&mut self, &mut PhaseTimes)` (new, additive, hash-neutral; `step` unchanged semantically) accumulates wall time per `Phase`; `--profile` prints the share per phase. No `perf` in the container; if sub-phase detail is needed, temporary Instant counters inside the top phase (not committed) or a documented sampling via `valgrind` is not available -> use counters.
3. **Optimisation rule**: behaviour must be bit-identical: the golden `state_hash` / digest tests and checkpoint tests are the oracle; additionally record `state_hash` after warm-up+ticks before and after and require equality. Candidate list (choose by profile, top-down): avoid per-tick allocations (Vec/HashMap in phases, `act_order`, query result buffers in SpatialIndex), replace BTreeMap/HashMap lookups by id with index maps, cache per-organism derived values, avoid cloning genomes, species classification interval cost (genome distance), `state_hash`/digest are not on the hot path. No RNG-order changes, no float reassociation that changes results, no new deps, no threads (determinism).
4. **Guard test**: `crates/core/tests/perf.rs`: builds a 48x32 config (~1,500+ organisms), 50 warm-up + 100 measured ticks, asserts ticks/s >= 15 in release (>= 1 in debug via `cfg!(debug_assertions)`), i.e. >10x below the measured speed; also asserts the digest equals a golden recorded value for the same run (so a "speedup" that changes behaviour fails). Uses best of 3 to reduce noise.
5. **Report**: `docs/PERFORMANCE.md` with hardware (`lscpu`, `nproc`, memory, rustc), command, before/after table (median of 3), profile table before and after, what was changed, remaining bottleneck, and the target verdict.

## Amendment (IMPLEMENT)
`step_profiled(&mut PhaseTimes)` became `step_hooked(&mut dyn FnMut(Phase, bool))`: the core test `no_wall_clock_or_global_rng` forbids `Instant` in `crates/core/src`, so timing lives in the example. Implemented optimisations: per-tick per-cell climate cache in the Plants phase; `resolve_deaths` skips the partition when nobody died. Results in docs/PERFORMANCE.md.

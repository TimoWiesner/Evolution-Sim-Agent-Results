# ADR-0016: Plant reproduction and dispersal (TASK-012)

Status: accepted, implemented (TASK-012 IMPLEMENT cycle 1).

## Decisions
1. **Asexual (clonal seed) reproduction only.** Child genome = `Genome::child_of_one(parent, Mutation::for_kind(Plant), rng)` (copy + mutation). Pollination is not modelled; `plants.pollination_range` stays a valid but unused key (documented as reserved in PLANTS.md/CONFIG description). Why: simplest model that satisfies "inherit with mutation", keeps one parent id (`parents=[pid,0]`), and sexual plants would need partner search with extra spatial cost. Revisit in a later task if diversity is too low.
2. **Where it runs:** in the Plants phase, after growth/upkeep/stress of each plant (ascending id). Offspring are queued with `Organisms::queue_birth` and materialise in the Births phase of the same tick (so parent id + generation = parent+1 are recorded by existing machinery). Parent must be active and not climate-dead this tick.
3. **Eligibility:** `energy >= max(plants.reproduction_threshold, plants.reproduction_cost)`. Cost is deducted from the parent only when an offspring is actually queued (a blocked attempt is free, nothing is created or lost).
4. **Energy conservation:** parent pays `reproduction_cost`; child starts with `cost * SEED_ENERGY_FRACTION` (const 0.5, remainder is seed overhead lost to the environment). Never creates energy. Child energy is clamped by Organism::new.
5. **Dispersal pattern:** one attempt per eligible plant per tick; distance `r = 1 + floor(R * u^2)` (u uniform [0,1), R = `plants.seed_range`; R = 0 -> own cell), clipped to R; heavy near-parent bias with a long tail so empty regions are occasionally recolonised. Target = uniform cell on the Chebyshev ring of radius r (8r cells; offset index mapped deterministically), wrapped with `Grid::wrap`; all distances are `Grid::dist` so edge wrapping is correct. Own cell allowed only when R = 0.
6. **Establishment (no room / no resources -> no offspring):** target cell must (a) hold fewer than `plants.cell_capacity` plants counting live plants plus births already queued this tick, (b) have fertility stock >= new key `plants.establish_resource` (default 1.0; range 0..=10000), (c) be survivable for the child genome: temp_factor > 0 and water factor >= STRESS_WATER_FLOOR. Otherwise the attempt fails, nothing is spent, a stat counter is incremented (`blocked_room/resource/climate`).
7. **Randomness:** the Plants phase takes `&mut Rng` (sim RNG, ADR-0009). Draws happen only for eligible plants, so a world with 0 plants draws nothing there. Fixed draw order per attempt: u (distance), ring index, mutation draws.
8. **Plants only come from plants:** the only code path creating `Kind::Plant` after `populate` is this reproduction (parents[0] must be a live plant; `queue_birth` rejects parent id 0). No seed bank / immigration. Seed bank deliberately not implemented (optional ecology idea).
9. Fertility trait/loci unchanged (no new genes).

## Consequences
Digests of runs with plants change (new RNG draws, new births); tests that pin digests/counts for plant populations need re-checking. New config key `plants.establish_resource`; regenerate docs/CONFIG.md.

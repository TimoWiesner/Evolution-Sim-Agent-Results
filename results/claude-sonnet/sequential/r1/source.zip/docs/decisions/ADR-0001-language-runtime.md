# ADR-0001: Language and runtime of the simulation core

Status: Accepted (TASK-001)

## Context
The core must run >=100 ticks/s at 2,000 entities, be bit-deterministic, support full-state save/load and state hashing, be shared by the headless CLI and the UI, and ship in a self-contained `dist/` that runs on a plain Ubuntu 24.04 x86-64 host without runtimes (CONTRACT §6). Container has Rust (cargo 1.100), Python 3.12, Node 18.

## Alternatives
1. **Python 3 (+NumPy)**: fastest to write; but per-organism logic with branching is slow (likely <20 ticks/s at 2,000 entities), NumPy vectorization complicates deterministic ordered conflict resolution; `dist/` needs PyInstaller-style bundling (large, fragile).
2. **Node/TypeScript**: decent JIT speed, same code could run in browser; but determinism of floats is fine, bundling needs `pkg`/SEA (fragile on Node 18), memory layout control is weak, typed-array SoA is awkward.
3. **Rust** (chosen).
4. Mixed Python core + Rust hot loops: two toolchains, FFI/packaging cost, no benefit.

## Decision
Simulation core, CLI, batch runner and local web server are written in **Rust** (stable, edition 2021), one Cargo workspace, `--release` with `lto`, `codegen-units=1`, `panic=abort` not required. Dependencies are kept minimal (serde/serde_json for config/state, optionally `tiny_http`-class server; the RNG, hashing and spatial code are written in-house so no dependency can change the random stream). Cargo.lock is committed; `setup.sh` runs `cargo build --release --locked`.

## Consequences
- Performance: native, SoA/arena storage, expected several hundred to thousands of ticks/s at 2,000 entities; headroom for 5,000.
- Testability: `cargo test` for unit, integration, regression (golden hashes), property tests (`proptest` as dev-dependency, or in-house seeded generators if offline), multi-thousand-tick tests in release profile.
- Distribution: `cargo build --release` yields one statically-reasonable binary (glibc dynamic only, available on Ubuntu 24.04). `./build.sh` copies it to `dist/evosim` with embedded UI assets (see ADR-0002); no runtime needed.
- Costs: slower iteration/compile times; mitigated by keeping the workspace small. Network required only for `setup.sh`/`build.sh` crate download (permitted); `./evosim` works offline.
- Floating point: only IEEE basic ops (+,-,*,/,sqrt) in state-affecting code; transcendental functions (exp/sin/pow) avoided or implemented in-house/lookup tables so results are identical across builds (see ADR-0005).

## Verification
Task IMPLEMENT of later tasks: `cargo test --release`, `./evosim version`, perf benchmark command recorded in STATE.md.

# ADR-0008: Grid geometry (`core::grid`)

Status: Accepted (implemented in `crates/core/src/grid.rs`, TASK-004).

## Context
ADR-0003 needs wrap-aware coordinates, distance, direction and radius enumeration on a W x H torus, W,H >= 1 (1x1, 1xN included). Later tasks (climate, organisms, spatial index TASK-010) build on one geometry module.

## Decisions
- **Types**: `Pos { x: i32, y: i32 }` always a valid in-range cell (private-ish constructor via `Grid`), `Delta { dx: i32, dy: i32 }` for shortest displacement, cell index `usize = y*W + x`. `i32` coordinates in the API; internal arithmetic in `i64` so arbitrary `i64` input wraps without overflow. Max dimension is validated by config (check against config limits; Grid::new rejects 0 and sizes whose product overflows `u32`/usize).
- **Distance measure: Chebyshev** (`max(|dx|,|dy|)` of the shortest toroidal delta). Reason: movement is cell-to-cell with 8 neighbours (one step = distance 1); "within radius r" is a (2r+1)^2 square, matching the ADR-0003 bucket scan, integer-only (deterministic, no sqrt). It is the only metric used by perception, hunting, mating and neighbour search. `dist2_euclid` is NOT provided to avoid mixing metrics.
- **Direction**: `Delta` = shortest signed displacement per axis in range `(-W/2, W/2]`. Tie (even size, exactly half way) resolves to the **positive** direction, deterministically. Size 1 axis -> 0. `step_toward`/`sign` helper gives a unit step (-1/0/1 per axis) for movement.
- **Wrap**: `rem_euclid` on i64.
- **Radius query**: `cells_within(center, r)` enumerates in fixed row-major order of offsets (dy ascending then dx ascending), per axis clamping offset span to the dimension: if `2r+1 >= W` the axis visits each column exactly once starting at `center.x - floor((W-1)/2)`... simplified: visit offsets `-r..=r` when `2r+1 <= W`, else exactly W offsets covering all columns once (lo = -(W-1)/2, hi = lo+W-1). Result: no duplicates, deterministic order, count = min(2r+1,W)*min(2r+1,H). Provide callback/iterator form `for_each_cell_within` (no allocation) and `Vec` convenience. Radius `0` -> the cell itself. Negative radius -> empty.
- Ties in the clamped-span case: the set (not the order) is what matters; order is documented as row-major from the lowest offset.

Note: `neighbors8` excludes the centre and dedups on tiny worlds.

## Alternatives rejected
Euclidean (needs sqrt or squared mixing; circular masks add cost and cross-platform float risk); Manhattan (diamond, awkward with 8-neighbour moves, diagonal costs 2); f32 positions (continuous space contradicts cell-to-cell movement).

## Consequences
Pure integer module, no deps, trivially deterministic and serialisable (`width,height` only). Tests: unit tests per property plus property tests against a brute-force reference (all cells, compute torus distance by exhaustive wrap images) over random sizes incl. 1xN, radius > dimension.

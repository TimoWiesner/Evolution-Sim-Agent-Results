# ADR-0006: Bootstrap, test command and dist

Status: accepted (TASK-002)

- Cargo workspace: `crates/core` (evosim-core lib), `crates/cli` (bin `evosim`). Zero third-party crates for now: works offline, `--locked` builds.
- Release profile: lto=fat, codegen-units=1.
- Tests: built-in `cargo test`; CLI integration tests run the compiled binary. One command: `./test.sh` (cargo tests + `scripts/contract_check.sh`).
- `./evosim` is a bash launcher that rebuilds if sources are newer than the binary (cargo output to stderr only).
- `dist/` = single executable copied from target/release (dynamic glibc only; UI assets will be embedded via include_str!). Musl static build is the fallback if needed.

# ADR-0005: Determinism

Status: Accepted (TASK-001)

## Context
CONTRACT §5: same config+seed+ticks -> identical final/totals/series/state_hash; checkpoint+resume == uninterrupted; different seeds -> different hashes.

## Decision
- **Random numbers**: one in-house PRNG (xoshiro256++ seeded through SplitMix64 from the config seed), implemented in `core::rng`, no external RNG crate, no OS entropy. The full 4x u64 state is part of the saved state and the hash. Where a per-purpose stream is helpful (climate/weather vs. organisms), separate generators derived by SplitMix64 from the seed with fixed stream constants, all saved. Integer ranges use rejection-free Lemire or modulo with documented bias handling; floats via the top 24 bits to f32.
- **Order**: organisms live in id-ordered arenas (monotonic u64 ids, never reused); each tick runs fixed phases in a fixed order (climate -> plants -> herbivores -> carnivores -> deaths -> births -> index rebuild). Within a phase entities are processed in ascending id; conflicts (two animals eating the same plant, two predators the same prey) are resolved by id order, with deaths and births applied in deferred batches sorted by id. Newborns receive ids in processing order. Compaction preserves order.
- **Avoid**: wall clock or `Instant` in state logic (only used for `elapsed_seconds`), `HashMap/HashSet` iteration (use `Vec`, `BTreeMap`, or hash maps only for lookups never iterated), threads that race on state (any parallelism must be deterministic: partition + ordered merge, otherwise single thread initially), pointer addresses, `f32::powf/exp/sin` and fused-multiply-add differences (use basic ops, in-house approximations, `-C target-cpu` left at default x86-64), uninitialised/padding bytes in hashes, locale/format dependent text.
- **State hash**: FNV-1a 64 x2 or SHA-256-style in-house digest (no dependency) over a canonical little-endian byte encoding of: clock, RNG states, climate/world fields, species tables, then all organisms in id order with genome bits. Hex lowercase.
- **Checkpoints**: binary or JSON with f32 bit patterns; contains everything needed (indices derived and rebuilt). Test: run A+B == run A, save, load, run B.
- **Tests**: golden-hash regression for fixed seeds, repeat-run equality, seeds-differ, checkpoint equality, single-thread vs. (future) multi-thread equality.

## Consequences
Slightly more code (PRNG, hasher) but no dependency drift; floating point stays identical within a build and platform.

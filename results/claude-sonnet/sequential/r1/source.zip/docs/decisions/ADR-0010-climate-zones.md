# ADR-0010: Climate zones, biomes and the torus compromise (TASK-006)

Status: accepted (plan). Module `core::climate`, stored as `World::climate`.

## Problem
A torus has no poles and no edges, but Earth-like zones need a cold-to-hot gradient. A plain linear gradient in y would make a hard hot/cold jump at the top/bottom seam.

## Decision (the documented compromise)
- **East-west (x):** the world is a ring; climate is independent of x apart from seeded noise that is periodic in x. No seam possible.
- **North-south (y):** the world is one planet "folded" so that **both the top and bottom edge are polar** and the **equator is the middle row**. The polar cap is thus a band straddling the y-seam; row `H-1` and row `0` are mirror images and neighbours across the seam are as alike as any other neighbours. Cost: the world has one equator and ONE polar band (two hemispheres glued along their poles), so it is a mirrored "double hemisphere"; there is no second equator and the north/south hemispheres are climatically identical (noise differs). Alternative rejected: two equators + two poles (period H/2) gives repeated zones at half the height each, too thin for small worlds.
- Cell-centre coordinate `u = (y+0.5)/H`. Warmth fraction `s = sin^2(pi*u) = (1-cos(2*pi*u))/2` (= cos^2 of latitude): 0 at the seam, 1 at the equator, smooth and periodic, symmetric under `y -> H-1-y`.
- Base temperature `T = pole_temp + (equator_temp-pole_temp)*s - terrain_noise*ELEV_COOLING*(elev-0.5)*2`, elevation in [0,1] from noise, `ELEV_COOLING` = 6 deg C (constant).
- Base precipitation (relative units, mean `precip_mean`): `P = precip_mean * max(0, 1 + precip_latitude_variation * cos(3*pi*(1-2u))) * (1 + terrain_noise*(n_wet-0.5))`. `cos(3*pi*(1-2u))` is even in latitude (wet equator, dry ~30 deg, wet ~60 deg, dry poles), smooth and periodic across the seam.
- Noise: seeded value noise on a lattice that WRAPS in both axes (lattice cell ~8 grid cells, lattice dims `max(1, round(W/8))` x `max(1, round(H/8))`, cosine/smoothstep interpolation), values from `Rng::stream(seed, STREAM_CLIMATE)`; two fields (elevation, wetness). Wrapping lattice => no seam in x or y; any world size works (1x1: constant). Noise never depends on world edges.
- Zones (by `s` plus the noise-perturbed normalised temperature `tau`; `tau == s` when `terrain_noise == 0`): polar `tau<0.07`, tundra `<0.25`, temperate `<0.62` (TemperateForest if wet else TemperateGrassland), dry `<0.88` (Savanna or Desert by precipitation ratio `P/precip_mean`: `<0.45` desert), tropical otherwise (TropicalRainforest; Savanna if very dry ratio `<0.5`). Order seam->equator: Polar, Tundra, Temperate, Dry, Tropical. Exact thresholds are constants in `climate.rs`, documented in `docs/CLIMATE.md`.
- Biome is a pure function of (base T, base P, latitude zone); no organism effects (TASK-007+).
- Inspection without UI: `ClimateMap::to_ascii()` (one letter per biome + legend), `to_json()` (via `core::json`: width, height, biome names row-major, temp, precip), example `cargo run -q --release -p evosim-core --example biome_map -- W H SEED [--json]`. No CLI subcommand (CONTRACT fixes the interface).
- Determinism: only `+ - * /`, `cos`, `sin` from std f64 (same-machine determinism; minor cross-platform differences are allowed by the brief). Noise lattice drawn once at world creation; climate map is a pure function of (config, seed) and need not be checkpointed beyond that (TASK-007 adds time variation).

## Consequences
New config keys: none (uses `climate.*` existing keys). `World::new` builds the map (needs seed -> signature takes `&Config`, already so). Tests listed in tasks/TASK-006/handoffs/plan-cycle1.md.

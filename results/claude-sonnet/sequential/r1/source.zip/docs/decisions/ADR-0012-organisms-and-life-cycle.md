# ADR-0012: Organisms and life cycle (`core::organism`)

Status: Accepted (planned in TASK-008; implemented in the following IMPLEMENT phase). Refines ADR-0004/0005/0009.

## Context
All three kinds share one definition of being born, living and dying. Genomes (TASK-009) and behaviours (feeding, movement, reproduction) come later and must plug into this without changing it.

## Decisions
### Data model
- `pub type Id = u64;` ids come from one counter `next_id` (starts at 1; 0 = "no id"), shared by all kinds, incremented on every creation, **never reused, never decremented**, part of the state digest.
- `enum Kind { Plant, Herbivore, Carnivore }` with `Kind::ALL`, `index()` (0,1,2), `name()`; `is_animal()`.
- `struct Traits` (all `f64`, flat, `Copy`; TASK-009 will compute it from the genome via the same struct):
  | trait | meaning | plant range | animal range |
  |---|---|---|---|
  | `speed` | cells/tick | 0 (fixed) | 0.1..16 |
  | `strength` | attack/competition power | 0..100 | 0..100 |
  | `fertility` | reproduction propensity | 0..1 | 0..1 |
  | `max_health` | health capacity | 0.1..10000 | 0.1..10000 |
  | `max_lifespan` | ticks (stored as `u32`) | 1..1_000_000 | 1..1_000_000 |
  | `max_energy` | energy capacity | 0.1..10000 | 0.1..10000 |
  | `metabolism` | multiplier on base energy cost | 0.25..4 | 0.25..4 |
  | `vision` | perception radius (cells) | 0 (fixed) | 1..64 |
  | `aggression` | animals: tendency to attack/compete | 0 (fixed) | 0..1 |
  | `risk_tolerance` | animals: tendency to accept danger (1 - caution) | 0 (fixed) | 0..1 |
  Ranges live in `Traits::range(kind) -> TraitRanges` (const table, documented in docs/ORGANISMS.md). `Traits::clamped(kind)` forces every field into range and replaces NaN by the range minimum; every constructor goes through it, so no organism ever holds an out-of-range trait. Baseline traits for founders: `Traits::baseline(kind, &Config)` from the existing `plants.*` / `herbivores.*` / `carnivores.*` keys (max_age -> max_lifespan, health -> max_health, strength, speed, vision, aggression, risk_tolerance, max_energy; fertility baseline 0.5, metabolism 1.0). No new config keys.
- `struct Organism { id, kind, pos: Pos, age: u32, energy: f64, health: f64, traits: Traits, parents: [Id;2] (0 = none; plants/asexual use parents[0] only, founders [0,0]), generation: u32, birth_tick: u64, alive: bool, death: Option<Death> }`, `struct Death { tick: u64, cause: DeathCause }`.
- `energy` in `[0, traits.max_energy]`, `health` in `[0, traits.max_health]`: fields are written only through `add_energy(delta) -> f64` (returns the delta actually applied), `set_energy`, `damage(amount)`, `heal(amount)`; all clamp, and treat NaN as 0 change. Direct field writes are prevented by keeping the fields private with getters (`energy()`, `health()`). Age is `u32` saturating.
- `generation`: founders 0; newborn = `max(generation of parents) + 1`.
- `enum DeathCause { OldAge, Starvation, Injury, Predation, Other }` (`Predation` = health reduced by a predator; `Injury` = other damage; behaviour tasks may append causes, append-only). Stored on the organism; counted in `LifeStats`.

### Storage
`Organisms { next_id, plants: Vec<Organism>, herbivores: Vec<Organism>, carnivores: Vec<Organism>, pending_births: Vec<NewBorn>, stats: LifeStats }`. One `Vec` per kind (iteration per phase is a contiguous scan), each **sorted by ascending id** because ids are monotonic and new organisms are only appended (ADR-0009 order for free). Lookup by id: binary search per kind (`get(id)`, `get_mut(id)`); `find_kind` tries the three. Removal by `Vec::retain` in the Deaths phase (stable, keeps order). No `HashMap`. The spatial index (ADR-0003) is derived and added by a later task; storage in per-kind arenas works with it unchanged. Alternatives rejected: slot-map with free list (id reuse hazards, order not by id), one mixed Vec (per-kind scans need filtering), SoA (more code, no gain at 5k organisms).

### Life-cycle rule (one documented rule for same-tick births and deaths)
Within `step`, phases run in `Phase::ORDER`; the life cycle is:
1. Behaviour phases (Plants, Herbivores, Carnivores) may call `mark_dead(id, cause)` (e.g. predation) and `queue_birth(NewBorn{kind,pos,parents,traits,energy})`. Both are **deferred**: `mark_dead` sets `alive = false` and records `Death{tick,cause}` immediately (first cause wins, repeat call is a no-op returning false), so a marked organism **never acts again** (`is_active()` false; behaviour code iterates via `active_ids(kind)` / skips `!alive`) and cannot be eaten twice or be a mate/parent for a *later* queue_birth (`queue_birth` rejects dead parents). Organisms are physically still in the Vec until the Deaths phase.
2. **Deaths phase** (`resolve_deaths(tick)`): for every living organism, in ascending id per kind order Plant, Herbivore, Carnivore: `age += 1`, then in fixed priority if not already dead: health <= 0 -> Injury, energy <= 0 -> Starvation, age >= max_lifespan -> OldAge. Then all `alive == false` organisms are removed (`retain`) and counted: `deaths[kind] += 1`, `deaths_by_cause[kind][cause] += 1`. Each organism is counted exactly once, when it is removed. The removed records are returned in `Vec<Organism>` (id order) for events/tests.
3. **Births phase** (`resolve_births(tick)`): pending births are materialised in queue order (= processing order, ascending parent id by ADR-0009) with fresh ids, age 0, `generation`, `birth_tick = tick`, energy/health clamped (health starts at max_health), and `births[kind] += 1`. Births are validated: parents must still exist **or have died this tick** (a parent that dies in the same tick as its offspring is born still counts as a parent; parents may have been removed in the Deaths phase, so validation happens at queue time, when they were alive). Newborns are appended to the end (keeps id order) and do not act or age before the next tick, and they cannot die this tick (Deaths ran before Births) — so a newborn is never in both counters for the same tick.
4. Counters are cumulative since tick 0 in `LifeStats { births: [u64;3], deaths: [u64;3], deaths_by_cause: [[u64; N_CAUSES];3], founded: [u64;3] }`; `Simulation` also keeps `last_tick_births/deaths` (per-kind arrays, reset each tick). Founders are **not** births (`founded`); invariant `count(kind) == founded + births - deaths` is tested at every tick.
- Net effect of a tick: `n_after = n_before - deaths_this_tick + births_this_tick`, deaths are evaluated before births, so population-dependent rules of the Births phase see survivors only.
- Initial population: `Organisms::populate(cfg, grid)` called from `Simulation::new`, uses its own stream `Rng::stream(seed, STREAM_ORGANISMS=2)` (placement uniform over cells, ascending id: plants, herbivores, carnivores) so the main RNG draw sequence (and existing digests of RNG/weather) is unchanged. This is the only creation of organisms other than births (PROJECT.md rule).
- Not done here (later tasks): metabolism drain, feeding, movement, reproduction decisions, genomes. TASK-008 provides the primitives `add_energy`, `damage`, `mark_dead`, `queue_birth`. Aging and the three death checks above are the only automatic life-cycle effects. The three behaviour-phase RNG placeholders in `sim.rs` stay as they are.
- Sim integration: `Simulation { organisms: Organisms }`; Deaths phase calls `resolve_deaths`, Births phase `resolve_births`; `digest()` additionally feeds `next_id`, counters and, per organism in id order, id, kind, pos, age, energy bits, health bits, parents, generation, alive. `EventKind` gains `Born{id,kind}` and `Died{id,kind,cause}` (recorded only when `record_events`).

## Consequences
Deterministic (ids, order, one RNG stream untouched), no population-size-dependent rules, tests can drive the primitives directly without behaviours. Risk: tests in tests/sim.rs and tests/weather.rs that rebuild a sim by copying rng/tick/acc/weather must also copy `organisms` (they compare digests).

## Verification
tests/organisms.rs (see tasks/TASK-008/handoffs/plan-cycle1.md for the list) + unit tests in organism.rs; `./test.sh`.

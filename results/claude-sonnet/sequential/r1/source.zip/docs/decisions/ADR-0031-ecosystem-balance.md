# ADR-0031: Prey refuge (cover) for ecosystem balance

Status: accepted (TASK-027)

## Decision
`climate.cover_fraction` (previously unused) now selects static cover cells: clumped 3x3 blocks, flagged by a hash of seed and block coordinates (`World::has_cover`). A new key `climate.cover_protection` cuts the success probability of a carnivore attack on a herbivore standing on a cover cell by that fraction. Defaults changed from fraction 0.15/no effect to 0.3/0.8.

## Why
Baseline analysis (docs/BALANCE.md): carnivores kill at a rate set by their own count, herbivores die of predation first, no floor for prey. A spatial refuge is a natural mechanism, uses only cell-local state, never reads population counts and spawns nothing, so the extinction rules of docs/PROJECT.md hold.

## Consequences
The cover map is a pure function of the configuration, so it is not part of the checkpoint or state hash beyond the configuration. State hashes and ecology results of earlier runs change (re-recorded).

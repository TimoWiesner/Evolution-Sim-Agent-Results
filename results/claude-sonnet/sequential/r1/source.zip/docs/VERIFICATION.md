# Verification evidence (TASK-028)

All commands were run in the build container (Ubuntu 24.04, 12 cores) from `/workspace`. Raw outputs: `experiments/delivery/`.

## 1. CONTRACT checks: `scripts/verify_contract.sh`
Runs from a temporary directory (any-cwd behaviour) and checks, for the given binary: `version` JSON and clean stdout; `run` result keys, `tick_end = tick_start + N`, series rules (ascending, no duplicates, first = `tick_start`, last = `tick_end`, default and explicit `--sample-every`); `initial + births - deaths = final`; determinism (same seed identical, other seed different hash, `--seed` override); `--ticks 0`; run from an all-extinct start still advances exactly N ticks; checkpoint equivalence (300 + 200 ticks equals 500); no replenishment (`initial.plants = 0`); 15 error cases (wrong type, missing key, out of range, negative count, malformed JSON, missing file, bad/missing/truncated/corrupted checkpoint, bad arguments, unknown command, batch without seeds, `ui --bogus`) each with exit 2, stderr message, empty stdout and no result file; `batch` files and `summary.json` and equality with the single run; `scenarios/demo.json` and the section-3 example accepted by `run`/`batch`; with `--ui` also `ui --smoke-test` (exit 0 < 60 s), the same with the demo scenario, and `ui --screenshots` (exit 0 < 120 s, `main.png` PNG >= 1280x720).

| command | exit | result |
|---|---|---|
| `scripts/verify_contract.sh ./evosim --ui` | 0 | ALL CHECKS PASSED (smoke test < 1 s, screenshots 3 s: main.png, charts.png, inspector.png, setup.png) |
| `scripts/verify_contract.sh dist/evosim` | 0 | ALL CHECKS PASSED |
| `./test.sh` (includes `scripts/verify_contract.sh target/release/evosim`) | 0 | 330 tests passed, 0 failed in 38 test binaries + contract_check + 30 PASS lines of verify_contract |

Not in `dist/evosim` scope: `ui --smoke-test/--screenshots` (CONTRACT section 2 requires them for `./evosim` only).

## 2. Self-contained distributable (CONTRACT section 6)
- `./build.sh` -> `dist/evosim` (1.2 MB). `ldd dist/evosim`: only `libgcc_s.so.1`, `libm.so.6`, `libc.so.6`, `ld-linux` (no Rust runtime, no project files; the web page is embedded in the binary).
- `dist/` copied to an empty directory, then run from `/` with `env -i` (empty environment, no PATH, no cargo): `evosim version` exit 0; `evosim run --config examples/minimal.json --ticks 100 --save c.bin` exit 0; `evosim run --load c.bin --ticks 10` exit 0.
- `git check-ignore dist target` lists both (not committed).

## 3. Randomised invariant tests: `crates/core/tests/invariants.rs`
Seeded by a fixed meta-seed (failures reproduce). Per case a random configuration is drawn (preset, world incl. 1x1, 1xN, Nx1 and odd sizes, populations incl. 0, 12 random parameters jittered within their validated range) and simulated 150 ticks, checking **every tick**: `ledger_check` (founded + births - deaths = living), `check_index` (spatial index equals organisms), per-kind accounting from the per-tick births/deaths, positions inside the grid, unique ids, all trait values / energy / health finite and inside the documented ranges, species count <= population and equals `living_species`, wrap-aware step length <= ceil(speed)+1, a kind that reached zero never comes back, a second simulation of the same config has an equal digest each tick, a checkpoint taken at a random tick restores the same hash and then continues identically. Further tests: different seed -> different hash on random configs; degenerate worlds 1x1, 1x9, 9x1, 2x2, 3x1.
- `cargo test --release -p evosim-core --test invariants`: 3 passed (40 cases, ~4 s).
- `EVOSIM_FUZZ_SEEDS=400 cargo test --release -p evosim-core --test invariants`: 3 passed (400 cases, 48 s). No invariant violation found, so no engine fix was needed.
- `crates/cli/tests/demo.rs` (2 tests): demo scenario and section-3 example run (200 ticks) and batch.


## 4. 10,000-tick reliability and coexistence runs
Commands (also `scripts/reliability.sh`): `./evosim batch --config examples/contract-example.json --seeds 1,2,3,4,5 --ticks 10000 --sample-every 10 --jobs 5 --out-dir experiments/delivery/results/contract-example --quiet` -> exit 0, 343 s wall. `./evosim batch --config scenarios/demo.json --seeds 1,2,3,4,5 --ticks 10000 --sample-every 10 --jobs 5 --out-dir experiments/delivery/results/demo --quiet`: seeds 1, 2, 4, 5 finished without error (see below); seed 3 was still running (one slow run, many surviving animals) when this document was written, so it is **not** part of the table. `examples/contract-example.json` is CONTRACT section 3 verbatim. All finished runs: exit 0, valid JSON, ledger identity `initial + births - deaths = final` ok, no panic on stderr. "All three until" = first tick (sample resolution 10) at which any kind had zero individuals. Ticks/s were measured with 5 runs plus up to 12 other threads sharing the 12 cores, so they are lower than single-run speed; runs that keep thousands of animals and ~25,000 plants run at only 14-70 ticks/s (the 100 ticks/s target of PROJECT.md applies to ~2,000 entities, not to these larger populations).


### experiments/delivery/results/contract-example

| seed | ticks | final P/H/C | plants ext. | herbivores ext. | carnivores ext. | all three until | ledger | ticks/s |
|---|---|---|---|---|---|---|---|---|
| 1 | 10000 | 105/293/0 | survived | survived | 2250 | 2250 | ok | 68 |
| 2 | 10000 | 10827/0/0 | survived | 8740 | 1980 | 1980 | ok | 39 |
| 3 | 10000 | 12268/0/0 | survived | 1580 | 1690 | 1580 | ok | 438 |
| 4 | 10000 | 12266/0/0 | survived | 2970 | 3030 | 2970 | ok | 283 |
| 5 | 10000 | 12258/0/0 | survived | 7260 | 2620 | 2620 | ok | 29 |

All three kinds alive until: median 2250, mean 2280, min 1580, max 2970; full 10,000 ticks in 0/5 runs.

### experiments/delivery/results/demo

| seed | ticks | final P/H/C | plants ext. | herbivores ext. | carnivores ext. | all three until | ledger | ticks/s |
|---|---|---|---|---|---|---|---|---|
| 1 | 10000 | 18100/3005/0 | survived | survived | 2980 | 2980 | ok | 16 |
| 2 | 10000 | 22500/4522/0 | survived | survived | 1440 | 1440 | ok | 14 |
| 4 | 10000 | 24546/0/0 | survived | 4990 | 5220 | 4990 | ok | 42 |
| 5 | 10000 | 24519/0/0 | survived | 1940 | 2030 | 1940 | ok | 328 |

All three kinds alive until: median 2980, mean 2838, min 1440, max 4990; full 10,000 ticks in 0/4 runs.

## 5. Demo scenario search (what was tried)
World for all trials: 96x64, 900 plants, 200 herbivores, 14 carnivores (a larger world than the default so that local refuges and migration have room), seeds 11-17 (disjoint from the final measurement seeds 1-5), 4,000-5,000 ticks, metric = all-three-alive ticks. Nothing reads population counts and nothing spawns; only parameters of the existing mechanisms were varied.

| id | change vs. defaults | seeds | all three until (ticks) | verdict |
|---|---|---|---|---|
| A | none (defaults in the larger world) | 11-13 | 1960, 2310, 1450 (median 1960) | reference |
| B | `climate.cover_fraction` 0.4 | 11-13 | 1230, 2070, 1130 | worse |
| C | `climate.resource_regen` 3.0 | 11-13 | 1560, 1960, 1320 | no better |
| D | carnivore `vision` 3 | 11-13 | 1090, 1370, 1330 | worse |
| E | carnivore `max_energy` 300, `initial_energy` 120, `reproduction_energy` 250 | 11-13 | 1190, 2660, 1880 | no better |
| **F** | **`carnivores.base_metabolism` 0.6, `carnivores.attack_cost` 2.0** | 11-13 / 14-17 | 2320, 3390, 4000+ / 4000+, 3780, 2890, 3460 (7 seeds, median 3460, mean 3406; 2 of 7 survived the 4,000 ticks) | **chosen** |
| G | `base_metabolism` 0.6, carnivore `max_age` 2000, `reproduction_cooldown` 100 | 11-13 / 14-17 | 4000+, 2750, 3330 / 4000+, 3200, 3520, 2350 (median 3330, mean 3307) | about as good as F |
| H | 8 carnivores, 300 herbivores | 11-13 | 1640, 960, 1170 | worse |
| I | F + G combined | 11-14 | 1550, 2100, 1630, 1660 | worse: carnivores too weak, herbivores die first (overgrazing) |
| J | I with `base_metabolism` 0.5 | 11-14 | 1620, 1550, 1610, 2200 | worse |
| K | `base_metabolism` 0.6, `max_age` 2000, cooldown 100, `digestion_efficiency` 0.8 | 11-14 | 1650, 2000, 2320, 1950 | worse than F/G |

Result: cheaper carnivores (F) roughly double the trial coexistence relative to the defaults in this world (median 1960 -> 3460) but do not reach 10,000 ticks; combining changes did not add up. The final measurement (seeds 1-5, 10,000 ticks) gave a median of about 2,500 ticks, lower than the trial figure (trial seeds were chosen before the final ones; trial medians over 3-7 seeds are noisy, and the final runs go beyond 4,000 ticks). Honest conclusion: the demo scenario is not clearly better than the section-3 example (median 2250 over 5 seeds vs. 2460 over 4 seeds, within noise). Per-trial raw JSON: `experiments/delivery/demo/res-*`.

## 6. Known gaps found by this verification
- The 10,000-tick coexistence goal is not reached (section 4).
- Large surviving populations slow the simulation to 14-70 ticks/s while sharing cores.
- No functional bug was found by the contract script, the randomised invariants (400 cases) or the 10k-tick runs; no engine change and no re-recorded golden in this task.

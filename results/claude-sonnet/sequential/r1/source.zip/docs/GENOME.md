# Genome (TASK-009, ADR-0013)

Code: `crates/core/src/genome.rs`. Diploid, real-valued: `Genome { alleles: [[f32;2]; 10] }`, alleles in [0,1].
Genes (append-only): Speed, Strength, Fertility, MaxHealth, MaxLifespan, MaxEnergy, Metabolism, Vision, Aggression, RiskTolerance.

## Gene -> trait (`Genome::traits(kind, &baseline)`)
g = mean of the two alleles. Unit traits (fertility, aggression, risk_tolerance) = g. Scale traits = baseline * f(g), f piecewise linear, f(0)=0.25, f(0.5)=1, f(1)=4; then clamped to `Traits::range(kind)` (max_lifespan rounded). Baselines come from the config (`Traits::baseline`), stored in `Organisms`. Plant-only fixed traits (speed, vision, aggression, risk) are carried but clamped to 0.

## Founders
`Genome::founder(kind, baseline, rng, genetics.founder_variation)`: both alleles = inverse mapping of baseline, plus uniform noise +-variation per allele (stream `STREAM_GENOMES=3`; variation 0 draws nothing). Default 0.05, so founders differ slightly.

## Inheritance
`child_of_one` = copy + mutate. `child_of_two(a, b, crossover_rate, &Mutation, rng)`: each parent gives a gamete (random start strand, switch strand between loci with probability `genetics.crossover_rate`; 0.5 = free recombination); slot 0 from `a`, slot 1 from `b`. Callers pass the simulation RNG.

## Mutation
`Mutation::for_kind(cfg, kind)` = `<kind>.mutation_rate` (per allele) and `genetics.mutation_sigma`. Hit: step = sigma*sqrt3*(u1+u2+u3+u4-2) (std sigma), clamp [0,1]. Rate 0 or sigma 0: no RNG draw, no change.

## Distance
`Genome::distance`: mean over loci of min-pairing L1/2, in [0,1]; 0 for same allele multisets, symmetric, triangle inequality. `trait_distance`: mean |locus value difference|. Neither is tied to position.

Tests: `crates/core/tests/genome.rs` (10 tests). Command: `cargo test --release -p evosim-core --locked --test genome`.

## Plant reuse of loci (TASK-011)
Plant traits speed/vision/aggression/risk are fixed to 0, so the Aggression, RiskTolerance and Vision loci are reused by plants as thermal optimum, temperature tolerance and water need (docs/PLANTS.md). No layout change.

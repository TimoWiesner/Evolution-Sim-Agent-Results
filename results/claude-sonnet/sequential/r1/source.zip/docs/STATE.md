# Project status (agent-maintained human-readable summary)

Status: TASK-028 IMPLEMENT cycle 1 done (verify_contract.sh, invariants.rs, scenarios/demo.json, README rewrite, docs/VERIFICATION.md + AUDIT.md, 10k-tick results in experiments/delivery; 10k coexistence still not reached). Earlier: TASK-027 IMPLEMENT cycle 1 done (prey refuge mechanism, ADR-0031, docs/BALANCE.md: coexistence mean 1187 -> 2717 ticks, goal of 10k not reached). Earlier: TASK-026 IMPLEMENT cycle 1 done (perf_bench example, Simulation::step_hooked, plants climate cache, resolve_deaths fast path, tests/perf.rs, docs/PERFORMANCE.md: 1,622 -> 2,215 ticks/s at ~3,400 organisms, state_hash unchanged; ADR-0030). Earlier: TASK-025 IMPLEMENT cycle 1 done (UI setup form, presets, config import/export, 5 live charts: crates/ui/src/experiment.rs + charts.rs, web/charts.js + setup.js, ADR-0029, docs/UI.md). Earlier: TASK-024 IMPLEMENT cycle 1 done (UI controls + inspector: crates/ui/src/session.rs, ADR-0028, docs/UI.md). Earlier: TASK-023 IMPLEMENT cycle 1 done (`evosim ui`: crates/ui, docs/UI.md, ADR-0027). Earlier: TASK-022 IMPLEMENT cycle 1 done (`run --save/--load`, core::checkpoint, docs/CHECKPOINT.md, tests core/tests/checkpoint.rs + cli/tests/checkpoint.rs). Earlier: TASK-021 IMPLEMENT cycle 1 done (`evosim batch`, crates/runner/src/batch.rs, docs/CLI.md, tests/batch.rs). Earlier: TASK-020 IMPLEMENT cycle 1 done (core::metrics, `evosim run --metrics`, docs/METRICS.md, tests/metrics.rs). Earlier: TASK-019 IMPLEMENT cycle 1 done (`evosim run`: crates/runner, core::hash SHA-256, Simulation::state_hash, docs/CLI.md, examples/minimal.json, ADR-0023). Earlier: TASK-018 IMPLEMENT cycle 1 done (ecology integration: docs/ECOLOGY.md, ADR-0022 accepted, retuned defaults, new key plants.graze_reserve, Simulation::ledger_check, core::ecology + example survival, tests/ecology.rs). Earlier: TASK-017 IMPLEMENT cycle 1 done (core::species, docs/SPECIES.md, ADR-0021; tests/species.rs). Earlier: TASK-016 IMPLEMENT cycle 1 done (core::reproduction, docs/REPRODUCTION.md, ADR-0020 accepted, tests/reproduction.rs; Organism.cooldown). Earlier: TASK-015 IMPLEMENT cycle 1 done (core::carnivore, docs/CARNIVORES.md, ADR-0019 accepted, tests/carnivore.rs; new key attack_cost, Organism.rest). Earlier: TASK-014 IMPLEMENT cycle 1 done (core::herbivore, ADR-0018, docs/HERBIVORES.md, tests/herbivore.rs; 4 new Animal config keys). Earlier: TASK-013 IMPLEMENT cycle 1 done (core::movement, docs/MOVEMENT.md, tests/movement.rs; spatial index wired into Simulation). Earlier: TASK-012 IMPLEMENT cycle 1 done (plant reproduction/dispersal, ADR-0016, docs/PLANTS.md, tests/plant_repro.rs). Earlier: TASK-011 IMPLEMENT cycle 1 done (plant growth/resources: docs/PLANTS.md, ADR-0015; tests/plants.rs). Earlier: TASK-003 IMPLEMENT cycle 1 done (config). Earlier: TASK-002 IMPLEMENT cycle 1 done: skeleton exists (workspace crates/core + crates/cli, setup.sh, evosim, build.sh, test.sh, README). `version` and `--help` work; run/batch/ui are stubs (exit 2). Harness decides DONE.

## Decisions (see docs/decisions/)
ADR-0001..0005 (Rust, browser UI, spatial index, genome, determinism), ADR-0006 (bootstrap, test command, dist = single glibc-linked binary).

## System dependencies
Present in container: cargo/rustc 1.100, node 18, python 3.12, chromium. No apt installs needed. No third-party crates yet (Cargo.lock committed; builds use --locked).

## Test commands
`./test.sh` (cargo test --release --workspace --locked + scripts/contract_check.sh). Check dist: `scripts/contract_check.sh dist/evosim`.

## Risks
Chromium headless as root needs `--no-sandbox`; crates download needs network in setup once deps are added (update Cargo.lock then); avoid f32 transcendental nondeterminism.

## Config (TASK-003, implemented)
ADR-0007: `core::json` (in-house parser/writer) + `core::config` (typed structs via `group!` macro, `Config::param_defs()`, `from_json`/`to_json`/`validate`/`preset`, `describe()`). Reference: docs/CONFIG.md (table checked by test `file_load_and_docs_in_sync`; regenerate with `cargo run -q --release -p evosim-core --example describe`). 70+ keys, unknown keys = error, presets default/lush/harsh/predator-rich/large. Not wired into the CLI yet (TASK-019).

## Grid (TASK-004, implemented)
ADR-0008: `core::grid` — `Grid::new(w,h)`, `Pos{x,y:i32}`, `Delta`, `wrap(i64,i64)`, `delta` (range (-N/2,N/2], tie positive), `dist` = Chebyshev (the only metric), `step_toward`, `cells_within`/`for_each_cell_within` (row-major offsets, clamped span, no duplicates), `neighbors8`. Tests: 7 unit tests in grid.rs + 10 integration tests in crates/core/tests/grid.rs (cells_within_matches_bruteforce, radius_larger_than_world_covers_each_cell_once, edges_and_corners_nonsquare, delta_dist_properties, wrap_negative_multiple_extreme, one_by_one, one_by_n_and_n_by_one, step_toward_signs, ...) using an independent brute-force distance reference. (Cycle 1 shipped tests/grid.rs empty; fixed in cycle 2.)

## TASK-005 (IMPLEMENT cycle 1 done)
Implemented crates/core/src/{rng,world,sim}.rs per ADR-0009; tests: 7 unit in rng.rs + 8 integration in crates/core/tests/sim.rs. `./test.sh` exit 0. Stub phases draw one RNG value each (placeholder, marked in sim.rs). Simulation::new validates config; tick increments at end of step; no checkpoint file format yet (only rng/tick/acc export).

## Next
TASK-005 implement; TASK-003 review, then per task list.

## TASK-006 (IMPLEMENT cycle 1 done)
Implemented crates/core/src/climate.rs, World::climate, example biome_map, docs/CLIMATE.md, tests/climate.rs (10 tests incl. seam proof with a negative-control). `./test.sh` exit 0. No new config keys. Next: TASK-006 review, then TASK-007 (climate over time).

## TASK-007 (PLAN cycle 1 done)
Plan in tasks/TASK-007/handoffs/plan-cycle1.md and ADR-0011 (seasons: cosine, amplitude scaled by latitude, precip monsoon-like with new key `climate.seasonal_precip_amplitude`; weather: wrapping AR(1) anomaly lattice drawn from the sim RNG in the Climate phase, part of state/digest; bounds documented and clamped). No code yet.

## TASK-007 (IMPLEMENT cycle 1 done)
Seasons + weather implemented per ADR-0011 (climate.rs, world.rs, sim.rs Climate phase now evolves weather from the sim RNG; digest includes weather). New key `climate.seasonal_precip_amplitude` (CONFIG.md regenerated; set in `harsh` preset). Tests: crates/core/tests/weather.rs. `./test.sh` exit 0. Docs: docs/CLIMATE.md. Next: TASK-007 review.

## TASK-008 (PLAN cycle 1 done)
ADR-0012 + tasks/TASK-008/handoffs/plan-cycle1.md: `core::organism` (Kind, Traits with ranges, Organism, per-kind id-sorted Vecs, deferred mark_dead/queue_birth, Deaths-before-Births rule, cumulative per-kind counters). No code yet.

## TASK-008 (IMPLEMENT cycle 1 done)
`core::organism` implemented per ADR-0012 (docs/ORGANISMS.md); Simulation owns `organisms`, Deaths/Births phases resolve them, digest includes them, events Born/Died. tests/organisms.rs (13 tests); sim/weather rebuild tests also copy `organisms`. `./test.sh` exit 0. No new deps/config keys. Next: TASK-008 review.

## TASK-009 (PLAN cycle 1 done)
ADR-0013 + tasks/TASK-009/handoffs/plan-cycle1.md: `core::genome` (diploid f32 alleles, 10 genes mapped to Traits relative to baselines, copy/crossover/mutation with sim RNG, distance = min-matching L1). New key `genetics.founder_variation` planned. No code yet.

## TASK-009 (IMPLEMENT cycle 1 done)
`core::genome` per ADR-0013 (docs/GENOME.md). `Organism.genome()` private/immutable, traits derived in constructor; `NewBorn.genome` replaces `traits`; `Organisms::baseline(kind)`; founders from stream 3; digest includes alleles. New key `genetics.founder_variation` (0.05; CONFIG.md regenerated). `mutate`/`child_of_*` not yet called by sim phases (reproduction = TASK-012/016). tests/genome.rs (10 tests); tests/organisms.rs sets founder_variation 0 for exact-age tests. `./test.sh` exit 0. Next: TASK-009 review.

## TASK-010 (PLAN cycle 1 done)
ADR-0014 + tasks/TASK-010/handoffs/plan-cycle1.md: `core::spatial::SpatialIndex` (incremental id-sorted per-kind cell buckets; query ordered by (dist,kind,id)). No code yet.

## TASK-010 (IMPLEMENT cycle 1 done)
`core::spatial::SpatialIndex` per ADR-0014 (docs/SPATIAL.md has interface + benchmark: 11.8x/4.7x/2.3x/1.2x faster at r=3/5/8/16). Not wired into sim.rs (digests unchanged). tests/spatial.rs (8 tests), example spatial_bench. No new deps/config keys. Next: TASK-010 review.

## TASK-011 (PLAN cycle 1 done)
ADR-0015 + tasks/TASK-011/handoffs/plan-cycle1.md: one fertility stock per cell (static climate cap, regen by current water = the only energy source), per-plant growth = fT*fW*crowd limited by uptake/stock, upkeep, climate stress damage (new DeathCause::Climate), plant tolerance traits reuse unused plant loci via `plants::PlantTraits`. New keys `plants.maintenance`, `plants.stress_damage`. No code yet.

## TASK-012 (PLAN cycle 1 done)
ADR-0016 + tasks/TASK-012/handoffs/plan-cycle1.md: asexual plant seeds in the Plants phase (threshold+cost, ring dispersal with wrapping, room/resource/climate establishment checks, new key `plants.establish_resource`).
IMPLEMENT cycle 1 done: `run_plants_phase(.., rng)`, `plants::seed_target`, new PlantPhaseStats fields; tests/plant_repro.rs (16 tests); tests/plants.rs helper sets establish_resource=10000 (growth-only tests), tests/weather.rs rng test runs with no organisms. `./test.sh` exit 0.

## TASK-013 (PLAN cycle 1 done)
ADR-0017 + tasks/TASK-013/handoffs/plan-cycle1.md: `core::movement` (vision via SpatialIndex, speed credit, king steps along shortest wrapped path, sprint-superlinear move cost, wander = correlated random walk), cell-sharing rule (unlimited except plants <= plants.cell_capacity, single `organism::cell_limit`), SpatialIndex wired into Simulation incrementally. No code yet.

IMPLEMENT cycle 1 done: `core::movement`, `Simulation.spatial/check_index/rebuild_index`, `organism::cell_limit`, new Organism fields move_credit/heading; Herbivores/Carnivores phases no longer draw the stub RNG value. tests/movement.rs (15 tests); other tests call `rebuild_index()` after replacing `organisms`. `./test.sh` exit 0. Gap for TASK-014: idle metabolism and feeding (animals only lose energy by moving). No system packages needed.

## TASK-014 (PLAN cycle 1 done)
ADR-0018 + tasks/TASK-014/handoffs/plan-cycle1.md: `core::herbivore` (running cost with climate multiplier, reach own+adjacent cell, limited bite, gene-driven plant scoring with aggression/risk_tolerance/vision, satiation); 4 new Animal keys (bite_size, temp_comfort, temp_tolerance, climate_cost). No code yet.

## TASK-015 (PLAN cycle 1 done)
ADR-0019 + tasks/TASK-015/handoffs/plan-cycle1.md: `core::carnivore` (one attack/tick from own/adjacent cell, p=A/(A+D) from both animals traits + sim RNG, attack_cost always paid, exactly-once Predation kill, gain<=prey energy, handling_time rest, carnivore upkeep, multi-carnivore: ascending id first kill wins). New key `attack_cost`, new Organism.rest. No code yet.

IMPLEMENT cycle 1 done (TASK-015): `core::carnivore::run_carnivore_phase` replaces plain carnivore movement; `herbivore::{climate_mult,upkeep_cost}` now take `&Animal`; carnivores pay upkeep, attack from own/adjacent cell, `Simulation.last_carnivore_stats`. tests/carnivore.rs (14 tests); tests/organisms.rs carnivores made inert; obsolete herbivore test `carnivores_still_use_plain_movement` removed. `./test.sh` exit 0. No system packages needed.

## TASK-016 (PLAN cycle 1 done)
ADR-0020 + tasks/TASK-016/handoffs/plan-cycle1.md: `core::reproduction` at the start of the Births phase; initiator model with mate_range search, nearest-then-most-similar mate, compatibility = genetic distance <= `genetics.species_threshold`, fertility = conception chance and litter size, both parents pay 0.6*n*offspring_energy, new `Organism.cooldown` (digested). No new config keys. No code yet. No system packages needed.

IMPLEMENT cycle 1 done (TASK-016): `core::reproduction::run_reproduction_phase` runs at the start of the Births phase; new `Organism.cooldown` (digested); `Simulation.last_reproduction_stats`; tests/reproduction.rs (15 tests); tests/organisms.rs exact-death tests set maturity_age = max_age. `./test.sh` exit 0. Observation: default config with 4000 plants/150 herb/10 carn breeds (23 herbivore, 6 carnivore births in 1000 ticks) but then collapses: balance is TASK-018. No system packages needed.

## TASK-017 (PLAN cycle 1 done)
ADR-0021 + tasks/TASK-017/handoffs/plan-cycle1.md: `core::species::SpeciesRegistry` in `Simulation.species`, `Organism.species`, frozen reference genome per species, `<=` genetic_threshold criterion, periodic reclassification (interval/min_size keys already exist), extinction swept each Births phase, deterministic names. No new config keys. No code yet. No system packages needed.

IMPLEMENT cycle 1 done (TASK-017): `core::species::SpeciesRegistry` in `Simulation.species`, `Organism.species`, classification in Births phase, `Simulation::living_species`. tests/species.rs (12); sim.rs/weather.rs rebuild tests also copy `species`. `./test.sh` exit 0. No new config keys or system packages.

## TASK-018 (PLAN cycle 1 done)
ADR-0022 + tasks/TASK-018/handoffs/plan-cycle1.md: tick order stays Climate, Plants, Herbivores, Carnivores, Deaths, Births(+species), Index; plan = ledger_check, survival report example (10,000 ticks x 5 seeds), tests/ecology.rs, and a rebalance of Config defaults (measured: with current defaults plants die out by t~150 when 120 herbivores are present; plants alone decline 400->~12). No code yet. No system packages needed.

## TASK-018 (IMPLEMENT cycle 1 done)
Defaults retuned (see docs/ECOLOGY.md); `plants.graze_reserve` keeps grazing from killing plants; `Simulation::ledger_check`; `ecology::run_survival` + `cargo run --release -p evosim-core --example survival -- 10000 5` (~95 s). Measured: plants survive 10,000 ticks on 5 seeds; herbivores die out at ticks 413-2706, carnivores 150-200 ticks later (coexistence is TASK-027). Tests that relied on old defaults now pin their values. Scratch example `trace` (config.json ticks every) prints populations and plant stats. No system packages needed.

## TASK-019 (PLAN cycle 1 done)
ADR-0023 + tasks/TASK-019/handoffs/plan-cycle1.md: new crate `evosim-runner` (run command), SHA-256 `Simulation::state_hash()` (in-house `core::hash`, covers state + climate map + config), result extras, atomic output write, exit 2 on all errors, `--save/--load` rejected until TASK-022. No code yet. No system packages needed.

## TASK-019 (IMPLEMENT cycle 1 done)
`./evosim run` implemented per ADR-0023 (docs/CLI.md): new crate `crates/runner` (no deps; `Cargo.lock` gained the package once, builds stay `--locked`), `core::hash::Sha256`, `Simulation::state_hash()` (+ `World::cap_words`), README example uses `examples/minimal.json` (CONTRACT section 3 sample). `--save/--load` rejected (TASK-022); batch/ui still stubs. Tests: crates/core/tests/state_hash.rs (5), hash unit tests (3), organism allele hash test, runner arg tests (4), crates/cli/tests/run.rs (7). `./test.sh` exit 0. Manual: `dist/evosim run --config examples/minimal.json --ticks 1000 --out /tmp/r.json` 0.66 s; default config herbivores/carnivores extinct by tick 1000 for seed 42 (balance: TASK-027). No system packages needed.

## TASK-020 (PLAN cycle 1 done)
ADR-0024 + tasks/TASK-020/handoffs/plan-cycle1.md: `core::metrics::MetricsRecorder` (read-only observer sampled at the series ticks), `evosim run --metrics FILE` writing a documented JSON (docs/METRICS.md, to be written in IMPLEMENT), per-kind population, births/deaths (cumulative+interval), deaths by cause, species, generation max/mean, 10 traits mean/sd/min/max, null for empty kinds; hash-neutrality test. No code yet. No system packages needed.

## TASK-020 (IMPLEMENT cycle 1 done)
`core::metrics::MetricsRecorder` + `--metrics FILE` per ADR-0024 (docs/METRICS.md, docs/CLI.md). Result extras `metrics_file`, `totals.deaths_by_cause`. Tests: crates/core/tests/metrics.rs (4, hand-verified world, hash neutrality), 2 in crates/cli/tests/run.rs. `./test.sh` exit 0. Note: metrics file is renamed into place just before the result file; both paths are probed up-front. No system packages needed.

## TASK-021 (PLAN cycle 1 done)
ADR-0025 + tasks/TASK-021/handoffs/plan-cycle1.md: `evosim batch` in `crates/runner/src/batch.rs`; sweeps via repeatable `--param PATH=V1,V2` (cartesian product, validated up-front), `--seeds` list/ranges, threads with `--jobs` and index-ordered results (reproducible), `summary.json` (runs[], aggregate, per-parameter groups with mean/min/max/sd/median of final population and extinct counts), always `summary.csv` + `aggregates.csv`. No code yet. No system packages needed.

## TASK-021 (IMPLEMENT cycle 1 done)
`evosim batch` per ADR-0025 (docs/CLI.md): `--param PATH=V1,V2` sweeps (cartesian, range-checked), threads via `--jobs`, summary.json + summary.csv + aggregates.csv. `runner::run_config` extracted from `run_headless_full`. Tests: 6 unit in batch.rs, 5 in crates/cli/tests/batch.rs. `./test.sh` exit 0. No system packages needed.

TASK-022 PLAN cycle 1 done: ADR-0026 + docs/CHECKPOINT.md + tasks/TASK-022/handoffs/plan-cycle1.md (binary LE format, version 1, SHA-256 trailer, no compression; `core::checkpoint`; runner `--save/--load`). No code yet. No system packages needed.

## TASK-022 (IMPLEMENT cycle 1 done)
Checkpoints per ADR-0026: `core::checkpoint` (container v1, SHA-256 trailer, no compression), per-module `write_state/read_state`, `Simulation::to_checkpoint/from_checkpoint` (verifies ledger, index and the stored `state_hash`). Runner: `RunArgs{config:Option,load,save}`, `run_simulation(sim,..)`, `write_atomic_bytes`; `--save` written before the result. Deviation from plan: none of substance. Rule: new simulation state -> checkpoint writer/reader + bump `FORMAT_VERSION`. Tests: 10 in crates/core/tests/checkpoint.rs, 4 in crates/cli/tests/checkpoint.rs, args unit test. No system packages needed.

## TASK-023 (PLAN cycle 1 done)
ADR-0027 + tasks/TASK-023/handoffs/plan-cycle1.md: new crate `evosim-ui` (std-only HTTP server, controller thread, binary frame/terrain endpoints, embedded vanilla-JS canvas view with pan/zoom/legend, chromium-driven --smoke-test/--screenshots). No code yet. No system packages needed (chromium and xvfb-run are present).

## TASK-023 (IMPLEMENT cycle 1 done)
`crates/ui` (`evosim-ui`, no deps): snapshot.rs (binary frame/terrain), controller.rs (sim thread), server.rs (std HTTP), browser.rs (chromium), web/{index.html,app.js,style.css}; `evosim ui [--config] [--port] [--no-open]`, `--smoke-test`, `--screenshots DIR` (docs/UI.md). Tests: crates/ui/tests/ui.rs (10, incl. node camera test). Smoke 0.3 s, screenshots 0.6 s. Known gap: screenshot has a blank strip at the bottom (headless window chrome). Placeholder sidebar panel ids exist for TASK-024/025. System deps: chromium (present), node (present), xvfb-run optional. No apt installs.

## TASK-023 (IMPLEMENT cycle 2 done)
Fixed review G1: crates/cli/tests/cli.rs `stubs_and_bare_run_exit_2` ran bare `evosim ui` (now a server, never exits). Renamed `bare_run_and_batch_exit_2`; `ui` checked only with `--bogus` (exit 2). Rule: no test may start a long-lived `evosim ui`. `./test.sh` exit 0 (full). No system packages needed.

## TASK-024 (IMPLEMENT cycle 1 done)
`crates/ui/src/session.rs` (pure `Session`: run/pause/step/reset/speed levels/select/inspect/save/load), controller owns a Session and answers commands over a reply channel (`Shared::call`), new HTTP cmds + `/api/inspect` + extended `/api/state`, page controls panel + inspector (genome table, follow, vision, parent links, DEAD banner), `inspector.png` screenshot. `info_json(sim, epoch)`; `Shared.terrain/info` are `Mutex<Arc<..>>`. Tests: crates/ui/tests/session.rs (10), crates/ui/tests/ui.rs (+5 incl. node `web/test/ui.test.js`). Known gaps: death cause usually `unknown` (organism removed in Deaths phase); screenshot blank strip remains. No system packages needed. Rule still: no test starts a long-lived `evosim ui`.

## TASK-025 (PLAN cycle 1 done)
ADR-0029 + tasks/TASK-025/handoffs/plan-cycle1.md: UI setup form from `Config::param_defs` with per-field validation (`experiment.rs`), presets cards, config export/import (`GET /api/config`, import endpoint), own-canvas charts (`charts.rs` history recorder + `web/charts.js`: population, births/deaths, species, trait mean, trait distribution), screenshots main/charts/setup/inspector. No code yet. No system packages needed.

## TASK-028 (IMPLEMENT cycle 1 done)
Evidence in docs/VERIFICATION.md, audit in docs/AUDIT.md, README rewritten (coexistence table). `./test.sh` (now also runs `scripts/verify_contract.sh target/release/evosim`) is the one test command. Randomised tests: crates/core/tests/invariants.rs (EVOSIM_FUZZ_SEEDS raises case count). Demo scenario `scenarios/demo.json` (96x64, carnivores base_metabolism 0.6, attack_cost 2.0; search log in VERIFICATION.md). Long runs: `scripts/reliability.sh` (minutes). No engine changes, no goldens re-recorded. System packages: none new (chromium, xvfb-run, python3, node present).

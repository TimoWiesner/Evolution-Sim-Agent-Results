# Climate zones and biomes (TASK-006, ADR-0010)

Module `core::climate`; the map lives in `World::climate`. It is a pure function of the config and seed (own RNG stream `STREAM_CLIMATE`, the simulation RNG is not consumed). It is static for now; time variation is TASK-007, effects on organisms come later. No new config keys: it uses `climate.equator_temp`, `pole_temp`, `precip_mean`, `precip_latitude_variation`, `terrain_noise`.

## The compromise: latitude zones on a world without edges
A torus has no poles and no edges, but Earth-like zones need a cold-to-hot gradient. A linear gradient in y would jump from hot to cold at the top/bottom **seam**. Chosen compromise: a **mirrored double hemisphere**.
- Rows are latitude. **Both the top and the bottom edge are polar** and the **equator is the middle row**, so the polar band straddles the y-seam: row `H-1` and row `0` are mirror images and their neighbours are as alike as any others. Cost: one equator, one polar band; the two hemispheres are climatically identical apart from noise. Rejected: two equators + two poles (period H/2): zones become too thin on small worlds.
- East-west (x) is a ring: climate does not depend on x except through noise that is periodic in x, so there is no x-seam.

## Formulas (cell centre `u = (y+0.5)/H`)
- Warmth `s = (1 - cos(2*pi*u))/2` in [0,1]; 0 at the seam, 1 at the equator, symmetric.
- Elevation `elev` in [0,1] and wetness `wet` in [0,1]: seeded value noise on a lattice of `max(1,round(W/8)) x max(1,round(H/8))` points that wraps in both axes (smoothstep interpolation).
- Temperature `T = pole_temp + (equator_temp-pole_temp)*s - terrain_noise*6*(elev-0.5)*2` (so within +-6 deg of the latitude value).
- Precipitation `P = precip_mean * max(0, 1 + precip_latitude_variation*cos(3*pi*(1-2u))) * (1 + terrain_noise*(wet-0.5))`: wet equator, dry ~30 deg, wet ~60 deg, dry poles.

## Zones and biomes
Normalised warmth `tau = s + dT/(equator_temp-pole_temp)` (= `s` without noise); `ratio = P/precip_mean`.

| zone | tau range | biome |
|---|---|---|
| 0 polar | < 0.07 | Polar (P) |
| 1 tundra | < 0.25 | Tundra (T) |
| 2 temperate | < 0.62 | Temperate forest (F) if ratio >= 0.8, else grassland (G) |
| 3 dry | < 0.88 | Desert (D) if ratio < 0.45, else Savanna (S) |
| 4 tropical | >= 0.88 | Tropical rainforest (R); Savanna (S) if ratio < 0.5 |

Order from seam to equator: polar, tundra, temperate, dry, tropical. Constants are in `climate.rs`.

## Inspecting the map without a UI
`cargo run -q --release -p evosim-core --example biome_map -- W H SEED` prints one letter per cell (top row first) plus a legend; add `--json` for width, height, zone names and row-major `biome`, `zone`, `temp`, `precip` arrays. In code: `ClimateMap::to_ascii()` / `to_json()`.

## Small worlds
Any size from 1x1 works. Noise lattices shrink to at least 1x1 (constant). With very small `H` some zones are absent (the full five-zone sequence is only tested for H >= 24); the order stays monotone. 1xN and Nx1 worlds are valid: the 1-wide world is a single column with the full latitude profile, the height-1 world is a single row at the equator-like middle (`s = 1`).

## Tests
`crates/core/tests/climate.rs`: zone order and symmetry, no-seam check for temperature and precipitation on several sizes/seeds (seam diffs <= interior diffs; a deliberately seamed gradient is shown to fail), small worlds, exports, determinism.

# Seasons and weather (TASK-007, ADR-0011)

Effective climate of cell `p` at tick `t` = base map (annual mean) + seasonal term + weather term. No effects on organisms yet.

- **Season**: `phase = 2*pi*(t mod L)/L`, `L = climate.season_length` (integer modulo first, so tick `t` and `t+L` are bit-identical). Tick 0 = midwinter, `L/2` = midsummer.
  - `T = T_base + A*k_T*(-cos(phase))`, `A = seasonal_amplitude`, `k_T = 0.25 + 0.75*(1-s)` (`s` = row warmth): full swing at poles, a quarter in the tropics.
  - `P = P_base*(1 + a_P*k_P*(-cos(phase - 2*pi/8)))`, `a_P = seasonal_precip_amplitude` (new key, default 0.3), `k_P = 0.3 + 0.7*s`: wet/dry seasons strongest in the tropics, wet peak lags the warm peak by 1/8 year. Yearly mean equals the base value.
  - Both hemispheres share the same phase (no phase jump at the y-seam).
- **Weather**: two anomaly fields (temperature, precipitation) on a wrapping lattice (~8 cells spacing), smoothstep-interpolated, so it is smooth with no seams. Each tick (Climate phase) every node follows AR(1): `a <- phi*a + sqrt(1-phi^2)*z`, `phi = exp(-1/weather_period)`, `z` approx N(0,1) from 4 uniforms of the **simulation RNG**; clamped to +-2. Tick 0 draws the stationary state. Draw count per tick is fixed (`2*nodes*4`) regardless of `weather_noise`, so changing weather strength does not shift the RNG stream. `weather_noise = 0` switches weather off exactly. `T += weather_noise*6*aT`, `P *= 1 + weather_noise*0.5*aP`.
- **State**: `World::weather` (tick + node values) is part of `Simulation::digest`; `Weather::state_words()/from_state_words()` give a lossless dump for checkpoints.
- **Bounds** (`ClimateBounds::from_config`, enforced by clamp in `World::temp_at/precip_at`):
  - `temp_min = pole_temp - 6 - A - 12*weather_noise`, `temp_max = equator_temp + 6 + A + 12*weather_noise`
  - `precip_min = 0`, `precip_max = precip_mean*(1+precip_latitude_variation)*(1+terrain_noise/2)*(1+a_P)*(1+weather_noise)`
  - Test `bounds_hold` shows the unclamped value is already inside (3000 ticks, extreme config).
- **Queries**: `World::temp_at(pos)` / `precip_at(pos)` (current climate tick, `World::climate_tick()`); `ClimateMap::seasonal_temp_at(pos, tick)` / `seasonal_precip_at(pos, tick)` for any tick, weather-free and pure.
- Tests: `crates/core/tests/weather.rs` (year repeat with weather off, seeded determinism, bounds, seasonal shape, seam smoothness, state carry-over, any-tick queries, RNG stream independence) plus unit tests in `climate.rs`.

# Plant growth and resources (TASK-011, ADR-0015)

Code: `crates/core/src/plants.rs`, resources in `crates/core/src/world.rs`; tests `crates/core/tests/plants.rs`.

## Where plant energy comes from, and what limits it
**The only source** is the per-cell *fertility stock* `World::resources` (stands for light + water + nutrients). A plant gains energy only by removing exactly the same amount from its cell's stock (efficiency 1; no other path adds energy; asserted by tests: `gain == stock_removed`, `Δstock == regen - removed`).
The stock refills only through regeneration: each tick `stock = min(cap, stock + climate.resource_regen * W(P_now))`, `W(P) = clamp(P / plants.water_need, 0, 1)` with the current precipitation (seasons/weather matter). `cap = climate.resource_max * W(P_base)` from the annual-mean precipitation (static, so weather never deletes stock). Initial stock = cap. No RNG.
Limits on a plant's gain per tick: `min(want, plants.resource_uptake, stock in the cell, max_energy - energy)`. Plants in a cell are served in ascending id, so a finite stock is shared (competition); total growth of a cell is bounded by regeneration + stock. Sinks: upkeep `plants.maintenance * metabolism * drought_cost` per tick, old age, stress.

## Growth formula (per plant, per tick, `T`, `P` = current cell temperature / precipitation)
- `fT = max(0, 1 - ((T - T_opt)/tol)^2)`, `fW = clamp(P/need, 0, 1)`
- `crowd = min(1, plants.cell_capacity / plants_in_cell)` (counted at phase start)
- `want = plants.growth_rate * fT * fW * crowd * size_scale * breadth`

## Deaths
- old age: `max_lifespan` (from `plants.max_age` via genome) — Deaths phase.
- lack of energy: energy 0 after upkeep -> Starvation (Deaths phase).
- hostile climate: if `fT == 0` (too cold/hot) or `fW < 0.1` the plant loses `plants.stress_damage * max_health` health; otherwise it heals 2 % of max health per tick; health 0 -> `DeathCause::Climate` ("climate", appended; N_CAUSES = 6).
With default config a plant at 20 deg C / good water is never damaged; in hostile cells it dies in about `1/stress_damage = 20` ticks.

## Traits (genome-derived, `PlantTraits::from_genome`, no new genes)
Plants ignore speed/vision/aggression/risk traits (clamped to 0), so their loci are reused (see GENOME.md):
| locus | effect |
|---|---|
| Aggression | thermal optimum `T_opt = temp_optimum + (g-0.5)*20` deg C (cold- vs warm-adapted) |
| RiskTolerance | temperature tolerance `tol = temp_tolerance * f(g)` (0.25x..4x); trade-off `breadth = sqrt(base_tol/tol)`: specialists peak higher, generalists survive more climates |
| Vision | water need `need = water_need * f(g)`; drought-tolerant (small need) pays upkeep factor `1 + 0.5*(1 - need/water_need)` |
| MaxEnergy | reserve size and growth `size_scale = sqrt(f(g))` |
| Metabolism, MaxLifespan, MaxHealth | upkeep multiplier, lifespan, stress resilience |

## New config keys
`plants.maintenance` (0.1 energy/tick), `plants.stress_damage` (0.05 of max health per hostile tick); see CONFIG.md.

## Reproduction and dispersal (TASK-012, ADR-0016)
Code: `plants::run_plants_phase` / `plants::seed_target`; tests `crates/core/tests/plant_repro.rs`.
- Asexual only: a seed is a mutated copy of one parent (`Genome::child_of_one`, `plants.mutation_rate`, `genetics.mutation_sigma`); `plants.pollination_range` is reserved/unused. Plants only come from plants (no immigration, no seed bank); zero plants stay zero and the phase draws no RNG then.
- Eligible: alive plant with energy >= max(`reproduction_threshold`, `reproduction_cost`) after its own growth/upkeep/stress this tick. One attempt per tick.
- Dispersal: distance `r = 1 + floor(R*u^2)` (`R = plants.seed_range`, 0 = own cell), uniform cell on the Chebyshev ring of radius r, wrapped over the world edges (`Grid::offset`; distances via `Grid::dist`).
- Establishment: target holds < `cell_capacity` plants (queued seeds count), fertility stock >= `plants.establish_resource`, and the child genome survives the target climate (temp factor > 0, water factor >= 0.1). Otherwise nothing is spent (stats `blocked_room/resource/climate`).
- Energy: the parent pays `reproduction_cost`; the seedling starts with half of it (`SEED_ENERGY_FRACTION`), rest is lost. Seedlings are born in the Births phase of the same tick with `parents=[parent,0]`, `generation=parent+1`.

## Not yet
Plants are eaten by herbivores (TASK-014, docs/HERBIVORES.md: `add_energy(-amount)`, death cause Predation at energy 0). Long-term balance (explosion/crash tuning) is for later tasks.

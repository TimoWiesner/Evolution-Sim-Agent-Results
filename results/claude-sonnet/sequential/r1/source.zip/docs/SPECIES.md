# Species and family tree (TASK-017, ADR-0021) — implemented

Module `core::species`; registry in `Simulation.species` (digested), `Organism.species: u32` (0 = unassigned, ids start at 1, global, never reused).

## Rule
Organism O is in species S (same kind) iff `Genome::distance(O.genome, S.reference) <= genetics.species_threshold` (equal = same species). `reference` = genome of the founding organism, frozen. Same distance/`<=` as mate compatibility (TASK-016).

## When
- Newborns inherit `parents[0]`'s species at `queue_birth` (captured in `Pending`, works if the plant parent dies the same tick).
- `Simulation::new` classifies founders (tick 0): join nearest living species within threshold else found a root species (parent 0).
- In every Births phase with `tick % genetics.species_check_interval == 0`: per kind in id order keep species if still within threshold, else move to nearest living species within threshold, else *outlier*. Outliers are greedily clustered (seed = lowest id; join first cluster whose seed is within threshold). A cluster with `>= genetics.species_min_size` members founds a new species (parent = seed's current species, arose = tick). Smaller clusters stay put. Unassigned (species 0) organisms found root species regardless of size.
- Every Births phase ends with `finish_tick`: counts members, sets `extinct = Some(tick)` for species with no living members. Extinct species never get members again.
- A label is "last classification": between checks an organism may be beyond threshold of its label.

## Queries
`Simulation::living_species(kind)`; `species.living(kind)`, `living_at(kind, t)` (state at end of tick t, any past tick), `get(id)`, `records()`, `parent_of`, `lineage(id)`, `children(id)`, `members(id)`.

## Names
Deterministic, no RNG: `Genus epithet`. Root species take the next genus per kind (bijective consonant-vowel syllable word, capitalised, ending -a plants / -us herbivores / -ax carnivores); descendants keep the root genus and take the next epithet (syllable word) in order of arising. Unique per kind. Not digested.

## Tests
`crates/core/tests/species.rs` (12): founders, determinism/names, forced split with parent/tick, min-size, threshold inclusive (equal vs next-lower float), check-tick timing, extinction, lineage chain, inheritance, unassigned, evolution run. Tests that copy `organisms` wholesale must also copy `species` (sim.rs, weather.rs do).

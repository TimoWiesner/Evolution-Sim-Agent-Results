# Configuration reference

JSON file given to `--config`. Implemented in `crates/core/src/config.rs` (ADR-0007).

Rules:
- Required (fixed) keys: `seed`, `world.width`, `world.height`, `initial.plants`, `initial.herbivores`, `initial.carnivores`. A file with only these is valid; every other key is optional and defaults as listed.
- **Unknown keys are an error** (message names the full key path, e.g. `plants.growht_rate`), so typos never silently change an experiment.
- Types are strict: integer keys need JSON integers (`64`, not `64.0`/`"64"`); float keys accept integers or floats; no `null`.
- Out-of-range values, wrong types, missing fixed keys and syntax errors are rejected; the message names the key. Cross-field rules: `climate.pole_temp <= equator_temp`; `initial_energy`, `reproduction_energy`/`reproduction_threshold` `<= max_energy`; `maturity_age <= max_age`; world area `<= 4000000`.
- `Config::to_json()` writes every key; reloading gives an equal config.
- Presets (`Config::preset(name)`): `default`, `lush`, `harsh`, `predator-rich`, `large`.
- Parameters are consumed incrementally by the simulation tasks (plants: TASK-011, see docs/PLANTS.md).
| key | type | min | max | default | description |
|---|---|---|---|---|---|
| `seed` | int | any | any | 42 | random seed (fixed key) **(required)** |
| `world.width` | int | 1 | 4096 | 64 | grid width in cells (fixed key) **(required)** |
| `world.height` | int | 1 | 4096 | 48 | grid height in cells (fixed key) **(required)** |
| `initial.plants` | int | 0 | 4000000 | 400 | plants at tick 0 (fixed key, 0 allowed) **(required)** |
| `initial.herbivores` | int | 0 | 4000000 | 120 | herbivores at tick 0 (fixed key, 0 allowed) **(required)** |
| `initial.carnivores` | int | 0 | 4000000 | 20 | carnivores at tick 0 (fixed key, 0 allowed) **(required)** |
| `climate.equator_temp` | float | -20 | 60 | 28.0 | mean annual temperature at the equator (deg C) |
| `climate.pole_temp` | float | -60 | 40 | -15.0 | mean annual temperature at the poles (deg C); must be <= equator_temp |
| `climate.seasonal_amplitude` | float | 0 | 40 | 8.0 | seasonal temperature swing (deg C) |
| `climate.seasonal_precip_amplitude` | float | 0 | 0.95 | 0.3 | relative seasonal swing of precipitation (wet/dry seasons) |
| `climate.season_length` | int | 2 | 100000 | 200 | ticks per year |
| `climate.precip_mean` | float | 0 | 5 | 1.0 | average precipitation (relative units) |
| `climate.precip_latitude_variation` | float | 0 | 1 | 0.6 | strength of wet/dry latitude bands |
| `climate.weather_noise` | float | 0 | 1 | 0.15 | amplitude of random weather fluctuations |
| `climate.weather_period` | int | 1 | 10000 | 25 | typical weather change period (ticks) |
| `climate.terrain_noise` | float | 0 | 1 | 0.2 | spatial unevenness of local climate |
| `climate.cover_fraction` | float | 0 | 1 | 0.3 | fraction of cells offering cover (refuge) to prey |
| `climate.cover_protection` | float | 0 | 0.95 | 0.8 | fraction by which cover cells cut the success chance of an attack on a herbivore standing there (ADR-0031) |
| `climate.resource_regen` | float | 0 | 100 | 2.0 | cell resource regeneration per tick |
| `climate.resource_max` | float | 0.1 | 10000 | 20.0 | cell resource capacity |
| `plants.initial_energy` | float | 0.1 | 10000 | 25.0 | energy of a starting plant; must be <= max_energy |
| `plants.max_energy` | float | 0.1 | 10000 | 50.0 | maximum stored energy/biomass |
| `plants.growth_rate` | float | 0 | 100 | 1.5 | energy gained per tick at optimal conditions |
| `plants.resource_uptake` | float | 0 | 100 | 2.0 | max cell resource taken per tick |
| `plants.water_need` | float | 0 | 10 | 0.3 | precipitation needed for full growth |
| `plants.temp_optimum` | float | -20 | 50 | 20.0 | optimal temperature (deg C) |
| `plants.temp_tolerance` | float | 0.1 | 60 | 12.0 | temperature deviation at which growth falls off |
| `plants.seed_range` | int | 0 | 50 | 3 | seed dispersal distance (cells) |
| `plants.pollination_range` | int | 0 | 50 | 2 | reserved, unused (plants reproduce asexually, ADR-0016) |
| `plants.reproduction_threshold` | float | 0.1 | 10000 | 8.0 | energy needed to reproduce; must be <= max_energy |
| `plants.reproduction_cost` | float | 0 | 10000 | 4.0 | energy spent on an offspring |
| `plants.establish_resource` | float | 0 | 10000 | 1.0 | minimum cell fertility stock for a seed to establish |
| `plants.max_age` | int | 1 | 1000000 | 400 | lifespan in ticks |
| `plants.cell_capacity` | int | 1 | 1000 | 4 | max plants per cell (density limit) |
| `plants.mutation_rate` | float | 0 | 1 | 0.05 | per-gene mutation probability at reproduction |
| `plants.maintenance` | float | 0 | 100 | 0.1 | energy a plant spends per tick on upkeep (times its metabolism trait) |
| `plants.graze_reserve` | float | 0 | 10000 | 6.0 | energy a plant keeps in its roots: herbivores can only eat the energy above it, so grazing alone never kills a plant (a local refuge) |
| `plants.stress_damage` | float | 0 | 1 | 0.05 | fraction of max health lost per tick in hostile climate (too cold/hot or too dry) |
| `herbivores.initial_energy` | float | 0.1 | 10000 | 50.0 | starting energy; must be <= max_energy |
| `herbivores.max_energy` | float | 0.1 | 10000 | 100.0 | energy capacity |
| `herbivores.base_metabolism` | float | 0 | 100 | 0.3 | energy cost per tick |
| `herbivores.move_cost` | float | 0 | 100 | 0.15 | extra energy per cell moved |
| `herbivores.speed` | float | 0.1 | 16 | 1.0 | cells per tick (base value of the trait) |
| `herbivores.vision` | int | 1 | 64 | 4 | perception radius (cells) |
| `herbivores.strength` | float | 0 | 100 | 1.0 | base strength |
| `herbivores.health` | float | 0.1 | 10000 | 10.0 | base health |
| `herbivores.max_age` | int | 1 | 1000000 | 800 | lifespan in ticks; must be >= maturity_age |
| `herbivores.maturity_age` | int | 0 | 1000000 | 50 | age at which reproduction becomes possible |
| `herbivores.reproduction_energy` | float | 0 | 10000 | 60.0 | energy needed to mate; must be <= max_energy |
| `herbivores.reproduction_cooldown` | int | 0 | 100000 | 50 | ticks between births |
| `herbivores.mate_range` | int | 0 | 64 | 4 | distance to find a mate (cells) |
| `herbivores.offspring_energy` | float | 0 | 10000 | 25.0 | energy given to a newborn |
| `herbivores.litter_size` | int | 1 | 16 | 1 | maximum offspring per birth |
| `herbivores.satiation_limit` | float | 0.1 | 1 | 0.9 | energy fraction above which the animal stops eating |
| `herbivores.digestion_efficiency` | float | 0.01 | 1 | 0.6 | fraction of food energy gained |
| `herbivores.handling_time` | int | 0 | 1000 | 2 | ticks spent eating after a meal/kill |
| `herbivores.aggression` | float | 0 | 1 | 0.3 | initial behavioural tendency to attack/compete |
| `herbivores.risk_tolerance` | float | 0 | 1 | 0.4 | initial tendency to accept danger |
| `herbivores.mutation_rate` | float | 0 | 1 | 0.05 | per-gene mutation probability at reproduction |
| `herbivores.bite_size` | float | 0 | 1000 | 3.0 | max plant energy taken per tick before the aggression factor (0.5 + aggression) |
| `herbivores.temp_comfort` | float | -20 | 50 | 18.0 | temperature (C) with no climate cost |
| `herbivores.temp_tolerance` | float | 0.1 | 60 | 14.0 | distance from temp_comfort (C) before the climate cost starts |
| `herbivores.climate_cost` | float | 0 | 10 | 0.5 | extra upkeep fraction per tolerance width beyond the comfort band (capped at 4 widths) |
| `herbivores.attack_cost` | float | 0 | 1000 | 0.5 | energy paid per attack (hit or miss), times the metabolism trait; used by carnivores |
| `carnivores.initial_energy` | float | 0.1 | 10000 | 60.0 | starting energy; must be <= max_energy |
| `carnivores.max_energy` | float | 0.1 | 10000 | 200.0 | energy capacity |
| `carnivores.base_metabolism` | float | 0 | 100 | 0.9 | energy cost per tick |
| `carnivores.move_cost` | float | 0 | 100 | 0.2 | extra energy per cell moved |
| `carnivores.speed` | float | 0.1 | 16 | 1.2 | cells per tick (base value of the trait) |
| `carnivores.vision` | int | 1 | 64 | 4 | perception radius (cells) |
| `carnivores.strength` | float | 0 | 100 | 2.0 | base strength |
| `carnivores.health` | float | 0.1 | 10000 | 20.0 | base health |
| `carnivores.max_age` | int | 1 | 1000000 | 1000 | lifespan in ticks; must be >= maturity_age |
| `carnivores.maturity_age` | int | 0 | 1000000 | 120 | age at which reproduction becomes possible |
| `carnivores.reproduction_energy` | float | 0 | 10000 | 170.0 | energy needed to mate; must be <= max_energy |
| `carnivores.reproduction_cooldown` | int | 0 | 100000 | 150 | ticks between births |
| `carnivores.mate_range` | int | 0 | 64 | 2 | distance to find a mate (cells) |
| `carnivores.offspring_energy` | float | 0 | 10000 | 60.0 | energy given to a newborn |
| `carnivores.litter_size` | int | 1 | 16 | 1 | maximum offspring per birth |
| `carnivores.satiation_limit` | float | 0.1 | 1 | 0.8 | energy fraction above which the animal stops eating |
| `carnivores.digestion_efficiency` | float | 0.01 | 1 | 0.7 | fraction of food energy gained |
| `carnivores.handling_time` | int | 0 | 1000 | 20 | ticks spent eating after a meal/kill |
| `carnivores.aggression` | float | 0 | 1 | 0.6 | initial behavioural tendency to attack/compete |
| `carnivores.risk_tolerance` | float | 0 | 1 | 0.5 | initial tendency to accept danger |
| `carnivores.mutation_rate` | float | 0 | 1 | 0.05 | per-gene mutation probability at reproduction |
| `carnivores.bite_size` | float | 0 | 1000 | 4.0 | max plant energy taken per tick before the aggression factor (0.5 + aggression) |
| `carnivores.temp_comfort` | float | -20 | 50 | 18.0 | temperature (C) with no climate cost |
| `carnivores.temp_tolerance` | float | 0.1 | 60 | 14.0 | distance from temp_comfort (C) before the climate cost starts |
| `carnivores.climate_cost` | float | 0 | 10 | 0.5 | extra upkeep fraction per tolerance width beyond the comfort band (capped at 4 widths) |
| `carnivores.attack_cost` | float | 0 | 1000 | 3.0 | energy paid per attack (hit or miss), times the metabolism trait; used by carnivores |
| `genetics.mutation_sigma` | float | 0 | 1 | 0.05 | standard deviation of a gene mutation step |
| `genetics.crossover_rate` | float | 0 | 1 | 0.5 | probability a gene comes from the other parent allele |
| `genetics.founder_variation` | float | 0 | 0.5 | 0.05 | half-width of the uniform noise added to each founder allele |
| `genetics.species_threshold` | float | 0.001 | 10 | 0.25 | genetic distance beyond which lineages are separate species |
| `genetics.species_min_size` | int | 1 | 10000 | 3 | minimum members for a species to be recorded |
| `genetics.species_check_interval` | int | 1 | 100000 | 50 | ticks between speciation checks |

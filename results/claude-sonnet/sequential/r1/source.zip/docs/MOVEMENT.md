# Animal sensing and movement (TASK-013, ADR-0017)

Code: `crates/core/src/movement.rs`; tests: `crates/core/tests/movement.rs`; bench: `cargo run --release -p evosim-core --example tick_bench`.

## Sensing
`vision_cells(o) = max(1, floor(traits.vision))`, Chebyshev toroidal distance. `perceive(spatial, orgs, id)` = `SpatialIndex::query` around the animal (wraps across all edges), minus self and organisms no longer active (marked dead this tick; the index lags until the Deaths phase). Order: (dist, kind, id). Own cell (dist 0) is perceived.

## Speed and steps
Each tick `move_credit += speed; steps = floor(credit); credit -= steps` (credit in [0,1)). Per-tick distance <= ceil(speed); long-run <= speed*ticks. A step is a king move (one cell, 8 directions). Paths use `Grid::step_toward` each step, i.e. the shortest wrapped way (ties at exactly N/2 go positive); no overshoot (`min(steps, dist)`), `plan_path` lists visited cells.

## Cost
`move_cost = herbivores|carnivores.move_cost * metabolism * n * (1 + SPRINT*(n-1))`, `SPRINT = 0.1` (code constant). Linear in distance over time, superlinear in steps per tick. `n` is reduced until affordable; energy never goes below 0 by moving; an animal without energy stays put. Herbivores additionally pay a running cost every tick (docs/HERBIVORES.md); carnivores' idle metabolism is still NOT charged (TASK-015).

## Targets and wandering
Herbivores use `herbivore::run_herbivore_phase` (best-scoring plant, stop at feeding distance 1, wander via `movement::wander` when nothing is worthwhile or when satiated; see docs/HERBIVORES.md). Carnivore for the nearest Herbivore (ties: lowest id); in the same cell it stays (eating/attacking = TASK-014/015). Chasing may use the full allowance. **Nothing in sight**: correlated random walk, keep `heading` with p=0.75 (`KEEP_HEADING`) else new random of 8 directions, at most 1 step per tick (cruising). Draws use the sim RNG in ascending id order.

## Cell-sharing rule (applies everywhere)
Any number of organisms of any kind may share a cell, except plants: at most `plants.cell_capacity` per cell. Single source: `organism::cell_limit(cfg, kind)` (`None` = unlimited), used by plant seeding (`plants.rs`) and `movement::can_enter`. Movement is never blocked or order dependent.

## Spatial index wiring
`Simulation.spatial` built in `new`, `move_to` per animal move, `remove` in Deaths, `insert` in Births. `check_index()` (called by `debug_assert!` in the Index phase and by tests) compares it to `organisms`. Code that replaces `sim.organisms` must call `sim.rebuild_index()`.

## Measurement
`tick_bench` (128x128, 1500 plants, 400 herbivores, 100 carnivores, 300 ticks, release): ~984 ticks/s (plants collapse to 13 as there is no climate tuning; indicative only).

# Organisms and life cycle (TASK-008, ADR-0012)

Code: `crates/core/src/organism.rs`; tests: `crates/core/tests/organisms.rs` + unit tests.

## Organism
`id` (u64, from one counter starting at 1, never reused), `kind` (Plant/Herbivore/Carnivore), `pos`, `age` (ticks, u32), `energy` in [0,max_energy], `health` in [0,max_health] (both private; only `set_energy/add_energy/damage/heal` write them, all clamp, NaN = no change/0), `traits`, `parents` ([0,0] founders; plants use parents[0]), `generation` (founders 0, child = max(parent gen)+1), `birth_tick`, `alive`, `death: Option<{tick, cause}>`.
Causes: old_age, starvation, injury, predation, other, climate (append-only; climate = hostile cell for a plant, TASK-011).

## Traits (`Traits::range(kind)`; out-of-range values are clamped, NaN -> range minimum)
| trait | plant | animal |
|---|---|---|
| speed | 0 | 0.1..16 |
| strength | 0..100 | 0..100 |
| fertility | 0..1 | 0..1 |
| max_health | 0.1..10000 | same |
| max_lifespan (ticks, u32) | 1..1e6 | same |
| max_energy | 0.1..10000 | same |
| metabolism (cost multiplier) | 0.25..4 | same |
| vision | 0 | 1..64 |
| aggression | 0 | 0..1 |
| risk_tolerance (1 - caution) | 0 | 0..1 |
Founder traits: `Traits::baseline(kind, cfg)` from `plants.*`/`herbivores.*`/`carnivores.*` (fertility 0.5, metabolism 1). No new config keys.

## Storage
`Organisms`: one Vec per kind, ascending id (ids only grow, appended), lookup by binary search, removal by stable partition in the Deaths phase.

## Same-tick rule
Behaviour phases defer: `mark_dead` (immediate flag; first cause wins; never acts again; excluded from `active_ids`; cannot be a parent of later `queue_birth`) and `queue_birth` (parents must be alive at queue time). Deaths phase: age+1, auto causes in priority Injury (health 0) > Starvation (energy 0) > OldAge (age >= max_lifespan), remove + count. Births phase: queued births get ids in queue order, appended, counted. So deaths are evaluated before births; newborns neither age nor die in their birth tick; a parent that died in the same tick is still recorded as parent. Counters (`LifeStats`: founded, births, deaths, deaths_by_cause per kind) are cumulative since tick 0; `count == founded + births - deaths`. `Simulation.last_births/last_deaths` hold the per-tick numbers; events `Born`/`Died` when `record_events`.
Founders are created only in `Organisms::populate` (stream 2 of the seed).

## Genomes (TASK-009)
Every organism owns an immutable `Genome`; `traits` are computed from it at construction against `Organisms::baseline(kind)`. `NewBorn` carries a genome. Founder genomes use stream 3. See docs/GENOME.md.

## Movement state (TASK-013)
`Organism.move_credit` (f64 in [0,1), fractional speed carry) and `heading` (u8, 0 none, 1..8 king directions) are in the digest. `organism::cell_limit` is the single cell-sharing rule. See docs/MOVEMENT.md.

Note (TASK-016): `Organism.cooldown` = ticks until an animal may reproduce again; digested. See docs/REPRODUCTION.md.

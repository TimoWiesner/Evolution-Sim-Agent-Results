# Ecology integration (TASK-018, ADR-0022)

## Tick order (contract of `Simulation::step`, `Phase::ORDER`)
1. climate (season, weather) 2. plants (regen, growth, upkeep, stress, seeding queued) 3. herbivores 4. carnivores 5. deaths (all removals; per-kind ledger exact) 6. births (reproduction, resolve births, species classification and extinction sweep) 7. index check.
Newborns appear after deaths, so a newborn never dies or is eaten in its birth tick. Test: `tick_order_documented`.

## Extinction is final
Organisms are created only by `Organisms::populate` (tick 0) and by `queue_birth` called from `plants.rs` (seeding) and `reproduction.rs` (mating), both needing living parents (test `only_reproduction_creates_organisms_in_source`, `zero_stays_zero_with_other_kinds_alive`, `extinct_kind_stays_extinct_in_a_real_run`). No code looks at population sizes.

## Ledger
`Simulation::ledger_check()`: per kind `founded + births - deaths == living == stored`. `run_survival` checks it every tick (report column `ledger errors`), tests also recompute it from per-tick `last_births/last_deaths`.

## Stabilising mechanisms relied on (all local)
Cell fertility stock regenerating to a cap and density cap per cell (plants); **root reserve** `plants.graze_reserve` (new key): herbivores can only eat plant energy above the reserve, so grazing alone never kills a plant and grazed plants regrow from the same cell stock (a refuge that every plant has at all times); low plant seeding threshold so grazed plants still reproduce; herbivore bite limit + satiation + mate search radius 4; carnivore success p=A/(A+D), long handling time (20), costly attacks, short vision (4), slow reproduction. `climate.cover_fraction` exists as a key but no code uses it yet (a possible refuge mechanism for TASK-027).

## Balance (defaults changed, see docs/CONFIG.md)
Before: plants alone 400 -> ~12; with 120 herbivores plants were extinct by tick ~150. Changes: resource_regen 0.5->2, plant growth 0.8->1.5, uptake 1->2, initial energy 5->25, reproduction threshold 30->8 and cost 10->4, graze_reserve 6; herbivore initial energy 50, metabolism 0.3, bite 3, maturity 50, mate_range 4, cooldown 50; carnivore metabolism 0.9, speed 1.2, vision 4, strength 2, handling 20, attack_cost 3, reproduction 170 energy / cooldown 150 / offspring 60. Presets lush/harsh adjusted around the new default.
Observed dynamics: plants fill the world (cell cap, ~12,270 plants on 64x48); herbivores boom to several hundred to ~1400 then crash by overgrazing/predation; carnivores follow the herbivores and die out 150-200 ticks later. Coexistence is short (TASK-027 tunes it).

## Survival report (re-run command)
`cargo run --release -p evosim-core --example survival -- 10000 5` (args: ticks, seeds (seeds 1..=N), optional config JSON; default = `Config::default()`, 64x48, 400/120/20). Takes ~95 s in release. "extinct at tick N" = completed ticks after which the kind first had 0 living (final).
Result recorded in this task (default parameters, 10,000 ticks):

```
seed 1 (10000 ticks, all three alive for 1328 ticks, ledger errors 0)
  Plant      survived             final  12265 peak  12281 births  268115 deaths  256250
  Herbivore  extinct at tick 1329 final      0 peak    956 births    2694 deaths    2814
  Carnivore  extinct at tick 1530 final      0 peak     47 births      59 deaths      79
seed 2 (10000 ticks, all three alive for 412 ticks, ledger errors 0)
  Plant      survived             final  12265 peak  12280 births  286770 deaths  274905
  Herbivore  extinct at tick 413  final      0 peak    120 births      93 deaths     213
  Carnivore  extinct at tick 532  final      0 peak     23 births       7 deaths      27
seed 3 (10000 ticks, all three alive for 607 ticks, ledger errors 0)
  Plant      survived             final  12267 peak  12281 births  290333 deaths  278466
  Herbivore  extinct at tick 608  final      0 peak    120 births     206 deaths     326
  Carnivore  extinct at tick 758  final      0 peak     23 births      12 deaths      32
seed 4 (10000 ticks, all three alive for 2705 ticks, ledger errors 0)
  Plant      survived             final  12254 peak  12283 births  233728 deaths  221874
  Herbivore  extinct at tick 2706 final      0 peak   1073 births    7094 deaths    7214
  Carnivore  extinct at tick 2874 final      0 peak     73 births     167 deaths     187
seed 5 (10000 ticks, all three alive for 1365 ticks, ledger errors 0)
  Plant      survived             final  12268 peak  12286 births  234488 deaths  222620
  Herbivore  extinct at tick 1366 final      0 peak   1387 births    3326 deaths    3446
  Carnivore  extinct at tick 1550 final      0 peak     67 births      86 deaths     106

real	1m33.426s
user	1m32.322s
sys	0m1.092s
```

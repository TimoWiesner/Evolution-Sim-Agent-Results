# Checkpoints (TASK-022, ADR-0026)

`evosim run --config C --ticks A --out o1.json --save s.ckpt`, then `evosim run --load s.ckpt --ticks B --out o2.json` gives the same `final`, `totals` and `state_hash` as one run of `A+B` ticks (`tick_start` of the second result is `A`; `--seed`/`--config` are not accepted together with `--load`).

File: `EVOSIMCK` | u32 version (1) | u64 payload length | payload | SHA-256(payload). Little-endian, floats as bit patterns, no compression. Payload contents and validation: see ADR-0026. Any problem (missing, unreadable, empty, truncated, trailing bytes, flipped bits, other version, inconsistent content) -> message on stderr, exit 2, no result file.

When you add simulation state: add it to the writer/reader in the owning module, bump `FORMAT_VERSION`, run `cargo test --release -p evosim-core --test checkpoint`.

#!/usr/bin/env bash
# usage: trial.sh NAME TICKS "SEEDS" [--param k=v ...]  -> results/trial-NAME, prints coexist summary
set -e
cd "$(dirname "$0")/../.."
n=$1; t=$2; s=$3; shift 3
./evosim batch --config experiments/balance/baseline.json --seeds "$s" --ticks "$t" --sample-every 10 --out-dir experiments/balance/results/trial-$n --quiet "$@"
for d in experiments/balance/results/trial-$n/*/ ; do [ -d "$d" ] && { echo "== $d"; python3 -I experiments/balance/analyze.py "$d" | tail -1; }; done
[ -f experiments/balance/results/trial-$n/seed-$(echo $s|cut -d, -f1|cut -d. -f1).json ] && python3 -I experiments/balance/analyze.py experiments/balance/results/trial-$n | tail -1 || true

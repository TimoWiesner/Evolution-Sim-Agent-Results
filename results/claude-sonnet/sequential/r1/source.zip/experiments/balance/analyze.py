#!/usr/bin/env python3
"""Usage: analyze.py DIR  -> per seed/kind extinction tick or survived, coexistence ticks."""
import json,sys,glob,os
d=sys.argv[1]
rows=[];co=[]
for f in sorted(glob.glob(os.path.join(d,'seed-*.json')),key=lambda p:int(p.split('-')[-1][:-5])):
    r=json.load(open(f)); ser=r['series']; seed=r['seed']
    ext={}
    for k in('plants','herbivores','carnivores'):
        z=[p['tick'] for p in ser if p[k]==0]
        ext[k]=z[0] if z else None
    end=r['tick_end']
    first=min([v for v in ext.values() if v is not None],default=end)
    co.append(first)
    print(seed,' '.join(f"{k[:4]}={'surv('+str(r['final'][k])+')' if ext[k] is None else 'ext@'+str(ext[k])}" for k in ext),f"coexist={first}")
co.sort(); print('coexistence ticks median',co[len(co)//2],'mean',sum(co)/len(co),'full10k',sum(c>=end for c in co),'/',len(co))

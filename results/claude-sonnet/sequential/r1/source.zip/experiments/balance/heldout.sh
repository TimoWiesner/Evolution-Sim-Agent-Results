#!/usr/bin/env bash
cd "$(dirname "$0")/../.."
B="./evosim batch --config experiments/balance/baseline.json --seeds 201..205 --ticks 10000 --sample-every 10 --quiet"
$B --out-dir experiments/balance/results/heldout-new >/dev/null
python3 -I experiments/balance/analyze.py experiments/balance/results/heldout-new > experiments/balance/results/heldout-new.txt
$B --param climate.cover_protection=0.0 --param climate.cover_fraction=0.15 --out-dir experiments/balance/results/heldout-old >/dev/null
python3 -I experiments/balance/analyze.py experiments/balance/results/heldout-old/*/ > experiments/balance/results/heldout-old.txt
echo done > experiments/balance/results/heldout.done

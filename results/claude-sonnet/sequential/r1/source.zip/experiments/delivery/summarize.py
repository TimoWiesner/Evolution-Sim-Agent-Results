#!/usr/bin/env python3
"""Usage: summarize.py DIR [DIR...] -> markdown table: per seed final counts, first extinction tick per kind,
coexistence (= tick of the first extinction of any kind, or tick_end), ledger check, ticks/s."""
import json, glob, os, sys
init_kinds = ("plants", "herbivores", "carnivores")
for d in sys.argv[1:]:
    print(f"\n### {d}\n")
    print("| seed | ticks | final P/H/C | plants ext. | herbivores ext. | carnivores ext. | all three until | ledger | ticks/s |")
    print("|---|---|---|---|---|---|---|---|---|")
    co = []
    files = sorted(glob.glob(os.path.join(d, "seed-*.json")), key=lambda p: int(os.path.basename(p)[5:-5]))
    for f in files:
        r = json.load(open(f)); s = r["series"]
        ext = {}
        for k in init_kinds:
            z = [p["tick"] for p in s if p[k] == 0]
            ext[k] = z[0] if z else None
        end = r["tick_end"]
        first = min([v for v in ext.values() if v is not None], default=end)
        co.append(first)
        a = r["series"][0]
        led = all(a[k] + r["totals"]["births"][k] - r["totals"]["deaths"][k] == r["final"][k] for k in init_kinds)
        fin = "/".join(str(r["final"][k]) for k in init_kinds)
        e = lambda k: "survived" if ext[k] is None else str(ext[k])
        print(f"| {r['seed']} | {end} | {fin} | {e('plants')} | {e('herbivores')} | {e('carnivores')} | {first if first < end else str(end) + ' (full run)'} | {'ok' if led else 'BAD'} | {r['ticks_per_second']:.0f} |")
    if co:
        co2 = sorted(co)
        print(f"\nAll three kinds alive until: median {co2[len(co2)//2]}, mean {sum(co)/len(co):.0f}, min {co2[0]}, max {co2[-1]}; full 10,000 ticks in {sum(c >= r['tick_end'] for c in co)}/{len(co)} runs.")

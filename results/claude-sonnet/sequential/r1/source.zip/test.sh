#!/usr/bin/env bash
# The one test command: cargo tests (unit, integration, randomised invariants) + entry-point contract checks + full CONTRACT verification (no UI; add --ui to scripts/verify_contract.sh for the browser checks).
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
export PATH="$HOME/.cargo/bin:$PATH"
cargo test --release --workspace --locked
scripts/contract_check.sh target/release/evosim
scripts/verify_contract.sh target/release/evosim

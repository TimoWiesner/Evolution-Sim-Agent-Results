# Complete-state checkpoints

`run` saves and resumes completed ticks through the same engine as a fresh run:

```sh
./evosim run --config target/run-config.json --ticks 53 --out target/first.json --save target/world.evo
./evosim run --load target/world.evo --ticks 147 --out target/resumed.json --save target/world.evo
```

These commands reach absolute tick 200. On the same machine/build, `state_hash`,
`final` and cumulative `totals` equal a fresh 200-tick run with the same effective
configuration/seed. `--ticks 0` can save the initial state or copy a checkpoint
without changing it. Saving consumes no RNG and changes no engine state.

Exactly one of `--config` or `--load` is required. `--seed` is allowed only with
configuration input; a loaded checkpoint retains its complete effective settings
and exact original integer seed. `--ticks` counts additional ticks. Start plus
additional ticks must fit u64. Loaded results report absolute `tick_start` and
`tick_end`. Samples occur at start, then every K additional ticks, then end once;
for start 7, K 13 and end 53 they are 7, 20, 33, 46, 53. Default K remains
`max(1, additional_ticks / 100)`; zero additional ticks produces one sample.

## Format 1

Files are uncompressed binary, independent of Rust struct layout:

| Offset | Contents |
| --- | --- |
| 0 | 17 ASCII bytes `EVOSIM-CHECKPOINT` |
| 17 | little-endian u32 envelope version, currently 1 |
| 21 | little-endian u64 canonical payload byte length N |
| 29 | N exact canonical state-schema-1 bytes |
| 29 + N | 32 raw SHA-256 bytes covering header and payload |

There are no trailing bytes. Canonical state includes its own magic, schema and
ordered model versions. Unknown envelope/schema/model versions are rejected;
there is no historical migration. SHA detects accidental corruption, not file
authorship. No compression avoids a new dependency and keeps length/checksum
verification straightforward. State hash schema and existing golden hash are
unchanged: the checkpoint envelope is excluded from `state_hash`.

The payload retains the full [canonical inventory](decisions/ADR-015-canonical-state-and-run.md):
effective config and exact seed, world dimensions and climate model, clock,
all four RNG words and algorithm version, temporal settings/weather offsets,
every row-major resource store, living IDs/kinds/species/cells/ages/vitals/DNA,
ordered parents/generations/birth ticks/reproduction cooldowns, all species
including immutable founders and extinct ancestry records, next ID (including
exhaustion), request sequence, u128 initial/current/birth/death/cause counters,
and ordered death history. Pending transactions must be empty. Spatial buckets
and phenotypes are derived; observations, metrics buffers, filenames and wall
clocks are excluded.

Owner-local readers validate bounded lengths before allocation, primitive tags,
UTF-8, finite bounded values, settings/dimension/clock agreement, sorted unique
IDs, life and lineage chronology, historical/species references, counters and
allocation accounting. Only spatial buckets and procedural base climate are
rebuilt. No initialization, classification, random draws or ecological changes
occur during loading. Re-encoding must exactly match the original payload.

## Files and failure behavior

Missing, truncated, damaged, wrong-version or semantically invalid checkpoints
return exit 2 with stderr and no newly created result. Nonregular checkpoint
inputs (including symlinks and FIFOs) are rejected. Save/result destinations must
be regular files or absent, with existing parents. Input/result and save/result
aliases (including existing hard links and normalized parent spellings) are
rejected; a save cannot alias the config. Loading and saving the same regular
checkpoint is supported, including hard-linked names: load finishes first and
atomic replacement updates the save path.

Result and checkpoint bytes are prepared before publication. Each file uses a
same-directory exclusive temporary, write, flush, close and rename. Checkpoint
publishes first, result last. A save failure blocks result publication; a later
result publication failure may leave the successfully saved checkpoint. Existing
outputs are preserved until their own successful publication. There is no
transaction spanning both files, fsync crash-durability guarantee or support for
concurrent writers racing on the same destination.

Library APIs are `persistence::checkpoint_bytes(&Simulation)`,
`from_checkpoint_bytes(&[u8])` and `load_checkpoint(path)`, returning io::Result.
Application adapters own publication; there is no UI save/load in this task.
Byte APIs use memory proportional to the payload plus restored engine; encoding
and validation scan all records, with ordered map/set lookups adding logarithmic
cost per record. Retained death/species histories grow without a fixed cap.
Malformed counts are bounded by actual bytes; legitimate huge states may still
exhaust memory or disk. OS OOM termination is not a recoverable status-2 error.
Runtime is offline and display independent, including the static distribution.
Continuation is guaranteed for the same build/machine; cross-libm/build float
hash equality and compatibility with future state models are not promised.

Tests in `tests/checkpoint.rs`, `tests/checkpoint_cli.rs`, owner unit tests and
`tests/test_entrypoints.py` exercise initial/nonzero splits, future evolution,
recruitment/cooldowns/speciation, corruption, semantic validation, path protection
and copied static-distribution continuation. Exact commands/results are recorded
in the TASK-022 implementation handoff.

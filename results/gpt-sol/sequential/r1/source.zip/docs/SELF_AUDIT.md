# Product self-audit — TASK-028

This audit describes the delivered hunting-model-2 build. Evidence is indexed in
[VERIFICATION.md](VERIFICATION.md); older ecology reports are historical. “Met”
means implemented and checked within the stated limits, rather than biological
realism or universal performance. No product code or default changed in TASK-028.

| PROJECT requirement | Status | Evidence and qualification |
|---|---|---|
| Finite 2-D raster world | Met | `tests/topology.rs`, `tests/simulation.rs`; integer cells and validated dimensions |
| Left/right and top/bottom wrap | Met | Exhaustive small-world topology tests, randomized signed multiple-wrap oracle in `tests/reliability.rs` |
| Cell-to-cell animal movement | Met | `animal_movement`, `herbivore_feeding`, `carnivore_hunting`; randomized old/new living positions remain within genetic speed budget; each internal step adjacent |
| Wrap-aware perception and spatial lookup | Met | `spatial`, `topology`, randomized brute-force nearby-ID and unique-cell comparison, seam cases |
| Configurable size and initial P/H/C populations | Met | `config`, `run_cli`, browser experiment tests; 1-cell axes, zero and stacked counts valid |
| Latitudinal climate, continuous torus seam | Met | `climate`, CLIMATE.md; periodic cold-hot-cold band compromises Earth's two distinct poles; discrete seam neighbors need not be equal |
| Temperature and precipitation | Met | Normalized [0,1] fields, biome rendering, `climate` and randomized per-cell checks |
| Seasons/weather vary with ticks and affect life | Met | `temporal_climate`, resource/upkeep/growth tests; persistent bounded weather and seasonal amplitudes, including disabled/max settings |
| Plant resource consumption/growth | Met | `resources`, `plants`, bit-exact row regeneration oracle; finite capped resources and paid growth |
| Plant reproduction/DNA/mutation/speciation | Met | Clonal seeds, `plant_reproduction`, `genome`, `species`; pollination optional and absent |
| Herbivores eat plants | Met | `herbivore_feeding`, isolated recruitment and food-removal ecology tests |
| Carnivores eat herbivores | Met | `carnivore_hunting`, satiety boundary tests; probabilistic paid attacks, prey-energy nutrition |
| Speed, strength, health, fertility traits | Met | All kinds store 12 bounded loci; `traits`/`organism`/genome mapping tests; inactive plant locomotion loci retained |
| Genetic aggression/risk behavior | Met | Inherited aggression and risk affect local action; `genome`, feeding/hunting/action tests |
| Coherent finite lifespan, energy, nutrition, costs, reproduction | Met | `lifecycle`, `plants`, feeding/hunting/reproduction, accounting/resource bounds; simplified model units, no realism claim |
| Two distinct animal parents, inherited DNA, mutation | Met | `animal_reproduction`, `genome`; haploid crossover, maturity/compatibility/cooldown/energy gates; no diploid genetics |
| Explicit stable species criterion, emergent species | Met | Immutable founders, integer distance <=1/10, lineage/extinction records; `species`, mutation/speciation fixtures; not biological reproductive isolation |
| No forced anti-extinction/replenishment | Met | Source audit below; absorbing-zero and food-removal tests; formal worlds all go extinct |
| Target simultaneous 1,000–5,000 | Partly met | Measured primary living floor >=2,000 and mixed work; demo begins at2,068. Populations fluctuate and eventual collapse prevents sustained three-kind occupancy |
| >=100 headless ticks/s at2,000 on disclosed setup | Met within measured workload | PERFORMANCE.md/`performance` release guard, current whole-suite raw guard. Historical model2 primary median857.619/s at2304..5118, mixed671.812/s at2559..3059. Primary has zero initial herbivores; 10/s test guard is weaker than100/s target and no universal guarantee |
| Same engine for headless and UI | Met | Real browser tick10/100 hashes equal CLI; no renderer in core; `test_ui`, `test_ui_controls`, `test_ui_experiments` |
| Climate-colored map/entity differentiation | Met | Real default/demo main.png, legend and browser render tests |
| Pan/zoom | Met | `ui_camera.cjs`, real browser drag/wheel/Fit tests |
| Run/pause/reset/step/speed | Met | Fake-duration session tests and real browser control tests, paused step exactly one |
| Inspect organism | Met | Stable-ID stack chooser, DNA/traits/parents/generation, death snapshot; browser inspection tests |
| Edit initial parameters, presets, seed | Met | All21 numeric config leaves, three presets; exact-token seed handling; browser configuration tests |
| Config import/export in >=1 format | Met | JSON shared validator and browser files; TOML/YAML absent and optional |
| Full-state save/load including DNA/RNG/climate | Met | Checkpoint codec inventory and semantic corruption tests, exact continuation; CLI/browser interchange. Old hunting-model1 checkpoints rejected intentionally |
| Headless multiseed/parameter batches and statistics | Met | `batch_cli`, copied distribution batch and CSV tests; exact repeatable summaries |
| Population/birth/death/diversity visualizations | Met | UI Canvas population/events/living-species charts, screenshots and browser tests; species counts measure operational diversity |
| Genetic distributions and means | Met | 12 selectable current20-bin histograms and mean history; `ui_charts.cjs`, browser chart tests |
| Generation trends visualization | Partly met | Generation max/mean time series exported in result analytics, individual generation in inspector; no dedicated generation chart in current UI (`ui/charts.js` has population/events/species/means only) |
| Unit/integration/regression/property tests | Met | One-command suite, randomized72-case deterministic corpus and independent geometry/accounting/value oracles; no third-party property framework required |
| Multi-thousand-tick testing and repeatability | Met | Eight randomized2200-tick cases, existing5000-tick food-removal tests, six formal10000-tick runs and12 candidate runs; equality/RNG/checkpoint/hash replay |
| Long coexistence goal | Partly met | Demo first-zero1111..1113 vs fixed310..315 on42..44; all empty by10000. Durable coexistence not reached; no required equilibrium promised |

## Mechanism and architecture audit

Initialization in `Simulation::new`/`Population::initialize` is the only non-parent
source. Ordinary simulation births go through paid plant seed or two-parent animal
reproduction and commit. A source read of `src/simulation.rs` finds no global
`counts()` call in production decisions; population counts, totals and species
membership serve bookkeeping, initialization, outputs and classification rather
than survival protection. Species classification uses genetic distance and
extinction identity; it does not feed abundance to ecological actions.

Resources regenerate per cell up to capacity using precipitation; plants consume
those stores. Herbivores receive nutrition from bounded plant bites; carnivores
from prey; reproduction transfers paid parent energy. Upkeep, movement, attack,
aging and climate damage still apply. Local crowding/resource competition and
carnivore satiety (own energy>=750 rests after upkeep) are uniform mechanisms.
No remaining-population threshold, rescue spawn, immortality, global balancing or
free energy is present. Tests alone cannot prove the absence of every possible
policy; the source audit supplements the absorbing-zero counter evidence.

Language/runtime choice and alternatives: ADR-001; embedded browser/UI and visual
freedom: ADR-002; dense toroidal cell buckets: ADR-003; twelve-u16 haploid DNA,
crossover/mutation/immutable-founder species: ADR-004. Each records tradeoffs and
test/distribution consequences. ADR-015/018 define full canonical/checkpoint state;
ADR-019 performance and ADR-020 satiety retain their limits. External tests,
reports, config trials, clocks and digest manifests do not feed back into policy.

## Known limits

The engine is educational: identical founder genomes, row-major initial placement,
coarse genetic distance, haploid sexual genetics, normalized climate, no terrain
or explicit sexes and no pollination. Stable three-kind ecology is unresolved.
Small seed samples are examples, not statistical confidence. Large valid inputs
can exhaust memory; lifetime lineage/death/species history grows without bound.
Exact determinism is within a machine/build, not across GNU/musl floating math.
Checkpoint schema/model compatibility is explicit, without migration. Save/result
publication is not a two-file transaction or fsync guarantee. UI uploads cap
checkpoint/config sizes at64MiB/1MiB; chart history retains2048 ten-tick samples
plus current, resets on new/load/reset, and plots approximate numeric y values.
Synchronous checkpoint serialization can delay UI response. Browser automation
needs Node/Chromium; static headless runtime does not. Root-only empty-chroot tests
prove runtime independence, not an install on a newly provisioned physical OS.

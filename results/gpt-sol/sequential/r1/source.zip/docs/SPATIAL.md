# Spatial lookup

Implemented in TASK-010 per ADR-003. `Population` exclusively owns the private
`SpatialIndex` cache beside its authoritative living BTreeMap. No new dependency,
CLI command, reproduction decision or search-driven behavior was added.

## Query and mutation contract

`simulation.population().nearby(center: Cell, radius: usize, kind: Option<Kind>)`
returns an allocated `Vec<OrganismId>` in strictly ascending ID order. Distance is
inclusive toroidal Chebyshev distance. Radius zero includes all center occupants;
self is included. None selects all kinds. Every usize radius, including MAX, is
accepted; foreign-world Cell coordinates normalize to the population's topology.
Tiny worlds, overlapping wrapped neighborhoods and co-located organisms return
no duplicate IDs. Later actions must recheck liveness with `get(id)` and apply
any self exclusion or distance-then-ID target ranking themselves.

Dense row-major buckets hold `(ID, Kind)` entries sorted by ID. Queries enumerate
unique cells using Topology::cells_within, filter occupants and sort matching IDs.
The cache is canonical regardless of insertion/movement history. Initial founders
and committed newborns enter once; queued births remain absent. Every immediate
death removes the bucket entry through Population::kill. The internal
`move_one_step` normalizes destination, validates living identity and distance <=1
before mutation, and updates position/buckets immediately. Same-cell is a no-op.
Rejected moves leave the entire population unchanged. The relocation primitive and queries use no RNG. TASK-013 production animal
actions select adjacent destinations and pay movement energy through Simulation;
random exploration uses the engine RNG before relocation.

Storage is O(area + living), lookup O(visited cells + candidates + matches log
matches), output O(matches). Sorted updates shift O(bucket occupancy) entries.
Dense allocation uses try_reserve_exact; initialization failures propagate as
PopulationError::SpatialAllocation through SimulationError. No arbitrary world
cap is added. Linux overcommit and later allocation failures can still exhaust
process memory; this is not universal OOM recovery. Whole-world queries and
crowded cells can be expensive.

Future persistence must rebuild the derived cache from living records without
RNG draws and exclude it from canonical checkpoint/hash state. Every future
living insertion/removal/position mutation must maintain both representations.
There is no public mutable organism/index escape.

## Correctness evidence

`env -u DISPLAY cargo test --locked --lib --test spatial --test lifecycle --test simulation`
passes 31 tests (22 unit + 9 integration). New coverage includes:

- Independent unsigned shortest-axis oracle for public queries, mixed kinds,
  co-occupancy, both seams/corners, foreign/negative/multiple-wrap centers,
  radius 0/1/boundaries/MAX, empty and degenerate worlds and exact ordering.
- Exactly 4096 randomized comparisons: 8 worlds (1x1, 1x9, 9x1, 2x2, 3x8,
  8x3, 17x12, 64x48), 4 seeds (1,42,991,987654), 128 steps each. Actual
  Population lifecycle primitives interleave moves, kills, accepted births and
  commits. Rebuilding from authoritative records in reverse ID order compares
  equal after every step. Oracle membership never calls production distance or
  radius enumeration. Test RNG is separate from engine genetics RNG.
- Birth invisibility before Commit, captured child after parent death, immediate
  injury/starvation/old-age removal, seam/corner moves and stale-cell exclusion,
  same-cell and normalized foreign moves, rejected nonadjacent/dead moves,
  clone/query purity and capacity-error propagation without huge allocation.
- A real simulation walker sees earlier movement/death before later actors act;
  newborns appear only at Commit. Moves/queries and Commit consume no RNG.

Full `./test.sh` additionally exercises deterministic lifecycle replay and
multi-thousand-tick extinction continuation, configuration/climate/genetics,
CLI and static distribution regression. Exact counts/results are in the task
implementation handoff; no whole-engine throughput or coexistence claim follows.

## Reproducible local benchmark

Command: `cargo run --locked --release --example spatial_bench` (exit 0).
Recorded 2026-11-20 in the disposable benchmark container:
AMD Ryzen 5 7500F (6 cores / 12 logical CPUs), x86_64, Ubuntu 24.04.5 LTS,
Linux 7.0.0-43-generic; rustc 1.100.0 (0ef1bc386 2026-11-09), LLVM 23.1.5,
x86_64-unknown-linux-gnu host. Cargo default optimized release profile, no custom
profile or flags added by this example; single-threaded, no affinity pinning.
Shared-host scheduling/frequency variation remains possible.

Fixed in PLAN before measuring: 64x48, seed 42, 2000 row-major founders (1400
plants, 500 herbivores, 100 carnivores), no ticks. 4096 precomputed centers use
seed-42 xoshiro bounded x/y draws; each coordinate is uniformly sampled. Primary
comparison is radius 4 with all kinds. Also measure 1, 8 and usize::MAX, all kinds
and Herbivore filter. No workload tuning after measurement.

Brute force scans actual authoritative BTreeMap records, applies kind filter and
independent unsigned shortest-axis predicate, and collects already-ID-ordered
results. Indexed path calls public nearby. Both allocate a Vec; complete result
equality is checked outside timing for every query/scenario. Both paths warm up
once, then run five repetitions with alternating order; report each path's median.
black_box protects inputs/results and a consumed wrapping base-31 ID checksum
prevents elimination. Time includes query allocation/sorting, checksum and result
destruction equally on both paths; excludes construction, input generation,
validation and printing. The common checksum adds O(matches) to measured work.

| Radius | Filter | Index ms / 4096 | Brute ms / 4096 | Index ns/query | Brute ns/query | Brute/index speedup |
|---|---|---:|---:|---:|---:|---:|
| 1 | all | 0.294 | 19.028 | 71.8 | 4645.6 | 64.674x |
| 1 | herbivore | 0.210 | 13.536 | 51.4 | 3304.7 | 64.346x |
| **4** | **all (primary)** | **1.455** | **18.740** | **355.3** | **4575.2** | **12.877x** |
| 4 | herbivore | 1.117 | 13.397 | 272.8 | 3270.7 | 11.989x |
| 8 | all | 4.837 | 18.482 | 1181.0 | 4512.3 | 3.821x |
| 8 | herbivore | 3.637 | 13.349 | 888.0 | 3259.1 | 3.670x |
| MAX | all | 38.268 | 22.719 | 9342.7 | 5546.7 | 0.594x |
| MAX | herbivore | 33.342 | 13.113 | 8140.2 | 3201.4 | 0.393x |

Each path/repetition produced these identical total matches and checksums:

| Radius | Filter | Matches across 4096 | Checksum (u64 decimal) |
|---|---|---:|---:|
| 1 | all | 24005 | 7403930217664008981 |
| 1 | herbivore | 6075 | 2019758369440570711 |
| 4 | all | 217160 | 8708500012885779909 |
| 4 | herbivore | 55141 | 16553904963485459498 |
| 8 | all | 774359 | 15022706126871468147 |
| 8 | herbivore | 197585 | 12312586375320535156 |
| MAX | all | 8192000 | 7714826458346979328 |
| MAX | herbivore | 2048000 | 14540921270631636992 |

The primary local query is faster on this disclosed setup. Full-world queries
are slower: visiting 3072 buckets and sorting results loses to an already ordered
scan. No universal speedup, alternative population layout, whole-engine ticks/s,
checkpoint integration, UI performance or other hardware result is claimed.

TASK-013 adds public `sense(observer)` over nearby: living animals use inherited
vision, all kinds and self exclusion; plants/missing IDs return None. All kinds
permit unlimited sharing at initialization, movement and committed birth. Plant
establishment occupancy checks remain local reproductive policy. Per-step animal
executor tests verify old/new cell queries and immediate lethal-debit removal.
See [animal model](ANIMALS.md).

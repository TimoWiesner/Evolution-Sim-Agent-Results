# Integrated ecology (TASK-018)

The public Rust `Simulation` runs the complete food chain. Application `run`,
batch, UI and checkpoint commands belong to later tasks. All scenarios below use
production `advance_one_tick`, not a substitute scheduler or injected organisms.

## Tick order and extinction

1. **Clock:** increment the absolute tick once.
2. **ClimateResources:** advance seasons/weather with the sole engine RNG, then
   regenerate row-major bounded cell resources using current precipitation.
3. **Plants:** snapshot ascending living plant IDs; age/expire each before climate
   damage, maintenance and resource-backed growth.
4. **Herbivores:** age/expire, pay current-temperature upkeep, sense remaining
   visible food/danger, move through paid adjacent cells and take one bounded bite.
5. **Carnivores:** age/expire, pay upkeep, sense remaining prey, move, then make at
   most one paid stochastic attack. A true kill alone supplies prey-backed nutrition.
6. **Reproduction:** plants, herbivores, then carnivores, in stable ID order. Local
   plant-site competition and paid seed budgets gate clonal births. Two mature,
   compatible, adjacent animals pay for a crossed/mutated child; both receive a
   cooldown stamp. No second age increment occurs.
7. **Commit:** sort accepted births by phase/parents/request order, allocate IDs,
   classify immutable-founder species, insert newborns and update spatial counts.
   Finalize death totals/history, then mark zero-member species extinct.

Deaths remove living records, spatial entries and species membership immediately
at their cause (old age, damage, starvation or predation); Commit accounts for each
once rather than conducting a second mortality sweep. Later actors see these
removals and earlier movements. A captured accepted child can outlive its parents;
newborns first act next tick. The existing private full-tick test
`full_tick_orders_weather_actions_plant_birth_then_both_sexual_births` compares
production dispatch with explicit stages and exercises all three birth policies.

Only two production insertion sites exist in `Population`: initial founders and
accepted inherited births at Commit. `queue_birth` requires one living same-kind
plant parent or two distinct living same-kind animal parents. No public spawn or
mutable organism API exists. At completed ticks, zero is absorbing: pending births
are empty and no same-kind parents remain. Reports record that zero but never feed
it back into ecology. Empty worlds still advance weather/resources/clock exactly
as long as requested. Species history persists without reactivation.

## Selected defaults and mechanisms

TASK-018 changes only two defaults: `plants.resource_regeneration` **1 → 2** and
`animals.reproduction_cooldown` **20 → 100**. Capacity 100, efficiency 0.5, plant
birth cost 20, dispersal 3, movement cost 0.2, basal cost 0.1, per-parent animal
birth cost 30, climate, genetics, founder genomes/placement/reserves stay as before.
The complete effective configuration for every measured seed is in the raw report.

Renewable resources represent external solar/primary-production input limited by
water, not energy obtained from population scarcity. Capacity, individual uptake,
local establishment competition and climate heterogeneity bound primary production.
Finite lives/reserves, paid movement/upkeep, limited grazing, one paid hunt per
tick, capacity-limited nutrition, paid mature local mating and cooldown constrain
consumers. These mechanisms apply uniformly regardless of kind/species counts.
They permit collapse; there is no replenishment or extinction protection.

Measurements used seeds 0, 1, 42, fixed-key-only worlds 64×48, plants-only 400/0/0
for 2,200 ticks and abundant-food 2,000/120/0 for 600 ticks. Every exploratory run
and exact effective configuration is retained in
`tasks/TASK-018/handoffs/balancing-cycle1.json` (69 runs):

| Candidate changes from original defaults | Observation |
|---|---|
| None | Isolated plants extinct at 1,462 / survived / 924; abundant-food plants extinct at 433/444/429. Herbivores alive at 600. |
| Regeneration 2 | Isolated plants all survive 2,200; abundant-food plants extinct at 433/443/431. |
| Regeneration 4 | Isolated plants all survive; abundant-food plants extinct at 432/446/433. |
| Regeneration 4, efficiency 0.75, then 1 | Both efficiency candidates retain isolated plants but fail to retain abundant-food plants through 600. |
| Regeneration 2, cooldown 40 | Abundant-food plants extinct at 493/496/498. |
| Regeneration 2, cooldown 80 | Abundant-food plants extinct before 600 for all three seeds. |
| Regeneration 2, cooldown 100 (selected) | Plants and herbivores alive every tick through 600; isolated plants alive every tick through 2,200. |

Regeneration 2 is the smallest tested supply change that sustains isolated plants.
Further supply/efficiency changes did not resolve grazing pressure. Cooldown 100
extends the plan's candidate 40 after measured failure at 40 and 80: it limits
recruitment bursts with the existing uniform waiting mechanism. No new ecological
policy or state was needed. Lower movement/reproductive energy costs were not
tried, since they would encourage recruitment rather than address this pressure.
This is bounded acceptance tuning, not an optimization of three-kind coexistence.

## Scenario and invariant evidence

`tests/ecology_integration.rs` parses configs containing only fixed keys. Its
read-only observer checks tick 0 and every completed tick: independent live counts,
`initial + births = deaths + living` per kind (u128), cause totals, finite positive
bounded vitals, normalized positions, age/birth tick, parent arity/ID lineage,
species membership counts/current species queries and extinction flags. Once any
kind reaches zero, both its living count and subsequent birth increments stay zero.

- The exact contract example (seed 42, 64×48, 400/120/20) advances 1,000 ticks with
  a fresh second simulation compared for full-state equality every tick; observing
  only the first copy does not change its trajectory. Phase reports and weather
  clock agree with the engine clock.
- Plants-only seeds 0/1/42 survive all 2,200 ticks with 9,789/9,796/9,675 births
  and final counts 476/493/487. Living descendants beyond founder lifespan 1,100
  prove replacement, rather than only spending founder reserves.
- Abundant-food seeds 0/1/42 retain both plants and herbivores at every tick through
  600. Herbivores have births by 300 and additional births during 301..600, living
  descendants at 600, total births 591/604/590 and final counts 671/684/667.
  Plants also reproduce; final plant counts are 146/93/199.
- Without plants (0/120/20), herbivores go extinct at 45/61/49 and carnivores later
  at 878/864/907 for seeds 0/1/42. All runs continue to 5,000. Predation can hasten
  prey extinction; prior focused grazing/hunting tests separately prove starvation.
- Without herbivores (400/0/20), carnivores die out before 5,000 for all three seeds.
  All-zero worlds advance 1,000 ticks. A fixed-key-only 1×1 plant world naturally
  loses its plant and continues through 2,200 without recovery, covering natural
  plant extinction separately from surviving isolated 64×48 populations.

## Reproduce the five-seed report

From `/workspace`, without a display:

```sh
env -u DISPLAY cargo run --locked --release --example ecology_report > tasks/TASK-018/handoffs/ecology-cycle1.json
```

The example uses public Config/Simulation APIs and existing serde_json/std only.
It sequentially runs the exact contract world and initial counts with seeds
0,1,2,42,99, defaults omitted, for exactly 10,000 ticks each, including extinct
and empty tails. Per-seed progress goes to stderr; stdout is one JSON object only
after all runs succeed. `schema=1`, `ticks`, `seeds`, fixed-key `scenario` and
`runs` describe the report; every run includes seed, complete effective config,
`tick_end`, measured seconds, completed ticks with all three kinds living and
per-kind `first_zero_tick`, `survived`, `final`, cumulative `births`/`deaths`.
Zero at initialization is tick 0, an extinction is its first completed zero tick,
and null means alive through the horizon. Helper tests cover these conventions.
The report audits accounting/absorbing-zero each tick; counters/timing are external
observers, excluded from authoritative engine state and future checkpoint/hash.

Recorded final results (first zero tick, or survival through tick 10,000):

| Seed | Plants | Herbivores | Carnivores | All-three completed ticks |
|---|---|---|---|---|
| 0 | survived (521 living) | 27 | 875 | 26 |
| 1 | survived (517 living) | 27 | 865 | 26 |
| 2 | survived (522 living) | 24 | 858 | 23 |
| 42 | survived (527 living) | 22 | 857 | 21 |
| 99 | survived (519 living) | 27 | 867 | 26 |

All five reach tick 10,000. This exposes short animal coexistence and no herbivore
births in the mixed default world, despite sustained reproduction in isolated
abundant-food scenarios. Early predator access, row-major founders and stable-ID
competition remain limitations; long coexistence tuning belongs to TASK-027.
No claim of all-kind stability, engine throughput target, or portable timing is made.

Measurement environment: disposable Ubuntu 24.04 x86-64 container, rustc
1.100.0 (0ef1bc386 2026-11-09), cargo 1.100.0 (3acc79c0c 2026-11-05), locked
release profile. CPU model/allocation undisclosed (no outside-workspace hardware
files inspected). Elapsed values include the loop's observational audits and
exclude initialization/JSON encoding; see raw JSON for actual per-seed seconds.
No package or system dependency was added. Full commands, results and limitations
are preserved in the task-local implementation handoff.


## TASK-027 amendment

The current carnivore phase pays upkeep, then rests at own energy>=750; otherwise
it performs the existing pursuit/paid trial. Reproduction remains independent of
this action gate. Hunting identity2 replaces1; no other model/default changes.
The historical TASK-018 tables above describe the previous policy. Current exact
10000-tick baseline/trials/held-out evidence is in BALANCE.md: paired held-out
first-zero median25→316, but all three kinds eventually disappear under satiety.
No enduring coexistence claim or replenishment mechanism is introduced.

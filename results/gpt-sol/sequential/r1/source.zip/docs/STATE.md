# Project status (agent-maintained human-readable summary)

TASK-001 IMPLEMENT cycle 1: architecture documentation written. No product code
exists. Harness owns completion, review, task states, commits and transitions.

Accepted decisions:
- ADR-001: Rust core/native CLI, later static musl packaging, explicit xoshiro256**
  RNG and deterministic lifecycle/checkpoint/hash boundary.
- ADR-002: embedded local browser Canvas UI; one engine owner; core has no UI
  dependency; real-browser automation planned, not implemented.
- ADR-003: dense cell buckets, unique toroidal Chebyshev queries and stable IDs.
- ADR-004: twelve u16 haploid loci, two-parent animal crossover, clonal plants,
  bounded mutation, immutable founder species and exact rational thresholds.

`docs/ARCHITECTURE.md` records planned module responsibilities, dependency rules,
state ownership, public interfaces, climate topology compromise and error policy.
ADRs include alternatives, performance/testability/distribution implications and
future validation. No performance or packaging success is claimed.

Phase memory:
- `tasks/TASK-001/handoffs/plan-cycle1.md` and `.json`: approved plan.
- `tasks/TASK-001/handoffs/implement-cycle1.md`: scope, executable documentation
  validation source/command and limitations.
- `tasks/TASK-001/handoffs/implement-cycle1.json`: required structured handoff.
No dependencies, prior review gaps, blockers or plan deviations were found.

Verification: the initial validator invocation failed with a shell quoting error
(exit 1); corrected by avoiding literal shell backticks. `git diff --check` exited 0 after ADR edits. The exact Python command
in the implement handoff executes the adjacent Markdown validation block; exit 0
checks four ADR structures/content, module boundaries, handoff UTF-8/fields/types,
exact nine documentation-only changed paths, protected-file integrity, whitespace
and no Git remotes. No application test suite exists; none was claimed or run.

Environment inherited from PLAN: rustc/cargo 1.100.0, Python 3.12.3, Node v18.19.1.
No packages installed or system dependencies added in TASK-001. Future system
installations must record their exact commands here and reinstall when missing.
The current documentation check uses the provided Python and Git only.

TASK-001 REVIEW cycle 1: PASS; all five architecture acceptance criteria met.
Independent committed-diff/documentation checks exited 0; no gaps or product code.
Review evidence: tasks/TASK-001/handoffs/review-cycle1.md and .json.
No packages installed; no system dependencies added. Harness owns task completion.
Later owning tasks must implement/test RNG vectors, wrapping properties, genetics,
checkpoint equivalence, real UI, CLI contracts and self-contained static dist;
measure throughput and coexistence instead of assuming this design achieves them.

TASK-002 PLAN cycle 1: documentation-only bootstrap plan prepared in
`tasks/TASK-002/handoffs/plan-cycle1.md` and `.json`. TASK-001 PASS handoff read;
no prior TASK-002 or downstream TASK-003/TASK-004 handoffs or review gaps.
Plan: Cargo/std-only version/help CLI, root-relative scripts, static musl dist,
Cargo plus Python stdlib tests under one test.sh command, copied-root isolation
and ELF checks. No application or tests implemented/executed this phase.
Environment probe: rustc/cargo 1.100.0; only GNU host Rust target installed;
rustup/readelf/chroot available, musl-gcc missing. No packages installed here.
Planned setup commands when missing: `apt-get update` and
`apt-get install -y --no-install-recommends musl-tools`, plus
`rustup target add x86_64-unknown-linux-musl`. These have NOT been run in PLAN.
Implementation must record actual dependency commands and reinstall when missing.
Initial Git tree clean and no remotes; planning scope/handoff checks recorded in
plan JSON. No fresh-container or static executable success claimed yet.


TASK-002 IMPLEMENT cycle 1: bootstrap implemented (not a simulation). Cargo package
0.1.0, library/thin main/std-only CLI, executable setup.sh/evosim/build.sh/test.sh,
Rust tests and Python stdlib packaging tests, and README instructions now exist.
Only version and --help/-h are supported; all invalid/surplus/missing arguments
exit 2 with stderr. No run/batch/ui placeholders. Existing .gitignore already
covers target/, dist/ and Python caches; retained unchanged, verified by tests.
Cargo.lock is retained and not ignored. No new crates or runtime dependencies.

Actual dependency installation via ./setup.sh (all succeeded):
- `apt-get update`
- `apt-get install -y --no-install-recommends musl-tools`
  installed musl, musl-dev and musl-tools version 1.2.4-2.
- `rustup target add x86_64-unknown-linux-musl`
  for supplied rustc/cargo 1.100.0.
No other system packages installed. setup.sh detects/reinstalls missing musl-gcc
and Rust target on later phases. Test prerequisites inherited from the benchmark:
Python 3.12.3, Git, readelf (binutils) and chroot (coreutils); no added browser or
pip/npm tooling. Package install commands if these are absent on another Ubuntu
host: `apt-get update` then
`apt-get install -y --no-install-recommends python3 git binutils coreutils`.

Verification: initial ./setup.sh exit 0; ./test.sh exit 0 (1 Rust unit,
1 Rust integration, 6 Python tests; no skips). Then
`cargo clean && ./setup.sh && ./test.sh && cargo fmt --check && git diff --check`
exit 0 with the same eight tests passing. Clean removed 247 files/37 MiB before
rebuild. Suite runs setup twice and build once from an unrelated cwd, parses both
version outputs, checks help/errors, executable modes and Git ignores, confirms
ELF no INTERP/NEEDED, and runs copied dist/evosim in an otherwise empty chroot.
Thus static binary isolation was executed as root, not skipped. This container
was not replaced; clean-artifact rebuild is not a fresh Ubuntu provisioning test.
No throughput, ecology, checkpoint or full run portability evidence exists yet.
No remotes, protected-file edits, commits, review gaps or blockers.
Phase evidence: tasks/TASK-002/handoffs/implement-cycle1.md and .json.
Harness owns review, commits and transitions.

TASK-002 REVIEW cycle 1: PASS, no acceptance gaps. Independent committed diff and
script/code inspection, clean-artifact setup rebuild, all eight tests (no skips),
ELF/empty-root chroot execution, non-Unicode errors and spaced-path invocations
passed. Review changed only STATE and task-local review handoffs; no dependencies
installed. Separate fresh Ubuntu provisioning remains unexecuted; prior actual
installation plus clean rebuild and isolated runtime evidence are recorded.
Details: tasks/TASK-002/handoffs/review-cycle1.md and .json. Harness owns task
completion, commits and transitions; simulation commands remain future scope.

TASK-003 PLAN cycle 1: documentation-only configuration plan prepared in
`tasks/TASK-003/handoffs/plan-cycle1.md` and `.json`. Required context, all existing
TASK-001/002 handoffs and four ADRs read; TASK-002 PASS has no gaps. No existing
TASK-003 or dependent TASK-005/019/025 handoffs. Initial tree clean; no remotes.
Plan specifies typed library API, required fixed JSON keys, optional defaults,
key-specific validation, unknown-key rejection, exact seed/float serialization,
three named presets and an acceptance matrix. No feature code or tests added.
Proposed serde_json dependency/features are not installed or resolved in PLAN.
No system packages installed; inherited setup remains responsible for missing
musl prerequisites. No application suite run this phase. Final scope/schema and
whitespace checks passed; detailed command/evidence in task-local handoffs.
Harness owns commits and phase transitions; implementation remains unstarted.

TASK-003 IMPLEMENT cycle 1: typed JSON configuration library implemented in
src/config.rs and exported from src/lib.rs. docs/CONFIGURATION.md documents every
field/default/range and named baseline, seasonal and plant-only presets. Required
fixed keys, optional defaults, strict unknown/null policy, dotted-path errors,
checked area/count totals, private validated records, exact seed modulo-u64 and
file/string round trips implemented. No engine or run command added.

Dependency: serde_json 1.0.154 with arbitrary_precision and float_roundtrip;
Cargo.lock resolves Rust 1.85-compatible packages. Actual build dependency graph
also compiles serde_core 1.0.229, itoa 1.0.19, memchr 2.8.3 and zmij 1.0.23.
Cargo resolved/downloaded crates during `cargo test --test cli`; future setup
uses the locked graph. No apt/system packages installed in this phase; inherited
musl tools/target present. Existing setup retains reinstall commands above.

Verification: `cargo test --test cli` exit 0 (1 integration test); targeted
`cargo test --locked --test config` exit 0 (8 tests). `./test.sh` exit 0:
1 Rust unit + 1 CLI integration + 8 configuration integration + 6 Python tests,
16 total, no skips. Packaging suite rebuilds host/musl with setup twice and build,
checks ELF no INTERP/NEEDED and executes copied version binary in empty chroot.
`cargo fmt --check` and `git diff --check` exit 0; final scope/schema validator
also exit 0. Final post-documentation test repetition is recorded in handoff.
No fresh container or simulation portability/performance/coexistence measured.
No test failures, prior review gaps, protected edits, remotes or blockers.
Some initial bulk inspection output truncated; bounded follow-up reads completed
relevant context. No plan deviations. Phase memory and exact evidence:
tasks/TASK-003/handoffs/implement-cycle1.md and .json. Harness owns next phase.

TASK-003 REVIEW cycle 1: PASS; all six acceptance criteria met, no gaps.
Independent implementation diff/source/schema inspection and full ./test.sh passed:
16 tests, no skips, including 8 configuration tests and static ELF/empty-root
version execution. cargo fmt --check and git diff --check pass. Committed-scope
probe confirms exact eleven implementation paths, protected files unchanged,
no remotes or downstream handoffs. No packages installed or product edits.
Review changes only STATE and task-local handoffs. Architecture/ADRs remain
accurate. Separate Rust 1.85/fresh-container execution and future run portability
remain unverified; ecology defaults and engine/CLI use belong to future tasks.
Details: tasks/TASK-003/handoffs/review-cycle1.md and .json. Harness owns commits,
task completion and transitions.

TASK-004 PLAN cycle 1: documentation-only geometry plan prepared in task-local
plan-cycle1.md/.json. Required context, existing TASK-001/002/003 handoffs and ADRs
read. TASK-002 dependency PASS has no gaps; no existing TASK-004 or dependent
TASK-005/006/010 handoffs. Initial tree clean, no remotes. Plan refines ADR-003:
Chebyshev distance, positive half-axis ties, usize cells/dimensions, i128 wrapping
and displacement, lazy unique radius iteration with overflow-safe axis caps.
No product code, new dependencies or system installs; no application tests run.
Future setup retains recorded musl prerequisite reinstall commands. Planned tests
cover all acceptance criteria with explicit boundary cases and finite exhaustive
oracle checks. Final scope/schema/whitespace check passed; see PLAN JSON and
reproducible validator in adjacent Markdown. Harness owns phase transitions and
commits; implementation has not started.


TASK-004 IMPLEMENT cycle 1: pure Rust toroidal geometry implemented in
src/topology.rs, exported from src/lib.rs. Validated usize dimensions/area and
private Cell values, full i128 wrapping, shortest i128 displacement with positive
half-axis ties, Chebyshev distance and O(1)-memory lazy unique inclusive radius
iterator. Foreign-world cells normalize to the receiving topology. No organisms,
spatial index, world raster, climate, engine or CLI commands added. Approved plan
followed without deviations; dependency TASK-002 PASS has no gaps.

Verification: cargo test --locked --test topology exit 0, seven tests pass.
./test.sh exit 0: 1 Rust unit, 1 CLI integration, 8 configuration integration,
7 topology integration, 1 rustdoc and 6 Python tests (24 total, no skips).
Topology tests cover every acceptance criterion, including exhaustive worlds
1..=8 per axis, all source/target pairs and all center/radius combinations for
radii 0..=10 plus usize::MAX against independent oracles. Suite also rebuilds
host/musl through setup twice/build and executes ELF/empty-root version checks.
No new dependencies or package installations; existing musl prerequisites were
present. Their exact reinstall commands remain recorded above and in setup.sh.
No fresh-container, Rust 1.85 execution, ecology or performance claim. Geometry
supports finite i128 inputs; enumerating huge representable areas still costs
area time. Details and final validation: task-local implement-cycle1.md/.json.
Harness owns review, commits, task states and phase transitions.

TASK-004 REVIEW cycle 1: PASS, no acceptance gaps. Independent committed-diff,
source/plan/ADR inspection and targeted seven topology tests pass. Full ./test.sh
passes all 24 tests without skips, including exhaustive topology oracles, rustdoc,
static ELF and empty-root version execution; formatting/whitespace pass. Review
changes only STATE and task-local review handoffs. No packages installed or
product edits; architecture/ADRs remain accurate. Finite i128 domain, positive
half-axis ties and area-time full enumeration are documented. Fresh-container,
Rust 1.85 and downstream performance remain unverified. Exact evidence and
acceptance matrix: tasks/TASK-004/handoffs/review-cycle1.md/.json. Harness owns
completion, commits and transitions.

TASK-005 PLAN cycle 1: prepared documentation-only clock/RNG/scheduler plan in
tasks/TASK-005/handoffs/plan-cycle1.md/.json. Required files verified before reads;
TASK-003/004 dependency reviews PASS with no gaps. Existing prior handoffs and
relevant ADRs inspected; no current-task or direct-dependent TASK-006/008/022
handoffs exist. Initial tree clean, no remotes. Plan specifies exact accepted
xoshiro256**/SplitMix64 algorithm, versioned four-word restore, rejection sampling
and rational probability draw rules; Config/World/clock/RNG ownership, checked
u64 tick advancement, seven fixed phases and deterministic fixture-ID ordering.
World initially contains Topology; biological stages stay empty with no dummy
draws or population initialization until owning tasks. Full RNG checkpoints,
climate, organisms and CLI remain future scope. ADR-001/architecture updated as
planned only. No feature code, tests, new dependencies or package installs.
Existing musl reinstall commands recorded above remain applicable.
Validation: required-file and Git inventory commands exit 0; final executable
planning validator checks UTF-8 handoff/schema, exact five documentation paths,
protected files, no remotes and whitespace (exit 0). No application suite run
because product code is unchanged; prior test results are inherited evidence.
No prior review gaps or blockers. Detailed implementation sequence, acceptance
matrix, risks and planned commands persist in task-local handoffs. Harness owns
commits, task state and transitions; implementation has not started.


TASK-005 IMPLEMENT cycle 1: approved frame implemented in src/rng.rs and
src/simulation.rs with public module exports. Exact xoshiro256**/SplitMix64,
version-1 four-word state restore, unbiased bounded sampling and rational
probabilities; Simulation owns Config/World/clock/RNG, checked one-tick advance,
seven ordered stages, observational reports and stable fixture-ID ordering.
World is geometry only; initial counts remain config data. Biological stages
are no-ops without draws, pending their owning tasks. No CLI/UI integration,
organisms, climate, canonical hash or disk checkpoint implementation claimed.
No plan deviations, blockers, prior review gaps, dependencies or system packages
added. Existing musl prerequisite installation/reinstallation commands above
remain applicable; setup found them present. No commits or phase transitions.

Commands/results: initial targeted `env -u DISPLAY cargo test --locked --test rng
--test simulation` exited 101 due to an unmatched format brace in a test fixture;
corrected the fixture, then the same command exited 0 (5 RNG + 3 simulation tests).
`./test.sh` exited 0: 3 Rust unit, 1 CLI, 8 config, 5 RNG, 3 simulation,
7 topology, 1 rustdoc, 6 Python = 34 tests, none skipped. Includes host/musl
builds, setup twice/build, ELF inspection and copied-empty-root version execution.
`cargo tree --locked`, `cargo fmt --check` and `git diff --check` exited 0.
Final handoff schema/scope validator passed (source in implement-cycle1.md).
Known vectors use an independent Python integer reference. No throughput,
full checkpoint, fresh-container or separate Rust 1.85 run performed. Empty-stage
replay and fixture ordering prove only the frame; lifecycle tests await TASK-008.
Required implementation handoff: tasks/TASK-005/handoffs/implement-cycle1.json,
with adjacent detailed acceptance evidence. Harness owns review and next phase.


TASK-005 REVIEW cycle 1: PASS; all six acceptance criteria verified, no gaps.
Independent committed implementation/source/plan/ADR inspection and ./test.sh
pass: 34 tests, no skips, including static ELF/copied-empty-root version checks.
Targeted RNG/simulation tests with DISPLAY unset pass (8 tests); cargo tree,
formatting and whitespace pass. Exact RNG restoration, known vectors, bounded
sampling, 128-tick replay, observations, fixed stage/fixture ID order and atomic
clock overflow verified. Review changes only STATE and task-local handoffs;
no system dependencies installed or product edits. Architecture/ADRs remain
accurate. Empty-stage/fixture tests prove the frame only; real lifecycle, full
checkpoint/hash, CLI/UI and throughput remain owning-task work. No separate
fresh-container or Rust 1.85 run. Required review handoff and detailed evidence:
tasks/TASK-005/handoffs/review-cycle1.json and .md. Harness owns task completion,
commits and phase transitions; no remediation required.

TASK-006 PLAN cycle 1: documentation-only plan prepared in task-local
plan-cycle1.md/.json and ADR-005. Required files verified first; dependency
TASK-004/005 reviews PASS with no gaps. No prior TASK-006 or downstream handoffs.
Initial tree clean, no Git remotes. Inspected task/project/contract/architecture,
PLAN skill, existing handoffs and relevant source/ADRs; bounded reads supplemented
truncated bulk output. Plan: normalized cell-centred cosine latitude, five ordered
biomes, smooth precipitation knots, no noise or RNG draws; O(1)-storage procedural
Climate in World, streaming JSON map and additive climate CLI inspection command.
Tiny grids may omit bands. Exact API/formula/export/error/test matrix persists in
TASK-006 plan. Temporal climate/resources/organisms remain later owning tasks.
No feature code, tests or dependencies added, no packages installed; inherited
musl reinstall commands above remain applicable. No application suite executed
in PLAN. Final planning validator passed: UTF-8 JSON fields/types, exact six
documentation paths, protected paths, absent remotes and git diff --check.
No blockers or review gaps; no commits, task-state changes or next phase started.
Harness owns transitions. Feature and packaging tests remain IMPLEMENT work.

TASK-006 IMPLEMENT cycle 1: approved static climate plan implemented with no
scope/algorithm deviations. src/climate.rs provides procedural immutable base
climate, five ordered biomes, normalized cosine temperature and smoothstep
precipitation; World owns the field and exposes read-only access. Headless
`climate --config FILE --out FILE` streams row-major JSON. Config/argument errors
preserve output; write failures report status 2 and may leave partial output.
No weather, resources, organisms, run/UI or persistence added. docs/CLIMATE.md
and ADR-005 document the toroidal cold-hot-cold compromise and tiny-world behavior.

Verification: `env -u DISPLAY cargo test --locked --test climate --test simulation
--test cli` passed twice (initial 10 tests, final 11 after adding CLI error tests).
`./test.sh` exited 0: 4 unit + 2 CLI + 5 climate + 8 config + 5 RNG +
4 simulation + 7 topology + 1 rustdoc + 7 Python = 43 tests, none skipped.
Includes host/musl builds, setup twice/build, both climate exports from unrelated
cwd, ELF and actual copied empty-root version execution. `cargo fmt --check` and
`git diff --check` exited 0. Actual documented export parsed 3072 cells:
polar 640, tundra 384, temperate 768, dry 512, tropical 768. First manual export
before creating target/climate-config.json correctly failed with status 2;
created the documented config and reran successfully. No test failures.
No new crates/system dependencies or installations; inherited musl requirements
were present and reinstall commands above/setup.sh remain valid. Initial tree
clean, no remotes, protected-file edits, manual commits or stage changes.
No performance, fresh-container, separate Rust 1.85 or temporal/ecological claims.
Required handoff: tasks/TASK-006/handoffs/implement-cycle1.json; adjacent Markdown
records acceptance mapping and final validator. Harness owns review/transitions.

TASK-006 REVIEW cycle 1: PASS; all six acceptance criteria verified, no gaps.
Independent implementation diff/source/plan/ADR inspection and ./test.sh pass:
43 tests, none skipped, including host/musl export and static packaging checks.
Independent headless exported-map oracle on six sizes (1x1 through 5x257)
confirms position-derived fields, band order, bounds, cell coverage and seams.
Formatting/whitespace pass. Review modifies only STATE and task-local handoffs;
no product edits, installations, remotes, commits or task-state changes.
Architecture/ADRs remain accurate. Tiny grids may omit bands; enormous exports
cost area time/disk and f64 resolution is limited. Future weather/persistence
obligations remain recorded in ADR-005. No temporal/ecological, throughput,
fresh-container or separate Rust 1.85 claim. Detailed evidence and required
handoff: tasks/TASK-006/handoffs/review-cycle1.md and .json. Harness owns
completion and next assignment; no remediation or phase transition initiated.

TASK-007 PLAN cycle 1: documentation-only plan prepared in
 tasks/TASK-007/handoffs/plan-cycle1.md/.json and ADR-006. Required files verified
first; dependency TASK-006 review PASS and no prior TASK-007/review gaps or
blockers. Initial tree clean; no remotes. Existing Config has all needed climate
settings. Plan preserves static base climate/export, adds World-owned temporal
state, modulo-first periodic seasons and global correlated two-channel weather
in ClimateResources using the sole engine RNG. Queries never draw; tick-zero
weather is neutral. No ecology, CLI expansion or disk persistence in this task.
Full ordered API/file plan, exact formulas, acceptance matrix and future canonical
state obligations persist in task-local Markdown and ADR-006. Existing tests
assuming every tick draws nothing must distinguish weather off from enabled.
No feature code, product tests, dependency installations or system packages in
PLAN. Existing musl dependency/reinstall commands above remain applicable.
Planning validator passed: required UTF-8 JSON fields/types, exact six planning
paths, protected-file integrity, no remotes and git diff --check. Inherited
TASK-006 43-test PASS is context, not a newly executed suite. No commits, task
state changes or next phase started; harness owns transitions.

TASK-007 IMPLEMENT cycle 1: implemented approved ADR-006 in
src/temporal_climate.rs and World/ClimateResources. Configurable modulo-first
cosine seasons vary both normalized fields with smooth zone amplitudes; global
persistent two-channel AR(1) weather uses exactly two engine RNG draws per enabled
tick, none when disabled. Neutral tick-zero initialization draws nothing. Pure
current queries preserve static base fields/export and seams. World owns settings,
model/tick/offsets with validated in-memory restoration; future disk persistence
must encode those plus full RNG and validate clock agreement. No ecology, resources,
CLI/UI expansion or checkpoint format. No plan deviations or known acceptance gaps.

Executed `cargo test --locked --lib --test simulation`: exit 0 (5 unit + 4
simulation tests). Executed `env -u DISPLAY cargo test --locked --test temporal_climate
--test simulation`: exit 0 (5 temporal + 4 simulation tests). `./test.sh`: exit 0,
49 tests, none skipped (5 unit, 2 CLI, 5 base climate, 8 config, 5 RNG, 4 simulation,
5 temporal climate, 7 topology, 1 rustdoc, 7 Python). Includes setup twice/build,
host/musl exports, static ELF and copied-empty-root version execution.
`cargo fmt --check` and `git diff --check`: exit 0. No failed test invocations.
Temporal tests exercise all-cell/all-phase exact year repetition on dimensions
1..=8 for years 1/2/7/16/240/1000, golden quarter-year values, independent seasonal
amplitudes, 294-tick seeded traces, 2001-tick bounds/draw-count matrices, pure
queries/seams, large-tick modulo, restoration errors and 37+256-tick temporal/RNG
continuation. Overflow stays atomic. Detailed evidence and required JSON:
tasks/TASK-007/handoffs/implement-cycle1.md and .json.

No new dependencies or system packages installed; inherited musl tools/target
were present. Exact reinstall commands remain above and in setup.sh. No throughput,
disk-checkpoint, fresh-container or separate Rust 1.85 execution claimed. Global
weather/synchronous seasons simplify geography; huge years lose adjacent floating
phase resolution. No protected changes, Git remotes, commits or phase transitions.
Harness owns review and completion.

TASK-007 REVIEW cycle 1: PASS; all six acceptance criteria verified, no gaps.
Independent implementation diff/source/plan/ADR review and ./test.sh pass: 49
 tests, none skipped, including temporal acceptance and static packaging checks.
Formatting/whitespace and final UTF-8 JSON/scope/protected-path/no-remotes validator
pass. Review changes only STATE and task-local handoffs; no product edits, system
packages, commits or phase transitions. Architecture/ADRs remain accurate.
Global weather, synchronous seasons, clipping and huge-year float resolution are
accepted documented simplifications. Future checkpoint/hash must include temporal
settings/model/tick/offsets plus RNG and validate engine/temporal clock agreement.
No disk persistence, ecology, throughput, fresh-container or Rust 1.85 claim.
Detailed evidence: tasks/TASK-007/handoffs/review-cycle1.md and .json. Harness owns
completion and subsequent assignment; no remediation required.


TASK-008 PLAN cycle 1: documentation-only organism/lifecycle plan prepared in
 tasks/TASK-008/handoffs/plan-cycle1.md and .json; ADR-007 records exact trait,
vital, storage, identity, lineage and same-tick rules. No implementation started.
Dependency TASK-005 review PASS, no existing TASK-008 gaps; current TASK-007
climate integration must be preserved. Planned BTreeMap living storage and
Simulation-owned Population initialize exact configured counts without RNG draws;
no initial births. Immediate death disables/removes actors, commit accounts causes
and births, accepted offspring survive later parental death and act next tick.
Age/lifespan is the only autonomous biological change here; feeding, movement,
reproductive decisions, genomes and spatial lookup remain later tasks. Test plan
covers real internal walkers/commit, not only sorted-ID fixtures. Death history
is retained and grows with lifetime deaths; storage performance is unmeasured.
No system dependencies installed or changed; existing musl reinstall commands
above remain authoritative. No application test suite run in this planning phase;
only handoff/scope/protected-file/no-remotes/whitespace validation is recorded.
Harness owns commits, completion and transitions; no next phase started.


TASK-008 IMPLEMENT cycle 1: organism/lifecycle foundation implemented in
src/organism.rs and src/population.rs, exported by lib.rs and owned by Simulation.
All three kinds now materialize exact configured initial counts without RNG draws.
Records retain opaque non-reused IDs, normalized cells, bounded vitals, twelve
validated traits, age, sorted parents, generation and birth tick. BTreeMap living
storage and the shared ordered walker enforce immediate removal/liveness rechecks;
lifespan deaths occur before action. No feeding, movement, DNA or autonomous
reproduction. Internal validated birth primitives capture lineage and reserve ID
capacity; accepted children survive later parental death, commit at age zero and
first act next tick. Per-kind u128 cumulative counts/cause history conserve initial
+ births - deaths = living at completed ticks. Full death history grows with all
deaths. Future persistence must include allocator exhaustion, request sequence,
all records, counters/history and later DNA. BirthPhase belongs to population to
avoid importing simulation in reverse; Traits typing excludes invalid traits from
birth requests. The previous fixture-only sorted-ID helper is replaced by actual
BTreeMap phase snapshots, preserving the approved order semantics.

Verification: initial `cargo test --locked --lib` exit 0 (4 tests at that point).
First `cargo test --locked --lib --test organism --test lifecycle --test simulation`
failed with exit 101: test RNG helper used nonexistent Rng::from_u64; corrected
to Rng::from_seed with Seed::from_u64. Second invocation failed with exit 101:
ambiguous sum type in lifecycle test; added sum::<usize>. Subsequent invocations
passed (19 then 20 tests as coverage was extended); an unused fixture phase
warning was fixed by assigning the intended phase. Final ./test.sh exit 0:
13 unit + 2 CLI + 5 climate + 8 config + 2 lifecycle + 2 organism + 5 RNG +
4 simulation + 5 temporal climate + 7 topology + 1 rustdoc + 7 Python = 61 tests,
none skipped. Includes setup twice/build, host/musl exports, static ELF checks
and copied-empty-root version execution. Final headless targeted command
`env -u DISPLAY cargo test --locked --test organism --test lifecycle --test simulation`
exit 0 (8 tests). cargo fmt --check and git diff --check exit 0. Detailed test
mapping and final schema/scope validator persist in implementation handoffs.

No new crates/system packages or installations; inherited musl prerequisites
were present and exact reinstall commands above/setup.sh remain applicable.
No fresh-container, Rust 1.85, throughput, coexistence or full checkpoint claim.
No protected edits, remotes, commits or phase transitions. No known acceptance
gaps; harness owns review and completion. Required structured handoff:
tasks/TASK-008/handoffs/implement-cycle1.json (verdict N/A).

TASK-008 REVIEW cycle 1: PASS; all six acceptance criteria verified, no gaps.
Independent committed implementation 0ef09ac..65fd91f/source/plan/ADR review and
./test.sh pass: 61 tests, no skips, including static musl/empty-root version
execution. Headless targeted command with --lib and organism/lifecycle/simulation
integration targets passes 21 tests. Formatting/whitespace and final review
schema/scope/protected-path/no-remotes checks pass. Exact commands and acceptance
mapping: tasks/TASK-008/handoffs/review-cycle1.md and .json. Review changes only
STATE and task-local handoffs; architecture/ADRs remain accurate. No product
edits, dependencies installed, manual commits or phase transitions. Birth/death
ordering, bounded vitals, immediate removal, next-tick newborns, lineage, lifetime
non-reused IDs and per-kind conservation are exercised through real primitives.
Storage/history costs remain unprofiled; no full checkpoint, ecology/coexistence,
throughput, fresh-container or separate Rust 1.85 evidence. Future persistence
must include complete population state as recorded in ADR-007. Harness owns
completion and subsequent assignment; no remediation required.


TASK-009 PLAN cycle 1: documentation-only genetics implementation plan written
in tasks/TASK-009/handoffs/plan-cycle1.md/.json. Dependency TASK-001/TASK-008
reviews PASS, no gaps; no earlier TASK-009 handoffs. Initial tree clean/no remotes.
Retain ADR-004 DNA/crossover/mutation/distance and existing GeneticsConfig.
Plan extracts shared traits to src/traits.rs with organism re-exports to avoid a
genome/organism import cycle; organisms derive traits from immutable DNA. Fixed
midpoint founder DNA consumes no draws; continuous founder values slightly shift.
Accepted internal births inherit/mutate using the engine RNG with transactional
rejection and capture DNA before parental death. No reproduction timing/species.
Detailed test matrix covers all acceptance points and existing lifecycle coverage.
No feature code/tests added, no application suite run, no packages installed;
existing musl reinstall commands above remain applicable. Planning schema/scope/
whitespace validator passed; exact command in handoff. No blockers or commits;
harness owns transitions. Implementation remains unstarted.


TASK-009 IMPLEMENT cycle 1: genetics implemented per ADR-004 and approved plan.
Every organism owns immutable Genome([u16;12]), with Traits derived on demand.
TraitValues/Traits/TraitError moved to src/traits.rs and remain re-exported from
organism. Genome exposes version/locus constants, fixed-array construction,
read-only alleles, deterministic bounded mapping, copy/crossover/mutation and
exact/normalized L1 distance. Initial DNA [32768;12] consumes no RNG, preserves
IDs/placement/lifespan and slightly quantizes continuous founder traits.

Population birth requests no longer accept arbitrary traits. Sorted live parent
DNA supplies copy (plants) or nonempty crossover (animals), then existing
GeneticsConfig mutation through the Simulation-owned RNG. A temporary cloned
state is published only after child-health validation; rejected requests change
neither population nor RNG. Pending DNA/lineage survives parental death; Commit
draws nothing. No production reproduction decisions, species, CLI or persistence
added. Full schema/draw rules: docs/GENETICS.md. Future checkpoint/hash must encode
schema/all alleles, effective settings and complete RNG; no phenotype cache.

Verification: first targeted compile failed (exit 101) on an unnecessary mutable
reference in migrated test code; fixed. Targeted lifecycle and genetics tests,
16 private tests and ./test.sh (68 tests at that point) pass. A final independent
Python frozen-vector test was then added and headless targeted tests pass (13).
Exact commands, results and scope are in TASK-009 implement handoffs. No system
packages/dependencies installed; existing setup dependencies/reinstall commands
above remain applicable. Uniform founders lack initial diversity; O(12) derived
traits and lifecycle storage are unprofiled. No throughput/coexistence/checkpoint
or separate fresh-container claim. Harness owns review, commits and transitions.


TASK-009 REVIEW cycle 1: PASS; all five acceptance criteria verified, no gaps.
Independent implementation 2b6dfaa..23d41fb/source/plan/ADR review and ./test.sh
pass: 69 tests, none skipped (16 unit, 45 integration, 1 rustdoc, 7 Python).
Separate headless targeted run passes 29 tests; formatting/whitespace and final
review schema/scope/protected-path/no-remotes validator pass. Full evidence and
acceptance mapping: tasks/TASK-009/handoffs/review-cycle1.md and .json.
Review changes only STATE and task-local handoffs; no product edits, dependencies
installed, commits or phase transitions. Architecture/ADRs remain accurate.
Uniform founders lack initial diversity; derived traits and lifecycle storage
remain unprofiled. No persistence, ecology/coexistence, throughput, separate
fresh-container or Rust 1.85 claim. Future checkpoint/hash must encode genome
schema/all alleles and complete engine state. Harness owns completion and next
assignment; no remediation required.

TASK-010 PLAN cycle 1: documentation-only spatial-search implementation plan in
 tasks/TASK-010/handoffs/plan-cycle1.md/.json. Dependency TASK-001/004/008 reviews
PASS without gaps; current TASK-009 genetics integration inspected. Initial Git
tree clean, no remotes, no previous TASK-010 handoffs or review gaps. Applied
.agents/skills/plan/SKILL.md; no feature edits or application suite executed.

ADR-003 refinement: Population will own derived dense sorted (ID, Kind) buckets;
public nearby(Cell, usize, Option<Kind>) returns ascending IDs. Founder/newborn
insertions, immediate kill and an internal validated one-cell move update index
with living records; no behavior/movement decisions or new RNG draws. Dense
initial allocation is fallible; overcommit/later allocation limitations remain.
Future checkpoint/hash excludes cache and rebuilds from living records without RNG.
Plan calls for >=4096 randomized oracle queries plus lifecycle/rebuild/purity
coverage and reproducible 2000-founder release measurements (64x48, primary
radius 4, additional local/full-world/filter cases). No timings or speedup claimed.
No dependencies/system packages installed; exact inherited musl reinstall commands
above/setup.sh remain applicable. Planning validation: UTF-8/schema, exact five
documentation paths, protected files, no remotes and whitespace; exit 0. Actual
command and evidence are in plan-cycle1.json and executable validator in .md.
Harness owns commits, task states and next phase; implementation remains unstarted.


TASK-010 IMPLEMENT cycle 1: implemented private src/spatial.rs, Population-owned
dense sorted (ID, Kind) buckets and public nearby(Cell, usize, Option<Kind>).
All production founders/committed births/immediate deaths/internal one-cell moves
update the cache. Queries are inclusive toroidal Chebyshev, normalize foreign
cells, accept every usize radius and return ascending unique IDs. The internal
move primitive rejects missing/nonadjacent actors atomically; it introduces no
behavior, movement costs, CLI command or RNG draw. Dense initial allocation
failure propagates through PopulationError::SpatialAllocation/SimulationError.
Memory overcommit/later allocation OOM limits remain. Future checkpoints rebuild
this canonical derived cache from living records without RNG and exclude it
from canonical state/hash. Future ecology must use these owner mutation paths.

Correctness: 4096 randomized actual-population queries across 8 worlds/4 seeds
with interleaved move/kill/birth/commit match independent brute force, with
reverse-order rebuild equality after every step. Explicit public/filter/seam/
co-occupancy/huge-radius/tiny-world tests, immediate vital/aging deaths, pending
birth timing, error/purity tests and real-walker visibility supplement them.
Release benchmark: command cargo run --locked --release --example spatial_bench,
exit 0. Declared primary radius 4/all, 2000 founders, 64x48, 4096 queries, median
of five: index 1.455 ms vs scan 18.740 ms (12.877x). Full-world/all index 38.268
ms vs scan 22.719 ms (0.594x). All scenarios/checksums/hardware/method and query
API are in docs/SPATIAL.md. No universal or engine-throughput claim.

No crates/system dependencies installed or changed. Inherited musl tools/target
were present; exact prerequisite reinstall commands above/setup.sh remain valid.
Implementation follows the approved plan. Required JSON and detailed command/
failure evidence: tasks/TASK-010/handoffs/implement-cycle1.json and .md.
Harness owns commits, task-state updates, review and phase transitions.

Final verification: ./test.sh exit 0, 78 tests, no skips (22 Rust unit, 48 Rust
integration, 1 rustdoc, 7 Python). Includes setup/build, host/static-musl exports,
ELF and actual copied-empty-root version execution. Final targeted headless
command passes 31 tests; cargo fmt --check and git diff --check exit 0. Initial
spatial test compile failed (101) on an unmatched format brace, then was fixed.
No product runtime/test assertions failed. See handoff for all attempts and
read-only metadata/inspection mistakes. No separate fresh-container, Rust 1.85,
full checkpoint, UI, ecology/coexistence or whole-engine throughput evidence.
Final handoff validator exit 0: UTF-8/schema, exact twelve implementation paths,
protected-file integrity, no remotes, formatting and whitespace.


TASK-010 REVIEW cycle 1: PASS; all five acceptance criteria independently verified.
Full ./test.sh passes 78 tests without skips, including 4096 randomized spatial
oracle comparisons and lifecycle synchronization. Repeated release benchmark at
2000 organisms: radius-4 all index 1.761 ms vs scan 22.979 ms per 4096 queries
(13.048x); full-world all 37.975 vs 22.910 ms (0.603x). Exact commands/results
and limitations: tasks/TASK-010/handoffs/review-cycle1.md and .json. No product
changes, dependencies installed, gaps or remediation. Dense-memory/full-world
costs and future cache rebuild obligations remain documented in docs/SPATIAL.md.
Harness owns completion and subsequent phase assignment.

TASK-011 PLAN cycle 1: documentation-only plant growth/resources plan prepared in
 tasks/TASK-011/handoffs/plan-cycle1.md/.json; ADR-008 specifies the exact model.
Dependency TASK-006/008/009 reviews PASS without gaps; current TASK-007 weather
and TASK-010 spatial mutation paths remain binding. No prior TASK-011 handoffs,
review gaps or blockers. Initial tree clean and no remotes. Applied workspace
PLAN skill; no feature code or next phase started.

Plan: World-owned authoritative row-major bounded resource field; current
precipitation limits external photosynthetic resource regeneration after weather.
Existing plant controls/defaults and twelve-locus DNA remain unchanged. Plant
walker applies age, climate damage, maintenance, headroom-limited resource uptake
and energy credit; all deaths use Population mutation paths. Climate optima,
tolerance and metabolism influence plants without new random draws or global
population feedback. Initial reserves are declared inputs; solar/environmental
regeneration is the sole ongoing energy source. Reproduction/grazing remain later
owning-task work. Full equations/interfaces, acceptance matrix and migration of
obsolete constant-vital lifecycle fixtures are persisted in the plan and ADR.
Future checkpoint/hash must encode every cell's depleted resource value and model
version/settings; never refill on load. Dense O(area) storage/update adds cost;
no throughput/coexistence evidence claimed.

No product tests or simulations run, no dependencies installed or changed in PLAN.
Existing exact musl prerequisite/reinstall commands above/setup.sh remain valid.
Planning validator checks UTF-8 JSON/schema, exact five documentation paths,
protected files, absent remotes and whitespace; actual result recorded in handoff.
Harness owns commits, task states and phase transitions.

TASK-011 IMPLEMENT cycle 1: implemented ADR-008 model-v1 plant growth and bounded
World-owned ResourceField. ClimateResources advances weather then regenerates
row-major from current precipitation. Plants age first, lose genetic climate
health/maintenance, then withdraw finite local resource and convert it into bounded
energy. Later same-cell IDs see depletion. Deaths use Population primitives and
retain immediate spatial removal/one Commit record. No reproduction, grazing,
animal behavior, CLI or checkpoint format added; no new RNG draws/dependencies.
Source, limits, equations and public observation API: docs/PLANTS.md. Future state
hash/checkpoint must retain exact depleted stores/version/effective plant settings;
resources cannot be reconstructed by refilling. Memory and regeneration cost
O(area); no throughput or coexistence evidence claimed.

Tests cover actual current-climate ticks with separate cold/dry inputs and an
independent energy oracle, 128-tick budget, shared versus isolated plants, genome
optima/tolerance/metabolism, old age/starvation/climate death, resource bounds and
allocation errors, tiny efficiencies, 2200-tick favorable/empty worlds and mixed
four-seed replay/accounting. Lifecycle fixtures now allow ecological plant deaths
while retaining exact animal vitals/old age and a separate favorable plant old-age
fixture. Oversized-world Simulation errors now report resources before spatial
storage; direct spatial-allocation unit coverage remains. A cfg(test)-only mutable
record helper supports fixtures without exposing production genome/vital writes.

Initial targeted run failed on obsolete constant plant-vital expectations; fixed
without suppressing physiology. Initial full suite failed on the allocation error
precedence assertion; updated to the resource failure. Subsequent ./test.sh passes
88 tests: 30 unit, 50 integration, 1 rustdoc, 7 Python; none skipped. Includes
host/musl builds, setup twice/build, static ELF and copied empty-root version.
Final targeted/headless and formatting/scope results are in TASK-011 implement
handoffs. No packages installed in this phase; existing musl prerequisites were
present. Reinstall commands remain setup.sh and the earlier STATE entries.
Harness owns review, task state, commits and transitions. No known acceptance gaps.


TASK-011 REVIEW cycle 1: PASS; all six plant growth/resource acceptance criteria
verified by independent committed-diff/source/plan/ADR inspection and executed
checks. ./test.sh passes 88 tests, no skips (30 unit, 50 integration, 1 rustdoc,
7 Python), including host/musl packaging and isolated version execution. Separate
headless targeted run passes 43 tests; formatting/whitespace pass. Exact commands,
acceptance mapping and scope validator: tasks/TASK-011/handoffs/review-cycle1.md
and .json. No acceptance gaps or product edits. Corrected stale architecture
opening/module inventory to include plant growth/resources. No system dependency
installed; existing setup/reinstall commands remain applicable. Dense O(area)
updates, order bias and harsh climates remain documented limitations; throughput,
coexistence and full-state persistence are not claimed. Future checkpoint/hash
must encode exact depleted resource stores/model/effective settings. Harness owns
completion, commits and transitions; no next phase started.


TASK-012 PLAN cycle 1: documentation-only plant reproduction plan prepared in
 task-local plan-cycle1.md/.json and ADR-009. Dependency TASK-009/011 reviews PASS
without gaps; initial tree clean/no remotes, no prior TASK-012 handoffs or gaps.
Plan: asexual one-attempt/tick reproduction in Reproduction, exact DNA fertility
ratio, uniform unique toroidal-radius cell sampling in O(1), reject occupied or
pending plant sites and sites with <1 resource. Accepted births debit configured
E, transfer min(E/2,1000) to child and consume1 local resource for establishment;
remaining energy dissipates. Require living positive parent remainder and a
representable paid debit. Existing transactional birth path supplies mutation,
lineage and Commit timing. No schema/default change or new persistent state.
Tests must exercise actual production births, reservations, wrapped dispersal,
mutation/lineage, numeric limits, zero plants and multi-seed replay/conservation.
Migrate obsolete no-birth/RNG/age fixtures while preserving their original intent.
No feature code or application tests in PLAN, no packages installed; inherited
musl installation/reinstall commands above remain valid. Planning UTF-8/schema,
exact documentation scope, protected files, no remotes and whitespace validator
passes (command in task-local Markdown). No throughput/coexistence/persistence
claim, blockers, commits or phase transitions. Harness assigns IMPLEMENT.

TASK-012 IMPLEMENT cycle 1: implemented ADR-009 model-v1 clonal plant reproduction
in Reproduction, after physiology/animal actions. Eligible energy must exceed E
with a representable positive paid debit; child gets min(E/2,1000), parent pays E,
and destination pays 1 dissipated germination resource. Exact inherited fertility
trial and O(1) unique toroidal Chebyshev cell sampling use the sole engine RNG.
Living/pending plant occupancy and remaining stock <1 reject establishment.
Animals may share cells; initial stacks remain valid. Temporary reservations add
no authoritative persistent state. Existing transactional birth path supplies
mutation, lineage/generation and age-zero next-tick Commit/spatial insertion.
No plants means no births/draws; no replenishment, species, animal policy or UI.
No configuration/default/schema/package changes or new system installation.
Existing musl dependency/reinstall commands above remain applicable.

Implementation tests cover paid energy/resource ledgers, numeric limits, six
wrapped edge/corner births, exhaustive sampler geometry/uniform unique mapping,
mutation endpoints, exact raw-draw weather/fertility/dispersal/mutation reference,
blocked/pending sites, resource thresholds, stacked founders/animal sharing,
ID/generation rejection, recursive lineage, parental death and newborn timing.
Four-seed mixed full-state replay and zero-plant/animal worlds run for2200 ticks.
Earlier physiology/weather/expiry fixtures use scoped E=1001; production-enabled
regressions remain. Initial unit failures exposed obsolete no-reproduction
assumptions; new fixtures initially chose an occupied target and a nonhostile
climate and were corrected. Full suite first exposed an obsolete spatial
founder-only extinction expectation, isolated with E=1001. Final suite passes
103 tests (42 unit,53 integration,1 rustdoc,7 Python), no skips, including
host/musl packaging/static ELF/copied-empty-root version. Headless targeted
command passes62 tests; exact commands/results are in TASK-012 implement handoffs.
Formatting, whitespace, handoff/schema/protected-path checks are recorded there.

No plan/model deviation or known acceptance gap. Dense area work, lifetime
history growth, stable-ID establishment bias and one-shot site failures remain.
No throughput/coexistence, disk persistence, separate fresh-container or Rust1.85
claim. Future checkpoint/hash must encode reproduction model/effective settings
and full DNA/lineage/RNG/depleted resources; no temporary reservations at tick
boundaries. Harness owns review, commits, task status and phase transitions.


TASK-012 REVIEW cycle 1: PASS; all five acceptance criteria independently verified,
no gaps. Reviewed committed implementation be49183..9e1a0e2, approved plan, ADR-009,
production code and acceptance/regression tests. ./test.sh exit 0: 103 pass, none
skipped (42 unit, 53 integration, 1 rustdoc, 7 Python), including host/musl
setup/build, static ELF and copied-empty-root version checks. Separate headless
targeted run passes 62 tests; formatting/whitespace pass. Energy/resource payments,
unique bounded seam dispersal, mutation/lineage, pending occupancy and zero-plant
2200-tick continuation are covered through actual production ticks. Review changes
only STATE and task-local review handoffs; architecture/ADRs remain current.
No product changes, dependencies installed, remotes, commits or phase transitions.
Stable-ID bias, one-shot misses, initial finite bursts and dense area/history
costs remain documented limits; no throughput/coexistence or disk persistence
claim. Future persistence must encode exact RNG/resources/DNA/lineage/settings.
Detailed evidence: tasks/TASK-012/handoffs/review-cycle1.md and .json. Harness owns
completion and next assignment; no remediation required.

TASK-013 PLAN cycle 1: documentation-only plan and ADR-010 prepared; no animal
feature implementation yet. TASK-008/010 dependency reviews PASS with no gaps;
no prior TASK-013 or downstream TASK-014..016 handoffs. Initial Git tree clean,
no remotes. Trait-based wrapped sense, nearest-food shortest adjacent pursuit,
stateless unique-neighbor random exploration and speed/metabolism-scaled paid
steps are specified. Co-occupancy remains unlimited; plant establishment retains
its local occupancy policy. No feeding/hunting/mating, basal maintenance, CLI,
checkpoint implementation or config/default change. Detailed interfaces, ordered
work, six-point acceptance matrix, RNG/energy regression migrations and bounded
2200-tick replay checks persist in tasks/TASK-013/handoffs/plan-cycle1.md.
No code/tests/dependencies added, packages installed or application tests run in
PLAN. Existing system dependency reinstall commands above remain applicable.
Planning validator passed: UTF-8 JSON fields/types, exact five documentation paths,
protected paths unchanged, no remotes and git diff --check. No blockers or review
gaps. Harness owns commits, task states and phase transitions.

TASK-013 IMPLEMENT cycle 1: animal navigation model 1 is implemented. Public
Population::sense derives inclusive wrapped vision from DNA, returns sorted IDs
excluding self, and is observational. Private ecology/animals helpers own only
geometry/cost/sampling; Simulation uses the existing age-first walkers, indexed
nearest-food selection, shortest adjacent pursuit and stateless random exploration.
At most inherited speed steps, each charged movement_cost * speed * metabolism;
unaffordable steps draw/move nothing and exact exhaustion removes immediately.
All kinds share cells without capacity; plant establishment gates stay local.
No feeding, attacks, mating, basal costs, new config/schema/dependency or CLI.
Future persistence retains model identity plus full existing DNA/RNG/position/
vitals/settings, rebuilds cache, and excludes temporary targets/neighbor lists.

Verification: final headless targeted command (in TASK-013 implementation handoff)
passes 63 tests; final ./test.sh passes 115, no skips: 50 unit, 57 integration,
1 rustdoc, 7 Python. Includes host/musl setup/build, static ELF and copied-empty-
root version, all-speed per-step cache/energy checks, exhaustive small-torus paths,
actual seam ticks and four-seed 2200-tick positive-cost replay/oracles. Initial
compile error (wrong test seed type) and one obsolete plant sharing fixture failed
and were repaired; exact commands/results in handoffs. cargo fmt --check and
git diff --check pass. No performance/coexistence, fresh-container or Rust 1.85
claim. No system packages installed, new dependencies, remotes or protected edits;
existing setup reinstalls missing musl prerequisites with commands recorded above.
No prior review gaps, blockers or plan deviations; harness owns commits/transitions.

TASK-013 REVIEW cycle 1: PASS, no acceptance gaps. Independent implementation
diff/source/plan review and full ./test.sh pass: 115 tests, no failures/skips
(50 unit, 57 integration, 1 rustdoc, 7 Python), including wrapped perception,
all-speed paid adjacent movement, exhaustive shortest routes, sharing, immediate
index/death synchronization and four-seed 2200-tick replay. Formatting/whitespace
pass. Review changes only STATE and task-local review handoffs; no dependency
installed. No throughput/coexistence or future checkpoint claim. Detailed evidence
and scope limits: tasks/TASK-013/handoffs/review-cycle1.md and .json. Harness owns
completion, commits and transitions.

TASK-014 PLAN cycle 1: documentation-only implementation plan and ADR-011 prepared;
no feature code or subsequent phase started. Required files verified, project/
contract/current architecture/source/tests and prior structured handoff summaries
inspected; TASK-011/013 dependency reviews PASS without gaps. Initial tree clean,
no remotes, no previous TASK-014 handoffs or blockers. Applied workspace PLAN skill.

Planned herbivore grazing: age first, then positive genetic/current-temperature
basal upkeep; risk locus 11 filters food adjacent to sensed predators, nearest
eligible plant/ID tie, paid speed-limited pursuit stopping within wrapped reach 1,
one <=4-unit bite converting 80% of realized plant debit. Immediate plant energy
death updates spatial cache before later actors/reproduction. Full headroom bounds
transfer; no resource payout, global population checks, new config/defaults,
attacks or animal births. Basal floor 1e-9 explicitly handles representability for
tiny positive valid settings. Carnivore navigation unchanged. No new persistent
state/dependency. Acceptance matrix includes real-tick paired genomes, seams,
energy/death/climate oracles, fixture migration and four-seed 2200-tick replay.

No application tests/simulations executed or packages installed in PLAN; existing
system prerequisite/reinstall commands above and setup.sh remain applicable.
Planning validator passes UTF-8/schema, exact five documentation paths, protected
files, absent remotes and whitespace; exact command/result in plan-cycle1.json.
No throughput/coexistence/checkpoint claim. Future persistence must capture model
identity, effective settings and complete existing state. Harness owns commits,
task status and phase transitions; IMPLEMENT remains unstarted.


TASK-014 IMPLEMENT cycle 1: herbivore grazing model 1 (ADR-011) is implemented.
The shared age-first walker applies positive basal maintenance, inherited
metabolism and CURRENT temperature stress, then one indexed sense snapshot.
Risk locus 11 filters plants beside visible predators for cautious animals;
nearest distance/ID chooses food. Paid speed-limited pursuit stops at wrapped
reach 1; one <=4-unit bite credits 80% of actual plant energy removed. Immediate
plant starvation removes its index entry before later grazers/reproduction.
No hunting, production animal births, global population feedback, new persistent
state, public mutation API, schema/default, CLI or dependency changes.

Pure ecology/herbivores helpers import config/traits/topology only. Simulation
owns target choice, common target/stop-radius movement executor and Population
ledgers. Carnivores retain prior navigation. Uniform numerical basal floor 1e-9
ensures tiny valid settings still pay a representable cost. Configuration and
model details: ANIMALS.md/CONFIGURATION.md/PLANTS.md and ADR-011. Future checkpoint/
hash must encode grazing model identity/effective settings and all existing
DNA/vitals/RNG/resources/climate/lifecycle state, excluding transient targets/cache.

Final ./test.sh exit 0: 132 tests, no failures/skips (64 unit, 60 integration,
1 rustdoc, 7 Python), including host/musl setup/build, static ELF and copied-empty-
root version. Headless targeted command in TASK-014 handoff exits 0, 84 tests.
Tests cover vision/reach/seams/tiny axes, all-speed paid pursuit, conservative
partial/lethal/capacity bites, sequential remaining stock and cache removal,
full-tick physiology ledgers, every-tick upkeep/starvation, thermal/genetic/current-
weather costs, paired risk-only genomes, hidden predators, death priority,
newborn timing and nonvacuous grazing-preempts-reproduction control. Existing
four-seed 2200-tick mixed replay retains conservation/spatial/extinction oracles.

Initial tests failed on eight obsolete movement/plant-ledger assumptions; fixtures
were migrated without disabling production upkeep. New climate fixture initially
saturated at static 1x1 temperature; changed to nonsaturated 1x4 current-climate
case. Plant establishment fixtures isolate grazing with a sub-upkeep animal;
separate sharing fixture keeps a full living herbivore. Lifecycle now allows
herbivore starvation and retains explicit low-upkeep OldAge evidence. Exact
commands/results, decisions and limitations: tasks/TASK-014/handoffs/implement-
cycle1.md and .json. No known acceptance gaps/model deviations; tests are private
child-module fixtures plus public integration, with no alternate engine.

Formatting/whitespace and handoff/protected-path validation are recorded in the
handoff. No packages installed; existing setup/system prerequisite reinstall
commands above remain applicable. No remotes, commits or phase transitions.
No throughput/coexistence, fresh-container or full checkpoint claim. Stable-ID
food access bias and O(local plants * visible predators) filtering remain limits.
Harness owns review, task state and completion.


TASK-014 REVIEW cycle 1: PASS, no acceptance gaps. Independent implementation
diff/source/plan review confirms visible-plant selection, wrapped reach <=1,
bounded conservative bites and immediate plant death, positive every-tick upkeep,
current-temperature effects and actual risk-locus-only behavioral differences.
Full ./test.sh passes 132 tests, no failures/skips (64 unit,60 integration,
1 rustdoc,7 Python), including host/musl/static packaging and copied-empty-root
version checks. Formatting/whitespace pass. Detailed acceptance mapping, commands
and limits: tasks/TASK-014/handoffs/review-cycle1.md and .json.
No product edits or system dependencies added; existing reinstall commands apply.
No throughput/coexistence or full checkpoint claim. Review changes only STATE and
task-local handoffs. Harness owns completion, commits and transitions.


TASK-015 PLAN cycle 1: documentation-only hunting plan and ADR-012 prepared;
implementation unstarted. Dependencies TASK-013/014 REVIEW PASS without gaps;
all existing phase handoffs read, initial tree clean/no remotes, no prior TASK-015
handoffs or blockers. Applied workspace PLAN skill. Required files verified first.

Plan: reuse age-first walker, identical current-temperature maintenance, indexed
nearest visible herbivore/ID tie and paid speed-limited pursuit stopping at reach
1. One payable 0.5*metabolism attack per tick uses bounded trait/health odds and
the sole engine RNG. Immediate Population::kill with Predation funds at most 80%
of prey's snapshotted energy within capacity, with conservative rounding guard;
only true kill credits. Sequential ID-order sensing prevents duplicate prey
payouts. No authoritative state/config/default/schema/dependency change, handling
timers, carcasses or animal reproduction. Exact formula/gates, interfaces and
acceptance/regression matrix persist in ADR-012 and TASK-015 plan-cycle1.md.

No application tests or simulations run and no packages installed in PLAN;
existing setup/musl reinstall commands above remain applicable. Prior 132-test
TASK-014 PASS is inherited evidence only. Planning validator checks UTF-8/schema,
exact five documentation paths, protected files, absent remotes and whitespace;
actual command/result recorded in plan-cycle1.json. No throughput/coexistence or
checkpoint claim. Future persistence records model identity and full existing
state. Harness owns commits, task state and phase transitions.


TASK-015 IMPLEMENT cycle 1: carnivore hunting model 1 (ADR-012) implemented using
workspace IMPLEMENT skill. Carnivores now pay identical current-temperature
maintenance, sense nearest visible herbivore with stable-ID ties, pursue by paid
adjacent steps to reach <=1 and attempt at most one paid stochastic attack.
Both animals' strength/health, predator aggression and prey speed determine odds
clamped 0.1..0.9; the sole engine RNG supplies each paid surviving trial.
Immediate Predation removal funds only true-kill nutrition, <=80% prey energy
within capacity, with exact realized-gain guard. Sequential fresh sensing prevents
duplicate consumption. No global rescue, new authoritative state, config/default,
dependency, reproduction, CLI/UI or persistence format added.

Numerical refinement of the plan: common rescaling only if both health scores
underflow to zero avoids NaN for minimum positive valid health. This preserves
the mathematical probability ratio; tested and documented in ADR-012/ANIMALS.md.
Navigation-only legacy adapters are cfg(test). Obsolete mixed fixtures isolate
unaffordable attacks for genetics/risk, use shared walkers for lifecycle timing,
and retain separate geometry-only navigation checks. Mixed production replay,
conservation/spatial oracles and explicit new hunt RNG/timing tests remain.

FINAL ./test.sh > target/task015-full-final.log exit 0: 145 tests, no failures or
skips (75 unit,62 integration,1 rustdoc,7 Python), including host/musl build,
static ELF and copied-empty-root version checks. Final headless targeted command
in task handoff passes 93 tests. Acceptance evidence includes 512 independent
production attacks with kills/escapes and exact independent formula/RNG/ledger
checks, four trait-only pairs each across 4096 shared trials, health effects,
reach/vision/all speeds/seams/tiny axes, immediate single predation/cache removal,
competition after success/failure, conservative subnormal/capacity nutrition,
upkeep/attack/movement lethal gates, current thermal costs, newborn timing,
weather/wander/trial ordering, public starvation and separate carnivore OldAge.
Existing four-seed 2200-tick mixed full-state replay remains passing.

Initial compilation failed on a not-yet-created test module, then four old unit
fixtures failed under new physiology/attacks. New tests initially used nonexistent
Seed::from conversion (fixed to from_u64); a new nearest-target expectation moved
an already-adjacent predator (fixed to radius-1 stay). All final checks pass.
Exact commands, outcomes, acceptance mapping and fixture explanations persist in
TASK-015 implement-cycle1.md/.json. No known acceptance gaps. Formatting/whitespace
and artifact validation pass. No package installed; existing setup/system install
commands above remain applicable. No remotes, commits or phase transitions.
No throughput/coexistence, fresh-container or full-checkpoint claim; stable-ID
competition and full-reserve predation bursts remain limits. Future persistence
must record model identity and full existing state, excluding transient targets
and derived cache. Harness owns review, completion and commits.


TASK-015 REVIEW cycle 1: PASS; all five hunting acceptance criteria independently
verified against implementation diff 5f3d779..825ba5d and production tests.
Full ./test.sh passes 145 tests without failures/skips; headless targeted subset
passes 93. Formatting, whitespace and review artifact/scope checks pass. Exact
commands, acceptance mapping and limits: tasks/TASK-015/handoffs/review-cycle1.md
and .json. No product edits, dependencies installed, gaps or remediation.
Architecture/ADRs remain accurate. Stable-ID competition/full-reserve bursts,
future complete-state persistence and unmeasured throughput/coexistence remain
documented limitations. Existing dependency reinstall commands above apply.
Harness owns completion, commits and subsequent assignment; no next phase begun.


TASK-016 PLAN cycle 1: documentation-only plan and ADR-013 prepared; feature
implementation unstarted. Required files verified first; applied workspace PLAN
skill, inspected required product/task/context and dependency handoffs/source.
TASK-009/013/014/015 reviews PASS, no gaps; no previous TASK-016 handoffs. Initial
worktree clean and no Git remotes. No packages installed or new dependencies
planned; inherited exact prerequisite/reinstall commands above remain applicable.

Chosen policy: local same-kind mature contact pairs, inclusive ADR-004 D<=1/5,
nearest eligible mate/ID tie, one trial per animal per tick, product fertility,
one immediate offspring. Both parents pay animals.reproduction_energy; combined
realized loss funds newborn energy, with representability guards. Configured
cooldown stamps BOTH successful parents via NEW authoritative optional last
reproduction tick; elapsed subtraction avoids u64 overflow. Existing queue_birth
supplies crossed/mutated DNA, sorted parents, max generation+1 and Commit timing.
No global-count rescue, species implementation, schema/default changes or UI/CLI.
Future checkpoint/hash MUST include optional last reproduction timestamps exactly;
transient attempted IDs and derived spatial cache are excluded.

Detailed ordered file/API plan, exact algorithms, tests and fixture migration:
tasks/TASK-016/handoffs/plan-cycle1.md and ADR-013. No application tests or
simulations executed in PLAN; prior 145-test TASK-015 PASS is inherited evidence
only. Planning validator passes UTF-8/schema, exact five documentation paths,
protected scope, absent remotes and whitespace (command in PLAN JSON). No known
blocker/review gap, throughput/coexistence or full-checkpoint claim. Harness owns
commits, task states and phase transitions; no subsequent phase started.

TASK-016 IMPLEMENT cycle 1: ADR-013 sexual reproduction model 1 implemented.
After unchanged plant reproduction, herbivores then carnivores select distinct
living same-kind contact mates by eligible distance/ID. Maturity is lifespan/10,
compatibility is inclusive integer D<=1/5, and one trial per animal per tick uses
the exact product of both fertility alleles. Accepted births reuse transactional
crossover/mutation and lineage; both parents pay E, newborn receives E and both
parents are immediately stamped for configured elapsed-tick cooldown. Conservative
floating-debit guards prevent free offspring. No global-count intervention,
config/default/dependency, species, CLI/UI or disk persistence additions.

Organism now owns authoritative last_reproduction_tick: Option<u64>, initially
None for founders/children, read-only publicly and included in clone equality.
Future checkpoint/hash MUST encode Option/value exactly, validate animal ticks
<= engine tick and preserve cooldown on load, plus model identity/full existing
state. Phase-local attempted IDs are transient; spatial index remains derived.
Pure helpers depend on genome/traits only, Population owns validated atomic pair
stamps and Simulation owns selection/RNG/payments. No packages installed; prior
exact prerequisite/reinstall commands remain applicable.

Final ./test.sh > target/task016-full-final.log exited 0: 159 tests, no failures
or skips (87 unit,64 integration,1 rustdoc,7 Python), including host/musl builds,
static ELF and copied-empty-root version. Production evidence covers both kinds,
wrapped contact/degenerate axes, gates/compatibility boundary, independent 512
fertility/crossover/mutation trials per rate/kind, 4096 paired fertility streams
per kind, exact energy/cooldown/lineage/index, ID/generation rejection, newborn
and three-kind birth ordering. Public solitary animals continue 2200 ticks with
zero births; existing four-seed mixed replay/conservation/spatial oracles retained.
The fixed two-carnivore starvation ledger alone sets E=1001 to isolate its old
purpose; mixed production replay remains enabled. Initial compile used a wrong
geometry method, one new test's patterned lifespan required older fixture parents,
and that old starvation ledger gained real births; all corrected and documented.
Final targeted/headless/format/schema evidence and exact commands: TASK-016
implement-cycle1.md/.json. No known acceptance gaps; no throughput/coexistence,
full checkpoint, separate fresh-container or minimum-Rust execution claim.
Local dense stacks may give quadratic mate work; stable-ID bias and finite
founder-reserve bursts remain. No commits/task-state changes/phase transitions;
harness owns review and completion.


TASK-016 REVIEW cycle 1: PASS, all six acceptance criteria met with no gaps.
Independent implementation diff ebabc56..eb4a2dc/source/test review confirms local
eligible distinct same-kind parents, crossed/mutated DNA and lineage, both-parent
costs/cooldowns, fertility trials and solitary zero births. Full ./test.sh passes
159 tests without failures/skips (87 unit,64 integration,1 rustdoc,7 Python),
including setup/build/static/copied-empty-root checks. Headless targeted subset
passes 114; formatting/whitespace and review artifact validation pass. Exact
commands, acceptance mapping and limits: tasks/TASK-016/handoffs/review-cycle1.md
and .json. No product edits or new tests/dependencies required; no packages
installed. Existing dependency reinstall commands remain applicable. Architecture
and ADRs are current. Future persistence must preserve cooldown Option/value and
complete state; dense mate stacks/stable-ID bias and unmeasured coexistence/
throughput remain documented limitations. Review changes STATE and task-local
handoffs only. Harness owns completion/commits/transitions; no next phase begun.

TASK-017 PLAN cycle 1: documentation-only species/family-tree plan prepared in
 tasks/TASK-017/handoffs/plan-cycle1.md/.json with ADR-004 integration refinement.
Required files verified first; applied workspace PLAN skill. Dependency
TASK-009/012/016 reviews PASS without gaps; no previous TASK-017 handoffs/gaps.
Initial tree clean/no remotes. No code, task states, protected files, commits,
packages or next phase. Existing exact system prerequisite/reinstall commands
above remain applicable; no new dependency planned.

Preserve immutable founder exact inclusive D<=1/10 classification at initial
insertion and sorted newborn Commit; same-kind nearest founder/ID tie, permanent
membership. Population owns registry; organism.rs owns opaque SpeciesId value,
re-exported from species.rs to avoid cycles. Species ID equals first member's
organism ID (monotonic with gaps), exact deterministic kind-ID name, no RNG or
independent allocator. Pending births capture lower-ID parent's species before
parent death. Immediate kills decrement live membership; extinction finalizes
only after all committed births/deaths, preventing false extinction with accepted
matching offspring. Extinct records never reactivate and persist for ancestry.
Current per-kind species counts can be queried at every tick; no historical
snapshot API planned. No species gate added to animal compatibility or ecology.

Detailed ordered APIs/files, threshold/forced-divergence/ancestry/extinction tests,
production policy paths and 2200-tick replay plan are in task-local Markdown.
Future canonical state must retain full registry history/founder DNA/ancestry/
ticks/memberships/model identity, with validated or rebuilt living counters;
no disk schema implemented. Historical registry scan costs grow with diversity;
no throughput/coexistence guarantee. No application tests/simulations executed
in PLAN; inherited TASK-016 159-test result is context only. Planning artifact
validator passed UTF-8/schema, exact five documentation paths, protected scope,
no remotes and whitespace. Exact command in JSON/Markdown. No blocker or review
gap; implementation remains unstarted and harness owns all transitions/commits.

TASK-017 IMPLEMENT cycle 1: Species model 1 is implemented under ADR-004.
Population owns SpeciesRegistry; all organisms have permanent nonoptional
SpeciesId. Initial insertion and sorted newborn Commit use nearest immutable
same-kind founder within exact inclusive 10*S<=786420, then smallest species ID.
New IDs equal first member organism IDs (gaps allowed), with canonical ASCII
kind-ID names and no RNG. Accepted births capture lower-ID parent's species
before possible parental death; existing species ancestry is never overwritten.
Immediate death updates member counts; Commit finalizes extinction after births
and death accounting. Historical records persist and extinct IDs never reactivate.
Public queries are observational/current-state, including per-kind living species.
No ecological, configuration/default, dependency or CLI/UI change. No legacy
biological fixture expectation changed. cfg(test)-only coherent-founder setup
supports full-tick divergence tests; production has no relabel/mutation API.

Final executed verification (all exit 0):
- `./test.sh > target/task017-full-final.log 2>&1`: 171 passed, no failures/skips
  (97 unit, 66 integration, 1 rustdoc, 7 Python). Includes host/musl setup/build,
  static ELF and copied-empty-root distribution/version checks.
- `env -u DISPLAY cargo test --locked --lib --test species --test genome --test organism --test lifecycle --test spatial --test simulation --test plant_reproduction --test animal_reproduction > target/task017-headless-final.log 2>&1`:
  121 passed (97 unit, 24 integration), no failures/skips.
- `cargo fmt --check && git diff --check`: formatting/whitespace pass.
New tests verify threshold78641/78642/78643, immutable founders/chaining,
nearest/ties/kinds, ordered newborns, exact captured ancestry, simultaneous splits,
parent death, extinction/no resurrection, transaction rollback, public count
oracles/query purity and four-seed2200-tick full-state replay. Actual full ticks
force plant split at seed1 and both animal kinds at seed0 with high validated
mutation, independently checking raw-draw DNA. Controlled animal founders belong
to distinct genetically compatible species, proving mating remains distance-based.
Initial new-test compile errors (typed seed and borrowed Genome) and a raw-draw
oracle missing the length-one dispersal axis draw were corrected; final runs
above include every correction. Full details: TASK-017 implement handoffs.

No new packages installed; inherited system prerequisites/install commands above
remain sufficient. No remotes, protected-file edits, commits or phase transition.
Future checkpoint/hash must include species model identity, immutable historical
records/founders, ancestry/origin/extinction ticks and every organism membership;
validate/rebuild counts, never founders. No new species allocator. See SPECIES.md.
Historical scans are O(total species*12) per birth and O(total species) per
extinction finalization/query, retaining lifetime history. No throughput,
coexistence, natural split frequency or on-disk persistence claim. Harness owns
review and subsequent work; no known implementation gaps.

TASK-017 REVIEW cycle 1: PASS, all five acceptance criteria met; no gaps.
Independent implementation 479a7ea..77f251b/source/plan/ADR/test inspection confirms
permanent distance-based same-kind membership, deterministic IDs/names, exact
inclusive threshold, forced production splits, retained ancestry/extinction ticks
and current living-species queries. Full ./test.sh passes 171 tests with no
failures/skips (97 unit,66 integration,1 rustdoc,7 Python), including host/musl
setup/build, static ELF and copied-empty-root version checks. Headless targeted
subset passes 121; formatting/whitespace and review artifact validation pass.
Exact commands/acceptance mapping: TASK-017 review-cycle1.md/.json. No product
edits, new tests, dependencies or packages required. Existing system install/
reinstall commands above remain applicable; architecture and ADRs are accurate.
Historical-scan/lifetime-history costs and future complete registry persistence
obligations remain documented in SPECIES.md. No throughput/coexistence/natural
split-frequency/full-persistence claim. Review changes STATE and task-local
handoffs only. Harness owns completion/commits/transitions; no next phase begun.


TASK-018 PLAN cycle 1: prepared documentation-only integration plan and ADR-014.
Current production engine already joins climate/resources, all actions, paid
reproduction, immediate deaths and end-Commit species updates. Dependencies
TASK-012/014/015/016/017 REVIEW PASS without gaps; no prior TASK-018 handoffs.
Preserve order and local ecological mechanisms. IMPLEMENT must add public default-
config scenario/accounting/extinction/viability tests, measure defaults before
bounded tuning, and add a library example recording seeds0,1,2,42,99 for exactly
10000 ticks each. No CLI work or coexistence guarantee. Detailed fixtures,
assertions, file/API sequence, candidate values, report schema and runtime budget:
tasks/TASK-018/handoffs/plan-cycle1.md and ADR-014. Default survival and five-seed
long-run outcomes have NOT been measured or claimed in PLAN.

Actual baseline command:
`env -u DISPLAY cargo test --locked --test plant_reproduction --test herbivore_feeding --test carnivore_hunting --test animal_reproduction --test species --test lifecycle --test simulation`
exit0:18 integration tests passed,0 failures/ignored. Planning validator passes
UTF-8/schema, exact five documentation paths, protected scope, no remotes and
whitespace; exact command in PLAN JSON. Initial tree clean/no remotes. No product
code, task-state/protected-file changes, commits or phase transition. No packages
installed or new dependencies planned; existing setup/musl reinstall commands
above remain applicable. Full suite/new scenarios/long report await IMPLEMENT.
Harness owns assignments, review, commits and task states.


TASK-018 IMPLEMENT cycle 1: integrated ecology is verified through production
public APIs; existing scheduler already joined all policies. Added four scenario
integration tests, the five-seed library example and a shared external observer.
Only production changes: default plant regeneration1→2 and mating cooldown20→100;
no new schema/state/dependency, global rescue or insertion path. ADR-014 records
the measured amendment from planned cooldown40 after40/80 failed.69 exploratory
runs with exact configs: tasks/TASK-018/handoffs/balancing-cycle1.json.

Final verification:
- `./test.sh > target/task018-full-final.log 2>&1`: exit0,175 passed (97 unit,
  70 integration,1 rustdoc,7 Python), none failed/ignored/skipped. Includes host/
  musl setup/build, static ELF and copied-empty-root distribution checks.
- `cargo test --locked --release --test ecology_integration --example ecology_report -- --nocapture > target/task018-targeted-final.log 2>&1`:
  exit0,4 integration plus1 example helper tests passed. Final subsequent phase-
  report equality assertion is also covered by the full suite above.
- `env -u DISPLAY cargo run --locked --release --example ecology_report > tasks/TASK-018/handoffs/ecology-cycle1.json`:
  exit0,5 seeds each exactly10000 ticks; per-tick conservation/species/absorbing-
  zero/lineage/vitals audits. Plants survive all, herbivores extinct22..27,
  carnivores857..875. Final loop+audit seconds1.854..1.921 per seed, hardware
  undisclosed, not a throughput claim. Raw report retains all configurations.
- `cargo test --locked --example ecology_report > target/task018-helper.log 2>&1`:
  exit0,1 test; initial-absence/survival/empty-tail conventions.
- `cargo fmt --check` and `git diff --check`: exit0.
Initial observer compilation failed on Traits::health (corrected to max_health).
One premature report JSON inspection during redirection saw an empty in-progress
file; completed final artifact validation passes. Exploratory runs reveal actual
viability failures, retained honestly; no baseline ecological outcome was hidden.

Default-only seeds0/1/42: isolated plants alive every tick through2200, with living
descendants after founder lifespan; abundant-food plants/herbivores alive every
tick through600, births by300 and additional herbivore births300..600. No-plants
scenarios lose herbivores45/61/49 then carnivores878/864/907, continue5000; no-
herbivores carnivores extinct by5000. Empty1000 and natural plant-extinction2200
scenarios keep ticking without recovery. Contract example1000-tick fresh replay
compares complete state every tick while auditing one copy only. ECOLOGY.md holds
order, mechanisms, exact commands and all final results. Mixed-world coexistence
is short, not guaranteed; broad tuning remains TASK-027. CLI remains TASK-019.

No packages or system dependencies added. Existing setup prerequisites/reinstall
commands remain applicable. No Git remotes, commits, protected task changes or
phase transition. Required implementation handoffs are task-local cross-session
memory; harness owns review and commits.


TASK-018 REVIEW cycle 1: PASS, all seven criteria independently verified with no gaps.
Full ./test.sh exit0:175 passed (97 unit,70 integration,1 rustdoc,7 Python);
report helper1 passed; cargo fmt --check and git diff --check exit0. Independently
reran five default10000-tick seeds; all outcomes equal recorded report excluding
timing. Plants survive all; herbivores extinct22..27, carnivores857..875.
Public scenario tests prove default2200-tick plant renewal and600-tick abundant-
food herbivore recruitment, per-tick ledgers, absorbing extinction and1000-tick
full-state replay. No product edits/dependencies; architecture/ADRs remain current.
Exact commands/evidence/limits: tasks/TASK-018/handoffs/review-cycle1.md and.json;
logs under target/task018-review-*. Harness owns completion and next assignment.

TASK-019 PLAN cycle 1: documentation-only headless run plan and ADR-015 prepared.
Dependencies TASK-003 and TASK-018 REVIEW PASS without gaps; no previous TASK-019
handoffs. Current run/hash unimplemented. Plan preserves engine/ecology and adds
contract CLI parsing, seed override, exact-N stepping through extinction, required
result/sampling, atomic output and complete-state SHA-256 schema1. Private owner
encoders cover allocator/sequence/counters/histories/resources/cooldowns/species;
derived cache and outer timing/sampling excluded. No save/load/batch/UI work.
Detailed ordered paths/interfaces/acceptance tests and limitations:
tasks/TASK-019/handoffs/plan-cycle1.md and docs/decisions/ADR-015-canonical-state-and-run.md.
Actual baseline `env -u DISPLAY cargo test --locked --test cli --test config --test simulation`
exit0:14 tests passed (2+8+4),0 failed/ignored. No new run/hash or full packaging
verification claimed. Initial tree clean, no remotes; no packages installed or
system dependencies added. Proposed sha2 dependency must be resolved/tested in
IMPLEMENT; existing setup/musl reinstall commands above remain applicable.
Harness owns phase transitions, commits and task states; PLAN stops here.

TASK-019 IMPLEMENT cycle 1: headless `run` and complete-state SHA-256 schema1
are implemented. Required flags --config/--ticks/--out and optional --seed/
--sample-every accept strict separated pairs once; save/load and batch remain
later tasks. Full config validation precedes normalized arbitrary-integer seed
override. Exact-N engine ticks continue through extinction; tick0/multiple-K/end
samples are unique, default K=max(1,N/100), with finite tick-call-only timings
and zero timings for N0. Required contract result keys plus state_hash_schema1
are published by same-parent exclusive temporary write/flush/close/rename.
Returned failures use stderr/status2, leave absent output absent and preserve
old regular output; nonregular/symlink outputs reject. README has a complete run
example. No ecology/default/scheduler changes or new authoritative state.

Private std-only canonical primitives and owner-local encoders cover effective
config, tick, full RNG, topology/climate/weather/resources, living DNA/lineage/
vitals/cooldowns, allocation/sequence/accounting/cause counts, ordered deaths and
all species history. Derived spatial/area/traits and outer observations exclude;
nonempty pending transactions reject hashes. Schema/golden/hash APIs and future
checkpoint obligations: ADR-015, architecture and TASK-019 implement handoffs.
No checkpoint codec implemented. Every new authoritative field must extend the
canonical inventory/tests and deliberate model/schema versioning.

Actual final verification:
- `cargo test --locked --test config --test cli --test run_cli --test state_hash > target/task019-targeted.log 2>&1`: exit0,16 pass.
- `cargo test --locked --lib --test run_cli --test state_hash > target/task019-final-targeted.log 2>&1`: exit0,116 pass (110 unit,4 run,2 hash).
- `./test.sh > target/task019-full-final.log 2>&1`: exit0,195 pass
  (110 unit,76 integration,1 rustdoc,8 Python),0 failed/skipped/ignored. Includes
  host/musl setup/build, actual launcher repeat-seed equality from spaced paths
  without displays, static ELF and copied empty-root N0/N10 runs.
- `cargo fmt --check` and `git diff --check`: both exit0.
- Required handoff/schema/inventory/protected-scope/no-remotes validator is in
  tasks/TASK-019/handoffs/implement-cycle1.md; final execution recorded in JSON.
Initial new sensitivity test compilation and golden-header assertion failed,
then corrected. First no-plants test wrongly forbade finite animal reproduction
from initial reserves; corrected to conservation, absent-kind births and empty
tails. Details and earlier successful runs remain in implementation handoffs.

New direct crate sha2 0.10.9, default-features=false. Cargo.lock adds digest
0.10.7, block-buffer0.10.4, crypto-common0.1.7, generic-array0.14.7, typenum1.20.1,
version_check0.9.5, cfg-if1.0.5, cpufeatures0.2.17 and libc0.2.191. Host/musl
compile and offline copied runtime verified. No system packages installed here;
existing exact reinstall commands remain: `apt-get update` then
`apt-get install -y --no-install-recommends musl-tools`, and
`rustup target add x86_64-unknown-linux-musl` when missing (setup.sh detects these).
Existing Python3/Git/readelf/coreutils/root chroot test prerequisites remain;
new FIFO test uses inherited coreutils mkfifo. No pip/npm/browser dependency.

Limits: SHA-256 collision resistance, not mathematical injectivity; huge valid
worlds/series/lifetime histories can still trigger OS OOM despite fallible vector
reserves. Publication is atomic on returned success, without crash-durable fsync.
GNU/musl floating hashes may differ across builds; deterministic equality is
within the same machine/build. No fresh Ubuntu replacement or separate minimum
Rust1.85 build was performed. No known acceptance gaps/blockers, no Git remotes,
protected edits, commits or phase transition. Harness assigns review.

TASK-019 REVIEW cycle 1: PASS; all six acceptance criteria independently verified.
Inspected implementation diff062f64d..6b5cfb7, owner state/encoder inventory, CLI
publication/errors and regression tests. ./test.sh > /workspace/target/task019-review-full.log 2>&1
exit0:195 tests (110 unit,76 integration,1 rustdoc,8 Python), no failures/skips.
Host/musl/static ELF/copied empty-root run checks pass. Additional12 headless
launcher runs cover N0,1x7/7x1 and contract64x48 N1000, exact sampling/accounting,
replay and different seeds. cargo fmt --check and git diff --check exit0.
No acceptance gaps, product changes or dependency installations. Full review
evidence/limitations: tasks/TASK-019/handoffs/review-cycle1.md and .json.
Architecture/ADR-015 remain accurate. Future checkpoints must preserve complete
canonical inventory. Harness owns task completion, commits and transitions.

TASK-020 PLAN cycle 1: documentation-only metrics plan and ADR-016 prepared;
not implemented. Read-only Snapshot capture will add metrics_schema1 and analytics
at every existing CLI series tick, retaining required population keys. Cumulative
birth/death/cause counters, living species, all12 expressed trait mean/population
stddev/min/max and per-kind/overall living generations; empty statistics null.
No new authoritative state, RNG draws, canonical/hash schema change, dependency
or ecological tuning. Baseline headless run_cli/state_hash Cargo tests pass;
exact command, planned acceptance matrix and limits in TASK-020 plan handoffs.
No package installed; no implementation, full-suite or metric success claimed.


TASK-020 IMPLEMENT cycle 1: implemented public read-only typed metrics snapshots
and metrics_schema1 additive analytics on every CLI series sample. All12 living
phenotype mean/population-standard-deviation/min/max summaries, cumulative u128
birth/death/five-cause totals, living species and per-kind/weighted-overall living
generation are recorded. Empty statistics null; highest generation exact u64.
No new authoritative state, reverse engine dependency, ecological/default/config
change, crate/system dependency, canonical hash schema or checkpoint obligation.
README and docs/METRICS.md document the file interface, precision, units and costs;
ADR-016 and architecture describe actual implementation. Private test-only setup
reuses existing fixture helpers; no production mutation API was added.

Actual verification:
- `cargo test --locked --lib metrics > target/task020-unit.log 2>&1`: exit0,4 new
  units pass. Initial cargo fmt before child-file creation exited1; corrected.
- `env -u DISPLAY cargo test --locked --lib --test metrics --test run_cli --test state_hash > target/task020-targeted.log 2>&1`:
  exit0,123 pass (114 unit,2 metrics,5 CLI,2 hash). Includes three seeds and2200-
  tick reproducing/mixed/extinct sampled versus unsampled full-state/hash equality.
- `./test.sh > target/task020-full.log 2>&1`: exit0,202 pass (114 unit,79
  integration,1 rustdoc,8 Python), no failures/ignored/skips. Host/musl builds,
  copied empty-root run analytics and static ELF checks pass.
- `cargo fmt --check` and `git diff --check`: exit0. Documented complete JSON
  example schema validator passed. Final UTF-8 handoff/scope validator also passed
  (command and validator source retained in task-local implementation handoffs).

No packages installed; inherited setup.sh detects/reinstalls musl prerequisites
using commands recorded above. Limits: larger sample buffers/output, O(historical
species) queries, f64 generation mean precision above2^53 and possible cross-build
floating differences. No fresh Ubuntu provisioning/minimum-Rust run, coexistence
or performance claim. No acceptance gaps, remotes, protected edits, commits or
phase transition. Harness owns review. See TASK-020 implement-cycle1.md/.json.

TASK-020 REVIEW cycle 1: PASS; all five acceptance criteria independently verified.
Reviewed committed implementation40521e1..299bab4, immutable capture, explicit
trait/cause mapping, CLI scheduling, mathematical hand oracles and state/hash purity.
`./test.sh > target/task020-review-full.log 2>&1` exit0:202 tests (114 unit,79
integration,1 rustdoc,8 Python), no failures/ignored/skips; host/musl/static ELF
and copied empty-root run analytics pass. Six additional real headless launcher
probes pass founder arithmetic, per-row accounting/causes/nulls/generation and
interval-independent hashes/common rows. `cargo fmt --check`, `git diff --check`
and review artifact validation pass. No product changes or dependencies installed.
Review evidence/script: tasks/TASK-020/handoffs/review-cycle1.md/.json and
review-checks.py. No acceptance gaps; one nonblocking ADR-016 sentence conflates
singleton generation with founder generation (actual behavior and METRICS.md
are correct); optional later wording cleanup is documented. Existing size/float/
platform limits remain. Architecture unchanged. Harness owns completion/commits
and phase transitions; no next phase started.


TASK-021 PLAN cycle 1: documentation-only batch/export plan and ADR-017 prepared.
Dependencies TASK-019 and TASK-020 REVIEW PASS, no acceptance gaps; no previous
TASK-021 handoffs. Sequential shared-run execution, normalized exact seeds and
one optional --sweep 'group.key=[values]' over existing numeric leaves except
seed. Contract seed-only files, indexed variant directories, complete per-run
parameter/tick records, final population mean/min/max and extinction frequency;
summary.json and always-exported summary.csv contain no clocks/absolute paths.
Initially absent kinds count as extinct (final zero), including ticks0. Reruns
stage before promotion, publish JSON summary last; promotion is not directory-
atomic and may leave partial per-run files on failure without a completion marker.
No implementation, new authoritative state, dependency, core/config/default/hash
change, package installation or performance/batch-success claim. Existing exact
system prerequisite install/reinstall commands above remain applicable; setup.sh
detects missing musl tools/target. Detailed ordered paths/interfaces/schema/test
oracles/limits: tasks/TASK-021/handoffs/plan-cycle1.md and ADR-017.

Actual baseline command:
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test run_cli --test state_hash --test metrics > /workspace/target/task021-plan-baseline.log 2>&1`
exit0:9 passed (5 run CLI,2 state hash,2 metrics),0 failed/ignored. This tests
existing behavior only. Planning handoff/schema/scope/UTF-8/no-remotes/whitespace
validator is retained in PLAN Markdown; no full suite or new batch tests run.
Initial tree clean, no remotes; no protected edits, commits or phase transitions.
Harness owns IMPLEMENT assignment, review, task state and commits.

TASK-021 IMPLEMENT cycle 1: implemented contract batch, one validated numeric-leaf
parameter sweep, deterministic complete-parameter JSON summary and automatic CSV.
Shared private cli/runner.rs retains standalone run semantics; cli/output.rs owns
unchanged atomic output; cli/batch.rs orchestrates fresh sequential engines in
variant-major/seed-major order. Summary aggregates final mean/min/max and zero-
population frequency, including initially absent kinds and ticks0. Exact seeds,
counts/extrema and checked u128 sums are retained; means/fractions use f64.
Stage cleanup and summary.json-last promotion support same-directory reruns;
promotion can leave partial per-runs without a completion marker. Real-directory,
symlink/special-file and configuration-alias preflight includes hard links.
No new authoritative state, core/config/default/model/hash/metrics/checkpoint
change or crate/system dependency. No packages installed. Existing musl prerequisite
reinstall commands above remain authoritative and setup.sh detects missing tools.

Actual verification:
- `cargo test --locked --test run_cli --test state_hash --test metrics > target/task021-extraction.log 2>&1`: exit0,9 existing tests after runner extraction.
- Initial `cargo test --locked --lib cli > target/task021-batch-unit.log 2>&1`
  failed101: missing json macro import in moved test; fixed test-only import,
  identical command rerun exit0,12 matching tests pass.
- `cargo test --locked --test batch_cli > target/task021-batch-cli.log 2>&1`:
  exit0,4 initial batch process tests pass.
- `cargo test --locked --lib cli > target/task021-fault-tests.log 2>&1`:
  exit0,13 matching tests pass, including added batch fault injection.
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib --test cli --test run_cli --test batch_cli --test state_hash --test metrics > /workspace/target/task021-final-targeted.log 2>&1`:
  exit0,134 pass (118 unit,16 integration),0 failed/ignored.
- `./test.sh > /workspace/target/task021-implement-full.log 2>&1`: exit0,
  earlier210 pass. Added final fault/normalization cases afterward.
- `./test.sh > /workspace/target/task021-implement-final-full.log 2>&1`: exit0,
  final212 pass (118 unit,84 integration,1 rustdoc,9 Python),0 failed/ignored/
  skipped. Includes host/musl/setup/build, static ELF, copied empty-root2x2 batch,
  standalone parity, Python CSV round-trip and deterministic repeat in separate
  and same output dirs on each build. No cross-build hash-equality assumption.
- Documented BATCH.md shell examples executed via Python subprocess: exit0,
  silent seed-only3 and matrix4 runs. Final `cargo fmt --check` and
  `git diff --check`: exit0. Handoff UTF-8/schema/scope validator retained in
  tasks/TASK-021/handoffs/validate-implement-cycle1.py.

README/docs/BATCH.md, ADR-017 and architecture describe commands, wire schemas,
precision, costs and failure limits. Risks: extreme batch/history/sample memory,
filename/disk limits, f64 precision above2^53, partial promotion/no concurrent
same-dir writer or fsync durability, allowed cross-build floating differences.
No performance, fresh-Ubuntu or minimum-Rust claim; no acceptance gaps/blockers.
Harness owns review, commits and task state/transitions. Detailed memory and
required UTF-8 JSON: tasks/TASK-021/handoffs/implement-cycle1.md/.json.


TASK-021 REVIEW cycle 1: PASS, all five acceptance criteria independently verified,
no gaps. Inspected committed implementation 8f354c7..f6ccaf8, approved plan,
ADR-017, dependent TASK-019/020 memory, CLI extraction, validation, aggregation,
CSV and staged publication. Full `./test.sh > /workspace/target/task021-review-full.log 2>&1`
exit0:212 pass (118 unit,84 integration,1 rustdoc,9 Python), no failures/ignored/
skips. Includes host/musl/setup/build, static ELF and copied empty-root batch.
`python3 tasks/TASK-021/handoffs/review-checks.py` exit0:18 real launcher calls,
three additional2x2 matrices (world size/weather/initial plants), standalone
parity, sampling, independent aggregates/CSV and byte-identical replay.
`cargo fmt --check`, log count and final handoff/scope/whitespace checks pass.
No product/architecture change or dependency installation; existing ADRs remain
accurate. Known memory/disk/f64/publication/cross-build limits remain documented.
No fresh-Ubuntu/minimum-Rust/performance claim. Review evidence and required JSON:
tasks/TASK-021/handoffs/review-cycle1.md/.json and review-checks.py.
Harness owns task completion, commits and phase transitions; no next phase begun.

TASK-022 PLAN cycle 1: documentation-only checkpoint plan and ADR-018 prepared;
implementation unstarted. Dependencies TASK-005/007/017/019 REVIEW PASS with no
gaps; no earlier TASK-022 handoffs. Initial tree clean, no remotes. Plan specifies
uncompressed version1 binary envelope around unchanged canonical schema1 with
length and SHA-256 checksum; owner-local inverse readers, bounded decoding and
cross-state validation; complete RNG/weather/resources/DNA/cooldowns/species/
allocation/accounting/death-history restoration without initialization or draws.
Derived spatial cache rebuilt only. CLI shared state runner supports absolute
loaded start/end and relative sampling, strict config/load exclusivity and save
publication before result; load=save supported. No feature code, core state,
default/config/dependency/model/hash changes or UI saving work in PLAN.
Details/acceptance matrix: tasks/TASK-022/handoffs/plan-cycle1.md and ADR-018.

Actual baseline:
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test rng --test temporal_climate --test species --test state_hash --test run_cli --test batch_cli`
exit0:24 passed,0 failed/ignored (5+5+2+2+5+5). Existing behavior only; no
checkpoint feature/full-suite/packaging success claimed. Planning scope/UTF-8
handoff/schema/no-remotes/whitespace validator retained in task-local file.
No packages installed or system dependencies added. Existing exact reinstall
commands remain `apt-get update`, `apt-get install -y --no-install-recommends musl-tools`
and `rustup target add x86_64-unknown-linux-musl` when missing via setup.sh.
Risks: codec inventory/invariant mistakes, malformed-length allocations, unbounded
history/byte-buffer memory/disk, partial two-file publication and cross-build float
differences. Harness owns IMPLEMENT assignment, task states, commits/transitions.

TASK-022 IMPLEMENT cycle 1: complete-state checkpoint format1 and run --save/
--load are implemented. Uncompressed versioned length-delimited canonical schema1
payload has SHA-256 header/payload checksum. Bounded owner-local readers validate
values, dimensions/settings/clocks, IDs/lineage/cooldowns, allocation/counters,
ordered deaths and retained species ancestry/membership before returning an
engine; exact canonical re-encoding guards fidelity. No initialization, species
reclassification, RNG draws, biological/default/config/schema change or new
runtime dependency. Only derived climate/spatial data is rebuilt. CLI preserves
batch's shared config wrapper, resumes actual absolute ticks with relative
sampling, checks overflow/aliases and publishes checkpoint before result.

Verification:
- `./test.sh > /workspace/target/task022-implement-full-final.log 2>&1`: exit0,
  224 tests pass (124 unit,89 integration,1 rustdoc,10 Python), no failures/skips.
  Includes setup twice/build, static ELF, root launcher/dist and copied empty-root
  save/resume at0/7/13, without display and from unrelated spaced paths.
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test checkpoint_cli --test state_hash --test run_cli --test batch_cli > target/task022-final-targeted.log 2>&1`:
  exit0,17 pass. Byte/CLI tests include actual0/7/53 splits and loaded analytics
  equal uninterrupted every-tick samples; public plant renewal through2250 and
  herbivore recruitment/cooldowns through650; forced speciation in all kinds.
- After the full suite's Rust build, added stricter ancestry-origin validation
  and one species unit test: `cargo test --locked --lib > target/task022-unit-validation.log 2>&1`
  exit0,125 pass. Final checkpoint continuation rerun is recorded in handoff JSON.
- Earlier full suite exited101 on a test-only invalid zero basal cost; changed
  signed-zero fixture to movement_cost. Other development corrections/commands
  are retained in TASK-022 implementation handoffs. No production ecology edits.

No packages installed. Existing exact prerequisite reinstall commands remain
`apt-get update`, `apt-get install -y --no-install-recommends musl-tools`, and
`rustup target add x86_64-unknown-linux-musl` when missing (setup detects these).
No Git remotes, commits, task states or next phases changed. docs/CHECKPOINTS.md
and ADR-018 define format/API/publication; task-local handoffs retain test evidence.
Limits: histories/checkpoint memory grow without bound; no multi-file transaction,
fsync durability, concurrent-writer or cross-build/libm compatibility guarantee.
No permissions-unreadable claim under root or separate minimum-Rust/fresh-OS run.
UI save/load remains TASK-024. Future state changes must update both codecs and
compatibility/model identities, inventory and continuation tests together.


TASK-022 REVIEW cycle 1: PASS; all five acceptance criteria verified, no gaps.
Independent diff/owner-code inspection and ./test.sh passed225 tests (125 unit,
89 integration,1 rustdoc,10 Python), none failed/ignored/skipped. Includes real
launcher/static copied-empty-root save/resume. Additional seven CLI runs verify
contract64x48 T300 splits0/37/117, matching hash/final/totals and independent
checkpoint header/length/SHA-256. Formatting/whitespace and review artifact scope
validation pass. Review modifies only STATE and task-local review handoffs;
architecture/ADRs remain accurate. No packages, product edits, commits or phase
transitions. Details: tasks/TASK-022/handoffs/review-cycle1.md and .json.
Retained limits: unbounded legitimate histories/buffers, same-build continuation,
no version migration, fsync, two-file transaction or concurrent-writer guarantee.
No fresh Ubuntu/minimum-Rust claim. Existing dependency reinstall commands above
remain applicable. Harness owns completion and next assignment; UI persistence
remains TASK-024.


TASK-023 PLAN cycle 1 (not implemented): ADR-002 refinement specifies private
application UI modules, tiny_http loopback server and embedded HTML/CSS/Canvas JS.
One UiSession owns the existing engine; capped20Hz scheduling and read-only10Hz
snapshots add no authoritative fields or schema/ecology changes. Static biome
cache, stable-ID living frame DTOs, camera and automation are observational state.
Node>=18 built-in CDP pipe driver controls actual Chromium for10/100-tick smoke/
screenshot modes with deadlines and child cleanup; Node/browser never enter core
or headless runtime requirements. Camera navigation/legend/world view only;
controls/inspection/checkpoint UI stay TASK-024, editing/charts TASK-025. Detailed
paths, protocol, visual choices and acceptance tests: TASK-023 plan-cycle1.md.

TASK-023 PLAN evidence:11 baseline tests passed using
`env -u DISPLAY cargo test --locked --test cli --test climate --test simulation`.
Chromium /usr/local/bin/chromium, Node /usr/bin/node and xvfb-run /usr/bin/xvfb-run
found. No system dependencies installed; no UI/browser/performance check run.
If Node is missing during implementation, planned exact reinstall commands are
`apt-get update` then `apt-get install -y --no-install-recommends nodejs`.
Chromium is benchmark-provided; retain its wrapper. Existing musl reinstall
commands remain above. Initial tree clean/no remotes; planning scope/schema and
whitespace validator result is in TASK-023 PLAN JSON. No prior review gaps.

TASK-023 IMPLEMENT cycle 1: live embedded browser world view implemented with
private cli/ui and ui_server adapters and ordinary Simulation production ticks.
Normal `./evosim ui [--config FILE]` prints the local capability URL; page first
draw starts advisory20Hz stepping, read-only frames poll10Hz. Canvas draws every
base-biome cell and all living IDs with distinct green disc/ivory circle/coral
triangle markers, full permanent legend, stack badges, drag/wheel/+/-/Fit and
DPR/resize handling. No ecology/default/config/hash/checkpoint/model changes or
new authoritative fields. Four response workers plus bounded queue isolate owned
HTTP output bytes from the single engine owner. All camera/DTO/OS-entropy token/
scheduling/automation state remains observational. Controls/inspection stay
TASK-024; editing/charts TASK-025. docs/UI.md and ADR-002 define protocol/limits.

New locked pure-Rust dependencies: tiny_http0.12.0, ascii1.1.0,
chunked_transfer1.5.0, httpdate1.0.3 and log0.4.35. No system packages installed.
Node18.19.1, benchmark Chromium131.0.6778.33 and xvfb were already present.
Setup now detects missing Node and installs with exact commands `apt-get update`
and `apt-get install -y --no-install-recommends nodejs`; requires Node>=18.
Do not replace benchmark Chromium with Ubuntu snap Chromium. Existing musl exact
reinstall commands above remain applicable. Headless version/run/batch retain
runtime-free offline static-musl isolation; UI needs a browser, unattended UI
also Node. Embedded assets/driver verified in static distribution UI smoke.

Real browser smoke uses the shared engine to tick10; screenshots to100 and real
CDP Page.captureScreenshot1440x900. Parent45/105s deadlines and Node40/100s,
child/profile guards and bounded server output keep returned errors finite.
Initial compile closure-lifetime error, initial browser profile shutdown race,
and CDP early-exit EPIPE were found and fixed; exact failures and successful
reruns are retained in TASK-023 handoffs/logs. Initial full ./test.sh passes
216 Rust tests plus14 Python tests and Node camera suite. Final expanded suite
and actual final evidence are recorded below and in implementation JSON.

Throughput on AMD Ryzen5 7500F6-core/12-thread Linux x86_64 container, Rust1.100
release, Chromium1311440x900 headless: mixed initial1000 and sustained1000 plants
each rendered51 distinct simulation frames/5.2s (~9.81/s), p95 gaps~116.8ms.
Stable fixture checks every measured frame remains1000. CDP drag/wheel/Fit and
Canvas polar RGB probe pass; explicit-config UI tick10/100 hashes equal headless.
Screenshot opened/inspected: real world/legend/navigation/footer visible at100;
baseline herbivores extinct naturally, legend remains. Exact commands, measures,
artifacts and limitations: TASK-023 implementation handoffs and target/task023-*.
No fresh-OS/minimum-Rust or universal frame-rate guarantee. Large worlds/history
can exhaust memory; stacked markers occlude at distant zoom; slow clients can
occupy bounded response workers. SIGKILL/host failure may leave profiles/children.
No commits/remotes/protected states modified; harness owns review/transitions.

Final TASK-023 verification: `./test.sh > target/task023-full-final.log 2>&1`
exit0:126 unit+89 integration+1 rustdoc=216 Rust,15 Python tests, plus Node camera
assertion suite,0 failures/ignored/skips. Includes final empty/stacked1x1 browser
cases, ordinary loopback lifecycle, malformed protocol/options and missing-browser
cleanup, actual CDP pointer/wheel/Fit/palette, sustained1000 performance, explicit
UI/headless10/100 hash parity and real screenshot dimensions. Host/musl/setup twice/
build/static ELF/copied-empty-root headless/batch/checkpoint remain passing.
`timeout 60s xvfb-run -a ./evosim ui --smoke-test` and
`timeout 120s xvfb-run -a ./evosim ui --screenshots target/task023-shots` exit0,
actual10/100 ticks and rendered1440x900 screenshot. Final full-run p95 frame gaps
117.0ms mixed/116.9ms sustained1000; both51 frames/5.2s. Format/whitespace and
UTF-8 handoff/scope/no-remotes validator pass. Structured JSON and detailed phase
memory: tasks/TASK-023/handoffs/implement-cycle1.json and .md. No acceptance gaps
or blockers identified; REVIEW remains harness-owned.


TASK-023 REVIEW cycle 1: PASS; all seven world-view acceptance criteria met, no
gaps. Independent committed-diff/source review and ./test.sh pass216 Rust tests
(126 unit,89 integration,1 rustdoc),15 Python and Node camera assertions, none
failed/ignored/skipped. Includes host/musl/setup/build/static ELF and copied empty-
root headless regressions. Real virtual-display smoke10/screenshots100 exit0;
1440x900 main.png opened and inspected. Mixed initial1000 and sustained1000 each
render51 distinct frames/5.2s (~9.81/s), p95 gaps117.0/117.2ms locally. Real drag/
wheel/Fit/palette and explicit-config UI/CLI hashes pass. Independent review probes
also match default UI/CLI hashes10/100, fault-inject stalled Chromium startup
(status2 after40.079s, profile removed), static UI smoke and early browser failure.
Formatting/whitespace and review artifact scope/schema validation pass. Detailed
evidence: tasks/TASK-023/handoffs/review-cycle1.md/.json and review-checks.py.
No product/architecture changes, dependencies installed, commits or transitions.
Existing exact prerequisite reinstall commands remain applicable. Resource limits,
stack occlusion, slow-client saturation and abrupt-host-kill cleanup limits remain
documented; no fresh-OS/minimum-Rust/universal frame-rate claim. Controls/inspection
remain TASK-024 and editing/charts TASK-025. Harness owns completion/next assignment.

TASK-024 PLAN cycle 1: documentation-only ordered plan written; implementation
unstarted. Dependency TASK-020/022/023 reviews PASS, no acceptance gaps or previous
TASK-024 handoffs. Applied PLAN skill; initial worktree clean and no remotes.
ADR-002 refinement chooses visible buttons, Slow5/Normal20/Fast60, Step=Pause+1,
Reset=current effective config/seed (including loaded config), paused reset/load,
and UI-only epoch/revision ordering. Inspector follows stable ID with same-cell
chooser, all12 named traits/exact u16 loci/parents and cached last-seen death panel.
Browser checkpoint .evo download/file upload reuses existing codec; bounded ingress
workers keep socket reads out of engine owner; explicit64MiB UI upload limit.
No feature code, authoritative field, core/config/default/dependency or canonical/
checkpoint/model schema change. Exact interfaces, ordered paths, acceptance matrix,
protocol/resource risks and fresh-context steps: TASK-024 plan-cycle1.md and JSON.

Actual baseline commands:
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib ui_server --test checkpoint --test metrics --test state_hash`: exit0;1 UI DTO test passes; integration binaries accidentally filtered by ui_server (7 tests not executed).
- Corrected `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test metrics --test state_hash`: exit0;7 tests pass (3 checkpoint,2 metrics,2 hash),0 failed/ignored/filtered.
Only existing behavior tested; no new control/browser feature success claimed.
Final planning artifact validator command/result retained in handoffs. No system
packages installed; existing exact reinstall commands remain `apt-get update`,
`apt-get install -y --no-install-recommends musl-tools`,
`rustup target add x86_64-unknown-linux-musl`, and for missing Node
`apt-get install -y --no-install-recommends nodejs` after apt update. Benchmark
Chromium wrapper remains required for real-browser checks. Harness owns commits,
implementation assignment and phase transitions; no next phase started.

TASK-024 final PLAN artifact validation: exit0; UTF-8 required JSON/schema, exact
five documentation paths, protected scope, no remotes and git diff --check pass.
No implementation or browser acceptance tests run in this phase.


TASK-024 IMPLEMENT cycle 1: private ui_server/session.rs owns Simulation plus
observational ready/running/Slow5-Normal20-Fast60 speed, explicit-duration scheduler,
epoch/revision and one selected live/terminal inspector. Step pauses+one tick;
reset/current effective config and checkpoint load pause and replace cached world.
Snapshot schema2 exposes exact decimal identities/ticks and all12 named traits/
u16 alleles/parents. Browser uses buttons (no new shortcuts), stable-ID complete
cell chooser, drag threshold, selected-cell highlight, independently scrollable
inspector preserving scroll, last-observed death data and matching epoch/revision
rendering. Browser .evo downloads and file-input uploads reuse persistence bytes.
Two bounded ingress workers isolate socket reads and reject stale completion;
64MiB UI upload cap; synchronous codec/cache work can delay owner responsiveness.
No core/authoritative/config/default/ecology/dependency/canonical/checkpoint schema
change; all application fields remain outside hash/codec. docs/UI.md records final
routes/semantics/precision/resource bounds. No system dependency installed; existing
STATE prerequisite install commands remain binding. Exact commands/results and
phase decisions/limits live in TASK-024 implementation handoffs. Harness owns
review, commits, state and transition; no other phase started.


Final TASK-024 verification: `./test.sh > target/task024-full-isolated.log 2>&1`
exit0:131 unit+89 integration+1 rustdoc=221 Rust,19 Python and Node camera checks;
0 failed/ignored/skipped. Includes all final control/inspector/files/epoch/mobile
assets plus host/static-musl/setup twice/build/ELF/copied-empty-root regressions.
Both initial/sustained1000 fixtures render51 frames/5.2s (~9.81/s); no universal
rate claim. Run the full suite without other browser commands: existing global
profile-inventory assertions require isolation. Earlier failed attempts and fixes
are recorded honestly in implementation handoffs. Virtual-display smoke10 and
screenshots100 exit0; actual1440x900 main.png and inspector.png opened/inspected.
Final UTF-8 handoff/inventory/scope/no-remotes/format checks recorded in JSON. No
known acceptance gaps. No packages installed or phase transition/commit performed.


TASK-024 REVIEW cycle 1: PASS; all eight acceptance criteria independently
verified, no gaps. Committed diff1311015..fd42b6c and private session/server/browser
code reviewed. ./test.sh exit0:221 Rust (131 unit+89 integration+1 rustdoc),19 Python
and Node camera assertions, none failed/ignored/skipped. Actual browser controls,
all-kind selection, stable live/dead inspector (#9 died1100), real download/file
input, CLI continuation bytes, invalid-load rollback/epochs/ingress and visible
tick/counts pass. Additional display-free six UI tests and task-local independent
HTTP probe (50 empty-world steps,three speeds,three byte-identical resets) pass.
Separate xvfb smoke10/screenshots100 exit0; main/inspector PNGs1440x900 opened and
inspected. Both1000 fixtures51 frames/5.2s,p95 gaps116.8/116.9ms locally. Format,
JS syntax,whitespace and review handoff/schema/scope checks pass. Evidence:
tasks/TASK-024/handoffs/review-cycle1.md/.json and review-probes.py. No product/
architecture/ADR changes or packages installed; existing reinstall commands apply.
Documented64MiB UI upload cap,large-state memory/codec latency,slow-client capacity
and browser-owned disk completion remain. No fresh OS/minimum-Rust/universal rate
claim. Harness owns completion/commits/transitions; no other phase started.

TASK-025 PLAN cycle1: documentation-only ordered experiment editor/chart plan
prepared in tasks/TASK-025/handoffs/plan-cycle1.md/.json and ADR-002 refinement.
Dependencies TASK-003/020/021/024 REVIEW PASS, no acceptance gaps or prior current-
task handoffs. Initial tree clean/no remotes. Reuse all3 Config presets and all21
numeric leaves; exact browser string-token drafts/raw Rust validation preserve
arbitrary seeds and integer/float round trips. New-world Start validates/builds
before swap, pauses at0; import/export affect draft only. Field/group errors reuse
ConfigError paths. Bounded ingress gains JSON operations with1MiB UI transport cap.
Five own-Canvas charts cover population, cumulative births/deaths, living species,
selectable mean and current selectable histogram. UI-only2048-point10-tick history
plus current, cached metrics and20-bin/all12-trait distributions remain outside
Simulation/hash/checkpoint. No new simulation/config/default/schema/dependency.
UI wire schema3/chart_schema1 are private application versions. Pure Node and Rust/
HTTP tests plus real browser/download/import/live charts/screenshots are planned.
No feature code or next phase started; harness owns commits and transitions.

No packages installed or system dependency added in PLAN. Existing exact setup
reinstall commands remain: `apt-get update`, then
`apt-get install -y --no-install-recommends musl-tools`,
`rustup target add x86_64-unknown-linux-musl`, and if Node is missing
`apt-get install -y --no-install-recommends nodejs` after apt update. Retain supplied
Chromium wrapper; do not install Ubuntu snap Chromium. Baseline existing tests and
final plan artifact checks are recorded in PLAN JSON; no new feature/full-suite/
browser acceptance success claimed. Main risks: raw-number precision, stale draft/
epoch responses, chart snapshot/serialization cost, resource bounds and readable
layout. Full suite must run without concurrent browser tests due global profile
inventory assertions. Detailed acceptance oracles and fresh-context steps are in
adjacent planning Markdown. No blockers or review gaps identified.

TASK-025 IMPLEMENT cycle1: experiment editor and five live own-Canvas charts
implemented in the private UI adapter. All21 numeric leaves editable with existing
presets/validator, adjacent field/group errors, raw JSON import/export and exact
seed/u64/f64 tokens. Start builds replacement/cache/history before swap, pauses
at0 and retains speed; reset/load use active effective config. Drafts remain
independent, with explicit Use active configuration and request generation/epoch
guards. Operation-tagged two-worker ingress adds1MiB JSON bodies; checkpoint cap
remains64MiB. UI-only history stores2048 ten-tick snapshots plus exact current,
with per-tick cached all12-trait20-bin histograms. Metrics and immutable living
readers supply all values. Reset/start/load restart window at actual tick. Private
UI schema3/chart_schema1 only; no core/default/ecology/hash/checkpoint/config/CLI
metrics schema or dependency change. docs/UI.md and ADR-002 describe semantics,
precision/costs and implementation refinements (private Value DTOs, browser-owned
field descriptors). No packages installed. Existing exact reinstall commands:
`apt-get update`, `apt-get install -y --no-install-recommends musl-tools`,
`rustup target add x86_64-unknown-linux-musl`, and if Node missing,
`apt-get install -y --no-install-recommends nodejs` after apt update. Keep provided
Chromium wrapper. No commits, remotes, delegation or phase transitions.

Initial checks found/fixed test-only usize/u128 comparison and mutable-frame borrow
errors; a history eviction oracle expected40 instead of correct30 and was fixed.
Display-free11 UI tests and three actual HTTP/browser experiment tests pass at the
first targeted stage. Initial full suite passed all Rust and20/22 Python tests,
but existing map navigation and screenshot selection failed because chart canvases
preceded map in DOM. Fixed product DOM order, explicit #world automation selector
and ignored hidden zero-size map resize; tests remain intact. Final verification
results and acceptance evidence will be appended below and retained in task-local
implementation handoffs. Browser suites must remain isolated from independent
smoke/screenshots due global profile-inventory checks.

Additional TASK-025 correction: second full run passed226 Rust/21 Python but new
chart Step check timed out after delayed Start catalog refresh switched back to
World. Fixed navigation ordering (World switch before refresh); targeted three
experiment tests pass. Deterministic held-catalog and held-validation reply tests
now protect navigation/draft ordering; error focus waits for input unlock and
explicit active refresh guards concurrent edits. Initial failures retained in
logs/handoff. Final isolated run pending below; no remaining feature blocker.

Final TASK-025 verification: `./test.sh > target/task025-full-final.log 2>&1`
exit0:136 unit+89 integration+1 rustdoc=226 Rust,22 Python and all three Node
camera/configuration/chart scripts;0 failed/ignored/skipped. Includes final focus,
held validation/catalog response regressions, HTTP overflow/rollback, browser file
round trip/live charts and exact CLI checkpoint parity at tick7. Existing1000
fixtures both51 frames/5.2s (~9.81/s), p95 gaps116.8/117.2ms locally. Host/static-
musl/setup twice/build/ELF/copied empty-root tests pass. Separate xvfb smoke10 and
screenshots100 succeed;1440x900 main/charts/inspector PNGs under target/task025-shots,
main/charts opened and inspected (all five labelled cards readable). Formatting,
JS syntax and whitespace checks pass. Required UTF-8 JSON handoff and local
artifact validator: tasks/TASK-025/handoffs/implement-cycle1.json and
validate-implement-cycle1.py. No known acceptance gaps; risks documented in UI.md
and handoff. Harness owns REVIEW assignment, commits, states and transitions.

TASK-025 REVIEW cycle1: PASS; all seven must-have criteria verified without product
changes. Independent full `./test.sh > target/task025-review-full.log 2>&1` exits0:
226 Rust (136 unit+89 integration+1 rustdoc),22 Python and three Node scripts pass;
no failed/ignored/skipped tests. Explicit no-display11 UI tests, pure Node logic,
and retained review-probes.py pass: all presets start,36 trait/kind histograms and
means independently reconstructed from inspectors, empty1x1 world through37 ticks,
exact sample schedule and repeated-poll purity. Actual browser tests cover adjacent
validation, JSON download/file-input round trip, stale replies, live charts and
CLI checkpoint parity. Fresh xvfb smoke10/screenshots100 exit0; real1440x900 main,
charts,inspector PNGs at target/task025-review-shots, main/charts visually inspected;
all five plots labelled/legended, no screenshot gap. Format/JS syntax/whitespace,
protected/core/dependency scope and no-remotes checks pass. Short1000-organism
fixtures51 frames/5.2s each; no maximum-history throughput claim. Full-history
serialization cost, large allocations/synchronous work and approximate huge y
plotting remain documented limitations. No package/system dependency installed.
Exact evidence/commands/risks: tasks/TASK-025/handoffs/review-cycle1.md and .json.
Harness owns commits, task state and transitions; no other phase started.

TASK-026 PLAN cycle1: documentation-only performance plan and ADR-019 prepared;
no optimization implemented, profiler installed/run or phase transition. Existing
dependency TASK-010/018/019/021 reviews PASS without gaps; no prior task handoffs.
Plan: public-API release example, fixed128x48 seed42 initial4600/240/40,100 untimed
warm-up+1000 measured ticks/five independent repeats, assert >=2000 each tick;
short64x48 mixed window supplements. Exploratory inherited-release CLI probes
show primary ticks100..1100 total2303..5081 (final2303 plants,no animals), but their
whole1100-tick695.238/s includes warm-up and concurrent test load: not formal
before data or target evidence. Exact inputs/commands/hashes/rejected fixtures
are in tasks/TASK-026/handoffs/plan-cycle1.md. docs/PERFORMANCE.md is explicitly
pending formal before/after/profile measurements in IMPLEMENT.

Candidates require profile confirmation: repeated identical longitude climate in
resource regeneration, then optional direct spatial kind-existence test for plant
establishment. Preserve exact float operation tree, row-major updates, RNG/actor
order/defaults and canonical/checkpoint bits; no new authoritative/cache field.
Baseline binary/checkpoints retained before edits support old/new differential,
not merely new/new replay. Plan includes loose10/s explicit release guard and full
isolated suite. Architecture/ADR-019 and task-local plan contain ordered paths,
interfaces, acceptance matrix, resource limits and implementation time budget.

No system dependencies installed in PLAN. perf and valgrind not found. Proposed
IMPLEMENT-only profiling dependency if needed: `apt-get update` then
`apt-get install -y --no-install-recommends valgrind`; record actual install/version
and reinstall when missing. Existing setup/musl/Node commands above remain binding.
Detected AMD Ryzen5 7500F6 cores/12 threads, rustc/cargo1.100.0. No universal
throughput, formal profile, fresh-OS or optimization result claimed. Initial Git
worktree clean/no remotes; protected files/task states/commits untouched. Baseline
test and final planning-artifact check outcomes are retained in PLAN JSON.

TASK-026 IMPLEMENT cycle1 dependency: installed development-only Callgrind via
`apt-get update` then `apt-get install -y --no-install-recommends valgrind`.
Both succeeded; Valgrind3.22.0. Reinstall with those exact commands if missing
in a later phase. Not required by setup.sh, headless/UI runtime or test.sh.
No Cargo dependency added. Detailed final evidence follows in task handoff/report.


TASK-026 IMPLEMENT cycle1: examples/performance_bench.rs and shared external
measurement helper use public Simulation APIs, fixed scenarios/performance.json,
100 warm-up+1000 measured ticks/five fresh repeats, with all-tick>=2000 floor.
Supplementary short mixed window and raw effective-config/counter/hash reports
are observational. Callgrind identified repeated latitude-only climate evaluation
in resources; private regenerate_rows streams one current_at precipitation per
row, preserving original per-cell float expression and row-major order with O(1)
workspace. No persistent cache, field, public core API, dependency, ecology,
default, RNG-order, canonical/model/checkpoint schema or inventory change.
Primary median751.693→847.955 ticks/s (+12.8%,population2303..5081); supplementary
1027.076→1095.760 (+6.7%). Mostly-plant primary is not sustained coexistence.
10/s release-only catastrophic slowdown guard is explicitly invoked by test.sh.
Bit-level resource oracles and30 exact baseline states/checkpoints plus20 cross-
version continuation checks pass. Trait conversion/ordered-map lookup remain
profiled costs; optional occupancy optimization was not implemented. Hardware,
profiling commands, precision/workload limits and exact suite evidence:
docs/PERFORMANCE.md,ADR-019 and TASK-026 implementation handoffs. All ADR-015/018
state duties remain unchanged; harness owns review/commits/transitions.

TASK-026 final validation: isolated ./test.sh exit0,228 Rust+22 Python tests and
all3 Node scripts pass,including real browsers/host/static-musl empty-root runs.
One debug timing-test ignore is explicitly executed in release:847.444 ticks/s,
threshold10/s,population minimum2303,tick1100. Targeted155 biology/spatial+17
checkpoint/CLI tests pass;30 old/new exact checkpoint/result pairs+20 bidirectional
continuations pass. Full commands/counts/raw evidence in TASK-026 implement-cycle1
handoffs and docs/PERFORMANCE.md. No existing test failure/skip or known acceptance
gap; no phase transition or manual commit. Final format/scope validation recorded
in structured handoff; harness owns review and completion.

TASK-026 REVIEW cycle1: PASS; all six acceptance criteria independently verified.
Full ./test.sh exit0:228 Rust+22 Python and3 Node scripts pass; one debug timing
guard ignore explicitly runs in release (829.356 ticks/s,minimum2303,tick1100).
Isolated primary baseline752.635→844.983 ticks/s (+12.27%),population2303..5081;
mixed1025.888→1100.222 (+7.25%).30 exact old/new state/checkpoint comparisons
and20 bidirectional continuations independently pass. Source/profile/report checks
confirm unchanged arithmetic/order/RNG/state/schema and documented resource-row
optimization. No gaps,product edits,new dependencies or installs. Mostly-plant
workload is not coexistence evidence; future longitude climate must revise row
reuse and bit tests. Evidence/commands: TASK-026 review-cycle1.md/.json and
review-measurements.json; review-checks.py validates retained artifacts. Harness
owns commits,task completion and transitions; no other phase started.


TASK-027 PLAN cycle1: documentation-only experiment plan and ADR-020. No ecology,
default, config, canonical/checkpoint layout or dependency change. Mandatory fresh
fixed-only batch baseline seeds0..9/10000 plus external per-tick observer must
precede written diagnosis and first ecological edit. Batch samples100-tick spacing
so exact extinction cannot be inferred from it. Candidate local carnivore satiety
reads only own existing energy after upkeep; thresholds750 then500, optional shared
cooldown40. At most three changed candidates; tune0..4, freeze before unseen100..104
10000-tick validation and paired preserved baseline. Failed trials retained;
no improvement/coexistence promised. If policy retained, hunting model2 encoder/
decoder identity rejects old-model checkpoints; no new state/layout. Full regression
and TASK-026 final-default benchmarks required. Detailed paths/commands/time budget:
TASK-027 plan-cycle1.md; docs/BALANCE.md remains explicitly unmeasured scaffold.
No packages installed; existing exact dependency reinstall commands above apply.
Harness retains phase transitions/commits; no IMPLEMENT work started.


TASK-027 IMPLEMENT cycle1: completed fresh fixed-only batch baseline seeds0..9
10000 before biology edits, external exact per-tick observer matched every hash/
final/totals, and timestamped diagnosis preceded first source change. Herbivores
first extinct21..27 (median24), all120 deaths predation,no births. T1 reserve750
and T2 reserve500 both measured2000 then10000 on0..4; median313,worst312 tie,
retained first750, rejected500; optional cooldown trial omitted. Selection frozen
before held-out100..104: paired baseline median25 vs chosen316 (313..320), but
plants now disappear first and all three kinds ultimately vanish. Durable
coexistence NOT reached. All failures/raw curves/configs/trial ledger retained
under tasks/TASK-027/evidence; docs/BALANCE.md explains measurement and tradeoff.

Production change is only pure private hungry predicate and gate after carnivore
upkeep/liveness; satiated actors skip action/RNG but age/pay upkeep/reproduce.
No global counts,new state,spawn path,energy source,configuration key,numeric
default or dependency. Hunting identity2 shared by writer/reader intentionally
rejects old model1 checkpoints; schema1/envelope1 and ADR-015/018 inventory unchanged.
Empty-state golden independently rehashed after proving only model identity differs.
Private hunting fixtures explicitly start hungry; saturated cases assert resting
and pure nutrition endpoints retain conservation. Founder expiry/lifecycle fixtures
disable animal reproduction to preserve their original purpose after improved
prey survival. New tests cover satiety boundary/RNG/aging/upkeep and resting-parent/
hungry-child continuation plus checksum-valid old-model rejection.

Original TASK-026 primary population floor fails tick685,total1998 (minimum564
over1100); all original data/failure retained. Replacement attempts120/20 herbs
also fail; chosen primary4600/0/40,128x48 keeps100+1000,five repeats,>=2000 floor
and10/s guard. Plant-focused replacement is NOT directly comparable to historical
primary; original mixed input/nine repeats unchanged. Isolated medians857.619
replacement (min2304),671.812 mixed (min2559),both>=100/s. Mixed38.7% slower than
TASK-026 with more active consumers; see BALANCE/PERFORMANCE and raw reports.
No new system packages installed; existing exact install commands earlier in this
file remain the prerequisites if missing. Full verification outcome appended below
and exact commands/limitations retained in TASK-027 implementation handoff.
Harness owns review/commits/stage transitions; none performed by implementation.

TASK-027 final verification: ./test.sh exit0,232 Rust+24 Python+3 Node scripts
pass,including real browser,headless,setup/static-musl distribution checks. One
debug timing guard ignore explicitly runs in release:857.001 ticks/s,min2304,
tick1100. Initial targeted3 and first-suite lifecycle failures were fixture/golden
assumptions, corrected without dropping assertions; failure logs retained alongside
success logs in task evidence/test-logs. Evidence validator,fmt and whitespace pass.
Final current-build batch matches frozen chosen final/totals/series/hash on all
five held-out seeds. No remaining acceptance gap known; long coexistence remains
unachieved and old-model checkpoints deliberately incompatible. Detailed handoff:
tasks/TASK-027/handoffs/implement-cycle1.json and .md.


TASK-027 REVIEW cycle1: PASS; all eight acceptance points independently verified.
Ten verified preserved-baseline and five current held-out10000-tick batch replays
match exact final/totals/series/hashes;11 observer directories validate all per-tick
accounting/causes/extinctions and experiment seed/digest records. Local post-upkeep
own-energy gate preserves paid births/upkeep/finite life; hunting2 compatibility
is explicit. Full suite rerun passes232 Rust+24 Python+3 Node scripts, including
release guard/browser/static packaging. Initial full run had one30-second browser
readiness timeout; isolated5-test UI rerun and complete rerun pass without edits.
Logs retained in TASK-027 handoffs. Isolated primary858.892/mixed673.454 ticks/s,
minimum2304/2559 organisms; matches recorded biological data. Original primary
floor failure and plant-focused replacement remain disclosed; no direct primary
speed comparison. Held-out first-zero median25→316 is delay only: chosen worlds
all empty eventually. Review handoff/check script/measurements preserve evidence;
no product/dependency/schema/doc-architecture change,package install or commit.

TASK-028 PLAN cycle1: documentation-only reliability/delivery plan prepared in
 tasks/TASK-028/handoffs/plan-cycle1.md/.json. Required files verified first;
workspace PLAN skill applied. Dependency TASK-018/021/022/025/026/027 reviews all
PASS with no gaps; no previous TASK-028 handoffs. Initial tree clean/no remotes.
No implementation, demo selection, formal10k runs, full suite or delivery claim.

Plan retains engine/config/defaults/model2/schema1/checkpoint1 and current ADRs.
Add public-API randomized64-seed/config corpus plus8 long cases, short contract
probes and external Python stdlib evidence runner; reuse exact balance observer
and static empty-root packaging tests. Bound four parameter-only demo candidates
on0/1/2, freeze before formal42/43/44; run both fixed-only and demo10000 ticks
for all three seeds, validate observer hashes/counts against CLI, retain exact
coexistence/censoring and whole-process deadline evidence. Complete contract matrix
in docs/VERIFICATION.md, every PROJECT subrequirement in docs/SELF_AUDIT.md, README
installation/config/run/batch/UI/demo/results and explicit known limitations.
No new feature or ecology/default tuning; only defects uncovered by checks may
be repaired with regression evidence. Preserve browser timeout failures, old-model
checkpoint incompatibility, poor coexistence and plant-focused performance caveat.
Final ./test.sh must run isolated from other browsers/timings; reserve handoff time.

Actual baseline command:
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test config --test topology --test checkpoint_cli --test run_cli --test batch_cli > /workspace/target/task028-plan-baseline.log 2>&1`
exit0:27 existing tests pass (8 config,7 topology,2 checkpoint CLI,5 run CLI,5 batch
CLI), no failed/ignored/filtered. No new acceptance tests run. Tool probe found
chromium/node/musl-gcc/readelf/chroot. No system package installed or dependency
added; existing setup exact reinstall commands above remain applicable. Final
planning handoff/schema/scope/whitespace checks recorded in PLAN JSON. Harness
owns commits, task state and all phase transitions; no next phase started.

TASK-028 IMPLEMENT cycle1: final delivery reliability and evidence are implemented.
No engine, ecology/default, public API, Cargo dependency, state/hash/checkpoint/
hunting model, UI feature or authoritative inventory change. tests/reliability.rs
uses public immutable APIs plus full engine equality for72 distinct seeds/configs,
including8x2200 ticks and16 midpoint checkpoint continuations. Independent geometry,
accounting, vital/resource/climate, species/lineage and absorbing-zero oracles run
at29838 completed states; final observed97353 moving animal ticks,3109 births,
4240 deaths. tests/test_reliability.py adds exact-observer boundary/corruption
fixtures and network-denied static runtime with EPERM negative control.

External tools/release_verify.py records commands/provenance and validates long
CLI results against the unchanged balance_report observer, every contiguous tick
and all counters/hashes. Four predeclared inputs measured on0/1/2; D3 selected by
median/minimum criterion, frozen before42/43/44 as scenarios/demo.json (64x48,
2000/60/8,regeneration4,cooldown300). Formal fixed-only first zeros315/315/310;
demo1111/1113/1112. Every one of18 trial/formal CLI runs completes10000 ticks;
all formal worlds end empty. Positive completed ticks are F-1, not F. No durable
coexistence or controlled throughput claim from empty-tail timings. Minor trial/
initial-fixed timing overlap with randomized tests disclosed in VERIFICATION;
formal demo/browser/full suite isolated. All exact observer/CLI hashes match.

Final isolated ./test.sh exits0:233 Rust passed,26 Python passed,3 Node scripts
passed; intentional1 debug performance ignore explicitly passes in release,
859.515 ticks/s,min2304,tick1100. No skip/failure remains. Existing suite reruns
setup twice/build, static ELF and actual copied empty-root version/run/save/load/
batch, plus real-browser controls/config/charts/files. Separate default/demo UI
smoke/screenshots exit0 within60/120s,10/100 ticks,CLI hash parity,1440x900 main.
Full raw evidence,final source/binary digests,trial configs/results/CSV/curves and
screenshots live tasks/TASK-028/evidence; docs/VERIFICATION.md indexes each contract
clause; docs/SELF_AUDIT.md marks every PROJECT requirement and known limit.
Generation trends remain exported data/inspector only,without dedicated UI chart;
long coexistence remains partly met. README now includes final usage/demo/results.

No new system package installed; setup found existing musl target/toolchain and
Node/Chromium. Existing exact reinstall commands above remain binding. No Git
remote,commit,task-state/protected spec edit or phase transition. Implementation
handoffs retain actual command/failure/validation/deviation evidence; orchestrator
owns review and commits.


TASK-028 REVIEW cycle1: PASS, all eight acceptance criteria verified, no gaps.
Fresh isolated ./test.sh exits0:233 Rust+26 Python tests+3 Node scripts; no failure
or Python skip, explicit release guard859.573 ticks/s/min2304. Static ELF/copied
empty-chroot version/run/save/load/batch and denied-network negative control pass.
Independent checks verify293 evidence digests/current production hashes and six
fresh10000-tick exact replays on42/43/44 for fixed/demo. Independent contiguous
CSV/accounting/absorbing-zero audit reproduces first-zero315/315/310 and1111/1113/
1112. Separate host/musl contract runner and fresh actual demo100-tick screenshot
1440x900/headless hash parity pass. Production/default/schema/dependency unchanged;
no package installed, remote or commit. Review evidence and acceptance matrix:
tasks/TASK-028/handoffs/review-cycle1.md/.json and adjacent logs/measurements.
Known collapse, missing generation chart and plant-focused throughput limitations
remain openly recorded. Harness owns completion/commits/transitions.

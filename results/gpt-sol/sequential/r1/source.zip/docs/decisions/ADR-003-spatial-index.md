# ADR-003: Dense cell buckets on the toroidal grid

Status: Accepted for implementation by later tasks (TASK-001, cycle 1).

## Context

Entities occupy integer cells, can share a cell, and perceive/move across wrapping
edges. Climate/resources already require a world raster. The default 64x48 world
is small; population targets are 1,000–5,000. Queries must be deterministic even
for a 1x1 world or perception radius larger than the world.

## Alternatives

| Option | Performance and testability | Self-contained dist implications |
|---|---|---|
| Dense row-major cell buckets (chosen) | O(width*height + entities) memory; direct cell access; straightforward brute-force oracle | Pure Rust data structures, no added runtime or shared library |
| Spatial hash of occupied cells | Saves index memory on sparse enormous worlds, but hashing adds overhead and iteration-order hazards | Pure Rust possible; explicit sorting still required, no external runtime |
| Scan every organism | Very simple oracle, O(entities) per query and potentially quadratic tick work | No added dependency; useful as a test reference |
| Quadtree | Useful for continuous sparse coordinates; rebalancing/wrapped split queries add complexity for a raster | Pure Rust possible but extra implementation/dependency burden to audit |

## Decision

Use a flat array indexed y*width+x, each bucket holding stable organism IDs.
Organism storage owns position and life state; buckets are a derived cache.
IDs are monotonic and never memory addresses. Insert/move/remove update buckets
immediately, with dead IDs removed or filtered before any query returns them.
Sort query results by ID; action target selection sorts by distance then ID.
Bucket insertion or swap-removal order must not affect biology.

Normalize each integer coordinate with Euclidean remainder by its positive axis
length, including negative coordinates. Shortest axis separation is
min(abs(a-b), size-abs(a-b)) for normalized positions. Perception uses toroidal
Chebyshev distance max(dx,dy), inclusive radius; adjacency includes eight neighbors
but excludes the origin as a movement destination. Degenerate axes can collapse
neighbors, so deduplicate destinations. For an even-axis exact half-world direction
tie choose positive. Speed grants a budget of individual adjacent-cell steps;
never teleport to a perceived target. Each step updates the index.

For a radius r>=0, enumerate the unique wrapped x coordinates in the radius and
the unique wrapped y coordinates, then their Cartesian product. Each axis visits
at most min(size,2*r+1) cells. When the radius covers an axis, enumerate that whole
axis directly; avoid overflowing 2*r+1 or iterating huge unwrapped ranges. Each
cell appears once, including radius zero, dimensions one and world-spanning radii.
Query cost is O(unique visited cells + candidates), plus deterministic sorting
O(candidates log candidates). Worst-case full-world lookup is O(cells + entities)
before sorting, not constant time; overcrowded cells remain expensive.

## Consequences

The index matches cell movement/climate locality and is easy to rebuild in ID
order after checkpoint load without RNG use. Dense allocation scales with world
area even when empty. Validate checked dimensions/allocation sizes and return a
clear configuration error for unrepresentable allocation, rather than overflowing.
Large sparse worlds may later justify another index behind the same query API;
that change must preserve query semantics and determinism. The representation
adds no external packaging dependency to the static Rust executable.

## Verification strategy

Later property tests compare indexed queries against a brute-force Chebyshev
oracle in seeded random worlds. Cover 1x1, 1xN, non-square worlds, corners/seams,
negative coordinates many wraps away, radius zero, radii exceeding dimensions,
even half-axis ties, dense buckets, duplicate prevention, immediate movement/death
updates and index rebuild after load. Benchmark local and full-world queries at
representative densities. TASK-001 checks the written design, not an implementation.

## TASK-004 PLAN cycle 1: geometry representation refinement

Planned pure std-only topology module: validated positive usize dimensions with
checked area, private usize Cell coordinates, signed i128 coordinate inputs and
shortest Displacement components. This matches configuration dimensions without
narrowing and permits wrapping the full i128 domain with Euclidean remainder,
including its minimum. Cell inputs are normalized to the receiving topology.
Chebyshev and positive half-axis ties above remain binding.

Radius queries will use an O(1)-memory lazy Cartesian iterator, capped per axis.
If radius>=axis_size/2, visit the full axis ascending from zero; otherwise visit
2*radius+1 wrapped coordinates starting at center-radius. Iterate y outer/x inner.
Branching before doubling prevents huge-radius overflow; degenerate axes have no
duplicates. These choices add no dependency or distribution cost. Finite exhaustive
oracle tests will cover seams, extreme inputs, tie rules, tiny/non-square worlds,
query order and usize::MAX radii. Full API and acceptance matrix are in
TASK-004 plan-cycle1.md. Geometry is not implemented yet; organism buckets and
spatial speed measurements remain TASK-010 work.

## TASK-004 IMPLEMENT cycle 1: geometry evidence

The representation/API refinement above is implemented in src/topology.rs and
exported by src/lib.rs. No deviation from the planned geometry semantics.
Seven public integration tests pass, including exhaustive small-world independent
oracles, maximum usize dimensions without allocation, full i128 input extremes,
all edges/corners, positive half ties, 1x1/1xN worlds, foreign-world cells and
usize::MAX radius. The lazy full-world prefix test demonstrates no eager area
allocation. A runnable rustdoc example passes. ./test.sh also preserves static
musl ELF and copied-empty-root version checks. No new dependencies or system
packages; spatial buckets, candidate lookup and throughput remain TASK-010 work.
See tasks/TASK-004/handoffs/implement-cycle1.md for exact commands and limitations.

## TASK-010 PLAN cycle 1: population-owned index refinement

Planned, not implemented: private src/spatial.rs stores dense row-major buckets
of (OrganismId, Kind), sorted by ID. Population owns this derived cache beside
its authoritative BTreeMap, so founder/newborn insertion, immediate kill and
one-cell relocation update records and buckets through one owner. Metadata
avoids per-candidate map lookups; no reverse directory is necessary when the
owner supplies the old cell. Sorted bucket insert/remove costs O(occupancy) but
makes rebuild/PartialEq independent of mutation history. No new dependency.

Public Population::nearby(Cell, usize, Option<Kind>) returns ascending IDs,
including center occupants, delegating to unique Topology::cells_within and
sorting matching occupants. Query accepts huge radii and normalizes foreign
Cells. No self exclusion, target selection or biological action is implied.
Query work is O(visited cells + candidates + matches log matches), with O(matches)
output and O(area + living) cache storage. Whole-world queries may lose to scans.
Crate-private move_one_step normalizes, validates liveness/adjacency (same-cell
no-op), then updates both representations immediately; ecology later chooses
moves and costs. No public spawn/teleport or behavioral search is added.

Initial dense bucket allocation is checked/fallible, reported through Population
initialization errors; no arbitrary ecological/world cap. Overcommit and later
allocations retain existing process-memory limits. Rebuild from authoritative
living records in ID order uses no RNG; future checkpoint/hash excludes cache.
Plan tests actual lifecycle synchronization, >=4096 randomized brute-force query
comparisons including tiny worlds/huge radii, order/rebuild/purity and errors.
A std-only release example benchmarks 2000 founders on 64x48 with radius 4
unfiltered declared primary; also reports radii 1/8/full-world and kind filtering.
Median timings/hardware and unfavorable cases must be recorded in docs/SPATIAL.md
in IMPLEMENT. No measurements or speed claims exist in this PLAN. Detailed API,
ordered work, benchmark fairness and acceptance matrix: TASK-010 plan-cycle1.md.


## TASK-010 IMPLEMENT cycle 1: index evidence

The population-owned refinement is implemented without representation/API changes.
src/spatial.rs is crate-private; sorted ID/Kind buckets are updated on every
production living insert/remove and the sole position mutation. Founder/newborn
insertion, immediate death and adjacency-checked internal movement all preserve
the derived cache. No search-driven ecology or additional RNG consumption.
Try-reserve allocation errors propagate through initialization; overcommit/later
allocation OOM remains a process limit. Future persistence rebuilds from living
records and excludes buckets from canonical state.

Tests cover 4096 seeded random queries with actual lifecycle events and an
independent brute-force oracle, explicit edges/filters/tiny worlds/huge radii,
canonical reverse rebuilds, purity, error atomicity and real-walker visibility.
The predeclared 2000-organism radius-4 all-kind benchmark measured 1.455 ms indexed
versus 18.740 ms scan per 4096 queries (12.877x) on the disclosed local setup.
Full-world all-kind queries measured 38.268 vs 22.719 ms (0.594x), confirming the
expected limitation rather than a universal speedup. docs/SPATIAL.md records
all radii/filters, checksums, hardware, method and reproducible command. No added
crate/system dependency or whole-simulation throughput claim.

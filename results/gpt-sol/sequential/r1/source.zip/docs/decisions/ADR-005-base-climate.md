# ADR-005: Smooth periodic base climate

Status: Implemented in TASK-006 IMPLEMENT cycle 1.

## Context

Each grid cell needs static temperature, precipitation and a biome. Latitude
zones must have cold-to-hot Earth-like ordering with continuous wrapped edges,
including tiny worlds. TASK-007 owns temporal climate; organisms come later.
ADR-004 uses normalized climate traits and ADR-001 permits periodic f64 functions.

## Alternatives

| Option | Performance and testability | Distribution implications |
|---|---|---|
| Procedural periodic latitude with five bands (chosen) | O(1) construction/storage/lookup; simple seam proof and tiny-world tests; cosine cost per query | std math and existing serde_json only; static musl regression required |
| Allocated row-major periodic climate raster | O(area) initialization/storage, cheap lookup; allocation limits and cache/checkpoint distinctions need tests | No runtime needed; larger saved states if raster authoritative |
| Seeded periodic terrain/noise plus latitude | More varied geography; extra computation/RNG ordering, seam and tuning complexity | Pure Rust possible, but noise crate or algorithm adds maintenance and packaging checks |
| Linear north-to-south latitude | Cheap and familiar spherical map | No new dependencies, but opposite-temperature seam violates the requirement |

## Decision

Model version 1 uses cell-centred normalized latitude and temperature q:
d=min(y,height-1-y); v=(d as f64+0.5)/(height as f64);
q=clamp((1-cos(TAU*v))/2,0,1). This symmetric evaluation equals the periodic
cold-hot-cold cosine while guaranteeing identical paired boundary-row samples.
There is no x influence, noise, elevation or RNG consumption. Seeds share base
geography. No new configuration keys; existing climate amplitudes apply later
only to temporal climate.

Temperature equals q. Five biome ranges are [0,.10) polar, [.10,.25) tundra,
[.25,.60) temperate, [.60,.85) dry (savanna/desert), [.85,1] tropical. Warmer
band owns a threshold. Biomes are categorical labels, not continuous fields.
Precipitation interpolates knots (q,p)=(0,.15),(.10,.25),(.25,.60),(.60,.20),
(.85,.35),(1,1) using s=t*t*(3-2*t), p=p_a+(p_b-p_a)*s. Clamp outputs to [0,1].
Temperature and precipitation are normalized model units, not measured weather.
Both scalar fields are continuous with matching periodic derivatives; piecewise
precipitation interpolation has zero derivative at each knot. East-west fields
are constant. Cell-centred vertical seam samples match exactly by construction.

A torus lacks two separate geographic poles. Its two map edges join in one cold
belt, while the hot belt crosses the middle. The sequence is cold-hot-cold and
periodic rather than a sphere flattened with distinct northern/southern poles.
Small grids may sample only a subset of bands; 1x1 is tropical, height 2 temperate.
No artificial duplication or resizing to show every biome.

Implement Climate as a small immutable procedural field holding Topology;
base_at(Cell) returns a BaseClimate value and normalizes foreign cells. World
owns this field. No eager raster or new allocation failure for huge dimensions.
A read-only write_json writer exports metadata and row-major per-cell records
using existing serde_json, bounded memory, no UI or random draws. Add the command
`evosim climate --config FILE --out FILE` to inspect the same World climate.
Detailed interfaces/schema and ordered implementation are in TASK-006 plan.

## Consequences

No new dependency or system package; static build and offline operation remain
required. O(1) storage avoids allocation for any representable valid topology;
export remains O(area) time/output. Repeated cosine queries might later justify
a derived row cache, after profiling. This decision refines the prior planned
climate raster for static fields only; resources and temporal state may still
need allocation. Large usize coordinates lose resolution in f64 but remain
finite and bounded. Same-build replay is required; cross-platform bit identity
of transcendental functions is not. Biome thresholds are intentional internal
label boundaries. Ecological suitability and coexistence remain unmeasured.

Temporal climate must retain an independently queryable base and document any
new current-state storage. Persistence must version the formula and include
its dimensions/model identity or equivalent complete derived values in the
checkpoint/hash boundary; no disk schema is introduced here.

## Verification strategy

IMPLEMENT must test complete per-cell assignment and normalized bounds, known
samples and exact classification/interpolation endpoints, five-band ordering
on tall/default maps, all small dimensions and extreme no-allocation lookups.
Compare horizontal/vertical seam differences against non-wrapping neighbor maxima
with tight numerical tolerance; paired seam rows must match including biome.
Prove periodic scalar limit/derivative behavior in documentation. Export JSON
must parse with exact row-major records matching World queries. Exercise real
CLI/config/output errors and both launcher/dist export without DISPLAY. Ensure
queries/export/ticks preserve base climate and RNG. Run full regression/static
packaging suite; no performance success is assumed. Evidence remains pending.


## TASK-006 implementation evidence

The planned procedural field, World ownership, streaming JSON schema and additive
CLI are implemented without algorithm or dependency changes. Climate construction,
queries, export and ticks consume no RNG draws. Tests cover bounded assignment
on all dimensions 1..=32; seam comparisons on 1..=64 plus tall maps; five-band
ordering, known samples, threshold/knot boundaries; tiny/extreme worlds; foreign
cells; export and writer failures; CLI validation and output preservation.
Full test.sh passes 43 tests without skips, including both host and musl climate
exports, ELF inspection and empty-root version execution. Actual 64x48 map export
and exact commands/results are recorded in TASK-006 implementation handoffs.
No throughput, organism effects or temporal climate claim is made.

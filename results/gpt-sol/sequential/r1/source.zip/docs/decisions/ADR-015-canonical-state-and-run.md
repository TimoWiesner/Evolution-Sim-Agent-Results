# ADR-015: Canonical complete-state hashing and headless run boundary

Status: Implemented in TASK-019 cycle 1; review remains harness-owned.

## Context and alternatives

Contract run requires full-state hashes and reproducible output excluding wall
clock. ADR-001 selects SHA-256. Hashing result JSON omits hidden future-influencing
state; Debug formatting is unstable; serializing entire state as JSON complicates
f64 bit preservation. Choose streaming explicit canonical binary encoding and a
pure Rust sha2 dependency over hand-written cryptography or external processes.
Disk checkpoints remain TASK-022; they must preserve this same state inventory.

## Encoding decision (schema 1)

Write ASCII `EVOSIM-STATE` then u32 schema1. All integers little-endian; u8 tags,
u16 alleles, u32 model versions, u64 dimensions/coordinates/ticks/IDs and u128
counts/sequences. usize converts checked to u64. f64 uses exact to_bits u64,
including signed zero. Strings are UTF-8 preceded by u64 byte length; vectors/maps
have u64 element count. Option uses u8 0/1 then value if Some. Kind tags plant0,
herbivore1,carnivore2; death tags starvation0,injury1,predation2,oldage3,climate4.
Records ordered by stable numeric ID; arrays in documented order, stores row-major.
Do not rely on enum discriminants, Debug, JSON map order or Rust Hash machinery.

Top-level order:
1. Model identity block: fixed named ordered version1 values for scheduler,
   base climate, temporal climate, resource, genome/traits/species and ecology
   (plant physiology/reproduction, animal navigation/grazing/hunting/mating).
   Reuse existing version constants; explicitly name otherwise unversioned models
   in schema docs. Changes require deliberate version update.
2. Effective Config: normalized seed decimal string; world width,height;
   initial plant,herbivore,carnivore counts (u64); climate year_ticks then season
   temperature,season precipitation,weather amplitudes; genetics mutation rate
   (u32),max step(u16); plants capacity,regeneration,efficiency,reproduction energy,
   dispersal radius(u32); animals movement,basal,reproduction energy,cooldown.
3. Engine tick(u64), RNG version(u32) and four u64 words in state order.
4. World topology width,height; procedural Climate topology and model version
   (no raster exists); TemporalClimate effective settings in config order plus
   WeatherState version,tick,temperature offset,precipitation offset; ResourceField
   topology then all exact store bits. Procedural climate is fully specified by
   topology+model; no reconstructed/refilled resource values.
5. Population topology; next_id Option<u64>; request_sequence u128; current counts,
   totals initial,births,deaths (each plants/herbivores/carnivores u128); cause totals
   kind order then death-tag order; living map length+organisms ascending ID.
   Organism order: id,kind,species_id,x,y,age,energy,health,12 alleles (fixed length),
   ordered parent IDs (length-prefixed),generation,birth_tick,last_reproduction_tick.
6. Complete species registry ascending ID including extinct records:
   id,kind,name,12 founder alleles,parent_species,origin_tick,extinction_tick,
   living_members. Then death_records in retained order: id,kind,tick,cause.
7. Pending death and birth lengths, required zero at public completed-tick hash
   boundary; reject nonempty rather than silently omit. Public Simulation cannot
   expose a midtick. TASK-022 saves only completed ticks as well.

Derived phenotype, spatial buckets, method-local target/reservation/attempt lists,
reports, sampling interval, CLI paths, elapsed times and result buffers are absent.
All authoritative redundant counters/settings are included rather than silently
recomputed. This schema covers current fields; new fields must update encoder,
inventory/tests and compatibility versions. Hash output is 64 lowercase hex chars.
Finite SHA-256 has theoretical collisions; requirement means complete-state input
coverage with cryptographic collision resistance, not mathematical injectivity.

## Ownership and run decisions

Owners write private state through crate-private methods to a std-only canonical
encoder. persistence imports Simulation, SHA-256 and encoder, with no reverse
Simulation -> persistence dependency. Configuration can depend on primitive
encoder, never CLI/UI. No mutation/RNG draws/global clocks during encoding.
Tests can collect bytes; production streams directly into hash, avoiding a second
copy of whole state. Future checkpoint codec may reuse the encoding/inventory;
no decoder or compatibility claim is added in TASK-019.

CLI only adds run's required and optional contract flags (save/load excluded).
Additional result key state_hash_schema1 identifies this encoding. Time measurements
are outer observations around actual tick calls; zero ticks yield zero timings.
Sampling includes start/end once, default max(1,N/100). Preserve arbitrary integer
seed; seed override changes effective Config before initialization. Atomic result
publication uses a same-parent exclusive temporary file and rename, preserving
old files on returned failures. Existing nonregular output paths are errors.

## Consequences and verification

SHA dependency must compile for host/musl and preserve offline static run. Hashing
is linear in world/living/history; series storage linear in sample count. More
small owner encoders are preferable to exposing mutable state. Verify SHA vectors,
canonical golden bytes/digest, field sensitivity (including private histories and
allocators), read-only hashing, repeated CLI seeds, sampling independence, extinct
empty tails, argument/config/output failures, and copied-dist headless runs.
Exact ordered plan and acceptance matrix: TASK-019 handoffs/plan-cycle1.md.
No runtime/hash/performance success is claimed by this planning ADR.

## TASK-019 implementation refinements and evidence

Schema 1 is implemented through std-only `canonical::Encoder`, with crate-private
owner encoders on Config/ClimateConfig, Topology, Genome, Kind/DeathCause,
Organism, Climate, TemporalClimate, ResourceField, RngState, SpeciesRegistry,
Population and Simulation. No authoritative field is made public for encoding.
`persistence::state_hash` streams bytes into sha2 0.10.9; no disk codec exists.
The schema constant lives in canonical and is exposed by persistence; Simulation
never imports persistence. Topology's cached area is derived from dimensions and
excluded along with spatial buckets and derived traits. Resource stores use an
explicit u64 element length followed by row-major f64 bits. BTreeMap keys equal
the stored record IDs in valid engine state, so each ID is encoded once per record.

The fixed model block's names/order are exactly: scheduler, base climate,
temporal climate, resource, genome, traits, species, plant physiology, plant
reproduction, animal navigation, grazing, hunting, mating. All currently version1 except hunting2 (TASK-027);
existing climate/resource/genome/species constants are reused. Counts and lifetime
sequences encode as u128; JSON counts preserve arbitrary integer precision.

Frozen hash for the empty 1x1 world, seed42, tick0, all default optional settings:
`356bbf1fd2b027ef0c95915f92fdfcd0bd87f2a5aec0997a80d2c5acae49eb63`.
The test checks exact primitive bytes, published SHA-256 empty/abc vectors and an
independent Python hashlib digest over emitted canonical bytes. Owner-local
sensitivity tests sometimes construct inconsistent private records solely to
check encoding coverage; they add no production mutation API. Rebuilt spatial
buckets preserve encoding; unfinished lifecycle transactions reject hashing.

The run adapter implements only the approved flags and extra schema key. It
uses checked accumulated tick-call durations, fallible sample-vector growth and
same-parent create_new temporary publication. Injected write and rename failures
preserve an existing result and clean temporary files. There is no crash-durable
fsync guarantee or hard memory bound for huge valid runs. Normal returned failures
are status2; OS OOM termination cannot be converted to a CLI error.

Host/musl builds, real launcher replay and copied empty-root run evidence are in
TASK-019 implement handoffs. Runtime requires no new system package or display;
sha2 and its transitive crates are pinned in Cargo.lock. No checkpoint, batch,
UI or ecology/default changes are part of this implementation.


TASK-027 compatibility amendment: hunting identity is2 in both codec directions;
all other identities, STATE_SCHEMA1 and canonical layout remain unchanged. The
shared private constant prevents encode/decode drift. Old hunting1 states fail
model validation explicitly. No new authoritative field; the full inventory above
still applies. Empty tick0 golden was independently recomputed by Python after
proving the payload differs only at hunting version; evidence/golden-verification.json
and baseline/chosen-empty.evo under TASK-027 retain proof.

# ADR-018: Versioned exact-state binary checkpoints

Status: Implemented in TASK-022 cycle 1; review is harness-owned.

## Context and alternatives

ADR-015 already defines a complete canonical binary state schema and encoders.
Checkpoint loading must retain every bit needed for continuation, including
private counters and historical records. JSON owner DTOs would duplicate this
inventory and require explicit float-bit wrappers. Serde/bincode over engine
structs would couple compatibility to Rust representation and expose caches.
Choose an inverse of the existing canonical encoding, with owner-local decoders.
No new crate or system dependency is needed.

## Format and compression

Checkpoint format 1 is an uncompressed binary envelope:
ASCII `EVOSIM-CHECKPOINT` (17 bytes), u32 little-endian envelope version 1,
u64 little-endian canonical payload byte length, exactly that many bytes from
Simulation::write_canonical (including its EVOSIM-STATE magic/schema/model block),
then 32 raw SHA-256 bytes over the entire preceding envelope header and payload.
No trailing bytes are accepted. Envelope version and state schema are separate;
unknown versions/model identities fail rather than migrate silently. SHA-256
already exists in Cargo.lock; checksum detects accidental damage, not authorship.
Keep canonical schema 1 and its golden hash unchanged. Envelope data is excluded
from state_hash. Equal complete states produce identical checkpoint bytes.

Choose no compression: simple offline static builds, no additional decoder or
compression dependency, transparent exact length checks and easy corruption
fixtures. Payload grows with area, living entities and retained history. Compression
can be introduced only through an explicitly versioned format decision later.
No JSON import/export, UI save/load or historical version migration is included.

## Ownership and decoding

Extend private std-only canonical.rs with a bounded slice Decoder and inverse
fixed-width primitives. Counts/lengths are checked against remaining bytes,
minimum record size, usize representability and checked arithmetic BEFORE reserve
or iteration; use fallible reserves where available. Reject invalid option/enum
tags, invalid UTF-8, unordered/duplicate map IDs, truncated records and unused
bytes. Preserve f64 via from_bits; reject nonfinite/out-of-domain values rather
than clamp, wrap, refill or normalize authoritative data.

Each existing owner implements crate-private read_canonical/restore validation
beside write_canonical: config, topology, climate, temporal_climate, rng, genome,
organism, resources, species, population, simulation. Helpers depend on canonical
primitives, never persistence/CLI. Simulation assembles locally, validates cross-
owner agreements and returns only a complete valid engine. Configuration reuses
existing validation; if converting through JSON, prove bit-exact round trips for
all floating leaves and canonical normalized seed, and reject repairs by final
canonical comparison. Prefer shared validation/direct validated construction.
Do not initialize organisms, classify species, replay ticks, draw RNG or reset
cooldowns during restore. Reconstruct procedural base climate from validated
model+topology; validate all duplicated topology/settings. Rebuild only spatial
buckets and derived phenotypes from living records, in stable ID order.

Public persistence APIs: checkpoint_bytes(&Simulation)->io::Result<Vec<u8>>,
from_checkpoint_bytes(&[u8])->io::Result<Simulation>, and
load_checkpoint(path: impl AsRef<Path>)->io::Result<Simulation>. Keep filesystem
publication in application adapters; byte APIs support later UI integration.
Reject nonregular load files to avoid blocking on FIFOs; stat/read actual length
with checked arithmetic, verify envelope size and checksum before state decoding.
Returned errors provide context and become CLI status 2. No partially loaded
engine escapes. Re-encode decoded state and compare bytes (streaming comparison
is acceptable) to enforce canonical representation and guard decode omissions.

## Validation boundary

Retain the entire ADR-015 inventory, including next_id Option, request_sequence,
u128 current/initial/birth/death/cause counts, ordered death history, extinct
species and all organism cooldown discriminants. Pending queues must encode zero.
Cross-check config/engine/world/population dimensions and temporal settings/tick;
RNG version/nonzero words; finite bounded weather, resources and vitals; valid
alleles, cells (reject out-of-grid before Topology::cell wraps), stable nonzero
IDs, birth/age/cooldown chronology, parent arity/order and generation consistency
where reconstructible. Dead parents need not be living; historical genomes and
full dead-organism lineage are not stored, so do not demand unavailable facts.

Check current counts against living records, initial counts against Config,
initial+births-deaths with checked u128 arithmetic, death-history counts and cause
sums against totals, unique dead IDs disjoint from living IDs, tick bounds/order
(non-decreasing death ticks; do not require ID order within history), allocator
against all allocated living/dead IDs and totals. Preserve exhausted None exactly.
Validate species IDs/order, names, founders, ancestry references/kinds/origin
chronology, membership kinds/counts and extinction flags/ticks. Do not reclassify
living genomes against founders: membership is permanent and extinct founders
remain historical. Parents/species ancestors may be extinct. Derived counts may
be calculated to validate stored counts, never silently repair them. Account for
species created during a tick whose ancestor goes extinct at that same tick.
Tests must establish these checks accept naturally produced states, including
empty worlds and born-then-extinct histories. Invariants must follow production
code, not assumptions about ecological outcomes.

## CLI and shared runner

run accepts exactly one of --config/--load, required --ticks/--out, optional
--sample-every/--save; --seed only with --config. Loaded effective config/seed
remain authoritative. N counts additional ticks and checked start+N must fit u64.
Keep simulate(Config,N,K)->Value as the batch-compatible wrapper; extract
simulate_state(&mut Simulation,N,K)->Value for standalone loaded/new engines.
Results use actual tick_start and tick_end and cumulative counters. Samples are
start, start+K, start+2K,...,end once; use invocation-relative elapsed tick index
for interval checks, avoiding additions/duplicate samples, including N0. Batch
starts at zero and retains existing behavior. Time only advance_one_tick calls.
No save paths, clocks or samples enter canonical state.

Validate both destinations and aliases before running. Reject --save==--out,
output aliasing input config/load, and save aliasing input config, including
canonical-parent/relative spellings and existing hard links. Allow --load and
--save to reference the same regular file (normal checkpoint replacement): fully
load first, then publish the replacement atomically. Reuse existing CLI atomic
regular-file temporary/flush/rename helper. Build result JSON and checkpoint
bytes before publication; publish checkpoint first, result last. Save failure
leaves no new result and preserves an old result. A later result publication
failure can leave the successfully saved checkpoint; two-file atomicity/fsync
crash durability/concurrent same-destination writers are not promised. Preserve
preexisting outputs on returned failures where not already published; never
delete user files to satisfy the contract's absent-result error case.

## Consequences and verification

Encoding/decoding is O(area+living+history); spatial rebuilding adds dense area
storage and occupant insertion. Byte APIs add O(checkpoint bytes) memory plus
restored engine; avoid keeping an unnecessary engine clone. Large legitimate
states can exhaust memory/disk; actual file lengths bound malformed length
allocations, but OS OOM termination cannot reliably become status 2. No arbitrary
ecological/state size cap. Same machine/build continuation is required; cross-
libm hash equality is not promised. Future authoritative fields must update both
codec directions, schema/model versions, inventory and tests together.

Verify unchanged hash golden; exact round-trip canonical bytes; save observational
purity; future tick/hash/RNG/metrics equality after tick0 and multiple nonzero
splits; actual CLI/checkpoint chaining; recomputed-checksum invalid states;
truncation/bit flips/version/size/trailing failures; root-safe injected I/O errors;
host and static musl offline copied-root save/load. Detailed ordered work and
acceptance matrix live in TASK-022 plan-cycle1.md. No feature success claimed here.


## Implementation refinements

Owner-local inverse readers and bounded Decoder now implement format1 without
changing canonical encoder bytes. Configuration is built directly, validated
through the existing effective-config validator, and retains original f64 bits;
final re-encoding rejects noncanonical seed/byte representations. Population
validates request_sequence equals cumulative accepted births (Commit accepts all
queued births); IDs form a contiguous allocated union of living and dead records.
Ordered maps/sets validate references without quadratic history scans. Founder
kind and surviving founder genome/origin/membership also validate; unavailable
historical DNA is never invented. CLI private publish_results isolates publication
order for injected failures, reusing the unchanged atomic file writer.

Tests use public production recruitment scenarios through ticks650/2250 plus
coherent private mature-founder fixtures for guaranteed speciation and sexual
cooldowns in both animal kinds. Semantic mutations use freshly checksummed
encoded states or owner-local decoder inputs, rather than relying on checksum
failure alone. Full evidence and remaining environmental limits are in TASK-022
implementation handoffs; wire/API reference is docs/CHECKPOINTS.md.


TASK-027 amendment: model compatibility deliberately changes for hunting2 local
satiety. Envelope1/schema1/layout are retained, but old hunting1 payloads are
rejected even with correct checksum. No migration and no new state inventory.
Roundtrip and exact continuation tests include satiated parents/hungry offspring
and existing recruitment/speciation/cooldown cases. See ADR-020/BALANCE.md.

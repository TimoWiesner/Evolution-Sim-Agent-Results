# ADR-020: Measured local satiety experiment

Status: accepted and implemented in TASK-027 cycle1; measured selection750.

## Context and alternatives

TASK-027 requires fresh ten-seed10000-tick batch baseline and written death/curve
analysis BEFORE ecological changes, a measured mechanism trial and five unseen
seeds. Earlier collapse reports are clues only. See TASK-027 plan-cycle1.md for
exact order, files, seed partition, commands, tests and time budget.

Parameter-only tuning cannot satisfy the mechanism criterion. Persistent handling
timers/cover add state and codec work; global scarcity rescue is forbidden.
Randomizing founders could obscure the existing hunting problem. Prefer first
trying reserve-based satiety: current code attacks even at near-full reserves.
This changes a local decision rule rather than just changing existing constants.
It remains subject to the baseline diagnosis; amend rationale before edits if
actual data identifies a different first-extinction cause.

## Decision

After ordinary age/expiry and maintenance/liveness, carnivores with energy>=750
rest for their action; no sensing, movement, hunting or action RNG. Others follow
unchanged paid pursuit and one stochastic attempt. Reproduction still follows
ordinary maturity/energy/cooldown/compatibility rules. Trial500 threshold separately,
optionally best threshold with existing cooldown40. No new energy, spawn path,
DNA locus, field, timer, public mutation API, dependency or configuration leaf.
Costs and death rules apply regardless of populations. Existing energy determines
hunger and is already checkpointed. Trial observation/counting remains external.

Select using seeds0..4 (up to three changed candidates), full-horizon comparison
for finalists; keep baseline if no improvement. Freeze before seeds100..104,
which are never used for tuning. Preserve failed trials and paired old baseline.
Baseline seeds0..9, held-out100..104; all formal runs10000 ticks. Report censored
survival and exact first-zero tick, not coarse batch-sample interpolation.

## Compatibility, ownership and consequences

Private pure hunger helper lives ecology/carnivores; Simulation orchestrates it.
No reverse dependencies. Gate reads own energy only. Resting can suppress mate
encounters or synchronize future hunger; improvement is not promised. Existing
finite life, thermal costs and lack of food still allow extinction. Work per
resting action decreases, but larger living populations may increase total cost.

If retained, version hunting model2 in both canonical encoder/decoder identity
blocks, preferably using one constant; keep state schema1 and checkpoint envelope1
because layout is unchanged. Reject model1 checkpoints explicitly; no silent
migration claim. Update ADR-012/015/018 and golden with independent digest/reason.
If rejected final baseline retains model1. No new state inventory entry; all
ADR-015/018 fields, RNG, histories and validation remain binding. Future changes
to threshold require deliberate identity review.

## Verification

Boundary/helper and actual action tests must prove upkeep/aging, satiety no draws/
movement, hunger paid trial/odds/nutrition, seams and no-prey starvation. Retain
older acceptance fixture purpose by making hungry starting vitals explicit.
New-model replay and checkpoint split continuation, model rejection, full test.sh,
external observer/batch hash agreement, all recorded trial outcomes and TASK-026
performance remeasurement are required before claiming success. No empirical
result or installed dependency is claimed by this ADR.


## Implementation outcome

Fresh batch baseline seeds0..9 before ecology edits: first extinction herbivores
21..27,median24; all120 deaths predation,no births. Timestamped diagnosis preceded
T1. T1 threshold750 and T2 threshold500 each screened2000 then10000 on0..4.
Both median313,worst312; retain first750 after tied equal-size differences.
Optional T3 omitted because plant overgrazing now limits coexistence. Frozen before
held-out100..104: paired median25→316,range313..320 under chosen policy. Every
chosen run ultimately empties; no stable coexistence claim. All numeric defaults
unchanged. No count feedback,new state/dependency/API/config; codec hunting2 and
old-model rejection implemented. Full counters/curves/trial patches/rejected
results/commands and safety/performance analysis in BALANCE.md and task evidence.
Original performance floor failure retained; documented plant-focused replacement
keeps>=2000/1000 measured ticks and10/s guard, original mixed input unchanged.
No additional candidate after held-out. Tests/phase handoff record actual evidence.

# ADR-016: Observational evolution metrics

Status: Implemented in TASK-020 IMPLEMENT cycle 1.

## Context and alternatives

TASK-020 requires sampled lifecycle, species, phenotype and generation summaries.
Existing Population read-only APIs supply all source data. Per-event metric state
would duplicate lifetime counters and risk replay/checkpoint drift. A separate
CSV/file would require another publication path and flatten nested kind/trait data.
Choose additive JSON result-series fields, calculated only on demand from immutable
engine references. Retain required contract series population keys.

## Decision

Add public metrics module with typed snapshots, immutable capture(&Simulation),
kind lookup and explicit JSON conversion. CLI invokes capture at the existing
start/interval/end sample points, after Commit for nonzero ticks. Always include
analytics, so no new flag/config or alternate output destination is needed.
Result root gains metrics_schema:1. Each series row keeps tick/plants/herbivores/
carnivores and adds analytics with plants/herbivores/carnivores and generation.
Each kind analytics record has births, deaths, deaths_by_cause, species, traits,
and generation. Births/deaths/cause counts are cumulative since tick0, initial
organisms excluded from births; count differences give interval events. Causes
are starvation, injury, predation, old_age, climate, always present including zero.
Species counts only living species. Exact integer counters remain u128 JSON
integers, never converted to f64.

Traits keys are exactly the twelve Traits getter names: speed, strength,
max_health, lifespan, fertility, vision, metabolic_multiplier,
preferred_temperature, preferred_moisture, climate_tolerance, aggression,
risk_tolerance. Summarize living phenotypes including inactive loci for plants.
Each value has mean, standard_deviation, min, max. Spread is population standard
deviation sqrt(sum((x-mean)^2)/n), not sample deviation. Stable ID-order Welford
accumulators use f64, clamp final variance to at least zero before sqrt. Singleton
spread is zero; absent-kind summaries are null for all four statistics. Numeric
integer traits are summarized in their expressed units (cells/tick, ticks, cells),
not allele values. Generation has highest (exact u64 or null) and mean (f64 or
null), both per kind and at analytics.generation over all living individuals.
Empty world generation is null/null; singleton and founder generation is zero.
Only generation means convert u64 to f64; document loss of precision above 2^53.

## Ownership, complexity and consequences

metrics depends on simulation, population/organism/traits read-only values and
existing serde_json only. Core engine/ecology/persistence never imports metrics.
No new authoritative state, schema/model/hash version or checkpoint payload.
One stable living scan accumulates three kinds plus overall generation; species
queries scan existing registry. Cost O(living*12 + historical species), constant
snapshot workspace; output buffers O(samples*3*12). No RNG access, engine clone,
mutation, wall clock, history traversal or global-count biological feedback.
Existing tick-only timings exclude metric capture. Always-on metrics increases
output size/capture time; users retain --sample-every to control it. Separate
metrics disable flags, distributions/histograms, charts, sweeps, checkpoint and
biological tuning are outside this task. Additional metrics limited to min/max
and overall generation; energy/health are vitals rather than heritable traits.

## Verification

Use independent hand-computed heterogeneous values (1,3 => mean2/stddev1), all
12 keys, absent/singleton kinds, founder values, generation0/2 => mean1/highest2,
and controlled births/deaths of every cause with completed Commit. Exact counts
and tolerance-based float assertions; no expected values from the accumulator.
Compare repeated capture and sampled versus unsampled engines by full equality
and canonical hashes through mixed/reproducing/extinct runs. CLI verifies schema,
all sample boundaries, unchanged contract fields and sampling-independent hash.
Existing static packaging and full suite must pass. Ordered files/tests are in
TASK-020 plan-cycle1.md. No new runtime dependency or system installation planned.

## TASK-020 implementation evidence

The public metrics module and additive CLI sample mapping implement this decision.
Four private metrics tests use independent arithmetic, controlled endpoint genomes,
existing cfg(test) population fixtures and committed lifecycle primitives; two
public tests cover founder/null oracles and repeated capture versus unsampled
engines through2200 ticks on three seeds. CLI schema/oracle/replay/extinction tests
and copied static-runtime checks cover the file interface. Exact executed commands,
results and remaining platform/size limits are in TASK-020 implementation handoffs.
No engine encoder, authoritative field, dependency or biological model changed.

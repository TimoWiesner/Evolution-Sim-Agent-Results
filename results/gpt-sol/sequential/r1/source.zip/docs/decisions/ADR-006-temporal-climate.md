# ADR-006: Periodic seasons and persistent seeded weather

Status: Implemented in TASK-007 IMPLEMENT cycle 1.

## Context and alternatives

TASK-007 needs a configurable year, bounded current climate and seeded weather
with all carry-over state owned by Simulation. Existing validated ClimateConfig
already supplies year_ticks (1..u64::MAX), two season amplitudes and one weather
amplitude (each finite 0..1). Preserve ADR-005 base climate and export unchanged.

| Model | Consequences |
|---|---|
| Smooth seasons plus global correlated weather (chosen) | O(1) storage/update/lookup; simple complete-state boundary and seam guarantee; weather lacks local storms |
| Independent per-cell weather | O(area) storage/draws/update, spatial discontinuities, expensive huge-world construction |
| Wrapped spatial noise and moving fronts | Rich variation but more state, parameters and seam/continuation tests than this task needs |
| Fresh random offsets on each query | Observation changes RNG and different consumers see different values; rejected |

## Decision

Keep Climate immutable. World additionally owns TemporalClimate containing a
copy of validated ClimateConfig and WeatherState. The latter has model version 1,
absolute u64 tick and two f64 normalized offsets, temperature then precipitation.
At tick 0 both offsets are +0.0; construction consumes no random draws.

For tick t, year Y and base temperature q, compute r=t%Y in integer arithmetic,
s=cos(TAU*(r as f64 / Y as f64)). Reduce before converting to floating point;
identical year remainders execute identical floating operations, hence repeat
exactly on one build. Y=1 is a valid constant seasonal phase. No promises of
resolving adjacent phases for enormous years beyond f64 integer precision.

Current temperature = clamp(q + A_T*(0.25+0.75*(1-q))*s + w_T,0,1).
Current precipitation = clamp(p - A_P*(0.5+0.5*q)*s + w_P,0,1), with base p.
Cool zones have stronger temperature seasons; warmer zones stronger wet/dry
seasons. All zones share phase: the torus has one joined cold belt, so this
simplification avoids a hemisphere phase seam. Wetness peaks opposite warmth.
Amplitude zero disables the corresponding season. Biome remains the static
base classification. Values use documented normalized [0,1] units throughout.
Clipping keeps bounds but may flatten extrema; it preserves continuity.

At each ClimateResources stage, after clock increment and before any organism
phase, update temperature then precipitation weather. If weather amplitude A=0,
set offsets to +0.0 and consume no draws. Otherwise consume exactly two raw
next_u64 draws, one per channel, with no rejection or helper generator. Convert
each draw d to u=(d>>11) as f64 / 9007199254740992.0 (uniform 53-bit [0,1));
innovation z=A*(2*u-1). Set w=0.75*w+0.25*z, defensively clamp to [-A,A].
Store the new absolute tick even with weather off. Querying never advances or
samples. Weather is shared spatially, so it cannot introduce a wrapping seam.
The AR(1) memory gives persistent, mean-reverting weather without new config.

## State and interfaces

New src/temporal_climate.rs exports TemporalClimate, CurrentClimate and
WeatherState (Clone/Debug/PartialEq; value records Copy where practical).
TemporalClimate::new(ClimateConfig) uses tick-zero neutral weather;
current_at(&self, base: &Climate, cell: Cell) -> CurrentClimate is observational.
CurrentClimate has read-only temperature()/precipitation() accessors.
weather_state() -> WeatherState returns an owned snapshot; tick() -> u64.
The mutation method advance_to(tick, &mut Rng) is crate-private, called exactly
once per engine tick. World::current_climate_at(Cell) delegates using its own
base field; World::temporal_climate() exposes read-only state/queries.
Simulation's RNG remains private and is the sole random source.

WeatherState::new/TemporalClimate::from_state(settings, state) must validate
version, finite offsets and abs(offset)<=weather_amplitude; reject nonzero
weather when A=0. No silent repairs or draws on restoration. Exact API names for
error type may follow existing RngError conventions. Restore retains float bits;
configuration, tick and both offsets plus engine RNG are future-influencing state.
Temporal tick must equal Simulation tick at completed boundaries. Later TASK-022
must encode these fields/settings/model version, verify clock agreement, and
include them in canonical checkpoints/hashes. This task adds no disk format.

## Consequences and verification

No new crate, runtime, system package, raster, CLI command or UI dependency.
Base model/version/export remain version 1; temporal model has separate identity.
Queries cost O(1), weather update O(1) and two draws regardless of area; throughput
is unmeasured. Shared weather and coherent phases are intentionally simplified.
Same-build exactness is required; minor cross-platform math differences allowed.
Bounded seasonal/weather properties, exact annual repetition, draw order, seed
traces, pure queries, cloned/restored continuation and seam invariants must be
executed in IMPLEMENT as detailed in TASK-007 plan-cycle1.md.


Implementation evidence: src/temporal_climate.rs and World integration follow
these formulas and boundaries without new dependencies. Public integration tests
cover exact annual repetition across all cells/phases on grids 1..=8, independent
quarter-year expectations, seed traces, bounds, draw counts, query purity/seams,
restoration validation and large-tick modulo behavior. A private recurrence oracle
and 37+256-tick temporal/RNG restoration test verify persistent continuation.
Exact execution results are recorded in TASK-007 implement-cycle1 handoffs.

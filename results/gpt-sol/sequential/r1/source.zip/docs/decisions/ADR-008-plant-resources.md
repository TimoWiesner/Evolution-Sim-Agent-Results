# ADR-008: Bounded cell resources and plant energy

Status: Implemented in TASK-011 IMPLEMENT cycle 1.

## Context and alternatives

TASK-011 requires climate-dependent plant energy, local competition, mortality
and genetic effects. Existing configuration already has resource_capacity (default
100), resource_regeneration (1) and growth_efficiency (0.5). Existing DNA supplies
climate optima/tolerance, metabolism, health and lifespan. Preserve that schema.

| Model | Tradeoff |
|---|---|
| One bounded renewable photosynthetic resource per cell (chosen) | One f64 per cell, explicit source/consumption budget and simple deterministic tests; abstracts light, soil and water |
| Separate soil nutrients, water and light | More ecological detail but multiple rasters, parameters and conservation rules; unnecessary for current criteria |
| Unlimited photosynthesis or global carrying capacity | Cheap but fails local finite competition or introduces global population feedback; rejected |

## Decision and exact model v1

World owns a row-major ResourceField, separate from immutable Climate and
TemporalClimate. ResourceField stores Topology and Vec<f64>; effective PlantConfig
remains owned by Simulation. Capacity C is the existing positive configured
resource_capacity; all cells start at C without RNG draws. Normalize foreign Cell
coordinates before indexing. Resources are authoritative memory, not a cache.

After temporal climate advances in ClimateResources, visit cells row-major and
let P be CURRENT precipitation in [0,1]. Add min(C-R, regeneration*P) to each
cell. C is a storage cap, not a population cap. Water is modeled as current
precipitation availability, without a separate soil-water reservoir. There is no
transport, runoff, seed bank or organism-count dependence.

One resource unit represents one unit of stored environmental photosynthetic
opportunity/chemical energy. Initial cell stores and organism reserves are
explicit initial-condition inputs. Ongoing resource regeneration represents
external sunlight/primary production limited by water; it is the sole ongoing
plant energy source. Efficiency eta in [0,1] converts withdrawn resource to plant
energy, with the rest dissipated. Maintenance dissipates energy, and unused
resources stay in the cell. Neither climate damage nor aging supplies energy.
This is an abstract energy model, not measured soil chemistry or a claim that
water itself supplies chemical energy. Document this simplification prominently.

Each plant acts through the existing ascending-ID walker, after aging; old-age
expiry preempts its action. Copy traits, cell and vitals from the living record.
For CURRENT temperature T, water P, genome optima t0/p0 and tolerance w:

- aT = clamp(1 - abs(T-t0)/w, 0, 1)
- aP = clamp(1 - abs(P-p0)/w, 0, 1)
- suitability s = aT*aP
- hostile stress h = clamp(max(abs(T-t0),abs(P-p0))/w - 1, 0, 1)

Apply health delta -h using DeathCause::Climate. If lethal, return before energy
or resource changes. Then apply maintenance energy delta -0.2*m where m is the
DNA metabolic_multiplier. If lethal, Starvation wins and no resource is taken.
Next compute headroom H=ENERGY_CAPACITY-current_energy. If eta=0, s=0 or H=0,
take nothing. Otherwise request min(4*s, H/eta) resource units from the cell;
withdraw u=min(R,request), store R-u, and credit eta*u energy through the bounded
Population vital primitive. Floating roundoff is bounded/clamped; exact arithmetic
budget comparisons in tests use a tight documented tolerance. Constants 0.2 and
4 are model-v1 physiology, not hidden population controls. With eta tiny, H/eta
can overflow to infinity; min with bounded 4*s before withdrawal keeps all stored
state finite. Do not persist that intermediate or reject a valid tiny efficiency.

Growth means replenishment/increase of stored energy, not a separate biomass or
size system. Existing energy capacity 1000 bounds each plant; finite initial
resource and regeneration bound aggregate gain in each cell over any interval.
Same-cell later IDs see the already-depleted pool immediately. Stable order bias
is accepted under ADR-001; no proportional sharing or RNG draws are added.
Health does not regenerate in this task. Plants can die of old age, maintenance
starvation or accumulated hostile-climate damage. No production reproduction,
grazing, animal costs or global-count-dependent rescue is added.

## Boundaries, cost and persistence

Add src/resources.rs (config/topology only) and src/ecology/{mod,plants}.rs
(config/traits only for pure rates). Simulation orchestrates mutating explicit
World/Population subsets; neither resource nor ecology modules import Simulation,
CLI or UI. ResourceField has a public read-only at(Cell) and model version;
construction/regeneration/withdrawal stay crate-private. World::resources() is
read-only. Use fallible checked dense Vec allocation and propagate ResourceError
through SimulationError. No arbitrary dimension policy cap. OS overcommit/OOM
is still possible, as with existing spatial storage.

Storage adds O(area) and climate/resources adds O(area) work per tick, even with
no plants; plant work adds O(plants log living) using existing records. No new
runtime/crate/system dependency; static musl packaging remains required. No
throughput or coexistence claim. Independent water/nutrient dynamics and fairness
can be revisited with measurements rather than adding unneeded model complexity.

Future checkpoint/hash must include resource model version and every row-major
f64 resource value, dimensions and effective plant settings, plus all existing
state. Loading must reject nonfinite/out-of-cap values; it must never regenerate
or refill depleted cells. Version changes need explicit compatibility handling.
TASK-011 adds no checkpoint wire format. Reproduction in TASK-012 may inspect
remaining resources but cannot create energy or bypass this source budget.

## Verification

Use independent arithmetic budget oracles, matched depleted plants under favorable,
cold and dry current climate, paired genomes differing only at active loci,
shared-cell depletion, bounded regeneration, no-consumption at zero efficiency,
all mortality causes through real tick/commit, exact replay/RNG draw counts,
zero-plant continued ticking and finite-bound matrices. Detailed tests, fixture
migration and implementation order: tasks/TASK-011/handoffs/plan-cycle1.md.

## Implementation evidence

ResourceField, pure plant rates and Simulation orchestration implement the model
above without equation/schema/default changes or new dependencies. Public
resource observations and private production-tick fixtures verify independent
energy budgets, isolated cold/dry effects, genetic physiology, local competition,
finite boundary values and all mortality causes. Existing lifecycle fixtures now
permit ecological plant deaths while retaining exact animal old age and mixed
replay/accounting. A favorable static-climate fixture retains exact plant old age.
Only cfg(test) fixture mutation can change organism DNA/vitals directly; no public
mutable API or production DNA override was introduced. Exact execution evidence
and limitations are in TASK-011 implementation handoffs and docs/PLANTS.md.

# ADR-019: Measured, behavior-preserving engine optimization

Status: Implemented in TASK-026 IMPLEMENT cycle1; review remains harness-owned.
Planning rationale retained below; measured refinements follow.

## Context

TASK-026 requires reproducible throughput, profile evidence, before/after numbers,
unchanged behavior and a loose slowdown guard. Existing release query benchmarks
are not engine measurements. Long default mixed runs collapse naturally, so an
initial population alone does not establish the measured population size.

## Alternatives

- Choose a fixed real-ecology window with observed live counts (chosen): measures
  actual work without changing defaults or forcing replenishment. State the changing
  kind mix and population range. A fixed-key larger world supports a longer sample.
- Disable biology or hold populations artificially: simpler steady load, but masks
  production work and risks violating no-replenishment/unchanged-behavior requirements.
- Parallelize actors, rewrite population storage or approximate climate: potentially
  larger gains, but risks ordering/RNG/float changes and codec churn. Not justified
  without evidence and unnecessary before smaller opportunities are measured.
- Assert100 ticks/s in ordinary debug tests: unstable and misleading. Use release
  measurements for target and a substantially looser release guard for gross loss.

## Decision

Implement an external Rust example benchmark using public Simulation APIs, Instant
only in the caller,100 warm-up+1000 measured ticks, five independent repeats at
seed42,128x48, initial4600 plants/240 herbivores/40 carnivores, all existing defaults.
Assert >=2000 living organisms at each measured tick; report actual extrema/mean
and kind breakdown, not a claim of constant2000 or all-kind coexistence. Supplement
with warm-up10+100 ticks at64x48,2400/120/20,nine repeats for an animal-active window.
Harness startup/warm-up/serialization/hash are excluded; cheap count observations
are included and disclosed. Preserve identical baseline binary and harness before
editing core; report median and spread without concurrent profiling/tests.

Profile release code with symbols using Callgrind instruction attribution (label
Ir distinctly from time), or supported sampling profiler if available. Compare
engine subtree, disclose startup/warm-up in whole-process profiles, record commands
and tool versions. No profiler was present/run in PLAN. Tools stay development-only;
no new product runtime dependency or Cargo crate is planned.

First candidate supported by source inspection: resource regeneration repeats
identical current-climate work across each longitude in a row. Subject to profile
confirmation, compute row precipitation once and apply exactly the prior cell
arithmetic in original row-major order. Prefer a streaming crate-private row
callback in ResourceField (O(1) workspace), keeping arbitrary-cell climate APIs and
all authoritative structures unchanged. Do not introduce persistent climate caches.
Second optional candidate: normalized direct kind-existence bucket query for plant
establishment instead of allocating/sorting a full radius-zero result. Public
spatial ordering and all action/RNG gates remain unchanged. Actual profile may
justify a different bounded change; persist evidence and decision before doing so.

No ecological equation/default, RNG call order, stable-ID scheduler, model/schema,
canonical bytes or checkpoint format change. Test old/new baseline hashes, complete
contract outputs excluding timings and checkpoint bytes/continuation, alongside
existing replay tests. Reject bit differences instead of weakening assertions.

## Consequences and verification

No reverse dependencies: benchmark/test observes core; core imports neither clocks
nor harness. No new authoritative or serialized fields; ADR-015/018 inventory stays
binding. Proposed row optimization changes repeated climate evaluation O(area) to
O(height), while authoritative resource update remains O(area); organism work
remains unchanged. Direct occupancy avoids one temporary result allocation per
establishment query. Neither improvement is claimed before measurement.

Add explicit release test invocation to test.sh:100+1000 ticks with population
floor and >=10 ticks/s. This coarse threshold is tenfold below the target, stable
on slower machines, not a universal100/s guarantee. Ordinary debug suite skips the
explicitly ignored timing test; test.sh runs it explicitly and must not skip it.
Full isolated test.sh retains deterministic/checkpoint/UI/static packaging tests.
Behavioral oracles cover row float bits, degenerate worlds and actual spatial
mutation. Report hardware/quota/affinity/compiler/build flags and before/after raw
measurements in docs/PERFORMANCE.md, including honest miss/bottleneck if <100/s.
Exact paths, interface choices, differential fixtures, timing/profile commands,
acceptance matrix and time budget: tasks/TASK-026/handoffs/plan-cycle1.md.


## Implementation and measured outcome

The external example/shared test helper and exact scenario above are implemented.
Formal preserved-baseline/final medians:751.693→847.955 ticks/s primary (+12.8%),
1027.076→1095.760 supplementary (+6.7%). All measured ticks retain>=2000;
primary actual2303..5081,mean3490.522,mostly plants.100/s target met for this
workload; no constant-population or sustained mixed-chain claim. Calls/timing
observations remain outside engine; full effective config/counters/hash are in
tracked raw reports. Initialization/warm-up/hash/JSON excluded from timed loop;
O(1) count aggregation/floor checks included. Ranges/hardware/commands/limits are
in docs/PERFORMANCE.md and task-local implementation evidence.

Callgrind3.22.0 with release debuginfo confirmed resource regeneration12.15% of
baseline whole-program instructions; repeated row-equivalent current climate
queries. Implemented only streaming regenerate_rows callback from Simulation:
one existing current_at query per row then exact original cell arithmetic and
order, constant extra space, no temporal-climate structural/API change. Regeneration
inclusive Ir2,264,907,396→91,344,032; whole-program Ir down11.66%. Profile includes
initialization/warm-up/final hash and is instruction attribution, not timing.
Optional spatial has_kind/season hoist not implemented: smaller expected scope
benefit, existing measured row speedup sufficient. Remaining repeated phenotype
conversion/validation and ordered-map lookups documented, no broad rewrite.

Bit-level resource oracles cover tiny/rectangular worlds, seasons, restored
weather/disabled/max offsets and resource extremes.30 baseline exact result/
checkpoint comparisons and20 bidirectional checkpoint continuations pass without
changing canonical golden/schema/model/defaults/ecology/RNG consumption. The
release-only10/s coarse guard is explicitly invoked by test.sh; debug tests skip
only that timing assertion. Final full-suite commands/results live in the
implementation handoff. No new crate/runtime dependency or authoritative field;
ADR-015/018 inventory and ownership remain exactly binding.

Development profiler install actually run: apt-get update then
apt-get install -y --no-install-recommends valgrind; exact reinstall commands
also recorded in STATE. No profiler dependency enters setup/runtime/test.sh.
Hardware quota/memory files outside /workspace were not read under the user
restriction; available CPU/tool metadata and this limitation are reported.


TASK-027 workload amendment: retained satiety changes primary ecology so the
original scenario fails>=2000 at tick685 (1998); measured1100-tick minimum564.
Original evidence and unsuccessful120/20-herbivore replacements are preserved.
scenarios/performance.json now initializes0 herbivores (4600 plants,40 carnivores
and128x48 unchanged), retaining100+1000/five repeats/floor>=2000/guard10/s. This
is an explicitly plant-focused replacement, not directly comparable to original
primary timing. Mixed input/window/nine repeats unchanged. Final medians857.619
replacement and671.812 mixed; both>=100/s, mixed38.7% slower with more active
animals. Full counts/raw evidence and limitations in BALANCE.md.

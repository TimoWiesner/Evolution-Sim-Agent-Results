# ADR-007: Organism records and deterministic lifecycle

Status: Implemented in TASK-008 IMPLEMENT cycle 1.

## Context and alternatives

TASK-008 introduces common life state, not DNA, feeding, movement or reproductive
behavior. Preserve ADR-001 scheduling and ADR-004 trait/lineage bounds.

| Storage | Tradeoff |
|---|---|
| BTreeMap<OrganismId, Organism> (chosen) | Deterministic ID iteration, O(log n) lookup/removal, no tombstones; node overhead and weaker locality |
| Dense Vec plus ID-to-slot map | Fast iteration but swap-removal needs extra invariant maintenance; can replace storage after profiling |
| Vec indexed by lifetime ID | Simple lookup but retains holes proportional to all births; rejected |

Choose std-only BTreeMap for living records, owned by Simulation via Population.
Spatial buckets remain a separate derived cache in TASK-010. No runtime/package
dependency. Performance is unmeasured; later profiling may motivate dense storage.

## State and bounds

OrganismId is a private-field u64 newtype. Allocate monotonically from 1, never
reuse a dead ID. Represent exhausted allocator explicitly (Option<u64> next ID),
allow the maximum ID once, then fail before mutation. Initial kinds allocate in
plants/herbivores/carnivores order; local ordinal i is placed row-major at
(i % area), continuing ordinal across kinds. Multiple occupants are allowed.
This deterministic provisional placement consumes no RNG; later initialization
may explicitly revise draw semantics when genomes/ecology exist.

Every organism has private validated fields: ID, Kind (three enum variants),
normalized Cell, u64 age, finite f64 energy and health, Traits, parent IDs,
u64 generation and birth tick. Initial records have age/generation/birth tick 0,
no parents, full energy and full health. Initial population is not counted as
births. Plants have zero or one parent, animals zero or two distinct parents;
zero parents is reserved for initialization. Offspring generation is checked
parent+1 or max(parent generations)+1, parent IDs sorted ascending. Capture
parent kind/generation at acceptance; no need to retain dead organism bodies.

Traits are a private validated phenotype record with the twelve ADR-004 bounds:
speed u8 1..4; strength f64 1..10; max health f64 10..100;
lifespan u64 200..2000; fertility f64 0..1; vision u8 1..8;
metabolic multiplier f64 0.5..2; preferred temperature and moisture f64 0..1;
climate tolerance f64 0.05..0.5; aggression and risk tolerance f64 0..1.
Reject nonfinite/out-of-range trait construction. Until TASK-009, use one explicit
founder phenotype for every kind: 2, 5.5, 55, 1100, 0.5, 4, 1.25, 0.5, 0.5,
0.275, 0.5, 0.5 in the order above. No alleles or mapping implemented here.
TASK-009 makes genome depend on this trait value type, avoiding a module cycle.
Plants retain inactive speed/behavior values as already allowed by ADR-004.

Energy range is [0,1000] model units; health [0,traits.max_health]. The fixed
energy capacity is provisional physiology, not free energy. Construction rejects
invalid values; live initialization and newborn acceptance additionally require
strictly positive energy and health, so no zero-vital living records are inserted.
Finite signed change APIs clamp within bounds using overflow-safe
comparisons; NaN/infinity are rejected without mutation. Zero energy kills by
Starvation; zero health by Injury unless a caller supplies the explicit cause
(e.g. Predation). Lifespan expiry kills by OldAge. Finite positive changes only
come from documented sources in later ecology; this task adds none. No basal
cost, feeding, climate damage, movement or reproduction decisions are added.
Dead records are removed immediately and cannot be mutated, healed or scheduled.
First lethal event wins, repeated death is a no-op, never double-counted.

## Tick rule and accounting

Each kind phase captures ascending living IDs, rechecks liveness before each
visit, increments age once, kills if age >= lifespan, then invokes its action
hook only if still living. The production hook is empty for TASK-008. Newborns
are absent until Commit, so first age increment/action is next tick. Age cannot
overflow in a valid living record because finite lifespan bounds it.

Birth requests are internal engine primitives, never a public spawn command.
Accept only validated live same-kind parent(s); capture lineage immediately.
They represent already-authorized reproduction, not autonomous reproduction.
Future ecology owns compatibility, energy, maturity and cooldown checks. Accepted
requests survive parental death later in the same tick; a dead parent cannot
submit a new request. Commit in originating phase then sorted parent IDs then
monotonic request sequence for exact ties. Assign newborn IDs in this order,
with age 0, accepted bounded vitals and captured generation. A queue is always
empty at completed-tick boundaries. No production caller creates requests yet.

Death disables/removes immediately; stage DeathRecord {id, kind, tick, cause}
until Commit, which increments per-kind death and cause totals and appends the
record to persistent death history. Initial births/deaths are zero. Successful
newborn insertions increment births once. Living counts are maintained on insert/
remove. At completed ticks: initial + births - deaths = living for every kind.
During a tick use pending deaths in the equivalent invariant. Death history is
O(all deaths), a deliberate initial inspection/audit tradeoff; future retention
changes need explicit persistence/inspection design. No dead body acts again.

Validate/reserve each birth request's ID/counter/generation capacity before
acceptance so Commit is infallible under valid state. Check tick overflow before
any mutation as today. Internal death/cause counters should use u128 so a u64-ID
lifetime cannot overflow them. Birth/initial/live counts can likewise use u128
internally; future result JSON emits exact integers. Allocation failures remain
subject to process memory; don't claim arbitrary representable counts fit RAM.

## Persistence and verification consequences

Future checkpoints/hash must include living records, traits (later genomes),
next-ID exhaustion state, initial/lifetime counters and death history/cause totals;
completed state has no pending events. No disk format is introduced now.
Deterministic stage fixtures must execute the same production lifecycle walker
and commit path, with controlled private test hooks; no test-only second engine.
Test trait/vital boundaries, ID/generation exhaustion, parent arity, same-tick
parent death and accepted birth, later-actor death, lifespan, counters and seeded
replay. Exact acceptance matrix is in TASK-008 plan-cycle1.md.


## Implementation evidence and API refinements

src/organism.rs, src/population.rs and Simulation implement this decision without
new dependencies. TraitValues is the named public construction input; Traits
validates and privately retains it. Organism records expose read-only getters;
mutation/initialization/birth requests remain crate-private. The population-owned
BirthPhase enum encodes only the four legal birth phases and avoids a dependency
cycle with simulation::TickPhase. Thus invalid phases/traits are unrepresentable
in a request rather than runtime PopulationError variants. Other validation uses
explicit PopulationError variants; ordinary health changes pass no cause to use
Injury, while ecological callers may supply a cause. u128 accounting cannot
overflow within the lifetime u64 identity capacity; no extra counter reservation
is needed. ID capacity is reserved by checking outstanding accepted requests.

The earlier fixture-only ordered_actor_ids helper is replaced by BTreeMap's
unique ascending phase snapshot and the shared actual lifecycle walker. Tests
exercise all three kinds, trait endpoints/nonfinite errors, finite extreme vital
changes, first cause/no resurrection, generation and ID exhaustion, birth ordering,
accepted births after parent death, next-tick newborn activity, repeated identity
allocation/conservation and four-seed 2200-tick lifespan/empty continuation.
Full ./test.sh passes 61 tests, none skipped, including static packaging. Exact
commands and initial test-compilation corrections are recorded in TASK-008
implement-cycle1.md/.json. No ecology, performance, disk persistence, separate
fresh-container or Rust 1.85 execution is claimed.

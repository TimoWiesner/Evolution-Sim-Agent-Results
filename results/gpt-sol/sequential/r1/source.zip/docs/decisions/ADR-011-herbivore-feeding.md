# ADR-011: Paid herbivore maintenance and risk-sensitive grazing

Status: Implemented in TASK-014 IMPLEMENT cycle 1.

## Context and alternatives

TASK-014 needs local bounded plant-to-herbivore energy transfer, continual costs,
current-climate consequences and a behavioral DNA decision. Reuse indexed sense,
shared age-first walkers and immediate Population mutation paths. Unlimited
feeding would break the energy budget. Global population feedback is forbidden.
A general behavior interpreter, persistent hunger/targets and new DNA loci add
unnecessary state. Choose deterministic local risk filtering and one bite, using
existing risk_tolerance; aggression can remain inactive until later ecology.

## Decision: grazing model 1

Only herbivore actions change. Carnivores retain TASK-013 navigation without
feeding, basal cost or attacks until TASK-015. Animal reproduction is TASK-016.
No config schema/default or dependency changes. Existing animals.basal_cost is
strictly positive (default 0.1); movement_cost may still be zero.

After the walker ages/expires an herbivore, copy its traits and starting cell.
Query CURRENT temperature T after this tick's weather, not static base climate.
Set stress = clamp(abs(T-preferred_temperature)/climate_tolerance - 1, 0, 1).
Maintenance = max(animals.basal_cost, 1e-9) * metabolic_multiplier * (1+stress).
Debit maintenance first via Population::change_energy; return immediately if dead.
The 1e-9 model-unit floor makes even subnormal accepted configuration costs cause
representable loss at the bounded 1000-unit capacity. It is documented numerical
physiology, applied to every herbivore independent of counts; never a rescue.
All operands remain finite (maintenance <=4,000,000). No health climate damage
is added for herbivores. Thermal mismatch increases the cost up to twofold.

Sense once after maintenance via Population::sense. Split living visible IDs into
plants and carnivores. A plant is dangerous if any of those VISIBLE carnivores is
within inclusive wrapped Chebyshev distance 1 of that plant. Never query hidden
predators or global counts. If risk_tolerance < 0.5, exclude dangerous plants;
otherwise allow all visible plants. Among eligible plants choose (distance from
herbivore, stable ID) ascending, retaining ADR-001 ties. This is avoidance of
risky feeding locations, not fleeing or being hunted; no attack/protection exists.
Threshold is inclusive for bold animals (>=0.5), and paired locus-11-only genome
tests must show actual different actions under identical surroundings and RNG.

With an eligible plant, pursue its fixed cell using existing shortest adjacent
steps and paid movement, capped by inherited speed, but STOP once distance <=1.
Same-cell and all eight adjacent cells are feeding reach, including torus seams.
No further step is charged or drawn. If movement kills the herbivore, stop. With
no eligible plant, use existing paid random exploration; do not opportunistically
bite plants not selected by this action's sense/risk decision. A newly encountered
plant is considered next tick. No pursuit RNG; exploration uses the sole engine
RNG with existing draw rules. All kinds retain unlimited co-occupancy.

After pursuit, recheck liveness, target kind and actual wrapped distance <=1.
One target, at most ONE bite per herbivore per tick, even if many plants share its
cell or it is killed. At distance >1 take nothing. Let H=1000-herbivore.energy,
eta=0.8, bite cap B=4 plant-energy units. Request min(B, plant.energy, H/eta).
If nonpositive take nothing. Debit the plant with change_energy, recording its
before/after energy (after=0 if it died). Only the REALIZED removed amount funds
eta*removed credit to the living herbivore through change_energy. If subtraction
rounds to no change, credit nothing. Finite capacity clamps remain authoritative.
Tests allow <=1e-10 absolute roundoff for transfer ledgers; the efficiency margin
ensures gain never materially exceeds removal. No health-based biomass payout,
refill, resource withdrawal or free nutrition. The remaining 20% dissipates.

A fully drained plant dies immediately by existing Starvation (energy depletion),
not animal Predation. Its spatial entry disappears before later herbivores sense;
its death is counted once at Commit and it cannot reproduce later this tick.
Partially eaten plants retain their DNA/vitals and can grow next tick. Plants
already acted before grazing, so full-tick tests must isolate/compute that growth
and maintenance instead of attributing all plant energy changes to bites.

## Boundaries and consequences

Add private src/ecology/herbivores.rs for pure maintenance, risk eligibility and
bite-budget helpers; imports config/traits/topology/value types only. Pass cells
and traits explicitly; never import Population or Simulation. Simulation owns
sense partitioning, deterministic selection, movement and the debit/credit order.
Reuse/refactor the existing movement executor with explicit target and stopping
radius parameters; preserve its real per-step observer and TASK-013 carnivore
behavior. Population remains the sole vital/index/lifecycle mutation owner; no
new public mutation API or alternate engine. Herbivore action still runs solely
inside the shared age-first walker.

Transient sensed IDs, target and budget vanish at action end. No authoritative
field or RNG is added. Future checkpoints/hash must retain grazing model identity,
effective basal settings and all existing complete state (DNA, vitals, positions,
RNG, climate/resources/counters); rebuild/exclude spatial cache. Changing policy
changes deterministic traces. Fixed risk threshold is intentionally simple;
stable-ID feeding favors earlier animals. Risk evaluation costs O(visible plants
* visible carnivores) bounded by local occupancy, not constant entity density;
no performance/coexistence claim. See task-local plan for executable matrix.


## Implementation evidence

Private ecology/herbivores.rs and Simulation's shared walker implement the exact
model above, including current-temperature upkeep before sense, one visible-risk
snapshot, radius-1 pursuit stop and realized debit before credit. The movement
executor accepts an explicit target and stop radius; carnivore navigation keeps
radius 0. No authoritative state, config/default or dependencies changed.
Production tests and public integration tests cover each acceptance criterion;
exact commands, fixture migrations and results persist in TASK-014 implementation
handoffs. Private production fixtures are in a child simulation test module for
readability, using only existing cfg(test) record access. No model deviation.


TASK-015 refinement: implemented ADR-012 supersedes carnivore navigation-only
behavior with identical shared thermal upkeep, radius-1 paid pursuit and one paid
stochastic herbivore attack. Existing movement geometry/execution and herbivore
policy remain unchanged. See ANIMALS.md and TASK-015 implementation evidence.

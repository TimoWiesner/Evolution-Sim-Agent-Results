# ADR-001: Rust simulation core and native runtime

Status: Accepted for implementation by later tasks (TASK-001, cycle 1).

## Context

The same engine must support headless runs and an interactive UI, seeded replay,
complete checkpoints and eventually thousands of organisms. The measured target
is 100 ticks/s at 2,000 entities, not a performance result of this decision.
The contract requires offline execution and a self-contained Linux dist folder.

## Alternatives

| Option | Performance and development | Testability and distribution |
|---|---|---|
| Rust library and native application (chosen) | Predictable memory layout, no interpreter or garbage collector in the tick loop; ownership/type checking adds implementation effort | Unit, integration and seeded property tests; native static build can avoid target runtimes |
| Python with NumPy/native extensions | Fast iteration; vectorized climate is efficient, but individual behavioral loops may require compiled extensions | Excellent test tooling; bundling interpreter, extensions and shared libraries complicates runtime-free distribution |
| TypeScript on Node | Familiar application tooling and adequate small-world loops; allocation/GC can affect latency | Good test tooling; requires bundling Node and assets, or verifying a standalone executable packager |

## Decision

Use a Rust library for the core and a thin native CLI application. Pin dependencies
in Cargo.lock, version configuration/checkpoint schemas, and prefer maintained
pure-Rust serialization/hash/HTTP libraries. Build release binaries for benchmarks.
The core has no display, browser, server, wall-clock or network requirement.

Later packaging will target x86_64-unknown-linux-musl with static linking and
embedded UI assets. setup.sh must install/build missing prerequisites idempotently;
build.sh must produce dist/evosim. Record exact system installation commands in
STATE when needed. No toolchain installation is needed in this documentation task.
A glibc-linked host executable alone is not evidence of self-containment. Verify
ELF dependencies and execute a copied dist folder on a runtime-free Ubuntu target.
Ordinary UI use can require a browser; contract version/run cannot.

## Determinism and complete state

Use one engine-owned xoshiro256** generator, never Rust's default/randomized RNG.
Its four u64 words are checkpointed. The specified transition uses wrapping u64
arithmetic: result = rotl(s1*5,7)*9; t = s1<<17; s2 ^= s0; s3 ^= s1;
s1 ^= s2; s0 ^= s3; s2 ^= t; s3 = rotl(s3,45). Return result. Expand the seed
with four SplitMix64 outputs: add 0x9e3779b97f4a7c15, then xor-shift/multiply by
0xbf58476d1ce4e5b9 (shift 30), 0x94d049bb133111eb (shift 27), final xor shift 31.
Convert signed integer seeds modulo 2^64; preserve the original seed in results.
If expansion ever yields all-zero state, set s0=1. Store RNG/schema versions.
For uniform [0,n), n>0, reject u64 draws below (2^64 mod n), then use draw mod n;
implement the threshold with wrapping arithmetic. Probabilities use integer ratios.

One tick increments the absolute clock, updates climate/resources in row-major
order, executes plants, herbivores, carnivores, reproduction, then commits births,
death accounting and species extinction. Each action phase captures living IDs
and visits them in ascending order. Dead actors become inactive immediately;
newborns enter at commit and first act next tick. Movement and resource consumption
are visible immediately to later actors. Reproduction reserves energy/cooldowns
immediately. Candidate ties use distance then stable ID. Species ties use species
ID. All random draws follow this sequence; no parallel engine updates. Order bias
is an accepted simplification. Read-only queries must not consume random draws.

Avoid wall-clock inputs, runtime RNGs, unordered collection iteration, thread
scheduling and browser randomness. UI controls request whole ticks; renderer and
sampling frequency cannot affect biology. Floating periodic climate functions
permit minor cross-platform differences; same machine/build replay is required.

At completed ticks, canonical state includes effective config and initial counts,
clock, full RNG, organisms with genomes/parents/energy/cooldowns and life history,
climate/weather/resources, species history, next IDs and cumulative births/deaths.
No pending births remain at this boundary. Serialize versioned fields in fixed
schema order and records in ID order to a canonical byte encoding for SHA-256;
define byte widths, endianness and floating representation when implementing the
schema. Never hash arbitrary JSON formatting or unordered maps. The checkpoint
must encode all the same authoritative information. Spatial caches rebuild without
randomness and cannot change query ordering. Wall-clock measurements, output paths,
sample intervals and metrics buffers are observational and excluded. Resumed and
uninterrupted runs must hash identically.

## Consequences

Native loops and explicit state support the target but do not guarantee throughput.
Rust increases initial development cost; musl/dependency compatibility must be
verified. No language runtime needs shipping if static linkage succeeds. Versioned
schemas permit explicit rejection of unsupported checkpoints rather than silent
reinterpretation. All future-influencing fields must be added to both checkpoint
and hash boundaries when introduced.

## Verification strategy

Later tests must check known RNG vectors, bounded-sampling boundaries, state
restore, repeated seeds, differing seeds, stable actor ordering, no actions after
death, newborn timing, and checkpoint A+B equivalence including hashes. Exercise
CLI errors/status 2 without output files, headless operation without DISPLAY,
offline execution, static linkage and copied-dist execution. Measure release-mode
throughput with hardware/configuration disclosed. No executable tests or measured
performance exist in TASK-001; current checks inspect these decisions and scope.

## TASK-002 bootstrap validation

Static musl packaging is now implemented for version/help in TASK-002 cycle 1.
Cargo is the build tool; built-in Rust tests and Python stdlib process/packaging
tests run via test.sh. ELF inspection found no INTERP or NEEDED entries, and a
copied executable ran version in an empty chroot with no runtime/project files.
Setup installed musl prerequisites and built both targets from clean artifacts.
This refines the packaging implementation timing, preserving the decision above.
No fresh-container provisioning or future run portability is claimed; exact
commands, dependencies and test counts are in STATE and TASK-002 handoffs.

## TASK-005 PLAN cycle 1: scheduler and RNG API refinement

Planned implementation follows the specified xoshiro256**/SplitMix64 algorithm,
using the existing Seed::wrapping_u64 conversion and preserving the original
seed in effective configuration. A version-1 RngState record exports four u64
words; restoring rejects unsupported versions and all-zero state. below(bound)
uses rejection sampling; bound zero errors without draws, bound one draws once.
chance(n,d) validates d>0 and n<=d without draws on error, returns deterministic
endpoint probabilities without draws, and otherwise uses below(d)<n. No new
crate or system dependency. These are component APIs, not a checkpoint format.

Simulation will own Config, World (initially Topology only), u64 tick and one RNG.
advance_one_tick checks overflow before mutation, increments once, and dispatches
Clock, ClimateResources, Plants, Herbivores, Carnivores, Reproduction, Commit.
A fixed-size TickReport records actual completed stages, outside authoritative
state. Biological stages are empty until their owning tasks: no dummy draws,
placeholder organisms or climate raster. Initial counts are retained as config,
not instantiated here. Actor snapshots will be sorted/deduplicated by u64 ID;
actual lifecycle behavior remains TASK-008. Existing distance/ID and species-ID
tie rules remain binding. No dynamic scheduler, global RNG or UI dependency.

Planned validation: independently known RNG vectors, rejection/ratio boundaries,
version/all-zero rejection, exact raw/mixed-draw restoration, checked tick overflow,
phase sequence, sorted fixture IDs, read-only observation and 128-tick same/different
seed traces. Empty ticks retain RNG state; separate >=128-draw tests verify streams.
Seeds congruent modulo 2^64 intentionally share streams. No performance or full
checkpoint claim; detailed APIs/acceptance mapping are in TASK-005 plan-cycle1.md.
This refinement is planned, not implemented in this phase.


## TASK-005 IMPLEMENT cycle 1: frame evidence

The planned component APIs and draw semantics above are implemented without
algorithm or scheduling deviations. Rng::from_state validates version 1 and
nonzero words; state() returns the exact four-word value. Simulation exposes
read-only RNG state, not mutable RNG access. Its Config retains the full seed;
modulo-equivalent seeds intentionally share streams. Seven fixed dispatches
produce a by-value report; checked clock overflow is atomic. Biological phases
remain empty and consume no dummy draws. World owns geometry only.

Independent frozen integer vectors for 0, 42, -1 and raw [1,2,3,4], exact mixed
stream restoration over 1024 iterations, u128 rejection-reference sampling,
forced rejection, endpoint/error consumption, modulo-equivalent seeds, 128-draw
streams and 128-tick replay pass. Private tests exercise maximum clock and stable
sorted/deduplicated ID fixtures. Full suite: 34 tests, no skips, including static
musl/empty-root version regression. No UI/time/global RNG dependency, new crate
or system install. Actual actor/lifecycle, climate, checkpoint disk format,
throughput and complete hash equivalence remain later tasks. Evidence and the
independent vector derivation are persisted in TASK-005 implement-cycle1.md.

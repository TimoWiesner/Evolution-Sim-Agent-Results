# ADR-017: Deterministic batch orchestration and summary export

Status: Implemented in TASK-021 IMPLEMENT cycle 1; review remains harness-owned.

## Context and alternatives

Contract section 2 requires per-seed run JSON and summary.json. TASK-021 adds a
parameter matrix, final-population aggregates, extinction frequency and CSV.
Reuse the existing run execution path instead of invoking subprocesses or copying
the tick loop. Sequential execution keeps memory to one engine/result at a time
and avoids worker scheduling/resource complexity. Parallel independent engines
could be deterministic but are unnecessary for this scope. Repeated CLI sweep
flags with arbitrary Cartesian products add parsing and naming complexity; one
parameter with several values meets the requirement and can cover every numeric
configuration leaf except seed. JSON arrays preserve number types more reliably
than comma-separated float coercion.

## Command, validation and ordering

Implement:

`evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR [--sweep 'PATH=[VALUE,...]']`

All flags are separated option/value pairs, each at most once, any order. Four
contract flags are required. Ticks use run's digits-only u64 >=0 parser. Seed
list is nonempty, comma-separated, with no empty entries or whitespace; parse
with Seed::from_decimal, normalize decimal text, reject duplicates after
normalization (1 and 01, 0 and -0 collide). Preserve arbitrary signed magnitude
in numeric JSON and filenames; modulo-equivalent distinct seeds are allowed.
No --jobs, --csv, --sample-every, checkpoint or chart option is added. Each result
uses run's default sampling max(1,N/100) and metrics schema.

Optional --sweep is exactly one dotted existing numeric leaf `group.key` plus
`=` plus a nonempty JSON array of numeric values. Split once at `=`. Groups are
world, initial, climate, genetics, plants, animals; seed and objects are excluded.
Resolve against full exported Config JSON, replace only an existing numeric leaf,
then validate every variant through Config::from_json. This preserves integer
versus float acceptance/ranges and cross-field checks. Never invent paths or
silently add unknown keys. Reject duplicate effective values after validated
Config export (e.g. float 1 and 1.0); do not deduplicate silently. Fully validate
base input before any override and all variants before running/writing outputs.

Variant input order is outer, seed input order inner. No sweep is one implicit
variant and writes DIR/seed-<normalized-seed>.json exactly as the contract says.
With sweep, write DIR/variant-0/seed-<seed>.json, variant-1/... in zero-based
array order. This avoids parameter text in filenames and collisions. Summary
uses relative result paths, no absolute directories/config filename/timestamps.
Run IDs are zero-based global indices in that same order. Counts/cardinality and
allocation sizes use checked arithmetic and fallible reservation where feasible.
No arbitrary ecological or run-count cap is introduced.

## Shared interfaces and state boundary

Extract private cli::runner::simulate(Config,u64,u64)->Result<Value,String> from
run.rs; it performs the unchanged initialization, exact ticks, sampled metrics,
tick-call timing, hash and result mapping. run.rs keeps flag/config parsing and
publication. cli::output owns existing atomic regular-file destination checks
and publication helpers. cli::batch owns validation, variant expansion, sequential
calls, compact observations, summary aggregation, CSV and staged publication.
No batch module is exported by the library; no Simulation/config public API,
core import, authoritative field, RNG draw, model/default, hash schema, checkpoint
payload or dependency changes. Future checkpoints still follow ADR-015; batch
metadata, samples, summaries, filesystem paths and elapsed measurements are not
simulation state. Hashes must equal standalone run for every effective config.

## Summary schema 1 and arithmetic

summary.json root: batch_schema=1, contract=1, ticks=N, run_count=R,
sweep=null or {path,values:[effective values in input order]}, runs=[...],
aggregates={plants:...,herbivores:...,carnivores:...}.
Each runs record has run_id, variant_index (0 also without sweep), seed (exact
JSON integer), parameters (full effective configuration object EXCLUDING seed),
tick_start=0, tick_end=N, result_file (relative POSIX path), final (including
species, as in result), state_hash, extinct={plants:bool,...}. Effective defaults
in parameters make the record independently reproducible after defaults change.
Summary excludes timing entirely; per-run contract results retain timings.

Each kind aggregate has mean, min, max of final living count, extinction_count
and extinction_fraction. R is always >0. Keep final counts/min/max exact u128;
accumulate sum with checked u128 and return a descriptive error on overflow,
then compute mean=sum as f64 / R as f64. Fractions are extinction_count/R.
Means/fractions are finite f64 with documented integer precision loss above
2^53; extrema remain exact integers. No variance, per-variant aggregates or first
extinction tick is required. Extinct means final count==0, including initially
absent kinds and N0; absorbing zero makes this equal to zero at any completed
tick in this run. State this convention instead of calling initial absence a
new extinction event. Do not infer extinction from sparse sampled series.

CSV is always exported as DIR/summary.csv, requiring no new flag. It represents
ALL run records and all aggregates in a fixed long-form table. Exact column order:
row_type,run_id,variant_index,result_file,seed,parameters,tick_start,tick_end,
state_hash,kind,final_population,extinct,mean,min,max,extinction_count,
extinction_fraction,run_count.
Three run rows per run in plants/herbivores/carnivores order; repeat metadata,
compact full parameters JSON in one cell, integer final_population and boolean
extinct. Then three aggregate rows in kind order, aggregate columns populated,
run-specific columns empty. run_count is R in every row. CSV output uses UTF-8,
CRLF, a header, comma delimiter and RFC4180 escaping (quote fields containing
comma, quote, CR or LF, double interior quotes). Round-trip via Python csv and
json must recover every parameter/seed without float coercion. Generate CSV and
JSON from the same owned compact summary records, not by rereading result files.

## Publication and errors

Create out-dir and variant directories when absent; allow reruns into an existing
real directory, preserve unrelated files. Reject symlink/special output roots,
variant directories and expected destinations; reject config/output path alias.
Preflight all destination paths before expensive runs. Use a unique create_dir
staging directory INSIDE out-dir; write one complete per-run result there, retain
only compact summary records, and drop each full result/engine before next run.
Prepare summary CSV/JSON in staging after all runs. Execution/validation/staging
failure leaves existing published artifacts intact; clean only this invocation's
staging files. An empty created directory can remain on failure.

After successful staging, invalidate an existing summary.json immediately before
promotion, rename staged result files, then summary.csv, then summary.json LAST.
Recheck destinations before replacement. On returned promotion failure, ensure
no new completion summary exists and clean staging; some per-run files may have
been replaced (explicitly not a directory-wide atomic transaction). summary.json
is the completion marker. No crash-durable fsync or concurrent same-dir writers
supported. Stale unrelated/old-variant files may remain; consumers enumerate only
runs listed in summary. Every returned error is status2 with stderr, empty stdout;
no new summary on a fresh failed batch. Do not delete an old successful summary
for argument/config/staging failure. Document the limited promotion guarantee.

## Consequences and verification

No new crates or system packages; existing static-musl setup remains sufficient.
Time is sequential sum of runs, memory one engine/result plus O(R) compact records,
disk O(all per-run sampled results) and temporary disk approximately another
batch during reruns. Unbounded seed text may exceed filename limits and returns
I/O error; retain exact seed precision instead of truncating. Resource/OOM limits
and cross-build float differences remain. Test contract filenames, a real 2x2
matrix, standalone parity, independent exact aggregation/CSV round trips,
repeat summaries in both fresh/same output dirs, extinction conventions and all
validation/publication failures. Full ordered work and acceptance commands are in
TASK-021 handoffs/plan-cycle1.md. Implementation evidence is recorded in TASK-021 implementation handoffs.

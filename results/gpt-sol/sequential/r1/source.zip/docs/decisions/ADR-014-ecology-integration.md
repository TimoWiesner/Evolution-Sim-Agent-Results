# ADR-014: Integrated ecology, absorbing extinction and measured defaults

Status: Implemented in TASK-018 IMPLEMENT cycle 1. Planning rationale retained below;
final selected defaults and measured evidence follow.

## Context and alternatives

TASK-012/014/015/016/017 already join production ecology through Simulation.
TASK-018 needs integrated evidence, default-parameter viability and a reproducible
five-seed 10,000-tick report. CLI run belongs to TASK-019. Preserve the Rust core,
spatial lookup and DNA choices in ADR-001/003/004.

Retain the deterministic sequential scheduler rather than simultaneous actions
(which would change budgets, targeting and RNG semantics). Prefer existing local
mechanisms and measured configuration tuning over new ecological state. Global
count-based birth/death protection, replenishment and artificial immortality are
forbidden. Handling timers, cover, seed banks and new movement/mating policies
are unnecessary unless concrete acceptance failure shows existing mechanisms and
configuration cannot suffice; document a justified amendment before such work.

## Decision: order and state boundary

Preserve Clock -> ClimateResources -> Plants -> Herbivores -> Carnivores ->
Reproduction -> Commit. Clock increments once; weather precedes row-major resource
regeneration. Each action kind snapshots ascending living IDs, ages/expires first,
then performs its current physiology and actions. Immediate deaths remove records,
spatial entries and species membership before subsequent actors; accounting is
finalized at Commit, not by a second mortality sweep. Reproduction visits plants,
herbivores, carnivores without aging again, reserving paid costs/cooldowns now.
Commit sorts captured births, allocates IDs, assigns species/inserts newborns,
commits death totals/history and finally marks species extinction. Newborns first
act next tick. Existing accepted offspring survive later parent death. See prior
ADRs for exact gates and RNG draws; no extra trial or engine RNG is introduced.

Absorbing extinction is asserted at completed ticks: no pending births remain,
and future births require living parents of that same kind. Observational
extinction reporting may count populations; ecological behavior may not use that
report or global kind/species counts to affect life. There is no early return
when the world becomes empty: climate/resources/clock continue to the requested tick.

## Decision: default balancing and stabilising mechanisms

Use existing defaults as the first candidate, not as already proven viable:
plant capacity100, regeneration1, efficiency0.5, cost20, dispersal3; animal
movement0.2, basal0.1, per-parent cost30, cooldown20. Keep climate/genetics and
founder DNA/placement unchanged initially. Select the first minimally changed
candidate that passes the explicit 1000/600-tick acceptance fixtures in the plan.
If necessary first try plant regeneration2 then4, efficiency0.75 then1; then
animal movement0.1 then0.05 and reproduction cost20, cooldown40. Change one
parameter family at a time and record measured before/after outcomes, exact
values and rejected candidates. These are bounded experiment candidates, not a
mandatory exhaustive grid or approved claim of survival. Any different value
needs the same measured justification. Final defaults must be centralized in
config.rs, exported by omitted-option configs and documented consistently;
scenario-only overrides cannot satisfy default viability.

Existing mechanisms: bounded precipitation-dependent renewable cell resources
(primary-production inflow), local competition/one-plant recruitment sites,
climate heterogeneity and finite lives, bounded reserves, paid movement/upkeep,
capacity-limited grazing, one paid stochastic hunt per predator/tick, and paid
local mating with maturity/cooldown. These apply uniformly at all populations;
none creates energy or organisms from global scarcity. Full initial reserves
are finite initial conditions; tests beyond founder lifespan distinguish renewal
from spending founders alone. No all-kind coexistence guarantee is required.

## Consequences and verification

No new authoritative state or dependency is planned. A library-driven example
runner observes population counts and reports first completed-tick zero (tick0
if initially absent), survival at the horizon, final counts, births/deaths,
coexistence duration and elapsed time. It never feeds observations to the engine.
Preserve complete future checkpoint/hash boundary including cooldown/species
history; observational report buffers/timings are excluded. Runtime cost remains
existing O(area) updates plus entity/local-query/history work. Dense mate stacks,
lifetime histories and stable-ID bias may matter in long runs; measure release
mode and keep time for tests/handoff. Performance goals remain later work.

Required new integration evidence and exact runner command/schema, bounded
balancing process, per-tick conservation, absorbing-zero checks, species oracles
and replay are specified in tasks/TASK-018/handoffs/plan-cycle1.md. Record all five
full 10,000-tick outcomes even when collapse occurs; truncated runs are incomplete.

## Implementation and measured amendment

Production already performed all seven phases; no dispatcher/lifecycle rewrite
was needed. Added tests/ecology_integration.rs and examples/ecology_report.rs with
shared read-only examples/support/ecology.rs. No core module, authoritative state,
config key, model equation, RNG draw policy or dependency was added. Future
checkpoint/hash retains complete existing state and effective tuned settings;
observer first-zero arrays/timings remain outside Simulation.

Selected default resource regeneration 2 (was 1), animal cooldown 100 (was 20).
All other defaults unchanged. Candidate0 isolated plants fail seeds0/42 before2200;
regeneration2 resolves isolated replacement. Regeneration4 and efficiency0.75/1
still lose plants in the abundant-food600 fixture. Returning to regeneration2,
cooldown40 then80 delay overgrazing but still fail that fixture. Extending the
planned candidate cooldown40 to100 is justified by those measurements: it slows
local paid recruitment uniformly without global-count feedback or a new policy.
No movement/reproduction-cost reduction or initial-genome manipulation was needed.
69 exploratory runs with complete configurations are in balancing-cycle1.json;
final three-seed tests verify continuous2200/600 survival, late recruitment,
per-tick ledgers/species, final extinctions and default1000-tick full-state replay.

All five final mixed-default10000-tick runs complete. Plants survive all seeds;
herbivores extinct at22..27, carnivores857..875. These are measured collapses,
not failures or a coexistence claim. docs/ECOLOGY.md documents the exact command,
schema, tick order, tables, mechanisms and limits; task-local raw ecology-cycle1.json
is retained. Application CLI, UI, persistence and broad balancing remain later tasks.


TASK-027 amendment: numeric defaults above remain unchanged. A local predator
satiety policy is retained as hunting identity2 (ADR-020); it rests after upkeep
at own energy>=750 and leaves all other phases/payment/spawn rules unchanged.
Full measured outcomes and unsuccessful500 trial are in BALANCE.md. Observation
remains external; no new authoritative field or population-dependent feedback.

# ADR-010: Trait-limited animal sensing and paid cell movement

Status: Implemented in TASK-013 IMPLEMENT cycle 1.

## Context and alternatives

ADR-003 supplies inclusive toroidal Chebyshev sensing and eight-neighbor movement;
Population already maintains its spatial cache for adjacent moves. Animal phase
hooks currently only age. Feeding, attacks and mating belong to TASK-014..016.
Continuous velocities would conflict with the cell model. Collision exclusion
would conflict with existing stacked founders and mixed-kind establishment.
Persistent headings add checkpoint state without a requirement. Use local indexed
sensing, shortest discrete pursuit, unrestricted co-occupancy and stateless random
exploration instead. No dependency or configuration/default changes are needed.

## Decision: model 1

All kinds may share a cell with any number of organisms. Initialization, internal
movement and committed births have no universal occupancy cap. Plant reproduction's
local rejection of an already planted/reserved site remains an establishment rule,
not a general cell capacity: existing plant stacks are valid. Animal movement must
never block on occupants, and future animal births retain this rule.

Population::sense(observer: OrganismId) -> Option<Vec<OrganismId>> is public and
observational. Missing/dead observers and plants return None; a living animal
returns Some (possibly empty). It calls nearby at the observer's position with
its genome-derived vision as inclusive Chebyshev radius, all kinds, excluding
only the observer ID. Results remain ascending IDs; no occlusion, random draws,
global scans or state changes. Co-located organisms are visible.

During each kind's existing walker, age/expiry precedes movement. An animal senses
once at its action start. Herbivores select the nearest visible plant, carnivores
the nearest visible herbivore, using (toroidal distance, ID) ascending. No target
eligibility by energy/health is needed beyond being living. This is navigation
only. Keep the selected target cell for this action; single-owner execution means
other actors do not move during its steps. At distance zero stop with no movement
charge or random draw. Future ecology may replace target selection while reusing
sensing and movement helpers.

A tick grants at most traits.speed() adjacent steps (1..4). Each pursuit step
uses signum of each component of Topology::displacement(current,target), wrapped
through Topology::cell. Each decreases Chebyshev distance by exactly one. Positive
half-axis ties retain ADR-003. Stop at the target or exhausted step budget; never
teleport and never charge a same-cell step.

Without a visible target, explore: for each affordable step, enumerate unique
radius-one cells, exclude the origin, sort by (y,x), then choose one with the
engine RNG's below(count). No persistent direction or separate RNG. At most eight
candidates, independent of world size. 1x1 has none: no movement, cost or draw.
Recompute neighbors after each step; revisiting a cell is allowed and still costs
energy. Draw even for one available neighbor, matching below(1) semantics. A
visible co-located food target means stay, rather than switch to exploration.

Per actual step charge c = animals.movement_cost() * speed * metabolic_multiplier.
For positive configured cost, higher speed costs more per step at equal metabolism;
d total steps costs d*c. Zero configured movement cost explicitly disables charges.
All operands are validated/bounded (c <= 8,000,000), hence finite. If energy < c,
stop before choosing a random destination or moving. Otherwise relocate through
Population::move_one_step, then debit c with change_energy. Exact exhaustion kills
immediately by Starvation; stop if removed. This charges completed steps only,
never permits an unpaid step, and updates/removes the index before the next query.
Stationary/blocked-by-energy animals pay no movement cost. Basal maintenance,
climate effects and consumption remain later tasks; immobile animals can currently
survive until lifespan expiry. Never infer survival decisions from global counts.

## Boundaries, consequences and verification

Private ecology/animals.rs contains pure next_toward(Topology,Cell,Cell)->Option<Cell>,
step_cost(Traits,&AnimalConfig)->f64 and wander_step(Topology,Cell,&mut Rng)->Option<Cell>.
It imports config/traits/topology/rng only. Population owns sensing and mutations;
Simulation owns action orchestration, target ranking and engine RNG. No reverse
Population/Simulation imports into ecology and no public mutation escape.

Sensing costs the existing bounded-radius query plus sorting and map lookups;
at most four movement updates per animal. Dense buckets, query allocations,
crowded cells and death-history storage retain existing costs. No throughput or
coexistence claim. Random walks can double back, and stable scheduling favors
earlier actors. Later feeding/hunting may revise navigation intentionally.

No new authoritative state: future checkpoint/hash already needs positions,
vitals, DNA, effective settings and full RNG; additionally record movement model
identity. Derived cache is rebuilt, never hashed. Temporary targets/neighbor lists
are absent at completed tick boundaries. Model changes alter deterministic traces.

Tests must exercise production animal ticks and per-step cache visibility, not
only geometry helpers. Include independent exhaustive small-torus shortest-path
oracles, trait vision/speed endpoints, all seams/corners/degenerate axes, costs,
energy thresholds/death accounting, co-occupancy, deterministic draw ordering,
liveness/newborn timing and multi-seed replay. Detailed matrix and fixture migration
are in tasks/TASK-013/handoffs/plan-cycle1.md.

Implementation evidence: src/ecology/animals.rs, Population::sense and the shared
Simulation animal executor implement model 1 without new authoritative state.
Tests include exhaustive geometry, per-step cache/energy checks, real production
ticks, full engine RNG phase order and four-seed 2200-tick replay. See ANIMALS.md
and TASK-013 implementation handoffs for commands, outcomes and fixture changes.


TASK-014 refinement: ADR-011 supersedes herbivore target eligibility and stopping
radius: pay current-climate basal maintenance, filter risky food using visible
predators and inherited risk tolerance, stop within reach 1, then take a bounded
plant-backed bite. Geometry, paid per-step execution, sensing, exploration and
carnivore radius-0 behavior remain as specified above.


TASK-015 refinement: implemented ADR-012 supersedes carnivore navigation-only
behavior with identical shared thermal upkeep, radius-1 paid pursuit and one paid
stochastic herbivore attack. Existing movement geometry/execution and herbivore
policy remain unchanged. See ANIMALS.md and TASK-015 implementation evidence.

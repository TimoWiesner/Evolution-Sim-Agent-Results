# ADR-012: Paid stochastic carnivore hunts

Status: Implemented in TASK-015 IMPLEMENT cycle 1.

## Context and alternatives

TASK-015 requires local pursuit, stochastic trait-dependent kills, conservative
nutrition and starvation. Reuse the existing single-owner age-first walker,
indexed sense, paid movement and Population kill/energy primitives. Deterministic
strength comparisons would omit chance; repeated hit-point combat adds injury
state and tuning without a requirement. Choose one probabilistic lethal attack
per active carnivore per tick. Persistent handling timers, corpses, cover and
territories are deferred; a one-attempt limit bounds instantaneous consumption.
No reproduction, config/default/schema change or additional dependency.

## Decision: hunting model 1

After shared age/expiry, debit the same thermal maintenance equation as grazing:
max(animals.basal_cost,1e-9) * metabolism * (1+stress), where
stress=clamp(abs(current_temperature-preferred_temperature)/climate_tolerance-1,0,1).
Use the existing pure herbivores::maintenance helper from Simulation (shared
physiology despite its historical module name), with current temperature at the
starting cell. If this kills the predator, return before sensing or RNG. This
uniform cost applies even in 1x1 worlds, at zero movement cost and without prey.
Old age retains priority; starvation need not precede old age at tiny basal costs.
A high-enough basal-cost controlled fixture must demonstrate actual Starvation.

Sense once; retain only living herbivores. Choose minimum (wrapped Chebyshev
distance, ID), retaining both ID and cell. Pursue through the existing executor,
with inherited speed, existing per-step charge and stopping radius 1 (supersedes
ADR-010's carnivore radius 0). No prey means existing paid random exploration,
with no opportunistic attacks against newly discovered prey this tick. Recheck
predator/prey liveness, prey kind and actual distance <=1 after movement. Same
cell and all eight neighbors, including wrapping seams, are attack reach.

At most one attack attempt, against that selected prey only. Attack cost is
0.5 * predator.metabolic_multiplier (0.25..1 units), separate from maintenance
and actual movement costs. If remaining energy < cost, return without attack,
debit or trial; upkeep was still paid. Otherwise debit cost via change_energy.
Exact exhaustion kills by Starvation and returns before trial or prey removal.
Both successful and failed completed attacks pay the identical positive cost.
No retries, retargeting or free trial on unaffordable attempts.

For living predator C and prey H after the cost, let
A = C.strength * (1 + C.aggression) * (C.health / C.max_health),
D = H.strength * (1 + H.speed / 4) * (H.health / H.max_health).
Set p=clamp(A/(A+D),0.1,0.9), n=floor(p*1_000_000) as u64.
Trial is engine_rng.chance(n,1_000_000). Both scores are positive finite for
living valid animals; p is always interior. Exactly one bounded trial per paid,
surviving in-reach attempt (below may reject raw draws). No trial on failed gates,
no pursuit draw; wander draws retain their current semantics. Weather precedes
herbivore exploration, then carnivore exploration/trials in ID order, then plant
reproduction draws. Failure leaves prey energy, health, position and identity
unchanged; escape means survival of this attack, without an extra escape move.
Strength/health of both, predator aggression and prey speed affect odds; no
count-based rescue, guaranteed kill, global census or separate RNG.

On success snapshot prey energy P immediately before kill. Call
Population::kill(prey_id,tick,Predation), never energy-deplete the prey first.
Only a true return funds nutrition: delta=min(0.8*P,1000-C.energy). The remaining
prey energy dissipates; no corpse, health/biomass payout or resource withdrawal.
Guard floating arithmetic conservatively: predict the same capped addition as
Population::change_energy; if its realized gain would exceed P, credit zero.
Otherwise apply delta through change_energy. This handles tiny/subnormal P and
near-capacity rounding without creating an ulp of energy. Actual gain is >=0
and <=P, including saturation; a failed/duplicate kill credits nothing.

Predators execute sequentially by ascending ID. Immediate prey removal updates
the spatial index before the next predator senses; later predators select from
remaining live prey (or explore). Failed hunts leave prey available to later
predators. Each predator gets only its own one attempt; a prey ID can fund only
one kill. Death history/cause totals commit exactly once by existing lifecycle.
Herbivores already acted this tick, so prey's available energy includes this
tick's grazing/upkeep/movement. No roll back of that prior action.

## Boundaries, consequences and verification

New private ecology/carnivores.rs contains pure attack_cost(Traits)->f64,
kill_probability_numerator(Traits,f64,Traits,f64)->u64 and
nutrition_credit(prey_energy,predator_energy)->f64. It imports traits only;
constants define model units/efficiency/denominator. Simulation orchestrates the
trial and all mutation. No Population/Simulation reverse imports. Existing shared
movement remains the sole executor, with its actual per-step observer retained.
No new authoritative state or public mutation API. Targets/budgets vanish after
action; future checkpoint/hash must encode hunting model identity and full existing
RNG, DNA, vitals, positions, climate/resources, effective settings and lifecycle
records, rebuilding/excluding spatial cache. No new checkpoint format here.

Stable-ID competition favors early predators; failed hunts may expose prey to
multiple attackers in a tick. High default founder energy can cause an initial
predation burst; no coexistence target or performance success is claimed. Query
cost remains indexed local perception plus map lookups, at most four moves and
one trial; death history retains its existing lifetime cost. Model changes alter
RNG traces; migrate old no-hunting fixtures while retaining their original purpose.
See task-local plan for real-tick, many-attack, numeric and regression tests.


## Implementation refinement and evidence

The approved formula/gates/competition model is implemented. One numerical
refinement: if both positive-health scores underflow to zero, recompute after
dividing both health inputs by their common maximum. This cancels in A/(A+D),
avoids NaN and preserves interior odds for valid subnormal vitals. A unit test
covers the minimum positive health case. Nutrition guards the realized capped
addition exactly as planned. No authoritative state or dependency is added.
Real phase/action tests, public tick tests and full regressions are recorded in
TASK-015 implementation handoffs; ANIMALS.md describes current behavior.


## TASK-027 measured amendment: hunting model2

Retain the local750-energy satiety gate after upkeep/liveness. At/above threshold
the action rests without sensing/movement/attack/action RNG; age, maintenance,
expiry and independent paid mating continue. Below threshold all model1 equations
are unchanged. Gate reads only existing own energy. No new field/state/config or
global counts; model2 shared identity is written/read in canonical state. Old
model1 checkpoints are rejected. State schema1/envelope1 and inventory unchanged.
Two threshold trials and held-out selection are documented in ADR-020/BALANCE.md.
First-extinction delay improves but plant collapse replaces early prey collapse.

# ADR-002: Embedded local browser interface

Status: Implemented through TASK-025 IMPLEMENT cycle1; original choice TASK-001.

## Context

The UI needs a climate map, distinct entities, navigation, simulation controls,
inspection, configuration, persistence and charts. It must use the headless engine
and support unattended smoke tests and screenshots from the real interface.

## Alternatives

| Option | Performance and testability | Distribution implications |
|---|---|---|
| Local HTML/Canvas and plain JavaScript (chosen) | Canvas suits raster cells and thousands of markers; browser automation tests the actual controls | Embed assets in Rust; ordinary UI needs an installed browser, headless commands do not |
| Native Rust egui | Efficient immediate-mode UI and direct Rust integration; desktop automation requires display/input tooling | Avoids browser protocol, but windowing/graphics libraries and Linux display setup require packaging verification |
| Qt/PySide desktop | Mature widgets/charts and GUI test tools; interpreter/Qt overhead acceptable for a separate renderer | Large Python/Qt/plugin bundle and system graphics dependencies complicate self-contained distribution |

## Decision

Use a loopback HTTP server in the native application, serving embedded HTML, CSS
and plain JavaScript without CDN, external fonts, npm runtime or network services.
Render the world on Canvas and use HTML controls/charts. The server owns exactly
one Rust Simulation and serializes mutating commands. The browser submits typed
commands (create/reset, step/run/pause, speed, config and checkpoint actions) and
receives read-only snapshots/inspection data. Validate commands before mutation.
Exact endpoints and controls belong to later UI tasks, not this ADR.

Dependency direction is UI/server -> public engine API; core -> UI is forbidden.
The browser never runs a second biology model. Frame timing controls how many whole
ticks are requested, not tick rules or RNG. Snapshot polling and pan/zoom do not
advance time or consume randomness. Keep rendering separate from engine work;
batch snapshots if necessary to avoid serializing the entire world every frame.
A single owner prevents racing run/step/reset/load commands. Bound the server to
loopback and keep its lifecycle under the launcher.

## Consequences

Browser layout and Canvas simplify a portable interface with testable controls.
Serialization/rendering cost and command orchestration require integration work;
measure frame responsiveness separately from headless ticks/s. No UI library or
JavaScript runtime is needed by version/run. Embedded assets travel with the static
dist executable and work offline. Ordinary UI on a distribution host needs a
browser; the contract guarantees runtime-free version/run, not a bundled browser.
Smoke/screenshot automation may use the benchmark-provided Chromium. Any additional
automation dependency must be installed by setup.sh and documented, never assumed.
No synthetic image generator may substitute for the actual UI.

## Verification strategy

Later UI automation must launch the real server and browser, create a world through
the interface, advance >=10 ticks, render a frame and terminate within 60 seconds
for smoke. Screenshots must advance >=100 ticks, capture the complete actual main
view to main.png at >=1280x720 within 120 seconds, then shut down and reap children.
Check control behavior, inspect/pan/zoom, configuration and checkpoint round trips,
no external network assets, and equivalent headless/UI state after equal explicit
ticks. Test startup/error cleanup and headless commands with no browser or display.
TASK-001 records this strategy only; no UI or automation has been built.


## TASK-023 PLAN cycle 1 refinement (not implemented)

Keep the embedded Canvas/plain-JavaScript choice. tiny_http 0.12 will serve fixed
embedded assets on an ephemeral loopback port. One UiSession owns Simulation,
serializes HTTP work and whole ticks at an advisory20Hz; read-only snapshots poll
at10Hz. Cache the engine's complete row-major static biome layer; stable-ID frame
records carry living kind/position without DNA/history. Exact IDs/ticks/counts use
decimal strings for JavaScript precision. Camera transforms and all UI buffers,
capability tokens, wall clocks and process state remain outside canonical state.
No core->UI import or model/schema/config change. Single finite map rectangle,
fit/drag/cursor-anchored zoom and distinct green plant discs, ivory herbivore
circles and coral predator triangles, with a full biome/organism legend.

Normal ui serves and prints a local URL; no desktop opener required. Ready after
initial draw starts scheduling. TASK-024 controls/inspection and TASK-025 editing/
charts remain deferred. Automation uses embedded Node>=18 built-ins and Chromium
CDP remote-debugging-pipe, with actual page readiness/render assertions, fixed
10/100 target ticks,45/105s internal deadlines and child/profile cleanup. Capture
real1440x900 main.png using Page.captureScreenshot. Node is automation-only;
version/run retain zero runtime/browser dependency. Existing benchmark Chromium,
Node and xvfb-run are present; no installation or UI success claimed in PLAN.
Alternative headless DOM dumps lack robust render/input checks; adding npm browser
frameworks adds dependency installation, so use direct pipe CDP. Native desktop
remains rejected for the original packaging reasons. Verify tiny_http on musl,
actual browser responsiveness with sustained1000 organisms, real navigation,
engine hashes and shutdown errors before claiming acceptance. Full interfaces,
ordered files, acceptance matrix and resource limits: TASK-023 plan-cycle1.md.


## TASK-023 IMPLEMENT cycle 1 refinement

The planned tiny_http/embedded Canvas/Node CDP design is implemented. The UI owns
one unmodified public Simulation and cached biome/living frame DTOs, with no new
authoritative state or reverse core import. Shapes use fixed per-kind in-cell
offsets; same-cell stacks have a count badge at close zoom. Normal startup prints
the complete capability-fragment URL and waits for the first page draw before
starting20Hz ticks. Automation stops at exactly10/100 production ticks and asserts
real rendering before optional1440x900 capture. IDs/ticks/counts remain decimal
strings. Navigation transforms are browser-only and tested with actual CDP inputs.

Implementation refinement: four I/O workers plus a bounded four-response queue
serve owned response bytes outside the engine loop; slow response writes cannot
block ticks or parent deadlines. Engine mutation remains single-owner. Private
snapshot tests live next to their private builders rather than exposing an API
solely for tests/ui.rs. Camera assertions use Node stdlib, real browser/CLI tests
use Python stdlib, and direct CDP helper reuse supplies navigation/throughput tests.
No npm framework or system package installation was needed. A Chromium shutdown
profile race found by tests was fixed with exit waiting/retries and parent-owned
profile cleanup. Final measured results and limitations live in task handoffs;
no general hardware/frame-rate guarantee follows. No simulation controls or
inspection/config/chart interfaces were added in this task.

## TASK-024 PLAN cycle 1 refinement (not implemented)

Extend the existing single-owner embedded browser adapter with a private tested
UiSession. Visible Run/Pause/Step/Reset buttons and closed Slow5/Normal20/Fast60
speed choices steer whole production ticks. Step pauses and advances exactly one;
reset pauses at0 using current effective config/seed, including a loaded state's
config. Successful load pauses at its saved tick. First ready retains auto-run;
no catch-up bursts or changes to core ecology/RNG. UI-only epoch/revision strings
order replies across backward ticks and world replacement. No authoritative field,
core dependency, config/default, canonical/hash/checkpoint schema or crate change.

Inspector follows a selected stable living ID, with same-cell chooser for hidden
occupants, live values and terminal death feedback retaining a labelled last-seen
DTO. Show all twelve named expressed traits and exact decimal u16 genome loci,
ID/kind/species/age/energy/health and parent IDs; founders explicitly have none.
Use buttons without extra keyboard shortcuts. Alternatives of symbolic genome
art alone or position-based selection lose exact data/identity; retain named
values and stable IDs. Selection/camera/control/scheduling remain observational.

Use browser .evo download and file-input binary upload with existing persistence
byte APIs, avoiding server path input or a second codec. Upload cap64MiB is an
explicit UI transport limit, not a CLI/state validity cap. Authenticated bounded
body readers pass owned bytes to the sole owner; no socket body read may block
engine scheduling/deadline checks. Decode/build replacement world cache before
swapping; invalid input preserves state. All mutations check Host/Origin/capability
and epoch. Loopback adapter is not a public service; slow clients can occupy bounded
workers and codec work can delay rendering. Save is observational; downloaded disk
completion belongs to the browser. Existing CLI file path semantics are unchanged.

Detailed private interfaces, routes/schema2, ordered files, test oracles, risks
and resource limits: tasks/TASK-024/handoffs/plan-cycle1.md. IMPLEMENT must prove
no-display transitions/HTTP tests, true browser controls/selection/death/file I/O,
CLI continuation parity, replacement ordering, slow-upload isolation and preserved
10/100-tick real smoke/screenshots. No feature or browser success claimed in PLAN.


TASK-024 IMPLEMENT cycle 1: private ui_server/session.rs owns Simulation plus
observational ready/running/Slow5-Normal20-Fast60 speed, explicit-duration scheduler,
epoch/revision and one selected live/terminal inspector. Step pauses+one tick;
reset/current effective config and checkpoint load pause and replace cached world.
Snapshot schema2 exposes exact decimal identities/ticks and all12 named traits/
u16 alleles/parents. Browser uses buttons (no new shortcuts), stable-ID complete
cell chooser, drag threshold, selected-cell highlight, independently scrollable
inspector preserving scroll, last-observed death data and matching epoch/revision
rendering. Browser .evo downloads and file-input uploads reuse persistence bytes.
Two bounded ingress workers isolate socket reads and reject stale completion;
64MiB UI upload cap; synchronous codec/cache work can delay owner responsiveness.
No core/authoritative/config/default/ecology/dependency/canonical/checkpoint schema
change; all application fields remain outside hash/codec. docs/UI.md records final
routes/semantics/precision/resource bounds. No system dependency installed; existing
STATE prerequisite install commands remain binding. Exact commands/results and
phase decisions/limits live in TASK-024 implementation handoffs. Harness owns
review, commits, state and transition; no other phase started.

## TASK-025 PLAN cycle 1 refinement (not implemented)

Extend the existing private UI adapter with an experiment editor and five Canvas
charts, reusing Config presets/validation and metrics::Snapshot. Edit all21 numeric
configuration leaves; keep browser draft strings and Rust-provided canonical JSON
text/field tokens to preserve arbitrary seeds/u64s/f64 round trips. Import/export
validate draft without changing active world. Start constructs a replacement then
pauses at0; reset still uses active effective config. Existing baseline/seasonal/
plant-only presets suffice; no simulation/default/config-schema change.

Own Canvas line/bar drawing avoids new offline dependencies; pure geometry/token
modules run under Node without display. Charts show per-kind population, cumulative
births/deaths, living species, selected expressed-trait mean and current selectable
trait distribution (all12 traits,20 fixed-domain bins per kind). Axis labels/legends
are explicit; empty means are gaps. UiSession owns a2048-point history at10-tick
spacing plus provisional current point; reset/start/load restart history at actual
tick. Cache current metrics/histograms by epoch/tick. All histories/DTOs/caches/drafts
remain observational, excluded from canonical/hash/checkpoint inventory.

Bounded ingress adds JSON validation/start jobs (1MiB UI limit) with operation and
epoch guards; engine owner never reads socket bodies. Configuration errors retain
dotted paths for adjacent field/group feedback. Browser serializes commands and
guards draft generations; exact labels use decimal strings, plot coordinates may
approximate huge counts. Existing checkpoint64MiB and security/deadline behavior
remain. UI schema3 and chart_schema1 are private adapter versions only. No new core
API/dependency/model identity or CLI metrics/result schema change. Tradeoffs include
bounded visible history, extra snapshot/serialization cost and large valid world
allocation risk. Detailed ordered paths/interfaces/tests: TASK-025 plan-cycle1.md.
IMPLEMENT must prove display-free data/config logic, actual browser file round trip,
validation rollback, live plots/distribution and main/charts screenshots. No feature
or browser success is claimed here.

## TASK-025 IMPLEMENT cycle1 refinement

Implemented experiment drafts and five own-Canvas charts as planned, without
additional packages. Configuration edits all21 existing numeric leaves, and raw
JSON/Rust field-token descriptions preserve signed-seed/u64/f64 precision across
import/export. Validated replacement pauses at0; reset uses active effective config.
Operation-tagged bounded ingress retains off-owner socket reads and stale completion
checks. History samples absolute ten-tick boundaries, keeps2048 stored points plus
current, and restarts on reset/start/load. Cached current histograms cover all12
expressed traits in20 fixed bins per kind. Immutable metrics supplies the matching
counts/counters/species/means, with no new authoritative or persisted fields.

Implementation refinements: use existing explicit serde_json::Value DTO convention
in these private UI builders rather than adding serialization structs; typed
Config/Snapshot remain authoritative inputs. Fields' labels/grammar live in the
pure browser module and descriptor/export coverage is tested across Rust and Node.
No need for a separately routed charts endpoint at the existing1000-organism test
scale; full bounded history travels in each frame. At maximum window this has
higher serialization/bandwidth cost; document it rather than claim universal rates.
Browser locks form inputs/actions for requests in addition to generation/epoch
guards. Test and screenshot evidence are in TASK-025 implementation handoffs.

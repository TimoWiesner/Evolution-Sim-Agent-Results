# ADR-004: Bounded haploid loci and immutable founder species

Status: Genetics implemented in TASK-009, species implemented in TASK-017.
Original decision accepted in TASK-001 cycle 1.

## Context

Plants must inherit/mutate DNA; animals require two-parent sexual reproduction
and heritable behavior. An explicit stable classification must allow emergent
species without population rescue. Representation must be cheap, serializable
and reproducible, while acknowledging simplified biology.

## Alternatives

| Option | Performance and testability | Distribution implications |
|---|---|---|
| Fixed ordered u16 numeric loci (chosen) | O(L) inheritance/mutation/distance; bounded values and exact threshold tests | Portable versioned integer records, no external runtime |
| Variable instruction genomes | Expressive evolving behavior; harder to bound execution and crossover validity | Requires an interpreter in the binary and additional checkpoint/version tests |
| Packed bitstrings | Compact, easy bitwise mutation; numeric trait mapping can be discontinuous | No runtime dependency, but encoding/bit-order/versioning need care |

For species, alternatives are mutable cluster centroids (can drift and relabel),
connected genetic-distance components (transitive chaining and global recompute),
and immutable founder exemplars (chosen for stable historical identities).

## Decision: representation and traits

Use a haploid [u16; 12], allele domain 0..65535 and schema version 1. Locus order
and phenotype bounds are fixed below; interpolate linearly from lower to upper
bound using allele/65535. Discrete traits use floor of the scaled span. Climate
units are model-normalized, not a claim of physiological measurement.

| Index | Trait | Phenotype range |
|---|---|---|
| 0 | speed budget | 1..4 cells per active tick |
| 1 | strength | 1..10 model units |
| 2 | maximum health | 10..100 units |
| 3 | lifespan | 200..2000 ticks |
| 4 | fertility propensity | 0..1 |
| 5 | vision radius | 1..8 cells |
| 6 | metabolic cost multiplier | 0.5..2 |
| 7 | preferred temperature | 0..1 |
| 8 | preferred moisture | 0..1 |
| 9 | climate tolerance width | 0.05..0.5 |
| 10 | aggression | 0..1 |
| 11 | risk tolerance | 0..1 |

Every kind stores the full genome; plant speed/aggression can be inactive while
climate, growth/metabolism, health, lifespan and fertility affect plant ecology.
Ecology tasks define energy/resource equations and costs; these bounds are design
defaults, not measured tuning or permission for unlimited energy. Animals remain
sexual despite haploidy, an intentional simplification rather than diploid genetics.

## Inheritance and mutation

Plants copy one living parent's alleles and mutate. Animals require two different
living parents of the same kind, within compatibility distance <=1/5, plus local
contact, energy, maturity and cooldown conditions defined by ecology. Different
species may interbreed if compatible. Sample a crossover boundary uniformly from
1..L-1 inclusive and an unbiased orientation bit; nonempty prefix and suffix come
from different parents. Then independently mutate each locus with default
probability 1/100, using a uniform signed nonzero step from -1024..-1 or 1..1024,
and clamp to 0..65535. These mutation rate/step limits may be configurable later
and must be validated/recorded in effective config and checkpoint. All sampling
uses ADR-001 integer RNG; a selected mutation can leave a boundary allele unchanged
after clamping. No mutation is forced merely to produce a new species.

Record one plant parent or both animal parent IDs (stable order), and generation
parent+1 for plants or max(parent generations)+1 for animals. Initial organisms
have generation 0 and no parents. IDs and births are committed in deterministic
parent/phase order. Reproduction is the only post-initialization organism source.

## Species criterion

For genomes a,b let S=sum(abs(a[i]-b[i])) and D=S/(12*65535). All loci have equal
weight, including inactive loci, so this is explicitly operational genetic
classification rather than a claim of biological reproductive isolation. Compare
thresholds using integer cross multiplication, not floating epsilon: species
threshold D<=1/10, mating compatibility D<=1/5, both inclusive.

A species stores immutable founder DNA, kind, monotonic ID, deterministic name
(kind-ID), origin tick, parent species and eventual extinction tick. At birth,
choose the nearest non-extinct same-kind founder with D<=1/10; break equal-distance
ties by species ID. If none qualifies, create a species with the newborn's genome
as exemplar. Existing organisms are never reassigned. Initialize by the same rule
in organism ID order. Register pending newborns in deterministic birth order so
later newborns can match their founder; include this registry in the tick commit.
Use the species registry's previous completed-tick extinction flags during birth
assignment, then mark extinction after all births/deaths commit. Thus an old
species losing its last adult can survive through an already produced newborn.

A new plant species points to its parent's species; a new animal species points
to the lower-ID parent's species, while both biological parents remain recorded.
Initial species have no ancestor. Extinct records persist for lineage history and
are never reactivated. Immutable founders avoid centroid drift and transitive
chaining; singleton species are possible. Assignment searches eligible founders
in stable ID order and does not inspect global population counts to alter survival,
reproduction or energy. Tracking extinction is bookkeeping, never protection.

## Consequences

Fixed-size integers are cheap to copy/hash/checkpoint; mutation and distance cost
O(L). Naive newborn assignment costs O(eligible species * L), which may grow with
diversity and must be profiled before adding an index. Founder thresholds are
explicit, stable and testable but approximate species; fixed loci limit open-ended
complexity and neutral loci can contribute to divergence. No interpreter, native
extension or data service is added to the self-contained dist folder. Schema
changes require versioning and explicit checkpoint compatibility handling.

## Verification strategy

Later tests cover trait endpoints, fixed locus order, two distinct parent checks,
nonempty inherited segments before mutation, clamping, zero-mutation clones,
repeatable mutation, generation/parent accounting and exact rational thresholds
(the species S boundary is 78642; 78643 is above). Test same/different kinds,
compatibility, nearest-founder ties, initial assignment, singleton divergence,
immutable labels, extinction timing/no reactivation and deterministic lineage IDs.
Use controlled genomes/RNG to force divergence in tests, never rescue in the
engine. Verify checkpoint/hash round trips include every allele and registry field.
TASK-001 defines this model only; ecology and coexistence remain untested.


## TASK-009 PLAN cycle 1: genetics integration refinement (not implemented)

Retain schema v1, twelve loci, linear mapping, one-boundary crossover, exact
per-million mutation with configurable bounded signed step and integer L1
distance. Detailed interfaces/draw rules/tests: tasks/TASK-009/handoffs/plan-cycle1.md.
Choose fixed [32768;12] founder DNA without RNG draws; slightly quantized
continuous traits replace the provisional TASK-008 phenotype. No species work.
Extract validated phenotype types into src/traits.rs, re-export from organism;
genome imports traits and organism imports genome. This supersedes ADR-007's
provisional genome-to-organism trait import to avoid a module dependency cycle.
Organisms store immutable genome and derive traits, rather than storing mutable
independent phenotypes. Pending births capture inherited/mutated DNA at acceptance
using engine RNG and existing GeneticsConfig. Rejected requests roll back RNG
via a temporary state clone; Commit draws nothing. Actual reproductive decisions
remain later work. Persistence must later encode schema/all alleles and effective
mutation settings; no checkpoint format or new dependency is planned here.


## TASK-009 implementation evidence

Genome/traits modules and the transactional Population/Simulation birth path now
implement the genetics refinement above. Species classification remains TASK-017;
TASK-016 now consumes the inclusive integer mating compatibility threshold
under ADR-013. Public tests exhaust
all 65536 uniform allele values and verify endpoints, locus independence,
nonempty crossovers across every boundary/orientation, independent mutation draw
reference and frozen Python integer vector, positive-rate diversity and L1 metric
properties. Private tests cover all-kind captured DNA, post-mutation health
rollback, parent death, engine weather/genetics draw interleaving and exact replay.
Full regression/packaging and headless targeted commands passed; exact evidence
is in TASK-009 implement-cycle1 handoffs. No new dependency, initial diversity,
checkpoint, ecological or performance claim.

## TASK-017 PLAN cycle 1: species integration refinement (not implemented)

Preserve the criterion and classification timing above. Population owns a private
SpeciesRegistry (src/species.rs) beside living records, not a separate Simulation
registry. Define the opaque Copy/Ord SpeciesId value in organism.rs beside Kind
and OrganismId and re-export it from species.rs: organism stores SpeciesId without
importing the registry module; species imports genome and organism value types
only. Population imports both, so there is no dependency cycle.

A newly created species uses its first member's OrganismId numeric value as its
SpeciesId. IDs are globally unique, increasing, nonzero and may have gaps; no
separate allocator or capacity failure is needed. This refines "monotonic ID"
without requiring contiguous numbers. Names are exactly plant-N, herbivore-N or
carnivore-N (ASCII decimal ID, no padding or RNG). Fixed midpoint founders thus
start one species for each nonempty kind, and none for an absent kind.

The registry retains ID-ordered immutable records: id, kind, name, founder_genome,
parent_species: Option<SpeciesId>, origin_tick, extinction_tick: Option<u64>, and
an internally maintained u128 living_members count. Organism::species_id() is
nonoptional and read-only. Public registry get/iter/living_count(Kind) accessors
are observational; mutation is crate-private. Counts describe actual current
living records even between internal stages; extinction flags represent completed
ticks and are finalized only after every committed birth/death. The task requires
queries of the current state at any tick, not an arbitrary historical snapshot API.

Initialization classifies before each founder insertion in organism-ID order.
queue_birth captures the first sorted biological parent's species ID alongside
DNA/generation, only on successful validation; no registry mutation or species
reservation at request time. At Commit, use the existing sort (phase, sorted
parents, request sequence), allocate the child organism ID, classify against all
same-kind records whose extinction_tick is None (including new species created
earlier in this Commit), install membership and increment live count. Choose
minimum (distance_sum, species ID) satisfying 10*S<=786420, else create a record
with this child's genome/ID/tick and captured parent species. Matching an existing
species never changes its recorded ancestry. Parent records persist after death,
so no lookup of dead organisms is needed at Commit.

Every successful kill decrements that member's species count exactly once,
including health/energy/old-age/predation paths; failed/repeated kills do nothing.
After all births and death accounting, finalize records with zero live members
and no extinction tick to Some(current tick). Never clear an extinction tick or
reuse an extinct record for classification. A species with zero adults during
this tick may retain its ID via accepted offspring; a child too divergent to
match it instead leaves an extinct parent and a living descendant species.
No random draws, ecological gates or global-count feedback are added.

Registry Clone/PartialEq participates in Population/Simulation replay. Future
canonical checkpoints/hashes must preserve all historical records, exact founder
DNA, ancestry/ticks, organism memberships and model version 1. Names are canonical
from kind/ID; living counts can be recomputed/validated from records on load.
No separate species allocator exists. Validate member kind/reference, lineage
ancestor ordering, origin/extinction ticks, unique IDs/names, immutable founders,
counts and no living members of extinct species. Do not reconstruct exemplars
from current survivors or discard extinct records. No disk format belongs here.

Naive classification is O(total historical species * 12) per birth, finalization
and read-only species counting O(total species); storage grows with lifetime
speciation. Prefer this deterministic implementation until measured need for an
index; no throughput/coexistence claim. Detailed implementation/test sequence is
in tasks/TASK-017/handoffs/plan-cycle1.md. No new crate, config or system dependency.


## TASK-017 implementation evidence

Population now owns the registry, and every organism stores SpeciesId. The
refinement above is implemented unchanged: immutable same-kind founders,
integer inclusive threshold, nearest then ID, deterministic first-member IDs/
names, captured ancestry, sorted Commit assignment and end-Commit extinction.
No ecological gate, RNG draw, config/dependency or public mutation API added.
Only a cfg(test) founder setup helper constructs coherent controlled genomes for
new full-tick tests; no legacy fixture or biological expectation was changed.
Tests exercise 78641/78642/78643, fixed exemplars/chaining, independent count
oracles, transactional failure including post-mutation health, parent death,
canonical Commit order, simultaneous divergent children, extinct history and
actual plant/both animal policy splits against raw-draw references. Public
four-seed 2200-tick replay includes registry/member equality and pure queries.
See docs/SPECIES.md and TASK-017 implementation handoffs for commands/results.
Future checkpoint/hash obligations and historical-scan costs above still apply;
no disk persistence, throughput or natural-run diversity guarantee is claimed.

# ADR-013: Local paid two-parent animal reproduction

Status: Implemented in TASK-016 IMPLEMENT cycle 1.

## Context and alternatives

TASK-016 requires sexual reproduction, both-parent costs, maturity, compatibility,
fertility and a waiting time. Existing Population::queue_birth already validates
distinct live same-kind parents, captures crossover/mutated DNA and lineage,
reserves IDs and stages RNG transactionally. It intentionally does not authorize
mating. ADR-004 fixes inclusive genetic compatibility D<=1/5. Reuse this path.

Choose immediate single births at Commit over gestation/litters: the latter add
pregnancy state, cancellation policy and energy allocation complexity without a
requirement. Choose contact-only deterministic mate choice over global search or
extra mate-seeking movement: it uses existing spatial lookup, limits work and
preserves current food navigation. No sexes, species labels, kinship exclusions,
global population feedback, configuration/default changes or new dependencies.

## Decision: animal reproduction model 1

Keep the seven phases. Within Reproduction execute existing plants unchanged,
then herbivores, then carnivores. Do not age animals again. Each kind snapshots
ascending living IDs after all feeding/hunting. Immediate earlier deaths exclude
parents, and movement/food energy this tick affect eligibility.

Maturity is age >= max(1,lifespan/10), integer floor (20..200 for schema 1).
Parents must be two different living animals of the same kind, wrapped Chebyshev
distance <=1 (including co-location), mature, paid-budget eligible and cooldown
ready. Genetic compatibility is 5*genome.distance_sum(other)<=MAX_DISTANCE_SUM,
using integer arithmetic, inclusive. Do not use future species IDs as a gate.

Each organism gains last_reproduction_tick: Option<u64>, initially None for all
founders and committed children (including plants, where unused). Expose only a
read-only getter. Ready if None or tick.checked_sub(last) is Some(elapsed) with
elapsed >= animals.reproduction_cooldown. A future last tick fails readiness.
Stamp BOTH parents Some(tick) immediately on accepted birth, before later actors.
No tick+cooldown addition, saturation or decrementing timer. This handles u64::MAX
cooldowns and final representable ticks without overflow. Cooldown C allows the
next birth at t+C, excludes t..t+C-1. Maturity separately delays newborns.

Maintain a temporary BTreeSet<OrganismId> of attempted animals per kind. For each
ascending initiator not attempted and otherwise eligible, query nearby(cell,1,
Some(kind)). Filter out self, attempted or ineligible/incompatible candidates;
choose minimum (wrapped distance, ID). Candidates may have lower or higher IDs.
No mate means no draw and no attempted mark. With a mate, mark both attempted
BEFORE the fertility trial; each animal participates in at most one trial per
tick, including failed trials. This prevents repeated reverse-pair trials and
multiple partners bypassing low fertility. Failed trials set no persistent
cooldown or energy debit; they may retry next tick. No fallback mate this tick.
Success also stamps cooldown immediately. No extra movement, target RNG or cell
reservation; unrestricted animal co-occupancy remains valid.

Let F1,F2 be raw locus-4 alleles, and draw engine_rng.chance(F1*F2,65535*65535)
using u64 products. This equals the product of both mapped fertility traits.
Either zero means no trial draw; both maximum means certain success without draw;
interior chance calls existing rejection sampling. Positive low fertility remains
positive without per-million quantization. After a successful trial use existing
sorted-parent crossover (boundary then orientation), then configured mutation in
locus order. RNG ordering: weather, animal actions/hunts, plant reproduction,
herbivore mating trials/genetics, carnivore mating trials/genetics; Commit draws
nothing. ID/generation rejection retains a consumed fertility trial but existing
queue_birth rolls back inheritance draws; no costs/cooldowns on rejection.

## Energy, accepted birth and failure rules

E=animals.reproduction_energy is the cost for EACH parent. Require each energy
strictly > E, finite positive residual energy and a representable actual debit
(energy-(energy-E)>0). Child energy is E, positive and <=1000. Require the sum of both actual
debits >= E, so combined realized loss funds the child's energy conservatively.
This sum is finite (each debit <=1000). These local representability rules apply to all
animals and cannot create energy from tiny valid settings. Settings E>=1000
naturally disable animal births at bounded energy capacity, without schema change.
At ordinary E=30 both parents pay 30, the child receives 30, and 30 dissipates as
reproductive overhead. No resources/health/global counters supply child energy.
Parents survive payment because eligibility requires a positive remainder.

Recheck copied eligibility inputs before request; single-owner synchronous code
has no intervening actor. Request kind, lower-ID parent's current cell, energy E,
health 10 (minimum possible schema-1 max health), sorted two parents and phase
Reproduction. Position choice is independent of which parent initiates. Existing
queue_birth captures DNA, parents and max(generations)+1. Only on Ok debit both
parents through Population and stamp both last ticks. Prevalidated nonlethal
finite payments/stamps must be infallible under valid state; a mismatch is an
internal invariant failure, never silently unpaid offspring. ID exhaustion or
generation overflow skips that birth with no payment/stamp. Unexpected request
errors are invariant failures as for plants. Child health is structural newborn
health, not an energy payout. Births commit with age 0, cooldown None, lineage
and exact captured DNA; first action/maturity progression is next tick. Existing
accepted-birth-survives-later-parent-death semantics remain unchanged.

## Boundaries, persistence and tradeoffs

Add private ecology/reproduction.rs with pure mature(age,Traits), ready(last,tick,
cooldown), compatible(&Genome,&Genome), birth_energy(e1,e2,cost)->Option<f64>,
and fertility_numerator(&Genome,&Genome)->u64 helpers plus denominator/model
constants. Imports genome/traits only (std primitives otherwise), never Population
or Simulation. Simulation owns indexed selection, temporary attempted set, sole
RNG and queue/payment orchestration. Population owns private cooldown mutation
and ordinary energy/index/counters. No public spawn or mutable organism access.

last_reproduction_tick is NEW authoritative future-influencing state: include
its Option discriminant/value in future canonical hashes/checkpoints and validate
animal timestamps <= engine tick on load. Preserve it exactly, never reset it on
load or derive it from child birth records. Record model identity, effective cost/
cooldown, existing full DNA/RNG/climate/resource/lifecycle state. Pending attempts
are transient and absent at completed ticks; spatial cache remains derived.
No disk persistence is implemented by this task.

Work is one bounded-radius query per eligible initiator plus local candidate map
lookups and fixed twelve-locus checks, with O(animals) transient IDs. Dense stacks
may give quadratic candidate work; no performance claim. Deterministic ID ties
bias access; local contact and a single newborn simplify ecology. Initial full
reserves may yield a finite birth burst after maturity. No tuning/coexistence
claim; no count-dependent protection or replenishment. Tests and migration plan:
 tasks/TASK-016/handoffs/plan-cycle1.md.


## Implementation evidence

src/ecology/reproduction.rs implements the pure gates; Simulation sequences
unchanged plant policy then both animal kinds through the existing inheritance
primitive. Population owns validated pair stamping; Organism exposes the optional
last tick read-only and both constructors initialize None. No dependency/schema
change. Tests cover both kinds with actual policy and full ticks, independent
512-trial crossover/mutation references per rate/kind, 4096 paired fertility
streams per kind, contact seams/degenerate worlds, energy guards, cooldown extreme
boundaries, overflow rollback, lineage/index/newborn timing and solitary 2200-tick
continuation. The only legacy migration disables births (E=1001) in the fixed
two-carnivore starvation ledger; mixed production replay retains births enabled.
Exact commands, results and limitations are in TASK-016 implementation handoffs.
No throughput/coexistence/full checkpoint claim; persistence obligations above
remain binding for the later owning task.

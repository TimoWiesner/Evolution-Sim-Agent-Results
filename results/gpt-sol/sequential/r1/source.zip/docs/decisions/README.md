# Architecture decisions

These decisions are accepted designs for later implementation, not evidence of
working software. TASK-001 contains documentation only.

- [ADR-001: Core runtime and determinism](ADR-001-core-runtime.md)
- [ADR-002: Local browser UI](ADR-002-ui-technology.md)
- [ADR-003: Wrapping spatial index](ADR-003-spatial-index.md)
- [ADR-004: Genome, inheritance and species](ADR-004-genome-species.md)

Each ADR records alternatives, performance/testability/distribution consequences
and future executable verification. Changes to a decision require a documented
superseding decision; preserve the rationale and checkpoint compatibility impact.

- [ADR-005: Smooth periodic base climate](ADR-005-base-climate.md)
  (TASK-006 planned static model and procedural storage; implementation pending).
- [ADR-006: Periodic seasons and persistent seeded weather](ADR-006-temporal-climate.md)
  (TASK-007 PLAN; implementation pending).

# ADR-009: Local clonal plant reproduction and dispersal

Status: Implemented in TASK-012 IMPLEMENT cycle 1.

## Context and alternatives

TASK-012 needs paid reproduction, toroidal dispersal, mutated inherited DNA,
lineage, local establishment limits and no spontaneous plants. ADR-004 already
chooses clonal plants; TASK-009 provides transactional inherited birth requests.
TASK-011 provides authoritative finite resources and physiology. Keep existing
configuration/defaults and twelve-locus schema.

Choose asexual reproduction only. Pollination adds mate search/compatibility
without being required. No seed bank, dormant state, species or initial-placement
change. Choose one uniformly sampled unique cell in the parent's inclusive
wrapped Chebyshev radius, with rejection if unsuitable. Searching all free cells
would guarantee success but costs radius area per parent; sampling raw offsets
biases small wrapped worlds through duplicate destinations. One sampled cell
keeps bounded attempt work and makes local crowding reduce recruitment naturally.

## Decision: exact reproduction model 1

Use Reproduction after plant/animal actions, before Commit. Snapshot living plant
IDs ascending; recheck each parent's liveness without aging again. A plant has at
most one attempt each tick. No additional maturity or cooldown state is needed:
newborns only enter Commit, and energy limits their next possible reproduction.
Let E = plants.reproduction_energy, existing positive finite config (default 20).
Require parent energy e > E; child energy b = min(E/2, ENERGY_CAPACITY), b > 0.
Also require the computed remainder e-E > 0, strictly below e, and actual f64
loss e-(e-E) >= b. Otherwise skip without draws. These numerical checks prevent
free births from a sub-ULP debit or an underflowed seed budget. E above capacity
naturally disables reproduction. No schema restriction or arbitrary energy floor.
On success debit E, give child b; the remaining debit is dissipated reproductive
work. Child health is 10, the minimum possible genome maximum health, so every
mutated child is valid. Health is a physiological condition, not an energy credit.
Initial organisms retain energy 1000/full health and are not births.

Next use exact chance(parent allele[4],65535) for inherited fertility propensity.
Zero and maximum fertility consume no chance draw per Rng semantics. On success,
sample x then y with below(unique_axis_length), including length one (one draw).
For each axis of length d and configured radius r converted safely to usize:
if r >= d/2, length=d and start=0; otherwise length=2*r+1 and start=center-r.
Map start+sample through Topology::cell using i128. This gives a uniform Cartesian
product of unique wrapped cells, exactly the existing cells_within membership,
without scanning/allocating the neighborhood. Include origin; its living parent
blocks establishment. Radius zero therefore cannot establish an offspring.
Huge radii visit no huge loops, and 1x1/1xN/Nx1 axes never duplicate candidates.

A destination has room iff no living plant occupies it and no accepted pending
plant birth reserves it. Animals may share its cell. Multiple initial plants in
one cell remain valid; the one-plant rule applies only to new establishments.
Check living occupancy with Population::nearby(cell,0,Some(Kind::Plant)). Track
accepted destinations as a local BTreeSet<(usize,usize)> during reproduction;
there are currently no production births in earlier phases. Future earlier plant
birth producers must share these reservations or move the invariant into
Population. Internal generic queue_birth remains a lifecycle primitive and does
not enforce plant ecology on unrelated fixtures or future animal births.

Require remaining destination resources R >= 1 after all current-tick physiology
and earlier establishments. Successful establishment consumes exactly 1 resource
unit as dissipated germination/site preparation; it does not add child energy.
Capacity below 1 or zero supply cannot establish, even if the parent is rich.
No climate veto is added; offspring face normal climate stress starting next tick.
This rule and occupancy are strictly local, never global population controls.

After all gates, request a BirthPhase::Reproduction plant child at destination,
with parents=[id], energy=b, health=10. Use the existing Simulation::queue_birth
and Population validation/mutation path. Only after acceptance debit the parent,
withdraw destination resource and insert its reservation; these validated updates
are infallible under single-owner execution. A rejected request charges nothing
and reserves nothing. Expected ID/generation exhaustion skips that attempt;
unexpected invalid-parent/vital errors indicate a programming invariant failure
and must not be silently swallowed. Fertility/dispersal attempt draws remain
consumed on ecological or capacity rejection; mutation draws roll back according
to existing queue_birth semantics. No whole-tick rollback is promised.

Commit installs captured DNA, parent ID, generation=parent+1, birth tick and age
zero, updates the spatial cache and counts once, draws nothing and clears pending
births. Accepted offspring survives later parental death under existing lifecycle
rules; first age/action is next tick. All post-initialization plants originate
through this one living-parent request path. No plant means no attempts or draws.

## Boundaries, cost and persistence

Extend private ecology/plants helpers for energy eligibility and bounded target
sampling; allowed imports become config/topology/rng/traits, never Simulation or
Population. Simulation orchestrates all world/population mutations and the local
reservation set. Resources/spatial/genome ownership and public read-only APIs
stay intact. No new runtime/system/crate dependency. No config schema/default
change. No CLI/run/UI/persistence implementation, species or animal ecology.

Attempt cost is O(log population + destination occupancy + log reservations),
plus fixed twelve-locus inheritance on success; total O(plants) attempts and
O(successes) temporary reservations, with no radius-area scan. Existing phase ID
snapshot, allocations and lifetime history retain process-memory limits. Dense
resources still cost O(world area) each tick. No throughput/coexistence claim.

There is no persistent cooldown/seed state or extra authoritative raster. Future
checkpoint/hash must capture reproduction model identity/effective settings,
existing parent/child DNA/lineage/vitals and complete RNG/resources/lifecycle state.
Reservations are temporary and empty at completed-tick boundaries; exclude from
checkpoint/hash. Model changes alter future evolution and need version handling.

## Verification

Acceptance matrix and regression migration: tasks/TASK-012/handoffs/plan-cycle1.md.
Test actual full production ticks/Commit, not only manually queued child fixtures.
Use controlled fertility and weather/DNA/vitals only through existing cfg(test)
fixtures; no public spawn/mutable-record API. Independently verify energy/resource
ledgers, exact RNG ordering, blocked attempts, seam/corner births, pending-site
competition, mutation endpoints, child timing and 2200-tick seeded conservation.


## Implementation evidence

The model above is implemented without schema/default or equation changes.
Ecology helpers use traits/rng/topology; Simulation owns reservations and all
mutations. Existing Population birth acceptance and Commit semantics remain intact.
A cfg(test)-only ID exhaustion setter permits production-policy rejection tests.
Independent raw RNG references verify attempt and mutation draw ordering, including
weather, fertility endpoints/midpoint and rejected sites. Actual ticks exercise
six seam/corner cases, paid reserves, resource thresholds, reservation collisions,
stacked founders/animal sharing, lineage and newborn timing. Exhaustive small-grid
sampler tests verify unique uniform coordinate mapping against a distance oracle.
Four-seed 2200-tick extinction/replay tests retain conservation and founder expiry.
Scoped E=1001 fixtures preserve earlier physiology/weather/lifespan test purposes;
production-enabled tests separately cover the new behavior. See implementation
handoffs for actual commands, failures, corrections and final results. No new
dependency, throughput/coexistence or disk-persistence claim.

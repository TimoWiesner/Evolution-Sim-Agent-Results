# Batch runs and export

Run independent seeds sequentially with the same engine and sampling as `run`:

```sh
mkdir -p target
cat > target/batch-config.json <<'JSON'
{"seed":42,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":1,"carnivores":0}}
JSON
./evosim batch --config target/batch-config.json --seeds 1,2,3 --ticks 100 --out-dir target/batch
./evosim batch --config target/batch-config.json --seeds 7,11 --ticks 17 --out-dir target/matrix --sweep 'plants.resource_regeneration=[1,2]'
```

Use any valid JSON configuration; output directories and missing parents are
created. Options are separate flag/value pairs in any order, each once. All four
contract flags are required. `--sweep` is optional; no other options are accepted.
Ticks are unsigned decimal u64, including zero. Seeds are comma-separated signed
integers of arbitrary magnitude, without whitespace or a plus sign. Leading zeros
and negative zero normalize; duplicate normalized seeds are errors. Distinct seeds
with equal RNG residues still retain distinct exact metadata, hashes and filenames.

One parameter may vary across a nonempty JSON number array. The dotted path must
be an existing numeric `group.key` in the effective configuration, excluding seed.
All variants pass ordinary configuration type, range and cross-field validation.
For example `initial.plants=[0,4]` varies an integer; `1.5` is invalid there.
Repeated effective values (including `1` and `1.0` for a float leaf) are errors.
The entire base configuration and every variant validate before output creation.

Runs execute in variant input order, then seed input order, starting a fresh
engine each time. Seed-only batches write `seed-<normalized-seed>.json` directly
in the output directory. Sweeps write `variant-0/seed-<seed>.json`, then
`variant-1/...`. Each is an ordinary contract `run` result, including sampled
analytics, final species, complete-state hash and tick-loop timings. Sampling is
at tick zero, every `max(1,ticks/100)` ticks and the end, without duplicates.

## JSON summary schema 1

`summary.json` contains:

| Key | Meaning |
|---|---|
| `batch_schema`, `contract` | Both 1 |
| `ticks`, `run_count` | Requested ticks per run and number of independent runs |
| `sweep` | null, or `{ "path": "group.key", "values": [...] }` with effective values |
| `runs` | Ordered compact records described below |
| `aggregates` | One final-population aggregate per kind |

Each run record has zero-based `run_id` and `variant_index`, exact numeric `seed`,
`parameters`, `tick_start` (zero), `tick_end`, relative `result_file`, `final`
(including species), `state_hash`, and per-kind boolean `extinct`. Parameters
contain every effective configuration group/default, excluding seed. Add the
record's seed to parameters to reconstruct an independently runnable config.
Paths use relative POSIX names; summary contents do not depend on output paths.

For each of plants, herbivores and carnivores, aggregates contain final-population
`mean`, `min`, `max`, `extinction_count` and `extinction_fraction`. Extinct means
final count zero, including a kind absent initially and runs of zero ticks. It
counts runs ending at zero, rather than counting new extinction events. All runs
continue for exactly the requested ticks through extinction. Summary statistics
never feed back into the engine.

Final counts and extrema retain exact integers. Sums use checked u128 arithmetic;
overflow returns an error. Means/fractions use finite f64 and can lose integer
precision above 2^53. Summaries omit wall-clock measurements, so identical batches
on the same build produce byte-identical JSON and CSV, including same-directory
reruns. Individual result files retain their ordinary variable timing fields.
Cross-build floating differences remain permitted.

## CSV export

Every batch also writes UTF-8 `summary.csv`, without an extra option. Columns are
in this exact order:

```text
row_type,run_id,variant_index,result_file,seed,parameters,tick_start,tick_end,state_hash,kind,final_population,extinct,mean,min,max,extinction_count,extinction_fraction,run_count
```

There are three `run` rows per simulation (plants, herbivores, carnivores), then
three `aggregate` rows in that order. Run rows repeat the record metadata and
contain the kind's integer final population and lowercase boolean extinction.
`parameters` is compact JSON within a CSV cell. Aggregate columns are empty in
run rows; run-specific columns are empty in aggregate rows. `run_count` is present
in every row. The CSV uses commas, CRLF line endings and RFC4180 escaping: fields
containing commas, quotes or newlines are quoted and interior quotes doubled.
Use an integer parser for seeds/counts and JSON decoding for parameter cells;
spreadsheet automatic numeric conversion can lose precision.

## Publication, costs and limitations

Argument/configuration errors return status 2 with stderr and empty stdout,
without creating output artifacts. Filesystem preflight may leave newly created
empty directories. Roots, ancestors, variant directories and expected files must
be real directories/regular files; symlinks and special files are rejected.
Expected files may not alias the input configuration, including hard links.
Unrelated existing files are preserved.

A private staging directory inside the output root holds all new results and
both summaries before publication. Returned simulation or staging errors clean
that directory and retain the prior published batch. After staging succeeds,
publication removes the old `summary.json` completion marker, promotes result
files and CSV, then promotes JSON last. A promotion error can leave some replaced
files and no completion marker. This is not a directory-wide atomic transaction,
crash-durable storage or support for concurrent writers to the same directory.
Read only files listed in a completed summary; stale files from older batches
can remain after reruns.

Execution uses one engine/full result at a time plus O(run count) compact records;
results and summaries consume disk proportional to batch size. Histories and
sample buffers can still exhaust memory; a staged rerun can temporarily need
roughly twice the output disk. Extremely long seed text can exceed filesystem
filename limits and return an I/O error. No extra packages, worker pool, charts,
checkpoint support, ecology changes or throughput guarantee are added here.

# Genetics API and model (TASK-009)

`genome::Genome` is an immutable, Copy/Eq schema-v1 `[u16; 12]` value.
`from_alleles` accepts the fixed array; `alleles` borrows it read-only.
`GENOME_VERSION`, `LOCUS_COUNT`, `LOCUS_NAMES` identify the stable schema.
Every living organism owns one genome and `Organism::traits()` computes its
phenotype from that DNA. No independent phenotype is stored in an organism.
Validated phenotype types live in `traits` and remain re-exported by `organism`.
`Traits::founder()` remains a standalone legacy phenotype convenience; it is
not the phenotype source for initial organisms.

The locus order and bounds are fixed in ADR-004:

| Index | Trait | Bounds |
|---|---|---|
| 0 | speed | 1..4 |
| 1 | strength | 1..10 |
| 2 | maximum health | 10..100 |
| 3 | lifespan | 200..2000 ticks |
| 4 | fertility | 0..1 |
| 5 | vision | 1..8 |
| 6 | metabolic multiplier | 0.5..2 |
| 7 | preferred temperature | 0..1 |
| 8 | preferred moisture | 0..1 |
| 9 | climate tolerance | 0.05..0.5 |
| 10 | aggression | 0..1 |
| 11 | risk tolerance | 0..1 |

Continuous traits use `low + (high-low)*(allele/65535)` with explicit exact
endpoints. Speed, lifespan and vision use integer floor division of the scaled
span. The mapped values pass through `Traits::new` validation. Queries are pure,
finite and bounded; they do not consume RNG. All kinds retain all loci, including
traits that later ecology may leave inactive for plants.

Initialization uses `Genome::founder() = [32768;12]` for every kind, with no draws.
It preserves row-major placement, IDs, seed stream and lifespan 1100. Continuous
values are slightly quantized (maximum health is `10+90*(32768/65535)`, not 55).
There is no initial genetic diversity; reproductive mutation supplies variation.

`copy_child(settings,rng)` copies then mutates. `crossover_child(other,settings,rng)`
draws boundary `1+below(11)` then orientation `below(2)`; orientation 0 takes the
self prefix and other suffix, orientation 1 reverses these. Both segments are
nonempty. Mutation then visits loci 0..11. Existing validated `GeneticsConfig`
controls the per-million chance and maximum signed step M. Selected loci draw
`z=below(2*M)`; `z<M` maps to `z-M`, otherwise to `z-M+1`. Add in i32 and clamp
to 0..65535. Steps are uniform and nonzero before clamping. A selected boundary
allele may remain unchanged. Rate zero draws nothing for copy/mutation; crossover
still draws twice. Rate one draws steps without probability draws. Intermediate
probabilities use the generator's rejection sampling. No forced novelty occurs.

`distance_sum` is exact L1 allele distance (0..786420), symmetric and obeying the
triangle inequality. `distance` divides by 786420 for normalized observation.
Larger total displacement gives larger distance; the number of changed loci
alone does not order distance. Species assignment uses the integer sum with inclusive 10*S<=786420;
TASK-016 mating uses inclusive 5*S<=786420. TASK-017 implements immutable founder
classification at initialization and Commit; see SPECIES.md.

The internal Simulation birth wrapper passes its sole RNG and effective settings
to Population. Requests contain no phenotype or caller-selected DNA. Parent IDs
are sorted and validated (one living plant, two distinct same-kind living animals).
Acceptance validates vitals, generation and ID capacity, computes child DNA on a
clone of the current RNG, then checks health against that child's maximum. Only
success publishes the advanced RNG and pending child. Errors leave population
and RNG unchanged. Child DNA and lineage are captured before any later parental
death; Commit stores them without draws. Newborns first act next tick. No
extra genetics draws occur at Commit. TASK-016 implements paid two-parent
local animal mating, maturity, compatibility, product fertility and cooldown
(ADR-013, ANIMALS.md). TASK-012
implements clonal plant policy: fertility, paid energy, uniform dispersal and
local room/resource gates precede the inherited request (see PLANTS.md).

Checkpoint/hash work must include schema version and every allele, as well as
settings and the complete engine RNG. No disk persistence format is added here.
Mapping costs O(12) per query; no throughput or coexistence result is claimed.
Executable evidence is in tests/genome.rs, tests/lifecycle.rs and private
population/simulation tests; exact commands are recorded in the task handoff.

TASK-016 adds last_reproduction_tick: Option<u64> to every organism (unused on
plants). Successful animal parents are stamped immediately; founders/newborns
start None. Future checkpoint/hash must include Option/value exactly alongside
DNA and validate animal timestamps against the clock. Clone equality already
includes it. Mating uses genetic distance, never a species label.

# Base climate (model version 1)

Each cell has an immutable biome, base temperature and base precipitation.
Temperature and precipitation are normalized model values in [0,1], not degrees
or millimetres. World owns a procedural Climate with O(1) storage; a lookup costs
O(1), including one cosine. Construction does not allocate a world raster.
Climate does not draw RNG values. Seeds share the same base geography. Existing
season/weather configuration parameters do not change these base fields.
Current seasonal/weather values are available separately as described below.
Ecological effects belong to later tasks.

For height h and normalized cell row y, define d=min(y,h-1-y),
v=(d+0.5)/h, q=clamp((1-cos(2*pi*v))/2,0,1). Temperature is q. Using d evaluates
symmetric rows identically, including the two rows adjoining the wrapping seam.
There is no longitude influence, terrain, elevation or noise.

| Temperature q | Biome |
|---|---|
| [0,.10) | polar |
| [.10,.25) | tundra |
| [.25,.60) | temperate |
| [.60,.85) | dry (savanna/desert) |
| [.85,1] | tropical |

Precipitation interpolates these (temperature, precipitation) knots:
(0,.15), (.10,.25), (.25,.60), (.60,.20), (.85,.35), (1,1).
Within [a,b], let t=(q-a)/(b-a), s=t*t*(3-2*t), then
p=p_a+(p_b-p_a)*s, clamped to [0,1]. Interpolation has zero slope at every knot;
scalar temperature and precipitation remain continuous with continuous first
derivatives. The relatively dry subtropical belt separates moist temperate
regions and wet tropical regions. The categorical biome thresholds are deliberate
internal label boundaries, not discontinuities in the underlying scalar fields.

A torus cannot reproduce Earth's two separate geographic poles. Latitude here
repeats cold-hot-cold: the top and bottom edges join inside one cold belt and the
hot belt crosses the middle. Without edges, there are no distinct north/south
poles or continents. The underlying periodic cosine has the same value and zero
derivative at v=0 and v=1; composed precipitation preserves those limits and
derivatives. Cell-centred seam rows are identical by symmetric evaluation.
East-west values are constant, so horizontal and corner wrapping add no seam.
Tests compare seam differences against maximum *non-wrapping* adjacent differences
for each scalar field, rather than including the seam in its own comparison.

Small worlds can miss bands: 1x1 is tropical, height 2 is temperate. No extra
cells are invented to show all five zones. Any valid Topology is supported,
including usize::MAX by 1 or 1 by usize::MAX, without area allocation. Very large
coordinates lose f64 cell resolution but still yield finite bounded values.
Transcendental results may differ slightly across platforms/libm builds; repeated
runs on the same build are deterministic.

The Rust API is `Climate::new(Topology)`, `base_at(Cell) -> BaseClimate`, and
`write_json(&mut impl Write) -> io::Result<()>`. BaseClimate exposes biome(),
temperature(), precipitation(); Biome exposes a stable lowercase name().
`Simulation::world().climate()` provides the same read-only field for adapters.
Foreign-world Cell coordinates normalize to the receiving topology.

To inspect a real map without a display, after running setup:

```sh
mkdir -p target
cat > target/climate-config.json <<'JSON'
{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}
JSON
./evosim climate --config target/climate-config.json --out target/climate-map.json
```

The same command works with dist/evosim. Flags may appear in either order and
both are required. Success exits 0 with empty stdout/stderr; errors exit 2 with a
diagnostic on stderr. Argument and configuration validation happen before opening
output, preserving an existing file on invalid input. Output open/write errors
are reported; a failed write can leave a partial map.

Export is streaming JSON, O(area) time/output with O(1) auxiliary memory. The
object contains climate_model (1), width, height, temperature_units and
precipitation_units (both "normalized"), and cells. Each row-major cell record
contains x, y, biome, base_temperature, base_precipitation. A final newline follows
the object. This is an inspection format, not a run result or checkpoint.
Future persistence must capture the base model version and dimensions or complete
equivalent values; future weather must preserve independently queryable base fields.


## Current climate (temporal model version 1)

World also owns TemporalClimate, with a copy of validated ClimateConfig and a
WeatherState containing model version, absolute tick, temperature offset and
precipitation offset. Construction starts at tick 0 with positive zero offsets,
without drawing from the engine RNG. Base geography and biomes stay immutable.

For completed tick t, year length Y, base temperature q and precipitation p:
let s=cos(TAU*((t%Y) as f64 / Y as f64)). Integer remainder precedes conversion,
so with weather off every phase repeats bit-for-bit after Y ticks on one build.
Year length 1 is a constant phase. Huge years can lose adjacent phase resolution.
The normalized current fields, always finite in [0,1], are:

- temperature = clamp(q + A_T*(0.25+0.75*(1-q))*s + w_T, 0, 1)
- precipitation = clamp(p - A_P*(0.5+0.5*q)*s + w_P, 0, 1)

Cool zones have stronger temperature swings; warm zones have stronger wet/dry
seasons. Wetness peaks opposite warmth. All zones share phase, a simplification
consistent with the torus's joined cold belt. Smooth zone amplitudes and spatially
uniform weather preserve both seams. Clipping can flatten seasonal extrema.
Setting a seasonal amplitude to zero disables only its corresponding season.

ClimateResources advances weather once after the clock increments. If weather
amplitude A is zero, offsets become positive zero and no draws occur. Otherwise,
exactly two raw next_u64 draws come from Simulation's sole RNG, temperature first,
precipitation second. For each draw d, u=(d>>11)/2^53, z=A*(2*u-1), then
w=clamp(0.75*w+0.25*z,-A,A). This global AR(1) weather persists and mean-reverts;
it has no local fronts. Even a tiny nonzero amplitude consumes two draws.

```rust
use evosim::{config::Config, simulation::Simulation};
let mut sim = Simulation::new(Config::preset("baseline").unwrap()).unwrap();
let cell = sim.world().topology().cell(-1, -1);
let at_zero = sim.world().current_climate_at(cell);
sim.advance_one_tick().unwrap();
let at_one = sim.world().current_climate_at(cell);
assert!((0.0..=1.0).contains(&at_zero.temperature()));
assert!((0.0..=1.0).contains(&at_one.precipitation()));
```

`World::temporal_climate()` exposes immutable settings(), tick(), weather_state()
and current_at(&Climate, Cell). CurrentClimate has temperature()/precipitation().
Queries at any reached tick consume no draws and mutate nothing. There is no
historical/future stochastic query; replay or advance to the desired tick.
Foreign cells normalize via the base Climate. CLI climate export remains base-only.

WeatherState::new(version,tick,temperature_offset,precipitation_offset) validates
version 1 and finite absolute offsets <=1; read-only accessors expose those fields.
TemporalClimate::from_state(settings,state) further requires abs(offset)<=A,
including zero offsets with weather disabled, retaining exact float bits.
TemporalClimate::settings() and weather_state() plus full engine RNG constitute
its in-memory continuation boundary. Future disk checkpoints/hashes must include
settings, temporal model version, tick and both offsets, as well as base model/
dimensions and engine RNG. Loading must validate temporal/engine clock agreement.
No disk checkpoint or canonical state hash is introduced by this task.

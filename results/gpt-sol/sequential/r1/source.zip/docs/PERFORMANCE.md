# Engine performance: TASK-026 (historical), TASK-027 amendment

The original TASK-026 measurements below are historical. Current
`scenarios/performance.json` uses the explicitly documented TASK-027 replacement
(4600/0/40 instead of4600/240/40); see the amendment at the end and BALANCE.md.
The original scenario is retained in TASK-027 evidence.

Implemented in TASK-026 cycle1. The primary median improved from **751.693 to 847.955
ticks/s (1.128×, +12.8%)** on the container below. The >=100 ticks/s target is met
for this changing 2,303–5,081-organism workload. This is a headless engine result,
not a UI speed or sustained food-chain coexistence claim.

## Reproduce

From the project root, one command builds and runs the measurement:

```sh
cargo run --locked --release --example performance_bench
```

For timing without a build in the invocation:

```sh
cargo build --locked --release --example performance_bench
target/release/examples/performance_bench
target/release/examples/performance_bench --workload mixed
```

Primary: `scenarios/performance.json`, seed42, 128×48, initial4600 plants,
240 herbivores,40 carnivores; all effective defaults unchanged. Five fresh worlds,
100 untimed warm-up ticks and1000 measured ticks each. Supplementary `mixed`:
seed42,64×48,initial2400/120/20,10 warm-up and100 measured ticks,nine fresh worlds.
`--repeats N` overrides the positive repeat count (used only for profiles).
JSON schema1 reports full effective config, individual seconds/rates, median,
range, per-kind counts/bounds, births/deaths and complete final state hash.

An outer Instant surrounds only completed tick calls plus O(1) count observations,
min/max/mean accumulation, floor assertions and black_box of returned TickReport.
Initialization, warm-up, metrics, hashing, checkpoint/JSON/file I/O are excluded.
Population floor>=2000 is asserted at every measured tick and at warm-up end;
exact final tick, positive finite elapsed time and repeated hashes are checked.
Extrema include warm-up end; means use only the1000/100 measured completed ticks.
There are no per-tick organism scans or ecological adjustments in the observer.

## Setup

AMD Ryzen5 7500F6-Core Processor,6 physical cores/12 logical CPUs,x86_64;
affinity CPUs0–11. Ubuntu24.04 container (provided environment), Linux
7.0.0-43-generic. rustc1.100.0 (0ef1bc386,2026-11-09),cargo1.100.0,LLVM23.1.5,
x86_64-unknown-linux-gnu host. Default Cargo release optimization (opt-level3),
no custom RUSTFLAGS, no profile/debug overhead in throughput runs. Measurements
were sequential without concurrent project tests,browser,build or profile jobs.
CPU frequency scaling/turbo and shared-host interference remain possible.
CPU quota and memory limits were not inspected because file access is restricted
to /workspace; exposed CPU count is not a quota guarantee. Full tool/hardware
output: `tasks/TASK-026/handoffs/hardware.json`. No fresh hardware/OS claim.

## Before and after

Identical harness/compiler/flags and exact workloads. Preserved pre-core-edit
binaries `target/task026/before-{bench,evosim,profile-bench}` were never rebuilt.
After profiler installation and correctness tests finished, reran the preserved
baseline followed by optimized binary; raw reports below are this isolated set.
The earlier exploratory/harness-setup timings are not used for the speedup.

| Workload | Before median ticks/s (min–max) | After median ticks/s (min–max) | Ratio |
|---|---|---|---|
| primary | 751.693 (705.422–752.044) | 847.955 (846.122–848.601) | 1.128× |
| mixed | 1027.076 (1025.458–1028.673) | 1095.760 (1063.870–1102.761) | 1.067× |

All repetitions have identical populations/counters/hash in both builds:

| Window | Total min / mean / max | Start plants/herbivores/carnivores | End plants/herbivores/carnivores |
|---|---|---|---|
| primary ticks100→1100 |2303 /3490.522 /5081|5041 /0 /40|2303 /0 /0|
| mixed ticks10→110 |2385 /2745.550 /2933|2682 /57 /20|2447 /0 /21|

Primary per-kind min[2303,0,0],max[5041,0,49]; mixed min[2365,0,20],
max[2913,57,21]. Per-kind extrema are independent, so their sums need not equal
total extrema. The primary has already lost herbivores before timing and loses
carnivores in the interval; the supplementary window starts with all three
kinds but loses herbivores. Neither proves sustained mixed-chain coexistence.
Peak population slightly exceeds5000; the workload is not a constant2000 actors.

Raw per-repeat reports (including exact effective config and all lifecycle totals):
`tasks/TASK-026/handoffs/{before,after}-{primary,mixed}.json`.
Primary final hash `7cd2929d919d393e6707ab2c477c11d95df951dfb6430ce76640bb72c891aa8a`;
mixed `664d8aadc5346dcf0923b5a7ce4e6ee861135bd07aa1d1880136c606ffd8be52`.

## Profile and optimization

Valgrind/Callgrind3.22.0 is a development-only dependency. Installation (both
commands succeeded; reinstall if missing):

```sh
apt-get update
apt-get install -y --no-install-recommends valgrind
```

Baseline profile command, before core edits:

```sh
CARGO_PROFILE_RELEASE_DEBUG=1 cargo build --locked --release --example performance_bench --target-dir target/task026-profile
cp target/task026-profile/release/examples/performance_bench target/task026/before-profile-bench
timeout 180s valgrind --tool=callgrind --callgrind-out-file=target/task026/before.callgrind target/task026/before-profile-bench --repeats 1
callgrind_annotate --auto=no --inclusive=yes --threshold=99 target/task026/before.callgrind
callgrind_annotate --auto=no --inclusive=no --threshold=95 target/task026/before.callgrind
```

Final profile uses the same build command, then:

```sh
timeout 180s valgrind --tool=callgrind --callgrind-out-file=target/task026/after.callgrind target/task026-profile/release/examples/performance_bench --repeats 1
callgrind_annotate --auto=no --inclusive=yes --threshold=99 target/task026/after.callgrind
callgrind_annotate --auto=no --inclusive=no --threshold=95 target/task026/after.callgrind
```

Profiles cover one whole primary invocation including initialization,warm-up and
final hash/serialization. These are **instruction counts (Ir), not elapsed-time
percentages**; throughput under Valgrind is excluded from the table. Optimized
inlining splits source attribution across several rows. Inclusive rows overlap
and must not be added. Bounded annotations/call counts are tracked alongside
the handoff; raw Callgrind files remain ignored in target/task026.

Baseline whole process18,644,111,702 Ir; advance_one_tick subtree18,555,493,484
(99.52%,1100 calls). ResourceField::regenerate subtree2,264,907,396 Ir (12.15%,
1100 calls), repeating climate evaluation6144 times/tick. Genome::traits has
4,501,716,032 inclusive Ir (24.15%,12,232,924 calls), including Traits::new
2,886,970,064 (15.48%). BTree search in advance_one_tick has11.09% self Ir;
cosine8.83% self (9.99% inclusive). These identify actual expensive work rather
than attributing end-to-end JSON overhead to the engine.

Retained change: crate-private ResourceField::regenerate_rows evaluates existing
current_at precipitation at x0 once per row, then applies the original per-cell
floating expression in the original row-major order. Climate currently depends
on latitude,tick,settings and weather, never longitude. No algebraic regrouping,
new persistent cache, state field, RNG draw, dependency or public API change.
Climate evaluation in this resource path falls from6144 to48 calls/tick; resource
updates remain O(area), with O(1) added workspace. Public arbitrary-cell climate
queries and organism behavior are untouched. Future longitude-varying climate
must revisit this precondition and its bit-level tests.

The optional direct spatial existence optimization was not implemented: profile
self costs were much smaller and the measured row change already improves both
workloads. Trait caching/storage rewrites were not attempted; they require a
separate bounded design to preserve ownership and authoritative-state rules.

Final whole-process16,470,550,534 Ir, down11.66%; tick subtree16,381,931,700
(99.46%,1100 calls). Regeneration subtree is now91,344,032 Ir (0.55%,1100 calls),
a95.97% reduction in that subtree. Climate::base_at calls fall from10,794,726 to
4,089,126 and cosine calls from21,589,452 to8,178,252. Trait conversion retains
exactly12,232,924 calls and4,501,716,032 inclusive Ir; its share grows to27.33%.
BTree search remains2,068,561,397 self Ir (12.56%); Traits::new has9.58% self,
Genome::traits7.72% self,cosine3.75% self. Remaining costs are repeated phenotype
conversion/validation, ordered-map access, ID snapshots and local queries.
No broader optimization or universal hardware speedup is claimed.

Call counts/direct incoming-arc Ir can be reproduced with
`python3 tasks/TASK-026/handoffs/profile_summary.py before` (or `after`).

## Behavior and regression guard

`tests/performance.rs` shares the same external helper. It is explicitly ignored
in ordinary debug cargo test, and test.sh explicitly runs it in release:

```sh
cargo test --locked --release --test performance -- --ignored --nocapture
```

Threshold10 ticks/s (100 seconds for1000 measured ticks) is over75× below measured
baseline and10× below the goal. It guards catastrophic slowdowns on slower/shared
machines; it is not a100/s guarantee. Population and tick assertions are independent
of speed, and no environment flag silently disables it.

The new resource unit oracle compares rain/store f64 bits against the original
cell formula across1x1,1x7,9x1,3x4,128x48, depleted/saturated stores,tiny/large
capacity,zero/max regeneration,season boundaries,u64::MAX tick,disabled/max
weather and restored nonzero offsets. Existing temporal climate tests retain
extreme seasonal/year settings. No golden or schema/model versions were changed.

Before editing core, saved tick0/100/1100 primary and0/25/110 for nine further
cases: mixed,contract,empty,no-food,no-weather,max mutation,1x1,1x17,19x1.
`python3 tasks/TASK-026/handoffs/differential.py before` captures baseline;
`python3 tasks/TASK-026/handoffs/differential.py after` compares every result key
except elapsed_seconds/ticks_per_second and compares checkpoint bytes exactly.
It also loads baseline checkpoints in optimized code and vice versa for10 more
ticks, comparing final/totals/hash to uninterrupted baseline (20 continuations).
Result:30 exact states/checkpoints plus20 continuation checks pass. Baseline/after
state and checkpoint digest manifests are tracked; large fixture files and
preserved executables stay ignored in target/task026. Same-build GNU comparison;
static-musl behavior is separately exercised by the existing packaging suite.

Final isolated `./test.sh > target/task026/full-suite.log 2>&1` exited0:
228 Rust tests passed (227 ordinary tests plus explicit release guard),22 Python
tests passed and all3 Node scripts passed. The debug timing guard is intentionally
ignored once, then explicitly runs in release (847.444 ticks/s,minimum2303,
exact tick1100). No existing tests skipped or failed. Includes determinism,
checkpoint/hash/run/batch,real browser UI,host/musl setup/build,static ELF and
copied empty-root headless distribution checks. Targeted biology/spatial command
passed155 tests; targeted checkpoint/hash/run/batch passed17. Exact commands,
counts and guard observation: tasks/TASK-026/handoffs/implement-cycle1.md and
test-results.json. Final cargo fmt --check and git diff --check passed.

No UI rendering work,new feature,ecological adjustment,canonical golden update
or benchmark state/tool modification was made.


## TASK-027: chosen ecology remeasurement and workload replacement

Local satiety is a deliberate biology change, not an optimization. The original
primary fails the unchanged>=2000 floor at tick685,total1998 (exit101). Full exact
observer minimum564; plants extinct799. Two attempted replacement inputs with120
and20 herbivores also fail (minimum982/1334); all configs/curves remain retained.
The chosen primary sets initial herbivores0, keeping128x48,4600 plants,40 carnivores,
seed42,100 warmup,1000 measured ticks,five repeats and>=2000/10-s guard unchanged.
It isolates natural plant work; the original timed primary had already lost its
herbivores. No product numeric default changes, replenishment or floor relaxation.
Original mixed input100 ticks/nine repeats stays unchanged for active animals.

Final isolated median857.619 ticks/s (796.327..859.009),minimum2304,max5118 for
replacement primary;671.812 (656.149..673.244),minimum2559,max3059 for mixed.
Both exceed100/s here. Mixed is38.7% slower than historical1095.760, with more
active animals (start2687/120/20,end2463/135/23 versus2682/57/20→2447/0/21).
More animal sensing/reproduction/hunting is a likely cost; no per-function profile
is claimed for this task. Replacement primary is not directly comparable to old
primary; do not call the changed workload an optimization. No stable coexistence
claim. Same disclosed container/compiler settings; no new system packages.
Raw final JSONs, original failing stderr/exit, all population curves and workload
selection rationale: tasks/TASK-027/evidence/performance-*. Reports suffixed
exploratory overlapped checkpoint tests and are excluded from final comparisons.
Reproduce final with the same commands above; original input is retained as
TASK-027/evidence/performance-original-config.json. Full safety/trial results and
final verification commands in BALANCE.md and TASK-027 implementation handoff.

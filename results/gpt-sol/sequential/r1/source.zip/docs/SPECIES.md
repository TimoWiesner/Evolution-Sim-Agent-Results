# Species and lineage model 1 (TASK-017)

Every initial organism and committed newborn gets a permanent `SpeciesId`.
`Organism::species_id()` and `Population::species()` expose read-only membership
and history. `SpeciesRegistry::get(id)`, `iter()` (ascending ID), and
`living_count(Kind)` do not change state or consume RNG. Record getters expose
ID, kind, name, immutable founder DNA, optional parent species, origin tick,
optional extinction tick, and current living-member count.

Assignment uses all twelve loci equally. Let S be the sum of absolute allele
differences from a species' immutable founder. Among same-kind, non-extinct
records with `10*S <= 786420`, choose the minimum `(S, SpeciesId)`.
S=78642 matches; S=78643 does not. If no founder qualifies, create a record
from this organism's DNA. Its ID equals its first member's numeric organism ID,
so IDs increase with possible gaps and require no independent allocator. Names
are exactly `plant-N`, `herbivore-N`, or `carnivore-N`, decimal N with no padding.
Existing organisms never change species, and founders never drift toward their
survivors. This prevents transitive genetic chaining and centroid drift.

Initial organisms classify in ID order with no ancestor and origin tick 0.
Only accepted births classify, at the existing sorted Commit (phase, sorted
biological parents, request sequence). Later newborns can join a founder made
earlier in that Commit. New species record their plant parent's species, or the
lower-organism-ID animal parent's species. Both animal biological parents remain
on the child. Matching an existing species preserves that record's ancestry.
Accepted requests capture ancestry alongside child DNA before parental death;
request time creates no species and increments no membership count.

Deaths immediately decrement species membership once. `living_count` therefore
reports actual current members even between internal stages. Extinction flags
are finalized after all births and death accounting at Commit. A species losing
its last adult can survive through a matching already-produced child; divergent
children instead leave an extinct parent species and living descendants. Extinct
records and their immutable exemplars remain forever and cannot reactivate,
even if a later organism has identical DNA. Queries describe the current state
at any engine tick, not arbitrary historical population snapshots.

Classification is bookkeeping. It does not gate mating, survival, feeding,
energy, mutation or reproduction. Animals of different species can mate when
their genetic distance satisfies the separate inclusive 1/5 compatibility rule.
No ecological defaults, configuration schema or RNG ordering changed.

Population owns the registry next to its lifecycle transactions. Species imports
only genome and organism value types; SpeciesId is defined in organism and
re-exported by species to avoid a module cycle. Whole-state Clone/PartialEq
includes the registry. `SPECIES_MODEL_VERSION = 1` identifies this policy.
Future checkpoint/hash work must retain every historical record, immutable
founder DNA, ancestry/ticks, model version and organism memberships. Names are
canonical; member counts must be validated or rebuilt from living records.
Validate uniqueness, kind/reference consistency, ancestor ID/origin ordering,
all ticks against the clock, extinction >= origin and no extinct living members.
Never reconstruct founders from survivors. There is no new species allocator.
No disk persistence format is implemented here.

Birth classification costs O(historical species * 12); extinction finalization
and living-species queries cost O(historical species), and history storage grows
with lifetime speciation. No performance or coexistence result is claimed.

Evidence: src/species.rs tests exact boundaries, nearest/tie selection, inactive
loci, immutable founders, multigeneration lineage and no resurrection;
src/population/species_tests.rs covers transaction rollback, sorted births,
parental death, divergent descendants and extinction timing;
src/simulation/species_tests.rs compares full-tick plant and both animal births
with independent raw-draw DNA references (bounded seed search finds plant seed 1
and both animal kinds seed 0). tests/species.rs checks public membership/counts,
query purity, absent kinds and four-seed 2200-tick full-state replay.
Exact executed commands/results are in TASK-017 implementation handoffs.

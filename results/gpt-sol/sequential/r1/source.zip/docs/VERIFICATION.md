# Delivery verification — TASK-028 IMPLEMENT cycle1

Current evidence is under [tasks/TASK-028/evidence](../tasks/TASK-028/evidence/).
This phase adds tests, external observation and documentation; production engine,
defaults, Cargo dependencies, state/checkpoint schemas and hunting model2 are
unchanged. The retained Git revision is the runtime-source baseline, with new
uncommitted delivery files identified separately; no phase commit was made by the
agent. `provenance.json` records source/binary SHA-256, working status/diff, tool
versions, CPU and environment. Final evidence manifest hashes relative paths;
it excludes itself. Build outputs in ignored target/dist are reproducible, not
tracked release artifacts. No installed-system files were read for provenance.

## Reproduction and recorded execution

All commands below ran from `/workspace`, except packaging tests deliberately use
unrelated directories with spaces. Captured command ledgers use argument arrays,
UTC start/end, wall times, deadlines, return codes, environment overrides and
stdout/stderr paths. No user input or Git network action is needed.

| Exact command | Exit | Evidence |
|---|---:|---|
| `./setup.sh` |0| `evidence/setup.log`; dependency setup and both release targets |
| `cargo build --locked --release --bin evosim --example balance_report` |0| `evidence/build-observer.log` |
| `./build.sh` |0| `evidence/build-dist.log` |
| `cargo test --locked --test reliability -- --nocapture` |0| `evidence/randomized-final.log`;72 cases,8 long; earlier macro compile failure retained as `randomized-compile-failure.log` |
| `python3 -m unittest discover -s tests -p test_reliability.py -v` |0| `evidence/python-reliability.log`;2 tests |
| `python3 tools/release_verify.py --mode contract --out-dir tasks/TASK-028/evidence/contract` |0| `evidence/contract.log`, contract/commands.json and assertions.json |
| `python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/D0.json --seeds 0,1,2 --ticks 10000 --label fixed --out-dir tasks/TASK-028/evidence/trials/D0` |0| trial-D0.log and trials/D0/commands.json |
| `python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/D1.json --seeds 0,1,2 --ticks 10000 --label demo --out-dir tasks/TASK-028/evidence/trials/D1` |0| trial-D1.log and trials/D1/commands.json |
| `python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/D2.json --seeds 0,1,2 --ticks 10000 --label demo --out-dir tasks/TASK-028/evidence/trials/D2` |0| trial-D2.log and trials/D2/commands.json |
| `python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/D3.json --seeds 0,1,2 --ticks 10000 --label demo --out-dir tasks/TASK-028/evidence/trials/D3` |0| trial-D3.log and trials/D3/commands.json |
| `python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/fixed.json --seeds 42,43,44 --ticks 10000 --label fixed --out-dir tasks/TASK-028/evidence/fixed` |0| formal-fixed.log and fixed/commands.json |
| `python3 tools/release_verify.py --mode long --config scenarios/demo.json --seeds 42,43,44 --ticks 10000 --label demo --out-dir tasks/TASK-028/evidence/demo` |0| formal-demo.log and demo/commands.json |
| `python3 tasks/TASK-028/verify-ui.py` |0| ui.log, ui/commands.json, ui/validated.json, actual screenshots |

The one complete test command is `./test.sh` (exit0): **233 Rust tests,26 Python
tests and3 Node scripts pass**, no Python/root packaging skips. One debug guard
is intentionally ignored and explicitly passes in release (859.515 ticks/s,
minimum2304 living,tick1100). Final formatting,
manifest and scope checks are recorded in `evidence/test-summary.json` and the
implementation handoff; full stdout/stderr is `evidence/full-suite.log`.
The suite itself runs setup twice and build again, so packaging is checked after
all tests have been added. Existing debug performance test is intentionally ignored
and then explicitly executed in release by test.sh. Root chroot test must run
rather than skip for release evidence.

## Contract clause matrix

The following named tests are in the final one-command suite. Their individual
`ok` results are preserved in full-suite.log; independent release command ledgers
supply host/musl and actual UI evidence as specified. Entries are assertions,
not inferences from a successful exit alone.

| CONTRACT clause | Check and result assertion | Evidence |
|---|---|---|
| §1 three executable entry points, any cwd, noninteractive | Entrypoints.test_executable_files and setUpClass run setup twice/build from unrelated spaced cwd; failures propagate | full-suite.log, test_entrypoints.py |
| §1 setup idempotent/build prerequisites | Two successful setup invocations, locked host+musl builds, subsequent build | full-suite.log; setup.log |
| §1 offline runtime/no display | Static dist runs version/run/save/load/batch with seccomp denying socket/connect/socketpair; negative control socket creation fails EPERM. Empty chroot removes installed runtimes/libraries/assets; DISPLAY unset | Reliability.test_network_denied_runtime_and_negative_control; copied-root test |
| §2 version | One JSON stdout object, exact name/version/contract1, no stderr; host/dist/copied | Entrypoints.test_version_json, test_copied_distribution_in_empty_root; contract commands |
| §2 run --config/seed/ticks/out | Production-engine oracle, seed override, exact tick_end, zero/nonmultiple horizons, clean success | run_cli::sampling_schema_and_direct_engine_oracle, seed_override_validation_precision_and_sampling_independence; contract replay |
| §2 run sampling | Start/everyK/end unique ascending, default max(1,N/100), zero horizon, K>N, loaded relative interval | run_cli sampling test; checkpoint_cli::split_zero_and_nonzero_relative_sampling_chain_and_seed |
| §2 save/load/additional ticks/replacement | Exact final/totals/hash split continuation, absolute tick_start/end; replace loaded save permitted | contract ledger splits0/37/117 at300; checkpoint_cli; copied-root splits0/7/13 at30 |
| §2 batch fixed interface | seed1/2/3 files and summary, each final/totals/series/hash equals standalone; demo and default seed42/43/44 short batches | contract/commands.json; ui/commands.json; batch_cli::contract_and_matrix_equal_standalone_and_repeat |
| §2 ordinary UI | Real server/browser create and navigate map, controls, inspector, editor, charts, files; owner uses same Simulation | test_ui, test_ui_controls, test_ui_experiments; full-suite.log |
| §2 smoke | Default and demo actual10 ticks, positive draws, CLI hash parity, exit0 within60s | ui/validated.json, commands0..9 with per-command deadlines |
| §2 screenshots | Default and demo actual100 ticks, real browser captures main/charts/inspector,1440×900 main PNG, CLI hash parity, exit0 within120s | ui/default/main.png, ui/demo/main.png, ui/validated.json and command ledger |
| §3 JSON fixed keys/default optional settings | Minimal example accepted; all fixed keys required; all types/ranges/overflow/unknown/null/zero edge cases | config::fixed_keys_defaults_and_zero_populations, missing_fixed_keys, all_fields_wrong_types_and_optional_defaults, boundaries_and_overflow, syntax_unknown_and_duplicates; formal fixed.json |
| §3 dimensions>=1/initial>=0 | Tiny/one-axis/stacked/empty randomized cases, dedicated input boundaries | reliability; config; UI.test_empty_and_stacked_single_cell_render |
| §4 required result object/keys | Direct immutable-engine oracle for contract/seed/ticks/world/final counts/species, metrics and cumulative accounting | run_cli::sampling_schema_and_direct_engine_oracle; analytic_counters_match_final_and_repeat_output |
| §4 cumulative totals after loading | Exact initial+births-deaths=final and continued cumulative totals | checkpoint_cli and checkpoint::complete_roundtrip_and_future_continuation; observer CSV accounting |
| §4 complete-state lowercase hash | Read-only canonical SHA-256, known independent byte/hash vector; repeat whole state including RNG/config/DNA/world/clock/history, different seeds | persistence unit tests; state_hash::replay_hashing_is_readonly_and_full_seed_is_retained; checkpoint and randomized tests |
| §4 timing | Nonnegative finite loop-only elapsed/tps; zero ticks both0; timer surrounds tick loop and excludes startup/output | run_cli sampling test, source `src/cli/run.rs`; raw formal JSON timing fields |
| §5.1 same machine/build deterministic | Repeat final/totals/series/hash, seed override and sampling purity; independent host/musl replay rather than cross-libm equality | contract ledger, Entrypoints.test_real_run_replay_headless_and_spaced_paths, reliability equality/hash every31 ticks |
| §5.2 checkpoint equivalence | Complete state and canonical bytes restored, continued RNG/resources/weather/genomes/cooldowns/history, no initialization on load | checkpoint::complete_roundtrip_and_future_continuation, long_production_recruitment_and_resource_extremes, resting_parents_and_hungry_offspring_resume_exactly; randomized16 midpoints |
| §5.3 absorbing zero/no food | Initial absent plants -> herbivores then carnivores extinct; natural extinct kinds never replenish; full requested empty tail | ecology_integration::food_removal_causes_final_extinction_with_empty_tail, naturally_extinct_plants_never_return; run_cli::exact_extinct_tails_without_replenishment; formal10000 results |
| §5.4 args/config/checkpoint failure status2 | Malformed/missing/wrong types/out-of-range/bad checkpoint/invalid paths; stderr nonempty, stdout empty, result absent, old regular output preserved | run_cli::argument_configuration_and_output_errors_are_transactional; checkpoint_cli::invalid_files_options_and_paths_preserve_outputs; batch_cli::validation_preserves_existing_outputs |
| §5.4 actually unreadable config | Run launcher as numeric uid/gid65534 against root600 file in traversable/writable output folder; exit2+stderr, no result | contract command final entry; chmod under root alone not used as evidence |
| §5.4 malformed checkpoint | Corruption/truncation/arbitrary bytes/semantic invariants and hunting-model1 incompatibility rejected | checkpoint::envelope_corruption_truncation_and_arbitrary_bytes, old_hunting_model_is_rejected_even_with_valid_checksum, owner codec unit tests |
| §5.5 clean output | version single JSON, successful run/batch silent, errors stderr; UI URL/automation stderr | entrypoints, run_cli, batch_cli, contract ledger; UI stderr files |
| §6 portable self-contained dist | readelf has neither INTERP nor NEEDED; copied executable in otherwise empty root executes version/run incl analytics/save/load/batch, no installed runtime/source/display; real root execution, no skip | Entrypoints.test_static_elf, test_copied_distribution_in_empty_root; full-suite.log |
| §7 demo file/README/acceptance | Frozen valid JSON, accepted by run/batch/real ui; one-command README demo | scenarios/demo.json, selection.json, demo/*, ui/* |
| §7 fixed and demo10000×>=3 within300/900s | Per-seed CLI deadlines, full ticks, exact observer rows0..10000, counters and hash agreement; all completed well below deadline | fixed/commands.json, demo/commands.json, per-seed CSV/JSON, observer.json, validated.json |

No test here claims a new physical Ubuntu machine was provisioned. Static ELF,
empty chroot and syscall network denial are complementary checks of the required
headless distribution interface; browser prerequisites are outside that runtime.
The source embeds UI assets and automation, with no runtime remote asset fetch.

## Randomized reliability corpus

Independent fixed-state LCG seed0x0285eed produces72 unique simulation seeds and
bounded valid configurations.64 horizons are128..256 ticks;8 are2200 ticks.
Dimensions1..16×1..12 include explicit empty,1×1 stacked, and one-axis cases;
counts span0..64/0..16/0..4. Climate/weather/mutation/resource/energy/cooldown
parameters cover disabled/ordinary/max/extreme-cost endpoints. This is a
reproducible bounded corpus, not exhaustive input-space exploration.

At all29,838 completed states, two engines compare complete equality, including
RNG/private history, while only one is queried. Hashes compare every31 ticks and
at boundaries;16 midpoint checkpoints compare bytes and future continuation.
Independent oracles check kind/accounting/death-cause sums/monotone counters,
absorbing zero/frozen births, finite bounded energy/health/resources/climate,
validated trait values, age/birth/parent identity/cooldown time, species members
and no extinct species revival, weather tick, signed wrapping, nearby IDs against
unsigned-distance brute force and unique radius cells (including usize::MAX).
Observed:97,353 moving animal ticks,3,109 births,4,240 deaths in the final corpus.
Dedicated nonvacuous sexual reproduction/speciation/seam tests remain necessary;
random observation alone cannot promise those rare behaviors. `--nocapture` log
retains generator/case/full config; failing equality includes case/tick.

Synthetic Python fixtures cover initial absence, extinction at1 and horizon,
tied extinctions, all-positive censoring, truncated/malformed CSV and CLI hash
mismatch. The wrapper requires CLI result files; validator errors are nonzero and
passing completion is written only after every assertion.

## Demo comparison and formal outcomes

[selection.json](../tasks/TASK-028/evidence/selection.json) froze D3 before formal
seed42..44 runs. All inputs keep64×48; only existing documented parameters vary.

| Candidate | Initial P/H/C | Optional changes | First zeros seeds0/1/2 | Median/min |
|---|---|---|---|---|
| D0 |400/120/20|none|312/313/313|313/312|
| D1 |2000/60/8|none|854/867/838|854/838|
| D2 |2000/60/8|resource regeneration4|854/874/817|854/817|
| D3 (chosen) |2000/60/8|regeneration4; animal cooldown300|1113/1113/1110|1113/1110|

Choose highest median, then minimum, then fewer optional changes, then candidate
order. No formal-seed adjustment, mechanism change or rescue was made. All12
candidate runs went10000 ticks. Exploratory D3 timing overlapped randomized tests;
fixed formal launch began near the end of those tests. These wall measurements
still demonstrate completion deadlines but are not controlled performance claims.
Demo formal/UI/full-suite runs were isolated; no browser commands overlapped.

| Input/seed | First zeros P/H/C | First any F | Positive completed ticks | Final P/H/C |
|---|---|---:|---:|---|
| fixed42 |315/750/1653|315|314|0/0/0|
| fixed43 |315/781/1718|315|314|0/0/0|
| fixed44 |310/836/1669|310|309|0/0/0|
| demo42 |1111/1859/2718|1111|1110|0/0/0|
| demo43 |1113/1854/2536|1113|1112|0/0/0|
| demo44 |1112/1868/2535|1112|1111|0/0/0|

First-zero F means coexistence over[0,F); positive completed samples are1..F-1.
An initial absence would yieldF=0 and zero positive completed ticks. No extinction
throughN would have nullF, N positive ticks and right_censored=true. None of the
formal runs is censored. Timing fields include long empty tails: their high
whole-run ticks/s do not measure2,000-entity sustained ecological throughput.
Use PERFORMANCE.md and the release guard for that distinct measurement.

Raw JSON includes seed, final/species, totals, series, hash and loop timings;
observer CSV has10001 contiguous rows with counts and every cause counter. SVGs
show exact population curves. Validator checks every row, monotonicity, accounting,
absorbing zeros, first-zero records and final CLI hash/totals/count parity. Runs
use ordinary production ticks and are read-only observations. SHA-256 manifest
and final provenance bind these artifacts to the current unchanged engine.

The [self-audit](SELF_AUDIT.md) enumerates every PROJECT subrequirement, design
choice, forbidden-mechanism check and known limitation. Stronger long coexistence,
a dedicated generation chart, realism and unlimited history/memory are not claimed.


## Independent review cycle1

PASS: all eight delivery criteria independently checked. Fresh `./test.sh` exits0
with233 Rust tests,26 Python tests and3 Node scripts; no Python skip. Separate
host/musl contract probes, six exact10000-tick formal replays, independent CSV/
accounting/zero audit and all293 retained artifact digests pass. Fresh demo real
browser capture reaches100 ticks and1440x900 with headless hash parity. Exact
commands, results and retained logs are indexed in
[review handoff](../tasks/TASK-028/handoffs/review-cycle1.md).

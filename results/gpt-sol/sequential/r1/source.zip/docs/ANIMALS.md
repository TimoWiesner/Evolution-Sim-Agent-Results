# Animal navigation, grazing, hunting and reproduction (hunting2; other models1)

Living herbivores and carnivores sense all organisms within their DNA-derived
inclusive Chebyshev vision radius (1..8), across every torus seam. Public
`Population::sense(id)` returns ascending IDs excluding the observer, including
co-located organisms. Missing/dead observers and plants return None. Sensing is
observational, uses the spatial index and consumes no RNG.

After age/expiry and animal upkeep, herbivores pursue the nearest eligible
visible plant and carnivores the nearest visible herbivore. Equal distance chooses lower ID. The selected target
cell is held for this action. Each adjacent step follows the sign of each
shortest wrapped displacement; exact half-axis ties choose positive. Each step
reduces remaining distance by one. Both animal kinds stop within feeding/attack reach 1.
After these actions, animal mating follows the policy below.

Without visible food, each step samples uniformly from unique adjacent cells,
excluding origin, sorted by (y,x). The sole engine RNG calls below(count), even
when count is one. In a 1x1 world there is no destination, draw or charge.
Neighbors are recomputed each step; revisiting a cell is allowed. No heading or
target is retained across ticks.

Inherited speed (1..4) is the maximum number of adjacent steps per tick. Each
completed step costs `animals.movement_cost * speed * metabolic_multiplier`.
Thus both greater traveled distance and greater inherited speed increase cost;
metabolism ranges from 0.5 to 2. Zero configured cost disables charges. Cost is
finite and at most 8,000,000. An unaffordable step stops before RNG selection or
movement. An affordable step moves then debits energy; exact exhaustion kills
immediately by Starvation, removes the index entry, and prevents later steps.
Stationary animals pay no movement charge. Both animal kinds additionally pay
the every-tick upkeep below, even when they cannot afford movement.

All kinds permit unlimited co-occupancy. Founders, movement and committed births
apply this rule. Plant reproduction's rejection of planted/reserved sites is a
local establishment policy, not a universal capacity; existing stacks are valid.
Navigation never blocks on occupants. Population primitives update the cache
immediately, including lethal debits. Later actors sense earlier actors' current
positions; newborns still first act next tick.

Implementation: private ecology/animals helpers import config/traits/topology/rng
only; Population owns sensing/mutations; Simulation orchestrates actual steps and
the single RNG. No new authoritative state, dependency, config key or CLI command.
Future full-state persistence must encode movement model identity and existing
DNA, positions, vitals, settings and complete RNG; rebuild/exclude the derived
index. Temporary targets and neighbor lists are absent at completed ticks.

Evidence: helper tests exhaust all source/target pairs in worlds 1..8 per axis
against an unsigned distance oracle and verify unique sorted wander draws on tiny
axes. Private real-executor tests check every speed, metabolic endpoints, energy
ledgers, per-step index visibility, exact exhaustion, bounds, DNA vision, target
ranking and RNG phase order. Public tests exercise actual seam-crossing ticks,
sharing, observational sensing and four-seed 2200-tick positive-cost replay with
conservation and spatial oracles. Exact commands/results and limitations are in
TASK-013 implementation handoffs. No throughput or coexistence claim.


## Herbivore grazing model 1 (TASK-014, ADR-011)

Age expiry precedes physiology. A living herbivore pays
`max(animals.basal_cost, 1e-9) * metabolic_multiplier * (1 + stress)` energy,
where `stress = clamp(abs(current_temperature - preferred_temperature) /
climate_tolerance - 1, 0, 1)`. Current temperature includes this tick's seasons
and weather. Extreme mismatch costs up to twice ideal upkeep; metabolism is
inherited. The numerical basal floor ensures a representable debit even for
subnormal configured values at the 1000-unit capacity. It is a uniform cost,
never a population-dependent intervention. Exhaustion kills immediately before
sensing, movement or eating, with one Starvation record at Commit.

One indexed sense snapshot supplies plants and visible carnivores. Risk tolerance
below 0.5 excludes plants within wrapped Chebyshev distance 1 of any sensed
carnivore; at least 0.5 allows those plants. Hidden predators have no influence.
Among eligible plants choose distance then ID. This is inherited avoidance of
feeding locations; it neither implements hunting nor grants protection.

Pursuit uses the paid adjacent executor, at most inherited speed steps, stopping
at distance <=1. Own cell and all eight adjacent cells are feeding reach,
including wrapped seams and degenerate axes. No eligible food means ordinary
random exploration, with no opportunistic bite until a later action senses it.
A target beyond reach after movement supplies nothing. A lethal movement debit
preempts feeding. An already adjacent animal may feed without paying for a step.

Take at most one bite from the chosen living plant per tick:
`request = min(4, plant_energy, (1000 - herbivore_energy) / 0.8)`.
Debit the plant through Population, then measure actual before/after energy
(after=0 if removed). Credit only 0.8 times this realized removal; the rest
is dissipated. If subtraction rounds to no change, no gain occurs. Vitals remain
bounded and transfer tests allow at most 1e-10 absolute arithmetic roundoff.
There is no health payout or direct environmental resource consumption.

A depleted plant disappears immediately from sense/index before the next
herbivore, cannot reproduce later that tick, and is counted once as Starvation.
Partial plants can grow again from environmental resources next tick. Plants
already paid maintenance and grew before grazing, so full-tick ledgers account
for both. Earlier stable IDs get first access to shared food.

Private ecology/herbivores helpers import only config/traits/topology and never
Population/Simulation. Simulation owns selection, movement and both ledgers.
No authoritative state, schema/default, dependency or public mutation API is
added. Maintenance, risk decisions and feeding consume no RNG; altered navigation
can change the number of exploration draws. Future checkpoint/hash must include
grazing model identity, effective basal settings and the existing full state;
transient targets/predator lists and derived index are excluded.

Evidence: src/simulation/herbivore_tests.rs exercises actual phases/full ticks for
reach/seams, vision/speed, all-speed paid pursuit, bounded one-target transfer,
partial/lethal bites, sequential depletion/cache/Commit, current climate, risk-only
paired genomes, hidden predators, maintenance/death priority and newborn timing.
Public tests/herbivore_feeding.rs verifies every-tick positive costs, extinction,
real feeding and four-seed 2200-tick replay. Existing mixed replay adds spatial
oracles and conservation. Exact commands and results: TASK-014 implementation
handoffs. Risk filtering costs O(visible plants * visible predators); no throughput
or coexistence claim, and cautious animals can starve despite available risky food.


## Carnivore hunting model 1 (TASK-015, ADR-012)

After age expiry, carnivores pay the same current-temperature maintenance as
herbivores. A survivor senses once and chooses the nearest living visible
herbivore, breaking ties by ID. Paid pursuit stops at wrapped Chebyshev distance
<=1; same cell and diagonal/seam neighbors are valid attack positions. No visible
prey means ordinary paid exploration, with no opportunistic attack this tick.
Recheck target and predator liveness, prey kind and reach after movement.

At most one attack per action costs `0.5 * metabolism` (0.25..1 energy), paid
before a trial. Insufficient energy skips payment/trial; exact exhaustion causes
Starvation and prevents the trial. Both completed successes and failures pay.
For predator C and herbivore H, compute
`A = C.strength * (1+C.aggression) * C.health/C.max_health` and
`D = H.strength * (1+H.speed/4) * H.health/H.max_health`.
Use `floor(clamp(A/(A+D),0.1,0.9)*1000000)` as numerator in one engine
`chance(n,1000000)`. Multiplication groups each health fraction first. Only when
both scores round to zero for subnormal health, divide both health inputs by
their common maximum before computing scores; this cancels in the ratio and
avoids 0/0. No new generator or authoritative state is added.

Failure leaves prey unchanged. Success snapshots its current energy P and kills
through Population with Predation. Only a true kill credits `min(0.8*P,1000-C.energy)`.
Predict the capped floating addition; if realized gain would exceed P, credit
zero. Thus even subnormal prey cannot create an ulp of energy. No corpse, health
payout or environmental resource withdrawal exists; unused energy dissipates.
Herbivores acted earlier, so P includes this tick's grazing/upkeep/movement.

Carnivores act sequentially in ascending ID order. Immediate prey removal updates
sense/index before later predators select. A failed earlier attack leaves that
prey available; a successful one prevents repeated death or payout. Only one
attempt per predator bounds consumption, including stacked prey. Death records
and cause totals commit once through existing lifecycle primitives.

Private ecology/carnivores imports only traits; Simulation owns RNG and mutations.
Future persistence must include hunting model identity and full existing state,
including DNA/vitals/RNG/settings/climate/resources/lifecycle, excluding transient
targets and derived index. Stable-ID access bias and initial full-energy predation
bursts are accepted; no coexistence or throughput claim. Animal births remain
outside this task. Exact test commands/results: TASK-015 implementation handoffs.
Production tests cover 512 independent attack outcomes, 4096 paired trials per
trait change, health, reach/vision/seams/speeds, competition, numeric nutrition,
paid/lethal gates, RNG order, newborn timing and public starvation/OldAge ticks.


## Sexual reproduction model 1 (TASK-016, ADR-013)

Reproduction runs after all actions, first plants, then herbivores, then
carnivores. For each animal kind, visit ascending living IDs. Parents must be
distinct same-kind animals, within wrapped Chebyshev distance 1 (including shared
cells), age >= max(1, lifespan/10), genetically compatible, energetically eligible
and out of cooldown. Select the nearest eligible mate, breaking ties by ID.
Compatibility is inclusive integer `5 * distance_sum <= 786420`, independent of
species labels. No mate-seeking movement or global population gate is added.

A temporary attempted-ID set permits only one trial per animal per tick, even
on failure. A failed trial changes neither energy nor cooldown and may retry
next tick. The exact trial is `chance(F1*F2,65535*65535)` with raw fertility
alleles; zero in either parent fails without a draw, both maxima succeed without
a draw. Success uses the existing sorted-parent crossover then configured
mutation. Expected ID/generation failures retain the fertility draw but roll back
genetics and incur no payment. No fallback mate is tried that tick.

One immediate child is queued at the lower-ID parent's cell. BOTH parents pay
`E=animals.reproduction_energy`; each must have energy strictly greater than E,
a positive finite residual and a representable actual debit. The sum of actual
floating losses must fund the child's E energy (<=1000). At default E=30, total
parent loss is 60, child energy is 30 and 30 dissipates. E>=1000 disables births
naturally at bounded capacity. Tiny costs rounded away cannot produce children.
Child health is 10, age 0, generation max(parent generations)+1 and sorted parent
IDs; DNA is captured at acceptance. Commit inserts the child/index without RNG;
it first acts next tick. Unlimited animal co-occupancy applies.

`Organism::last_reproduction_tick()` exposes new authoritative Option<u64> state,
None for founders and children. Successful acceptance stamps BOTH parents
immediately. Ready means no previous birth or checked `tick-last >= cooldown`;
future timestamps fail. Cooldown C excludes t through t+C-1 and permits t+C.
Elapsed subtraction avoids overflow even for u64::MAX. Clone/equality retain it.
Future checkpoint/hash MUST preserve its discriminant and value, validate that
animal timestamps are <= engine tick, and include model identity, effective
settings and full existing state. Never reset cooldown on load. Attempted sets
and spatial cache are transient/derived and excluded. No disk persistence here.

Pure ecology/reproduction helpers import genome/traits only. Simulation owns
pair selection, sole RNG, queue/payment ordering; Population owns atomic pair
stamping and existing mutations. Local dense stacks can yield quadratic search;
stable-ID access bias and finite founder-reserve birth bursts are simplifications.
No performance or coexistence claim. Species classification remains TASK-017.
Tests in src/simulation/animal_reproduction_tests.rs and tests/animal_reproduction.rs
exercise both kinds, paid births, gates, seams, offspring DNA/lineage, exact trial
and mutation streams, cooldown boundaries, overflow rejection, phase order and
solitary 2200-tick continuation. Exact commands/results: TASK-016 handoffs.

TASK-018 raises the default mating cooldown from 20 to 100 ticks; per-parent
energy cost remains 30. The uniform waiting period slows recruitment and grazing
pressure without consulting population counts. See ECOLOGY.md for experiments.


## TASK-027: hunting model2, local satiety

After aging/expiry and ordinary thermal upkeep/liveness, carnivores hunt only
when their own remaining energy is below750. At/above750 they rest: no sensing,
pursuit, wandering, attack or action RNG. Mating still follows ordinary paid
maturity/adjacency/cooldown gates. Hungry action equations/order are unchanged.
No timer, new state, config key, global census feedback or energy source exists.
Numeric defaults remain unchanged. Identity2 rejects model1 checkpoints; state
schema1/envelope1 and authoritative inventory are unchanged. BALANCE.md records
the pre-change diagnosis, both measured trials and held-out collapse: satiety
delays first extinction but does not establish sustained coexistence.

# Live world interface

`./evosim ui [--config FILE]` prints an ephemeral `http://127.0.0.1:PORT/#TOKEN`
URL on stderr. Open that complete URL in a local browser. Ctrl-C stops the server.
The default is the baseline preset. Assets are embedded in the executable and
need no internet connection, npm packages, external fonts or workspace files.
Normal operation needs only the executable and a browser. Headless commands
continue to need neither a browser nor Node.

The dark Living Atlas view paints every cell from the actual immutable base biome,
then all living records in stable-ID order within plant, herbivore and carnivore
layers. Plants are small green discs; herbivores are larger ivory circles;
carnivores are coral triangles. A permanent legend identifies all three even when
extinct and explains all five biome colours. Markers stay within their cells;
stacked same-kind records occlude, with a total count badge at >=24 screen pixels
per cell. At distant zoom tiny glyphs may occlude. No organism is invented or
moved to improve the view. The single rectangle represents the canonical torus;
opposite edges connect. The base-biome view deliberately does not animate weather.

Drag the map to pan, scroll to zoom around the cursor, use +/- to zoom around the
centre, or Fit world to recover the whole map. Resizing fits again. Device pixel
ratio is respected. Navigation changes browser camera state only. The sidebar includes a live organism inspector. New experiment opens a draft
configuration editor; Charts opens five live plots. World returns to the map. Loading and disconnected/error messages appear over the
map. Keyboard focus is visible on camera buttons.

## Ownership and protocol

Private `ui_server` owns one ordinary `Simulation`. The same `advance_one_tick`
used by `run` advances it at the chosen advisory5/20/60Hz, at most one tick per event
loop. No catch-up burst or biological adjustment is made for slow hardware.
After the first actual draw the browser sends POST `/api/ready` once to start the
clock; repeated ready calls cannot reset it. Frames poll serially at10Hz, with
camera redraws on requestAnimationFrame independently of fetch. Empty worlds keep
ticking. Stale frame replies are discarded. No camera, DTO, wall time, driver,
capability or render history enters hashes or checkpoints. No core module imports
UI code. Timed engine failures stop the server with stderr/status2; explicit command
failures are shown inline and pause on engine failure. Diagnostics hash only in automation mode, not every normal poll.

Fixed embedded GET routes: `/`, `/style.css`, `/camera.js`, `/configuration.js`, `/charts.js`, `/experiments.js`, `/app.js`.
GET `/api/world`: `ui_schema:3`, numeric width/height, row-major biome names in
`cells` (polar/tundra/temperate/dry/tropical). Cached outside the engine and rebuilt on reset/load; includes decimal-string epoch.
GET `/api/frame`: `ui_schema:3`, exact decimal-string `tick`, three decimal-string
counts in plant/herbivore/carnivore order, and every living organism as
`[id decimal string,kind code 0/1/2,x,y]` in ascending ID order. Map snapshot work is
O(cells) once and O(living) per frame; chart capture and serialization add the
bounded costs described below; only the selected organism adds genome/traits. Its terminal death transition
scans existing death history once. All numeric
IDs/ticks/counts remain strings in JavaScript; coordinates use Canvas numbers.
Huge valid worlds or populations may exceed browser memory/coordinate precision
or serialization budgets; no new configuration size cap is imposed.

The loopback-only server checks exact Host and rejects foreign Origin. POST ready
requires a192-bit OS-entropy capability from the URL fragment in
`X-Evosim-Token`, separate from the engine RNG. Checkpoint load and configuration validation/start accept bounded bodies; other nonempty/transfer-encoded bodies
receive413, foreign capability/host/origin403,
wrong methods405 and unknown routes404. Normal operation has no filesystem route
or arbitrary command endpoint. CSP restricts assets/connections to the local
origin. This is a local application adapter, not a public multi-user service.
Four response workers and a bounded four-reply queue keep slow socket writes
outside the sole engine owner's loop. At saturation excess requests are closed;
the page can retry. Workers receive only owned response bytes and requests, never
engine references. Slow clients can occupy workers; resource exhaustion is not a
service guarantee. tiny_http owns connection parsing. Server polling waits<=10ms.

## Real browser automation

`./evosim ui --smoke-test` and `./evosim ui --screenshots DIR` accept optional
`--config FILE`. DIR must already exist and be writable. Unknown/duplicate flags,
missing values, invalid configs or both modes fail with status2 before startup.
The actual engine stops at exactly10 or100 ticks. The embedded CommonJS driver
uses Node>=18 built-ins, launches actual Chromium over private CDP pipes, attaches
the page, waits for completed Canvas draws and the target tick, verifies legends,
collects uncaught JS errors, then captures the real1440x900 page for screenshots.
`main.png` is checked for at least1280x720. No second image renderer is used.
Automation evidence (tick, draw count, canvas dimensions and engine hash) goes to
stderr. Smoke internal deadline45s; screenshots105s, with earlier Node deadlines.
Driver cleanup waits for browser shutdown, retries profile removal, and the Rust
parent owns a process group/profile guard for returned failures/timeouts. Abrupt
SIGKILL/host crash cannot guarantee cleanup. Existing screenshots are preserved
until successful capture; writing main.png itself is not a multi-file transaction.

Chromium discovery: CHROME_BIN, then PUPPETEER_EXECUTABLE_PATH, then `chromium` on
PATH. DISPLAY selects a headed browser (including xvfb); absent DISPLAY selects
headless Chromium. Root uses `--no-sandbox`. The benchmark supplies Chromium131,
Node18 and xvfb. setup checks Node>=18 and installs missing Node with
`apt-get update` then `apt-get install -y --no-install-recommends nodejs`.
Do not replace benchmark Chromium with Ubuntu's snap-dependent chromium package.
Browser absence is an explicit failure, never a skipped test. tiny_http0.12.0 and
ascii1.1.0/chunked_transfer1.5.0/httpdate1.0.3/log0.4.35 are locked pure-Rust HTTP
crates; host and static-musl builds are tested. No system package was installed
in TASK-023; exact pre-existing musl prerequisites remain in STATE.

Tests: `cargo test --locked --lib ui_server`, `node tests/ui_camera.cjs`, and
`python3 -m unittest discover -s tests -p test_ui.py -v`. `./test.sh` includes all
of these plus existing headless/checkpoint/packaging checks. Real CDP tests drag,
wheel and Fit, assert all legend labels, read Canvas pixels and measure completed
simulation-frame renders for5.2s in a mixed initial1000 world and a sustained1000
plant world (zero growth/mutation, unaffordable reproduction). Measurements and
hardware are recorded in TASK-023 implementation handoffs, not universal promises.


## Controls, inspection and checkpoint files (TASK-024)

Visible buttons provide Run, Pause, Step and Reset, with three speed choices:
Slow5, Normal20 and Fast60 target ticks/s. Rates are nonnegative closed choices,
not arbitrary numeric inputs. No new keyboard shortcuts. Step pauses and performs
exactly one production tick, including on an extinct world. Pause acknowledgement
is a scheduling barrier. Repeated Run/Pause is idempotent; no catch-up bursts.
Speed reschedules the next tick without advancing. Hardware/loop overhead may
reduce rates. Reset pauses at tick0, using the exact current effective config and
seed; after Load this means the loaded checkpoint's config. Chosen speed survives
reset/load. Tick and three populations stay above the inspector's independent
scroll area at laptop sizes, including when a population is zero.

Click a cell to inspect its organism. A cell with multiple organisms shows every
occupant in stable ID order as kind/ID buttons, including occluded markers.
Panning requires a4 CSS pixel drag threshold; drags never select. Selection follows
a stable ID, highlighted at its current cell, with live age/energy/health, kind,
species ID/name, generation, parents, twelve named expressed traits and all twelve
exact decimal u16 alleles in fixed locus order (genome version1). Founders say
“None (initial organism)”; offspring have one plant or two animal parents. These
are simplified haploid loci, not diploid chromosomes. Expressed values use readable
precision; exact alleles remain visible. On death the panel retains last observed
data labelled with its observation tick, plus actual death tick/cause. It persists
until Clear/reselection/reset/load. Inspector refresh preserves scroll position.
Selection between a frame and the command can fail if the organism has died;
inline feedback reports this without selecting a replacement.

Save checkpoint prepares a browser download of the existing format1 binary bytes,
filename evosim-tick-T.evo. “Download prepared” means the browser received bytes;
browser download settings, disk completion and disk errors remain browser-owned.
Load checkpoint opens a file input and uploads the selected binary file. Cancelling
changes nothing. Successful load validates and builds the replacement world before
swapping, pauses at the saved tick and clears selection. Invalid data reports an
error without changing the session. UI uploads require1..64MiB; larger checkpoints
can use the CLI. Files are exactly interoperable with `run --load` / `--save`; no
second codec or frame-as-state format exists. Save is observational and preserves
engine RNG/hash. All UI scheduling/selection/revision/camera fields are excluded
from checkpoints and hashes.

Additional POST routes (capability header required, no token in query/path):
- `/api/control/run`, `/pause`, `/step`, `/reset`, `/clear-selection`,
  `/speed/slow|normal|fast`, `/select/<nonzero-u64-id>` under `/api/control/`.
- `/api/checkpoint/save`: bodyless, application/octet-stream attachment reply.
- `/api/checkpoint/load`: application/octet-stream, Content-Length1..64MiB,
  no Transfer-Encoding. Decode failures400, invalid size413, wrong content type415.

All controls/checkpoint routes require `X-Evosim-Epoch` matching the current
world's decimal-string epoch; stale/missing epoch409. Unknown controls/invalid
speed/ID400, wrong method405, invalid capability403. Ready remains bodyless,
idempotent and does not require epoch. Frame schema2 adds decimal-string epoch
and revision, booleans ready/running, speed name, nullable selected inspector.
Inspector IDs/age/parents/generation/observation/death ticks are decimal strings;
traits are numbers, alleles exact small integers. Browser requests are serialized,
older revisions discarded; changed epochs fetch matching world dimensions before
render, clear old chooser and refit camera. A newer world than a frame is retried
on the next poll. Server serializes commands in arrival/application order.

Two blocking ingress workers, two queued requests and a bounded two-completion
queue isolate socket reads from the engine owner. Headers/auth/size are checked
before dispatch and epoch again on completion. Saturation503; a full completion
queue closes excess requests. Slow uploads can occupy ingress capacity but do not
block independent control connections, ticks or automation deadlines. Workers are
not joined on shutdown (a body reader may stall); process exit cleans threads.
Codec/hash/cache work itself runs synchronously on the owner and large states can
delay responsiveness or exhaust memory. Existing bounded response workers remain.
No public-service availability guarantee or filesystem path endpoint is provided.

Display-free tests: `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib ui_server`
and `python3 -m unittest discover -s tests -p test_ui_controls.py -k without_display -v`
(the second is actual HTTP controls/CLI byte parity). The full Python module also
checks slow ingress/stale completion and actual CDP controls/map selection/death,
browser file download and DOM file-input upload, backward ticks/stale revisions,
1280x720/1440x900 visibility and exact future CLI checkpoint parity. `./test.sh`
includes these tests. Evidence and honest limitations: TASK-024 implementation
handoffs. No new crate/system dependency is added by this task.

At widths below900px a sticky compact tick/population summary accompanies controls,
so scrolling the map/inspector does not hide live totals. Screenshot automation can
also write inspector.png after a real map click/chooser at the same tick100.

## Experiments and configuration JSON (TASK-025)

New experiment edits a draft independently of the active world, which may keep
running. Choose baseline, seasonal or plant-only, then edit any of the21 existing
numeric leaves: seed, two dimensions, three populations, four climate, two genetics,
five plant and four animal settings. Labels include units/bounds. The normal core
configuration validator remains authoritative; no defaults or ecology change.
Field errors appear beside inputs with aria-invalid/aria-describedby. A world-area
overflow marks both dimensions; a total-population error marks the population group.
File syntax, unknown paths and construction errors also appear above the form.
Invalid input never replaces the world. Only the first server validation error is
returned; correct it to expose another. Lexical errors can mark several fields.

Start world validates and constructs the complete replacement engine, biome cache
and initial chart data before swapping, then pauses at tick0, clears selection and
increments epoch/revision. Run resumes. Speed is retained; Reset always uses the
active configuration, including one adopted from a loaded checkpoint. Draft edits,
preset choice, import and export never change the running engine. Loading/resetting
while a draft exists retains it and labels the active-world change; Use active
configuration explicitly refreshes it. Presets are choices rather than new models.

Import JSON uses a browser file input; validation succeeds before filling the draft.
An invalid file leaves draft and engine intact. Export JSON validates the draft and
downloads complete effective configuration (including defaults) as evosim-config.json.
Export followed by import preserves Config equality, rather than whitespace or
omitted-default formatting. Inputs are strings, including arbitrarily large signed
seeds and u64 settings. Raw JSON goes to Rust without JavaScript numeric parsing.
The Rust response contains canonical_json as a string and a dotted-path fields map
of numeric token strings. Form assembly allowlists keys and JSON number grammar;
no Number conversion or float rounding occurs during config round trips. Integer
fields reject exponent/decimal notation; real fields accept JSON exponent notation.

GET `/api/config` returns `{epoch,active,presets}`. Each active/preset DTO has
`canonical_json` and `fields`. POST `/api/config/validate` and `/api/config/start`
accept raw JSON with application/json and Content-Length1..1MiB, with the existing
capability/epoch/Host/Origin checks. Two bounded ingress workers carry operation,
original epoch and owned bytes to the engine owner. No socket reads enter its loop.
Completion checks epoch again. Validate returns `{epoch,config}` without changing
revision; Start returns `{epoch,config,frame}`. Validation errors are400 JSON
`{path,message}`; invalid UTF-8 uses `$`. Header failures use413/415, stale409,
unauthorized403, method405 and saturation503. No server filesystem paths are exposed.
Browser commands share the existing serial queue, capture epoch/draft generation,
and lock form actions/inputs during requests. Late validation replies cannot
silently overwrite an edited draft or a newer accepted epoch.

## Chart data and rendering

Charts uses own Canvas drawing and pure display-free configuration/geometry modules,
with no new crate, npm, CDN or system dependency. Five cards show populations,
cumulative births/deaths, living species, selected trait mean and selected current
trait distribution. Every card has axis labels, exact first/last tick labels and
explicit kind legends; deaths use dashed lines. Null means form gaps. Latest values
are also text; extinct kinds show zero counts and absent means show a dash. The
trait selector covers all12 named expressed phenotypes, default speed. Units are
phenotype values, never raw alleles; plant inactive behavioral loci are still DNA.

Frame schema3 retains previous fields and adds `charts`:

- `chart_schema:1`, decimal-string `epoch`, `sample_every:"10"`, `capacity:2048`.
- `points`: `{tick,kinds:[plant,herbivore,carnivore]}`; each kind contains
  decimal-string `population,births,deaths,species` and `means`,12 nullable f64
  values in LOCUS_NAMES order. Births/deaths are cumulative since tick0, excluding
  initial organisms from births. Species counts living species only.
- `current`: `{tick,histograms:[...]}`,12 entries in LOCUS_NAMES order with
  `{name,edges:[21 finite numbers],counts:[[20 decimal strings];3]}`.

History starts at the actual initial/load tick, then records each completed
absolute tick divisible by10. Keep latest2048 stored samples plus a provisional
exact-current point when needed (at most2049 points, no duplicate ticks). Polling
never appends. Step updates current data even between samples. Reset, Start and
Load create a fresh history, never joining runs; checkpoint files do not contain
UI history and cannot recover earlier samples. Pause, speed, validation, export,
selection and trait selection preserve history. The visible window is labelled.

Twenty fixed equal-width bins use domains speed[1,4],strength[1,10],max_health[10,100],
lifespan[200,2000],fertility[0,1],vision[1,8],metabolic_multiplier[.5,2],preferred_
temperature/moisture[0,1],climate_tolerance[.05,.5],aggression/risk_tolerance[0,1].
Bin=min(19,floor(20*(value-low)/(high-low))); bins include the left edge and exclude
the right, except the final bin includes the upper endpoint. Empty kinds have20
zero bins. Grouped bars retain per-kind colours and latest per-kind totals.

Capture reuses immutable metrics::Snapshot and scans living organisms once more
for histograms, O(living*12+historical species), never scanning death history.
Cache by tick within an epoch, reused for stored/current samples; history stores
bounded detached JSON DTOs and histograms only for the current tick. Serialization
and browser drawing are O(window*3*12); every frame currently includes the bounded
window, so long-running UI throughput may drop as it fills. This history is private
application data; no core import, config, metrics, model, hash or checkpoint schema
changes. Chart coordinates use Number/f64; count/tick labels retain exact strings.
Subtract BigInt ticks before conversion so adjacent ticks above2^53 remain distinct.
Very large y magnitudes can lose plotting precision; labels still retain exact counts.
Large valid allocations/codec work can delay the single owner or exhaust memory.

Screenshot automation keeps main.png at100, opens the real Charts panel, waits for
its Canvas draw and writes charts.png, then optionally inspector.png at the same
engine tick. Tests use pure Node modules, display-free Cargo and actual HTTP,
plus real CDP preset/edit/error/download/import/run/trait interactions. Run
`./test.sh` in isolation from other browser commands because cleanup assertions
inventory all browser profiles.

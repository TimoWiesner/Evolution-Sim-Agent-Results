# Metrics format (schema 1)

Every `evosim run --config FILE --ticks N --out FILE [--sample-every K]`
result includes `metrics_schema: 1`. Metrics are additional keys in the result
JSON; no separate option or file is needed. The required contract fields remain.
Samples occur at tick zero, each absolute multiple of K, and the final tick once.
Default K is max(1, N/100); N=0 produces one row. Nonzero-tick samples describe
completed Commit state. The same format applies to the static distribution.

Each `series` row contains integer `tick`, `plants`, `herbivores`, `carnivores`
(living counts), and `analytics`. Analytics contains one record for each of those
three kind names, plus `generation` over **all living individuals**, weighted by
individual count. Each kind record has:

| Key | Meaning |
|---|---|
| `births` | Cumulative offspring since tick 0, excluding initialization |
| `deaths` | Cumulative deaths since tick 0 |
| `deaths_by_cause` | Cumulative `starvation`, `injury`, `predation`, `old_age`, `climate` counters; all five keys always present |
| `species` | Number of species with living members, excluding extinct history |
| `traits` | Twelve expressed phenotype summaries of living individuals |
| `generation` | Living highest generation (exact integer) and arithmetic mean |

Cause counters sum to deaths. At each sample, initial + births - deaths equals
living count, per kind. Counter differences between samples give interval events;
these counters never reset on sampling. Final sampled births/deaths/species match
the result's `totals` and `final.species`. Extinct tails retain cumulative counters.

Every trait summary has exactly `mean`, `standard_deviation`, `min`, `max`.
Spread is the **population** standard deviation, sqrt(sum((x-mean)^2)/n), rather
than the sample estimate with denominator n-1. Singleton/constant spreads are
zero. All four fields are JSON null when the kind is absent. Both generation
fields (`highest`, `mean`) are null if no individuals are alive in that group.
Founders have generation zero. Vitals such as current health/energy are excluded.
All twelve traits are reported for plants as well, including inactive loci.

| Trait key | Expressed units |
|---|---|
| `speed` | Cells per active tick (integer phenotype, summarized as floating values) |
| `strength` | Model strength units |
| `max_health` | Health capacity units |
| `lifespan` | Ticks (integer phenotype) |
| `fertility` | Propensity, 0..1 |
| `vision` | Cells of Chebyshev radius (integer phenotype) |
| `metabolic_multiplier` | Dimensionless cost multiplier |
| `preferred_temperature` | Normalized temperature, 0..1 |
| `preferred_moisture` | Normalized moisture, 0..1 |
| `climate_tolerance` | Normalized tolerance width |
| `aggression` | Propensity, 0..1 |
| `risk_tolerance` | Propensity, 0..1 |

These summarize phenotypes, not raw u16 alleles. Lifecycle/cause/population counts
are exact u128 JSON integers; tick/highest generation are exact u64 integers.
Consumers must use an integer-capable parser to retain precision above 2^53.
Means/spreads/min/max use f64, with stable-ID Welford accumulation and variance
clamped nonnegative before square root. Generation means may lose low bits above
2^53; highest remains exact. Floating statistics are repeatable on the same build;
minor differences between platforms/build targets are allowed.

`evosim::metrics::Snapshot::capture(&Simulation)` returns an owned, typed snapshot.
`tick()`, `counts()`, `kind(Kind)`, `generation()` read it; `to_json()` returns a
complete series row. KindMetrics/TraitMetrics/TraitSummary/GenerationSummary are
public value records; editing a detached value cannot change the engine. Trait
array order is `genome::LOCUS_NAMES`; cause array order is `DeathCause::ALL`.
The metrics module only reads existing immutable APIs. It never draws RNG,
changes biology, or participates in canonical state/checkpoints/hashes.

Capture costs O(living individuals * 12 + historical species) with constant
summary workspace. CLI retains O(samples * 3 * 12) summary values; output can
be large, so increase `--sample-every` for long runs. Tick timing excludes capture,
serialization, hashing and file publication; it is not end-to-end throughput.

A complete empty-world series row follows. Its enclosing result has
`metrics_schema: 1`; the other contract result keys are unchanged.

```json
{
  "tick": 0, "plants": 0, "herbivores": 0, "carnivores": 0,
  "analytics": {
    "plants": {"births": 0, "deaths": 0, "deaths_by_cause": {"starvation": 0, "injury": 0, "predation": 0, "old_age": 0, "climate": 0}, "species": 0, "traits": {"speed": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "strength": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "max_health": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "lifespan": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "fertility": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "vision": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "metabolic_multiplier": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_temperature": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_moisture": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "climate_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "aggression": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "risk_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}}, "generation": {"highest": null, "mean": null}},
    "herbivores": {"births": 0, "deaths": 0, "deaths_by_cause": {"starvation": 0, "injury": 0, "predation": 0, "old_age": 0, "climate": 0}, "species": 0, "traits": {"speed": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "strength": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "max_health": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "lifespan": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "fertility": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "vision": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "metabolic_multiplier": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_temperature": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_moisture": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "climate_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "aggression": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "risk_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}}, "generation": {"highest": null, "mean": null}},
    "carnivores": {"births": 0, "deaths": 0, "deaths_by_cause": {"starvation": 0, "injury": 0, "predation": 0, "old_age": 0, "climate": 0}, "species": 0, "traits": {"speed": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "strength": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "max_health": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "lifespan": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "fertility": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "vision": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "metabolic_multiplier": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_temperature": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "preferred_moisture": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "climate_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "aggression": {"mean": null, "standard_deviation": null, "min": null, "max": null}, "risk_tolerance": {"mean": null, "standard_deviation": null, "min": null, "max": null}}, "generation": {"highest": null, "mean": null}},
    "generation": {"highest": null, "mean": null}
  }
}
```

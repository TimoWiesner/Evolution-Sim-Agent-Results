# Architecture ledger

Accepted architecture from TASK-001; bootstrap implemented in TASK-002 cycle 1.
Typed configuration implemented in TASK-003 cycle 1.
Toroidal geometry implemented in TASK-004 cycle 1.
The clock/RNG/scheduler frame is implemented in TASK-005 cycle 1;
static base climate is implemented in TASK-006 cycle 1, temporal climate in
TASK-007, shared organism lifecycle in TASK-008, genetics in TASK-009 and spatial
lookup in TASK-010, plant growth/resources in TASK-011, and plant reproduction
in TASK-012, animal navigation in TASK-013 and herbivore grazing in TASK-014;
carnivore hunting in TASK-015, animal reproduction in TASK-016 and species
classification/lineage in TASK-017 and integrated ecology evidence/default tuning
in TASK-018; headless run and complete-state hashing in TASK-019, observational
metrics in TASK-020, batch/export in TASK-021 and checkpoints in TASK-022; the live browser world view is implemented in TASK-023, controls/inspection/UI
checkpoints in TASK-024, and experiment editing/live charts in TASK-025. ADR-001 through ADR-018
in `docs/decisions/` record the decisions,
alternatives, tradeoffs and future verification obligations.

Chosen technology: Rust simulation library and native application, embedded
local browser Canvas UI; later static musl headless distributable. No browser
or UI dependency is permitted in the simulation core.

| Planned module/path | Responsibility | Allowed dependencies |
|---|---|---|
| `src/config.rs` | Typed JSON configuration, defaults, validation, presets | Serialization only |
| `src/topology.rs` | Integer wrapping, shortest directions, unique radius cells | Value types only |
| `src/rng.rs` | Specified seeded generator and complete restorable state | Value types only |
| `src/traits.rs` | Validated phenotype value types | std only |
| `src/genome.rs` | Ordered bounded loci, phenotype mapping, crossover, mutation, distance | config, rng, traits |
| `src/organism.rs` | Stable IDs, kind, immutable DNA, derived traits, position and read-only life records | topology, genome, traits |
| `src/population.rs` | Living BTreeMap, identity allocation, lineage, bounded vital changes, pending events and lifetime accounting | config, topology, organism, genome, rng, spatial, species |
| `src/spatial.rs` | Per-cell occupant buckets, deterministic neighbor lookup | topology, organism ID/Kind values |
| `src/temporal_climate.rs` | Periodic seasons, persistent weather state and current queries | config, climate, topology, rng |
| `src/climate.rs` | Immutable periodic latitude/biomes and export | topology, serde_json, std I/O |
| `src/temporal_climate.rs` | Current seasons and persistent weather | climate, config, topology, rng |
| `src/resources.rs` | World-owned authoritative bounded cell energy | config, topology |
| `src/ecology/reproduction.rs` | Pure maturity, cooldown, compatibility, fertility and paid offspring budgets | genome, traits |
| `src/ecology/carnivores.rs` | Pure attack cost, per-million odds and conservative prey nutrition | traits |
| `src/ecology/herbivores.rs` | Pure thermal upkeep, visible-risk food eligibility and bounded bite budget | config, traits, topology |
| `src/ecology/animals.rs` | Pure shortest-step, cost and wander helpers | config, traits, topology, rng |
| `src/ecology/plants.rs` | Pure plant physiology, seed budget and uniform dispersal sampling | traits, rng, topology |
| `src/species.rs` | Founder exemplars, stable genetic classification, lineage | genome, organism IDs |
| `src/ecology/` | Plant, herbivore, carnivore actions and reproduction | config, topology, organism, spatial, climate, genome, rng |
| `src/simulation.rs` | Own state; initialize, advance one tick, lifecycle commit | All preceding core modules |
| `src/metrics.rs` | Read-only snapshots, accounting and genetic summaries | Core read-only views |
| `src/persistence.rs` | Versioned checkpoints, canonical state hashing | Core state, serialization/hash libraries |
| `src/cli.rs` | Contract commands, sampling, batch orchestration, error status | simulation, config, metrics, persistence, UI adapter |
| `src/ui_server.rs`, `ui/` | Loopback commands/snapshots; browser rendering/controls | Public core interfaces, metrics, persistence; never reverse |
| `src/main.rs` | Thin process entry and dispatch | cli |

src/config.rs, src/topology.rs, src/climate.rs, src/temporal_climate.rs, src/rng.rs,
src/traits.rs, src/genome.rs, src/organism.rs, src/population.rs, src/spatial.rs,
src/resources.rs, src/species.rs, src/ecology/{plants,animals,herbivores,carnivores,reproduction}.rs,
src/simulation.rs, src/metrics.rs, src/persistence.rs, src/canonical.rs,
src/main.rs, src/cli.rs and src/ui_server.rs with embedded ui/ assets currently
exist from this table. Core interfaces will be equivalent
to `Simulation::new(validated_config)`, `advance_one_tick(&mut self)`, read-only
`snapshot()` and entity lookup by stable ID. One engine owner serializes all UI
commands. Headless and UI advance the same engine. UI scheduling sets how many
whole ticks to request, never the biology or RNG sequence.

State owns clock, RNG, config, climate/resources, organisms, species/lineage,
ID counters and cumulative lifecycle accounting. Dense spatial buckets are a
derived cache updated immediately and rebuilt deterministically on load. Births
commit at tick end; deaths disable actors immediately; iteration is stable ID
order. Observational metrics and wall-clock timings cannot mutate engine state.

Chosen DNA uses bounded u16 fixed loci with haploid two-parent animal crossover,
clonal plant inheritance, mutation and immutable founder species exemplars.
Topology uses toroidal Chebyshev distance and cell-to-cell moves; wrapped radius
queries enumerate no duplicate cells. Smooth periodic latitude bands acknowledge
that a torus cannot reproduce Earth's distinct geographic poles.

Checkpoints and hashes share a versioned canonical state boundary containing all
future-influencing data, including complete RNG and climate state. CLI validates
before writing result output; errors use stderr and status 2. Runtime headless
operation is offline. ADRs define algorithms and alternatives; exact wire/checkpoint byte schemas must
be finalized and versioned when implemented in their owning tasks.


Dependency rules: core modules are config through persistence in the table.
No core module imports cli, ui_server, browser assets or renderer types. Metrics
reads state without drawing RNG or owning engine mutation. Persistence encodes
state without calling UI or CLI. Avoid module cycles by defining serializable
state/value records with their owning core modules; simulation orchestrates
behavior, while ecology receives explicit mutable state subsets. Only the outer
application reads wall clock for timing and tick scheduling.

Initialization validates fixed config keys/types/ranges, expands the seed, builds
row-major climate/resources, inserts initial organisms in stable ID order and
classifies initial species. Tick order and lifecycle timing are binding in ADR-001;
query semantics are in ADR-003 and the twelve-locus/species schema in ADR-004.
Completed-tick checkpoints contain no pending actions. Loading validates versions
and state invariants before replacing the engine, then rebuilds derived caches.
Config/checkpoint/argument failures are status 2 on stderr with no result file.

Climate uses smooth periodic functions in both axes and periodic temporal
season/weather state; a repeated cold-to-hot-to-cold latitude band replaces the
sphere's distinct poles. This torus compromise preserves seam continuity rather
than geographic realism. Seam tests must compare limits/gradients, not require
adjacent discrete seam cells to have identical values.

The CLI and UI own sampling/render buffers outside authoritative state. Headless
results include the start, every requested interval and the end without duplicate
ticks, and advance exactly N ticks through extinction. Save/load and result hashes
share the complete-state boundary in ADR-001. No arbitrary replenishment or
population-count-dependent survival/reproduction belongs in any module.

TASK-002 PLAN cycle 1 bootstrap refinement (not implemented): Cargo library plus
thin binary; std-only CLI dispatch for version/help; root-relative shell entry
points; Cargo tests plus Python stdlib process/packaging acceptance via test.sh.
Build dist as a copied static x86_64-unknown-linux-musl release executable from
the outset. Full plan and verification matrix: tasks/TASK-002/handoffs/plan-cycle1.md.
Simulation, run/batch/ui and their existing module ledger remain future work.

TASK-002 IMPLEMENT cycle 1: Cargo package evosim 0.1.0 (edition 2024, minimum
Rust 1.85), src/lib.rs plus thin main and std-only cli dispatcher are implemented.
The dispatcher accepts an argument slice and output/error writers, keeping process
access in main. Available commands are version and --help/-h; invalid arguments
return status 2. No simulation commands or placeholder engine modules exist.
setup.sh builds locked host and musl releases; evosim execs the prebuilt host
binary without invoking Cargo. build.sh copies the static musl binary to dist/.
All scripts resolve their own directory. test.sh runs Cargo tests and Python
stdlib process/packaging acceptance tests. Current ELF/chroot evidence confirms
version needs no shared libraries or installed runtime. Future engine/dependency
changes must preserve static distribution and extend tests to run behaviour.

TASK-003 PLAN cycle 1 (not implemented): configuration will be a typed, validated
library API in src/config.rs, independent of CLI/UI. JSON fixed keys remain
required; optional climate/genetics/plants/animals groups and leaves default.
Unknown keys and explicit null fail with dotted key paths. serde_json Value with
arbitrary_precision/float_roundtrip is planned for exact seed/float round trips;
Seed retains arbitrary signed decimal integers and exposes modulo-u64 conversion.
Presets baseline, seasonal and plant-only share the validation path. All exports
contain effective defaults. Checked dimensions/counts have machine limits but no
ecological policy caps. No engine consumption or run handling belongs here.
Detailed schema, API, preset overrides and test matrix are persisted in
tasks/TASK-003/handoffs/plan-cycle1.md. Later owning tasks add/tune parameters with
updated validation/defaults/docs rather than treating this initial list as final.

TASK-003 IMPLEMENT cycle 1: src/config.rs now implements schema v1 with private
validated typed records/read-only accessors, exact arbitrary signed integer Seed,
JSON string/file import and effective export, structured key-specific errors and
baseline/seasonal/plant-only presets selected by name. Fixed keys stay required;
optional groups/leaves default. Unknown keys/null fail; duplicate keys use last
occurrence. Checked area/count sums enforce representability, not ecology caps.
serde_json (arbitrary_precision, float_roundtrip) is the only direct dependency;
no CLI/UI dependency enters configuration. docs/CONFIGURATION.md is the schema/API
reference. All presets and exports reuse validation. No simulation consumption or
run dispatch was added. Eight public configuration integration tests supplement
bootstrap tests; static musl packaging regression remains passing. Exports are
human configuration JSON, not the future canonical state/checkpoint boundary.

TASK-004 PLAN cycle 1 (not implemented): src/topology.rs will expose validated
Topology dimensions/area, private usize Cell values, full i128 signed wrapping,
i128 shortest displacement and usize Chebyshev distance. Pure value module, no
config/CLI/UI dependencies. Radius queries are lazy, unique, inclusive Cartesian
iterators with O(1) auxiliary memory; full axes enumerate ascending from zero,
partial axes begin at wrapped center-radius, y outer/x inner. Positive half-axis
ties follow ADR-003. Cross-topology Cell inputs are normalized to the receiver.
No world raster, spatial index, movement, climate or simulation added. Interfaces,
overflow strategy and exhaustive public-API test matrix are persisted in
 tasks/TASK-004/handoffs/plan-cycle1.md; ADR-003 records this refinement.

TASK-004 IMPLEMENT cycle 1: src/topology.rs now provides the planned std-only
value API: Topology::new validates positive usize dimensions and checked area;
Cell has private usize coordinates; cell(i128,i128) accepts the full signed input
domain; Displacement exposes signed i128 dx/dy. Queries normalize foreign-world
Cell inputs. distance uses shortest-axis Chebyshev distance; even half-axis
shortest-direction ties choose positive in both orders. cells_within returns an
owned lazy iterator including center, with capped unique axes, y outer/x inner;
full axes ascend from zero, partial axes start at wrapped center-radius.
Construction and auxiliary storage are O(1), iteration O(returned cells), without
allocating a raster or doubling an unchecked radius. No index or movement is
implemented. Public integration tests exhaustively compare worlds 1..=8 on both
axes against independent unsigned-distance and radius-membership oracles; edge,
integer extreme, tie, huge-radius, foreign-cell and ordering tests supplement them.
The rustdoc example also executes. No dependencies or configuration changes.

TASK-005 PLAN cycle 1 (not implemented): add std-only src/rng.rs and
src/simulation.rs exported by the library. Simulation owns effective Config,
World (initially Topology only), u64 clock and one xoshiro256** RNG. The seven
fixed stages are Clock, ClimateResources, Plants, Herbivores, Carnivores,
Reproduction, Commit; biological stages are no-ops until their owning tasks.
No population materialization, climate raster or dummy random draws. Initial
counts remain configuration data. advance_one_tick returns a fixed-size stage
report after checked single-tick advancement; reports are observational.
RngState version 1 carries four u64 words with validated exact restoration.
Integer rejection sampling and rational probabilities specify draw consumption.
A crate-private sorted/deduplicated ID helper prepares the stable scheduling
rule; real lifecycle tests belong to TASK-008. No mutable public simulation RNG,
UI import, runtime scheduler, persistence format or CLI changes planned.
Full interface/test plan and caveats: tasks/TASK-005/handoffs/plan-cycle1.md;
ADR-001 refines RNG endpoint semantics and frame ownership without changing its
algorithm, tick order, tie rules or lifecycle timing.


TASK-005 IMPLEMENT cycle 1: src/rng.rs implements xoshiro256**/SplitMix64,
version-1 RngState exact restoration, rejection-sampled below and integer chance.
No dependency added. src/simulation.rs owns Config, World (Topology only), u64
clock and exactly one RNG. Full signed seed is retained in Config. Read-only
accessors and returned TickReport do not affect authoritative state. A checked
advance_one_tick dispatches the seven TICK_PHASES in order, recording phases
after execution; overflow returns an error before any mutation. Biological
methods are intentionally empty and draw nothing. Initial counts are not yet
materialized, even for baseline presets. No CLI/UI integration is introduced.
The crate-private ordered_actor_ids helper sorts/deduplicates a living-ID snapshot;
future phases must recheck liveness, preserve immediate effects and next-tick
newborn timing. Fixture ordering tests do not validate actual lifecycle behavior.
Five RNG integration tests, three simulation integration tests and two private
boundary/order tests cover the frame; all 34 regression tests pass. Exact commands,
known-vector reference and scope limitations are in TASK-005 implement handoffs.

TASK-006 PLAN cycle 1 (not implemented): ADR-005 specifies a procedural immutable
Climate owned by World, using Topology and normalized cell-centred periodic
latitude. Five bands: polar/tundra/temperate/dry/tropical; smooth precipitation
interpolation creates a relatively dry subtropical belt. No longitude noise or
random draws. Static base fields are computed on demand with O(1) storage rather
than the previously anticipated raster; dynamic weather/resources remain later
state. Climate values depend only on topology; export additionally uses existing
serde_json and std I/O, never config/CLI/UI/RNG. Public base_at/read-only World
access and streaming row-major JSON export are planned, with additive
`evosim climate --config FILE --out FILE` inspection. No season/weather updates,
resource fields, organisms, run/UI or persistence added in this phase. Exact
formulas, interfaces, schema, scope and acceptance matrix are in TASK-006
plan-cycle1.md. Future checkpoint/hash schema must capture model version and
reconstructible inputs or complete equivalent base values. Tiny grids can miss
bands. No new dependencies, performance or implementation claims.


TASK-006 IMPLEMENT cycle 1: src/climate.rs now implements ADR-005 model version 1
with five ordered biomes, normalized cosine temperature and smoothstep precipitation.
World owns immutable procedural Climate alongside Topology, exposed read-only via
climate(). Static lookup requires no raster, RNG, config, CLI or UI dependency.
Only the export method additionally uses existing serde_json/std I/O, streaming
row-major cell records with constant auxiliary memory. CLI now supports the
observational `climate --config FILE --out FILE` command, validating configuration
before opening output and flushing buffered errors explicitly. No simulation tick
stage changes or temporal climate/resources/organisms were introduced. docs/CLIMATE.md
records schema, units, tiny-world behavior and torus compromise. Future current
weather state must retain base access; future persistence must encode model identity
and dimensions or equivalent derived values. Tests validate seam continuity and
host/musl exports; no performance or full-state persistence evidence yet.

TASK-007 PLAN cycle 1 (not implemented): ADR-006 specifies separate
src/temporal_climate.rs and World-owned TemporalClimate beside immutable Climate.
Existing ClimateConfig supplies year length and amplitudes. Modulo-first cosine
seasons use smooth zone-dependent amplitudes; current normalized temperature and
precipitation are clipped to [0,1]. Global two-channel AR(1) weather updates once
in ClimateResources using exactly two engine RNG draws when enabled, none when
disabled. Tick-zero offsets are zero without draws. World exposes observational
current_climate_at(Cell); temporal state includes settings, model version, tick
and both offsets. Later checkpoint/hash schemas must include these and full RNG,
validate clock agreement and preserve exact continuation. Base climate API/export
remain unchanged. No raster, new dependencies, CLI or ecology effects planned.
Detailed interfaces, formulas and acceptance tests: TASK-007 plan-cycle1.md and
ADR-006. Same-phase seasons/global weather simplify geography but preserve seams.


TASK-007 IMPLEMENT cycle 1: src/temporal_climate.rs implements ADR-006 and World
owns TemporalClimate beside immutable Climate. ClimateResources advances its
absolute clock and persistent two-channel AR(1) offsets using the engine's only
RNG; enabled weather draws twice, disabled weather draws nothing. Current queries
are pure and bounded; base export stays unchanged. Settings and versioned offset/
tick records support validated exact in-memory restoration. Future persistence
must encode them plus RNG and validate temporal/engine clock agreement. No disk
format, resources, organisms, CLI commands or UI integration introduced here.


TASK-008 PLAN cycle 1 (not implemented): ADR-007 specifies src/organism.rs
(private validated organism/trait value records) and src/population.rs (Simulation-
owned BTreeMap of living IDs, monotonic allocator, counters, pending births/deaths,
death history). Founder traits use ADR-004 bounds without DNA. Initial counts
will be materialized deterministically row-major without RNG draws; initial
individuals are not births. Age/lifespan advances in each kind's shared ordered
walker, immediate removal prevents later actions, and queued offspring commit
at tick end, first acting next tick. Internal birth primitives capture lineage
before parental death; production reproductive behavior remains unimplemented.
Traits reside in organism; future genome imports the trait value type instead
of organism importing genome, preventing a dependency cycle. Spatial buckets
remain TASK-010. Completed-state persistence must later cover allocator exhaustion,
living records/traits/genomes, counters and death history. No new dependencies,
CLI changes, ecology or checkpoint format planned. Interfaces and acceptance
matrix are in tasks/TASK-008/handoffs/plan-cycle1.md and ADR-007.


TASK-008 IMPLEMENT cycle 1: src/organism.rs defines Kind, opaque OrganismId,
validated twelve-field Traits/TraitValues, read-only Organism and DeathCause.
Simulation now owns Population and exposes population() read-only. Population
uses BTreeMap living records, non-reused u64 IDs with explicit exhaustion, u128
per-kind initial/living/birth/death/cause counts, captured parent lineage and
persistent death history. Exact initial counts occupy row-major cells without
RNG draws; founders have no parents, age/generation/birth tick zero, full vitals.
No DNA, feeding, movement, energy costs or production reproduction is present.

Each kind uses one shared walker over ascending living IDs, rechecking liveness
and aging before action; lifespan expiry removes immediately. The old fixture-only
ordered_actor_ids helper was replaced by the map's unique ascending phase snapshot.
Finite vital changes clamp without overflowing; nonfinite inputs fail atomically.
Zero energy kills by Starvation; zero health uses Injury unless an explicit cause
is supplied. First death wins; counters/history commit once at tick end.
Accepted internal birth requests capture live same-kind parents and generation,
reserve ID capacity, survive subsequent parental death and commit with age zero;
newborns first act next tick. BirthPhase is population-owned (Plants, Herbivores,
Carnivores, Reproduction), avoiding a reverse import of simulation::TickPhase.
Commit orders phase, sorted parent IDs, then request sequence. Invalid traits
cannot enter requests because Traits itself is validated. These primitives have
no production reproduction caller until the owning ecology tasks.

Completed-state conservation is initial + births - deaths = living per kind.
During phases subtract pending deaths as well; accepted births are not living yet.
Later persistence must encode allocator Option/exhaustion, request sequence,
living records/traits (later DNA), initial/cumulative/cause counts and all death
history alongside the existing complete state. No pending events remain at tick
boundaries. No checkpoint or throughput claim. Public/private acceptance tests,
including real walker hooks and four-seed 2200-tick runs, pass; exact commands
and results are in TASK-008 implementation handoffs.


TASK-009 PLAN cycle 1 (not implemented): src/traits.rs will own validated
phenotype values, re-exported from organism for compatibility; genome depends on
traits/config/rng and organism depends on genome/traits/topology. This replaces
the provisional genome-to-organism dependency above. Organism stores immutable
Genome([u16;12]) and derives traits without an independent cache. Population
initializes fixed [32768;12] DNA without draws. Its internal accepted birth path
uses parent DNA, GeneticsConfig and the Simulation-owned RNG transactionally,
captures child DNA before parental death, and commits without additional draws.
No production reproduction, species, CLI or persistence work. Exact interfaces,
algorithms and acceptance matrix: tasks/TASK-009/handoffs/plan-cycle1.md and
ADR-004 refinement. Future checkpoint/hash must include every allele/version.


TASK-009 IMPLEMENT cycle 1: src/traits.rs owns validated phenotype values,
re-exported by organism for compatibility. Genome depends on config/rng/traits;
organism depends on genome/traits/topology, with no module cycle. Every organism
stores immutable schema-v1 twelve-u16 DNA and derives Traits on demand without
an authoritative cache. Initial DNA is [32768;12], no draws; continuous founder
traits are quantized while lifespan remains 1100. Internal birth requests accept
no traits/DNA override: sorted live parents supply one-parent copy or two-parent
crossover, followed by configured mutation using the engine RNG. A staged RNG
clone permits complete rollback on rejected child health or other errors.
Pending births capture child DNA and lineage; Commit draws nothing and newborns
act next tick. No production reproduction decisions/species/persistence added.
Full API/draw semantics: docs/GENETICS.md and ADR-004. Future full-state persistence
must encode schema and every allele, not an independent trait cache.

TASK-010 PLAN cycle 1 (not implemented): Population will own private SpatialIndex
from src/spatial.rs beside its authoritative BTreeMap. Population gains spatial
dependency; spatial imports only topology and organism ID/Kind value types, never
Population/Simulation. Dense sorted per-cell (ID, Kind) buckets form a derived
canonical cache, updated at founder insertion, committed birth, immediate death
and validated internal one-cell movement. Public Population::nearby(Cell, usize,
Option<Kind>) returns ascending IDs using existing unique toroidal cell queries.
No production behavior/CLI changes or additional RNG draws. Checked dense initial
allocation errors propagate through PopulationError/SimulationError; ordinary
memory limits still apply. Future persistence rebuilds cache without RNG and
excludes it from canonical state. Planned oracle/rebuild/lifecycle tests and a
2000-organism release microbenchmark are specified in TASK-010 plan-cycle1.md;
no query performance measured yet. No new runtime/system dependency planned.


TASK-010 IMPLEMENT cycle 1: private src/spatial.rs now implements sorted dense
(ID, Kind) buckets owned exclusively by Population. Founder insertion, committed
birth, immediate kill and internal adjacency-checked move_one_step maintain the
cache. Public nearby(Cell, usize, Option<Kind>) returns ascending unique IDs with
inclusive toroidal Chebyshev semantics. No behavior/CLI changes or new RNG draws.
Dense construction errors propagate through Population/Simulation errors; process
memory limits remain. Cache is canonical/derived, rebuilt from living records
without RNG and excluded from future checkpoint/hash state. Randomized tests
compare 4096 actual-population queries against an independent oracle while
interleaving real lifecycle mutations; reverse rebuild and real-walker tests
verify synchronization/timing. The declared 2000-organism release benchmark
measured radius-4 unfiltered lookup at 12.877x brute force locally; full-world
queries lose. API, all timings/checksums/hardware and limits: docs/SPATIAL.md.

TASK-011 PLAN cycle 1 (not implemented): ADR-008 adds World-owned authoritative
ResourceField in src/resources.rs, separate from immutable Climate and temporal
weather. Resources imports config/topology only; regeneration receives a current-
precipitation closure. Public World::resources()/ResourceField::at(Cell) are
observational; construction/regeneration/withdrawal remain internal. Planned
src/ecology/{mod,plants}.rs contains pure phenotype/climate rates (config/traits
only), while Simulation orchestrates current climate, resources and Population
mutation paths without reverse dependencies. Climate's table entry above is an
older planned responsibility: static Climate remains immutable and does NOT own
seasons, weather or resources. These belong to separate World fields.

ClimateResources advances weather then regenerates all cells row-major. The
existing plant walker ages, then applies genetic climate damage, maintenance,
bounded cell withdrawal and converted energy gain; immediate deaths still update
the spatial index and commit counters once. No new RNG draws, animal behavior,
reproduction, CLI/UI or persistence format. Checked dense allocation errors must
propagate through SimulationError; per-tick work and resource memory are O(area).
Future canonical checkpoint/hash includes resource model/version, effective plant
settings and all row-major f64 stores, never a reconstruction that refills cells.
Detailed equations, interfaces, tests and fixture migrations: TASK-011 plan.


TASK-011 IMPLEMENT cycle 1: World now owns ResourceField alongside separate base
and temporal climate. ResourceField has fallible dense allocation and read-only
normalized at(Cell); internal regeneration takes a precipitation closure and
imports neither climate nor Simulation. ClimateResources advances weather then
regenerates every cell row-major. The plant walker ages first, then applies pure
genetic climate damage, maintenance, bounded withdrawal and resource-backed energy
credit. All organism changes/deaths use Population primitives; animal actions,
RNG draw semantics and Commit timing remain unchanged. Test-only fixture mutation
is compiled only under cfg(test) and creates no production mutable organism API.
Current source/limits, model-v1 equations and persistence obligations: PLANTS.md
and ADR-008. Resource stores are authoritative, must be saved exactly, and cost
O(area) memory/update even after extinction. No runtime/system dependency added.


TASK-012 PLAN cycle 1 (not implemented): ADR-009 specifies clonal plant policy in
Simulation::reproduction after physiology/animal actions. Private ecology/plants
helpers gain config/topology/rng/traits dependencies for energy eligibility and
O(1) uniform unique toroidal-cell sampling; never import Simulation/Population.
Simulation alone orchestrates local occupancy/resources, engine RNG, inherited
queue_birth and paid establishment. A phase-local BTreeSet of coordinate tuples
reserves pending plant sites; no added authoritative persistent state. Existing
Population genetics/Commit, ResourceField and SpatialIndex ownership is unchanged.
No schema/default/API dependency change or new package. Future hash/checkpoint
must retain model identity, effective settings and complete RNG/resource/offspring
state; temporary reservations are absent at completed ticks. Exact costs, draw
order, error handling and acceptance/regression matrix: TASK-012 plan and ADR-009.


TASK-012 IMPLEMENT cycle 1: Simulation::reproduction now orchestrates clonal plant
attempts after physiology/animal actions using ADR-009 model 1. Pure plant helpers
compute representable seed budgets and sample unique wrapped cells in constant
work; they import traits/rng/topology, never Simulation/Population. Temporary
BTreeSet coordinates reserve accepted sites; no authoritative state is added.
Local occupancy/resources gate existing transactional genetics/lineage requests.
Accepted births debit parent energy and germination resources before Commit.
No settings/default/schema or package changes. Public/private real-tick tests
cover mutation, seams, budgets, reservations, rejection/RNG, recursive lineage,
spatial insertion, extinction and 2200-tick replay. Test-only ID exhaustion joins
existing record fixtures under cfg(test), with no production mutation API.
Future persistence must encode model/settings and existing full RNG/resource/
organism state; reservations vanish at completed ticks. Exact evidence and limits
are in TASK-012 implement handoffs. Animal policy, species and UI remain later work.

TASK-013 PLAN cycle 1 (not implemented): ADR-010 defines model-1 animal navigation.
Population gains observational sense(ID), deriving inclusive wrapped vision from
DNA and excluding self; missing/plants return None. Simulation retains the shared
age-first walker and orchestrates nearest-visible-food pursuit or per-step random
exploration through existing Population move/debit primitives. New private
src/ecology/animals.rs imports config/traits/topology/rng only; no reverse imports.
At most speed adjacent steps, shortest signed wrapped directions, paid per-step
cost movement_cost * speed * metabolism, no unpaid step and immediate lethal
debit removal. All kinds permit co-occupancy; plant establishment rejection is a
local reproduction policy, not a global capacity. No persistent heading/target,
new dependency, config change, feeding/attacks/mating or basal animal cost planned.
Future persistence includes movement model identity and existing full DNA/RNG/
position/vitals/settings; temporary paths/targets are absent at tick boundaries.
Acceptance matrix, exact draw ordering and fixture migrations: TASK-013 plan.

TASK-013 IMPLEMENT cycle 1: Population::sense is an observational indexed animal
view with inherited vision and self exclusion. Private ecology/animals helpers
import only config/traits/topology/rng. Simulation's shared age-first walkers
select nearest visible food and execute at most speed paid adjacent steps, with
immediate cache relocation/death. Stateless random exploration uses the sole RNG
after weather and before reproduction. Unlimited cell sharing applies to all
kinds; local plant establishment gates remain. No added authoritative state,
dependency, config schema or CLI change. Future state encodes model identity plus
existing complete DNA/RNG/position/vitals/settings, excluding temporary targets
and derived cache. Exact model and executable evidence: ANIMALS.md and TASK-013
implementation handoffs. Feeding/attacks/mating/basal costs remain future work.

TASK-014 PLAN cycle 1 (not implemented): ADR-011 specifies herbivore grazing model
1. Add private ecology/herbivores.rs for pure thermal maintenance, visible-predator
risk filtering and bite budgets; imports config/traits/topology/value types only.
Simulation retains the shared age-first walker and owns sensing/selection,
movement and plant debit/herbivore credit through Population primitives. Reuse
paid adjacent movement with explicit target/stop radius: herbivores stop at reach
1, carnivores retain radius 0 and existing navigation. Risk locus 11 excludes
plants beside a visible predator for cautious animals (<0.5). One <=4-unit bite
per tick converts 80% of actual removed plant energy; zero plant energy removes
immediately and prevents later reproduction. Current temperature/genetic mismatch
increases positive basal upkeep; a documented 1e-9 basal floor prevents rounded-
away upkeep for tiny valid config values. No authoritative state/config/default/
package changes, attacks or animal births. Future persistence records grazing
model identity plus complete existing state, excluding transient targets/cache.
Detailed order, formulas, interfaces, acceptance and fixture migrations are in
ADR-011 and tasks/TASK-014/handoffs/plan-cycle1.md; no feature is implemented here.


TASK-014 IMPLEMENT cycle 1: ADR-011 herbivore model 1 is implemented. Pure
herbivore policy imports config/traits/topology only; Simulation orchestrates
current-climate maintenance, indexed visible-risk selection, radius-1 paid pursuit
and conservative plant debit/consumer credit through Population. The common
movement executor accepts target/stop radius; carnivores keep radius 0. One
<=4-unit bite converts 80% of actual removal; energy depletion removes plants
immediately before later herbivores and reproduction. Upkeep applies uniformly
with the documented 1e-9 numerical floor. No authoritative state, dependency,
configuration/default or CLI changes. Future persistence includes grazing model
identity and complete existing state, excluding transient targets/risk lists/cache.
Exact evidence and fixture migrations: TASK-014 implement handoffs and ANIMALS.md.


TASK-015 PLAN cycle 1 (not implemented): ADR-012 defines carnivore hunting model
1. Add private ecology/carnivores.rs pure attack cost, per-million kill odds and
conservative nutrition helpers (traits only); Simulation owns current-climate
maintenance (reuse herbivores::maintenance), indexed selection, radius-1 paid
pursuit, engine trial and Population kill/credit. Existing shared age-first walker,
spatial/lifecycle mutation paths and ownership remain unchanged. One paid attack
per tick; sequential ID-order fresh sensing, immediate Predation removal and
true-kill-only prey-energy-backed nutrition prevent double consumption. No new
authoritative state, config/default/schema or package. No animal reproduction,
CLI/UI or persistence implementation. Future state includes hunting model identity
and full existing DNA/vitals/RNG/climate/resource/settings/lifecycle state, excluding
temporary targets and derived spatial cache. Exact formula, rounding/gate/draw
order, fixture migrations and executable acceptance plan: ADR-012 and TASK-015
plan-cycle1.md. This supersedes only the planned carnivore radius-0 action behavior
when implemented; current production still has navigation without hunting.


TASK-015 IMPLEMENT cycle 1: private ecology/carnivores.rs imports traits only.
Simulation orchestrates shared current-climate maintenance, fresh indexed target
selection, radius-1 paid pursuit, paid stochastic trial and true-kill-only credit.
Population owns immediate Predation removal/index update and Commit accounting.
Sequential stable-ID selection prevents duplicate consumption. Navigation-only
legacy adapters are cfg(test); production shares one movement executor. No new
authoritative state, dependency, configuration or public mutation API. Future
checkpoint/hash retains hunting model identity and full existing state, excluding
transient targets and derived cache. Numerical underflow/rounding guards and
executable evidence: ANIMALS.md, ADR-012 and TASK-015 implementation handoffs.


TASK-016 PLAN cycle 1 (not implemented): ADR-013 specifies local immediate
single-offspring sexual reproduction after existing plant reproduction, then
herbivores/carnivores. Add private ecology/reproduction.rs (genome/traits only);
Simulation owns indexed contact selection, attempted-pair exclusion, product-
fertility trial, inherited queue_birth and paid parent costs. Population owns
cooldown mutation and existing energy/index/lifecycle operations. No config or
dependency change. NEW authoritative Organism::last_reproduction_tick Option<u64>
starts None, stamps both successful parents immediately and gates elapsed ticks
without deadline overflow. Future checkpoint/hash must encode its discriminant
and value plus model identity/effective settings/full existing state, validate
timestamps and never reset cooldown on load. Attempted IDs are temporary, spatial
cache remains derived. No species, gestation, CLI/UI or disk persistence work.
Exact interfaces, energy guards, RNG ordering and acceptance/regression matrix:
ADR-013 and tasks/TASK-016/handoffs/plan-cycle1.md.


TASK-016 IMPLEMENT cycle 1: ADR-013 mating model 1 now runs after unchanged
plant reproduction, then herbivores and carnivores. Private pure reproduction
helpers depend only on genome/traits; Simulation owns indexed same-kind contact
selection, temporary attempted IDs, single engine trial, inherited queue_birth,
then both-parent payment/stamping. Population validates both parents before any
cooldown write. No module cycle, config/default, dependency or public mutation
API added. New authoritative last_reproduction_tick: Option<u64> belongs to
Organism, starts None for founders/children and participates in Clone/PartialEq.
Future persistence/hash must encode its discriminant/value and validate timestamps
against engine tick, preserving cooldown exactly. No disk format implemented.
Phase-local attempts disappear; spatial index remains derived. Exact policy,
numerical energy guards, RNG order and tests: ANIMALS.md, ADR-013 and TASK-016
implementation handoffs. Species/CLI/UI and balancing remain later scope.

TASK-017 PLAN cycle 1 (not implemented): Population will own SpeciesRegistry from
src/species.rs and every Organism a nonoptional SpeciesId. Define that value type
in organism.rs and re-export from species; registry imports genome/organism values
only, never Population/Simulation, avoiding cycles. Classification occurs on
initial insertion and sorted birth Commit with exact ADR-004 founder distance;
queue_birth captures ancestor species before parental death without registry
mutation. New species IDs equal their first member's stable numeric organism ID,
monotonic with gaps; deterministic kind-ID names draw no RNG. Immediate deaths
update per-species living counts; extinction flags finalize after all births and
death accounting, with no resurrection. Current living species per kind is an
observational registry query at every tick. Historical records/immutable founders,
ancestry/ticks/memberships/model identity belong to future checkpoint/hash state;
counts are validated/rebuilt from living records and no extra allocator exists.
No ecological gates, config/dependency, CLI/UI or disk persistence changes planned.
Exact interfaces, lifecycle timing, acceptance/regression matrix: ADR-004 TASK-017
refinement and tasks/TASK-017/handoffs/plan-cycle1.md.

TASK-017 IMPLEMENT cycle 1: Population now owns SpeciesRegistry from species.rs;
Organism stores SpeciesId (value defined in organism, re-exported by species).
Species imports genome and organism value types only, avoiding a reverse module
cycle. Initialization and sorted Commit classify against immutable same-kind
founders using exact inclusive threshold/nearest-ID ordering. Accepted requests
capture ancestry; immediate kill decrements membership and end-Commit finalizes
extinction, retaining history without resurrection. No new allocator, RNG draw,
ecology gate, config/schema/dependency or public mutation API. Queries expose
current species records/counts read-only. Registry is authoritative Clone/PartialEq
state. Future checkpoint/hash includes model identity, all historical founders/
lineage/ticks and memberships, validating/rebuilding member counts from living
records; spatial cache and phase-local reservations/attempts remain derived.
No disk format implemented. API/timing/costs: SPECIES.md; exact validation and
limits: TASK-017 implementation handoffs. No old ecology test expectations changed.


TASK-018 PLAN cycle 1 (not implemented): ADR-014 preserves the existing seven-phase
engine and mutation/state ownership. Integration will add public production-tick
scenario tests and examples/ecology_report.rs driving existing Config/Simulation
APIs, observing counts outside authoritative state. The example will record five
seeds for10000 ticks, including empty tails, without implementing TASK-019 CLI.
No new core module, runtime dependency or authoritative field is planned. Existing
local resource/competition/paid nutrition/mating mechanisms remain; measured
configuration-only default tuning is allowed with synchronized docs/tests.
Report extinction trackers/timings are observational and excluded from future
canonical state; all existing resources/RNG/DNA/cooldown/species history must still
be retained. No survival/performance/coexistence result yet. Detailed acceptance,
report schema and ordered work: TASK-018 plan-cycle1.md and ADR-014.


TASK-018 IMPLEMENT cycle 1: the existing seven-phase production scheduler required
no refactor. tests/ecology_integration.rs and examples/ecology_report.rs share
examples/support/ecology.rs, a public-API-only observer, outside core state. Every
completed tick checks accounting, absorbing zero, vitals/lineage and species counts;
report buffers/first-zero trackers/wall times do not enter canonical state. Default
regeneration2 and animal cooldown100 are measured config-only tuning; no schema,
model equation, dependency or authoritative-field change. No ecological global
count feedback. docs/ECOLOGY.md documents order, mechanisms, all69 exploratory
runs and final five-seed10000-tick report. Mixed defaults collapse animals early;
isolated plants replace founders beyond2200 and abundant-food herbivores recruit
through600. Future persistence retains full RNG/resources/DNA/cooldown/species
history and effective settings; CLI/UI/checkpoints remain outside this task.

TASK-019 PLAN cycle 1 (not implemented): ADR-015 specifies complete-state schema1
and SHA-256, refining ADR-001. New std-only canonical primitive writer and owner-
local crate-private encoders retain encapsulation; persistence reads Simulation
and streams its canonical bytes into sha2, with no reverse import. Hash includes
full effective settings, tick/RNG/climate/resources, living DNA/vitals/cooldowns,
private allocation/sequence/counters/death histories and all species history.
Derived spatial caches/phenotypes and outer timings/sample buffers are excluded;
completed-tick pending queues must be empty. No checkpoint codec yet. CLI run
adapter owns parsing, exact-N stepping, sampling, finite loop timing and atomic
JSON publication; core receives no wall-clock/display dependencies. No ecology
change. File/API sequence, encoding widths/order, tests and risks: ADR-015 and
TASK-019 plan-cycle1.md. Proposed sha2 crate needs host/musl verification later.


TASK-019 IMPLEMENT cycle 1: private std-only canonical.rs defines explicit
schema-1 primitive writes. Core owners encode private state locally through
crate-private methods, depending only on the primitive writer; persistence.rs
imports Simulation and streams its completed-tick canonical bytes into SHA-256.
No reverse Simulation->persistence edge, new authoritative state, public mutable
state, biological equation, default or scheduler change. Resource and species/
death histories, allocation/sequence/cause counters, cooldowns, complete RNG and
effective config/climate settings participate. Derived topology area, spatial
cache and phenotypes do not. Pending transactions reject hashing. No checkpoint
codec exists yet; TASK-022 must retain the exact ADR-015 inventory.

cli/run.rs owns strict flag parsing, validated seed override, exact-N stepping,
observational samples and finite tick-only timing, result JSON and atomic file
publication. Series/results/paths/clocks never enter Simulation. Required result
keys plus state_hash_schema1 are implemented; run excludes save/load. Full seed
text remains exact and normalized even for modulo-equivalent RNG streams.
No new runtime system dependency; sha2 0.10.9 (no default features) and transitive
versions are locked. Host/static-musl and real copied empty-root run checks are
covered by test.sh; exact evidence and limitations: TASK-019 implement handoffs.

TASK-020 PLAN cycle 1 (not implemented): ADR-016 defines public metrics.rs typed
read-only Snapshot::capture(&Simulation), explicit JSON mapping and stable-ID
Welford phenotype summaries. CLI samples after Commit using its existing schedule,
adding metrics_schema1 and per-row analytics. Metrics reads immutable organism,
population and species APIs; Simulation/ecology/persistence never imports metrics.
No new authoritative field, config/schema/model identity or checkpoint/hash change.
Capture is O(living*12 + historical species), constant workspace; CLI buffers grow
with samples. Counters stay exact u128, generation highest u64, means/stddev f64;
empty statistics null. File sequence, schema and tests: TASK-020 plan and ADR-016.


TASK-020 IMPLEMENT cycle 1: public metrics.rs captures typed owned snapshots from
immutable Simulation/Population/Organism/Species views, with no reverse imports.
CLI samples include metrics_schema1 and analytics at the existing schedule;
contract population keys remain. Stable-ID Welford summaries cover all twelve
phenotypes, with exact lifecycle/cause counters, living species and per-kind/
weighted overall generation. Empty summaries use null, spread is population
standard deviation. No authoritative field, dependency, configuration, ecology,
canonical schema or checkpoint/hash inventory changed. Detached records only
contain bounded summaries; sample buffers remain CLI-owned. Capture scans living
records and species history, never death history. docs/METRICS.md defines wire
format, precision and costs. Implementation handoffs retain actual test evidence.


TASK-021 PLAN cycle 1 (not implemented): ADR-017 specifies private CLI batch
orchestration, extracting the existing unchanged run loop/result mapping into
cli/runner.rs and atomic file helpers into cli/output.rs. New cli/batch.rs owns
strict seed/single numeric-leaf sweep validation, sequential variant-major runs,
compact records, per-kind final aggregates and JSON/CSV export. No public core
API, authoritative state, configuration/default, dependency, model/hash schema
or checkpoint change. Seed-only filenames follow contract; sweep variants use
indexed subdirectories. Summary parameters contain full effective config except
separate exact seed; relative paths and no timings make summaries deterministic.
One engine/result at a time plus O(run count) compact records; staged disk writes
and summary.json-last completion marker permit reruns, without directory-wide
atomicity or concurrent-writer support. Exact schema, arithmetic, file sequence,
acceptance matrix and limitations: ADR-017 and TASK-021 plan-cycle1.md. Future
persistence still follows ADR-015; batch paths/records/timings remain outside it.

TASK-021 IMPLEMENT cycle 1: private cli/runner.rs now owns the unchanged run
engine loop, sampled metrics, tick-only timings and contract result mapping;
cli/run.rs retains standalone parsing and cli/output.rs atomic file publication.
cli/batch.rs owns validated exact-seed/single-leaf variants, sequential orchestration,
compact JSON/CSV summary records and checked u128 aggregates. Variant-major then
seed-major order, full effective parameters and relative paths make summaries
deterministic; a fresh engine uses the shared runner for every record. Staging is
owned by a private cleanup guard; successful promotion writes summary.json last.
Returned staging errors preserve old output; promotion errors can leave partial
files without a completion marker. No concurrent same-directory writer or fsync
promise. Core imports, authoritative state, config/defaults, biological models,
RNG order, metrics/canonical schema, dependency graph and checkpoint inventory
are unchanged. Batch metadata/paths/clocks remain outside Simulation/hash.
One engine/result plus O(run count) records is live; staging uses batch-sized disk.
Schema, commands, arithmetic/precision and failure behavior: docs/BATCH.md and
ADR-017. Acceptance evidence and exact test outcomes are retained in TASK-021
implementation handoffs; persistence still follows ADR-015.

TASK-022 PLAN cycle 1 (not implemented): ADR-018 chooses uncompressed checkpoint
format1: versioned length-delimited exact canonical schema1 payload plus SHA-256
header/payload checksum. Private std-only bounded Decoder and owner-local inverse
readers preserve module ownership; Simulation assembles/validates without founder
initialization, classification or RNG draws. Persistence exposes checkpoint byte
encode/decode and path load; application owns atomic publication. Full ADR-015
inventory stays authoritative, including exhausted allocator, sequence, counters,
ordered deaths, extinct species and cooldowns. Only spatial caches/phenotypes are
rebuilt; pending queues must be empty. No new state, config/default, dependency,
model/hash schema or ecology change. Shared CLI state runner retains config wrapper
for batch and gains actual absolute start/end with invocation-relative samples.
run accepts exclusive config/load and optional save, seed only on config; load=save
replacement permitted. Save publishes before result; no two-file transaction/fsync
promise. Exact interfaces, validation, ordered files and tests: ADR-018 and
TASK-022 plan-cycle1.md. UI persistence remains TASK-024.


TASK-022 IMPLEMENT cycle 1: canonical Decoder and owner-local inverse readers
restore the complete existing schema1 inventory. Persistence owns format1 binary
envelope/checksum and byte/path APIs; Simulation assembles validated owners with
no initialization, classification, ecology calls or RNG draws. Only procedural
base climate and spatial cache are rebuilt. No new authoritative field, public
mutation API, dependency, config/default, scheduler or hash/model-schema change.
Population validates ID union/allocation, accounting/death causes, lineage and
species histories/memberships; canonical re-encoding enforces exact payload bits.
CLI simulate_state retains caller-owned engine, checks tick overflow before
stepping and samples relative to actual tick_start; batch config wrapper remains.
Run validates exclusive config/load and aliases, allows load=save, prepares both
outputs then atomically publishes checkpoint before result. No two-file transaction,
fsync or concurrent writer promise. docs/CHECKPOINTS.md and ADR-018 describe format,
API, costs and compatibility; implementation handoffs retain exact test evidence.
UI persistence remains TASK-024; all future authoritative changes must update both
codec directions, model/schema versions, inventory and continuation tests together.


TASK-023 PLAN cycle 1 (not implemented): ADR-002 refinement specifies private
application UI modules, tiny_http loopback server and embedded HTML/CSS/Canvas JS.
One UiSession owns the existing engine; capped20Hz scheduling and read-only10Hz
snapshots add no authoritative fields or schema/ecology changes. Static biome
cache, stable-ID living frame DTOs, camera and automation are observational state.
Node>=18 built-in CDP pipe driver controls actual Chromium for10/100-tick smoke/
screenshot modes with deadlines and child cleanup; Node/browser never enter core
or headless runtime requirements. Camera navigation/legend/world view only;
controls/inspection/checkpoint UI stay TASK-024, editing/charts TASK-025. Detailed
paths, protocol, visual choices and acceptance tests: TASK-023 plan-cycle1.md.


TASK-023 IMPLEMENT cycle 1: private ui_server and cli/ui adapters serve embedded
HTML/CSS/Canvas/JavaScript through tiny_http0.12 on an ephemeral loopback port.
One Simulation owner uses the ordinary production tick at an advisory20Hz, with
at most one tick per loop and10ms receive polling. Ready-after-first-draw starts
the clock. Four bounded response workers move only owned bytes/requests, never
engine state, keeping socket writes outside the engine owner. The initial biome
DTO is cached; stable-ID living frame DTOs poll at10Hz and exclude genomes/history.
All DTOs/cameras/capabilities/clocks/processes are observational, with no canonical,
checkpoint, config/default, ecology or core dependency change. OS entropy only
creates the loopback capability and does not draw engine RNG. Embedded assets and
CDP driver travel in the static executable. Node>=18/Chromium are UI-automation
requirements only; headless runtime isolation remains tested. Driver owns real
Chromium pipes; parent profile/process-group guard handles returned failures and
deadlines. World/legend/pan/zoom only: controls/inspection remain TASK-024, editing/
charts TASK-025. Protocol, visual rules, resource limits: docs/UI.md and ADR-002.
Actual test/performance/screenshot evidence: TASK-023 implementation handoffs.

TASK-024 PLAN cycle 1 (not implemented): private ui_server/session.rs will own
Simulation and observational ready/running/speed/selection/epoch/revision/cache
state; explicit command and fake-time scheduling methods permit display-free tests.
Step pauses plus one tick; Reset reconstructs current effective config/seed; load
adopts checkpoint config and pauses. Browser replies use revision/epoch instead
of monotonic tick to survive backward reset/load. Snapshot inspector uses immutable
organism/genome/traits/species data, with one last-seen DTO/death transition cache.
No core/schema/default/dependency change. Authenticated browser binary downloads
and bounded64MiB uploads reuse persistence byte APIs, with private transport.rs
body readers sending owned bytes to the engine owner; no blocking socket read in
engine loop. Browser owns file selection/download and stable-ID hit/stack choices.
All UI fields remain outside checkpoint/hash; existing canonical inventory stays
binding. Full interfaces, routes, ordered tests/risks: TASK-024 plan and ADR-002.


TASK-024 IMPLEMENT cycle 1: private ui_server/session.rs owns Simulation plus
observational ready/running/Slow5-Normal20-Fast60 speed, explicit-duration scheduler,
epoch/revision and one selected live/terminal inspector. Step pauses+one tick;
reset/current effective config and checkpoint load pause and replace cached world.
Snapshot schema2 exposes exact decimal identities/ticks and all12 named traits/
u16 alleles/parents. Browser uses buttons (no new shortcuts), stable-ID complete
cell chooser, drag threshold, selected-cell highlight, independently scrollable
inspector preserving scroll, last-observed death data and matching epoch/revision
rendering. Browser .evo downloads and file-input uploads reuse persistence bytes.
Two bounded ingress workers isolate socket reads and reject stale completion;
64MiB UI upload cap; synchronous codec/cache work can delay owner responsiveness.
No core/authoritative/config/default/ecology/dependency/canonical/checkpoint schema
change; all application fields remain outside hash/codec. docs/UI.md records final
routes/semantics/precision/resource bounds. No system dependency installed; existing
STATE prerequisite install commands remain binding. Exact commands/results and
phase decisions/limits live in TASK-024 implementation handoffs. Harness owns
review, commits, state and transition; no other phase started.

TASK-025 PLAN cycle1 (not implemented): private ui_server/configuration.rs will
bridge existing Config presets/validation to exact canonical JSON strings and
field-token DTOs; ui_server/analytics.rs will own bounded chart history and current
histograms from immutable Simulation/metrics views. UiSession gains observational
cache/history and validated new-world replacement; transport jobs carry operation
and epoch for bounded config JSON ingress. Browser configuration/charts pure modules
support display-free Node tests; own Canvas drawing adds no dependencies. All21
existing numeric config leaves are editable, with field/group errors; import/export
change draft only. Start pauses at0 after complete replacement construction.
History samples every10 ticks,2048 points plus current; all12 trait20-bin per-kind
distributions are current-frame data. UI schema3/chart_schema1 do not affect core,
config/defaults, CLI metrics, hash or checkpoint schemas. No new authoritative state
or reverse imports. Exact routes/precision/costs/tests: TASK-025 plan-cycle1.md and
ADR-002 refinement. Implementation remains assigned to the next phase.

TASK-025 IMPLEMENT cycle1: private configuration.rs describes effective Config as
canonical JSON text plus exact numeric field tokens and reuses Config validation/
presets. Operation-tagged transport jobs preserve bounded off-owner body reads,
1MiB JSON/64MiB checkpoint limits and completion epoch checks. UiSession constructs
replacement engine/world/chart cache before swapping and pauses Start at0.
Private analytics.rs reuses immutable metrics::Snapshot and living trait getters;
it owns2048 detached ten-tick DTOs plus current cached20-bin/all12 histograms.
Reset/start/load restart history; no history is authoritative or persisted.
Browser exact-token configuration.js and charts.js are pure Node-testable modules;
experiments.js wires editor/files/Canvas charts to the existing serial queue.
All21 numeric config leaves are editable. Own Canvas avoids new dependencies.
Private UI schema3/chart_schema1 only; no core/default/ecology/canonical/checkpoint/
CLI metrics schema change. Full-window serialization is bounded but grows with the
window; exact labels and relative BigInt tick coordinates coexist with approximate
Number y plotting. DTOs use existing serde_json::Value style instead of additional
serialize structs; typed Config/Snapshot remain the source of validated semantics.
Protocol, resource bounds and precision: docs/UI.md; actual phase evidence in
TASK-025 implementation handoffs. Harness retains commits, review and transitions.

TASK-026 PLAN cycle1 (not implemented): ADR-019 plans an external release example
and shared test-only measurement helper, fixed128x48 seed42 initial4600/240/40,
100 warm-up+1000 measured ticks/five repeats with >=2000 living at every measured
tick. A shorter64x48 animal-active window supplements it. Callgrind release profile
must confirm candidates before core changes. Prefer streaming row precipitation
in resource regeneration, preserving exact cell arithmetic/order with O(1) extra
workspace; optional private spatial kind-existence check avoids radius0 output
allocation. No persistent cache, authoritative field, reverse import, ecological/
default/RNG/model/canonical/checkpoint change. All current ADR-015/018 state duties
remain. Proposed10/s release guard is explicitly invoked by test.sh; baseline/new
hash/checkpoint differential and full suite required. docs/PERFORMANCE.md is a
planning scaffold, not completed evidence; exact paths/interfaces/tests and time
budget live in TASK-026 plan-cycle1.md.


TASK-026 IMPLEMENT cycle1: examples/performance_bench.rs and shared external
measurement helper use public Simulation APIs, fixed scenarios/performance.json,
100 warm-up+1000 measured ticks/five fresh repeats, with all-tick>=2000 floor.
Supplementary short mixed window and raw effective-config/counter/hash reports
are observational. Callgrind identified repeated latitude-only climate evaluation
in resources; private regenerate_rows streams one current_at precipitation per
row, preserving original per-cell float expression and row-major order with O(1)
workspace. No persistent cache, field, public core API, dependency, ecology,
default, RNG-order, canonical/model/checkpoint schema or inventory change.
Primary median751.693→847.955 ticks/s (+12.8%,population2303..5081); supplementary
1027.076→1095.760 (+6.7%). Mostly-plant primary is not sustained coexistence.
10/s release-only catastrophic slowdown guard is explicitly invoked by test.sh.
Bit-level resource oracles and30 exact baseline states/checkpoints plus20 cross-
version continuation checks pass. Trait conversion/ordered-map lookup remain
profiled costs; optional occupancy optimization was not implemented. Hardware,
profiling commands, precision/workload limits and exact suite evidence:
docs/PERFORMANCE.md,ADR-019 and TASK-026 implementation handoffs. All ADR-015/018
state duties remain unchanged; harness owns review/commits/transitions.


TASK-027 PLAN cycle1 (not implemented): ADR-020 proposes a private pure hunger
predicate in ecology/carnivores and post-upkeep Simulation gate; no new state,
public core API, config leaf or dependency. External example observer streams exact
completed-tick counts/cause counters and verifies hashes against required batch
runs. Reports/curves/trial ledger never enter engine state. If adopted, hunting
model identity2 must change in both canonical write/read blocks, rejecting old
model checkpoints while retaining schema1/envelope1 and full ADR-015/018 inventory.
Selection and compatibility remain conditional on measured trials. Detailed
implementation/testing order and limits: TASK-027 plan-cycle1.md and ADR-020.


TASK-027 IMPLEMENT cycle1: private ecology/carnivores::hungry reads own existing
energy; Simulation gates carnivore action after upkeep/liveness. At>=750 action
rests (no sensing/movement/trial/action RNG); normal age/expiry/upkeep and paid
mating continue. All other action equations,defaults,phase order and dependencies
unchanged. Shared HUNTING_MODEL_VERSION2 is encoded/validated in both canonical
identity blocks; model1 checkpoints explicitly fail. Schema1/envelope1/layout
and full ADR-015/018 inventory remain unchanged; no state/cache/timer/public API.

examples/balance_report.rs is an external read-only O(1)-memory streaming observer
over ordinary production ticks; tools/balance_report.py validates CSV counters/
absorbing zeros/exact extinction summaries against batch hashes/totals and draws
SVG curves. Python plotting retains one run externally; neither output/counts nor
experiment/config/performance records feed ecology or persistence. No added Cargo
or system dependency. Timestamped baseline diagnosis precedes changes; trial and
frozen held-out ledgers retained in TASK-027/evidence. Biology improves early
first-zero delay, not durable coexistence. Performance primary input replacement
is explicitly plant-focused after original floor failure; mixed workload unchanged.
BALANCE.md/ADR-020 explain measured choices,compatibility,tradeoffs and tests.

TASK-028 PLAN cycle1 (not implemented): reliability work is external observation
and delivery documentation. Proposed tests/reliability.rs uses existing immutable
public APIs and complete Simulation equality for deterministic randomized corpus,
resource/vital/geometry/accounting/continuation oracles. Short Python launcher
probes and tools/release_verify.py record contract and long-run evidence, reusing
examples/balance_report.rs exact per-tick observer. All ledgers, configs, CSVs,
coexistence trackers, digests, clocks and test RNG remain outside authoritative
state; no reverse dependency/core API/runtime crate/config/default/ecology/model/
canonical/checkpoint change. Static-musl/copy isolation and actual-browser checks
remain mandatory, with the full suite isolated from other browser commands.
scenarios/demo.json will be a measured frozen input, not a product default or
rescue rule. Existing ADR-001..004/015/017..020 remain binding. Detailed ordered
files/interfaces, selection algorithm, invariant corpus, contract matrix, audit,
risks and phase budget: tasks/TASK-028/handoffs/plan-cycle1.md. Final verification
and project audit documentation must distinguish current evidence from historical
results and state partly met/missing behavior without adding new features.

TASK-028 IMPLEMENT cycle1: delivery checks stay outside production dependencies.
New tests/reliability.rs compares existing immutable APIs and complete Simulation
values; its independent LCG/configs/ledgers/oracles never enter engine RNG/state.
Python tools/release_verify.py invokes ordinary binaries and unchanged streaming
balance_report, validating every completed-tick CSV row against final CLI hashes/
counts/totals. Command clocks/provenance/digests/curves are external observations.
scenarios/demo.json is a frozen initial config using existing parameters, not a
policy/default. No core,codec/schema/model/config/default/dependency change;
ADR-015/018 inventory and all owner validations remain binding. Network syscall
denial is test-process-only. Static runtime and real-browser evidence remain
separate. VERIFICATION.md/SELF_AUDIT.md and TASK-028 handoffs are final delivery
indexes; historical ledger entries above retain their original phase context.

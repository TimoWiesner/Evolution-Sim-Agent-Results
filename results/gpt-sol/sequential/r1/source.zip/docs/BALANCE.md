# Ecosystem balance (TASK-027)

Reserve-based carnivore satiety extends the first-extinction time, but **does not
achieve long-term coexistence**. Paired held-out seeds have median first extinction
**25 → 316 ticks**. All three kinds eventually become extinct under the new policy;
baseline plants survive the horizon. The improvement is an early food-chain delay,
with a real cost to eventual plant survival, not a stable equilibrium.

## Baseline diagnosis recorded before the first ecology edit

A fresh `./evosim batch` used exactly the contract section3 configuration (seed42,
64×48,400 plants,120 herbivores,20 carnivores; no extra keys), overridden with
seeds0..9 for10000 ticks. `evidence/fixed.json` retains the input. Baseline release
binary was preserved before any core edits; revision, compiler, digest and initial
command order are in `evidence/commands.json`. The baseline observer was also
preserved before core edits. No source/default/ecology change preceded the batch.

**Herbivores go extinct first in every baseline seed, at21..27, median24 ticks.**
Every one of the120 initial herbivores dies from predation, with zero births;
there are no starvation, climate, injury or old-age herbivore deaths before that
extinction. Plants number756..801 (full exact values in the
analysis); food is still abundant. Carnivores eventually starve after losing prey.
All-kind population curves and cumulative causes support this timing. This is
association; the mechanistic hypothesis was that full-reserve founders waste prey
because the old action hunts regardless of hunger. It does not prove that satiety
will solve recruitment or resource balance.

This diagnosis was written to this document and timestamped/digested
`evidence/baseline-analysis.json` **before** the first core edit. It retains the
original wording, all first-extinction counters and input digests. Later reasoning
below is explicitly post-trial. Fresh baseline per-kind exact outcomes:

| Seed | Plants first zero | Herbivores first zero | Carnivores first zero | First zero of any kind |
|---|---:|---:|---:|---:|
| 0 | survived 10000 | 27 | 875 | 27 |
| 1 | survived 10000 | 27 | 865 | 27 |
| 2 | survived 10000 | 24 | 858 | 24 |
| 3 | survived 10000 | 22 | 850 | 22 |
| 4 | survived 10000 | 22 | 836 | 22 |
| 5 | survived 10000 | 25 | 863 | 25 |
| 6 | survived 10000 | 22 | 837 | 22 |
| 7 | survived 10000 | 26 | 821 | 26 |
| 8 | survived 10000 | 21 | 852 | 21 |
| 9 | survived 10000 | 24 | 854 | 24 |

## Observation and reproducibility

All paths called `evidence/` here mean `tasks/TASK-027/evidence/`. Every formal
run advances exactly10000 ticks, including the empty tail. `batch` supplies the
required result files and coarse100-tick series. The external Rust example
`examples/balance_report.rs` independently streams tick0 and every completed tick
into three-kind CSV with births and all five cumulative death causes; its summary
includes exact first zero, counters for all kinds at each extinction, final counts,
full config and hash. It uses only immutable public getters between ordinary engine
ticks; neither CSV nor summaries enter policy/state. O(1) observer memory plus
streaming disk; hashing occurs once at the end. Python validation/plotting retains
one run's rows in memory outside the engine.

The observer's final hash, totals and final counts match every baseline batch run
and both held-out batches, not an interpolated extinction estimate. Zero at tick0
means initially absent; null means alive at horizon, right-censored. First-zero
score is the first completed tick with any zero, or the horizon if none. Thus a
score27 means positive populations through tick26; it is not27 completed positive
ticks. Absorbing zero and accounting are checked on every CSV row. Ties are retained.

Per-seed `seed-*.csv` and `seed-*.svg` show all three kinds through the full horizon;
SVG x is log(1+tick) to reveal early collapse, y is independently scaled per kind.
These are population plots, not UI screenshots. Example curves:

![Baseline seed0](../tasks/TASK-027/evidence/baseline/seed-0.svg)
![Chosen held-out seed100](../tasks/TASK-027/evidence/chosen-heldout/seed-100.svg)

Reproduce (first build on the baseline revision to reproduce baseline):

```sh
cargo build --locked --release --bin evosim --example balance_report
./evosim batch --config tasks/TASK-027/evidence/fixed.json --seeds 0,1,2,3,4,5,6,7,8,9 --ticks 10000 --out-dir OUTPUT
 target/release/examples/balance_report --config tasks/TASK-027/evidence/fixed.json --seeds 0,1,2,3,4,5,6,7,8,9 --ticks 10000 --out-dir OUTPUT
python3 tools/balance_report.py --validate tasks/TASK-027/evidence
```

Historical commands use preserved binaries under ignored `target/task027/`;
source baseline revision is recorded and the code patch for each trial is tracked.
Raw outputs/curves/configs are tracked; executables/build logs are local ignored
artifacts. Current code reproduces chosen policy, not historical baseline.

## Trials and frozen selection

`evidence/trials.json` was appended before each changed run, recording parent,
exact patch/digest, expectation, seeds, horizon and afterward every outcome.
Tuning uses only seeds0..4. Each candidate was screened at2000 ticks then followed
to10000 (maximum two full finalists). No candidate was terminated at first zero.

| Trial | Change and expectation | First-zero median / range at10000 | Decision |
|---|---|---|---|
| Baseline tuning subset | Unconditional hunting |24 /22..27|reference|
| T1 | After upkeep, own energy>=750 rests action; conserve prey, enable maturation |313 /312..315; plants first|chosen|
| T2 | Same rule with threshold500; further conservation might help recruitment |313 /312..313; plants first|rejected, no score improvement|

Both trials enable herbivore births, then switch the first extinction to plants.
For T1 seed0 at plant extinction312, herbivores number239 (142 births,23 predation
deaths), carnivores41 (21 births,no deaths), and plants have4625 births and5025
deaths:2770 starvation and2255 climate. Grazing drains plants through the existing
energy mutation path, which labels zero-energy loss Starvation; the cause label
alone cannot separate grazing from maintenance. These data support a trophic
pressure shift; plant climate deaths also matter. T2 changes later herbivore and
carnivore extinction times but fails to improve the first-zero objective. Its
unhelpful result is retained, not discarded.

Selection uses full-horizon tuning median, then worst seed, then smaller change.
Both changed candidates tie on these criteria (equal-sized constant differences).
Retain the first candidate750 as the final tie-break; its range also includes a
slightly later best outcome. This tie-break is documented before held-out use.
`evidence/selection.json` freezes policy/model/defaults before unseen seeds100..104.
No adjustment followed their results. Optional T3 cooldown40 was omitted: plant
loss already limits both candidates, so faster shared consumer recruitment was
unlikely to help; no unrun trial is claimed measured. Only two changed candidates.

## Held-out paired check

Five seeds100..104 were never screened/tuned. Chosen defaults and the preserved
baseline both ran batch plus exact observer for10000 ticks. Baseline median25,
range23..30; chosen median316,range313..320. Paired differences296,286,287,288,295
(median288). These small samples are descriptive, not a statistical stability proof.

Baseline on held-out seeds:

| Seed | Plants first zero | Herbivores first zero | Carnivores first zero | First zero of any kind |
|---|---:|---:|---:|---:|
| 100 | survived 10000 | 23 | 851 | 23 |
| 101 | survived 10000 | 30 | 872 | 30 |
| 102 | survived 10000 | 28 | 844 | 28 |
| 103 | survived 10000 | 25 | 857 | 25 |
| 104 | survived 10000 | 25 | 842 | 25 |

Chosen750 policy on held-out seeds:

| Seed | Plants first zero | Herbivores first zero | Carnivores first zero | First zero of any kind |
|---|---:|---:|---:|---:|
| 100 | 319 | 801 | 1697 | 319 |
| 101 | 316 | 816 | 1650 | 316 |
| 102 | 315 | 817 | 1652 | 315 |
| 103 | 313 | 793 | 1733 | 313 |
| 104 | 320 | 765 | 1698 | 320 |

Every chosen held-out run loses plants first; herbivores then vanish765..817 and
carnivores1650..1733. None survives10000. The original baseline retains plants in
all15 formal seeds; chosen policy empties every tuning/held-out world. That tradeoff
must remain visible when interpreting the larger first-zero score.

## Model and safety audit

The only production biology edit is a pure local hunger predicate and an early
return in the carnivore action **after ordinary upkeep and liveness**. At/above750
it skips sensing, pursuit, exploration, attack and action RNG. Below750 the old
movement/trial/odds/prey-backed nutrition are unchanged. Age/expiry, climate costs,
starvation and normal paid reproduction still apply; resting does not exempt a
parent from mating. No global kind/species counts, observer results or scarcity
feedback are read. No timer, immortal actor, replenishment, energy source, spawn
path, initial population/placement/DNA or configuration leaf is added. Every new
organism still comes only from initialization or the existing inherited paid birth
path. All numeric configuration defaults, including cooldown100, remain unchanged.
The performance scenario change below is a benchmark input, not a product default.

Hunting identity is now2 in both canonical writer and reader, shared from one
constant. State schema1/checkpoint envelope1 and full ADR-015/018 inventory stay
unchanged. Model1 checkpoints are explicitly rejected; no migration is promised.
`golden-verification.json` and two tiny empty checkpoints demonstrate independently
with Python SHA-256 that the empty-state golden changes only for identity1→2.
Tests cover checksum-valid old identity rejection, new-state roundtrip/continuation,
resting parents with hungry offspring, and unchanged absorbing-zero/accounting.

Tests previously assuming every full-energy predator acts now explicitly initialize
hungry fixtures. Saturated production nutrition cases assert resting/no draw;
pure nutrition tests retain saturation/subnormal conservation endpoints. The private expiry and public lifecycle
fixtures now disable animal reproduction as needed: satiety
allowed offspring that invalidated its old assumption that all living IDs were
founders. This preserves expiry assertions rather than removing them. The original
probability, trait, seam, movement-budget and exact RNG/energy checks remain.

## Performance and regression evidence

TASK-026's original primary workload was rerun unchanged first and **failed** the
population assertion at tick685,total1998 (exit101). Its full unguarded observer
then measured minimum564 over ticks100..1100; plants vanish799. Original config,
stderr, exit status and all counts are retained. Thresholds were not relaxed.
Replacement attempts with120 and20 initial herbivores also fail the floor
(min982 and1334). These performance-input experiments do not alter the frozen
policy or count as ecological tuning; `performance-workload-selection.json`
records every attempt.

The replacement retains128×48,4600 plants,40 carnivores,seed42,100 warmup+1000
measured ticks,five repeats,>=2000 at every measured tick and10/s guard, with
**zero initial herbivores**. It isolates natural plant regeneration, matching the
old primary's already herbivore-free timed phase. It is explicitly not a mixed
food-chain benchmark or directly comparable to the old primary timing. The original
mixed workload and nine repeats are unchanged and still exercise active animals.

Isolated final results (no concurrent tests/build/profile jobs during timing):

| Workload | Median ticks/s | Range | Population min..max | Start → end P/H/C |
|---|---:|---|---|---|
| replacement primary |857.619|796.327..859.009|2304..5118|5078/0/40 →2300/0/4|
| original mixed |671.812|656.149..673.244|2559..3059|2687/120/20 →2463/135/23|

Both meet100 ticks/s on this container;10/s remains only a catastrophic-slowdown
guard. Mixed was1095.760 in TASK-026 and is now38.7% slower, with many more living
herbivores and continuing mating/sensing/hunting work (old mixed ended2447/0/21).
This attributes likely work differences, not an isolated profiler-based causal
speed breakdown. Machine/toolchain/setup remain as disclosed in PERFORMANCE.md;
no new dependency/system package installed in this task. Initial exploratory
replacement/mixed timings overlapped checkpoint testing and are retained separately,
excluded from the reported table. Raw final reports: `performance-replacement.json`
and `performance-mixed.json`; original failure: `performance-primary.*`.

Final `./test.sh > target/task027/full-suite.log 2>&1` exited0: **232 Rust tests,
24 Python tests and all three Node scripts pass**. The one debug performance guard
ignore is explicitly exercised in release (857.001 ticks/s,min2304,tick1100).
Includes real browser controls/charts/checkpoint files, headless replay, setup,
static-musl build and copied distribution tests. Initial targeted and full-suite
fixture/golden failures are retained in `evidence/test-logs/`, with their resolutions
in `test-results.json`; no failing test or unreported skip remains. `cargo fmt
--check`, `git diff --check` and the full evidence validator pass. A final current
`./evosim batch` on all five held-out seeds reproduces frozen chosen final/totals/
series/hashes exactly (`final-build-verification.json`). Exact commands/counts are
in the implementation handoff and `evidence/commands.json`.

## Remaining limits

Founder co-location/row-major placement, identical starting DNA, a single reserve
threshold, finite horizon and modest seed samples limit inference. Predators rest
instead of actively seeking mates; conservation can synchronize future hunts.
Herbivores recruit but then overgraze a climate-stressed plant population. More
mechanisms or parameter exploration could address that in a future assigned task,
but no extra candidate is silently introduced here. The goal of durable coexistence
was **not reached**, despite the reproducible first-extinction delay.

# Plant growth and resources (model 1)

Plants grow by increasing stored energy, up to the shared energy capacity 1000.
They have no separate biomass/size variable. Each cell stores a finite renewable
photosynthetic resource; current precipitation represents available water.
This abstracts sunlight, water and fertility into one pool, rather than claiming
that water supplies chemical energy or modeling actual soil chemistry.

Initial resources equal `plants.resource_capacity` C in every cell; initial
organism reserves equal 1000. These are explicit initial-condition energy stores.
Each tick, after weather advances, external solar/primary-production energy adds
`min(C-R, plants.resource_regeneration * current_precipitation)` to each store R.
No organism or global population count controls this inflow. Empty worlds still
regenerate; there is no creation of organisms or forced population rescue.

The existing ascending-ID plant walker ages each plant first. Lifespan expiry
kills by OldAge before consuming anything. For living plants let current
normalized temperature/water be T/P, DNA optima t0/p0 and tolerance width w:

- Temperature suitability: `aT = clamp(1-abs(T-t0)/w, 0, 1)`.
- Water suitability: `aP = clamp(1-abs(P-p0)/w, 0, 1)`.
- Combined suitability: `s = aT*aP`.
- Hostile stress: `h = clamp(max(abs(T-t0),abs(P-p0))/w-1, 0, 1)`.

Subtract h health, with Climate as the explicit death cause. There is no health
regeneration here. If alive, dissipate `0.2 * metabolic_multiplier` energy for
maintenance. Zero energy kills by Starvation before any uptake. Otherwise let
H be energy headroom and eta be `plants.growth_efficiency`. If eta, suitability or
headroom is zero, consume nothing. Otherwise withdraw `u=min(R,4*s,H/eta)` and
credit exactly `eta*u` energy through the existing bounded vital primitive.
The bounded `4*s` term keeps demand finite even if tiny eta makes H/eta overflow.
All persisted values remain finite. Budget comparisons allow f64 roundoff of
1e-10 in the focused engine ledger tests (1e-9 for maximum-capacity generated tests).

Every positive energy credit debits local resources. Conversion loss `(1-eta)*u`
and maintenance dissipate energy; neither aging nor climate damage generates it.
Over an interval, summed gains cannot exceed eta times the initial local stock
plus environmental inflow. Resource capacity bounds stock, regeneration bounds
renewable supply, uptake bounds individual gain, and energy capacity bounds
reserves. Unused stock remains available. Same-cell later IDs see depletion
immediately; competition favors earlier IDs under the existing deterministic
scheduler. There is no global carrying-capacity or low-population exception.

DNA loci 6/7/8/9 specify metabolism, preferred temperature/moisture and tolerance.
Loci 2/3 specify maximum health/lifespan. Existing genome bounds/schema remain
unchanged; there are no new plant-only traits. Fertility and the configuration
controls reproduction_energy/dispersal_radius now drive clonal reproduction below;
grazing, hunting and animal reproduction are integrated (TASK-014..018).

`World::resources()` and `ResourceField::at(Cell)` are read-only, normalize foreign
cells with toroidal wrapping, and draw no randomness. RESOURCE_MODEL_VERSION is 1.
Construction/regeneration/withdrawal are internal. ResourceField depends only on
config/topology; pure plant helpers depend on traits/rng/topology; Simulation orchestrates
weather, resources and Population mutations. Population maintains death removal,
spatial synchronization and single Commit accounting. Plant actions add no RNG
draws; weather retains exactly two draws when enabled and none when disabled.

The dense field costs one f64 per cell and O(area) regeneration work per tick.
Allocation is fallible with checked byte limits; process/OS overcommit limits
still apply. No throughput or coexistence target has been measured here.

Resources are authoritative state, not a derived cache. Future checkpoints and
canonical hashes must include model version, dimensions, effective plant settings
and every row-major f64 store, alongside organisms/DNA, clock, weather and RNG.
Restoration must validate finite in-cap stores and retain depletion exactly,
without refilling. No disk checkpoint or hash format is introduced by TASK-011.

Tests exercise production ticks with controlled valid weather restoration,
independent energy ledgers, separate cold/dry changes, 128-tick shared-cell budgets,
DNA changes, cap/efficiency boundaries, all three mortality causes and spatial
removal. Public regressions include favorable old age and zero-plant continuation
for 2200 ticks, plus four-seed mixed-kind replay/accounting. See the task-local
implementation handoff for exact commands and outcomes.


## Clonal reproduction and dispersal (model 1, TASK-012)

After physiology and animal actions, visit living plants once in stable ID order,
without a second age increment. Each can make one reproductive attempt. Let E be
`plants.reproduction_energy` (default 20). Require energy e>E and a positive seed
budget b=min(E/2,1000). Also require computed e-E>0, e-E<e and e-(e-E)>=b.
These floating-point checks prevent underflow or a sub-ULP cost from creating
unpaid offspring. Costs above the energy capacity naturally disable reproduction.
Initial full reserves can fund a finite burst; they are an explicit initial source.

An eligible plant succeeds in its fertility trial with exact probability
`DNA[4]/65535`. Zero and maximum fertility draw nothing; intermediate values use
the engine's integer rejection sampler. Sample x then y uniformly from the
unique coordinates in the inclusive toroidal Chebyshev radius
`plants.dispersal_radius` (default 3). Each axis draws even if its length is one.
Large radii cover the whole axis without duplicate cells, allocation or a
neighborhood scan. The parent's cell is included and is blocked by its parent.
Radius zero and a 1x1 occupied world therefore cannot establish offspring.

Reject the sampled cell if it contains any living plant, has a pending accepted
plant birth this phase, or holds less than 1 resource after physiology. Animals
may share the cell. Existing stacked founders remain valid. There is one sampled
site per attempt, with no retry or search for a viable alternative. A temporary
ordered coordinate set reserves accepted destinations until Commit.

Request the child through the existing transactional one-parent genetic path.
Only acceptance debits E from the parent, consumes exactly 1 destination resource
as dissipated germination/site preparation, and reserves the site. Child energy
is b and health is 10 (valid for every possible genome). The remaining reproductive
energy is dissipated; resources do not credit extra child energy. Thus combined
parent/child energy cannot exceed the parent's reserve before reproduction.
ID or generation exhaustion skips the birth without payment or mutation draws.
Unexpected request errors are programming invariant failures. Fertility/dispersal
draws remain consumed on failed attempts; staged mutation rolls back on rejected
requests. No plants means no reproductive draws, seeds or spontaneous recovery.

Commit installs the captured mutated DNA, parent ID, parent generation+1, absolute
birth tick and age zero; it updates counts and spatial buckets without draws.
Children first age/act next tick, even if a parent dies after the accepted request.
No seed bank, pollination, species rule or global population feedback is present.

Reproduction adds O(plants) attempts with logarithmic map/set costs and twelve-locus
inheritance on success. Temporary reservations cost O(successes). Future checkpoint
and hash code must encode model identity, effective settings, exact depleted stores,
RNG and complete lineage/DNA/vitals; reservations are absent at tick boundaries.

Production-tick tests cover paid births, mutation endpoints, six seam/corner paths,
resource thresholds, occupied/pending sites, animal sharing, stacked founders,
ID/generation exhaustion, recursive lineage, newborn timing and exact weather /
fertility / dispersal / mutation ordering. The sampler's unique mapping is checked
exhaustively on sizes 1..8 with huge radii against independent distance oracles.
Public four-seed zero-plant and mixed-kind replay tests run for 2200 ticks.
Exact commands/results and regression migrations are in TASK-012 implement handoffs.


TASK-014 herbivores now consume up to 4 stored plant-energy units per animal/tick
within wrapped adjacent reach. Only 80% of actual removed energy funds herbivore
gain; there is no health/biomass payout. Zero energy removes a plant immediately
as Starvation, before later animals and plant reproduction; partial plants remain
able to regrow. Plant physiology runs first, so observed full-tick energy changes
combine maintenance/growth and grazing. See ANIMALS.md and ADR-011 for ledgers.

TASK-018 selects default resource regeneration 2 (previously 1); all other plant
defaults and model equations stay unchanged. See ECOLOGY.md for measurements.

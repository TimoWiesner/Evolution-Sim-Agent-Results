# Configuration schema v1

Configuration is JSON. A file containing only the following fixed keys is valid:

```json
{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}
```

The root, world and initial must be objects. All fixed leaves are required.
Optional groups and individual leaves default when omitted; empty optional objects
are valid. Explicit null fails. Unknown keys fail at every level, to catch typos.
Duplicate object keys use the last occurrence. Object order is irrelevant.
Malformed JSON, trailing documents and non-object roots report path `$`.
Other errors name a dotted field path; I/O errors name the file path.

Integer fields require JSON integer tokens; strings, booleans, fractions and
exponent notation are rejected. Float fields accept integer tokens and finite f64
values. Seeds retain arbitrary signed decimal integer precision, normalize -0 to
0 and export as JSON numbers. Seed::wrapping_u64 converts modulo 2^64 for the
future RNG. UI integrations must preserve large seeds without JavaScript numeric
truncation. Dimensions/counts use usize (64 bits on the target); width*height and
total initial counts must fit, and the total must be less than u64::MAX to reserve
a next organism ID. Overflow reports world.width/world.height or initial.
Shared cells are allowed: counts can exceed area. Validation allocates no world;
representable configurations can still exceed memory available to a future engine.

All bounds below are inclusive except explicitly positive lower bounds.

| JSON path | Rust value / valid range | Default | Meaning |
|---|---|---|---|
| seed | Seed / any signed JSON integer | required; programmatic default 42 | deterministic seed |
| world.width | usize / 1..usize::MAX, checked area | required; default 64 | horizontal cells |
| world.height | usize / 1..usize::MAX, checked area | required; default 48 | vertical cells |
| initial.plants | usize / 0..usize::MAX, checked sum | required; default 400 | initial individuals |
| initial.herbivores | usize / 0..usize::MAX, checked sum | required; default 120 | initial individuals |
| initial.carnivores | usize / 0..usize::MAX, checked sum | required; default 20 | initial individuals |
| climate.year_ticks | u64 / 1..u64::MAX | 1000 | seasonal period |
| climate.season_temperature_amplitude | f64 / 0..1 | 0.15 | normalized seasonal temperature amplitude |
| climate.season_precipitation_amplitude | f64 / 0..1 | 0.10 | normalized seasonal precipitation amplitude |
| climate.weather_amplitude | f64 / 0..1 | 0.05 | normalized weather deviation; zero disables weather |
| genetics.mutation_per_million | u32 / 0..1000000 | 10000 | exact per-locus probability numerator over 1000000 |
| genetics.mutation_max_step | u16 / 1..65535 | 1024 | maximum nonzero signed allele step |
| plants.resource_capacity | f64 / 0 exclusive ..1000000 | 100 | per-cell resource ceiling |
| plants.resource_regeneration | f64 / 0..1000000 | 2 | maximum resource addition per cell/tick, capped at capacity |
| plants.growth_efficiency | f64 / 0..1 | 0.5 | consumed resource converted to plant energy |
| plants.reproduction_energy | f64 / 0 exclusive ..1000000 | 20 | energy threshold and cost budget for a birth |
| plants.dispersal_radius | u32 / 0..u32::MAX | 3 | maximum toroidal Chebyshev dispersal distance |
| animals.movement_cost | f64 / 0..1000000 | 0.2 | base energy cost per adjacent step |
| animals.basal_cost | f64 / 0 exclusive ..1000000 | 0.1 | base energy cost per active tick |
| animals.reproduction_energy | f64 / 0 exclusive ..1000000 | 30 | per-parent energy budget for reproduction |
| animals.reproduction_cooldown | u64 / 1..u64::MAX | 100 | minimum ticks between births |

The exclusive lower bounds are explicit exceptions to the inclusive table rule.
No constraint regeneration<=capacity: a refill can saturate at capacity. Climate
amplitudes can sum above 1; current climate clamps normalized outputs to [0,1]. Zero
mutation and weather are valid. Mutation strength remains positive even at zero
rate so later re-enabling mutation cannot create an invalid distribution. Default
biology has isolated viability and multi-seed measurements in [ECOLOGY.md](ECOLOGY.md);
these are not a promise of coexistence or performance.
Named default constants are centralized in src/config.rs. A full exported config includes every optional group/leaf.

## Built-in presets

Select an exact name with `Config::preset(name)`; list names using
`Config::preset_names()`. Every preset uses seed 42 and the defaults above except:

| Name | Dimensions | Initial plants/herbivores/carnivores | Overrides and intended experiment |
|---|---|---|---|
| baseline | 64x48 | 400/120/20 | contract example; Config::default() |
| seasonal | 64x48 | 400/120/20 | year_ticks=240, season_temperature_amplitude=0.3, weather_amplitude=0.1; stronger, faster seasons |
| plant-only | 32x24 | 200/0/0 | mutation_per_million=50000, dispersal_radius=5; isolated plant diversification |

Presets pass the same validation as input files. These are experimental inputs;
only the baseline has measured outcomes in ECOLOGY.md.

## Library API

```rust
use evosim::config::Config;

let config = Config::preset("seasonal")?;
assert_eq!(config.climate().year_ticks(), 240);
config.save("target/seasonal.json")?;
let reloaded = Config::load("target/seasonal.json")?;
assert_eq!(config, reloaded);
Ok::<(), evosim::config::ConfigError>(())
```

`Config::from_json(&str)` and `Config::to_json()` provide string operations;
`load` and `save` accept paths. Export is pretty JSON containing every effective
field, with deterministic key order, exact integer seeds and f64 round trips.
Export is a configuration, not a checkpoint or canonical state-hash encoding.
All operations return `Result<_, ConfigError>`; errors implement Display/Error
and expose `path()` and `message()`. Saves report I/O failures and are not atomic.

Config and group records derive Clone/Debug/PartialEq, have private fields and
read-only accessors named after JSON keys. Edits must pass through validation
by editing JSON and reloading. Seed also provides from_i64/from_u64/as_decimal.
Simulation now consumes the climate settings for seasons and weather; see
[the model and state boundary](CLIMATE.md#current-climate-temporal-model-version-1).
Year length 1 is a constant seasonal phase; zero weather amplitude draws nothing.
CLI run handling belongs to TASK-019; the engine consumes all biological groups. Future parameters
must add types, defaults, validation, documentation and tests here; strict unknown
key rejection makes schema evolution explicit. Only JSON is supported.


TASK-009 consumes `genetics.mutation_per_million` and `mutation_max_step` in
accepted internal birth requests. Defaults and validation are unchanged. All
sampling uses the Simulation RNG; rejected requests roll back its stream.
Rate zero copies parental material without mutation draws. See GENETICS.md for
crossover, step/clamping and endpoint draw semantics. Production reproduction
rules are implemented for plants in TASK-012 and animals in TASK-016 (ADR-013).


TASK-011 consumes `plants.resource_capacity` (initial and maximum local energy
stock), `resource_regeneration` (maximum per-tick environmental inflow, scaled by
current precipitation) and `growth_efficiency` (withdrawal-to-energy conversion
eta in [0,1]). TASK-018 raises default regeneration from 1 to 2; validation is unchanged. TASK-012 consumes reproduction
energy as a strict eligibility threshold and paid cost E, transferring min(E/2,1000)
to offspring with a positive representable parent debit. Costs above 1000 disable
births. Dispersal radius samples one uniform unique toroidal Chebyshev cell,
including the origin, and rejects plants/pending births or remaining stock <1.
Accepted establishment consumes 1 local resource. DNA fertility supplies the exact
per-tick trial probability. See [plant model/source ledger](PLANTS.md).

TASK-013 consumes `animals.movement_cost` as the base energy units per adjacent
step, multiplied by inherited speed and metabolic_multiplier. Each completed
step is charged; unaffordable steps do not occur. Zero disables movement charges.
TASK-014/015 consume basal_cost for every living herbivore/carnivore action: the effective
base is max(configured value, 1e-9), multiplied by inherited metabolism and a
current-temperature stress factor in [1,2]. These are dissipated energy units per
tick; the floor prevents rounding away arbitrarily tiny valid costs. Hunting adds
a fixed 0.5 * inherited metabolism attack cost, bounded stochastic odds and 80%
prey-energy conversion within capacity (ADR-012); no configuration key/default
changes. TASK-016 consumes reproduction_energy as a cost for EACH parent and
newborn energy E; both parents require strictly more than E and representable
combined losses >= E. Costs >=1000 disable animal births at bounded capacity.
reproduction_cooldown is the minimum elapsed ticks since each parent last
successfully reproduced; both parents are stamped at acceptance. Fertility is
the exact product of both DNA fertility alleles, and maturity is lifespan/10
(floored, minimum 1). No schema/default changes. See
[animal models](ANIMALS.md) for exact equations, draws and sharing rules.

TASK-019 adds `Seed::from_decimal(&str)` for CLI overrides: optional minus,
ASCII digits only, arbitrary magnitude, normalized leading zeroes and negative
zero. `Config::with_seed(Seed)` clones an already validated configuration and
replaces only its seed. `run` validates the input file before applying overrides;
`--seed` cannot hide a missing or invalid required input seed.


TASK-027 retains every numeric default/preset field. Carnivore satiety is a private
hunting model2 policy (own post-upkeep energy<750 enables action), not a config
key. Old hunting1 checkpoints are rejected. See ANIMALS.md and BALANCE.md.

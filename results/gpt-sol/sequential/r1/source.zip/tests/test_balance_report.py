"""Synthetic completed-tick fixtures for exact extinction and counter validation."""
import csv,importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('balance',Path(__file__).resolve().parents[1]/'tools/balance_report.py')
balance=importlib.util.module_from_spec(spec);spec.loader.exec_module(balance)
class BalanceReportTests(unittest.TestCase):
 def fixture(self,root):
  rows=[]
  for t in range(4):
   row={'tick':t}
   for i,n in enumerate(balance.NAMES):
    count=0 if i==0 or t>=2 else 1
    row[n]=count;row[n+'_births']=0;row[n+'_deaths']=int(i!=0 and t>=2)
    for c in balance.CAUSES:row[n+'_'+c]=int(i!=0 and t>=2 and c=='Predation')
   rows.append(row)
  with (root/'seed-0.csv').open('w') as f:
   writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
  def counters(row):
   return {n:{'initial':int(i!=0),'count':row[n],'births':0,'deaths':row[n+'_deaths'],'causes':{c:row[n+'_'+c] for c in balance.CAUSES}} for i,n in enumerate(balance.NAMES)}
  r={'seed':'0','tick_end':3,'first_zero':[0,2,2],'coexistence':0,'right_censored':False,'first_kinds':['plants'],'final':counters(rows[-1]),'extinctions':{n:{'tick':t,'counters':counters(rows[t])} for n,t in zip(balance.NAMES,[0,2,2])},'state_hash':'abc'}
  (root/'observer.json').write_text(json.dumps({'ticks':3,'runs':[r]}));return r,rows
 def test_absent_early_tied_extinctions(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'target') as d:
   root=Path(d);self.fixture(root);r=balance.validate(root)
   self.assertEqual(r['first_zero'],[[0,2,2]]);self.assertTrue((root/'seed-0.svg').exists())
 def test_censor_and_counter_corruption(self):
  with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'target') as d:
   root=Path(d);r,rows=self.fixture(root)
   for row in rows:
    for n in balance.NAMES:
     row[n]=1;row[n+'_deaths']=0;row[n+'_Predation']=0
   with (root/'seed-0.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
   for n in balance.NAMES:r['final'][n].update(initial=1,count=1,deaths=0,causes={c:0 for c in balance.CAUSES})
   r.update(first_zero=[None]*3,coexistence=3,right_censored=True,first_kinds=[],extinctions={})
   (root/'observer.json').write_text(json.dumps({'ticks':3,'runs':[r]}));self.assertEqual(balance.validate(root)['coexistence_median'],3)
   r['final']['plants']['births']=1;(root/'observer.json').write_text(json.dumps({'ticks':3,'runs':[r]}))
   with self.assertRaises(AssertionError):balance.validate(root)
if __name__=='__main__': unittest.main()

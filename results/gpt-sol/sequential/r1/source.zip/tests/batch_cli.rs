//! Real-process batch validation, independent standalone parity and file safety.
use serde_json::{Value, json};
use std::{
    fs,
    path::{Path, PathBuf},
    process::{Command, Output},
};
struct Fixture(PathBuf);
impl Fixture {
    fn new(name: &str) -> Self {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("batch-{name}-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        fs::write(root.join("config.json"), config().to_string()).unwrap();
        Self(root)
    }
    fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_evosim"))
            .args(args)
            .current_dir(&self.0)
            .env_remove("DISPLAY")
            .env_remove("WAYLAND_DISPLAY")
            .output()
            .unwrap()
    }
    fn batch(&self, ticks: &str, extra: &[&str]) -> Value {
        let mut args = vec![
            "batch",
            "--config",
            "config.json",
            "--seeds",
            "7,11",
            "--ticks",
            ticks,
            "--out-dir",
            "results",
        ];
        args.extend_from_slice(extra);
        let o = self.run(&args);
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
        assert!(o.stdout.is_empty() && o.stderr.is_empty());
        read(&self.0.join("results/summary.json"))
    }
    fn error(&self, args: &[&str]) {
        let o = self.run(args);
        assert_eq!(o.status.code(), Some(2), "{args:?}");
        assert!(o.stdout.is_empty() && !o.stderr.is_empty(), "{args:?}");
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn config() -> Value {
    json!({"seed":42,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":1,"carnivores":0}})
}
fn read(path: &Path) -> Value {
    serde_json::from_slice(&fs::read(path).unwrap()).unwrap()
}
fn strip(v: &mut Value) {
    for key in ["elapsed_seconds", "ticks_per_second"] {
        v.as_object_mut().unwrap().remove(key);
    }
}
#[test]
fn contract_and_matrix_equal_standalone_and_repeat() {
    let f = Fixture::new("parity");
    for extra in [
        vec![],
        vec!["--sweep", "plants.resource_regeneration=[1,2]"],
    ] {
        let summary = f.batch("17", &extra);
        let runs = summary["runs"].as_array().unwrap();
        assert_eq!(runs.len(), if extra.is_empty() { 2 } else { 4 });
        for (id, run) in runs.iter().enumerate() {
            assert_eq!(run["run_id"], id);
            assert_eq!(run["variant_index"], id / 2);
            assert_eq!(run["seed"], if id % 2 == 0 { 7 } else { 11 });
            assert_eq!(run["tick_start"], 0);
            assert_eq!(run["tick_end"], 17);
            let relative = run["result_file"].as_str().unwrap();
            assert_eq!(
                relative,
                if extra.is_empty() {
                    format!("seed-{}.json", run["seed"])
                } else {
                    format!("variant-{}/seed-{}.json", id / 2, run["seed"])
                }
            );
            let mut effective = run["parameters"].clone();
            effective["seed"] = run["seed"].clone();
            assert_eq!(effective["world"], config()["world"]);
            fs::write(f.0.join("oracle.json"), effective.to_string()).unwrap();
            let o = f.run(&[
                "run",
                "--config",
                "oracle.json",
                "--ticks",
                "17",
                "--out",
                "oracle-result.json",
            ]);
            assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
            let mut actual = read(&f.0.join("results").join(relative));
            assert_eq!(run["final"], actual["final"]);
            assert_eq!(run["state_hash"], actual["state_hash"]);
            let mut expected = read(&f.0.join("oracle-result.json"));
            strip(&mut actual);
            strip(&mut expected);
            assert_eq!(actual, expected);
        }
        let bytes = fs::read(f.0.join("results/summary.json")).unwrap();
        let csv = fs::read(f.0.join("results/summary.csv")).unwrap();
        assert_eq!(summary, f.batch("17", &extra));
        assert_eq!(bytes, fs::read(f.0.join("results/summary.json")).unwrap());
        assert_eq!(csv, fs::read(f.0.join("results/summary.csv")).unwrap());
    }
}
#[test]
fn tick_zero_hand_oracle_and_extinct_tail() {
    let f = Fixture::new("aggregates");
    let summary = f.batch("0", &["--sweep", "initial.plants=[0,4]"]);
    assert_eq!(
        summary["aggregates"],
        json!({
        "plants":{"mean":2.0,"min":0,"max":4,"extinction_count":2,"extinction_fraction":0.5},
        "herbivores":{"mean":1.0,"min":1,"max":1,"extinction_count":0,"extinction_fraction":0.0},
        "carnivores":{"mean":0.0,"min":0,"max":0,"extinction_count":4,"extinction_fraction":1.0}})
    );
    fs::write(f.0.join("config.json"),json!({"seed":42,"world":{"width":2,"height":2},"initial":{"plants":0,"herbivores":4,"carnivores":2}}).to_string()).unwrap();
    let summary = f.batch("5000", &[]);
    for run in summary["runs"].as_array().unwrap() {
        assert_eq!(run["tick_end"], 5000);
        assert_eq!(
            run["extinct"],
            json!({"plants":true,"herbivores":true,"carnivores":true})
        );
        let result = read(
            &f.0.join("results")
                .join(run["result_file"].as_str().unwrap()),
        );
        assert_eq!(
            result["series"].as_array().unwrap().last().unwrap()["tick"],
            5000
        );
        for kind in ["plants", "herbivores", "carnivores"] {
            assert_eq!(result["final"][kind], 0);
        }
    }
}
#[test]
fn validation_preserves_existing_outputs() {
    let f = Fixture::new("errors");
    f.batch("0", &[]);
    let summary = fs::read(f.0.join("results/summary.json")).unwrap();
    let base = vec![
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "7,11",
        "--ticks",
        "0",
        "--out-dir",
        "results",
    ];
    for args in [
        vec!["batch"],
        vec!["batch", "--ticks"],
        vec!["batch", "--config", "config.json"],
        vec![
            "batch",
            "--seeds",
            "1",
            "--ticks",
            "0",
            "--out-dir",
            "results",
        ],
    ] {
        f.error(&args);
    }
    for flag in [
        "--config",
        "--seeds",
        "--ticks",
        "--out-dir",
        "--unknown",
        "--jobs",
        "--sample-every",
        "--save",
        "--load",
    ] {
        let mut a = base.clone();
        a.extend([flag, "1"]);
        f.error(&a);
    }
    for (index, values) in [
        (
            4,
            vec![
                "", ",1", "1,", "1,,2", "1, 2", "+1", "1.0", "1e2", "1,01", "0,-0",
            ],
        ),
        (6, vec!["-1", "1.0", "+1", "1e2", "18446744073709551616"]),
        (2, vec!["missing.json"]),
    ] {
        for value in values {
            let mut a = base.clone();
            a[index] = value;
            f.error(&a);
        }
    }
    for spec in [
        "initial.plants",
        "initial.plants=bad",
        "initial.plants=[]",
        "initial.plants={}",
        "initial.plants=[null]",
        "initial.plants=[true]",
        "initial.plants=[\"1\"]",
        "initial.plants=[1.5]",
        "initial.plants=[-1]",
        "world.width=[0]",
        "world.width=[18446744073709551615]",
        "world.width.extra=[1]",
        "missing.leaf=[1]",
        "seed=[1]",
        "initial=[1]",
        "initial.missing=[1]",
        "plants.resource_regeneration=[1,1.0]",
        "initial.plants=[1,1]",
        "initial.plants=[1,-1]",
    ] {
        let mut a = base.clone();
        a.extend(["--sweep", spec]);
        f.error(&a);
    }
    let mut a = base.clone();
    a.extend([
        "--sweep",
        "initial.plants=[0,4]",
        "--sweep",
        "initial.plants=[1,2]",
    ]);
    f.error(&a);
    assert_eq!(summary, fs::read(f.0.join("results/summary.json")).unwrap());
    assert!(!fs::read_dir(f.0.join("results")).unwrap().any(|p| {
        p.unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".evosim")
    }));
    fs::write(f.0.join("config.json"), "{}").unwrap();
    let mut a = base.clone();
    a.extend(["--sweep", "initial.plants=[1,2]"]);
    f.error(&a);
    assert_eq!(summary, fs::read(f.0.join("results/summary.json")).unwrap());
}
#[test]
fn filesystem_preflight_and_config_alias() {
    use std::os::unix::fs::symlink;
    let f = Fixture::new("files");
    fs::create_dir(f.0.join("real")).unwrap();
    symlink("real", f.0.join("link")).unwrap();
    fs::write(f.0.join("regular"), "sentinel").unwrap();
    for destination in ["link", "link/child", "regular"] {
        f.error(&[
            "batch",
            "--config",
            "config.json",
            "--seeds",
            "1",
            "--ticks",
            "0",
            "--out-dir",
            destination,
        ]);
    }
    let args = [
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "1",
        "--ticks",
        "0",
        "--out-dir",
        "results",
    ];
    fs::create_dir(f.0.join("results")).unwrap();
    let out = f.0.join("results/seed-1.json");
    symlink("../config.json", &out).unwrap();
    f.error(&args);
    fs::remove_file(&out).unwrap();
    fs::create_dir(&out).unwrap();
    f.error(&args);
    fs::remove_dir(&out).unwrap();
    assert!(Command::new("mkfifo").arg(&out).status().unwrap().success());
    f.error(&args);
    fs::remove_file(&out).unwrap();
    fs::hard_link(f.0.join("config.json"), &out).unwrap();
    f.error(&args);
    fs::remove_file(&out).unwrap();
    fs::hard_link(f.0.join("config.json"), f.0.join("results/summary.json")).unwrap();
    f.error(&args);
    fs::remove_file(f.0.join("results/summary.json")).unwrap();
    symlink("../real", f.0.join("results/variant-0")).unwrap();
    let mut sweep = args.to_vec();
    sweep.extend(["--sweep", "initial.plants=[1,2]"]);
    f.error(&sweep);
    assert!(!f.0.join("results/summary.json").exists());
    // Ordinary missing ancestors are created, and unrelated files survive reruns.
    let o = f.run(&[
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "1",
        "--ticks",
        "0",
        "--out-dir",
        "new/child",
    ]);
    assert!(o.status.success());
    fs::write(f.0.join("new/child/sentinel"), "keep").unwrap();
    let o = f.run(&[
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "1",
        "--ticks",
        "0",
        "--out-dir",
        "new/child",
    ]);
    assert!(o.status.success());
    assert_eq!(
        fs::read_to_string(f.0.join("new/child/sentinel")).unwrap(),
        "keep"
    );
}

#[test]
fn normalized_exact_seeds_option_order_and_invalid_matrix_before_output() {
    let f = Fixture::new("normalization");
    let o = f.run(&[
        "batch",
        "--out-dir",
        "results",
        "--ticks",
        "0",
        "--seeds",
        "0007,-00,-0008,18446744073709551623",
        "--config",
        "config.json",
    ]);
    assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
    let summary = read(&f.0.join("results/summary.json"));
    let runs = summary["runs"].as_array().unwrap();
    let seeds = ["7", "0", "-8", "18446744073709551623"];
    for (run, seed) in runs.iter().zip(seeds) {
        assert_eq!(run["seed"].to_string(), seed);
        assert_eq!(run["result_file"], format!("seed-{seed}.json"));
    }
    assert_ne!(runs[0]["state_hash"], runs[3]["state_hash"]);
    f.error(&[
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "1,2",
        "--ticks",
        "0",
        "--out-dir",
        "fresh",
        "--sweep",
        "initial.plants=[1,-1]",
    ]);
    assert!(!f.0.join("fresh").exists());
    f.error(&[
        "batch",
        "--config",
        "config.json",
        "--seeds",
        "1",
        "--ticks",
        "0",
        "--out-dir",
        "",
    ]);
}

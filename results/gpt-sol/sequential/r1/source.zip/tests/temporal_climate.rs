use evosim::{
    climate::Climate,
    config::Config,
    rng::Rng,
    simulation::Simulation,
    temporal_climate::{TemporalClimate, WeatherState},
    topology::Topology,
};

fn config(seed: u64, width: usize, height: usize, year: u64, t: f64, p: f64, w: f64) -> Config {
    Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{width},"height":{height}}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}},"climate":{{"year_ticks":{year},"season_temperature_amplitude":{t},"season_precipitation_amplitude":{p},"weather_amplitude":{w}}}}}"#)).unwrap()
}
fn values(sim: &Simulation) -> Vec<(u64, u64)> {
    let topology = sim.world().topology();
    topology
        .cells_within(topology.cell(0, 0), usize::MAX)
        .map(|cell| {
            let c = sim.world().current_climate_at(cell);
            (c.temperature().to_bits(), c.precipitation().to_bits())
        })
        .collect()
}

#[test]
fn exact_annual_repeat_all_cells_and_phases_without_weather() {
    for width in 1..=8 {
        for height in 1..=8 {
            for year in [1, 2, 7, 16, 240, 1000] {
                let c = config(42, width, height, year, 0.15, 0.1, 0.);
                let mut sim = Simulation::new(c).unwrap();
                let rng = sim.rng_state();
                let mut first_year = Vec::new();
                for _ in 0..year {
                    first_year.push(values(&sim));
                    sim.advance_one_tick().unwrap();
                }
                for phase in first_year {
                    assert_eq!(values(&sim), phase);
                    sim.advance_one_tick().unwrap();
                }
                assert_eq!(sim.rng_state(), rng);
                assert_eq!(sim.tick(), year * 2);
            }
        }
    }
}

#[test]
fn seasonal_golden_samples_zone_strength_and_independent_amplitudes() {
    // h=3 has q=.25 at seam rows, q=1 at its middle, up to libm rounding.
    let topology = Topology::new(1, 3).unwrap();
    let base = Climate::new(topology);
    let c = config(42, 1, 3, 16, 0.2, 0.2, 0.);
    for (tick, expected_t, expected_p) in [
        (0, 0.4125, 0.475),
        (4, 0.25, 0.6),
        (8, 0.0875, 0.725),
        (16, 0.4125, 0.475),
    ] {
        let temporal = TemporalClimate::from_state(
            c.climate().clone(),
            WeatherState::new(1, tick, 0., 0.).unwrap(),
        )
        .unwrap();
        let sample = temporal.current_at(&base, topology.cell(0, 0));
        assert!((sample.temperature() - expected_t).abs() < 1e-14);
        assert!((sample.precipitation() - expected_p).abs() < 1e-14);
    }
    // Independent quarter/half-year expectations on rows in all five zones.
    let topology = Topology::new(1, 256).unwrap();
    let base = Climate::new(topology);
    for y in [0, 35, 55, 85, 127] {
        let cell = topology.cell(0, y);
        let b = base.base_at(cell);
        let q = b.temperature();
        for tick in [0, 4, 8, 12, 16] {
            let sign = match tick {
                0 | 16 => 1.,
                8 => -1.,
                _ => 0.,
            };
            let temporal = TemporalClimate::from_state(
                c.climate().clone(),
                WeatherState::new(1, tick, 0., 0.).unwrap(),
            )
            .unwrap();
            let actual = temporal.current_at(&base, cell);
            assert!(
                (actual.temperature() - (q + 0.2 * (1. - 0.75 * q) * sign).clamp(0., 1.)).abs()
                    < 1e-14
            );
            assert!(
                (actual.precipitation()
                    - (b.precipitation() - 0.1 * (1. + q) * sign).clamp(0., 1.))
                .abs()
                    < 1e-14
            );
        }
    }
    for (t, p) in [(0., 0.2), (0.2, 0.)] {
        let c = config(42, 1, 3, 16, t, p, 0.);
        let mut sim = Simulation::new(c).unwrap();
        let cell = sim.world().topology().cell(0, 0);
        let start = sim.world().current_climate_at(cell);
        for _ in 0..8 {
            sim.advance_one_tick().unwrap();
        }
        let end = sim.world().current_climate_at(cell);
        assert_eq!(start.temperature() == end.temperature(), t == 0.);
        assert_eq!(start.precipitation() == end.precipitation(), p == 0.);
    }
    let mut shorter = Simulation::new(config(42, 1, 3, 8, 0.2, 0.2, 0.)).unwrap();
    for _ in 0..4 {
        shorter.advance_one_tick().unwrap();
    }
    assert!(
        (shorter
            .world()
            .current_climate_at(topology.cell(0, 0))
            .temperature()
            - 0.0875)
            .abs()
            < 1e-14
    );
}

#[test]
fn seeded_weather_trace_queries_seams_and_clone_continuation() {
    let trace = |seed| {
        let mut sim = Simulation::new(config(seed, 7, 48, 16, 0.15, 0.1, 0.05)).unwrap();
        let mut unobserved = sim.clone();
        let mut trace = Vec::new();
        for tick in 0..=293 {
            assert_eq!(sim.tick(), sim.world().temporal_climate().tick());
            let before = sim.clone();
            let top = sim.world().topology();
            let foreign = Topology::new(100, 100).unwrap().cell(99, 99);
            assert_eq!(
                sim.world().current_climate_at(foreign),
                sim.world().current_climate_at(top.cell(99, 99))
            );
            for y in 0..48 {
                assert_eq!(
                    sim.world().current_climate_at(top.cell(0, y)),
                    sim.world().current_climate_at(top.cell(6, y))
                );
                assert_eq!(
                    sim.world().current_climate_at(top.cell(0, y)),
                    sim.world().current_climate_at(top.cell(0, 47 - y))
                );
            }
            let v = values(&sim);
            assert_eq!(sim, before);
            trace.push((
                v,
                sim.world().temporal_climate().weather_state(),
                sim.rng_state(),
            ));
            if tick == 37 {
                unobserved = sim.clone();
            }
            sim.advance_one_tick().unwrap();
            unobserved.advance_one_tick().unwrap();
            assert_eq!(sim, unobserved);
        }
        trace
    };
    let a = trace(42);
    assert_eq!(a, trace(42));
    let b = trace(43);
    assert_ne!(a[1].0, b[1].0);
    assert_ne!(a[1].1, b[1].1);
}

#[test]
fn bounded_extremes_long_traces_and_exact_draw_counts() {
    for (width, height) in [(1, 1), (1, 7), (7, 1), (2, 2), (3, 11), (8, 7)] {
        for (t, p, w) in [
            (0., 0., 0.),
            (1., 1., 1.),
            (0., 1., 1.),
            (1., 0., 1.),
            (1., 1., 0.),
            (0., 0., f64::MIN_POSITIVE),
        ] {
            for seed in [0, 42, u64::MAX] {
                let c = config(seed, width, height, if seed == 0 { 1 } else { 7 }, t, p, w);
                let mut expected_rng = Rng::from_seed(c.seed());
                let mut sim = Simulation::new(c).unwrap();
                for _ in 0..2001 {
                    let ws = sim.world().temporal_climate().weather_state();
                    for offset in [ws.temperature_offset(), ws.precipitation_offset()] {
                        assert!(offset.is_finite() && offset.abs() <= w);
                    }
                    for (t, p) in values(&sim) {
                        for v in [f64::from_bits(t), f64::from_bits(p)] {
                            assert!(v.is_finite() && (0.0..=1.0).contains(&v));
                        }
                    }
                    assert_eq!(sim.rng_state(), expected_rng.state());
                    sim.advance_one_tick().unwrap();
                    if w > 0. {
                        expected_rng.next_u64();
                        expected_rng.next_u64();
                    }
                }
            }
        }
    }
}

#[test]
fn restoration_validation_and_modulo_before_float_conversion() {
    for version in [0, 2, u32::MAX] {
        assert!(WeatherState::new(version, 0, 0., 0.).is_err());
    }
    for bad in [
        f64::NAN,
        f64::INFINITY,
        f64::NEG_INFINITY,
        1.00001,
        -1.00001,
    ] {
        assert!(WeatherState::new(1, 0, bad, 0.).is_err());
        assert!(WeatherState::new(1, 0, 0., bad).is_err());
    }
    for amplitude in [0., 0.05, 1.] {
        let c = config(42, 1, 3, 7, 0.2, 0.1, amplitude);
        assert!(
            TemporalClimate::from_state(
                c.climate().clone(),
                WeatherState::new(1, 37, amplitude, -amplitude).unwrap()
            )
            .is_ok()
        );
        if amplitude < 1. {
            assert!(
                TemporalClimate::from_state(
                    c.climate().clone(),
                    WeatherState::new(1, 37, amplitude + 0.001, 0.).unwrap()
                )
                .is_err()
            );
        }
    }
    let top = Topology::new(1, 3).unwrap();
    let base = Climate::new(top);
    for year in [1, 7, 16, 1000, u64::MAX] {
        let c = config(42, 1, 3, year, 0.2, 0.1, 0.);
        for tick in [0, 1, u64::MAX - 1, u64::MAX] {
            let at = |tick| {
                TemporalClimate::from_state(
                    c.climate().clone(),
                    WeatherState::new(1, tick, 0., 0.).unwrap(),
                )
                .unwrap()
                .current_at(&base, top.cell(0, 0))
            };
            assert_eq!(at(tick), at(tick % year));
        }
    }
    let initial = TemporalClimate::new(config(42, 1, 1, 1, 0., 0., 0.1).climate().clone());
    assert_eq!(initial.tick(), 0);
    assert_eq!(initial.weather_state().version(), 1);
    assert_eq!(initial.weather_state().temperature_offset().to_bits(), 0);
    assert_eq!(initial.weather_state().precipitation_offset().to_bits(), 0);
}

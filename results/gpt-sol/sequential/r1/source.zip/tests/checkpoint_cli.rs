use serde_json::{Value, json};
use std::{
    fs,
    path::{Path, PathBuf},
    process::{Command, Output},
};
struct Fixture(PathBuf);
impl Fixture {
    fn new(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("checkpoint-{name}-{}", std::process::id()));
        let _ = fs::remove_dir_all(&path);
        fs::create_dir_all(&path).unwrap();
        fs::write(path.join("config.json"),json!({"seed":42,"world":{"width":8,"height":6},"initial":{"plants":20,"herbivores":8,"carnivores":2}}).to_string()).unwrap();
        Self(path)
    }
    fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_evosim"))
            .arg("run")
            .args(args)
            .current_dir(&self.0)
            .env_remove("DISPLAY")
            .env_remove("WAYLAND_DISPLAY")
            .output()
            .unwrap()
    }
    fn ok(&self, args: &[&str]) -> Value {
        let out = self.run(args);
        assert!(
            out.status.success(),
            "{args:?}: {}",
            String::from_utf8_lossy(&out.stderr)
        );
        assert!(out.stdout.is_empty() && out.stderr.is_empty());
        let p = args.windows(2).find(|w| w[0] == "--out").unwrap()[1];
        serde_json::from_slice(&fs::read(self.0.join(p)).unwrap()).unwrap()
    }
    fn bad(&self, args: &[&str]) {
        let out = self.run(args);
        assert_eq!(out.status.code(), Some(2), "{args:?}");
        assert!(out.stdout.is_empty() && !out.stderr.is_empty());
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
#[test]
fn split_zero_and_nonzero_relative_sampling_chain_and_seed() {
    let f = Fixture::new("splits");
    for seed in ["42", "-184467440737095516170001"] {
        let direct = f.ok(&[
            "--config",
            "config.json",
            "--ticks",
            "200",
            "--out",
            "direct.json",
            "--sample-every",
            "1",
            "--seed",
            seed,
        ]);
        for a in [0, 7, 53] {
            let atext = a.to_string();
            let b = (200 - a).to_string();
            f.ok(&[
                "--config",
                "config.json",
                "--ticks",
                &atext,
                "--out",
                "first.json",
                "--save",
                "state.bin",
                "--seed",
                seed,
            ]);
            let before = fs::read(f.0.join("state.bin")).unwrap();
            let zero = f.ok(&[
                "--load",
                "state.bin",
                "--ticks",
                "0",
                "--out",
                "zero.json",
                "--save",
                "state.bin",
            ]);
            assert_eq!(zero["series"].as_array().unwrap().len(), 1);
            assert_eq!(before, fs::read(f.0.join("state.bin")).unwrap());
            let resumed = f.ok(&[
                "--load",
                "state.bin",
                "--ticks",
                &b,
                "--out",
                "resumed.json",
                "--save",
                "state.bin",
                "--sample-every",
                "13",
            ]);
            for key in ["state_hash", "final", "totals", "seed"] {
                assert_eq!(resumed[key], direct[key], "split {a} {key}");
            }
            assert_eq!(resumed["tick_start"], a);
            assert_eq!(resumed["tick_end"], 200);
            let mut expected: Vec<u64> = (a..=200).step_by(13).collect();
            if *expected.last().unwrap() != 200 {
                expected.push(200);
            }
            assert_eq!(
                resumed["series"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .map(|v| v["tick"].as_u64().unwrap())
                    .collect::<Vec<_>>(),
                expected
            );
            for row in resumed["series"].as_array().unwrap() {
                assert_eq!(
                    row,
                    &direct["series"][row["tick"].as_u64().unwrap() as usize]
                );
            }
            let chained = f.ok(&["--load", "state.bin", "--ticks", "0", "--out", "chain.json"]);
            assert_eq!(chained["state_hash"], direct["state_hash"]);
        }
    }
}
#[test]
fn invalid_files_options_and_paths_preserve_outputs() {
    let f = Fixture::new("errors");
    f.ok(&[
        "--config",
        "config.json",
        "--ticks",
        "7",
        "--out",
        "first.json",
        "--save",
        "good.bin",
    ]);
    let good = fs::read(f.0.join("good.bin")).unwrap();
    let mut wrong = good.clone();
    wrong[17] = 2;
    fs::write(f.0.join("wrong.bin"), wrong).unwrap();
    fs::write(f.0.join("truncated.bin"), &good[..good.len() - 1]).unwrap();
    let mut damaged = good.clone();
    damaged[100] ^= 1;
    fs::write(f.0.join("damaged.bin"), damaged).unwrap();
    fs::write(f.0.join("empty.bin"), []).unwrap();
    fs::create_dir(f.0.join("directory")).unwrap();
    #[cfg(unix)]
    {
        std::os::unix::fs::symlink("good.bin", f.0.join("symlink")).unwrap();
        assert!(
            Command::new("mkfifo")
                .arg(f.0.join("fifo"))
                .status()
                .unwrap()
                .success()
        );
    }
    for path in [
        "missing.bin",
        "wrong.bin",
        "truncated.bin",
        "damaged.bin",
        "empty.bin",
        "directory",
        "symlink",
        "fifo",
    ] {
        for existing in [false, true] {
            let out = f.0.join("result.json");
            let _ = fs::remove_file(&out);
            if existing {
                fs::write(&out, b"sentinel").unwrap();
            }
            f.bad(&["--load", path, "--ticks", "1", "--out", "result.json"]);
            if existing {
                assert_eq!(fs::read(out).unwrap(), b"sentinel");
            } else {
                assert!(!out.exists());
            }
        }
    }
    fs::hard_link(f.0.join("config.json"), f.0.join("config-link")).unwrap();
    for extra in [
        vec!["--save", "config.json"],
        vec!["--save", "config-link"],
        vec!["--save", "./result.json"],
        vec!["--save", "directory"],
        vec!["--save", "symlink"],
        vec!["--save", "fifo"],
        vec!["--save", "missing-parent/file"],
        vec!["--load", "good.bin"],
        vec!["--save", "a", "--save", "b"],
    ] {
        let mut args = vec![
            "--config",
            "config.json",
            "--ticks",
            "1",
            "--out",
            "result.json",
        ];
        args.extend(extra);
        f.bad(&args);
        assert_eq!(fs::read(f.0.join("result.json")).unwrap(), b"sentinel");
    }
    f.bad(&[
        "--load",
        "good.bin",
        "--seed",
        "1",
        "--ticks",
        "1",
        "--out",
        "result.json",
    ]);
    f.bad(&[
        "--load",
        "good.bin",
        "--ticks",
        "18446744073709551615",
        "--out",
        "result.json",
        "--save",
        "good.bin",
    ]);
    f.bad(&["--load", "good.bin", "--ticks", "0", "--out", "./good.bin"]);
    fs::hard_link(f.0.join("good.bin"), f.0.join("hard-link")).unwrap();
    f.bad(&["--load", "good.bin", "--ticks", "0", "--out", "hard-link"]);
    assert_eq!(good, fs::read(f.0.join("good.bin")).unwrap());
    assert!(
        !fs::read_dir(&f.0).unwrap().any(|e| e
            .unwrap()
            .file_name()
            .to_string_lossy()
            .contains(".tmp"))
    );
}

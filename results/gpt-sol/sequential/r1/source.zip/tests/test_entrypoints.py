"""Real entry points and runtime-free packaging, using only Python stdlib."""
import csv
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import tomllib
import unittest

ROOT = Path(__file__).resolve().parents[1]


def run(args, cwd, timeout=120):
    env = os.environ.copy()
    env.pop('DISPLAY', None)
    env.pop('WAYLAND_DISPLAY', None)
    return subprocess.run([str(arg) for arg in args], cwd=cwd, env=env,
                          capture_output=True, text=True, timeout=timeout)


class Entrypoints(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='bootstrap spaced ', dir=ROOT / 'target')
        cls.addClassCleanup(cls.temp.cleanup)
        cls.cwd = Path(cls.temp.name)
        # Setup and build must resolve their own root from an unrelated cwd.
        for script in ('setup.sh', 'setup.sh', 'build.sh'):
            result = run([ROOT / script], cls.cwd, timeout=240)
            if result.returncode != 0:
                raise AssertionError(f'{script}: {result.returncode}\n{result.stdout}\n{result.stderr}')
        cls.binaries = [ROOT / 'evosim', ROOT / 'dist/evosim']

    def test_executable_files(self):
        for name in ('setup.sh', 'evosim', 'build.sh', 'test.sh', 'dist/evosim'):
            self.assertTrue(os.access(ROOT / name, os.X_OK), name)

    def test_version_json(self):
        version = tomllib.loads((ROOT / 'Cargo.toml').read_text())['package']['version']
        for binary in self.binaries:
            with self.subTest(binary=binary):
                result = run([binary, 'version'], self.cwd)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stderr, '')
                self.assertEqual(len(result.stdout.splitlines()), 1)
                data = json.loads(result.stdout)
                self.assertEqual(data, {'name': 'Evolution Simulation', 'version': version, 'contract': 1})
                self.assertIs(type(data['contract']), int)

    def test_help_and_invalid_arguments(self):
        for binary in self.binaries:
            for flag in ('--help', '-h'):
                result = run([binary, flag], self.cwd)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, '')
                self.assertIn('version', result.stdout)
                self.assertIn('--help', result.stdout)
            for args in ([], ['unknown'], ['--unknown'], ['version', 'extra'], ['--help', 'extra'], ['run'], ['batch'], ['ui', '--unknown'], ['ui', '--config'], ['ui', '--smoke-test', '--smoke-test']):
                with self.subTest(binary=binary, args=args):
                    result = run([binary, *args], self.cwd)
                    self.assertEqual(result.returncode, 2)
                    self.assertEqual(result.stdout, '')
                    self.assertTrue(result.stderr.strip())

    def test_static_elf(self):
        binary = ROOT / 'dist/evosim'
        for flag, forbidden in (('-lW', 'INTERP'), ('-dW', 'NEEDED')):
            result = run(['readelf', flag, binary], self.cwd)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertNotIn(forbidden, result.stdout)

    @unittest.skipUnless(os.geteuid() == 0, 'empty-root execution requires root; ELF check still runs')
    def test_copied_distribution_in_empty_root(self):
        isolated = self.cwd / 'isolated root'
        isolated.mkdir()
        shutil.copy2(ROOT / 'dist/evosim', isolated / 'evosim')
        result = run(['chroot', isolated, '/evosim', 'version'], self.cwd)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['contract'], 1)
        self.assertEqual(result.stderr, '')
        self.assertEqual(list(isolated.iterdir()), [isolated / 'evosim'])
        config = {'seed': 42, 'world': {'width': 3, 'height': 2},
                  'initial': {'plants': 2, 'herbivores': 1, 'carnivores': 1}}
        (isolated / 'config.json').write_text(json.dumps(config))
        for ticks in (0, 10):
            result = run(['chroot', isolated, '/evosim', 'run', '--config', '/config.json',
                          '--ticks', ticks, '--out', '/result.json'], self.cwd)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, '')
            self.assertEqual(result.stderr, '')
            data = json.loads((isolated / 'result.json').read_text())
            self.assertEqual(data['tick_end'], ticks)
            self.assertEqual(len(data['state_hash']), 64)
            self.assertEqual(data['metrics_schema'], 1)
            sample = data['series'][0]
            self.assertEqual(set(sample), {'tick', 'plants', 'herbivores', 'carnivores', 'analytics'})
            for kind in config['initial']:
                metrics = sample['analytics'][kind]
                self.assertEqual(set(metrics), {'births', 'deaths', 'deaths_by_cause', 'species', 'traits', 'generation'})
                self.assertEqual(metrics['births'], 0)
                self.assertEqual(metrics['deaths'], 0)
                self.assertEqual(set(metrics['deaths_by_cause']), {'starvation', 'injury', 'predation', 'old_age', 'climate'})
                self.assertEqual(len(metrics['traits']), 12)
                self.assertEqual(metrics['generation'], {'highest': 0, 'mean': 0.0})
                for trait in metrics['traits'].values():
                    self.assertEqual(set(trait), {'mean', 'standard_deviation', 'min', 'max'})
                    self.assertEqual(trait['standard_deviation'], 0.0)
            for kind, initial in config['initial'].items():
                self.assertEqual(initial + data['totals']['births'][kind] -
                                 data['totals']['deaths'][kind], data['final'][kind])

        self.checkpoint_splits(['chroot', isolated, '/evosim'], isolated, '/config.json')

        result = run(['chroot', isolated, '/evosim', 'batch', '--config', '/config.json',
                      '--seeds', '1,2', '--ticks', '3', '--out-dir', '/batch',
                      '--sweep', 'initial.plants=[0,2]'], self.cwd)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual((result.stdout, result.stderr), ('', ''))
        summary = json.loads((isolated / 'batch/summary.json').read_text())
        self.assertEqual(summary['run_count'], 4)
        self.assertEqual(len(list(csv.DictReader(io.StringIO((isolated / 'batch/summary.csv').read_text())))), 15)

    def checkpoint_splits(self, prefix, folder, config):
        def invoke(args):
            result = run([*prefix, 'run', *args], self.cwd)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual((result.stdout, result.stderr), ('', ''))
        invoke(['--config', config, '--ticks', 30, '--out', '/direct.json' if len(prefix)>1 else folder / 'direct.json'])
        direct = json.loads((folder / 'direct.json').read_text())
        for split in (0, 7, 13):
            def path(name):
                return '/' + name if len(prefix)>1 else folder / name
            invoke(['--config', config, '--ticks', split, '--out', path('first.json'), '--save', path('save game.bin')])
            invoke(['--load', path('save game.bin'), '--ticks', 30-split, '--out', path('resumed.json'), '--save', path('save game.bin')])
            resumed = json.loads((folder / 'resumed.json').read_text())
            self.assertEqual((resumed['tick_start'], resumed['tick_end']), (split, 30))
            for key in ('state_hash', 'final', 'totals'):
                self.assertEqual(direct[key], resumed[key])

    def test_checkpoint_real_launchers(self):
        config = self.cwd / 'checkpoint config.json'
        config.write_text(json.dumps({'seed': 42, 'world': {'width': 8, 'height': 6},
                                     'initial': {'plants': 20, 'herbivores': 8, 'carnivores': 2}}))
        for binary in self.binaries:
            self.checkpoint_splits([binary], self.cwd, config)

    def test_batch_matrix_csv_replay_and_standalone(self):
        config = self.cwd / 'batch config.json'
        config.write_text(json.dumps({'seed': 42, 'world': {'width': 3, 'height': 2},
                                     'initial': {'plants': 2, 'herbivores': 1, 'carnivores': 0}}))
        kinds = ('plants', 'herbivores', 'carnivores')
        header = ('row_type,run_id,variant_index,result_file,seed,parameters,tick_start,tick_end,'
                  'state_hash,kind,final_population,extinct,mean,min,max,extinction_count,'
                  'extinction_fraction,run_count').split(',')
        for bi, binary in enumerate(self.binaries):
            for sweep, ticks in ((None, 17), ('plants.resource_regeneration=[1,2]', 17),
                                 ('initial.plants=[0,4]', 0)):
                seeds = [-7, 11] if sweep else [-7, 0, 1, 18446744073709551617]
                outputs = []
                for repeat in (0, 1, 0):
                    folder = self.cwd / f'batch {bi} {sweep is not None} {ticks} {repeat}'
                    args = [binary, 'batch', '--config', config, '--seeds',
                            ','.join(map(str, seeds)), '--ticks', ticks, '--out-dir', folder]
                    if sweep:
                        args += ['--sweep', sweep]
                    result = run(args, self.cwd)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertEqual((result.stdout, result.stderr), ('', ''))
                    summary_bytes = (folder / 'summary.json').read_bytes()
                    csv_bytes = (folder / 'summary.csv').read_bytes()
                    outputs.append((summary_bytes, csv_bytes))
                    summary = json.loads(summary_bytes)
                    self.assertEqual(summary['batch_schema'], 1)
                    self.assertEqual(summary['contract'], 1)
                    runs = summary['runs']
                    self.assertEqual(summary['run_count'], len(seeds) * (2 if sweep else 1))
                    reader = csv.DictReader(io.StringIO(csv_bytes.decode(), newline=''))
                    self.assertEqual(reader.fieldnames, header)
                    rows = list(reader)
                    self.assertEqual(len(rows), 3*len(runs)+3)
                    self.assertEqual(csv_bytes.count(b'\r\n'), len(rows)+1)
                    files = {'summary.json', 'summary.csv'}
                    for i, record in enumerate(runs):
                        self.assertEqual(record['run_id'], i)
                        self.assertEqual(record['variant_index'], i//len(seeds))
                        self.assertEqual(record['seed'], seeds[i % len(seeds)])
                        self.assertEqual((record['tick_start'], record['tick_end']), (0, ticks))
                        self.assertNotIn('seed', record['parameters'])
                        self.assertEqual(set(record['parameters']), {'world', 'initial', 'climate', 'genetics', 'plants', 'animals'})
                        if sweep:
                            group, leaf = sweep.split('=')[0].split('.')
                            values = json.loads(sweep.split('=')[1])
                            self.assertEqual(record['parameters'][group][leaf], values[i//len(seeds)])
                        files.add(record['result_file'])
                        actual = json.loads((folder / record['result_file']).read_text())
                        self.assertEqual(actual['final'], record['final'])
                        self.assertEqual(actual['state_hash'], record['state_hash'])
                        effective = dict(record['parameters'], seed=record['seed'])
                        oracle_config = self.cwd / 'batch oracle.json'
                        oracle_config.write_text(json.dumps(effective))
                        oracle_path = self.cwd / 'batch oracle result.json'
                        result = run([binary, 'run', '--config', oracle_config, '--ticks', ticks,
                                      '--out', oracle_path], self.cwd)
                        self.assertEqual(result.returncode, 0, result.stderr)
                        expected = json.loads(oracle_path.read_text())
                        for value in (actual, expected):
                            for key in ('elapsed_seconds', 'ticks_per_second'):
                                value.pop(key)
                        self.assertEqual(actual, expected)
                        for j, kind in enumerate(kinds):
                            row = rows[3*i+j]
                            self.assertEqual(row['row_type'], 'run')
                            self.assertEqual(int(row['seed']), record['seed'])
                            self.assertEqual(int(row['run_id']), i)
                            self.assertEqual(int(row['variant_index']), record['variant_index'])
                            self.assertEqual(row['result_file'], record['result_file'])
                            self.assertEqual(json.loads(row['parameters']), record['parameters'])
                            self.assertEqual(int(row['tick_start']), 0)
                            self.assertEqual(int(row['tick_end']), ticks)
                            self.assertEqual(row['state_hash'], record['state_hash'])
                            self.assertEqual(row['kind'], kind)
                            self.assertEqual(int(row['final_population']), record['final'][kind])
                            self.assertEqual(json.loads(row['extinct']), record['extinct'][kind])
                            self.assertEqual(record['extinct'][kind], record['final'][kind] == 0)
                            self.assertTrue(all(row[k] == '' for k in ('mean', 'min', 'max', 'extinction_count', 'extinction_fraction')))
                            self.assertEqual(int(row['run_count']), len(runs))
                    self.assertEqual({str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()}, files)
                    for j, kind in enumerate(kinds):
                        values = [r['final'][kind] for r in runs]
                        expected = dict(mean=sum(values)/len(values), min=min(values), max=max(values),
                                        extinction_count=values.count(0), extinction_fraction=values.count(0)/len(values))
                        self.assertEqual(summary['aggregates'][kind], expected)
                        row = rows[3*len(runs)+j]
                        self.assertEqual(row['row_type'], 'aggregate')
                        self.assertEqual(row['kind'], kind)
                        for key in expected:
                            self.assertEqual(json.loads(row[key]), expected[key])
                        self.assertEqual(int(row['run_count']), len(runs))
                        self.assertTrue(all(row[k] == '' for k in header[1:9]+['final_population', 'extinct']))
                self.assertEqual(outputs[0], outputs[1])
                self.assertEqual(outputs[0], outputs[2])
                if not sweep:
                    hashes = [r['state_hash'] for r in summary['runs']]
                    self.assertEqual(len(set(hashes)), len(hashes))
                if sweep == 'initial.plants=[0,4]':
                    self.assertEqual(summary['aggregates']['plants'], dict(mean=2.0, min=0, max=4,
                                                                         extinction_count=2, extinction_fraction=0.5))

    def test_git_ignores_build_outputs(self):
        result = run(['git', '-C', ROOT, 'check-ignore', 'target/probe', 'dist/evosim', 'tests/__pycache__/probe.pyc'], self.cwd)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(result.stdout.splitlines()), 3)
        result = run(['git', '-C', ROOT, 'check-ignore', 'Cargo.lock'], self.cwd)
        self.assertEqual(result.returncode, 1)

    def test_climate_export(self):
        config = self.cwd / 'climate config.json'
        config.write_text(json.dumps({'seed': 42, 'world': {'width': 3, 'height': 5},
                                     'initial': {'plants': 0, 'herbivores': 0, 'carnivores': 0}}))
        maps = []
        for index, binary in enumerate(self.binaries):
            path = self.cwd / f'climate map {index}.json'
            result = run([binary, 'climate', '--config', config, '--out', path], self.cwd)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, '')
            self.assertEqual(result.stderr, '')
            data = json.loads(path.read_text())
            self.assertEqual((data['climate_model'], data['width'], data['height']), (1, 3, 5))
            self.assertEqual(data['temperature_units'], 'normalized')
            self.assertEqual(data['precipitation_units'], 'normalized')
            self.assertEqual(len(data['cells']), 15)
            for i, cell in enumerate(data['cells']):
                self.assertEqual((cell['x'], cell['y']), (i % 3, i // 3))
                self.assertIn(cell['biome'], ('polar', 'tundra', 'temperate', 'dry', 'tropical'))
                for key in ('base_temperature', 'base_precipitation'):
                    self.assertTrue(0 <= cell[key] <= 1)
            maps.append(data)
        # Separate libm builds can differ slightly; schema and biome labels must agree.
        for a, b in zip(maps[0]['cells'], maps[1]['cells']):
            self.assertEqual(a['biome'], b['biome'])
            self.assertAlmostEqual(a['base_temperature'], b['base_temperature'], places=14)
            self.assertAlmostEqual(a['base_precipitation'], b['base_precipitation'], places=14)

    def test_real_run_replay_headless_and_spaced_paths(self):
        config = self.cwd / 'run config.json'
        config.write_text(json.dumps({'seed': 42, 'world': {'width': 8, 'height': 6},
                                     'initial': {'plants': 8, 'herbivores': 4, 'carnivores': 2}}))
        for binary in self.binaries:
            results = []
            for index in range(2):
                destination = self.cwd / f'run result {index}.json'
                output = run([binary, 'run', '--config', config, '--ticks', 250,
                              '--out', destination, '--seed', -7, '--sample-every', 3], self.cwd)
                self.assertEqual(output.returncode, 0, output.stderr)
                self.assertEqual(output.stdout, '')
                self.assertEqual(output.stderr, '')
                data = json.loads(destination.read_text())
                self.assertEqual(data['seed'], -7)
                self.assertEqual(data['tick_end'], 250)
                self.assertEqual([s['tick'] for s in data['series']], list(range(0, 251, 3)) + [250])
                for key in ('elapsed_seconds', 'ticks_per_second'):
                    self.assertGreaterEqual(data.pop(key), 0)
                results.append(data)
            self.assertEqual(*results)

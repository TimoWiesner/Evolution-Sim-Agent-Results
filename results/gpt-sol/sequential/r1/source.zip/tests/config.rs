use evosim::config::{Config, Seed};
use serde_json::{Value, json};
fn minimal() -> Value {
    json!({"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}})
}
fn parse(v: &Value) -> Config {
    Config::from_json(&v.to_string()).unwrap()
}
fn error(v: &Value, path: &str) {
    let e = Config::from_json(&v.to_string()).unwrap_err();
    assert_eq!(e.path(), path, "{v}: {e}");
    assert!(e.to_string().contains(path));
    assert!(!e.message().is_empty());
}
fn effective() -> Value {
    serde_json::from_str(&Config::default().to_json().unwrap()).unwrap()
}
fn set(v: &mut Value, path: &str, value: Value) {
    let mut parts = path.split('.');
    let a = parts.next().unwrap();
    if let Some(b) = parts.next() {
        v[a][b] = value
    } else {
        v[a] = value
    }
}
#[test]
fn fixed_keys_defaults_and_zero_populations() {
    assert_eq!(parse(&minimal()), Config::default());
    let mut documented = minimal();
    documented["climate"] = json!({"year_ticks":1000,"season_temperature_amplitude":0.15,"season_precipitation_amplitude":0.10,"weather_amplitude":0.05});
    documented["genetics"] = json!({"mutation_per_million":10000,"mutation_max_step":1024});
    documented["plants"] = json!({"resource_capacity":100,"resource_regeneration":2,"growth_efficiency":0.5,"reproduction_energy":20,"dispersal_radius":3});
    documented["animals"] = json!({"movement_cost":0.2,"basal_cost":0.1,"reproduction_energy":30,"reproduction_cooldown":100});
    assert_eq!(parse(&documented), parse(&minimal()));

    for group in ["climate", "genetics", "plants", "animals"] {
        let mut v = minimal();
        v[group] = json!({});
        assert_eq!(parse(&v), Config::default());
    }
    for kind in ["plants", "herbivores", "carnivores"] {
        let mut v = minimal();
        v["initial"][kind] = json!(0);
        parse(&v);
    }
    let mut v = minimal();
    v["world"] = json!({"width":1,"height":1});
    parse(&v);
    v["initial"] = json!({"plants":0,"herbivores":0,"carnivores":0});
    parse(&v);
    assert_eq!(Config::default().climate().year_ticks(), 1000);
    assert_eq!(Config::default().genetics().mutation_per_million(), 10000);
    assert_eq!(Config::default().plants().resource_capacity(), 100.);
    assert_eq!(Config::default().animals().basal_cost(), 0.1);
}
#[test]
fn missing_fixed_keys() {
    for key in ["seed", "world", "initial"] {
        let mut v = minimal();
        v.as_object_mut().unwrap().remove(key);
        error(&v, key);
    }
    for (g, keys) in [
        ("world", vec!["width", "height"]),
        ("initial", vec!["plants", "herbivores", "carnivores"]),
    ] {
        for k in keys {
            let mut v = minimal();
            v[g].as_object_mut().unwrap().remove(k);
            error(&v, &format!("{g}.{k}"));
        }
    }
}
#[test]
fn all_fields_wrong_types_and_optional_defaults() {
    let base = effective();
    for (g, group) in base.as_object().unwrap() {
        if let Some(fields) = group.as_object() {
            for (k, default) in fields {
                let path = format!("{g}.{k}");
                for bad in [Value::Null, json!({}), json!([]), json!("1"), json!(true)] {
                    let mut v = base.clone();
                    set(&mut v, &path, bad);
                    error(&v, &path);
                }
                if default
                    .as_number()
                    .unwrap()
                    .to_string()
                    .bytes()
                    .all(|b| b.is_ascii_digit())
                {
                    for bad in [json!(1.5), serde_json::from_str("1e0").unwrap()] {
                        let mut v = base.clone();
                        set(&mut v, &path, bad);
                        error(&v, &path);
                    }
                }
                if !["world", "initial"].contains(&g.as_str()) {
                    let mut v = base.clone();
                    v[g].as_object_mut().unwrap().remove(k);
                    assert_eq!(parse(&v), Config::default());
                }
            }
            for bad in [Value::Null, json!([]), json!(1), json!("x"), json!(false)] {
                let mut v = base.clone();
                v[g] = bad;
                error(&v, g);
            }
        }
    }
    for bad in [
        Value::Null,
        json!({}),
        json!([]),
        json!("42"),
        json!(true),
        json!(1.1),
        serde_json::from_str("1e0").unwrap(),
    ] {
        let mut v = minimal();
        v["seed"] = bad;
        error(&v, "seed");
    }
}
#[test]
fn boundaries_and_overflow() {
    let rows = [
        (
            "world.width",
            "1",
            "18446744073709551615",
            "0",
            "18446744073709551616",
        ),
        (
            "world.height",
            "1",
            "18446744073709551615",
            "-1",
            "18446744073709551616",
        ),
        (
            "initial.plants",
            "0",
            "18446744073709551614",
            "-1",
            "18446744073709551616",
        ),
        (
            "initial.herbivores",
            "0",
            "18446744073709551614",
            "-1",
            "18446744073709551616",
        ),
        (
            "initial.carnivores",
            "0",
            "18446744073709551614",
            "-1",
            "18446744073709551616",
        ),
        (
            "climate.year_ticks",
            "1",
            "18446744073709551615",
            "0",
            "18446744073709551616",
        ),
        (
            "genetics.mutation_per_million",
            "0",
            "1000000",
            "-1",
            "1000001",
        ),
        ("genetics.mutation_max_step", "1", "65535", "0", "65536"),
        (
            "plants.dispersal_radius",
            "0",
            "4294967295",
            "-1",
            "4294967296",
        ),
        (
            "animals.reproduction_cooldown",
            "1",
            "18446744073709551615",
            "0",
            "18446744073709551616",
        ),
    ];
    for (path, lo, hi, badlo, badhi) in rows {
        let mut base = effective();
        base["world"] = json!({"width":1,"height":1});
        base["initial"] = json!({"plants":0,"herbivores":0,"carnivores":0});
        for n in [lo, hi] {
            let mut v = base.clone();
            set(&mut v, path, serde_json::from_str(n).unwrap());
            parse(&v);
        }
        for n in [badlo, badhi] {
            let mut v = base.clone();
            set(&mut v, path, serde_json::from_str(n).unwrap());
            error(&v, path);
        }
    }
    for (path, max, positive) in [
        ("climate.season_temperature_amplitude", 1., false),
        ("climate.season_precipitation_amplitude", 1., false),
        ("climate.weather_amplitude", 1., false),
        ("plants.resource_capacity", 1e6, true),
        ("plants.resource_regeneration", 1e6, false),
        ("plants.growth_efficiency", 1., false),
        ("plants.reproduction_energy", 1e6, true),
        ("animals.movement_cost", 1e6, false),
        ("animals.basal_cost", 1e6, true),
        ("animals.reproduction_energy", 1e6, true),
    ] {
        for good in [if positive { f64::from_bits(1) } else { 0. }, max] {
            let mut v = effective();
            set(&mut v, path, json!(good));
            let c = parse(&v);
            assert_eq!(c, Config::from_json(&c.to_json().unwrap()).unwrap());
        }
        for bad in [
            json!(-0.1),
            json!(max + 1.),
            serde_json::from_str("1e400").unwrap(),
        ] {
            let mut v = effective();
            set(&mut v, path, bad);
            error(&v, path);
        }
        if positive {
            let mut v = effective();
            set(&mut v, path, json!(0));
            error(&v, path);
        }
    }
    let mut v = minimal();
    v["world"] = json!({"width":usize::MAX,"height":2});
    error(&v, "world.width/world.height");
    v = minimal();
    v["initial"]["plants"] = json!(usize::MAX);
    error(&v, "initial");
    v["initial"] = json!({"plants":u64::MAX,"herbivores":0,"carnivores":0});
    error(&v, "initial");
}
#[test]
fn syntax_unknown_and_duplicates() {
    for s in ["", "{", "[]", "null", "{} {}", "{\"seed\":NaN}"] {
        assert_eq!(Config::from_json(s).unwrap_err().path(), "$");
    }
    let mut v = minimal();
    v["typo"] = json!(1);
    error(&v, "typo");
    for g in [
        "world", "initial", "climate", "genetics", "plants", "animals",
    ] {
        let mut v = effective();
        v[g]["typo"] = json!(1);
        error(&v, &format!("{g}.typo"));
    }
    let s = minimal()
        .to_string()
        .replacen("\"seed\":42", "\"seed\":0,\"seed\":42", 1);
    assert_eq!(Config::from_json(&s).unwrap(), Config::default());
}
#[test]
fn seed_precision_and_modulo() {
    for (s, normalized, modulo) in [
        ("-0", "0", 0),
        ("0", "0", 0),
        ("-1", "-1", u64::MAX),
        (
            "9223372036854775807",
            "9223372036854775807",
            i64::MAX as u64,
        ),
        ("-9223372036854775808", "-9223372036854775808", 1 << 63),
        ("18446744073709551615", "18446744073709551615", u64::MAX),
        ("18446744073709551616", "18446744073709551616", 0),
        ("-18446744073709551617", "-18446744073709551617", u64::MAX),
        (
            "340282366920938463463374607431768211457",
            "340282366920938463463374607431768211457",
            1,
        ),
    ] {
        let input = minimal()
            .to_string()
            .replace("\"seed\":42", &format!("\"seed\":{s}"));
        let c = Config::from_json(&input).unwrap();
        assert_eq!(c.seed().as_decimal(), normalized);
        assert_eq!(c.seed().wrapping_u64(), modulo);
        let out = c.to_json().unwrap();
        assert!(out.contains(&format!("\"seed\": {normalized}")));
        assert_eq!(c, Config::from_json(&out).unwrap());
    }
    assert_eq!(Seed::from_i64(-1).wrapping_u64(), u64::MAX);
    assert_eq!(
        Seed::from_u64(u64::MAX).as_decimal(),
        "18446744073709551615"
    );
}
#[test]
fn presets_and_custom_roundtrip() {
    let presets: Vec<_> = Config::preset_names()
        .iter()
        .map(|name| {
            let c = Config::preset(name).unwrap();
            assert_eq!(c, Config::from_json(&c.to_json().unwrap()).unwrap());
            c
        })
        .collect();
    assert_eq!(presets.len(), 3);
    for i in 0..3 {
        for j in i + 1..3 {
            assert_ne!(presets[i], presets[j]);
        }
    }
    assert_eq!(presets[1].climate().year_ticks(), 240);
    assert_eq!(presets[1].climate().season_temperature_amplitude(), 0.3);
    assert_eq!(presets[1].climate().weather_amplitude(), 0.1);
    assert_eq!(presets[2].world().width(), 32);
    assert_eq!(presets[2].world().height(), 24);
    assert_eq!(presets[2].initial().plants(), 200);
    assert_eq!(presets[2].initial().herbivores(), 0);
    assert_eq!(presets[2].initial().carnivores(), 0);
    assert_eq!(presets[2].genetics().mutation_per_million(), 50000);
    assert_eq!(presets[2].plants().dispersal_radius(), 5);
    for name in ["", "Baseline", "missing"] {
        assert_eq!(Config::preset(name).unwrap_err().path(), "preset");
    }
    let mut v = effective();
    for (g, group) in v.as_object_mut().unwrap() {
        if let Some(fields) = group.as_object_mut() {
            for (k, value) in fields {
                if g == "world" || g == "initial" {
                    *value = json!(7);
                } else if value.as_number().unwrap().to_string().contains('.') {
                    *value = json!(0.12345678901234568);
                } else {
                    *value = json!(2);
                }
                assert!(!k.is_empty());
            }
        }
    }
    let c = parse(&v);
    assert_eq!(c, Config::from_json(&c.to_json().unwrap()).unwrap());
}
#[test]
fn file_operations() {
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("target")
        .join(format!("config-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let p = dir.join("config.json");
    let c = Config::preset("seasonal").unwrap();
    c.save(&p).unwrap();
    assert_eq!(c, Config::load(&p).unwrap());
    assert!(
        Config::load(dir.join("missing"))
            .unwrap_err()
            .message()
            .contains("No such file")
    );
    assert!(c.save(&dir).unwrap_err().path().contains("config-test-"));
    std::fs::write(&p, "{").unwrap();
    assert_eq!(Config::load(&p).unwrap_err().path(), "$");
    std::fs::remove_dir_all(dir).unwrap();
}

use evosim::{
    config::Config,
    organism::{DeathCause, Kind},
    simulation::Simulation,
};

fn simulation(seed: u64, plants: usize, basal: f64) -> Simulation {
    Simulation::new(Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":1,"height":1}},"initial":{{"plants":{plants},"herbivores":1,"carnivores":0}},"animals":{{"movement_cost":0,"basal_cost":{basal}}},"plants":{{"reproduction_energy":1001}},"climate":{{"weather_amplitude":0}}}}"#)).unwrap()).unwrap()
}
#[test]
fn every_tick_positive_current_temperature_upkeep_and_absorbing_starvation() {
    for basal in [f64::from_bits(1), 0.1, 10., 1_000_000.] {
        let mut s = simulation(42, 0, basal);
        let a = s.population().iter().next().unwrap().id();
        let mut dead = false;
        let mut lost = false;
        for _ in 0..2200 {
            let before = s.population().get(a).cloned();
            s.advance_one_tick().unwrap();
            if let Some(old) = before {
                let t = old.traits();
                let temperature = s.world().current_climate_at(old.position()).temperature();
                let stress =
                    ((temperature - t.preferred_temperature()).abs() / t.climate_tolerance() - 1.)
                        .clamp(0., 1.);
                let expected =
                    old.energy() - basal.max(1e-9) * t.metabolic_multiplier() * (1. + stress);
                if let Some(after) = s.population().get(a) {
                    assert!(after.energy() < old.energy());
                    lost = true;
                    assert!((after.energy() - expected).abs() < 1e-10);
                } else {
                    dead = true;
                }
            } else {
                assert_eq!(s.population().counts().get(Kind::Herbivore), 0);
            }
            assert_eq!(s.population().totals().births.get(Kind::Herbivore), 0);
        }
        assert!(dead);
        if basal < 1_000_000. {
            assert!(lost);
        }
        if basal >= 10. {
            assert_eq!(
                s.population()
                    .deaths_by_cause(Kind::Herbivore, DeathCause::Starvation),
                1
            );
        }
    }
}

#[test]
fn adjacent_food_supplies_energy_with_real_tick_replay_and_no_animal_births() {
    for seed in [0, 1, 42, u64::MAX] {
        let mut fed = simulation(seed, 1, 0.1);
        let mut replay = fed.clone();
        let mut bare = simulation(seed, 0, 0.1);
        let a = fed
            .population()
            .iter()
            .find(|o| o.kind() == Kind::Herbivore)
            .unwrap()
            .id();
        fed.advance_one_tick().unwrap();
        replay.advance_one_tick().unwrap();
        bare.advance_one_tick().unwrap();
        assert_eq!(fed, replay);
        let unprovided = bare.population().iter().next().unwrap().energy();
        assert!(fed.population().get(a).unwrap().energy() > unprovided);
        for _ in 1..2200 {
            fed.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
            assert_eq!(fed, replay);
            for kind in Kind::ALL {
                let t = fed.population().totals();
                assert_eq!(
                    t.initial.get(kind) + t.births.get(kind) - t.deaths.get(kind),
                    fed.population().counts().get(kind)
                );
                let causes: u128 = DeathCause::ALL
                    .iter()
                    .map(|cause| fed.population().deaths_by_cause(kind, *cause))
                    .sum();
                assert_eq!(causes, t.deaths.get(kind));
            }
            assert_eq!(fed.population().totals().births.get(Kind::Herbivore), 0);
        }
    }
}

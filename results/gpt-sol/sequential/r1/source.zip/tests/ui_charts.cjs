'use strict';
const assert=require('node:assert/strict'),C=require('../ui/charts.js');
const points=['9007199254740993','9007199254740994','9007199254740995'].map((tick,i)=>({tick,kinds:[0,1,2].map(k=>({population:String(i+k),births:String(i*2),deaths:String(i),species:String(k),means:Array(12).fill(k===2?null:i)}))}));
for(const type of ['population','events','species','means']){const lines=C.lines(points,type),g=C.geometry(lines);assert.equal(lines.length,type==='events'?6:3);assert.equal(g.series[0].values[1].x,.5);assert.equal(g.first,points[0].tick);assert.equal(g.last,points[2].tick);for(const s of g.series)for(const v of s.values){assert(Number.isFinite(v.x));assert(v.y===null||Number.isFinite(v.y));}}
assert.equal(C.lines(points,'events').filter(s=>s.dashed).length,3);assert.equal(C.geometry(C.lines(points,'means')).series[2].values[0].y,null);
for(const p of [[],[points[0]]])assert.equal(C.geometry(C.lines(p,'population')).max>=1,true);
const histograms=Array.from({length:12},(_,i)=>({name:String(i),edges:Array.from({length:21},(_,j)=>j/20),counts:Array.from({length:3},()=>Array(20).fill('0'))}));assert.equal(C.histogram({tick:'0',histograms},11).max,1);assert.throws(()=>C.histogram({histograms},12));assert.throws(()=>C.lines(points,'means',-1));
console.log('Chart selections, null gaps, histograms and exact relative tick geometry passed');

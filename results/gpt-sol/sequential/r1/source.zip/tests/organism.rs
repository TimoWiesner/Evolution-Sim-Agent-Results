use evosim::organism::{TraitValues, Traits};

#[test]
fn all_trait_endpoints_and_founder_are_validated() {
    let low = TraitValues {
        speed: 1,
        strength: 1.,
        max_health: 10.,
        lifespan: 200,
        fertility: 0.,
        vision: 1,
        metabolic_multiplier: 0.5,
        preferred_temperature: 0.,
        preferred_moisture: 0.,
        climate_tolerance: 0.05,
        aggression: 0.,
        risk_tolerance: 0.,
    };
    let high = TraitValues {
        speed: 4,
        strength: 10.,
        max_health: 100.,
        lifespan: 2000,
        fertility: 1.,
        vision: 8,
        metabolic_multiplier: 2.,
        preferred_temperature: 1.,
        preferred_moisture: 1.,
        climate_tolerance: 0.5,
        aggression: 1.,
        risk_tolerance: 1.,
    };
    for v in [low, high, Traits::founder().values()] {
        let t = Traits::new(v).unwrap();
        assert_eq!(t.values(), v);
        assert_eq!(
            (
                t.speed(),
                t.strength(),
                t.max_health(),
                t.lifespan(),
                t.fertility(),
                t.vision()
            ),
            (
                v.speed,
                v.strength,
                v.max_health,
                v.lifespan,
                v.fertility,
                v.vision
            )
        );
        assert_eq!(
            (
                t.metabolic_multiplier(),
                t.preferred_temperature(),
                t.preferred_moisture(),
                t.climate_tolerance(),
                t.aggression(),
                t.risk_tolerance()
            ),
            (
                v.metabolic_multiplier,
                v.preferred_temperature,
                v.preferred_moisture,
                v.climate_tolerance,
                v.aggression,
                v.risk_tolerance
            )
        );
    }
    let f = Traits::founder();
    assert_eq!(
        (
            f.speed(),
            f.strength(),
            f.max_health(),
            f.lifespan(),
            f.fertility(),
            f.vision()
        ),
        (2, 5.5, 55., 1100, 0.5, 4)
    );
    assert_eq!(
        (
            f.metabolic_multiplier(),
            f.preferred_temperature(),
            f.preferred_moisture(),
            f.climate_tolerance(),
            f.aggression(),
            f.risk_tolerance()
        ),
        (1.25, 0.5, 0.5, 0.275, 0.5, 0.5)
    );
}

#[test]
fn every_trait_rejects_outside_bounds_and_nonfinite_values() {
    macro_rules! invalid {
        ($field:ident, $name:literal, $values:expr) => {
            for value in $values {
                let mut v = Traits::founder().values();
                v.$field = value;
                assert_eq!(Traits::new(v).unwrap_err().0, $name);
            }
        };
    }
    invalid!(speed, "speed", [0, 5, u8::MAX]);
    invalid!(lifespan, "lifespan", [0, 199, 2001, u64::MAX]);
    invalid!(vision, "vision", [0, 9, u8::MAX]);
    macro_rules! float_invalid {
        ($field:ident, $name:literal, $low:expr, $high:expr) => {
            invalid!(
                $field,
                $name,
                [
                    $low - 0.000001,
                    $high + 0.000001,
                    f64::NAN,
                    f64::INFINITY,
                    f64::NEG_INFINITY
                ]
            );
        };
    }
    float_invalid!(strength, "strength", 1., 10.);
    float_invalid!(max_health, "max_health", 10., 100.);
    float_invalid!(fertility, "fertility", 0., 1.);
    float_invalid!(metabolic_multiplier, "metabolic_multiplier", 0.5, 2.);
    float_invalid!(preferred_temperature, "preferred_temperature", 0., 1.);
    float_invalid!(preferred_moisture, "preferred_moisture", 0., 1.);
    float_invalid!(climate_tolerance, "climate_tolerance", 0.05, 0.5);
    float_invalid!(aggression, "aggression", 0., 1.);
    float_invalid!(risk_tolerance, "risk_tolerance", 0., 1.);
}

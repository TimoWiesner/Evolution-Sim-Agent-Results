'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const{open}=require('../ui/automation.cjs');
(async()=>{const dir=process.argv[3],c=await open(process.argv[2]);try{
await c.wait('window.evosim && evosim.renderedTick !== null');
async function click(id){await c.wait(`!document.getElementById(${JSON.stringify(id)}).disabled`);const rev=await c.evaluate('evosim.revision');await c.evaluate(`document.getElementById(${JSON.stringify(id)}).click()`);await c.wait(`evosim.revision!==${JSON.stringify(rev)}`);}
await click('pause');await click('reset');await c.wait('evosim.renderedTick==="0"');
let before=await c.evaluate('evosim.renderedTick');await new Promise(r=>setTimeout(r,200));assert.equal(await c.evaluate('evosim.renderedTick'),before);
await click('step');assert.equal(await c.evaluate('evosim.renderedTick'),'1');await click('reset');
for(const speed of ['slow','normal','fast']){await c.evaluate(`document.querySelector('#speed').value='${speed}';document.querySelector('#speed').dispatchEvent(new Event('change'))`);await c.wait(`evosim.frame.speed==='${speed}'`);}
// Real map gestures: drag never selects, cell click exposes every stacked ID.
const point=await c.evaluate(`(()=>{const r=document.querySelector('canvas').getBoundingClientRect(),p=Camera.worldToScreen(evosim.camera,.5,.5);return {x:r.x+p.x,y:r.y+p.y}})()`);
async function mouse(type,x,y,extra={}){await c.send('Input.dispatchMouseEvent',{type,x,y,button:'left',clickCount:1,...extra},c.session);}
await mouse('mousePressed',point.x,point.y);await mouse('mouseMoved',point.x+20,point.y+10,{buttons:1});await mouse('mouseReleased',point.x+20,point.y+10);assert.equal(await c.evaluate('evosim.frame.selected'),null);await c.evaluate('document.querySelector("#fit").click()');await new Promise(r=>setTimeout(r,60));
async function cell(){await mouse('mousePressed',point.x,point.y);await mouse('mouseReleased',point.x,point.y);await c.wait('document.querySelectorAll("#chooser button").length===10');}
await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x:point.x,y:point.y,deltaX:0,deltaY:300},c.session);await c.wait('evosim.camera.scale<160');
for(const kind of ['Plant','Herbivore','Carnivore']){
 await cell();const rev=await c.evaluate('evosim.revision');await c.evaluate(`[...document.querySelectorAll('#chooser button')].find(b=>b.textContent.startsWith('${kind}')).click()`);await c.wait(`evosim.revision!==${JSON.stringify(rev)} && evosim.frame.selected?.kind==='${kind}'`);
 const s=await c.evaluate('evosim.frame.selected');assert.equal(s.genome.alleles.length,12);assert.equal(Object.keys(s.traits).length,12);assert.deepEqual(s.parents,[]);const text=await c.evaluate('document.querySelector("#inspector").innerText');for(const label of ['ID','Kind','Species','Age','Energy','Health','Parents','None (initial organism)','Expressed traits','Genome','32768'])assert(text.includes(label),text);
}
const selected=await c.evaluate('evosim.frame.selected');await click('step');const current=await c.evaluate('evosim.frame.selected');assert.equal(current.id,selected.id);if(current.status==='living')assert.equal(BigInt(current.age),BigInt(selected.age)+1n);
// Real file download, browser writes the file; CLI validates it in Python.
await c.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:dir});
const savedTick=Number(await c.evaluate('evosim.renderedTick'));
await c.evaluate('document.querySelector("#save").click()');await c.wait('document.querySelector("#feedback").textContent==="Download prepared"');
for(let i=0;i<100&&!fs.existsSync(path.join(dir,`evosim-tick-${savedTick}.evo`));i++)await new Promise(r=>setTimeout(r,30));assert(fs.existsSync(path.join(dir,`evosim-tick-${savedTick}.evo`)));
// Keep selected identity through actual production death, never retarget.
await click('run');await c.wait('evosim.frame.selected.status==="died"',25000);await click('pause');
const dead=await c.evaluate('evosim.frame.selected');assert.equal(dead.id,selected.id);assert(dead.death_tick);assert(dead.death_cause);assert((await c.evaluate('document.querySelector("#inspector").innerText')).includes('Last observed at tick'));
for(const [width,height]of [[1280,720],[1440,900]]){await c.send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:false},c.session);await new Promise(r=>setTimeout(r,100));const visible=await c.evaluate(`(()=>{document.querySelector('#inspector').scrollTop=100000;return ['tick','plants','herbivores','carnivores'].every(id=>{const r=document.getElementById(id).getBoundingClientRect();return r.width>0&&r.height>0&&r.top>=0&&r.bottom<=innerHeight;})})()`);assert(visible);}
await c.send('Emulation.setDeviceMetricsOverride',{width:800,height:720,deviceScaleFactor:1,mobile:false},c.session);await c.evaluate('scrollTo(0,600)');await new Promise(r=>setTimeout(r,150));assert(await c.evaluate(`['mobile-tick','mobile-plants','mobile-herbivores','mobile-carnivores'].every(id=>{const r=document.getElementById(id).getBoundingClientRect();return r.width>0&&r.top>=0&&r.bottom<innerHeight;})`));await c.evaluate('scrollTo(0,0)');await c.send('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false},c.session);await new Promise(r=>setTimeout(r,100));
const screenshot=await c.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},c.session);fs.writeFileSync(path.join(process.cwd(),'target/task024-inspector.png'),Buffer.from(screenshot.data,'base64'));
async function upload(file){const {root}=await c.send('DOM.getDocument',{},c.session);const {nodeId}=await c.send('DOM.querySelector',{nodeId:root.nodeId,selector:'#checkpoint-file'},c.session);await c.send('DOM.setFileInputFiles',{nodeId,files:[path.join(dir,file)]},c.session);}
const old=await c.evaluate('JSON.stringify(evosim.frame.selected)');await upload('bad.evo');await c.wait('document.querySelector("#feedback").textContent.includes("Invalid checkpoint")');assert.equal(await c.evaluate('JSON.stringify(evosim.frame.selected)'),old);
// Hold a completed load reply; queue an old-world inspector action before accepting it.
await c.evaluate(`(()=>{const original=window.fetch;window.fetch=async function(input,options){const response=await original(input,options);if(input==='/api/checkpoint/load'){window.fetch=original;window.uploadWaiting=true;await new Promise(resolve=>window.releaseUpload=resolve);}return response;};})()`);
await upload('other.evo');await c.wait('window.uploadWaiting');await c.evaluate('document.querySelector("#clear-selection").click();window.releaseUpload()');await c.wait('evosim.renderedTick==="17" && evosim.frame.selected===null && !evosim.frame.running');await c.wait('document.querySelector("#feedback").textContent.includes("stale world epoch")');assert.equal(await c.evaluate('document.querySelector("#dimensions").textContent'),'7 × 3 CELLS');
for(let i=0;i<3;i++)await click('step');assert.equal(await c.evaluate('evosim.renderedTick'),'20');
// Export final bytes without a second browser download, for exact CLI continuation comparison.
const bytes=await c.evaluate(`fetch('/api/checkpoint/save',{method:'POST',headers:{'X-Evosim-Token':location.hash.slice(1),'X-Evosim-Epoch':evosim.epoch}}).then(r=>r.arrayBuffer()).then(b=>Array.from(new Uint8Array(b)))`);fs.writeFileSync(path.join(dir,'browser-final.evo'),Buffer.from(bytes));
const stale=await c.evaluate('JSON.stringify(evosim.frame)');await click('reset');await c.wait('evosim.renderedTick==="0"');assert.equal(await c.evaluate('evosim.frame.counts[0]'),'9');
// Inject a genuinely older revision in the next poll: backward reset must survive it.
await c.evaluate(`(()=>{const original=window.fetch;window.fetch=function(input,options){if(input==='/api/frame'){window.fetch=original;return Promise.resolve(new Response(${JSON.stringify(stale)},{status:200,headers:{'Content-Type':'application/json'}}));}return original(input,options);};})()`);
await new Promise(r=>setTimeout(r,350));assert.equal(await c.evaluate('evosim.renderedTick'),'0');assert.equal(c.errors.length,0);assert.equal(await c.evaluate('evosim.error'),null);
console.log(JSON.stringify({saved_tick:savedTick,death_id:dead.id,death_tick:dead.death_tick,browser_controls:true,file_input:true,download:true,dimensions:[7,3]}));
}finally{await c.close();}})().catch(e=>{console.error(e.stack);process.exitCode=1;});

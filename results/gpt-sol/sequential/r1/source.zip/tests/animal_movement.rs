use evosim::{config::Config, organism::Kind, simulation::Simulation};
fn simulation(seed: u64, w: usize, h: usize, counts: [usize; 3]) -> Simulation {
    let [p, a, c] = counts;
    Simulation::new(Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{p},"herbivores":{a},"carnivores":{c}}}}}"#)).unwrap()).unwrap()
}
fn distance(w: usize, h: usize, a: evosim::topology::Cell, b: evosim::topology::Cell) -> usize {
    let dx = a.x().abs_diff(b.x());
    let dy = a.y().abs_diff(b.y());
    dx.min(w - dx).max(dy.min(h - dy))
}
#[test]
fn public_sense_is_observational_sorted_and_includes_edge_and_colocated_organisms() {
    for (w, h) in [(19, 19), (1, 19), (19, 1), (1, 1)] {
        let s = simulation(42, w, h, [w * h, 3, 2]);
        let before = s.clone();
        for animal in s.population().iter() {
            let expected = if animal.kind() == Kind::Plant {
                None
            } else {
                Some(
                    s.population()
                        .iter()
                        .filter(|o| {
                            o.id() != animal.id()
                                && distance(w, h, o.position(), animal.position())
                                    <= animal.traits().vision() as usize
                        })
                        .map(|o| o.id())
                        .collect::<Vec<_>>(),
                )
            };
            assert_eq!(s.population().sense(animal.id()), expected);
        }
        assert_eq!(s, before);
    }
}
#[test]
fn actual_tick_feeds_across_horizontal_vertical_and_corner_seams_without_extra_step() {
    for (w, h, p) in [(7, 1, 6), (1, 7, 6), (3, 3, 8)] {
        let mut s = simulation(42, w, h, [p, 1, 0]);
        let animal = s
            .population()
            .iter()
            .find(|o| o.kind() == Kind::Herbivore)
            .unwrap()
            .id();
        let initial = s.population().get(animal).unwrap().clone();
        s.advance_one_tick().unwrap();
        let after = s.population().get(animal).unwrap();
        assert_eq!(after.position(), initial.position());
        assert!((after.energy() - 1000.).abs() < 1e-10);
        assert!(
            s.population()
                .nearby(after.position(), 1, Some(Kind::Plant))
                .len()
                > 0
        );
        assert!(
            s.population()
                .nearby(initial.position(), 0, None)
                .contains(&animal)
        );
    }
}
#[test]
fn stacked_tiny_world_never_charges_or_draws_for_nonexistent_steps() {
    let mut value: serde_json::Value =
        serde_json::from_str(&simulation(42, 1, 1, [2, 3, 0]).config().to_json().unwrap()).unwrap();
    value["climate"]["weather_amplitude"] = serde_json::json!(0);
    value["plants"]["reproduction_energy"] = serde_json::json!(1001);
    let mut s = Simulation::new(Config::from_json(&value.to_string()).unwrap()).unwrap();
    let rng = s.rng_state();
    s.advance_one_tick().unwrap();
    assert_eq!(rng, s.rng_state());
    assert_eq!(
        s.population()
            .nearby(s.world().topology().cell(0, 0), 0, None)
            .len(),
        5
    );
    for o in s.population().iter().filter(|o| o.kind() != Kind::Plant) {
        if o.kind() == Kind::Carnivore {
            assert_eq!(o.energy(), 1000.);
        } else {
            assert!((o.energy() - 1000.).abs() < 1e-10);
        }
    }
    // No food at all also leaves a 1x1 explorer stationary without a draw.
    let mut value: serde_json::Value =
        serde_json::from_str(&s.config().to_json().unwrap()).unwrap();
    value["initial"]["plants"] = serde_json::json!(0);
    value["initial"]["carnivores"] = serde_json::json!(0);
    let mut s = Simulation::new(Config::from_json(&value.to_string()).unwrap()).unwrap();
    let before = s.rng_state();
    s.advance_one_tick().unwrap();
    assert_eq!(s.rng_state(), before);
}
#[test]
fn mixed_four_seed_2200_tick_replay_conservation_and_spatial_oracles_with_positive_cost() {
    let mut saw_movement = false;
    let mut saw_cost = false;
    for seed in [0, 1, 42, u64::MAX] {
        let mut s = simulation(seed, 7, 5, [3, 3, 2]);
        let mut replay = s.clone();
        let mut extinct = [false; 3];
        for _ in 0..2200 {
            let before = s.clone();
            s.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
            assert_eq!(s, replay);
            for (i, kind) in Kind::ALL.into_iter().enumerate() {
                let totals = s.population().totals();
                let count = s.population().counts().get(kind);
                assert_eq!(
                    totals.initial.get(kind) + totals.births.get(kind) - totals.deaths.get(kind),
                    count
                );
                if extinct[i] {
                    assert_eq!(count, 0);
                }
                extinct[i] = count == 0;
            }
            for o in s.population().iter() {
                assert!(o.energy() > 0. && o.health() > 0.);
                let ids = s.population().nearby(o.position(), 0, None);
                let expected: Vec<_> = s
                    .population()
                    .iter()
                    .filter(|x| x.position() == o.position())
                    .map(|x| x.id())
                    .collect();
                assert_eq!(ids, expected);
                if o.kind() != Kind::Plant {
                    let expected: Vec<_> = s
                        .population()
                        .iter()
                        .filter(|x| {
                            x.id() != o.id()
                                && distance(7, 5, o.position(), x.position())
                                    <= o.traits().vision() as usize
                        })
                        .map(|x| x.id())
                        .collect();
                    assert_eq!(s.population().sense(o.id()), Some(expected));
                    if let Some(old) = before.population().get(o.id()) {
                        saw_movement |= o.position() != old.position();
                        saw_cost |= o.energy() < old.energy();
                        assert!(
                            distance(7, 5, o.position(), old.position())
                                <= o.traits().speed() as usize
                        );
                    }
                }
            }
        }
    }
    assert!(saw_movement && saw_cost);
}

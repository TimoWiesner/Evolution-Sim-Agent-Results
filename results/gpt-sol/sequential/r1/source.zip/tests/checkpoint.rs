use evosim::{
    config::Config,
    persistence::{checkpoint_bytes, from_checkpoint_bytes, state_hash},
    simulation::Simulation,
};
fn config(w: usize, h: usize, p: usize, hb: usize, c: usize, seed: &str) -> Config {
    Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{p},"herbivores":{hb},"carnivores":{c}}}}}"#)).unwrap()
}
#[test]
fn complete_roundtrip_and_future_continuation() {
    for (w, h, p, hb, c) in [
        (8, 6, 30, 12, 3),
        (1, 9, 12, 3, 1),
        (9, 1, 12, 3, 1),
        (1, 1, 0, 0, 0),
    ] {
        for seed in ["42", "-1844674407370955161700001"] {
            for split in [0, 7, 53, 200] {
                let mut original = Simulation::new(config(w, h, p, hb, c, seed)).unwrap();
                while original.tick() < split {
                    original.advance_one_tick().unwrap();
                }
                let before = state_hash(&original).unwrap();
                let bytes = checkpoint_bytes(&original).unwrap();
                assert_eq!(state_hash(&original).unwrap(), before);
                let mut restored = from_checkpoint_bytes(&bytes).unwrap();
                assert_eq!(checkpoint_bytes(&restored).unwrap(), bytes);
                assert_eq!(original, restored);
                for _ in 0..100 {
                    original.advance_one_tick().unwrap();
                    restored.advance_one_tick().unwrap();
                    assert_eq!(original, restored);
                    assert_eq!(
                        state_hash(&original).unwrap(),
                        state_hash(&restored).unwrap()
                    );
                }
            }
        }
    }
}
#[test]
fn envelope_corruption_truncation_and_arbitrary_bytes() {
    let bytes = checkpoint_bytes(&Simulation::new(config(1, 1, 0, 0, 0, "0")).unwrap()).unwrap();
    assert_eq!(&bytes[..17], b"EVOSIM-CHECKPOINT");
    assert_eq!(&bytes[17..21], &1u32.to_le_bytes());
    assert_eq!(
        u64::from_le_bytes(bytes[21..29].try_into().unwrap()) as usize,
        bytes.len() - 61
    );
    for n in 0..bytes.len() {
        assert!(from_checkpoint_bytes(&bytes[..n]).is_err(), "prefix {n}");
    }
    for i in 0..bytes.len() {
        let mut bad = bytes.clone();
        bad[i] ^= 128;
        assert!(from_checkpoint_bytes(&bad).is_err(), "flip {i}");
    }
    let mut bad = bytes.clone();
    bad.push(0);
    assert!(from_checkpoint_bytes(&bad).is_err());
    let mut word = 42u64;
    for n in 0..2048 {
        let b: Vec<u8> = (0..n % 1024)
            .map(|_| {
                word = word.wrapping_mul(6364136223846793005).wrapping_add(1);
                (word >> 32) as u8
            })
            .collect();
        assert!(from_checkpoint_bytes(&b).is_err());
    }
}
#[test]
fn long_production_recruitment_and_resource_extremes() {
    use evosim::{metrics::Snapshot, organism::Kind};
    for (p, h, horizon, split) in [(400, 0, 2250, 2100), (2000, 120, 650, 301)] {
        let mut a = Simulation::new(config(64, 48, p, h, 0, "42")).unwrap();
        for _ in 0..split {
            a.advance_one_tick().unwrap();
        }
        assert!(a.population().totals().births.plants() > 0);
        if h > 0 {
            assert!(a.population().totals().births.herbivores() > 0);
            assert!(
                a.population()
                    .iter()
                    .any(|o| o.kind() == Kind::Herbivore && o.last_reproduction_tick().is_some())
            );
        }
        let mut b = from_checkpoint_bytes(&checkpoint_bytes(&a).unwrap()).unwrap();
        for _ in split..horizon {
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
            assert_eq!(a, b);
            assert_eq!(Snapshot::capture(&a), Snapshot::capture(&b));
        }
        assert!(a.population().iter().any(|o| o.generation() > 0));
    }
    for amplitude in [0., 1.] {
        let mut v = serde_json::from_str::<serde_json::Value>(
            &config(2, 2, 2, 0, 0, "42").to_json().unwrap(),
        )
        .unwrap();
        v["climate"]["weather_amplitude"] = serde_json::json!(amplitude);
        v["climate"]["season_temperature_amplitude"] = serde_json::json!(-0.0);
        for (group, field, value) in [
            ("plants", "resource_capacity", 1e-300),
            ("plants", "resource_regeneration", 1e6),
            ("plants", "growth_efficiency", -0.0),
            ("animals", "movement_cost", -0.0),
        ] {
            v[group][field] = serde_json::json!(value);
        }
        let mut a = Simulation::new(Config::from_json(&v.to_string()).unwrap()).unwrap();
        for _ in 0..10 {
            a.advance_one_tick().unwrap();
        }
        let bytes = checkpoint_bytes(&a).unwrap();
        assert_eq!(
            checkpoint_bytes(&from_checkpoint_bytes(&bytes).unwrap()).unwrap(),
            bytes
        );
    }
}

#[test]
fn old_hunting_model_is_rejected_even_with_valid_checksum() {
    use sha2::{Digest, Sha256};
    let mut bytes =
        checkpoint_bytes(&Simulation::new(config(1, 1, 0, 0, 0, "42")).unwrap()).unwrap();
    let needle = b"hunting";
    let positions: Vec<_> = bytes
        .windows(needle.len())
        .enumerate()
        .filter_map(|(i, b)| (b == needle).then_some(i))
        .collect();
    assert_eq!(positions.len(), 1);
    let i = positions[0] + needle.len();
    assert_eq!(&bytes[i..i + 4], &2u32.to_le_bytes());
    bytes[i..i + 4].copy_from_slice(&1u32.to_le_bytes());
    let end = bytes.len() - 32;
    let checksum = Sha256::digest(&bytes[..end]);
    bytes[end..].copy_from_slice(&checksum);
    let error = from_checkpoint_bytes(&bytes).unwrap_err().to_string();
    assert!(error.contains("unsupported state model"), "{error}");
}

#[test]
fn resting_parents_and_hungry_offspring_resume_exactly() {
    let cfg=Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":2},"animals":{"movement_cost":0,"basal_cost":0.1},"genetics":{"mutation_per_million":0}}"#).unwrap();
    for split in [0, 109, 120, 220] {
        let mut a = Simulation::new(cfg.clone()).unwrap();
        for _ in 0..split {
            a.advance_one_tick().unwrap();
        }
        if split >= 120 {
            assert!(a.population().totals().births.carnivores() > 0);
            assert!(a.population().iter().any(|o| o.energy() >= 750.));
            assert!(a.population().iter().any(|o| o.energy() < 750.));
        }
        let mut b = from_checkpoint_bytes(&checkpoint_bytes(&a).unwrap()).unwrap();
        for _ in 0..50 {
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
            assert_eq!(a, b);
            assert_eq!(state_hash(&a).unwrap(), state_hash(&b).unwrap());
        }
    }
}

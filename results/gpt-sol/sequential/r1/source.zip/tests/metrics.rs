use evosim::{
    config::Config, metrics::Snapshot, organism::Kind, persistence::state_hash,
    simulation::Simulation,
};
use serde_json::json;
fn world(seed: u64, counts: [usize; 3], size: [usize; 2]) -> Config {
    Config::from_json(&json!({"seed":seed,"world":{"width":size[0],"height":size[1]},"initial":{"plants":counts[0],"herbivores":counts[1],"carnivores":counts[2]}}).to_string()).unwrap()
}
#[test]
fn hand_calculated_founders_empty_and_singleton() {
    let sim = Simulation::new(world(42, [2, 1, 0], [4, 4])).unwrap();
    let before = sim.clone();
    let hash = state_hash(&sim).unwrap();
    let s = Snapshot::capture(&sim);
    assert_eq!(s.tick(), 0);
    assert_eq!(s.counts().plants(), 2);
    assert_eq!(s.counts().herbivores(), 1);
    let q = 32768. / 65535.;
    let expected = [
        2.,
        1. + 9. * q,
        10. + 90. * q,
        1100.,
        q,
        4.,
        0.5 + 1.5 * q,
        q,
        q,
        0.05 + 0.45 * q,
        q,
        q,
    ];
    for kind in [Kind::Plant, Kind::Herbivore] {
        let k = s.kind(kind);
        assert_eq!(
            (k.births, k.deaths, k.deaths_by_cause, k.species),
            (0, 0, [0; 5], 1)
        );
        assert_eq!(k.generation.highest, Some(0));
        assert_eq!(k.generation.mean, Some(0.));
        for (summary, value) in k.traits.0.iter().zip(expected) {
            assert!((summary.mean.unwrap() - value).abs() < 1e-12);
            assert_eq!(summary.standard_deviation, Some(0.));
            assert_eq!(summary.min, Some(value));
            assert_eq!(summary.max, Some(value));
        }
    }
    let absent = s.kind(Kind::Carnivore);
    assert_eq!(absent.species, 0);
    assert_eq!(absent.generation.highest, None);
    for summary in absent.traits.0 {
        assert_eq!(summary, Default::default());
    }
    assert_eq!(sim, before);
    assert_eq!(state_hash(&sim).unwrap(), hash);
    let empty = Snapshot::capture(&Simulation::new(world(0, [0, 0, 0], [1, 1])).unwrap());
    assert_eq!(empty.generation().mean, None);
    assert_eq!(
        empty.to_json()["analytics"]["generation"],
        json!({"highest":null,"mean":null})
    );
}
#[test]
fn repeated_capture_cannot_change_evolving_or_extinct_state() {
    for seed in [0, 1, 42] {
        for (counts, size) in [
            ([16, 4, 2], [8, 6]),
            ([400, 0, 0], [64, 48]),
            ([1, 0, 0], [1, 1]),
        ] {
            let mut sampled = Simulation::new(world(seed, counts, size)).unwrap();
            let mut plain = sampled.clone();
            for tick in 0..=2200 {
                let first = Snapshot::capture(&sampled);
                assert_eq!(first, Snapshot::capture(&sampled));
                assert_eq!(sampled, plain);
                if tick % 550 == 0 {
                    assert_eq!(state_hash(&sampled).unwrap(), state_hash(&plain).unwrap());
                }
                if tick == 2200 {
                    break;
                }
                sampled.advance_one_tick().unwrap();
                plain.advance_one_tick().unwrap();
            }
            if counts[0] == 400 {
                assert!(sampled.population().totals().births.plants() > 0);
            }
            if size == [1, 1] {
                assert_eq!(sampled.population().counts().plants(), 0);
            }
        }
    }
}

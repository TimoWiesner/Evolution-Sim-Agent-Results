use evosim::{
    config::{Config, Seed},
    persistence::state_hash,
    simulation::Simulation,
};
#[test]
fn replay_hashing_is_readonly_and_full_seed_is_retained() {
    let config = Config::from_json(r#"{"seed":42,"world":{"width":8,"height":6},"initial":{"plants":8,"herbivores":4,"carnivores":2}}"#).unwrap();
    let mut a = Simulation::new(config.clone()).unwrap();
    let mut b = a.clone();
    for tick in 0..=2200 {
        if tick % 100 == 0 {
            let before = a.clone();
            let hash = state_hash(&a).unwrap();
            assert_eq!(a, b);
            assert_eq!(a, before);
            assert_eq!(hash, state_hash(&b).unwrap());
            assert_eq!(hash.len(), 64);
            assert!(
                hash.bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
            );
        }
        a.advance_one_tick().unwrap();
        b.advance_one_tick().unwrap();
    }
    let a = Simulation::new(config.clone()).unwrap();
    let b = Simulation::new(config.with_seed(Seed::from_decimal("18446744073709551658").unwrap()))
        .unwrap();
    assert_eq!(a.rng_state(), b.rng_state());
    assert_ne!(state_hash(&a).unwrap(), state_hash(&b).unwrap());
}
#[test]
fn seed_decimal_grammar_and_normalization() {
    for (text, expected) in [
        ("00042", "42"),
        ("-00042", "-42"),
        ("-000", "0"),
        ("0", "0"),
    ] {
        assert_eq!(Seed::from_decimal(text).unwrap().as_decimal(), expected);
    }
    for bad in ["", "-", "+1", " 1", "1 ", "1.0", "1e2", "--1", "１２"] {
        assert!(Seed::from_decimal(bad).is_err(), "{bad}");
    }
}

use evosim::{
    config::{Config, Seed},
    genome::{GENOME_VERSION, Genome, LOCUS_COUNT, LOCUS_NAMES, MAX_DISTANCE_SUM},
    rng::Rng,
};
fn config(rate: u32, step: u16) -> Config {
    Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":{step}}}}}"#)).unwrap()
}
fn rng(seed: u64) -> Rng {
    Rng::from_seed(&Seed::from_u64(seed))
}
fn values(g: Genome) -> [f64; 12] {
    let t = g.traits();
    [
        t.speed() as f64,
        t.strength(),
        t.max_health(),
        t.lifespan() as f64,
        t.fertility(),
        t.vision() as f64,
        t.metabolic_multiplier(),
        t.preferred_temperature(),
        t.preferred_moisture(),
        t.climate_tolerance(),
        t.aggression(),
        t.risk_tolerance(),
    ]
}
const LOW: [f64; 12] = [1., 1., 10., 200., 0., 1., 0.5, 0., 0., 0.05, 0., 0.];
const HIGH: [f64; 12] = [4., 10., 100., 2000., 1., 8., 2., 1., 1., 0.5, 1., 1.];
#[test]
fn exhaustive_mapping_bounds_monotonicity_exact_endpoints_and_locus_order() {
    assert_eq!(
        (GENOME_VERSION, LOCUS_COUNT, LOCUS_NAMES.len()),
        (1, 12, 12)
    );
    assert_eq!(values(Genome::from_alleles([0; 12])), LOW);
    assert_eq!(values(Genome::from_alleles([65535; 12])), HIGH);
    let mut previous = LOW;
    for allele in 0..=65535u16 {
        let g = Genome::from_alleles([allele; 12]);
        let actual = values(g);
        assert_eq!(actual, values(g));
        for i in 0..12 {
            assert!(actual[i].is_finite() && (LOW[i]..=HIGH[i]).contains(&actual[i]));
            assert!(actual[i] >= previous[i]);
            let expected = if [0, 3, 5].contains(&i) {
                LOW[i] + ((u32::from(allele) * (HIGH[i] - LOW[i]) as u32) / 65535) as f64
            } else if allele == 65535 {
                HIGH[i]
            } else {
                LOW[i] + (HIGH[i] - LOW[i]) * (f64::from(allele) / 65535.)
            };
            assert_eq!(actual[i], expected, "locus {i}, allele {allele}");
        }
        previous = actual;
    }
    for i in 0..12 {
        let mut a = [0; 12];
        a[i] = 65535;
        let actual = values(Genome::from_alleles(a));
        for j in 0..12 {
            assert_eq!(actual[j], if i == j { HIGH[j] } else { LOW[j] });
        }
    }
}
// Independent sampling reference uses raw generator draws, not chance/below.
fn below(r: &mut Rng, bound: u64) -> u64 {
    loop {
        let n = r.next_u64();
        if n >= bound.wrapping_neg() % bound {
            return n % bound;
        }
    }
}
fn reference(mut a: [u16; 12], b: Option<[u16; 12]>, rate: u32, m: u16, r: &mut Rng) -> [u16; 12] {
    if let Some(b) = b {
        let split = below(r, 11) as usize + 1;
        let reverse = below(r, 2) == 1;
        let original = a;
        for i in 0..12 {
            a[i] = if (i < split) != reverse {
                original[i]
            } else {
                b[i]
            };
        }
    }
    for v in &mut a {
        let selected = match rate {
            0 => false,
            1_000_000 => true,
            n => below(r, 1_000_000) < u64::from(n),
        };
        if selected {
            let z = below(r, 2 * u64::from(m)) as i64;
            let delta = if z < i64::from(m) {
                z - i64::from(m)
            } else {
                z - i64::from(m) + 1
            };
            *v = (i64::from(*v) + delta).clamp(0, 65535) as u16;
        }
    }
    a
}
#[test]
fn zero_rate_clones_and_all_nonempty_crossover_boundaries_orientations() {
    let c = config(0, 1024);
    let a = Genome::from_alleles([123; 12]);
    let b = Genome::from_alleles([54321; 12]);
    let mut seen = [[false; 11]; 2];
    for seed in 0..1000 {
        let mut r = rng(seed);
        let before = r.state();
        assert_eq!(a.copy_child(c.genetics(), &mut r), a);
        assert_eq!(a.mutated(c.genetics(), &mut r), a);
        assert_eq!(r.state(), before);
        let child = a.crossover_child(&b, c.genetics(), &mut r);
        let x = child.alleles();
        let split = (1..12).find(|&i| x[i] != x[0]).unwrap();
        assert!(x[..split].iter().all(|&v| v == x[0]));
        assert!(
            x[split..]
                .iter()
                .all(|&v| v != x[0] && [123, 54321].contains(&v))
        );
        seen[usize::from(x[0] != 123)][split - 1] = true;
        let mut expected = rng(seed);
        assert_eq!(
            *x,
            reference(*a.alleles(), Some(*b.alleles()), 0, 1024, &mut expected)
        );
        assert_eq!(r.state(), expected.state());
    }
    assert!(seen.into_iter().flatten().all(|s| s));
    assert_eq!(a.alleles(), &[123; 12]);
    assert_eq!(b.alleles(), &[54321; 12]);
}
#[test]
fn mutation_reference_draw_order_strength_clamping_and_replay() {
    for rate in [0, 10000, 321987, 1_000_000] {
        for step in [1, 1024, 65535] {
            for seed in 0..100 {
                let c = config(rate, step);
                let a = Genome::from_alleles([
                    0, 65535, 32768, 1, 65534, 900, 32000, 0, 65535, 10, 60000, 32768,
                ]);
                let b = Genome::from_alleles([32768; 12]);
                for sexual in [false, true] {
                    let mut r = rng(seed);
                    let mut expected = r.clone();
                    let mut replay = Rng::from_state(r.state()).unwrap();
                    let child = if sexual {
                        a.crossover_child(&b, c.genetics(), &mut r)
                    } else {
                        a.copy_child(c.genetics(), &mut r)
                    };
                    assert_eq!(
                        *child.alleles(),
                        reference(
                            *a.alleles(),
                            sexual.then_some(*b.alleles()),
                            rate,
                            step,
                            &mut expected
                        )
                    );
                    assert_eq!(r.state(), expected.state());
                    let repeated = if sexual {
                        a.crossover_child(&b, c.genetics(), &mut replay)
                    } else {
                        a.copy_child(c.genetics(), &mut replay)
                    };
                    assert_eq!(child, repeated);
                    assert_eq!(r, replay);
                }
            }
        }
    }
    let c = config(1_000_000, 1);
    let a = Genome::founder();
    let mut r = rng(42);
    let changed = a.mutated(c.genetics(), &mut r);
    assert!(
        a.alleles()
            .iter()
            .zip(changed.alleles())
            .all(|(&a, &b)| a.abs_diff(b) == 1)
    );
    let c = config(10000, 1024);
    let mut r = rng(42);
    assert!(
        (0..2000)
            .filter(|_| a.copy_child(c.genetics(), &mut r) != a)
            .count()
            > 0
    );
    let c = config(1_000_000, 65535);
    let mut signs = [false; 4];
    for _ in 0..100 {
        let low = Genome::from_alleles([0; 12]).mutated(c.genetics(), &mut r);
        let high = Genome::from_alleles([65535; 12]).mutated(c.genetics(), &mut r);
        signs[0] |= low.alleles().contains(&0);
        signs[1] |= low.alleles().iter().any(|&v| v > 0);
        signs[2] |= high.alleles().contains(&65535);
        signs[3] |= high.alleles().iter().any(|&v| v < 65535);
    }
    assert!(signs.into_iter().all(|s| s));
}
#[test]
fn distance_metric_exact_extremes_known_displacements_and_generated_triangles() {
    let zero = Genome::from_alleles([0; 12]);
    let max = Genome::from_alleles([65535; 12]);
    assert_eq!(zero.distance_sum(&max), 786420);
    assert_eq!(MAX_DISTANCE_SUM, 786420);
    assert_eq!(zero.distance(&max), 1.);
    assert_eq!(zero.distance(&zero), 0.);
    let mut previous = 0;
    for n in 1..=12 {
        let mut a = [0; 12];
        a[..n].fill(1);
        let g = Genome::from_alleles(a);
        assert_eq!(zero.distance_sum(&g), n as u32);
        assert!(zero.distance_sum(&g) > previous);
        previous = n as u32;
    }
    let mut r = rng(7);
    for _ in 0..1000 {
        let mut make = || Genome::from_alleles(std::array::from_fn(|_| r.next_u64() as u16));
        let (a, b, c) = (make(), make(), make());
        let expected: u32 = a
            .alleles()
            .iter()
            .zip(b.alleles())
            .map(|(&x, &y)| (i32::from(x) - i32::from(y)).unsigned_abs())
            .sum();
        assert_eq!(a.distance_sum(&b), expected);
        assert_eq!(a.distance_sum(&b), b.distance_sum(&a));
        assert_eq!(a.distance_sum(&a), 0);
        assert!((0.0..=1.).contains(&a.distance(&b)));
        assert!(a.distance_sum(&c) <= a.distance_sum(&b) + b.distance_sum(&c));
    }
}

#[test]
fn independent_python_frozen_patterned_crossover_and_mutation_vector() {
    // Python integer SplitMix64/xoshiro256** + rejection/step reference; seed 42,
    // boundary 1, orientation 0. Frozen independently of the Rust genome API.
    let a = Genome::from_alleles(std::array::from_fn(|i| i as u16 * 1000));
    let b = Genome::from_alleles(std::array::from_fn(|i| 60000 - i as u16 * 1000));
    let c = config(321987, 1024);
    let mut r = rng(42);
    let child = a.crossover_child(&b, c.genetics(), &mut r);
    assert_eq!(
        child.alleles(),
        &[
            0, 59613, 58000, 56111, 56000, 55000, 54000, 53000, 52000, 51974, 50918, 49000
        ]
    );
    assert_eq!(
        r.state().words,
        [
            5726367031845654541,
            3662791717741399644,
            17042498262953750018,
            5049584178551681873
        ]
    );
    let c = config(0, 1024);
    for seed in 0..100 {
        let child = a.crossover_child(&b, c.genetics(), &mut rng(seed));
        assert!(
            child
                .alleles()
                .iter()
                .enumerate()
                .all(|(i, v)| *v == a.alleles()[i] || *v == b.alleles()[i])
        );
    }
}

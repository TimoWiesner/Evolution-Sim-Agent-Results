//! Deterministic external corpus: no test hooks or production RNG consumption.
use evosim::{
    config::Config,
    organism::{DeathCause, Kind},
    persistence::{checkpoint_bytes, from_checkpoint_bytes, state_hash},
    simulation::Simulation,
    traits::Traits,
};
use serde_json::json;
use std::collections::{BTreeMap, BTreeSet};
fn draw(r: &mut u64, n: u64) -> u64 {
    *r = r
        .wrapping_mul(6364136223846793005)
        .wrapping_add(1442695040888963407);
    (*r >> 32) % n
}
#[test]
fn randomized_completed_tick_invariants() {
    let mut r = 0x0285eed_u64;
    let mut queries = 0;
    let mut movements = 0;
    let mut births = 0;
    let mut deaths = 0;
    for case in 0..72 {
        let w = if case % 8 == 0 {
            1
        } else {
            1 + draw(&mut r, 16)
        };
        let h = if case % 8 == 1 {
            1
        } else {
            1 + draw(&mut r, 12)
        };
        let mut v = json!({
            "seed":case*7919+17,
            "world":{
            "width":w,
            "height":h},
            "initial":{
            "plants":draw(&mut r,65),
            "herbivores":draw(&mut r,17),
            "carnivores":draw(&mut r,5)},
            "climate":{
            "year_ticks":1+draw(&mut r,1000),
            "weather_amplitude":([0.0,0.05,1.0][case%3]),
            "season_temperature_amplitude":([0.0,0.15,1.0][case%3]),
            "season_precipitation_amplitude":([1.0,0.1,0.0][case%3])},
            "genetics":{
            "mutation_per_million":([0,10000,1000000][case%3]),
            "mutation_max_step":([1,1024,65535][case%3])},
            "plants":{
            "resource_capacity":([1.0,100.0,1000.0][case%3]),
            "resource_regeneration":([0.0,2.0,4.0][case%3]),
            "growth_efficiency":([0.0,0.5,1.0][case%3]),
            "reproduction_energy":([20.0,1000000.0,40.0][case%3]),
            "dispersal_radius":draw(&mut r,5)},
            "animals":{
            "movement_cost":([0.0,0.2,1000000.0][case%3]),
            "basal_cost":([0.1,1.0,10.0][case%3]),
            "reproduction_energy":([30.0,1000000.0,60.0][case%3]),
            "reproduction_cooldown":([1,100,300][case%3])}});
        if case == 0 {
            v["initial"] = json!({"plants":0,"herbivores":0,"carnivores":0});
        }
        if case == 2 {
            v["world"] = json!({"width":1,"height":1});
        }
        let w = v["world"]["width"].as_u64().unwrap();
        let h = v["world"]["height"].as_u64().unwrap();
        eprintln!("generator=0x0285eed case={case} config={v}");
        let config = Config::from_json(&v.to_string()).unwrap();
        let mut a = Simulation::new(config.clone()).unwrap();
        let mut b = Simulation::new(config).unwrap();
        let end = if case >= 64 {
            2200
        } else {
            128 + draw(&mut r, 129)
        };
        let mut extinct_species = BTreeSet::new();
        let different = Simulation::new(
            a.config()
                .with_seed(evosim::config::Seed::from_u64(9999999)),
        )
        .unwrap();
        assert_ne!(state_hash(&a).unwrap(), state_hash(&different).unwrap());
        let mut old = BTreeMap::new();
        let mut previous = [(0, 0); 3];
        let mut zero = [false; 3];
        for tick in 0..=end {
            assert_eq!(a, b, "case {case} tick {tick}");
            assert_eq!(a.tick(), tick);
            assert_eq!(a.world().temporal_climate().tick(), tick);
            if tick % 31 == 0 || tick == end {
                assert_eq!(state_hash(&a).unwrap(), state_hash(&b).unwrap());
            }
            if case < 16 && tick == end / 2 {
                let bytes = checkpoint_bytes(&a).unwrap();
                b = from_checkpoint_bytes(&bytes).unwrap();
                assert_eq!(checkpoint_bytes(&b).unwrap(), bytes);
            }
            let p = a.population();
            let totals = p.totals();
            let topo = a.world().topology();
            for (i, k) in Kind::ALL.into_iter().enumerate() {
                let count = p.iter().filter(|o| o.kind() == k).count() as u128;
                assert_eq!(count, p.counts().get(k));
                assert_eq!(
                    totals.initial.get(k) + totals.births.get(k) - totals.deaths.get(k),
                    count
                );
                assert_eq!(
                    DeathCause::ALL
                        .into_iter()
                        .map(|c| p.deaths_by_cause(k, c))
                        .sum::<u128>(),
                    totals.deaths.get(k)
                );
                assert!(
                    totals.births.get(k) >= previous[i].0 && totals.deaths.get(k) >= previous[i].1
                );
                if zero[i] {
                    assert_eq!(count, 0);
                    assert_eq!(totals.births.get(k), previous[i].0);
                }
                zero[i] = count == 0;
                previous[i] = (totals.births.get(k), totals.deaths.get(k));
            }
            for o in p.iter() {
                assert!(o.energy().is_finite() && o.energy() > 0.0 && o.energy() <= 1000.0);
                assert!(
                    o.health().is_finite()
                        && o.health() > 0.0
                        && o.health() <= o.traits().max_health()
                );
                assert!(Traits::new(o.traits().values()).is_ok());
                assert_eq!(o.age(), tick - o.birth_tick());
                assert!(o.age() < o.traits().lifespan());
                assert!(o.last_reproduction_tick().is_none_or(|t| t <= tick));
                assert!(o.parents().iter().all(|id| id.value() < o.id().value()));
                assert!(o.position().x() < w as usize && o.position().y() < h as usize);
                if o.kind() != Kind::Plant {
                    if let Some(pos) = old.get(&o.id()) {
                        let d = topo.distance(*pos, o.position());
                        assert!(d <= o.traits().speed() as usize);
                        movements += u64::from(d > 0);
                    }
                }
            }
            for s in p.species().iter() {
                if extinct_species.contains(&s.id()) {
                    assert_eq!(s.living_members(), 0);
                }
                if s.extinction_tick().is_some() {
                    extinct_species.insert(s.id());
                }
                let n = p.iter().filter(|o| o.species_id() == s.id()).count() as u128;
                assert_eq!(n, s.living_members());
                assert_eq!(s.extinction_tick().is_some(), n == 0);
            }
            for y in 0..h {
                for x in 0..w {
                    let c = topo.cell(x as i128, y as i128);
                    let resource = a.world().resources().at(c);
                    assert!(
                        resource.is_finite()
                            && resource >= 0.0
                            && resource <= a.config().plants().resource_capacity()
                    );
                    let climate = a.world().current_climate_at(c);
                    assert!(
                        (0.0..=1.0).contains(&climate.temperature())
                            && (0.0..=1.0).contains(&climate.precipitation())
                    );
                }
            }
            let x = draw(&mut r, 10001) as i128 - 5000;
            let y = draw(&mut r, 10001) as i128 - 5000;
            let c = topo.cell(x, y);
            assert_eq!(c.x(), ((x % (w as i128) + w as i128) % w as i128) as usize);
            assert_eq!(c.y(), ((y % (h as i128) + h as i128) % h as i128) as usize);
            let radius = if tick % 17 == 0 {
                usize::MAX
            } else {
                draw(&mut r, 9) as usize
            };
            let expected: Vec<_> = p
                .iter()
                .filter(|o| {
                    let dx = o.position().x().abs_diff(c.x());
                    let dy = o.position().y().abs_diff(c.y());
                    dx.min(w as usize - dx).max(dy.min(h as usize - dy)) <= radius
                })
                .map(|o| o.id())
                .collect();
            assert_eq!(p.nearby(c, radius, None), expected);
            let cells: Vec<_> = topo.cells_within(c, radius).collect();
            assert_eq!(
                cells.len(),
                cells
                    .iter()
                    .map(|c| (c.x(), c.y()))
                    .collect::<BTreeSet<_>>()
                    .len()
            );
            queries += 1;
            old = p.iter().map(|o| (o.id(), o.position())).collect();
            if tick < end {
                a.advance_one_tick().unwrap();
                b.advance_one_tick().unwrap();
            }
        }
        births += a.population().totals().births.plants()
            + a.population().totals().births.herbivores()
            + a.population().totals().births.carnivores();
        deaths += a.population().death_records().len();
    }
    eprintln!(
        "72 cases (8 x 2200 ticks); queries={queries} moved_animal_ticks={movements} births={births} deaths={deaths}"
    );
    assert!(movements > 0 && births > 0 && deaths > 0);
}

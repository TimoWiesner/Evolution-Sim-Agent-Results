'use strict';
const assert=require('node:assert/strict'),C=require('../ui/configuration.js');
assert.equal(C.fields.length,21);assert.equal(new Set(C.fields.map(f=>f[0])).size,21);
const fields=Object.fromEntries(C.fields.map(([p,,t])=>[p,t==='real'?'0.123':'1']));
fields.seed='-1234567890123456789012345678901234567890';fields['climate.year_ticks']='18446744073709551615';fields['animals.movement_cost']='5e-324';
let a=C.assemble(fields);assert.deepEqual(a.errors,{});assert(a.json.includes(fields.seed));assert(a.json.includes(fields['climate.year_ticks']));assert(a.json.includes('5e-324'));assert.equal(JSON.parse(a.json).animals.movement_cost,5e-324);
for(const bad of ['',' 1','1 ','1e3','1.0','+1','01','NaN','Infinity','1,"x":2']){assert(C.assemble({...fields,seed:bad}).errors.seed,bad);}
assert(C.assemble({...fields,'world.width':'-1'}).errors['world.width']);
assert.deepEqual(C.affected('initial'),['initial.plants','initial.herbivores','initial.carnivores']);assert.equal(C.affected('world.width/world.height').length,2);assert.deepEqual(C.affected('$'),[]);
console.log('Exact-token configuration logic passed');

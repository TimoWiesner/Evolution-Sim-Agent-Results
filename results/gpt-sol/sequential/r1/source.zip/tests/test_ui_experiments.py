"""Experiment HTTP/purity checks without display plus real browser interactions."""
import json
import socket
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from test_ui import ROOT, server, request

class Experiments(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(['cargo','build','--locked','--release'],cwd=ROOT,check=True,capture_output=True)

    def test_configuration_charts_and_rollback_without_display(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target') as tmp, server([]) as url:
            d=Path(tmp);token=url.split('#')[1]
            def frame():return json.loads(request(url,'/api/frame')[1])
            def post(path,data=None,epoch=None,mime='application/json'):
                return request(url,path,'POST',token,{'X-Evosim-Epoch':epoch or frame()['epoch'],'Content-Type':mime},data)
            def save():return post('/api/checkpoint/save')[1]
            def config(op,c):return post('/api/config/'+op,json.dumps(c).encode())
            catalog=json.loads(request(url,'/api/config')[1]);self.assertEqual(set(catalog['presets']),{'baseline','seasonal','plant-only'})
            original=save();before=frame()
            for dto in catalog['presets'].values():
                c=json.loads(dto['canonical_json']);code,b=config('validate',c);self.assertEqual(code,200,b)
                self.assertEqual(json.loads(b)['config']['canonical_json'],dto['canonical_json'])
            c=json.loads(catalog['active']['canonical_json'])
            c['seed']=-1234567890123456789012345678901234567890;c['world']={'width':9,'height':7};c['initial']={'plants':18,'herbivores':7,'carnivores':3}
            c['climate']['year_ticks']=18446744073709551615;c['animals']['movement_cost']=5e-324
            code,b=config('validate',c);self.assertEqual(code,200,b);dto=json.loads(b)['config'];self.assertEqual(json.loads(dto['canonical_json']),c)
            self.assertEqual(dto['fields']['seed'],str(c['seed']));self.assertEqual(dto['fields']['climate.year_ticks'],str(c['climate']['year_ticks']))
            self.assertEqual(save(),original);self.assertEqual(frame(),before)
            for path,value in [('world.width',0),('genetics.mutation_per_million',1000001),('animals.basal_cost',0),('initial.plants',-1),('animals.unknown',1)]:
                bad=json.loads(json.dumps(c));g,k=path.split('.');bad[g][k]=value
                code,b=config('start',bad);self.assertEqual(code,400,b);self.assertEqual(json.loads(b)['path'],path);self.assertEqual(save(),original);self.assertEqual(frame(),before)
            for group,changes,path in [('world',{'width':18446744073709551615,'height':2},'world.width/world.height'),('initial',{'plants':18446744073709551615,'herbivores':1,'carnivores':0},'initial')]:
                bad=json.loads(json.dumps(c));bad[group]=changes
                code,b=config('start',bad);self.assertEqual(code,400,b);self.assertEqual(json.loads(b)['path'],path);self.assertEqual(save(),original)
            for raw in [b'{',b'[]',b'null',b'\xff']:
                code,b=post('/api/config/start',raw);self.assertEqual(code,400,b);self.assertEqual(save(),original)
            self.assertEqual(post('/api/config/start',b'{}',mime='text/plain')[0],415)
            self.assertEqual(post('/api/config/start')[0],413)
            self.assertEqual(request(url,'/api/config/start','POST',data=b'{}')[0],403)
            self.assertEqual(request(url,'/api/config/start','GET',token)[0],405)
            self.assertEqual(request(url,'/api/config/start','POST',token,{'X-Evosim-Epoch':'0','Origin':'http://foreign','Content-Type':'application/json'},b'{}')[0],403)
            code,b=config('start',c);self.assertEqual(code,200,b);f=json.loads(b)['frame'];self.assertEqual(f['tick'],'0');self.assertFalse(f['running']);self.assertNotEqual(f['epoch'],before['epoch']);self.assertEqual(len(f['charts']['points']),1)
            self.assertEqual(post('/api/config/start',json.dumps(c).encode(),epoch='0')[0],409)
            cfg=d/'config.json';cfg.write_text(json.dumps(c));checkpoint=d/'expected.evo';out=d/'out.json'
            for _ in range(23):self.assertEqual(post('/api/control/step')[0],200)
            f=frame();self.assertEqual([p['tick'] for p in f['charts']['points']],['0','10','20','23'])
            for _ in range(3):self.assertEqual(frame(),f)
            subprocess.run([str(ROOT/'evosim'),'run','--config',str(cfg),'--ticks','23','--out',str(out),'--save',str(checkpoint),'--sample-every','10'],check=True)
            result=json.loads(out.read_text());self.assertEqual(checkpoint.read_bytes(),save())
            for chart,row in zip(f['charts']['points'],result['series']):
                self.assertEqual(int(chart['tick']),row['tick'])
                for i,k in enumerate(['plants','herbivores','carnivores']):
                    p=chart['kinds'][i];m=row['analytics'][k];self.assertEqual(int(p['population']),row[k]);self.assertEqual(int(p['births']),m['births']);self.assertEqual(int(p['deaths']),m['deaths']);self.assertEqual(int(p['species']),m['species'])
                    # All12 histogram totals at the actual current frame.
                    for h in f['charts']['current']['histograms']:self.assertEqual(sum(map(int,h['counts'][i])),int(f['counts'][i]))
            self.assertGreater(sum(int(k['births'])+int(k['deaths']) for k in f['charts']['points'][-1]['kinds']),0)
            code,b=post('/api/checkpoint/load',checkpoint.read_bytes(),mime='application/octet-stream');self.assertEqual(code,200,b);self.assertEqual([p['tick'] for p in frame()['charts']['points']],['23'])
            post('/api/control/reset');self.assertEqual([p['tick'] for p in frame()['charts']['points']],['0'])

    def test_config_ingress_without_display(self):
        with server([]) as url:
            host=url.split('/')[2];token=url.split('#')[1];port=int(host.split(':')[1]);sockets=[]
            def connect(length):
                s=socket.create_connection(('127.0.0.1',port));s.settimeout(3);sockets.append(s)
                s.sendall((f'POST /api/config/validate HTTP/1.1\r\nHost: {host}\r\nX-Evosim-Token: {token}\r\nX-Evosim-Epoch: 0\r\nContent-Type: application/json\r\nContent-Length: {length}\r\nConnection: close\r\n\r\n').encode());return s
            try:
                self.assertIn(b'413',connect(1024*1024+1).recv(4096))
                slow=connect(65536);time.sleep(.1)
                code,b=request(url,'/api/control/step','POST',token,{'X-Evosim-Epoch':'0'});self.assertEqual(code,200,b)
                code,b=request(url,'/api/control/reset','POST',token,{'X-Evosim-Epoch':'0'});self.assertEqual(code,200,b)
                slow.sendall(b' '*65536);self.assertIn(b'409',slow.recv(4096))
            finally:
                for s in sockets:s.close()

    def test_real_browser_experiments_and_charts(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target',prefix='experiments ') as tmp, server([]) as url:
            d=Path(tmp);(d/'bad.json').write_text('{"unknown":0}')
            p=subprocess.run(['node',str(ROOT/'tests/ui_experiments.cjs'),url,str(d)],capture_output=True,text=True,timeout=55)
            self.assertEqual(p.returncode,0,p.stderr);print(p.stdout.strip())
            evidence=json.loads(p.stdout);c=json.loads((d/'evosim-config.json').read_text());self.assertEqual(c['seed'],-1234567890123456789012345678901234567890);self.assertEqual(c['world'],{'width':12,'height':9})
            expected=d/'expected.evo';cfg=d/'config.json';cfg.write_text(json.dumps(c))
            subprocess.run([str(ROOT/'evosim'),'run','--config',str(cfg),'--ticks',str(evidence['final_tick']),'--out',str(d/'result.json'),'--save',str(expected)],check=True)
            self.assertEqual((d/'browser.evo').read_bytes(),expected.read_bytes())

if __name__=='__main__':unittest.main()

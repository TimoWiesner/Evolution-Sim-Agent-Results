"""Real browser, release launcher, loopback protocol and shared-engine checks."""
import contextlib
import json
import os
from pathlib import Path
import re
import selectors
import subprocess
import tempfile
import time
import unittest
import urllib.request
import urllib.error
ROOT=Path(__file__).resolve().parents[1]

@contextlib.contextmanager
def server(args):
    p=subprocess.Popen([str(ROOT/'evosim'),'ui',*map(str,args)],cwd=ROOT/'target',stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        with selectors.DefaultSelector() as select:
            select.register(p.stderr,selectors.EVENT_READ)
            if not select.select(10): raise AssertionError('server startup timeout')
            line=p.stderr.readline()
        match=re.search(r'http://127\.0\.0\.1:\d+/#\w+',line)
        if not match: raise AssertionError(line)
        yield match[0]
    finally:
        p.terminate()
        try:p.communicate(timeout=5)
        except subprocess.TimeoutExpired:p.kill();p.communicate()

def request(url,path,method='GET',token=None,headers=None,data=None):
    headers=dict(headers or {})
    if token: headers['X-Evosim-Token']=token
    req=urllib.request.Request(url.split('/#')[0]+path,method=method,headers=headers,data=data)
    try:
        with urllib.request.urlopen(req,timeout=5) as r:return r.status,r.read()
    except urllib.error.HTTPError as e:return e.code,e.read()

class UI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(['cargo','build','--locked','--release'],cwd=ROOT,check=True,capture_output=True)

    def test_protocol_read_purity_and_normal_clock(self):
        with server([]) as url:
            token=url.split('#')[1]
            for path in ['/','/app.js','/style.css','/camera.js']:
                self.assertEqual(request(url,path)[0],200)
            w=json.loads(request(url,'/api/world')[1]);self.assertEqual(len(w['cells']),w['width']*w['height'])
            first=request(url,'/api/frame')[1];time.sleep(.15);self.assertEqual(first,request(url,'/api/frame')[1])
            self.assertEqual(request(url,'/api/ready','POST')[0],403)
            self.assertEqual(request(url,'/api/ready')[0],405)
            self.assertEqual(request(url,'/api/frame','POST')[0],405)
            self.assertEqual(request(url,'/missing')[0],404)
            self.assertEqual(request(url,'/api/frame',headers={'Origin':'https://foreign.invalid'})[0],403)
            self.assertEqual(request(url,'/api/frame',headers={'Host':'foreign.invalid'})[0],403)
            self.assertEqual(request(url,'/api/ready','POST',token,data=b'x'*2000)[0],413)
            self.assertEqual(request(url,'/api/ready','POST',token)[0],200)
            time.sleep(.3);self.assertGreater(int(json.loads(request(url,'/api/frame')[1])['tick']),0)

    def test_bad_arguments_and_missing_browser(self):
        for args in [['--unknown'],['--config'],['--config','missing','--config','missing'],['--screenshots'],['--config','missing'],['--screenshots','missing'],['--smoke-test','--smoke-test'],['--smoke-test','--screenshots',str(ROOT/'target')]]:
            p=subprocess.run([str(ROOT/'evosim'),'ui',*args],capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,2,p.stderr);self.assertEqual(p.stdout,'')
        before=set((ROOT/'target').glob('evosim*browser-*'))
        env=dict(os.environ,CHROME_BIN='/workspace/target/nonexistent-chromium')
        p=subprocess.run([str(ROOT/'evosim'),'ui','--smoke-test'],env=env,capture_output=True,text=True,timeout=15)
        self.assertEqual(p.returncode,2,p.stderr)
        self.assertIn('Chromium',p.stderr)
        self.assertEqual(before,set((ROOT/'target').glob('evosim*browser-*')))

    def test_smoke_screenshot_and_engine_hash(self):
        before=set((ROOT/'target').glob('evosim*browser-*'))
        with tempfile.TemporaryDirectory(dir=ROOT/'target',prefix='ui spaced ') as d:
            d=Path(d);config=d/'config.json';config.write_text(json.dumps({'seed':17,'world':{'width':8,'height':6},'initial':{'plants':10,'herbivores':2,'carnivores':1}}))
            for mode,ticks in [(['--smoke-test'],10),(['--screenshots',str(d)],100)]:
                p=subprocess.run([str(ROOT/'evosim'),'ui','--config',str(config),*mode],capture_output=True,text=True,timeout=110)
                self.assertEqual(p.returncode,0,p.stderr);self.assertEqual(p.stdout,'')
                evidence=json.loads(next(line.removeprefix('UI automation ') for line in p.stderr.splitlines() if line.startswith('UI automation {')))
                out=d/'result.json';subprocess.run([str(ROOT/'evosim'),'run','--config',str(config),'--ticks',str(ticks),'--out',str(out)],check=True)
                self.assertEqual(evidence['tick'],str(ticks));self.assertGreater(evidence['draws'],0)
                self.assertEqual(evidence['state_hash'],json.loads(out.read_text())['state_hash'])
            self.assertEqual(before,set((ROOT/'target').glob('evosim*browser-*')))
            png=(d/'main.png').read_bytes();self.assertEqual(png[:8],b'\x89PNG\r\n\x1a\n');self.assertGreaterEqual(int.from_bytes(png[16:20],'big'),1280);self.assertGreaterEqual(int.from_bytes(png[20:24],'big'),720)

    def test_empty_and_stacked_single_cell_render(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target',prefix='ui edge ') as d:
            config=Path(d)/'config.json'
            for initial in [{'plants':0,'herbivores':0,'carnivores':0},{'plants':5,'herbivores':3,'carnivores':2}]:
                config.write_text(json.dumps({'seed':42,'world':{'width':1,'height':1},'initial':initial}))
                p=subprocess.run([str(ROOT/'evosim'),'ui','--smoke-test','--config',str(config)],capture_output=True,text=True,timeout=50)
                self.assertEqual(p.returncode,0,p.stderr)
                self.assertIn('"tick":"10"',p.stderr)

    def test_browser_navigation_and_thousand_organism_throughput(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target',prefix='ui throughput ') as d:
            d=Path(d)
            for mode,initial,extra in [('mixed',{'plants':800,'herbivores':170,'carnivores':30},{}),('stable',{'plants':1000,'herbivores':0,'carnivores':0},{'genetics':{'mutation_per_million':0},'plants':{'growth_efficiency':0,'reproduction_energy':1000000}})]:
                config=d/(mode+'.json');config.write_text(json.dumps({'seed':42,'world':{'width':64,'height':48},'initial':initial,**extra}))
                with server(['--config',config]) as url:
                    p=subprocess.run(['node',str(ROOT/'tests/ui_browser.cjs'),url,mode],cwd=ROOT,capture_output=True,text=True,timeout=25)
                    self.assertEqual(p.returncode,0,p.stderr)
                    (ROOT/'target'/('task023-'+mode+'-performance.json')).write_text(p.stdout)
                    print(p.stdout.strip())

if __name__=='__main__':unittest.main()

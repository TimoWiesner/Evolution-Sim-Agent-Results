use evosim::{
    config::Config,
    rng::Rng,
    simulation::{Simulation, TickPhase},
};

fn config(seed: u64, width: usize, height: usize, count: usize) -> Config {
    Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{width},"height":{height}}},"initial":{{"plants":{count},"herbivores":{count},"carnivores":{count}}}}}"#)).unwrap()
}
fn phases() -> [TickPhase; 7] {
    [
        TickPhase::Clock,
        TickPhase::ClimateResources,
        TickPhase::Plants,
        TickPhase::Herbivores,
        TickPhase::Carnivores,
        TickPhase::Reproduction,
        TickPhase::Commit,
    ]
}

#[test]
fn state_owns_config_geometry_clock_and_seeded_rng() {
    let mut configs = vec![config(42, 1, 1, 0), config(43, 7, 3, 4)];
    configs.extend(
        Config::preset_names()
            .iter()
            .map(|name| Config::preset(name).unwrap()),
    );
    for config in configs {
        // Isolate scheduler/weather draws; reproduction has its own stream tests.
        let mut value: serde_json::Value =
            serde_json::from_str(&config.to_json().unwrap()).unwrap();
        value["plants"]["reproduction_energy"] = serde_json::json!(1001);
        value["initial"]["herbivores"] = serde_json::json!(0);
        value["initial"]["carnivores"] = serde_json::json!(0);
        let config = Config::from_json(&value.to_string()).unwrap();
        let mut sim = Simulation::new(config.clone()).unwrap();
        assert_eq!(sim.tick(), 0);
        assert_eq!(sim.config(), &config);
        let topology = sim.world().topology();
        assert_eq!(topology.width(), config.world().width());
        assert_eq!(topology.height(), config.world().height());
        assert_eq!(sim.rng_state(), Rng::from_seed(config.seed()).state());
        let mut rng = Rng::from_state(sim.rng_state()).unwrap();
        for tick in 1..=129 {
            let report = sim.advance_one_tick().unwrap();
            assert_eq!(report.tick, tick);
            assert_eq!(report.phases, phases());
            assert_eq!(sim.tick(), tick);
            if config.climate().weather_amplitude() > 0. {
                rng.next_u64();
                rng.next_u64();
            }
            assert_eq!(sim.rng_state(), rng.state());
            assert_eq!(sim.world().temporal_climate().tick(), tick);
        }
    }
}

#[test]
fn replay_trace_over_128_ticks() {
    let trace = |seed| {
        let mut sim = Simulation::new(config(seed, 7, 3, 0)).unwrap();
        (0..128)
            .map(|_| {
                let report = sim.advance_one_tick().unwrap();
                (report, sim.world().topology(), sim.rng_state())
            })
            .collect::<Vec<_>>()
    };
    assert_eq!(trace(42), trace(42));
    assert_ne!(trace(42), trace(43));
}

#[test]
fn observations_and_reports_do_not_affect_future() {
    let mut observed = Simulation::new(config(42, 7, 3, 4)).unwrap();
    let mut unobserved = observed.clone();
    for _ in 0..128 {
        let before = observed.clone();
        for _ in 0..5 {
            let _ = (
                observed.config(),
                observed.world(),
                observed.tick(),
                observed.rng_state(),
            );
        }
        assert_eq!(observed, before);
        let mut report = observed.advance_one_tick().unwrap();
        report.tick = 0;
        report.phases.reverse();
        unobserved.advance_one_tick().unwrap();
        assert_eq!(observed, unobserved);
    }
}

#[test]
fn base_climate_is_static_and_observational() {
    let mut observed = Simulation::new(config(42, 7, 48, 0)).unwrap();
    let mut unobserved = observed.clone();
    let original = observed.world().climate().clone();
    let rng = observed.rng_state();
    let other = Simulation::new(config(43, 7, 48, 0)).unwrap();
    assert_eq!(observed.world().climate(), other.world().climate());
    assert_ne!(rng, other.rng_state());
    for _ in 0..128 {
        let before = observed.clone();
        let t = observed.world().topology();
        for y in 0..48 {
            let _ = observed.world().climate().base_at(t.cell(0, y));
        }
        observed
            .world()
            .climate()
            .write_json(&mut Vec::new())
            .unwrap();
        assert_eq!(observed, before);
        observed.advance_one_tick().unwrap();
        unobserved.advance_one_tick().unwrap();
        assert_eq!(observed, unobserved);
        assert_eq!(observed.world().climate(), &original);
    }
}

use evosim::{config::Config, organism::Kind, simulation::Simulation};
fn simulation(seed: u64, plants: usize, extra: &str) -> Simulation {
    Simulation::new(Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":7,"height":5}},"initial":{{"plants":{plants},"herbivores":2,"carnivores":1}}{extra}}}"#)).unwrap()).unwrap()
}
#[test]
fn zero_plants_with_animals_stay_zero_for_2200_ticks_across_seeds() {
    for seed in [0, 1, 42, u64::MAX] {
        let mut s = simulation(seed, 0, "");
        let initial_rng = s.rng_state();
        for tick in 1..=2200 {
            s.advance_one_tick().unwrap();
            assert_eq!(s.tick(), tick);
            assert_eq!(s.population().counts().get(Kind::Plant), 0);
            assert_eq!(s.population().totals().births.get(Kind::Plant), 0);
            assert_eq!(s.population().totals().initial.get(Kind::Plant), 0);
        }
        assert_eq!(s.world().temporal_climate().tick(), 2200);
        assert_ne!(initial_rng, s.rng_state());
    }
}
#[test]
fn public_production_births_have_bounded_positions_lineage_and_replay() {
    let mut observed_birth = false;
    for seed in [0, 1, 42, 99] {
        let mut s = simulation(seed, 1, r#", "genetics":{"mutation_per_million":0}"#);
        let mut replay = s.clone();
        let mut seen = std::collections::BTreeMap::new();
        for o in s.population().iter() {
            seen.insert(o.id(), (o.position(), o.generation(), *o.genome()));
        }
        for _ in 0..80 {
            s.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
            assert_eq!(s, replay);
            let mut sites = std::collections::HashSet::new();
            for o in s.population().iter().filter(|o| o.kind() == Kind::Plant) {
                assert!(sites.insert(o.position()));
                if o.birth_tick() == s.tick() {
                    observed_birth = true;
                    let (pos, generation, dna) = seen[&o.parents()[0]];
                    let dx = pos.x().abs_diff(o.position().x());
                    let dy = pos.y().abs_diff(o.position().y());
                    assert!(dx.min(7 - dx).max(dy.min(5 - dy)) <= 3);
                    assert_eq!(o.generation(), generation + 1);
                    assert_eq!(*o.genome(), dna);
                    assert_eq!(o.age(), 0);
                    assert_eq!(o.energy(), 10.);
                }
                seen.insert(o.id(), (o.position(), o.generation(), *o.genome()));
            }
        }
    }
    assert!(observed_birth);
}
#[test]
fn high_cost_disables_reproduction_and_preserves_empty_continuation() {
    let mut s = simulation(42, 1, r#", "plants":{"reproduction_energy":1001}"#);
    for _ in 0..2200 {
        s.advance_one_tick().unwrap();
    }
    assert_eq!(s.population().counts().get(Kind::Plant), 0);
    assert_eq!(s.population().totals().births.get(Kind::Plant), 0);
    for _ in 0..100 {
        s.advance_one_tick().unwrap();
    }
    assert_eq!(s.population().iter().count(), 0);
}

use evosim::{
    config::Config,
    organism::Kind,
    resources::ResourceError,
    simulation::{Simulation, SimulationError},
    topology::Topology,
};

fn world(w: usize, h: usize, n: usize) -> Simulation {
    Simulation::new(Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{n},"herbivores":{n},"carnivores":{n}}}}}"#)).unwrap()).unwrap()
}
#[test]
fn founders_filters_seams_order_and_observation_purity() {
    for (w, h) in [(1, 1), (1, 7), (8, 1), (2, 2), (7, 4), (64, 48)] {
        let sim = world(w, h, 2 * w * h);
        let before = sim.clone();
        let t = sim.world().topology();
        let foreign = Topology::new(999, 999).unwrap();
        for center in [
            t.cell(0, 0),
            t.cell(-1, -1),
            t.cell(-123 * w as i128, 98 * h as i128),
            foreign.cell(998, 997),
        ] {
            for radius in [0, 1, 2, 4, usize::MAX] {
                for kind in [
                    None,
                    Some(Kind::Plant),
                    Some(Kind::Herbivore),
                    Some(Kind::Carnivore),
                ] {
                    let expected: Vec<_> = sim
                        .population()
                        .iter()
                        .filter(|o| {
                            let dx = o.position().x().abs_diff(center.x() % w);
                            let dy = o.position().y().abs_diff(center.y() % h);
                            dx.min(w - dx).max(dy.min(h - dy)) <= radius
                                && kind.is_none_or(|k| o.kind() == k)
                        })
                        .map(|o| o.id())
                        .collect();
                    let found = sim.population().nearby(center, radius, kind);
                    assert_eq!(found, expected);
                    assert!(found.windows(2).all(|x| x[0] < x[1]));
                    assert_eq!(found, sim.population().nearby(center, radius, kind));
                }
            }
        }
        assert_eq!(sim, before); // includes complete RNG, DNA, vitals, counts and index
    }
}
#[test]
fn empty_and_old_age_removed_from_queries() {
    // Isolate founder expiry; offspring have their own spatial insertion tests.
    let mut value: serde_json::Value =
        serde_json::from_str(&world(3, 2, 2).config().to_json().unwrap()).unwrap();
    value["plants"]["reproduction_energy"] = serde_json::json!(1001);
    let mut sim = Simulation::new(Config::from_json(&value.to_string()).unwrap()).unwrap();
    let t = sim.world().topology();
    for _ in 0..1100 {
        sim.advance_one_tick().unwrap();
    }
    assert!(
        sim.population()
            .nearby(t.cell(0, 0), usize::MAX, None)
            .is_empty()
    );
    assert!(
        world(1, 1, 0)
            .population()
            .nearby(t.cell(0, 0), usize::MAX, None)
            .is_empty()
    );
}
#[test]
fn dense_capacity_error_propagates_through_simulation() {
    let config=Config::from_json(&format!(r#"{{"seed":1,"world":{{"width":{},"height":1}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}}}}"#,usize::MAX)).unwrap();
    assert_eq!(
        Simulation::new(config),
        // Resources are now constructed before the spatial cache, so the
        // first checked dense-allocation failure is reported here.
        Err(SimulationError::Resources(ResourceError))
    );
}

use evosim::{
    config::Config,
    genome::Genome,
    organism::{DeathCause, ENERGY_CAPACITY, Kind},
    simulation::Simulation,
};
fn simulation(seed: u64, width: usize, height: usize, counts: [usize; 3]) -> Simulation {
    // Isolate founder lifetime/accounting from animal recruitment.
    let [p, h, c] = counts;
    let config = Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{width},"height":{height}}},"initial":{{"plants":{p},"herbivores":{h},"carnivores":{c}}},"animals":{{"movement_cost":0,"reproduction_energy":1001}}}}"#)).unwrap();
    Simulation::new(config).unwrap()
}
#[test]
fn exact_initial_records_and_row_major_placement() {
    for (w, h, counts) in [(1, 1, [0, 0, 0]), (1, 1, [2, 3, 4]), (3, 2, [4, 2, 3])] {
        let sim = simulation(42, w, h, counts);
        let p = sim.population();
        assert_eq!(p.iter().count(), counts.iter().sum::<usize>());
        assert!(p.death_records().is_empty());
        for (kind, n) in Kind::ALL.into_iter().zip(counts) {
            assert_eq!(p.counts().get(kind), n as u128);
            assert_eq!(p.totals().initial.get(kind), n as u128);
            assert_eq!(p.totals().births.get(kind), 0);
            assert_eq!(p.totals().deaths.get(kind), 0);
        }
        for (i, o) in p.iter().enumerate() {
            let expected = if i < counts[0] {
                Kind::Plant
            } else if i < counts[0] + counts[1] {
                Kind::Herbivore
            } else {
                Kind::Carnivore
            };
            assert_eq!(o.kind(), expected);
            assert_eq!(o.id().value(), i as u64 + 1);
            assert_eq!(p.get(o.id()), Some(o));
            assert_eq!(
                o.position(),
                sim.world()
                    .topology()
                    .cell((i % w) as i128, ((i / w) % h) as i128)
            );
            assert_eq!((o.age(), o.generation(), o.birth_tick()), (0, 0, 0));
            assert!(o.parents().is_empty());
            assert_eq!(o.traits(), Genome::founder().traits());
            assert_eq!(o.genome().alleles(), &[32768; 12]);
            assert_eq!(
                (o.energy(), o.health()),
                (ENERGY_CAPACITY, 10. + 90. * (32768. / 65535.))
            );
        }
    }
}
#[test]
fn multi_seed_2200_tick_founder_expiry_accounting_and_full_state_replay() {
    for seed in [0, 1, 42, u64::MAX] {
        let mut a = simulation(seed, 3, 2, [3, 2, 1]);
        let mut b = a.clone();
        let ids: Vec<_> = a.population().iter().map(|o| o.id()).collect();
        for tick in 1..=2200 {
            let before = a.clone();
            for o in a.population().iter() {
                let _ = (
                    o.id(),
                    o.kind(),
                    o.position(),
                    o.age(),
                    o.energy(),
                    o.health(),
                    o.traits(),
                    o.parents(),
                    o.generation(),
                    o.birth_tick(),
                );
            }
            let _ = (
                a.population().totals(),
                a.population().counts(),
                a.population().death_records(),
            );
            assert_eq!(a, before);
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
            assert_eq!(a, b);
            let p = a.population();
            for kind in Kind::ALL {
                let t = p.totals();
                assert_eq!(
                    t.initial.get(kind) + t.births.get(kind) - t.deaths.get(kind),
                    p.counts().get(kind)
                );
                if kind != Kind::Plant {
                    assert_eq!(t.births.get(kind), 0);
                }
                let causes: u128 = DeathCause::ALL
                    .into_iter()
                    .map(|cause| p.deaths_by_cause(kind, cause))
                    .sum();
                assert_eq!(causes, t.deaths.get(kind));
            }
            for o in p.iter() {
                assert_eq!(o.age(), tick - o.birth_tick());
                if o.birth_tick() > 0 {
                    assert_eq!(o.parents().len(), 1);
                    assert!(o.generation() > 0);
                    assert!(o.parents()[0] < o.id());
                }
                assert!(o.energy() > 0. && o.energy() <= ENERGY_CAPACITY);
                assert!(o.health() > 0. && o.health() <= o.traits().max_health());
                if o.kind() != Kind::Plant {
                    assert_eq!(o.health(), o.traits().max_health());
                }
            }
            assert_eq!(
                p.death_records().len() + p.iter().count(),
                6 + p.totals().births.get(Kind::Plant) as usize
            );
            if tick >= 1100 {
                for id in &ids {
                    assert!(p.get(*id).is_none());
                }
            }
        }
    }
}

#[test]
fn herbivore_founder_old_age_with_small_positive_upkeep() {
    let mut s = Simulation::new(Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":1,"carnivores":0},"animals":{"movement_cost":0,"basal_cost":0.000001}}"#).unwrap()).unwrap();
    for tick in 1..=1100 {
        s.advance_one_tick().unwrap();
        assert_eq!(
            s.population().counts().get(Kind::Herbivore),
            u128::from(tick < 1100)
        );
    }
    assert_eq!(
        s.population()
            .deaths_by_cause(Kind::Herbivore, DeathCause::OldAge),
        1
    );
}

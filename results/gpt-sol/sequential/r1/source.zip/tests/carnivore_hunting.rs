use evosim::{
    config::Config,
    organism::{DeathCause, Kind},
    simulation::Simulation,
};
#[test]
fn public_actual_ticks_show_predation_and_absorbing_starvation_without_prey() {
    let mut predation = 0;
    for seed in 0..32 {
        let mut s=Simulation::new(Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":1,"carnivores":1}},"animals":{{"movement_cost":0,"basal_cost":300}}}}"#)).unwrap()).unwrap();
        s.advance_one_tick().unwrap();
        predation += s
            .population()
            .deaths_by_cause(Kind::Herbivore, DeathCause::Predation);
    }
    assert!(predation > 0 && predation < 32);
    let mut s=Simulation::new(Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":2},"animals":{"basal_cost":2,"movement_cost":0,"reproduction_energy":1001}}"#).unwrap()).unwrap();
    let mut replay = s.clone();
    // Isolate the fixed two-founder starvation ledger from paid reproduction.
    let mut last = 1000.;
    for _ in 0..2200 {
        s.advance_one_tick().unwrap();
        replay.advance_one_tick().unwrap();
        assert_eq!(s, replay);
        for o in s.population().iter() {
            assert!(o.energy() < last);
        }
        last = s.population().iter().next().map_or(0., |o| o.energy());
    }
    assert_eq!(s.population().counts().get(Kind::Carnivore), 0);
    assert_eq!(
        s.population()
            .deaths_by_cause(Kind::Carnivore, DeathCause::Starvation),
        2
    );
    assert_eq!(s.population().totals().births.get(Kind::Carnivore), 0);
}
#[test]
fn no_prey_low_upkeep_preserves_old_age_priority() {
    let mut s=Simulation::new(Config::from_json(r#"{"seed":0,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":1},"animals":{"basal_cost":0.000001,"movement_cost":0}}"#).unwrap()).unwrap();
    for _ in 0..1100 {
        s.advance_one_tick().unwrap();
    }
    assert_eq!(
        s.population()
            .deaths_by_cause(Kind::Carnivore, DeathCause::OldAge),
        1
    );
}

#[path = "../examples/support/ecology.rs"]
mod ecology;
use ecology::{Observer, fixed, run};
use evosim::{organism::Kind, simulation::Simulation};

#[test]
fn default_plants_replace_founders_and_herbivores_keep_recruiting() {
    for seed in [0, 1, 42] {
        for (counts, horizon) in [([400, 0, 0], 2200), ([2000, 120, 0], 600)] {
            let mut s = Simulation::new(fixed(seed, counts)).unwrap();
            let mut observer = Observer::default();
            observer.audit(&s);
            let mut births_at_300 = 0;
            for _ in 0..horizon {
                s.advance_one_tick().unwrap();
                observer.audit(&s);
                assert!(
                    s.population().counts().plants() > 0,
                    "plants seed={seed} tick={}",
                    s.tick()
                );
                if counts[1] > 0 {
                    assert!(s.population().counts().herbivores() > 0);
                    if s.tick() == 300 {
                        births_at_300 = s.population().totals().births.herbivores();
                        assert!(births_at_300 > 0);
                    }
                }
            }
            assert!(s.population().totals().births.plants() > 0);
            let kind = if counts[1] > 0 {
                Kind::Herbivore
            } else {
                Kind::Plant
            };
            assert!(
                s.population()
                    .iter()
                    .any(|o| o.kind() == kind && o.generation() > 0)
            );
            if counts[1] > 0 {
                assert!(s.population().totals().births.herbivores() > births_at_300);
            }
            eprintln!(
                "viability seed={seed} counts={counts:?}: {}",
                observer.result(&s)
            );
        }
    }
}
#[test]
fn food_removal_causes_final_extinction_with_empty_tail() {
    for seed in [0, 1, 42] {
        let absent_plants = run(fixed(seed, [0, 120, 20]), 5000).unwrap();
        let h = absent_plants["kinds"]["herbivores"]["first_zero_tick"]
            .as_u64()
            .unwrap();
        let c = absent_plants["kinds"]["carnivores"]["first_zero_tick"]
            .as_u64()
            .unwrap();
        assert!(h > 0 && h < c && c < 5000);
        eprintln!("no plants seed={seed}: herbivores extinct {h}, carnivores extinct {c}");
        let absent_herbivores = run(fixed(seed, [400, 0, 20]), 5000).unwrap();
        assert_eq!(
            absent_herbivores["kinds"]["herbivores"]["first_zero_tick"],
            0
        );
        assert!(
            absent_herbivores["kinds"]["carnivores"]["first_zero_tick"]
                .as_u64()
                .unwrap()
                < 5000
        );
    }
    let empty = run(fixed(42, [0, 0, 0]), 1000).unwrap();
    assert_eq!(empty["tick_end"], 1000);
    for name in ecology::NAMES {
        assert_eq!(empty["kinds"][name]["first_zero_tick"], 0);
        assert_eq!(empty["kinds"][name]["births"], 0);
    }
}
#[test]
fn fixed_keys_1000_tick_replay_and_observation_purity() {
    let config = fixed(42, [400, 120, 20]);
    let mut a = Simulation::new(config.clone()).unwrap();
    let mut b = Simulation::new(config).unwrap();
    let mut observer = Observer::default();
    observer.audit(&a);
    for tick in 1..=1000 {
        let report = a.advance_one_tick().unwrap();
        assert_eq!(report.tick, tick);
        assert_eq!(report.phases, evosim::simulation::TICK_PHASES);
        b.advance_one_tick().unwrap();
        observer.audit(&a);
        assert_eq!(a, b);
    }
    assert_eq!(a.population().totals().initial.get(Kind::Plant), 400);
}

#[test]
fn naturally_extinct_plants_never_return() {
    let c = evosim::config::Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#).unwrap();
    let r = run(c, 2200).unwrap();
    let zero = r["kinds"]["plants"]["first_zero_tick"].as_u64().unwrap();
    assert!(zero > 0 && zero < 2200);
    assert_eq!(r["kinds"]["plants"]["survived"], false);
    assert_eq!(r["tick_end"], 2200);
}

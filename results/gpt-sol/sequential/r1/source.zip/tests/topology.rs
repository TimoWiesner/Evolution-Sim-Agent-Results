use evosim::topology::{Cell, Displacement, Topology, TopologyError};
use std::collections::HashSet;

fn xy(cell: Cell) -> (usize, usize) {
    (cell.x(), cell.y())
}

// Independent oracle: direct unsigned separations, no signed/remainder algorithm.
fn oracle(a: Cell, b: Cell, width: usize, height: usize) -> usize {
    let dx = a.x().abs_diff(b.x());
    let dy = a.y().abs_diff(b.y());
    dx.min(width - dx).max(dy.min(height - dy))
}

#[test]
fn validates_dimensions_without_allocating() {
    assert_eq!(Topology::new(0, 1), Err(TopologyError::ZeroWidth));
    assert_eq!(Topology::new(1, 0), Err(TopologyError::ZeroHeight));
    assert_eq!(
        Topology::new(usize::MAX, 2),
        Err(TopologyError::AreaOverflow)
    );
    for error in [
        TopologyError::ZeroWidth,
        TopologyError::ZeroHeight,
        TopologyError::AreaOverflow,
    ] {
        let dynamic: &dyn std::error::Error = &error;
        assert!(!dynamic.to_string().is_empty());
    }
    let t = Topology::new(usize::MAX, 1).unwrap();
    assert_eq!(
        (t.width(), t.height(), t.area()),
        (usize::MAX, 1, usize::MAX)
    );
    let half = usize::MAX / 2;
    assert_eq!(t.distance(t.cell(0, 0), t.cell(half as i128, 0)), half);
    assert_eq!(t.displacement(t.cell(0, 0), t.cell(-1, 0)).dx, -1);
    // Taking a prefix proves construction is lazy even for a full huge world.
    assert_eq!(
        t.cells_within(t.cell(-1, 0), usize::MAX)
            .take(3)
            .map(xy)
            .collect::<Vec<_>>(),
        vec![(0, 0), (1, 0), (2, 0)]
    );
    assert_eq!(
        t.cells_within(t.cell(-1, 0), 1).map(xy).collect::<Vec<_>>(),
        vec![(usize::MAX - 2, 0), (usize::MAX - 1, 0), (0, 0)]
    );
}

#[test]
fn wraps_edges_corners_negative_and_multiple_turns() {
    let t = Topology::new(7, 4).unwrap();
    for (input, expected) in [
        ((-1, 2), (6, 2)),
        ((7, 2), (0, 2)),
        ((3, -1), (3, 3)),
        ((3, 4), (3, 0)),
        ((-1, -1), (6, 3)),
        ((7, -1), (0, 3)),
        ((-1, 4), (6, 0)),
        ((7, 4), (0, 0)),
        ((-22, -13), (6, 3)),
        ((29, 18), (1, 2)),
        ((-21, -12), (0, 0)),
        ((0, 0), (0, 0)),
        ((i128::MIN, i128::MIN), (5, 0)),
        ((i128::MAX, i128::MAX), (1, 3)),
    ] {
        assert_eq!(xy(t.cell(input.0, input.1)), expected, "{input:?}");
    }
    for x in -50..=50 {
        for y in -30..=30 {
            let c = t.cell(x, y);
            assert!(c.x() < 7 && c.y() < 4);
            assert_eq!(t.cell(c.x() as i128, c.y() as i128), c);
        }
    }
}

#[test]
fn shortest_seams_diagonals_and_positive_half_ties() {
    let t = Topology::new(7, 4).unwrap();
    for (target, expected) in [
        ((6, 0), (-1, 0)),
        ((0, 3), (0, -1)),
        ((6, 3), (-1, -1)),
        ((1, 1), (1, 1)),
        ((0, 0), (0, 0)),
    ] {
        let delta = t.displacement(t.cell(0, 0), t.cell(target.0, target.1));
        assert_eq!(
            delta,
            Displacement {
                dx: expected.0,
                dy: expected.1
            }
        );
        assert_eq!(
            t.distance(t.cell(0, 0), t.cell(target.0, target.1)),
            expected.0.abs().max(expected.1.abs()) as usize
        );
    }
    let t = Topology::new(4, 6).unwrap();
    let a = t.cell(0, 0);
    let b = t.cell(2, 3);
    assert_eq!(t.displacement(a, b), Displacement { dx: 2, dy: 3 });
    assert_eq!(t.displacement(b, a), Displacement { dx: 2, dy: 3 });
    assert_eq!(t.distance(a, b), 3);
}

#[test]
fn radius_order_thresholds_and_large_radii() {
    let t = Topology::new(7, 4).unwrap();
    let c = t.cell(0, 0);
    assert_eq!(t.cells_within(c, 0).collect::<Vec<_>>(), vec![c]);
    assert_eq!(
        t.cells_within(c, 1).map(xy).collect::<Vec<_>>(),
        vec![
            (6, 3),
            (0, 3),
            (1, 3),
            (6, 0),
            (0, 0),
            (1, 0),
            (6, 1),
            (0, 1),
            (1, 1)
        ]
    );
    let expected: Vec<_> = (0..4)
        .flat_map(|y| [5, 6, 0, 1, 2].map(|x| (x, y)))
        .collect();
    assert_eq!(t.cells_within(c, 2).map(xy).collect::<Vec<_>>(), expected);
    let full: Vec<_> = (0..4).flat_map(|y| (0..7).map(move |x| (x, y))).collect();
    for r in [3, 7, 400, usize::MAX] {
        assert_eq!(t.cells_within(c, r).map(xy).collect::<Vec<_>>(), full);
    }
    let small = Topology::new(2, 3).unwrap();
    assert_eq!(small.cells_within(small.cell(1, 2), usize::MAX).count(), 6);
    let mut iter = small.cells_within(small.cell(1, 2), usize::MAX);
    assert_eq!(iter.by_ref().count(), 6);
    assert_eq!(iter.next(), None);
    assert_eq!(iter.next(), None);
}

#[test]
fn degenerate_worlds_and_foreign_cells() {
    let singleton = Topology::new(1, 1).unwrap();
    let only = singleton.cell(i128::MIN, i128::MAX);
    assert_eq!(xy(only), (0, 0));
    assert_eq!(
        singleton.displacement(only, only),
        Displacement { dx: 0, dy: 0 }
    );
    assert_eq!(singleton.distance(only, only), 0);
    for r in [0, 1, 900, usize::MAX] {
        assert_eq!(
            singleton.cells_within(only, r).collect::<Vec<_>>(),
            vec![only]
        );
    }
    for (w, h) in [(1, 7), (7, 1), (2, 2)] {
        let t = Topology::new(w, h).unwrap();
        assert_eq!(t.distance(t.cell(0, 0), t.cell(-1, -1)), 1);
        assert_eq!(t.cells_within(t.cell(-1, -1), usize::MAX).count(), w * h);
    }
    let large = Topology::new(99, 99).unwrap();
    let t = Topology::new(7, 4).unwrap();
    let a = large.cell(98, 98);
    let b = large.cell(75, 80);
    let normalized_a = t.cell(98, 98);
    let normalized_b = t.cell(75, 80);
    assert_eq!(
        t.displacement(a, b),
        t.displacement(normalized_a, normalized_b)
    );
    assert_eq!(t.distance(a, b), t.distance(normalized_a, normalized_b));
    for r in [0, 1, usize::MAX] {
        assert_eq!(
            t.cells_within(a, r).collect::<Vec<_>>(),
            t.cells_within(normalized_a, r).collect::<Vec<_>>()
        );
    }
}

#[test]
fn exhaustive_small_world_distance_and_displacement_oracle() {
    for w in 1..=8 {
        for h in 1..=8 {
            let t = Topology::new(w, h).unwrap();
            let cells: Vec<_> = t.cells_within(t.cell(0, 0), usize::MAX).collect();
            for &a in &cells {
                for &b in &cells {
                    let d = t.distance(a, b);
                    assert_eq!(d, oracle(a, b, w, h));
                    assert_eq!(d, t.distance(b, a));
                    assert_eq!(d == 0, a == b);
                    let delta = t.displacement(a, b);
                    assert_eq!(
                        t.cell(a.x() as i128 + delta.dx, a.y() as i128 + delta.dy),
                        b
                    );
                    assert_eq!(delta.dx.abs().max(delta.dy.abs()) as usize, d);
                    let half_tie = (w % 2 == 0 && a.x().abs_diff(b.x()) == w / 2)
                        || (h % 2 == 0 && a.y().abs_diff(b.y()) == h / 2);
                    let reverse = t.displacement(b, a);
                    if !half_tie {
                        assert_eq!((delta.dx, delta.dy), (-reverse.dx, -reverse.dy));
                    }
                }
            }
        }
    }
}

#[test]
fn exhaustive_radius_membership_and_uniqueness_oracle() {
    for w in 1..=8 {
        for h in 1..=8 {
            let t = Topology::new(w, h).unwrap();
            let cells: Vec<_> = (0..h)
                .flat_map(|y| (0..w).map(move |x| t.cell(x as i128, y as i128)))
                .collect();
            for &center in &cells {
                for radius in (0..=10).chain([usize::MAX]) {
                    let actual: Vec<_> = t.cells_within(center, radius).collect();
                    let unique: HashSet<_> = actual.iter().copied().collect();
                    let expected: HashSet<_> = cells
                        .iter()
                        .copied()
                        .filter(|&c| oracle(center, c, w, h) <= radius)
                        .collect();
                    assert_eq!(actual.len(), unique.len(), "duplicate {w}x{h} r={radius}");
                    assert_eq!(unique, expected, "{w}x{h} center={center:?} r={radius}");
                    assert!(unique.contains(&center));
                    assert!(actual.iter().all(|c| c.x() < w && c.y() < h));
                    assert_eq!(actual, t.cells_within(center, radius).collect::<Vec<_>>());
                }
            }
        }
    }
}

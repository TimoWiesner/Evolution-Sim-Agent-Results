use evosim::{
    config::Config,
    organism::{DeathCause, Kind},
    simulation::Simulation,
};
#[test]
fn favorable_plants_survive_to_old_age_and_zero_plants_stay_extinct() {
    for plants in [0, 6] {
        let config = Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":3,"height":2}},"initial":{{"plants":{plants},"herbivores":0,"carnivores":0}},"plants":{{"reproduction_energy":1001}},"climate":{{"season_temperature_amplitude":0,"season_precipitation_amplitude":0,"weather_amplitude":0}}}}"#)).unwrap();
        let mut sim = Simulation::new(config).unwrap();
        let rng = sim.rng_state();
        for tick in 1..=2200 {
            sim.advance_one_tick().unwrap();
            assert_eq!(
                sim.population().counts().get(Kind::Plant),
                if tick < 1100 { plants } else { 0 }
            );
            assert_eq!(sim.population().totals().births.get(Kind::Plant), 0);
        }
        assert_eq!(
            sim.population()
                .deaths_by_cause(Kind::Plant, DeathCause::OldAge),
            plants
        );
        assert_eq!(sim.rng_state(), rng);
        assert_eq!(sim.world().temporal_climate().tick(), 2200);
    }
}

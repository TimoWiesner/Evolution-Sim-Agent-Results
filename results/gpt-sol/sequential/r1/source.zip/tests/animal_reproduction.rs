use evosim::{config::Config, organism::Kind, simulation::Simulation};
#[test]
fn solitary_animals_never_reproduce_over_2200_ticks_and_extinction_is_absorbing() {
    for (herbs, carns, kind) in [(1, 0, Kind::Herbivore), (0, 1, Kind::Carnivore)] {
        let mut s=Simulation::new(Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":{herbs},"carnivores":{carns}}},"animals":{{"movement_cost":0,"basal_cost":0.000001}}}}"#)).unwrap()).unwrap();
        let mut replay = s.clone();
        for tick in 1..=2200 {
            s.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
            assert_eq!(s, replay);
            assert_eq!(s.population().totals().births.get(kind), 0);
            if tick >= 1100 {
                assert_eq!(s.population().counts().get(kind), 0);
            }
        }
    }
}
#[test]
fn public_ticks_produce_paid_two_parent_children_for_both_kinds_and_replay() {
    for (herbs, carns, kind) in [(2, 0, Kind::Herbivore), (0, 2, Kind::Carnivore)] {
        let mut s=Simulation::new(Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":{herbs},"carnivores":{carns}}},"animals":{{"movement_cost":0,"basal_cost":0.000001}}}}"#)).unwrap()).unwrap();
        let parents: Vec<_> = s.population().iter().map(|o| o.id()).collect();
        let mut replay = s.clone();
        let mut found = false;
        for _ in 0..200 {
            let before: Vec<_> = parents
                .iter()
                .map(|id| s.population().get(*id).unwrap().energy())
                .collect();
            s.advance_one_tick().unwrap();
            replay.advance_one_tick().unwrap();
            assert_eq!(s, replay);
            if let Some(c) = s.population().iter().find(|o| o.generation() == 1) {
                assert_eq!(c.parents(), parents.as_slice());
                assert_eq!(c.age(), 0);
                assert_eq!(c.energy(), 30.);
                assert_eq!(c.last_reproduction_tick(), None);
                for (i, id) in parents.iter().enumerate() {
                    let p = s.population().get(*id).unwrap();
                    assert!(p.energy() <= before[i] - 30.);
                    assert_eq!(p.last_reproduction_tick(), Some(c.birth_tick()));
                }
                found = true;
                break;
            }
        }
        assert!(found, "no production birth for {kind:?}");
    }
}

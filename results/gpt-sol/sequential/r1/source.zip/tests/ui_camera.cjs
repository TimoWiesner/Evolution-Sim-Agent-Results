'use strict';
const assert=require('node:assert/strict'),C=require('../ui/camera.js');
for(let w=1;w<=100;w+=7)for(let h=1;h<=80;h+=9){const c=C.fit(w,h,1000,700);assert(c.x>=0&&c.y>=0);assert(c.x+w*c.scale<=1000);for(let x=-5;x<100;x+=7){const p=C.worldToScreen(c,x,3),q=C.screenToWorld(c,p.x,p.y);assert(Math.abs(q.x-x)<1e-10);const z=C.zoomAt(c,260,210,1.8),before=C.screenToWorld(c,260,210),after=C.screenToWorld(z,260,210);assert(Math.abs(before.x-after.x)<1e-10);assert(Math.abs(before.y-after.y)<1e-10);}}
assert.equal(C.zoomAt({x:0,y:0,scale:1},0,0,1e99).scale,160);assert.equal(C.zoomAt({x:0,y:0,scale:1},0,0,1e-99).scale,.01);
console.log('PASS camera round trips, fit, anchor and bounds');

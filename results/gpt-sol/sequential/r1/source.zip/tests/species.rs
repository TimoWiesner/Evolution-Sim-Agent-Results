use evosim::{config::Config, organism::Kind, population::Population, simulation::Simulation};
use std::collections::{BTreeMap, BTreeSet};
fn oracle(p: &Population) {
    let mut members = BTreeMap::new();
    for o in p.iter() {
        let record = p
            .species()
            .get(o.species_id())
            .expect("every organism assigned");
        assert_eq!(record.kind(), o.kind());
        assert_eq!(record.extinction_tick(), None);
        assert!(10 * o.genome().distance_sum(record.founder_genome()) <= 786420);
        *members.entry(o.species_id()).or_insert(0u128) += 1;
    }
    for record in p.species().iter() {
        assert_eq!(
            record.living_members(),
            *members.get(&record.id()).unwrap_or(&0)
        );
        let prefix = match record.kind() {
            Kind::Plant => "plant",
            Kind::Herbivore => "herbivore",
            Kind::Carnivore => "carnivore",
        };
        assert_eq!(record.name(), format!("{prefix}-{}", record.id().value()));
    }
    for kind in Kind::ALL {
        let ids: BTreeSet<_> = p
            .iter()
            .filter(|o| o.kind() == kind)
            .map(|o| o.species_id())
            .collect();
        assert_eq!(p.species().living_count(kind), ids.len());
    }
}
#[test]
fn initial_membership_absent_kinds_and_queries_are_pure() {
    for counts in [[0, 0, 0], [4, 0, 0], [0, 4, 0], [0, 0, 4], [4, 3, 2]] {
        let config=Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":4,"height":4}},"initial":{{"plants":{},"herbivores":{},"carnivores":{}}}}}"#,counts[0],counts[1],counts[2])).unwrap();
        let s = Simulation::new(config).unwrap();
        let before = s.clone();
        oracle(s.population());
        oracle(s.population());
        assert_eq!(s, before);
        let mut first_id = 1;
        for (kind, n) in Kind::ALL.into_iter().zip(counts) {
            assert_eq!(
                s.population().species().living_count(kind),
                usize::from(n > 0)
            );
            if n > 0 {
                let r = s
                    .population()
                    .species()
                    .iter()
                    .find(|r| r.kind() == kind)
                    .unwrap();
                assert_eq!(r.id().value(), first_id);
                assert_eq!(r.parent_species(), None);
                assert_eq!(r.origin_tick(), 0);
            }
            first_id += n as u64;
        }
    }
}
#[test]
fn four_seed_2200_tick_full_replay_membership_and_absorbing_extinction() {
    for seed in [0, 1, 42, u64::MAX] {
        let config=Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":8,"height":6}},"initial":{{"plants":12,"herbivores":6,"carnivores":2}}}}"#)).unwrap();
        let mut a = Simulation::new(config.clone()).unwrap();
        let mut b = Simulation::new(config).unwrap();
        for _ in 0..2200 {
            oracle(a.population());
            let before = a.clone();
            oracle(a.population());
            assert_eq!(a, before);
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
            assert_eq!(a, b);
            for r in a.population().species().iter() {
                if let Some(t) = r.extinction_tick() {
                    assert!(t <= a.tick());
                    assert_eq!(r.living_members(), 0);
                }
            }
        }
        oracle(a.population());
    }
    let config=Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":2,"carnivores":2}}"#).unwrap();
    let mut a = Simulation::new(config).unwrap();
    for _ in 0..2200 {
        a.advance_one_tick().unwrap();
        oracle(a.population());
    }
    assert!(a.population().iter().next().is_none());
    assert!(
        a.population()
            .species()
            .iter()
            .all(|r| r.extinction_tick().is_some())
    );
    let old = a.population().species().clone();
    for _ in 0..10 {
        a.advance_one_tick().unwrap();
        assert_eq!(a.population().species(), &old);
    }
}

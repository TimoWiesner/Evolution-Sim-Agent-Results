#[path = "../examples/support/performance.rs"]
mod performance;
#[test]
#[ignore = "release performance guard; invoked explicitly by test.sh"]
fn release_engine_avoids_catastrophic_slowdown() {
    assert!(!cfg!(debug_assertions), "run this guard with --release");
    let report = performance::measure(false).unwrap();
    println!("{report}");
    assert!(report["ticks_per_second"].as_f64().unwrap() >= 10.0);
    assert_eq!(report["tick_end"], 1100);
    assert!(report["population_min"].as_u64().unwrap() >= 2000);
}

use evosim::{
    config::Config, resources::RESOURCE_MODEL_VERSION, simulation::Simulation, topology::Topology,
};
#[test]
fn public_resource_queries_are_bounded_wrapped_and_observational() {
    assert_eq!(RESOURCE_MODEL_VERSION, 1);
    let mut sim = Simulation::new(Config::default()).unwrap();
    sim.advance_one_tick().unwrap();
    let before = sim.clone();
    let topology = sim.world().topology();
    for cell in topology.cells_within(topology.cell(0, 0), usize::MAX) {
        let value = sim.world().resources().at(cell);
        assert!(value >= 0. && value <= sim.config().plants().resource_capacity());
    }
    let foreign = Topology::new(1000, 1000).unwrap().cell(65, 49);
    assert_eq!(
        sim.world().resources().at(foreign),
        sim.world().resources().at(topology.cell(1, 1))
    );
    assert_eq!(sim, before);
}

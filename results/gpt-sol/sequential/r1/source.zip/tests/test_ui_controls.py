"""Display-free actual application commands, byte checkpoints, ingress isolation."""
import json
import socket
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from test_ui import ROOT, server, request

class Controls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        subprocess.run(['cargo','build','--locked','--release'],cwd=ROOT,check=True,capture_output=True)

    def test_controls_files_and_rollback_without_display(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target') as temp:
            d=Path(temp);config=d/'config.json'
            config.write_text(json.dumps({'seed':-123456789012345678901234567890,'world':{'width':1,'height':1},'initial':{'plants':5,'herbivores':3,'carnivores':2}}))
            with server(['--config',config]) as url:
                token=url.split('#')[1]
                def frame():return json.loads(request(url,'/api/frame')[1])
                def post(path,data=None,**extra):return request(url,path,'POST',token,{'X-Evosim-Epoch':frame()['epoch'],**extra},data)
                def cmd(name):
                    status,body=post('/api/control/'+name);self.assertEqual(status,200,body);return json.loads(body)
                def save():
                    status,body=post('/api/checkpoint/save');self.assertEqual(status,200,body);return body
                initial=save();self.assertEqual(cmd('pause')['tick'],'0')
                request(url,'/api/ready','POST',token)
                for _ in range(2):
                    before=frame();time.sleep(.12);self.assertEqual(frame(),before)
                    a=cmd('step');self.assertEqual(int(a['tick']),int(before['tick'])+1);self.assertFalse(a['running'])
                for speed in ['slow','normal','fast']:self.assertEqual(cmd('speed/'+speed)['speed'],speed)
                for speed in ['-1','0','300','unknown']:self.assertEqual(post('/api/control/speed/'+speed)[0],400)
                cmd('run');time.sleep(.12);self.assertGreater(int(cmd('pause')['tick']),2)
                for _ in range(2):self.assertEqual(cmd('reset')['tick'],'0');self.assertEqual(save(),initial)
                for id in ['1','6','9']:
                    selected=cmd('select/'+id)['selected'];self.assertEqual(selected['id'],id);self.assertEqual(len(selected['traits']),12);self.assertEqual(selected['genome']['alleles'],[32768]*12)
                self.assertEqual(post('/api/control/select/999999')[0],400)
                before=save();selection=frame()['selected']
                self.assertEqual(post('/api/checkpoint/load',b'broken',**{'Content-Type':'application/octet-stream'})[0],400)
                self.assertEqual(save(),before);self.assertEqual(frame()['selected'],selection)
                unknown=bytearray(before);unknown[17:21]=(999).to_bytes(4,'little')
                self.assertEqual(post('/api/checkpoint/load',bytes(unknown),**{'Content-Type':'application/octet-stream'})[0],400)
                self.assertEqual(save(),before);self.assertEqual(frame()['selected'],selection)
                self.assertEqual(post('/api/checkpoint/load',b'a',**{'Content-Type':'text/plain'})[0],415)
                self.assertEqual(post('/api/checkpoint/load')[0],413)
                self.assertEqual(request(url,'/api/control/step','POST',token,{'X-Evosim-Epoch':'0'})[0],409)
                self.assertEqual(request(url,'/api/control/step','POST')[0],403)
                self.assertEqual(request(url,'/api/control/step')[0],403)
                self.assertEqual(request(url,'/api/control/step','GET',token)[0],405)
                config2=d/'other.json';config2.write_text(json.dumps({'seed':29,'world':{'width':7,'height':3},'initial':{'plants':9,'herbivores':0,'carnivores':0}}))
                checkpoint=d/'cli.evo';out=d/'cli.json'
                subprocess.run([str(ROOT/'evosim'),'run','--config',str(config2),'--ticks','17','--out',str(out),'--save',str(checkpoint)],check=True)
                code,body=post('/api/checkpoint/load',checkpoint.read_bytes(),**{'Content-Type':'application/octet-stream'});self.assertEqual(code,200,body)
                self.assertEqual(frame()['tick'],'17');self.assertFalse(frame()['running']);self.assertEqual(save(),checkpoint.read_bytes());self.assertEqual(json.loads(request(url,'/api/world')[1])['width'],7)
                for _ in range(4):cmd('step')
                saved=d/'ui.evo';saved.write_bytes(save())
                subprocess.run([str(ROOT/'evosim'),'run','--load',str(checkpoint),'--ticks','4','--out',str(out),'--save',str(d/'expected.evo')],check=True)
                self.assertEqual(saved.read_bytes(),(d/'expected.evo').read_bytes())
                cmd('reset')
                subprocess.run([str(ROOT/'evosim'),'run','--config',str(config2),'--ticks','0','--out',str(out),'--save',str(d/'fresh.evo')],check=True)
                self.assertEqual(save(),(d/'fresh.evo').read_bytes())

    def test_slow_ingress_and_stale_completion(self):
        with server([]) as url:
            token=url.split('#')[1];host=url.split('/')[2];port=int(host.split(':')[1])
            f=json.loads(request(url,'/api/frame')[1]);epoch=f['epoch']
            # Header-only slow request uses a different connection from controls.
            sock=socket.create_connection(('127.0.0.1',port));sock.settimeout(5)
            try:
                sock.sendall((f'POST /api/checkpoint/load HTTP/1.1\r\nHost: {host}\r\nX-Evosim-Token: {token}\r\nX-Evosim-Epoch: {epoch}\r\nContent-Type: application/octet-stream\r\nContent-Length: 65536\r\nConnection: close\r\n\r\n').encode())
                request(url,'/api/ready','POST',token);time.sleep(.2)
                self.assertGreater(int(json.loads(request(url,'/api/frame')[1])['tick']),0)
                code,body=request(url,'/api/control/reset','POST',token,{'X-Evosim-Epoch':epoch});self.assertEqual(code,200,body)
                sock.sendall(b'x'*65536);reply=sock.recv(4096);self.assertIn(b'409',reply)
                self.assertEqual(json.loads(request(url,'/api/frame')[1])['tick'],'0')
            finally:sock.close()

    def test_ingress_saturation_and_header_limits(self):
        with server([]) as url:
            token=url.split('#')[1];host=url.split('/')[2];port=int(host.split(':')[1]);sockets=[]
            def connect(length):
                sock=socket.create_connection(('127.0.0.1',port));sock.settimeout(2);sockets.append(sock)
                sock.sendall((f'POST /api/checkpoint/load HTTP/1.1\r\nHost: {host}\r\nX-Evosim-Token: {token}\r\nX-Evosim-Epoch: 0\r\nContent-Type: application/octet-stream\r\nContent-Length: {length}\r\nConnection: close\r\n\r\n').encode())
                return sock
            try:
                self.assertIn(b'413',connect(64*1024*1024+1).recv(4096))
                for _ in range(4):connect(65536);time.sleep(.03)
                self.assertIn(b'503',connect(65536).recv(4096))
                code,body=request(url,'/api/control/step','POST',token,{'X-Evosim-Epoch':'0'});self.assertEqual(code,200,body);self.assertEqual(json.loads(body)['tick'],'1')
            finally:
                for sock in sockets:sock.close()

    def test_real_browser_controls_inspection_and_files(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'target',prefix='controls ') as temp:
            d=Path(temp);cfg=d/'config.json';cfg.write_text(json.dumps({'seed':42,'world':{'width':1,'height':1},'initial':{'plants':5,'herbivores':3,'carnivores':2}}))
            other=d/'other.json';other.write_text(json.dumps({'seed':121,'world':{'width':7,'height':3},'initial':{'plants':9,'herbivores':0,'carnivores':0}}))
            checkpoint=d/'other.evo'
            subprocess.run([str(ROOT/'evosim'),'run','--config',str(other),'--ticks','17','--out',str(d/'other-result.json'),'--save',str(checkpoint)],check=True)
            (d/'bad.evo').write_bytes(b'broken')
            with server(['--config',cfg]) as url:
                p=subprocess.run(['node',str(ROOT/'tests/ui_controls.cjs'),url,str(d)],capture_output=True,text=True,timeout=50)
                self.assertEqual(p.returncode,0,p.stderr)
                print(p.stdout.strip())
            downloads=list(d.glob('evosim-tick-*.evo'));self.assertEqual(len(downloads),1)
            subprocess.run([str(ROOT/'evosim'),'run','--load',str(downloads[0]),'--ticks','0','--out',str(d/'download.json')],check=True)
            result=json.loads((d/'download.json').read_text());evidence=json.loads(p.stdout)
            self.assertEqual(result['tick_end'],evidence['saved_tick'])
            subprocess.run([str(ROOT/'evosim'),'run','--load',str(checkpoint),'--ticks','3','--out',str(d/'continued.json'),'--save',str(d/'expected.evo')],check=True)
            self.assertEqual((d/'browser-final.evo').read_bytes(),(d/'expected.evo').read_bytes())

if __name__=='__main__':unittest.main()

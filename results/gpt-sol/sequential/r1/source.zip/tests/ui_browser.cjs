'use strict';
const assert=require('node:assert/strict');const{open}=require('../ui/automation.cjs');
(async()=>{const c=await open(process.argv[2]);try{
await c.wait('window.evosim && evosim.renderedTick !== null');
const initial=await c.evaluate('evosim.initialCount');assert.equal(initial,1000);
const legend=await c.evaluate('document.querySelector("aside").innerText');for(const label of ['Plants','Herbivores','Carnivores','Polar','Tundra','Temperate','Dry','Tropical'])assert(legend.includes(label));
const camera=await c.evaluate('({...evosim.camera})');
const rect=await c.evaluate('(()=>{const r=document.querySelector("canvas").getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()');
const x=rect.x+rect.width/2,y=rect.y+rect.height/2;
await c.send('Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',clickCount:1},c.session);
await c.send('Input.dispatchMouseEvent',{type:'mouseMoved',x:x+60,y:y+30,button:'left',buttons:1},c.session);
await c.send('Input.dispatchMouseEvent',{type:'mouseReleased',x:x+60,y:y+30,button:'left',clickCount:1},c.session);
await c.wait(`evosim.camera.x !== ${camera.x}`);
await c.send('Input.dispatchMouseEvent',{type:'mouseWheel',x,y,deltaX:0,deltaY:-300},c.session);
await c.wait(`evosim.camera.scale > ${camera.scale}`);
await c.evaluate('document.querySelector("#fit").click()');await c.wait(`Math.abs(evosim.camera.scale-${camera.scale})<1e-8 && Math.abs(evosim.camera.x-${camera.x})<1e-8`);
// Actual canvas biome colour probe: fixture cell (0,0) has no markers at its upper corner.
const probe=await c.evaluate(`(()=>{const canvas=document.querySelector('canvas'),c=canvas.getContext('2d'),p=Camera.worldToScreen(evosim.camera,.8,.45),d=devicePixelRatio;return [...c.getImageData(Math.floor(p.x*d),Math.floor(p.y*d),1,1).data]})()`);assert(probe[3]>0);assert.deepEqual(probe.slice(0,3),[103,125,137]);
const start=await c.evaluate('performance.now()');await new Promise(r=>setTimeout(r,5200));
const data=await c.evaluate(`({frames:evosim.frames.filter(f=>f.time>=${start}),draws:evosim.draws,error:evosim.error,camera:evosim.camera})`);
assert.equal(data.error,null);assert.equal(c.errors.length,0);assert(data.frames.length>=16,JSON.stringify(data));
if(process.argv[3]==='stable')assert(data.frames.every(f=>f.count===1000),JSON.stringify(data.frames));
const gaps=data.frames.slice(1).map((f,i)=>f.time-data.frames[i].time).sort((a,b)=>a-b);
const version=await c.send('Browser.getVersion');
console.log(JSON.stringify({mode:process.argv[3],initial,completedFrames:data.frames.length,seconds:5.2,rate:data.frames.length/5.2,p95GapMs:gaps[Math.floor(gaps.length*.95)],first:data.frames[0],last:data.frames.at(-1),probe,browser:version.product,draws:data.draws}));
}finally{await c.close();}})().catch(e=>{console.error(e.stack);process.exitCode=1;});

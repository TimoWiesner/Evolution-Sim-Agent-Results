use evosim::{
    climate::{Biome, CLIMATE_MODEL_VERSION, Climate},
    topology::Topology,
};

#[test]
fn complete_bounded_repeatable_assignment_small_worlds() {
    for w in 1..=32 {
        for h in 1..=32 {
            let t = Topology::new(w, h).unwrap();
            let c = Climate::new(t);
            for y in 0..h {
                for x in 0..w {
                    let b = c.base_at(t.cell(x as i128, y as i128));
                    assert!((0.0..=1.0).contains(&b.temperature()));
                    assert!((0.0..=1.0).contains(&b.precipitation()));
                    assert!(
                        ["polar", "tundra", "temperate", "dry", "tropical"]
                            .contains(&b.biome().name())
                    );
                    assert_eq!(b, c.base_at(t.cell(0, y as i128)));
                    assert_eq!(b, c.base_at(t.cell(x as i128, y as i128)));
                }
            }
        }
    }
}

#[test]
fn bands_order_mirror_and_known_samples() {
    for (w, h) in [(7, 256), (64, 48)] {
        let t = Topology::new(w, h).unwrap();
        let c = Climate::new(t);
        let mut bands = Vec::new();
        let mut previous = 0.;
        for y in 0..h / 2 {
            let b = c.base_at(t.cell(0, y as i128));
            assert!(b.temperature() >= previous);
            previous = b.temperature();
            if bands.last() != Some(&b.biome()) {
                bands.push(b.biome());
            }
            assert_eq!(b, c.base_at(t.cell(0, (h - 1 - y) as i128)));
        }
        assert_eq!(
            bands,
            [
                Biome::Polar,
                Biome::Tundra,
                Biome::Temperate,
                Biome::Dry,
                Biome::Tropical
            ]
        );
    }
    let t = Topology::new(1, 5).unwrap();
    let c = Climate::new(t);
    let samples = [
        (0, 0.09549150281252627, Biome::Polar),
        (1, 0.6545084971874737, Biome::Dry),
        (2, 1., Biome::Tropical),
    ];
    for (y, q, biome) in samples {
        let b = c.base_at(t.cell(0, y));
        assert!((b.temperature() - q).abs() < 1e-14);
        assert_eq!(b.biome(), biome);
    }
    assert_eq!(c.base_at(t.cell(0, 2)).precipitation(), 1.);
    let t = Topology::new(1, 256).unwrap();
    let c = Climate::new(t);
    let moist = c.base_at(t.cell(0, 40)).precipitation();
    let dry = c.base_at(t.cell(0, 72)).precipitation();
    assert!(moist > dry);
    assert!(c.base_at(t.cell(0, 127)).precipitation() > dry);
}

#[test]
fn seams_no_larger_than_non_wrapping_neighbors() {
    let mut sizes = Vec::new();
    for w in 1..=64 {
        for h in 1..=64 {
            sizes.push((w, h));
        }
    }
    sizes.extend([(3, 255), (64, 48), (7, 256)]);
    for (w, h) in sizes {
        let t = Topology::new(w, h).unwrap();
        let c = Climate::new(t);
        assert_eq!(c.base_at(t.cell(0, 0)), c.base_at(t.cell(0, -1)));
        assert_eq!(c.base_at(t.cell(-1, -1)), c.base_at(t.cell(0, 0)));
        for field in [
            evosim::climate::BaseClimate::temperature,
            evosim::climate::BaseClimate::precipitation,
        ] {
            let at = |x, y| field(c.base_at(t.cell(x, y)));
            let mut vertical_max: f64 = 0.;
            for y in 1..h {
                vertical_max = vertical_max.max((at(0, y as i128) - at(0, y as i128 - 1)).abs());
            }
            assert!((at(0, 0) - at(0, -1)).abs() <= vertical_max + 1e-12);
            for y in 0..h {
                let mut horizontal_max: f64 = 0.;
                for x in 1..w {
                    horizontal_max = horizontal_max
                        .max((at(x as i128, y as i128) - at(x as i128 - 1, y as i128)).abs());
                }
                assert!((at(0, y as i128) - at(-1, y as i128)).abs() <= horizontal_max + 1e-12);
            }
        }
    }
}

#[test]
fn tiny_extreme_and_foreign_cells() {
    for (w, h) in [
        (1, 1),
        (1, 7),
        (7, 1),
        (2, 2),
        (11, 17),
        (usize::MAX, 1),
        (1, usize::MAX),
    ] {
        let t = Topology::new(w, h).unwrap();
        let c = Climate::new(t);
        for (x, y) in [(0, 0), (w / 2, h / 2), (w - 1, h - 1)] {
            let b = c.base_at(t.cell(x as i128, y as i128));
            assert!(b.temperature().is_finite() && b.precipitation().is_finite());
            assert!((0.0..=1.0).contains(&b.temperature()));
            assert!((0.0..=1.0).contains(&b.precipitation()));
        }
    }
    let t = Topology::new(3, 5).unwrap();
    let c = Climate::new(t);
    let foreign = Topology::new(100, 100).unwrap().cell(99, 98);
    assert_eq!(c.base_at(foreign), c.base_at(t.cell(99, 98)));
    assert_eq!(c.base_at(t.cell(-1, -1)), c.base_at(t.cell(2, 4)));
    assert_eq!(
        Climate::new(Topology::new(1, 1).unwrap())
            .base_at(t.cell(0, 0))
            .biome(),
        Biome::Tropical
    );
    assert_eq!(
        Climate::new(Topology::new(2, 2).unwrap())
            .base_at(t.cell(0, 0))
            .biome(),
        Biome::Temperate
    );
}

#[test]
fn streaming_export_schema_order_and_write_errors() {
    for (w, h) in [(3, 5), (1, 1)] {
        let t = Topology::new(w, h).unwrap();
        let c = Climate::new(t);
        let mut bytes = Vec::new();
        c.write_json(&mut bytes).unwrap();
        assert_eq!(bytes.last(), Some(&b'\n'));
        let v: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(v["climate_model"], CLIMATE_MODEL_VERSION);
        assert_eq!(v["width"], w);
        assert_eq!(v["height"], h);
        assert_eq!(v["temperature_units"], "normalized");
        assert_eq!(v["precipitation_units"], "normalized");
        let cells = v["cells"].as_array().unwrap();
        assert_eq!(cells.len(), w * h);
        for (i, cell) in cells.iter().enumerate() {
            let (x, y) = (i % w, i / w);
            let b = c.base_at(t.cell(x as i128, y as i128));
            assert_eq!(cell["x"], x);
            assert_eq!(cell["y"], y);
            assert_eq!(cell["biome"], b.biome().name());
            assert_eq!(cell["base_temperature"].as_f64().unwrap(), b.temperature());
            assert_eq!(
                cell["base_precipitation"].as_f64().unwrap(),
                b.precipitation()
            );
        }
    }
    struct Fail;
    impl std::io::Write for Fail {
        fn write(&mut self, _: &[u8]) -> std::io::Result<usize> {
            Err(std::io::Error::other("injected"))
        }
        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }
    assert!(
        Climate::new(Topology::new(3, 5).unwrap())
            .write_json(&mut Fail)
            .is_err()
    );
}

use std::process::Command;

#[test]
fn process_contract() {
    let binary = env!("CARGO_BIN_EXE_evosim");
    for argument in ["--help", "-h", "version"] {
        let output = Command::new(binary).arg(argument).output().unwrap();
        assert!(output.status.success());
        assert!(output.stderr.is_empty());
        assert!(!output.stdout.is_empty());
    }
    for args in [
        vec![],
        vec!["unknown"],
        vec!["version", "extra"],
        vec!["--help", "extra"],
    ] {
        let output = Command::new(binary).args(args).output().unwrap();
        assert_eq!(output.status.code(), Some(2));
        assert!(output.stdout.is_empty());
        assert!(!output.stderr.is_empty());
    }
}

#[test]
fn climate_export_and_errors_without_display() {
    let binary = env!("CARGO_BIN_EXE_evosim");
    let dir = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("target")
        .join(format!("climate cli {}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let config = dir.join("input config.json");
    let map = dir.join("output map.json");
    std::fs::write(&config,r#"{"seed":42,"world":{"width":3,"height":5},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let c = config.to_str().unwrap();
    let m = map.to_str().unwrap();
    let run = |args: &[&str]| {
        Command::new(binary)
            .args(args)
            .env_remove("DISPLAY")
            .current_dir(&dir)
            .output()
            .unwrap()
    };
    for args in [
        ["climate", "--config", c, "--out", m],
        ["climate", "--out", m, "--config", c],
    ] {
        let output = run(&args);
        assert!(output.status.success(), "{:?}", output);
        assert!(output.stdout.is_empty() && output.stderr.is_empty());
        let v: serde_json::Value = serde_json::from_slice(&std::fs::read(&map).unwrap()).unwrap();
        assert_eq!(v["cells"].as_array().unwrap().len(), 15);
    }
    let missing = dir.join("missing.json");
    let missing = missing.to_str().unwrap();
    let invalid = dir.join("invalid.json");
    std::fs::write(&invalid, "{}").unwrap();
    let invalid = invalid.to_str().unwrap();
    let cases = vec![
        vec!["climate"],
        vec!["climate", "--config", c],
        vec!["climate", "--out", m],
        vec!["climate", "--config", c, "--config", c],
        vec!["climate", "--out", m, "--out", m],
        vec!["climate", "--config", c, "--unknown", m],
        vec!["climate", "--config", c, "--out", m, "extra"],
        vec!["climate", "--config", "--out", "--out", m],
        vec!["climate", "--config", missing, "--out", m],
        vec!["climate", "--config", invalid, "--out", m],
    ];
    for args in cases {
        std::fs::write(&map, "sentinel").unwrap();
        let output = run(&args);
        assert_eq!(output.status.code(), Some(2), "{args:?}");
        assert!(output.stdout.is_empty());
        assert!(!output.stderr.is_empty());
        assert_eq!(std::fs::read_to_string(&map).unwrap(), "sentinel");
        std::fs::remove_file(&map).unwrap();
        assert_eq!(run(&args).status.code(), Some(2));
        assert!(!map.exists());
    }
    let output = run(&["climate", "--config", c, "--out", dir.to_str().unwrap()]);
    assert_eq!(output.status.code(), Some(2));
    assert!(!output.stderr.is_empty());
    assert!(output.stdout.is_empty());
    // /dev/full accepts open but fails on write/flush, exercising buffered error handling.
    if std::path::Path::new("/dev/full").exists() {
        assert_eq!(
            run(&["climate", "--config", c, "--out", "/dev/full"])
                .status
                .code(),
            Some(2)
        );
    }
    std::fs::remove_dir_all(dir).unwrap();
}

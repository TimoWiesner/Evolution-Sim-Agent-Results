use evosim::{
    config::{Config, Seed},
    rng::{Rng, RngError, RngState},
};

#[test]
fn independent_known_vectors() {
    // Frozen from a separate Python arbitrary-precision integer reference;
    // mask each multiply/shift to 64 bits, express rotation with shift/or.
    let fixtures = [
        (
            0,
            [
                16294208416658607535,
                7960286522194355700,
                487617019471545679,
                17909611376780542444,
            ],
            [
                11091344671253066420,
                13793997310169335082,
                1900383378846508768,
                7684712102626143532,
            ],
        ),
        (
            42,
            [
                13679457532755275413,
                2949826092126892291,
                5139283748462763858,
                6349198060258255764,
            ],
            [
                1546998764402558742,
                6990951692964543102,
                12544586762248559009,
                17057574109182124193,
            ],
        ),
        (
            -1,
            [
                16490336266968443936,
                16834447057089888969,
                4048727598324417001,
                7862637804313477842,
            ],
            [
                10328197420357168392,
                14156678507024973869,
                9357971779955476126,
                13791585006304312367,
            ],
        ),
    ];
    for (seed, words, draws) in fixtures {
        let mut rng = Rng::from_seed(&Seed::from_i64(seed));
        assert_eq!(rng.state(), RngState { version: 1, words });
        for draw in draws {
            assert_eq!(rng.next_u64(), draw);
        }
    }
    let mut rng = raw([1, 2, 3, 4]);
    for draw in [11520, 0, 1509978240] {
        assert_eq!(rng.next_u64(), draw);
    }
}
fn raw(words: [u64; 4]) -> Rng {
    Rng::from_state(RngState { version: 1, words }).unwrap()
}

#[test]
fn state_validation_and_exact_restoration() {
    for version in [0, 2, u32::MAX] {
        assert_eq!(
            Rng::from_state(RngState {
                version,
                words: [1, 2, 3, 4]
            }),
            Err(RngError::UnsupportedVersion(version))
        );
    }
    assert_eq!(
        Rng::from_state(RngState {
            version: 1,
            words: [0; 4]
        }),
        Err(RngError::ZeroState)
    );
    for words in [[1, 0, 0, 0], [0, 0, 0, u64::MAX], [u64::MAX; 4]] {
        assert_eq!(raw(words).state().words, words);
    }
    let mut a = Rng::from_seed(&Seed::from_u64(42));
    assert_eq!(Rng::from_state(a.state()).unwrap(), a);
    for _ in 0..37 {
        a.next_u64();
    }
    let state = a.state();
    assert_eq!(a.state(), state);
    let mut b = Rng::from_state(state).unwrap();
    for _ in 0..1024 {
        assert_eq!(a.next_u64(), b.next_u64());
        assert_eq!(a.below((1 << 63) + 1), b.below((1 << 63) + 1));
        assert_eq!(a.chance(2, 7), b.chance(2, 7));
    }
    assert_eq!(a.state(), b.state());
}

#[test]
fn bounded_sampling_matches_u128_rejection_reference() {
    for bound in [1, 2, 3, 4, 256, 1 << 63, (1 << 63) + 1, u64::MAX] {
        let mut actual = Rng::from_seed(&Seed::from_u64(42));
        let mut reference = actual.clone();
        let threshold = ((1u128 << 64) % u128::from(bound)) as u64;
        for _ in 0..256 {
            let expected = loop {
                let draw = reference.next_u64();
                if draw >= threshold {
                    break draw % bound;
                }
            };
            let sampled = actual.below(bound).unwrap();
            assert!(sampled < bound);
            assert_eq!(sampled, expected);
            assert_eq!(actual.state(), reference.state());
        }
    }
    let mut actual = raw([1, 0, 2, 3]);
    let mut reference = actual.clone();
    assert_eq!(reference.next_u64(), 0); // below threshold 1, must reject
    let accepted = reference.next_u64();
    assert!(accepted >= 1);
    assert_eq!(actual.below(3).unwrap(), accepted % 3);
    assert_eq!(actual, reference);
}

#[test]
fn draw_consumption_and_ratio_boundaries() {
    let mut a = raw([1, 2, 3, 4]);
    let before = a.clone();
    assert_eq!(a.below(0), Err(RngError::ZeroBound));
    for (n, d) in [(0, 0), (1, 0), (3, 2), (u64::MAX, 1)] {
        assert_eq!(
            a.chance(n, d),
            Err(RngError::InvalidRatio {
                numerator: n,
                denominator: d
            })
        );
    }
    for d in [1, 2, u64::MAX] {
        assert_eq!(a.chance(0, d), Ok(false));
        assert_eq!(a.chance(d, d), Ok(true));
    }
    assert_eq!(a, before);
    let mut reference = before;
    reference.next_u64();
    assert_eq!(a.below(1), Ok(0));
    assert_eq!(a, reference);
    for (n, d) in [(1, 2), (2, 3), (1, u64::MAX), (1, (1 << 63) + 1)] {
        assert_eq!(a.chance(n, d).unwrap(), reference.below(d).unwrap() < n);
        assert_eq!(a, reference);
    }
}

#[test]
fn seeded_streams_and_modulo_equivalence() {
    fn trace(seed: u64) -> Vec<u64> {
        let mut rng = Rng::from_seed(&Seed::from_u64(seed));
        (0..128).map(|_| rng.next_u64()).collect()
    }
    assert_eq!(trace(42), trace(42));
    assert_ne!(trace(42), trace(43));
    for (large, equivalent) in [
        ("18446744073709551658", 42),
        ("-18446744073709551617", u64::MAX),
    ] {
        let config = Config::from_json(&format!(r#"{{"seed":{large},"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}}}}"#)).unwrap();
        let mut a = Rng::from_seed(config.seed());
        let mut b = Rng::from_seed(&Seed::from_u64(equivalent));
        for _ in 0..128 {
            assert_eq!(a.next_u64(), b.next_u64());
        }
    }
}

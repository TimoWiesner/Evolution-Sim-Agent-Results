use evosim::{
    config::{Config, Seed},
    metrics::Snapshot,
    organism::{DeathCause, Kind},
    persistence::state_hash,
    simulation::Simulation,
};
use serde_json::{Value, json};
use std::{
    fs,
    path::{Path, PathBuf},
    process::{Command, Output},
};
struct Fixture(PathBuf);
impl Fixture {
    fn new(name: &str) -> Self {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("run-{name}-{}", std::process::id()));
        fs::create_dir_all(&path).unwrap();
        Self(path)
    }
    fn run(&self, args: &[&str]) -> Output {
        Command::new(env!("CARGO_BIN_EXE_evosim"))
            .args(args)
            .env_remove("DISPLAY")
            .env_remove("WAYLAND_DISPLAY")
            .current_dir(&self.0)
            .output()
            .unwrap()
    }
    fn config(&self, v: &Value) {
        fs::write(self.0.join("config.json"), v.to_string()).unwrap();
    }
    fn success(&self, extra: &[&str]) -> Value {
        let mut args = vec!["run", "--config", "config.json", "--out", "result.json"];
        args.extend_from_slice(extra);
        let o = self.run(&args);
        assert!(o.status.success(), "{}", String::from_utf8_lossy(&o.stderr));
        assert!(o.stdout.is_empty() && o.stderr.is_empty());
        serde_json::from_slice(&fs::read(self.0.join("result.json")).unwrap()).unwrap()
    }
}
impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn config() -> Value {
    json!({"seed":42,"world":{"width":8,"height":6},"initial":{"plants":8,"herbivores":4,"carnivores":2}})
}
fn ticks(v: &Value) -> Vec<u64> {
    v["series"]
        .as_array()
        .unwrap()
        .iter()
        .map(|s| s["tick"].as_u64().unwrap())
        .collect()
}
#[test]
fn sampling_schema_and_direct_engine_oracle() {
    let f = Fixture::new("oracle");
    f.config(&config());
    for (n, k) in [
        (0, None),
        (1, None),
        (7, Some(1)),
        (7, Some(3)),
        (7, Some(99)),
        (99, None),
        (100, None),
        (250, None),
        (250, Some(3)),
    ] {
        let ns = n.to_string();
        let ks = k.map(|k| k.to_string());
        let mut args = vec!["--ticks", &ns];
        if let Some(s) = &ks {
            args.extend(["--sample-every", s]);
        }
        let v = f.success(&args);
        let interval = k.unwrap_or((n / 100).max(1));
        let mut expected: Vec<_> = (0..=n).filter(|t| t % interval == 0).collect();
        if expected.last() != Some(&n) {
            expected.push(n);
        }
        assert_eq!(ticks(&v), expected);
        assert_eq!(v["tick_start"], 0);
        assert_eq!(v["tick_end"], n);
        assert_eq!(v["contract"], 1);
        assert_eq!(v["seed"], 42);
        assert_eq!(v["world"], config()["world"]);
        let mut sim = Simulation::new(Config::from_json(&config().to_string()).unwrap()).unwrap();
        assert_eq!(v["metrics_schema"], 1);
        for row in v["series"].as_array().unwrap() {
            let tick = row["tick"].as_u64().unwrap();
            while sim.tick() < tick {
                sim.advance_one_tick().unwrap();
            }
            assert_eq!(*row, Snapshot::capture(&sim).to_json());
            assert_metrics_schema(row);
        }
        assert_eq!(v["state_hash"], state_hash(&sim).unwrap());
        assert_eq!(v["state_hash_schema"], 1);
        for (kind, key) in Kind::ALL
            .into_iter()
            .zip(["plants", "herbivores", "carnivores"])
        {
            assert_eq!(v["final"][key], json!(sim.population().counts().get(kind)));
            assert_eq!(
                v["totals"]["births"][key],
                json!(sim.population().totals().births.get(kind))
            );
            assert_eq!(
                v["totals"]["deaths"][key],
                json!(sim.population().totals().deaths.get(kind))
            );
            assert_eq!(
                v["final"]["species"][key],
                sim.population().species().living_count(kind)
            );
            assert_eq!(
                config()["initial"][key].as_u64().unwrap()
                    + v["totals"]["births"][key].as_u64().unwrap()
                    - v["totals"]["deaths"][key].as_u64().unwrap(),
                v["final"][key]
            );
        }
        for key in ["elapsed_seconds", "ticks_per_second"] {
            let t = v[key].as_f64().unwrap();
            assert!(t.is_finite() && t >= 0.);
            if n == 0 {
                assert_eq!(t, 0.);
            }
        }
    }
}
#[test]
fn seed_override_validation_precision_and_sampling_independence() {
    let f = Fixture::new("seeds");
    f.config(&config());
    for seed in [
        "-42",
        "0",
        "18446744073709551658",
        "-999999999999999999999999999999999",
    ] {
        let a = f.success(&["--ticks", "7", "--seed", seed, "--sample-every", "1"]);
        let b = f.success(&["--ticks", "7", "--seed", seed, "--sample-every", "3"]);
        for key in ["state_hash", "final", "totals", "seed"] {
            assert_eq!(a[key], b[key]);
        }
        assert_eq!(a["seed"].to_string(), seed);
        let mut sim = Simulation::new(
            Config::from_json(&config().to_string())
                .unwrap()
                .with_seed(Seed::from_decimal(seed).unwrap()),
        )
        .unwrap();
        for _ in 0..7 {
            sim.advance_one_tick().unwrap();
        }
        assert_eq!(a["state_hash"], state_hash(&sim).unwrap());
    }
    let a = f.success(&["--ticks", "0", "--seed", "42"]);
    let b = f.success(&["--ticks", "0", "--seed", "18446744073709551658"]);
    assert_ne!(a["state_hash"], b["state_hash"]);
    f.config(
        &serde_json::from_str::<Value>(
            &Config::from_json(&config().to_string())
                .unwrap()
                .to_json()
                .unwrap(),
        )
        .unwrap(),
    );
    assert_eq!(a["state_hash"], f.success(&["--ticks", "0"])["state_hash"]);
}
#[test]
fn exact_extinct_tails_without_replenishment() {
    let f = Fixture::new("extinct");
    for (herbivores, carnivores, n) in [(0, 0, 1000), (4, 2, 5000)] {
        f.config(&json!({"seed":42,"world":{"width":2,"height":2},"initial":{"plants":0,"herbivores":herbivores,"carnivores":carnivores}}));
        let v = f.success(&["--ticks", &n.to_string(), "--sample-every", "33"]);
        assert_eq!(v["tick_end"], n);
        for row in v["series"].as_array().unwrap() {
            assert_metrics_schema(row);
        }
        assert_eq!(ticks(&v).last(), Some(&n));
        for key in ["plants", "herbivores", "carnivores"] {
            assert_eq!(v["final"][key], 0);
            if key == "plants" || herbivores == 0 {
                assert_eq!(v["totals"]["births"][key], 0);
            }
        }
        assert_eq!(
            v["totals"]["deaths"]["herbivores"].as_u64().unwrap(),
            herbivores + v["totals"]["births"]["herbivores"].as_u64().unwrap()
        );
        assert_eq!(
            v["totals"]["deaths"]["carnivores"].as_u64().unwrap(),
            carnivores + v["totals"]["births"]["carnivores"].as_u64().unwrap()
        );
        assert!(
            v["series"]
                .as_array()
                .unwrap()
                .iter()
                .rev()
                .take(10)
                .all(|s| s["plants"] == 0 && s["herbivores"] == 0 && s["carnivores"] == 0)
        );
    }
    f.config(&json!({"seed":42,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":0,"carnivores":0}}));
    let v = f.success(&["--ticks", "2200", "--sample-every", "1"]);
    assert_eq!(v["tick_end"], 2200);
    let series = v["series"].as_array().unwrap();
    let zero = series.iter().position(|s| s["plants"] == 0).unwrap();
    assert!(zero > 0 && zero < 2200);
    assert!(
        series[zero..]
            .iter()
            .all(|s| s["plants"] == 0 && s["herbivores"] == 0 && s["carnivores"] == 0)
    );
    assert_eq!(
        1 + v["totals"]["births"]["plants"].as_u64().unwrap(),
        v["totals"]["deaths"]["plants"]
    );
}
#[test]
fn argument_configuration_and_output_errors_are_transactional() {
    let f = Fixture::new("errors");
    f.config(&config());
    let out = f.0.join("result.json");
    let base = vec![
        "run",
        "--config",
        "config.json",
        "--ticks",
        "0",
        "--out",
        "result.json",
    ];
    let mut cases = vec![
        vec!["run"],
        vec!["run", "positional"],
        vec!["run", "--ticks", "0"],
        vec!["run", "--config", "config.json", "--out", "result.json"],
        vec!["run", "--ticks", "0", "--out", "result.json"],
    ];
    for flag in [
        "--config",
        "--ticks",
        "--out",
        "--seed",
        "--sample-every",
        "--unknown",
        "--load",
        "--save",
    ] {
        let mut a = base.clone();
        a.extend([flag, "1"]);
        if flag == "--seed" || flag == "--sample-every" || flag == "--save" {
            a.extend([flag, "1"]);
        }
        cases.push(a);
        let mut a = base.clone();
        a.push(flag);
        cases.push(a);
    }
    for (flag, bad) in [
        ("--ticks", "-1"),
        ("--ticks", "1.0"),
        ("--ticks", "+1"),
        ("--ticks", "1e2"),
        ("--ticks", "18446744073709551616"),
        ("--sample-every", "0"),
        ("--sample-every", "-1"),
        ("--sample-every", "1.0"),
        ("--sample-every", "1e2"),
        ("--sample-every", "18446744073709551616"),
        ("--seed", "+1"),
        ("--seed", "1e2"),
        ("--seed", "1.0"),
        ("--seed", ""),
    ] {
        let mut a = base.clone();
        if flag == "--ticks" {
            a[4] = bad;
        } else {
            a.extend([flag, bad]);
        }
        cases.push(a);
    }
    for a in cases {
        for existing in [true, false] {
            if existing {
                fs::write(&out, "sentinel").unwrap();
            } else {
                let _ = fs::remove_file(&out);
            }
            let o = f.run(&a);
            assert_eq!(o.status.code(), Some(2), "{a:?}");
            assert!(o.stdout.is_empty());
            assert!(!o.stderr.is_empty());
            if existing {
                assert_eq!(fs::read_to_string(&out).unwrap(), "sentinel");
            } else {
                assert!(!out.exists());
            }
        }
    }
    let mut invalids = vec![
        "{}".to_string(),
        "not json".to_string(),
        format!("{} trailing", config()),
    ];
    for path in [
        vec!["seed"],
        vec!["world", "width"],
        vec!["world", "height"],
        vec!["initial", "plants"],
        vec!["initial", "herbivores"],
        vec!["initial", "carnivores"],
    ] {
        for bad in [Value::Null, json!("wrong"), json!(1.5)] {
            let mut v = config();
            let mut slot = &mut v;
            for key in &path {
                slot = &mut slot[*key];
            }
            *slot = bad;
            invalids.push(v.to_string());
        }
        let mut v = config();
        let (last, parents) = path.split_last().unwrap();
        let mut slot = &mut v;
        for key in parents {
            slot = &mut slot[*key];
        }
        slot.as_object_mut().unwrap().remove(*last);
        invalids.push(v.to_string());
    }
    for input in invalids {
        fs::write(f.0.join("config.json"), input).unwrap();
        let _ = fs::remove_file(&out);
        let mut args = base.clone();
        args.extend(["--seed", "42"]);
        let o = f.run(&args);
        assert_eq!(o.status.code(), Some(2));
        assert!(!o.stderr.is_empty());
        assert!(o.stdout.is_empty());
        assert!(!out.exists());
    }
    f.config(&config());
    let mut missing = base.clone();
    missing[2] = "missing.json";
    assert_eq!(f.run(&missing).status.code(), Some(2));
    assert!(!out.exists());
    fs::create_dir(f.0.join("directory")).unwrap();
    std::os::unix::fs::symlink("config.json", f.0.join("link")).unwrap();
    let fifo = f.0.join("fifo");
    assert!(
        Command::new("mkfifo")
            .arg(&fifo)
            .status()
            .unwrap()
            .success()
    );
    for name in ["directory", "link", "fifo", "missing-parent/out.json"] {
        let mut a = base.clone();
        a[6] = name;
        let o = f.run(&a);
        assert_eq!(o.status.code(), Some(2));
        assert!(!o.stderr.is_empty());
        assert!(o.stdout.is_empty());
    }
    assert!(
        fs::symlink_metadata(f.0.join("link"))
            .unwrap()
            .file_type()
            .is_symlink()
    );
    assert!(
        fs::metadata(&fifo).unwrap().file_type()
            != fs::metadata(f.0.join("config.json")).unwrap().file_type()
    );
    assert!(!fs::read_dir(&f.0).unwrap().any(|p| {
        p.unwrap()
            .file_name()
            .to_string_lossy()
            .starts_with(".evosim-result-")
    }));
}

fn assert_keys(value: &Value, keys: &[&str]) {
    let actual: std::collections::BTreeSet<_> = value
        .as_object()
        .unwrap()
        .keys()
        .map(String::as_str)
        .collect();
    assert_eq!(actual, keys.iter().copied().collect());
}
fn assert_metrics_schema(row: &Value) {
    assert_keys(
        row,
        &["tick", "plants", "herbivores", "carnivores", "analytics"],
    );
    let a = &row["analytics"];
    assert_keys(a, &["plants", "herbivores", "carnivores", "generation"]);
    assert_keys(&a["generation"], &["highest", "mean"]);
    for name in ["plants", "herbivores", "carnivores"] {
        let k = &a[name];
        assert_keys(
            k,
            &[
                "births",
                "deaths",
                "deaths_by_cause",
                "species",
                "traits",
                "generation",
            ],
        );
        assert_keys(
            &k["deaths_by_cause"],
            &["starvation", "injury", "predation", "old_age", "climate"],
        );
        assert_eq!(
            k["deaths_by_cause"]
                .as_object()
                .unwrap()
                .values()
                .map(|n| n.as_u64().unwrap())
                .sum::<u64>(),
            k["deaths"].as_u64().unwrap()
        );
        assert_keys(&k["traits"], &evosim::genome::LOCUS_NAMES);
        assert_keys(&k["generation"], &["highest", "mean"]);
        for t in k["traits"].as_object().unwrap().values() {
            assert_keys(t, &["mean", "standard_deviation", "min", "max"]);
            if row[name] == 0 {
                assert!(t.as_object().unwrap().values().all(Value::is_null));
            } else {
                assert!(
                    t.as_object()
                        .unwrap()
                        .values()
                        .all(|v| v.as_f64().unwrap().is_finite())
                );
            }
        }
    }
}
#[test]
fn analytic_counters_match_final_and_repeat_output() {
    let f = Fixture::new("analytics");
    f.config(&config());
    let mut a = f.success(&["--ticks", "1000", "--sample-every", "3"]);
    let mut b = f.success(&["--ticks", "1000", "--sample-every", "3"]);
    for v in [&mut a, &mut b] {
        v.as_object_mut().unwrap().remove("elapsed_seconds");
        v.as_object_mut().unwrap().remove("ticks_per_second");
    }
    assert_eq!(a, b);
    let mut sim = Simulation::new(Config::from_json(&config().to_string()).unwrap()).unwrap();
    for _ in 0..1000 {
        sim.advance_one_tick().unwrap();
    }
    let last = a["series"].as_array().unwrap().last().unwrap();
    assert_metrics_schema(last);
    for (kind, name) in Kind::ALL
        .into_iter()
        .zip(["plants", "herbivores", "carnivores"])
    {
        assert_eq!(
            last["analytics"][name]["births"],
            a["totals"]["births"][name]
        );
        assert_eq!(
            last["analytics"][name]["deaths"],
            a["totals"]["deaths"][name]
        );
        assert_eq!(
            last["analytics"][name]["species"],
            a["final"]["species"][name]
        );
        for (cause, key) in DeathCause::ALL.into_iter().zip([
            "starvation",
            "injury",
            "predation",
            "old_age",
            "climate",
        ]) {
            assert_eq!(
                last["analytics"][name]["deaths_by_cause"][key],
                json!(sim.population().deaths_by_cause(kind, cause))
            );
        }
    }
}

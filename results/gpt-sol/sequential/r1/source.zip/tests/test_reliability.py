"""Delivery validator boundary cases and actual network-denied static execution."""
import csv
import ctypes
import errno
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import release_verify as release


def deny_network():
    # Linux x86-64 seccomp BPF: reject socket(41), connect(42), socketpair(53).
    class Filter(ctypes.Structure):
        _fields_=[('code',ctypes.c_ushort),('jt',ctypes.c_ubyte),('jf',ctypes.c_ubyte),('k',ctypes.c_uint)]
    class Program(ctypes.Structure):
        _fields_=[('len',ctypes.c_ushort),('filter',ctypes.POINTER(Filter))]
    ins=[(0x20,0,0,0)]
    for number in [41,42,53]:ins.extend([(0x15,0,1,number),(0x06,0,0,0x50000|errno.EPERM)])
    ins.append((0x06,0,0,0x7fff0000))
    filters=(Filter*len(ins))(*(Filter(*x) for x in ins));program=Program(len(ins),filters)
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(38,1,0,0,0) or libc.prctl(22,2,ctypes.byref(program)):
        os._exit(99)


class Reliability(unittest.TestCase):
    def test_network_denied_runtime_and_negative_control(self):
        self.assertEqual(os.uname().machine,'x86_64')
        p=subprocess.run([sys.executable,'-c','import socket; socket.socket()'],cwd=ROOT,capture_output=True,preexec_fn=deny_network)
        self.assertNotEqual(p.returncode,0);self.assertIn(b'Operation not permitted',p.stderr)
        binary=ROOT/'dist/evosim'
        self.assertTrue(binary.exists(),'run setup/build before suite')
        with tempfile.TemporaryDirectory(dir=ROOT/'target') as name:
            folder=Path(name)
            config=folder/'config.json';config.write_text(json.dumps({'seed':42,'world':{'width':3,'height':2},'initial':{'plants':2,'herbivores':1,'carnivores':1}}))
            for flags in [['version'],['run','--config',str(config),'--ticks','10','--out',str(folder/'out.json'),'--save',str(folder/'save.evo')],['run','--load',str(folder/'save.evo'),'--ticks','3','--out',str(folder/'out.json')],['batch','--config',str(config),'--seeds','1,2','--ticks','3','--out-dir',str(folder/'batch')]]:
                p=subprocess.run([str(binary),*flags],cwd=folder,capture_output=True,preexec_fn=deny_network,timeout=30)
                self.assertEqual(p.returncode,0,p.stderr)

    def fixture(self,folder,zero):
        names=release.NAMES;causes=release.balance_report.CAUSES;rows=[]
        for t in range(4):
            row={'tick':t}
            for n,z in zip(names,zero):
                dead=z is not None and t>=z
                row[n]=int(not dead);row[n+'_births']=0;row[n+'_deaths']=int(dead and z!=0)
                for c in causes:row[n+'_'+c]=int(dead and z!=0 and c=='OldAge')
            rows.append(row)
        def counters(row):
            return {n:dict(initial=int(z!=0),count=row[n],births=0,deaths=row[n+'_deaths'],causes={c:row[n+'_'+c] for c in causes}) for n,z in zip(names,zero)}
        score=min((z for z in zero if z is not None),default=3)
        run=dict(seed='0',tick_end=3,first_zero=zero,coexistence=score,right_censored=all(z is None for z in zero),first_kinds=[n for n,z in zip(names,zero) if z==score],final=counters(rows[-1]),extinctions={n:dict(tick=z,counters=counters(rows[z])) for n,z in zip(names,zero) if z is not None},state_hash='a'*64)
        with (folder/'seed-0.csv').open('w') as f:
            w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
        (folder/'observer.json').write_text(json.dumps(dict(ticks=3,runs=[run])))
        cli=dict(tick_start=0,tick_end=3,state_hash=run['state_hash'],final={n:run['final'][n]['count'] for n in names},totals={k:{n:run['final'][n][k] for n in names} for k in ['births','deaths']})
        (folder/'seed-0.json').write_text(json.dumps(cli))
        return cli

    def test_observer_boundaries_and_corruption(self):
        for zeros,positive in [([0,1,3],0),([1,1,None],0),([3,None,None],2),([None]*3,3)]:
            with self.subTest(zeros=zeros),tempfile.TemporaryDirectory(dir=ROOT/'target') as name:
                folder=Path(name);cli=self.fixture(folder,zeros)
                release.balance_report.validate(folder)
                self.assertEqual(release.coexistence(zeros,3)['positive_completed_ticks'],positive)
                cli['state_hash']='bad';(folder/'seed-0.json').write_text(json.dumps(cli))
                with self.assertRaises(AssertionError):release.balance_report.validate(folder)
                self.fixture(folder,zeros)
                csvpath=folder/'seed-0.csv';csvpath.write_text('\n'.join(csvpath.read_text().splitlines()[:-1])+'\n')
                with self.assertRaises(AssertionError):release.balance_report.validate(folder)
                self.fixture(folder,zeros);csvpath.write_text('broken\n')
                with self.assertRaises((AssertionError,KeyError,ValueError)):release.balance_report.validate(folder)

if __name__=='__main__':unittest.main()

#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
cargo test --locked
cargo test --locked --release --test performance -- --ignored --nocapture
node tests/ui_camera.cjs
node tests/ui_configuration.cjs
node tests/ui_charts.cjs
python3 -m unittest discover -s tests -p 'test_*.py' -v

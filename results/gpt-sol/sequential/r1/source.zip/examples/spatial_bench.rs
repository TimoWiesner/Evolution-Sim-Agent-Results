//! Reproduce with: cargo run --locked --release --example spatial_bench
//! Timings include result allocation, sorting and checksum equally on both paths.
use evosim::{
    config::{Config, Seed},
    organism::{Kind, OrganismId},
    population::Population,
    rng::Rng,
    simulation::Simulation,
    topology::{Cell, Topology},
};
use std::{hint::black_box, time::Instant};

fn brute(
    p: &Population,
    t: Topology,
    center: Cell,
    radius: usize,
    kind: Option<Kind>,
) -> Vec<OrganismId> {
    p.iter()
        .filter(|o| {
            if kind.is_some_and(|k| k != o.kind()) {
                return false;
            }
            let dx = o.position().x().abs_diff(center.x() % t.width());
            let dy = o.position().y().abs_diff(center.y() % t.height());
            dx.min(t.width() - dx).max(dy.min(t.height() - dy)) <= radius
        })
        .map(|o| o.id())
        .collect() // BTreeMap is already in ascending ID order.
}
fn measure(centers: &[Cell], mut query: impl FnMut(Cell) -> Vec<OrganismId>) -> (u128, u64, usize) {
    let start = Instant::now();
    let mut checksum = 0u64;
    let mut matches = 0usize;
    for &center in centers {
        let ids = black_box(query(black_box(center)));
        matches += ids.len();
        for id in ids {
            checksum = checksum.wrapping_mul(31).wrapping_add(id.value());
        }
    }
    (
        start.elapsed().as_nanos(),
        black_box(checksum),
        black_box(matches),
    )
}
fn main() {
    let config=Config::from_json(r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":1400,"herbivores":500,"carnivores":100}}"#).unwrap();
    let sim = Simulation::new(config).unwrap();
    let p = sim.population();
    let t = sim.world().topology();
    let mut rng = Rng::from_seed(&Seed::from_u64(42));
    let centers: Vec<_> = (0..4096)
        .map(|_| {
            t.cell(
                rng.below(64).unwrap() as i128,
                rng.below(48).unwrap() as i128,
            )
        })
        .collect();
    println!(
        "64x48, 2000 row-major founders (1400/500/100), seed=42, 4096 precomputed uniform centers, 5 alternating repeats; primary=radius 4 all"
    );
    println!(
        "radius,filter,index_ms,brute_ms,index_ns_per_query,brute_ns_per_query,speedup,matches,checksum"
    );
    for radius in [1, 4, 8, usize::MAX] {
        for kind in [None, Some(Kind::Herbivore)] {
            for &center in &centers {
                assert_eq!(
                    p.nearby(center, radius, kind),
                    brute(p, t, center, radius, kind)
                );
            }
            let index = |center| p.nearby(center, black_box(radius), black_box(kind));
            let scan = |center| brute(p, t, center, black_box(radius), black_box(kind));
            // Warm both full paths before collecting five measurements.
            let warm_index = measure(&centers, index);
            let warm_brute = measure(&centers, scan);
            assert_eq!((warm_index.1, warm_index.2), (warm_brute.1, warm_brute.2));
            let mut indexed = vec![];
            let mut scanned = vec![];
            for repeat in 0..5 {
                let (a, b) = if repeat % 2 == 0 {
                    (measure(&centers, index), measure(&centers, scan))
                } else {
                    let b = measure(&centers, scan);
                    let a = measure(&centers, index);
                    (a, b)
                };
                assert_eq!((a.1, a.2), (warm_index.1, warm_index.2));
                assert_eq!((a.1, a.2), (b.1, b.2));
                indexed.push(a.0);
                scanned.push(b.0);
            }
            indexed.sort_unstable();
            scanned.sort_unstable();
            let (a, b) = (indexed[2] as f64, scanned[2] as f64);
            let label = if radius == usize::MAX {
                "MAX".to_string()
            } else {
                radius.to_string()
            };
            println!(
                "{label},{},{:.3},{:.3},{:.1},{:.1},{:.3},{},{}",
                if kind.is_none() { "all" } else { "herbivore" },
                a / 1e6,
                b / 1e6,
                a / 4096.,
                b / 4096.,
                b / a,
                warm_index.2,
                warm_index.1
            );
        }
    }
}

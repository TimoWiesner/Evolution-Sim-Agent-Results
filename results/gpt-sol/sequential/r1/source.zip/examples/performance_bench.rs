#[path = "support/performance.rs"]
mod performance;
use serde_json::json;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    let mut mixed = false;
    let mut repeats = None;
    let mut i = 0;
    while i < args.len() {
        let value = args.get(i + 1).ok_or("missing option value")?;
        match args[i].as_str() {
            "--workload" => {
                mixed = match value.as_str() {
                    "mixed" => true,
                    "primary" => false,
                    _ => return Err("invalid workload".into()),
                }
            }
            "--repeats" => {
                let n: usize = value.parse()?;
                if n == 0 {
                    return Err("repeats must be positive".into());
                }
                repeats = Some(n);
            }
            _ => return Err("unknown option".into()),
        }
        i += 2;
    }
    let n = repeats.unwrap_or(if mixed { 9 } else { 5 });
    let mut runs = Vec::new();
    for _ in 0..n {
        runs.push(performance::measure(mixed)?);
    }
    assert!(
        runs.iter()
            .all(|r| r["state_hash"] == runs[0]["state_hash"])
    );
    let mut rates: Vec<_> = runs
        .iter()
        .map(|r| r["ticks_per_second"].as_f64().unwrap())
        .collect();
    rates.sort_by(f64::total_cmp);
    let median = if n % 2 == 0 {
        (rates[n / 2 - 1] + rates[n / 2]) / 2.
    } else {
        rates[n / 2]
    };
    let (config, warmup, ticks) = performance::workload(mixed);
    println!(
        "{}",
        serde_json::to_string_pretty(
            &json!({"schema":1,"build":if cfg!(debug_assertions){"debug"}else{"release"},
        "workload":if mixed{"mixed"}else{"primary"},"effective_config":serde_json::from_str::<serde_json::Value>(&config.to_json()?)?,
        "warmup_ticks":warmup,"measured_ticks":ticks,"repeats":n,"median_ticks_per_second":median,
        "min_ticks_per_second":rates[0],"max_ticks_per_second":rates[n-1],"runs":runs})
        )?
    );
    Ok(())
}

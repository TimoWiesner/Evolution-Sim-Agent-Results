mod support {
    pub mod ecology;
}
use support::ecology::{fixed, run};
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let seeds = [0, 1, 2, 42, 99];
    let mut runs = Vec::new();
    for seed in seeds {
        eprintln!("Running seed {seed} for 10000 ticks");
        let mut result = run(fixed(seed, [400, 120, 20]), 10000)?;
        result["seed"] = serde_json::json!(seed);
        eprintln!("seed {seed}: {}", result["kinds"]);
        runs.push(result);
    }
    println!(
        "{}",
        serde_json::to_string_pretty(&serde_json::json!({"schema":1,"ticks":10000,"seeds":seeds,
        "scenario":{"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}},"runs":runs}))?
    );
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn absent_and_surviving_conventions() {
        let r = run(fixed(42, [1, 0, 0]), 1).unwrap();
        assert_eq!(r["tick_end"], 1);
        assert_eq!(r["kinds"]["herbivores"]["first_zero_tick"], 0);
        assert_eq!(r["kinds"]["herbivores"]["survived"], false);
        assert!(r["kinds"]["plants"]["first_zero_tick"].is_null());
        assert_eq!(r["kinds"]["plants"]["survived"], true);
        let r = run(fixed(42, [0, 0, 0]), 25).unwrap();
        assert_eq!(r["tick_end"], 25);
        for name in support::ecology::NAMES {
            assert_eq!(r["kinds"][name]["first_zero_tick"], 0);
        }
    }
}

//! Observers used by the example and integration tests; never fed into the engine.
use evosim::{
    config::Config,
    organism::{DeathCause, ENERGY_CAPACITY, Kind},
    simulation::Simulation,
};
use serde_json::{Value, json};
use std::collections::{BTreeMap, BTreeSet};

pub fn fixed(seed: u64, counts: [usize; 3]) -> Config {
    Config::from_json(
        &json!({"seed":seed,"world":{"width":64,"height":48},
        "initial":{"plants":counts[0],"herbivores":counts[1],"carnivores":counts[2]}})
        .to_string(),
    )
    .unwrap()
}
pub const NAMES: [&str; 3] = ["plants", "herbivores", "carnivores"];
#[derive(Default)]
pub struct Observer {
    pub first_zero: [Option<u64>; 3],
    frozen_births: [Option<u128>; 3],
}
impl Observer {
    pub fn audit(&mut self, s: &Simulation) {
        let p = s.population();
        let totals = p.totals();
        let mut members = BTreeMap::new();
        let mut live = [0u128; 3];
        let mut species = [BTreeSet::new(), BTreeSet::new(), BTreeSet::new()];
        for o in p.iter() {
            if o.generation() == 0 {
                assert!(o.parents().is_empty());
                assert_eq!(o.birth_tick(), 0);
            } else {
                assert_eq!(
                    o.parents().len(),
                    if o.kind() == Kind::Plant { 1 } else { 2 }
                );
                assert!(o.parents().iter().all(|id| id.value() < o.id().value()));
                assert!(o.birth_tick() > 0);
            }
            let i = Kind::ALL.iter().position(|k| *k == o.kind()).unwrap();
            live[i] += 1;
            species[i].insert(o.species_id());
            *members.entry(o.species_id()).or_insert(0u128) += 1;
            assert!(o.energy().is_finite() && o.energy() > 0. && o.energy() <= ENERGY_CAPACITY);
            assert!(
                o.health().is_finite() && o.health() > 0. && o.health() <= o.traits().max_health()
            );
            assert_eq!(o.age(), s.tick() - o.birth_tick());
            assert!(o.position().x() < s.config().world().width());
            assert!(o.position().y() < s.config().world().height());
            let r = p.species().get(o.species_id()).unwrap();
            assert_eq!(r.kind(), o.kind());
            assert_eq!(r.extinction_tick(), None);
        }
        for r in p.species().iter() {
            assert_eq!(r.living_members(), *members.get(&r.id()).unwrap_or(&0));
            assert_eq!(r.extinction_tick().is_some(), r.living_members() == 0);
            if let Some(t) = r.extinction_tick() {
                assert!(t <= s.tick());
                assert_eq!(r.living_members(), 0);
            }
        }
        for (i, k) in Kind::ALL.into_iter().enumerate() {
            assert_eq!(live[i], p.counts().get(k));
            assert_eq!(
                totals.initial.get(k) + totals.births.get(k),
                totals.deaths.get(k) + live[i]
            );
            assert_eq!(
                totals.deaths.get(k),
                DeathCause::ALL
                    .into_iter()
                    .map(|c| p.deaths_by_cause(k, c))
                    .sum::<u128>()
            );
            assert_eq!(species[i].len(), p.species().living_count(k));
            if let Some(b) = self.frozen_births[i] {
                assert_eq!(live[i], 0);
                assert_eq!(totals.births.get(k), b);
            }
            if live[i] == 0 && self.first_zero[i].is_none() {
                self.first_zero[i] = Some(s.tick());
                self.frozen_births[i] = Some(totals.births.get(k));
            }
        }
        assert_eq!(s.world().temporal_climate().tick(), s.tick());
    }
    pub fn result(&self, s: &Simulation) -> Value {
        let mut result = serde_json::Map::new();
        for (i, k) in Kind::ALL.into_iter().enumerate() {
            result.insert(NAMES[i].into(), json!({"first_zero_tick":self.first_zero[i],
                "survived":s.population().counts().get(k)>0,"final":s.population().counts().get(k),
                "births":s.population().totals().births.get(k),"deaths":s.population().totals().deaths.get(k)}));
        }
        Value::Object(result)
    }
}
pub fn run(config: Config, ticks: u64) -> Result<Value, Box<dyn std::error::Error>> {
    let effective: Value = serde_json::from_str(&config.to_json()?)?;
    let mut s = Simulation::new(config)?;
    let mut observer = Observer::default();
    observer.audit(&s);
    let start = std::time::Instant::now();
    let mut coexistence_ticks = 0u64;
    for _ in 0..ticks {
        s.advance_one_tick()?;
        observer.audit(&s);
        if Kind::ALL
            .into_iter()
            .all(|k| s.population().counts().get(k) > 0)
        {
            coexistence_ticks += 1;
        }
    }
    Ok(
        json!({"effective_config":effective,"tick_end":s.tick(),"kinds":observer.result(&s),
        "coexistence_ticks":coexistence_ticks,"elapsed_seconds":start.elapsed().as_secs_f64()}),
    )
}

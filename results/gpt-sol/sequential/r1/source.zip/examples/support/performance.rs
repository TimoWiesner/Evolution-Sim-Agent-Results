//! External observer shared by the release benchmark and catastrophic slowdown guard.
use evosim::{config::Config, organism::Kind, persistence::state_hash, simulation::Simulation};
use serde_json::{Value, json};
use std::{hint::black_box, time::Instant};
pub fn workload(mixed: bool) -> (Config, u64, u64) {
    if mixed {
        (Config::from_json(r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":2400,"herbivores":120,"carnivores":20}}"#).unwrap(), 10, 100)
    } else {
        (
            Config::from_json(include_str!("../../scenarios/performance.json")).unwrap(),
            100,
            1000,
        )
    }
}
fn counts(s: &Simulation) -> [u128; 3] {
    Kind::ALL.map(|k| s.population().counts().get(k))
}
pub fn measure(mixed: bool) -> Result<Value, Box<dyn std::error::Error>> {
    let (config, warmup, ticks) = workload(mixed);
    let mut s = Simulation::new(config)?;
    for _ in 0..warmup {
        s.advance_one_tick()?;
    }
    let initial = counts(&s);
    let mut min = initial;
    let mut max = initial;
    let mut min_total = initial.iter().sum::<u128>();
    let mut max_total = min_total;
    let mut sum = 0u128;
    let start = Instant::now();
    for _ in 0..ticks {
        black_box(s.advance_one_tick()?);
        let c = counts(&s);
        let total = c.iter().sum::<u128>();
        assert!(total >= 2000, "population floor at {}: {total}", s.tick());
        min_total = min_total.min(total);
        max_total = max_total.max(total);
        sum += total;
        for i in 0..3 {
            min[i] = min[i].min(c[i]);
            max[i] = max[i].max(c[i]);
        }
    }
    let seconds = start.elapsed().as_secs_f64();
    assert!(seconds.is_finite() && seconds > 0.);
    assert_eq!(s.tick(), warmup + ticks);
    assert!(min_total >= 2000);
    let totals = s.population().totals();
    Ok(
        json!({"seconds":seconds,"ticks_per_second":ticks as f64/seconds,
        "population_min":min_total,"population_max":max_total,"population_mean":sum as f64/ticks as f64,
        "kinds_start":initial,"kinds_end":counts(&s),"kinds_min":min,"kinds_max":max,
        "births":Kind::ALL.map(|k|totals.births.get(k)),"deaths":Kind::ALL.map(|k|totals.deaths.get(k)),
        "tick_end":s.tick(),"state_hash":state_hash(&s)?}),
    )
}

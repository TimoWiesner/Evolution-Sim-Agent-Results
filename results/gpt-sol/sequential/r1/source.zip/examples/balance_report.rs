//! Read-only, streaming ecological experiment observer. Never feeds counts to policy.
use evosim::{
    config::{Config, Seed},
    organism::{DeathCause, Kind},
    persistence::state_hash,
    simulation::Simulation,
};
use serde_json::{Value, json};
use std::{
    fs,
    io::{BufWriter, Write},
    path::PathBuf,
};
const NAMES: [&str; 3] = ["plants", "herbivores", "carnivores"];
fn counters(s: &Simulation) -> Value {
    let p = s.population();
    let t = p.totals();
    let mut v = json!({});
    for (i, k) in Kind::ALL.into_iter().enumerate() {
        let mut causes = json!({});
        for c in DeathCause::ALL {
            causes[format!("{c:?}")] = json!(p.deaths_by_cause(k, c));
        }
        v[NAMES[i]] = json!({"count":p.counts().get(k),"initial":t.initial.get(k),"births":t.births.get(k),"deaths":t.deaths.get(k),"causes":causes});
    }
    v
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    let a: Vec<String> = std::env::args().skip(1).collect();
    let get = |key: &str| -> Result<&str, String> {
        a.windows(2)
            .find(|p| p[0] == key)
            .map(|p| p[1].as_str())
            .ok_or(format!("missing {key}"))
    };
    let config = Config::from_json(&fs::read_to_string(get("--config")?)?)?;
    let ticks: u64 = get("--ticks")?.parse()?;
    let out = PathBuf::from(get("--out-dir")?);
    fs::create_dir_all(&out)?;
    let mut runs = vec![];
    for token in get("--seeds")?.split(',') {
        let seed = Seed::from_decimal(token)?;
        let mut s = Simulation::new(config.with_seed(seed.clone()))?;
        let effective: Value = serde_json::from_str(&s.config().to_json()?)?;
        let mut csv = BufWriter::new(fs::File::create(out.join(format!("seed-{token}.csv")))?);
        write!(csv, "tick")?;
        for n in NAMES {
            write!(csv, ",{n},{n}_births,{n}_deaths")?;
            for c in DeathCause::ALL {
                write!(csv, ",{n}_{c:?}")?;
            }
        }
        writeln!(csv)?;
        let mut zero = [None; 3];
        let mut ext = json!({});
        for tick in 0..=ticks {
            if tick > 0 {
                s.advance_one_tick()?;
            }
            write!(csv, "{tick}")?;
            for (i, k) in Kind::ALL.into_iter().enumerate() {
                let p = s.population();
                let t = p.totals();
                write!(
                    csv,
                    ",{},{},{}",
                    p.counts().get(k),
                    t.births.get(k),
                    t.deaths.get(k)
                )?;
                for c in DeathCause::ALL {
                    write!(csv, ",{}", p.deaths_by_cause(k, c))?;
                }
                if p.counts().get(k) == 0 && zero[i].is_none() {
                    zero[i] = Some(tick);
                    ext[NAMES[i]] = json!({"tick":tick,"counters":counters(&s)});
                }
            }
            writeln!(csv)?;
        }
        csv.flush()?;
        let score = zero.into_iter().flatten().min().unwrap_or(ticks);
        runs.push(json!({"seed":seed.as_decimal(),"effective_config":effective,"tick_end":ticks,"first_zero":zero,"coexistence":score,"right_censored":zero.iter().all(Option::is_none),"first_kinds":NAMES.into_iter().enumerate().filter(|(i,_)|zero[*i]==Some(score)).map(|(_,n)|n).collect::<Vec<_>>(),"extinctions":ext,"final":counters(&s),"state_hash":state_hash(&s)?}));
        eprintln!("seed {token}: {zero:?}");
    }
    fs::write(
        out.join("observer.json"),
        serde_json::to_string_pretty(&json!({"ticks":ticks,"runs":runs}))?,
    )?;
    Ok(())
}

#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
for tool in rustc cargo rustup; do
    command -v "$tool" >/dev/null 2>&1 || { echo "setup: required tool missing: $tool (install Rust 1.85+ with rustup)" >&2; exit 1; }
done
if ! command -v musl-gcc >/dev/null 2>&1; then
    apt-get update
    apt-get install -y --no-install-recommends musl-tools
fi
if ! rustup target list --installed | grep -qx x86_64-unknown-linux-musl; then
    rustup target add x86_64-unknown-linux-musl
fi
if ! command -v node >/dev/null 2>&1; then
    apt-get update
    apt-get install -y --no-install-recommends nodejs
fi
node -e 'if(Number(process.versions.node.split(".")[0]) < 18) { console.error("setup: UI automation requires Node >=18"); process.exit(1); }'
cargo build --locked --release
cargo build --locked --release --target x86_64-unknown-linux-musl

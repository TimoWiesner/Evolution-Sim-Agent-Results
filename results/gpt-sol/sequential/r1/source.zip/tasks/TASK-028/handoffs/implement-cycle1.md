# TASK-028 IMPLEMENT cycle1

Completed the approved reliability/delivery plan without production-engine or UI
feature changes. Read required workspace/product/contract/state/architecture,
TASK-028 plan/task/skill, dependency handoffs (latest reviews PASS) and relevant
ADRs. Required initial files existed, initial Git tree clean and remotes empty.
No packages installed, commits made, protected files altered or phase advanced.

## Delivered

- `tests/reliability.rs`: independent LCG72-case configuration/seed corpus,64
  horizons128..256,8x2200. Explicit empty/tiny/stacked/one-axis; optional parameter
  endpoints/interiors. Full Simulation equality each tick, one-sided observation,
  hashes every31/boundaries,16 restored midpoints, distinct seed hash, independent
  geometry/accounting/causes/vitals/resources/climate/age/parents/species/clock.
  Final29838 completed states,97353 moving animal ticks,3109 births,4240 deaths.
- `tests/test_reliability.py`:2 tests discovered by unchanged test.sh. Exact
  observer synthetic boundary/censor/tie/corruption/hash fixtures. Test-only Linux
  x86-64 seccomp denies socket/connect/socketpair for actual static version/run/
  save/load/batch; Python socket negative control proves EPERM. Existing real
  copied empty-chroot/static-ELF tests reused unchanged and actually run as root.
- `tools/release_verify.py`: external stdlib command/provenance/validation runner,
  modes contract/long/validate, argument arrays, UTC/wall/deadline/status/log ledger.
  Reuses unchanged balance_report production observer and row validator. Requires
  CLI files in formal mode, exact final counts/totals/hash. Writes validated
  completion only after checks. Digest manifest excludes itself; final provenance
  distinguishes baseline runtime source/binaries from uncommitted delivery files.
- `tasks/TASK-028/verify-ui.py`:serial actual default/demo smoke/screenshots with
  60/120 deadlines,10/100 ticks,draws and hash parity,1440x900 main, short batches.
- D0..D3 on0/1/2 at10000 ticks; highest median/minimum rule chooses D3 (1113/1110).
  Freeze timestamp/digest precedes formal42..44. Demo64x48 initial2000/60/8,
  regeneration4,animal cooldown300,other defaults. No engine tuning/rescue.
- Six formal10000 CLI runs, matching exact observer CSVs and curves. Fixed first
  zeros315/315/310; demo1111/1113/1112, plants first; positive completed ticks F-1.
  Every formal world ultimately empty; no censoring/durable coexistence claim.
- README installation/run/batch/UI/config/demo/results; VERIFICATION contract
  matrix/commands/evidence; SELF_AUDIT every PROJECT subrequirement,status,limits.
  STATE/ARCHITECTURE retain external observation/state-boundary and package facts.

## Actual checks and failures

All exact commands/statuses are in implement-cycle1.json, VERIFICATION.md and
retained command ledgers/logs under evidence. Initial Rust targeted test failed
exit101 because json! array-index expressions needed parentheses; corrected test
syntax, with original stderr retained. No production defect was demonstrated.
Targeted final Rust test passes20–26s; Python2 tests pass; release contract probes
host/musl pass, including unreadable root600 config under numeric uid/gid65534.

Final isolated `./test.sh > tasks/TASK-028/evidence/full-suite.log 2>&1` exits0:
233 Rust passed,26 Python passed,all3 Node scripts passed. Exactly1 intentional
debug performance ignore is exercised in release:859.515/s,min2304,tick1100.
No Python skip or remaining failure. Static copied-root check runs as root.
Actual browser default/demo smoke/screenshots all pass, no browser concurrency.
Formatting-only line breaks were added to the randomized config token tree after
suite compilation; no test expression or behavior changed. Final fmt/diff checks
and task-local handoff/evidence/source/binary/scope validator pass.

## Plan refinements/deviations and limitations

Reused existing comprehensive launcher/packaging tests instead of duplicating
all their cases in a new Python test; short release runner supplements them.
No full-suite baseline before changes: setup/build, targeted tests, then mandatory
final isolated full suite. No tests or required acceptance behavior omitted.
D3 exploratory measurement overlapped the randomized test; initial fixed formal
launch was near its end. All still satisfy wall deadlines; these are completion
measurements, not controlled performance comparisons. Formal demo/browser/suite
were isolated. Trial first-zero selection is deterministic and timing-independent.
No automatic green retries; initial compile failure preserved.

Self-audit openly marks unresolved long coexistence and generation visualization
as partly met: generation max/mean series exist in output and generation in
inspector, but no dedicated generation chart. This task forbids new features.
Original performance-primary replacement is plant-focused (no herbivores), and
10/s guard is weaker than100/s goal; current workload measured859.5/s. Exact
cross-GNU/musl float identity, physical fresh-OS provisioning, arbitrary huge valid
allocations, unlimited history, transactional/fsync multi-file publication and
future checkpoint migration are not claimed. JSON-only config is allowed.

No new system dependency; setup found installed prerequisites. Existing STATE
exact install commands remain the reinstall source. No network publishing/Git
remote/commit. Review should rerun the read-only final validator, inspect the
matrix/manifest and audit, and independently sample contract/demo/browser checks;
only harness may transition phase. No blocker or TASK-028 acceptance gap remains.

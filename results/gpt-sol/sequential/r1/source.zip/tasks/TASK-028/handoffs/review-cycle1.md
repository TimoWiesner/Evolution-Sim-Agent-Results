# TASK-028 REVIEW cycle 1

Verdict: PASS. All eight TASK-028 acceptance criteria are met; no actionable gaps.

Verified AGENTS.md and STATE.md exist first. Read project/contract/task, phase
skill, task plan/implementation handoffs, dependency handoffs and relevant ADRs.
Reviewed committed implementation diff ec77ebd..f0db1e2, test/helper code, existing
contract tests, delivery documents, source/state boundary and actual screenshots.
Initial tree clean, no Git remotes. No product/protected/task specification edits,
packages, commits or phase transitions. Workspace review skill applied.

## Acceptance evidence

1. Every contract command/behavior: VERIFICATION.md clause matrix maps concrete
   assertions to tests/logs. Fresh complete suite and separate host/musl contract
   runner pass, including sampling, seed override, split save/load, cumulative
   counters, standalone/batch parity, invalid/unreadable inputs, status2 and clean
   output. Existing UI server/browser tests cover ordinary interactive use.
2. Self-contained build: fresh suite runs setup twice and build from unrelated
   spaced cwd, checks executable modes/static ELF and executes copied version/run/
   save/load/batch in otherwise empty chroot as root. No packaging skip. New
   seccomp test denies networking with EPERM negative control and static commands.
3. At least three seeds through10000: independently replayed all six formal runs,
   fixed and demo on42/43/44. Each tick_end10000, silent success; final/totals/
   series/hash/seed/world exactly equal retained outputs. Whole-process replay
   times0.46..0.98s, far below300/900s. Original ledgers also meet deadlines.
4. Randomized invariants: read tests/reliability.rs and reran in full suite:
   72 seeds/configurations, eight2200-tick cases, full engine equality, independent
   accounting/geometry/ranges, zero absorption and16 checkpoint continuations.
   Corpus is bounded and supplemented by nonvacuous reproduction/speciation tests.
5. One-command suite: ./test.sh exit0;233 Rust tests,26 Python tests,3 Node scripts.
   Intentional debug timing ignore is explicitly run release:859.573 ticks/s,
   minimum2304 organisms. No failure, retry or Python skip in this review.
6. README covers setup/build/copy, run/save/load/batch/UI, parameter groups/schema,
   test command and one-command scenarios/demo.json UI launch.
7. Formal coexistence: independently scanned all10001 CSV rows per formal run;
   contiguous ticks, accounting, death-cause sums, monotone totals and absorbing
   zeros agree. Fixed first zeros315/315/310; demo1111/1113/1112. README correctly
   distinguishes interval[0,F) from F-1 positive completed ticks. Demo JSON matches
   frozen D3 digest, selected using separate0/1/2 trials before formal runs.
8. SELF_AUDIT enumerates every PROJECT requirement and honest limits. Generation
   visualization, long coexistence and sustained population target are partly
   met; neither a new chart nor stable ecology is TASK-028 acceptance scope.

## Independent artifact and browser checks

review-checks.py verifies all293 retained artifact digests, current production
source digests, fixed-only input, demo freeze/selection, six fresh replays and
independent CSV oracles. No production/Cargo/UI/setup/build/test.sh change exists
in implementation diff. Final formatting/whitespace/remotes checks pass. The
implementation validator intentionally assumes an uncommitted implementation;
review uses its own checks against the committed phase instead.

Fresh release contract runner passes35 recorded commands; review-contract.json
retains exact arguments/status/deadlines. Fresh demo actual-browser screenshots
exit0 before120s at exactly100 ticks, positive draws,1440x900 PNG and headless
hash parity. review-ui.json retains both actual commands and rendering/hash
observations; review-demo.png is the captured interface. Browser commands were
run after the isolated complete suite and release replay checks.

Logs: review-suite.log, review-checks.log, review-contract.log.
Structured measurements: review-measurements.json, review-contract.json,
review-ui.json. Replay result files are reproducible ignored target/task028-review
artifacts; original full results/curves remain tracked in evidence/.

## Limits and disposition

All formal worlds end empty; demo extends first-zero time without durable
coexistence. Generation data lacks a dedicated UI chart. Plant-focused performance
and weak10/s regression threshold are disclosed;859.573/s is measured only for
that workload. Bounded random seeds cannot prove exhaustive correctness; empty
chroot/static/syscall denial is runtime-independence evidence, not fresh physical
OS provisioning. Prior intermittent browser readiness failure did not recur.
No acceptance remediation required. Harness owns completion, commits and transitions.

"""Independent retained-artifact audit and fresh six-run release replay."""
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/workspace')
E = ROOT / 'tasks/TASK-028/evidence'
OUT = ROOT / 'target/task028-review'
OUT.mkdir(parents=True, exist_ok=True)
def read(p):
    return json.loads(p.read_text(encoding='utf-8'))
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

manifest = read(E / 'manifest.json')
assert set(manifest) == {str(p.relative_to(E)) for p in E.rglob('*') if p.is_file() and p.name != 'manifest.json'}
for p, digest in manifest.items():
    assert sha(E / p) == digest, p
for p, digest in read(E / 'provenance.json')['sources'].items():
    assert sha(ROOT / p) == digest, p
assert read(E / 'fixed.json') == dict(seed=42, world=dict(width=64, height=48), initial=dict(plants=400, herbivores=120, carnivores=20))
selection = read(E / 'selection.json')
assert selection['chosen'] == 'D3'
assert sha(ROOT / 'scenarios/demo.json') == selection['sha256']
assert read(ROOT / 'scenarios/demo.json') == read(E / 'D3.json')
names = ('plants', 'herbivores', 'carnivores')
results = []
for label, expected in [('fixed', [315,315,310]), ('demo', [1111,1113,1112])]:
    directory = E / label
    config = E / 'fixed.json' if label == 'fixed' else ROOT / 'scenarios/demo.json'
    records = read(directory / 'commands.json')
    assert all(c['returncode'] == 0 and not c['timeout'] and c['wall_seconds'] < c['deadline_seconds'] for c in records)
    assert selection['frozen_at'] < records[0]['start']
    observer = read(directory / 'observer.json')
    for index, seed in enumerate([42,43,44]):
        rows = list(csv.DictReader((directory / f'seed-{seed}.csv').open()))
        assert len(rows) == 10001
        assert [int(row['tick']) for row in rows] == list(range(10001))
        initial = read(config)['initial']
        zeros = []
        for name in names:
            zero = None
            prev_b = prev_d = 0
            for t,row in enumerate(rows):
                n,b,d = (int(row[name+s]) for s in ['', '_births', '_deaths'])
                assert n >= 0 and b >= prev_b and d >= prev_d
                assert initial[name] + b - d == n
                assert sum(int(row[name+'_'+c]) for c in ['Starvation','Injury','Predation','OldAge','Climate']) == d
                if zero is not None:
                    assert n == 0 and b == prev_b
                if n == 0 and zero is None:
                    zero = t
                prev_b,prev_d = b,d
            zeros.append(zero)
        assert min(zeros) == expected[index]
        run = next(r for r in observer['runs'] if str(r['seed']) == str(seed))
        assert run['first_zero'] == zeros
        output = OUT / f'{label}-{seed}.json'
        argv = [str(ROOT/'evosim'),'run','--config',str(config),'--seed',str(seed),'--ticks','10000','--out',str(output)]
        start = time.monotonic()
        p = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=300 if label=='fixed' else 900)
        elapsed = time.monotonic()-start
        assert p.returncode == 0 and not p.stdout and not p.stderr, p
        actual, original = read(output), read(directory/f'seed-{seed}.json')
        for key in ['final','totals','series','state_hash','tick_start','tick_end','seed','world']:
            assert actual[key] == original[key], (label,seed,key)
        assert actual['tick_end'] == 10000
        assert actual['state_hash'] == run['state_hash']
        assert re.fullmatch('[0-9a-f]{64}', actual['state_hash'])
        results.append(dict(argv=argv,exit_code=p.returncode,wall_seconds=elapsed,first_zero=zeros,state_hash=actual['state_hash']))

suite = (ROOT/'tasks/TASK-028/handoffs/review-suite.log').read_text()
assert 'FAILED' not in suite and '\nOK\n' in suite and '... skipped' not in suite
rust = sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',suite)))
assert rust == 233, rust
assert 'Ran 26 tests' in suite
assert 'test_copied_distribution_in_empty_root (test_entrypoints.Entrypoints.test_copied_distribution_in_empty_root) ... ok' in suite
assert not subprocess.check_output(['git','remote','-v'],cwd=ROOT)
assert not subprocess.check_output(['git','diff','ec77ebd','f0db1e2','--','src','ui','Cargo.toml','Cargo.lock','setup.sh','build.sh','test.sh'],cwd=ROOT)
subprocess.run(['cargo','fmt','--check'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
(ROOT/'tasks/TASK-028/handoffs/review-measurements.json').write_text(json.dumps(dict(manifest_entries=len(manifest),rust_passed=rust,python_passed=26,replays=results),indent=2)+'\n')
print(f'PASS: {len(manifest)} digests, six exact 10000-tick replays, independent CSV/accounting/zero checks,233 Rust/26 Python suite, unchanged production,formatting,no remotes')

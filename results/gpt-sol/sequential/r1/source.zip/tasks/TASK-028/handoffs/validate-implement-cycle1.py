"""Final task-local delivery/scope check; read-only after manifest generation."""
import hashlib
import json
from pathlib import Path
import subprocess
ROOT=Path('/workspace')
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
r=ROOT/'tasks/TASK-028/evidence'
h=json.loads((ROOT/'tasks/TASK-028/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}<=h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-028','implement',1,'N/A')
assert type(h['cycle']) is int and h['gaps']==[]
for key in ['changed_files','decisions','tests','risks','next_steps','gaps']:assert isinstance(h[key],list)
for t in h['tests']:assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
changed=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert changed==set(h['changed_files']),(changed-set(h['changed_files']),set(h['changed_files'])-changed)
allowed={'README.md','docs/VERIFICATION.md','docs/SELF_AUDIT.md','docs/STATE.md','docs/ARCHITECTURE.md','tests/reliability.rs','tests/test_reliability.py','tools/release_verify.py','scenarios/demo.json'}
assert all(p in allowed or p.startswith('tasks/TASK-028/evidence/') or p.startswith('tasks/TASK-028/handoffs/implement-cycle1.') or p in ['tasks/TASK-028/verify-ui.py','tasks/TASK-028/handoffs/validate-implement-cycle1.py'] for p in changed),changed-allowed
assert not git('remote','-v')
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['cargo','fmt','--check'],cwd=ROOT,check=True)
manifest=json.loads((r/'manifest.json').read_text())
assert set(manifest)=={str(p.relative_to(r)) for p in r.rglob('*') if p.is_file() and p.name!='manifest.json'}
for rel,digest in manifest.items():assert sha(r/rel)==digest,rel
provenance=json.loads((r/'provenance.json').read_text())
for rel,digest in provenance['sources'].items():assert sha(ROOT/rel)==digest,rel
for rel,digest in provenance['binaries'].items():assert sha(ROOT/rel)==digest,rel
selection=json.loads((r/'selection.json').read_text());assert sha(ROOT/'scenarios/demo.json')==selection['sha256'] and selection['chosen']=='D3'
for label in ['fixed','demo']:
    summary=json.loads((r/label/'validated.json').read_text());assert summary['horizon']==10000 and summary['seeds']==['42','43','44']
    for run in summary['runs']:assert run['positive_completed_ticks']==run['first_zero']-1 and not run['right_censored']
    records=json.loads((r/label/'commands.json').read_text())
    assert len(records)==4 and all(c['returncode']==0 and not c['timeout'] and c['wall_seconds']<c['deadline_seconds'] for c in records)
    assert provenance['sources']==json.loads((r/label/'provenance.json').read_text())['sources']
for path in r.rglob('commands.json'):
    for c in json.loads(path.read_text()):assert c['returncode']==c['expected_returncode'] and not c['timeout'],c
suite=json.loads((r/'test-summary.json').read_text());assert suite['exit_code']==0 and suite['rust_passed']==233 and suite['python_passed']==26 and suite['python_skipped']==0
log=(r/'full-suite.log').read_text();assert '\nOK\n' in log and 'FAILED' not in log and '... skipped' not in log
assert 'test_copied_distribution_in_empty_root (test_entrypoints.Entrypoints.test_copied_distribution_in_empty_root) ... ok' in log
for label in ['default','demo']:
    p=r/'ui'/label/'main.png';raw=p.read_bytes();assert raw[:8]==b'\x89PNG\r\n\x1a\n' and int.from_bytes(raw[16:20],'big')>=1280 and int.from_bytes(raw[20:24],'big')>=720
assert len(json.loads((r/'ui/validated.json').read_text()))==4
print(f'PASS: handoff, {len(changed)} allowed paths, {len(manifest)} artifact digests, binaries/sources, 6 formal runs, UI, suite, no remotes, formatting')

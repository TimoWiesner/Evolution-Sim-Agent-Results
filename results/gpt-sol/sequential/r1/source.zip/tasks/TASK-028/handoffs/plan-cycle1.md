# TASK-028 PLAN cycle 1 — reliability and delivery

## Entry and boundaries

Verified /workspace/AGENTS.md and /workspace/docs/STATE.md exist before reads.
Applied .agents/skills/plan/SKILL.md. Read task/project/contract, current state and
architecture, dependency phase JSON handoffs and relevant ADRs, source/tests,
configuration, balance and delivery documentation. There were no TASK-028 handoffs.
TASK-018/021/022/025/026/027 latest reviews all PASS, gaps empty. No replan gaps.
Initial Git tree clean; git remote -v empty. No package installation, feature code,
benchmark/task/skill edits, commit or phase transition. Work stays in /workspace.

This phase specifies work only. Inherited suite success is not fresh TASK-028
acceptance evidence. The baseline below verifies existing behavior only. Harness
assigns IMPLEMENT and owns all commits/transitions.

## Findings that determine the plan

- Rust core, CLI, embedded browser, canonical schema1/checkpoint envelope1 already
  work. Hunting model2 deliberately rejects old model1 checkpoints. ADR-001..004,
  015/017/018/019/020 remain authoritative; no new architecture ADR is necessary.
- test.sh already runs cargo tests, explicit ignored release performance guard,
  three Node scripts and Python discovery. Packaging tests run setup twice/build
  from unrelated spaced paths, inspect static ELF and execute version/run/batch/
  save/load in an empty chroot. Reuse rather than duplicate those mechanisms.
- tests/run_cli.rs/checkpoint_cli.rs/batch_cli.rs cover sampling, errors, aliases,
  replay and split continuation. Current config validation is strict JSON; all21
  leaves/defaults/ranges are documented in docs/CONFIGURATION.md. README lacks a
  release demo and final measured coexistence/audit. scenarios/demo.json is absent.
- Existing topology tests exhaust tiny worlds and spatial tests randomize queries;
  multi-seed ecology tests audit fixed configs. Missing delivery work is a clearly
  reproducible combined randomized configuration/seed corpus and consolidated
  evidence that maps every contract clause and project requirement to checks.
- examples/balance_report.rs already streams tick0..N counts, births/deaths/causes,
  exact first zeros and final hash. Its coexistence field is first-zero time,
  whereas examples/support/ecology.rs counts positive *completed* ticks. Define
  both explicitly; never infer extinction from batch's sparse100-tick samples.
- Current TASK-027 held-out first zero313..320 is a delay, not durable coexistence;
  every chosen world eventually empties. TASK-018 numbers precede model2 and must
  not be presented as current defaults. The performance primary was changed to
  plant-focused4600/0/40 after a real population-floor failure. Preserve disclosure.
- TASK-027 review observed a browser readiness timeout; unchanged isolated UI and
  full reruns passed. Full suite and browser commands must be isolated because
  profile-inventory assertions inspect concurrent profiles. Retain failures and
  investigate recurrence; do not automatically retry until green or widen bounds.

## Decisions and planned files

No new feature, ecology equation, default, runtime dependency, DNA/spatial choice,
state field, checkpoint/hash/model version or public engine API is planned.
Only fix reproducible defects uncovered by verification, with regression coverage
and written scope/reason. No balance mechanism or tuning of product defaults.

| File | Planned responsibility |
|---|---|
| tests/reliability.rs | Deterministic randomized production-engine invariants through public immutable APIs; ordinary cargo test discovery |
| tests/test_reliability.py | Short real launcher contract probes and evidence-helper synthetic tests; Python discovery |
| tools/release_verify.py | Python stdlib external evidence runner/validator; no engine policy; explicit long-run mode |
| tests/test_entrypoints.py | Extend only a proven gap in existing static/copied-root acceptance coverage |
| examples/balance_report.rs | Reuse unchanged; modify only if an actual observer defect is demonstrated |
| scenarios/demo.json | Frozen selected config using existing parameters, seed42 and all three initial kinds |
| tasks/TASK-028/evidence/ | Tracked configs, trial ledger, exact command records/logs, compact summaries, final raw CLI JSON, observer CSV/JSON, selected screenshots and digest manifest |
| docs/VERIFICATION.md | Contract clause matrix, execution environment, commands/results/artifact links and limitations |
| docs/SELF_AUDIT.md | Every PROJECT requirement/status/evidence/qualification, including allowed/forbidden mechanisms |
| README.md | Finished-product install/use/config/test/demo instructions and fresh coexistence table |
| docs/STATE.md, docs/ARCHITECTURE.md | Actual final delivery status, evidence boundaries and dependency record |
| tasks/TASK-028/handoffs/implement-cycle1.md/.json | Actual decisions, failures, exact tests, outcomes, gaps and follow-up |

Keep existing ./test.sh as the one documented whole-suite command. New Rust and
Python files are discovered automatically. Modify test.sh only if an otherwise
undiscovered test target is necessary. Explicit long evidence runs remain separate
release verification commands to avoid bloating the ordinary suite. Full suite
must still include existing multi-thousand-tick tests and the release guard.

### Evidence runner interface and provenance

Implement `python3 tools/release_verify.py --mode contract|long|validate --out-dir DIR`
with root-relative source paths and caller-supplied workspace-contained output.
No shell interpolation: subprocess argument arrays, explicit cwd/environment,
per-command timeout, flushed JSON command ledger after every completed command.
Long mode accepts `--config FILE --seeds LIST --ticks N` (require >=10000 for formal
runs) and `--label NAME`. Contract mode runs short launcher cases and records
schema/error/replay assertions; validate mode rechecks existing artifacts without
rerunning simulations. Split helpers if useful, without introducing a framework.

Record argv, cwd, selected environment overrides, start/end UTC, return code,
wall seconds, stdout/stderr file paths, assertions and timeout status. Record source
revision plus dirty diff/source/config digests, executable SHA-256, rustc/cargo,
Python/Node/Chromium versions, CPU metadata available through commands within the
workspace restriction, build profile and OS facts supplied by the environment.
Never claim a pristine revision describes uncommitted source. At finalization,
write relative-path SHA-256 manifest for inputs/results/logs; exclude the manifest
itself and describe source versus binary provenance. Do not hash ignored build
outputs as if they were durable tracked evidence. Keep raw failures as well as
successes. Large temporary profiles/binaries stay under ignored target/task028/;
raw formal results and summaries must survive a new process and cleanup of target.

Use existing balance observer for exact completed-tick counts with ordinary engine
ticks, O(1) observer memory, and match CLI final counts/totals/hash for every formal
run (same host release build). Validate all10001 CSV rows, contiguous ticks,
accounting, monotone counters, absorbing zeros and exact first-zero summaries.
Synthetic validator tests cover tick0 absence, extinction at1 and at horizon,
all-positive horizon, ties, malformed/truncated CSV and hash mismatch. Helper
returns nonzero on a mismatch, never writes a passing completion record early.

## Ordered implementation and validation

1. **Inventory and fresh baseline (budget 0–8 minutes).** Read implement skill and
   this plan. Check dependencies and reinstall only missing ones using STATE exact
   commands. Run setup then build locked release bin and balance_report. Capture
   baseline version/environment/source/binary digests and current full-suite log
   if runtime permits; a final full suite is mandatory. Create evidence directories
   and ledger before experiments. Fresh config is exactly contract section3,
   no optional keys. No previous report replaces a current run.
2. **Randomized invariant tests and short contract checks (8–22 minutes).** Add
   tests below; use existing tests as references, independent oracles for expected
   values, no test-only production API. Run targeted tests and repair actual bugs
   only. Complete contract coverage matrix and runner, including negative cases.
3. **Bounded demo comparison then freeze (22–32 minutes).** Measure the candidate
   configurations below on seeds0,1,2 through exactly10000 ticks (empty tails too),
   CLI batch plus observer. Sequential processes; no overlapping timing/suite/UI
   work. Record every attempt/result, then freeze selected scenarios/demo.json
   and its digest before formal seeds. Stop optional exploration when budget is
   reached; retain best completed candidate without claiming unrun alternatives.
4. **Formal long evidence and distribution/UI checks (32–42 minutes).** Fresh
   contract and frozen demo, seeds42,43,44,10000 ticks, at least six CLI runs plus
   matching observer runs. Enforce external whole-process per-run300s contract/
   900s demo deadlines (serial batch wrapper timeout scales with seed count).
   Record actual per-run wall times, tick_end and result timings separately.
   Demo must accept run/batch/ui. Perform real smoke/screenshots serially and
   copied-root distribution checks. If budget cannot fit full worst-case runs,
   run each CLI seed individually with a process deadline capped by remaining
   phase time, record timeout honestly, never certify unfinished acceptance.
5. **Final suite, docs and handoff (42–60 minutes).** Run isolated ./test.sh,
   cargo fmt --check and git diff --check. Preserve full stdout/stderr logs and
   count pass/fail/ignore/skip honestly; intentional debug guard ignore must have
   explicit successful release execution. Finish all documentation and audit,
   validate final evidence and JSON handoff, scope/protected-file/remotes checks.
   Reserve at least8 minutes for suite+handoff; shorten demo exploration first.
   If fixing product code after formal measurements, rerun affected evidence and
   final suite on final binary, do not reuse stale hashes/results.

### Demo choice protocol

Choose a moderate64x48 world to retain contract-scale runtime; no new mechanisms.
Candidate inputs (all seed42; optional leaves otherwise existing defaults):

| ID | Initial P/H/C | Overrides | Rationale |
|---|---|---|---|
| D0 | 400/120/20 | none | Current fixed-only baseline, direct comparator |
| D1 | 2000/60/8 | none | More producers and fewer consumers, bounded area |
| D2 | 2000/60/8 | plants.resource_regeneration=4 | More documented environmental inflow for grazed producers |
| D3 | 2000/60/8 | plants.resource_regeneration=4; animals.reproduction_cooldown=300 | Slower uniform consumer recruitment to limit overshoot |

No automatic population adjustment. All three kinds initially positive. Reproduction
and costs always apply uniformly. Ledger contains full effective configs, seeds,
model identity, horizon, observed outcomes and reasoning. Prefer highest median
first-zero tick on0,1,2, then highest minimum, then fewer optional overrides, then
candidate order. Do not adapt candidates based on formal42..44. If every candidate
collapses, select measured best and state collapse; coexistence target has no
required threshold. No broader TASK-027 mechanism experiment is authorized here.
Formal seeds are validation of delivery rather than a statistical generalization.

Coexistence interval is [0,F) in tick-time units if first zero F; all three positive
at completed ticks1..F-1. Report F and `positive_completed_ticks=min(N,max(0,F-1))`
when any initial kind absent F=0; with no zero through N, F=null, right_censored=true,
positive_completed_ticks=N and say "at least10000 ticks". Do not call F=313 a count
of313 positive completed samples. Report per-kind first zero, first zero of any,
censoring, final counts, hashes, time and seed; README uses labeled columns.

### Randomized corpus and algorithm

Use a small independent test-only fixed-state LCG/xorshift integer generator, no
new crate and no Simulation RNG consumption. Print generator seed, case index,
full effective JSON and tick in failure context. At least64 distinct simulation
seeds/configurations; choose dimensions1..16 by1..12, initial counts0..64/0..16/
0..4 with explicit empty/one-axis/tiny/stacked cases, horizons128..256. Add8 cases
through2200 ticks at bounded small sizes to cross founder lifespans. Randomize
valid endpoints/interiors across climate, genetics, resources and animal settings
(including disabled weather/mutation/movement, zero regeneration/efficiency,
maximum mutation, ordinary/prohibitive birth costs); keep bounded areas/counts,
no enormous allocation/f64 overflow test workload. Existing config tests cover
unrepresentable/invalid extremes. Report exact corpus count and coverage tally.

Each completed tick including0:
- Two fresh engines same Config compare complete Simulation equality, including
  RNG/history/private state via existing PartialEq; hashes at boundaries/every31
  ticks. Observe only one engine between ticks to test observational purity.
- Independent living-kind count and initial+births-deaths ledger; death-cause sum,
  monotone cumulative births/deaths; absorbing zeros freeze births. Living species
  membership/counts agree with records and extinct species do not resurrect.
- Every organism has finite positive energy<=1000 and health<=genetic maximum,
  in-world cell, valid trait bounds/schema, coherent age/birth/cooldown/parents.
  All resource cells finite in[0,capacity]; current climate in[0,1], clock agreement.
- Random signed coordinates/multiple wraps use independent modulo/reference;
  wrapped distance from unsigned axis differences, radius query unique membership
  and sorted nearby IDs against brute-force living records. Cover seam/corner/
  one-cell axes and huge radius without huge storage. Living animal old/new
  positions have toroidal distance<=speed; newborn/dead IDs treated separately.
- On16 chosen cases decode a midpoint checkpoint, compare exact bytes/state and
  continue against direct engine through horizon. Different seeds yield different
  complete state hash (config seed participates); do not require each population
  trajectory to differ. Count observed births/deaths/movement/query checks to make
  clear which random behaviors ran; retain dedicated nonvacuous existing sexual
  reproduction/speciation/seam tests instead of relying on chance for those.

Target command: `cargo test --locked --test reliability -- --nocapture`.
No engine mutation helper, property-test framework or new authoritative field.

## Contract acceptance matrix to complete with actual commands/artifacts

Docs/VERIFICATION.md must give each row an actual command/test name, exit status,
result assertions and evidence path, not just a claim that the suite passes.

| Contract section | Verification |
|---|---|
| 1 entry points | setup twice + build from unrelated cwd/spaced paths; executable bits, noninteractive return status; inherited packaging suite rerun |
| 1 offline runtime | Static ELF no INTERP/NEEDED, copied dist in empty chroot, no runtimes/project assets/display/network source; inspect embedded assets and absence of runtime remote fetches; avoid claiming fresh OS provisioning |
| 2 version | Exactly one JSON stdout object with name/version/contract1, no stderr, host/dist/copied binary |
| 2 run config | Required/optional flags, seed override, ticks0/1/nonmultiple, default and explicit K, start/end sampling exactly once, full requested extinct tail |
| 2 run load/save | Config/save and load/additional ticks/save replacement; splits0/37/117 at total300, cumulative counters/hash parity, absolute ticks and relative sampling |
| 2 batch | Seed-only exact files seed42/43/44 and summary JSON; short seeds1/2/3 standalone parity; existing2x2 sweep/CSV checks remain |
| 2 UI ordinary | Existing real-server lifecycle and browser navigation/control/inspection/config/chart/file tests; explicit demo config accepted; same engine/hash parity |
| 2 UI automation | timeout60s smoke and120s screenshots, default and explicit demo coverage; actual10/100 ticks/render, main.png dimensions>=1280x720, complete real UI, cleanup and exit0; preserve selected images |
| 3 config | Every fixed key required, JSON types/ranges/missing/wrong/zero cases; fixed-only config defaults, dimension1 and zero initial counts, optional settings through shared validator |
| 4 result JSON | Required keys/types/bounds, tick equation, final living/species, cumulative accounting, initial/everyK/end rows unique/ascending, lowercase64hex hash, finite wall timings excluding startup, N0 convention |
| 5.1 deterministic | Same-build repeat outputs final/totals/series/hash equal except timing; distinct seed hash; sampled/unsampled hash independence; host/musl each independently, no cross-libm bit equality claim |
| 5.2 checkpoint | Exact uninterrupted vs split final/totals/hash and future state/RNG/resources/DNA/history/cooldowns; existing codec corruption/semantic tests |
| 5.3 no replenishment | Random and dedicated zero/food-removal worlds, no-plant herbivore then carnivore extinction, natural absorbing zero, exact empty-tail advancement; source audit of spawn/local costs |
| 5.4 errors | Bad args/config/checkpoint/missing file exit2+stderr and absent result; old regular output preserved; malformed types/ranges; actual unreadable file via child numeric uid/gid65534 when root (chmod-only under root proves nothing), temp tree accessible and output writable; no outside files |
| 5.5 clean output | version JSON only; successful run/batch silent; failures stderr; UI local URL stderr |
| 6 distribution | Fresh build and full copied-folder runtime-free empty-root version/run mandatory with no skip as root; run includes save/load and analytics; existing static batch check retained |
| 7 demo | scenarios/demo.json frozen and accepted by run/batch/ui, README one-command launch, three fresh10k seeds each for fixed-only and demo, deadlines/coexistence reported |

Example formal CLI calls after inputs exist (all paths relative to /workspace):

```
./setup.sh
cargo build --locked --release --bin evosim --example balance_report
./build.sh
python3 tools/release_verify.py --mode contract --out-dir tasks/TASK-028/evidence/contract
python3 tools/release_verify.py --mode long --config tasks/TASK-028/evidence/fixed.json --seeds 42,43,44 --ticks 10000 --label fixed --out-dir tasks/TASK-028/evidence/fixed
python3 tools/release_verify.py --mode long --config scenarios/demo.json --seeds 42,43,44 --ticks 10000 --label demo --out-dir tasks/TASK-028/evidence/demo
./test.sh > tasks/TASK-028/evidence/full-suite.log 2>&1
python3 tools/release_verify.py --mode validate --out-dir tasks/TASK-028/evidence
cargo fmt --check
git diff --check
```

Long runner may invoke individual `./evosim run --seed S ...` for enforceable
per-run deadlines and also a contract batch. If using batch for all seeds, add
individual watchdog timing or measured individual reruns for deadline evidence.
Precreate screenshot destinations; run browser commands separately from test.sh.
Do not claim proposed helper interfaces or any of these unexecuted commands exist
or pass in PLAN.

## Project self-audit and reader handover

SELF_AUDIT.md must enumerate all seven PROJECT Required behavior bullets, splitting
multi-part bullets into independently assessable rows. Also cover deterministic
seed behavior, topology compromise, permitted mechanisms and each forbidden rescue
category, all three agent-owned ADR decisions and tests. Each row says met, partly
met or missing with source/evidence link and qualifier. Required rows include:
torus/grid/perception/configurable world; climate/seasons/weather/effects; plant
DNA/paid growth/mutation/speciation; all animal traits/sexual inheritance/behavior/
lifespan/energy/costs; target1000–5000 and measured100/s at>=2000 with disclosed
plant-focused versus mixed workload; shared engine and every UI action; presets/
JSON import-export/seed/full-state persistence; seed+parameter batches/statistics;
every chart including generation trends; unit/integration/regression/property/
multi-thousand tests. Inspect actual UI: generation summaries in metrics alone
must not be misrepresented as a generation-trend chart. Mark any absent part
openly rather than adding a feature. Long coexistence goal remains partly met or
missing if measurements collapse, regardless of passing delivery acceptance.

README leads with install, one command `./evosim ui --config scenarios/demo.json`
after setup, headless demo alternative, run/save/load/batch/UI examples, ./test.sh,
brief configuration key/group defaults/ranges or concise table plus full schema
link, self-contained build/copy instructions and browser-only dependencies. State
fresh per-seed fixed and demo coexistence results, meaning/censoring, final losses
and measured horizon. Link VERIFICATION/SELF_AUDIT and retained balance/performance
reports. Remove stale bootstrap/future-task descriptions where misleading without
rewriting history in earlier task handoffs. Document model1 incompatibility, same-
build floating determinism, unbounded histories/memory, no fsync/two-file atomicity/
concurrent writers, UI upload/chart-window limits and browser timeout if unresolved.

## Risks, actual PLAN checks and handoff

Main risks: intermittent browser timing, underestimated long viable-run cost,
observer off-by-one, stale binary/source evidence, randomized cases vacuously empty,
resource/disk growth and overstating self-containment as fresh-OS provisioning.
Bound search, validate observer against CLI, disclose behavior coverage, keep
mandatory six long runs and final suite ahead of optional exploration. No new
system dependency needed; all exact setup reinstall commands remain in STATE.
No internet research is needed for local delivery; no Git hosting/network use.

Actual baseline command (exit0):
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test config --test topology --test checkpoint_cli --test run_cli --test batch_cli > /workspace/target/task028-plan-baseline.log 2>&1`
27 tests passed: config8, topology7, checkpoint_cli2, run_cli5, batch_cli5; no
failures/ignored/filtered. No full suite, UI, demo trial or10k run executed in PLAN.
Tool probe found provided chromium, node, musl-gcc, readelf and chroot. Inspection
`rg --files tasks/TASK-028/handoffs` exited1 before directory creation because
there were no handoffs; not a product failure. Initial large concatenated reads
truncated; bounded follow-up reads established relevant current context.

Final planning validation command/result is in plan-cycle1.json. Implementation
must fill evidence with actual results, state any deviations and write honest
IMPLEMENT handoff; no automatic stage advance. No known acceptance blocker, and
no completed delivery claim in this phase.

For explicit offline execution evidence, prefer `unshare --net` around the copied
static headless commands if supported. If network namespace creation is denied,
record that outcome and use a small workspace-local test-only Linux seccomp
launcher denying network socket/connect syscalls for version/run/save/load; compile
with the supplied C toolchain. A network-dependent program must fail under the
same restriction as a negative control. Keep any helper under tests/support/ and
record the actual method. Empty chroot alone does not disable network syscalls;
do not claim network isolation solely from that test. Browser uses loopback and
is tested separately; it is not part of the runtime-free version/run requirement.

## Reproducible final planning validator

Run with:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-028/handoffs/plan-cycle1.md").read_text().split("```python\n")[-1].split("```")[0])'`

```python
import json
import subprocess
from pathlib import Path
root = Path('/workspace')
p = root / 'tasks/TASK-028/handoffs/plan-cycle1.json'
d = json.loads(p.read_text(encoding='utf-8'))
required = {'task_id', 'phase', 'cycle', 'summary', 'changed_files', 'decisions',
            'tests', 'risks', 'next_steps', 'verdict', 'gaps'}
assert required <= d.keys()
assert (d['task_id'], d['phase'], d['cycle'], d['verdict']) == ('TASK-028', 'plan', 1, 'N/A')
assert type(d['cycle']) is int and d['gaps'] == []
for key in ('changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps'):
    assert isinstance(d[key], list), key
for t in d['tests']:
    assert isinstance(t['command'], str) and type(t['exit_code']) is int
    assert isinstance(t['notes'], str)
expected = {'docs/STATE.md', 'docs/ARCHITECTURE.md',
            'tasks/TASK-028/handoffs/plan-cycle1.md',
            'tasks/TASK-028/handoffs/plan-cycle1.json'}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True)
actual = set(git('diff', '--name-only').splitlines())
actual.update(git('ls-files', '--others', '--exclude-standard').splitlines())
assert actual == expected, actual
assert set(d['changed_files']) == expected
assert git('remote', '-v') == ''
for rel in expected:
    (root / rel).read_text(encoding='utf-8')
log = (root / 'target/task028-plan-baseline.log').read_text()
import re
counts = [int(n) for n in re.findall(r'test result: ok\. (\d+) passed;', log)]
assert sum(counts) == 27, counts
assert '0 failed; 0 ignored;' in log
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
print('PASS: UTF-8 handoff/schema, 27 baseline tests, four documentation paths, no remotes, whitespace')
```

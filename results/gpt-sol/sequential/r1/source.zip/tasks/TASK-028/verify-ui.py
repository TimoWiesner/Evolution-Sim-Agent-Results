"""Serial real-browser release evidence, independent CLI hashes and PNG dimensions."""
from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'tools'))
from release_verify import ROOT, Recorder
out=ROOT/'tasks/TASK-028/evidence/ui'
rec=Recorder(out)
records=[]
for label,config in [('default',None),('demo',ROOT/'scenarios/demo.json')]:
    args=['--config',config] if config else []
    rec.run([ROOT/'evosim','batch','--config',config or ROOT/'tasks/TASK-028/evidence/fixed.json','--seeds','42,43,44','--ticks',17,'--out-dir',out/f'batch-{label}'])
    for mode,ticks,timeout in [('smoke',10,60),('screenshots',100,120)]:
        shots=out/label;shots.mkdir(exist_ok=True)
        flags=['--smoke-test'] if mode=='smoke' else ['--screenshots',shots]
        stdout,stderr=rec.run([ROOT/'evosim','ui',*args,*flags],timeout=timeout)
        assert not stdout
        evidence=json.loads(next(line.removeprefix('UI automation ') for line in stderr.decode().splitlines() if line.startswith('UI automation {')))
        result=out/f'{label}-{mode}.json'
        rec.run([ROOT/'evosim','run','--config',config or ROOT/'tasks/TASK-028/evidence/fixed.json','--ticks',ticks,'--out',result])
        assert evidence['tick']==str(ticks) and evidence['draws']>0
        assert evidence['state_hash']==json.loads(result.read_text())['state_hash']
        if mode=='screenshots':
            png=(shots/'main.png').read_bytes();assert png[:8]==b'\x89PNG\r\n\x1a\n'
            width=int.from_bytes(png[16:20],'big');height=int.from_bytes(png[20:24],'big');assert width>=1280 and height>=720
            evidence.update(width=width,height=height)
        records.append(dict(label=label,mode=mode,**evidence))
(out/'validated.json').write_text(json.dumps(records,indent=2)+'\n')

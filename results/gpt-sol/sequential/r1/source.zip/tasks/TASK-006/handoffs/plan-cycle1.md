# TASK-006 PLAN cycle 1

## Findings and scope

Verified /workspace/AGENTS.md and docs/STATE.md before reading. Inspected required
project/contract/state/architecture/task documents, PLAN skill, existing handoffs,
ADRs and source/tests. TASK-004 and TASK-005 reviews PASS with no gaps. No existing
TASK-006 handoffs or downstream handoffs (including TASK-007) exist. Initial tree
clean, no remotes. Bulk output sometimes truncated; bounded follow-ups covered
relevant source, decisions and dependency review evidence. No packages installed.

Current library has validated Config, Topology, RNG and Simulation/World. World
stores only topology. Seven phases dispatch but biological phases draw nothing.
CLI supports version/help only. This phase changes planning documents only.
Implementation will add static base climate, observational world access and a
small headless export command; seasons/weather/resources/organism effects,
run/batch/UI/checkpoints remain later tasks. No REVIEW gaps to close.

## Algorithm and representation (planned)

ADR-005 records the decision and alternatives. Climate model version 1 uses
normalized temperature and precipitation, both within [0,1], consistent with
ADR-004 climate preferences. These are model units, not degrees or millimetres.
There are five ordered Biome variants: Polar, Tundra, Temperate, Dry, Tropical.
Dry represents the shared savanna/desert belt; no extra split or terrain noise.

At cell centre v=(y+0.5)/height, define q=(1-cos(TAU*v))/2 clamped to [0,1].
Use symmetric evaluation d=min(y,height-1-y), v=(d as f64+0.5)/height as f64
before cosine. This is mathematically the same function, makes paired seam rows
bit-identical and avoids subtracting two nearly equal large phases. Temperature
is q. Classify q<0.10 polar; <0.25 tundra; <0.60 temperate; <0.85 dry; otherwise
tropical. Exact thresholds belong to the warmer band. Classification is categorical;
only the underlying climate fields have a continuous-value meaning.

Precipitation is C1 piecewise smooth interpolation in q through these knots:
(q,p)=(0,0.15),(0.10,0.25),(0.25,0.60),(0.60,0.20),(0.85,0.35),(1,1).
For the containing interval [a,b], t=(q-a)/(b-a), s=t*t*(3-2*t),
p=p_a+(p_b-p_a)*s, clamped to [0,1]. Endpoint derivatives vanish, so knots do not
introduce jumps or slope discontinuities. Cooler temperate regions are moist,
subtropical regions relatively dry, tropical regions wet. No stochastic influence;
all seeds share this geography, and construction/lookup/export consume no draws.
ClimateConfig's existing season/weather fields do not affect base climate.

Latitude repeats cold-hot-cold on a torus. It cannot have two separate geographic
poles as a sphere does: top/bottom meet within one cold belt; the hot belt runs
through the middle. East-west climate is constant, hence periodic. This sacrifices
continents and longitudinal variation for simple smooth wrapped latitude zones.
Small worlds legitimately miss bands: 1x1 samples tropical, height 2 samples
q=0.5 (temperate); do not fabricate rows or require all five bands at all sizes.

Use a procedural `Climate` field storing Topology (Clone/Debug/PartialEq), not an
allocated per-cell raster. `Climate::new(topology: Topology) -> Climate` is O(1).
`Climate::base_at(cell: Cell) -> BaseClimate` normalizes via its topology before
calculation, matching foreign-world Cell semantics. `BaseClimate` is a Copy value
with private fields and read-only biome(), temperature(), precipitation().
`Biome` derives Copy/Clone/Debug/Eq/PartialEq; provide stable lowercase name().
Export a model version constant (1). No continuous public coordinate API needed.
This assigns a value to every cell without limiting constructor memory by area.
Queries cost O(1) with one cosine; later profiling may justify a derived row cache.
No throughput claim. f64 loses cell-level precision at enormous usize dimensions,
but values remain finite/bounded and lookup works; exact distinct adjacent values
are not promised. No area allocation, integer y+1 at MAX, or unchecked index math.

## Interfaces and ordered implementation

1. Add src/climate.rs, export in src/lib.rs. Implement the above types, private
   interpolation helper, formula, normalized foreign-cell access and rustdoc.
   Dependencies: topology and std only for climate values. No new Cargo crate.
2. In src/simulation.rs add Climate to World, build from the same Topology in
   Simulation::new, expose `World::climate(&self) -> &Climate`. Preserve existing
   topology/clock/RNG APIs and unchanged tick scheduling; static climate does not
   mutate in ClimateResources. Update stale geometry-only comments and extend
   tests/simulation.rs for static climate and observational independence.
3. Add `Climate::write_json(&self, writer: &mut impl std::io::Write)
   -> std::io::Result<()>` as a read-only streaming export. Use existing serde_json
   to serialize bounded per-cell records (map serde errors to io::Error), never a
   whole-world Value/Vec. This is an explicit small refinement of the module
   dependency: export uses existing serialization; numerical climate needs no RNG,
   config, CLI or UI. Format: object with climate_model:1, width, height,
   temperature_units:"normalized", precipitation_units:"normalized", and cells
   array in row-major order. Each cell has x,y,biome (lowercase),
   base_temperature,base_precipitation. Exactly area records. Write newline at end.
   Derive/serialization need no new serde dependency: serialize per-cell json! Value
   with already available serde_json. Full streaming costs O(area) time/O(1) memory.
4. Extend src/cli.rs dispatch/help with additive command
   `evosim climate --config FILE --out FILE` (both flags required, either order,
   reject duplicates/unknown/missing/surplus). Config::load validates before opening
   output. Construct Simulation and export its World climate, ensuring same engine
   field as future UI. Success 0, stdout/stderr empty; argument/config/open/write
   failures 2 with diagnostic on stderr. I/O write failure can leave partial export;
   invalid config/arguments must not create or truncate output. No run result
   schema is involved. Keep std-only argument dispatch; dist supports it too.
5. Add tests/climate.rs, extend tests/simulation.rs, tests/cli.rs and
   tests/test_entrypoints.py as detailed below. Update README and new docs/CLIMATE.md
   with model, normalized units, thresholds/knots, topology compromise, tiny-world
   behavior, library API, export schema and an actual reproducible CLI command.
   Use a test-generated config under target/ for inspection; no premature demo
   scenario or new preset. Readable JSON suffices for the headless map requirement.
6. Execute targeted/full commands, update STATE/ARCHITECTURE/ADR-005 with actual
   results, dependencies and deviations, and write implement-cycle1.md/.json.
   Leave orchestration state, commits and phase transitions to the harness.

## Acceptance matrix and executable evidence required in IMPLEMENT

All tests below are planned, NOT run in PLAN. Rust built-in tests and bounded
exhaustive properties suffice; no new test dependency.

1. Every cell assigned: for widths/heights 1..=32 enumerate all coordinates,
   assert finite values in [0,1], one valid biome, equality across x and across
   repeated calls. Frozen representative q/biome/precipitation expectations on a
   tall world should supplement tests to avoid merely reimplementing the formula.
   Private helper tests cover exact thresholds and interpolation knot endpoints,
   immediately below/above thresholds, bounded smooth interpolation.
2. Earth-like order: on 7x256 walk north-to-middle, collapse consecutive labels,
   assert exactly Polar,Tundra,Temperate,Dry,Tropical, temperature nondecreasing;
   reverse side mirrors it. Assert temperate precipitation exceeds driest belt
   and tropical precipitation exceeds dry. Default 64x48 also contains all five.
3. Seam proof: enumerate widths/heights 1..=64 (one column per vertical test
   suffices after checking x invariance), plus 3x255,64x48,7x256. Compute each field's
   actual wrapped seam difference and compare against maximum NON-WRAPPING
   adjacent difference in that axis, with epsilon 1e-12; degenerate axes use zero.
   Assert seam rows' complete BaseClimate values identical, including biome.
   Explicitly exercise horizontal, vertical and diagonal corner wrapping via
   Topology::cell(-1,-1), and compare all horizontal/vertical neighbor pairs.
   Separate mathematical explanation: v=0 and v=1 agree with matching zero
   derivative; cell-centred paired seam samples agree; x is constant. Document
   discrete biome boundaries as expected internal classifications, not scalar jumps.
4. Topology compromise: docs/CLIMATE.md and ADR-005 explain cold-hot-cold versus
   spherical poles and normalization. Record document inspection in handoff.
5. Headless map: serialize 3x5 and 1x1 to memory, parse real JSON, assert schema,
   model version, units, exact record count/order/coordinates and values equal to
   queried World climate. Inject failing writer and assert propagated error.
   CLI subprocess tests cover flag orders, paths with spaces, no DISPLAY,
   invalid config/arguments/no output modification, unreadable config, unwritable
   output. Python packaging suite exercises workspace and dist export from an
   unrelated cwd, parses every record; keep all existing version/ELF/chroot tests.
   Record `./evosim climate --config target/climate-config.json
   --out target/climate-map.json` after creating fixed-key config in target/;
   parse it and record counts by biome for 64x48. No UI required.
6. Tiny/extreme dimensions: exhaustive dimensions above plus 1x1,1x7,7x1,2x2,
   prime/non-square, odd/even heights; accept absent bands. Topology::new(usize::MAX,1)
   and (1,usize::MAX), sample first/middle/last cells without enumeration to show
   construction has no area allocation and outputs stay bounded. Foreign cells
   normalize identically to explicit wrapped coordinates. Signed extreme wrapping
   remains Topology's responsibility; include representative negative lookup.
7. Regression: repeated Simulation initialization and 128 ticks preserve base
   climate and initial RNG state; repeated queries/exports leave entire sim equal
   to unobserved clone. Equal seeds reproduce; different seeds may share base
   geography but retain different RNG states. Existing scheduler/overflow tests
   and complete packaging suite must continue to pass.

Commands: `env -u DISPLAY cargo test --locked --test climate --test simulation
--test cli`, `./test.sh`, `cargo fmt --check`, `git diff --check`. The whole suite
covers static host/musl packaging; report exact totals, failures and skips.
No benchmark throughput, fresh-container provisioning, UI or checkpoint claim.

## Risks and phase evidence

Scalar continuity and categorical bands must not be conflated. Center sampling
and symmetric evaluation make the actual seam equal; finite grid tests compare
with non-seam neighbors rather than making a vacuous max over all edges. Model
is intentionally simple and seed-independent. Tiny grids cannot display all bands.
Streaming export avoids memory growth but huge exports still take area time and
disk space. Future TASK-007 must keep base climate separate from current weather;
TASK-022 must encode model version/dimensions or derived base values consistently
with checkpoint/hash rules. No new resources or energy sources are introduced.

No packages or product tests run in PLAN; inherited dependency PASS results are
context only. Existing musl reinstall commands remain in STATE/setup.sh. Planning
validation checks JSON/schema, exact six documentation paths, protected paths,
no remotes and whitespace. Validator source below; actual result is in JSON.

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-006/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-006','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/README.md','docs/decisions/ADR-005-base-climate.md','tasks/TASK-006/handoffs/plan-cycle1.md','tasks/TASK-006/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, six documentation paths, protected files, no remotes, whitespace')
```

# TASK-006 IMPLEMENT cycle 1

Implemented the approved plan only; no deviations or known acceptance gaps.
Required files verified first, then project/contract/state/architecture/task,
current plan/ADR-005, relevant prior ADRs, dependency handoffs and implementation
skill inspected. TASK-004/005 reviews PASS without gaps. Initial tree clean and
no remotes. Some bulk reads truncated; bounded follow-ups covered relevant files.
No packages installed, dependencies changed, protected files edited, commits made
or other phase started. The harness owns state and transitions.

## Acceptance evidence

1. Every cell: immutable procedural Climate in World returns BaseClimate with
   private fields/read-only accessors. Exhaustive widths/heights 1..=32 check
   bounded finite fields, repeatability, valid biome and longitude invariance.
   Version 1 cosine latitude and smoothstep precipitation follow ADR-005 exactly.
   Unit tests check exact thresholds, neighboring values, knot endpoints and
   near-knot flat slopes; public known samples freeze representative temperatures.
2. Earth-like order: 7x256 and default 64x48 north-to-middle sequences collapse
   to Polar,Tundra,Temperate,Dry,Tropical with nondecreasing temperature and mirrored
   other halves. Tests compare moist temperate/dry/tropical precipitation.
3. Seam: exhaustive widths/heights 1..=64 plus 3x255,64x48,7x256 compare scalar
   seam differences against maximum NON-wrapping adjacent differences (1e-12
   tolerance). Paired seam rows match complete values including biome; horizontal
   neighbor pairs and diagonal corner wrapping are exercised. docs/CLIMATE.md
   proves periodic value/derivative limits; labels have intentional thresholds.
4. Topology compromise: inspected docs/CLIMATE.md and ADR-005. Both explain that
   a torus joins the two cold map edges into one belt, rather than retaining a
   sphere's distinct poles. Normalized units, cell centers and tiny grids documented.
5. Headless export: memory exports of 3x5 and 1x1 parse with exact schema/model,
   units, row-major coordinates and all values matching queries; failing writer
   propagates error. CLI tests exercise both flag orders, paths with spaces,
   missing/duplicate/unknown/surplus args, missing/invalid configs, no output
   creation or truncation on invalid input, directory output failure and /dev/full
   buffered-write failure. Packaging tests parse all records from workspace and
   musl dist exports from unrelated cwd without DISPLAY. Manual documented
   64x48 export contains 3072 cells: polar 640, tundra 384, temperate 768,
   dry 512, tropical 768. Ignored target/climate-map.json is the inspection artifact.
6. Any size: tiny/prime/non-square/odd/even maps and usize::MAX axes are covered.
   Extreme construction/first-middle-last lookups require no raster allocation.
   Foreign cells normalize and negative wrapped lookups work. 1x1 tropical and
   2x2 temperate are explicit; not every size must sample every biome.

Simulation observation tests query/export across 128 ticks and compare complete
Simulation equality to an unobserved clone, static base field and unchanged RNG.
Different seeds retain different RNG states but intentionally share geography.
Existing overflow/scheduler/RNG/topology/config tests remain passing.

## Commands and results

- `env -u DISPLAY cargo test --locked --test climate --test simulation --test cli`:
  exit 0 initially (10 tests), exit 0 after CLI test additions (11 tests).
- `./test.sh`: exit 0; 43 tests, none skipped: 4 unit, 2 CLI, 5 climate, 8 config,
  5 RNG, 4 simulation, 7 topology, 1 rustdoc, 7 Python. Includes setup twice/build,
  host/musl rebuild, ELF no INTERP/NEEDED and copied empty-root version execution.
- `./evosim climate --config /workspace/target/climate-config.json --out /workspace/target/climate-map.json`:
  first exit 2 because manual fixture did not yet exist; this is an operator-order
  mistake, no code failure. Created fixed-key JSON as in docs/CLIMATE.md, then
  `./evosim climate --config target/climate-config.json --out target/climate-map.json`:
  exit 0. Python json/Counter assertion: exit 0, counts above.
- `cargo fmt --check` and `git diff --check`: exit 0.
- Final validator below: checks required UTF-8 JSON/types, exact changed paths,
  protected files, absent remotes, formatting and whitespace.

No product code changed after passing tests. No throughput, ecology, weather,
checkpoint, fresh-container or separate minimum-Rust-version claim. Huge export
still costs area time/disk; f64 loses resolution on huge dimensions. Write failures
may leave partial output. Future temporal climate must retain base access; future
checkpoint/hash must encode model identity and dimensions or equivalent values.
No remediation known; harness assigns review.

## Final validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-006/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-006/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-006','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'README.md','docs/STATE.md','docs/ARCHITECTURE.md','docs/CLIMATE.md','docs/decisions/ADR-005-base-climate.md','src/climate.rs','src/cli.rs','src/lib.rs','src/simulation.rs','tests/climate.rs','tests/cli.rs','tests/simulation.rs','tests/test_entrypoints.py','tasks/TASK-006/handoffs/implement-cycle1.md','tasks/TASK-006/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact fifteen paths, protected files, no remotes, formatting, whitespace')
```

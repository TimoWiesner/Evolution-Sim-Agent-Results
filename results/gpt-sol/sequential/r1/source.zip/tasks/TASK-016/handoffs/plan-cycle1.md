# TASK-016 PLAN cycle 1

Documentation only; implementation unstarted. Applied workspace PLAN skill
.agents/skills/plan/SKILL.md. Required AGENTS.md and STATE existence verified first.
Read task/spec/JSON, project, binding contract, state/architecture, dependency
TASK-009/013/014/015 phase handoffs and relevant runtime, genome, lifecycle,
spatial, navigation, plant reproduction, grazing and hunting decisions/source.
All four dependency reviews PASS with no gaps. No existing TASK-016 handoffs or
review remediation. Initial worktree clean, no Git remotes. No questions, package
installs, commits, task-state edits or phase transitions.

## Ordered implementation plan

ADR-013 is the exact model, including energy/rounding and RNG gate semantics.

1. Add last_reproduction_tick: Option<u64> to src/organism.rs with public
   read-only getter. Initialize None in both Organism constructors in
   src/population.rs (founders and Commit). Keep derived Clone/PartialEq so full
   engine replay compares cooldown. Add crate-private Population method
   record_reproduction_pair([OrganismId;2], tick) to stamp both already validated
   distinct living animal parents; validate both before any write, assert same
   kind, and never expose a public mutable record. Energy still goes through
   existing change_energy. Tests use current cfg(test) fixtures only.
2. Add src/ecology/reproduction.rs and register src/ecology/mod.rs. Implement
   pure helpers specified by ADR-013. Integer compatibility uses distance_sum,
   no floating tolerance; fertility uses raw allele product/4294836225.
   Test maturity/ready boundary cases, fertility endpoints/products, compatibility
   exact threshold, and finite representable conservative energy budgets.
3. Refactor Simulation::reproduction in src/simulation.rs into existing unchanged
   plant_reproduction followed by animal_reproduction(Kind::Herbivore) and
   animal_reproduction(Kind::Carnivore). Preserve plant ordering/draw semantics
   and reservations. New animal method takes ascending current phase IDs, uses
   nearby(radius 1, same kind), gates all eligibility before choosing nearest/ID,
   tracks phase-local attempted IDs, performs one fertility trial, requests one
   birth at lower-ID parent's cell through existing queue_birth, and only on Ok
   pays/stamps both parents immediately. Copy values before mutable operations;
   expected ID/generation failures cost/draw exactly as ADR-013, other errors
   remain explicit invariants. No extra aging or mutable public API.
4. Add src/simulation/reproduction_tests.rs as a cfg(test) child module, following
   herbivore_tests/carnivore_tests. Exercise actual production reproduction and
   full advance_one_tick/Commit with controlled existing private fixture access.
   Relocate using move_one_step so the index remains correct; never directly
   rewrite positions. Add tests/animal_reproduction.rs for public full-tick
   solitary animals, actual births/lineage and deterministic replay.
5. Audit src/simulation.rs existing fixtures, tests/lifecycle.rs, tests/spatial.rs,
   tests/animal_movement.rs, tests/herbivore_feeding.rs, tests/carnivore_hunting.rs,
   tests/organism.rs and genetics tests for old no-animal-birth assumptions or
   Organism construction. Isolate unrelated legacy long-run ledgers using
   animals.reproduction_energy=1001 when necessary and document why. Preserve
   mixed production replay with births enabled; do not globally suppress mating
   or remove conservation/spatial/extinction assertions. Existing raw queue_birth
   unit fixtures are authorized primitive tests and need not pass policy gates.
6. Update docs/ANIMALS.md, docs/CONFIGURATION.md, docs/GENETICS.md and
   docs/ARCHITECTURE.md/STATE plus ADR-013 status/evidence. Explain current
   per-parent cost, maturity, fertility, immediate litter of one, compatibility,
   attempt pairing and exact cooldown; remove obsolete "mating future" wording.
   ADR-004 compatibility is now consumed, species remains TASK-017. No config
   schema/default change, crate/system dependency, CLI/UI or checkpoint format.
7. Run targeted checks and full test.sh within IMPLEMENT's own 30-minute budget.
   Record actual failures, fixes, commands and test counts; write required
   implementation handoffs. Harness owns commits and transitions.

## Acceptance and regression matrix

| Must have | Production-path evidence required in IMPLEMENT |
|---|---|
| Two distinct live same-kind, close mature energized compatible parents | For BOTH animal kinds, actual policy plus full tick tests: same cell, cardinal/diagonal/corner/horizontal/vertical seams, 1x1/1xN/Nx1; distance 2 excluded despite vision; self, dead, wrong kind, immature and each-parent energy/cooldown failures; nearest eligible then ID; incompatible nearest skipped for compatible next candidate |
| Crossed/mutated DNA, both IDs, generation | Distinguishable compatible parental arrays, rate 0 and 1000000, independent boundary/orientation/mutation RNG reference; two nonempty segments at zero mutation, bounded mutated alleles, sorted IDs, unequal generations -> max+1; production child age 0/position/vitals/index/lineage after Commit, first action next tick |
| Both pay energy | Isolated reproduction and full tick before/after ledgers: each loses E, child gains E, combined energy decreases; parent survives; no failure debit; near-capacity, just-over-cost, equal/below-cost, E=1001, subnormal/round-away cases; actual child energy <= combined realized loss |
| Waiting time for each parent | Success at t stamps BOTH; neither initiator nor mate can reuse them with a third partner in same phase or ticks t+1..t+C-1; eligible at t+C with restored eligible energy; C=1,20,u64::MAX, final-tick arithmetic; failed trial stamps neither, newborn None; cloned continuation retains timestamp |
| Fertility influences chance | Paired otherwise identical fertility-only genomes, endpoints 0/65535, either-parent zero, both max; >=512 independent policy trials with exact rational/RNG agreement, both interior outcomes; shared seeded trials with higher fertility never fewer and strictly more successes over bounded 4096 sample |
| Single animal never offspring | Public full ticks for one herbivore alone and one carnivore alone through >=2200 ticks; births stay zero and extinction is absorbing; separate well-fed/low-upkeep mature private fixtures prove failure is absence of mate, not early death |

Additional nonvacuous tests:
- Three/four eligible animals exercise deterministic pairing, attempted-on-failure
  exclusion, no reverse-pair retries, one child per successful pair, and no
  co-occupancy rejection. No mate/ineligible pair draws nothing; endpoint trial
  draws nothing; interior failure draws only trial; success adds crossover and
  mutation draws, Commit adds none. Public observations leave state/RNG unchanged.
- Exact compatibility uses threshold sum floor(786420/5)=157284, plus sums 157283
  and 157285. Construct legal arrays to hit these sums; check symmetry. Species
  identity is absent and must not be invented as compatibility.
- ID exhaustion and generation overflow skip without energy/cooldown changes,
  with fertility trial retained and staged genetics draws rolled back. Check
  request queue, counters, index and RNG. A paid captured child survives later
  parental death per existing primitive semantics; death before mating excludes
  parent. Predation/starvation/age in earlier real phases prevents mating.
- Full-tick ordering explicitly accounts weather -> herbivore action -> carnivore
  action -> plant births -> herbivore trials/genetics -> carnivore trials/genetics
  -> Commit. Include both kinds and a real plant birth; avoid assertions based
  solely on manual birth requests. Newborn cannot reproduce or act in birth tick.
- Existing four-seed 0,1,42,u64::MAX 2200-tick mixed replay compares full Simulation
  (including cooldown), initial+births-deaths=live and independent spatial/sense
  oracles. Ensure actual animal births occur in controlled production fixtures;
  long extinct tails alone do not establish the feature. No long balancing run.

## Planned commands, not executed in PLAN

- env -u DISPLAY cargo test --locked --lib --test animal_reproduction --test genome --test organism --test lifecycle --test spatial --test simulation --test animal_movement --test herbivore_feeding --test carnivore_hunting
- ./test.sh
- cargo fmt --check
- git diff --check

No application tests/simulations run in PLAN because only planning docs change.
Dependency TASK-015's 145-test PASS is inherited evidence, not a run this phase.
No package installed; exact inherited musl prerequisite reinstall commands in
STATE/setup.sh remain applicable. No additional dependency planned.

## Risks and handoff obligations

New authoritative last-reproduction Option/value MUST enter future canonical
checkpoint/hash schemas; clone equality includes it now. Avoid overflow by elapsed
subtraction, not future deadline addition. Local dense mate stacks may be quadratic;
one-trial temporary set caps stochastic opportunities, not population size.
Stable-ID mate access and founder-reserve bursts are accepted simplifications.
No coexistence/throughput/full persistence/fresh-container/minimum-Rust claim.
This phase cannot implement the feature or start the next phase. No known blocker,
review gap or unresolved choice. ADR-013 plus this plan are next-phase memory.

## Planning validation

Run the Python block below after writing JSON:

```python
import json, subprocess
from pathlib import Path
root=Path('/workspace')
d=json.loads((root/'tasks/TASK-016/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert (d['task_id'],d['phase'],d['cycle'],d['verdict'])==('TASK-016','plan',1,'N/A')
assert type(d['cycle']) is int and isinstance(d['summary'],str)
for key in ['changed_files','decisions','tests','risks','next_steps','gaps']:
    assert isinstance(d[key],list)
for test in d['tests']:
    assert isinstance(test['command'],str) and type(test['exit_code']) is int
    assert isinstance(test['notes'],str)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
assert set(changed+new)==set(d['changed_files']) and len(d['changed_files'])==5
allowed={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-013-animal-reproduction.md','tasks/TASK-016/handoffs/plan-cycle1.md','tasks/TASK-016/handoffs/plan-cycle1.json'}
assert set(changed+new)==allowed
for path in allowed:
    (root/path).read_text(encoding='utf-8')
assert not subprocess.check_output(['git','remote','-v'],cwd=root,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected scope, no remotes, whitespace')
```

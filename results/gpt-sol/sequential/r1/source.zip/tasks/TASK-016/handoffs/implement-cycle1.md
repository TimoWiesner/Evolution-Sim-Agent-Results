# TASK-016 IMPLEMENT cycle 1

Implemented approved ADR-013 using the workspace IMPLEMENT skill. Verified
/workspace/AGENTS.md and /workspace/docs/STATE.md before reading context.
Read project/contract, state/architecture, task/spec, plan handoffs, dependency
handoffs/reviews (009/013/014/015 PASS, no gaps), relevant lifecycle/genetics/
spatial/ecology ADRs and current source. Bulk reads sometimes truncated; bounded
follow-ups supplied relevant details. Initial tree clean, no Git remotes. No
package installations, protected-file/task-state edits, commits or phase changes.

## Result

- Pure ecology/reproduction gates import only genome/traits. Maturity is floored
  lifespan/10, readiness uses checked elapsed subtraction, compatibility uses
  5*S<=786420, fertility trial is raw allele product over 65535 squared.
- Simulation calls unchanged plant reproduction then herbivore and carnivore
  policy. Ascending IDs select nearest eligible local mate then ID, with a
  temporary attempted set preventing reverse retries or third-partner reuse.
  Each pair may produce one immediate child. Self, dead, wrong-kind, remote,
  immature, poor-energy, cooldown and incompatible candidates cannot mate.
- Existing queue_birth captures sorted parents, crossed/mutated DNA and
  max-generation+1. Newborn appears at Commit with age 0, health 10, energy E,
  lower-ID parent's cell and cooldown None. Commit draws nothing; first action
  next tick. Expected ID/generation errors retain the trial draw only.
- Both parents pay E immediately on acceptance, then Population validates and
  stamps both cooldowns. Positive representable residuals and combined actual
  debit>=child energy avoid free offspring at tiny floating costs. At E=30,
  total parents lose 60, newborn receives 30; no health/resource/global payout.
- New authoritative Organism::last_reproduction_tick Option<u64> is initialized
  None in both constructors, read-only publicly and retained in Clone/PartialEq.
  Future checkpoint/hash must encode discriminant/value exactly, validate animal
  timestamps against engine tick, preserve cooldown and include model/settings/
  complete existing state. No disk persistence introduced.

Minor file naming deviation: plan proposed src/simulation/reproduction_tests.rs,
but the existing inline plant reproduction_tests module already owns that name.
Use src/simulation/animal_reproduction_tests.rs to keep both suites intact.
No behavior/model deviation. Only legacy fixture migration sets reproduction
energy 1001 in tests/carnivore_hunting.rs's fixed two-founder starvation ledger;
its monotonic loss, exact two Starvation deaths and extinction assertions remain.
Existing mixed four-seed 2200 replay, conservation/spatial/sense oracles and
production births remain enabled. No other old assertions were removed.

## Acceptance evidence

1. Both kinds: controlled actual policy covers same cell, cardinal/diagonal and
   every seam,1 x 1/1 xN/Nx 1, distance 2 exclusion, solitary well-fed mature animals,
   each parent's maturity/energy/cooldown failure, dead/wrong-kind exclusion,
   nearest eligible/ID ranking and incompatible-nearest skip. Exact genetic
   distances 157283/157284/157285 test inclusive policy boundary and symmetry.
2. Distinct patterned compatible parents at mutation rates 0 and 1000000:512
   independently seeded production trials per rate/kind compare exact trial,
   raw boundary/orientation/step reference, full DNA and final RNG. Separate
   unequal-generation parents verify max+1, sorted IDs, positions, vitals,index
   and newborn age/cooldown. Zero-rate crossover contains two nonempty segments.
3. Actual policy before/after ledger verifies each parent loses E, survives,
   child receives E and combined realized losses fund it. Threshold/equal/below,
   just-above, near-capacity,999/1000/1001 costs, minimum subnormal/normal and
   rounded-away cases are checked. Failure does not debit or stamp.
4. Both parents stamp immediately. Three animals cannot reuse a paid pair.
   C=1/20/u64::MAX boundaries and all intermediate ticks for C 20, final-tick
   helper arithmetic, future timestamp rejection and cloned continuation tested.
5. Exact 512-trial references above show both outcomes.4096 shared streams per
   kind compare fertility 20000 and 50000 with monotonic and strictly increased
   successes. Zero in either parent and both-max endpoints check no trial draws.
6. Public solitary herbivore/carnivore worlds run 2200 ticks, never give birth
   and remain extinct after lifespan; separate mature high-energy fixtures prove
   lack of mate alone prevents birth. Public full ticks produce real two-parent
   children for both kinds and compare full cloned replay.

Additional tests cover one trial per attempted animal, generation/ID failures
with an explicitly successful interior trial and genetics rollback, atomic pair
stamp validation, accepted paid child surviving later parental death, immediate
index insertion, first action next tick, earlier age/starvation/death preemption,
and actual full tick weather/actions/plant birth/herbivore birth/carnivore birth
ordering. A bounded 64-seed fixture requires all three actual births (no manual
request replacing production policy). Helpers are not a second engine.

## Executed commands and corrections

- Required-file verification, Git status/remotes: exit 0, clean/no remotes.
- cargo test --locked --lib redirected to target/task016-first.log: exit 101,
  nonexistent Displacement::chebyshev; corrected to Topology::distance.
- cargo test --locked > target/task016-baseline.log: exit 101, old fixed
  two-carnivore starvation ledger now has 6 deaths from genuine reproduction;
  isolate births with E 1001 in that one fixture.
- cargo test --locked --lib animal_reproduction > target/task016-new.log:
  exit 101, patterned genome changed lifespan so age 110 was immature; set those
  parents age 200. No production weakening.
- cargo test --locked --lib --test animal_reproduction > target/task016-tests.log:
  exit 0,83 unit+2 integration tests at that point.
- cargo test --locked > target/task016-regression.log: exit 0 after legacy
  migration, before three additional feature tests.
- cargo test --locked --lib animal_reproduction > target/task016-extra.log:
  exit 0,10 feature tests; later policy boundary test added.
- ./test.sh > target/task016-full.log: exit 0,158 tests before final boundary test.
- cargo test --locked --lib animal_reproduction > target/task016-final-feature.log:
  exit 0,11 feature tests. Later strengthened rejection fixture to require success.
- FINAL ./test.sh > target/task016-full-final.log: exit 0,159 passed, no
  failures/skips:87 unit,64 integration,1 rustdoc,7 Python. Includes setup/build,
  host/musl climate exports, static ELF and copied empty-root version checks.
- FINAL headless command and validation are recorded exactly in adjacent JSON.
  Logs are ignored target artifacts; this handoff persists results.

No new system/runtime dependency; inherited setup reinstall commands in STATE
still apply. No throughput/coexistence, full checkpoint/hash, separate fresh
container or minimum-Rust execution claim. Dense local stacks may yield quadratic
mate search; stable-ID bias and finite founder-reserve bursts are accepted limits.
No known acceptance gap or blocker. Harness assigns review/commits/transitions.

## Final artifact validator

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-016/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-016','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual == set(h['changed_files'])
for p in actual:
    assert p not in ('AGENTS.md','CLAUDE.md','docs/CONTRACT.md')
    assert not p.startswith(('.agents/','tools/'))
    assert not p.endswith(('task.md','task.json'))
    (root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: handoff schema/UTF-8, exact changed paths, protected scope, no remotes, whitespace')
```

"""Independent TASK-020 review probes against the documented file interface."""
import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path('/workspace')
KINDS = ('plants', 'herbivores', 'carnivores')
CAUSES = {'starvation', 'injury', 'predation', 'old_age', 'climate'}
q = 32768 / 65535
FOUNDER = dict(zip(('speed', 'strength', 'max_health', 'lifespan', 'fertility',
                    'vision', 'metabolic_multiplier', 'preferred_temperature',
                    'preferred_moisture', 'climate_tolerance', 'aggression',
                    'risk_tolerance'),
                   (2, 1+9*q, 10+90*q, 1100, q, 4, .5+1.5*q, q, q, .05+.45*q, q, q)))
RUNS = 0

def run(folder, initial, ticks, interval):
    global RUNS
    config = {'seed': 42, 'world': {'width': 8, 'height': 6},
              'initial': dict(zip(KINDS, initial))}
    path = folder / 'config.json'
    output = folder / 'result.json'
    path.write_text(json.dumps(config))
    env = {k: v for k, v in os.environ.items() if k not in ('DISPLAY', 'WAYLAND_DISPLAY')}
    p = subprocess.run([str(ROOT/'evosim'), 'run', '--config', str(path),
                        '--ticks', str(ticks), '--out', str(output),
                        '--sample-every', str(interval)], cwd=folder, env=env,
                       capture_output=True, timeout=60)
    assert p.returncode == 0, p.stderr
    assert p.stdout == b''
    result = json.loads(output.read_text())
    assert result['metrics_schema'] == 1
    expected = sorted(set([0, ticks] + list(range(0, ticks+1, interval))))
    assert [row['tick'] for row in result['series']] == expected
    prior = {kind: {'births': 0, 'deaths': 0} for kind in KINDS}
    for row in result['series']:
        a = row['analytics']
        for kind in KINDS:
            m = a[kind]
            assert config['initial'][kind]+m['births']-m['deaths'] == row[kind]
            assert set(m['deaths_by_cause']) == CAUSES
            assert sum(m['deaths_by_cause'].values()) == m['deaths']
            assert 0 <= m['species'] <= row[kind]
            assert set(m['traits']) == set(FOUNDER)
            for counter in ('births', 'deaths'):
                assert m[counter] >= prior[kind][counter]
            prior[kind] = m
            if row[kind] == 0:
                assert m['generation'] == {'highest': None, 'mean': None}
                assert all(all(x is None for x in t.values()) for t in m['traits'].values())
            else:
                assert 0 <= m['generation']['mean'] <= m['generation']['highest']
                for trait in m['traits'].values():
                    assert all(math.isfinite(x) for x in trait.values())
                    assert trait['min']-1e-9 <= trait['mean'] <= trait['max']+1e-9
                    assert trait['standard_deviation'] >= 0
            if row['tick'] == 0 and row[kind]:
                assert m['species'] == 1 and m['births'] == m['deaths'] == 0
                assert m['generation'] == {'highest': 0, 'mean': 0.0}
                for name, value in FOUNDER.items():
                    trait = m['traits'][name]
                    assert math.isclose(trait['mean'], value, abs_tol=1e-12)
                    assert trait['min'] == trait['max'] == value
                    assert trait['standard_deviation'] == 0
        total = sum(row[kind] for kind in KINDS)
        if total:
            mean = sum(row[k]*a[k]['generation']['mean'] for k in KINDS if row[k])/total
            assert math.isclose(a['generation']['mean'], mean, abs_tol=1e-9)
        else:
            assert a['generation'] == {'highest': None, 'mean': None}
    for kind in KINDS:
        last = result['series'][-1]['analytics'][kind]
        assert last['births'] == result['totals']['births'][kind]
        assert last['deaths'] == result['totals']['deaths'][kind]
        assert last['species'] == result['final']['species'][kind]
    RUNS += 1
    return result

with tempfile.TemporaryDirectory(prefix='task020-review-', dir=ROOT/'target') as d:
    folder = Path(d)
    run(folder, [2, 1, 0], 0, 9)
    run(folder, [0, 0, 0], 13, 5)
    results = [run(folder, [16, 4, 2], 1200, k) for k in (1, 7, 5000)]
    assert len({r['state_hash'] for r in results}) == 1
    fine = {r['tick']: r for r in results[0]['series']}
    for result in results[1:]:
        assert all(row == fine[row['tick']] for row in result['series'])
    run(folder, [0, 4, 2], 2500, 33)
print(f'PASS: {RUNS} real headless launcher runs; founder oracle, sample boundaries, cumulative accounting, causes, trait/null/generation invariants and interval-independent hashes/rows')

# TASK-020 PLAN cycle 1

Applied /workspace/.agents/skills/plan/SKILL.md. AGENTS.md and docs/STATE.md
verified first. Read project/contract/state/architecture, task/spec JSON,
dependency TASK-017/018/019 plan/implement/review handoffs and relevant source,
ADR-004/007/014/015. Dependency reviews all PASS with empty gaps. No prior
TASK-020 handoffs/review gaps. Initial tree clean and no Git remotes. No package
installed, feature code changed, commit made or phase transition started.

## Findings and decisions

src/cli/run.rs currently captures only tick and living kind counts; start,
absolute interval boundaries and final are already deduplicated. Population
exposes iter, counts, totals, deaths_by_cause and species; organism exposes
immutable traits and generation. All needed authoritative counters already exist.
Death accounting is complete only after Commit. src/metrics.rs does not exist.
One exploratory read included that nonexistent path and returned exit1; this
confirmed the planned boundary rather than a product failure. Source reads with
large combined output were truncated; subsequent focused reads inspected the
needed APIs and dependent review outcomes.

ADR-016 records chosen wire semantics, algorithm, alternatives and state boundary.
Always add analytics to existing result series with metrics_schema1; no extra
CLI option. Spread means population standard deviation, with min/max also
reported. Counters are cumulative since tick0. All twelve phenotypes are included
for all kinds, even inactive plant traits. Per-kind and overall living generation
summaries remove ambiguity in the highest/mean generation criterion. Empty
statistics are null; counters/species remain zero. No histograms or vitals added.

## Ordered work for the assigned IMPLEMENT phase

1. Add src/metrics.rs, export pub mod metrics in src/lib.rs. Define public
   Snapshot, KindMetrics, TraitSummary, TraitMetrics and GenerationSummary value
   records (private fields/read-only getters or equivalent immutable public
   records), Clone/Debug/PartialEq. Snapshot::capture(&Simulation)->Self,
   tick(), counts(), kind(Kind), generation() and to_json()->serde_json::Value
   are the intended reusable surface. Keep JSON wire names explicit rather than
   Rust enum/debug strings. Snapshot owns bounded summaries, not engine references
   or organism copies. No changes needed to Population/Simulation production API.
2. Private Welford accumulator tracks count/mean/M2/min/max. Update twelve trait
   summaries in stable Population::iter ID order; use explicit trait extraction
   once per organism. Generation highest remains exact u64, average uses f64.
   Derive lifecycle/cause fields from existing totals/getters; query living
   species by kind. No cumulative metric-side cache, pending event observer,
   death-history scan, randomness or engine mutation. Final variance clamped to
   nonnegative to avoid numerical sqrt artifacts. All valid values are bounded
   and finite; null for no observations avoids division by zero/NaN JSON.
3. In src/cli/run.rs replace minimal sample construction with Snapshot capture
   plus explicit row conversion preserving tick/plants/herbivores/carnivores.
   Add metrics_schema:1 to result root. Keep existing try_reserve, exact-N tick
   loop, tick-only timing, sample schedule, arbitrary seed precision and atomic
   publication unchanged. Do not introduce extra root files/options. Keep hash
   schema1 and golden digest unchanged. No save/load/batch implementation.
4. Add tests/metrics.rs for public founder/empty/singleton snapshots and repeated
   captures; add owner-local cfg(test) fixture tests for heterogeneous genomes,
   known generations and committed lifecycle/cause totals. Prefer existing
   Population initialization/queue_birth/kill/commit primitives. If private
   owner setup is required, put tests in src/population/metrics_tests.rs registered
   under cfg(test); no public mutation API and no malformed production state.
   Use raw chosen alleles and independently written mapping arithmetic for every
   phenotype, and a pure accumulator test with samples1,3 => mean2/stddev1.
   Establish coherent species membership for any altered fixture genome using
   owner-local existing pattern; do not alter historical species founders later.
5. Extend tests/run_cli.rs or add tests/metrics_cli.rs. Validate complete nested
   key sets, exact integers, nulls, start/interval/nondivisible end and N0 once,
   extinct tails, repeat-run equality excluding timing, state hashes across
   intervals and direct unsampled library engine. Existing tests parsing only
   contract fields should remain valid. Extend tests/test_entrypoints.py copied
   static run assertions to inspect metrics_schema and one complete sample.
6. Add docs/METRICS.md as normative format/API/units/semantics reference with a
   valid complete example (including every trait/cause), null rules, cumulative
   convention, population deviation and generation precision. Update README run
   usage with an actual example showing --sample-every and result analytics.
   Finalize ADR-016 status, STATE and ARCHITECTURE with actual evidence/limits.
   Run checks below and write honest implementation handoffs. Harness owns review.

## Acceptance tests and independent oracles

- Every sample has counts, births/deaths, five causes, species, all twelve
  phenotype summaries and generation: CLI schema and small-world snapshots;
  require exact key sets so a forgotten trait cannot silently pass.
- Hand oracle: founder-only world e.g. [2 plants,1 herbivore,0 carnivores] tick0
  has those counts, living species[1,1,0], zero lifecycle totals, generation0,
  zero trait spreads. Founder allele32768 maps with q=32768/65535: speed2,
  strength1+9q, max_health10+90q, lifespan1100, fertilityq, vision4,
  metabolic_multiplier0.5+1.5q, preferred_temperature/moistureq,
  climate_tolerance0.05+0.45q, aggression/riskq. Verify actual genome mapping
  integer rounding against src/genome.rs before locking the test constants.
- Heterogeneous valid endpoint genomes allow manual trait mean midpoint and
  stddev half the endpoint difference (integer phenotype endpoints included).
  Controlled generations0 and2 give highest2/mean1. Verify kind separation and
  weighted overall mean with unequal kind counts, not average of kind means.
- Owner-local controlled lifecycle fixture: initialize enough same-kind parents,
  queue a valid inherited child, kill distinct individuals under all five causes,
  Commit; assert exact births1, deaths5, each cause1 and initial+births-deaths.
  Repeat by kind or include all kinds, respecting two-parent animal arity. Check
  species by independent living SpeciesId sets and historical extinct exclusion.
- Capture purity: compare before/after clone equality and state_hash; twin engines
  sampled every tick/repeatedly versus never sampled advance identical ticks.
  Cover seeds0,1,42 on a mixed small world and a plant-reproducing config for
  >=2200 ticks plus extinct continuation, reusing bounded existing fixtures.
  Compare hashes at selected boundaries to avoid quadratic lifetime-history work;
  use full equality at other checkpoints. This exercises evolution, not just tick0.
- CLI files: same engine hashes for --sample-every1,3,99, default; N0, N7/K3,
  interval>N, end divisible/nondivisible and empty populations. Match cumulative
  final sample to root totals and causes to deaths, maintain exact integer JSON.
- Numerical primitive tests for empty, singleton, constant, [1,3], stable variance;
  wide u128 counter serialization and u64 highest generation stay integer.

## Commands and evidence

Executed in PLAN:
`env -u DISPLAY cargo test --locked --test run_cli --test state_hash > /workspace/target/task020-plan-baseline.log 2>&1`
passed exit0 (4 run CLI +2 hash integration tests). This is baseline coverage;
metrics implementation/tests do not yet exist. No full suite or performance claim.
Required-file check and clean Git/no-remote inspection succeeded.

Planned in IMPLEMENT (not executed here):
- `env -u DISPLAY cargo test --locked --lib --test metrics --test run_cli --test state_hash`
  (include --test metrics_cli if split into a separate file).
- `./test.sh > /workspace/target/task020-implement-full.log 2>&1`
  includes host/musl setup/build and copied-empty-root runtime tests.
- `cargo fmt --check` and `git diff --check`.
- Validate handoff UTF-8/required fields, exact changed paths and protected scope.

## Risks and limits

Always-on analytics expands result buffers by a fixed per-sample factor;
--sample-every controls sampling but extreme valid requests can still OOM, as
before. Species queries scan lifetime history; capture must not walk death
history or hash per entity. Floating statistics are deterministic on the same
build but require tolerance-based mathematical assertions. Generation means
lose low bits above2^53; highest/counters remain exact. Existing GNU/musl numeric
hash differences are allowed across builds. Do not retune ecology to obtain
pretty metrics or claim long coexistence from these tests. No system dependencies
or crate changes are expected; inherited setup.sh reinstalls missing musl tooling.
No blocker or unresolved acceptance gap; no prior review remediation required.

## Planning artifact validator

Executed with python3 (exit0), followed by git diff --check (exit0):

```python
from pathlib import Path
import json, subprocess
r = Path('/workspace')
h = json.loads((r/'tasks/TASK-020/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-020','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int
    assert isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=r,text=True).splitlines()
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert changed == set(h['changed_files']), changed
for p in changed:
    (r/p).read_text(encoding='utf-8')
    assert p.endswith(('.md','.json'))
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: planning handoff schema, UTF-8, exact documentation scope, no remotes and whitespace')
```

"""Local phase-artifact validation; run from /workspace after implementation."""
import json
from pathlib import Path
import re
import subprocess

root = Path('/workspace')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).splitlines()

h = json.loads((root / 'tasks/TASK-020/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id', 'phase', 'cycle', 'summary', 'changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'verdict', 'gaps'} <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-020', 'implement', 1, 'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'], str)
for key in ('changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps'):
    assert isinstance(h[key], list)
for t in h['tests']:
    assert isinstance(t['command'], str) and type(t['exit_code']) is int and isinstance(t['notes'], str)
changed = set(git('diff', '--name-only') + git('ls-files', '--others', '--exclude-standard'))
assert changed == set(h['changed_files']), (changed, h['changed_files'])
for path in changed:
    (root / path).read_text(encoding='utf-8')
    assert not (path in {'AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md'} or path.startswith(('.agents/skills/', 'tools/')) or re.match(r'tasks/[^/]+/task\.(md|json)$', path)), path
assert not git('remote', '-v')
s = (root / 'docs/METRICS.md').read_text()
row = json.loads(re.search(r'```json\n(.*?)\n```', s, re.S).group(1))
traits = {'speed', 'strength', 'max_health', 'lifespan', 'fertility', 'vision', 'metabolic_multiplier', 'preferred_temperature', 'preferred_moisture', 'climate_tolerance', 'aggression', 'risk_tolerance'}
assert set(row) == {'tick', 'plants', 'herbivores', 'carnivores', 'analytics'}
assert set(row['analytics']) == {'plants', 'herbivores', 'carnivores', 'generation'}
for kind in ['plants', 'herbivores', 'carnivores']:
    k = row['analytics'][kind]
    assert set(k) == {'births', 'deaths', 'deaths_by_cause', 'species', 'traits', 'generation'}
    assert set(k['traits']) == traits
    assert set(k['deaths_by_cause']) == {'starvation', 'injury', 'predation', 'old_age', 'climate'}
    assert all(set(t) == {'mean', 'standard_deviation', 'min', 'max'} and all(v is None for v in t.values()) for t in k['traits'].values())
log = (root / 'target/task020-full.log').read_text()
results = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
assert sum(int(r[0]) for r in results) == 194
assert all(r[1:] == ('0', '0') for r in results)
assert 'Ran 8 tests' in log and log.rstrip().endswith('OK')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
print('PASS: handoff, UTF-8, exact inventory, protected scope, no remotes, example, suite count and whitespace')

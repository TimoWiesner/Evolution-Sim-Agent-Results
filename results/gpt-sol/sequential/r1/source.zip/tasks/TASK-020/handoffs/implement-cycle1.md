# TASK-020 IMPLEMENT cycle 1

Applied `.agents/skills/implement/SKILL.md` and approved plan-cycle1/ADR-016.
Verified /workspace/AGENTS.md and /workspace/docs/STATE.md before reading the
project/interface/state/architecture/task, task handoffs, dependency TASK-017/018/
019 handoffs and relevant ADRs. Dependency reviews PASS, no remediation gaps.
Initial tree clean and no Git remotes. No commits, protected specifications,
benchmark state/tools, remote changes, questions or phase transitions.

## Implementation and acceptance mapping

- Public metrics module provides owned typed Snapshot, KindMetrics, TraitMetrics,
  TraitSummary and GenerationSummary values. Snapshot::capture(&Simulation),
  tick/counts/kind/generation getters and explicit to_json full-row conversion
  reuse immutable production APIs. CLI captures at its unchanged start/interval/
  end schedule. Result gains metrics_schema1 and each series row gains analytics.
- Every sample retains living populations, cumulative exact u128 births/deaths,
  all five death causes, living species, twelve phenotype mean/population stddev/
  min/max summaries and per-kind/overall highest/mean generation. No RNG access,
  authoritative state, ecological equation/default/config/dependency change,
  canonical/hash schema change, death-history scan or engine reverse import.
- Stable-ID Welford accumulation, nonnegative final variance, null empty moments,
  integer highest generation and weighted individual-level overall mean implement
  ADR-016. docs/METRICS.md defines every field, cause/trait key, unit, cumulative
  convention, population spread, precision, costs/API and complete JSON example.
  README documents actual --sample-every usage and how to find analytics.
- Four private tests independently verify empty/singleton/constant/[1,3]/large-
  offset accumulator results; heterogeneous endpoint trait bounds with midpoint/
  half-range oracles; generations0/2 and overall0/2/4 weighted mean2; all-kind
  committed births1/deaths5/each cause1/count2 and later historical extinction;
  u128 counters and u64 highest remain exact JSON integers.
- Public founder hand oracle uses raw allele32768/65535 arithmetic for all twelve
  traits, distinct kind counts, singleton and absent/empty worlds. Repeated
  captures on seeds0/1/42 through2200 ticks compare full engines every tick and
  hashes every550 ticks versus a never-sampled twin, including mixed worlds,
  plant reproduction beyond founder lifespan and naturally extinct empty tails.
- CLI tests inspect exact nested key sets, independent public engine rows at
  every sample, N0/1/7/99/100/250, default/K1/K3/K>N and divisible/nondivisible end,
  deterministic repeated JSON, final totals/species/causes and extinct tails.
  Existing seed/interval hash oracles and hash golden test remain passing.
  Python copied static empty-root tests now check complete analytic record shape.

## Plan refinements and limits

No behavior deviations. Private tests live under src/metrics/tests.rs instead
of adding a Population child module: existing cfg(test)-only fixture_mut and
fixture_species_from_genomes already supply controlled coherent species setup,
so no extra mutation API was necessary. The endpoint generation fixture directly
sets generation metadata to isolate arithmetic; production birth/lineage paths
are exercised by the separate valid queue/Commit and real2200-tick tests.
Detached public summary fields are mutable values, never engine references.

No packages installed or dependencies changed. Existing setup.sh detects/reinstalls
musl tooling/target using exact commands already in docs/STATE.md. No fresh Ubuntu
replacement or separate minimum-Rust build claim. Large sample buffers/output and
species history can grow; f64 generation means lose precision above2^53 while
highest/counters stay exact. Timing excludes analytics, so not whole-run speed.
Charts, batches, checkpoints and ecology tuning remain outside this phase.

## Commands and actual outcomes

- Initial `cargo fmt`: exit1 because new cfg(test) child file had not yet been
  created; no product/test failure. Created the file, reran formatting successfully.
- `cargo test --locked --lib metrics > target/task020-unit.log 2>&1`: exit0,
  four new unit tests pass,110 filtered out.
- `env -u DISPLAY cargo test --locked --lib --test metrics --test run_cli --test state_hash > target/task020-targeted.log 2>&1`:
  exit0,123 tests (114 unit,2 metrics,5 CLI,2 hash), none failed/ignored.
- `cargo fmt --check` and `git diff --check`: exit0 after source/doc edits.

Final full-suite and artifact validation evidence is recorded in the adjacent
JSON and docs/STATE.md after completion. Logs in ignored target/ are local only;
this handoff preserves commands/results for the next fresh process.


Final `./test.sh > target/task020-full.log 2>&1`: exit0,202 tests passed:
114 units,79 integration,1 rustdoc,8 Python; no failures/ignored/skips. Includes
host/musl setup/build, static ELF and copied empty-root run analytics. Final
`cargo fmt --check` and `git diff --check`: exit0. Python documented-example
schema validator: exit0. Full-suite log count validator: exit0 (194 Rust,8 Python).

Final artifact validator command:
`python3 tasks/TASK-020/handoffs/validate-implement-cycle1.py`
checks UTF-8/identity/required field types, exact changed-file inventory, no
protected paths or remotes, complete documented JSON shape and full-suite totals.
It runs `git diff --check` as well. This is a task-local implementation artifact,
not a benchmark reference check. Exit0 recorded in the JSON handoff.

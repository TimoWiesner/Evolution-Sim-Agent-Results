# TASK-020 REVIEW cycle 1

Verdict: PASS. All five acceptance criteria met; no remediation gaps.
External harness checks remain authoritative.

Verified /workspace/AGENTS.md and /workspace/docs/STATE.md first. Applied
/workspace/.agents/skills/review/SKILL.md. Inspected task/spec JSON, approved plan,
implementation handoffs, dependent TASK-017/018/019 phase evidence, project,
contract, state/architecture and relevant ADR-001/004/007/014/015/016. Independently
inspected committed implementation diff 40521e1..299bab4 and current source/tests.
Initial tree clean; no Git remotes. No product changes, packages, commits,
protected-file edits, benchmark changes or phase transitions.

## Acceptance evidence

1. Every sample has population, cumulative births/deaths, all five causes, living
   species, all twelve expressed traits with mean/population standard deviation,
   and highest/mean living generation per kind and overall. Explicit mappings in
   src/metrics.rs agree with Kind::ALL, DeathCause::ALL and LOCUS_NAMES. Capture
   reads completed state; CLI retains start/interval/end sampling without duplicate
   ticks. CLI schema tests check exact nested key sets and direct engine rows.
2. Recording is observational: immutable Simulation reference, owned summaries,
   no RNG access, mutation, persistent cache or reverse core dependency. The only
   production changes are the metrics module/export and additive CLI capture/root
   schema key. Public repeated-capture tests compare full sampled/unsampled engines
   at every tick for seeds0/1/42 through2200 and hashes every550 ticks, including
   reproduction and extinct tails. Existing canonical golden hash remains valid.
3. The documented run --out result contains metrics_schema1 and analytics in
   every series sample, from both launcher and copied static executable. No new
   flag is necessary. Six independent real launcher probes verify output files,
   empty stdout, no display, exact sample boundaries and common-row/hash equality
   for intervals1/7/5000 through1200 ticks.
4. docs/METRICS.md specifies cumulative convention, causes/trait keys and units,
   population spread, exact integer counters, empty nulls, per-kind/individually
   weighted overall generation, schema, API, costs and complete JSON example.
   README links it and documents --out/--sample-every usage. The schema matches
   the implementation. Timing excludes metrics as documented.
5. Small-world tests use independent arithmetic: founder allele32768/65535;
   endpoint phenotypes with midpoint/half-range oracles; accumulator[1,3] gives
   mean2/spread1; generations0/2 and weighted0/2/4; committed births1/deaths5 with
   each cause1 for every kind; historical extinction and exact wide integers.
   Existing cfg(test) fixtures remain internal. The independent Python probe
   repeats the founder oracle through the actual launcher and verifies per-row
   conservation, cause sums, monotonic counters, nulls and generation weighting.

## Commands and outcomes

Final checks executed from /workspace, all exit0:
- `./test.sh > target/task020-review-full.log 2>&1`: 202 tests passed (114 Rust
  unit,79 integration,1 rustdoc,8 Python), no failures/ignored/skips. Includes
  host/musl setup/build, static ELF and copied executable runs in empty chroot.
- `python3 tasks/TASK-020/handoffs/review-checks.py`: six real headless launcher
  runs pass. Cases: founder2/1/0 N0 K9; empty N13 K5; mixed16/4/2 N1200 at
  K1/7/5000; no-plants0/4/2 N2500 K33, seed42,8x6 world. Script retained.
- `cargo fmt --check` and `git diff --check`: pass.
- Inline Python full-suite log validator:194 Rust +8 Python, all zero failures/
  ignored, final Python OK. Command logic: sum regex
  `test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored` and check final OK.
- Final review artifact validator below: UTF-8 JSON/types/inventory, implementation
  inventory, protected scope, no remotes, documented JSON and whitespace pass.

The first artifact-validator extraction failed with SyntaxError because a literal
Markdown fence in its regex prematurely ended the extracted block. Replaced the
literal fence with chr(96)*3; the corrected validator passes. No product test failed.

## Limits and nonblocking note

Always-on analytics increases output/storage; species queries scan historical
records. f64 generation means lose low bits above2^53; exact highest and counters
are preserved. No separate fresh Ubuntu/minimum-Rust or throughput claim.
No new dependencies installed; existing exact reinstall commands in STATE apply.
Architecture and state ownership need no changes.

ADR-016's sentence 'singleton and founder generation is zero' overgeneralizes:
a singleton descendant retains its actual generation. docs/METRICS.md, code and
tests correctly define actual living generation and only founders as zero. This
is a nonblocking ADR wording issue, not a format/behavior acceptance gap; a later
documentation edit can say 'singleton trait spread is zero; founder generation
is zero'. No implementation remediation is required. Harness owns completion,
commits and subsequent phase assignments.

## Review artifact validator

```python
from pathlib import Path
import json, re, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-020/handoffs/review-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-020','review',1,'PASS')
assert type(h['cycle']) is int and h['gaps']==[] and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert changed==set(h['changed_files'])
for p in changed: (root/p).read_text(encoding='utf-8')
i=json.loads((root/'tasks/TASK-020/handoffs/implement-cycle1.json').read_text())
assert set(git('diff','--name-only','40521e1','299bab4'))==set(i['changed_files'])
protected=['AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools']
assert not git('diff','--name-only','40521e1','--',*protected)
assert not git('remote','-v')
s=(root/'docs/METRICS.md').read_text()
example=json.loads(re.search(chr(96)*3+r'json\n(.*?)\n'+chr(96)*3,s,re.S).group(1))
assert example['tick']==0 and all(example[k]==0 for k in ('plants','herbivores','carnivores'))
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: review handoff UTF-8/schema/inventory, implementation scope, protected paths, no remotes, documented JSON and whitespace')
```

# TASK-013 REVIEW cycle 1

Verdict: PASS. No acceptance gaps or product edits required.

Verified AGENTS.md and docs/STATE.md exist before inspection. Applied
.agents/skills/review/SKILL.md; inspected project/contract/state/architecture,
task specification/JSON, TASK-013 plan and implementation handoffs, dependency
TASK-008/010 handoffs and relevant ADR-003/004/007/010. Independently inspected
implementation diff b27a0e2..9ba7183 and actual source/tests. Initial worktree
was clean and git remote -v empty. No packages installed, protected files edited,
Git network actions, commits or phase transitions performed.

## Acceptance findings

1. Trait-based perception: Population::sense delegates to indexed nearby with
   genome-derived vision, excludes self, and preserves sorted IDs. Public
   observational tests and private vision_from_dna_matches_unsigned_oracle_at_seams_and_tiny_axes
   compare with independent unsigned-distance scans across 19x19, 1x19, 19x1,
   and 1x1 worlds, minimum/interior/maximum vision, colocation and dead observers.
2. Adjacent speed-limited movement: both real animal walkers call the same
   executor after age/expiry. Loop is bounded by inherited speed; next_toward
   takes one signed step per axis. executor_steps_are_adjacent_paid_and_indexed_for_every_speed_and_metabolism
   and exploration_every_speed_matches_reference_steps_and_real_ticks cover
   speeds 1..4, intermediate steps and agreement with production ticks.
3. Movement energy: finite configured cost * speed * metabolism is checked before
   movement or random destination selection, then debited after relocation via
   Population. Independent ledgers cover differing distances/speeds/metabolism,
   zero and maximum configured cost, insufficient energy and exact exhaustion.
   Exact exhaustion removes the animal/cache immediately and counts death once.
   Zero cost is an explicitly valid existing configuration setting.
4. Shortest routes: helper tests exhaust all pairs for worlds 1..8 on both axes,
   independently verify distance decreases exactly one per step, and exercise
   positive half ties. Public actual ticks cross horizontal, vertical and corner
   seams. Target ranking uses wrapped distance then ID and stops at target.
5. Sharing: ADR-010, ANIMALS.md and SPATIAL.md consistently allow unlimited
   co-occupancy for every kind. Founder/committed-birth/movement paths have no
   universal collision gate. Actual ticks stack both animal kinds; animals enter
   plant cells. Plant establishment exclusion remains a documented local policy,
   consistent with the previously accepted reproduction task.
6. Index synchronization: move_one_step relocates buckets and record immediately;
   lethal debit removes both. Per-step callback tests observe the real executor,
   sequential production walkers see earlier actors' new positions, and existing
   randomized spatial lifecycle oracles remain passing. Public four-seed 2200-tick
   positive-cost replay checks determinism, conservation, speed/sense/cache oracles
   and absorbing extinction with nonvacuous movement/energy observations.

## Regression and scope review

Old weather-only tests now isolate animals; lifecycle expiry tests explicitly
use zero movement cost. Genetics uses 1x1 to isolate its existing RNG purpose.
Plant establishment sharing isolates an animal with insufficient movement energy.
These changes preserve their original assertions; new tests separately cover
positive costs, both animal walkers and weather -> animal -> plant RNG ordering.
No added authoritative state, dependency, configuration schema or public mutation
escape. Ecology helper dependencies follow the planned boundaries. Architecture
and ADRs accurately describe the change; no architecture revision was necessary.

## Commands and actual results

- ./test.sh > target/task013-review-full.log 2>&1 : exit 0; 115 passed,
  no failures/skips (50 Rust unit, 57 integration, 1 rustdoc, 7 Python).
  Includes exhaustive movement geometry, full replay and randomized spatial tests;
  packaging exercises host/musl setup/build, static ELF and copied-empty-root
  version execution. Log is an ignored build artifact; this report is durable.
- cargo fmt --check && git diff --check : exit 0.
- python3 review artifact validator (executed after writing handoffs): verifies
  required UTF-8 JSON fields/types, exact three review paths, protected committed
  paths, absent remotes and whitespace. See structured handoff for result.

## Limits and follow-up

No task remediation required. Animals reaching food do not eat yet; unaffordable
movement can leave an animal alive until lifespan expiry because basal costs are
later scope. Exploration can revisit cells. No throughput/coexistence, future
checkpoint equivalence, fresh-container or separate minimum-Rust claim is made.
No new dependency installation. Preserve complete RNG/DNA/vitals/positions/settings
and movement model identity in future persistence; rebuild/exclude derived cache.
Harness owns task completion, phase commits and subsequent assignment.

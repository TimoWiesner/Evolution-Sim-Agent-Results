# TASK-013 IMPLEMENT cycle 1

Implemented the approved plan and ADR-010 model 1. No review phase started,
commits created, task specifications/state changed, remotes configured, packages
installed or files outside /workspace accessed. Required AGENTS.md/STATE.md were
verified before inspection. Read project/contract/state/architecture, task and
plan handoffs, dependency handoffs and relevant ADR/source/test interfaces;
applied .agents/skills/implement/SKILL.md. Dependency reviews report PASS/no gaps.
Some initial combined inspection output truncated; focused follow-up reads
supplied relevant interfaces. No known blockers or plan deviations.

## Result and boundaries

Population::sense uses the existing index, DNA vision and stable ID order,
excluding self; None for missing/plants. Private animals helpers import only
config/traits/topology/rng. Both production animal walkers call one executor,
retaining age-first expiry and newborn timing. Target ranking is (wrapped
distance, ID), toward visible plants/herbivores respectively. Each shortest step
is adjacent; at most speed steps. Without food, uniform unique sorted-neighbor
sampling consumes the sole RNG per affordable step. A 1x1 world has no step/draw.

Each completed step costs movement_cost * speed * metabolic_multiplier. Check
budget before choosing/moving, relocate through Population, then debit through
Population; exact exhaustion removes/indexes immediately. Unexpected primitive
errors surface as invariant failures. Co-occupancy is unrestricted for all kinds;
local plant establishment policy stays intact. No new persistent state, schema,
dependency or public mutation API. A private observer callback on the actual
executor allows per-step assertions; production uses a no-op callback.

No feeding, attacks, mating, basal maintenance or animal climate damage was added.
Positive but insufficient energy can currently keep an animal stationary until
old age. No performance or coexistence claim. Future canonical state must encode
model identity and all existing DNA/RNG/positions/vitals/settings; derived cache
and temporary navigation data are excluded. See docs/ANIMALS.md.

## Acceptance evidence

- Sensing: public sense test and private DNA vision oracle test compare exact
  sorted IDs using unsigned wrapped distance, all kinds/self exclusion, 1x1,
  1xN/Nx1 and 19x19 full-grid founders, min/interior/max vision and dead observers.
  Clone equality verifies queries do not mutate RNG/state.
- Steps/speed: private executor test covers speeds 1..4, metabolism endpoints,
  one/four-cell pursuits, intermediate adjacency/index visibility/energy. Actual
  production ticks agree on position/energy. Exploration covers each speed with
  reference draws and actual ticks. Plants remain stationary under their walker.
- Energy: independent numeric ledgers cover speed/metabolism/distance, costs
  0/1/1,000,000, targeted and untargeted actions, below-cost/no draw, exact-cost
  death and one death count, removal before the next query and no later step.
- Paths: helper test exhausts all source/target pairs for every 1..8 dimension,
  decreasing independent unsigned distance exactly one each step; positive half
  ties explicit. Actual public ticks cross horizontal/vertical/corner seams;
  private ticks verify lower-ID food ties, invisible food and co-located stops.
- Sharing: actual ticks put multiple herbivores/carnivore on the same cell,
  animal arrivals share plant cells, and all-kind stacked 1x1 ticks stay valid.
  Existing internal birth sharing and local plant rejection/reservation tests
  remain passing. Plant sharing fixture now sets animal energy below cost to
  isolate its original establishment purpose.
- Index: every observed real step checks old/new cells, lethal debit removes
  immediately; real sequential production walkers show carnivore following the
  earlier herbivores' new positions. Existing 4096 randomized lifecycle/cache
  oracle checks remain. Public four-seed 2200-tick positive-cost replay checks
  exact state, conservation, positive vitals, sensing/occupancy oracles, speed
  bounds and extinction staying zero; movement/cost assertions are non-vacuous.
- RNG: independent sorted-neighbor test verifies tiny-grid deduplication, no-draw
  1x1 and below(1). Full tick stream test checks weather, herbivore wander,
  carnivore wander, then plant dispersal; existing genetics/mutation reference
  tests remain. Rejected/targeted/stationary moves draw nothing.

## Fixture migrations

Weather-only scheduler integration sets zero animals. Genetics engine-stream
fixture uses 1x1 with mixed founders, leaving weather as its only tick draw before
explicit births. Lifecycle founder-expiry fixture explicitly sets movement_cost=0
so old full-energy/OldAge assertions retain their purpose; new public replay uses
default positive cost. Plant establishment sharing fixture leaves a stationary
animal via insufficient energy; sharing and movement are independently covered.
No conservation assertion was weakened.

## Commands and actual results

- Initial `cargo test --locked --lib --test lifecycle --test simulation > target/task013-initial.log 2>&1`:
  exit 101, compile error in new wander test: Rng::from_seed needs &Seed, not an
  integer. Fixed test using Seed::from_u64.
- Same selected tests to target/task013-initial2.log: exit 101; 43 unit pass/one
  old plant sharing fixture fails because its animal now moves. Isolated it as
  described above.
- `cargo test --locked --lib --test lifecycle --test simulation > target/task013-unit.log 2>&1`:
  exit 0, 49 unit + 6 integration pass after fixes/new coverage.
- `env -u DISPLAY cargo test --locked --lib --test animal_movement --test lifecycle --test simulation --test spatial > target/task013-targeted-final.log 2>&1`:
  exit 0, final 63 pass (50 unit + 13 integration).
- `./test.sh > target/task013-full-final.log 2>&1`: exit 0, final 115 pass with no
  skips (50 unit + 57 integration + 1 rustdoc + 7 Python). Packaging suite executes
  setup/build host/musl, static ELF checks and copied version in an empty chroot.
  Earlier full invocations also passed before final extra coverage. No product
  source changed after this final full run.
- `cargo test --locked --lib animal_tests > target/task013-extra.log 2>&1`: exit 0,
  five selected tests before final exploration case.
- `cargo test --locked --lib exploration_every_speed > target/task013-explore.log 2>&1`:
  exit 0, one selected test; followed by final targeted/full commands above.
- `cargo fmt --check && git diff --check`: exit 0.

No separate fresh-container or Rust 1.85 run; no throughput benchmark required or
executed. Target log artifacts are ignored build outputs, not cross-phase memory;
this handoff records the durable results. No system dependencies added; setup's
existing reinstall instructions remain in STATE. Harness assigns the next phase.

Final artifact validator (run from /workspace):

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-013/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-013','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ['changed_files','decisions','tests','risks','next_steps','gaps']:
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual==set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
assert not git('remote','-v')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: handoff schema, changed paths, protected files, no remotes, formatting and whitespace')
```

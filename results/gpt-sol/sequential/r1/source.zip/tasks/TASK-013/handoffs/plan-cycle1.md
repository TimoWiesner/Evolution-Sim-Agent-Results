# TASK-013 PLAN cycle 1

Required AGENTS.md and STATE.md verified first; clean initial Git tree and no
remotes. Read project/contract/state/architecture, task JSON/spec, current PLAN
skill, existing TASK-008/010 dependency phase handoffs, relevant ADRs, TASK-012
implementation evidence and actual topology/traits/config/population/simulation
sources/tests. Dependency reviews PASS without gaps. No prior TASK-013 handoffs,
review gaps, or TASK-014/015/016 handoffs exist; downstream specifications inspected.
Some combined reads truncated; follow-up source/interface reads supplied the
planning context. Applied .agents/skills/plan/SKILL.md. No feature code changed,
application tests run, packages installed, commits or phase transitions.

## Ordered implementation work, only when assigned IMPLEMENT

1. Implement ADR-010 model 1 exactly. Add private src/ecology/animals.rs and
   register in src/ecology/mod.rs. Pure helpers next_toward, step_cost and
   wander_step use existing validated types and engine RNG. next_toward returns
   None at target. Wander uses unique radius-one neighbors sorted (y,x), origin
   excluded; below(count) only when count > 0. At most eight cells, no extra
   persistent state, dependencies or public mutation API.
2. Add public Population::sense(OrganismId)->Option<Vec<OrganismId>> in
   src/population.rs: None for missing/plants; otherwise nearby at derived vision,
   all kinds except observer, ascending IDs. Use existing index and no RNG.
   Retain nearby's generic include-self semantics unchanged.
3. In src/simulation.rs replace both empty animal hooks with one private
   animal_movement(id) used by the actual walk_kind. Age/expiry remains first.
   Sense once, rank food candidates by (distance,ID), retain chosen cell. Pursue
   with shortest signed adjacent steps or wander if no target. At each iteration
   check budget, liveness, target reached, available distinct destinations and
   affordability before RNG/mutation; move via existing move_one_step then debit
   through change_energy. Stop at target, insufficient energy, death or speed
   budget. Unexpected primitive errors indicate invariant failure, not a silently
   skipped move. No feeding, attacks, mating, basal costs or climate animal damage.
4. Add tests/animal_movement.rs for public sensing, actual production ticks,
   co-occupancy, index results after moves and deterministic cloned replay.
   Add private tests alongside helpers/simulation for custom genomes, energy,
   exact paths and step visibility using existing cfg(test) fixture_mut and
   move_one_step for setup. Test-only trace/callback instrumentation may observe
   the actual movement executor if needed; do not implement a second movement
   loop for tests or expose teleport/spawn publicly. Test energy ledgers against
   independent numeric expectations and shortest distance against unsigned oracle.
5. Migrate obsolete fixtures carefully. tests/simulation.rs's weather-only draw
   expectation now conflicts with wandering: isolate weather with zero animals
   while retaining separate mixed-population production replay. Private engine
   RNG tests (including plant reproduction) must isolate animals where their
   purpose is weather/genetics draws, and separately assert weather -> herbivore
   wander -> carnivore wander -> plant reproduction stream ordering. Search all
   tests for unchanged RNG/positions/energy/OldAge-only assumptions. In
   tests/lifecycle.rs preserve founder-expiry tests with movement_cost=0 (movement
   may still draw); add default positive-cost accounting/starvation cases instead
   of weakening conservation/expiry expectations. Apply same strategy to spatial,
   plant and temporal tests only where their explicit purpose requires isolation.
6. Document implemented rules in docs/ANIMALS.md and docs/CONFIGURATION.md
   (movement_cost units/zero behavior), docs/SPATIAL.md (sense/co-occupancy),
   ARCHITECTURE/STATE and ADR-010 evidence. No CLI or contract change. Record
   actual results/failures and required implement handoffs. Harness owns commits
   and task transitions; do not start review.

## Acceptance and regression matrix

| Must have | Planned executable evidence |
|---|---|
| Trait-based edge-aware sensing | Vision alleles producing 1 and 8, interior values; all kinds incl. co-located other IDs, self excluded; exact inclusive boundary and just outside across horizontal/vertical/corner seams; compare sorted IDs against independent unsigned torus oracle; None for dead/missing/plant; no mutation/RNG draws; 1x1/1xN/Nx1 |
| Cell steps and speed cap | Speeds 1..4 under controlled DNA, actual tick pursuit and exploration; record each intermediate production move, each distance exactly 1 and count <= speed; reaching target stops early, co-located target does not move; plants never move |
| Energy costs scale | Equal-distance speed 1 vs 4, equal-speed one vs several steps, metabolism endpoints, configured zero and maximum costs, independent c and d*c expectations; no move/draw when below cost, exact-cost move then one Starvation death, immediate index removal, no later step; no stationary charge |
| Shortest wrapped path | Exhaustive 1..8 dimensions/source/target pairs helper paths vs unsigned-distance oracle; every step lowers remaining distance by one; even half ties positive; explicit actual animal tick seam/corner and unequal-axis pursuit; equal-distance food ties choose lower ID; invisible food ignored |
| Consistent sharing rule | Multiple founders, animal steps onto plant/animal and same-kind occupants, mixed/all kinds in 1x1, committed internal animal birth into occupied cell remains valid; retained plant establishment rejection/reservations are local policy; no collision cap introduced |
| Spatial synchronization | Query old/new cells after each production step, wrapped movements and lethal debit; oracle sense from another living animal observes current positions; actual sequential walker later actor sees earlier actor's new position; existing randomized lifecycle/cache tests retained |

Additional tests: wander reference draw sequence, deterministic (y,x) neighbor
mapping for tiny dimensions with duplicate directions collapsed, 1x1/no target
no draw, single-neighbor draw, target pursuit no RNG, early unaffordability no draw,
empty population no animal draws. Keep lifespan-before-action, newborn-first-next-
tick and first-death/Commit accounting. Run mixed small worlds four seeds
[0,1,42,u64::MAX] for 2200 ticks with clone equality, per-kind conservation,
positive living vitals, index oracle checks and extinction remaining zero. This
is replay/lifecycle evidence, not coexistence or full checkpoint equivalence.

Planned IMPLEMENT commands (not executed here):
- env -u DISPLAY cargo test --locked --lib --test animal_movement --test lifecycle --test simulation --test spatial
- ./test.sh (full Rust/rustdoc/Python setup/build/musl packaging regression)
- cargo fmt --check
- git diff --check

Allow time to repair regressions and write handoff within 30 minutes. No new system
dependencies expected; setup.sh reinstalls missing musl prerequisites using exact
commands already in STATE. No performance benchmark required by this task.

## Risks and resolution

Energy loss changes old tests and deterministic streams; preserve isolated old
assertions with explicit fixtures and cover new behavior separately. Cell-sharing
must be described consistently with plant establishment, not as a hidden hard cap.
A speed-dependent per-step charge means inherited maximum speed incurs higher
cost even on short trips; intentional simple physiology, documented in ADR-010.
Zero movement_cost is already a valid configuration exception to positive cost.
Animals stationary at food cannot eat until TASK-014/015, and insufficient-energy
animals do not move until later maintenance/feeding rules; these are task scope
limits, not replenishment. Local crowding/index overhead remains unmeasured.
No known blockers or review gaps.

## Executable planning validator

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-013/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-013','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-010-animal-movement.md','tasks/TASK-013/handoffs/plan-cycle1.md','tasks/TASK-013/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

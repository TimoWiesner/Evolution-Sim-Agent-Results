# TASK-019 IMPLEMENT cycle 1

Implemented the approved run/hash plan in this phase only. Required workspace
files were verified before reading. Read project/contract/state/architecture,
task spec/JSON, implementation skill, TASK-019 plan/ADR-015, relevant architecture
ADRs and TASK-003/TASK-018 dependency handoffs (both REVIEW PASS, no gaps).
Initial tree was clean; no Git remotes. No commits or phase transitions performed.
No task specs, contract, agent instructions, benchmark checks/tools/state edited.

## Implemented behavior and boundaries

- `run --config FILE --ticks N --out FILE [--seed INTEGER] [--sample-every K]`
  accepts separated option/value pairs in any order, each exactly once. N is
  digits-only u64 >=0, K digits-only u64 >=1. Missing, duplicate, unknown,
  checkpoint flags, invalid config/integer/path and returned engine/I/O errors
  report stderr/status2 without publishing a result. Runtime has no display or
  network requirement. Existing climate/version/help behavior is retained.
- `Seed::from_decimal` normalizes optional-minus ASCII decimal integers with no
  magnitude limit; `Config::with_seed` replaces only seed after full input
  validation. The original full integer, not only its modulo-u64 RNG seed, is
  represented in effective state and numeric JSON results.
- Run calls the existing engine exactly N times through extinction. Samples are
  tick0, multiples of K, and final tick once; N0 has one sample. Default interval
  max(1,N/100). Result includes every contract key plus state_hash_schema1.
  u128 totals preserve integer precision; timing measures only tick calls,
  excludes sampling/hash/I/O, is finite, and is zero for N0.
- Private std-only canonical primitives and owner encoders stream full schema-1
  state into SHA-256. Config, tick, RNG version/four words, all topology/climate/
  weather/settings/resources, living records/DNA/lineage/vitals/cooldowns,
  allocator/sequence/all accounting/cause counts, species history and ordered
  death history are encoded. Pending queues must be empty. Derived spatial cache,
  topology area, phenotypes and observational reports/timing/samples are excluded.
  Encoders are crate-private, with no production mutable API or new state.
- Publication serializes fully before creating a same-parent exclusive temporary
  regular file, writes/flushes/closes, then renames. Existing regular output is
  preserved on recoverable failure; absent output remains absent. Nonregular
  and symlink destinations reject; write/rename injection tests check cleanup.
- README includes a complete launcher example. ADR-015 documents exact schema,
  model names/versions, golden hash, exclusions and future compatibility duties.
  Architecture and configuration docs describe the implemented APIs/boundaries.
  No save/load, batch, UI, ecology tuning, defaults or extra feature flags added.

## Acceptance evidence

`tests/run_cli.rs` executes the real Cargo-built binary without DISPLAY or
WAYLAND_DISPLAY. It compares results against direct shared-engine execution for
N0/1/7/99/100/250, default/K1/K3/K>N sampling, schema/timings/hash/species and
accounting; seed overrides cover negatives, zero, arbitrary large magnitudes,
modulo-equivalent seeds and sampling-independent final state. Effective defaults
and explicitly exported defaults hash identically. Empty1000, no-plants5000 and
natural plant extinction2200 cases verify exact ends and absorbing empty tails.
Malformed/duplicate/missing flag, invalid config, override validation, missing
parent, directory, symlink and FIFO cases verify status/stderr/stdout and absent
or sentinel-preserved output with no leftover temporary files. Existing config
suite covers complete leaf type/range validation.

`tests/test_entrypoints.py` builds host/musl via root entrypoints from an unrelated
cwd, runs ROOT/evosim twice with identical seed and spaced paths, compares all
JSON except timing, and does the same with dist. Copied dist runs N0 and N10 in
an otherwise empty chroot, checking schema/accounting; static ELF has no loader
or shared-library requirements. No external runtime/network/display is required.

Owner-local tests change every config leaf; RNG version/each word; weather
version/tick/offsets/settings; resource cells by one float bit; organism identity,
kind/species, x/y, age/vitals, each allele, ordered parents, generation/birth tick
and cooldown; allocation/sequence/counts/totals/all cause counts; death fields/
order; and species fields/founders/extinct history. Some fixtures intentionally
violate cross-record invariants to isolate encoding coverage, never production
behavior. They compare canonical bytes; known SHA vectors and independent Python
hashlib validate the digest layer. Primitive tests freeze widths, endianness,
UTF-8 lengths, option tags and exact negative-zero bits. Spatial rebuild preserves
bytes; unfinished birth/death transactions reject. Public state_hash replay runs
2200 ticks and proves hashing read-only, full-seed sensitivity and clone equality.

## Actual commands and outcomes

- `cargo check`: exit0, resolved sha2 0.10.9 and compiled host dependency graph.
- `cargo test --locked --lib > target/task019-initial.log 2>&1`: exit0,98 tests.
- First new sensitivity test compilation failed (exit101) because assert_ne's
  diagnostic treated stringify output as a format literal; fixed with an explicit
  `"{}"` argument. Corrected library invocation passed107 tests.
- Golden-fixture test initially failed (exit101) on a 15-byte header slice; corrected
  to16. Next invocation intentionally exposed the unfrozen digest (exit101).
  Independent Python hashlib agreed before freezing the hash in ADR/test.
- First targeted CLI invocation exit101: new no-plants fixture wrongly assumed
  no animal births. Initial reserves permit finite births; corrected to require
  ledger conservation, no births of absent plants and final empty tails. No
  ecological behavior was changed to satisfy the test.
- `cargo test --locked --test config --test cli --test run_cli --test state_hash > target/task019-targeted.log 2>&1`:
  exit0,16 tests (8 config,2 CLI,4 run,2 hash).
- `./test.sh > target/task019-full.log 2>&1`: exit0,194 tests
  (109 unit,76 integration,1 rustdoc,8 Python), none failed/skipped/ignored.
- `cargo test --locked --lib --test run_cli --test state_hash > target/task019-final-targeted.log 2>&1`:
  exit0,116 tests (110 unit,4 run,2 hash), after added sensitivity/natural extinction checks.
- Final full-suite/check/schema validator evidence is in implement-cycle1.json
  and docs/STATE.md. Logs under target are local ignored execution evidence;
  the test sources, commands, counts and outcomes survive in tracked handoffs.

## Dependencies, deviations and limitations

Only the approved sha2 dependency was added, default features disabled. Locked
new versions: sha2 0.10.9, digest 0.10.7, block-buffer 0.10.4, crypto-common 0.1.7,
generic-array 0.14.7, typenum 1.20.1, version_check 0.9.5, cfg-if 1.0.5,
cpufeatures 0.2.17, libc 0.2.191. No system package installed. Existing musl
prerequisite reinstall commands in STATE/setup.sh remain applicable. Python3,
mkfifo/coreutils and root chroot/readelf are inherited test prerequisites.

No product-scope deviation. Small implementation refinements: topology/genome/
Kind/DeathCause/RngState own their encoding, keeping canonical primitives std-only;
schema constant is shared through canonical rather than a reverse persistence
import. SHA collisions are theoretically possible; contract is interpreted as
complete canonical coverage with cryptographic collision resistance. Huge valid
worlds, samples and historical records may exhaust memory; fallible reservations
cannot convert an OS OOM kill into exit2. Atomic publication is not fsync-based
crash durability. Separate GNU/musl libm builds may differ in float hashes; required
determinism is within a machine/build. No fresh Ubuntu replacement or separate
minimum-Rust-version build was run. Checkpoint codec and balancing remain later
work. No known acceptance gap or blocker remains; harness owns review assignment.

## Reproducible final handoff validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-019/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-019/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-019','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual==set(h['changed_files']),(actual,set(h['changed_files']))
for f in actual: (r/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
assert not [f for f in actual if f.startswith('tasks/') and not f.startswith('tasks/TASK-019/handoffs/implement-cycle1.')]
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: handoff UTF-8/schema/inventory, protected scope, no remotes, whitespace')
```

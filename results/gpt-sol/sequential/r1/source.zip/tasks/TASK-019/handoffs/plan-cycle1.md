# TASK-019 PLAN cycle 1

Scope: planning only. Required AGENTS.md and STATE.md exist; initial Git tree
clean and no remotes. Read project/contract/state/architecture, task specification,
PLAN skill, dependency TASK-003 and TASK-018 phase handoffs, and current CLI,
configuration, simulation, population, species, organism, climate/resources and
entrypoint tests. Both dependencies REVIEW PASS with no gaps. No previous
TASK-019 handoff or review gap exists. Some bulk inspection output truncated;
source-specific reads established the interfaces and state inventory below.
ADR-001 already chooses SHA-256 and canonical bytes; ADR-015 refines that decision.
No feature changes, packages, commits or phase transitions in this session.

## Current findings

Rust library engine is complete through TASK-018. `Simulation::new(Config)` and
`advance_one_tick()` already advance through extinction. `Population::counts()`,
`totals()` and species registry views supply result values. CLI supports version,
help and climate export, with a testable writer-based dispatcher and status 2.
Config retains arbitrary signed integer seed text; Seed parsing is private and
there is no validated seed override method. Initial organisms do not draw RNG;
seed must still change hashes at tick zero through effective config/full RNG.
Only serde_json is currently a direct crate. Static musl and copied-empty-root
version tests exist; actual run packaging needs new evidence. Sampling, result
encoding and canonical hashing do not exist. Don't hash Debug strings, result
JSON, living population only or RNG only.

## Ordered implementation and files

1. Add SHA-256 crate `sha2` 0.10 with default features disabled in Cargo.toml;
   resolve Cargo.lock, record exact resolved versions and musl compatibility.
   No system installation is expected; inherited setup.sh reinstalls missing
   musl packages/target using commands already recorded in STATE.
2. Implement ADR-015 canonical writer in new private `src/canonical.rs` and
   owner-local `pub(crate) write_canonical(&self, writer)` methods in config,
   organism, population, species, resources, climate, temporal_climate, rng,
   simulation as needed. Parent owners call child owners; helpers import std
   only. A new public `src/persistence.rs` exposes
   `state_hash(&Simulation) -> Result<String, ...>` by streaming canonical bytes
   into a SHA-256 Write adapter. Expose persistence from lib.rs. This module
   implements hash only: no checkpoint read/write or save/load flags. No public
   mutable state or copied shadow engine. See ADR for exact field inventory.
3. Add `Config::with_seed(&self, Seed) -> Config` (clone and replace already
   validated seed) and `Seed::from_decimal(&str) -> Result<Seed, ConfigError>`.
   Accept `-?[0-9]+`, normalize leading zeroes and negative zero, reject plus,
   whitespace, fractional/exponent tokens. Reuse the same normalization in JSON
   parsing; JSON grammar still rejects leading zeroes. Preserve arbitrary
   magnitude and numeric result JSON. Config is loaded/validated BEFORE override:
   a missing/invalid required seed in input must not be hidden by --seed.
4. Add private run adapter `src/cli/run.rs` (or adjacent equivalent) and branch
   in src/cli.rs. Required flags exactly once: --config FILE --ticks N --out FILE.
   Optional exactly once: --seed INTEGER --sample-every K. Accept any order,
   separated values only. Reject positionals, duplicate/unknown options, absent
   values, --save/--load, negatives/fractions/exponents for N/K, zero K and u64
   overflow. N is u64 >=0; K is u64 >=1; use digits-only parsing. No additional
   feature flags this task; run --help may display usage if deliberately tested.
   Keep existing climate/version/help behavior and main's non-Unicode rejection.
5. Implement outer runner with observational result records (private to adapter,
   reusable extraction helpers if useful; no new engine metrics state required).
   Start sample at absolute tick0, advance once in a u64 range for exactly N,
   sample when tick%K==0, append final iff absent. Default K=max(1,N/100), integer
   floor; N0 gives exactly one tick0 sample. Avoid next-sample additions that
   overflow at u64::MAX. Never break for extinction. Collect counts in u128 and
   JSON integers without u64 casts: serde_json arbitrary_precision can represent
   totals beyond u64, using Number/from_str or supported u128 conversion.
   Use fallible vector capacity growth for series rather than unchecked capacity
   arithmetic proportional to N. No arbitrary tick/count ceiling.
6. Result has exactly required contract fields initially: contract1, effective
   numeric seed, tick_start0, tick_endN, dimensions, final counts and living
   species counts, cumulative births/deaths, series, lowercase 64-digit hash,
   elapsed_seconds and ticks_per_second. Add only `state_hash_schema:1` as a
   useful interpretation key. No batch summaries/genetic charts here. Time only
   calls to advance_one_tick using outer Instant measurements accumulated around
   each call; exclude initial construction, sampling, hashing, serialization and
   output. For N0 both timing values are 0; if measured duration is zero use
   TPS0; otherwise N/elapsed, ensuring finite JSON numbers. Timing is excluded
   from deterministic equality. Sampling never mutates/draws from engine.
7. Validate args/config, initialize and run, hash and serialize before publishing
   destination. Write complete JSON plus newline to exclusive temporary regular
   file in destination parent, flush/close, rename atomically to --out; clean up
   on every recoverable error. No parent auto-creation required by contract.
   Existing regular result may be replaced on success; preserve existing output
   on failure and leave absent output absent. Reject existing nonregular/symlink
   destinations (including /dev/full), so atomic rename cannot replace devices.
   Temporary naming uses create_new with bounded collision retries. Handle empty
   relative parent as '.'. No stdout on success, status2+stderr on every returned
   error. Do not remove an existing user's output to satisfy 'no result file'.
8. Add tests and docs described below; README gives a complete shell example
   creating a minimal fixed-key config under target and running ./evosim run
   --config ... --ticks 1000 --out ... --seed 42 --sample-every 10. Do not create
   scenarios/demo.json owned by a later task. Update STATE/ARCHITECTURE and
   canonical schema docs, record actual commands/results/deviations/dependencies.
   Write mandatory implementation handoffs; harness owns review/commits.

## Acceptance and test matrix

- Canonical tests in owner modules plus tests/state_hash.rs: SHA-256 empty/abc
  vectors against published fixed bytes, independently Python hashlib over a
  canonical fixture emitted by a test, fixed schema golden digest, cloned state
  unchanged by hashing, exact repeat replay, changed seed including modulo-2^64
  equivalent seeds, tick0/empty/populated/after-deaths-and-births states.
- Sensitivity tests change one field at a time using private cfg(test) fixtures:
  each config leaf, clock, each RNG word/version, weather tick/offsets/settings,
  each resource store including one-bit f64 differences, organism ID/kind/species/
  cell/age/energy/health/every genome locus/ordered parents/generation/birth tick/
  cooldown None vs Some(0), allocator None/value, request_sequence, each totals/
  cause-count field, death-record fields/order, every species record field and
  extinct history. Test serialized primitive widths/order/length delimiters and
  option tags; no public mutation API. Representable valid state mutations are
  preferred; encoding-only impossible states may test private owner encoders.
  Verify derived spatial bucket layout excluded and rebuilding index leaves hash
  unchanged; completed-tick pending lists must be empty and encode zero lengths.
  Any future authoritative field requires schema/test update. No finite digest
  mathematically guarantees no collision; SHA-256 is the conventional contract
  interpretation, with complete encoding rather than an impossible proof.
- tests/cli.rs or tests/run_cli.rs: run N0,1,7,250; K1,3,>N and default K for
  0/99/100/250; assert exact ascending expected tick arrays including final once.
  Check all JSON types/fields, finite timings, hash syntax, per-kind ledger and
  living species against direct library execution at the same N/seed. Compare
  requested seeds negative/huge/zero and input config retained under override.
- End-to-end Python tests/test_entrypoints.py: its setup builds fresh host/musl
  binaries, then invoke ROOT/evosim twice from unrelated cwd with spaced paths,
  DISPLAY/WAYLAND_DISPLAY absent. Compare every field except the two timings;
  compare same seed with different K for final/totals/hash. Different seed must
  change hash even at tick0. Compare valid config with explicit defaults vs
  omitted defaults. No network is used by runtime.
- Extinction: empty world N1000, no plants with animals N5000 and tiny natural
  extinction fixture: exact tick_end and full empty-tail sampling/ledger, no
  replenishment, zero births of absent kinds. Can use small grids to bound cost.
- Table-driven malformed CLI/config tests: all missing flags/values, duplicates,
  unknown, save/load/batch rejection, invalid integers, invalid config fixed-key
  types/ranges/missing/malformed/trailing JSON/unreadable path. Exercise output
  nonexistent parent, directory, symlink/special file, and injected writer/rename
  failure; assert status2, stderr nonempty, stdout empty, absent destination or
  unchanged sentinel, no leftover temporaries. Use permission denial via a
  controlled test/injected failure since root bypasses ordinary chmod. Keep
  fixtures within workspace. Never alter a device to test write failures.
- Extend copied dist empty-root test with minimal config+run N0 and N10, parsing
  result and ledger. Preserve static ELF/version tests. Compare repeatability
  within each build; GNU vs musl hashes need not agree because libm may differ.
  Existing assertion that bare `run` errors remains valid (required flags absent).
- Planned commands: `cargo test --locked --test config --test cli --test run_cli
  --test state_hash` (adapt target names to actual files), `./test.sh`,
  `cargo fmt --check`, `git diff --check`. Record tests actually present/executed.
  Full suite rebuilds host/musl and runs Python entrypoint/package checks.

## Risks and phase evidence

Largest correctness risk is forgetting private allocator/cause/history/cooldown
state; living organisms plus RNG is insufficient. Avoid broad pub(crate) fields
solely for hashing: owners encode their private fields. Config JSON is export,
not canonical encoding. Hash streaming is O(area+living+history) work with bounded
additional hash memory. Series is O(samples), lifetime history remains unbounded;
fallible reserves cannot prevent OS overcommit/OOM termination for enormous
representable requests. Document this existing resource limit; do not cap valid
normal inputs or pretend OOM kills return2. No long ecology tuning required.
Time budget: prioritize state inventory/tests, then CLI/errors, then real launcher
and dist tests; reserve final10 minutes for full suite and handoff. No checkpoints,
batch, UI, ecological equations/default changes or benchmark tools.

Actual PLAN baseline:
`env -u DISPLAY cargo test --locked --test cli --test config --test simulation`
exit0:14 tests (2 CLI,8 config,4 simulation),0 failed/ignored. This is existing
behavior only; new run/hash tests and full packaging were not executed here.
No packages installed. Final handoff validator command/result in JSON.

## Reproducible planning validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-019/handoffs/plan-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-019/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-019','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-015-canonical-state-and-run.md','tasks/TASK-019/handoffs/plan-cycle1.md','tasks/TASK-019/handoffs/plan-cycle1.json'}
assert actual==set(h['changed_files'])==expected,actual
for f in actual: (r/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected scope, no remotes, whitespace')
```

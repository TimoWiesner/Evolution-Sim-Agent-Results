# TASK-019 REVIEW cycle 1

Verdict: PASS. No acceptance gaps found. External harness checks remain authoritative.

Verified required files first. Read AGENTS, project/contract, state/architecture,
task/spec JSON, phase handoffs and dependency TASK-003/TASK-018 handoffs, relevant
ADR-001/004/015 and review skill. Inspected actual implementation diff
062f64d..6b5cfb7 and current source/test inventory. Initial tree clean, no remotes.
No product changes, packages, commits, task-state changes or phase transitions.

Acceptance evidence:
1. src/cli/run.rs implements required config/ticks/out and optional seed/sample
   flags, strict errors and all result fields plus state_hash_schema. Tests compare
   results with direct shared-engine execution and validate sampling and accounting.
   Config validation occurs before override. Full decimal seed precision is retained.
2. Rust process tests and real launcher/distribution tests remove DISPLAY and
   WAYLAND_DISPLAY. Copied static binary runs ticks 0 and 10 in an empty chroot.
3. Exact-N loop has no extinction exit. Tests cover N0/1/7/99/100/250, empty1000,
   no-plants5000 and naturally extinct plants2200 with absorbing empty tails.
4. Argument/config/output failure tests verify status2, stderr, empty stdout,
   absent result or preserved preexisting file. Same-parent exclusive temporary
   publication and injected write/rename failures verify cleanup and preservation.
5. Compared owner struct fields with canonical encoders. Full effective settings,
   tick, RNG, topology/climate/weather/resources, all organism DNA/vitals/lineage/
   cooldowns, allocator/sequence/counters/cause totals/death records and all species
   history are encoded with explicit lengths/tags/bit patterns/stable ordering.
   Only derived cache/area/phenotypes and outer observations are excluded. Pending
   transactions reject hashing. SHA vectors, independent hashlib, golden fixture,
   field sensitivity and read-only 2200-tick replay tests pass. No state omission found.
6. Python test invokes ./evosim twice with identical seed and compares all fields
   except the two nondeterministic timings; same checks run on dist. README gives
   a complete example. Different seeds and sampling independence are also tested.

Executed verification:
- ./test.sh > /workspace/target/task019-review-full.log 2>&1 : exit0,
  195 passed (110 Rust unit, 76 integration, 1 rustdoc, 8 Python); none failed,
  ignored or skipped. Includes host/musl setup/build, static ELF and empty-root run.
- cargo fmt --check and git diff --check : exit0.
- Inline Python launcher probe : exit0, 12 real headless runs across empty1x1 N0,
  populated1x7 N137, no-plants7x1 N2500 and fixed-key contract64x48 N1000.
  Each runs seeds42/42/43; verified exact end/sample ticks, accounting, repeated
  deterministic equality excluding timing and different-seed hash inequality.
- Log count validator : exit0, 187 Rust tests plus8 Python confirmed.

Architecture/ADRs remain accurate; no design amendment required. Review changes
only STATE and these handoffs. Retained limitations: finite SHA-256 collision
resistance, resource exhaustion for extreme valid sizes/histories, no fsync crash
 durability, cross-build floating differences and no separate fresh-container or
minimum-Rust validation. These are documented limitations, not acceptance gaps.
Checkpoint flags, batch and UI remain outside this task. Future TASK-022 must
preserve the full canonical inventory, especially cooldown and extinct history.
Harness owns completion, commits and subsequent assignment.

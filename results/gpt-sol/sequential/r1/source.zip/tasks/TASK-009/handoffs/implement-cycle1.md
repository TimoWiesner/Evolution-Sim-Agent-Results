# TASK-009 IMPLEMENT cycle 1

Implemented the approved genetics plan; no phase transition or commit performed.
Required AGENTS.md and STATE.md existed before reads. Read project/contract,
state/architecture, task/spec, plan handoffs, dependency TASK-001/008 handoffs,
relevant ADR-001/004/007 and IMPLEMENT skill. Dependency reviews PASS with no
gaps. Some bulk output truncated; bounded source/plan follow-ups supplied context.
Initial tree clean, no Git remotes. No system dependencies or packages added.
Protected files/task state/benchmark tools untouched.

## Result and decisions

- New traits.rs extracts the unchanged validated phenotype API. organism re-exports
  it to preserve imports. Genome depends on config/rng/traits; organism depends
  on genome/traits/topology. No dependency cycle or new package.
- Genome is private fixed [u16;12], Copy/Eq, schema 1; names/count/version constants,
  read-only array, deterministic exact-endpoint linear/floored mapping and metric.
  All organisms own DNA, derive Traits without an independent cache, and expose
  DNA read-only. Initial DNA [32768;12] draws nothing, keeps IDs/placement/lifespan
  1100; continuous traits are quantized rather than old exact midpoint values.
- One-parent copies and nonempty one-boundary/orientation two-parent crossover
  mutate with existing validated config. Mutation visits ordered loci, exact
  per-million chance then uniform signed nonzero step; clamping may erase a step.
  Rate zero draws nothing except the two crossover draws; rate one skips chances.
- Population requests no longer accept arbitrary traits or DNA. Validate parents,
  capacity/generation/basic vitals before genetics; normalize position. Sorted
  parent genomes drive inheritance using a clone of the current supplied engine
  RNG, then reject health above the derived child maximum without publishing
  RNG/state changes. Success captures DNA and lineage before parental death.
  Commit installs exactly that DNA without draws; newborns first act next tick.
- Simulation wrapper passes effective config and its sole RNG, no reseeding.
  Existing private lifecycle tests use a deterministic per-call helper for their
  unrelated event fixtures; new engine-stream and captured-DNA tests retain a
  continuous RNG and explicitly compare it. Production reproduction decisions,
  species, mating gates, CLI and persistence remain outside this task.

No plan deviation or known acceptance gap. docs/GENETICS.md gives complete model,
API and future persistence obligations. STATE/ARCHITECTURE/ADR-004/config docs
reflect current implementation. No old lifecycle assertion was removed; health
expectations changed to quantized DNA mapping and Injury fixture uses lethal
finite magnitude to preserve its meaning.

## Acceptance evidence

| Criterion | Executed evidence |
|---|---|
| Every organism DNA, deterministic bounded phenotype | Public initial mixed-kind records check genome and independently calculated health; private committed child fixtures check DNA/derived traits; exhaustive all-65536 allele sweep checks every trait's independent formula, bounds, monotonicity, endpoints; one-locus fixtures check order/independence |
| One-parent and two-parent inheritance | Zero-rate copy equals parent without draws; 1000 seeds exercise every nonempty split and both orientations; patterned parents verify corresponding parental alleles; independent frozen crossover/mutation vector and final RNG words |
| Configurable mutation and engine generator | Existing configuration boundary/default/round-trip tests retained; rates 0/10000/321987/1000000 and strengths 1/1024/65535 checked against independent raw-draw rejection/step reference with exact final RNG and restored replay; engine fixture interleaves weather's two draws then births for all kinds |
| No mutation => parental material; positive differences | Zero-rate copy/crossover checks; 2000 default-rate offspring show differences; full-rate strength-1 interior alleles all move exactly one; extreme boundary tests observe both clamp/no-clamp signs |
| Genetic distance | Exact identity/symmetry/maximum 786420 and normalized 1; increasing known displacement; 1000 generated triples check independently summed distances, triangle inequality and bounds |

Lifecycle coverage retains parent death, ascending walker/liveness, next-tick
newborn action, generation/ID exhaustion, birth ordering, conservation and
four-seed 2200-tick runs. Invalid parents, vitals, exhausted allocator and generation
errors check population and RNG rollback. A specific rejection after mutation
uses low-health parental DNA and legal global requested health above the child's
maximum, proving staged draws do not leak. Accepted mutated births for all kinds
retain DNA after parental death; engine replay and observations preserve state.

## Actual commands

- Required-file check before reads: exit 0.
- `cargo fmt`: exit 0 after edits.
- `cargo test --locked --lib --test organism --test lifecycle --test simulation`:
  first exit 101, test helper unnecessarily borrowed an already mutable reference;
  corrected that call. Second invocation exit 0, 21 tests. No runtime failures.
- `cargo test --locked --test genome`: exit 0, initial four public genetics tests.
- `cargo test --locked --lib`: exit 0, 16 tests after integration additions.
- `./test.sh`: exit 0, 68 tests, no failures/skips: 16 unit, 44 integration,
  1 rustdoc, 7 Python. Includes setup twice, host/musl builds and climate exports,
  static ELF and copied-distribution version in empty root. No product code changed
  after this run. A fifth genetics test with frozen Python reference was added.
- `env -u DISPLAY cargo test --locked --test genome --test organism --test lifecycle --test simulation`:
  exit 0, 13 final tests, including the newly added frozen test. Thus 69 unique
  tests pass across the full suite plus this subsequent targeted run.
- `cargo fmt --check` and `git diff --check`: exit 0 after final source/docs edits.
- Final Python handoff/scope validator below: exit 0.

No throughput/coexistence/checkpoint/fresh-container or separate Rust 1.85 claim.
Uniform founders intentionally lack diversity until reproductive mutation occurs.
O(12) trait queries, BTreeMap and lifetime death history remain unprofiled.
Future checkpoint/hash must include schema/all alleles, effective settings and
complete RNG/lifecycle/climate state. Harness assigns REVIEW and commits.

## Independent frozen-vector provenance

The Python integer reference seeded SplitMix64 with 42, using wrapping 64-bit
addition/multiplication and the ADR-001 constants, then xoshiro256** raw draws.
For `a[i]=1000*i`, `b[i]=60000-1000*i`, rate 321987 and strength 1024:
rejection-sampled boundary is 1, orientation 0; final child is
`[0,59613,58000,56111,56000,55000,54000,53000,52000,51974,50918,49000]`.
Final words are `[5726367031845654541,3662791717741399644,
17042498262953750018,5049584178551681873]`. The Python calculation exited 0;
frozen Rust assertions agree. The broader public test also independently computes
sampling via raw `next_u64` rejection rather than calling chance/below.

## Final validator

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-009/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-009','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
 assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git','-C',str(root),*a],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual==set(h['changed_files']) and len(actual)==15, actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact fifteen paths, protected files, no remotes, formatting, whitespace')
```

# TASK-009 PLAN cycle 1

Documentation-only plan; implementation has not started. Required AGENTS.md and
STATE.md existed on entry. Project/contract, architecture, task/spec JSON, PLAN
skill, dependency TASK-001/TASK-008 handoffs and ADR-001/004/007 were inspected.
Both dependency reviews PASS with no gaps. No previous TASK-009 handoffs or
review gaps exist. Initial tree clean, no Git remotes. No packages installed.
Historical 61-test TASK-008 result is inherited evidence, not a test run here.

## Decisions and exact algorithms

Retain ADR-004 schema v1: private Genome([u16;12]), Copy/Eq, named schema/locus
constants, public from_alleles([u16;12]), alleles() read-only, founder(), traits(),
copy_child(settings,&mut Rng), crossover_child(other,settings,&mut Rng),
mutated(settings,&mut Rng), distance_sum(other)->u32 and distance(other)->f64.
The fixed array encodes length/domain validity; no fallible wire format yet.
Settings are the existing validated GeneticsConfig, borrowed rather than copied
into another editable settings type. No new dependencies or config fields.

All twelve locus names/order/ranges are exactly ADR-004. Continuous traits use
low + (high-low)*(f64::from(allele)/65535.0); handle allele endpoints explicitly
to return exact documented bounds. Discrete speed, lifespan and vision use
low + (u32::from(allele)*span)/65535 with integer division, then safe narrowing.
Map through validated Traits::new so invalid phenotype cannot enter a record.
No phenotype inversion: most old continuous founder values cannot be represented
exactly by this allele domain. Genome::founder() is [32768;12] for all kinds;
no RNG draw, initial variation or mutation. This keeps seed/weather initialization
and row-major placement unchanged. Lifespan remains 1100; max health becomes
10+90*(32768/65535), rather than exactly 55. No biological diversity claim.
Ecology may later deliberately refine initial variation with documented draws.

Copy all alleles for one-parent inheritance. Two-parent crossover first samples
boundary=1+rng.below(11), then orientation=rng.below(2); orientation 0 takes
prefix from self and suffix from other, orientation 1 reverses sources. Both
segments nonempty, even if parental values coincide. Mutate after inheritance,
index 0 through 11. Per locus use chance(mutation_per_million,1000000). Selected
loci sample z=below(2*M), M=mutation_max_step: z<M maps to z-M (-M..-1), otherwise
z-M+1 (1..M). Calculate in i32 and clamp to [0,65535]. Rate 0 draws nothing for
copy/mutation; crossover still draws boundary and orientation. Rate 1000000
skips probability draws by existing chance semantics but draws each step.
Boundary clamping may produce unchanged selected alleles. Never force novelty.

Distance S=sum of twelve unsigned absolute differences fits u32 (max 786420).
Normalized D=S/786420 is observational. S is the exact primary metric for future
rational comparisons; no species or mating-compatibility gate in this task.
It measures total allele displacement, not simply the number of changed loci;
no claim of strict growth with changed-locus count independent of magnitude.

## Ordered implementation and file interfaces

1. Extract TraitValues, Traits, TraitError, getters and existing validation into
   new src/traits.rs. Re-export them from src/organism.rs to preserve existing
   public imports. src/genome.rs depends on traits, config and rng; organism
   depends on genome, traits and topology. Export modules in src/lib.rs. This
   explicitly supersedes ADR-007's suggested genome-to-organism import: once
   organisms store Genome, that suggestion would create a module cycle.
   Keep Traits::founder() as a legacy validated phenotype convenience for tests
   and external source compatibility; organisms never use it for initialization.
2. Add src/genome.rs value API and algorithms above with rustdoc explaining
   versions, draw order, endpoints, clamping and distance. Genome::traits is pure.
   Add genome to Organism and genome() read-only. Remove authoritative cached
   traits field; traits() derives from genome. Update lifecycle/vital code to
   call traits() instead of direct fields. DNA stays immutable during life.
   This prevents inconsistent genome/phenotype construction and duplication.
3. Population::initialize installs Genome::founder() on every initial record;
   full health derives from its genome. Preserve IDs, initial counts and no-draw
   initialization. BirthRequest stops accepting arbitrary Traits (or caller DNA).
   queue_birth(request,&GeneticsConfig,&mut Rng) validates parents, kind/arity,
   generations, capacity, position and basic vitals before genetics. Sort parent
   IDs first; use their captured genomes in that order. Plants copy, animals
   crossover. Stage mutation using a temporary clone of the supplied RNG, derive
   child traits, validate health against child max health, then accept pending
   child genome and publish advanced RNG only on success. This is transactional
   use of the same engine stream, not a second independent source. Invalid
   requests leave RNG, queues, counters and allocator unchanged. Do not clamp
   invalid requested health silently. PendingBirth captures child DNA at acceptance
   so later parent death cannot affect it; Commit stores that exact DNA with
   age zero and captured lineage, without further genetics draws.
4. In src/simulation.rs add a crate-private queue_birth(request) wrapper passing
   self.config.genetics() and &mut self.rng to Population, for future ecology and
   controlled real-engine fixtures. No production reproduction caller or new
   public spawn method. Migrate existing private fixtures to this path, preserving
   lifecycle ordering/ID/accounting assertions. Controlled nonfounder genomes
   may be installed only in private fixture construction. Replace tests that
   directly overwrite traits with controlled genomes, not mutable trait caches.
5. Add tests/genome.rs public acceptance tests; expand private population and
   simulation fixtures and tests/lifecycle.rs. Existing tests/organism.rs continue
   testing standalone trait validation/re-exports. Replace hardcoded founder
   organism traits/health expectations with independently calculated allele
   mapping, preserving exact lifespan, accounting and newborn-timing checks.
   Update documentation: docs/GENETICS.md for API/semantics, CONFIGURATION.md
   noting genetics settings now consumed on accepted birth requests, architecture,
   ADR evidence and STATE. No CLI, checkpoint, species or ecology feature work.
6. Run targeted tests, then full regression/packaging and formatting. Fix failures,
   record exact evidence and implementation handoffs. Harness owns all transitions,
   task state and commits. Do not start IMPLEMENT in this phase.

## Acceptance and regression matrix

| Requirement | Planned executable evidence |
|---|---|
| Every organism DNA and deterministic bounded traits | Mixed-kind initial population plus committed one/two-parent children: genome getter, all twelve independently computed values equal traits(), health bounded, no legacy traits constructor path. Endpoints all-zero/all-MAX; independently sweep every allele 0..65535 in uniform genomes to check finiteness/ranges/monotonicity; one-locus fixtures verify order/no cross-locus effects and discrete floors. Repeat pure mapping without changing RNG. |
| Copy and crossover | Rate-zero clone equals parent and RNG unchanged; contrasting patterned parents produce exactly one switch, nonempty segments and only corresponding parental alleles across many seeds, both orientations and all boundaries observed. Fixed-seed frozen child and final RNG state checked against an independent draw reference. Parents unchanged. |
| Configurable mutation/simulation RNG | Existing config default/zero/max/invalid/round-trip tests retained. Mutation rate 0, intermediate and 1; strength 1, default and 65535; replay from identical RngState equals child and end state. Independent integer loop predicts draw order/results. Controlled engine birth fixture interleaves weather then genetics and compares exact engine RNG state to manual reference. Empty biological ticks still draw nothing. |
| Zero-rate parental material; positive-rate differences | At rate zero copy/crossover checks above. At positive default rate generate 2000 children of interior-valued parents and assert at least one change, with fixed seeds. Rate 1 and strength 1 on interior genome changes every locus by exactly one. Boundary mutation covers both signs/clamps; tests do not require every selected locus to change at limits. |
| Distance | Identical=>0; symmetry; all-zero vs all-MAX=>S=786420,D=1; increasing known displacements yield increasing S/D, one-locus unit gives S=1; deterministic generated triples check triangle inequality and normalized bounds. Tests use independent integer expected values. |
| Lifecycle integration | Children preserve DNA/lineage through parent death before commit; newborn traits derive from captured DNA and act next tick. Invalid parents, exhausted IDs, generation overflow and child-vital rejection leave entire population/RNG unchanged. Rate-zero integration and mutated births for all kinds. Same-seed repeated controlled births identical; observations cannot draw. Preserve death/conservation and four-seed 2200-tick tests. |

Planned commands (not executed in PLAN):
- `env -u DISPLAY cargo test --locked --test genome --test organism --test lifecycle --test simulation`
- `cargo test --locked --lib`
- `./test.sh` (all Rust/rustdoc plus Python, host/musl/static distribution)
- `cargo fmt --check` and `git diff --check`.
No benchmark throughput, coexistence, checkpoint or fresh-container claim.

## Risks and follow-up

Uniform founders intentionally lack initial diversity; mutations supply variation
once owning ecology tasks reproduce. Continuous founder values shift slightly;
update only invalid exact-55 assumptions, never weaken lifecycle tests. Derived
traits cost O(12) per query, acceptable until measured; later caching must preserve
DNA consistency. Transactional RNG clone is fixed four-word cost and must not
reseed; rejection tests guard rollback. Internal birth fixture changes are broad
because traits inputs are replaced; keep original lineage/death/ID coverage.
Full checkpoint/hash later must encode schema version and all alleles and reject
inconsistent redundant trait data if any; effective config already stores mutation
settings. No on-disk persistence in TASK-009. Species remains TASK-017 and actual
reproduction rules TASK-012/016. No prior review remediation or blockers.

## Planning validation

The final validator below is executed in PLAN; it checks planning artifacts only.

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-009/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-009','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
 assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual==set(h['changed_files']) and len(actual)==5, actual
assert all(p.endswith(('.md','.json')) for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(r),'diff','--check'],check=True)
print('PASS: UTF-8/schema, five documentation paths, protected files, no remotes, whitespace')
```

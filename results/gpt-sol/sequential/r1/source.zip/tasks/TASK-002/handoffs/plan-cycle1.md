# TASK-002 PLAN cycle 1

## Findings and scope

Required workspace files verified; read AGENTS, PROJECT, CONTRACT, STATE,
ARCHITECTURE, TASK-002 specifications, plan skill, all TASK-001 handoffs and
ADR-001..004 plus index. TASK-001 review passed without gaps. No TASK-002
handoffs exist, and downstream TASK-003/TASK-004 have no handoffs. Initial tree
clean; no Git remotes. Only documentation exists; no Cargo manifest or tests.
This phase creates planning documents only. Harness owns transitions and commits.

Environment: rustc/cargo 1.100.0, only x86_64-unknown-linux-gnu installed.
`rustup`, `readelf`, `chroot` available; `musl-gcc` absent. No packages installed.
Inventory concatenation returned exit 1 because TASK-002/handoffs did not yet
exist; all dependency handoffs were subsequently read without truncation.

## Decisions and interfaces

Follow ADR-001: Cargo package named `evosim`, version `0.1.0`, edition 2024,
`src/lib.rs` exporting `cli`, thin `src/main.rs` mapping dispatcher result to
process exit status. No empty ecology modules or speculative engine API needed.
Use std-only argument dispatch initially: dependency-free bootstrap is sufficient
for version/help and avoids a parser framework before run/batch/ui are owned.
Version JSON has name `Evolution Simulation`, version from Cargo metadata,
contract integer 1; stdout contains exactly one JSON object and newline.
Only `version`, `--help`, `-h` are available; help lists version and help.
Explicitly document future run/batch/ui as unavailable, without claiming support.
No arguments, unknown commands/options and surplus version/help arguments return
2 with stderr diagnostic. Help/version succeed with 0. Keep dispatch testable via
an argument slice and output/error writers; main owns environment/process access.

Use Cargo built-in unit/integration tests plus Python stdlib unittest for shell
entry-point and packaging acceptance. `./test.sh` is the single documented whole
suite command: Cargo tests with --locked, then Python unittest discovery. No pip,
npm, browser or display dependency in bootstrap. Tests must propagate failures.

Use static x86_64-unknown-linux-musl release executable for dist immediately,
refining ADR-001's packaging choice rather than postponing portability. Copy the
binary, not a launcher pointing into target/ or a Cargo-dependent wrapper. Static
linking avoids bundling glibc, loader and language runtimes. Retain Cargo.lock.
Do not pin to this future-dated container toolchain without a need; document Rust
edition/minimum requirement and use available compatible Rust via rustup.

## Ordered implementation plan (future assigned IMPLEMENT only)

1. Add Cargo.toml, Cargo.lock, src/lib.rs, src/cli.rs, src/main.rs. Implement only
   command dispatch above. Put process contract integration tests in tests/cli.rs
   using Cargo's built executable path and std::process::Command; test real JSON
   stdout via Python acceptance tests (avoid a JSON crate solely for bootstrap).
2. Add executable setup.sh, evosim, build.sh, test.sh with robust script-directory
   discovery, quoted paths, fail-fast status propagation and arbitrary caller cwd.
   - setup: check Rust/Cargo/rustup; use provided toolchain, diagnose unsupported
     environments clearly. Benchmark includes Rust. If musl-gcc missing, run
     `apt-get update` then `apt-get install -y --no-install-recommends musl-tools`.
     Ensure target with `rustup target add x86_64-unknown-linux-musl` when absent.
     Build locked host release and static release; setup twice must succeed.
     Record actual installs, exact commands and any additional dependencies in
     STATE. Fresh phases must reinstall missing system packages.
   - evosim: exec the prebuilt host release binary with all arguments; no network,
     Cargo invocation or rebuild at runtime. Before setup, clear stderr failure.
   - build: build locked static release, create dist/, copy to dist/evosim with
     executable permission. Scope cleanup to generated artifact, never broad rm.
     Must work after setup and from other cwd; network permitted only at build/setup.
   - test: enter repository root, run `cargo test --locked`, then
     `python3 -m unittest discover -s tests -p 'test_*.py'`; any failure nonzero.
3. Add tests/test_entrypoints.py: subprocess helper with timeouts, temporary
   directories beneath /workspace, isolated caller cwd, no DISPLAY dependency.
   Run setup twice and build once per suite fixture; assert executable files,
   version schema/metadata agreement, exact stdout/no stderr on success, help,
   unknown command status 2/stderr, missing args and surplus args. Exercise both
   workspace launcher and dist binary. Do not invoke test.sh recursively.
   Verify `readelf -lW dist/evosim` has no INTERP and `readelf -dW` no NEEDED.
   Copy dist into an otherwise empty temporary root under /workspace and execute
   `chroot <root> /evosim version` with sanitized environment and no display.
   Root is guaranteed here; on non-root developer machines explain skip reason,
   while release verification in this benchmark must actually execute it as root.
   This demonstrates version needs neither runtime, shared libs nor project files;
   full run portability remains a future owning-task obligation. No Docker needed.
4. Add .gitignore for /target/, /dist/, Python bytecode/cache and explicit temporary
   test outputs if any. Do not ignore Cargo.lock. Test with git check-ignore.
   Write README.md with setup/version/build/test commands, prerequisites,
   noninteractive/idempotent setup, network only at setup/build, offline runtime,
   supported scope, self-contained dist copy procedure and no simulation claims.
5. Update architecture's opening status and actual bootstrap paths, preserving
   all future engine decisions/boundaries. Update STATE with observed environment,
   install commands, measured checks and limitations. No new ADR required unless
   implementation changes the existing static packaging/runtime decision.
6. Run acceptance commands below, inspect protected-file/scope diff, write exact
   evidence and any deviations in implement-cycle1.md and required JSON handoff.
   Do not change task state, protected instructions or commit.

## Acceptance evidence to collect

All commands below are planned, NOT executed in PLAN:

- `./setup.sh` twice (status 0 each), then `./evosim version`: parse one JSON
  object with string name/version and contract integer 1; test from a different
  cwd with absolute launcher path too. Current container is not a new container:
  report clean-artifact rebuild separately from true fresh-container evidence.
- `./build.sh`, `dist/evosim version`, ELF checks and copied-root chroot version.
  Run from outside project cwd. Only existing system setup prerequisites may be
  assumed; copied dist execution must not find project files or installed runtimes.
- `./evosim --help` status 0 lists available commands; unknown command status 2,
  diagnostic stderr. Verify dist has same behavior. No fake run/batch/ui stubs.
- `./test.sh` status 0 with nonzero test count, unit and subprocess checks recorded.
- `git check-ignore target/probe dist/evosim tests/__pycache__/probe.pyc` status 0;
  Cargo.lock tracked/not ignored. Inspect README installation/build/test instructions.
- `git diff --check`; verify no protected-file changes or Git remotes; UTF-8
  handoff schema validation. No claims of simulator or packaging run support.

## Risks and implementation guidance

Musl Rust target retrieval may be unavailable for container's unusual toolchain;
record failures honestly and select a supported compatible toolchain if needed,
documenting exact command/version rather than silently shipping dynamic output.
System package retrieval and target download require network during setup.
Keep install/build/test time within phase budget; bootstrap has no crates and
should compile quickly. chroot checks Linux binary isolation, not a complete
fresh Ubuntu provisioning test. Use ELF inspection and repeated clean-artifact
setup as complementary evidence, and state environment limitations honestly.
Adding dependencies later requires rechecking static linkage and distribution.
No engine, timing, throughput, coexistence or UI result is claimed here.
No review gaps, blockers or interactive questions exist.

## PLAN validation (executed, exit 0)

Run from /workspace: `python3` with the following source. This checks planning
scope/schema only; no product tests exist. `git diff --check` also exited 0.

```python
from pathlib import Path
import json, subprocess
h = json.loads(Path('tasks/TASK-002/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required = {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-002','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'], str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k], list)
for t in h['tests']:
    assert isinstance(t['command'], str) and type(t['exit_code']) is int
    assert isinstance(t['notes'], str)
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(h['changed_files']), actual
assert len(actual) == 4
assert all(Path(p).is_file() for p in actual)
assert all(p in ('docs/STATE.md','docs/ARCHITECTURE.md') or p.startswith('tasks/TASK-002/handoffs/plan-cycle1.') for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/TASK-002/task.md','tasks/TASK-002/task.json')
subprocess.run(['git','diff','--check'], check=True)
print('PASS: handoff schema, four documentation-only paths, protected files, no remotes, whitespace')
```

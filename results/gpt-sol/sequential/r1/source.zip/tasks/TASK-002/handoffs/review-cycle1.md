# TASK-002 REVIEW cycle 1

Verdict: PASS. Independently inspected implementation commit range
`a6c31cc..ecf9888`, actual scripts/code/tests, README, TASK-002 plan and implement
handoffs, all TASK-001 dependency handoffs and four ADRs. Read the current review
skill. No downstream TASK-003/TASK-004 handoffs exist. Initial tree clean, no Git
remotes. No product changes or dependency installations made during review.

Acceptance evidence:
- All three required root entry points are tracked mode 100755. Scripts resolve
  their own location, propagate failures and run non-interactively. setup checks
  supplied Rust tools, installs missing musl prerequisites/target, then builds
  locked host and musl releases. Runtime launcher invokes no build/network tool.
- Version emits exactly one JSON object with name, package version and integer
  contract 1, no stderr. Verified both workspace and distribution binaries.
- build creates a static dist/evosim. ELF tests find no INTERP/NEEDED; copied
  executable runs version in an otherwise empty chroot, actually executed as root.
- Help lists version and help; unknown/missing/surplus arguments return 2 with
  stderr and empty stdout. Non-Unicode arguments also return 2 for both binaries.
- README documents install, build, complete test command ./test.sh and supported
  scope. Eight tests pass: 1 Rust unit, 1 Rust integration, 6 Python acceptance;
  zero skipped. Git ignore tests cover target, dist and Python cache, while
  Cargo.lock is retained. Layout/test/packaging decisions are documented.
- No run/batch/ui implementation or simulation behaviour required by this task.

Commands and actual results:
1. `./test.sh && cargo fmt --check && git diff --check`: exit 0; eight tests pass.
2. `cargo clean && ./setup.sh && ./test.sh && cargo fmt --check && git diff --check a6c31cc..HEAD`:
   exit 0; clean removed 247 files/37 MiB, both releases rebuilt, eight tests pass
   again. Suite runs setup twice and build from unrelated cwd and checks chroot.
3. Inline Python subprocess/scope probes: exit 0. Compared committed implementation
   paths to implement JSON changed_files; protected files unchanged across full
   TASK-002 range; no remotes. For /workspace/evosim and dist/evosim, invoked with
   raw byte argument 0xff and asserted status 2, empty stdout, Unicode diagnostic.
   Created temporary symlink named 'workspace link' under target/'review space *',
   invoked setup.sh, build.sh and evosim version through it from unrelated cwd;
   all status 0 and version parsed. Temporary probe directory cleaned afterward.
4. Final review handoff/schema/scope/whitespace validator: command below, exit 0.

An initial bulk read command exited 1 because tests/* included the __pycache__
directory; output was also truncated. Relevant documents were reread in bounded
calls. This is an inspection-command failure, not a product failure.

Fresh Ubuntu provisioning was not rerun in a separate container. Prior actual
musl installation is recorded by implementation; independent clean builds,
setup idempotence, script inspection and empty-root execution provide the current
bootstrap evidence. No claim of full simulator portability is made. Future
engine/dependency changes must extend distribution checks to run and preserve
static linking. No actionable acceptance gaps found. External checks remain
authoritative; harness owns commits, task state and phase transitions.

# TASK-005 IMPLEMENT cycle 1

Implemented the approved plan with no scope deviations. Required workspace files
were verified first. Read project/contract/state/architecture, task and plan,
current implement skill, all four ADRs and dependency TASK-003/004 plan,
implementation and review handoffs. Dependency reviews PASS with no gaps.
Initial tree clean, no remotes. No direct-dependent TASK-006/008/022 handoffs
exist. Bulk inspection was occasionally truncated; bounded reads covered relevant
context. No system packages or Cargo dependencies added, no protected files,
manual commits or orchestration changes. Setup found existing musl prerequisites.
Exact reinstall commands remain in STATE.

## Implementation and acceptance evidence

- State ownership/exact advancement: src/simulation.rs owns validated Config,
  geometry-only World, clock and one seeded RNG. Tests cover minimal JSON, 1x1,
  non-square, zero/nonzero counts and all presets, exact config/geometry/RNG,
  tick 0 and 129 individual increments. Internal maximum-clock test succeeds
  from MAX-1 then rejects overflow with complete state unchanged.
- All randomness: src/rng.rs implements accepted xoshiro256** and SplitMix64,
  private words, signed-seed modulo-u64 conversion and no alternate source.
  Known literals for seeds 0/42/-1 and raw [1,2,3,4] test transitions/expansion.
  Source review: imports only Config/Seed, Topology, RNG and std error/fmt;
  no time, UI, CLI, browser, network, global RNG or thread dependency. Cargo
  graph remains existing serde_json and its dependencies. Simulation exposes
  only a read-only RNG state and seeds once. Full original seed stays in Config.
- Fixed scheduling/ties: one explicit seven-element TICK_PHASES array drives
  match dispatch and records each phase after execution. Public tests compare
  reports to a separately written literal sequence. ordered_actor_ids sorts
  and deduplicates snapshot IDs; internal fixtures exercise permutations,
  duplicates, empty inputs and extremes. ADR/rustdoc require living snapshots,
  liveness rechecks, immediate effects, next-tick newborn actions, distance/ID
  target ties, species-ID ties and phase/parent-ID commit order. Actual actor
  storage and lifecycle tests are deferred to TASK-008, per approved plan.
- Restoration: version-1 four-word RngState is a public value record, not a disk
  schema. Tests reject 0/2/MAX versions and zero words, accept raw boundary
  states, restore tick-zero and after 37 draws, then compare 1024 iterations of
  raw/bounded/ratio draws and final state. Observations consume no draws.
- Replay: public tests collect reports, world geometry and RNG state for 128
  ticks; seeds 42/42 equal, 42/43 differ. Empty stages draw nothing. Separate
  128-draw traces verify stochastic stream replay and difference; huge positive
  and negative modulo-equivalent seeds match intended streams.
- Headless separation: targeted tests run with DISPLAY unset; imports/graph
  reviewed. Existing full packaging/headless regression passes. Accessor/report
  mutation tests show read-only observation and discarded/mutated reports cannot
  influence future engine state.

Sampling tests cover bound zero unchanged, one consuming exactly one draw, bounds
2/3/powers of two/2^63+1/MAX, 256 samples each against a u128 threshold reference.
A raw state with s1=0 forces a rejected zero before an accepted draw for bound 3;
state equality checks consumption. Invalid probabilities, deterministic endpoints,
interior and maximum-denominator ratios have explicit consumption assertions.

## Executed commands

- `cargo fmt`: exit 0.
- `env -u DISPLAY cargo test --locked --test rng --test simulation`: first exit
  101, unmatched escaped brace in tests/simulation.rs JSON format fixture.
  Corrected fixture, formatted and reran identical command: exit 0, 8 tests.
- `./test.sh`: exit 0; 34 tests, none skipped: 3 unit + 1 CLI + 8 config +
  5 RNG + 3 simulation + 7 topology + 1 rustdoc + 6 Python. Python packaging
  tests include setup twice, host/musl rebuild, build, ELF no INTERP/NEEDED and
  actual copied version execution in an otherwise empty chroot.
- `cargo tree --locked`: exit 0; dependency graph unchanged.
- `cargo fmt --check` and `git diff --check`: exit 0.
- Final validator below: exit 0; exact ten implementation paths, required UTF-8
  JSON types, protected integrity, no remotes, formatting and whitespace.

No product code changed after successful tests. Biology, initial organism
materialization, climate/resources, full checkpoint/hash/CLI/UI and throughput
remain outside this task. Actor fixtures do not prove lifecycle behavior. No
fresh-container or separate Rust 1.85 execution; current environment and static
version regression pass. No blockers or known acceptance gaps. Harness assigns
review/commits/transitions; this process does not start another phase.

## Independent vector derivation

Executed before tests were frozen; reproducible with Python 3. It uses arbitrary
precision integers plus masks and explicit shift/or rotation, independent of Rust
wrapping operations. Output is embedded literally in tests/rng.rs.

```python
mask = 2**64 - 1
for seed in [0, 42, -1]:
    x = seed & mask
    s = []
    for _ in range(4):
        x = (x + 0x9e3779b97f4a7c15) & mask
        z = x
        z = ((z ^ (z >> 30)) * 0xbf58476d1ce4e5b9) & mask
        z = ((z ^ (z >> 27)) * 0x94d049bb133111eb) & mask
        s.append(z ^ (z >> 31))
    print(seed, 'state', s)
    out = []
    for _ in range(4):
        v = (s[1] * 5) & mask
        out.append(((((v << 7) | (v >> 57)) & mask) * 9) & mask)
        a, b, c, d = s
        t = (b << 17) & mask
        c ^= a
        d ^= b
        b ^= c
        a ^= d
        c ^= t
        d = ((d << 45) | (d >> 19)) & mask
        s = [a, b, c, d]
    print('output', out)
```

## Final validator

Run: `python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-005/handoffs/implement-cycle1.md").read_text().split("\n<!-- validator -->\n",1)[1].split(chr(96)*3+"python\n")[1].split(chr(96)*3)[0])'`

<!-- validator -->
```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-005/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-005','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
expected = {'src/lib.rs','src/rng.rs','src/simulation.rs','tests/rng.rs','tests/simulation.rs','docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-001-core-runtime.md','tasks/TASK-005/handoffs/implement-cycle1.md','tasks/TASK-005/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact ten paths, protected files, no remotes, formatting, whitespace')
```

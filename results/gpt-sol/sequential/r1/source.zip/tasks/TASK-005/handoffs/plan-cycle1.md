# TASK-005 PLAN cycle 1

## Entry findings and scope

Required AGENTS.md and STATE.md existence verified first. Read project, contract,
state, architecture, TASK-005 specifications, plan skill, ADRs, existing prior
TASK-001..004 handoffs and dependency source/test infrastructure. Some bulk tool
output was truncated; bounded follow-ups covered dependency plans, implementation
and review evidence and relevant ADRs. TASK-003 and TASK-004 reviews PASS with no
gaps. No TASK-005 handoffs or handoffs for direct dependents TASK-006, TASK-008,
TASK-022 exist. Their task specifications were consulted for boundary needs.
Initial Git tree clean; no remotes. No prior TASK-005 review gaps or blockers.

This phase is documentation only. Implement the library frame in the next assigned
IMPLEMENT phase, not here. No actual climate, organisms, ecology, raster, spatial
index, CLI run/batch/ui, metrics, hash or checkpoint file format belongs here.
No packages or dependencies need adding. Existing setup reinstalls missing musl
prerequisites; exact installation commands remain in STATE. Do not modify task
specifications, orchestration state, protected instructions or commit history.

## Decisions and interfaces

### Randomness: src/rng.rs

Implement the exact ADR-001 xoshiro256** transition and SplitMix64 expansion using
wrapping u64 arithmetic and rotate_left. This choice is already accepted; do not
substitute a crate-default generator. Benefits: four portable words, O(1) draw,
no new dependency, exact restorable behavior. Alternatives remain a runtime RNG
(unstable algorithm/state API) or a larger generator (unnecessary state/complexity).
It is a simulation PRNG, with no cryptographic promise.

Public `Rng::from_seed(&Seed) -> Rng` expands Seed::wrapping_u64(), retaining the
full original seed in Simulation's Config. Four sequential SplitMix64 outputs
form s0..s3; apply the ADR fallback s0=1 only if expansion is all zero. A standalone
Rng is permitted for tests/tools; a running Simulation owns exactly one mutable
instance, passed by mutable reference to later stochastic subsystems. No global,
thread-local, wall-clock or UI source supplies randomness.

`RngState` is a value record with public `version: u32` and `words: [u64; 4]`,
deriving Clone, Copy, Debug, Eq, PartialEq. Version 1 identifies both algorithm
and state word ordering. `Rng::state(&self) -> RngState` is read-only;
`Rng::from_state(RngState) -> Result<Rng, RngError>` rejects unsupported versions
and all-zero words without repairing or reseeding them. This record is the exact
export/restore boundary; disk serialization belongs to TASK-022. No serde change
is needed. Private Rng words prevent unchecked mutation; derive Clone/Debug/Eq.

`next_u64(&mut self) -> u64` returns ADR-001 output before transition.
`below(&mut self, bound: u64) -> Result<u64, RngError>` rejects zero without a draw;
threshold = bound.wrapping_neg() % bound, reject draws below threshold, return
accepted draw % bound. Bound 1 still consumes one draw. Support u64::MAX.
`chance(&mut self, numerator: u64, denominator: u64) -> Result<bool, RngError>`
requires denominator>0 and numerator<=denominator, errors without a draw;
0/denominator and denominator/denominator return false/true without a draw;
otherwise use below(denominator)<numerator. Explicit draw semantics aid replay.
Do not use floats, modulo-only biased sampling or a statistical test as proof
of correctness. RngError implements Display/Error with typed invalid-state,
invalid-bound and invalid-ratio cases.

Seeds differing by a multiple of 2^64 intentionally have identical PRNG streams
per ADR-001 and existing Seed API, although full configuration values differ.
The acceptance differing-seed test uses 42 and 43, not modulo-equivalent seeds.
No arbitrary-integer seed algorithm change is proposed.

### State and scheduler: src/simulation.rs

`World` initially owns a private `Topology`, with `topology(&self) -> Topology`.
This is the actual finite grid-world geometry; avoid an area-sized empty raster
or fake climate data. Place World in simulation.rs for now, adding a separate
module only when real world data warrants it. Future climate/resources attach to
World while organisms are introduced by their owning task. Initial population
counts are retained in Config but not materialized as placeholder organisms.
Document this scaffold limitation explicitly even for nonzero initial counts.

`Simulation` owns private `config: Config`, `world: World`, `tick: u64`, `rng: Rng`.
`Simulation::new(config: Config) -> Result<Simulation, SimulationError>` constructs
Topology from the validated dimensions, seeds the RNG once and starts tick 0.
Expose `config(&self) -> &Config`, `world(&self) -> &World`, `tick(&self) -> u64`,
and `rng_state(&self) -> RngState`. No mutable RNG accessor or arbitrary state
setter is required on Simulation. Clone/Debug/PartialEq support tests; equality
is not a canonical state hash. Reading any accessor consumes no draws.

`advance_one_tick(&mut self) -> Result<TickReport, SimulationError>` is the only
public advancement function. Check tick.checked_add(1) before any mutation;
at u64::MAX return TickOverflow with no changes. On success increment once,
then execute these fixed stages serially:

1. Clock (the checked increment).
2. ClimateResources (future row-major update).
3. Plants.
4. Herbivores.
5. Carnivores.
6. Reproduction.
7. Commit (births, death accounting, species extinction in that order later).

Represent these as `TickPhase` variants and a single explicit ordered constant
array. Dispatch through a match to private phase methods; currently biological
methods are documented no-ops. No parallel dispatch, plugin/event bus, dynamic
closure registry or wall-clock scheduler. `TickReport` contains the resulting
absolute tick and a fixed array of completed TickPhase values, appended/filled
as dispatch actually executes, rather than fabricated independently afterward.
It is returned by value, not retained as an unbounded authoritative event log.
No RNG draw merely to animate an empty tick. A completed step consumes zero draws
until a genuine stochastic subsystem is introduced by a later task. Reports and
read-only observations do not change future state. No lifecycle event variants
are invented without lifecycle data; later tasks can extend reports separately.

Stable organism scheduling follows ADR-001: at entry to each action phase capture
living IDs, sort ascending, and recheck liveness before each action. Newborns only
enter at Commit and first act next tick. Movement/resource use/deactivation is
immediately visible; reproduction reserves costs immediately. Candidate priority
is (toroidal distance, stable ID); species ties use species ID; birth commit order
follows phase and ascending parent IDs. No collection storage order is authoritative.

To make the presently applicable ordering rule executable without inventing
organisms, add a small crate-private `ordered_actor_ids` helper accepting an
iterator of u64 IDs and returning a sorted, deduplicated Vec<u64>. Unit-test it
with scrambled fixture IDs, duplicates and extreme values. Document that its
input must already be the living snapshot; actual liveness/death/birth timing
requires TASK-008 integration tests once real lifecycle records exist. Do not
claim fixture IDs constitute an organism model. Later action phases must reuse
this helper or preserve its exact semantics when their real storage is added.
The helper need not be public; avoid promising an unused general framework.

SimulationError implements Display/Error with topology-construction failure and
TickOverflow. No user-triggered panic or silent tick wrapping. Only constructor
and tick-overflow errors are possible in this frame; later fallible phases must
specify transactional semantics before extending it.

## Ordered implementation steps (next assigned phase only)

1. Add src/rng.rs, exports in src/lib.rs, exact transitions/state validation and
   integer sampling. Add tests/rng.rs and private unit tests as needed for forced
   rejection paths; confirm fixed known vectors before building scheduler on it.
2. Add src/simulation.rs with World, state, error, phase/report types, checked
   advancement and sorted-ID helper. No config/schema, CLI, Cargo or UI changes.
   Export simulation in src/lib.rs. Rustdoc explains frame-only initial counts,
   empty biological stages, full seed retention and pure observations.
3. Add tests/simulation.rs public integration coverage and internal boundary/order
   tests. Use built-in Rust tests; test.sh already discovers new integration files.
4. Update ADR-001 with implemented API/state/draw semantics, docs/ARCHITECTURE.md
   with actual World/scheduler ownership and scope, and docs/STATE.md with exact
   commands/counts/dependencies/limits. No README CLI additions are necessary.
5. Run targeted tests, full regression and static packaging tests, formatting and
   whitespace checks. Inspect core imports for forbidden UI/CLI/time/global RNG
   dependencies and verify changed/protected paths and absent remotes. Persist
   all results/deviations in implement-cycle1.md and required JSON. Do not commit
   or start review yourself.

## Acceptance/test matrix for IMPLEMENT and REVIEW

All tests here are planned, not executed in this PLAN.

| Requirement | Concrete evidence |
|---|---|
| State owns clock/RNG/world and steps exactly once | Construct from minimal JSON and presets; assert tick 0, exact Topology dimensions and Config, RNG seeded from Config; call 1 then 128 steps and assert each resulting absolute tick. Test 1x1, non-square and zero populations; nonzero counts remain configuration until TASK-008. Private test sets tick=u64::MAX-1, succeeds once then overflow leaves complete state unchanged. |
| Only seeded randomness | Fixed expansion/output vectors for seed 0, 42, -1 and raw state [1,2,3,4]; independently calculated expected literals, not production code computing expected results. Existing Seed tests plus modulo-equivalent seed stream tests cover negative/large integers. Source review finds no time/thread/global RNG in core; new modules import only std value/error utilities, config/topology/rng. |
| Fixed stages and actor/tie rule | Every TickReport equals literal seven-phase expected sequence, no duplicate/skipped phase. Unit-test helper sorted unique output for multiple permutations and extremes. Rustdoc/ADR explicitly prescribe per-phase living snapshot, immediate deactivation, next-tick newborns and distance/ID ties. Actual organism action/tie/lifecycle tests deferred to owners, not simulated biology in this task. |
| Exact RNG export/restore | Draw e.g. 37 values, export, restore, assert next 1024 raw and mixed below/chance outputs and end state identical; also restore tick-zero state and raw nonzero word boundaries. Reject version 0/2 and all-zero state; accepted raw [1,2,3,4] has first outputs 11520, 0, 1509978240. Repeated state() does not advance. |
| >=100-tick identical/different seed traces | Run 128 ticks for seeds 42, 42, 43; collect (absolute tick, actual phases, world dimensions, rng_state) each tick. Two 42 traces equal and 43 differs; tick components change even though empty biological stages intentionally consume no randomness. Separately run same/different seeded RNG draw traces over >=128 draws. This proves frame replay and stochastic stream replay without a dummy engine draw. |
| No UI dependency | Review module imports and Cargo graph; run targeted tests with DISPLAY unset; full existing packaging/headless tests remain green. Core must not import cli/ui_server or use browser assets, network, wall clock or rendering. |

Additional RNG edge coverage: bound 0 errors without mutation; bounds 1, 2, 3,
powers of two, 2^63+1 and u64::MAX; outputs in range; exact draw consumption.
Force a rejection with a valid exported state whose s1=0 (first raw output 0)
and bound=3 (threshold=1), compare accepted result and final state with a manual
raw-draw reference. Test denominator zero, numerator>denominator (unchanged RNG),
0/d and d/d (no draw), and interior ratios. Use finite deterministic tables and
u128 threshold/reference arithmetic, not flaky distribution tolerances. Known
vectors may be independently computed with a tiny test-reference integer model
and frozen as literals; no external website or dependency is necessary.

Planned commands:
- `env -u DISPLAY cargo test --locked --test rng --test simulation`
- `./test.sh` (all Rust tests/rustdoc plus Python packaging; setup twice/build,
  static ELF and copied-empty-root version test inherited).
- `cargo fmt --check` and `git diff --check`.

No throughput, ecology, CLI run or complete checkpoint equivalence is claimed.
Full checkpoint/hash schemas remain TASK-022 and their other owning tasks.
The exported RNG version is a component schema, not a prematurely frozen full
simulation checkpoint format. Frame advancement is O(1); future actor sorting
is O(n log n) time/O(n) memory, with deterministic bias accepted by ADR-001.

## PLAN evidence, risks and next handoff

No application tests run: feature code is unchanged. Verified required files,
repository inventory, clean initial tree/no remotes and dependency PASS evidence.
Final documentation scope/schema/protected-file/no-remotes/whitespace validator
below must pass. No dependencies or system packages installed. Performance and
Rust 1.85/fresh-container execution remain unmeasured as before. Principal risks
are wrong wrapping arithmetic, malformed RNG state, undocumented draw consumption,
clock overflow and accidentally introducing dummy draws or fake biology. Exact
vectors, raw-state boundary tests, checked clock and explicitly empty stages
address them. New real subsystems will legitimately change frame traces and must
preserve seeded replay rather than treat empty-stage traces as final game output.
No blockers, prior review gaps, new phase, or manual Git changes.

Reproduce final planning validation from /workspace with:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-005/handoffs/plan-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-005/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-005','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-001-core-runtime.md','tasks/TASK-005/handoffs/plan-cycle1.md','tasks/TASK-005/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(root),'diff','--check'],check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

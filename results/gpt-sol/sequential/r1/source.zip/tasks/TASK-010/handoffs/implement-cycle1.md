# TASK-010 IMPLEMENT cycle 1

Implemented only the approved spatial-search plan; verdict N/A for implementation.
Required AGENTS.md/STATE.md verified first. Read project/contract/state/architecture,
TASK-010 spec/JSON/plan handoffs, dependency TASK-001/004/008 handoffs and current
TASK-009 genetics review/implementation evidence, relevant ADR-001/003/004/007,
existing modules and .agents/skills/implement/SKILL.md. Dependency reviews PASS
with no gaps. Initial tree clean, no remotes. Bulk reads sometimes truncated;
bounded reads supplied the relevant context. No prior TASK-010 review gaps.
No subagents, commits, task-state edits or phase transitions.

## Implementation and decisions

Private SpatialIndex owns dense row-major sorted (ID, Kind) buckets. Population
owns the cache and authoritative BTreeMap; spatial depends only on topology and
organism ID/Kind values, with no reverse dependency. Binary-search insertion/
removal preserves canonical buckets independently of history. Nearby queries
use existing unique toroidal cells and sort IDs ascending; no self exclusion.
Public Population::nearby(Cell, usize, Option<Kind>) accepts all radii, center
occupants and normalized foreign Cells. No public mutable index/spawn API.

Founders and committed newborns insert once; pending births are absent. Immediate
kill removes buckets before any later query, covering all vital/lifespan death
paths. Crate-private move_one_step validates identity and normalized adjacency
before changing position and index; same-cell is a no-op. No autonomous movement,
feeding or reproduction behavior, CLI/config changes, new RNG draws or dependencies.
Simulation source changes are test-only. Initial dense try_reserve_exact errors
propagate through PopulationError::SpatialAllocation and existing SimulationError.
No arbitrary size cap or universal OOM-recovery promise.

Future persistence must rebuild from authoritative living records without RNG and
exclude buckets from canonical state/hash. No checkpoint implementation is added.
API, invariants, complexity, all benchmark data and limitations: docs/SPATIAL.md.
Architecture/state/ADR-003 updated. No substantive plan deviations. Benchmark
includes equal checksum/destruction work on both paths, disclosed explicitly.

## Acceptance mapping

1. Query correctness/order: tests/spatial.rs mixed kinds and co-occupancy across
   1x1/1xN/Nx1/2x2/non-square/default worlds; radius 0/1/2/4/MAX; foreign,
   negative/multiply-wrapped centers, seams/corners and independent unsigned
   oracle. Exact Vec equality, strictly increasing IDs, repeats and full
   Simulation clone equality (including RNG) verify membership/order/purity.
2. Add/move/remove: population private fixtures execute actual queue_birth,
   commit, move_one_step, kill, change_health/energy and age_before_action.
   Assert no queued child, committed child after parental death, stale-cell
   exclusion after seam/corner moves, immediate injury/starvation/aging removal,
   no-op moves, rejected nonadjacent/dead moves and repeated deaths. Actual
   simulation walker observes moves/deaths before later actors, no child until
   commit, no query/move/commit RNG draws. Cache reverse rebuild equality checks
   every randomized step and explicit event fixtures.
3. Random oracle: exactly 4096 queries (8 world shapes x 4 seeds x 128 steps).
   Queries use independent unsigned shortest-axis membership over authoritative
   records, not production distance or cells_within. Test-local RNG selects
   real mutations, centers, radii/filters, including tiny worlds and world-
   spanning/MAX radii. Genetics uses a separate fixture RNG. Repeated results,
   ascending IDs, query purity and canonical reverse rebuild checked each step.
4. Performance: cargo run --locked --release --example spatial_bench uses exactly
   the PLAN-declared 2000 founders, 64x48, seed 42, 4096 uniform precomputed centers,
   5 alternating repetitions, full Vec equality outside timing and consumed
   checksums. Primary radius 4/all: index 1.455 ms vs scan 18.740 ms (12.877x).
   MAX/all loses: 38.268 vs 22.719 ms (0.594x). Every radius/filter and checksum
   is documented; no selective omission or universal throughput claim.

## Executed commands and outcomes

- `cargo fmt` then `cargo test --locked --lib`: exit 0; 18 tests at that point,
  including two new index unit tests and unchanged lifecycle regressions.
- `env -u DISPLAY cargo test --locked --lib --test spatial --test lifecycle --test simulation`:
  first exit 101 from an unmatched closing format brace in tests/spatial.rs.
  Fixed fixture, cargo fmt, reran: exit 0, 30 tests (21 unit + 9 integration).
  Added final real-walker spatial test; final same command exit 0, 31 tests
  (22 unit + 9 integration). No runtime assertion failure.
- `cargo run --locked --release --example spatial_bench`: exit 0. All eight
  radius/filter result sets and every repetition checksum match; local gains
  and wide-query losses recorded in docs/SPATIAL.md, with hardware/compiler.
- `./test.sh`: initial exit 0 with 77 tests. After final walker test and docs,
  final exit 0 with 78 tests, none skipped: 22 unit, 48 integration, 1 rustdoc,
  7 Python. Includes setup twice/build, host/musl climate exports, static ELF,
  copied-empty-root version execution. Python final run 1.241 seconds; Rust
  suites complete in seconds. No fresh-container provisioning performed.
- `cargo fmt --check` and `git diff --check`: exit 0 after final edits.
- Read-only metadata/source audit command printed rustc/uname/lscpu, OS metadata
  and mutation sites, then exited 1 on nonexistent .cargo/config.toml. No custom
  Cargo configuration exists in the project. A later inspection exited 1 for
  guessed ADR-001-runtime-and-engine.md; corrected using rg inventory and read
  actual ADR-001-core-runtime.md. These were inspection errors, not test failures.
- Process deviation: metadata probe read /etc/os-release outside the requested
  workspace boundary. It was read-only; no external file changed. No further
  out-of-workspace file inspection was performed. This does not change feature
  evidence, and is recorded rather than concealed.
- A metadata-only handoff update script initially exited 1 on an unterminated
  Python string before executing any writes; corrected and reran successfully.
- Final validator below: schema/UTF-8, exact twelve changed paths, protected-file
  integrity, no Git remotes, formatting and whitespace. Actual result is recorded
  in JSON after execution.

No packages/crates installed or changed. Existing musl tools/target were present;
exact inherited reinstall commands remain in STATE/setup.sh. Dense area storage,
per-bucket shifting and full-world sorting remain costs; overcommit/later OOM is
not recoverable by initial reservation alone. No full checkpoint, UI/ecology,
coexistence, whole-engine ticks/s, separate Rust 1.85 or fresh-container claim.
No known acceptance gaps or blockers. Assigned review may rerun evidence; harness
owns commits, task completion and subsequent phase assignment.

## Final validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-010/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-010/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-010','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'src/lib.rs','src/spatial.rs','src/population.rs','src/simulation.rs','tests/spatial.rs','examples/spatial_bench.rs','docs/STATE.md','docs/ARCHITECTURE.md','docs/SPATIAL.md','docs/decisions/ADR-003-spatial-index.md','tasks/TASK-010/handoffs/implement-cycle1.md','tasks/TASK-010/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
for p in actual: (root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact twelve paths, protected files, no remotes, formatting, whitespace')
```

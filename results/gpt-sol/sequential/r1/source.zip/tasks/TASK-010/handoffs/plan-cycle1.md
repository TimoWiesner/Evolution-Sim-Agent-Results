# TASK-010 PLAN cycle 1

## Entry and scope

Required AGENTS.md and STATE.md verified first. Read project, contract, state,
architecture, task/spec JSON and PLAN skill. Applied the workspace PLAN skill
`.agents/skills/plan/SKILL.md`. Inspected dependency TASK-001/004/008 phase
handoffs, prior handoff JSON summaries, current TASK-009 genetics implementation/
review, ADR-001/003/007 and actual topology/population/simulation sources.
Dependency reviews PASS without gaps; no earlier TASK-010 handoffs or review gaps.
Initial working tree clean; no remotes. Some bulk inspection output truncated;
bounded follow-ups supplied relevant interfaces, decisions and dependency evidence.
No feature edits, application tests, benchmark runs or dependency installs in PLAN.

Current Topology already implements unique inclusive toroidal Chebyshev radius
cells, even half-axis ties and foreign Cell normalization. Population owns all
living records in a BTreeMap; initialize and commit insert, kill removes, and
vital/age deaths funnel through kill. It currently has no movement primitive.
Genomes are now authoritative; preserve genetics draw/rollback semantics. No
production search behavior, movement decisions or reproduction belongs here.

## Chosen representation and interface

Retain ADR-003 dense buckets. Add crate-private `spatial` module in src/lib.rs
and `src/spatial.rs`. `SpatialIndex` owns Topology and a row-major
`Vec<Vec<Occupant>>`; Occupant is private `{id: OrganismId, kind: Kind}`.
Population owns the index beside its authoritative living map, rather than World
or Simulation maintaining a second mutation path. This requires population ->
spatial -> organism/topology only, with no dependency back to Population.
Kind metadata avoids a BTreeMap lookup for every candidate. Position/liveness
remain authoritative in organisms. Index consumes no RNG and has no wall clock.

Buckets stay sorted by ID using binary-search insertion/removal. This yields a
canonical representation independent of insertion/movement history, preserving
existing derived Clone/PartialEq behavior and allowing exact rebuild comparisons.
No reverse ID map is necessary: Population already knows the old cell/kind.
Internal insertion requires a globally unique living ID; population allocator and
single-owner integration enforce this, rather than scanning all buckets on insert.
No public raw index mutations, public arbitrary ID constructor or spawn interface.

Planned APIs (names may be adapted consistently with these semantics):

- `SpatialIndex::new(topology: Topology) -> Result<Self, SpatialError>`: checked
  bucket storage capacity and `try_reserve_exact(area)` before `resize_with`.
  SpatialError identifies unrepresentable/allocation-failed dense storage with
  Display/Error. Map to a Copy/Eq-friendly `PopulationError::SpatialAllocation`
  variant, already propagated by SimulationError::Population. Fail construction
  without a partial Simulation; don't add arbitrary world size policy limits.
- crate-private `insert(id, kind, cell)`, `remove(id, cell)`,
  `relocate(id, kind, old_cell, new_cell)` for trusted population callers.
  Normalize Cell inputs before row-major addressing. Same-cell relocation is a
  no-op. Missing remove can return false; contradictory duplicate insert is an
  internal invariant violation, not a new user-facing population operation.
- `query(center: Cell, radius: usize, kind: Option<Kind>) -> Vec<OrganismId>`:
  enumerate Topology::cells_within, append matching occupants, sort ascending ID.
  Include center, accept radius zero and usize::MAX, normalize foreign cells;
  every living occupant once, even where multiple organisms share a cell.
- Public `Population::nearby(center, radius, kind) -> Vec<OrganismId>` delegates
  to query. Return IDs rather than borrowed organism records so later behavior
  can recheck liveness through get(id) after mutations. No implicit exclusion of
  the querying organism. Future behavior owns self exclusion/distance-then-ID
  target ranking. No redundant Simulation wrapper is needed: population() exists.
- crate-private `Population::move_one_step(id, destination: Cell)
  -> Result<(), PopulationError>` normalizes destination, rejects missing/dead
  IDs and distance >1 before mutation (`NonAdjacentMove` error). Same-cell is
  an accepted no-op, useful for degenerate axes. Valid moves change position and
  index immediately without changing counts, age, DNA, vitals or RNG. This is a
  mutation primitive only; ecology later selects destinations and pays costs.
  No public teleport/movement CLI and no changes to production action hooks.

Query complexity O(visited unique cells + candidates + matches log matches),
O(matches) output storage, O(area + living) index storage. Bucket updates include
O(bucket occupancy) element shifting; an intentionally crowded cell is expensive.
Whole-world queries can be slower than a direct scan. No universal speed or engine
100 ticks/s claim. Dense allocation can exceed RAM even at representable sizes;
fallible initial bucket reservation handles reported allocation failures, but
Linux overcommit and later per-bucket/population allocations retain existing
process-OOM limitations. Do not promise universal memory-failure recovery.

## Ordered implementation work (only when assigned IMPLEMENT)

1. Implement private spatial types, fallible dense constructor, normalized bucket
   addressing, sorted mutation primitives and query. Add module declaration and
   private unit fixtures for raw index insertion/removal/relocation, canonical
   rebuilding and allocation-capacity failure (no intentionally huge allocation).
2. Add private index field to Population, initialize before founders and insert
   each founder. Integrate remove in kill before returning; all current injury,
   starvation and aging paths thereby update immediately, before Commit. Insert
   newborns only at Commit with assigned ID and captured kind/cell, never on
   queue acceptance. Preserve current genetics transactional RNG/lineage handling.
   Add nearby and move_one_step. Audit every living.insert/remove and position
   assignment so no production write bypasses index upkeep. Existing crate-private
   organism fields are an internal discipline obligation; no mutable public escape.
3. Add tests/spatial.rs for public query API and initialization/aging death.
   Add private population fixtures for actual move/kill/commit integration and
   deterministic random event sequences; tests may access internal IDs and birth
   primitives, but must exercise production mutation code. Extend existing private
   simulation walker test if useful to prove later actors observe moves/deaths and
   queries see no queued newborn until Commit. Recheck counts/genomes/RNG unchanged
   by query/movement, exact clones, and error atomicity. No fabricated feature
   output or production biology behavior.
4. Add reproducible std-only release benchmark `examples/spatial_bench.rs` using
   public Simulation/Population/Topology APIs. See protocol below. Add no crates,
   system dependencies, external benchmarking framework or CLI command.
5. Run targeted correctness, release measurement, full ./test.sh, formatting and
   whitespace checks; fix actual failures and record every relevant attempt.
   If local index performance fails the requirement, profile and improve query
   implementation within ADR-003; never change correctness, hide unfavorable
   radii or claim an unmeasured gain. Reserve handoff time within phase limit.
6. Create docs/SPATIAL.md with API/invariants and actual benchmark table/hardware/
   commands; update ADR-003, STATE and ARCHITECTURE to distinguish implemented
   index from planned behavior. Write implementation Markdown and mandatory JSON.
   No task-state edits, commits or phase transitions; harness owns them.

## Acceptance evidence to implement

| Must have | Executable evidence |
|---|---|
| All nearby organisms; optional kind; seams/no duplicates | Explicit mixed-kind/co-occupancy worlds; all/each-kind filters; radius 0/1, exact boundary inclusion, corners and both seams; empty world, 1x1/1xN/Nx1/2x2/non-square, negative/multiply-wrapped centers via topology.cell and foreign-world cells; usize::MAX returns each matching ID once |
| Add/move/remove correctness | Actual founders indexed; controlled accepted births absent before Commit, indexed once afterward; parent death after acceptance; moving one step across each seam/corner removes old radius-zero membership and adds destination membership; same-cell no-op; repeated move/remove; immediate injury/starvation/old-age death; rejected nonadjacent/dead moves leave complete population unchanged |
| Deterministic order | Assert strictly ascending IDs, repeat exact Vec equality, insertion-history/rebuild equality for same living records, co-located occupants, clones and query purity/RNG checks |
| >=1000 random queries vs brute force | At least 4096 explicit query comparisons, independent unsigned toroidal distance oracle, seeded reproducible harness; include tiny worlds and huge radii, all kind filters, multiple seeds and interleaved valid insert/move/remove events. Assert total comparison count >=4096, membership/order/uniqueness after each operation; compare actual Population::nearby as well as raw index fixtures |
| Faster at about 2000 organisms, numbers documented | Release benchmark protocol below; actual timings, ratio, checksums, parameters and hardware recorded in docs/SPATIAL.md and implementation handoff |

Brute-force correctness oracle scans authoritative living records and computes
axis difference from normalized coordinates independently as min(abs_diff,size-
abs_diff); max of two axes <= radius. Do not call cells_within, index helpers or
production distance to decide oracle membership. Sort expected IDs. Seeded test
RNG is local to the harness, not Simulation's RNG; e.g. existing Rng with fixed
Seed values, no new randomness dependency. Random population fixtures may use
private lifecycle primitives; index-only synthetic occupants must not substitute
for tests of Population synchronization. Verify rebuild from living records in
ID order equals current canonical index, no RNG consumed. No persistence format
or load command is added; future checkpoints rebuild this derived cache.

Planned correctness/regression commands (not run in PLAN):
- `env -u DISPLAY cargo test --locked --lib --test spatial --test lifecycle --test simulation`
- `cargo run --locked --release --example spatial_bench`
- `./test.sh`
- `cargo fmt --check` and `git diff --check`.

## Benchmark protocol

Use 64x48 with exactly 2000 founders (1400 plants, 500 herbivores, 100 carnivores),
seed 42, existing deterministic row-major placement, no engine ticks in timing.
Use a fixed precomputed list of at least 4096 uniformly distributed centers.
Report radius 1, 4, 8 and usize::MAX, with None and a kind filter (Herbivore).
Declare radius 4, unfiltered, as primary local comparison before measurement.
Both implementations return allocated ascending ID Vecs and the same checksums;
brute force iterates the actual BTreeMap records, applies a documented unsigned
shortest-distance predicate and identical kind filter (already ID ordered).
Use public nearby for indexed timing; do not benchmark a different hidden query.
Validate complete result equality outside timed loops, then use black_box on
inputs/results and a consumed result checksum to prevent optimization. Time
query work including allocation/sorting, exclude construction/input generation,
validation and printing for both. Warm up each path; use five bounded repetitions
with alternating path order and report median total ns/ms and ns/query, speedup
brute/index, matches/checksum. Use std::time::Instant only in the example adapter,
never in core. Report CPU model, architecture, OS, rustc version, release flags,
world/population/layout/radii/filters/query count/repeats alongside timings.
Record unfavorable full-world numbers and limits as well as local wins. Timing
is not a noisy unit-test assertion; recorded reproducible local gain fulfills the
criterion. If no local gain appears, treat as unresolved implementation work,
not a passing measurement. Do not tune or silently cherry-pick worlds/seeds after
seeing results. Bound benchmark to seconds or a few minutes, never long ecology
runs in this task. Future clustered/distributed fixtures can supplement, not
replace, the declared primary comparison.

## Risks and phase limits

Dense storage adds area-dependent allocation where topology/climate were lazy.
Try-reserve/capacity errors require an initialization error; representable enormous
worlds may still exceed actual RAM. Bucket shifting costs rise with crowding;
query sorting/allocation can dominate wide radii. Kind metadata must update with
all lifecycle mutations (kind is immutable). Index must remain derived and
excluded from future canonical checkpoint/hash; rebuild without RNG. Movement
primitive must not introduce actual behavioral costs or actions prematurely.
No blockers or prior REVIEW gaps. No packages installed; inherited setup.sh and
exact musl prerequisite reinstall commands in STATE remain applicable. No new
runtime/system dependency planned. Measurements and feature tests are deferred
to assigned IMPLEMENT, and none are claimed here.

## Planning validation

Execute this Python block from /workspace; it validates planning artifacts only.

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-010/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-010','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-003-spatial-index.md','tasks/TASK-010/handoffs/plan-cycle1.md','tasks/TASK-010/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
for p in actual: (root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(root),'diff','--check'],check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

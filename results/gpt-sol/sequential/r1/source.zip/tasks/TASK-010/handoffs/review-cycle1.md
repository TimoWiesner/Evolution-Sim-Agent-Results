# TASK-010 REVIEW cycle 1

Verdict: PASS. All five acceptance criteria met; no actionable gaps.
External harness checks remain authoritative.

Verified AGENTS.md and docs/STATE.md exist first. Read project/contract/state/
architecture, TASK-010 specification and phase handoffs, dependency architecture,
topology and lifecycle handoffs, relevant ADRs and current review skill. Inspected
committed implementation range 589f34f..2717ac9, actual source, public/private tests,
benchmark and spatial documentation. Initial tree clean; no Git remotes. No product
changes, packages installed, commits, task-state edits or phase transitions.

## Acceptance evidence

1. Query correctness: public founders_filters_seams_order_and_observation_purity
   compares exact ID vectors against an independent unsigned-distance oracle for
   every kind filter, co-occupancy, seams/corners, normalized foreign centers,
   radii 0/1/2/4/MAX and tiny/non-square/default worlds. Empty populations and
   immediate old-age removals are covered. Topology tests independently exhaust
   small-world unique wrapped radius enumeration.
2. Mutation synchronization: audited every production living.insert/remove and
   position assignment. Founders and committed newborns insert once; kill removes
   immediately; move_one_step normalizes and validates adjacency before updating
   buckets and position. Private tests exercise actual birth/commit, movement,
   injury/starvation/aging deaths, same-cell and rejected moves. Seam moves assert
   old-cell exclusion. Pending births remain invisible; accepted births survive
   parental death. Real walker observes changes before later actions.
3. Determinism: buckets stay sorted by ID and query sorts globally. Tests assert
   strict ascending order, repeat equality, clone/query purity and canonical reverse
   rebuild equality, including interleaved lifecycle mutations. No new RNG draws.
4. Randomized oracle: randomized_4096_queries_with_real_lifecycle_events_and_rebuilds
   executes exactly 4096 comparisons (8 shapes x 4 seeds x 128 steps), including
   1x1/1xN/Nx1, usize::MAX and radii exceeding world dimensions. Oracle scans living
   records and computes unsigned toroidal distances without production radius or
   distance helpers. Actual population mutations and reverse rebuild checks run.
5. Performance: independently reran the predeclared release benchmark at 2000
   founders, 64x48, 4096 centers, five alternating repetitions. Complete vectors
   match outside timing; checksums and match counts agree on every repetition.
   Radius-4 all-kind median: 1.761 ms index / 22.979 ms scan = 13.048x.
   Implementation measurement and complete method/hardware are in docs/SPATIAL.md.
   Full-world loss is disclosed and reproduced, not hidden.

## Independent commands and outcomes

- ./test.sh: exit 0; 78 tests pass, no failures/skips: 22 Rust unit,
  48 Rust integration, 1 rustdoc, 7 Python. Includes static distribution and
  copied executable version inside an empty chroot. No fresh-container claim.
- cargo run --locked --release --example spatial_bench: exit 0. Results below
  are index ms / scan ms / scan-to-index speedup, each per 4096 queries:
  - radius 1 all: 0.357 / 23.408 / 65.521x
  - radius 1 herbivore: 0.260 / 16.448 / 63.225x
  - radius 4 all: 1.761 / 22.979 / 13.048x
  - radius 4 herbivore: 1.112 / 13.448 / 12.091x
  - radius 8 all: 4.828 / 18.652 / 3.864x
  - radius 8 herbivore: 3.634 / 13.423 / 3.694x
  - MAX all: 37.975 / 22.910 / 0.603x
  - MAX herbivore: 33.301 / 13.183 / 0.396x
  Checksums/matches exactly match docs/SPATIAL.md for all eight scenarios.
- cargo fmt --check && git diff --check: exit 0, following benchmark in same
  shell invocation. No review command failure.
- Final Python handoff/scope/protected-path/no-remotes validation and whitespace:
  exit 0 (executed after artifact creation).

## Limits and future obligations

Dense memory scales with world area; fallible initial reservation cannot guarantee
survival under overcommit or later allocation failures. Full-world queries lose
to ordered scans, and sorted bucket updates cost O(occupancy). These documented
limits do not violate this task. Future mutations must maintain the cache; future
persistence rebuilds it without RNG and excludes it from canonical state/hash.
No ecological behavior, checkpoint/UI or whole-engine throughput was required
or claimed here. Architecture/ADR already reflect implementation; no changes
needed. No new system dependency. No remediation required; harness owns next steps.

# TASK-008 REVIEW cycle 1

Verdict: PASS. All six acceptance criteria met, no actionable gaps.
External harness checks remain authoritative.

Verified required AGENTS.md and STATE.md files before reading. Read project,
contract, state, architecture, task/spec JSON, current REVIEW skill, task-local
plan/implementation handoffs, TASK-005 dependency handoffs and relevant ADRs
001/004/007 (existing climate integration preserved). Downstream TASK-009/010/
011/013 have task specs but no handoffs. Initial Git tree clean and no remotes.
Inspected actual committed implementation 0ef09ac..65fd91f and complete new
organism/population code, simulation changes, public/private tests and documentation.
Bounded follow-up reads supplemented truncated bulk outputs. No product edits,
packages installed, task-state changes, manual commits or phase transitions.

## Acceptance evidence

1. Three kinds: Kind has precisely Plant, Herbivore, Carnivore. Public
   exact_initial_records_and_row_major_placement checks mixed exact counts,
   all-zero populations, 1x1 co-occupancy and placement wrapping.
2. Complete records and never-reused IDs: public initialization test checks ID,
   kind, position, age, energy, health, traits, parents, generation and birth tick.
   Private accepted_lineage_survives_parent_death_and_normalizes_position checks
   sorted parental IDs, max-parent generation + 1 and normalized child position.
   repeated_multi_kind_birth_death_cycles_never_reuse_ids replaces 12 generations
   across all three kinds. Allocator fixture permits u64::MAX once, then rejects
   another request even after that child dies; capacity reservation and generation
   overflow rejection leave state unchanged. Allocation is monotonic, never reset
   on death; living storage is a BTreeMap owned by Population/Simulation.
3. Traits: public endpoint/founder tests independently check all twelve documented
   bounds and getters, including speed, strength, fertility, lifespan, max health,
   aggression and risk tolerance. Every trait rejects invalid range inputs;
   floating traits reject NaN and both infinities. Private validated Traits
   prevents invalid phenotype requests without redundant runtime checks.
4. Valid vitals, death/no action/cause: bounded_vitals_first_cause_and_no_resurrection
   covers signed finite extremes, positive saturation, lethal negative saturation,
   nonfinite rejection without mutation, first cause, repeated kill and dead update
   rejection. ordinary_lethal_health_change_records_injury checks default cause.
   The actual shared simulation walker rechecks each ID through age_before_action;
   a callback kills a later actor, which is never visited. All kinds expire before
   actions at lifespan. Removal is immediate; commit persists one death/cause
   record. Comparisons before addition keep finite vital changes from overflowing.
5. Lifetime counts: initial population is not births. Controlled multi-kind tests
   check exact birth/death counts, cause sums, persistent history and conservation
   initial + births - deaths = living after every commit. Four-seed event sequences
   check intermediate pending-death accounting and repeatability. Commit twice
   does not double-count. u128 counters exceed the lifetime u64 ID capacity.
6. Documented same-tick rule: ADR-007 captures live parents at birth acceptance;
   accepted children survive later parental death, dead parents cannot request new
   births, deaths remove immediately, and birth IDs follow phase/sorted parents/
   request sequence. Private real_walker_rechecks_liveness_and_newborns_wait_until_next_tick
   runs the actual walker and commit with controlled events for all three kinds:
   two deaths and one child account correctly, child age is zero at commit and one
   next tick. Separate ordering test covers phase, parent and exact-tie sequence.
   Four-seed 2200-tick public runs verify lifespan, continued empty ticking,
   non-replenishment, exact cloned replay and observational independence.

The implementation follows the approved plan. Population-owned BirthPhase avoids
reverse imports; its legal variants and validated Traits make invalid phase/trait
requests unrepresentable. No production reproduction caller exists, appropriate
for explicit task exclusions. No public mutable record/map/spawn escape exists.
Crate-private record fields remain an internal invariant obligation for later core
modules. No global-count survival or extra-energy source was introduced.
Architecture/ADR-007 accurately describe current state and future obligations.

## Executed commands and limits

- `./test.sh`: exit 0; 61 tests pass, none skipped: 13 unit, 40 integration,
  1 rustdoc, 7 Python. Includes setup twice/build, host/musl exports, static ELF
  inspection and actual copied version execution inside an empty chroot.
- `env -u DISPLAY cargo test --locked --lib --test organism --test lifecycle --test simulation`:
  exit 0; 21 tests pass (13 unit and 8 integration).
- `cargo fmt --check && git diff --check`: exit 0.
- Final Python validator below: exit 0; checks actual committed implementation
  scope instead of rerunning the implement validator's obsolete dirty-tree premise.

No failures during review. Existing musl prerequisites present; no system installs.
BTreeMap costs and O(all deaths) history need later profiling. Huge representable
initial populations may exceed RAM. Founder phenotype/placement remain provisional;
DNA and ecological behavior are excluded. Future persistence must encode allocator
exhaustion, request sequence, records/traits/lineage, counters/history plus the rest
of engine state. No throughput, coexistence, full checkpoint, separate fresh-container
provisioning or Rust 1.85 execution claimed. No remediation required; harness owns
completion and subsequent assignment.

Final validator (execute this fenced Python block from /workspace):

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-008/handoffs/review-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-008','review',1,'PASS')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
assert not h['gaps']
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(h['changed_files']) == {'docs/STATE.md','tasks/TASK-008/handoffs/review-cycle1.md','tasks/TASK-008/handoffs/review-cycle1.json'}
impl=json.loads((root/'tasks/TASK-008/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert set(git('diff','--name-only','0ef09ac..65fd91f').splitlines()) == set(impl['changed_files'])
assert not git('remote','-v')
assert not git('diff','--name-only','0ef09ac','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: review UTF-8/schema/scope, implementation scope, protected paths, no remotes, whitespace')
```

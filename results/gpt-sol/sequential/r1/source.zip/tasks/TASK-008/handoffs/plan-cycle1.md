# TASK-008 PLAN cycle 1

## Entry and scope

Verified /workspace/AGENTS.md and docs/STATE.md first. Read project/contract,
state/architecture, task files, planning skill, ADRs 001..006, historical structured
handoffs and TASK-005 detailed plan/implementation/review. Prior reviews PASS;
no TASK-008 handoffs or review gaps existed. Downstream TASK-009/010 handoffs
are absent; read their task boundaries. Initial Git tree clean, no remotes.
No feature changes, package installs or application tests in PLAN.

Current src/simulation.rs has private Config/World/tick/RNG, seven ordered
phases and biological no-ops. World includes both implemented climate models.
ordered_actor_ids is only a fixture helper, not evidence of actual lifecycle.
Existing simulation tests require initialization not to consume RNG; retain this
with deterministic row-major initial placement. Temporal weather still owns two
draws/enabled tick. CLI run/UI/checkpoint commands are not part of this task.

## Ordered implementation plan (only when assigned IMPLEMENT)

1. Implement src/organism.rs and export it in src/lib.rs. Add Kind,
   OrganismId, Traits, trait validation error, Organism and DeathCause. Follow
   all exact ranges/defaults in ADR-007, themselves compatible with ADR-004.
   Public getters expose immutable values; mutation remains crate-private.
   Traits::new validates all twelve inputs (a named input record is preferable
   to twelve positional arguments). Traits::founder provides provisional values.
   Organism construction is controlled by Population, not a public ID setter.
2. Implement src/population.rs with BTreeMap living storage, monotonic allocator,
   initial/living/birth/death/cause counts, death history and pending events.
   Provide public read-only get(id), iter() in ID order, counts(), totals(),
   death_records(); crate-private initialize, change_energy, change_health,
   kill, queue_birth, commit, phase ID snapshots and age-before-action methods.
   All fallible validation must precede mutation. No mutable map/record escape.
   Birth inputs contain kind, cell, traits, bounded initial vitals and parent IDs;
   derive generation from parents, not caller data. Normalize foreign Cells via
   owned Topology. Use explicit error variants for invalid traits/vitals/lineage,
   missing/dead IDs and exhausted ID/generation capacity. Repeated kill returns
   false; attempted updates of missing/dead IDs fail without resurrection.
3. Integrate Population as a private Simulation field with population() accessor.
   Simulation::new materializes configured counts at tick zero, no births and
   no random draws. Extend SimulationError for initialization failures. Keep
   World climate ownership/API unchanged. Kind phases use one shared private
   walker: snapshot IDs, liveness check, age/expiry, empty action hook. Commit
   executes actual lifecycle bookkeeping. Leave reproduction decisions empty.
   Keep existing fixed phase dispatch, TickReport and overflow atomicity.
4. Add tests/organism.rs for public trait boundaries and read-only organism
   records. Add tests/lifecycle.rs for actual initialization/aging/accounting,
   three kinds, replay and observational purity. Add private tests adjacent
   to population/simulation for mutation and controlled stage events. Reuse
   the production walker/commit implementation with an injected internal
   callback in tests to exercise death-before-turn and queued newborn ordering;
   do not create public spawn/damage CLI or test-only lifecycle algorithms.
5. Update tests/simulation.rs only as needed to include population invariants
   and preserve weather/RNG expectations. Extend docs/ARCHITECTURE.md and STATE,
   mark ADR-007 implemented with evidence. Retain genealogy/traits in future
   complete-state boundary; no premature checkpoint or genome code.
6. Run targeted tests then full regression/packaging once, fix failures and
   record exact results. Write implementation Markdown/JSON handoffs. No task
   states, phase transitions or commits; those belong to the harness.

## Acceptance matrix

| Requirement | Required executable evidence |
|---|---|
| Three kinds | Initialize distinct nonzero counts, inspect each Kind; all-zero and 1x1 mixed-kind worlds |
| Complete record/unique IDs | Assert every initial field, normalized cells, generation/parents; insert/remove/birth repeated cycles with no reused IDs; MAX ID once then rejection |
| Traits and animal behavior | Independently expected endpoints for all twelve fields, interior founder values, lower/upper violations and NaN/infinities; inspect animal aggression/risk |
| Bounded energy/health and death | Signed finite deltas below zero/above caps and extreme f64 values; nonfinite input leaves state unchanged; lethal values remove immediately with correct cause; attempted healing/damage/death cannot reanimate or double count |
| Lifetime counts | Zero initial births; controlled multi-kind births/deaths on multiple ticks; exact per-kind conservation, death causes and history; repeated death counted once |
| Same-tick rule | Queue birth from live parent(s), kill parent(s), commit: child survives with captured lineage, parent death counted, child age 0; next tick child ages once. Kill lower/later snapshot actor via callback: no later action. Reject post-death birth request |

Additional tests: plant one-parent/animal distinct two-parent lineage and generation
max+1; reject missing/wrong-kind/duplicate parents, invalid vitals/traits, generation
overflow and exhaustion with no partial changes. Invalid requests leave counters,
allocator and queues untouched. Birth order independent of map insertion history:
phase, sorted parent IDs, request sequence. Check parent ID storage order. Seeded
finite event sequences should maintain bounds, unique IDs, accounting and replay
after each commit. Use multiple seeds and >=2000 ticks on a small population,
cover lifespan deaths and continued empty ticks without replenishment. This is
lifecycle evidence, not food-chain coexistence. Same-build clones plus read-only
queries must give identical states/RNG, including counters and death history.
Test private tick-overflow case still leaves complete state unchanged.

Planned commands (not executed in PLAN):
- `env -u DISPLAY cargo test --locked --test organism --test lifecycle --test simulation`
- `cargo test --locked --lib` (private lifecycle/error/ordering fixtures)
- `./test.sh` (full Rust/rustdoc and Python host/musl packaging regression)
- `cargo fmt --check` and `git diff --check`.

No performance, full checkpoint, ecology, UI, fresh-container or separate Rust
1.85 claims. No new dependencies expected; setup already detects/reinstalls musl
prerequisites using exact commands in STATE. Existing test counts are historical,
not rerun evidence for this phase.

## Risks and choices

ADR-007 is the binding planned refinement: BTreeMap has lookup/node costs, death
history grows with lifetime deaths, provisional deterministic placement and traits
are intentionally simple until genome/ecology initialization exists. Initial
organisms age and die naturally but consume no energy in this scope. An empty
production birth queue is intentional: tests exercise real internal primitives,
while ecology later decides reproduction. Never add an application-accessible
population replenishment mechanism. Profile storage later rather than claiming
100 ticks/s now. No known blockers or previous REVIEW gaps. Planning validation executed with
exit 0: UTF-8/schema, exact five planning paths, protected files, no remotes,
whitespace. No application tests were run.

## Planning validation

Run the Python block below to validate UTF-8 handoff fields/types, exact
documentation-only paths, protected files, no remotes and whitespace. This
task-local validator is planning evidence, not feature code.

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-008/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-008','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-007-organism-lifecycle.md','tasks/TASK-008/handoffs/plan-cycle1.md','tasks/TASK-008/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(root),'diff','--check'],check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

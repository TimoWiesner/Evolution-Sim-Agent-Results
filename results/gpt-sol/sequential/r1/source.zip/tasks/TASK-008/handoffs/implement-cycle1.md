# TASK-008 IMPLEMENT cycle 1

Implemented the approved organism/lifecycle plan. Verified the required files
first; read contract/project/state/architecture, current task and plan handoffs,
IMPLEMENT skill, ADRs 001..007 and TASK-005 dependency handoffs. Dependency review
PASS has no gaps. TASK-009/010/011/013 dependent handoff directories are absent.
Some bulk reads truncated; bounded follow-ups supplied the relevant context.
Initial Git tree clean, no remotes. No packages installed, protected edits,
manual commits, task-state changes or phase transitions.

## Changes and rule

- organism.rs defines three kinds, opaque non-reused IDs, named TraitValues,
  validated private Traits and read-only organism records with all required data.
  The twelve ranges and provisional founder phenotype exactly follow ADR-007.
- population.rs owns BTreeMap living storage, monotonic Option<u64> allocator,
  initial/living/birth/death/cause counts (u128), death history and pending events.
  Simulation materializes exact initial counts in plant/herbivore/carnivore order,
  continuing row-major placement, with no RNG draws or initial birth counts.
- One actual walker snapshots ascending live IDs, rechecks liveness, ages once,
  removes lifespan-expired organisms before the hook, then runs the action hook.
  Production hooks are empty; no feeding, movement, DNA or reproductive behavior.
- Death removes immediately; first cause wins, repeated death is false, dead IDs
  cannot be healed or act. Finite signed vital deltas clamp with comparisons before
  addition, so even finite f64 extremes cannot overflow. Nonfinite input fails
  without changes. Zero energy means Starvation; zero health defaults to Injury
  or uses an explicit supplied cause. Commit increments totals and history once.
- Birth acceptance validates positive bounded vitals, live same-kind parent arity
  (one plant/two distinct animal), generation capacity and reserved ID capacity.
  Parents are sorted; lineage is captured at acceptance. Accepted children survive
  subsequent parental death. Commit orders birth phase, parent IDs, then request
  sequence, assigns never-reused IDs, age zero and current birth tick. A newborn
  enters no action snapshot until the next tick. Dead parents cannot request births.
- Completed conservation: initial + births - deaths = living. Mid-tick subtract
  pending deaths too; accepted newborns are not yet living. Commit empties queues.

API refinements within the plan: a population-owned BirthPhase enum has only legal
phases, avoiding a population -> simulation import cycle; invalid phase values are
unrepresentable. Traits already validates construction, so BirthRequest takes
Traits rather than duplicating validation or adding an unused InvalidTraits error.
All counters use u128 and are bounded by lifetime u64 IDs, so explicit counter
reservation is unnecessary; pending births reserve remaining ID capacity. The old
fixture-only ordered_actor_ids helper was removed because BTreeMap snapshots are
already unique and sorted. No behavioral or scope deviation.

## Acceptance evidence

| Must have | Executed evidence |
|---|---|
| Three kinds | lifecycle::exact_initial_records_and_row_major_placement inspects exact mixed, zero, 1x1 and wrapped placements; all private fixtures cover three kinds |
| Complete records/unique IDs | Public initial-record test inspects every field; private lineage test checks child fields, foreign Cell normalization and generation; repeated_multi_kind_birth_death_cycles_never_reuse_ids checks 12 generations; MAX-ID reservation/exhaustion fixture allows MAX once then rejects without mutation |
| Required traits/behavior | Two organism integration tests independently check all twelve endpoints, founder literals/getters, lower/upper invalid inputs and all nonfinite float inputs; animals expose aggression and risk tolerance |
| Bounded energy/health, removal/cause/no action | bounded_vitals_first_cause_and_no_resurrection checks finite extremes, nonfinite atomic errors, dead healing/update failures, immediate removal and first cause; ordinary lethal health test checks Injury default; actual simulation walker test proves later dead actors never act; expiry test proves no action on lifespan tick |
| Per-kind birth/death totals | Initialization excludes births; 12-generation multi-kind test, cause/history tests and seeded sequences verify exact conservation and single accounting after each commit |
| Same-tick rule | real_walker_rechecks_liveness_and_newborns_wait_until_next_tick queues child, kills parent/later actor, executes actual commit, checks age 0 then age 1 next tick; lineage fixture accepts before parent death, rejects after death; ordering fixture checks phase/parents/sequence independent of insertion history |

Additional evidence: invalid parent count/duplicates/wrong kind/missing ID,
invalid newborn vitals and generation/allocator exhaustion leave the entire
population unchanged. Four-seed 256-event sequences exercise real primitives,
bounds, conservation, IDs and exact replay. Four seeds run 2200 engine ticks,
including natural death at tick 1100, continued empty ticking and no replenishment;
observation cannot alter complete cloned state/RNG. Existing tests retain temporal
climate draw counts and clock-overflow atomicity with materialized populations.
Tests use internal controlled hooks, not a second lifecycle engine or public spawn.

## Actual commands and results

1. `cargo test --locked --lib`: exit 0, initial four tests before new test code.
2. `cargo test --locked --lib --test organism --test lifecycle --test simulation`:
   first exit 101, nonexistent Rng::from_u64 in test code. Corrected to
   Rng::from_seed(&Seed::from_u64(seed)). Second exit 101, ambiguous sum type in
   test assertion due to serde_json comparisons; corrected to sum::<usize>.
   Subsequent same-command runs exited 0 (19 then 20 tests as coverage grew).
   One successful intermediate run warned of unused phase fixture variable;
   corrected by assigning it to the birth request. No runtime test failures.
3. `cargo fmt`: exit 0 after edits.
4. `./test.sh`: exit 0, 61 tests, no skips: 13 unit, 2 CLI, 5 climate, 8 config,
   2 lifecycle, 2 organism, 5 RNG, 4 simulation, 5 temporal climate, 7 topology,
   1 rustdoc, 7 Python. Includes setup twice/build, host/musl climate exports,
   static ELF and actual copied version execution inside an empty chroot.
5. `env -u DISPLAY cargo test --locked --test organism --test lifecycle --test simulation`:
   exit 0, eight tests after final product/test edits.
6. `cargo fmt --check` and `git diff --check`: exit 0.
7. Final validator below: exit 0, required UTF-8 JSON/schema, exact eleven paths,
   protected-file integrity, no remotes, formatting and whitespace.

No dependencies or system packages added. Setup found inherited musl tools/target;
exact reinstall commands remain in STATE/setup.sh. No code changes after final
full suite. No throughput, full checkpoint, coexistence, fresh-container or
separate Rust 1.85 evidence. Representable counts may exceed RAM; BTreeMap overhead
and O(all deaths) history require later profiling. Provisional founder phenotype
and placement intentionally await later biology/genetics initialization. Persistence
must include next-ID exhaustion, request sequence, living traits/life/lineage,
initial/lifetime/cause counts and death history plus existing engine state.
No known acceptance gaps or blockers. Harness assigns review/commits/transitions.

## Final validator

Execute the Python block below from /workspace (or extract the final fenced block).

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-008/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-008','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'src/lib.rs','src/organism.rs','src/population.rs','src/simulation.rs','tests/organism.rs','tests/lifecycle.rs','docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-007-organism-lifecycle.md','tasks/TASK-008/handoffs/implement-cycle1.md','tasks/TASK-008/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact eleven paths, protected files, no remotes, formatting, whitespace')
```

"""Run from /workspace; review evidence checks, without product mutation."""
import json
from pathlib import Path
import subprocess
p = Path('tasks/TASK-026/handoffs')
for name in ('primary', 'mixed'):
    a = json.loads((p / f'after-{name}.json').read_text())
    b = json.loads((p / f'before-{name}.json').read_text())
    for d in (a, b):
        rates = sorted(r['ticks_per_second'] for r in d['runs'])
        assert d['median_ticks_per_second'] == rates[len(rates) // 2]
        for r in d['runs']:
            assert r['population_min'] >= 2000
            assert abs(r['ticks_per_second'] * r['seconds'] - d['measured_ticks']) < 1e-9
    assert a['effective_config'] == b['effective_config']
    stable = lambda d: [{k: v for k, v in r.items() if k not in ('seconds', 'ticks_per_second')} for r in d['runs']]
    assert stable(a) == stable(b)
    print(name, 'matched biological results; median ratio', a['median_ticks_per_second'] / b['median_ticks_per_second'])
key = lambda r: (r['case'], r['ticks'])
a = json.loads((p / 'after-differential.json').read_text())
b = json.loads((p / 'before-differential.json').read_text())
assert sorted(a['states'], key=key) == sorted(b['states'], key=key)
assert (a['checks'], b['checks']) == (50, 30)
assert not subprocess.check_output(['git', 'remote', '-v'])
assert not subprocess.check_output(['git', 'diff', 'e7f8574..HEAD', '--name-only', '--', 'AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md', '.agents/skills', 'tasks/*/task.md', 'tasks/*/task.json', 'tools', 'Cargo.toml', 'Cargo.lock'])
for command in (['cargo', 'fmt', '--check'], ['git', 'diff', '--check']):
    subprocess.run(command, check=True)
print('PASS: 30 matched manifest states/checkpoints, timing reports, protected scope, formatting and no remotes')

"""Summarize direct incoming Callgrind arcs (Ir and calls, not wall time).
Run from /workspace; optimized inline source attribution remains in annotations.
"""
import json
import pathlib
import re
import sys
label=sys.argv[1]
assert label in ('before','after')
names={}
calls={}
cost={}
target=None
pending=False
for line in pathlib.Path(f'target/task026/{label}.callgrind').read_text().splitlines():
    match=re.match(r'c?fn=\((\d+)\)(?: (.*))?$',line)
    if match:
        if match[2]: names[match[1]]=match[2]
        if line.startswith('cfn='): target=match[1]
    if line.startswith('calls='):
        n=int(line.split('=')[1].split()[0])
        calls[target]=calls.get(target,0)+n
        pending=True
    elif pending and re.match(r'[+*\-\d]',line):
        cost[target]=cost.get(target,0)+int(line.split()[1])
        pending=False
rows=[{'function':names.get(k,k),'calls':n,'inclusive_Ir':cost.get(k)} for k,n in calls.items()
      if any(x in names.get(k,'') for x in ['advance_one_tick','regenerate','Genome>::traits',
                                              'Climate>::base_at','__cos_fma','Traits>::new'])]
pathlib.Path(f'tasks/TASK-026/handoffs/{label}-profile-calls.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))

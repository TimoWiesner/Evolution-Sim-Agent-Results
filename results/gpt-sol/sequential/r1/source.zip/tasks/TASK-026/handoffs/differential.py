"""Run from /workspace. Baseline first, then compare after core optimization.
Artifacts are ignored under target/task026; this script preserves exact commands.
"""
import hashlib, json, pathlib, subprocess, sys
root=pathlib.Path('target/task026/differential');root.mkdir(parents=True,exist_ok=True)
mode=sys.argv[1]
assert mode in ('before','after')
binary='target/task026/before-evosim' if mode=='before' else 'target/release/evosim'
def run(args): subprocess.run([binary,'run',*map(str,args)],check=True)
def clean(p):
 d=json.loads(p.read_text())
 for k in ('elapsed_seconds','ticks_per_second'): d.pop(k)
 return d
base={'seed':42,'world':{'width':64,'height':48},'initial':{'plants':400,'herbivores':120,'carnivores':20}}
cases={'contract':base,'primary':json.loads(pathlib.Path('scenarios/performance.json').read_text()),
'mixed':dict(base,initial={'plants':2400,'herbivores':120,'carnivores':20}),
'empty':dict(base,initial={'plants':0,'herbivores':0,'carnivores':0}),
'nofood':dict(base,initial={'plants':0,'herbivores':120,'carnivores':20}),
'noweather':dict(base,climate={'weather_amplitude':0}),
'mutation':dict(base,genetics={'mutation_per_million':1000000})}
for w,h in [(1,1),(1,17),(19,1)]: cases[f'{w}x{h}']=dict(base,world={'width':w,'height':h},initial={'plants':20,'herbivores':8,'carnivores':3})
checks=0
manifest=[]
for name,config in cases.items():
 p=root/(name+'.json');p.write_text(json.dumps(config))
 for ticks in ([0,100,1100] if name=='primary' else [0,25,110]):
  tag=f'{name}-{ticks}';out=root/f'{mode}-{tag}.json';save=root/f'{mode}-{tag}.evo'
  run(['--config',p,'--ticks',ticks,'--sample-every',10,'--out',out,'--save',save])
  if mode=='after':
   assert clean(out)==clean(root/f'before-{tag}.json'),tag
   assert save.read_bytes()==(root/f'before-{tag}.evo').read_bytes(),tag
  manifest.append({'case':name,'ticks':ticks,'state_hash':clean(out)['state_hash'],
      'checkpoint_sha256':hashlib.sha256(save.read_bytes()).hexdigest()})
  checks+=1
 if mode=='after':
  # Both directions, and uninterrupted baseline, with identical final state.
  before=root/f'before-{name}-25.evo' if name!='primary' else root/'before-primary-100.evo'
  after=root/f'after-{name}-25.evo' if name!='primary' else root/'after-primary-100.evo'
  split=25 if name!='primary' else 100
  for b,checkpoint,label in [(binary,before,'new-from-old'),('target/task026/before-evosim',after,'old-from-new')]:
   out=root/f'{label}-{name}.json'
   subprocess.run([b,'run','--load',str(checkpoint),'--ticks','10','--out',str(out)],check=True)
   ref=root/f'uninterrupted-{name}.json'
   subprocess.run(['target/task026/before-evosim','run','--config',str(p),'--ticks',str(split+10),'--out',str(ref)],check=True)
   a=json.loads(out.read_text());r=json.loads(ref.read_text())
   for k in ('final','totals','state_hash'): assert a[k]==r[k],(name,label,k)
   checks+=1
pathlib.Path(f'tasks/TASK-026/handoffs/{mode}-differential.json').write_text(json.dumps({'checks':checks,'states':manifest},indent=2)+'\n')
print(f'{mode}: {checks} exact output/checkpoint/continuation checks passed')

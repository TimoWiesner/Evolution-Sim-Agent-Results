# TASK-026 IMPLEMENT cycle1

Implemented only the approved performance plan; verdict N/A. Verified required
AGENTS.md/STATE.md first. Read project/contract/state/architecture, task spec/JSON,
plan handoffs, dependent TASK-010/018/019/021 implementation/review memory and
TASK-022/025 current memory, relevant ADRs and implement skill. Dependency reviews
have no gaps. Initial tree clean; no Git remotes. No manual commits, history or
branch changes, protected/task-state/benchmark-tool edits, delegation or phase
transition. Harness retains all such ownership. All artifacts stay local.

## Final implementation

- External performance_bench example and shared public-API-only measurement helper;
  fixed scenario, warm-up, timed ticks, repeated final hashes, all-tick population
  floor, O(1) observational population summaries, raw schema1 JSON. No core clock
  or reverse dependency. test.sh invokes the ignored release10/s guard explicitly.
- Preserved unchanged baseline CLI/benchmark/profile executables in ignored
  target/task026 before core edits. Baseline fixture states/checkpoints captured
  before edits; later repeated formal baseline timing with the preserved binary
  after installation/tests and before optimized timing in isolation.
- Callgrind release-with-debuginfo profile confirmed resource regeneration's
  repeated row-equivalent climate queries (12.15% baseline inclusive Ir).
  ResourceField::regenerate_rows invokes existing current_at at x0 once per row,
  preserving original cell formula/order with O(1) workspace. No state, schema,
  model/default/ecology/RNG/dependency/public API changes. TemporalClimate and
  public arbitrary-cell queries remain unchanged. No persistent cache.
- Optional direct occupancy/season hoist not implemented; one measured bounded
  change improves both workloads. Trait conversion/validation and BTree searches
  remain major costs; broad storage/cache rewrites were not attempted.

Primary median751.693→847.955 ticks/s (+12.8%); range705.422..752.044 before,
846.122..848.601 after. Mixed1027.076→1095.760 (+6.7%). Goal100/s met here.
Primary2303..5081,mean3490.522; mostly plants, herbivores already gone at100 and
carnivores die later. Short mixed2385..2933,mean2745.550; herbivores die during
measurement. No sustained coexistence/constant2000 actors/universal speed claim.
Raw configs/repeats/hashes/counts and exact reproduction commands/hardware/profile
explanations: docs/PERFORMANCE.md and adjacent before/after JSON/annotations.

Whole profile18,644,111,702→16,470,550,534 Ir (-11.66%), regeneration subtree
2,264,907,396→91,344,032 (-95.97%). This includes initialization/warm-up/hash,
uses instruction attribution, never profiler wall time as throughput. Inclusive
rows overlap. Calls to Genome::traits unchanged12,232,924. Profile commands bound
by timeout180s; both finish successfully. Tool3.22.0. Development-only installation
actually succeeded: apt-get update then
apt-get install -y --no-install-recommends valgrind. STATE records exact commands;
reinstall if missing, no setup/runtime/test.sh profiler dependency. No Cargo change.

## Validation commands and results

- `cargo build --locked --release --examples --bin evosim`: exit0 after correcting
  missing scenarios directory; saved target/task026/before-{bench,evosim}.
- `target/task026/before-bench > tasks/TASK-026/handoffs/before-primary.json`,
  same with `--workload mixed`/before-mixed, optimized binary equivalents after:
  all exit0. Five primary/nine mixed fresh repeats each; exact observations/hash
  match across all before/after repeats after excluding measured seconds/rate.
- `CARGO_PROFILE_RELEASE_DEBUG=1 cargo build --locked --release --example performance_bench --target-dir target/task026-profile`:
  exit0 both builds; saved baseline profile executable before edits. Both
  `timeout 180s valgrind --tool=callgrind --callgrind-out-file=target/task026/{before,after}.callgrind BINARY --repeats 1`
  exit0. Both self/inclusive callgrind_annotate invocations exit0. Full exact paths
  are in PERFORMANCE; profile_summary.py extracts direct incoming arcs/call counts.
- `cargo test --locked --lib --test spatial --test resources --test climate --test temporal_climate --test ecology_integration`:
  exit0,155 passed,0 failed/ignored (137 unit+18 integration). New bit oracle checks
  five shapes, seasonal ticks/extreme clock, weather0/default/max and nonzero
  restored offsets, depleted stores and extreme resource budgets. Existing
  temporal tests retain extreme years/season amplitudes.
- `python3 tasks/TASK-026/handoffs/differential.py before`: exit0,30 original states;
  `python3 tasks/TASK-026/handoffs/differential.py after`: exit0,50 checks. All30
  results compare every key except two timing fields, and every checkpoint byte;
 20 bidirectional continuation checks compare final/totals/hash to uninterrupted
  baseline. Ten varied workloads and three splits each; tracked digest manifests
  independently match every pair. Full output/checkpoint files remain ignored.
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test checkpoint_cli --test state_hash --test run_cli --test batch_cli`:
  exit0,17 passed,0 failed/ignored.
- Six invalid benchmark option probes (missing values,zero/nonnumeric repeats,
  unknown workload/flag): all reject with status1,stderr and no stdout. This is
  an example, not a new contracted CLI command. Probe assertion script exit0.
- `./test.sh > target/task026/full-suite.log 2>&1`: exit0;228 Rust passed,
  22 Python passed,all3 Node scripts passed. Ordinary debug invocation ignores
  the timing guard once; explicit release invocation passes847.444 ticks/s
  (minimum2303,exact1100),threshold10/s. No existing test skipped or failed.
  Includes real browser controls/charts/files,host/musl setup/build,static ELF,
  copied-empty-root offline headless run/checkpoints and replay. Python61.407s.
  test-results.json preserves counts and actual release guard observation.
- `cargo fmt --check` and `git diff --check`: exit0; repeated after final handoff.
- Validator below verifies required UTF-8 JSON/types/scope, unchanged protected
  files, no remotes, exact digest pairs and raw per-repeat data. Final outcome
  retained in structured handoff.

Initial setup mistakes: first command lacked scenarios directory; initial build
failed include_str and subsequent missing-copy/executable chain ended127. Created
directory/scenario and explicitly rebuilt before baseline; no failed timing data
used. Early differential fixture misspelled mutation_per_million as mutation_rate;
corrected to validated max-rate config before successful final baseline capture.
No runtime assertion mismatch, test failure or ecological change was concealed.
Formal baseline was rerun after installation to avoid its possible timing overlap.

## Limits and next phase

Shared-host CPU scaling/contention persists; quota/memory files outside /workspace
were not read under user constraint. Hardware command output/affinity are tracked,
not quota guarantees. Row optimization assumes the current longitude-independent
climate; future longitude variation must update it and bit tests together.10/s
coarse guard is not a100/s hardware guarantee. Mostly-plant benchmark is not a
balancing result. Core codec/hash inventory remains exactly ADR-015/018. Ignored
local baseline executables/raw fixtures aid review but are not tracked or shipped.
No fresh-OS/minimum-Rust execution claimed. Harness assigns REVIEW, owns commit
and task transitions; this process does not start another phase.

## Final artifact validator

Run from /workspace:

```sh
python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-026/handoffs/implement-cycle1.md").read_text().split("```python\n",1)[1].split("```",1)[0])'
```

```python
import json, subprocess
from pathlib import Path
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-026/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}<=h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-026','implement',1,'N/A')
assert type(h['cycle']) is int
for k in ['changed_files','decisions','tests','risks','next_steps','gaps']: assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=root,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual==set(h['changed_files']),actual^set(h['changed_files'])
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools','Cargo.toml','Cargo.lock')
for f in actual:
    (root/f).read_text(encoding='utf-8')
    assert f in {'src/resources.rs','src/simulation.rs','test.sh','examples/performance_bench.rs','examples/support/performance.rs','tests/performance.rs','scenarios/performance.json','docs/STATE.md','docs/ARCHITECTURE.md','docs/PERFORMANCE.md','docs/decisions/ADR-019-performance-measurement.md'} or f.startswith('tasks/TASK-026/handoffs/'),f
p=root/'tasks/TASK-026/handoffs'
a=json.loads((p/'after-differential.json').read_text());b=json.loads((p/'before-differential.json').read_text())
key=lambda r:(r['case'],r['ticks'])
assert a['checks']==50 and b['checks']==30
assert sorted(a['states'],key=key)==sorted(b['states'],key=key)
for name,n in [('primary',5),('mixed',9)]:
    a=json.loads((p/f'after-{name}.json').read_text());b=json.loads((p/f'before-{name}.json').read_text())
    assert a['effective_config']==b['effective_config'] and a['repeats']==b['repeats']==n
    assert all(r['population_min']>=2000 for r in a['runs']+b['runs'])
    stable=lambda d:[{k:v for k,v in r.items() if k not in ('seconds','ticks_per_second')} for r in d['runs']]
    assert stable(a)==stable(b)
assert not h['gaps']
assert 'PENDING' not in (root/'docs/PERFORMANCE.md').read_text()
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8 handoff/schema, exact changed scope, protected files, no remotes,30 exact state/checkpoint pairs,50 differential checks,28 timing reports, formatting/whitespace')
```

# TASK-026 PLAN cycle 1

## Scope and evidence on entry

Applied `.agents/skills/plan/SKILL.md`. Verified /workspace/AGENTS.md and
/workspace/docs/STATE.md first. Read project/contract, state/architecture, task
specification and JSON, historical structured handoff summaries, dependency
TASK-010/018/019/021 implementation/review evidence and relevant ADR-001/003/014/
015/017/018. TASK-022 checkpoint and TASK-025 current UI memory were also inspected.
All prior reviews PASS without acceptance gaps; no prior TASK-026 handoffs.
Initial tree clean and no remotes. No implementation, installs, commits, protected
file edits, task state changes, delegation or phase transitions in this PLAN.
The user explicitly forbids accessing paths outside /workspace; keep artifacts here.

Simulation is sequential and stable-ID ordered. Resource regeneration queries
current climate for every cell; every query recomputes base latitude cosine,
precipitation interpolation and seasonal cosine. Plants query again. Both base
and current climate depend on y, settings and tick/weather, not x. Spatial query
allocates/sorts output; plant establishment allocates it merely to test emptiness.
Population phase IDs already come from ordered BTreeMap iteration (no redundant
sort there). These are source-derived hypotheses, not profile results.

Existing `examples/spatial_bench.rs` is a query microbenchmark, not ticks/s.
CLI runner times individual tick calls only; excludes metrics, hash and I/O.
Changing sampling interval cannot change ecology, but end-to-end timings must be
reported separately if used. No early extinction shortcut, altered defaults,
replenishment, DNA policy or UI rendering optimization is allowed.

## Workload decision and planning probes

Primary fixed input (only contract keys; defaults unchanged):

```json
{"seed":42,"world":{"width":128,"height":48},"initial":{"plants":4600,"herbivores":240,"carnivores":40}}
```

Use 100 warm-up ticks followed by 1000 measured ticks, five fresh independent
repeats. Count every completed measured tick; require total >=2000 throughout.
Report min/mean/max total and per-kind start/end counts, births/deaths and final
hash. No requirement that all kinds survive: probe ends with 2303 plants and no
animals. This measures a changing ecological workload, mainly plants in its tail;
it is not evidence of sustained mixed-chain coexistence. Population initially
4880 can grow above5000. Do not reduce real ecological work to hit a timing target.

Supplementary animal-active window: 64x48, seed42, initial2400/120/20, warm-up10,
measure100, nine repeats. Verify >=2000 throughout, report animal loss explicitly.
It complements rather than replaces the longer primary. Do not use the rejected
2400-plant growth0/reproduction1000000 fixture: population falls to1632 by110.
Long 64x48 mixed intervals also fall below2000 (minimum1605 through550 and1234
through1100); choosing them as primary would give misleading target evidence.

Exploratory commands used existing inherited release launcher, without rebuilding;
therefore these are feasibility observations, NOT formal before-optimization data.
Artifacts ignored under target/task026-plan; exact reproduction:

```sh
./evosim run --config target/task026-plan/sustained.json --ticks 1100 --sample-every 1 --out target/task026-plan/sustained-result.json
./evosim run --config target/task026-plan/mixed.json --ticks 110 --sample-every 1 --out target/task026-plan/mixed-result.json
./evosim run --config target/task026-plan/mixed.json --ticks 1100 --sample-every 1 --out target/task026-plan/mixed-long-result.json
./evosim run --config target/task026-plan/stable.json --ticks 110 --sample-every 1 --out target/task026-plan/stable-result.json
```

All exit0. Primary ticks100..1100 total2303..5081, whole1100 tick-loop695.238/s,
final hash7cd2929d919d393e6707ab2c477c11d95df951dfb6430ce76640bb72c891aa8a.
64x48 ticks10..110 total2385..2933, whole110 loop799.986/s,
hash664d8aadc5346dcf0923b5a7ce4e6ee861135bd07aa1d1880136c606ffd8be52.
These rates include warm-up; the planned harness must time only measured ticks.
The probes ran while targeted debug tests were running; do not compare their rates.
Machine probe: AMD Ryzen5 7500F,6 cores/12 threads, Linux x86_64, rustc/cargo1.100.0.
`perf` and `valgrind` not found; no profiler was installed or run in PLAN.

## Ordered implementation plan

1. Add `scenarios/performance.json` with the exact primary input. Add
   `examples/support/performance.rs` for fixed workload constants/config loading,
   warm-up and a shared measurement helper using only public Simulation APIs.
   Add `examples/performance_bench.rs`: default primary five repeats, optional
   `--workload mixed` for the supplementary window, optional positive `--repeats N`
   for profiling. Reject malformed options. Use Instant in this outer example,
   never in core. Build once then run the executable. Emit versioned JSON to
   stdout with config/effective config, warmup/ticks/repeats/build label, each
   seconds/rate/population extrema/mean/by-kind bounds and final hash, plus median
   and spread. Capture host/rustc/OS/cgroup quota/affinity separately in report.
   Exclude initialization, warm-up, hashing, checkpoint and serialization from
   timed interval. Include cheap O(1) count observations in that interval and
   disclose them; no per-tick metrics or history audit. Assert population floor,
   exact end tick, positive finite time and identical hashes across repeats.
   Consume outputs through black_box where appropriate. Shared helper returns a
   detached report; no benchmark fields enter Simulation. No new CLI command.
2. BEFORE core edits, run `cargo build --locked --release --examples`, preserve
   target/release/examples/performance_bench as target/task026-before-bench and
   target/release/evosim after an explicit release binary build. Run five primary
   and nine mixed repeats and save raw reports under task-local handoffs (small
   JSON), along with same-build baseline state/checkpoint fixtures. Capture
   tick0/100/1100 canonical hashes and checkpoint bytes for primary and several
   varied cases before editing. Also build and preserve a debuginfo profile
   binary; never rebuild the baseline after edits. No Git checkout/reset/worktree
   or history mutation is needed. Formal comparison must use identical harness,
   compiler, flags, configs and no concurrent tests/browser/profile processes.
3. Profile baseline before choosing changes. Preferred portable container method:
   Valgrind Callgrind with release optimization + debuginfo, separate target dir
   `target/task026-profile`, using `CARGO_PROFILE_RELEASE_DEBUG=1 cargo build
   --locked --release --example performance_bench --target-dir target/task026-profile`.
   Install only if missing: `apt-get update`, then
   `apt-get install -y --no-install-recommends valgrind`. Record actual versions
   and exact commands in STATE. Run `valgrind --tool=callgrind
   --callgrind-out-file=target/task026-before.callgrind
   target/task026-profile/release/examples/performance_bench --repeats 1` and
   `callgrind_annotate --inclusive=yes --threshold=95 ...`; record self and inclusive
   costs/call counts, avoid double counting nested inclusive percentages.
   Initialization/warm-up are included in whole-program instruction profile and
   must be labelled; compare tick call subtree, not JSON/hash instructions as
   engine cost. Profile mixed separately if needed. Callgrind Ir is instruction
   cost, not wall-time percentage. Check a short run early; bound each profile
   with timeout180s. If unavailable, use supported perf with symbols and record
   permissions/failure, or a test-only phase timing profile invoking actual
   private phase methods on clones, rather than inventing hotspot percentages.
4. First candidate, only if profile supports it: add private exact row climate
   preparation in src/temporal_climate.rs and consume it in
   Simulation::climate_resources (src/simulation.rs) through a crate-private
   ResourceField::regenerate_rows(settings, precipitation_by_row) in
   src/resources.rs. Current climate has no longitude variation: compute identical
   `current_at(base, topology.cell(0,y))` once per row at the new weather tick,
   then regenerate every cell in the original row-major order with that exact
   precipitation. Preserve current per-cell arithmetic/order and saturation,
   not `(store+regen).min(cap)` algebraic rewrites. Prefer a streaming row callback
   so O(1) extra memory, no new persistent cache, construction or codec change.
   Optionally reuse a scalar seasonal cosine per call batch, preserving the
   original operation tree/rounding. Keep public arbitrary-cell current_at intact.
   If profile instead favors another hot path, document evidence before changing
   the candidate; no broad storage rewrite is pre-authorized by speculation.
5. Optional second small candidate if measured useful: crate-private
   SpatialIndex::has_kind(cell, kind)->bool and Population forwarding helper;
   use in plant establishment instead of nearby(...radius0...).is_empty().
   Direct bucket membership must normalize cells and preserve rejection/RNG/
   reservation ordering exactly. Keep nearby/sense order and public signatures.
   Existing sorted buckets make this O(occupants) without result allocation/sort.
   Touch only src/spatial.rs, src/population.rs, src/simulation.rs and relevant
   tests for this candidate. Do not alter animal target ties or iteration order.
6. After EACH candidate run behavior checks and identical primary/mixed timing;
   retain useful changes only, record attempts/rejections honestly. Reprofile final
   code with identical flags/workloads. Report target reached or actual miss,
   remaining expensive functions and limitations. Keep no unproven optimization.
7. Add tests described below, wire the release slowdown guard into test.sh,
   finish docs/PERFORMANCE.md with real raw before/after evidence and hardware;
   update ADR-019, architecture and STATE to implemented facts. Run full suite in
   isolation and leave detailed implement handoff. Do not start REVIEW or TASK-027.

## Acceptance and validation matrix

| Must have | Implementation evidence |
|---|---|
| Reproducible >=2000 workload, warm-up and measured length | `cargo run --locked --release --example performance_bench`, primary100+1000/five repeats, exact scenario, all-tick floor assertion, JSON raw reports |
| Hardware, command and before/after | docs/PERFORMANCE.md plus tracked small before/after JSON and toolchain/build/hardware metadata |
| Identified profile hotspots and action | Callgrind baseline/final named self/inclusive Ir and calls, raw filenames/commands, code candidate rationale and rejected attempts |
| >=100 ticks/s or explained miss | Median unprofiled primary ticks/s, repeat range, measured population range, actual miss and remaining bottleneck if applicable |
| All existing tests including determinism/checkpoints | isolated `./test.sh`; targeted command below; unchanged golden and baseline differential comparison |
| Loose slowdown guard | release-only test enabled in test.sh, primary100+1000, >=2000 each tick, minimum10 ticks/s (=100 seconds measured1000), not debug100/s assertion |

Proposed tests/performance.rs imports the shared examples support module and uses
`#[ignore = "release performance guard; invoked by test.sh"]` plus a release-build
assertion; test.sh explicitly runs `cargo test --locked --release --test performance
-- --ignored --nocapture`. Ordinary debug cargo test does not enforce wall-time.
No environment variable may silently disable the explicit guard. 10/s is a coarse
catastrophic-regression threshold, not proof of100/s target or same-host speedup.
Record rationale against measured baseline; keep one primary run in guard to bound
suite duration. Assert measured counts and exact ticks separately from throughput.

Behavior tests: row rain bits and resource bits match the prior per-cell oracle
for tiny/rectangular worlds, all rows, seasons, restored nonzero weather, disabled
weather and extreme valid settings. Keep resources/clock/RNG unchanged except
original intended ticks. Spatial existence oracle matches nearby radius0 for each
kind, seams/foreign cells, empty/stacked cells and after births/moves/deaths.
Preserve all current randomized spatial/lifecycle/ecology tests.

Record before/after outputs of preserved same-toolchain baseline binary for
primary, mixed, fixed contract config,1x1/1xN/Nx1, empty/no-food, high mutation and
weather-disabled cases at selected ticks. Compare final/totals/series/state_hash
exactly after excluding only documented timings, and checkpoint bytes exactly;
run at least one baseline checkpoint in optimized binary and vice versa, then
compare continuation to uninterrupted baseline. New-old differential matters:
same-version replay alone could hide a deterministic behavioral regression.
GNU/musl builds need not have equal hashes to each other; compare each build to
itself. Keep existing canonical/schema/model versions and hash golden unchanged.

Planned commands:

```sh
env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test checkpoint_cli --test state_hash --test run_cli --test batch_cli
cargo test --locked --lib --test spatial --test resources --test climate --test temporal_climate --test ecology_integration
cargo run --locked --release --example performance_bench
cargo test --locked --release --test performance -- --ignored --nocapture
./test.sh
cargo fmt --check
git diff --check
```

Existing suite includes Node and real browser/host/static-musl packaging. Run it
without concurrent browser automation (global profile inventory assertions).
Reserve at least15 minutes of IMPLEMENT's60 for full checks/docs/handoff; complete
baseline/profile in first15, candidates next20, remaining10 for measurements.
Avoid long10k multi-seed balancing; explicitly out of scope. Profiling tool failure
is not permission to skip profile acceptance: record an honest blocker if no method
works. Target miss is allowed with measured explanation, behavioral mismatch is not.

## Risks and handoff

Main risks: changed float operation tree, row assumptions spreading into future
longitude climate, profiling startup costs confused with ticks, timing contention,
short mixed window masking animal extinction, profiler tooling unavailable, debug
slowdown assertions, nondeterministic query iteration, new caches breaking hash or
checkpoint ownership. Primary uses about2300..5100 organisms rather than constant
2000; disclose this and retain mixed window. No fresh-container/performance claim
is made in PLAN. Existing dependency commands in STATE remain binding; no new
system dependency installed here. IMPLEMENT owns all new tests/profiling/code and
formal before/after data. Harness owns commits, task states and next phase.

## Interface refinement and actual PLAN validation

Preferred row API is crate-private
`ResourceField::regenerate_rows(&mut self, settings: &PlantConfig,
precipitation: impl FnMut(usize) -> f64)`, called once for each y before the
unchanged inner x loop. Simulation supplies a closure calling existing
TemporalClimate::current_at(&Climate, topology.cell(0,y)). This first candidate
needs no TemporalClimate structural change at all. Existing generic per-cell
regeneration can remain test-only as a differential oracle, or its previous
formula can be retained in a private test reference. Avoid duplicate production
algorithms. A seasonal-hoist helper in temporal_climate.rs is optional and only
worth adding after separate measured evidence; retaining the existing query API
is preferred. Row callback is explicitly precipitation independent of x, not a
general promise that all future climate implementations lack longitude effects.

Actual existing behavior baseline command:
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test checkpoint_cli --test state_hash --test run_cli --test batch_cli > /workspace/target/task026-plan/baseline-tests.log 2>&1`
exit0:17 passed (3 checkpoint,2 checkpoint CLI,2 hash,5 run CLI,5 batch CLI),
0 failed/ignored/filtered. No new test/full-suite/profiling/optimization success
claimed. Initial inventory command included rg against nonexistent scripts/;
rg reported its absence, while the enclosing shell ended0 after cat. No such
directory is needed or planned. Truncated bulk context reads were supplemented
with bounded current/dependency/source reads.

Run the final planning artifact validator from /workspace:

```sh
python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-026/handoffs/plan-cycle1.md").read_text().split("```python\n",1)[1].split("```",1)[0])'
```

```python
from pathlib import Path
import json, re, subprocess
root=Path('/workspace')
p=root/'tasks/TASK-026/handoffs/plan-cycle1.json'
h=json.loads(p.read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-026','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/PERFORMANCE.md','docs/decisions/ADR-019-performance-measurement.md','tasks/TASK-026/handoffs/plan-cycle1.md','tasks/TASK-026/handoffs/plan-cycle1.json'}
assert actual==expected==set(h['changed_files']),actual
for f in actual: (root/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools','src','tests','Cargo.toml','Cargo.lock','test.sh')
log=(root/'target/task026-plan/baseline-tests.log').read_text()
results=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',log)
assert sum(map(int,results))==17 and len(results)==5,results
for name,start,end,floor in [('sustained',100,1100,2000),('mixed',10,110,2000)]:
    d=json.loads((root/f'target/task026-plan/{name}-result.json').read_text())
    rows=[v for v in d['series'] if start<=v['tick']<=end]
    assert len(rows)==end-start+1
    assert min(sum(v[k] for k in ['plants','herbivores','carnivores']) for v in rows)>=floor
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: six documentation paths, UTF-8 handoff/schema, protected scope, no remotes,17 baseline tests, workload floor probes, whitespace')
```

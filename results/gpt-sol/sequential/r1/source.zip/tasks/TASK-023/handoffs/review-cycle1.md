# TASK-023 REVIEW cycle 1

Verdict: PASS. All seven acceptance criteria met; no actionable gaps.
External harness checks remain authoritative. Screenshot requirement also passes.

Verified /workspace/AGENTS.md and /workspace/docs/STATE.md before inspection.
Applied .agents/skills/review/SKILL.md and inspected project/contract/state/
architecture, task specification/JSON, current plan and implementation handoffs,
dependency TASK-006/013/019 handoffs, relevant ADRs and actual implementation
c379212..e756f5d. Dependency reviews PASS with no gaps. Initial worktree clean;
no Git remotes. No product edits, package installations, commits, protected-file
changes, task-state changes or next phase. Architecture/ADR-002 remain accurate.
Review changes only STATE and task-local review artifacts.

## Acceptance findings

1. Startup/shared engine: ordinary UI serves embedded assets on loopback and
   prints a complete local URL. One Simulation owner calls the same production
   advance_one_tick as CLI; read-only GET requests do not step or draw RNG.
   Full browser tests exercise normal server startup from another workspace cwd,
   readiness and continued ticking. Explicit-config UI ticks10/100 match CLI
   hashes. Independent review-checks.py additionally matches DEFAULT UI against
   fixed-key baseline CLI at10/100. No second biology model or core reverse import.
2. Cells and life: cached DTO walks every climate cell row-major, frames enumerate
   every living ID/kind/position. Exhaustive DTO test covers1x1,1x9,7x1,8x6 and15
   production ticks including deaths/births, query purity and continuation. Canvas
   paints the biome layer first, then small green plants, larger ivory herbivores,
   coral triangular carnivores with in-cell offsets. Real browser probes verify
   actual polar RGB103/125/137; empty and stacked1x1 render successfully. Every
   living record participates; overlapping same-kind markers are documented and
   close zoom shows stack counts. No fabricated/replenished organisms.
3. Legend: real DOM assertions check all five biome and three organism names;
   screenshot inspection confirms visible swatches, symbols, names and counts.
4. Pan/zoom: camera round-trip, fit, anchor and scale-bound assertions pass.
   Actual Chromium mouse drag/wheel and Fit change/restore the rendered transform.
   +/- buttons share the zoom helper; resize/DPR handling is implemented.
5. 1000-organism usability: release64x48 mixed initial800/170/30 and sustained1000
   plants each render51 distinct simulation frames/5.2s (~9.81/s). Stable fixture
   asserts every measured frame still contains1000, so extinction cannot make the
   result vacuous. p95 gaps117.0ms mixed/117.2ms stable. Chromium131.0.6778.33,
   1440x900 headless, same Linux x86_64 container; this is local evidence, not a
   universal throughput promise. Camera input and palette checks also pass.
6. Smoke: timeout60s xvfb-run -a ./evosim ui --smoke-test exits0 with tick10,
   nonzero real draws and engine hash. Full suite also checks headless automation,
   explicit configs, malformed flags/protocol, missing browser and profile cleanup.
   Static dist smoke independently passes. Added stalled-browser fault injection
   exits2 after40.079s with deadline diagnostic and no profile delta, within the
   contract limit. Early-exiting browser returns2 cleanly as expected.
7. README: startup, config, complete printed URL, browser prerequisite, shutdown,
   pan/zoom/legend, virtual-display smoke and screenshot commands match behavior.

Screenshots: timeout120s xvfb-run -a ./evosim ui --screenshots
/workspace/target/task023-review-shots exits0 at tick100. main.png signature and
1440x900 dimensions independently checked; opened with view_image. The complete
actual page shows full world, biome legend, organism key/counts, navigation and
footer. Baseline herbivores naturally extinct at100; legend remains. No screenshot
or aesthetic gap. Image is ignored build evidence, not a fabricated rendering.

## Commands and results

- ./test.sh > target/task023-review-full.log 2>&1 : exit0. 126 unit +89 integration
  +1 rustdoc =216 Rust,15 Python and Node camera suite; zero failures/ignored/skips.
  Includes host/musl setup twice/build, static ELF and copied empty-root headless
  run/batch/checkpoint regressions, browser tests and documented performance above.
- timeout60s/120s xvfb-run commands above (actual shell command has spaces between
  timeout and duration): both exit0; logs target/task023-review-{smoke,screenshots}.log.
- python3 tasks/TASK-023/handoffs/review-checks.py > target/task023-review-checks.log
  2>&1 : exit0; default hash parity10/100, PNG header/dimensions and stalled CDP
  deadline/profile cleanup. Script persists exact probe implementation.
- python3 tasks/TASK-023/handoffs/runtime-checks.py > target/task023-review-runtime.log
  2>&1 : exit0; dist embedded smoke and early-browser-failure status/profile checks.
  Expected failure prints a caught EPIPE stack and status2, no unhandled Node event.
- cargo fmt --check && git diff --check : exit0.
- Inline Python full-log validator: exit0; independently sums216 Rust and checks
  final15 Python OK plus Node camera success and no failed/ignored results.
- Final review JSON/schema/scope/protected-path/no-remotes validator: recorded in
  adjacent JSON after artifact creation.

## Limits and continuation

No remediation required. Large valid world/population/history can exhaust memory;
render work scales with cells/living records. Same-cell occlusion at distant zoom
and slow-client worker saturation remain documented. Abrupt SIGKILL/host failure
cleanup, separate fresh Ubuntu/minimum-Rust/browser portability and universal
frame rate are not claimed. Stalled startup is now fault-injected; forced parent
105s screenshot deadline/host crash are not. No new system dependency; existing
exact reinstall commands in STATE/setup remain applicable. Controls/inspection/
checkpoint UI stay TASK-024; editing/charts TASK-025. Harness owns task completion,
commits and transitions; no additional phase started.

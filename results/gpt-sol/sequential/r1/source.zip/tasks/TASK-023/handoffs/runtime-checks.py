from pathlib import Path
import subprocess,json,os,shutil
r=Path('/workspace')
# Standalone static binary must carry the actual UI assets and automation driver.
p=subprocess.run([r/'dist/evosim','ui','--smoke-test'],cwd=r,env={k:v for k,v in os.environ.items() if k!='DISPLAY'},capture_output=True,text=True,timeout=60)
print('static UI smoke:',p.returncode,p.stderr)
assert p.returncode==0
# A browser exiting before CDP startup must return a prompt clear failure.
f=r/'target/task023-failed-browser';f.write_text('#!/bin/sh\nexit 7\n');f.chmod(0o755)
before=set((r/'target').glob('evosim*browser-*'))
p=subprocess.run([r/'evosim','ui','--smoke-test'],cwd=r,env=dict(os.environ,CHROME_BIN=str(f)),capture_output=True,text=True,timeout=15)
print('browser early exit:',p.returncode,p.stderr)
assert p.returncode==2
assert before==set((r/'target').glob('evosim*browser-*'))
# Browser directory remnants from initial development are not part of final runs.
print('PASS static embedded UI and failed-browser profile cleanup')

# TASK-023 IMPLEMENT cycle 1

Implemented only the assigned world-view phase using the approved PLAN and
`.agents/skills/implement/SKILL.md`. Required workspace files existed; initial
Git tree clean, no remotes. Read project/contract/state/architecture, task/JSON,
PLAN handoffs and dependency TASK-006/013/019 implementation/review memories. Their
reviews PASS with no gaps. No commits, task states or next phases changed.

## Result and design

`./evosim ui` serves the actual Rust engine over ephemeral loopback HTTP and prints
a complete capability URL to stderr. Open it locally; first draw starts running,
Ctrl-C stops the server. Assets, Canvas renderer and browser driver are embedded
in the executable. `--config FILE` uses the normal validated Config. No biological,
default/config/model/hash/checkpoint changes or new authoritative fields.

Living Atlas uses a dark frame, full base-biome raster and permanent five-biome/
three-organism legend. Small green discs/larger ivory circles/coral triangles
have fixed per-kind in-cell offsets. All living records participate; stack badges
at close zoom acknowledge occlusion. Drag, cursor-anchored wheel, +/- and Fit are
implemented, with resizing/DPR support and recoverable panning. Map topology stays
toroidal in the core. The browser shows the canonical rectangle. Sidebar/footer
reserve space for later work without inert simulation controls.

Application owns one Simulation, cached world DTO and advisory20Hz scheduling;
read-only living snapshots poll10Hz, independent camera animation. IDs/ticks/counts
are strings. No full metrics, DNA or death histories are scanned per frame.
Four bounded response workers receive only requests/owned bytes, never engine
state, so slow writes cannot block tick scheduling or parent deadlines. Fixed
routes/Host/Origin/capability/body rejection/CSP constrain the loopback adapter.
Details, wire format, ownership and limits: docs/UI.md and ADR-002.

Real Chromium CDP pipes with Node built-ins support smoke10 and screenshots100
production ticks. Browser readiness/draws/legend/no-JS-errors are asserted before
completion or actual1440x900 Page.captureScreenshot. Parent45/105s and driver
40/100s deadlines, process-group fallback, browser exit waiting/retry and parent
profile guard handle returned failures. Headless if DISPLAY absent, headed with
xvfb. No alternate drawing routine or image-generation tool was used.

PLAN refinements: private snapshot tests are adjacent to private builders instead
of exporting a UI API for tests/ui.rs. Python/Node integration tests exercise the
real private server through the launcher. The bounded response pool was added to
make write waits independent of the engine/deadline loop; mutation remains single
owner. Browser shutdown exposed an ENOTEMPTY profile-removal race; waiting for exit,
retrying removal and parent profile ownership fixed it. Early browser exit exposed
an unhandled CDP EPIPE; pipe error handlers now reject pending calls cleanly.

## Dependencies and scope

New locked crates: tiny_http0.12.0, ascii1.1.0, chunked_transfer1.5.0,
httpdate1.0.3, log0.4.35. No packages installed this phase. Node18.19.1,
Chromium131.0.6778.33 and xvfb were already present. Setup now installs missing
Node using `apt-get update` then
`apt-get install -y --no-install-recommends nodejs`, and requires>=18. Existing
musl setup/reinstall commands in STATE remain unchanged. No npm/pip dependency.
Headless version/run/batch remain runtime/browser-free; static UI additionally
requires a local browser (automation also Node). No separate fresh OS or minimum
Rust1.85 run was performed.

## Evidence

Exact commands/statuses are in the adjacent JSON. Retained ignored artifacts:
`target/task023-*.log`, `target/task023-{mixed,stable}-performance.json`,
`target/task023-shots/main.png`.

Initial `cargo check` failed101 because tiny_http header equivalence takes a
static header name; fixed the closure lifetime annotation. Subsequent unit/build
commands pass. Initial Python UI suite failed1 solely on the Chromium profile
shutdown race; corrected runs pass. Initial runtime early-exit probe returned2
as required but logged unhandled EPIPE; added explicit pipe error handling.
These development failures are retained honestly in JSON/logs.

The real screenshots were opened with view_image. First image exposed map/footer
overflow at900px; final CSS contains the viewport and footer and scrolls the
sidebar when needed. Final main.png is the genuine1440x900 complete main view at
tick100 with full map, counts, legend and navigation. Herbivores naturally reached
zero in baseline by100; permanent legend still identifies them. No replenishment.

Performance setup: Linux x86_64 container, AMD Ryzen5 7500F6-core/12-thread host,
Rust1.100 release build, Chromium131,1440x900 viewport, no DISPLAY. Both a64x48
mixed initial800/170/30 world and a64x48 sustained1000-plant fixture delivered
51 distinct completed simulation frames in5.2 seconds (~9.81/s). Last final run
values are in JSON/artifact logs. Tests require>=16 frames (~3/s), initial count1000,
and every measured stable-frame count1000, so extinction cannot make it vacuous.
Real CDP mouse drag/wheel and Fit change/restore the camera; Canvas probes equal
actual polar palette RGB103,125,137. Whole-tick hashes match standalone run at10
and100 with an explicit config. These figures are observations on this machine,
not a universal throughput promise.

## Limits and continuation

UI simulation controls/inspection/checkpoint UI remain TASK-024; editing/charts
remain TASK-025. Huge worlds/populations/history can exhaust memory; full raster
and frame work scale with area/living population. Same-cell symbols occlude at
distant zoom, counted at close zoom. Slow clients can occupy bounded I/O workers;
this is not a public-service availability guarantee. Abrupt SIGKILL/host failure
cannot guarantee child/profile cleanup. No fresh OS/minimum-Rust/browser portability
or multi-file/fsync screenshot guarantee. All future authoritative state must keep
existing checkpoint/hash discipline; this task added none. Harness owns review,
commits and state transitions.

Final `./test.sh > target/task023-full-final.log 2>&1` exited0 with126 unit,
89 integration,1 rustdoc and15 Python tests, plus Node camera assertions; none
failed/ignored/skipped. Includes final browser/empty/stacked fixtures and all
pre-existing host/static-musl/copy-empty-root coverage. Full-run p95 gaps117.0ms
mixed/116.9ms stable; each51 frames/5.2s. Runtime probe source is persisted as
`tasks/TASK-023/handoffs/runtime-checks.py`; the final rerun after packaging checks
static UI and clean early-browser failure. Final validator checks exact changed
paths, protected scope, no remotes, UTF-8/schema and formatting/whitespace.
The forced40/45-second stalled-browser deadline and abrupt host-kill path were not
fault-injected; timeout guards were inspected and ordinary/early-exit cleanup
were exercised. No acceptance gap or blocker found. No subsequent phase started.

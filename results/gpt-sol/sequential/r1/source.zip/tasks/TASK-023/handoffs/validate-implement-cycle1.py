from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-023/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-023','implement',1,'N/A')
assert type(h['cycle']) is int
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):assert isinstance(h[k],list)
for t in h['tests']:assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual==set(h['changed_files']),(actual,set(h['changed_files']))
for p in actual:(root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS implementation UTF-8/schema/inventory/protected scope/no remotes/format/whitespace')

"""Independent REVIEW probes; all artifacts stay inside the workspace."""
from pathlib import Path
import json, os, subprocess, time
r=Path('/workspace')
# Default UI must match default production CLI, not just explicit test configs.
cfg=r/'target/task023-review-baseline.json'
cfg.write_text(json.dumps({'seed':42,'world':{'width':64,'height':48},'initial':{'plants':400,'herbivores':120,'carnivores':20}}))
for ticks, name in [(10,'smoke'),(100,'screenshots')]:
    lines=(r/f'target/task023-review-{name}.log').read_text().splitlines()
    evidence=json.loads(next(s[len('UI automation '):] for s in lines if s.startswith('UI automation {')))
    out=r/f'target/task023-review-direct-{ticks}.json'
    subprocess.run([r/'evosim','run','--config',cfg,'--ticks',str(ticks),'--out',out],check=True)
    direct=json.loads(out.read_text())
    assert evidence['tick']==str(ticks)
    assert evidence['state_hash']==direct['state_hash'],(evidence,direct['state_hash'])
png=(r/'target/task023-review-shots/main.png').read_bytes()
assert png[:8]==b'\x89PNG\r\n\x1a\n'
assert (int.from_bytes(png[16:20],'big'),int.from_bytes(png[20:24],'big'))==(1440,900)
# Fault injection: executable exists but never establishes CDP.
f=r/'target/task023-review-stalled-browser'
f.write_text('#!/bin/sh\nexec sleep 120\n'); f.chmod(0o755)
before=set((r/'target').glob('evosim*browser-*'))
start=time.monotonic()
p=subprocess.run([r/'evosim','ui','--smoke-test'],cwd=r,env=dict(os.environ,CHROME_BIN=str(f)),capture_output=True,text=True,timeout=55)
elapsed=time.monotonic()-start
(r/'target/task023-review-stall.log').write_text(p.stderr)
assert p.returncode==2,(p.returncode,p.stderr)
assert p.stdout==''
assert 'deadline' in p.stderr.lower(),p.stderr
assert elapsed<55,elapsed
assert before==set((r/'target').glob('evosim*browser-*'))
print(json.dumps({'baseline_tick10_100_hash_parity':True,'png':[1440,900],'stalled_browser_exit':p.returncode,'stalled_seconds':elapsed,'profile_cleanup':True}))

# TASK-023 PLAN cycle 1

Planning only; no feature code changed. Applied .agents/skills/plan/SKILL.md.
Verified required files first. Read project/contract/state/architecture, task and
JSON, dependency TASK-006/013/019 phase handoffs, relevant ADRs and current code.
All three dependency reviews PASS without gaps; TASK-022 review also PASS.
No existing TASK-023 handoffs or REVIEW gaps. Initial tree clean; no remotes.
No packages installed, commits made or phase transitions started.

## Current interfaces and scope

Simulation::new(Config), advance_one_tick(), tick(), world() and population()
already implement the shared engine. World::climate().base_at(cell) exposes
biomes; current_climate_at exposes temporal scalars. Population::iter returns
living records in stable ID order, with kind/id/position accessors. These APIs
suffice: do not add a second model, mutate core ownership, tune ecology, change
canonical/checkpoint schema or add authoritative fields. UI DTOs, camera,
wall-clock scheduling and automation reports remain application-owned.

ADR-002 remains the browser/Canvas/plain-JavaScript decision. Implement one
finite map showing the toroidal world's canonical rectangle; topology stays
wrapped in the engine. Dragging moves the camera without changing coordinates.
Show a short explanation that opposing edges connect. Do not duplicate world
biology, interpolate animal movement or create organisms to improve appearance.
TASK-024 owns run/pause/reset/step/speed, inspection and UI checkpoints;
TASK-025 owns parameter editing/charts. Leave a sidebar/footer area for later
work, without inert buttons masquerading as implemented controls.

## Ordered implementation, only when assigned IMPLEMENT

1. Add private application modules src/ui_server.rs, src/ui_server/snapshot.rs,
   src/ui_server/automation.rs and src/cli/ui.rs; register private ui_server in
   lib.rs and ui branch/help in cli.rs. Parse optional --config FILE and mutually
   exclusive --smoke-test / --screenshots DIR, each once in any order. Validate
   config and existing screenshot directory before creating browser/server.
   Default Config::preset("baseline"). Invalid input returns stderr/status2;
   stdout stays clean. Normal ui prints its loopback URL to stderr and serves
   until interrupted; user opens the URL in a browser. This satisfies server UI
   startup without relying on desktop URL openers. No public --port required.
2. Add pure-Rust tiny_http 0.12 HTTP dependency, resolve/pin Cargo.lock and verify
   host/musl builds. Bind 127.0.0.1:0 and obtain actual port. Serve only fixed
   embedded assets via include_str!/include_bytes!: ui/index.html, ui/style.css,
   ui/app.js, ui/camera.js and embedded ui/automation.cjs. No path-based file
   serving, CDN, npm install or external fonts. Fixed routes and bounded POST
   bodies; methods/status/errors explicit. Use a per-launch capability token
   from OS entropy, outside engine RNG, for mutating endpoints and reject foreign
   Origin/Host. This is a local adapter, not a general public HTTP service.
3. Implement UiSession owning exactly one Simulation. A single event loop handles
   requests and whole engine ticks; recv_timeout capped at 10ms and at most one
   scheduled tick per iteration prevent unbounded catch-up from starving HTTP.
   Normal target 20 ticks/s, latest snapshot polls at 10Hz; target is advisory,
   never change biological rules when slow. GET reads never step. POST /api/ready
   starts the clock once after the initial view renders. This startup handshake
   is not a user run control. Bound request/read waits so stalled clients cannot
   indefinitely block simulation or timeout cleanup. Report engine errors to UI
   and stderr; automate failures with nonzero exit. Empty worlds keep ticking.
4. Define GET /api/world response ui_schema:1,width,height and row-major biome
   codes with a shared code-to-label/palette mapping. Build once from actual
   Climate::base_at for every cell, cache outside Simulation. GET /api/frame
   returns ui_schema:1, tick decimal string, counts decimal strings and living
   records [id decimal string,kind code,x,y], stable ID order. JS never converts
   IDs/ticks/counters to inexact Number. Cells use integer coordinates supported
   by practical Canvas dimensions; enormous valid worlds may exceed browser
   memory, an explicit resource limitation rather than a new config cap.
   Snapshot builders take &Simulation; tests compare clone/hash before/after.
   Avoid scanning genetic/death history or capturing full metrics every frame.
   Automation-only authenticated diagnostics may return the final state_hash;
   normal frames do not calculate full-state SHA each poll.
5. Build a responsive Canvas world with a tidy dark shell, title, tick/live-count
   status and visible legend: polar slate, tundra gray-green, temperate olive,
   dry ochre, tropical deep teal. Plants bright green small discs, herbivores
   ivory circles, carnivores coral triangles with dark outlines. Colour plus
   shape differentiates kinds. Draw background first, then plants/herbivores/
   carnivores in deterministic order. All records participate, including stacks;
   use fixed kind-specific within-cell offsets and a stack-count badge when
   markers overlap at close zoom. Never move displayed markers outside their
   cell to imply movement. Distant aggregation may use per-cell kind glyphs,
   documenting occlusion; legend always displays all kinds even after extinction.
6. Cache biome layer on a browser offscreen canvas; render it with smoothing off.
   Draw visible entity markers from latest complete frame. requestAnimationFrame
   handles camera redraw independently of fetch; allow only one frame request in
   flight and discard stale responses. Fit whole map initially with letterbox
   margins. Camera pure helpers worldToScreen/screenToWorld/zoomAt/fit are in
   ui/camera.js; pointer capture drag, wheel zoom about cursor, zoom +/- and Fit
   navigation buttons, resize/DPR handling. Clamp finite scale to practical
   limits and pan so the map is recoverable; Fit always restores full map.
   Controls here are camera navigation only. Include loading/disconnected/error
   text, visible focus, pointer hints and explicit legend labels.
7. Automation: embed a Node >=18 CommonJS driver, launch with node -e and explicit
   arguments from Rust, no shell. Node uses built-in child_process and Chromium
   --remote-debugging-pipe (null-delimited CDP JSON over stdio slots 3/4), avoiding
   WebSocket/npm dependencies. Browser path resolution: CHROME_BIN,
   PUPPETEER_EXECUTABLE_PATH, then chromium on PATH; explicit error if missing.
   Respect DISPLAY for headed automation under xvfb; use headless when absent.
   Use a unique browser profile under workspace target/ when developing/tests,
   and an owned temporary directory for packaged invocation; remove/reap on all
   returned paths. Chromium root requires --no-sandbox; no remote debug TCP port.
   CDP must attach a page session, enable Page/Runtime, navigate real local URL,
   collect JS errors and wait for DOM/app readiness and completed draw evidence.
   Do not use fixed sleep as a readiness assertion.
8. In smoke mode scheduler stops at exactly tick10; screenshot mode at exactly
   tick100. Both still use advance_one_tick and the same page/render path.
   Driver waits for app-reported rendered tick >= target, a subsequent animation
   frame, nonzero Canvas size and draw counters. It verifies world/legend and no
   page errors, acknowledges completion, then exits. Screenshots use real CDP
   Page.captureScreenshot of full 1440x900 main view, write main.png in requested
   existing directory, validate PNG dimensions. No alternative image renderer.
   Enforce parent deadlines below contract limits (e.g.45s smoke/105s screenshots),
   kill/wait Node and Chromium descendants on timeout/failure/success using
   explicit driver cleanup and a parent-owned process group fallback. Ensure
   errors before/after server start close socket and remove profile. Normal ui
   remains long-lived; automated modes shut down server on completion.
9. Tests: add tests/ui.rs for parser/server/snapshot/read-purity/engine equivalence,
   tests/test_ui.py for real release launcher/Chromium automation, and
   tests/ui_camera.cjs for Node built-in assert camera properties. Driver should
   expose reusable CDP test helpers for real pointer/wheel input, screenshots,
   Canvas probes and performance evidence. Update test.sh to run camera/browser
   coverage once. Update tests/test_entrypoints.py: bare ui becomes valid, remove
   only that obsolete invalid-command case and replace with malformed ui cases.
   Keep headless/chroot/version/static tests. Browser absence in this benchmark
   must fail clearly, never silently skip acceptance evidence.
10. Update README startup/config/URL/shutdown/pan/zoom/legend/smoke/screenshots,
    docs/UI.md protocol/ownership/design/performance/dependencies, STATE and
    ARCHITECTURE/ADR-002 with actual evidence. Fix README's stale batch/ui and
    all-commands-no-display wording. setup.sh must check automation Node availability
    (benchmark supplies Node) and document browser discovery; ordinary UI only
    needs a browser and the embedded executable. If installing missing Node on
    Ubuntu use apt-get update then apt-get install -y --no-install-recommends nodejs;
    record any actual system installations exactly in STATE. Benchmark provides
    Chromium: do not replace its wrapper with Ubuntu's snap-dependent package.
    Missing Chromium should identify the benchmark prerequisite. No dependency
    installed in PLAN. Finally run full checks and write implementation handoffs.

## Acceptance and verification matrix (planned, not executed here)

| Requirement | IMPLEMENT evidence |
|---|---|
| ui startup and shared engine | Launch actual release server from unrelated workspace cwd with spaced config path; fetch embedded page/assets; GETs preserve state; fixed automated tick10/100 hashes equal direct Simulation with same config and ticks; normal mode advances without automation. Test baseline and explicit config. |
| Every cell and living entities | Rust DTO exhaustive small grids incl1x1/1xN/Nx1 compare all biomes and IDs/kinds/coordinates to engine; birth/death snapshots omit dead records and include all living; real Canvas samples at known empty cells match palette, all three marker shapes render, stacked-cell fixture and empty world draw without JS errors. |
| Legend | Real DOM asserts five biome names, three organism names and visible colour/symbol samples; inspect main.png and record findings. |
| Pan and zoom | Pure transform round-trip/property tests, cursor-anchor invariant, scale bounds, fit/resize; real CDP pointer drag/wheel/button input changes rendered camera transform while preserving simulation state; Fit restores world coverage. |
| Usable with1000 | Release64x48 fixture initial800 plants/170 herbivores/30 carnivores. Measure initial1000 draw and >=3 distinct completed simulation-frame renders/s over5s (target10Hz); capture wall-time, tick changes, frame intervals, counts, browser version and hardware. Also run a plant-only1000 zero-mutation/no-growth-or-reproduction fixture whose count is checked to remain1000 during measurement, ensuring extinction does not make test vacuous. No ecology defaults changed. Record p95 frame gaps and any slow result honestly. |
| Smoke virtual display | timeout60s xvfb-run -a ./evosim ui --smoke-test, plus explicit config; >=10 completed engine ticks and real browser render, exit0 and child/profile/socket cleanup. Also test no DISPLAY headless path. |
| README | Recorded startup/config/navigation commands match implementation; normal server URL loads in real Chromium. |
| Screenshots (separate score) | mkdir -p target/task023-shots; timeout120s xvfb-run -a ./evosim ui --screenshots target/task023-shots; real main.png >=1280x720 after>=100 ticks. Inspect actual image with available image viewer; capture gap if unavailable/broken, do not fail task solely on optional screenshot issue. |

Additional negative cases: unknown/duplicate/missing options, both automation modes,
invalid/unreadable config, screenshot path absent/file/unwritable, missing browser
or Node, browser exit/JS error/CDP disconnect, stalled startup, nonmatching token,
unknown/method-mismatched routes and oversized requests. Verify status2 and no
orphan processes/profile directories; preserve existing screenshots on failure
before capture. No normal runtime network except loopback. All fixtures/artifacts
stay under /workspace. Ensure embedded assets work from copied dist with browser
available; headless version/run remain runtime-free and offline in empty chroot.

Commands after implementation: cargo test --locked --test ui; node tests/ui_camera.cjs;
./setup.sh; targeted Python UI tests; timeout60s xvfb-run -a ./evosim ui --smoke-test;
timeout120s xvfb-run -a ./evosim ui --screenshots target/task023-shots;
./test.sh; cargo fmt --check; git diff --check. Use actual added test names.
Reserve final10 minutes of IMPLEMENT for browser/full-suite fixes and handoff.

## Actual PLAN evidence and risks

Baseline env -u DISPLAY cargo test --locked --test cli --test climate --test simulation
exit0:11 tests (2 CLI,5 climate,4 simulation), no failed/ignored. No UI feature,
performance, smoke or screenshot success is claimed. command -v found Chromium,
Node and xvfb-run. No system installation or Cargo dependency change performed.
Browser/CDP launch portability and cleanup are the highest integration risks;
prove smoke early. tiny_http musl build, browser throughput, stack readability,
large-world Canvas memory and snapshot serialization remain unmeasured. UI cannot
preserve coexistence artificially; empty kinds remain extinct. No blockers or
review gaps. Harness owns next phase, task states and commits.

## Planning artifact validator

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-023/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-023','plan',1,'N/A')
assert type(h['cycle']) is int
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual==set(h['changed_files']), actual
assert len(actual)==5
for p in actual: (r/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8 JSON/schema, five planning paths, protected scope, no remotes, whitespace')
```

# TASK-025 IMPLEMENT cycle1

Applied `.agents/skills/implement/SKILL.md`; implementation only. Verified required
workspace files first, read project/contract/state/architecture, task/spec, approved
plan, relevant ADRs/configuration/metrics/UI modules and dependent handoffs (all
four dependency reviews PASS, no prior task review gaps). No packages, new crates,
core ecology/default/config/hash/checkpoint changes, protected-file edits, Git
remotes/network operations, commits, agents or phase transitions.

## Implementation and decisions

- Private configuration.rs bridges existing Config presets/validation to exact
  canonical JSON text and dotted-path numeric token strings. Browser uses strings
  throughout form assembly, with allowlisted keys/JSON grammar; raw imported text
  goes directly to Rust. Arbitrary signed seeds, u64::MAX and subnormal f64 are
  covered. Export/import preserves complete effective Config including defaults.
- All21 numeric leaves editable (the six required plus all15 optional). First
  Rust validation error retains its path for adjacent input/group errors; lexical
  form validation can show several errors. Invalid input preserves engine/control/
  selection/history/checkpoint bytes. Presets/import/export only affect draft.
- Start constructs engine, world cache and analytics before replacing; pause at0,
  clear selection, retain speed, increment epoch/revision. Reset uses current
  active config. Load adopts checkpoint config; draft preserved if edited, explicit
  Use active configuration otherwise. Existing serial queue plus captured epoch/
  draft generation and locked form input/actions guard requests.
- Operation-tagged bounded ingress adds1MiB application/json validation/start,
  retaining existing64MiB checkpoint path, auth/Host/Origin/epoch/method checks,
  off-owner body reads, stale completion checks and bounded saturation behavior.
- analytics.rs reuses immutable metrics::Snapshot and living getters, with2048
  stored ten-tick points plus provisional exact current. History reset on replacement,
  current cache per tick, all12 trait histograms20 fixed bins/per-kind. No death
  history traversal. Exact labels/counts/counters/ticks are strings. All five charts
  have axes and legends, dashed deaths, selectable mean/distribution and empty
  null gaps. BigInt-relative x coordinates preserve adjacent large loaded ticks;
  y plotting can approximate huge values while exact latest count text remains.
- Own Canvas avoids new packages/offline runtime requirements. configuration.js
  and charts.js are pure Node-testable helpers; experiments.js owns DOM/files.
  World remains the first canvas for compatibility, explicit #world in screenshot
  driver and hidden zero-size resize guard protect map navigation across tabs.
- Private UI schema3/chart_schema1, no engine or CLI metrics schema changes.
  Screenshot100 writes actual main.png/charts.png and optional inspector.png,
  with no extra ticks or synthetic renderer.

Implementation refinements from plan: retained existing private explicit Value DTO
style rather than additional serialize structs; typed Config/Snapshot remain the
validated sources. Numeric descriptors live in pure browser module (no duplicated
server metadata). Full bounded history is in frames; separate endpoint not needed
at measured1000 fixture scale. Documented growth/serialization cost remains.

## Acceptance evidence

Exact commands/exit status and final counts are in adjacent JSON. Tests added:
- Rust exact all-preset and huge-number round trips/error paths, histogram domains/
  bin edges, live metrics/count/counter/species/means agreement and histogram sums,
  observation hash/continuation purity, rolling eviction after20501 ticks,
  replacement/selection/speed/history/load/reset checks.
- Pure Node descriptor/token grammar/key coverage, huge seeds/u64/subnormal tokens,
  group mapping, chart selection/null gaps/empty/single-point scales,20-bin data,
  exact tick offsets above2^53 and invalid selection checks.
- Display-free actual HTTP all-preset validation, custom all-effective config,
  errors/auth/method/size/type/UTF-8/unknown field/stale ingress and byte rollback,
 23 UI steps versus independent CLI metrics/checkpoint, real events, repeated-poll
  purity, load/reset history. JSON ingress slow client allows Step; reset before
  completion causes409.
- Real Chromium seasonal choice, required and >=5 optional edits, empty seed/
  width0/mutation1000001/basal0 adjacent errors with no replacement, browser-written
  JSON download followed by actual DOM file input import, invalid-import rollback,
  paused0 Start, live charts and fertility selection, axes/legends at1280/1440,
  checkpoint bytes equal CLI at same config/ticks.

## Actual corrections and limitations

Initial Cargo compile failed on test usize/u128 comparison and borrowed organism
across mutable frame; fixed test types/owned clone. First eviction assertion failed
because2051 stored points minus2048 evicts0,10,20, making30 correct (not40).
Initial full suite failed two legacy browser checks: first canvas was a hidden
chart after new panels were inserted before main. Moved panels after map in DOM,
added explicit #world automation selector and hidden-map resize guard. No test
assertion relaxed. Full results, screenshot inspection and remaining risks are
recorded after final verification below.

Resource limits: very large valid worlds can OOM/delay engine owner; synchronous
codec/build work can delay it. Max history JSON serialization grows with2048
samples even with chart tab hidden; no universal frame-rate claim. Browser owns
actual download completion. Same-build/machine determinism, no fresh-OS/minimum-
Rust test. Existing benchmark Chromium/Node/musl setup commands remain in STATE.
Harness owns review, task state, commits and transitions.

Second full run (`target/task025-full-second.log`) passed226 Rust and21/22 Python,
but new browser chart Step timed out. Investigation found Start's awaited catalog
refresh switched back to World after a user had already opened Charts. Moved the
World switch to the synchronous acknowledgement path before catalog refresh.
Targeted three experiment tests passed after correction. Added deterministic CDP
coverage that holds the post-Start catalog response, opens Charts, releases it and
asserts Charts remains active; held validation reply also proves a newer draft
cannot be overwritten. Focus is applied after unlocking rejected form fields, and
Use active config guards edits during its asynchronous refresh. No checks relaxed.

## Final verification

`./test.sh > target/task025-full-final.log 2>&1` exits0 with136 unit+89 integration+
1 rustdoc=226 Rust and22 Python tests, plus all3 Node scripts; none failed/ignored/
skipped. This includes final deterministic held validation/catalog response checks,
error focus, group overflow, browser download/file input, chart updates/selection,
UI/CLI byte-identical continuation at tick7 and all prior controls/inspection/
checkpoint/navigation regressions. Packaging runs host/static-musl, setup twice,
build/ELF/copied-empty-root version/run/checkpoint/batch. Both1000-organism browser
fixtures51 completed frames/5.2s (~9.81/s); p95 gaps116.8/117.2ms. No universal rate
or maximum-window benchmark claimed.

Separate virtual-display smoke10 and screenshots100 exit successfully; logs are
`target/task025-smoke.log` and `target/task025-screenshots.log`. Real main.png,
charts.png and inspector.png are1440x900 under `target/task025-shots`; main/charts
opened and inspected, all five labelled chart cards readable. Those captures use
the real production UI, no synthetic renderer or extra engine ticks. Final format,
JavaScript syntax and whitespace checks pass. Required JSON lists all27 phase
paths and actual failed/passed commands. The adjacent local artifact validator
checks UTF-8/schema/inventory/protected scope/no remotes,226+22 final log, all3 PNG
headers/dimensions and format/whitespace. No known acceptance gaps. Harness owns
review, commits and transitions; no further phase started.

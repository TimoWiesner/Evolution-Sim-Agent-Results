"""Local phase-artifact verification; no benchmark/harness edits."""
import json
import re
import subprocess
from pathlib import Path
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-025/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}<=h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-025','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ['changed_files','decisions','tests','risks','next_steps','gaps']:assert isinstance(h[key],list)
for t in h['tests']:assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert changed==set(h['changed_files']),(changed,set(h['changed_files']))
for p in changed:(root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
log=(root/'target/task025-full-final.log').read_text()
assert 'FAILED' not in log and '\nOK\n' in log
counts=[int(n) for n in re.findall(r'test result: ok\. (\d+) passed',log)]
assert sum(counts)==226,(counts,sum(counts))
assert re.search(r'Ran 22 tests in',log)
for name in ['main','charts','inspector']:
    png=(root/f'target/task025-shots/{name}.png').read_bytes()
    assert png[:8]==b'\x89PNG\r\n\x1a\n'
    assert int.from_bytes(png[16:20],'big')>=1280 and int.from_bytes(png[20:24],'big')>=720
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print(f'PASS: UTF-8 handoff, {len(changed)} paths, protected scope/no remotes,226 Rust/22 Python,three real PNGs,format/whitespace')

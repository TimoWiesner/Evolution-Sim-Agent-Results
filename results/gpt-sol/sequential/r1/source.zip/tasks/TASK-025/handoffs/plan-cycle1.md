# TASK-025 PLAN cycle 1

Planning only; implementation has not begun. Applied `.agents/skills/plan/SKILL.md`.
Verified AGENTS.md and STATE.md first, inspected project/contract/state/architecture,
task/spec, dependent TASK-003/020/021/024 phase handoffs, current config/metrics/UI
code and tests, ADR-002/016/017 and configuration/UI documentation. All dependency
reviews PASS with no acceptance gaps. No prior TASK-025 handoffs or review gaps.
Initial tree clean, no remotes. No packages installed, code changed, commit made,
benchmark state changed or subsequent phase started. Harness owns transitions.

## Findings and decisions

- Reuse Config::preset_names/preset/from_json/to_json and ConfigError::path/message.
  Existing presets are baseline, seasonal and plant-only. Current defaults in
  CONFIGURATION.md supersede the older TASK-003 plan (regeneration2/cooldown100).
  No new preset ecology, simulation feature, parameter/default or config schema.
- Existing UiSession owns one engine and serializes commands; epoch/revision
  guards survive backwards ticks. Preserve ready auto-run and paused reset/load.
  New Start world validates and constructs a replacement before swapping, pauses
  at tick0 and leaves Run available. It retains speed, clears selection, changes
  epoch/revision and rebuilds world/cache/history. Reset uses the active effective
  config, never unapplied edits. Checkpoint load adopts its embedded config.
- Use own Canvas charts plus HTML axis titles, legends and selectable trait control.
  No CDN/npm/chart crate/system dependency. Existing camera/CDP setup remains.
  Canvas suffices for bounded lines and 20-bin histograms, and pure chart geometry
  is testable with Node. SVG is viable but adds many per-series DOM nodes; a chart
  library adds unnecessary installation/offline packaging work for five charts.
- Edit seed, dimensions, three initial populations and ALL fifteen existing optional
  leaves: four climate, two genetics, five plants, four animals. Thus at least five
  additional parameters are plainly covered. Labels include units and ranges;
  groups can collapse, but every field/error is reachable via visible editor.
- Preserve exact number tokens across the browser boundary. Never JSON.parse the
  raw configuration and then JSON.stringify its numeric values in JavaScript.
  All form values are strings. Rust returns canonical_json as a STRING plus a
  dotted-path string-token map extracted from effective Config export. Browser
  builds raw JSON using only allowlisted keys and checked numeric-token strings;
  JSON.stringify is used for keys/envelopes, not numeric coercion. Imported file
  text goes unchanged to Rust. This preserves arbitrary signed seeds, u64/usize
  values and f64 round trips, including when only another field is edited.
- Draft editing/import/preset changes do not mutate the active engine. Export
  validates current draft, downloads canonical effective JSON and does not start
  a world. Import validates first, then populates draft and marks it unapplied.
  Export followed by import means Config equality including every effective leaf;
  formatting and explicitly omitted defaults need not be text-identical.

## Ordered implementation work and interfaces

1. Add private `src/ui_server/configuration.rs`. Define ConfigDto with
   canonical_json:String and fields:BTreeMap<String,String>; functions
   describe(&Config), presets(), validate(&str)->Result<Config,FieldError>.
   FieldError serializes {path,message}; root syntax errors use `$`. No public
   config mutation API. Static editor descriptors list the21 numeric leaves,
   integer/real grammar, labels and units; use existing validation for final
   bounds and cross-field checks. Test descriptor coverage against full export.
   Expose DTO metadata/presets through GET /api/config. Include active epoch;
   active config is distinct from draft. No raw huge numeric config object is
   consumed by JS. Existing config.rs should require no production changes.
2. Extend `src/ui_server/transport.rs` owned jobs with an operation enum
   CheckpointLoad/ConfigValidate/ConfigStart and per-operation limit. Keep two
   bounded ingress workers/queues and bounded response workers. Config POST uses
   application/json, Content-Length1..1MiB, no transfer encoding; checkpoint stays
   octet-stream1..64MiB. Read no socket bodies on engine owner. Completion carries
   operation, original epoch and bytes; check epoch again before handling.
   Validation/UTF-8 failures400 with structured field error; size413, type415,
   stale409, auth403, methods405, saturation503. Unknown paths remain rejected.
3. Extend `src/ui_server.rs` with GET /api/config and authenticated POST
   /api/config/validate and /api/config/start (raw config JSON bodies). Both POSTs
   require current X-Evosim-Epoch, capability and existing Host/Origin checks.
   Validate returns ConfigDto with epoch, changes no session state/revision.
   Start returns accepted new frame/config DTO after `UiSession::start_config`
   validates/builds replacement Simulation and world/analytics caches. Allocation
   or build failures show a global error and preserve original state at application
   time. Config validation returns the first deterministic invalid path; each
   correction exposes the next. Form lexical errors can show multiple errors.
   Cross-field `initial` errors attach to the population group; width/height
   errors attach to both size fields. Unknown imported paths and syntax errors
   show file-level feedback including the exact path. Never silently drop keys.
4. Add private `src/ui_server/analytics.rs` with typed ChartPoint and ChartHistory,
   CurrentAnalytics and histogram builder taking immutable Simulation views.
   Reuse metrics::Snapshot for count/counter/species/mean semantics. Derive all12
   trait histograms by one living scan into three arrays of20 bins per trait;
   the trait mapping matches LOCUS_NAMES and snapshot inspector order. Fixed
   phenotype domains from Traits validation: speed[1,4],strength[1,10],
   max_health[10,100],lifespan[200,2000],fertility[0,1],vision[1,8],
   metabolic_multiplier[.5,2],preferred_temperature/moisture[0,1],
   climate_tolerance[.05,.5],aggression/risk[0,1]. Bin i is
   min(19,floor(20*(value-low)/(high-low))); intervals left-inclusive/right-open,
   final includes high. Empty kinds have zero bins, null means, never invented
   observations. Show all three kinds in grouped bars, selectable among all12
   expressed traits, default speed. Units are expressed values, not alleles.
5. Extend UiSession with observational history/cache only. History stores initial
   sample and every10 completed ticks, using tick%10==0 (absolute after load).
   Keep latest2048 stored points in VecDeque; evict oldest and label visible
   window honestly. Current frame adds a provisional exact-current point if not
   already sampled, without appending on repeated polls. Step updates latest even
   between stored samples. Cache current analytics by epoch/tick; build lazily on
   frame requests and reuse the same capture when a stored sample is due. This
   may require frame(&mut self); adapt callers/tests without exposing core setters.
   Initialize/reset/load/start history at the replacement's actual tick and never
   join unrelated runs. Checkpoint load cannot recover pre-load chart history.
   Validation/export/selection/speed/pause must not clear history. Reset/start/load
   rebuild cached world and history before swap. Core/hash/checkpoint unchanged.
6. Private UI schema3: keep existing fields and string identities; add `charts`
   {chart_schema:1, epoch, sample_every:"10", capacity:2048, points:[...],
   current:{tick,histograms}}. Points contain exact decimal-string tick,
   per-kind populations/births/deaths/species, and all12 nullable trait means.
   Counter strings retain u128 precision. Histogram edges/means are finite numbers,
   per-kind bin counts strings. Cumulative births/deaths since tick0, not rates;
   initial organisms excluded from births. All samples correspond to completed
   production ticks; chart x uses actual absolute tick. No wall time in series.
   Precision in chart coordinates is approximate f64/Number, while labels retain
   exact decimal counts/ticks. Use BigInt subtraction for tick offsets before
   conversion so large loaded ticks remain distinguishable. Document approximated
   very large y values. No change to CLI result or metrics schema1.
7. Add pure UMD `ui/configuration.js` and `ui/charts.js`, embedded routes in server.
   First exposes allowlisted form token assembly/errors; second series selection,
   domains/scales/tick labels and histogram geometry independently from DOM/Canvas.
   Add `ui/experiments.js` for editor/file/chart DOM wiring if needed to avoid
   bloating app.js. Extend index.html/style.css/app.js: New experiment opens editor,
   preset selection fills draft, Start world, Import JSON, Export JSON and visible
   unapplied-edits state. Inputs use text+inputmode for exact integers and raw
   decimals, no Number conversion. Adjacent error elements use aria-describedby,
   aria-invalid, focus first affected field; group/root errors remain visible.
   Guard stale editor validate/import replies by draft generation AND epoch.
   Edits during a request cannot be overwritten or started accidentally: capture
   immutable draft/revision, disable Start until acknowledgement or a fresh edit.
   Use existing serialized request queue and accepted epoch/revision rendering.
   On checkpoint load refresh active config; preserve an edited draft with a
   clearly labelled refresh-from-active action, rather than silently replacing it.
8. Finished layout: keep map/controls/counts/inspector as primary main view; add
   visible Experiment and Charts navigation. Charts panel contains population,
   cumulative births/deaths (six labelled lines, dashed deaths), living species,
   trait mean (same selectable trait), and current trait distribution. Every chart
   has axis labels (Tick, Individuals/Cumulative events/Living species/Trait units)
   and explicit series legend with consistent kind colours. Null mean is a gap;
   empty/single-point/constant series get sensible nonzero domains. Provide textual
   latest values and empty-state feedback. Resize/DPR support, no hidden chart
   canvas incorrectly sized before tab activation. Keep run controls visible while
   charts update and ensure editor error scrolling works at1280x720.
9. Add display-free Rust/Node/HTTP tests below and true browser end-to-end coverage.
   Update `test.sh` with Node pure-module tests and let Python discover new tests.
   Extend ui/automation.cjs screenshot path: keep main.png at actual tick100 showing
   finished world view, activate Charts and wait for its actual draw before saving
   charts.png; preserve inspector.png if feasible (at most six total PNGs).
   No extra ticks for screenshots, no synthetic renderer. Retain10/100 targets,
   parent/browser deadlines, child/profile cleanup and smoke parity.
10. Update docs/UI.md, README.md, STATE/ARCHITECTURE and ADR-002 with implemented
    protocol, semantics, precision/history limits and exact results. Run targeted
    tests then full suite in isolation (global browser-profile assertions forbid
    concurrent browser suites); release launcher needs rebuild, cargo test alone
    does not update it. Inspect screenshots, reserve final10 minutes for handoff.
    No commits or review transition in IMPLEMENT process.

## Acceptance and verification matrix (future implementation evidence)

| Requirement | Required proof |
| --- | --- |
| Preset + editable new world | Node descriptor/token tests and Rust all3 presets; browser chooses seasonal, edits all6 required plus >=5 optional fields, Start acknowledges tick0 paused/new epoch, checkpoint config equals expected Config, then Run advances. Verify plant-only and zero populations. |
| Adjacent errors, no invalid start | Rust config error paths/bounds and session rollback hash/epoch/control state; no-display HTTP wrong type/range/malformed/overflow/unknown field; browser empty seed, width0, mutation1000001 and basal0 each show adjacent error and no replacement. Correct input subsequently starts. Test group overflow separately; import root errors remain file-level. |
| JSON round trip | Node field strings preserve huge negative/positive seeds, u64 values, exponent rejection for integer fields and subnormal floats; Rust validate/export/import equality for all presets and custom all-leaf config. Real CDP download -> JSON file -> actual DOM file-input import, compare full effective config (including non-edited optional fields), no automatic start. Invalid import preserves draft/engine. |
| Four updating time plots | Rust samples compared with independent engine Snapshot at0/10/20 and provisional3/11, exact cumulative event accounting, actual species/current means. Browser Run observes >=2 distinct chart ticks/values; deterministic Step tests geometry/text against DTOs, no sampling through repeated polls. Include actual births/deaths/speciation fixtures when practical, not only tick0 zeros. |
| Selectable distribution | Independent known endpoint/midpoint/bin-edge oracle, per-kind sum equals living population, max in last bin, empty all0. Test all12 names/domains and reject unknown selections. Browser changes speed->fertility, checks labels/bars/data update to current accepted tick; CLI/state remains identical. |
| Axes and legends | Node geometry label/schema tests plus actual browser visibility checks on all5 charts at1440x900 and1280x720; verify plants/herbivores/carnivores and Births/Deaths legend labels, trait units, Tick and count axes. Empty/single-point/nonfinite scaling never draws NaN. |
| No display logic tests | env-unset Cargo UI tests, Node modules without DOM/browser, Python actual HTTP config/chart tests (separate without_display subset). No test-only alternate simulation model. |
| Screenshots (nonblocking scoring) | Real smoke10 and screenshot100 commands finish within60/120s, main.png>=1280x720 and charts.png from real UI with readable charts; open/inspect both. Record gaps honestly rather than claim success from PNG presence alone. |

Additional regression oracles: sampling and repeated poll/export/validate/trait
selection do not change state hash/checkpoint bytes or future continuation; UI new
world +N explicit steps equals CLI same config/seed; reset/load start a fresh chart
window and stale epoch/draft replies cannot replace it.2048 cap and eviction tested
with a cheap empty world >20480 ticks; latest stored/current no duplicate tick;
loaded tick above2^53 uses exact strings and relative x offsets. Malformed/oversized/
short/stale config bodies, wrong auth/origin/method/type and slow ingress cannot
mutate replacement or block owner on body I/O. Existing headless/static packaging,
checkpoint, navigation/selection,1000-organism frame tests remain passing.

Planned commands (not new feature evidence in PLAN):
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib ui_server`
- `node tests/ui_configuration.cjs` and `node tests/ui_charts.cjs`
- `env -u DISPLAY -u WAYLAND_DISPLAY python3 -m unittest discover -s tests -p test_ui_experiments.py -k without_display -v`
- `python3 -m unittest discover -s tests -p test_ui_experiments.py -v`
- `./test.sh > target/task025-full.log 2>&1` (isolated)
- `timeout 60s xvfb-run -a ./evosim ui --smoke-test`
- `mkdir -p target/task025-shots` followed by
  `timeout 120s xvfb-run -a ./evosim ui --screenshots target/task025-shots`
- `cargo fmt --check`, Node syntax checks for changed JS, `git diff --check`.

## Costs, risks and phase evidence

History is O(2048*3*12), fixed bin arrays O(12*3*20); serialized frames add bounded
history, potentially several MiB at maximum window. Snapshot captures cost
O(living*12+historical species), histogram O(living*12). Cache per tick, never scan
death history for charts; response/history serialization remains application work.
Measure existing1000 frame tests before optimizing. If full-history polling is
materially slow, a revisioned separate charts endpoint is an allowed documented
implementation refinement, with identical semantics and explicit tests. Large
valid configs can still OOM during Simulation creation; no new ecology cap or
universal responsiveness guarantee.1MiB config body limit is UI transport only;
CLI schema and64MiB checkpoint limit unchanged. No filesystem path API.

No new crate, npm or system package planned. Existing STATE/setup musl/Node reinstall
commands remain binding; benchmark Chromium wrapper must be retained. No web search
needed for this repository-specific plan. No full suite/browser/new feature tests
run in PLAN. Actual baseline commands/results and final planning validation are
in plan-cycle1.json. One exploratory glob `docs/decisions/002*` failed exit1;
correct ADR-002 path was subsequently read. Large initial outputs were truncated;
focused source/docs/handoff reads supplied relevant decisions and review outcomes.
No blockers or acceptance gaps identified; implementation and its evidence remain
for the assigned next phase.

## Reproducible final planning artifact validator

Executed by extracting this Python block (exit0). This checks planning artifacts,
not the unimplemented acceptance behavior.

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-025/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required={'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-025','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-002-ui-technology.md',
          'tasks/TASK-025/handoffs/plan-cycle1.md','tasks/TASK-025/handoffs/plan-cycle1.json'}
assert changed==expected==set(h['changed_files']),changed
for path in changed: (root/path).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md',
               '.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8 JSON/schema, exact five planning paths, protected scope, no remotes, whitespace')
```

Actual baseline outcome:6 existing UI unit tests and12 integration tests (8 config,
2 metrics,2 hash) passed with both display variables removed. No failures/ignored;
125 unrelated unit tests filtered by the intentional UI filter. These18 existing
tests establish baseline only. No full suite, new chart/config feature tests or
browser tests run in PLAN.

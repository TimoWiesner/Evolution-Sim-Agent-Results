"""Independent no-display acceptance edge probes against the real UI adapter."""
import json
import math
import sys
from pathlib import Path
sys.path.insert(0, str(Path('/workspace/tests')))
from test_ui import server, request

with server([]) as url:
    token = url.split('#')[1]
    def get(path):
        code, data = request(url, path)
        assert code == 200, (code, data)
        return json.loads(data)
    def post(path, body=None):
        epoch = get('/api/frame')['epoch']
        code, data = request(url, path, 'POST', token,
                             {'X-Evosim-Epoch': epoch, 'Content-Type': 'application/json'}, body)
        assert code == 200, (code, data)
        return json.loads(data)
    catalog = get('/api/config')
    for name, dto in catalog['presets'].items():
        f = post('/api/config/start', dto['canonical_json'].encode())['frame']
        c = json.loads(dto['canonical_json'])
        assert f['tick'] == '0' and not f['running']
        assert list(map(int, f['counts'])) == [c['initial'][k] for k in ['plants','herbivores','carnivores']]
        assert get('/api/config')['active'] == dto
    c = {'seed': -987654321012345678909876543210, 'world': {'width': 1, 'height': 1},
         'initial': {'plants': 1, 'herbivores': 1, 'carnivores': 1}}
    f = post('/api/config/start', json.dumps(c).encode())['frame']
    # Independently reconstruct every histogram and mean from selected organism DTOs.
    domains = [(1,4),(1,10),(10,100),(200,2000),(0,1),(1,8),(.5,2),(0,1),(0,1),(.05,.5),(0,1),(0,1)]
    for row in f['organisms']:
        selected = post('/api/control/select/' + row[0])['selected']
        k = row[1]
        for i, h in enumerate(f['charts']['current']['histograms']):
            value = selected['traits'][h['name']]
            low, high = domains[i]
            expected = [0] * 20
            expected[min(19, math.floor(20*(value-low)/(high-low)))] = 1
            assert list(map(int, h['counts'][k])) == expected, (h['name'], k)
            assert f['charts']['points'][0]['kinds'][k]['means'][i] == value
    # Start an extinct world and advance across multiple chart sampling boundaries.
    c['initial'] = dict.fromkeys(['plants','herbivores','carnivores'], 0)
    post('/api/config/start', json.dumps(c).encode())
    for _ in range(37): post('/api/control/step')
    f = get('/api/frame')
    assert [p['tick'] for p in f['charts']['points']] == ['0','10','20','30','37']
    assert f['counts'] == ['0','0','0']
    for point in f['charts']['points']:
        for k in point['kinds']:
            assert [k[x] for x in ['population','births','deaths','species']] == ['0'] * 4
            assert k['means'] == [None] * 12
    for h in f['charts']['current']['histograms']:
        assert h['counts'] == [['0'] * 20] * 3
    assert get('/api/frame') == f
print('PASS: all presets start; 36 independently reconstructed histogram/mean pairs; empty 1x1 world through tick37; repeated-poll purity')

# TASK-003 PLAN cycle 1

## Entry findings and scope

Verified /workspace/AGENTS.md and docs/STATE.md before inspection. Read project,
contract, state, architecture, task.md/task.json, plan skill, four ADRs and index,
all TASK-001 and TASK-002 handoffs. TASK-002 review PASS has no remediation gaps.
Initial working tree clean, no Git remotes. No TASK-003 handoffs existed; no
handoffs exist for dependent TASK-005, TASK-019 or TASK-025. Inspected Cargo,
library/CLI, scripts and bootstrap tests. Bulk read output truncated; relevant
ADRs and handoffs were subsequently read in bounded calls. No packages installed.

Only configuration planning is authorized here. No feature code, dependency
installation, simulation, run command, UI, demo scenario or phase transition.
Existing bootstrap exposes version/help only. The IMPLEMENT phase should add a
public library configuration API, not a temporary CLI command. Selection by name
is through Config::preset; later CLI/UI tasks can use this same API.

## Decisions

Use JSON only. Add serde_json 1.x with arbitrary_precision and float_roundtrip
features, committing the resolved Cargo.lock in IMPLEMENT. Use its Value parser
and explicit typed extraction/validation rather than raw derived Deserialize:
there are few fields, and explicit traversal gives stable full dotted paths for
missing keys, wrong types, unknown keys and range errors without another error
path dependency. Do not implement a JSON parser. All validation passes through
one API, including serialization and built-in presets. Document library errors;
status 2 and no result files are responsibilities of future CLI integration.

Reject unknown keys at root and within every recognized group to catch typos.
Omitted optional groups and individual optional leaves expand to defaults;
explicit null is an error. Required root/world/initial objects and all fixed
leaves remain mandatory in JSON, even though Config::default() exists for presets.
Do not put a blanket default on the input root. JSON object order is irrelevant;
if duplicate keys occur, use serde_json Value's last occurrence (document this).
Malformed JSON and non-object root use path "$" plus parser context, since no
reliable offending key exists. Reject trailing JSON values. Reject booleans,
strings and fractional/exponent notation for integer fields (1.0 and 1e0 are not
integer tokens); numeric float parameters accept integer tokens too.

No arbitrary policy caps on contract dimensions or population counts: use usize
on this x86-64 platform, positive dimensions and nonnegative counts. Validate
checked width*height and total initial counts (reserve one u64 ID for next ID).
Do not reject initial populations above cell count; shared cells are allowed.
Validation allocates no grid or organisms. Future initialization must handle
actual allocation failure separately, without pretending enormous worlds fit.
Any representability error names the input path; multiplication overflow names
world.width/world.height, total overflow names initial. Document machine limits.

The contract places no magnitude limit on integer seeds. Represent Seed as a
private normalized signed decimal integer string, parsed from a JSON number
with arbitrary_precision and emitted as a JSON number, never as a quoted string.
Normalize negative zero to zero. Provide Seed::from_i64, Seed::from_u64,
Seed::as_decimal and Seed::wrapping_u64; implement modulo 2^64 by a wrapping
base-10 fold and wrapping negation. This preserves the original mathematical
seed for future results and matches ADR-001 without f64 truncation or a BigInt
runtime dependency. Test beyond signed/unsigned 64-bit endpoints. Do not implement
RNG here. Avoid presenting seed as a JavaScript number in future UI integration.

Additional tunables are a deliberately small initial schema, with intended
meaning and defaults below. They are configuration data only in this task;
owning ecology tasks must document their exact equations, consume these fields,
and add any newly introduced tunables with types/ranges/defaults. Fixed genome
trait bounds, species thresholds and crossover operator remain ADR-004 constants,
not newly configurable fields. No global-count replenishment knobs exist.

## Proposed effective schema

All bounds inclusive. u64/usize integer fields reject negative/fractional values;
f64 fields must be finite. Derive Clone, Debug and PartialEq for configuration
records. No Eq for records with floats. Groups are typed structs; fields private
with read-only accessors, or expose read-only group references. Invariants must
not be bypassed via public writable fields. Future editors should update JSON
or use validated builder methods, rather than mutate unchecked records.

| JSON path | Rust value / valid range | Default | Meaning |
|---|---|---|---|
| seed | Seed / any signed JSON integer | required; programmatic default 42 | deterministic seed |
| world.width | usize / 1..usize::MAX, checked area | required; default 64 | horizontal cells |
| world.height | usize / 1..usize::MAX, checked area | required; default 48 | vertical cells |
| initial.plants | usize / 0..usize::MAX, checked sum | required; default 400 | initial individuals |
| initial.herbivores | usize / 0..usize::MAX, checked sum | required; default 120 | initial individuals |
| initial.carnivores | usize / 0..usize::MAX, checked sum | required; default 20 | initial individuals |
| climate.year_ticks | u64 / 1..u64::MAX | 1000 | seasonal period |
| climate.season_temperature_amplitude | f64 / 0..1 | 0.15 | normalized seasonal temperature amplitude |
| climate.season_precipitation_amplitude | f64 / 0..1 | 0.10 | normalized seasonal precipitation amplitude |
| climate.weather_amplitude | f64 / 0..1 | 0.05 | normalized weather deviation; zero disables weather |
| genetics.mutation_per_million | u32 / 0..1000000 | 10000 | exact per-locus probability numerator over 1000000 |
| genetics.mutation_max_step | u16 / 1..65535 | 1024 | maximum nonzero signed allele step |
| plants.resource_capacity | f64 / 0 exclusive ..1000000 | 100 | per-cell resource ceiling |
| plants.resource_regeneration | f64 / 0..1000000 | 1 | maximum resource addition per cell/tick, capped at capacity |
| plants.growth_efficiency | f64 / 0..1 | 0.5 | consumed resource converted to plant energy |
| plants.reproduction_energy | f64 / 0 exclusive ..1000000 | 20 | energy threshold and cost budget for a birth |
| plants.dispersal_radius | u32 / 0..u32::MAX | 3 | maximum toroidal Chebyshev dispersal distance |
| animals.movement_cost | f64 / 0..1000000 | 0.2 | base energy cost per adjacent step |
| animals.basal_cost | f64 / 0 exclusive ..1000000 | 0.1 | base energy cost per active tick |
| animals.reproduction_energy | f64 / 0 exclusive ..1000000 | 30 | per-parent energy budget for reproduction |
| animals.reproduction_cooldown | u64 / 1..u64::MAX | 20 | minimum ticks between births |

The exclusive lower bounds are explicit exceptions to the inclusive table rule.
No constraint regeneration<=capacity: a refill can saturate at capacity. Climate
amplitudes can sum above 1; future climate must clamp normalized outputs. Zero
mutation and weather are valid. Mutation strength remains positive even at zero
rate so later re-enabling mutation cannot create an invalid distribution. Default
biology is provisional and unmeasured, not a promise of coexistence or performance.
Use named default constants in one place and avoid duplicated magic defaults in
presets/docs/tests. A full exported config includes every optional group/leaf.

## Public interfaces and files

Implement in src/config.rs, exported with pub mod config in src/lib.rs:

- Config::from_json(&str) -> Result<Config, ConfigError>.
- Config::load(path: impl AsRef<Path>) -> Result<Config, ConfigError>.
- Config::to_json(&self) -> Result<String, ConfigError> (pretty effective JSON).
- Config::save(&self, path: impl AsRef<Path>) -> Result<(), ConfigError>.
- Config::preset(name: &str) -> Result<Config, ConfigError>.
- Config::preset_names() -> &'static [&'static str].
- Config::default() returns a valid baseline built through the same validation.
- Config accessors for Seed, WorldConfig, InitialConfig, ClimateConfig,
  GeneticsConfig, PlantConfig, AnimalConfig; Seed accessors as specified above.
- ConfigError implements Display + std::error::Error and exposes path/message.
  For unreadable/writable paths include file path and I/O cause; for an unknown
  preset use path "preset" and list supported names. No panic on user input.

File operations are convenience wrappers around the string API; do not change
cwd, allocate world state, access RNG, or write anything on load failure. A failed
save must surface the error; atomic checkpoint persistence is not this task.
Serialization constructs known typed fields in a deterministic order, round trips
all supported f64 values exactly via float_roundtrip, preserves integer seed
magnitude, and does not serialize cached/derived fields. Config equality compares
all effective values, so omitted defaults equal explicit defaults. JSON schema
version 1 is documented, not a new required key. Unknown-key rejection means
future schema evolution must be explicit; checkpoint versioning is later work.

Three public preset names, exact match, all using seed 42 and defaults except:

| Name | World | Initial plants/herbivores/carnivores | Other overrides / purpose |
|---|---|---|---|
| baseline | 64x48 | 400/120/20 | contract example, default values |
| seasonal | 64x48 | 400/120/20 | year_ticks=240, season_temperature_amplitude=0.3, weather_amplitude=0.1; stronger, faster climate variation |
| plant-only | 32x24 | 200/0/0 | mutation_per_million=50000, dispersal_radius=5; plant isolation/diversification experiment |

These differ in effective inputs with clear experimental purposes; do not claim
observed ecological effects. Names are not accepted as configuration root strings.
No scenarios/demo.json yet; it is owned by a later task. Presets reuse baseline
and validated override application, not independent unchecked constructors.

## Ordered implementation steps (assigned IMPLEMENT only)

1. Add dependency/features in Cargo.toml, resolve and commit lockfile through
   normal file changes (orchestrator commits). No system package expected. Record
   crate versions actually resolved and verify available Rust 1.85 compatibility.
2. Implement typed records, constants, Seed and ConfigError in src/config.rs;
   write Value extraction helpers with explicit paths, unknown-key allowlists,
   integer-token checks, finite/range checks and cross-field checked arithmetic.
   Keep core independent of CLI/UI. Expose module from src/lib.rs.
3. Implement parsing, effective JSON serialization, file wrappers and preset
   registry as above. Reuse one validation route for presets and defaults. Avoid
   run dispatch, temporary config CLI flags or placeholders in other modules.
4. Add tests/config.rs integration tests using public API and fixtures inline;
   keep temp file round trips under target/ with unique names and cleanup. Use
   Cargo built-in tests and existing ./test.sh; no new test runner required.
5. Document all fields/ranges/defaults, unknown/duplicate/null policies, presets
   and Rust API usage in docs/CONFIGURATION.md; link from README.md. Remove the
   bootstrap README claim that no third-party Rust crates are needed once false.
   Update STATE and ARCHITECTURE with implemented scope, dependencies, evidence
   and any justified deviations. A new ADR is unnecessary: this refines ADR-001's
   pure-Rust serialization choice and ADR-004's configurable mutation allowance.
6. Run targeted config suite, full bootstrap/packaging regression suite, formatting
   and whitespace checks. Inspect scope/protected paths/remotes. Write mandatory
   implement-cycle1.json with exact results, any failures and follow-up. Do not
   commit or advance phases.

## Acceptance/test matrix for IMPLEMENT and REVIEW

All feature tests below are planned; none exists or was executed in PLAN.

1. Minimal exact contract example loads, optional groups match documented defaults.
   Test 1x1 and non-square dimensions, each zero population and all-zero population,
   and populations exceeding cell count. Verify defaults/presets require no UI.
2. Table-driven tests remove each fixed leaf and required object; assert precise
   path (e.g. initial.herbivores). Wrong types for every field: null, object/array,
   strings, booleans and fractional values where integers required. Root is also
   tested as array/null. Missing optional groups/leaves and empty optional objects
   all load with defaults. Supplying null instead of omission fails.
3. For every bounded field, test lower/upper boundaries and invalid sides where
   representable. Test zero dimension, negative populations, area/sum overflow,
   oversized integer fields, probability >1000000, strength 0/>65535, year/cooldown
   zero, negative/out-of-range/nonfinite numeric inputs. JSON 1e400 must fail with
   its field path. Integer overflow must not silently round through f64.
4. Unknown root/nested keys give offending full paths; malformed/truncated JSON
   and trailing documents fail at $. Duplicate policy test confirms last wins.
   Multiple invalid keys may report only the first deterministic traversal error.
5. Round trip minimal config, full custom non-default config, each preset and
   unusual finite decimal floats through to_json/from_json; assert whole Config
   equality. File save/load equivalence, unreadable/malformed input, unwritable
   destination return structured error. Fixtures/tests stay inside workspace.
6. Iterate every preset name: valid, round trips and differs meaningfully from
   others. Unknown, empty and incorrectly cased names fail with path preset.
   Assert all preset overrides listed above and Config::default()==baseline.
7. Seed tests: 0/-0, negative, i64 min/max, u64 max and larger positive/negative
   integers preserve normalized numeric JSON and expected modulo. Independently
   known modulo cases include 18446744073709551616 -> 0 and -1 -> u64::MAX.
8. Existing CLI/version/help/error/packaging tests remain valid. Planned commands:
   `cargo test --locked --test config`, `./test.sh`, `cargo fmt --check`,
   `git diff --check`. ./test.sh rebuilds setup twice and static dist, checks ELF
   and executes copied version binary in empty chroot. Record actual counts and
   skips; new crates must preserve static packaging. No fake end-to-end run test.

## Risks, boundaries and PLAN evidence

Registry access and musl compilation of the new dependency remain unverified;
IMPLEMENT should measure them. Existing setup reinstalls missing system packages;
record any actual installs in STATE. No package was installed in this PLAN.
No seed magnitude policy cap is introduced; arbitrary_precision requires explicit
numeric-token handling and tests. usize/area/ID limits are representational limits,
not population balancing. Validating enormous inputs does not guarantee memory.
Float round trips require the chosen feature and boundary tests. Ecological
parameters can be tuned by later owning tasks with updated docs/tests; no energy
or resource equations are implemented here. Private validated values avoid invalid
programmatic configs. Full exported JSON is a configuration format, not checkpoint
or canonical state-hash encoding. Future batch/UI must reuse validation and take
care around large seed values and JS precision. No review gaps or blockers found.

Executed in PLAN: required file existence check, source/document inspections,
clean-tree/no-remotes inspection, git diff --check and the validator below. No
application suite was run because feature code is unchanged; prior TASK-002 PASS
is inherited evidence, not a new test result.

Reproduce final planning validation from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-003/handoffs/plan-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root / 'tasks/TASK-003/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required = {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-003','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'], str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k], list)
for t in h['tests']:
    assert isinstance(t['command'], str) and type(t['exit_code']) is int
    assert isinstance(t['notes'], str)
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
expected = {'docs/STATE.md','docs/ARCHITECTURE.md','tasks/TASK-003/handoffs/plan-cycle1.md','tasks/TASK-003/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root / p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(root),'diff','--check'], check=True)
print('PASS: UTF-8 handoff/schema, exact four planning paths, protected files, no remotes, whitespace')
```

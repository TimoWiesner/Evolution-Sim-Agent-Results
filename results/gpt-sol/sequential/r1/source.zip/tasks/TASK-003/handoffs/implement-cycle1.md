# TASK-003 IMPLEMENT cycle 1

Implemented the approved plan in the Rust library. Required workspace files were
verified first. Read project/contract/state/architecture, task specifications,
TASK-003 plan, current implement skill, dependency TASK-002 handoffs, architecture
TASK-001 handoffs and ADRs. Some bulk output truncated; bounded reads completed
relevant context. No dependent TASK-005/019/025 handoffs exist. TASK-002 review
PASS had no remediation gaps. Initial tree clean, no Git remotes.

## Changes and decisions

src/config.rs provides Config, Seed, ConfigError and seven typed configuration
group records with private fields and read-only accessors. String/file import,
pretty effective JSON export, named presets and Default share explicit validation.
Required fixed leaves remain mandatory, zero initial populations valid, optional
groups/leaves default, unknown/null inputs fail with dotted paths. Duplicate keys
use last occurrence. Integer tokens are checked without f64 conversion; arbitrary
signed integer seeds preserve numeric representation and normalize -0, with exact
modulo-u64 conversion. Float fields require finite values and documented ranges.
Checked area/count arithmetic protects representability and reserves next ID.
No world allocation or ecological population cap. No run dispatch/engine changes.

Defaults are centralized named constants; preset overrides match the plan.
baseline matches the contract, seasonal changes climate period/amplitudes,
plant-only removes animals and changes mutation/dispersal/world dimensions.
All are valid experimental inputs; ecology is unimplemented and unmeasured.
README links docs/CONFIGURATION.md for schema, defaults, policy and API usage.
STATE and ARCHITECTURE record implemented boundaries and limitations.
No plan deviations or new ADR required. No protected files or task specs changed.

Added serde_json 1.0.154 with arbitrary_precision and float_roundtrip. Cargo.lock
resolved the compatible graph; compiled transitive crates were serde_core
1.0.229, itoa 1.0.19, memchr 2.8.3, zmij 1.0.23. Cargo also locks optional
serde/proc-macro dependencies; no derive macros added to this code. Available
Rust/Cargo 1.100.0 used; a separate Rust 1.85 execution was not performed.
No system packages installed; inherited musl prerequisites were present.

## Acceptance evidence

Eight public integration tests in tests/config.rs cover:
1. Minimal fixed JSON, every documented default, empty optional groups and each
   omitted optional leaf, zero populations, 1x1/non-square/shared-cell inputs.
2. Every missing fixed leaf/object and wrong types for each field/group, integer
   fractions/exponents, explicit null, structured error path/message.
3. Integer/float lower and upper boundaries and invalid sides, huge/nonfinite
   numbers, checked area/count overflow and reserved next ID.
4. Unknown root/nested keys, malformed/trailing/non-object JSON, duplicate policy.
5. Minimal, fully customized, preset and subnormal/decimal float round trips.
6. All three named presets, every planned override, name errors and inequality.
7. Seed normalization, i64 endpoints, u64 maximum and larger signed magnitudes,
   exact numeric export and known modulo values beyond 128 bits.
8. File save/load equality, unreadable/malformed files and unwritable destination.

Executed commands, all exit 0:
- `cargo test --test cli`: dependency resolution/download/build and 1 CLI test.
- `cargo test --locked --test config`: 8 passing tests (repeated after constants
  and after the explicit documented-default fixture).
- `./test.sh`: 16 passing tests, no skips (1 unit, 1 CLI integration,
  8 configuration integration, 6 Python packaging); repeated after final edits.
- Final combined command:
  `cargo test --locked --test config && ./test.sh && cargo fmt --check && git diff --check`.
  Targeted 8 plus complete 16 pass. Formatting and whitespace checks pass.
- Final handoff/scope validator below, exit 0.

Packaging tests execute setup twice and build from an unrelated cwd, verify
version/help/error behavior, ELF no INTERP/NEEDED and copied dist version inside
an otherwise empty chroot as root. Host/musl dependency builds succeeded.
The binary's current version/help path does not exercise config parsing in the
chroot; the library is tested by host integration tests. No fresh Ubuntu container,
Rust 1.85 toolchain, full simulation portability, performance or ecology measured.
No test failures, blockers or known acceptance gaps remain. Future owning tasks
consume/tune/extend schema and must preserve large seeds in browser workflows.
Harness owns review, commits and transitions; no next phase started.

## Final validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-003/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
h = json.loads(Path('/workspace/tasks/TASK-003/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-003','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int
    assert isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git', *args],text=True).strip()
changed=set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
assert changed==set(h['changed_files']),changed
assert len(changed)==11
assert all(Path(p).is_file() for p in changed)
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
assert not git('remote','-v')
subprocess.run(['git','diff','--check'],check=True)
print('PASS: UTF-8 handoff schema, exact eleven paths, protected files, no remotes, whitespace')
```

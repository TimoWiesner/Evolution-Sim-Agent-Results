# TASK-007 REVIEW cycle 1

Verdict: PASS. All six acceptance criteria met; no gaps or product changes.

Used the repository REVIEW skill. Verified required files first, read the task,
project/contract, state/architecture, TASK-007 plan/implementation handoffs,
TASK-006 dependency handoffs and relevant ADR-001/005/006. Independently inspected
implementation commit diff d752a0e..c5b8e5d and actual source/tests. Initial tree
clean; no Git remotes. Some bulk output truncated; bounded follow-up reads covered
relevant context. No system packages/dependencies installed, protected files
changed, commits made or subsequent phase started.

Acceptance evidence (executed with ./test.sh, exit 0):
1. Configurable year: existing private validated ClimateConfig supplies positive
   u64 year and finite [0,1] amplitudes. TemporalClimate uses integer remainder
   before cosine phase conversion. Seasonal golden tests cover both fields,
   quarter/half-year phases, zone strengths, independent amplitude disabling and
   changed year length. Smooth zone amplitudes and clipping match ADR-006.
2. Seeded weather: ClimateResources updates the World-owned temporal state from
   Simulation's sole RNG, temperature then precipitation, exactly two draws per
   enabled tick. Tests compare same/different seed climate traces, an independently
   advanced RNG and explicit AR(1) recurrence. Tick zero draws nothing; weather
   off draws nothing. Queries have no RNG/mutable access.
3. Bounds: current temperature/precipitation are documented normalized [0,1].
   Configuration/state validation prevents nonfinite inputs; seasonal sums and
   recurrence are finite and clamped. 2001-tick bounds matrices exercise six
   worlds, three seeds, extreme/zero/tiny amplitudes and year lengths 1/7.
4. Any cell at any reached tick: World::current_climate_at delegates to pure
   current_at; base lookup normalizes foreign cells. Tests observe tick zero and
   every reached tick, all cells, seams, x invariance and full Simulation equality
   versus unobserved clones. Historical stochastic queries require replay, as
   explicitly documented in the approved plan; no retrospective API is required.
5. Exact year repetition: test exact_annual_repeat_all_cells_and_phases_without_weather
   compares both fields by float bits at every cell/phase over consecutive years,
   dimensions 1..=8 and years 1/2/7/16/240/1000. Weather disabled and nonzero
   seasonal amplitudes. Large tick/year tests verify modulo before conversion.
6. Carry-over state: TemporalClimate lives inside World inside Simulation and
   stores validated settings, version, absolute tick and both offsets. Snapshot
   plus full RNG restore at tick 37 matches 256 further ticks exactly. Tests also
   check clone continuation, version/offset errors, clock agreement and atomic
   clock overflow. No hidden random source or observational state influences it.

Executed commands:
- ./test.sh: exit 0, 49 tests, none skipped: 5 unit, 2 CLI, 5 climate, 8 config,
  5 RNG, 4 simulation, 5 temporal, 7 topology, 1 rustdoc, 7 Python. Includes
  host/musl setup twice/build, exports, static ELF and empty-root copied version.
- cargo fmt --check && git diff --check && git diff d752a0e c5b8e5d --stat:
  exit 0. Formatting/whitespace pass; reviewed thirteen implementation paths.
- Final validator below: checks UTF-8 handoff identity/schema, exact review scope,
  protected paths, absent remotes and whitespace; result recorded in JSON.

Existing tests are substantive and sufficient; no redundant review test added.
Architecture/ADRs accurately describe current implementation and need no changes.
Global weather and same-phase seasons simplify geography; clipping flattens some
extrema, and huge years lose adjacent f64 phase resolution. These are documented
model choices, not acceptance gaps. Disk checkpoint/hash, ecology, throughput,
fresh-container and separate Rust 1.85 execution remain outside this evidence.
Future persistence must encode settings/model/tick/offsets and full RNG and validate
engine/temporal clock agreement. No remediation required; harness owns completion,
commits and next assignment.

Final validator command:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-007/handoffs/review-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-007/handoffs/review-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-007','review',1,'PASS')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(h['changed_files']) == {'docs/STATE.md','tasks/TASK-007/handoffs/review-cycle1.md','tasks/TASK-007/handoffs/review-cycle1.json'}, actual
assert not git('remote','-v')
assert not git('diff','d752a0e','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8 JSON/schema, exact review scope, protected files, no remotes, whitespace')
```

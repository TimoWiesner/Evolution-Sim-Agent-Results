# TASK-007 IMPLEMENT cycle 1

Implemented the approved plan without algorithm or scope deviations. Required
workspace files existed; read AGENTS, project, contract, state, architecture,
task/spec, current implement skill, TASK-007 plan, dependency TASK-006 handoffs,
TASK-005 frame evidence and relevant ADRs. Dependency review PASS has no gaps.
Initial tree clean, no remotes; no packages installed, protected files edited,
commits made or phase transitions started. Some bulk reads truncated; bounded
follow-ups covered relevant code, plan and dependency evidence.

src/temporal_climate.rs implements ADR-006 model 1. TemporalClimate owns validated
settings and WeatherState (model, absolute tick, both offsets); read-only APIs
expose complete memory and pure current queries. WeatherState validates global
bounds; from_state also checks configured amplitude, preserving exact bits.
World owns it alongside immutable base Climate. ClimateResources updates it once
from the sole engine RNG after clock increment, before biological phases. Two
raw draws per enabled tick, temperature then precipitation; none if disabled.
Tick-zero offsets are positive zero with no draws. Base API/export unchanged.
No resources, organisms, ecology, new command, UI or disk checkpoint introduced.
Future checkpoint/hash work must encode settings/model/tick/offsets and full RNG,
and validate engine/weather clock agreement. In-memory continuation is tested;
this is not disk-checkpoint evidence.

Acceptance evidence:
1. Configurable year and both seasonal fields: exact annual-repeat integration
   covers every cell and phase, dimensions 1..=8 and years 1,2,7,16,240,1000.
   Golden samples independently verify quarter/half-year phase, opposite wetness,
   zone amplitudes, both fields changing, independent zero amplitudes and shorter
   year extrema. Large-tick restoration verifies modulo before float conversion.
2. Seeded weather: 294-tick traces include actual values, both offsets and RNG;
   same seeds equal, different seeds differ in climate values. Private recurrence
   test independently draws engine RNG and checks channel order and exact offsets.
3. Bounds: 2001-tick traces for six tiny/odd/non-square worlds, three seeds, six
   amplitude combinations (0/1 and tiny positive), years 1/7. All values finite
   within [0,1], offsets within configured amplitude; exact two-draw/zero-draw
   counts verified. Queries draw nothing.
4. Query any reached tick: tick 0 and all subsequent trace ticks; foreign-cell
   normalization, x invariance, paired seam rows, full Simulation equality before
   and after observations and future equality with unobserved clone tested.
   Existing base-climate static/export regression stays passing.
5. Exact weather-off annual repetition: bitwise field comparisons across all
   phases and cells of successive years, including Y=1 and nonzero seasons.
6. Persistent state: private 37-tick snapshot restores temporal settings/state
   and full RNG then compares 256 further ticks exactly; full Simulation clones
   continue identically. Invalid versions/nonfinite/oversized offsets and disabled
   weather incompatibility rejected. Clock agreement and atomic overflow tested.

Commands actually executed (all exit 0, no failed invocations):
- `cargo test --locked --lib --test simulation`: 5 unit + 4 simulation tests.
- `env -u DISPLAY cargo test --locked --test temporal_climate --test simulation`:
  5 temporal + 4 simulation integration tests.
- `./test.sh`: 49 tests, none skipped: 5 unit, 2 CLI, 5 climate, 8 config, 5 RNG,
  4 simulation, 5 temporal, 7 topology, 1 rustdoc, 7 Python. Includes setup twice,
  build, host/musl export, static ELF and copied-empty-root version execution.
- `cargo fmt --check && git diff --check && git diff --stat && git status --short`:
  formatting/whitespace pass; inspected changed-file scope.
- Final validator below checks required JSON, exact paths, protected files, no
  remotes, formatting and whitespace (actual result recorded in JSON).

No new dependencies, apt commands or runtime requirements. Existing setup.sh
reinstalls missing musl prerequisites; exact inherited install commands are in
STATE. No throughput, full disk persistence, separate Rust 1.85 or fresh-container
claim. Global weather, synchronous seasons, clipping and huge-year f64 phase
resolution limitations are documented. Reviewer should inspect plan/code and rerun
suite; harness owns all subsequent phases, states and commits. No known gaps.

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-007/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-007','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for test in h['tests']:
    assert isinstance(test['command'],str) and type(test['exit_code']) is int and isinstance(test['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
expected = {'README.md','docs/STATE.md','docs/ARCHITECTURE.md','docs/CLIMATE.md','docs/CONFIGURATION.md','docs/decisions/ADR-006-temporal-climate.md','src/lib.rs','src/simulation.rs','src/temporal_climate.rs','tests/simulation.rs','tests/temporal_climate.rs','tasks/TASK-007/handoffs/implement-cycle1.md','tasks/TASK-007/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/path).is_file() for path in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: JSON/schema, exact 13 paths, protected files, no remotes, format and whitespace')
```

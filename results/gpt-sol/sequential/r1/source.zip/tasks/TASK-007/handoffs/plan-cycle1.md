# TASK-007 PLAN cycle 1

## Entry findings

Verified /workspace/AGENTS.md and docs/STATE.md first. Read required project,
contract, state, architecture, task/task.json and PLAN skill; inspected existing
handoff summaries and TASK-006 plan/implementation/review details, TASK-005
scheduler/RNG evidence, ADRs, config, climate, RNG, simulation, CLI and tests.
Dependency TASK-006 review PASS, no gaps. No prior TASK-007 or downstream task
handoffs exist. Initial tree clean; no remotes. Bulk reads were supplemented
with bounded relevant reads where output truncated. No packages installed.
Only planning documents change in this phase; implementation has not begun.

Existing Config already validates all four needed climate parameters, defaults
1000/.15/.10/.05, seasonal preset 240/.3/.10/.1. Climate is immutable procedural
base geography; CLI climate export reports only base values. Simulation stages
exist with ClimateResources empty. Several tests assert no RNG consumption and
must be updated because this task introduces a real random subsystem. Base
Climate equality/static export tests must continue proving base immutability.

## Ordered implementation plan

1. Implement ADR-006 in new src/temporal_climate.rs and export via src/lib.rs.
   Use existing ClimateConfig (Clone) and Climate, Topology Cell and Rng types;
   no config schema/default change. Implement exact seasonal modulo-first phase,
   zone-dependent smooth amplitudes, clipped values and global two-channel
   correlated weather per ADR. Public immutable current values and versioned
   WeatherState restoration validate finite/bounded offsets and disabled-weather
   invariants. Error implements Display/Error. Constructor and restore draw
   nothing; mutation remains crate-private. No retrospective random access to
   stochastic history: current_at means the current completed tick, queryable
   for any cell at tick 0 and after every advance. Historical/future weather
   requires replay/advancement, not a query that secretly samples or forecasts.
2. Extend World in src/simulation.rs with TemporalClimate; initialize from
   config.climate().clone(), expose temporal_climate() and
   current_climate_at(Cell). Wire ClimateResources to advance_to(self.tick,
   &mut self.rng). Preserve seven-stage order, checked clock overflow atomicity,
   static climate API and initial counts. At every completed boundary both clocks
   agree. Empty organism stages remain empty; no ecology, resources, organisms,
   population effects, persistence, run/batch/UI or CLI expansion in this task.
3. Add tests/temporal_climate.rs for public API/validation/properties; private
   unit tests for crate-private updates, channel recurrence and restoration.
   Extend tests/simulation.rs for real seeded temporal evolution and replace
   obsolete blanket unchanged-RNG assertions: weather-off retains those checks;
   default weather-on checks exact two-draw advancement. Base fields themselves
   remain static across ticks and seeds. Keep observation equality checks over
   the complete Simulation, not just the returned values.
4. Update docs/CLIMATE.md and docs/CONFIGURATION.md with normalized bounds,
   exact model/season phase, defaults, year=1, settings semantics, RNG draw order,
   tick-zero state, current query example, no historical forecast API, spatial
   simplification and complete persistence boundary. Correct stale comments in
   simulation and README as needed; base CLI export stays unchanged and clearly
   labeled. Mark ADR-006 implemented only after code/tests exist. Update
   STATE/ARCHITECTURE with actual results and any deviations.
5. Execute targeted tests, full ./test.sh (including host/musl static packaging),
   cargo fmt --check and git diff --check; record exact commands, counts, failures
   and skips. Write implement-cycle1.md/.json; harness owns commits/transitions.
   Reinstall missing musl prerequisites through existing setup.sh as needed and
   record actual install commands in STATE. No new dependencies expected.

## Acceptance tests to implement and run

1. Configurable year and both cycles: use full Simulation advancement with weather
   off on year lengths 1,2,7,16,240 and 1000. On a tall map, independently check
   quarter-year golden samples for temperature and precipitation in cool,
   temperate, dry and tropical rows; ensure BOTH fields change on unsaturated
   representative cells for years >1 and nonzero amplitudes. Compare year-16
   extrema at ticks 0/8/16; verify alternate year length moves extrema. Setting
   each amplitude to zero independently removes only that seasonal component.
   For every cell on small grids (dimensions 1..=8), store a complete year and
   compare the following year exactly (PartialEq/float bits), including ticks
   0,Y,2Y. Y=1 repeats constant phase. Add direct state-restoration tick samples
   near u64::MAX and year u64::MAX to verify integer remainder before f64 and
   no tick overflow arithmetic; engine overflow test remains atomic.
2. Seeded weather: equal-seed full traces include actual current values, both
   stored offsets, tick, RNG words; compare 256+ ticks, seeds 42/42 and 42/43.
   Different seeds must differ in weather values (not merely RNG state). Independently
   draw two next_u64 values from Rng::from_seed and check first/second channel
   expectations, recurrence on later ticks and final RNG equality. No draws at
   construction; weather off consumes none; enabled tiny amplitude still two.
3. Bounds: finite [0,1] values for both fields over tiny/odd/non-square grids,
   seeds and 2000+ ticks. Exercise amplitudes 0 and 1, all three amplitudes at
   their extremes, year=1 and representative seasons; offsets stay finite within
   [-A,A]. Frozen expected quarter-year values and independently advanced RNG
   complement bounds tests to catch wrong phase/amplitude/channel usage.
4. Current query at any reached tick: check tick 0, each tick across several
   years, and wrapped/foreign Cell normalization; repeated calls must leave full
   Simulation and RNG identical to an unobserved clone. Observations at different
   frequencies produce identical future weather. Base query/export still return
   unchanged values and no draws. Test seam equality for paired rows and x
   invariance at multiple phases/weather states; the formulas are continuous
   periodic functions of base fields plus spatially uniform weather.
5. Required exact annual repeat: covered by (1), explicitly weather_amplitude=0
   and nonzero seasonal amplitudes, testing both fields, all cells and all phases;
   do not test only a single year boundary or only base geography.
6. Carry-over state: after 37 ticks snapshot TemporalClimate settings/state and
   RngState, restore both and advance another 256 ticks through the private
   update interface; compare state/current values/RNG exactly with uninterrupted
   originals. Also clone a complete Simulation at tick 37 and compare subsequent
   full states. Reject unsupported versions, NaN/infinite/out-of-range offsets
   and nonzero disabled weather. Verify tick-zero record, clock agreement after
   each full step, and overflow failure changes neither clock, offsets nor RNG.
   These in-memory state/continuation tests are not disk-checkpoint evidence.

Planned commands (not executed during PLAN):
`env -u DISPLAY cargo test --locked --test temporal_climate --test simulation`,
`env -u DISPLAY cargo test --locked --lib`, `./test.sh`,
`cargo fmt --check`, `git diff --check`.
Existing CLI/packaging tests run unchanged in full suite; no new external
command is needed to prove the library feature. No throughput claim.

## Risks and handoff

Global weather has no local fronts; synchronous seasons trade geographic realism
for torus continuity. Saturation may hide a cycle at a particular extreme cell,
so tests use unsaturated cells too. Large years lose adjacent phase precision in
f64 but preserve exact annual remainder repeat. Existing tests must retain base
immutability while acknowledging weather RNG consumption. Settings/model/tick/
offsets/RNG all enter future checkpoint/hash schemas. No review gaps or blockers.
No new system dependencies; inherited install commands remain in STATE.

PLAN verification uses a documentation-only Python validator (command in JSON):
required UTF-8 JSON identity/fields/types, exact six changed documentation files,
all files present, protected files untouched, no remotes, git diff --check.
No product tests run in this planning phase; prior 43-test PASS is inherited
TASK-006 evidence only. No feature or performance success claimed.

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-007/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-007','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/README.md','docs/decisions/ADR-006-temporal-climate.md','tasks/TASK-007/handoffs/plan-cycle1.md','tasks/TASK-007/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8 JSON/schema, six documentation paths, protected files, no remotes, whitespace')
```

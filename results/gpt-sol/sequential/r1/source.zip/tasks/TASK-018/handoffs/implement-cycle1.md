# TASK-018 IMPLEMENT cycle 1

Applied `.agents/skills/implement/SKILL.md`; required files verified first. Read
AGENTS, product/contract, state/architecture, task/specification, approved plan,
ADR-014 and relevant ecology/genetics ADRs, dependency implementation and review
handoffs (all dependency reviews PASS with empty gaps). Initial tree clean and no
Git remotes. No installs, commits, remote operations, task-state changes, questions
or transition to another phase. All file access stayed within /workspace.

## Implementation and decisions

The existing scheduler already connected climate/resources, plant physiology,
grazing, hunts, paid reproduction, immediate mortality, Commit and species.
Preserved that implementation rather than introduce a redundant dispatcher.
Only production code edits are two config defaults: regeneration2 and mating
cooldown100. Synchronized default assertions/config docs, added ECOLOGY.md,
updated README/architecture/state and ADR-014 with measured results.

Added four public integration tests and an example with shared external observer.
Audits independently enumerate living organisms/species, check u128 conservation,
death causes, bounded vitals, toroidal coordinates, age/birth/parent invariants,
weather clock and absorbing-zero/frozen births. A1000-tick fresh full-state replay
observes only one copy. Default-only isolated plants run2200 ticks beyond founder
lifespan and abundant-food herbivores run600 with births by300 and during301..600.
Food-removal scenarios run5000 including empty tails; no-plants herbivores vanish
before predators for all3 selected seeds. A natural1x1 plant extinction is also
absorbing. Existing private real-tick cross-phase/reproduction/species tests remain
unchanged and pass, not merely a list of phase names.

`examples/ecology_report.rs` runs public APIs sequentially for seeds0,1,2,42,99
and exactly10000 ticks using only fixed config keys. The external observer never
mutates core state or draws RNG. JSON includes full effective settings, per-kind
first zero/survival/final/birth/death values and loop timings. Helper tests cover
initial-zero/null-survival/empty-tail conventions. The final raw JSON artifact is
`ecology-cycle1.json`; all69 exploratory runs with full configs are retained in
`balancing-cycle1.json`. docs/ECOLOGY.md contains all final tables and exact command.

## Plan amendment and experiments

Original defaults fail isolated plant viability for seeds0/42. Regeneration2
passes2200 for all0/1/42. Regeneration4 and efficiency0.75 then1 (at regeneration4)
do not prevent herbivore overgrazing in the abundant-food600 fixture. Return to
regeneration2; cooldown40 and80 fail that fixture (last plants disappear before600).
Extend the planned cooldown candidate40 to100 based on these measured failures.
It passes all final viability assertions with both plants and herbivores retained
through600. No movement/cost reduction, new mechanism, altered genes/placement or
exception was needed. The100 value is a documented measured plan amendment.
Accepted supply change is the smallest tested one that sustains isolated plants;
not a global balance optimum. No acceptance behavior was skipped or shortened.

Raw experimental sources were temporary measurement fixtures, replaced by final
assertive tests and removed. Their configurations/results remain complete in
balancing-cycle1.json, so rejected candidates are explicit rather than hidden.

Final report: plants survive10000 in all seeds, herbivores extinct27/27/24/22/27,
carnivores875/865/858/857/867. Loop+audit seconds1.920358453/1.88525149/
1.868808522/1.853924828/1.878907899. These timings are not engine throughput or a
portable performance promise. x86_64 Ubuntu24.04 container, rustc/cargo1.100.0;
CPU model/allocation undisclosed. No outside-workspace hardware files read.
Short mixed-world coexistence and zero herbivore births in those runs are recorded
limitations, not hidden behind successful isolated scenarios. TASK-027 owns broad
tuning; CLI/UI/persistence remain later scope.

## Commands and actual results

- `cargo test --locked --release --test ecology_integration -- --nocapture > target/task018-candidate0.log 2>&1`
  first invocation exit101: nonexistent Traits::health in new audit. Fixed to
  max_health; next invocation exit0. Measurement-only matrix intentionally reported
  candidate viability failures rather than asserting them at that exploratory stage.
- Candidate1/2 matrix invocations exit0. Both temporary efficiency/cooldown probe
  invocations (`cargo run --locked --release --example ecology_probe`) exit0.
  Results/configs persisted in balancing-cycle1.json; temporary probe removed.
- `cargo test --locked --release --test ecology_integration -- --nocapture > target/task018-final-scenarios.log 2>&1`:
  exit0,3 final scenario/replay tests passed before added natural plant extinction.
- `cargo test --locked --lib --tests > target/task018-regression.log 2>&1`:
  exit0,166 Rust tests at that stage (before fourth integration test).
- `cargo test --locked --example ecology_report > target/task018-helper.log 2>&1`:
  exit0,1 helper test passed.
- `env -u DISPLAY cargo run --locked --release --example ecology_report > tasks/TASK-018/handoffs/ecology-cycle1.json`:
  exit0 twice; final run uses final enhanced audit, stderr captured in
  target/task018-report-final.log. All5 seeds exactly10000, no omitted tails.
- `cargo test --locked --release --test ecology_integration --example ecology_report -- --nocapture > target/task018-targeted-final.log 2>&1`:
  exit0,4 integration plus1 example test passed. The later phase-report equality
  assertion was additionally verified by the final full suite.
- `./test.sh > target/task018-full-final.log 2>&1`: exit0,175 passed (97 unit,
  70 integration,1 rustdoc,7 Python),0 failures/skips/ignored. Host/musl setup/build,
  static ELF, copied-empty-root version/packaging checks passed. No legacy
  biological assertions needed weakening; only documented-default equality changed.
- `cargo fmt --check` and `git diff --check`: exit0 after final source changes.
- A premature ad-hoc JSON inspection while the report was still redirected saw
  an empty in-progress file and exited1. Completed final report validation passes
  schema,5 distinct seeds, complete10000 horizons, fixed-key scenario, effective
  selected defaults, extinct/survived consistency and population accounting.
- Final artifact validator below: executed with exit0 after handoff creation.

No new dependencies or install commands; inherited setup prerequisites in STATE
remain applicable. Full state/checkpoint/hash must later retain effective settings,
RNG/climate/resource/DNA/vitals/cooldown/species history; observer buffers excluded.
No required acceptance gaps or blockers. Harness assigns review and owns commits.

## Artifact validator

```python
from pathlib import Path
import json, subprocess
r = Path('/workspace')
h = json.loads((r/'tasks/TASK-018/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-018','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert actual == set(h['changed_files']), actual
for f in actual: (r/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
v=json.loads((r/'tasks/TASK-018/handoffs/ecology-cycle1.json').read_text())
assert v['schema']==1 and v['ticks']==10000 and v['seeds']==[0,1,2,42,99]
assert len(v['runs'])==5 and {x['seed'] for x in v['runs']}==set(v['seeds'])
for x in v['runs']:
    c=x['effective_config']
    assert c['seed']==x['seed'] and x['tick_end']==10000
    assert c['world']==v['scenario']['world'] and c['initial']==v['scenario']['initial']
    assert c['plants']['resource_regeneration']==2 and c['animals']['reproduction_cooldown']==100
    assert set(x['kinds'])==set(c['initial'])
    for k,a in x['kinds'].items():
        assert c['initial'][k]+a['births']==a['deaths']+a['final']
        assert a['survived']==(a['final']>0)==(a['first_zero_tick'] is None)
        if a['first_zero_tick'] is not None: assert type(a['first_zero_tick']) is int and 0<=a['first_zero_tick']<=10000
b=json.loads((r/'tasks/TASK-018/handoffs/balancing-cycle1.json').read_text())
assert len(b['runs'])==69
subprocess.run(['cargo','fmt','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS handoff UTF-8/schema/inventory, protected scope, no remotes, full report and formatting')
```

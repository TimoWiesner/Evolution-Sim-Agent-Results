# TASK-018 PLAN cycle 1

## Entry and findings

Required /workspace/AGENTS.md and docs/STATE.md verified before inspection.
Applied .agents/skills/plan/SKILL.md. Read product/contract, state/architecture,
task specification/JSON, dependency phase handoffs and relevant ADRs/core/docs/tests.
Some combined outputs truncated; focused source and handoff reads supplied relevant
interfaces. No earlier TASK-018 handoffs exist; dependencies TASK-012/014/015/016/017
have REVIEW PASS and empty gaps. Initial Git tree clean, remote list empty.
This phase edits documentation only, with no feature code, installs, commits,
benchmark-state changes or phase transition. No interactive questions.

Simulation::advance_one_tick already runs all seven phases. Simulation owns the
sole RNG and orchestrates ecology; Population exclusively owns lifecycle, spatial
cache and species mutation. Existing public APIs suffice for integration tests and
an example runner: Config::from_json/to_json/preset; Simulation::new,
advance_one_tick, tick, population, world, rng_state; Population::iter/counts/
totals/deaths_by_cause/species; registry get/iter/living_count. Counts are u128.
No public spawn or mutable organism API exists. Founders use [32768;12], reserve
1000, deterministic row-major positions (all kinds share a single ordinal),
lifespan1100, no initialization RNG draws. These initial conditions can mask
failure to sustain descendants. Prior tests mostly use tiny worlds, isolated
cost overrides or short birth observations; their PASS does not prove default
viability or the requested long-run report. CLI currently has no run command.

## Decisions

ADR-014 records order, default balancing policy, alternatives and ecological
mechanisms. Keep the current order and all existing paid biological policies.
Do not refactor a working engine just to make integration appear new. Add tests,
a small library-driven example and measured documentation; fix production only
where a failing requirement identifies a real issue. Use centralized existing
optional defaults as candidate0, then bounded measured configuration tuning if
needed. Final selected values must actually pass default-only acceptance tests.
No arbitrary coexistence threshold, global rescue, new authoritative state,
checkpoint format, UI, CLI command, dependency or TASK-027 broad optimization.

## Ordered implementation when IMPLEMENT is assigned

1. Add tests/ecology_integration.rs with helpers parsing JSON containing only
   seed/world/initial, advancing real Simulation ticks, and auditing population.
   Use fixed seeds [0,1,2,42,99]. The audit compares initial+births = deaths+live
   in u128 (avoid unsigned subtraction underflow), sums independently iterated
   organisms by kind and death causes, checks finite positive bounded vitals,
   valid wrapped coordinates and age=tick-birth_tick. Compare species member
   counts and unique living species IDs to registry queries at tick0 and after
   every completed tick. Remember first zero and assert it remains zero AND
   births do not increase afterward, even when all kinds are empty. Every tick
   must advance once, including weather clock. Keep reports observational.
2. Establish candidate0 behavior with public production runs before tuning:
   (a) exact contract fixed-key example,64x48,400/120/20,seed42, >=1000 ticks;
   (b) plants-only64x48,400/0/0, >=2200 ticks;
   (c) abundant-plants64x48,2000/120/0, >=600 ticks;
   (d) no-plants64x48,0/120/20 and no-herbivores64x48,400/0/20, >=5000 ticks;
   (e) all-zero64x48 for >=1000 ticks. Default options remain omitted in all.
   For b/c repeat seeds0,1,42 at minimum. Record initial findings and runtimes
   in implementation handoff, including failures. No test-only resource/vital
   reset, spawning, special placement or reproduction override is allowed in
   default viability fixtures. Existing tiny controlled unit tests remain valid
   for policy gates but cannot substitute for these integration requirements.
3. If b/c fail, tune existing defaults in src/config.rs as ADR-014 specifies.
   Inspect actual limiting cause/energy/resource/age and births, using readonly
   public observations. Start with resource regeneration2/4 and efficiency0.75/1
   if primary production is inadequate; consider movement0.1/0.05, animal
   reproduction cost20 and cooldown40 if paid navigation/recruitment is limiting.
   Prefer minimal changes, no blind exhaustive sweep. Re-run b/c and extinction
   scenarios for each accepted candidate; record exact effective JSON and
   outcome of every attempted set. Keep extinction possible and finite. No
   mortality floor removal, immortality, free child energy, population-aware
   feedback or initial-only gene manipulation. If defaults change update
   tests/config.rs expectations, docs/CONFIGURATION.md defaults, PLANTS/ANIMALS
   illustrative defaults and ADR-014 implementation evidence. Audit tests that
   hardcode20/30 costs: explicitly configure old values for isolated numeric
   fixture purposes, retaining default-enabled integration and full production
   replay. Do not weaken conservation, numeric guards or extinction assertions.
4. Add examples/ecology_report.rs, using only existing public library APIs and
   serde_json/std (no crate needed). With no arguments it constructs the exact
   contract fixed-key world/counts with seeds0,1,2,42,99, expands defaults via
   Config, and advances each for exactly10000 ticks. Emit one JSON document
   on stdout; errors to stderr/nonzero, no partial success artifact. Include
   schema/version, ticks10000, seed list, scenario fixed-key input and effective
   config for every seed; per kind first_zero_tick (integer or null), survived
   (zero-at-end is false), final population and cumulative births/deaths; also
   tick_end and measured loop seconds. Distinguish null meaning survived through
   horizon from tick0 initial absence. Report coexistence ticks only as additional
   observation. First-zero tracking is external to Simulation and draws no RNG.
   Audit conservation and absorbing-zero during the loop, including empty tails.
   Reuse small local runner helper functions rather than add a metrics subsystem.
   Optional config/horizon flags are unnecessary; no application CLI changes.
5. Test report logic on short runs and initially absent kinds (unit tests in the
   example or shared test helper), verifying tick0/first-zero/null conventions,
   tick_end, schema and conservation. Public integration must separately prove
   known finite extinctions so an all-null report bug cannot pass. A run that
   ends early or times out must not be labelled10000. No wall-clock pass/fail
   threshold, exact runtime assertion or exact stochastic extinction-tick golden
   is needed. Existing engine tests prove repeatability; add same-config fresh
   Simulation equality/replay over1000 ticks, with new audits/observations on
   only one copy, to cover integrated default behavior/query purity.
6. Run the documented command from /workspace:
   `env -u DISPLAY cargo run --locked --release --example ecology_report > tasks/TASK-018/handoffs/ecology-cycle1.json`
   Ensure exit0, parse the saved UTF-8 JSON, require5 distinct seeds,10000 end
   ticks each,3 kinds each, valid extinct/survived consistency, exact effective
   defaults and accounting. Run sequential seeds to bound memory and allow
   per-seed progress to stderr. Do not stop ticking on extinction. Capture
   compiler/runtime version, available within-workspace hardware metadata, release
   command, observed durations and all results in docs/ECOLOGY.md plus handoff.
   State hardware undisclosed if unavailable; respect workspace-only file access.
   The raw JSON artifact is tracked task-local evidence, not ignored target data.
   Record failures honestly; do not turn a collapse into a test failure. If tuning
   follows a report, rerun ALL5 seeds for final defaults; identify superseded runs.
7. Document implemented order and allowed mechanisms in docs/ECOLOGY.md; link
   it from README.md with the example command (not a fictional evosim run).
   Remove/correct stale future-ecology wording in touched current docs, preserving
   historical phase records. Update ARCHITECTURE/STATE/ADR-014 with actual files,
   selected values, test evidence, limitations, and no unmeasured coexistence or
   speed claim. Keep disk persistence and application CLI outside TASK-018.
8. Run targeted tests, report helper tests, full ./test.sh, cargo fmt --check and
   git diff --check. Record exact command, exit, counts and all failures/fixes.
   Write IMPLEMENT handoffs when assigned; harness owns commits and transitions.

## Acceptance matrix and concrete assertions

| Must have | Planned evidence |
|---|---|
| Documented complete order | docs/ECOLOGY.md and ADR-014 match src/simulation.rs; existing TICK_PHASES report test plus production full-tick cross-phase test in src/simulation/animal_reproduction_tests.rs. Retain real birth/hunt/death/Commit coverage; a phase-name list alone is insufficient. If a missing integration timing case is found, add a controlled private full-tick test, not an alternate dispatcher. |
| Fixed keys >=1000 ticks | Exact contract example only fixed keys, default options omitted, advance1000 with audits each tick; repeat/fresh replay. Extinction does not fail this test. |
| Creation only initialization/reproduction; zero absorbing | Inspect only2 living insertion paths in Population; accepted queue requires live same-kind parent(s). Matrix includes each initially absent kind/all-zero and naturally reached zero, frozen births thereafter through full horizon. Existing pending-child/Commit timing regression retained; completed-tick zero is the invariant. |
| Food-removal scenarios | No plants: herbivores and carnivores both zero by5000, record each first zero and continue. No herbivores: carnivores zero by5000, no herbivore births. All default settings retained. To show trophic starvation rather than only age expiry, retain existing high-basal controlled starvation tests; don't require a universal ordering of last herbivore vs last predator, since predators may collapse earlier naturally. Add a documented deterministic default scenario showing herbivore-first then predator extinction if initial experiment permits; task wording motivates finding one, not introducing a global ordering rule. |
| Per-kind ledger every tick | Audit tick0 and every tick in all new scenarios and long report, independent live/cause/species oracles and equality initial+births=deaths+living. |
| Default isolated viability | Plants-only alive at EVERY tick through2200, births>0, living generation>=1 after1100 proves replacement beyond founder lifespan. Abundant plants/herbivores alive at EVERY tick through600; herbivore births>0 by300 AND an increase in cumulative births during ticks300..600 proves sustained recruitment beyond early founder burst; descendant living at600. Plants reproduce there too. Seeds0,1,42, no optional overrides.600 is explicit interpretation of several hundred. If hard to achieve, diagnose/tune; never silently shorten horizon/drop seed or weaken required behavior. |
| Five-seed10k recorded command | Exact example command above, final raw JSON and docs table for every seed/kind with actual first zero or survived10000; ticks advance exactly10000 regardless collapse. No mandatory coexistence duration threshold. |

The no-plants wording needs visible food-chain collapse, not a universal stochastic
extinction ordering claim: report actual times. If all chosen default no-plant
fixtures have predators disappear first, search a bounded set of initial counts
(e.g. herbivores20/120 and carnivores1/2/20, seeds0,1,2,42,99) for one natural
herbivore-first case, record the complete selected fixed-key config, assert that
case's order and retain broad no-food tests. Do not assume a pair of prey-free
monotonic founders tests covers reproducing populations. Avoid unbounded searches.

## Verification performed in PLAN

`env -u DISPLAY cargo test --locked --test plant_reproduction --test herbivore_feeding --test carnivore_hunting --test animal_reproduction --test species --test lifecycle --test simulation`
exit0:18 integration tests pass,0 failures/ignored (2 animal reproduction,
2 carnivore,2 herbivore,3 lifecycle,3 plant reproduction,4 simulation,2 species).
This is baseline evidence only, not execution of new acceptance scenarios or
five-seed10000-tick measurement. No new tests or product changes in this phase.
Required-file/Git probes succeeded, no remotes. No system packages installed;
existing setup.sh/STATE exact musl prerequisite reinstall commands still apply.

## Risks, time budget and boundaries

Default viability is unmeasured; high founder reserves, hostile initial latitude,
weak newborn budgets and synchronized founder aging may cause collapse. A report
with long empty tails can be quick but is not viability evidence. Dense animal
stacks, species/death lifetime history and O(area) climate/resource updates can
make viable long runs expensive. Run release code, measure one1000-tick sample
before committing the long run, then start final report with >=15 minutes left
in the60-minute implementation budget. Use tool polls <=60s with progress updates.
Reserve time for full suite and UTF-8/schema handoff validation; don't silently
reduce seeds/ticks or discard history. Report any timed-out/incomplete run honestly.
No system dependencies planned. No production architecture redesign, balancing
coexistence guarantee, CLI/UI or persistence work. No prior REVIEW gaps or current
blocker; final default selection intentionally depends on actual measurements.

## Planning validator

Run the fenced Python block after JSON exists:

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
p=r/'tasks/TASK-018/handoffs/plan-cycle1.json'
h=json.loads(p.read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-018','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-014-ecology-integration.md','tasks/TASK-018/handoffs/plan-cycle1.md','tasks/TASK-018/handoffs/plan-cycle1.json'}
assert actual==set(h['changed_files'])==expected,actual
for f in actual: (r/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected scope, no remotes, whitespace')
```

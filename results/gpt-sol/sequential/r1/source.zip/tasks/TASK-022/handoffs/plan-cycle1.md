# TASK-022 PLAN cycle 1

Planning only. Required /workspace/AGENTS.md and docs/STATE.md verified first.
Read project, contract, state, architecture, task/spec, PLAN skill, dependency
TASK-005/007/017/019 handoffs and relevant ADRs; inspected current core owners,
canonical encoding, persistence, CLI runner/output, tests and recent TASK-021
handoff. Dependencies REVIEW PASS without gaps. No prior TASK-022 handoffs or
review gaps exist. Initial Git tree clean; git remote -v empty. Bulk output was
sometimes truncated; bounded source-specific reads established the inventory.
No code, tests, dependencies, task state or protected files changed in PLAN.
No system packages installed; inherited setup.sh musl reinstall commands in STATE
remain applicable. Harness owns commits and phase transitions.

## Findings and binding decisions

See ADR-018 for exact envelope, API, validation, ownership and error policy.
Existing canonical encoders already cover the full required state. Persistence
currently hashes only. Rng::from_state and TemporalClimate::from_state validate
component restoration, but Simulation/Population/Species/Resource owners have no
production restore interface. Population owns private counters/index/history;
SpeciesRegistry owns private records. Add owner-local inverse readers instead
of broad mutable fields or a shadow serialization model.

Existing runner::simulate constructs an engine and hardcodes tick_start0, samples
on absolute tick modulus and decides final inclusion from requested ticks. A
loaded engine requires a shared state runner with invocation-relative sampling
and actual start/end. Keep existing config wrapper for batch, preserving batch
results at start0. Do not change ecology, config defaults, RNG order, metrics,
state_hash schema1/golden, scheduler or runtime dependencies.

File choice: uncompressed binary canonical schema1 inside version1 length/checksum
envelope; no new dependencies. Exact format and rationale are ADR-018. Restore
all state, reject invalid values, rebuild only derived cache, never replay
initialization or classify organisms again. No UI saving/loading in this task.

## Ordered implementation plan

1. Add private Decoder in src/canonical.rs, leaving existing Encoder output
   unchanged. Fixed little-endian primitives, bit-exact floats, bounded UTF-8,
   lengths and option/enum tags. Use io::Error InvalidData for malformed payloads,
   checked arithmetic/usize conversions and remaining-byte bounds before allocating.
   Add primitive round-trip/truncation/invalid-tag/UTF-8/oversized-length tests.
2. Add crate-private read_canonical methods beside owner encoders in
   src/{config,topology,climate,temporal_climate,rng,genome,organism,resources}.rs.
   Keep constructors/validators shared rather than weaken validation. Config
   decoding retains every effective value and full normalized seed, with float
   bits exact; if using Config::from_value, exercise all finite accepted extremes,
   negative zero and re-encode equality. Raw out-of-grid cells reject before
   wrapping. Resources restore exact row-major values, not initial capacity.
   RNG and weather use existing state constructors, including settings bounds.
3. Add inverse/validation in src/species.rs and src/population.rs. Read sorted
   unique IDs, retained extinct species, all history/counters/allocator/sequence,
   organisms/genomes/lineage/cooldowns, with no species assignment/RNG draws.
   Completed-tick pending lengths must be zero. Validate ADR-018 local and cross-
   record invariants with checked arithmetic. Match actual production invariants:
   IDs start1; every allocated organism is living or in death history; death
   history is retained in commit order, not sorted ID order. Avoid requiring dead
   parents alive or genes to be reclassified. Rebuild SpatialIndex from validated
   living map only after validation; errors return without exposing partial state.
4. In src/simulation.rs add crate-private read_canonical assembling validated
   config, world, tick/RNG and population without Simulation::new. Validate exact
   state magic/schema, ordered model identity strings/versions and duplicate
   settings/dimensions/tick agreement. Factor model identity block into a shared
   private constant/helper if useful while retaining identical encoded bytes.
   Expose no public core setters. No reverse imports to persistence or CLI.
5. Extend src/persistence.rs with public checkpoint_bytes, from_checkpoint_bytes
   and load_checkpoint APIs from ADR-018. Verify actual envelope length, magic,
   version and SHA checksum before decoding; reject trailing bytes. Check valid
   re-encoding equals payload, so all stored canonical values survive. Path load
   rejects nonregular input and errors contextually; all runtime remains offline.
   Tests use byte API without requiring paths/UI. Update module rustdoc.
6. Refactor src/cli/runner.rs to retain simulate(Config,N,K) for batch and add
   simulate_state(&mut Simulation,N,K) returning owned result JSON. Caller retains
   final engine for optional checkpoint encoding. Check start+N overflow before
   mutation, actual absolute result ticks, unchanged default max(1,N/100), samples
   at start and each K additional ticks and end once (N0 only one row). Retain
   Snapshot capture and tick-only finite timing, cumulative counters and full seed.
7. Extend src/cli/run.rs and help in src/cli.rs with --save/--load forms. Exactly
   one config/load, reject seed with load, existing strict duplicate/missing/unknown
   parsing, validate N/K and destinations/aliases before simulation. Use shared
   private path identity helpers in cli/output.rs if useful (batch already has
   alias checks; inspect/reuse without changing batch policy). Allow load=save;
   reject result aliasing input and save aliasing config/result, including hard
   links and normalized parent spellings. Encode checkpoint/result before writes,
   publish save first and result last via existing atomic publisher. Errors status2,
   stderr only, absent result stays absent and existing result preserved. Document
   checkpoint may remain if final result promotion fails. No batch checkpoint flags.
8. Add tests/checkpoint.rs and tests/checkpoint_cli.rs (or equivalently explicit
   tests/run_cli.rs groups), owner-local malformed-state tests and entrypoint/
   packaging coverage. Update obsolete run tests that reject valid save/load
   flags, keeping malformed forms rejected. No test should rely only on all-empty
   states or equal hashes immediately after decoding. Test future continuation.
9. Add docs/CHECKPOINTS.md with format, full inventory/exclusions, commands,
   sampling, compatibility, load validation, publication/resource/cross-build
   limits. README contains runnable config save/load and load=save examples.
   Update STATE/ARCHITECTURE/ADR-018 status with actual implementation evidence.
   Run commands below, record honest outcomes/deviations, write IMPLEMENT handoff.
   Remain in assigned phase; harness assigns review and commits.

## Acceptance and regression matrix

1. Contract --save/--load equivalence: real binary fixed-key small mixed world,
   several seeds, compare uninterrupted T=200 with splits A=0,7,53 (B=T-A).
   Require identical state_hash/final/totals and effective numeric seed, absolute
   start/end; loaded series starts A, advances K=13 relative to A and ends T
   without duplicates. Compare matching sampled metrics with direct engine
   snapshots; do not compare concatenated series or timings. N0 load/save yields
   one sample and unchanged checkpoint/hash. Repeat checkpoints in a chain and
   allow replacement --load FILE --save FILE. Seed/config conflicts reject.
2. Complete state: byte round-trip at tick0, mixed populated early tick (animals
   alive and nonzero weather), reproducing plant/abundant-food animal fixtures,
   post-death/extinct-species histories and entirely empty worlds. Compare exact
   canonical bytes/hash and read-only state before/after serialization, then
   advance original and restored side-by-side for >=100 ticks comparing full
   canonical state, RNG, weather/resources, memberships, cooldowns and metrics
   at each tick. Include seeds of arbitrary magnitude/negative/modulo equivalence,
   weather off/on, degenerate toroidal axes and depleted resources. Use existing
   cfg(test) fixture helpers for guaranteed sexual births/cooldown/speciation;
   independently include production-only public scenario continuation. Exercise
   plant renewal beyond2200 and animal recruitment through600 from existing
   ecology fixtures with strategically placed saves; total test cost bounded.
3. Version: independent header byte fixture asserts magic17, version u32=1,
   payload length u64 and digest location/coverage. State schema/model/RNG/weather
   versions also validate. Confirm unchanged ADR-015 golden hash and deterministic
   identical checkpoint bytes, same-build replay and no RNG consumption on save.
4. Errors: missing/unreadable/nonregular paths, empty/random bytes, every prefix
   truncation of a small valid checkpoint, selected bit flips including digest,
   length over/underflow and maximum u64, wrong envelope/state/model versions,
   appended bytes and malformed UTF-8/tags. CLI must return2, stderr nonempty,
   stdout empty, absent --out stays absent; existing output sentinel unchanged.
   Test invalid internal state with RECOMPUTED checksum so semantic checks execute:
   all-zero RNG; mismatched settings/clocks/topologies; NaN/Inf/bad resource/vital
   bounds; coordinate overflow; duplicate/unsorted IDs; broken species/lineage/
   cooldown chronology; wrong counters/cause history/membership/allocator and
   nonempty pending queues. Owner fixtures can focus individual fields; do not
   add a public mutation API. Huge record counts in tiny files fail before reserve.
   Arbitrary-byte deterministic generated corpus must return Err without panic.
5. Split requirement: explicit tick0 and at least two nonzero split CLI cases
   above; use tests with a fixed expected absolute schedule [7,20,33,...,200]
   to catch runner's current zero-origin assumptions. Save0+resume with an
   explicit --seed config override preserves original exact seed and stream.
   Loaded start+N overflow rejects before any new output/checkpoint publication.
6. Filesystem: bad save destination/missing parent, directory/symlink/FIFO, same
   save/result, output alias input, hard links and relative aliases; preserve
   inputs. load=save allowed. Inject write/flush/rename failures (root bypasses
   chmod) into existing helper and run publication sequencing; no temporary leaks,
   no new result after save failure. Result failure after save is documented and
   tested. No two-file atomicity or fsync promise. All artifacts stay in workspace.
7. Regression/package: unchanged state_hash golden, metrics/run/batch suites,
   no ecology/default/canonical output drift. Extend tests/test_entrypoints.py
   with actual root launcher and dist save0/load plus nonzero split, unrelated
   cwd/spaced paths and displays unset. In copied empty chroot run dist save/load
   against its own uninterrupted run (N modest, e.g.30 split7); static musl checks
   retained. Do not require host/musl hashes equal to each other. No network/display
   at runtime; test.sh builds both targets and handles missing musl prerequisites.

Planned IMPLEMENT commands (new tests do not exist yet):
- cargo test --locked --lib
- env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test checkpoint_cli --test state_hash --test run_cli --test batch_cli
- ./test.sh > /workspace/target/task022-implement-full.log 2>&1
- cargo fmt --check
- git diff --check

## Risks, evidence and handoff

Primary risk: missed private state or over-strict invented invariants. Inventory
against ADR-015 encoders and actual production state; canonical re-encode equality
and future continuation complement checksum validation. Empty-world-only tests
cannot expose missing cooldowns/lineage. Decoder must bound corrupted lengths
against actual bytes, not trust checksum or a count. Full-history memory/disk is
unbounded; Vec checkpoint APIs add a complete byte buffer, while existing histories
already grow indefinitely. Same-build determinism is required, no migration or
cross-build floating guarantee. No new dependency/system installation expected.
Reserve final10 minutes of IMPLEMENT for full suite/documentation/handoff.

Actual PLAN baseline command:
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test rng --test temporal_climate --test species --test state_hash --test run_cli --test batch_cli`
exit0:24 passed (5 RNG,5 temporal,2 species,2 state_hash,5 run CLI,5 batch),
0 failed/ignored. This verifies existing behavior, not checkpoint implementation.
No full suite/package build or feature test was run in PLAN. JSON handoff and
scope validator command/result are recorded in plan-cycle1.json.

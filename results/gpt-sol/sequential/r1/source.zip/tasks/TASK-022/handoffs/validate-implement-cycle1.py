"""Validate this phase's persisted handoff and permitted changed paths."""
import json
import subprocess
from pathlib import Path
root = Path('/workspace')
p = root / 'tasks/TASK-022/handoffs/implement-cycle1.json'
v = json.loads(p.read_text(encoding='utf-8'))
assert (v['task_id'], v['phase'], v['cycle'], v['verdict']) == ('TASK-022', 'implement', 1, 'N/A')
assert type(v['cycle']) is int and isinstance(v['summary'], str)
for key in ['changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps']:
    assert isinstance(v[key], list), key
for t in v['tests']:
    assert isinstance(t['command'], str) and type(t['exit_code']) is int and isinstance(t['notes'], str)
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).splitlines()
changed = set(git('diff', '--name-only')) | set(git('ls-files', '--others', '--exclude-standard'))
assert changed == set(v['changed_files']), (changed, v['changed_files'])
for path in changed:
    assert path not in ['AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md']
    assert not path.startswith(('.agents/', 'tools/', 'benchmark'))
    assert not path.startswith('tasks/') or path.startswith('tasks/TASK-022/handoffs/implement-cycle1.') or path == 'tasks/TASK-022/handoffs/validate-implement-cycle1.py'
    (root / path).read_text(encoding='utf-8')
assert not git('remote', '-v')
subprocess.run(['git', '-C', str(root), 'diff', '--check'], check=True)
print('TASK-022 IMPLEMENT handoff/scope/UTF-8/whitespace/remotes validated')

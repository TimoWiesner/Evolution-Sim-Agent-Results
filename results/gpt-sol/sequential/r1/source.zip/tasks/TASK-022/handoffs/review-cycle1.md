# TASK-022 REVIEW cycle 1

Verdict: PASS. All five acceptance criteria met; no gaps or remediation required.
External harness checks remain authoritative.

Verified /workspace/AGENTS.md and docs/STATE.md first. Applied the repository
review skill. Inspected task/specification, PROJECT/CONTRACT/STATE/ARCHITECTURE,
current plan/implementation handoffs, dependency TASK-005/007/017/019 handoffs,
relevant ADR-001/004/006/015/018 and actual implementation diff b8c36d7..651f58c.
Initial working tree clean and no remotes. No product changes, added tests,
packages, commits, protected-file edits or phase transitions. Large initial reads
were truncated; targeted reads supplied task-relevant source and evidence.

Acceptance evidence:
1. CLI config/load exclusivity, optional save, loaded absolute clock, checked
   tick overflow, cumulative totals and invocation-relative sampling are correct.
   tests/checkpoint_cli.rs compares T200 splits0/7/53 for two seeds, including a
   large negative seed; hash/final/totals/seed and matching metrics rows agree.
   Zero-tick replacement and chained loading preserve checkpoint bytes.
2. Compared owner encoders/readers and struct fields: effective settings, topology,
   climate model and weather offsets/tick, clock, full RNG, exact resources,
   organisms/DNA/vitals/parents/generation/cooldowns/species memberships, complete
   species history/founders/ancestry/extinctions, allocator/request sequence,
   u128 counters/cause totals and ordered death history all survive. Only derived
   spatial cache and procedural climate are rebuilt. No initialization, species
   classification or RNG draws occur during restoration. Final canonical
   re-encoding rejects repaired/noncanonical payloads. Future-state tests compare
   full Simulation/hash and reproduction through plant2250/herbivore650, with
   private forced-speciation tests covering both animal reproduction policies.
3. Independent byte checks and tests confirm 17-byte magic, LE version1, payload
   length, unchanged schema1 and SHA-256 covering header+payload. No compression
   is explicitly chosen and justified in ADR-018; golden state hash unchanged.
4. CLI missing/damaged/truncated/wrong-version cases return2, stderr, empty stdout
   and no absent result created; preexisting sentinels survive. Tests additionally
   cover special files, aliases/hard links, conflicts, save failures and overflow.
   Byte tests cover every prefix and high-bit flip of a small checkpoint, trailing
   data, arbitrary corpora and checksummed semantic corruption. Lengths bound
   record allocations; cross-owner accounting and chronology are validated.
5. Tick0 plus multiple nonzero split tests run via byte APIs, real CLI, launcher,
   static dist and copied empty-root execution. Additional independent debug CLI
   probe used the exact fixed-key contract64x48 configuration at T300 with
   splits0/37/117 (seven runs). Hash/final/totals agree and Python hashlib verifies
   checkpoint checksum/length/version independently.

Executed checks, all exit0:
- ./test.sh > /workspace/target/task022-review-full.log 2>&1
  225 passed:125 unit,89 integration,1 rustdoc,10 Python;0 failed/ignored/skipped.
  Includes setup twice, host/musl/build, static ELF and actual copied empty-root
  save/resume. Log counter independently confirms215 Rust plus10 Python.
- cargo fmt --check && git diff --check
- Inline Python contract-world CLI/envelope probe described above.
- Final UTF-8 JSON/scope/protected-path/remotes/whitespace validator (recorded in
  JSON). The implementation validator assumes uncommitted implementation paths;
  checked its inventory against HEAD^..HEAD instead of invoking it unchanged.

No architecture or ADR amendment needed. Review changes only STATE and these
handoffs. No redundant review tests added. Remaining documented limits are memory/
disk exhaustion for legitimate huge histories, same-machine/build floating
continuation, no version migration, no concurrent same-output writers, no fsync
or two-file transaction. These are not acceptance gaps. No separate fresh Ubuntu
or minimum-Rust validation claimed. No system dependencies installed; existing
STATE/setup.sh installation commands remain applicable. UI persistence remains
TASK-024. Harness owns completion, phase commits and subsequent assignment.

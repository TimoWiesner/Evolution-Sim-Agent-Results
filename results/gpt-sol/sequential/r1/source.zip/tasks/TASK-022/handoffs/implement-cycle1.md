# TASK-022 IMPLEMENT cycle 1

Scope: IMPLEMENT only, approved plan and ADR-018. Required workspace files were
verified first. Initial tree clean, git remote -v empty. No commits, task/spec,
benchmark, protected instruction or phase-state edits. No system packages or new
crate dependencies installed. Existing setup prerequisite commands in STATE apply.
Dependencies TASK-005/007/017/019 have REVIEW PASS and no handoff gaps.

## Implementation and ownership

Format1 is an uncompressed, length-delimited schema1 canonical payload with magic,
version and SHA-256 over header/payload; no change to canonical encoder bytes,
existing state hash golden, config defaults, biological equations or RNG order.
Decoder bounds lengths against remaining bytes before allocation. Existing owners
read their own private data; Simulation assembles without initialization or
reclassification and persistence verifies exact re-encoding. Dense spatial cache
and procedural base climate alone are rebuilt. No public state mutation API.

The complete authoritative inventory in ADR-015 is retained, including original
seed text, weather/resources, genomes/parents/generation/cooldowns, historical
extinct species, ordered deaths, u128 counters, next-ID discriminant and request
sequence. Validation covers local and cross-owner invariants; allocation is a
contiguous unique union of living and dead IDs and completed-tick request sequence
equals accepted births (confirmed against queue_birth/Commit). Historical parent
DNA/lineage is not stored by the existing state model and is not invented.

Runner retains simulate(Config,N,K) for batch and exposes private simulate_state
with actual start tick, checked start+N and invocation-relative sample schedule.
Run allows exclusive config/load plus optional save, forbids seed with load,
protects aliases/hard links, allows load=save and publishes checkpoint before
result using existing atomic helper. Private publish_results tests ordering with
injected failures. No UI saving/loading; no multi-file transaction/fsync promise.

## Test design and development corrections

Public CLI tests compare T200 at A0/7/53 for two exact seeds (including a large
negative integer), hash/final/totals, loaded sample ticks and metrics against
uninterrupted every-tick snapshots. Byte API tests restore A0/7/53/200 across
mixed/tiny/empty worlds then compare full state/hash over100 further ticks.
Long production fixtures checkpoint plants at2100 and continue to2250 and
abundant-food herbivores at301 through650; assertions require reproduction and
cooldowns. Coherent mature-founder fixtures force speciation in all kinds,
including both sexual policies, before100 future equal ticks. Weather on/off,
resource extremes and signed-zero config values are round-tripped.

Corruption tests reject every prefix truncation and individual byte high-bit flip
of a small checkpoint, trailing bytes, random corpora, wrong versions/lengths,
and malformed canonical primitives. Recomputed-checksum tests reach model, RNG,
weather and resource validation. Semantically invalid encoded simulations and
owner fixtures cover vitals/coordinates/chronology/membership, allocation/counters,
ancestry/names and pending lengths. CLI errors preserve existing result sentinels
or leave absent outputs absent; includes FIFO/directory/symlink, missing parent,
hard links, conflicts, duplicates and tick overflow. Root-safe atomic writer
write/rename fault tests are retained, with publication-order injection added.
Real launcher/dist and copied empty-root tests save/resume at0/7/13 with spaced
paths, unrelated cwd and no display variables.

Development failures were test-fixture issues, not hidden successes:
- First checkpoint integration compilation failed (101): a format! closing brace
  was missing. Corrected before tests ran.
- First targeted run failed (101): old run_cli test expected --save to be unknown.
  It now tests a duplicated --save, preserving malformed-option coverage.
- First forced-speciation test failed (101): required3 species even for the
  one-founder plant fixture. Corrected to2 for plants and3 for animals.
- First long fixture and first full suite failed (101): basal_cost=-0.0 is outside
  existing config bounds. Changed the signed-zero test to movement_cost; production
  validator/defaults unchanged. The long reproduction cases had already completed.
- A final test inspection moved fresh initialization inside each byte split loop
  so labels0/7/53/200 are actual split ticks, and added loaded metrics equality.

Plan refinements: direct config construction retains original float bits after
existing to_json/from_value validation (no JSON decode round-trip of stored bits).
Historical lookup uses ordered maps rather than quadratic history scans. Test
coverage uses representative semantic owner mutations and deterministic corpora,
rather than every possible Cartesian combination in the planning matrix. No
unreadable-permissions claim under root, concurrent-writer/race test, separate
minimum-Rust build or fresh-container OS replacement is made. These do not omit
any required task behavior; exact command evidence is in adjacent JSON.

## Verification and handoff

See implement-cycle1.json for exact commands, exit statuses and final totals.
Logs live under ignored target/task022-*.log. Documentation: CHECKPOINTS.md,
README, ADR-018, STATE and ARCHITECTURE. Handoff validator checks UTF-8 JSON,
identity/required fields, changed-file inventory, protected paths, no remotes and
whitespace. Harness owns REVIEW, commits and task transitions. No next phase
started. Future UI adapter may use byte/path APIs but must retain publication and
complete-state invariants; future authoritative changes must update both codecs,
model/schema identities and tests together.

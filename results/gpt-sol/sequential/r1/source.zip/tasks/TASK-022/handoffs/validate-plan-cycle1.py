from pathlib import Path
import json
import subprocess

root = Path('/workspace')
h = json.loads((root / 'tasks/TASK-022/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required = {'task_id', 'phase', 'cycle', 'summary', 'changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'verdict', 'gaps'}
assert required <= h.keys()
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-022', 'plan', 1, 'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'], str)
for key in ('changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps'):
    assert isinstance(h[key], list)
for test in h['tests']:
    assert isinstance(test['command'], str) and type(test['exit_code']) is int and isinstance(test['notes'], str)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).splitlines()
actual = set(git('diff', '--name-only') + git('ls-files', '--others', '--exclude-standard'))
expected = {'docs/STATE.md', 'docs/ARCHITECTURE.md', 'docs/decisions/ADR-018-checkpoints.md', 'tasks/TASK-022/handoffs/plan-cycle1.md', 'tasks/TASK-022/handoffs/plan-cycle1.json', 'tasks/TASK-022/handoffs/validate-plan-cycle1.py'}
assert actual == expected == set(h['changed_files']), actual
for file in actual:
    (root / file).read_text(encoding='utf-8')
assert not git('remote', '-v')
assert not git('diff', '--name-only', '--', 'AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md', '.agents/skills', 'tasks/*/task.md', 'tasks/*/task.json', 'tools')
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
print('PASS: UTF-8 handoff/schema, exact six planning files, protected scope, no remotes, whitespace')

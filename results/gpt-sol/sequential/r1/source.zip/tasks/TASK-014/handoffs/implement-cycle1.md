# TASK-014 IMPLEMENT cycle 1

Implemented approved plan and ADR-011 grazing model 1. Required workspace files
were verified first. Read project/contract/state/architecture, task/spec and plan
handoffs, dependency TASK-011/013 handoff summaries and review verdicts (PASS,
no gaps), relevant ADRs and source/tests; used .agents/skills/implement/SKILL.md.
Some combined inspection output truncated; focused reads supplied the relevant
interfaces. No interactive questions, system installs, Git remotes/network,
commits, protected-file edits or phase transitions. No known acceptance gap.

## Implementation and ownership

Private ecology/herbivores.rs implements pure current-temperature maintenance,
visible-predator risk eligibility and bite budgets, importing only config, traits
and topology. Simulation retains the shared age-first walker and orchestrates
maintenance -> sense/selection -> paid movement -> plant debit -> herbivore credit.
Population remains the only owner of mutations, immediate index changes and death
accounting. Movement executor now takes target/stop radius, retaining its real
per-step observer. Carnivores retain radius-0 navigation; herbivores stop at 1.

Maintenance is max(basal_cost,1e-9)*metabolism*(1+clamped thermal stress), every
living herbivore action; death preempts eating. Risk <0.5 excludes plants adjacent
to visible predators; choose nearest eligible plant then ID. No eligible plant
means ordinary exploration without an opportunistic bite. Own/eight adjacent
cells, including seams, are feeding reach. One bite requests min(4,plant energy,
headroom/0.8), debits the plant, measures realized removal and credits only 80%.
Zero energy removes the plant immediately as Starvation. No health payout,
refill, population-count feedback, attack or production animal birth was added.
No authoritative state, public mutation API, configuration/default or dependency
changes. Future persistence must include model identity/effective settings and
all existing authoritative state; transient targets/risk lists/cache are excluded.

## Acceptance evidence

1. Vision/reach: private visible_boundary_pursuit_speed_and_no_remote_bites checks
   min/max vision, exact boundary/outside, speed-1 starting distance 3 (no bite),
   distance 2 (bite), speed-4 pursuit and independent expected positions/RNG.
   feeding_reach_seams_degenerate_axes_and_full_tick_plant_ledger checks same,
   orthogonal, diagonal and wrapped cells on 11x9, 1x9, 11x1 and 1x1 worlds.
   Public animal_movement tests retain sense and unsigned distance oracles.
2. Conservative feeding: private bite_cap_capacity_roundoff_partial_depletion_
   and_one_target_only covers plant energy min-subnormal/0.5/4/5/1000, full/tiny
   headroom, one chosen plant among stacks, actual removal/gain ledgers and
   immediate index removal. Sequential tests distribute only the remaining
   6-unit stock as 4/2/0 to three consumers. Full ticks independently subtract
   plant physiology before bite. Depleted plant cannot recur; one death commits.
   A nonvacuous control actually reproduces without grazing, while the matched
   lethal bite prevents paid reproduction later in that tick.
3. Every-tick loss/death: public upkeep integration checks exact current-climate
   ledger and strict decrease without plants at basal min-subnormal/0.1/10/1e6,
   2200-tick absorbing extinction, no animal births, finite-time starvation for
   high upkeep. Private tests prove below/equal upkeep dies before adjacent food,
   no movement/draw/credit, max-cost death, OldAge priority, lethal movement and
   adjacent feeding without an affordable move. Explicit small-upkeep lifecycle
   test retains founder OldAge at tick 1100. Newborn acts/pays upkeep next tick.
4. Climate/genetics: pure helper tests verify ideal/thermal threshold/extreme
   twofold cost, metabolic endpoints and numeric bounds. Private current-weather
   real-tick test uses a nonsaturated 1x4 world, enabled weather/seasons, two
   temperature-preference genomes, and an independent current-cost oracle;
   explicitly verifies current differs from base climate. All-speed production
   pursuit checks positions and exact upkeep+movement+feeding energy ledgers
   for speeds 1..4 and both metabolic endpoints.
5. Behavior genes: paired clones differing ONLY in risk locus 11 select different
   food/positions/energy under identical surroundings. Alleles 0/32767/32768/
   65535 test threshold and wrapped danger; cautious selects a safe alternative.
   With only dangerous food cautious follows independently replayed exploration
   and does not bite, while bold pursues/bites. No predator and hidden predator
   cases produce equal feeding for both genomes. No global-count query exists.

Additional retained checks: sole RNG order weather -> herbivore exploration ->
carnivore exploration -> plant reproduction, no feeding/upkeep/risk draws, real
per-step paid adjacency/cache/death tests, shared lifecycle/newborn rules,
four-seed [0,1,42,u64::MAX] 2200-tick mixed replay with conservation, cause sums,
positive bounded vitals, spatial/sense oracles and absorbing extinction.

## Fixture migrations and deviations

Old herbivore tests assumed zero upkeep/consumption and radius-0 pursuit. Public
seam tests now check staying adjacent and feeding; private geometry/per-step
checks call the real navigation executor without the full herbivore policy.
Production pursuit is separately tested for all speeds/metabolic endpoints with
complete ledgers. Exploration full ticks explicitly include upkeep. Plant-only
establishment fixtures give their existing herbivore sub-upkeep energy so it dies
before grazing; the separate animal-sharing case uses a full living herbivore
that stays adjacent. No production bypass was added. Lifecycle still checks
accounting, ages, health and newborns, allows herbivore starvation, and separately
retains exact founder OldAge with positive small upkeep.

No model/behavior deviation. For readability private tests are in child module
src/simulation/herbivore_tests.rs rather than inline in simulation.rs; private
access and production execution are identical. No benchmark checks were changed.

## Actual commands and results

Commands ran from /workspace; log redirection suppressed routine terminal output.
Logs are retained locally in ignored outputs/TASK-014/; results below do not rely
on those artifacts surviving a later checkout.

- `cargo test --locked --lib --tests`: first run exit 101, 44 unit pass/8 fail.
  Failures were obsolete herbivore position/energy and plant-only grazing/sharing
  assumptions. After intentional fixture migration rerun exit 0, 110 Rust tests.
- `cargo test --locked --lib herbivore`: first new-test run exit 101, 10 pass/1
  fail. Climate fixture used a saturated 1x1 temperature equal to base; corrected
  to 1x4 and broad tolerance to show unequal preference costs/current temperature.
- `cargo test --locked --lib --test herbivore_feeding`: exit 0, 63 tests at that
  stage (61 unit plus 2 integration).
- `./test.sh`: initial full run exit 0, 131 tests. Added the nonvacuous
  grazing/reproduction control and sequential-stock regression afterward.
- `env -u DISPLAY cargo test --locked --lib --test herbivore_feeding --test animal_movement --test lifecycle --test plants --test plant_reproduction --test spatial --test simulation`:
  final targeted exit 0, 84 tests (64 unit,20 integration), no failures/skips.
- `./test.sh`: FINAL exit 0, 132 tests (64 unit,60 integration,1 rustdoc,7
  Python), no failures/skips; includes host/musl setup/build, static ELF and
  copied-distribution empty-root version checks.
- `cargo fmt --check`: exit 0. `git diff --check`: exit 0.
- The validator below is executed before return; results in structured handoff.

## Limits and next phase

Stable-ID scheduling biases access to shared food. Risk evaluation is O(visible
plants * visible predators) and cautious animals may starve beside risky food.
Dense area work and lifetime death-history growth remain. No throughput,
coexistence, disk persistence, separate fresh-container or older-toolchain claim.
No new system dependency; existing setup/reinstall commands in STATE apply.
Review should inspect acceptance evidence and independently run checks when
assigned. Harness owns task state, review start, commits and completion.

## Handoff validator

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-014/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-014','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(h['changed_files']),actual
for path in actual: (root/path).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact changed paths, protected files, no remotes, whitespace')
```

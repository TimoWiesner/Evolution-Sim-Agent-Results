# TASK-014 PLAN cycle 1

## Entry, findings and scope

Verified /workspace/AGENTS.md and docs/STATE.md exist before project inspection.
Applied .agents/skills/plan/SKILL.md. Read PROJECT, binding CONTRACT, STATE,
ARCHITECTURE, task.md/task.json, all prior task structured handoff summaries,
dependency TASK-011/013 plan/implementation/review evidence, relevant ADRs
001/003/004/007/008/010 and current config/genome/organism/population/ecology/
simulation/tests. Some bulk output truncated; focused source reads recovered
relevant interfaces. TASK-011/013 reviews PASS, no gaps. No previous TASK-014
handoffs, replan gaps or blockers. Initial Git tree clean and remote list empty.
Only planning documentation changes; no application tests or feature code here.

Current engine: seven ordered tick phases, one RNG, age-first ascending-ID shared
walker, immediate deaths/cache changes and end-tick birth/accounting Commit.
Plants pay maintenance, gain from local current-climate resources and reproduce
later in Reproduction. Animals currently only sense and move; herbivore and
carnivore share animal_movement_observed. Population::change_energy returns unit
and kills immediately at zero; read plant before/after to measure actual debit.
Risk locus 11 already exists; founders [32768;12] have risk slightly above 0.5.
Animal basal_cost is positive and defaults to 0.1, not yet consumed. CLI currently
has version/help/climate only: run/batch/UI/persistence remain future task scope.

## Decisions

ADR-011-herbivore-feeding.md defines exact grazing model 1. Herbivores pay positive
current-temperature/genetic maintenance before navigation/food; risky food filtering
uses only sensed carnivores and inherited risk tolerance. Reach is own/eight-
adjacent cells (inclusive toroidal Chebyshev <=1); stop pursuit there, then take
one <=4-unit bite with 80% energy conversion and capacity headroom. Only actual
plant energy removed funds gain. No health payout, plant refill, population
feedback, hunting, animal births, new config keys/defaults or authoritative state.
Carnivore navigation remains unchanged. Numerical floor for positive basal costs
and roundoff ledger tolerance are explicit in ADR-011.

## Ordered next-phase implementation

1. Add private src/ecology/herbivores.rs, register in src/ecology/mod.rs. Pure
   functions: maintenance(Traits,&AnimalConfig,temperature)->f64;
   accepts_food(Traits,Topology,plant_cell,&[visible_predator_cells])->bool;
   bite_request(plant_energy,herbivore_energy)->f64. Constants/model identity
   live with policy, not public configuration. Unit-test thermal thresholds,
   metabolism, tiny/max basal values, risk endpoints/threshold, wrapped danger,
   capacity/bite bounds and finite results. Ecology imports no state owners.
2. Refactor src/simulation.rs movement executor to separate target selection
   from execution with explicit target cell/stop radius. Keep existing no-op
   production/per-step test observer and paid adjacent step semantics. Carnivores
   select nearest herbivore with radius 0; herbivores select policy-approved plants
   with radius 1. No target retains existing exploration and sole RNG rules.
   A wrapper can retain old helper names for isolated navigation tests; production
   herbivore calls must always use the new maintenance/policy/feeding action.
3. Wire herbivores() through walk_kind to herbivore_action. Apply maintenance and
   immediate liveness check; collect one indexed sense snapshot and partition
   plants/predators; filter and choose distance/ID; execute bounded movement;
   recheck living herbivore/plant and reach, debit plant once and credit 0.8 times
   realized removal once. Use Population mutation paths, capture values before
   mutable borrows, no cfg(test) production bypass, no pending bite or extra RNG.
   Zero target energy cannot be a living input. Depleted plants disappear before
   the next herbivore and reproduction, and Commit records one Starvation death.
4. Add real-tick private tests in src/simulation.rs using existing cfg(test)
   fixture_mut/validated Genome::from_alleles and movement primitives. No public
   mutable genome/vital API. Add tests/herbivore_feeding.rs for public production
   upkeep/extinction/deterministic integration, using existing Simulation APIs.
   Acceptance matrix below specifies cases and independent oracles.
5. Migrate old fixtures intentionally: tests/animal_movement.rs full-tick
   herbivore seam destinations/energy change because pursuit stops adjacent and
   feeding follows maintenance. Keep geometry/per-step paid movement tests on
   the actual executor, preserve unchanged carnivore expectations, add explicit
   new herbivore full-tick equations. Tiny 1x1 still draws/moves nothing but now
   pays upkeep/eats. tests/lifecycle.rs must retain conservation/aging/newborn
   invariants while allowing herbivore Starvation and changing energy; retain
   exact founder OldAge with a separate no-plant, zero movement, basal_cost=1e-6
   fixture (thermal bound makes 1100-tick upkeep safely below reserves).
   Search all src/tests for full energy, exact herbivore positions, constant RNG,
   plant reproduction/sharing and OldAge-only assumptions. In plant-only purpose
   fixtures use zero herbivores or independently isolated near-death herbivores;
   retain separate sharing tests with a well-fed living animal. Never disable
   production upkeep or weaken accounting just to preserve obsolete expectations.
   Verify weather -> actual herbivore exploration -> carnivore exploration ->
   plant reproduction RNG ordering with controlled genomes/energy so paths are
   known; targeted/risk-filter/feeding/maintenance decisions draw nothing.
6. Update docs/ANIMALS.md, CONFIGURATION.md (basal floor/climate/units), PLANTS.md
   (grazing energy death), ARCHITECTURE/STATE and ADR-011 implementation evidence.
   Clarify ADR-010 herbivore target/stop behavior is superseded by ADR-011 while
   its geometry/cost/carnivore rules stand. Run targeted/full checks, repair
   regressions and record all commands/failures in implement handoffs within
   30 minutes. No system dependency expected; setup.sh/STATE existing musl
   reinstall commands remain applicable. Harness owns commits and transitions.

## Acceptance and regression matrix

| Required behavior | Planned actual executable evidence |
|---|---|
| Find visible plants; bite only local/adjacent | Controlled DNA vision 1/8 and speed 1/4, target exactly at vision boundary/outside; speed-1 target starting 3 cells away ends distance 2 and takes nothing, distance 2 ends 1 and bites; same cell, orthogonal/diagonal adjacency, horizontal/vertical/corner seams, 1x1/1xN/Nx1; independent unsigned torus distance; plants outside vision never selected even if exploration happens to approach |
| Bounded conservative eating and plant death | Isolated herbivore phase PLUS full ticks accounting separately for plant growth; <=4 removed and <=0.8*removed gained to tight tolerance; low-energy plant exact depletion/one Starvation death/immediate cache removal/no later reproduction; high energy partial bite, full/tiny headroom, stacked multiple plants still one bite, sequential herbivores see remaining stock/death and do not double-credit; depleted plant cannot recur |
| Every-tick loss and starvation | No plants and movement_cost=0, stationary 1x1: exact maintenance ledger and finite-time death before lifespan with high basal setting; exact/below-maintenance energy dies before feeding even with adjacent food, one committed death and no movement/draw; above maintenance can act; min-subnormal and max config values; age expiry precedes upkeep, dead actors never act |
| Climate consequence | Same genome/energy/actions at ideal vs extreme current temperature; independent formula oracle proves greater cost; explicit actual temporal-climate tick including seasonal/weather settings, demonstrate using current not base temperature; test temperature preference, tolerance and metabolic allele endpoints |
| Behavioral DNA changes decisions | Clone identical surroundings/seed/energy, alter ONLY risk locus 11 (0 vs 65535). Visible predator adjacent to visible plant: cautious refuses plant/bite and explores, bold approaches/bites; assert target/position or plant/consumer energy differ, not merely derived traits. Safe food alternative selected by cautious, no predator -> both same, exact threshold alleles 32767/32768, predator outside vision has no effect, seam danger recognized; no attacking or global-count rule |

Additional regression: speed cap/paid adjacent steps, lethal movement before bite,
unaffordable movement (may still bite only when already within reach), deterministic
distance/ID ties, no animal births, newborn first action next tick, observation
purity, no added feeding RNG, plant grazing affects subsequent reproduction,
no plants -> no herbivore energy gain, absorbing extinction. Four seeds
[0,1,42,u64::MAX], small mixed worlds for 2200 ticks: clone equality, positive
finite living vitals, initial+births-deaths=living, death-cause sums, spatial
oracle and extinct kinds remain zero. Include nonvacuous successful grazing and
plant death before extinction; no claim of coexistence or full checkpoint replay.

Planned commands (NOT run in PLAN):
- env -u DISPLAY cargo test --locked --lib --test herbivore_feeding --test animal_movement --test lifecycle --test plants --test plant_reproduction --test spatial --test simulation
- ./test.sh
- cargo fmt --check
- git diff --check

## Risks and limits

Stable-ID access biases shared food. Risk filtering scales with local plants times
local predators; crowded cells may be expensive. Fixed threshold can lead cautious
animals to starve near visible predators even though hunting is unimplemented;
this is an inherited local choice, never population protection. Costs/bites are
simplified model units, no coexistence/performance tuning here. Full-start founders
may eat just upkeep headroom, so low-energy controlled fixtures are essential for
nonvacuous bite-cap/death tests. Floating arithmetic must never create energy
when a debit rounded to zero. New policy intentionally changes RNG traces via
changed movement decisions but not through added draws. No blocker or review gap.
Future persistence must record model identity/effective settings and exact existing
RNG/climate/resources/DNA/vitals/lineage/counters, excluding temporary targets/cache.

## Executable planning validator

```python
from pathlib import Path
import json, subprocess
root=Path('/workspace')
h=json.loads((root/'tasks/TASK-014/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-014','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-011-herbivore-feeding.md','tasks/TASK-014/handoffs/plan-cycle1.md','tasks/TASK-014/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']),actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

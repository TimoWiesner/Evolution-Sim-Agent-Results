# TASK-012 PLAN cycle 1

## Entry, scope and current state

Verified /workspace/AGENTS.md and docs/STATE.md before reading. Applied
.agents/skills/plan/SKILL.md. Read project/contract/state/architecture, TASK-012
spec/JSON, dependency TASK-009/011 phase handoffs, relevant ADR-001/003/004/007/008,
and actual config, genome/birth, simulation, resource, topology, RNG and test APIs.
Dependency reviews PASS without gaps; no prior TASK-012 handoff/review gaps.
Initial tree clean; git remote -v empty. Some bulk reads truncated; focused
follow-ups supplied relevant source and handoff context. No interactive questions,
installations, feature code, commits, task-state changes or next phase begun.

Current Simulation has working plant climate damage/maintenance/uptake, shared
aging and immediate deaths, but reproduction() is empty. Existing queue_birth
already captures one-parent mutated DNA and lineage transactionally; Commit
inserts newborns at age zero, assigns IDs and increments counts without draws.
Resources are authoritative, spatial buckets derived, and all public access is
read-only. E=20 and radius=3 already validate/export through PlantConfig. Initial
plants start at full energy 1000; this reserve can support a finite reproductive
burst and is an explicit initial source, not an excuse for free offspring.
CLI only version/help/climate currently exists; no run/UI work belongs here.

## Decisions

ADR-009-plant-reproduction.md specifies exact gates, costs, RNG sequence, uniform
unique-cell sampler, establishment, reservations, errors and state boundaries.
Choose asexual only, one attempt per plant/tick in Reproduction, inherited exact
fertility ratio, and one uniformly sampled toroidal Chebyshev cell. Reject a
blocked destination rather than scanning for another. New establishments require
no living/pending plant and at least 1 remaining resource, then consume that unit.
Animals can coexist in the cell; stacked initial plants remain valid. Debit
configured E only on accepted birth, transfer min(E/2,1000) energy, dissipate the
rest, health=10. Require parent remains alive and numeric debit is representable.
No new settings, seed bank, maturity/cooldown state, species or animal actions.
These local rules apply at all counts; no extinction protection or replenishment.

## Ordered implementation for the assigned IMPLEMENT phase

1. Extend src/ecology/plants.rs with crate-private energy-budget helper returning
   Option of child energy for the exact ADR gates, and sample_dispersal(topology,
   center,radius,&mut Rng)->Cell. Prefer private per-axis helper producing length
   and signed start, branching before doubling. Sample x then y via below; no
   neighborhood Vec, retry loop, hidden reseed or full-world scan. Keep existing
   rates unchanged. Add focused independent unit tests for gates and sampler.
   Update module allowed dependencies to config/topology/rng/traits as needed;
   no reverse imports or public mutation API.
2. Implement Simulation::reproduction calling a private reproduce_plants helper.
   Capture population.phase_ids(Plant), recheck get per ID, copy DNA/position/
   energy; do not call walk_kind (it would age twice). Initialize local ordered
   coordinate reservation set. Check budget before any attempt draw, then chance
   allele4/65535, sample destination, living occupancy, reserved occupancy and
   resource threshold, in this exact order. queue_birth uses existing config and
   engine RNG; parents vec![id], health10, child budget, Reproduction phase.
   On success subtract E using change_energy, take exactly 1 resource and reserve
   coordinate. Assert validated finite primitive results; no costs on errors.
   Explicitly handle only IdExhausted/GenerationOverflow as skipped attempts.
   Preserve queue mutation rollback and document attempt-draw retention. Remove
   obsolete no-production-caller allow/dead comments in simulation/population
   where appropriate, without changing generic request validation or commit.
3. Add private production-tick acceptance fixtures in src/simulation.rs and public
   tests/plant_reproduction.rs. Set fertility endpoints/DNA/reserves/current
   weather with cfg(test) fixtures, then run actual advance_one_tick. Distinguish
   reproduction-only unit tests from mandatory full tick/Commit assertions.
   Build a one-free-cell collision fixture; choose deterministic seeds by finite
   test search or frozen raw-draw reference, never probabilistic assertions with
   unbounded retry. Verify both parent debits and rejected parent's unchanged
   post-physiology reserve, single resource withdrawal, one birth and spatial sync.
4. Migrate obsolete regression assumptions without deleting their purpose:
   tests/lifecycle.rs currently requires births=0, age=tick, living<=6 and all
   bodies gone by1100. Retain four-seed 2200-tick full-state replay, observational
   purity, counts/causes and founder expiry; allow plant offspring, assert
   age=tick-birth_tick, conservation initial+births=deaths+living, monotonic IDs
   and lineage. Keep animals' exact full vitals, no births and old-age timing.
   Preserve an explicit no-reproduction/empty-continuation test with E>1000.
   tests/plants.rs favorable-full-world fixture has no room but still may consume
   attempt RNG: set E=1001 for its exact old-age/no-extra-draw purpose, retain
   zero-plant path separately with default E. Do not disable behavior globally.
   Audit private simulation genetics interleaving, expiry, one-tick newborn and
   plant-ledger fixtures for unintended reproduction: isolate their purpose with
   E=1001 or fertility0 where needed. Preserve a separate reproduction-enabled
   RNG reference test. Audit tests/simulation.rs and temporal/spatial tests that
   assert no draws/extinction or whole-state equality; update only invalid claims.
5. Update docs/PLANTS.md and CONFIGURATION.md with actual E/radius/fertility
   semantics, rejection, energy/germination ledgers and draw order. Update
   GENETICS.md if its production-reproduction status is stale. Record implemented
   evidence in ADR-009, STATE and ARCHITECTURE; do not claim planned work is done.
   No configuration parser/schema/default change is planned. Record any justified
   deviations and all executed tests/failures in implementation handoffs.
6. Run targeted headless tests, full ./test.sh, formatting and whitespace. Fix
   failures; record exact commands/results/test counts. Prior 88-test PASS is
   inherited context only. setup.sh reinstalls missing existing musl dependencies
   using recorded commands; no new dependency is planned. Harness owns review,
   task states, commits and transitions. Stay inside assigned phase.

## Acceptance and test matrix

| Must have | Required evidence in IMPLEMENT |
|---|---|
| Enough energy and paid birth | Actual tick with fertility1, benign weather and an eligible site: independently calculate physiology then parent debit E and child min(E/2,1000), resource debit1, positive retained parent energy and dissipation. Paired low-energy/exact-E/just-above-E gates, E>1000, smallest positive E/underflow and sub-ULP debit tests. Blocked/rejected attempts charge nothing; independently sum parent+child energy before/after reproduction. |
| Bounded dispersal including seams | Actual children across left/right/top/bottom and a corner in non-square world, independent shortest unsigned-axis Chebyshev oracle <=radius. Sampler outputs equal cells_within membership for all centers of sizes1..8, radii0/1/3/u32::MAX; independently enumerate index combinations to prove unique/uniform mapping. Frozen/reference RNG verifies x/y draw order; no full-area traversal for huge radius. Include 1x1/1xN/Nx1. |
| Mutated inheritance and lineage | Production births with mutation0 exactly equal parent DNA; mutation1000000/step1 changes each interior allele exactly1 and keeps derived vitals valid. Check parent unchanged DNA, parents=[id], generation+1, birth_tick, age0 and no action until next tick. Reproduce a later-generation parent through actual policy to prove recursive lineage. Compare genome and final RNG to independent raw-draw mutation reference after weather/fertility/dispersal. |
| Room/resources | Fully plant-occupied, radius0, 1x1, resource0/<1/exact1, animal-only site, stacked initial plants and two parents competing for one free cell. Verify no duplicate pending destination and resource consumed once, reservations block the second birth even with abundant resources. Failed queue via ID/generation exhaustion consumes no energy/resources or reservation; existing post-mutation invalid-health rollback stays covered. |
| Plants only from plants | Default-E mixed-animal zero-plant worlds across four seeds for2200 ticks: zero plant initial/birth/living forever, clock and climate continue. Also kill the last parent through normal climate/age/energy action before reproduction and prove no later reappearance; no pending seed bank. No public spawning path. |

Additional regression: full-state clone replay for2200 ticks including resources,
DNA/lineage and RNG, observation purity, conservation, immediate spatial deaths
and committed spatial births. Keep independent real production birth evidence;
manual queue tests alone cannot satisfy this task. Fertility0/1 and midpoint
exact probability/draw sequence; no RNG draws with no plants or failed energy
gate; blocked ecological attempts retain only their defined attempt draws.
Old age occurs before attempting, newborns cannot reproduce/age in their birth
tick. Existing tick overflow remains atomic including all new behavior. Future
parent death after an accepted request preserves captured child, covered by
existing lifecycle fixture and reproduction-only private test if needed.

Suggested commands (NOT run in PLAN):
- env -u DISPLAY cargo test --locked --lib --test plant_reproduction --test plants --test lifecycle --test genome --test simulation --test temporal_climate
- ./test.sh
- cargo fmt --check
- git diff --check

## Risks, limits and evidence

Default high initial energy can produce a short reproductive burst; one plant per
new cell and local resources limit recruitment, not global counts. Fertility and
one-shot destination sampling can fail despite a nearby viable site; intentional
local stochastic ecology, not an acceptance gap. Stable IDs favor earlier
establishers. No coexistence or throughput tuning belongs here. Extreme positive
E values may disable reproduction; tiny subnormal values cannot buy free births.
Dense world costs and lifetime history remain. Future persistence needs model
identity, effective settings, complete RNG/depleted resources and every child
record; no extra persistent state or wire format is introduced now.

Only five documentation files change. No application suite run because this is
PLAN with unchanged product code. No dependencies installed; inherited musl
installation/reinstallation commands in STATE remain applicable. No blockers or
review gaps. Final validator below checks actual planning artifacts only.

## Planning validator

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-012/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-012','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
a=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert a==set(h['changed_files']) and len(a)==5,a
assert all((r/p).read_text(encoding='utf-8') for p in a)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, five planning paths, protected files, no remotes, whitespace')
```

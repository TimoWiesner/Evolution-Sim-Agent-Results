# TASK-012 IMPLEMENT cycle 1

Applied `.agents/skills/implement/SKILL.md`; verified required files before reads.
Read project/contract/state/architecture, task specification/JSON, approved plan,
ADR-009 and relevant existing architecture/genetics/lifecycle/resource decisions,
dependency TASK-009/011 implementation/review handoffs and actual engine/tests.
Dependency reviews PASS without gaps. Initial tree clean and no Git remotes.
No interactive questions, installations, commits, protected files or task states
changed. Only IMPLEMENT performed; harness owns review and transitions.

## Implementation and decisions

Follow ADR-009 without model/schema/default changes. Plants reproduce asexually,
at most one attempt each tick in Reproduction, without aging twice. Energy checks
precede all attempt draws, followed by exact fertility, uniform unique wrapped
x/y dispersal, living occupancy, pending reservation and resource gates. Accepted
requests use existing one-parent transactional genetics, then pay configured E
from the parent and 1 destination resource; offspring energy min(E/2,1000), health10.
ID/generation exhaustion skips without payment/mutation. Unexpected errors panic
as internal invariants. Commit captures DNA/lineage and inserts age-zero children
and spatial entries without draws. No new authoritative state or dependency.

Pure plant helpers depend on traits/rng/topology. Simulation owns all orchestration
and a temporary BTreeSet of accepted destinations. Population's only additional
helper is cfg(test)-only ID exhaustion, supplementing existing test-only records;
there is no production mutable-record or spawn API. Removed obsolete no-caller
annotation on the existing birth primitive. Other phase variants remain future.

Documented ecology/source ledger, cost and draw semantics, configuration use,
genetics caller status, architecture/state boundaries and implemented ADR evidence.
No technology, spatial or DNA redesign. No plan deviation or known acceptance gap.

## Acceptance evidence

- Energy: helper boundaries cover low/equal/just-above threshold, overcapacity
  cost, smallest positive values, underflow and sub-ULP rejection. Actual ticks
  independently calculate maintenance, parent E debit, child half-budget and
  germination debit; blocked attempts charge nothing. Parent remains alive.
- Dispersal: actual ticks cross six left/right/top/bottom/corner seam paths in
  a non-square world, checked with an independent shortest-axis oracle. Sampler
  tests exhaust sizes1..8, all centers and radii0/1/3/u32::MAX/usize::MAX, proving
  one-to-one coordinate mapping equals independent distance membership and the
  existing topology iterator. Unit axes, huge radius and x/y draw order covered.
- Inheritance: actual production births with mutation0 copy DNA; mutation1 with
  step1 matches independent raw-draw reference, including boundary clamping.
  Parent DNA unchanged; parent ID, generation+1, birth tick, age0, child energy /
  health, spatial insertion and first age next tick asserted. A later-generation
  parent reproduces through policy; controlled existing reserve isolates lineage.
  Accepted policy child survives subsequent parental death before Commit.
- Establishment: radius0, 1x1, fully occupied grids (including 1xN/Nx1), stock0,
  stock<1 and stock=1; two parents selecting the same free site with abundant
  stock create one child and charge only the accepted parent. Stacked founders
  and animal-only sites retain intended semantics. Generation/ID exhaustion
  consume only attempt draws, no mutation, payment or reservation.
- Extinction: public zero-plant mixed-animal worlds across four seeds stay at
  zero initial/birth/living plants for2200 ticks while climate/clock advance.
  Private full ticks kill the last parent by age/starvation/climate before
  reproduction, followed by2200-tick no-reappearance checks.
- Regression: four-seed2200-tick full Simulation equality/replay includes RNG,
  resources, DNA/lineage/vitals and spatial state. Conservation, observation purity,
  founder expiry, animal no-birth/full-vital/old-age timing retained. Separate
  E=1001 empty continuation retains the previous no-reproduction purpose.

Scoped fixture migration: old physiology, exact weather/genetics interleaving,
founder expiry and spatial-old-age tests now explicitly use E=1001 when births
would invalidate their purpose. Lifecycle tests allow plant births, age=tick-
birth_tick, ancestry and initial+births=deaths+living. Behavior remains enabled in
separate public/private production tests; no global test disabling of reproduction.

## Commands and outcomes

1. `cargo test --locked --lib --test lifecycle --test plants --test simulation`
   initial cargo exit101:26 unit pass/4 fail on obsolete physiology draw,
   weather/genetics draw, climate-death-count and founder-only age assumptions.
   Corrected those fixtures with scoped E=1001. The shell wrapper printed tail
   and returned0; cargo's log records its actual failure.
2. `cargo test --locked --lib > target/task012-unit.log 2>&1` first new-test
   run exit101:36 pass/2 fail. Mistakes in new fixtures: seed42 chose occupied
   origin for resource-threshold test; founder in3x2 climate was not hostile.
   Replaced seed assumption with bounded deterministic free-site search and
   deliberately narrow zero-optimum DNA for lethal climate. Same command then
   exit0:38 pass. Further test additions follow below.
3. `env -u DISPLAY cargo test --locked --lib --test plant_reproduction --test plants --test lifecycle --test genome --test simulation --test temporal_climate > target/task012-targeted.log 2>&1`
   exit0:62 pass (42 unit,20 integration), none skipped.
4. `./test.sh > target/task012-full.log 2>&1` first exit101:obsolete spatial
   founder-only empty-world expectation failed because plant offspring survive.
   Scoped that test with E=1001, retaining separate production birth/index tests.
   Subsequent full run exit0:103 pass, none skipped. Final run after adding a
   non-vacuity assertion in the weather/mutation test also exit0:103 pass
   (42 unit,53 integration,1 rustdoc,7 Python). Host/musl setup/build, static ELF,
   copied-empty-root version and command/config regressions included.
5. `cargo test --locked --lib weather_attempt_and_mutation_share_the_single_engine_stream`
   exit0:1 pass,41 filtered; final added assertion proves weather-enabled reference
   actually exercises an accepted mutated child. No later source changes.
6. `cargo fmt --check` and `git diff --check` exit0 after code/docs edits.
7. Final validator below verifies required JSON, exact changed paths, protected
   files, no remotes, formatting and whitespace. Actual result recorded in JSON.

Logs under ignored target/ are local convenience; commands/outcomes persist here
and in JSON. No benchmark reference checks changed or external evaluation claimed.

## Limits and next steps

Stable IDs favor early establishers; one-shot sampling can reject despite available
nearby habitat. Initial reserves can support finite bursts. Existing dense area
updates/history costs remain; no throughput or coexistence result. No disk state
format or separate fresh-container/Rust1.85 execution. Future persistence must
encode model/settings/full RNG/resources/DNA/lineage; reservations are temporary.
No new system dependency. Review is the harness's next assignment; inspect plan,
ADR and code and rerun tests as appropriate. No current blocker/remediation gap.

## Final validator

Run with:
`python3 -c 'from pathlib import Path; s=Path("tasks/TASK-012/handoffs/implement-cycle1.md").read_text(); exec(s.split("```python\n")[1].split("```")[0])'`

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-012/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-012','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git','-C',str(r),*args],text=True).strip()
changed=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert changed==set(h['changed_files']),changed ^ set(h['changed_files'])
for p in changed: (r/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['cargo','fmt','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: handoff UTF-8/schema/scope, protected paths, no remotes, formatting, whitespace')
```

# TASK-011 PLAN cycle 1

## Entry and scope

Required /workspace/AGENTS.md and docs/STATE.md existed before reads. Applied
.agents/skills/plan/SKILL.md; no feature code changes. Read task/spec, project,
contract, state/architecture, prior handoff inventory and JSON summaries, dependency
TASK-006/008/009 implementation and review evidence, current temporal climate and
spatial integration, relevant ADR-001/004/005/006/007, and actual core/test sources.
Dependency reviews PASS with no gaps. No previous TASK-011 handoffs or review gaps;
TASK-012 has no handoff yet. Initial working tree clean and no remotes. Bulk reads
occasionally truncated; bounded follow-up reads supplied relevant APIs/evidence.
One inspection tried nonexistent src/config/defaults.rs; defaults are inline in
src/config.rs and were subsequently read. No installs or product tests in PLAN.

Current behavior: Simulation owns World (Topology, Climate, TemporalClimate),
Population and sole RNG. Weather advances before Plants. Shared walker ages,
checks liveness and invokes empty plant actions. Population supports immediate
kill, clamped vital deltas and deferred accounting/commit with spatial removal.
Organisms store DNA and derive traits. Founders start at energy 1000 and full
health; configuration already validates the three plant-resource controls.
The CLI currently supports version/help/climate only; run/UI/checkpoints are
later tasks and MUST NOT be implemented here. Preserve initialization placement,
DNA, seed/draw semantics, animal behavior and lifecycle ordering.

## Decisions

ADR-008-plant-resources.md is normative for exact model-v1 equations, energy
source, bounded capacity, regeneration, withdrawal, climate damage and maintenance.
Use one per-cell renewable photosynthetic resource, with current precipitation
as water availability. Keep existing defaults and genome schema; active plant
traits are preferred_temperature, preferred_moisture, climate_tolerance,
metabolic_multiplier, max_health and lifespan. Fertility belongs to TASK-012;
other loci remain stored but inactive for growth. No extra plant-only loci.

Use current climate for BOTH resource regeneration and plant suitability, never
base climate. Regenerate every cell after weather, then process living plant IDs
in order. Apply age (existing walker), climate damage, maintenance, resource uptake
and energy credit in that order, returning immediately on death. Every positive
energy credit debits its cell; maintenance-first permits uptake at full starting
energy, and headroom avoids wasting resources on saturated plants. No births or
feeding. Health loss beyond the tolerance envelope explicitly kills by Climate;
zero energy by Starvation, lifespan by OldAge. No vitality floor or rescue.

## Ordered implementation (only in the next assigned IMPLEMENT phase)

1. Add public src/resources.rs and export from src/lib.rs. ResourceField derives
   Clone/Debug/PartialEq, stores private topology and Vec<f64>, exposes at(Cell)
   and resource model version (constant 1); normalize foreign cells. Internal new
   accepts Topology and &PlantConfig, returns Result<ResourceField, ResourceError>.
   Check Vec byte/capacity bounds, try_reserve_exact(area), then initialize C.
   ResourceError must support Error/Display and map to Copy/Eq-friendly
   SimulationError::Resources. Internal regenerate accepts existing immutable
   Climate/TemporalClimate references OR a closure mapping Cell to precipitation;
   prefer the closure to keep resources dependent only on config/topology. Visit
   y outer/x inner. Internal take(cell, nonnegative bounded demand) returns actual
   withdrawal; callers supply validated finite bounded demand. No mutable public
   resource/organism interface. Zero dimensions remain Topology's responsibility.
2. Add private src/ecology/mod.rs and src/ecology/plants.rs; export private module
   in lib.rs. Pure crate-private plant rates helper accepts Traits and normalized
   current T/P and returns suitability, climate damage and maintenance. Constants
   and arithmetic follow ADR-008. Tests may call this helper with controlled
   climate values, but integration tests must also exercise real Simulation
   climate/resources/Plants/Commit. No arbitrary public climate constructor.
3. In src/simulation.rs, add ResourceField to World and read-only resources().
   Construct it fallibly in Simulation::new without RNG draws. Keep Simulation
   construction atomic (no partial returned instance on allocation error). Extend
   SimulationError Display/source. In climate_resources advance weather first,
   borrow disjoint climate/temporal/resource fields to regenerate row-major.
   In plants use the shared walk_kind callback, copy needed read-only organism
   values, calculate current rates, apply Climate health delta, recheck get(id),
   apply maintenance, recheck, calculate headroom/withdraw/credit. Use population
   primitives for all mutations/deaths so spatial and counters stay synchronized.
   Internal validated arithmetic errors indicate a programming invariant failure;
   do not silently ignore Result or create partial-tick error semantics. No new
   RNG draws, spawn, production queue_birth or modifications to animal actions.
4. Implement focused unit/resource/plant tests and public tests/resources.rs and
   tests/plants.rs for observational surfaces and real engine behavior. Private
   simulation tests can use existing crate-private move_one_step/change_energy
   and organism fields to set matched cells, depleted reserves, age or genomes;
   this is fixture setup only, never a public testing/spawn API. Resource tests
   reside in resources.rs when internal mutation is needed. Test the actual
   plants callback/production rates, not a parallel miniature engine.
5. Migrate ecology-invalid lifecycle expectations without deleting their purpose.
   tests/lifecycle.rs currently asserts ALL kinds keep full vitals and die only
   at 1100 on weather-enabled 3x2; this will no longer be true for plants. Preserve
   mixed-kind multi-seed replay/conservation/no births/empty continuation with
   per-kind valid bounds and actual cause histories; retain exact old-age evidence
   in a separate favorable controlled plant fixture. Its default 3x2/height2
   base climate is T~0.5/P~0.304: with weather/seasons OFF, stress=0 and one plant
   per cell can maintain its large initial reserve until lifespan, though energy
   need not stay 1000. Use explicit favorable optima or equivalent stable climate
   for old-age tests. Preserve exact animal full-vital/1100-tick checks. Private
   lifespan_expiry_prevents_action_for_every_kind currently runs baseline 1099
   ticks: isolate pre-expiry age or provide benign plant placement/climate to
   keep meaningful plant expiry checks. Also audit one-tick genetics/newborn
   fixtures and any test relying on resource-less World construction. Do not
   disable plant behavior globally to make obsolete assumptions pass.
6. Add docs/PLANTS.md with equations, source/dissipation ledger, normalized units,
   growth=stored energy, current precipitation as water, finite local competition,
   order bias, configurable controls, traits, mortality and persistence boundary.
   Update docs/CONFIGURATION.md semantics without changing defaults/schema;
   reproduction_energy/dispersal_radius remain unused until TASK-012. Update
   STATE/ARCHITECTURE and ADR-008 from planned to implemented with actual evidence.
7. Run targeted headless tests, full ./test.sh and formatting/whitespace checks.
   Record actual commands, counts, any corrections and limitations in implement
   handoffs. Do not copy inherited 78-test PASS as fresh evidence. Install missing
   existing musl prerequisites through setup.sh only as necessary and record exact
   commands in STATE. No new dependency is planned. Harness owns commits/review.

## Acceptance and regression matrix

| Must have | Required evidence in IMPLEMENT |
|---|---|
| Energy from cell resources, depends on current temperature/water | Deplete a real plant below cap, advance real tick; independently compute post-weather/current T/P, regeneration, maintenance, uptake, resource debit and energy credit. Verify positive net growth in favorable fixture and match ledger within ~1e-10. Assert observation leaves entire state/RNG unchanged. |
| Same plant slower in cold/dry | Cloned genotype/age/reserves, identical full resource/config, favorable T=P=optima versus T at least 2*w colder (where representable) and P=0 for midpoint genotype. Pure rates oracle AND real-engine fixture using selected latitude cells with season/weather off, or controlled persistent weather restoration inside private tests. Favorable net gain exceeds cold and dry gains; separately vary temperature and water. Keep resources abundant to isolate suitability. |
| Limited resources and competition | At least two depleted identical plants in one cell, regen=0, eta=1, a small positive configured capacity. First cannot take more than demand; later gets remaining supply or zero. Compare with isolated equal plants in separate cells under identical climate. Sum gains <= initial resource (plus documented regeneration when enabled); resources never negative. Repeated ticks deplete the pool, no unlimited gain; full-energy/headroom and eta=0 do not waste stock. |
| Old age, starvation, hostile climate | Three explicit production-tick/commit tests: favorable plant with age=lifespan-1 dies OldAge before consuming; zero-efficiency/resources or depleted pool and small reserve yields Starvation; sustained extreme current climate and ample energy yields Climate. Verify exact cause once, immediate spatial absence, conservation and no further actions. Include public long seeded regression. |
| Document source and limits | docs/PLANTS.md and ADR-008 explain initial stores, solar/water-limited environmental inflow, conversion <=1, maintenance dissipation, resource cap, energy cap and lack of replenishment. Test budget over 100+ ticks independent of implementation formulas. |
| DNA-derived growth/tolerance | Paired genomes differ only in locus 7, 8 or 9: independently mapped traits change favorable/hostile suitability or damage under same T/P. Pair locus 6 changes maintenance. Exercise at least one actual plant tick with different immutable DNA, not only hand-built Traits or helper rates. No DNA override in production birth requests. |

Additional required boundaries: C positive tiny/large values, regen=0 and maximum,
eta=0/1 and tiny positive efficiency (avoid intermediate infinity leaking), cap
saturation, requests zero, finite bounds, foreign-cell wrapping, 1x1/1xN/Nx1 and
multiple occupants. Seeded generated sequences compare resource budget with an
independent arithmetic oracle. Exhausted plant populations stay empty while
climate/resources keep advancing. Check zero plants across >=2200 ticks; no births
for any kind. Same-seed cloned engines match full PartialEq including resources,
queries never mutate, enabled weather still draws exactly twice per tick and
weather-off plants consume zero draws. Temporal climate remains observational and
base export/schema unchanged. Overflow must leave resources and all state intact.

Suggested exact commands (not yet run in PLAN):
- env -u DISPLAY cargo test --locked --lib --test resources --test plants --test lifecycle --test simulation --test temporal_climate
- ./test.sh
- cargo fmt --check
- git diff --check

No throughput threshold or long coexistence requirement belongs to this task.
Avoid expensive benchmark tuning; a four-seed 2200-tick tiny-world invariant test
is enough for persistence-free regression, and should fit the phase deadline.

## Risks and phase evidence

Dense resource state adds O(area) memory and per-tick work even after extinction;
resource math currently recomputes climate per cell. No throughput is measured.
Extreme accepted dimensions can exceed process memory; use fallible construction
but do not claim protection against OS overcommit kills. Stable ID competition
favors older IDs; chosen intentionally under existing scheduler. Uniform founders
may die in harsh cells; ecological tuning/coexistence and initial placement changes
are later work. Initial energy 1000 can mask growth/starvation: tests must deplete
reserves without changing production initialization. Resource history must be
saved exactly in future checkpoints/hashes; never reconstruct by refilling.

Only planning documentation is changed. No product tests or simulation runs in
this phase; no system dependencies installed. Prior musl reinstall commands remain
in STATE/setup.sh. No known blockers, prior review gaps or next phase started.

Planning validation command (execute from /workspace):

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-011/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-011','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
 assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
a=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert a==set(h['changed_files']) and len(a)==5, a
assert all((r/p).is_file() and (r/p).read_text(encoding='utf-8') for p in a)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, exact five documentation paths, protected files, no remotes, whitespace')
```

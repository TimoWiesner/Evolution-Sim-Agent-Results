# TASK-011 IMPLEMENT cycle 1

Implemented the approved plan and ADR-008 equations. Applied the local IMPLEMENT
skill, read required product/contract/state/architecture/task/plan and dependency
handoffs (TASK-006/008/009 reviews PASS), relevant ADRs and actual modules. Initial
workspace clean with no remotes; verified required files first. Some bulk reads
truncated and were followed by bounded source/ADR reads. No installations,
protected-file changes, commits, task-state updates or phase transitions.

ResourceField owns checked/fallibly allocated row-major f64 stores, exposes only
read-only wrapped lookup and a model-version constant. Construction/regeneration/
withdrawal remain internal. It imports config/topology only. World stores it
beside independent immutable and temporal climate. Pure plant rates import traits
only; Simulation coordinates weather, regeneration and Population mutation.
Allocation errors propagate as SimulationError::Resources with Error/source.

Production Plants follows existing age-first ascending-ID walker, then climate
health damage, maintenance and headroom-limited resource withdrawal/conversion.
Every energy credit is resource-backed; no reproductive or feeding behavior,
animal changes or extra RNG draws. Full initial reserves are unchanged. Details,
energy source/dissipation, active traits and persistence obligations: PLANTS.md.
No schema/default or ecological model deviation.

Fixture migration: lifecycle regression retains four-seed 2200-tick exact replay,
conservation, no births, finite live vitals and empty continuation, while allowing
plant ecological deaths; exact animal vitals/lifespan checks remain. Favorable
static-climate tests retain exact plant old age. Existing private expiry fixture
uses a small benign world rather than waiting in baseline hostile latitudes.
A cfg(test)-only Population::fixture_mut supports controlled age/DNA/vitals;
production does not expose mutable records or accept arbitrary newborn DNA.
One additional fixture migration beyond the named plan files was necessary:
tests/spatial.rs expected spatial allocation failure on usize::MAX area, but the
new resource constructor now fails first. Assert Resources(ResourceError) instead;
direct spatial oversized-allocation unit test remains intact.

## Acceptance evidence

| Requirement | Test evidence |
|---|---|
| Resource-backed current T/water growth | actual_ticks_isolate_cold_and_dry_and_match_current_climate_ledger controls valid persistent weather inputs then runs real full ticks; independently computes suitability, regenerated supply, uptake and net energy; checks two draws and observational purity |
| Same DNA colder/drier grows less | Same test isolates T=0 versus T=.5 with P=.5, then P=0 versus P=.5 at T=.5; same cloned plant/config/resource/reserves. Pure rates test independently checks exact optima and stress |
| Bounded local competition | shared_cell_competition_and_128_tick_energy_budget compares two plants co-located versus separate cells and checks first-ID depletion, no overshoot and independent interval resource/energy ledger |
| Old age, starvation, climate death | mortality_causes_remove_once_before_uptake_and_conserve checks all three through full tick/Commit, no uptake, immediate query absence and one record; sustained hostile climate also kills from full health; public favorable 2200-tick test proves exact natural old age |
| Source/limits documented | PLANTS.md and ADR-008 specify initial stores, solar primary-production inflow limited by water, eta conversion loss, maintenance dissipation, caps and deterministic local competition |
| Genome effects | immutable_dna_controls_actual_growth_tolerance_and_maintenance changes only loci 6/7/8/9 in paired fixtures and exercises real ticks; unchanged immutable DNA, growth and tolerance/damage differences verified |

Other boundaries: generated 128-step resource oracle sequences on 1x1/1xN/Nx1/
rectangular grids, cap 1e-300/.3/1e6, regeneration 0/1/1e6, zero demand, cap
saturation and foreign-cell wrapping; eta zero/one/minimum normal/minimum
subnormal, headroom-limited consumption and finite stores. Overflow still compares
complete state including resources. Zero plants remain zero for 2200 ticks while
climate advances. Mixed-world clone replay now includes resource depletion.

## Actual commands and results

- Required-file check and Git remote inspection: exit 0, files present/no remotes.
- `cargo test --locked --lib --test lifecycle --test simulation`: exit 101 after
  22 passing unit tests; old full-vital lifecycle expectation failed. Migrated it.
- `cargo test --locked --lib --test resources --test plants --test lifecycle --test simulation --test temporal_climate`:
  exit 0, 37 tests at that stage; warned of unused fixture_mut before new tests used it.
- `cargo test --locked --lib`: exit 0, 30 tests after focused engine fixtures.
- First `./test.sh > target/task011-test.log 2>&1`: exit 101, old spatial allocation
  error expectation failed. Corrected error precedence as described above.
- Subsequent `./test.sh > target/task011-test.log 2>&1`: exit 0, 88 tests
  (30 unit, 50 integration, 1 rustdoc, 7 Python), none skipped. Host/musl,
  setup/build, static ELF and actual empty-root copied version checks included.
- Final headless targeted/full results and validator are recorded in adjacent JSON.
- `cargo fmt` used after Rust edits; final formatting/whitespace checks in JSON.

No performance, coexistence, disk checkpoint/hash, fresh-container or separate
Rust 1.85 claim. Dense O(area) storage/update, stable ID competition bias and
harsh-cell founder mortality are known model limitations. Future checkpoint/hash
must include resource model identity/effective settings/every depleted value.
No known acceptance gap or blocker. Harness assigns REVIEW and commits.

Final rerun after the minimum-subnormal efficiency boundary addition:
`./test.sh > target/task011-test.log 2>&1` exited 0, all 88 tests passed.
`env -u DISPLAY cargo test --locked --lib --test resources --test plants --test lifecycle --test simulation --test temporal_climate > target/task011-targeted.log 2>&1`
exited 0, 43 tests passed. No subsequent Rust edits.

## Final validator

Execute this Python block from /workspace:

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-011/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-011','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(h['changed_files']) and len(actual)==17, actual
for p in actual: assert (r/p).is_file() and (r/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, exact 17 paths, protected files, no remotes, formatting, whitespace')
```

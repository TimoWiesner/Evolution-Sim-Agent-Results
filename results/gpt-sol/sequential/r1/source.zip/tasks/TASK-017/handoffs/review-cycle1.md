# TASK-017 REVIEW cycle 1

Verdict: PASS. No acceptance gaps or remediation requirements.

Applied `.agents/skills/review/SKILL.md`. Independently inspected implementation
479a7ea..77f251b, task/specification, approved plan, implementation handoffs,
ADR-004, species/genetics documentation, registry and population lifecycle code,
new private/public tests and dependent TASK-009/012/016 PASS reviews. Verified
AGENTS.md and STATE.md exist first. Initial worktree clean and no Git remotes.
No product changes, additional tests, dependency installations, commits or phase
transitions were necessary. Architecture and ADRs accurately describe the code.

## Acceptance evidence

1. Every organism belongs to its kind's species: both production constructors
   assign a nonoptional SpeciesId. Registry filters kind and exact twelve-locus
   immutable-founder distance. Public membership oracle verifies kind, threshold,
   member counts and every living entity through four seeds and 2200 ticks.
   Initial absent/all-kind fixtures cover tick zero and empty registries.
2. Deterministic IDs/names: first member organism ID is used without an independent
   allocator or RNG. Canonical kind-N names, minimum (distance, ID), sorted birth
   Commit and read-only queries match documentation. Replay compares the complete
   engine/registry every tick. Reversed insertion/submission tests cover ties and
   canonical Commit order; later same-Commit children join the first founder.
3. Divergence/boundary: direct tests exercise sums 78641, 78642 and 78643 against
   inclusive 10*S <= 786420, all loci including inactive ones, fixed founders and
   multigeneration ancestry. Actual full-tick paid clonal and both sexual policies
   produce divergent species with independently reconstructed raw-draw child DNA.
   Animal parents are distinct genetically compatible species, demonstrating
   species bookkeeping does not change mating eligibility.
4. History: immutable public records retain parent species, origin and extinction
   ticks. Successful requests capture lower-ID parent ancestry after validation;
   parent death cannot invalidate it. Kill decrements membership once, Commit
   finalizes extinction after births, matching accepted offspring preserve the
   lineage, divergent offspring leave extinct ancestors, and extinct records
   never reactivate. Tests cover simultaneous distinct founders, original ancestry
   retention, exact ticks, repeated kills/Commit and transactional rejection.
5. Living species per kind: public living_count(Kind) counts positive memberships;
   independent BTreeSet/live-record oracles check every tick, initial absent kinds,
   immediate last-member removal and empty continuation. Queries preserve full
   engine equality and RNG. This is current-state access at any tick, as planned;
   historical population snapshots are outside the accepted scope.

All registry mutation stays beside lifecycle owner operations. No ecological
count feedback, organism source, energy source, extra RNG draw or public mutable
organism/registry API was introduced. Test-only coherent founder construction is
cfg(test), not a production relabeling path. Existing ecology assertions were
not weakened. Arithmetic cross multiplication fits u32; species identity cannot
exhaust independently of the already-reserved organism ID.

## Executed validation

- `./test.sh > /workspace/target/task017-review-full.log 2>&1`: exit 0;
  171 passed, no failures/skips (97 Rust unit, 66 integration, 1 rustdoc,
  7 Python). Includes setup/build, host/musl, static ELF and actual copied
  distribution version execution in an otherwise empty chroot.
- `env -u DISPLAY cargo test --locked --lib --test species --test genome --test organism --test lifecycle --test spatial --test simulation --test plant_reproduction --test animal_reproduction > /workspace/target/task017-review-headless.log 2>&1 && cargo fmt --check && git diff --check`:
  exit 0; 121 passed (97 unit, 24 integration), formatting/whitespace passed.
- Review artifact validator below: required UTF-8 JSON fields/types, exact three
  review paths, implementation inventory, protected paths and no remotes.

No failed application checks during review. An inspection command used the
nonexistent glob docs/decisions/004*; the correct ADR-004-genome-species.md was
subsequently read. Earlier oversized context output was truncated; targeted
reads supplied task-relevant code, decisions and evidence.

## Remaining limits

Historical scans are O(total species * 12) per birth and O(total species) per
extinction pass/query; history storage grows without bound over lifetime splits.
No throughput, coexistence, natural split frequency, new fresh-container or
minimum-Rust execution claim. Future checkpoint/hash must preserve model version,
all historical immutable founders/ancestry/ticks and memberships; validate or
rebuild counts from living records without reconstructing founders. Disk formats,
CLI export and species UI remain later work. No system dependencies installed;
existing exact install/reinstall commands in STATE/setup.sh remain applicable.
Harness owns task completion, commits and subsequent assignment.

## Review artifact validator

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-017/handoffs/review-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-017','review',1,'PASS')
assert type(h['cycle']) is int and h['gaps']==[]
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert changed == set(h['changed_files']) == {'docs/STATE.md','tasks/TASK-017/handoffs/review-cycle1.md','tasks/TASK-017/handoffs/review-cycle1.json'}
for f in changed: (r/f).read_text(encoding='utf-8')
i=json.loads((r/'tasks/TASK-017/handoffs/implement-cycle1.json').read_text())
assert set(git('diff','--name-only','479a7ea','77f251b'))==set(i['changed_files'])
protected=['AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools']
assert not git('diff','--name-only','479a7ea','--',*protected)
assert not git('diff','--name-only','--',*protected)
assert not git('remote','-v')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: review schema/UTF-8/inventory, implementation scope, protected paths, no remotes, whitespace')
```

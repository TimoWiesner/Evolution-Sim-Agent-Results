# TASK-017 IMPLEMENT cycle 1

Applied `.agents/skills/implement/SKILL.md`, the approved plan and ADR-004.
Verified required AGENTS/STATE files first. Read product/interface/state/
architecture/task, current plan and dependency TASK-009/012/016 handoffs;
dependency reviews PASS with no gaps. Initial tree clean and no remotes.
No protected/task/harness files modified, no Git network operations, commits or
phase transitions. No system package/crate/runtime dependency added.

## Result and acceptance evidence

Implemented species model 1 in src/species.rs. Population owns it; Organism has
nonoptional permanent SpeciesId. Same-kind immutable founder L1 distance uses
inclusive integer 10*S<=786420, minimum(distance,ID). New species ID is first
member organism ID, exact ASCII kind-N name, no RNG or independent allocator.
Initialization and sorted Commit classify only; no adult relabeling. An accepted
request captures the lower-ID parent's species; new lineage records retain this
ancestry even if parents die. Matching records retain original ancestry. Death
updates counts once immediately; extinction finalizes after all committed births/
deaths, never clears, and historical records persist. Public current-state queries
are read-only. No ecology settings/gates or draw order changes.

Must-have mapping:
- Every organism belongs to its kind's distance-based species: tests/species.rs
  checks all founders/absent kinds and every living member over four seeds and
  2200 ticks, against per-record and BTreeSet count oracles. Private population
  tests cover committed all-kind inherited children, and full-tick tests exercise
  real clonal/sexual paid policy births. No mutable production API added.
- IDs/names deterministic: replay compares complete independently initialized
  engines/registries each tick. Names/first-member IDs are asserted. Unit tests
  reverse record insertion and scramble birth requests to prove nearest/tie and
  canonical Commit order. Commit draws no RNG. Controlled request-local identical
  RNG streams isolate Commit ordering from acceptance-time genetics ordering.
- Emergent splits/boundary: unit tests exercise sums78641/78642/78643, neutral
  plant loci, nearest higher-ID winner, ID tie, immutable founders and a gradual
  multigeneration chain. Actual full-tick production test finds plant seed1 and
  herbivore/carnivore seed0 within bounded0..256 search, using validated mutation
  rate1000000/maxstep65535. Independent raw RNG arithmetic reconstructs child
  DNA and total stream. Animal founders belong to distinct compatible species;
  child diverges beyond both founder balls and uses lower-ID parent ancestry.
- History/ticks: direct and lifecycle tests assert initial None/tick0, origin
  ticks, multiple descendant generations, parent death before Commit, matching
  offspring rescuing membership only through ordinary reproduction, divergent
  offspring leaving extinct parents, repeated death no-op, exact extinction
  timestamps, simultaneous distinct new founders and nonreactivation.
- Living species any tick: current query compares independent live sets/member
  counts at tick0/each tick and immediately after last death before Commit.
  Query purity preserves full state/RNG. Zero kinds create no records and extinct
  empty continuations preserve history/counts.

## Files, decisions and scope

New public species module and record/getter API; organism SpeciesId/getter;
population registry and lifecycle integration; new private/public tests. Only
simulation production-file change registers its cfg(test) child module. A
cfg(test)-only helper establishes coherent controlled founder genomes before new
simulation fixtures tick; no legacy fixture biological expectations were changed.
The plan is implemented without behavior deviations. Separate child test modules
keep new tests local. docs/SPECIES.md records API/model/timing/costs and future
persistence; GENETICS, STATE, ARCHITECTURE and ADR-004 reflect implementation.

## Actual commands and outcomes

- `cargo test --locked --lib > target/task017-initial.log 2>&1`: exit0, existing
  87 units passed immediately after production integration.
- `cargo test --locked --lib --test species > target/task017-new.log 2>&1`:
  exit0, 90 units +2 integrations passed at that point.
- `cargo test --locked --lib species > target/task017-private.log 2>&1`:
  exit101, new tests initially failed compilation: Rng::from_seed expects &Seed,
  and one Genome assertion borrowed the expected value. Corrected test code.
- `cargo test --locked --lib species -- --nocapture > target/task017-private.log 2>&1`:
  exit101, 7 pass/1 fail; independent plant oracle omitted below(1) for the
  one-cell y axis. Added that required raw draw; engine unchanged. This command
  overwrote the compile log; compile diagnostics are summarized here honestly.
- `cargo test --locked --lib species -- --nocapture > target/task017-private-final.log 2>&1`:
  exit0, 8 feature tests pass,87 filtered; logs record found seeds1/0/0.
- `./test.sh > target/task017-full.log 2>&1`: exit0,169 pass before last two
  transaction/simultaneous-split tests and canonical fixture refinement.
- `cargo test --locked --lib species > target/task017-refined.log 2>&1`:
  exit0,8 feature tests pass after coherent canonical Commit fixture refinement.
- `cargo test --locked --lib species > target/task017-refined-final.log 2>&1`:
  exit0,10 feature tests pass,87 filtered, including post-mutation health rollback
  and multiple divergent species in the same Commit.
- `./test.sh > target/task017-full-final.log 2>&1`: exit0,171 pass (97 unit,
  66 integration,1 rustdoc,7 Python), no failures/skips. Host/musl setup/build,
  static ELF and copied empty-root distribution checks included.
- `env -u DISPLAY cargo test --locked --lib --test species --test genome --test organism --test lifecycle --test spatial --test simulation --test plant_reproduction --test animal_reproduction > target/task017-headless-final.log 2>&1`:
  exit0,121 pass (97 unit,24 integration), no failures/skips.
- `cargo fmt --check && git diff --check`: exit0 after final source changes.
- Final artifact validator below: checks required JSON/UTF-8/inventory,
  protected scope, no remotes and formatting/whitespace. Actual outcome in JSON.

## Risks and handoff

No known acceptance gaps. Review is assigned by harness, not started here.
Naive birth scans O(total historical species*12), queries/extinction passes
O(total species), storage grows with lifetime history. No throughput/coexistence,
natural-run split frequency, separate fresh-container or minimum-Rust claim.
Future canonical checkpoint/hash must include model identity, immutable founders,
all living/extinct historical records, ancestry/origin/extinction ticks and
memberships. Validate kind/references, uniqueness, ancestor ordering and ticks,
exact member counts/no extinct living members; rebuild counts/cache only, never
founders. No additional allocator. Disk persistence, UI/charts and CLI export are
later scope. No new dependencies installed; inherited STATE install commands apply.

## Artifact validator

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
p=r/'tasks/TASK-017/handoffs/implement-cycle1.json'
h=json.loads(p.read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-017','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
a=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert a==set(h['changed_files']), (a,set(h['changed_files']))
for f in a: (r/f).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['cargo','fmt','--check'],cwd=r,check=True)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: handoff identity/schema/UTF-8, exact inventory, protected scope, no remotes, formatting/whitespace')
```

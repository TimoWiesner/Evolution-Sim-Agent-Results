# TASK-017 PLAN cycle 1

Applied the workspace `.agents/skills/plan/SKILL.md`. Verified AGENTS.md and
STATE.md exist before reading. Inspected project/contract/state/architecture,
task/spec/JSON, dependent TASK-009/012/016 handoffs and relevant genetics,
lifecycle, scheduler, spatial and reproduction source/ADRs. Dependency reviews
PASS without gaps (TASK-009:69, TASK-012:103, TASK-016:159 tests in their reviews;
inherited evidence, not tests run here). No prior TASK-017 handoffs or review gaps.
Initial worktree clean and no remotes. No code, protected files, dependencies,
commits or task states changed. No next phase started. Harness owns transitions.

## Current facts and chosen policy

Population owns living BTreeMap, ID allocator, pending births/deaths, spatial
index and cumulative lifecycle accounting. Both Organism constructors are in
population.rs (initialize and commit); no species module exists. Organism DNA is
immutable publicly. Genome::distance_sum returns exact twelve-u16 L1 sum, maximum
786420. queue_birth validates then stages genetics and captures DNA/generation;
Commit is infallible after accepted reservations, sorted by phase/parents/sequence.
Deaths remove records immediately; counters/history commit later. Animal mating
uses genetic distance <=1/5 independent of species and must remain so.

Keep accepted ADR-004: same-kind immutable founders, nearest eligible distance,
ID tie, inclusive D<=1/10, classify only initial organisms/newborns, never relabel.
At S=78642 a child matches; S=78643 does not. Founders cannot drift with their
survivors. All twelve loci contribute even if inactive for that kind. This is an
operational genetic species criterion, not reproductive isolation. Species never
control energy, death, mating, reproduction chance or replenishment.

Detailed authoritative integration decisions are the TASK-017 refinement in
ADR-004. Choose SpeciesId numeric value equal to first member organism ID, with
gaps allowed, and exact ASCII names plant-N/herbivore-N/carnivore-N. Global ID
monotonicity then needs no second allocator or new error at Commit. New species
parent is the plant parent's species or lower-organism-ID animal parent's species;
matching an existing species preserves that record's original ancestry. Both
biological parents remain on the child. Initial species have no parent and tick0.

Registry owned by Population, not Simulation, keeps mutations beside lifecycle.
SpeciesId value belongs to organism.rs, re-exported from species.rs, to avoid
organism <-> registry module dependencies. Species record fields are private with
public getters, immutable publicly. No settings/default or dependency changes.

## Ordered implementation plan for the assigned IMPLEMENT phase

1. In src/organism.rs add opaque SpeciesId(pub(crate) u64) with value(), Copy,
   Eq/Ord/Hash, and Organism.species_id with getter. Add public src/species.rs
   via src/lib.rs. Registry imports only genome::{Genome,MAX_DISTANCE_SUM} and
   organism::{Kind,OrganismId,SpeciesId}; std BTreeMap otherwise. Define model
   version 1 and record getters id(), kind(), name(), founder_genome(),
   parent_species(), origin_tick(), extinction_tick(), living_members(). Registry
   supports public get(SpeciesId)->Option<&SpeciesRecord>, iter() in ID order,
   living_count(Kind)->usize. Derive Clone/Debug/PartialEq (Eq where possible).
   Mutation helpers new(), assign(kind,genome,first_member_id,parent_species,tick)
   ->SpeciesId, remove_member(SpeciesId), finalize_extinctions(tick) are internal.
   assign increments a matched record or creates one with count1; validated
   callers guarantee ID uniqueness/parent-kind consistency and nonzero IDs.
2. Implement assignment via integer sums, choose min (S,ID) only among same kind
   with extinction_tick None and 10*S<=MAX_DISTANCE_SUM. u32 multiplication is
   bounded by 7864200, safe. Extinct species never eligible, even exact genome.
   Membership permanent. Use stable ID-ordered records, no RNG/hash-map iteration.
   Add direct module tests with explicit genomes for boundary, ties, nearer
   higher-ID winner, kind isolation, immutable founder and extinct exclusion.
3. Add private registry field and public Population::species()->&SpeciesRegistry.
   During initialize allocate organism ID, assign founder with parent None/tick0,
   then insert living record/index/counts as before. Empty kinds create no records;
   no extra RNG calls or altered organism placement/order. initialize remains
   fallible for existing ID/spatial failures only. Species IDs cannot exhaust
   independently because every new species consumes an already reserved member ID.
4. Extend PendingBirth with captured parent_species: SpeciesId from the first
   sorted parent. Capture it after parents validate, publish only after child
   health/genetics validate. No species creation or membership increment at queue
   time. Failed requests leave entire registry/population/RNG unchanged. Commit
   uses captured species even if every parent died. In sorted Commit order allocate
   organism ID, classify using captured child DNA and ancestry, install the ID on
   newborn, then existing index/count/birth operations. Later births see new
   founders created earlier in the same Commit. Do not change draw order, child
   IDs, biological parent order, generation, paid costs or first-action timing.
5. In Population::kill, after successful living removal decrement its species
   living_members once, alongside current spatial/count update. All death paths
   already funnel here; no new per-action code. Failed/repeated kill is a no-op.
   At end of commit, after births/death accounting, set extinction_tick=tick for
   each nonextinct zero-count record. Prior tick extinction flags therefore govern
   this tick's assignments, while fresh live counts can be queried immediately.
   Species that lose their adults but receive a matching child never go extinct.
   Species that lose adults and only produce divergent children become extinct,
   retaining parent/descendant links. Retain all old records forever.
6. Add public tests/species.rs for initial all/absent kinds, complete entity
   membership/name/kind, current species counts every tick, query purity and
   same-seed registry/full-engine replay. Add private population species tests
   (prefer src/population/species_tests.rs child module) for accepted/failed birth,
   deterministic Commit order, captured ancestry after death, extinction and
   nonreactivation. Add src/simulation/species_tests.rs for real plant AND animal
   policy births/full ticks, testing actual inherited DNA classification rather
   than a separate fake classifier. Use cfg(test) fixtures only; do not add public
   spawn, genome mutation or registry mutation APIs.
7. Audit existing private fixtures that overwrite genomes: their DNA can depart
   from the old exemplar in a test but production classification remains fixed.
   For tests asserting genetic membership invariants, construct coherent registry
   founders at fixture initialization via internal assign, rather than relabeling
   living adults. Do not rebuild production species automatically from genomes.
   Both constructors need the new field; existing whole-state equality must now
   include registry, including failed-request rollback. Keep all ecology draw,
   conservation, spatial, cooldown and 2200-tick replay assertions. Membership
   bookkeeping should require no changed biological expected values or suppression
   of reproduction. Document any justified fixture adjustment explicitly.
8. Create docs/SPECIES.md documenting model/API/timing, naming/ancestry, current-
   tick query semantics and limits. Update docs/GENETICS.md to replace future
   species wording, ADR-004 implementation status/evidence, STATE/ARCHITECTURE.
   Keep historical phase entries intact. No CLI result schema implementation,
   UI/charts, balancing, persistence format or unrelated feature work.
9. Execute tests below within IMPLEMENT's own 30-minute budget, fix failures,
   report exact commands/results and write required implementation handoffs.
   Leave commits/states/transitions to harness.

## Acceptance and regression matrix

| Must have | Required evidence in IMPLEMENT |
|---|---|
| Every organism assigned to species of own kind by distance | Public mixed/one-kind/all-zero founders; private committed plant/herbivore/carnivore children; all live IDs resolve to records of same kind with immutable exemplar distance <=threshold at assignment. Same genome across kinds never merges. Fixed-label rule tested after survivor composition changes. |
| Deterministic IDs/names | Same config/seed full-state replay and exact ordered record tuples (ID, name, DNA, ancestor, ticks); first member ID rule, zero kinds/gaps, stable equal-distance ties. Reverse map insertion and scrambled birth request submission exercise existing canonical phase/parents/sequence order; sequence remains tie-break for otherwise identical requests. No extra RNG draws. |
| Divergence and exact threshold | Direct tests S=78641/78642/78643, independent sum oracle; uniform zeros vs array [65535,13107,0,...] hits exact boundary, next allele13108 is above. A gradual chain of near-parent genomes diverges from immutable original founder and splits, ruling out centroid/chaining. Real queue mutation and real production policy create a divergent child and a new record; record the bounded seed/genome fixture used. |
| Parent species/origin/extinction tick | Initial None/tick0; clonal child ancestry; animals with distinct compatible species preserve both biological IDs while new species chooses lower-ID parent's species. Parent death before Commit still works. Split lineage over >=2 generations, exact commit ticks, last member natural/explicit deaths, repeated kill, simultaneous births/deaths, parent extinct while descendant alive, all-zero kind. Existing record ancestry never overwritten on matching births. |
| Living species per kind at any tick | At tick0 and each completed tick, compare living_count for all kinds to independent BTreeSet of live organism species IDs; also compare per-record member counts to living map after kills and Commit. Check count immediately after last death is zero while extinction is still pending until Commit. Read-only repeated queries preserve full state/RNG. Empty continuation stays zero. |

Further necessary edge cases:
- Nearest founder wins over smaller ID; equal distances choose smaller ID;
  nonmatching kinds and extinct records are ignored. No reassignment of survivors.
- Multiple pending divergent children create one new species if within its first
  founder threshold; later child outside it creates another. Classification waits
  until sorted Commit, so request order cannot preempt canonical first-member IDs.
- Last adult killed after accepted matching child: species stays unextinct at
  Commit, child belongs to old ID. If no matching child, extinction is exactly t,
  unchanged through later empty ticks. A later identical-genome descendant of
  another species must create/match an eligible record, never resurrect old ID.
- Animal new-species ancestry test needs offspring outside BOTH eligible founder
  balls; use compatible parental exemplars and bounded high-mutation reference,
  not a hidden species gate or arbitrary DNA override in the production API.
- Species records are absent until accepted birth commits. Missing/wrong-kind/
  duplicate parents, generation overflow, exhausted organism IDs, invalid child
  health after mutation leave registry unchanged, including counters and names.
- Observe actual policy-born child then next-tick action; reject vacuous tests
  where all organisms die before any birth/split. For forced production divergence,
  use existing validated mutation_per_million=1000000, mutation_max_step=65535,
  a bounded seed search (e.g.0..256 with assertion at least one qualifying case),
  independent raw-draw DNA reference, and favorable local ecological fixtures.
  Freeze a found seed if clearer. Mutations/randomness are never forced in engine.
- Four seeds 0,1,42,u64::MAX over2200 ticks preserve full Simulation replay,
  conservation/index/cooldown invariants and registry equality; count oracle each
  tick. Empty-kind extinction is absorbing. No 10k balancing/performance run needed.

## Planned commands (not run in PLAN)

- `env -u DISPLAY cargo test --locked --lib --test species --test genome --test organism --test lifecycle --test spatial --test simulation --test plant_reproduction --test animal_reproduction`
- `./test.sh` (full Rust/rustdoc and Python including host/musl packaging)
- `cargo fmt --check`
- `git diff --check`

No application tests/simulations run in PLAN: only planning documents change.
No new system dependency installed or planned; inherited musl reinstall commands
in STATE/setup.sh still apply. Prior 159-test PASS is not this phase's result.

## Risks and future state boundary

Naive newborn scan and per-tick extinction pass grow with historical species;
record O(total_species*12) per birth and O(total_species) finalization/query,
O(total_species) retained storage. Optimize only with evidence; do not discard
extinct records or apply population-based ecology. Immutable founders can create
singletons and distance-compatible interbreeding across species remains allowed.
High default-distance threshold need not split in every short natural run; forced
controlled tests prove emergence without promising coexistence/diversity.

Future checkpoints/hashes must include model identity, immutable founder genomes,
all extinct/live historical records, parent links/origin/extinction ticks and every
living organism's SpeciesId. Names are canonical kind-ID; counters validate or
rebuild from memberships, never restore founders from survivors. There is no new
species allocator. Validate references/kinds, uniqueness, parent older ID/origin,
no extinct living members, ticks <=engine tick, extinction>=origin and exact live
counts on load. Clone equality covers registry now, disk persistence later.

No blocker or prior REVIEW remediation. Interpretation of "at any tick" is a
read-only current-state query after any number of ticks, not a retrospective
population history API. UI/chart export and on-disk schemas remain later tasks.

## Planning artifact validation

Execute the following Python block after writing JSON:

```python
from pathlib import Path
import json, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-017/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required={'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-017','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*a): return subprocess.check_output(['git',*a],cwd=r,text=True).splitlines()
a=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-004-genome-species.md','tasks/TASK-017/handoffs/plan-cycle1.md','tasks/TASK-017/handoffs/plan-cycle1.json'}
assert a==set(h['changed_files'])==expected,a
for p in a: (r/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected scope, no remotes, whitespace')
```

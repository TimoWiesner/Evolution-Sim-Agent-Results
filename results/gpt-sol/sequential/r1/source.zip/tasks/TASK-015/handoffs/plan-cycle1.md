# TASK-015 PLAN cycle 1

Documentation-only plan. Apply .agents/skills/plan/SKILL.md. No implementation or
phase transition performed. Required AGENTS.md/STATE existence verified first.
Project, binding contract, state, architecture, task spec/JSON, all existing phase
handoffs and relevant ADR-001/003/004/007/010/011 inspected. Dependencies TASK-013
and TASK-014 REVIEW PASS, gaps empty; no previous TASK-015 handoffs or review gaps.
Initial tree clean, no remotes. No interactive questions or network/Git writes.

## Current source and implementation sequence

1. Add src/ecology/carnivores.rs and register in src/ecology/mod.rs. Implement
   pure attack cost, bounded per-million probability and conservative nutrition
   helpers exactly as ADR-012. Unit-test endpoints/finite ranges, monotonic trait
   effects, health fractions, capacity and subnormal energy arithmetic.
2. In src/simulation.rs route carnivores() through shared walk_kind with new
   carnivore_action. Preserve age-before-action/expiry, immediate deaths and
   next-tick newborn timing. Reuse herbivores::maintenance for identical current-
   temperature upkeep; keep herbivore behavior unchanged. Copy relevant values
   before mutations to avoid references spanning Population writes.
3. Select living sensed herbivore by distance/ID; keep target ID and position.
   Reuse move_toward_observed(id,target_cell,1,no_op). Keep no-target exploration
   and paid-step observer. Existing animal_movement[_observed] is a navigation
   helper used by legacy tests: retain only as an explicitly navigation-only
   test helper if production no longer calls it (cfg(test) to avoid dead code),
   or migrate tests onto the common executor. Never make it a second policy.
4. Recheck liveness/kind/reach, require payable attack cost, debit before trial,
   stop on lethal debit. One engine chance(n,1_000_000), then successful kill via
   Population::kill(...,Predation). Snapshot energy before kill and only credit
   after true kill. Reuse existing change_energy, spatial removal, Commit and
   death records; no new mutable Population/public organism API.
5. Add src/simulation/carnivore_tests.rs child test module for private controlled
   production fixtures, patterned after herbivore_tests.rs. Existing cfg(test)
   fixture_mut and validated move_one_step suffice; relocate through Population
   so spatial cache stays correct. Call real carnivore phase/action for isolated
   budgets and full advance_one_tick for phase order. Test setup-only spawning
   or resets must never enter production. Add tests/carnivore_hunting.rs public
   actual-tick integration for observable hunting, starvation and replay.
6. Migrate obsolete fixtures in src/simulation.rs, tests/animal_movement.rs,
   tests/lifecycle.rs, and any other genuinely affected tests. Mixed 1x1 worlds
   now pay maintenance/attacks and can consume RNG/lose prey. Old fixed-energy,
   carnivore-only OldAge, no-attack sharing and weather/wander-only RNG assertions
   must change deliberately. Keep geometry/per-step tests on actual common
   movement executor; use no-prey worlds for wander-only RNG, and a separate
   low-upkeep no-prey carnivore OldAge case. Retain full production mixed replay
   and add exact hunt-trial ordering coverage, rather than disabling hunts there.
7. Update docs/ANIMALS.md, docs/CONFIGURATION.md (basal cost now both animal kinds,
   hunting constants), docs/ARCHITECTURE.md, docs/STATE.md, ADR-010/011 cross-links
   and ADR-012 status/evidence. Do not alter configuration schema/defaults, task
   specs, contract, skills, harness or reference checks. Record actual test
   failures/fixes and commands in IMPLEMENT handoffs when that phase is assigned.

## Acceptance and regression matrix

- Vision/pursuit/reach: real ticks/private action fixtures for inside, exact and
  outside DNA vision; nearest-distance and stable-ID tie, no hidden prey target;
  all speed endpoints, same cell, cardinal/diagonal adjacency, distance 2+ no
  remote attack, paid pursuit ending at reach 1; horizontal/vertical/corner seams,
  1x1/1xN/Nx1. Independent unsigned toroidal distance oracle. Show distant visible
  prey closes by <=speed adjacent moves, with exact movement ledger/cache checks.
- Traits/chance: across at least 512 independently seeded actual production
  attacks on matched fresh fixtures, assert both kills and escapes, total 512
  completed trials, exact agreement with independently computed formula and a
  restored engine RNG chance reference. Isolate weather/wander draws. Paired
  strength-only predator and prey genomes change n in opposite directions;
  aggression-only predator, speed-only prey and health fractions test formula
  directions. With identical trial streams favorable odds must never yield fewer
  kills and must yield strictly more over a declared fixed large sample (e.g.
  4096); assert a broad expected frequency band, not a fragile exact percentage.
- Exactly-once predation: controlled success seed from bounded deterministic
  search (fail test if not found); multiple predators/one prey and multiple prey,
  failed earlier hunt then later success, dead target recheck. Verify immediate
  absence from get/sense/nearby before later action, one death record and cause
  Predation after Commit, no repeated payout/death, and initial+births-deaths=live.
  Compare lower-ID winning behavior against ADR-012 sequential selection.
- Energy: isolate action then full tick, use prey snapshot after herbivore
  actions; success gain before/after <=P, costs charged separately. Test low prey
  energy, subnormal, ordinary, cap saturation, full predator and almost-full
  predator. Check finite [0,1000] vitals; no nutrition after failed kill or trial.
  Test no transfer from health, resources or duplicate prey. Exact realized gain
  bound is required; approximate ledger checks may use <=1e-10 absolute roundoff.
- Cost/starvation: forced success and failure fixtures pay identical attack cost,
  plus separately accounted upkeep/moves. Insufficient and exactly sufficient
  attack energy, lethal upkeep, lethal movement and age expiry cause no later
  trial/kill. No-prey 1x1 movement_cost=0 world with basal_cost=2 proves monotonic
  energy loss and Starvation before lifespan; continue >=2200 ticks and assert
  extinction absorbing. Tiny positive basal proves representable upkeep without
  claiming starvation before lifespan. Default basal without prey may die of age.
- Timing/RNG: actual tick independent reference for weather -> herbivore wander ->
  carnivore wander/attack -> plant reproduction, no trial on rejected gates,
  failure draws same trial as success, observers draw nothing; newborn first
  hunts next tick. Retain death priority and existing pending-birth semantics
  (accepted earlier birth survives parental death); no animal birth policy added.
- Retain existing four-seed (0,1,42,u64::MAX) 2200-tick mixed full-state equality,
  conservation, independent spatial/sense oracles and absorbing-extinction tests.
  Ensure hunting is nonvacuous using separate assertions of actual predation and
  both outcomes in bounded fixtures; long empty tails alone are insufficient.

## Planned commands (not executed in PLAN)

- env -u DISPLAY cargo test --locked --lib --test carnivore_hunting --test herbivore_feeding --test animal_movement --test lifecycle --test spatial --test simulation
- ./test.sh (all Rust/rustdoc and Python entrypoint/static packaging tests)
- cargo fmt --check
- git diff --check

No new runtime/system dependency planned; inherited setup.sh reinstalls missing
musl prerequisites with exact commands already in STATE. No packages installed
or product tests/simulations executed in this PLAN. Prior TASK-014 132-test PASS
is inherited evidence only. No throughput/coexistence/full persistence claim.
Implement phase has its own 30-minute budget: run bounded thousands-of-attacks
fixtures and small-world 2200-tick replay, avoid ecology tuning/large benchmarks.

## Risks and cross-session obligations

ADR-012 is authoritative for exact formula, attack payment, rounding guard,
competition and RNG gate order. Default saturation may waste kills; stable-ID
bias is accepted and no global rescue is allowed. Strength and health odds are
simplified rather than biomechanical combat. No authoritative state is added;
future checkpoints/hash need model identity plus complete existing state. No
handling timers/carcasses/cover, animal reproduction (TASK-016), CLI/UI, parameter
sweeps or balancing belong here. No unresolved blocker or review remediation.
Harness owns commits/task state/phase transition; next step only when assigned.

## Planning validation

Execute the following validator after writing the structured handoff:

```python
import json, subprocess
from pathlib import Path
root=Path('/workspace')
p=root/'tasks/TASK-015/handoffs/plan-cycle1.json'
d=json.loads(p.read_text(encoding='utf-8'))
assert (d['task_id'],d['phase'],d['cycle'],d['verdict'])==('TASK-015','plan',1,'N/A')
assert type(d['cycle']) is int and isinstance(d['summary'],str)
for k in ['changed_files','decisions','tests','risks','next_steps','gaps']:
    assert isinstance(d[k],list)
for t in d['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
assert set(tracked+untracked)==set(d['changed_files'])
assert len(d['changed_files'])==5
assert not subprocess.check_output(['git','remote','-v'],cwd=root,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=root,check=True)
for f in d['changed_files']:
    assert f.endswith(('.md','.json'))
    (root/f).read_text(encoding='utf-8')
assert not any(f in ['AGENTS.md','CLAUDE.md','docs/CONTRACT.md'] or f.startswith(('.agents/','src/','tests/')) for f in tracked+untracked)
print('PLAN UTF-8/schema, exact documentation scope, protected files, no remotes and whitespace: PASS')
```

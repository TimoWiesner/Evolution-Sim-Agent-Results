# TASK-015 REVIEW cycle 1

Verdict: PASS. All five acceptance criteria met; no remediation gaps.

Verified required files before inspection; applied .agents/skills/review/SKILL.md.
Reviewed task/JSON, project, binding contract, architecture/state, plan and
implementation handoffs, dependency TASK-013/014 evidence (reviews PASS, no gaps),
relevant runtime/spatial/genetics/lifecycle/navigation/grazing/hunting ADRs and
actual implementation diff 5f3d779..825ba5d. Initial tree clean, no Git remotes.
No product edits, package installs, commits, task-state edits or phase transitions.

## Acceptance evidence

1. Vision/pursuit/reach: carnivore_action uses indexed inherited sense, ranks
   live herbivores by wrapped distance/ID, and uses the shared paid adjacent
   movement executor with stopping radius 1. It rechecks live prey/kind/distance
   before payment/trial. pursuit_reach_vision_all_speeds_and_wrapped_axes covers
   same/adjacent/diagonal/seam cells, degenerate axes, speeds 1..4, exact vision 8
   and outside 9. hidden_prey_never_receives_opportunistic_attack_and_one_target_only
   also covers minimum vision and a single attempt with stacked alternatives.
2. Traits/chance: the pure formula depends on predator strength, aggression and
   health fraction and prey strength, speed and health fraction. Only the engine
   RNG supplies trials. many_actual_attacks_match_independent_formula_rng_and_exact_energy_death_ledgers
   performs 512 independently seeded production phases, checks exact reference
   trial/RNG agreement and both outcomes in a broad frequency band. Paired
   strength/aggression/prey-speed genomes execute 4096 shared trials per pair,
   checking monotonic outcomes and strictly different totals. Public real ticks
   also show both outcomes. Minimum-positive-health fallback keeps odds bounded.
3. Exactly-once death: successful trial calls Population::kill with Predation,
   which removes the authoritative record/index immediately and returns false
   for repeat removal. Credit is gated on true removal. The 512-attack test
   verifies immediate sense/index absence, repeat-kill no-op, double Commit,
   exact death/cause history and conservation. Sequential competition tests
   verify both earlier success and earlier failure/later success, with one death
   and one nutrition payout. Ascending-ID competition is documented in ADR-012.
4. Nutrition: credit is capacity-limited 80% of snapshotted prey energy; a
   conservative guard rejects any floating addition whose realized gain exceeds
   that energy. Production tests exercise minimum subnormal, minimum normal,
   tiny and ordinary prey energy, full/near-full predators and saturation.
   Separate full-tick accounting snapshots prey after its own costs. No health,
   resource or duplicate-kill payout exists.
5. Costs/starvation: every survivor pays current-temperature maintenance, actual
   movement and a positive attack cost before chance. Success/failure use the
   same cost; unaffordable/lethal upkeep, movement, attack and age gates draw no
   trial. A public zero-movement/no-prey/high-basal fixture proves monotonic loss,
   two Starvation deaths and absorbing extinction through 2200 ticks. Tiny costs
   remain representable; low-upkeep OldAge priority is separately tested.

## Regression and design assessment

The traits-only hunting helper follows existing ownership boundaries. Simulation
owns RNG/actions, Population owns mutation/index/death accounting. No added
persistent state, config/default/dependency, public mutation API, animal birth
policy or global-count intervention. Subnormal-health rescaling is a documented
numerical refinement, preserving the ratio when both computed scores vanish.

Legacy fixtures deliberately isolate genetics, risk, navigation and lifecycle
from newly introduced predation. Their obsolete full-energy/OldAge-only claims
are removed, while new production tests retain hunt/newborn/tick-order evidence.
The four-seed 2200-tick full-production replay still checks equality, conservation,
spatial/sense oracles and extinction. Navigation adapters are cfg(test) and share
the real movement executor. No acceptance is established by an alternate engine.
Architecture, ANIMALS.md, CONFIGURATION.md and ADR refinements accurately describe
current behavior; no architecture or decision change was needed during review.

## Executed checks

- `./test.sh > target/task015-review-full.log 2>&1`: exit 0; 145 passed,
  no failures/skips (75 unit, 62 integration, 1 rustdoc, 7 Python). Includes
  host/musl setup/build, static ELF and copied-distribution empty-root execution.
- `env -u DISPLAY cargo test --locked --lib --test carnivore_hunting --test herbivore_feeding --test animal_movement --test lifecycle --test spatial --test simulation > target/task015-review-headless.log 2>&1 && cargo fmt --check && git diff --check`:
  exit 0; 93 tests passed (75 unit, 18 integration), formatting/whitespace passed.
- `python3 tasks/TASK-015/handoffs/validate-review-cycle1.py`: exit 0;
  handoff identity/types/UTF-8, exact review scope, protected implementation paths,
  absent remotes and whitespace verified. Validator is review-owned evidence.

Logs live in ignored target/; this report and JSON preserve results.
No throughput/coexistence, full checkpoint, fresh-container or separate minimum
Rust verification claimed. Stable-ID access bias/full-reserve predation bursts
remain documented limitations. Future persistence must retain model identity and
complete existing state while rebuilding/excluding derived cache. No dependency
installation; existing exact reinstall commands in STATE remain applicable.
Harness owns completion, commits and subsequent assignment; no remediation needed.

"""Review evidence validator; does not modify product or task state."""
import json
import subprocess
from pathlib import Path

root = Path('/workspace')
data = json.loads((root / 'tasks/TASK-015/handoffs/review-cycle1.json').read_text(encoding='utf-8'))
assert (data['task_id'], data['phase'], data['cycle'], data['verdict']) == ('TASK-015', 'review', 1, 'PASS')
assert type(data['cycle']) is int and isinstance(data['summary'], str)
for key in ['changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps']:
    assert isinstance(data[key], list)
for test in data['tests']:
    assert isinstance(test['command'], str) and type(test['exit_code']) is int
    assert isinstance(test['notes'], str)
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=root, text=True).splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines()
assert set(changed) == set(data['changed_files'])
for path in changed:
    (root / path).read_text(encoding='utf-8')
for path in subprocess.check_output(['git', 'diff', '5f3d779', '825ba5d', '--name-only'], cwd=root, text=True).splitlines():
    assert path not in ['AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md']
    assert not path.startswith(('.agents/', 'tools/'))
    assert not path.endswith(('task.md', 'task.json'))
assert not subprocess.check_output(['git', 'remote', '-v'], cwd=root, text=True).strip()
subprocess.run(['git', 'diff', '--check'], cwd=root, check=True)
print('Review identity/schema/UTF-8/scope, protected implementation files, no remotes and whitespace: PASS')

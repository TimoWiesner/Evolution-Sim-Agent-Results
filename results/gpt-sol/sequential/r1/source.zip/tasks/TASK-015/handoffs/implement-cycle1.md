# TASK-015 IMPLEMENT cycle 1

Implemented only the approved plan using .agents/skills/implement/SKILL.md.
Required AGENTS.md/STATE files verified before reading project files. Read task,
plan, dependent IMPLEMENT/REVIEW evidence, architecture/state and relevant ADRs.
Dependencies TASK-013/014 REVIEW PASS; no existing review gaps. No interactive
questions, Git network operations, commits, protected-file edits or transitions.

## Implementation and acceptance evidence

- src/ecology/carnivores.rs is pure traits-only policy: attack payment,
  per-million odds and conservative floating nutrition. Simulation owns all
  current-climate upkeep, indexed targeting, common movement, RNG, kill and credit.
- Shared walker retains age priority and next-tick newborn activation. Nearest
  visible herbivore by distance/ID; radius-1 stop/recheck includes same cell,
  diagonals and wrapping seams. No hidden-prey opportunistic attacks or retries.
- One positive attack payment before a surviving trial. Both strength/health,
  predator aggression and prey speed affect bounded odds. No new RNG/state/config.
- Predation uses kill, never prey starvation debit; successful removal is immediate
  from records/index and later senses. True-kill-only energy credit cannot exceed
  snapshotted prey energy even for subnormal P or capacity rounding. Death/cause
  totals commit once. Earlier failure leaves prey for later predator; success
  removes it before later selection. IDs schedule predators deterministically.
- No prey means existing exploration plus unconditional maintenance. Public
  high-basal zero-movement 1x1 fixture demonstrates Starvation, then absorbing
  extinction through 2200 ticks; separate tiny-basal fixture retains OldAge.

Private production tests: src/simulation/carnivore_tests.rs. Many-attack test
executes 512 independently seeded actual phases, checks both outcomes in a broad
150..349-kill band, independent formula/trial and exact postcost nutrition,
unchanged escaped prey, cache/sense removal, repeated kill no-op and death ledgers.
Trait-only strength/predator aggression/prey speed pairs each execute 4096 paired
shared-stream trials, with per-trial monotonicity and strictly different totals;
health fractions separately affect odds. Geometry tests cover every speed, exact
vision 8/outside 9, minimum vision 1, no remote attack, reach/seams/tiny axes,
paid movement and one selected target among stacked prey. Numeric tests exercise
minimum positive energy, ordinary and saturated reserves and exact realized gain.
Other tests cover two predators/one prey (earlier failure or success), gates for
lethal upkeep, unaffordable/exhausting attack, lethal move and expiry, current
thermal costs/tiny basal floor, pending newborn first hunt next tick and actual
weather -> herbivore wander -> hunt trial ordering. Public tests/carnivore_hunting.rs
exercises real ticks, both outcomes, starvation and OldAge. Existing four-seed
2200-tick mixed replay retains equality, conservation, spatial/sense oracles and
absorbing extinction. No alternate production engine or public test mutation API.

## Refinement and fixture migrations

One numeric refinement: valid subnormal health can make both health fractions
round to zero, contradicting the plan's positive-score assumption. Only in that
case rescale both health inputs by their maximum before computing odds, cancelling
the common factor. Unit coverage checks bounded odds at minimum positive health;
normal formula/order unchanged. ADR-012 and ANIMALS document this explicitly.

Old genetics weather fixture keeps carnivores alive at energy .5 so attacks are
unaffordable and its two-parent inheritance assertions remain nonvacuous. New
hunt tests independently retain actual trial ordering. Old next-tick walker test
uses the actual same-kind lifecycle walker with empty action, preserving accepted
births-after-parent-death semantics without unrelated predation. Newborn production
hunting is separately tested. Old geometric sequential-sensing fixture uses the
cfg(test) navigation-only adapter/common executor after actual herbivore actions;
production hunting has separate target/order coverage. Herbivore risk fixture
keeps predators visible with subattack energy so it tests risk without consuming
the inspected herbivore. Tiny-world no-step test uses herbivores without predators;
new mixed hunting tests verify shared cells and trials. Mixed lifecycle removes
obsolete full-energy/carnivore-only-OldAge assertions; public separate carnivore
OldAge fixture preserves expiry evidence. Mixed replay still uses full production.

## Commands and actual results

Logs below are ignored local target artifacts; test sources and results here persist.

- Initial cargo fmt and test attempt: exit 101 because new child module did not
  yet exist. Created it before subsequent compilation.
- `cargo test --locked --lib --tests > target/task015-initial.log 2>&1`: exit 101,
  61 unit passed/4 obsolete fixture failures; migrated as above.
- `cargo test --locked --lib --tests > target/task015-second.log 2>&1`: exit 101,
  new tests used nonexistent Seed::from; changed to Seed::from_u64.
- `cargo test --locked --lib --tests > target/task015-third.log 2>&1`: exit 0.
- `cargo test --locked --lib --test carnivore_hunting > target/task015-hunt.log 2>&1`:
  exit 101, 72 unit passed/one new expectation incorrectly moved adjacent predator.
  Corrected expected radius-1 stay; subsequent hunt-final and hunt-final2 exit 0.
- `env -u DISPLAY cargo test --locked --lib --test carnivore_hunting --test herbivore_feeding --test animal_movement --test lifecycle --test spatial --test simulation > target/task015-targeted-final.log 2>&1`:
  exit 0, 93 pass (75 unit/18 integration), no failures/skips.
- `./test.sh > target/task015-full-final.log 2>&1`: exit 0, 145 pass
  (75 unit/62 integration/1 rustdoc/7 Python), no failures/skips; host and musl
  setup/build, static ELF and copied empty-root version pass. Earlier full run
  also exited 0 before adding final numerical/vision tests.
- `cargo fmt --check` and `git diff --check`: exit 0.

No dependency/system installation. Existing STATE setup reinstall commands apply.
No throughput/coexistence, separate fresh-container/older-toolchain or complete
checkpoint claim. Stable-ID bias/full-reserve predation burst accepted. Future
persistence records hunting model identity/full existing state, rebuilding cache.
No known acceptance gap. Harness owns review/completion/commits; no next phase.

## Artifact validator

```python
import json, subprocess
from pathlib import Path
root=Path('/workspace')
p=root/'tasks/TASK-015/handoffs/implement-cycle1.json'
d=json.loads(p.read_text(encoding='utf-8'))
assert (d['task_id'],d['phase'],d['cycle'],d['verdict'])==('TASK-015','implement',1,'N/A')
assert type(d['cycle']) is int and isinstance(d['summary'],str)
for k in ['changed_files','decisions','tests','risks','next_steps','gaps']:
    assert isinstance(d[k],list)
for t in d['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
assert set(changed)==set(d['changed_files'])
for f in changed:
    assert f not in ['AGENTS.md','CLAUDE.md','docs/CONTRACT.md']
    assert not f.startswith(('.agents/','tools/'))
    assert not f.endswith(('task.md','task.json'))
    (root/f).read_text(encoding='utf-8')
assert not subprocess.check_output(['git','remote','-v'],cwd=root,text=True).strip()
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('UTF-8/schema, exact changed paths, protected scope, no remotes, formatting/whitespace: PASS')
```

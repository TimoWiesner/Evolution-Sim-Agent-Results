"""Independent display-free empty-world acceptance probe; run from workspace."""
import json
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path('/workspace')
sys.path.insert(0, str(ROOT / 'tests'))
from test_ui import server, request

with tempfile.TemporaryDirectory(dir=ROOT / 'target') as directory:
    config = Path(directory) / 'zero.json'
    config.write_text(json.dumps({'seed': 8675309, 'world': {'width': 1, 'height': 1},
                                 'initial': {'plants': 0, 'herbivores': 0, 'carnivores': 0}}))
    with server(['--config', config]) as url:
        token = url.split('#')[1]

        def frame():
            return json.loads(request(url, '/api/frame')[1])

        def action(name):
            status, body = request(url, '/api/control/' + name, 'POST', token,
                                   {'X-Evosim-Epoch': frame()['epoch']})
            assert status == 200, (status, body)
            return json.loads(body)

        def save():
            status, body = request(url, '/api/checkpoint/save', 'POST', token,
                                   {'X-Evosim-Epoch': frame()['epoch']})
            assert status == 200
            return body

        action('pause')
        request(url, '/api/ready', 'POST', token)
        fresh = save()
        for tick in range(1, 51):
            result = action('step')
            assert result['tick'] == str(tick)
            assert result['counts'] == ['0', '0', '0'] and not result['running']
        state = save()
        for speed in ['slow', 'normal', 'fast']:
            assert action('speed/' + speed)['speed'] == speed
            time.sleep(.06)
            assert save() == state
        for _ in range(3):
            assert action('reset')['tick'] == '0'
            assert save() == fresh
print('PASS: 50 exact empty-world steps, three observational speeds, three exact resets')

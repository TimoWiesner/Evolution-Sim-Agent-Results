# TASK-024 REVIEW cycle 1

Verdict: PASS. All eight acceptance criteria are met; no gaps or remediation.
Reviewed committed implementation 1311015..fd42b6c independently against task,
contract, approved plan, dependency TASK-020/022/023 handoffs and relevant
ADR-002/004/015/016/018. Applied the review skill only. Initial tree clean and
Git remote inventory empty. No product, protected file, task state, commit,
dependency installation or phase transition changed in review.

## Acceptance evidence

| Criterion | Verified evidence |
| --- | --- |
| Run/pause/step/reset/speed | Actual private UiSession fake-time tests and actual HTTP/CDP controls pass. Step pauses and calls production advance once; pause is a barrier. Independent review-probes.py performs 50 exact steps through an absorbing empty world. |
| Repeatable reset | Session tests compare complete hashes with exact large negative seed; HTTP tests compare checkpoint bytes after repeated resets and after loading a different config/seed. Review probe repeats byte-identical reset three times. |
| Three nonnegative speeds | Closed Rust enum Slow/Normal/Fast, explicit 5/20/60 intervals; invalid numeric/unknown inputs rejected. Fake-time deadline tests and browser selector pass. Review probe confirms speed changes while paused do not alter checkpoint bytes. |
| Always-visible tick/populations | CDP checks bounds at 1280x720 and 1440x900 while inspector scrolls and sticky mobile summary at 800px after page scroll. Main and inspector screenshots independently opened; all three counts including zero and tick visible. |
| Complete selection/inspector | Immutable DTO exposes ID/kind/species/age/energy/health, all twelve named traits, exact u16 alleles, parents. Rust fixtures verify real plant/animal offspring and IDs beyond 2^53. Browser gestures select all three kinds from complete 1x1 cell chooser after pan/zoom and check actual inspector text. |
| Follow/death | Selection refreshed after each production tick, keyed by stable ID; one terminal DTO retained on death. Rust verifies actual death history; Chromium follows carnivore #9 to death at1100, retaining identity and labelled last-observed values. |
| UI checkpoint files | Chromium performs real download and DOM file-input upload; CLI decodes download. Loaded checkpoint at17 in a different7x3 world pauses, then three UI steps yield bytes identical to CLI continuation. Corrupt/unknown-version rollback, reset source, stale epochs and slow/saturated ingress pass. Existing persistence byte APIs reused, no second codec. |
| Display-free controls | Six private UI tests pass with DISPLAY/WAYLAND_DISPLAY removed; actual HTTP control tests are browser-independent. Independent review probe also runs with display variables removed. |

Decisions are documented: visible buttons without extra shortcuts; twelve named
exact decimal alleles and expressed traits. These satisfy task-owned decisions.
UI-only scheduler/selection/epoch/revision fields remain outside Simulation and
canonical/checkpoint state; no core, config/default, ecology, dependency or schema
change in implementation. Architecture and ADRs accurately describe final design;
no review amendment needed. Parameter editing/charts remain TASK-025.

## Actual verification

Exact commands/exit codes are in review-cycle1.json. Full suite was run without
other browser automation, as dependency cleanup tests inventory global profiles.
It passed221 Rust tests (131 unit,89 integration,1 rustdoc),19 Python tests and
Node camera assertions, zero failures/ignored/skipped. Includes host/musl builds,
setup idempotence, ELF and copied-empty-root launcher/run/checkpoint/batch checks.
Both mixed and sustained1000 fixtures render51 distinct frames/5.2s (~9.81/s),
local p95 gaps116.8/116.9ms. No universal throughput claim.

Separate xvfb smoke and screenshots pass at actual10/100 ticks. Main and optional
inspector PNGs are1440x900; both opened and inspected, world/controls/tick/counts
visible and inspector scrollable. Artifacts/logs under ignored target/task024-review-*
are reproducible but not durable source. Additional probe source is adjacent
review-probes.py. An equivalent inline probe also passed before persisting it.
No failed test command occurred during review. Formatting, JS syntax, whitespace
and final UTF-8 handoff/schema/scope validation passed.

## Retained limits

UI upload limit64MiB is documented; larger files use CLI. Valid large worlds/
histories can exhaust memory and synchronous codec/cache work delays owner.
Slow local clients can occupy bounded worker capacity; browser owns download disk
completion. Same-build continuation only; no fresh Ubuntu/minimum-Rust or abrupt
host-kill guarantee tested. These are existing documented limits, not acceptance
gaps. No remediation required; harness owns task completion/commit/next assignment.

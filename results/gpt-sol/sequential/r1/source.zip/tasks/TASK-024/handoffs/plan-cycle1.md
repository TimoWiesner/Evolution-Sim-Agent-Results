# TASK-024 PLAN cycle 1

Planning only; apply `.agents/skills/plan/SKILL.md`. Required AGENTS.md and
STATE.md verified before inspection. Initial worktree clean and no Git remotes.
Read product/contract/state/architecture, task and JSON, dependency TASK-020,
TASK-022 and TASK-023 handoffs, relevant ADR-002/004/016/018, UI/server/automation,
organism/genome/population/persistence APIs and existing tests. Dependency reviews
PASS with no acceptance gaps. TASK-020 has an optional wording correction about
singleton generation, unrelated to this task. No existing TASK-024 handoffs or
review gaps. No code, protected files, dependencies or task state changed here.
Harness owns commits and phase transitions. No interactive questions required.

## Findings

The current server owns one Simulation, cached biome JSON and ready/next-deadline
locals. It starts running at20Hz after first draw; frames poll10Hz. It rejects all
request bodies. Bounded response workers keep socket writes outside the engine
owner. Automation stops at10/100 and compares hashes to headless. Preserve these
features and deadlines. Current browser rejects any reply whose tick is lower:
that must change for reset/load. Current pointer handlers treat all gestures as
pan; selection needs a click/drag threshold and same-cell organism chooser.

All inspector data is available through immutable APIs: Organism getters,
Genome::alleles/LOCUS_NAMES, Traits getters, species registry and death_records.
OrganismId's constructor is crate-private: parse nonzero u64 inside this private
application module, without adding core setters. Historical deaths only store
ID/kind/tick/cause, not the entire dead genome; cache only the selected live DTO.
Persistence already provides checkpoint_bytes/from_checkpoint_bytes, including
full validation. Do not implement a second codec or serialize frame JSON as state.
Population counts already exist; full metrics capture per frame is unnecessary.

## Binding design decisions

- Use visible HTML buttons Run, Pause, Step, Reset plus a three-option speed
  selector: Slow5, Normal20, Fast60 target ticks/s. Buttons suffice; no new keyboard
  shortcuts, avoiding conflicts with browser/file input and existing navigation.
  Speed is a closed Rust enum and validated matching browser values, never signed
  arbitrary input. Defaults remain Normal and auto-run on first ready.
- Step pauses first, then calls advance_one_tick exactly once, even if previously
  running. Pause/Run are idempotent. Pause acknowledgement is the barrier after
  which no timed tick can occur until Run/Step. Speed changes reschedule the next
  deadline without ticking. No catch-up bursts; one production tick per due loop.
  A tick already completed before receipt is reflected in the command response.
- Reset constructs Simulation::new(current sim.config().clone()), including exact
  seed. Successful reset pauses at0, clears selection and rebuilds biome cache.
  On successful checkpoint load, its embedded effective config/seed becomes the
  current reset source. Keep chosen speed; load pauses at its saved tick and clears
  selection. Decode/build all replacement state/cache before swapping. Errors
  preserve engine, selection, config, mode and speed at command application time.
- Store control/camera/selection/scheduler/revisions only in the application, never
  Simulation or canonical/checkpoint state. Core and canonical schema remain
  unchanged, as do ecology, RNG draw order, config/defaults and dependencies.
- Inspector shows decimal ID, kind, species ID/name, age ticks, energy, health,
  twelve named expressed traits, twelve exact decimal u16 allele values in locus
  order with names and genome version1, plus parent IDs. Founders show explicitly
  'None (initial organism)'; one parent for a plant child, two for an animal child.
  Optional generation/position are cheap helpful fields. No chromosome art replaces
  exact values. Use textContent, readable precision for vitals, scrollable panel.
- Click map to choose a real living entity; use inverse camera coordinates and
  frame records. Pick nearest rendered marker within clicked cell; if multiple
  occupants, show an ID/kind chooser containing every occupant in stable ID order,
  including occluded same-kind markers. Use drag threshold4 CSS pixels; drags do
  not select. Selection is one stable ID, never nearest-by-position each frame.
  Highlight current position. Keep live DTO refreshed after ticks; when missing,
  retain last observed values labelled 'last observed at tick T', show 'Died' and
  actual death tick/cause from history. No endless history scans per frame: look
  up death once at transition; cache that terminal DTO. Clear/reselect explicitly.
- Save uses browser download; Load uses an HTML file input and binary upload.
  No server filesystem paths or new OS dialogs/dependencies. Download preserves
  exact TASK-022 .evo bytes; upload uses its existing validation. These are actual
  local checkpoint files interoperable with CLI. Transport caps upload at64MiB
  (UI only; CLI codec unchanged), rejects excess explicitly and documents limit.
  Browser download completion/disk failures remain browser-owned; say 'Download
  prepared', not 'Saved to disk'. Upload cancellation leaves everything unchanged.

## Private interfaces and protocol

Add `src/ui_server/session.rs`: UiSession owns Simulation, Speed, running/ready,
selected cached DTO and monotonically increasing revision/epoch counters plus
cached world. Intended methods: new(Config), ready(), command(Command),
on_due_tick(), frame(), world(), checkpoint_bytes(), load_checkpoint(&[u8]).
Use typed Command::{Run,Pause,Step,Reset,SetSpeed,Select,ClearSelection}; invalid
wire values return errors before mutation. Pure scheduling decision helper takes
an explicit time/duration; no sleeps in session tests. Network loop owns Instant
and calls the helper; deadlines reset after ready/run/step/speed/load/reset.
Completed reset/load increment epoch, all visible changes and ticks increment
revision using checked counters; expose exact decimal strings. Reject stale
mutations with a supplied epoch (409); same-epoch commands serialize in arrival
order. Counters/engine overflow return actionable errors and pause safely; never
wrap. Return command state after application, not optimistically in JavaScript.

Evolve private UI wire schema to2 (not contract result/metrics/checkpoint schema).
Frame adds epoch, revision, running, speed, ready and nullable selected inspector.
World has epoch. Tick/counts/IDs/ages/parents/revisions remain decimal strings for
JS precision; twelve allele values fit JS numeric integers. Counts and tick stay
in fixed visible header/summary even when inspector scrolls or kind is extinct.
World cache and frame must share epoch. Browser serializes command requests and
polls, uses revision order (not tick order), drops stale replies; on new epoch it
fetches/rebuilds world before rendering that frame, clears old selection/camera
and fits new dimensions. Guard late world/download/upload replies against epoch
changes. Update browser test observation fields to include epoch/revision.

Suggested exact routes (document final implemented forms in UI.md):
- POST /api/control/run, /pause, /step, /reset, /speed/slow|normal|fast,
  /select/<decimal-id>, /clear-selection: bodyless, capability required and
  X-Evosim-Epoch required. Ready stays bodyless/idempotent without epoch.
- POST /api/checkpoint/save: bodyless authenticated/epoch-checked; return binary
  application/octet-stream, attachment filename evosim-tick-<tick>.evo. Encode
  consistent completed-tick bytes in owner. Saving changes no engine/control state.
- POST /api/checkpoint/load: authenticated, octet-stream Content-Length1..64MiB,
  no transfer encoding; X-Evosim-Epoch required. Decode then atomically replace
  session, respond with new state. Unsupported/corrupt data400; stale409;
  body size413; wrong type415; invalid token/Host/Origin403; wrong method405.
- Existing GET assets/world/frame remain, ready semantics retained. Diagnostics
  remains capability-protected and automation-only; tests compare downloaded
  checkpoint hashes through public codec or CLI instead of opening diagnostics.

No upload read may block the engine/deadline loop. Add
`src/ui_server/transport.rs` for bounded ingress workers (two workers, two queued
requests, one bounded completion queue) that receive owned upload requests and
read at most limit+1 bytes. Owner validates headers/auth/size before dispatch;
workers never see engine or decode it. Completion returns request/bytes/epoch to
owner, which checks epoch again and decodes/applies serially. Saturation yields503
or closes excess, never blocks owner; short/malformed bodies fail without mutation.
Worker completion uses bounded nonblocking delivery, preserving existing bounded
response worker behavior. Avoid joining a stalled body reader on shutdown; process
exit cleans threads. Slow uploads can occupy ingress capacity, a documented local
service limit, but cannot stop ticks/control/deadline checks. tiny_http may defer
other requests on the same connection; independent connections must keep working.
Keep Host/Origin/capability/CSP checks for all mutations; download uses fetch Blob
so it can carry capability header. No GET mutation or token in query/file paths.

## Ordered IMPLEMENT work

1. Extract current owner/scheduling into session.rs with no initial behavior
   change; add typed controls and fake-time unit tests first. Extend snapshot.rs
   with read-only inspector/control DTOs. Cache selected death transition, not
   every organism genome/history. No public library API solely for testing.
2. Integrate session in ui_server.rs, dispatch strict bodyless commands and epoch
   guards, retain ready startup, bounded responses and automation10/100 caps.
   Normal mode permits chosen speed; automation target stop remains exact even
   at Fast. Add no-display HTTP tests for pause/step/reset/invalid commands early.
3. Add binary save/upload ingress and validated replacement. Test independently
   with HTTP and CLI before browser work, including different-world checkpoint,
   invalid upload, stale queued upload and slow reader isolation. Header/body
   validation precedes engine access. Update response assembly to support bytes
   and Content-Disposition without weakening existing static/JSON responses.
4. Update ui/index.html/style.css/app.js: always-visible status/counts, accessible
   controls/status feedback, speed select, file input/download. Disable dependent
   controls while request pending, show errors inline, recover from rejected
   commands without reconnect/reset. Cache world by epoch, use revision ordering;
   keep selected inspector live at10Hz. Add pure `ui/selection.js` hit-testing if
   useful (embed route in server), test via Node; preserve camera pan/zoom/resize.
   Sidebar scrolls separately; critical controls/counts remain outside scroll.
5. Add stable stack chooser, inspector named traits/alleles/parent labels/death
   state/highlight; handle death between click and server select with clear
   'no longer living' feedback, no accidental retarget. Selected-following is data
   following; camera auto-follow is optional and not planned.
6. Extend existing tests/test_ui.py and CDP helper tests (new
   tests/ui_controls.cjs and tests/ui_selection.cjs if split). Do not regress
   test_ui protocol/purity, empty/1x1 stacks,1000-organism responsiveness, real
   navigation, headless hash parity or browser failure cleanup. Update test.sh
   for any new standalone Node assertions. Retain ui/automation.cjs true10/100
   screenshots and deadline cleanup; optional inspector.png only after main.png
   and without advancing past target. Update explicit schema1 expectations.
7. Update README/docs/UI.md with controls/semantics/precision/limits/checkpoint
   interoperability and decisions; update STATE/ARCHITECTURE/ADR-002 evidence.
   Run targeted then full verification, inspect actual main.png (and inspector
   if produced), reserve final10 minutes for handoff. Record all commands, failures,
   fixes, dependencies and deviations. Do not transition to REVIEW or commit.

## Acceptance and regression matrix (planned evidence)

| Acceptance | Required proof in IMPLEMENT |
| --- | --- |
| Run/pause/step/reset/speed | Display-free session tests use fake deadlines: pause no ticks across due times, run resumes, repeated run/pause idempotent, Step while running pauses and delta exactly1, consecutive steps delta1 each including extinct world. After commands acknowledged no scheduler extra tick. HTTP matches session and ordinary production engine hash after explicit N steps. |
| Reset repeatability | At nonzero tick reset and compare complete hash/checkpoint bytes with fresh exact current Config/seed at0, repeat twice; arbitrary magnitude negative seed, empty and mixed/tiny worlds. After loading a different config/dimensions/seed, reset matches THAT loaded config, not startup config. Browser sees tick0/new map despite stale old frame. |
| Three nonnegative speeds | Enum parser rejects negative/zero/arbitrary rates/unknown names with no state mutation; fake-time5/20/60 tick spacing and no catch-up bursts; browser selector has three working levels and selected server value. No timing-fragile fixed tick assertions while running. |
| Always-visible counts/tick | Real browser at1440x900 and1280x720 checks nonzero bounds/visibility of header +3 counts while inspector scrolls, paused/running/reset/load/extinct; compare labels to same accepted frame. |
| Complete inspector | Rust DTO exact key/locus list and independent founder allele32768/trait values; production-born plant/animal parent IDs, species registry match; real map click opens inspector, selects any ID in stacked1x1 chooser after pan/zoom; drag does not select; empty click harmless. Both kinds of animals covered. |
| Follow and death | Select living organism, step/run and compare current ID/age/vitals/position to engine; actual production death retains selected ID, death tick/cause, last-seen traits/genome/parents with timestamp. Died panel persists until clear/reselect/reset/load. Ensure test fixture really dies; death never retargets new occupant. |
| UI checkpoint file save/load | Real browser fetch-backed download captured by CDP download behavior to workspace target; file passed to CLI --load --ticks0 and future continuation. CLI-created nonzero checkpoint uploaded through real file input (DOM.setFileInputFiles), pauses/restores exact hash and view/dimensions, then N UI steps equal CLI continuation; save/load/reset/current seed semantics. Test damaged/unknown-version file leaves paused original hash/selection unchanged and shows useful error. Cancellation changes nothing. |
| Display-free control tests | env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib ui_server plus Python HTTP test subset (no CDP) executes all state transitions, invalid input and persistence rollback. No browser dependency for these. |

Additional tests: query/inspection/speed/pause/save purity through full hash;
selected parent IDs beyond JS2^53 represented as strings via DTO fixture; unknown
ID/speed/stale epoch; auth/Origin/Host/method/type/empty/oversized/truncated body
errors; stale completion after reset; saturation/slow upload cannot block owner
or automation deadline; replacement error never partially swaps cached world.
File protocol reuses checkpoint corruption tests; no new codec test duplication.
No-display tests must use actual session state transitions, not a test-only model.
Check browser stale-reply logic with controlled reordered revisions/epoch fixtures.
Memory O(area+living) existing frame/world plus one selected DTO, bounded upload
buffers and checkpoint bytes/restored engine; history cost remains existing.

Suggested final commands (new tests are not implemented in PLAN):
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib ui_server`
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test checkpoint --test state_hash`
`node tests/ui_selection.cjs` (if created)
`python3 -m unittest discover -s tests -p test_ui.py -v`
`timeout 60s xvfb-run -a ./evosim ui --smoke-test`
`mkdir -p target/task024-shots` then
`timeout 120s xvfb-run -a ./evosim ui --screenshots target/task024-shots`
`./test.sh`, `cargo fmt --check`, `git diff --check`.
Full suite owns host/musl packaging/static empty-root regression. Do not assume
baseline release launcher is rebuilt by cargo test; Python suite rebuilds release.

## Actual PLAN evidence and limits

Only baseline existing tests and planning validation run; no new feature or
browser acceptance success claimed. First combined Cargo command accidentally
applied ui_server filter to integration binaries: only one existing UI DTO unit
test executed, seven integration tests filtered. Corrected unfiltered command
recorded separately in JSON. No dependency installed; existing exact reinstall
commands for musl/Node remain in STATE/setup. Main risks are stale replies after
backward ticks, slow HTTP upload handling, file-transfer CDP coverage, selection
stack ergonomics and canonical purity. UI64MiB upload limit and synchronous codec
latency are explicit limits; huge valid states still risk memory exhaustion.
Save/load serialization may briefly pause responsiveness while owner is busy;
no responsiveness guarantee during large codec operations. Browser disk download
completion is outside server control. No blockers/prior review gaps found.

## Reproducible planning artifact validator

Run this block with Python3 from /workspace (or execute its extracted text).
It checks only planning artifacts, not unimplemented product acceptance.

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-024/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
required = {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-024','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[k],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
changed = set(git('diff','--name-only') + git('ls-files','--others','--exclude-standard'))
expected = {'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-002-ui-technology.md',
            'tasks/TASK-024/handoffs/plan-cycle1.md','tasks/TASK-024/handoffs/plan-cycle1.json'}
assert changed == expected == set(h['changed_files']), changed
for p in changed:
    (root/p).read_text(encoding='utf-8')
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8 JSON/schema, five planning paths, protected scope, no remotes, whitespace')
```

# TASK-024 IMPLEMENT cycle 1

Applied `.agents/skills/implement/SKILL.md`; current phase only. Verified required
AGENTS.md/STATE.md before reading project/contract/state/architecture/task/plan,
dependency TASK-020/022/023 implementation/review handoffs and relevant ADRs.
Dependencies reviewed PASS, no inherited acceptance gaps. Initial tree clean,
no remotes. No task/protected file, orchestration state, dependency or core model
changed; no commit, Git network operation, other phase or agent delegation.

## Implementation and decisions

Follow approved plan: private UiSession owns one ordinary Simulation plus only
application control/scheduler/cache/selection/epoch/revision fields. Its explicit
Duration clock permits actual production control logic tests without sleeping or
display. Closed speed choices Slow5/Normal20/Fast60; Run/Pause idempotent; Step
pauses+exactly one tick. Speed reschedules without ticking, no catch-up. Reset
rebuilds exact current effective configuration/seed; load adopts embedded config;
both pause, clear selection, retain speed and rebuild world cache before swap.
Capacity checks prevent revision/epoch wrapping and pause safely on exhaustion.
No authoritative fields/codec/hash/config/default/ecology/RNG ordering change.

Buttons (no new shortcuts) avoid browser input conflicts. Inspector shows exact
identity/kind/species, age/vitals, parents/generation, all twelve named expressed
traits and exact named decimal u16 loci (genome version1). Founder parents explicitly
none. Cell click uses inverse camera and complete stable-ID kind/ID chooser;
4 CSS pixel drags pan without selecting. Highlight follows current selected cell;
last live DTO is retained on actual death, labelled observation tick plus actual
death tick/cause from one history lookup. Selection never follows a replacement
at the same position. Inspector refresh preserves scroll; counts/tick remain
visible above it. Mobile sticky controls include a compact tick/count summary.

Binary browser download/file-input upload reuses public persistence byte APIs,
not a new codec. Save is observational; wording is Download prepared, since disk
completion belongs to browser. Upload UI cap64MiB, explicit length/type/auth/epoch
validation. Two bounded ingress workers/two queued/two completions keep blocking
socket reads outside owner. Completed upload checks epoch again; decode/cache
before swap. Four original bounded response workers remain. Codec work itself
runs synchronously and can delay response on large files; no public service promise.

Wire schema2 has decimal epoch/revision, running/ready/speed, selected inspector.
Browser serializes polls/actions; rejects old revisions, fetches matching world
before changed-epoch rendering and fits new dimensions. Actions capture their epoch
when initiated, so a queued old inspector action cannot target a loaded world.
Tests deliberately delay a load reply and queue an old-world action; stale command
is rejected. Initial world/frame epochs are matched before first draw.

Existing real10/100-tick smoke/screenshots remain. Optional inspector.png uses
actual map click/chooser after main.png, without additional ticks or another renderer.

Minor implementation choices within plan: no separate selection.js; existing camera
inverse plus browser gesture/stack tests suffice. Rust tests stay private under
session/tests.rs; no engine API exported for tests. Generic inspector formatter is
shared with a large-ID DTO fixture without inserting invalid engine state.
No system package installed; exact existing reinstall commands remain in STATE.

## Evidence and acceptance mapping

- Six display-free UI Rust tests: fake-time5/20/60 deadlines, no catch-up,
  ready/Run/Pause idempotence, exact Step while running/extinct, repeat Reset full
  hash equality with huge negative seed, load-config reset, byte/hash purity,
  invalid-load rollback, actual death follow, capacity boundaries, production-born
  plant/herbivore parents/species and identity/parents above2^53 as strings.
- HTTP tests: controls, speed/ID/method/auth/stale errors; two repeated reset byte
  equality; CLI-created different7x3/seed checkpoint at17; four UI steps byte-equal
  CLI continuation; damaged/unknown checkpoint version preserves selection/bytes;
  empty/type/oversize limits; four stalled64KiB uploads saturate ingress with503
  while Step works; slow upload permits timed ticks/reset and stale completion409.
- Real Chromium test: actual pan/zoom/click/stack picks Plant/Herbivore/Carnivore,
  all fields/loci, stable selected identity/age, actual death at1100 retained,
  actual browser download decoded by CLI, real DOM file input damaged/successful
  load, pause at17/dimensions7x3, three explicit UI steps byte-equal CLI continuation,
  loaded-config reset to0, stale frame fixture and delayed-load stale-action guard.
  Tick/count bounds tested1440x900/1280x720, mobile800px sticky summary after scroll.
- Existing browser navigation/palette/1000-population responsiveness, explicit10/100
  UI/headless hashes, genuine screenshot dimensions, static-musl/empty-root CLI,
  checkpoints, batch and all biological regression tests remain in ./test.sh.

Exact commands/exit codes and final totals are in adjacent JSON; logs/artifacts in
`target/task024-*` are ignored build outputs, not durable phase source. Review can
reproduce from tests and commands. Final artifact validator is task-local.

## Failures found and corrected

Initial Rust test compilation: json! does not accept array-repeat syntax (changed
to Vec), ambiguous string Into (to_owned), TrySendError has no into_inner (match).
Later inspector formatter extraction left one extra delimiter; corrected before
successful six-test run. No feature success claimed for these failed invocations.

Initial ingress saturation fixture used10-byte header-only requests and timed out
instead of saturating application workers. Changed stalled bodies to64KiB to
reliably occupy ingress; two ingress tests pass. Earlier full run had already
loaded old Python fixture and failed that one case (all Rust and other Python
cases passed); fresh final full run uses corrected fixture. This is a test-fixture
correction, not an increased service limit or engine scheduling change.

## Limits and next steps

Large legitimate states/history can exhaust memory; codec/cache work can delay
single owner. Slow clients can occupy bounded worker capacity; abrupt host/process
kill bypasses orderly browser cleanup. Browser controls actual disk download
completion. Same-build/machine checkpoint continuation; no fresh OS/minimum-Rust
or universal frame-rate claim. All UI-only fields remain excluded from canonical
inventory; future core changes retain ADR-015/018 obligations. Parameter editing
and charts remain TASK-025. Harness owns review/commits/transitions; no next phase
started. No known acceptance gap at handoff; actual final validation recorded JSON.

A second broad run passed all221 Rust tests and all feature checks, but one existing
profile-inventory assertion failed because the agent launched independent smoke/
screenshot processes concurrently with Python tests. The before set contained an
independent profile that was correctly cleaned during the assertion interval.
Corrected the verification procedure: final full suite runs with no other browser
commands. No product workaround or weakened cleanup assertion was introduced.

Final screenshots opened with view_image: actual1440x900 main.png and inspector.png,
world visible, all controls/tick/counts/compact permanent biome legend present;
selected Plant#1 age100 and founder parents visible in inspector image. Separate
virtual-display smoke and screenshot commands both exited0 at exactly10/100.


Final TASK-024 verification: `./test.sh > target/task024-full-isolated.log 2>&1`
exit0:131 unit+89 integration+1 rustdoc=221 Rust,19 Python and Node camera checks;
0 failed/ignored/skipped. Includes all final control/inspector/files/epoch/mobile
assets plus host/static-musl/setup twice/build/ELF/copied-empty-root regressions.
Both initial/sustained1000 fixtures render51 frames/5.2s (~9.81/s); no universal
rate claim. Run the full suite without other browser commands: existing global
profile-inventory assertions require isolation. Earlier failed attempts and fixes
are recorded honestly in implementation handoffs. Virtual-display smoke10 and
screenshots100 exit0; actual1440x900 main.png and inspector.png opened/inspected.
Final UTF-8 handoff/inventory/scope/no-remotes/format checks recorded in JSON. No
known acceptance gaps. No packages installed or phase transition/commit performed.

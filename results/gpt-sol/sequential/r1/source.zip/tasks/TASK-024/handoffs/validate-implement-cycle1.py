"""Validate implementation phase artifacts and local-only protected scope."""
from pathlib import Path
import json
import subprocess
ROOT=Path('/workspace')
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).splitlines()
h=json.loads((ROOT/'tasks/TASK-024/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
required={'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'}
assert required<=h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-024','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):assert isinstance(h[key],list)
for test in h['tests']:
    assert isinstance(test['command'],str) and type(test['exit_code']) is int and isinstance(test['notes'],str)
changed=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
assert changed==set(h['changed_files']),(changed,set(h['changed_files']))
for path in changed:
    (ROOT/path).read_text(encoding='utf-8')
    assert path not in {'AGENTS.md','CLAUDE.md','docs/CONTRACT.md'}
    assert not path.startswith(('.agents/skills/','tools/'))
    assert not (path.startswith('tasks/') and Path(path).name in {'task.md','task.json'})
assert not git('remote','-v')
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
subprocess.run(['cargo','fmt','--check'],cwd=ROOT,check=True)
print('PASS: UTF-8 handoff/schema, exact inventory, protected scope, no remotes, format/whitespace')

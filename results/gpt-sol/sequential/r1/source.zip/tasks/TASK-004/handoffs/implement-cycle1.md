# TASK-004 IMPLEMENT cycle 1

Implemented the approved plan only: src/topology.rs, public library export and
public-API tests/topology.rs. Required files verified before inspection. Read
project/contract/state/architecture, task specs, current implementation skill,
TASK-004 plan, TASK-002 dependency handoffs and relevant ADRs. Dependency review
PASS has no gaps; no prior TASK-004 implementation/review or downstream
TASK-005/006/010 handoffs exist. Initial tree clean, no remotes. No commits made.
Bulk inspection output truncated; relevant plan, dependency evidence, state and
ADRs reread in bounded calls. One inspection used guessed ADR-002/004 filenames
that did not exist (cat diagnostics, overall command exit 0); corrected by rg
inventory and reading actual paths. No product/test command failed.

Topology validates positive usize dimensions and checked area without allocating.
Cells have private usize coordinates and read-only getters; signed inputs span
all i128, including MIN/MAX. Shortest displacement has public i128 dx/dy fields;
even half-axis ties are positive in both directions. Chebyshev distance shares
that implementation. Foreign-world cells normalize before queries. Radius
iteration is owned/lazy/unique, O(1) auxiliary space, includes center and handles
usize::MAX safely. Full axes ascend from zero; partial axes start at wrapped
center-radius; y outer/x inner. No new dependencies, config changes, world raster,
spatial index, movement, climate, engine or new CLI commands. No plan deviations.
Architecture ledger and ADR-003 now record implementation and verification.

Actual executed feature/regression evidence:
- `cargo fmt` followed by `cargo test --locked --test topology`: exit 0;
  seven tests pass in 0.41 seconds. Tests cover wrapping all edges/corners,
  negative/multiple turns and i128 extremes, dimension validation/area overflow,
  maximum usize axis without allocation, shortest seam/diagonal directions,
  positive half ties, deterministic order, all radii including usize::MAX,
  degeneracy, foreign-cell normalization and repeated exhausted next().
- Exhaustive public-API tests use every width/height 1..=8, every source/target
  pair for distance/displacement and every center with radii 0..=10 plus
  usize::MAX. Independent unsigned separation oracle checks shortest distance;
  radius oracle filters every cell. Tests check bounds, exact membership,
  uniqueness, center inclusion, repeat ordering, symmetry/identity, displacement
  reaching target, magnitude and antisymmetry outside half-axis ties.
- `./test.sh`: exit 0; 1 unit, 1 CLI, 8 config, 7 topology, 1 rustdoc and 6 Python
  tests pass (24 total, none skipped). Topology tests 0.42 seconds; Python tests
  0.908 seconds. Includes setup twice and build, host/static musl rebuild,
  executable/ignore/version/help/errors, static ELF and actual empty-root
  chroot version execution. No fresh container provisioned.
- `cargo fmt --check && git diff --check`: exit 0 after doc updates.
- Final validator below: exit 0; schema, exact eight changed files, protected
  integrity, no remotes, formatting and whitespace. No code changed after tests.

No system packages installed or Cargo dependency changes. Existing musl tools
and target present; setup retains exact missing-dependency install commands in
STATE. i128 is a finite machine input domain; enormous representable worlds
remain expensive to enumerate fully. No simulator throughput or downstream
behavior is claimed. No blockers or known acceptance gaps. Harness owns review
and transitions; assigned reviewer can rerun the targeted/full commands above.

Final validator, from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-004/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-004/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-004','implement',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
expected = {'src/topology.rs','src/lib.rs','tests/topology.rs','docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-003-spatial-index.md','tasks/TASK-004/handoffs/implement-cycle1.md','tasks/TASK-004/handoffs/implement-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['cargo','fmt','--check'],cwd=root,check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
print('PASS: UTF-8/schema, exact eight implementation paths, protected files, no remotes, formatting, whitespace')
```

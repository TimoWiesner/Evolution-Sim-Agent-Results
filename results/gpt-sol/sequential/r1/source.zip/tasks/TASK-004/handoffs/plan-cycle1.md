# TASK-004 PLAN cycle 1

## Entry findings and scope

Verified /workspace/AGENTS.md and docs/STATE.md before inspection. Read project,
contract, state, architecture, task specifications, PLAN skill, all existing
TASK-001/002/003 phase handoffs and ADRs. Initial tree clean; no remotes.
TASK-002 dependency review PASS has no gaps; TASK-003 configuration also PASS.
No prior TASK-004 handoff or downstream TASK-005/006/010 handoffs exist.
Some bulk reads truncated; bounded follow-ups covered relevant decisions,
implementation notes and dependency evidence. No packages installed.

This phase changes planning documentation only. Geometry is a pure Rust value
module, not a world allocation, organism/index, climate, scheduler or CLI feature.
ADR-003 already chooses Chebyshev and positive half-axis ties. No superseding ADR
is needed; append the representation/API refinement to that ADR.

## Interfaces and representation for IMPLEMENT

Add src/topology.rs and `pub mod topology` in src/lib.rs. Use std only, no Cargo
or configuration schema changes. The module imports neither config nor CLI/UI.
Config's existing usize dimensions can be passed directly by future engine code.

- `Topology::new(width: usize, height: usize) -> Result<Topology, TopologyError>`:
  reject zero axes and checked width*height overflow, with Display/Error messages.
  Store private width/height/area; expose read-only getters. No raster allocation.
- `Cell`: private usize x/y with x()/y() getters; derive Copy, Clone, Debug, Eq,
  PartialEq, Hash. Construct through `Topology::cell(x: i128, y: i128) -> Cell`.
  i128 accepts signed coordinates far beyond machine-sized grid dimensions.
  All supported integer inputs mean the full i128 domain, not arbitrary BigInts.
  Dimensions are usize on the supported x86-64 target; conversion to i128 is exact.
- `Displacement`: signed i128 dx/dy, public fields or getters, Copy/Clone/Debug/Eq.
  `Topology::displacement(from: Cell, to: Cell) -> Displacement` gives the shortest
  signed displacement along each axis, not a normalized unit vector.
- `Topology::distance(from: Cell, to: Cell) -> usize`: max(abs(dx),abs(dy)), using
  the same shortest axis separations as displacement. Inclusive radius semantics.
- `Topology::cells_within(center: Cell, radius: usize) -> CellsWithin`: deterministic
  lazy owned iterator of Cell values, including center. No result Vec or HashSet.
  Radius usize::MAX is valid. Iterator retains value state only, not references.
  Standard Iterator is enough; do not promise ExactSizeIterator or special traits.

Cell represents an integer position, not ownership by a particular world. Normalize
Cell inputs again in every query so passing a cell from another topology is safe
and documented. Keep fields private so raw coordinate construction is explicit.
No row-major index conversion or movement API is required: future index/movement
owners can add those when needed. Document eight-neighbor Chebyshev adjacency and
that movement must exclude the origin; cells_within deliberately includes it.

## Algorithms and edge semantics

Normalize axes with `coordinate.rem_euclid(size as i128)`; never abs/negate the raw
coordinate, so i128::MIN is safe. For displacement first normalize both cells,
compute forward=(target-origin).rem_euclid(size), and backward=size-forward.
Return forward if forward<=backward, else -backward. A zero difference returns 0.
Positive exact half-axis ties follow ADR-003; antisymmetry is deliberately absent
at those ties. Applying the displacement and wrapping must reach the target.
Distance is symmetric even when the chosen displacement is not antisymmetric.

For each radius axis, if radius>=size/2 the axis is fully covered: enumerate
0..size in ascending order. Otherwise 2*radius+1<size fits usize; enumerate that
many coordinates starting at wrap(center-radius), incrementing and wrapping.
Compute center-radius in i128 after conversion, avoiding usize underflow. This
branch avoids ever doubling huge radii and caps work to unique cells.
Cartesian product order: y outer, x inner. For partial axes start at wrapped
center-radius; full axes start at zero. Use counters/reset, not overflowing
coordinate addition or multiplication. Radius zero returns exactly center;
1x1 always yields one cell; 1xN/Nx1 collapse the degenerate axis naturally.
Construction O(1), iteration O(returned cells), auxiliary memory O(1), count at
most checked area. Never iterate the unwrapped square or deduplicate afterward.
A full-world iterator can still take area time; laziness prevents eager memory
failure but does not promise affordable enumeration of enormous valid worlds.

## Ordered implementation plan (next assigned phase only)

1. Implement topology value/error types, validated constructor and signed wrapping
   in src/topology.rs; expose module in src/lib.rs. Preserve config independence.
2. Implement shared axis displacement, Chebyshev distance and lazy capped-axis
   radius iterator with the exact ordering above. Add rustdoc examples and explain
   half-axis tie behavior, full signed input domain and cross-topology normalization.
3. Add tests/topology.rs using only public API and Rust built-in tests. Use exhaustive
   finite-domain property checks and an independently written brute-force oracle;
   no random crate or new property-testing dependency needed.
4. Run targeted tests and complete existing regression/packaging suite, formatting
   and whitespace checks. Inspect changed/protected paths and no remotes. Record
   actual commands/results, counts and failures, never inherited results as new.
5. Update STATE/ARCHITECTURE and ADR-003 from planned to implemented geometry only;
   dense index remains future TASK-010. Write implement-cycle1.md and mandatory
   JSON. Do not alter task specs/states, commit, or transition phases.

## Acceptance and verification matrix

All feature checks below are planned, not executed during PLAN.

- Coordinate mapping: table tests on 7x4 check left/right/top/bottom crossings,
  all four corners, negative values and offsets several widths/heights away.
  Include i128::MIN/MAX per axis, -1, zero and exact dimension multiples. Verify
  known expected remainders, bounds and idempotence. Test maximum usize axis with
  other axis 1 (no allocation) to exercise signed conversion and extreme distance.
- Shortest direction/distance: explicit horizontal/vertical/corner seam pairs,
  7x4 non-square world, coincident cells, diagonal moves and even half-axis ties
  in both argument orders. Example 7x4 (0,0)->(6,3) is (-1,-1), distance 1;
  4x6 (0,0)->(2,3) is (+2,+3), reverse also (+2,+3).
- Radius: radius 0, 1, just below/at half-axis coverage, dimensions, many times
  dimensions and usize::MAX. On small grids collect into a set and assert no
  duplicates; compare to every row-major cell filtered by an independent oracle
  using min(abs coordinate difference,size-abs difference). Assert center included,
  exact count, no out-of-bounds values, repeated calls same sequence and documented
  ordering. Huge radius on 2x3 must finish with exactly six outputs.
- Degeneracy: 1x1, 1x7, 7x1, 2x2 and non-square grids cover wrapping, distance,
  displacement and radii; 1x1 displacement zero and all radii return one cell.
- Exhaustive properties: dimensions 1..=8 on each axis, every source/target pair,
  radii 0..=10 plus usize::MAX. Check oracle equality, distance symmetry/identity,
  displacement wrapping to target, magnitude equal to distance, bounds/uniqueness,
  and radius membership. Keep loops bounded; if factoring radius checks out of
  pair loops reduces repetition, retain every center/radius combination. Check
  displacement antisymmetry only when neither differing axis is an even half tie.
- API errors: zero width, zero height, checked area overflow; valid area boundary
  usize::MAX x 1 construction; passing cells produced by another topology.
- Commands: `cargo test --locked --test topology`, `./test.sh`,
  `cargo fmt --check`, `git diff --check`. ./test.sh discovers integration tests
  automatically and retains host/musl/static ELF/copied-root version regressions.
  No run command, benchmark throughput, UI or spatial-index test is claimed here.

## Risks and phase evidence

Main risks are signed overflow, huge-radius arithmetic, duplicate degenerate
neighbors and undocumented tie/order behavior. Wide signed intermediates, branch
before doubling, bounded iterators and independent exhaustive oracles address
these. i128 is an explicit finite machine input domain. Topology validates
representability, not memory availability. No dependency/system install expected;
existing setup must reinstall missing musl prerequisites using STATE commands.
No prior review gaps, blockers or plan deviations. Product suites were not run
because no feature code changed. Planning scope/schema/whitespace validation is
recorded in JSON. Harness owns all commits and subsequent phase assignment.

Reproduce final PLAN validation from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-004/handoffs/plan-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, subprocess
root = Path('/workspace')
h = json.loads((root/'tasks/TASK-004/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict']) == ('TASK-004','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str)
for key in ('changed_files','decisions','tests','risks','next_steps','gaps'):
    assert isinstance(h[key],list)
for t in h['tests']:
    assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args):
    return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
actual=set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-003-spatial-index.md','tasks/TASK-004/handoffs/plan-cycle1.md','tasks/TASK-004/handoffs/plan-cycle1.json'}
assert actual == expected == set(h['changed_files']), actual
assert all((root/p).is_file() for p in actual)
assert not git('remote','-v')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json')
subprocess.run(['git','-C',str(root),'diff','--check'],check=True)
print('PASS: UTF-8/schema, exact five planning paths, protected files, no remotes, whitespace')
```

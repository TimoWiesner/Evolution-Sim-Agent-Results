"""Local implementation evidence/schema/scope validation; no simulation mutation."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).resolve().parents[3]
assert root == Path('/workspace')
p = root / 'tasks/TASK-027/evidence'
h = json.loads((root / 'tasks/TASK-027/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert h['task_id'] == 'TASK-027' and h['phase'] == 'implement'
assert type(h['cycle']) is int and h['cycle'] == 1 and h['verdict'] == 'N/A'
assert not h['gaps']
for test in h['tests']:
    assert isinstance(test['command'], str) and type(test['exit_code']) is int
changed = subprocess.check_output(['git','diff','--name-only'], cwd=root, text=True).splitlines()
added = subprocess.check_output(['git','ls-files','--others','--exclude-standard'], cwd=root, text=True).splitlines()
assert set(changed + added) == set(h['changed_files'])
for name in changed + added:
    assert name not in ['AGENTS.md','CLAUDE.md','docs/CONTRACT.md','tasks/TASK-027/task.md','tasks/TASK-027/task.json']
    assert not name.startswith('.agents/skills/')
    assert (root / name).is_file()
assert not subprocess.check_output(['git','remote','-v'], cwd=root, text=True).strip()
commands = json.loads((p / 'commands.json').read_text())
for name, digest in commands['final_production_source_sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == digest
assert 'src/config.rs' not in changed and 'Cargo.toml' not in changed and 'Cargo.lock' not in changed
assert (root/'src/simulation.rs').read_text().count('("hunting", HUNTING_MODEL_VERSION)') == 2
assert 'energy < 750.' in (root/'src/ecology/carnivores.rs').read_text()
results = json.loads((p/'test-results.json').read_text())
assert results['exit_code'] == 0 and results['rust_passed'] == 232 and results['python_tests'] == 24
log = (p/'test-logs/full-suite.log').read_text()
rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)
assert sum(int(row[0]) for row in rows) == 232
assert sum(int(row[1]) for row in rows) == 0
assert sum(int(row[2]) for row in rows) == 1
assert 'Ran 24 tests' in log and '\nOK\n' in log
assert 'FAILED' not in log
assert (p/'performance-primary.exit').read_text().strip() == '101'
assert 'population floor at 685: 1998' in (p/'performance-primary.stderr').read_text()
for name, repeats in [('replacement',5),('mixed',9)]:
    report = json.loads((p/f'performance-{name}.json').read_text())
    assert report['repeats'] == repeats and report['median_ticks_per_second'] >= 100
    assert all(run['population_min'] >= 2000 for run in report['runs'])
selection = json.loads((p/'selection.json').read_text())
assert selection['chosen'] == 'T1' and selection['threshold'] == 750
for run in json.loads((p/'final-build-verification.json').read_text()):
    frozen = json.loads((p/f'chosen-heldout/seed-{run["seed"]}.json').read_text())
    assert run['state_hash'] == frozen['state_hash']
subprocess.run(['python3','tools/balance_report.py','--validate',str(p)], cwd=root, check=True, stdout=subprocess.DEVNULL)
subprocess.run(['cargo','fmt','--check'], cwd=root, check=True)
subprocess.run(['git','diff','--check'], cwd=root, check=True)
print('PASS: handoff/scope/no remotes,232 Rust+24 Python,full experiment counters/hashes/seed partition,performance,format')

"""Independent TASK-027 evidence/replay and review-run checks."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace')
E = ROOT / 'tasks/TASK-027/evidence'
OUT = ROOT / 'target/task027-review'
spec = importlib.util.spec_from_file_location('balance', ROOT / 'tools/balance_report.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
m.draw_curves = lambda *args: None
results = {str(p.parent.relative_to(E)): m.validate(p.parent)
           for p in sorted(E.rglob('observer.json'))}
m.validate_experiment(E, results)
commands = json.loads((E / 'commands.json').read_text())
for name, digest in commands['baseline_source_sha256'].items():
    data = subprocess.check_output(['git', 'show', commands['baseline_revision'] + ':' + name], cwd=ROOT)
    assert hashlib.sha256(data).hexdigest() == digest
for name, digest in commands['preserved_executables'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
for folder, recorded, seeds in [('baseline', 'baseline', range(10)),
                                 ('heldout', 'chosen-heldout', range(100, 105))]:
    for seed in seeds:
        actual = json.loads((OUT / folder / f'seed-{seed}.json').read_text())
        expected = json.loads((E / recorded / f'seed-{seed}.json').read_text())
        for key in ['state_hash', 'final', 'totals', 'series', 'tick_start', 'tick_end']:
            assert actual[key] == expected[key], (folder, seed, key)
log = (OUT / 'full-suite.log').read_text()
rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
assert sum(int(r[0]) for r in rows) == 232
assert sum(int(r[1]) for r in rows) == 0
assert sum(int(r[2]) for r in rows) == 1
assert 'Ran 24 tests' in log and '\nOK\n' in log and 'FAILED' not in log
summary = {'observer_directories': len(results), 'baseline_replays': 10,
           'heldout_replays': 5, 'rust_passed': 232, 'python_passed': 24}
for workload in ['primary', 'mixed']:
    r = json.loads((OUT / f'performance-{workload}.json').read_text())
    assert r['median_ticks_per_second'] >= 100
    assert all(x['population_min'] >= 2000 for x in r['runs'])
    summary[workload] = {k: r[k] for k in ['median_ticks_per_second', 'repeats']}
    summary[workload]['population_min'] = min(x['population_min'] for x in r['runs'])
    frozen = json.loads((E / ('performance-replacement.json' if workload == 'primary' else 'performance-mixed.json')).read_text())
    for a, b in zip(r['runs'], frozen['runs']):
        for key in ['state_hash', 'population_min', 'population_max', 'kinds_start', 'kinds_end', 'births', 'deaths']:
            assert a[key] == b[key], (workload, key)
assert not subprocess.check_output(['git', 'remote', '-v'], cwd=ROOT, text=True).strip()
subprocess.run(['cargo', 'fmt', '--check'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
(ROOT / 'tasks/TASK-027/handoffs/review-measurements.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))

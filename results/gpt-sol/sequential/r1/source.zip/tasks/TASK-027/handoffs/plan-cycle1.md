# TASK-027 PLAN cycle 1

Documentation-only plan. No ecology/default change or balance experiment executed
in PLAN. Dependency TASK-018/020/021/022/025/026 reviews all PASS with no gaps;
TASK-027 has no previous handoff or review remediation. Initial tree and remotes
were empty. Read project, contract, state, architecture, task/specification,
dependency handoffs, all ADRs and the plan skill. No external files or network.

## Findings and constraints

Rust single-owner engine, cell buckets, twelve-locus DNA and seeded RNG remain.
`src/simulation.rs:298` pays carnivore upkeep then pursues/attacks regardless of
reserve. `src/ecology/carnivores.rs` caps nutrition but not attacks; a full predator
can destroy prey for almost no usable gain. Founders have 1000 energy, identical
DNA, sequential row-major placement across kinds (`population.rs:136`), making
initial contact biased. TASK-018 reports herbivore extinction22..27 and carnivore
857..875 on five seeds. These are historical clues, NOT the required new baseline
or proof of causality. Herbivore risk filtering only avoids feeding near predators;
it is not escape movement. Reproduction is local/contact, mature, paid and cooled.
Do not claim durable coexistence from delaying one founder extinction.

`batch` samples max(1,N/100), has no sample override and its extinction boolean is
final-only. At10000 it cannot identify exact early extinction. Keep that interface
unchanged; pair required batch evidence with a separate immutable observer using
the same engine/config and verify final hash/totals match for every seed. No global
observer counts may feed ecology. Timings exclude observer serialization as stated.

## Ordered implementation (only after harness assigns IMPLEMENT)

1. Budget0–12 minutes: read this plan, implement skill and ADR-020. Build release
   CLI before any biology/default edits (`cargo build --locked --release --bin evosim`).
   Preserve `target/task027/baseline-evosim`, revision (`git rev-parse HEAD`), compiler
   version, effective config, executable/source digests and exact commands. Create
   `tasks/TASK-027/evidence/fixed.json` with EXACT fixed-only config:
   `{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}`.
   Run `./evosim batch --config tasks/TASK-027/evidence/fixed.json --seeds 0,1,2,3,4,5,6,7,8,9 --ticks 10000 --out-dir tasks/TASK-027/evidence/baseline`.
   Record all ten completed outputs and summary; timeout is incomplete evidence.
   No source/default/ecology edit before baseline. Documentation/harness only is OK.

2. Add `examples/balance_report.rs` and `examples/support/balance.rs`, external
   observers only, no new crate/public mutation API. Interface:
   `cargo run --locked --release --example balance_report -- --config FILE --seeds 0,1,2,3,4,5,6,7,8,9 --ticks 10000 --out-dir DIR`.
   Parse exact signed seeds with Config/Seed; fresh Simulation per seed, no engine
   clones needed. On tick0 and every completed tick record tick, three counts,
   births and cumulative deaths for all five causes via Population getters.
   Stream compact CSV per seed; retain JSON summary with effective config, first
   zero per kind (null=survives horizon,0=absent initially), all tied first kinds,
   horizon, final hash/totals, and death counts at each extinction plus final.
   Coexistence score is first completed tick with ANY zero, or horizon if none;
   label horizon survivors right-censored, not extinct at10000. Curves show all
   kinds throughout, not only the first extinction. Derive interval death counts
   by differencing exact cumulative counts. Cheap per-tick observation O(1) over
   kind/cause counters; retain O(1) observer state plus streaming disk, avoid
   repeated full metrics snapshots/retained engine clones. Match batch final
   hash/final/totals for all ten before calling evidence valid. Add a stdlib
   `tools/balance_report.py` for validation, curve SVG generation and aggregate
   tables from these data (no plotting dependency). Its observer fixtures test
   zero at0, early extinction between batch samples, ties and horizon censoring.

3. BEFORE first ecology/default edit, write baseline diagnosis in docs/BALANCE.md
   and `evidence/baseline-analysis.json`: exact per-seed table, median/min/max
   coexistence, earliest kind(s), births and death causes at first extinction,
   all-kind curves and source code explanation. Digest inputs and record revision/
   command order in `evidence/commands.json`. Describe associations vs causal
   hypothesis. If deaths disagree with predation hypothesis, amend experiment
   rationale here BEFORE editing code, retaining history. Never backfill diagnosis
   as though it preceded a change. New baseline code/binaries remain preserved.

4. Budget12–28 minutes: perform bounded experiments below. Before EACH run append
   trial ID, parent trial, exact diff/config/model identity, expected direction
   and horizon/seeds to `evidence/trials.json`. Afterward append actual summaries,
   hash/curves, elapsed time, failures and accept/reject reason. Retain rejected
   trials too. Never overwrite an evidence directory. Tuning uses seeds0..4 only;
   baseline seeds5..9 can be reported but are not held out. Screen each trial for
   2000 ticks; promote at most two to10000 on seeds0..4. Stop after three changed
   candidates or at minute28 (earlier if tests need longer); collapse is allowed.

   T1 (mandatory mechanism trial): reserve-based hunting satiety as ADR-020,
   initial threshold750 energy. Measure even if it fails. After ordinary upkeep,
   a predator at/above threshold rests this action: no prey sensing/pursuit/
   exploration/attack/RNG; it still ages, pays upkeep and can reproduce normally.
   Below threshold unchanged paid pursuit/hunt semantics. No timer/new field.
   T2: same mechanism threshold500 (parameter of new policy, pure constant), tests
   whether conserving prey at lower reserves helps recruitment. T3 optional:
   best satiety threshold plus existing animal reproduction_cooldown40 (was100)
   to test replacement beyond founder lifespan; shared-kind effect may overgraze
   plants, explicitly predict/record it. No arbitrary replenishment, founder DNA/
   placement change, lifetime extension or initial counts change in this plan.
   Trial constants are private model policy, not new configuration leaves.
   Choose candidate by full-horizon tuning median first-zero, then worst seed,
   then smaller diff. Prefer baseline if no candidate improves. A tried/rejected
   mechanism still meets the experiment criterion; report lack of improvement.

5. Before held-out measurements freeze selection and write decision, exact model/
   defaults and criteria to ledger. Run chosen fixed-only defaults on NEW seeds
   100..104 for10000 ticks with batch plus exact observer, same validation as
   baseline. These seeds must never be screened/tuned; no candidate adjustment
   after seeing them. Run preserved baseline on100..104 as paired comparison
   (stronger inference than comparing unrelated seeds). Keep tuning and held-out
   statistics separate. If held-out results disappoint, report them unchanged.
   Record full10000 final results for all seeds even after collapse.

6. Files/interfaces: add private `hungry(energy:f64)->bool` and named
   `HUNTING_MODEL_VERSION` in `src/ecology/carnivores.rs`; Simulation gates after
   upkeep/liveness. Keep all Population energy/death/birth paths unchanged.
   Model version2 supersedes model1 in BOTH write/read identity blocks in
   `src/simulation.rs`; rejected trial restoring baseline restores model1.
   Final policy threshold is part of that model identity. No wire layout change,
   no new state, config key or Cargo dependency; preserve canonical schema1 and
   checkpoint envelope1. Old model1 checkpoints must fail explicitly under2,
   not silently resume different biology. New-model roundtrip/continuation must
   be bit exact. Update ADR-012/014/015/018 with final model identity/default and
   compatibility statements. If retaining baseline, leave its identity/goldens.
   Defaults only live in `src/config.rs`; update docs/CONFIGURATION.md and
   docs/ANIMALS.md/docs/ECOLOGY.md if chosen values/policy differ. UI automatically
   reads Config presets; no UI feature changes. No demo scenario is required here.

7. Budget28–50 minutes reserve verification. Add boundary and controlled real-tick
   tests in carnivores.rs and src/simulation/carnivore_tests.rs: below/equal/above
   threshold after upkeep; satiated no movement/trial but upkeep+aging; hungry
   paid success/failure, seam reach, trait-based odds, energy conservation and
   starvation with no prey. Fixtures expecting predation must explicitly begin
   hungry; retain the old probabilistic/budget assertions instead of deleting
   them. Public tests/carnivore_hunting.rs and ecology_integration.rs retain
   absorbing zero, per-tick accounting and reproduction requirements.
   Update tests/checkpoint.rs/checkpoint_cli.rs and tests/state_hash.rs as needed
   for new identity: recompute independent golden reason, reject old-model
   checksum-valid checkpoint, split continuation at hungry/satiated states and
   after reproduction. Do not weaken earlier task acceptance assertions to tune.
   If earlier viability fixtures fail, fix policy or reject candidate.

   Commands: `cargo fmt --check`; `cargo test --locked --lib --test carnivore_hunting --test ecology_integration --test checkpoint --test checkpoint_cli --test state_hash --test batch_cli`;
   `python3 tools/balance_report.py --validate tasks/TASK-027/evidence` (planned
   interface; validate horizons,seed disjointness,CSV/JSON counters,hash equality,
   trial completeness and all linked files); then full `./test.sh > target/task027/full-suite.log 2>&1`.
   Full suite includes headless, musl packaging, UI and explicit release guard.
   Record exact command/exit/counts; no fabricated success or unreported skips.

8. Run TASK-026 `cargo run --locked --release --example performance_bench > tasks/TASK-027/evidence/performance-primary.json`
   and `target/release/examples/performance_bench --workload mixed > tasks/TASK-027/evidence/performance-mixed.json`
   sequentially without other tests running. Retain original workload/warm-up/
   repeats/floor and measure actual final defaults. Compare median and population
   mix to TASK-026847.955/1095.760, distinguish100/s target from10/s guard. If new
   ecology invalidates >=2000 floor, record original failure and actual counts;
   document/measure a justified naturally populated replacement workload, retain
   meaningful >=2000/10-s guard and original failing evidence. Do not quietly
   remove population checks or label changed workload directly comparable.
   Report any slowdown honestly; actual failure is not a successful measurement.

9. Budget50–60 minutes: finish docs/BALANCE.md with before/after tuning and held-out
   tables, curves, trial log links, seed/horizon definitions, first-extinction
   causes, safety audit, performance, exact commands, tests and remaining limits.
   Clearly state whether all kinds survive10000 and whether evidence supports
   improved long coexistence; neither outcome is guaranteed. Update STATE,
   ARCHITECTURE and ADR-020 status; write IMPLEMENT UTF-8 handoff including all
   deviations/failures and changed files. No next phase, commits or task-state edit.

## Acceptance mapping and risks

Baseline criterion -> step1 batch outputs plus step2 exact observer; causality
criterion -> timestamped/digested step3 diagnosis before edits; mechanism/trial
criteria -> T1 plus preregistered complete ledger; held-out -> step5 frozen choice
and seeds100..104; rules/regressions -> step7 tests plus audit all new ecology for
count/census access; performance -> step8 raw reports; honesty -> step9 BALANCE.

Risks: satiety may only postpone initial predation until all founders hunt at
once; resting may reduce mate contact; relaxed cooldown can overgraze; deterministic
placement and identical founders limit generalization; ten/five seeds are modest
and horizon censoring cannot prove stability. Larger survivors can slow runs or
grow histories; use bounded screens and one process at a time. Budget baseline
and held-out full runs before optional trials; do not terminate surviving worlds
at first extinction, since10000 exact horizon is required. No packages installed
in PLAN; inherited setup dependency/install commands remain STATE-authoritative.
No extra dependency is planned. No unresolved blocker or prior REVIEW gap.

## PLAN verification actually run

Existing targeted tests:14 passed (batch5,hunting2,checkpoint3,ecology4), no
failures/ignores/filters. Exact command and failed ancillary inspection are in
JSON. Full suite, fresh balance baseline/trials/held-out and benchmarks are NOT
run in PLAN. No evidence of improved ecology is claimed.

Final validator (execute the first Python fenced block in this file):

```python
from pathlib import Path
import json, re, subprocess
p=Path('tasks/TASK-027/handoffs/plan-cycle1.json')
h=json.loads(p.read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert h['task_id']=='TASK-027' and h['phase']=='plan' and type(h['cycle']) is int and h['cycle']==1
assert h['verdict']=='N/A' and h['gaps']==[]
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int
expected=set(h['changed_files'])
assert len(expected)==6 and all(x.endswith(('.md','.json')) for x in expected)
tracked=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
assert set(tracked+untracked)==expected, (tracked,untracked)
for x in expected: Path(x).read_text(encoding='utf-8')
assert not subprocess.check_output(['git','remote','-v'],text=True).strip()
s=Path('target/task027-plan/tests.log').read_text()
r=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s)
assert len(r)==4 and sum(int(x[0]) for x in r)==14
assert all(all(int(v)==0 for v in x[1:]) for x in r)
subprocess.run(['git','diff','--check'],check=True)
print('PASS: handoff/schema, six documentation-only files,14 existing tests,no remotes,whitespace')
```

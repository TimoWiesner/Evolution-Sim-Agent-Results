# TASK-027 IMPLEMENT cycle1

Implemented only the approved balance phase. No commit, remote/network Git action,
benchmark state, task spec, protected skill/contract or stage change. Initial tree
clean, no remotes. No system dependencies installed; existing STATE exact install
commands remain authoritative. Read required project/contract/state/architecture,
TASK-027 plan and ADR-020, dependent phase handoffs (all reviews PASS), relevant
ADRs and implement skill. Required files were verified before reads.

## Outcome and acceptance map

- Fresh `./evosim batch` fixed-only contract config, seeds0..9,10000, before ecology
  edits. Preserved binary/revision/compiler/source+binary digests. Exact observer
  hashes/final/totals match every batch output. Baseline first zero herbivores21..27,
  median24; all120 deaths predation,no births,plants756..801 at first extinction.
- Written timestamped baseline diagnosis and input digest manifest preceded T1.
  Original record remains evidence/baseline-analysis.json. Current BALANCE repeats
  original diagnosis and distinguishes post-trial reasoning. Every kind's curve,
  births and all causes recorded every completed tick, including empty tails.
- T1 threshold750 and T2 threshold500 were preregistered then each measured2000 and
  10000 on tuning0..4. Both median313,worst312; T1 range312..315,T2 range312..313.
  T2 rejected, results retained. Optional T3 omitted because plant pressure now
  limits both; no unmeasured trial presented as tested. Ledger+exact patches retain
  expectations/outcomes/digests. T1 full ran using preserved binary after T2 screen
  began; no source policy confusion. All formal measurements completed.
- Frozen T1 before unseen100..104. Paired baseline median25,range23..30; chosen
  median316,range313..320. Exact per-kind extinction tables in BALANCE/aggregate.
  All chosen runs eventually lose every kind; baseline plants survive. Durable
  coexistence NOT achieved. No post-held-out policy adjustment. Final current CLI
  batch reproduces frozen chosen final/totals/series/hashes for all five seeds.
- Pure own-energy post-upkeep gate only. No census feedback,replenishment,new
  field,timer,energy source,spawn path,config key,numeric default or dependency.
  Every life/birth/payment/expiry rule remains. Hungriness is not an immortality
  exemption; both maintenance and independent paid reproduction continue.
- Full suite passes, after honest initial stale-fixture/golden failures described
  below. No earlier probability,conservation,reproduction or expiry assertion
  removed. Tests explicitly isolate founder-only lifetime and hungry attack cases.
- Original TASK-026 primary rerun FAILED floor at685,total1998. Full observer
  minimum564,plants extinct799.120/20-herb input alternatives also fail floors
  982/1334. Replacement initial4600/0/40 keeps128x48,100+1000,five repeats,>=2000
  and10/s guard. Explicitly plant-focused and not directly comparable to original
  primary; original mixed input/nine repeats unchanged. Isolated medians857.619
  replacement (min2304) and671.812 mixed (min2559),both>=100/s. Mixed38.7% slower,
  with more active animals. Raw failure,candidates,final and excluded exploratory
  timings retained. No weakened threshold or hidden population replenishment.
- BALANCE.md openly states collapse, tradeoffs, causes, limits and reproducibility;
  STATE/ARCHITECTURE/ADRs/ANIMALS/ECOLOGY/PERFORMANCE/CONFIGURATION kept current.

## Implementation and compatibility

Private hungry(energy) in ecology/carnivores, gate in Simulation after existing
upkeep/liveness. Own energy>=750 rests action,skipping sensing/movement/attack/RNG.
Shared HUNTING_MODEL_VERSION2 in canonical writer and reader; schema1/envelope1/
layout and full ADR-015/018 inventory unchanged. Old hunting1 checkpoints fail
explicitly, even with a valid checksum. No migration promised. Golden empty state
only differs at hunting identity; two tiny real checkpoints plus independent
Python hashlib proof retained in evidence/golden-verification.json. Checkpoint
continuations cover resting parents,hungry offspring and existing recruitment,
mutation/speciation,cooldown/extinction cases.

New example is an O(1)-observer-memory per-tick CSV stream over public immutable
getters and ordinary Simulation ticks. Small summaries retain one seed record per
run. Final hash once per seed. Python validator retains one CSV run outside engine,
checks accounting,monotone causes,birth freeze after zero,exact zeros/ties/censoring,
summary counters,batch identity/trial links/digests/seed partition and draws SVGs.
No count is fed back to policy. No UI feature changes.

Plan deviations: observer is self-contained examples/balance_report.rs rather than
splitting a separate support/balance.rs; no other consumer needs the helper, and
keeping the small independent O(1) observer avoids the old ecology helper's full
organism audits. T3 optional omitted. Equal median/worst/diff-size tie resolved by
retaining first candidate750, documented before held-out. Primary workload change
follows the plan's explicitly allowed original-floor-failure path, retaining all
failed alternatives and semantic guard. Experimental T2 temporarily used draft
model2; it produced no supported checkpoints. Final model2 means750 only.

## Actual tests and failures

Exact commands are recorded in JSON handoff and evidence/commands.json. Permanent
raw logs: evidence/test-logs; performance failure stderr/exit also tracked.

1. Initial targeted command exited101:136 passed,3 lib failures (old model golden,
   full-energy action/RNG fixture, lifespan fixture assumed no offspring). Fixed
   independent golden,explicit hungry fixture and disabled reproduction solely in
   founder-expiry fixture. Rerun exited0: targeted test-result totals in logs.
2. New checkpoint tests command exited0:5 tests, including checksum-valid old-model
   rejection and mixed hungry/resting continuation. Existing long recruitment tests
   remain. New Python synthetic tests exited0:2, also included in final full suite.
3. First full ./test.sh exited101 at public lifecycle founder-only fixture expecting
   no animal births. Satiety allowed recruitment. Explicitly set prohibitive animal
   birth cost in that fixture; retained full2200-tick age/accounting/replay and
   founder expiry checks. Targeted lifecycle rerun:3 passed,exit0.
4. Final ./test.sh exited0:232 Rust tests (231 ordinary+explicit release guard),
   24 Python tests and3 Node scripts pass. One debug guard intentionally ignored,
   then explicitly run release:857.001 ticks/s,min2304,tick1100. Includes real
   Chromium controls/inspection/files/charts,headless deterministic run/batch,
   checkpoint CLI,setup/build/static-musl ELF/copied empty-root distribution.
5. Final evidence validator,format and whitespace checks exit0. Source final CLI
   held-out batch comparison exit0:all five exact final/totals/series/hash matches.
6. Original primary performance command exits101 as described; final replacement
   and original mixed commands exit0. Initial overlapping exploratory timings are
   retained but excluded; final timing jobs ran without concurrent tests/profiles.

## Review follow-up and limits

Review the recorded acceptance evidence and scope. Full logs and compact
counts/configs/counters/hashes persist locally; ignored executables can be rebuilt
from recorded baseline revision plus tracked trial patches. No manual commit made.
Old checkpoints deliberately incompatible. Modest seed set,finite horizon,clustered
founders and one reserve threshold limit inference. New mechanism delays first
extinction while worsening eventual plant survival; no durable equilibrium claim.
Primary benchmark replacement is a different plant-focused workload; mixed slowdown
is openly reported. No known acceptance gap or blocker. Harness owns REVIEW and
all subsequent stage/commit/task-state changes.

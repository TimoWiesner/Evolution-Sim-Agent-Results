# TASK-027 REVIEW cycle 1

Verdict: PASS. Independently inspected dad6516..2bbfb5f, task/plan/implementation
handoffs, dependency handoffs/reviews, current project/contract/state/architecture
and relevant ADRs. No product changes, dependencies, Git remotes, commits or phase
transition. All acceptance points satisfied; no remediation gaps.

Acceptance evidence:
- Ten fixed-only baseline batch runs at10000, seeds0..9, are retained with exact
  per-kind first-zero curves/counters. Baseline revision source hashes and preserved
  executable digests verified. Independently reran all ten using the verified
  preserved baseline executable; final/totals/series/hash/tick bounds match exactly.
- Timestamped pre-change diagnosis/digests and ordered command/trial ledger support
  the required sequence. All120 herbivores die by predation before reproduction;
  plants remain abundant. This supports the documented hypothesis, not proof that
  satiety alone solves ecology. Historical chronology is based on retained records.
- T1 and T2 patches, predictions,2000/10000-tick measurements and rejection reason
  are retained. T2 does not improve first extinction. Optional T3 was not executed
  and is not claimed as measured. Selection frozen before unseen100..104.
- Current executable independently reran all five chosen held-out seeds at10000;
  all exact final/totals/series/hash/tick bounds match retained frozen results.
  Baseline paired median25 vs chosen316; chosen eventually loses every kind.
- Read-only observer validation passes across11 directories, checking every CSV
  row, absorbing zero, cumulative accounting/death causes, extinction summaries,
  batch hashes/totals, trial digests, chronology and seed partition. Review imports
  the validator with plotting disabled so tracked historical evidence is unchanged.
- Production diff only gates the existing carnivore action on its own post-upkeep
  energy<750, with no count feedback/new energy/spawn/timer. Aging/expiry precede
  action and independent paid mating remains. Checkpoint model identity2 is shared
  in writer/reader; tests reject checksum-valid old-model payloads. Fixture edits
  retain founder-expiry and paid hungry-hunting assertions; no removed invariant.
- Original TASK-026 primary floor failure and replacement candidates are honestly
  retained. The approved plan explicitly permits a justified replacement after
  failure. Replacement plant-focused scenario keeps>=2000/1000 measured ticks and
  unchanged10/s guard; original mixed scenario stays unchanged. Isolated review
  medians858.892 and673.454 ticks/s; population minima2304 and2559. Biological
  counters/hashes match retained implementation measurements. No direct old/new
  primary speed comparison is accepted. Mixed slowdown remains documented.
- BALANCE.md states both first-zero improvement and eventual universal collapse;
  this task explicitly does not require guaranteed coexistence.

Actual review tests:
1. First ./test.sh > target/task027-review/full-suite.log 2>&1 exited1. All Rust
   tests passed; Python had one screenshot readiness timeout waiting for rendered
   tick100 after30 seconds. Preserved review-suite-first-failed.log. No product
   edit made. No evidence of ecology failure; intermittent browser startup/runtime
   behavior remains a risk, not silently suppressed.
2. python3 -m unittest discover -s tests -p test_ui.py -v >
   target/task027-review/ui-rerun.log 2>&1 exited0, all5 UI tests pass.
3. Initial benchmark runs overlapped that UI rerun unintentionally; excluded from
   reported timings (target/*-overlap.json). Reran both after it ended, sequentially:
   target/release/examples/performance_bench > target/task027-review/performance-primary.json
   target/release/examples/performance_bench --workload mixed > target/task027-review/performance-mixed.json
   Both exit0. See review-measurements.json for isolated medians/floors/repeats.
4. After benchmarks completed, moved initial full log aside and reran ./test.sh >
   target/task027-review/full-suite.log 2>&1. Exit0:232 Rust,24 Python and3 Node
   scripts pass; one debug release-only performance guard ignored and then explicitly
   executed in release. Includes actual browser, checkpoint and static packaging.
   Final log preserved as review-suite-final.log.
5. python3 tasks/TASK-027/handoffs/review-checks.py exited0, including evidence,
  15 replays, source/executable identity, suite counts, isolated performance data,
   cargo fmt --check, git diff --check and absent Git remotes.

Review scope is documentation/evidence only. No architecture/ADR update needed:
implementation documentation accurately records ownership, compatibility and limits.
No system packages installed. Harness owns completion/commit/subsequent assignment.

# TASK-001 IMPLEMENT cycle 1

## Outcome and scope

Executed the approved plan as documentation only: four accepted ADRs, index and
architecture ledger. No product files, dependencies or future-feature tests were
added. No dependent task handoffs or review gaps existed. No plan deviations.
Read the current implement skill; all required source documents and plan handoffs
were read before edits. No packages were installed and Git has no remotes.

Defaults are explicitly unbenchmarked. ADR-004 fixes 12 loci and phenotype bounds,
1/100 mutation probability and bounded nonzero steps; ADR-001 specifies PRNG
arithmetic. These make the plan concrete without implementing or tuning ecology.
Species extinction is recorded after births, resolving within-tick assignment.

## Verification

No application exists, so no compile, unit, integration, biology, browser or
packaging test is claimed. The following executable documentation check validates
ADR structure, key acceptance content, dependency direction, UTF-8 handoff schema,
exact changed-file allowlist, unchanged protected files, whitespace and no remotes.
Text checks complement manual inspection of all ADRs and the architecture table;
they cannot prove future engine correctness.

Run exactly from /workspace:
python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-001/handoffs/implement-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'

```python
from pathlib import Path
import json
import subprocess
root = Path('/workspace')
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()
adrs = sorted((root / 'docs/decisions').glob('ADR-*.md'))
assert len(adrs) == 4
for p in adrs:
    s = p.read_text(encoding='utf-8')
    for phrase in ['Status: Accepted', '## Context', '## Alternatives',
                   '## Decision', '## Consequences', '## Verification strategy']:
        assert phrase in s, (p, phrase)
    assert s.count('|') >= 16, p
    for phrase in ['performance', 'test', 'dist']:
        assert phrase in s.lower(), (p, phrase)
rng = adrs[0].read_text()
for term in ['xoshiro256**', 'SplitMix64', 'ascending order', 'wall-clock',
             'unordered collection', 'checkpoint', 'SHA-256', 'four u64']:
    assert term in rng, term
arch = (root / 'docs/ARCHITECTURE.md').read_text()
assert 'core -> UI is forbidden' in adrs[1].read_text()
assert 'No core module imports cli, ui_server' in arch
for module in ['config', 'topology', 'rng', 'genome', 'organism', 'spatial',
               'climate', 'species', 'ecology/', 'simulation', 'metrics',
               'persistence', 'cli', 'ui_server', 'main']:
    assert 'src/' + module in arch, module
handoff_path = root / 'tasks/TASK-001/handoffs/implement-cycle1.json'
h = json.loads(handoff_path.read_text(encoding='utf-8'))
for k in ['task_id', 'phase', 'cycle', 'summary', 'changed_files', 'decisions',
          'tests', 'risks', 'next_steps', 'verdict', 'gaps']:
    assert k in h, k
assert (h['task_id'], h['phase'], h['cycle'], h['verdict']) == ('TASK-001', 'implement', 1, 'N/A')
assert type(h['cycle']) is int
for k in ['changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps']:
    assert isinstance(h[k], list), k
for test in h['tests']:
    assert isinstance(test['command'], str) and type(test['exit_code']) is int
expected = set(h['changed_files'])
assert len(expected) == 9
assert all((root / p).is_file() for p in expected)
actual = set(git('diff', '--name-only').splitlines())
actual.update(git('ls-files', '--others', '--exclude-standard').splitlines())
assert actual == expected, (actual, expected)
assert all(p.endswith(('.md', '.json')) and
           (p.startswith('docs/') or p.startswith('tasks/TASK-001/handoffs/implement-'))
           for p in actual)
assert not git('diff', '--name-only', '--', 'AGENTS.md', 'CLAUDE.md',
               'docs/CONTRACT.md', '.agents/skills', 'tasks/TASK-001/task.md',
               'tasks/TASK-001/task.json')
assert not git('remote', '-v')
subprocess.run(['git', '-C', str(root), 'diff', '--check'], check=True)
print('PASS: four ADRs, acceptance text, module boundaries, UTF-8 handoff, nine documentation-only paths, protected files, whitespace and no remotes')
```

The first shell invocation of this validator failed (exit 1) because Markdown
backticks inside double shell quotes triggered command substitution. The command
above avoids literal backticks and is the corrected invocation. No product state
was affected.

## Remaining work

Review this phase against TASK-001 only. Later owning tasks must implement and
validate the engine, static packaging, real-browser automation and ecology;
TASK-001 makes no application performance/coexistence claims. Harness owns the
next phase and commits. No blockers or known acceptance gaps remain.

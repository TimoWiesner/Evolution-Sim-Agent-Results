# TASK-001 — PLAN cycle 1

## Entry findings and scope

Read AGENTS.md, PROJECT, immutable CONTRACT, STATE, ARCHITECTURE, task.md,
task.json, decisions/README, and the plan skill. No prior task handoffs exist;
there are no dependencies and no dependent-task handoffs to reconcile. The
repository contains specifications and instructions only. Git status was clean
and `git remote -v` returned no entries. No review gaps exist in this first cycle.

This phase records a plan only. IMPLEMENT for TASK-001 means writing architecture
decisions, not implementing the simulation. Do not create Cargo files, launcher
scripts, UI assets, tests of future features, or install dependencies in TASK-001.
Harness owns task status, commits, and phase transitions.

## Ordered implementation plan

1. Write `docs/decisions/ADR-001-core-runtime.md`.
   - Compare Rust native (proposed choice), Python with arrays/native extensions,
     and TypeScript/Node. Explain development cost versus predictable native loop
     performance, type safety, unit/property testing, dependency footprint and
     reproducible builds. No measured throughput claims before benchmarks exist.
   - Choose a Rust library and thin native application; release build, locked
     dependencies, serde-compatible versioned state/config schemas. Avoid requiring
     Python/Node on target machines.
   - Plan a static x86_64 Linux musl binary for later `dist/evosim`, embedding UI
     assets. State that static linkage and copied-folder execution must actually
     be verified later; host glibc linkage alone is not a self-contained strategy.
     Later setup must install any missing musl toolchain idempotently and record
     exact commands in STATE; none is installed or required for this phase.
   - Include the determinism specification below and validation consequences.
2. Write `docs/decisions/ADR-002-ui-technology.md`.
   - Compare local browser Canvas/HTML/JavaScript (proposed choice), native egui,
     and Qt/PySide. Explain rendering cost, platform/system dependencies, testing,
     packaging and maintainability. Prefer plain embedded assets without a JS
     runtime or network CDN requirement at runtime.
   - Rust owns the only engine. Local loopback HTTP server accepts commands and
     returns read-only snapshots; JavaScript renders and submits user actions.
     Browser frame rate never supplies simulation randomness or changes tick
     semantics. A single server-owned engine serializes mutating commands.
   - Later automation starts the real server and Chromium, drives controls,
     verifies tick >=10 for smoke / >=100 for screenshots, captures the complete
     real UI at >=1280x720, then reaps children. No synthetic screenshot renderer.
     Headless run/version need neither browser nor display; ordinary UI needs a
     browser. The supplied Chromium is available to root launcher automation;
     a plain distribution host is only guaranteed headless version/run.
3. Write `docs/decisions/ADR-003-spatial-index.md`.
   - Compare dense per-cell buckets (proposed choice), spatial hash buckets,
     brute-force scanning and a quadtree. Dense buckets match the climate/resource
     raster and small default world; memory O(width*height + organisms), local
     query O(unique visited cells + candidates), worst case O(cells + organisms).
     Do not promise constant cost under arbitrary crowding or huge radii.
   - Use a flat row-major cell array with occupant IDs, shared cells permitted.
     IDs are stable and monotonic, not memory addresses. Insert/move/remove update
     buckets immediately; query results sort by ID before simulation decisions.
   - Integer Euclidean remainder normalizes coordinates. Use toroidal Chebyshev
     distance consistently for perception and adjacency, including diagonals.
     Enumerate each wrapped cell at most once, even for radius >= world dimensions;
     bounded wrapped-axis lists avoid radius-dependent repeated scanning. For an
     even-axis half-world movement tie choose the positive direction. Cell-to-cell
     movement consumes a speed budget; no teleporting to the destination.
   - Test plan: compare queries with brute force over seeded random worlds;
     1x1, 1xN, non-square, edges/corners, multiply negative coordinates, radius 0,
     world-spanning radius, dense cells, move/death updates. Rebuild index from
     authoritative organisms after load without consuming randomness.
4. Write `docs/decisions/ADR-004-genome-species.md`.
   - Compare a fixed ordered bounded numeric locus array (proposed choice),
     variable instruction genomes, and bitstrings. Cover locality, O(loci)
     crossover/mutation/distance, testability and portable serialization. All four
     ADRs must explicitly address self-contained packaging, even where the choice
     adds no runtime dependency.
   - Propose haploid `[u16; L]` loci with a versioned fixed locus order and names,
     integer allele domain 0..65535, and explicit bounded mappings to speed,
     strength, health/lifespan, fertility, vision, metabolism, climate preferences,
     aggression/risk. Haploidy is a simplification; animals still require two
     different living compatible parents. Plants clone then mutate.
   - For animals choose one crossover boundary in 1..L and random parent
     orientation; inherit nonempty segments from each parent, then independent
     per-locus bounded signed-step mutation with clamping. State probabilities,
     mutation step bounds and locus meanings in the ADR; they are configurable
     later with defaults, not a promise of tuned ecology. Use integer RNG sampling
     to avoid platform-sensitive distribution helpers. Record both parents and
     generation = max(parent generations)+1 (plant: parent+1).
   - Define distance as sum(abs(a_i-b_i))/(L*65535), with integer rational
     comparisons for exact thresholds. Proposed species threshold = 1/10;
     compatibility threshold = 1/5, same kind, compared inclusively. Species are
     immutable founder exemplars; at birth choose nearest same-kind non-extinct
     exemplar within threshold, break ties by species ID, otherwise create a
     monotonic deterministic species ID/name. Living organisms are not reassigned.
     Initial organisms use the same deterministic assignment in ID order.
     Extinct species records persist but are not reactivated. Parent species for
     a new animal species is that of its lower-ID parent; plant uses its parent;
     initial species has none. Record origination and extinction tick, with
     extinction updated after all committed births/deaths in a tick.
   - Explicitly explain that this is operational genetic classification, not a
     claim of biological reproductive isolation. Fixed exemplars avoid transitive
     chaining and centroid drift; singleton new species are possible. This rule
     permits emergent divergence without forced species creation or population
     rescue. Tests later cover exact threshold and one allele step above, nearest
     exemplar ties, animal compatibility, forced divergence and deterministic IDs.
5. Update `docs/decisions/README.md` to index all four ADRs. Finalize
   `docs/ARCHITECTURE.md` from the proposed ledger, ensuring one-way dependencies,
   state ownership, initialization/tick/query interfaces, RNG/hash/checkpoint
   boundary, CLI error semantics, and continuous torus climate compromise.
6. Update STATE with the documentation-only outcome and exact verification
   evidence. Write `handoffs/implement-cycle1.json` and optional adjacent notes
   when that phase is invoked. Do not claim harness completion.

## Determinism specification to include in ADR-001

Use an explicitly specified seeded PRNG (proposed xoshiro256** with SplitMix64
seed expansion), serializable four-word state, documented integer overflow and
unbiased bounded integer sampling. Record algorithm/schema version and seed;
never use runtime-default RNG, UI randomness, wall clock, hash iteration or
parallel scheduling as engine input. Test known vectors and state restoration
when implemented. Seed conversion must document signed input handling.

Proposed tick pipeline: increment absolute tick; update climate/resources in
row-major order; plant growth/actions; herbivore actions; carnivore actions;
reproduction; commit births/death bookkeeping and species extinction updates;
produce read-only metrics. Each action phase traverses ascending IDs captured
from living organisms. A killed organism becomes inactive immediately and never
acts again; newborns enter only at commit and first act next tick. Later actors
see earlier committed movement/resource use. Reproduction reserves parental
energy/cooldown immediately; pending births cannot reproduce. Fix candidate ties
by distance then ID. Every draw uses the state-owned generator in this documented
order. This introduces order bias, accepted for simplicity and repeatability.

Checkpoint/hash must cover all future-influencing state: validated effective
config, initial counts, organisms/genomes/parents, pending state if allowed,
clock, full RNG, climate/weather/resources, species registry, monotonic ID
counters and cumulative births/deaths. Prefer checkpoint only at completed ticks.
Canonical schema-ordered encoding with ID-sorted records feeds SHA-256; no hash
of unordered maps or human JSON formatting. Derived index/caches reconstruct
identically and cannot influence results through insertion order. Timing,
sampling interval, renderer, metrics buffers and output paths are observational
and excluded. A resumed run and uninterrupted run must give the same state hash.
Same machine/build determinism is binding; cross-platform transcendental float
identity is not promised. Climate spatial functions are periodic across both
axes; latitude is a repeated smooth cold-to-hot-to-cold band on a torus, not a
sphere with two distinct poles.

## Acceptance and verification matrix for IMPLEMENT/REVIEW

- Four ADRs: list/read files, confirm each has Status, Context, at least two
  alternatives besides the chosen option, Decision, Consequences, Verification;
  explicitly cover performance, testability, self-contained dist implications.
- Determinism: inspect ADR-001 for seed/RNG state, order, stable ties, exclusions,
  snapshot/hash equivalence. Future executable tests are specified, not claimed.
- Architecture: inspect module/dependency table; no core -> UI/browser/server edge.
- Scope: `git diff --name-status` against the phase baseline shows only docs and
  task-local handoffs; inspect untracked files as well. No product code.
- Hygiene: `git diff --check`; parse handoff using Python json and check required
  fields/types, UTF-8, task_id/phase/cycle/verdict. Inspect protected-file diff
  and `git remote -v`. No external benchmark is present; none is invented.
- No application test suite exists. Documentation checks are the appropriate
  present evidence; compile, throughput, browser, checkpoint and biology tests
  belong to later tasks, not architecture documentation.

## Risks and follow-up

Rust increases initial implementation effort; browser protocol/automation adds
integration work; static toolchain may need setup support; dense cells use memory
proportional to world area; species exemplar searches can grow with diversity;
haploid fixed loci simplify biology. Defaults and performance remain unmeasured.
Later tasks must measure rather than assume 100 ticks/s or long coexistence.
No interactive questions or external service access are needed.

# TASK-021 PLAN cycle 1

Applied `/workspace/.agents/skills/plan/SKILL.md`. Required AGENTS.md and
STATE.md verified first. Read project, contract, state, architecture, task.md and
task.json, dependent TASK-019/TASK-020 plan/implement/review handoffs, relevant
ADR-001/015/016, configuration/metrics documentation and current CLI/config/test
code. Dependency reviews both PASS with no gaps; no existing TASK-021 handoff or
review gap. Initial tree clean and no Git remotes. Some bulk reads truncated;
focused follow-ups inspected normative contract, APIs and dependent review facts.
No interactive questions, packages, feature changes, commits or phase transitions.

## Current implementation findings

src/cli.rs has process-independent dispatch and private run module; main preserves
status2/Unicode handling. src/cli/run.rs currently combines parsing, validated
seed override, engine loop/result mapping and atomic publication. It already
runs through extinction, samples tick0/interval/end, adds metrics_schema1 and
analytics, hashes full state and measures only tick calls. Batch is unimplemented.
Config::load/from_json/to_json and with_seed allow validated effective variants
without opening private fields. Config export includes all defaults and exact
arbitrary signed seed text. serde_json supports arbitrary_precision and
float_roundtrip. No new config API or dependency is necessary.

Tests/run_cli.rs has five process tests; tests/state_hash.rs two public hash
tests; tests/metrics.rs two public metrics tests. Python entrypoint suite builds
host/musl and tests static ELF/copied empty-root run. Existing ['batch'] rejection
case remains correct because required options are absent. Never compare hashes
between GNU and musl builds; compare repeat runs within each build.

## Decisions (normative detail in ADR-017)

- Sequential independent runs, variant-major then seed-major input order; reuse
  one extracted run helper rather than spawning CLI subprocesses or copying loop.
- Exactly one optional --sweep 'group.key=[numeric values]' over existing numeric
  leaves except seed; validate via effective Config export/reparse. This supports
  many parameter choices without a new config schema or arbitrary path creation.
- Normalized unique arbitrary integer seeds. No sweep retains root seed-N.json;
  sweep outputs variant-0/seed-N.json etc., summary lists every relative path.
- summary.json schema1 lists full effective parameters per run, seeds, ticks,
  final/species/hash/extinction, overall per-kind mean/min/max and extinction
  count/fraction. Initially absent kinds count as zero/extinct, including N0.
- Always emit summary.csv containing every run and aggregate. No extra export
  command/flag, charts, per-variant statistics, worker pool or ecological tuning.
- Summaries omit clocks/absolute paths, so repeats can be byte-identical. Per-run
  result schema/timings stay exactly compatible with standalone run.
- Stage a complete batch before publishing; summary.json last is completion
  marker. Reruns supported, unrelated files preserved. Publication is not a
  directory-wide transaction; promotion failure can leave partial per-run files
  but must not leave a successful completion marker for the new batch.

## Ordered implementation for the assigned IMPLEMENT process

1. Add private src/cli/runner.rs with
   `pub(super) fn simulate(config: Config, ticks: u64, interval: u64)
   -> Result<serde_json::Value,String>`.
   Move the existing sample/count helpers and exact loop/result mapping verbatim
   from run.rs; Config and interval validated by caller. Do not change hash
   schema, ecology, timing boundaries or metrics schema. Add src/cli/output.rs
   for current destination validation, publication and injected failure tests;
   give sibling adapters only the visibility they need. Expose the digits-only
   parser to batch (small private common helper or pub(super) in run acceptable).
   run::execute still parses the same flags, validates config/output first,
   calls simulate, serializes/newline and publishes. Run baseline tests before
   adding batch to isolate regressions. No change to library/core modules.
2. Add private src/cli/batch.rs: strict four required flags and optional --sweep,
   any order, once each. Parse seeds with Seed::from_decimal and reject empty,
   whitespace or normalized duplicates without reducing distinct modulo seeds.
   Load full base config first. Parse sweep at first '=', require exactly two
   path components resolving an existing numeric leaf in exported effective
   JSON; require nonempty number array. Build/revalidate variants independently
   from original base, normalize values by reading validated exports; reject
   duplicate effective values. Set each seed with with_seed. Checked product
   seed_count*variant_count, fallible buffers. No flags beyond ADR-017.
3. Define private immutable batch records, e.g. BatchPlan (ticks, seeds,
   variants, relative destinations), RunSummary and BatchSummary; explicit
   to_json conversion, not Debug serialization. Parameters include all effective
   config groups except seed. Plan holds config variants once, not an R-engine
   array. Read final counts directly from each in-memory result with checked
   extraction or a typed shared result wrapper; no lossy JSON f64 coercion.
   Update three exact u128 sums/min/max and usize extinction counts; checked
   overflow yields status2. Calculate finite mean/fraction at finish. run_count
   >0 invariant eliminates empty means. Final zero, including initial absence,
   is extinction; do not inspect only sparse series or alter the engine.
4. Preflight root/variant dirs and expected files, reject symlink/nonregular
   destinations and config alias. Create dirs as needed, reserve a private unique
   staging dir with create_dir and collision retries inside out-dir. Sequentially
   call simulate with default sample interval, write each result into staging,
   collect only compact metadata, then drop full result before next run. Stage
   both summary files after all runs. Cleanup owned staging on returned failure;
   never recursively delete unrelated outputs. Existing completed output intact
   until promotion. Before promotion invalidate old summary.json, recheck paths,
   rename per-runs, CSV then JSON last. Failed promotion leaves no completion
   summary; partial per-runs may remain. Tests inject failures because root
   bypasses normal chmod errors. No concurrent same-dir writer guarantee/fsync.
5. Implement CSV writer over the same summary records in batch.rs or private
   src/cli/batch/csv.rs. ADR-017 fixes header, run rows (3 per run), aggregate
   rows (3), field order, exact integer seed/count text, parameters compact JSON,
   empty cells and RFC4180 CRLF escaping. Escape all fields through one helper;
   use an independent Python csv.DictReader + json.loads round-trip oracle.
   No CSV crate required. Include unit tests for comma/quote/CR/LF and numeric
   aggregation oracles independently constructed without production engine.
6. Wire `mod batch`, `mod runner`, `mod output` and batch branch into src/cli.rs;
   update --help and generic invalid-command diagnostic to mention supported
   run/batch. Preserve climate/version/help and silent successful run/batch.
7. Add tests/batch_cli.rs process integration and Python entrypoint tests below.
   Keep test artifacts under /workspace/target or suite temp directories there;
   do not modify benchmark tools/checks or task specs. Add docs/BATCH.md normative
   command/schema/CSV/failure/precision docs, link README with complete seed-only
   and 2x2 examples, finalize ADR status and STATE/ARCHITECTURE evidence. No new
   demo scenario, save/load, UI, charts or biological defaults.
8. Run targeted tests, full test.sh, format/scope/UTF-8 checks and record actual
   commands/outcomes including failures in implementation handoffs. If 60-minute
   budget becomes tight, use bounded tiny-grid matrices and reserve time for
   handoff; no multi-thousand-tick batch performance study required. Do not start
   REVIEW or commit; harness owns assignment/state/transitions.

## Acceptance matrix and independent test oracles

1. Contract batch: real process --config fixed-key tiny config --seeds 1,2
   --ticks 17 --out-dir DIR produces seed-1.json, seed-2.json, summary.json and
   summary.csv; no stdout/stderr, status0. Compare every per-seed field except
   elapsed_seconds/ticks_per_second with standalone `run --seed` including all
   analytics/series/hash. Assert default tick arrays and accounting/species.
2. Required 2 values x 2 seeds: tiny world with initial plants2, herbivores1,
   carnivores0; --sweep 'plants.resource_regeneration=[1,2]' --seeds 7,11
   --ticks 17. Exactly four listed runs, correct variant-major/seed-major IDs,
   full parameters reflect the selected value and effective defaults, correct
   relative filenames, no overwrite. Standalone run with four reconstructed
   configurations must match per-run results excluding timings. Also test integer
   sweep initial.plants=[0,4] at ticks0 with seeds1,2.
3. Summary aggregation: for integer sweep above, hand oracle plants final
   [0,0,4,4] => mean2,min0,max4,extinction_count2,fraction0.5;
   herbivores fixed1 => mean/min/max1,extinction_count0; carnivores absent =>
   mean/min/max0,extinction_count4,fraction1. Tick0 is intentional independent
   arithmetic, not a biological probability. Additional nonzero-tick matrix
   recomputes aggregates in Python from actual per-run JSON, verifies seeds,
   all parameters/ticks/final/hash and exact file inventory. Private synthetic
   aggregate fixture checks counts above2^53 remain exact extrema and sum overflow
   returns error. At least one no-plants animals run continues5000 ticks in a
   tiny grid (or reuse established bounded extinction fixture) to confirm final
   zero/extinction with exact ticks and no replenishment.
4. CSV: csv.DictReader sees exactly3*R+3 rows and normative header; each run-kind
   row has exact seed/parameter JSON/ticks/hash/final/extinct, each aggregate
   agrees with JSON. Include negative/normalized/large seeds above u64 in a small
   batch; do not read them via float. Unit test escaping arbitrary strings
   containing comma, quote, CR and LF; no platform newline surprises.
5. Repeatability: two separate output directories and rerun the SAME directory
   with identical args. summary.json and summary.csv must be byte-identical;
   per-run JSON equal after removing just two timings. Relative paths and full
   defaults stay fixed. Reordered seeds/values intentionally reorder entries.
   Check differing seeds change hashes and modulo-equivalent seeds stay distinct
   metadata/files even when RNG streams coincide. Each host/musl build repeated
   separately; no cross-build float/hash equality assumption.
6. Failures: missing/duplicate/unknown flags, odd pairs, unsupported --jobs/
   --sample-every/--save/--load, ticks negative/fraction/overflow; empty seed list,
   leading/trailing/consecutive commas, whitespace/plus/decimal and normalized
   duplicates; malformed base despite overrides. Sweep missing '=', malformed
   JSON, empty/nonarray/nonnumeric, unknown/object/seed path, extra path segments,
   out-of-range/cross-field overflow, duplicate effective float values, repeated
   --sweep. All preflight errors status2, stderr nonempty, stdout empty, no new
   files; existing successful output/sentinel intact. Filesystem cases include
   output regular-file root, symlink root/variant/result, expected destination
   directory/FIFO, missing parent creation, config alias and invalid second
   variant proving no first run published. Inject staging/write/promotion failures
   to verify cleanup/old-summary rules and final marker; do not rely on chmod.
7. Static/offline launcher: extend tests/test_entrypoints.py to run seed-only and
   2x2 CSV/replay tests for ROOT/evosim and dist/evosim from spaced unrelated cwd,
   without displays; extend copied-empty-root static test with a small batch.
   Runtime stays network-free. Existing full suite verifies all old interfaces.

## Executed PLAN checks

Baseline command (record outcome in JSON after completion):
`env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --test run_cli --test state_hash --test metrics > /workspace/target/task021-plan-baseline.log 2>&1`
This is EXISTING run/hash/metrics coverage, not batch validation. No new tests or
product code in PLAN. No packages installed; inherited setup.sh detects missing
musl-tools/target. Exact reinstall commands already in STATE:
`apt-get update`; `apt-get install -y --no-install-recommends musl-tools`;
`rustup target add x86_64-unknown-linux-musl`.

Planned IMPLEMENT commands (not executed in PLAN):
- `env -u DISPLAY -u WAYLAND_DISPLAY cargo test --locked --lib --test cli --test run_cli --test batch_cli --test state_hash --test metrics`
- `./test.sh > /workspace/target/task021-implement-full.log 2>&1`
- `cargo fmt --check` and `git diff --check`.
- Validate mandatory implementation handoff UTF-8/schema/exact paths/protected
  scope and no remotes; add recorded launcher commands as needed for acceptance.

## Risks, limits and fresh-process next steps

Summary means/fractions use f64; final counts/min/max stay exact. Sum uses checked
u128, rejecting overflow rather than wrapping. One engine/result at a time reduces
memory but per-run samples/history and O(R) metadata can still OOM; staging can
fill disk. Long arbitrary seed text may exceed filesystem component limits and
return status2. Sequential execution has no speedup; no throughput promise.
Promotion is not directory-atomic or fsync-durable; no concurrent writer support.
Old unlisted files may survive reruns; summary's list is authoritative. Existing
cross-build float differences remain permitted. No acceptance gap/blocker found,
no prior REVIEW gaps to close. TASK-020's nonblocking singleton-generation ADR
wording note does not affect this batch design and is not changed here.

When IMPLEMENT is assigned, read this handoff, ADR-017 and dependency reviews,
then execute ordered steps and tests. No implementation/batch success claimed.

## Reproducible planning artifact validator

Run from /workspace:
`python3 -c 'from pathlib import Path; exec(Path("tasks/TASK-021/handoffs/plan-cycle1.md").read_text().split(chr(96)*3+"python\n",1)[1].split(chr(96)*3,1)[0])'`

```python
from pathlib import Path
import json, re, subprocess
r=Path('/workspace')
h=json.loads((r/'tasks/TASK-021/handoffs/plan-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id','phase','cycle','summary','changed_files','decisions','tests','risks','next_steps','verdict','gaps'} <= h.keys()
assert (h['task_id'],h['phase'],h['cycle'],h['verdict'])==('TASK-021','plan',1,'N/A')
assert type(h['cycle']) is int and isinstance(h['summary'],str) and h['gaps']==[]
for k in ('changed_files','decisions','tests','risks','next_steps','gaps'): assert isinstance(h[k],list)
for t in h['tests']: assert isinstance(t['command'],str) and type(t['exit_code']) is int and isinstance(t['notes'],str)
def git(*args): return subprocess.check_output(['git',*args],cwd=r,text=True).splitlines()
actual=set(git('diff','--name-only')+git('ls-files','--others','--exclude-standard'))
expected={'docs/STATE.md','docs/ARCHITECTURE.md','docs/decisions/ADR-017-batch-and-export.md','tasks/TASK-021/handoffs/plan-cycle1.md','tasks/TASK-021/handoffs/plan-cycle1.json'}
assert actual==expected==set(h['changed_files']),(actual,expected)
for p in actual: (r/p).read_text(encoding='utf-8')
assert not git('diff','--name-only','--','AGENTS.md','CLAUDE.md','docs/CONTRACT.md','.agents/skills','tasks/*/task.md','tasks/*/task.json','tools')
assert not git('remote','-v')
log=(r/'target/task021-plan-baseline.log').read_text()
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
assert len(counts)==3 and sum(int(a) for a,b,c in counts)==9
assert all(int(b)==int(c)==0 for a,b,c in counts)
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('PASS: planning UTF-8/schema/exact scope, baseline9, protected files, no remotes and whitespace')
```

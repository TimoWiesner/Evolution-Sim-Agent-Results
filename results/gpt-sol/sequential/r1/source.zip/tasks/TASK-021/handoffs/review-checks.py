"""Independent bounded CLI sweep/reconstruction and export review probes."""
import csv
import io
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path('/workspace')
KINDS = ('plants', 'herbivores', 'carnivores')
calls = 0

def invoke(*args):
    global calls
    calls += 1
    p = subprocess.run([str(ROOT / 'evosim'), *map(str, args)], cwd=ROOT,
                       capture_output=True, timeout=60)
    assert p.returncode == 0, p.stderr
    assert not p.stdout and not p.stderr

with tempfile.TemporaryDirectory(prefix='review021-', dir=ROOT / 'target') as tmp:
    root = Path(tmp)
    config = root / 'config.json'
    config.write_text(json.dumps(dict(seed=42, world=dict(width=3, height=2),
                          initial=dict(plants=3, herbivores=2, carnivores=1))))
    for spec, ticks in [('world.width=[1,4]', 251),
                        ('climate.weather_amplitude=[0,0.2]', 19),
                        ('initial.plants=[0,5]', 0)]:
        out = root / 'out'
        args = ('batch', '--config', config, '--seeds', '-3,13', '--ticks', ticks,
                '--out-dir', out, '--sweep', spec)
        invoke(*args)
        before = [(out / name).read_bytes() for name in ('summary.json', 'summary.csv')]
        summary = json.loads(before[0])
        assert summary['run_count'] == len(summary['runs']) == 4
        rows = list(csv.DictReader(io.StringIO(before[1].decode(), newline='')))
        assert len(rows) == 15
        group, leaf = spec.split('=')[0].split('.')
        values = json.loads(spec.split('=')[1])
        for i, record in enumerate(summary['runs']):
            assert record['parameters'][group][leaf] == values[i // 2]
            assert record['seed'] == (-3, 13)[i % 2]
            actual = json.loads((out / record['result_file']).read_bytes())
            effective = dict(record['parameters'], seed=record['seed'])
            oracle = root / 'oracle.json'
            oracle.write_text(json.dumps(effective))
            result = root / 'result.json'
            invoke('run', '--config', oracle, '--ticks', ticks, '--out', result)
            expected = json.loads(result.read_bytes())
            for item in (actual, expected):
                for key in ('elapsed_seconds', 'ticks_per_second'):
                    item.pop(key)
            assert actual == expected
            interval = max(1, ticks // 100)
            assert [r['tick'] for r in actual['series']] == sorted(set([*range(0, ticks+1, interval), ticks]))
            assert record['final'] == actual['final']
            for j, kind in enumerate(KINDS):
                assert int(rows[i*3+j]['final_population']) == actual['final'][kind]
                assert json.loads(rows[i*3+j]['parameters']) == record['parameters']
        for j, kind in enumerate(KINDS):
            ns = [r['final'][kind] for r in summary['runs']]
            aggregate = dict(mean=sum(ns)/4, min=min(ns), max=max(ns),
                             extinction_count=ns.count(0), extinction_fraction=ns.count(0)/4)
            assert summary['aggregates'][kind] == aggregate
            assert all(json.loads(rows[12+j][k]) == v for k, v in aggregate.items())
        invoke(*args)
        assert before == [(out / name).read_bytes() for name in ('summary.json', 'summary.csv')]
print(f'PASS: {calls} launcher calls; three 2x2 matrices, standalone parity, sampling, aggregates, CSV and replay')

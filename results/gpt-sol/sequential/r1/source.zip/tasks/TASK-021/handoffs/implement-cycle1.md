# TASK-021 IMPLEMENT cycle 1

Read the assigned implement skill, task/spec/approved PLAN and ADR-017, product
contract, state/architecture, dependent TASK-019/020 implementation/review memory
and relevant ADR-015/016. Verified required AGENTS.md/STATE.md first. Initial tree
clean, no Git remotes. Work remains solely IMPLEMENT; no commits, task state,
protected instructions/specifications, benchmark tools or phase transitions.

## Result and implementation decisions

Implemented the approved sequential batch design. Contract seed-only runs write
root seed-N.json files. One optional --sweep 'group.key=[numbers]' runs an ordered
variant-major/seed-major matrix with indexed variant directories. Strict flags,
normalized unique arbitrary signed seeds, numeric-leaf resolution, complete base
and per-variant configuration validation precede output creation. Config export
provides effective defaults; each record contains full parameters except exact
seed separately. Checked cardinality/fallible major buffers avoid silent overflow.

cli/runner.rs is extracted verbatim from the former run engine loop/result mapping;
cli/output.rs contains the previous atomic output helper and injected tests.
Standalone run keeps its parser and output behavior. New cli/batch.rs uses one
fresh engine/full result at a time, retains compact owned JSON records, and adds
checked u128 sums/exact extrema and final-zero extinction counts/fractions. JSON
and always-exported RFC4180 CSV omit clocks and absolute paths. The engine,
configuration, defaults, ecology, canonical/hash/metrics schemas, checkpoint
inventory and dependencies do not change. No chart/checkpoint/UI work added.

Private Stage cleanup guard reserves an exclusive in-root directory. Every result
and both summaries stage before publication. Preflight checks real roots/ancestors,
variant dirs, regular destinations and config aliases (including hard links).
Old successful output survives returned staging failures. Promotion invalidates
old summary.json, promotes per-runs then CSV then JSON last. Injected failures
at each staging/promotion position verify cleanup/marker behavior under root.
No directory-wide transaction, fsync durability or concurrent-writer guarantee;
partial promotion can leave replaced files without a completion marker.

No material plan deviation. Compact records are owned serde_json values built by
explicit wire mapping, while planning/aggregation remain private typed records;
there is no Debug serialization or result-file rereading. Ancestor checks and
hard-link identity checks concretely implement the plan's symlink/alias policy.
No package/system dependency installed. Existing exact reinstall commands remain
in STATE and setup.sh detects missing musl prerequisites.

## Acceptance evidence and independent oracles

- tests/batch_cli.rs drives real processes. Seed-only and actual2x2 regeneration
  matrices compare every per-result field except two timings against standalone
  run with reconstructed configs. Same-dir replays compare both summaries bytewise.
- Tick0 initial.plants=[0,4] with two seeds has the independent plant oracle:
  final[0,0,4,4], mean2,min0,max4,extinctions2,fraction0.5; herbivores remain1 and
  absent carnivores are extinct4/4. No-food animals advance exactly5000 ticks to
  zero for both seeds; final summary and sampled tail agree.
- Strict argument/config/sweep cases reject invalid/duplicate effective values,
  normalized duplicate seeds, missing/unknown/unsupported flags and ranges.
  A bad second variant produces no output root. Filesystem tests cover symlink
  root/ancestor/variant/result, FIFO/directory results, config hardlink aliases,
  missing parent creation and unrelated-file preservation. Arbitrary seeds,
  negative zero/leading zeros, reordered flags and distinct modulo seeds retain
  correct normalized exact metadata/files/hash.
- Python stdlib csv.DictReader/json.loads independently parse every run-kind and
  aggregate-kind field and recompute aggregates from results. Matrices, tick0
  hand oracle and seed-only batches run against BOTH root launcher and musl
  distribution from a spaced unrelated cwd without displays. Two distinct output
  dirs and a same-dir rerun compare JSON/CSV bytes. Each per-result matches an
  independent standalone command within that build. Exact inventory is checked.
- Static ELF checks and a copied chroot with no language runtime run a real2x2
  batch, its JSON summary and15 CSV rows. No cross-GNU/musl hash equality assumed.
- Private tests independently exercise CSV comma/quote/CR/LF escaping, count
  extrema above2^53, checked u128 sum overflow, atomic write/rename failures and
  all three batch staging/promotion write positions.

## Executed commands and outcomes

Exact commands/status/counts are retained in implement-cycle1.json. Logs are
local ignored target/task021-*.log; tests themselves and this handoff are durable.
The initial `cargo test --locked --lib cli` invocation failed compilation because
a moved output test lacked `serde_json::json`; added that test-only import and
reran successfully. No product behavior failure was observed. The first full
suite passed210 tests; subsequently added one fault-injection unit and one
normalization integration test and reran the final suite. Final results and
scope validation are recorded below/in the JSON after completion.

## Limits and next steps

Resource exhaustion remains possible for huge valid batches/seed text/worlds and
histories. Means/fractions are f64, exact counts/extrema remain integers. Staging
uses batch-sized disk, and promotion is intentionally not a directory transaction.
No new coexistence/performance/minimum-Rust/fresh-Ubuntu claim. No acceptance gap
or blocker identified. Harness owns review, commits and task/phase transitions.
Future checkpoint implementation still follows full-state ADR-015.

Reproduce final artifact/scope check from /workspace:

```sh
python3 tasks/TASK-021/handoffs/validate-implement-cycle1.py
```

Final completion: targeted134 tests pass. Final full suite212 pass (118 unit,
84 integration,1 rustdoc,9 Python), no failures/ignored/skips. Root/musl/static
ELF/copied empty-root checks pass. Documented shell examples execute silently
with expected3/4 run counts. Format/whitespace and final handoff validator pass.
Required JSON handoff has verdict N/A, no gaps, and all15 changed paths; no
protected edits, Git remotes, package installations, commits or phase transition.

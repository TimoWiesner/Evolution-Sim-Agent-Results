# TASK-021 REVIEW cycle 1

Review scope: committed IMPLEMENT diff `8f354c7..f6ccaf8`, approved PLAN,
TASK-021 specifications, contract, architecture, ADR-015/016/017, dependent
TASK-019/020 handoffs (both reviews PASS), actual code and tests. Required
AGENTS.md and STATE.md were verified first. Applied the repository review skill.
Initial tree clean, no remotes. No product code, protected instructions, task
specification, benchmark state/tools or dependency changes. No commits or phase
transitions. Review artifacts and STATE are the only review changes.

## Acceptance evidence

1. Contract seed-only invocation dispatches to batch, writes root seed-N.json
   results and summary.json. The extracted runner matches the previous run loop,
   mapping and timing exactly; no engine/config/default changes. Existing process
   tests compare complete per-run outputs against standalone run except timings.
   Python entrypoint tests execute both root and musl binaries from unrelated
   spaced paths and copy the static binary into an empty chroot for a real batch.
2. Optional numeric-leaf sweep validates every variant before output. Existing
   tests execute two regeneration values by two seeds and initial plants [0,4].
   Additional review probes run three independent 2x2 matrices: world.width [1,4]
   for 251 ticks, climate.weather_amplitude [0,0.2] for 19 ticks, and
   initial.plants [0,5] at tick zero; all use seeds -3,13. Each record reconstructs
   a standalone config and matches every result field except timings. Default
   sampling at nondivisible endpoints also matches an independent tick oracle.
3. Every record lists exact seed, full effective parameters, start/end ticks,
   relative result path, final counts/species and hash. Checked u128 sums retain
   exact integer extrema; all runs contribute to mean/min/max and final-zero
   extinction count/fraction for each kind. Initial absence counts as zero,
   explicitly documented. The tick-zero [0,4] test has independent means 2,1,0
   and extinction counts 2,0,4. No-food 5000-tick tests verify absorbing zero and
   exact completion. Review probes independently recompute every aggregate.
4. Always-produced summary.csv contains three run rows per simulation and three
   aggregate rows. Python csv/json parsing verifies seeds, parameters, ticks,
   final populations and aggregate fields against independent values. Unit tests
   check comma/quote/CR/LF escaping and exact large integer counts/overflow.
5. Existing tests compare summaries bytewise across two directories and same-dir
   reruns on each build. All three review matrices also compare JSON/CSV bytes
   after same-dir reruns. No timing/path metadata enters summaries.

## Edge cases and design inspection

Strict options reject missing/duplicate/unknown flags, malformed ticks/seeds,
duplicate normalized seeds, invalid base configuration, unknown/nonnumeric sweep
leaves, invalid second variants and duplicate effective values. Exact arbitrary
integer seeds preserve metadata and filenames. Sequential fresh engines avoid
state leakage; batch has no reverse core dependency or biological feedback.

Publication reserves owned staging, cleans returned staging failures and preserves
the prior batch until promotion. Preflight rejects symlink/special destinations
and hard-link aliases to the input config. Fault tests cover every staging and
promotion write position; summary.json is promoted last and absent after failed
promotion. These guarantees match the documented single-writer limits.

No actionable acceptance gaps or required product remediation found. Existing
limits remain: unbounded valid work can exhaust memory/disk, f64 means lose
integer precision above 2^53, promotion lacks directory-wide atomicity/fsync and
concurrent-writer support, and cross-build floating differences are permitted.
No separate fresh-Ubuntu/minimum-Rust/throughput validation. No system dependency
installed; inherited exact reinstall commands in STATE remain applicable.

## Commands

- `./test.sh > /workspace/target/task021-review-full.log 2>&1`: final result below.
- `python3 tasks/TASK-021/handoffs/review-checks.py`: exit 0; 18 launcher calls,
  three 2x2 matrices, standalone parity, sampling, aggregate/CSV and replay checks.
- `cargo fmt --check`: exit 0.
- `git diff --check`: exit 0 before final handoff; repeated after writing it.

The implementation's artifact validator assumes an uncommitted IMPLEMENT tree;
it is not applicable after the orchestrator's implementation commit. This review
checks committed implementation scope and its own current inventory instead.
Harness owns completion, commits and all further phase/task assignments.

Final verdict: PASS. Full suite exit 0: 212 passed (118 unit, 84 integration,
1 rustdoc, 9 Python), no failures/ignored/skips. Log count validator exit 0.
Host/musl/setup/build/static ELF/copied empty-root checks passed. No gaps.

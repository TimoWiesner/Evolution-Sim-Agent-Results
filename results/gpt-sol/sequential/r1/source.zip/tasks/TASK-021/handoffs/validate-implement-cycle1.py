"""Local implementation handoff/scope/evidence check; no benchmark state edits."""
from pathlib import Path
import json
import re
import subprocess

ROOT = Path('/workspace')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).splitlines()

handoff = json.loads((ROOT / 'tasks/TASK-021/handoffs/implement-cycle1.json').read_text(encoding='utf-8'))
assert {'task_id', 'phase', 'cycle', 'summary', 'changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'verdict', 'gaps'} <= handoff.keys()
assert (handoff['task_id'], handoff['phase'], handoff['cycle'], handoff['verdict']) == ('TASK-021', 'implement', 1, 'N/A')
assert type(handoff['cycle']) is int
for key in ('changed_files', 'decisions', 'tests', 'risks', 'next_steps', 'gaps'):
    assert isinstance(handoff[key], list)
for test in handoff['tests']:
    assert isinstance(test['command'], str) and type(test['exit_code']) is int and isinstance(test['notes'], str)
actual = set(git('diff', '--name-only') + git('ls-files', '--others', '--exclude-standard'))
expected = {'README.md', 'docs/ARCHITECTURE.md', 'docs/BATCH.md', 'docs/STATE.md',
            'docs/decisions/ADR-017-batch-and-export.md', 'src/cli.rs',
            'src/cli/batch.rs', 'src/cli/output.rs', 'src/cli/run.rs', 'src/cli/runner.rs',
            'tests/batch_cli.rs', 'tests/test_entrypoints.py',
            'tasks/TASK-021/handoffs/implement-cycle1.md',
            'tasks/TASK-021/handoffs/implement-cycle1.json',
            'tasks/TASK-021/handoffs/validate-implement-cycle1.py'}
assert actual == expected == set(handoff['changed_files']), (actual, expected)
for path in actual:
    (ROOT / path).read_text(encoding='utf-8')
assert not git('remote', '-v')
assert not git('diff', '--name-only', '--', 'AGENTS.md', 'CLAUDE.md', 'docs/CONTRACT.md', '.agents/skills', 'tasks/*/task.md', 'tasks/*/task.json', 'tools')
log = (ROOT / 'target/task021-implement-final-full.log').read_text()
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
assert sum(int(a) for a, b, c in counts) == 203, counts
assert all(int(b) == int(c) == 0 for a, b, c in counts)
assert 'Ran 9 tests' in log and log.rstrip().endswith('OK')
subprocess.run(['cargo', 'fmt', '--check'], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
print('PASS: handoff UTF-8/schema, exact15 paths, protected scope, no remotes, 212 tests, format and whitespace')

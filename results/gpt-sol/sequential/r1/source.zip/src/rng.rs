//! Portable xoshiro256** randomness. All arithmetic is wrapping u64 arithmetic.
//! Simulation owns one generator; observations must never consume its stream.
use crate::config::Seed;
use std::{error::Error, fmt};

/// Exact algorithm/version and s0..s3 word order, not a disk checkpoint format.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct RngState {
    pub version: u32,
    pub words: [u64; 4],
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RngError {
    UnsupportedVersion(u32),
    ZeroState,
    ZeroBound,
    InvalidRatio { numerator: u64, denominator: u64 },
}
impl fmt::Display for RngError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnsupportedVersion(v) => write!(f, "unsupported RNG state version {v}"),
            Self::ZeroState => f.write_str("RNG state must not be all zero"),
            Self::ZeroBound => f.write_str("RNG bound must be positive"),
            Self::InvalidRatio {
                numerator,
                denominator,
            } => write!(f, "invalid probability {numerator}/{denominator}"),
        }
    }
}
impl Error for RngError {}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Rng {
    words: [u64; 4],
}
impl Rng {
    /// Signed seeds are reduced modulo 2^64, then expanded using SplitMix64.
    pub fn from_seed(seed: &Seed) -> Self {
        let mut state = seed.wrapping_u64();
        let mut words = [0; 4];
        for word in &mut words {
            state = state.wrapping_add(0x9e3779b97f4a7c15);
            let mut z = state;
            z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
            *word = z ^ (z >> 31);
        }
        if words == [0; 4] {
            words[0] = 1;
        }
        Self { words }
    }
    pub fn state(&self) -> RngState {
        RngState {
            version: 1,
            words: self.words,
        }
    }
    /// Reject invalid records without repairing or reseeding them.
    pub fn from_state(state: RngState) -> Result<Self, RngError> {
        if state.version != 1 {
            return Err(RngError::UnsupportedVersion(state.version));
        }
        if state.words == [0; 4] {
            return Err(RngError::ZeroState);
        }
        Ok(Self { words: state.words })
    }
    pub fn next_u64(&mut self) -> u64 {
        let s = &mut self.words;
        let result = s[1].wrapping_mul(5).rotate_left(7).wrapping_mul(9);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        result
    }
    /// Uniform [0,bound). Zero errors without a draw; one consumes one draw.
    pub fn below(&mut self, bound: u64) -> Result<u64, RngError> {
        if bound == 0 {
            return Err(RngError::ZeroBound);
        }
        let threshold = bound.wrapping_neg() % bound;
        loop {
            let draw = self.next_u64();
            if draw >= threshold {
                return Ok(draw % bound);
            }
        }
    }
    /// Exact rational probability. Errors and deterministic endpoints draw nothing.
    pub fn chance(&mut self, numerator: u64, denominator: u64) -> Result<bool, RngError> {
        if denominator == 0 || numerator > denominator {
            return Err(RngError::InvalidRatio {
                numerator,
                denominator,
            });
        }
        if numerator == 0 {
            return Ok(false);
        }
        if numerator == denominator {
            return Ok(true);
        }
        Ok(self.below(denominator)? < numerator)
    }
}

impl RngState {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.u32(self.version)?;
        for word in self.words {
            w.u64(word)?;
        }
        Ok(())
    }
}
#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn version_and_every_rng_word_are_encoded() {
        let base = RngState {
            version: 1,
            words: [1, 2, 3, 4],
        };
        let bytes = collect(|w| base.write_canonical(w));
        assert_eq!(bytes.len(), 36);
        let mut v = base;
        v.version += 1;
        assert_ne!(bytes, collect(|w| v.write_canonical(w)));
        for i in 0..4 {
            let mut v = base;
            v.words[i] ^= 1;
            assert_ne!(bytes, collect(|w| v.write_canonical(w)));
        }
    }
}

impl Rng {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        let version = r.u32()?;
        let mut words = [0; 4];
        for w in &mut words {
            *w = r.u64()?;
        }
        Self::from_state(RngState { version, words }).map_err(crate::canonical::invalid)
    }
}

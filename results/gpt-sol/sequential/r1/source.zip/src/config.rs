//! Validated configuration schema v1. No engine state or process dependencies.
use serde_json::{Map, Number, Value, json};
use std::{fmt, path::Path};

// Defaults are centralized; presets override only their experimental differences.
mod defaults {
    pub const CLIMATE_YEAR_TICKS: u64 = 1000;
    pub const CLIMATE_SEASON_TEMPERATURE_AMPLITUDE: f64 = 0.15;
    pub const CLIMATE_SEASON_PRECIPITATION_AMPLITUDE: f64 = 0.1;
    pub const CLIMATE_WEATHER_AMPLITUDE: f64 = 0.05;
    pub const GENETICS_MUTATION_PER_MILLION: u32 = 10000;
    pub const GENETICS_MUTATION_MAX_STEP: u16 = 1024;
    pub const PLANTS_RESOURCE_CAPACITY: f64 = 100.0;
    pub const PLANTS_RESOURCE_REGENERATION: f64 = 2.0;
    pub const PLANTS_GROWTH_EFFICIENCY: f64 = 0.5;
    pub const PLANTS_REPRODUCTION_ENERGY: f64 = 20.0;
    pub const PLANTS_DISPERSAL_RADIUS: u32 = 3;
    pub const ANIMALS_MOVEMENT_COST: f64 = 0.2;
    pub const ANIMALS_BASAL_COST: f64 = 0.1;
    pub const ANIMALS_REPRODUCTION_ENERGY: f64 = 30.0;
    pub const ANIMALS_REPRODUCTION_COOLDOWN: u64 = 100;
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ConfigError {
    path: String,
    message: String,
}
impl ConfigError {
    fn new(path: impl Into<String>, message: impl Into<String>) -> Self {
        Self {
            path: path.into(),
            message: message.into(),
        }
    }
    pub fn path(&self) -> &str {
        &self.path
    }
    pub fn message(&self) -> &str {
        &self.message
    }
}
impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.path, self.message)
    }
}
impl std::error::Error for ConfigError {}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Seed(String);
impl Seed {
    pub fn from_i64(value: i64) -> Self {
        Self(value.to_string())
    }
    pub fn from_u64(value: u64) -> Self {
        Self(value.to_string())
    }
    pub fn as_decimal(&self) -> &str {
        &self.0
    }
    pub fn wrapping_u64(&self) -> u64 {
        let n = self.0.trim_start_matches('-').bytes().fold(0u64, |n, b| {
            n.wrapping_mul(10).wrapping_add((b - b'0') as u64)
        });
        if self.0.starts_with('-') {
            n.wrapping_neg()
        } else {
            n
        }
    }
    pub fn from_decimal(token: &str) -> Result<Self, ConfigError> {
        let digits = token.strip_prefix('-').unwrap_or(token);
        if digits.is_empty() || !digits.bytes().all(|b| b.is_ascii_digit()) {
            return Err(ConfigError::new("seed", "expected decimal integer"));
        }
        let digits = digits.trim_start_matches('0');
        Ok(Self(if digits.is_empty() {
            "0".into()
        } else if token.starts_with('-') {
            format!("-{digits}")
        } else {
            digits.into()
        }))
    }
    fn parse(v: &Value) -> Result<Self, ConfigError> {
        let token = integer(v, "seed")?;
        Self::from_decimal(&token)
    }
}
fn integer(v: &Value, path: &str) -> Result<String, ConfigError> {
    let token = v
        .as_number()
        .map(ToString::to_string)
        .ok_or_else(|| ConfigError::new(path, "expected integer"))?;
    let digits = token.strip_prefix('-').unwrap_or(&token);
    if digits.is_empty() || !digits.bytes().all(|b| b.is_ascii_digit()) {
        return Err(ConfigError::new(path, "expected integer token"));
    }
    Ok(token)
}
fn unsigned(v: &Value, path: &str, min: u64, max: u64) -> Result<u64, ConfigError> {
    let n = integer(v, path)?
        .parse::<u64>()
        .map_err(|_| ConfigError::new(path, "integer out of range"))?;
    if n < min || n > max {
        return Err(ConfigError::new(path, format!("expected {min}..={max}")));
    }
    Ok(n)
}
fn real(v: &Value, path: &str, min: f64, max: f64, positive: bool) -> Result<f64, ConfigError> {
    let n = v
        .as_number()
        .and_then(Number::as_f64)
        .ok_or_else(|| ConfigError::new(path, "expected finite number"))?;
    if !n.is_finite() || n < min || n > max || (positive && n == 0.) {
        return Err(ConfigError::new(path, "number out of range"));
    }
    Ok(n)
}
fn object<'a>(
    v: &'a Value,
    path: &str,
    keys: &[&str],
) -> Result<&'a Map<String, Value>, ConfigError> {
    let o = v
        .as_object()
        .ok_or_else(|| ConfigError::new(path, "expected object"))?;
    for key in o.keys() {
        if !keys.contains(&key.as_str()) {
            return Err(ConfigError::new(
                if path == "$" {
                    key.clone()
                } else {
                    format!("{path}.{key}")
                },
                "unknown key",
            ));
        }
    }
    Ok(o)
}
fn required<'a>(
    o: &'a Map<String, Value>,
    key: &str,
    path: &str,
) -> Result<&'a Value, ConfigError> {
    o.get(key)
        .ok_or_else(|| ConfigError::new(path, "missing required key"))
}

#[derive(Clone, Debug, PartialEq)]
pub struct WorldConfig {
    width: usize,
    height: usize,
}
impl WorldConfig {
    pub fn width(&self) -> usize {
        self.width
    }
    pub fn height(&self) -> usize {
        self.height
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct InitialConfig {
    plants: usize,
    herbivores: usize,
    carnivores: usize,
}
impl InitialConfig {
    pub fn plants(&self) -> usize {
        self.plants
    }
    pub fn herbivores(&self) -> usize {
        self.herbivores
    }
    pub fn carnivores(&self) -> usize {
        self.carnivores
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct ClimateConfig {
    year_ticks: u64,
    season_temperature_amplitude: f64,
    season_precipitation_amplitude: f64,
    weather_amplitude: f64,
}
impl ClimateConfig {
    pub fn year_ticks(&self) -> u64 {
        self.year_ticks
    }
    pub fn season_temperature_amplitude(&self) -> f64 {
        self.season_temperature_amplitude
    }
    pub fn season_precipitation_amplitude(&self) -> f64 {
        self.season_precipitation_amplitude
    }
    pub fn weather_amplitude(&self) -> f64 {
        self.weather_amplitude
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct GeneticsConfig {
    mutation_per_million: u32,
    mutation_max_step: u16,
}
impl GeneticsConfig {
    pub fn mutation_per_million(&self) -> u32 {
        self.mutation_per_million
    }
    pub fn mutation_max_step(&self) -> u16 {
        self.mutation_max_step
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct PlantConfig {
    resource_capacity: f64,
    resource_regeneration: f64,
    growth_efficiency: f64,
    reproduction_energy: f64,
    dispersal_radius: u32,
}
impl PlantConfig {
    pub fn resource_capacity(&self) -> f64 {
        self.resource_capacity
    }
    pub fn resource_regeneration(&self) -> f64 {
        self.resource_regeneration
    }
    pub fn growth_efficiency(&self) -> f64 {
        self.growth_efficiency
    }
    pub fn reproduction_energy(&self) -> f64 {
        self.reproduction_energy
    }
    pub fn dispersal_radius(&self) -> u32 {
        self.dispersal_radius
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct AnimalConfig {
    movement_cost: f64,
    basal_cost: f64,
    reproduction_energy: f64,
    reproduction_cooldown: u64,
}
impl AnimalConfig {
    pub fn movement_cost(&self) -> f64 {
        self.movement_cost
    }
    pub fn basal_cost(&self) -> f64 {
        self.basal_cost
    }
    pub fn reproduction_energy(&self) -> f64 {
        self.reproduction_energy
    }
    pub fn reproduction_cooldown(&self) -> u64 {
        self.reproduction_cooldown
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Config {
    seed: Seed,
    world: WorldConfig,
    initial: InitialConfig,
    climate: ClimateConfig,
    genetics: GeneticsConfig,
    plants: PlantConfig,
    animals: AnimalConfig,
}
impl Config {
    pub fn with_seed(&self, seed: Seed) -> Self {
        let mut config = self.clone();
        config.seed = seed;
        config
    }
    pub fn seed(&self) -> &Seed {
        &self.seed
    }
    pub fn world(&self) -> &WorldConfig {
        &self.world
    }
    pub fn initial(&self) -> &InitialConfig {
        &self.initial
    }
    pub fn climate(&self) -> &ClimateConfig {
        &self.climate
    }
    pub fn genetics(&self) -> &GeneticsConfig {
        &self.genetics
    }
    pub fn plants(&self) -> &PlantConfig {
        &self.plants
    }
    pub fn animals(&self) -> &AnimalConfig {
        &self.animals
    }
    pub fn from_json(input: &str) -> Result<Self, ConfigError> {
        let v: Value =
            serde_json::from_str(input).map_err(|e| ConfigError::new("$", e.to_string()))?;
        Self::from_value(&v)
    }
    fn from_value(v: &Value) -> Result<Self, ConfigError> {
        let root = object(
            v,
            "$",
            &[
                "seed", "world", "initial", "climate", "genetics", "plants", "animals",
            ],
        )?;
        let seed = Seed::parse(required(root, "seed", "seed")?)?;
        let empty = json!({});
        let world = object(
            required(root, "world", "world")?,
            "world",
            &["width", "height"],
        )?;
        let world = WorldConfig {
            width: unsigned(
                required(world, "width", "world.width")?,
                "world.width",
                1,
                usize::MAX as u64,
            )? as usize,
            height: unsigned(
                required(world, "height", "world.height")?,
                "world.height",
                1,
                usize::MAX as u64,
            )? as usize,
        };
        let initial = object(
            required(root, "initial", "initial")?,
            "initial",
            &["plants", "herbivores", "carnivores"],
        )?;
        let initial = InitialConfig {
            plants: unsigned(
                required(initial, "plants", "initial.plants")?,
                "initial.plants",
                0,
                usize::MAX as u64,
            )? as usize,
            herbivores: unsigned(
                required(initial, "herbivores", "initial.herbivores")?,
                "initial.herbivores",
                0,
                usize::MAX as u64,
            )? as usize,
            carnivores: unsigned(
                required(initial, "carnivores", "initial.carnivores")?,
                "initial.carnivores",
                0,
                usize::MAX as u64,
            )? as usize,
        };
        let climate = object(
            root.get("climate").unwrap_or(&empty),
            "climate",
            &[
                "year_ticks",
                "season_temperature_amplitude",
                "season_precipitation_amplitude",
                "weather_amplitude",
            ],
        )?;
        let climate = ClimateConfig {
            year_ticks: unsigned(
                climate
                    .get("year_ticks")
                    .unwrap_or(&json!(defaults::CLIMATE_YEAR_TICKS)),
                "climate.year_ticks",
                1,
                u64::MAX,
            )?,
            season_temperature_amplitude: real(
                climate
                    .get("season_temperature_amplitude")
                    .unwrap_or(&json!(defaults::CLIMATE_SEASON_TEMPERATURE_AMPLITUDE)),
                "climate.season_temperature_amplitude",
                0.,
                1.0,
                false,
            )?,
            season_precipitation_amplitude: real(
                climate
                    .get("season_precipitation_amplitude")
                    .unwrap_or(&json!(defaults::CLIMATE_SEASON_PRECIPITATION_AMPLITUDE)),
                "climate.season_precipitation_amplitude",
                0.,
                1.0,
                false,
            )?,
            weather_amplitude: real(
                climate
                    .get("weather_amplitude")
                    .unwrap_or(&json!(defaults::CLIMATE_WEATHER_AMPLITUDE)),
                "climate.weather_amplitude",
                0.,
                1.0,
                false,
            )?,
        };
        let genetics = object(
            root.get("genetics").unwrap_or(&empty),
            "genetics",
            &["mutation_per_million", "mutation_max_step"],
        )?;
        let genetics = GeneticsConfig {
            mutation_per_million: unsigned(
                genetics
                    .get("mutation_per_million")
                    .unwrap_or(&json!(defaults::GENETICS_MUTATION_PER_MILLION)),
                "genetics.mutation_per_million",
                0,
                1_000_000,
            )? as u32,
            mutation_max_step: unsigned(
                genetics
                    .get("mutation_max_step")
                    .unwrap_or(&json!(defaults::GENETICS_MUTATION_MAX_STEP)),
                "genetics.mutation_max_step",
                1,
                65_535,
            )? as u16,
        };
        let plants = object(
            root.get("plants").unwrap_or(&empty),
            "plants",
            &[
                "resource_capacity",
                "resource_regeneration",
                "growth_efficiency",
                "reproduction_energy",
                "dispersal_radius",
            ],
        )?;
        let plants = PlantConfig {
            resource_capacity: real(
                plants
                    .get("resource_capacity")
                    .unwrap_or(&json!(defaults::PLANTS_RESOURCE_CAPACITY)),
                "plants.resource_capacity",
                0.,
                1000000.0,
                true,
            )?,
            resource_regeneration: real(
                plants
                    .get("resource_regeneration")
                    .unwrap_or(&json!(defaults::PLANTS_RESOURCE_REGENERATION)),
                "plants.resource_regeneration",
                0.,
                1000000.0,
                false,
            )?,
            growth_efficiency: real(
                plants
                    .get("growth_efficiency")
                    .unwrap_or(&json!(defaults::PLANTS_GROWTH_EFFICIENCY)),
                "plants.growth_efficiency",
                0.,
                1.0,
                false,
            )?,
            reproduction_energy: real(
                plants
                    .get("reproduction_energy")
                    .unwrap_or(&json!(defaults::PLANTS_REPRODUCTION_ENERGY)),
                "plants.reproduction_energy",
                0.,
                1000000.0,
                true,
            )?,
            dispersal_radius: unsigned(
                plants
                    .get("dispersal_radius")
                    .unwrap_or(&json!(defaults::PLANTS_DISPERSAL_RADIUS)),
                "plants.dispersal_radius",
                0,
                u32::MAX as u64,
            )? as u32,
        };
        let animals = object(
            root.get("animals").unwrap_or(&empty),
            "animals",
            &[
                "movement_cost",
                "basal_cost",
                "reproduction_energy",
                "reproduction_cooldown",
            ],
        )?;
        let animals = AnimalConfig {
            movement_cost: real(
                animals
                    .get("movement_cost")
                    .unwrap_or(&json!(defaults::ANIMALS_MOVEMENT_COST)),
                "animals.movement_cost",
                0.,
                1000000.0,
                false,
            )?,
            basal_cost: real(
                animals
                    .get("basal_cost")
                    .unwrap_or(&json!(defaults::ANIMALS_BASAL_COST)),
                "animals.basal_cost",
                0.,
                1000000.0,
                true,
            )?,
            reproduction_energy: real(
                animals
                    .get("reproduction_energy")
                    .unwrap_or(&json!(defaults::ANIMALS_REPRODUCTION_ENERGY)),
                "animals.reproduction_energy",
                0.,
                1000000.0,
                true,
            )?,
            reproduction_cooldown: unsigned(
                animals
                    .get("reproduction_cooldown")
                    .unwrap_or(&json!(defaults::ANIMALS_REPRODUCTION_COOLDOWN)),
                "animals.reproduction_cooldown",
                1,
                u64::MAX,
            )?,
        };
        world
            .width
            .checked_mul(world.height)
            .ok_or_else(|| ConfigError::new("world.width/world.height", "area overflow"))?;
        let total = initial
            .plants
            .checked_add(initial.herbivores)
            .and_then(|n| n.checked_add(initial.carnivores))
            .ok_or_else(|| ConfigError::new("initial", "total population overflow"))?;
        if total as u128 >= u64::MAX as u128 {
            return Err(ConfigError::new("initial", "must reserve next organism ID"));
        }
        Ok(Self {
            seed,
            world,
            initial,
            climate,
            genetics,
            plants,
            animals,
        })
    }
    fn value(&self) -> Value {
        json!({"seed":self.seed.0.parse::<Number>().expect("validated seed"),
        "world": {"width":self.world.width,"height":self.world.height},
        "initial": {"plants":self.initial.plants,"herbivores":self.initial.herbivores,"carnivores":self.initial.carnivores},
        "climate": {"year_ticks":self.climate.year_ticks,"season_temperature_amplitude":self.climate.season_temperature_amplitude,"season_precipitation_amplitude":self.climate.season_precipitation_amplitude,"weather_amplitude":self.climate.weather_amplitude},
        "genetics": {"mutation_per_million":self.genetics.mutation_per_million,"mutation_max_step":self.genetics.mutation_max_step},
        "plants": {"resource_capacity":self.plants.resource_capacity,"resource_regeneration":self.plants.resource_regeneration,"growth_efficiency":self.plants.growth_efficiency,"reproduction_energy":self.plants.reproduction_energy,"dispersal_radius":self.plants.dispersal_radius},
        "animals": {"movement_cost":self.animals.movement_cost,"basal_cost":self.animals.basal_cost,"reproduction_energy":self.animals.reproduction_energy,"reproduction_cooldown":self.animals.reproduction_cooldown},
        })
    }
    pub fn to_json(&self) -> Result<String, ConfigError> {
        let v = self.value();
        Self::from_value(&v)?;
        serde_json::to_string_pretty(&v).map_err(|e| ConfigError::new("$", e.to_string()))
    }
    pub fn load(path: impl AsRef<Path>) -> Result<Self, ConfigError> {
        let path = path.as_ref();
        let input = std::fs::read_to_string(path)
            .map_err(|e| ConfigError::new(path.display().to_string(), e.to_string()))?;
        Self::from_json(&input)
    }
    pub fn save(&self, path: impl AsRef<Path>) -> Result<(), ConfigError> {
        let output = self.to_json()?;
        let path = path.as_ref();
        std::fs::write(path, output)
            .map_err(|e| ConfigError::new(path.display().to_string(), e.to_string()))
    }
    pub fn preset_names() -> &'static [&'static str] {
        &["baseline", "seasonal", "plant-only"]
    }
    pub fn preset(name: &str) -> Result<Self, ConfigError> {
        let mut v = json!({"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}});
        match name {
            "baseline" => {}
            "seasonal" => {
                v["climate"] = json!({"year_ticks":240,"season_temperature_amplitude":0.3,"weather_amplitude":0.1});
            }
            "plant-only" => {
                v["world"] = json!({"width":32,"height":24});
                v["initial"] = json!({"plants":200,"herbivores":0,"carnivores":0});
                v["genetics"] = json!({"mutation_per_million":50000});
                v["plants"] = json!({"dispersal_radius":5});
            }
            _ => {
                return Err(ConfigError::new(
                    "preset",
                    "expected baseline, seasonal or plant-only",
                ));
            }
        }
        Self::from_value(&v)
    }
}
impl Default for Config {
    fn default() -> Self {
        Self::preset("baseline").expect("valid built-in baseline")
    }
}

impl Config {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.string(self.seed.as_decimal())?;
        w.usize(self.world.width)?;
        w.usize(self.world.height)?;
        for n in [
            self.initial.plants,
            self.initial.herbivores,
            self.initial.carnivores,
        ] {
            w.usize(n)?;
        }
        self.climate.write_canonical(w)?;
        w.u32(self.genetics.mutation_per_million)?;
        w.u16(self.genetics.mutation_max_step)?;
        for n in [
            self.plants.resource_capacity,
            self.plants.resource_regeneration,
            self.plants.growth_efficiency,
            self.plants.reproduction_energy,
        ] {
            w.f64(n)?;
        }
        w.u32(self.plants.dispersal_radius)?;
        for n in [
            self.animals.movement_cost,
            self.animals.basal_cost,
            self.animals.reproduction_energy,
        ] {
            w.f64(n)?;
        }
        w.u64(self.animals.reproduction_cooldown)
    }
}
impl ClimateConfig {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.u64(self.year_ticks)?;
        for n in [
            self.season_temperature_amplitude,
            self.season_precipitation_amplitude,
            self.weather_amplitude,
        ] {
            w.f64(n)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let base = Config::default();
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut Config| {
            v.seed = Seed::from_i64(-1);
        });
        changed!(|v: &mut Config| {
            v.world.width += 1;
        });
        changed!(|v: &mut Config| {
            v.world.height += 1;
        });
        changed!(|v: &mut Config| {
            v.initial.plants += 1;
        });
        changed!(|v: &mut Config| {
            v.initial.herbivores += 1;
        });
        changed!(|v: &mut Config| {
            v.initial.carnivores += 1;
        });
        changed!(|v: &mut Config| {
            v.climate.year_ticks += 1;
        });
        changed!(|v: &mut Config| {
            v.climate.season_temperature_amplitude += 0.001;
        });
        changed!(|v: &mut Config| {
            v.climate.season_precipitation_amplitude += 0.001;
        });
        changed!(|v: &mut Config| {
            v.climate.weather_amplitude += 0.001;
        });
        changed!(|v: &mut Config| {
            v.genetics.mutation_per_million += 1;
        });
        changed!(|v: &mut Config| {
            v.genetics.mutation_max_step += 1;
        });
        changed!(|v: &mut Config| {
            v.plants.resource_capacity += 0.001;
        });
        changed!(|v: &mut Config| {
            v.plants.resource_regeneration += 0.001;
        });
        changed!(|v: &mut Config| {
            v.plants.growth_efficiency += 0.001;
        });
        changed!(|v: &mut Config| {
            v.plants.reproduction_energy += 0.001;
        });
        changed!(|v: &mut Config| {
            v.plants.dispersal_radius += 1;
        });
        changed!(|v: &mut Config| {
            v.animals.movement_cost += 0.001;
        });
        changed!(|v: &mut Config| {
            v.animals.basal_cost += 0.001;
        });
        changed!(|v: &mut Config| {
            v.animals.reproduction_energy += 0.001;
        });
        changed!(|v: &mut Config| {
            v.animals.reproduction_cooldown += 1;
        });
    }
}

impl ClimateConfig {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        Ok(Self {
            year_ticks: r.u64()?,
            season_temperature_amplitude: r.f64()?,
            season_precipitation_amplitude: r.f64()?,
            weather_amplitude: r.f64()?,
        })
    }
}
impl Config {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        let value = Self {
            seed: Seed::from_decimal(&r.string()?).map_err(crate::canonical::invalid)?,
            world: WorldConfig {
                width: r.usize()?,
                height: r.usize()?,
            },
            initial: InitialConfig {
                plants: r.usize()?,
                herbivores: r.usize()?,
                carnivores: r.usize()?,
            },
            climate: ClimateConfig::read_canonical(r)?,
            genetics: GeneticsConfig {
                mutation_per_million: r.u32()?,
                mutation_max_step: r.u16()?,
            },
            plants: PlantConfig {
                resource_capacity: r.f64()?,
                resource_regeneration: r.f64()?,
                growth_efficiency: r.f64()?,
                reproduction_energy: r.f64()?,
                dispersal_radius: r.u32()?,
            },
            animals: AnimalConfig {
                movement_cost: r.f64()?,
                basal_cost: r.f64()?,
                reproduction_energy: r.f64()?,
                reproduction_cooldown: r.u64()?,
            },
        };
        // Validate through the existing effective-config validator, keeping original bits.
        value.to_json().map_err(crate::canonical::invalid)?;
        Ok(value)
    }
}

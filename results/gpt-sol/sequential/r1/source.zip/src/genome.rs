//! Schema-v1 haploid DNA (ADR-004). Pure phenotype and distance queries draw nothing.
use crate::{
    config::GeneticsConfig,
    rng::Rng,
    traits::{TraitValues, Traits},
};

pub const GENOME_VERSION: u32 = 1;
pub const LOCUS_COUNT: usize = 12;
pub const LOCUS_NAMES: [&str; LOCUS_COUNT] = [
    "speed",
    "strength",
    "max_health",
    "lifespan",
    "fertility",
    "vision",
    "metabolic_multiplier",
    "preferred_temperature",
    "preferred_moisture",
    "climate_tolerance",
    "aggression",
    "risk_tolerance",
];
pub const MAX_DISTANCE_SUM: u32 = LOCUS_COUNT as u32 * u16::MAX as u32;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Genome([u16; LOCUS_COUNT]);
impl Genome {
    pub const fn from_alleles(alleles: [u16; LOCUS_COUNT]) -> Self {
        Self(alleles)
    }
    pub fn alleles(&self) -> &[u16; LOCUS_COUNT] {
        &self.0
    }
    /// Uniform provisional founders; initialization consumes no RNG.
    pub const fn founder() -> Self {
        Self([32768; LOCUS_COUNT])
    }
    /// Linear continuous mapping with exact endpoints; discrete traits floor the
    /// scaled integer span. There is no independently mutable phenotype cache.
    pub fn traits(&self) -> Traits {
        let a = self.0;
        let continuous = |i: usize, low: f64, high: f64| match a[i] {
            0 => low,
            u16::MAX => high,
            n => low + (high - low) * (f64::from(n) / 65535.0),
        };
        let discrete = |i: usize, low: u32, span: u32| low + u32::from(a[i]) * span / 65535;
        Traits::new(TraitValues {
            speed: discrete(0, 1, 3) as u8,
            strength: continuous(1, 1., 10.),
            max_health: continuous(2, 10., 100.),
            lifespan: u64::from(discrete(3, 200, 1800)),
            fertility: continuous(4, 0., 1.),
            vision: discrete(5, 1, 7) as u8,
            metabolic_multiplier: continuous(6, 0.5, 2.),
            preferred_temperature: continuous(7, 0., 1.),
            preferred_moisture: continuous(8, 0., 1.),
            climate_tolerance: continuous(9, 0.05, 0.5),
            aggression: continuous(10, 0., 1.),
            risk_tolerance: continuous(11, 0., 1.),
        })
        .expect("schema-v1 mapping preserves validated trait bounds")
    }
    pub fn copy_child(&self, settings: &GeneticsConfig, rng: &mut Rng) -> Self {
        self.mutated(settings, rng)
    }
    /// Draw boundary (1..12), then orientation (0 takes self prefix), then
    /// mutate in locus order. Both parental segments are nonempty.
    pub fn crossover_child(&self, other: &Self, settings: &GeneticsConfig, rng: &mut Rng) -> Self {
        let boundary = 1 + rng.below(11).unwrap() as usize;
        let reverse = rng.below(2).unwrap() == 1;
        let mut alleles = self.0;
        for (i, allele) in alleles.iter_mut().enumerate() {
            *allele = if (i < boundary) != reverse {
                self.0[i]
            } else {
                other.0[i]
            };
        }
        Self(alleles).mutated(settings, rng)
    }
    /// Independent per-locus rational chance followed by a uniform nonzero
    /// signed step. Clamp at allele boundaries; selected loci may stay unchanged.
    /// Rate zero draws nothing; rate one draws only steps (Rng::chance semantics).
    pub fn mutated(&self, settings: &GeneticsConfig, rng: &mut Rng) -> Self {
        let mut alleles = self.0;
        let m = i32::from(settings.mutation_max_step());
        for allele in &mut alleles {
            if rng
                .chance(u64::from(settings.mutation_per_million()), 1_000_000)
                .unwrap()
            {
                let z = rng.below((2 * m) as u64).unwrap() as i32;
                let step = if z < m { z - m } else { z - m + 1 };
                *allele = (i32::from(*allele) + step).clamp(0, 65535) as u16;
            }
        }
        Self(alleles)
    }
    /// Exact L1 allele distance for future rational threshold comparisons.
    pub fn distance_sum(&self, other: &Self) -> u32 {
        self.0
            .iter()
            .zip(other.0)
            .map(|(&a, b)| u32::from(a.abs_diff(b)))
            .sum()
    }
    pub fn distance(&self, other: &Self) -> f64 {
        f64::from(self.distance_sum(other)) / f64::from(MAX_DISTANCE_SUM)
    }
}

impl Genome {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        for allele in self.alleles() {
            w.u16(*allele)?;
        }
        Ok(())
    }
}

impl Genome {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        let mut alleles = [0; LOCUS_COUNT];
        for a in &mut alleles {
            *a = r.u16()?;
        }
        Ok(Self(alleles))
    }
}

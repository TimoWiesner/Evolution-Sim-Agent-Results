//! Explicit schema-1 primitives. No native-width or formatting-based encoding.
use std::io::{self, Write};
pub(crate) const STATE_SCHEMA: u32 = 1;
pub(crate) struct Encoder<W: Write>(pub W);
impl<W: Write> Encoder<W> {
    pub fn bytes(&mut self, value: &[u8]) -> io::Result<()> {
        self.0.write_all(value)
    }
    pub fn u8(&mut self, value: u8) -> io::Result<()> {
        self.bytes(&[value])
    }
    pub fn u16(&mut self, value: u16) -> io::Result<()> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn u32(&mut self, value: u32) -> io::Result<()> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn u64(&mut self, value: u64) -> io::Result<()> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn u128(&mut self, value: u128) -> io::Result<()> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn usize(&mut self, value: usize) -> io::Result<()> {
        self.u64(
            value
                .try_into()
                .map_err(|_| io::Error::other("canonical length exceeds u64"))?,
        )
    }
    pub fn f64(&mut self, value: f64) -> io::Result<()> {
        self.u64(value.to_bits())
    }
    pub fn string(&mut self, value: &str) -> io::Result<()> {
        self.usize(value.len())?;
        self.bytes(value.as_bytes())
    }
    pub fn option(&mut self, value: Option<u64>) -> io::Result<()> {
        match value {
            None => self.u8(0),
            Some(value) => {
                self.u8(1)?;
                self.u64(value)
            }
        }
    }
}

#[cfg(test)]
pub(crate) fn collect(f: impl FnOnce(&mut Encoder<Vec<u8>>) -> io::Result<()>) -> Vec<u8> {
    let mut encoder = Encoder(Vec::new());
    f(&mut encoder).unwrap();
    encoder.0
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_widths_endianness_lengths_options_and_float_bits() {
        let bytes = collect(|w| {
            w.u8(255)?;
            w.u16(0x1234)?;
            w.u32(0x12345678)?;
            w.u64(0x0123456789abcdef)?;
            w.u128(u128::MAX)?;
            w.string("é")?;
            w.option(None)?;
            w.option(Some(0))?;
            w.f64(-0.0)
        });
        let mut expected = vec![
            255, 0x34, 0x12, 0x78, 0x56, 0x34, 0x12, 0xef, 0xcd, 0xab, 0x89, 0x67, 0x45, 0x23, 0x01,
        ];
        expected.extend([255; 16]);
        expected.extend(2u64.to_le_bytes());
        expected.extend("é".as_bytes());
        expected.extend([0, 1]);
        expected.extend([0; 8]);
        expected.extend(0x8000000000000000u64.to_le_bytes());
        assert_eq!(bytes, expected);
        assert_ne!(collect(|w| w.string("a")), collect(|w| w.string("a\0")));
        struct Fail;
        impl Write for Fail {
            fn write(&mut self, _: &[u8]) -> io::Result<usize> {
                Err(io::Error::other("injected"))
            }
            fn flush(&mut self) -> io::Result<()> {
                Ok(())
            }
        }
        assert!(Encoder(Fail).u64(1).is_err());
    }
}

pub(crate) fn invalid(message: impl ToString) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message.to_string())
}
pub(crate) fn require(condition: bool, message: &str) -> io::Result<()> {
    if condition {
        Ok(())
    } else {
        Err(invalid(message))
    }
}
/// Bounded cursor: no length from disk can allocate beyond the remaining input.
pub(crate) struct Decoder<'a> {
    remaining: &'a [u8],
}
impl<'a> Decoder<'a> {
    pub fn new(bytes: &'a [u8]) -> Self {
        Self { remaining: bytes }
    }
    pub fn bytes(&mut self, n: usize) -> io::Result<&'a [u8]> {
        require(n <= self.remaining.len(), "truncated canonical state")?;
        let (a, b) = self.remaining.split_at(n);
        self.remaining = b;
        Ok(a)
    }
    pub fn finished(&self) -> bool {
        self.remaining.is_empty()
    }
    pub fn u8(&mut self) -> io::Result<u8> {
        Ok(self.bytes(1)?[0])
    }
    pub fn u16(&mut self) -> io::Result<u16> {
        Ok(u16::from_le_bytes(self.bytes(2)?.try_into().unwrap()))
    }
    pub fn u32(&mut self) -> io::Result<u32> {
        Ok(u32::from_le_bytes(self.bytes(4)?.try_into().unwrap()))
    }
    pub fn u64(&mut self) -> io::Result<u64> {
        Ok(u64::from_le_bytes(self.bytes(8)?.try_into().unwrap()))
    }
    pub fn u128(&mut self) -> io::Result<u128> {
        Ok(u128::from_le_bytes(self.bytes(16)?.try_into().unwrap()))
    }
    pub fn usize(&mut self) -> io::Result<usize> {
        self.u64()?.try_into().map_err(invalid)
    }
    pub fn count(&mut self, minimum: usize) -> io::Result<usize> {
        let n = self.usize()?;
        require(
            n <= self.remaining.len() / minimum,
            "record count exceeds remaining bytes",
        )?;
        Ok(n)
    }
    pub fn f64(&mut self) -> io::Result<f64> {
        Ok(f64::from_bits(self.u64()?))
    }
    pub fn string(&mut self) -> io::Result<String> {
        let n = self.count(1)?;
        String::from_utf8(self.bytes(n)?.to_vec()).map_err(invalid)
    }
    pub fn option(&mut self) -> io::Result<Option<u64>> {
        match self.u8()? {
            0 => Ok(None),
            1 => Ok(Some(self.u64()?)),
            _ => Err(invalid("invalid option tag")),
        }
    }
}

#[cfg(test)]
mod decoder_tests {
    use super::*;
    #[test]
    fn primitives_bounds_tags_and_utf8() {
        let bytes = collect(|w| {
            w.u8(9)?;
            w.u16(555)?;
            w.u32(90000)?;
            w.u64(u64::MAX)?;
            w.u128(u128::MAX)?;
            w.f64(-0.)?;
            w.string("é")?;
            w.option(None)?;
            w.option(Some(17))
        });
        let mut r = Decoder::new(&bytes);
        assert_eq!(r.u8().unwrap(), 9);
        assert_eq!(r.u16().unwrap(), 555);
        assert_eq!(r.u32().unwrap(), 90000);
        assert_eq!(r.u64().unwrap(), u64::MAX);
        assert_eq!(r.u128().unwrap(), u128::MAX);
        assert_eq!(r.f64().unwrap().to_bits(), (-0f64).to_bits());
        assert_eq!(r.string().unwrap(), "é");
        assert_eq!(r.option().unwrap(), None);
        assert_eq!(r.option().unwrap(), Some(17));
        assert!(r.finished());
        assert!(r.u8().is_err());
        assert!(Decoder::new(&[2]).option().is_err());
        assert!(Decoder::new(&[1]).option().is_err());
        assert!(Decoder::new(&u64::MAX.to_le_bytes()).string().is_err());
        let mut bad = 1u64.to_le_bytes().to_vec();
        bad.push(255);
        assert!(Decoder::new(&bad).string().is_err());
    }
}

//! Authoritative bounded environmental energy stores (ADR-008).
use crate::{
    config::PlantConfig,
    topology::{Cell, Topology},
};
use std::{error::Error, fmt};

pub const RESOURCE_MODEL_VERSION: u32 = 1;
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ResourceError;
impl fmt::Display for ResourceError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot allocate dense cell resources")
    }
}
impl Error for ResourceError {}
#[derive(Clone, Debug, PartialEq)]
pub struct ResourceField {
    topology: Topology,
    stores: Vec<f64>,
}
impl ResourceField {
    pub(crate) fn new(topology: Topology, settings: &PlantConfig) -> Result<Self, ResourceError> {
        topology
            .area()
            .checked_mul(std::mem::size_of::<f64>())
            .filter(|&bytes| bytes <= isize::MAX as usize)
            .ok_or(ResourceError)?;
        let mut stores = Vec::new();
        stores
            .try_reserve_exact(topology.area())
            .map_err(|_| ResourceError)?;
        stores.resize(topology.area(), settings.resource_capacity());
        Ok(Self { topology, stores })
    }
    fn address(&self, cell: Cell) -> usize {
        (cell.y() % self.topology.height()) * self.topology.width()
            + cell.x() % self.topology.width()
    }
    pub fn at(&self, cell: Cell) -> f64 {
        self.stores[self.address(cell)]
    }
    /// Precipitation is longitude-independent in the current climate model.
    /// Evaluate once per row without retaining a cache or changing cell arithmetic.
    pub(crate) fn regenerate_rows(
        &mut self,
        settings: &PlantConfig,
        mut precipitation: impl FnMut(usize) -> f64,
    ) {
        for y in 0..self.topology.height() {
            let rain = precipitation(y);
            for x in 0..self.topology.width() {
                let slot = y * self.topology.width() + x;
                let room = (settings.resource_capacity() - self.stores[slot]).max(0.);
                self.stores[slot] = (self.stores[slot]
                    + room.min(settings.resource_regeneration() * rain))
                .min(settings.resource_capacity());
            }
        }
    }
    pub(crate) fn take(&mut self, cell: Cell, demand: f64) -> f64 {
        assert!(demand.is_finite() && demand >= 0.);
        let slot = self.address(cell);
        let amount = self.stores[slot].min(demand);
        self.stores[slot] = (self.stores[slot] - amount).max(0.);
        amount
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Config;
    #[test]
    fn generated_budgets_caps_wrapping_and_extremes() {
        for (w, h) in [(1, 1), (1, 7), (9, 1), (3, 4)] {
            for cap in [1e-300, 0.3, 1e6] {
                for regen in [0., 1., 1e6] {
                    let c = Config::from_json(&format!(r#"{{"seed":0,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}},"plants":{{"resource_capacity":{cap},"resource_regeneration":{regen}}}}}"#)).unwrap();
                    let topology = Topology::new(w, h).unwrap();
                    let mut field = ResourceField::new(topology, c.plants()).unwrap();
                    let mut oracle = vec![cap; w * h];
                    let mut random = 123456789u64;
                    for _ in 0..128 {
                        random = random.wrapping_mul(6364136223846793005).wrapping_add(1);
                        let rain = (random % 1001) as f64 / 1000.;
                        field.regenerate_rows(c.plants(), |_| rain);
                        for y in 0..h {
                            for x in 0..w {
                                let i = y * w + x;
                                oracle[i] = (oracle[i] + regen * rain).min(cap);
                                let demand = ((random >> (i % 32)) % 9) as f64 / 3.;
                                let expected = demand.min(oracle[i]);
                                let actual =
                                    field.take(topology.cell(x as i128, y as i128), demand);
                                assert!((actual - expected).abs() <= 1e-9);
                                oracle[i] -= expected;
                                let value = field.at(topology.cell(x as i128, y as i128));
                                assert!(value.is_finite() && value >= 0. && value <= cap);
                                assert!((value - oracle[i]).abs() <= 1e-9);
                            }
                        }
                    }
                    let foreign = Topology::new(w + 5, h + 5)
                        .unwrap()
                        .cell((w + 2) as i128, (h + 2) as i128);
                    assert_eq!(field.at(foreign), field.at(topology.cell(2, 2)));
                    assert_eq!(field.take(topology.cell(0, 0), 0.), 0.);
                }
            }
        }
    }
    #[test]
    fn row_regeneration_matches_original_cell_bits() {
        use crate::{
            climate::Climate,
            temporal_climate::{TemporalClimate, WeatherState},
        };
        for (w, h) in [(1, 1), (1, 7), (9, 1), (3, 4), (128, 48)] {
            for (cap, regen) in [(1e-300, 1e6), (0.3, 0.), (100., 2.), (1e6, 1e6)] {
                for amplitude in [0., 0.05, 1.] {
                    let c = Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}},"plants":{{"resource_capacity":{cap},"resource_regeneration":{regen}}},"climate":{{"weather_amplitude":{amplitude}}}}}"#)).unwrap();
                    let t = Topology::new(w, h).unwrap();
                    let base = Climate::new(t);
                    let mut actual = ResourceField::new(t, c.plants()).unwrap();
                    for tick in [0, 1, 249, 500, 999, 1000, 12345, u64::MAX] {
                        let state =
                            WeatherState::new(1, tick, amplitude * 0.25, -amplitude * 0.5).unwrap();
                        let temporal =
                            TemporalClimate::from_state(c.climate().clone(), state).unwrap();
                        // Unequal depleted cells exercise both saturation and partial refill.
                        for (i, v) in actual.stores.iter_mut().enumerate() {
                            *v = cap * ((i % 11) as f64 / 11.);
                        }
                        let mut expected = actual.clone();
                        for y in 0..h {
                            let rain = temporal
                                .current_at(&base, t.cell(0, y as i128))
                                .precipitation();
                            for x in 0..w {
                                let cell = t.cell(x as i128, y as i128);
                                let cell_rain = temporal.current_at(&base, cell).precipitation();
                                assert_eq!(rain.to_bits(), cell_rain.to_bits());
                                let slot = y * w + x;
                                let room = (cap - expected.stores[slot]).max(0.);
                                expected.stores[slot] =
                                    (expected.stores[slot] + room.min(regen * cell_rain)).min(cap);
                            }
                        }
                        let mut calls = 0;
                        actual.regenerate_rows(c.plants(), |y| {
                            calls += 1;
                            temporal
                                .current_at(&base, t.cell(0, y as i128))
                                .precipitation()
                        });
                        assert_eq!(calls, h);
                        assert_eq!(
                            actual
                                .stores
                                .iter()
                                .map(|v| v.to_bits())
                                .collect::<Vec<_>>(),
                            expected
                                .stores
                                .iter()
                                .map(|v| v.to_bits())
                                .collect::<Vec<_>>()
                        );
                        assert_eq!(temporal.weather_state(), state);
                    }
                }
            }
        }
    }
    #[test]
    fn oversized_storage_fails_before_allocation() {
        let topology = Topology::new(isize::MAX as usize, 1).unwrap();
        assert_eq!(
            ResourceField::new(topology, Config::default().plants()),
            Err(ResourceError)
        );
    }
}

impl ResourceField {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        self.topology.write_canonical(w)?;
        w.usize(self.stores.len())?;
        for value in &self.stores {
            w.f64(*value)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let base = ResourceField::new(
            Topology::new(3, 2).unwrap(),
            crate::config::Config::default().plants(),
        )
        .unwrap();
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut ResourceField| {
            v.topology = Topology::new(2, 3).unwrap();
        });

        for index in 0..base.stores.len() {
            changed!(|v: &mut ResourceField| {
                v.stores[index] = f64::from_bits(v.stores[index].to_bits() + 1);
            });
        }
    }
}

impl ResourceField {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        expected: Topology,
        capacity: f64,
    ) -> std::io::Result<Self> {
        crate::canonical::require(
            Topology::read_canonical(r)? == expected,
            "resource topology mismatch",
        )?;
        let n = r.count(8)?;
        crate::canonical::require(n == expected.area(), "resource area mismatch")?;
        let mut stores = Vec::new();
        stores
            .try_reserve_exact(n)
            .map_err(crate::canonical::invalid)?;
        for _ in 0..n {
            let v = r.f64()?;
            crate::canonical::require(
                v.is_finite() && v >= 0. && v <= capacity,
                "invalid resource store",
            )?;
            stores.push(v);
        }
        Ok(Self {
            topology: expected,
            stores,
        })
    }
}

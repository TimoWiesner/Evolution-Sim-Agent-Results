//! Validated phenotype values shared by genomes and organism readers.
use std::{error::Error, fmt};

/// Named construction inputs; only validated Traits can enter an organism.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TraitValues {
    pub speed: u8,
    pub strength: f64,
    pub max_health: f64,
    pub lifespan: u64,
    pub fertility: f64,
    pub vision: u8,
    pub metabolic_multiplier: f64,
    pub preferred_temperature: f64,
    pub preferred_moisture: f64,
    pub climate_tolerance: f64,
    pub aggression: f64,
    pub risk_tolerance: f64,
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Traits(TraitValues);
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TraitError(pub &'static str);
impl fmt::Display for TraitError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "invalid trait: {}", self.0)
    }
}
impl Error for TraitError {}
macro_rules! trait_getters {
    ($($name:ident: $ty:ty),* $(,)?) => { $(pub fn $name(self) -> $ty { self.0.$name })* };
}
impl Traits {
    pub fn new(v: TraitValues) -> Result<Self, TraitError> {
        for (name, value, low, high) in [
            ("speed", v.speed as f64, 1., 4.),
            ("strength", v.strength, 1., 10.),
            ("max_health", v.max_health, 10., 100.),
            ("lifespan", v.lifespan as f64, 200., 2000.),
            ("fertility", v.fertility, 0., 1.),
            ("vision", v.vision as f64, 1., 8.),
            ("metabolic_multiplier", v.metabolic_multiplier, 0.5, 2.),
            ("preferred_temperature", v.preferred_temperature, 0., 1.),
            ("preferred_moisture", v.preferred_moisture, 0., 1.),
            ("climate_tolerance", v.climate_tolerance, 0.05, 0.5),
            ("aggression", v.aggression, 0., 1.),
            ("risk_tolerance", v.risk_tolerance, 0., 1.),
        ] {
            if !value.is_finite() || !(low..=high).contains(&value) {
                return Err(TraitError(name));
            }
        }
        Ok(Self(v))
    }
    pub fn founder() -> Self {
        Self::new(TraitValues {
            speed: 2,
            strength: 5.5,
            max_health: 55.,
            lifespan: 1100,
            fertility: 0.5,
            vision: 4,
            metabolic_multiplier: 1.25,
            preferred_temperature: 0.5,
            preferred_moisture: 0.5,
            climate_tolerance: 0.275,
            aggression: 0.5,
            risk_tolerance: 0.5,
        })
        .unwrap()
    }
    pub fn values(self) -> TraitValues {
        self.0
    }
    trait_getters!(speed: u8, strength: f64, max_health: f64, lifespan: u64,
        fertility: f64, vision: u8, metabolic_multiplier: f64,
        preferred_temperature: f64, preferred_moisture: f64, climate_tolerance: f64,
        aggression: f64, risk_tolerance: f64);
}

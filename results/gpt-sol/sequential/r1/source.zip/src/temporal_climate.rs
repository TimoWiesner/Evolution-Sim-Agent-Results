//! Periodic normalized seasons and engine-owned persistent weather (ADR-006).
use crate::{climate::Climate, config::ClimateConfig, rng::Rng, topology::Cell};
use std::{error::Error, fmt};

pub const TEMPORAL_CLIMATE_MODEL_VERSION: u32 = 1;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CurrentClimate {
    temperature: f64,
    precipitation: f64,
}
impl CurrentClimate {
    pub fn temperature(self) -> f64 {
        self.temperature
    }
    pub fn precipitation(self) -> f64 {
        self.precipitation
    }
}

/// Complete weather memory; settings and engine RNG must also be retained.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct WeatherState {
    version: u32,
    tick: u64,
    temperature_offset: f64,
    precipitation_offset: f64,
}
impl WeatherState {
    /// Validate model identity and absolute normalized offset bounds.
    pub fn new(
        version: u32,
        tick: u64,
        temperature_offset: f64,
        precipitation_offset: f64,
    ) -> Result<Self, WeatherError> {
        if version != TEMPORAL_CLIMATE_MODEL_VERSION {
            return Err(WeatherError::Version(version));
        }
        if [temperature_offset, precipitation_offset]
            .iter()
            .any(|v| !v.is_finite() || v.abs() > 1.)
        {
            return Err(WeatherError::Offset);
        }
        Ok(Self {
            version,
            tick,
            temperature_offset,
            precipitation_offset,
        })
    }
    pub fn version(self) -> u32 {
        self.version
    }
    pub fn tick(self) -> u64 {
        self.tick
    }
    pub fn temperature_offset(self) -> f64 {
        self.temperature_offset
    }
    pub fn precipitation_offset(self) -> f64 {
        self.precipitation_offset
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WeatherError {
    Version(u32),
    Offset,
}
impl fmt::Display for WeatherError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Version(v) => write!(f, "unsupported temporal climate version {v}"),
            Self::Offset => {
                f.write_str("weather offsets must be finite and within configured amplitude")
            }
        }
    }
}
impl Error for WeatherError {}

#[derive(Clone, Debug, PartialEq)]
pub struct TemporalClimate {
    settings: ClimateConfig,
    state: WeatherState,
}
impl TemporalClimate {
    /// Neutral weather at tick zero, without RNG consumption.
    pub fn new(settings: ClimateConfig) -> Self {
        Self {
            settings,
            state: WeatherState {
                version: TEMPORAL_CLIMATE_MODEL_VERSION,
                tick: 0,
                temperature_offset: 0.,
                precipitation_offset: 0.,
            },
        }
    }
    /// Restore exact offsets, rejecting incompatible settings without repair or draws.
    pub fn from_state(settings: ClimateConfig, state: WeatherState) -> Result<Self, WeatherError> {
        if state.version != TEMPORAL_CLIMATE_MODEL_VERSION {
            return Err(WeatherError::Version(state.version));
        }
        let amplitude = settings.weather_amplitude();
        if [state.temperature_offset, state.precipitation_offset]
            .iter()
            .any(|v| !v.is_finite() || v.abs() > amplitude)
        {
            return Err(WeatherError::Offset);
        }
        Ok(Self { settings, state })
    }
    pub fn settings(&self) -> &ClimateConfig {
        &self.settings
    }
    pub fn weather_state(&self) -> WeatherState {
        self.state
    }
    pub fn tick(&self) -> u64 {
        self.state.tick
    }

    /// Query the current completed tick. Historical weather requires replay.
    pub fn current_at(&self, base: &Climate, cell: Cell) -> CurrentClimate {
        let base = base.base_at(cell);
        let q = base.temperature();
        let phase = (self.state.tick % self.settings.year_ticks()) as f64
            / self.settings.year_ticks() as f64;
        let season = (std::f64::consts::TAU * phase).cos();
        CurrentClimate {
            temperature: (q
                + self.settings.season_temperature_amplitude() * (0.25 + 0.75 * (1. - q)) * season
                + self.state.temperature_offset)
                .clamp(0., 1.),
            precipitation: (base.precipitation()
                - self.settings.season_precipitation_amplitude() * (0.5 + 0.5 * q) * season
                + self.state.precipitation_offset)
                .clamp(0., 1.),
        }
    }
    /// Called once in ClimateResources, after the engine clock advances.
    pub(crate) fn advance_to(&mut self, tick: u64, rng: &mut Rng) {
        let amplitude = self.settings.weather_amplitude();
        if amplitude == 0. {
            self.state.temperature_offset = 0.;
            self.state.precipitation_offset = 0.;
        } else {
            for offset in [
                &mut self.state.temperature_offset,
                &mut self.state.precipitation_offset,
            ] {
                let u = (rng.next_u64() >> 11) as f64 / 9007199254740992.;
                let innovation = amplitude * (2. * u - 1.);
                *offset = (0.75 * *offset + 0.25 * innovation).clamp(-amplitude, amplitude);
            }
        }
        self.state.tick = tick;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::Config, topology::Topology};
    #[test]
    fn recurrence_draw_order_and_restored_continuation() {
        let config = Config::preset("baseline").unwrap();
        let mut temporal = TemporalClimate::new(config.climate().clone());
        let mut rng = Rng::from_seed(config.seed());
        let mut oracle_rng = rng.clone();
        let mut expected = [0., 0.];
        for tick in 1..=37 {
            for offset in &mut expected {
                let draw = oracle_rng.next_u64();
                let z = 0.05 * (2. * ((draw >> 11) as f64 / 9007199254740992.) - 1.);
                *offset = 0.75 * *offset + 0.25 * z;
            }
            temporal.advance_to(tick, &mut rng);
            assert_eq!(temporal.weather_state().temperature_offset(), expected[0]);
            assert_eq!(temporal.weather_state().precipitation_offset(), expected[1]);
            assert_eq!(rng, oracle_rng);
        }
        let mut restored =
            TemporalClimate::from_state(temporal.settings().clone(), temporal.weather_state())
                .unwrap();
        let mut restored_rng = Rng::from_state(rng.state()).unwrap();
        let base = Climate::new(Topology::new(7, 48).unwrap());
        for tick in 38..=293 {
            temporal.advance_to(tick, &mut rng);
            restored.advance_to(tick, &mut restored_rng);
            assert_eq!(temporal, restored);
            assert_eq!(rng, restored_rng);
            assert_eq!(
                temporal.current_at(&base, Topology::new(1, 1).unwrap().cell(0, 0)),
                restored.current_at(&base, Topology::new(1, 1).unwrap().cell(0, 0))
            );
        }
    }
}

impl TemporalClimate {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        self.settings.write_canonical(w)?;
        w.u32(self.state.version)?;
        w.u64(self.state.tick)?;
        w.f64(self.state.temperature_offset)?;
        w.f64(self.state.precipitation_offset)
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let base = TemporalClimate::new(crate::config::Config::default().climate().clone());
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut TemporalClimate| {
            v.settings = crate::config::Config::preset("seasonal")
                .unwrap()
                .climate()
                .clone();
        });
        changed!(|v: &mut TemporalClimate| {
            v.state.version += 1;
        });
        changed!(|v: &mut TemporalClimate| {
            v.state.tick += 1;
        });
        changed!(|v: &mut TemporalClimate| {
            v.state.temperature_offset = -0.0;
        });
        changed!(|v: &mut TemporalClimate| {
            v.state.precipitation_offset = f64::from_bits(1);
        });
    }
}

impl TemporalClimate {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        expected: &ClimateConfig,
        tick: u64,
    ) -> std::io::Result<Self> {
        let settings = ClimateConfig::read_canonical(r)?;
        crate::canonical::require(&settings == expected, "weather settings mismatch")?;
        let state = WeatherState::new(r.u32()?, r.u64()?, r.f64()?, r.f64()?)
            .map_err(crate::canonical::invalid)?;
        crate::canonical::require(state.tick() == tick, "weather clock mismatch")?;
        Self::from_state(settings, state).map_err(crate::canonical::invalid)
    }
}

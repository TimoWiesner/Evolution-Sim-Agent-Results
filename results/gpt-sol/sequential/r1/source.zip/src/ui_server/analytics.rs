//! Bounded observational history and expressed-phenotype histograms.
use crate::{genome::LOCUS_NAMES, metrics::Snapshot, organism::Kind, simulation::Simulation};
use serde_json::{Value, json};
use std::collections::VecDeque;
const CAPACITY: usize = 2048;
const DOMAINS: [(f64, f64); 12] = [
    (1., 4.),
    (1., 10.),
    (10., 100.),
    (200., 2000.),
    (0., 1.),
    (1., 8.),
    (0.5, 2.),
    (0., 1.),
    (0., 1.),
    (0.05, 0.5),
    (0., 1.),
    (0., 1.),
];
fn bin(value: f64, low: f64, high: f64) -> usize {
    (((value - low) / (high - low) * 20.).floor() as usize).min(19)
}
fn capture(sim: &Simulation) -> (Value, Value) {
    let snapshot = Snapshot::capture(sim);
    let mut hist = [[[0usize; 20]; 3]; 12];
    for o in sim.population().iter() {
        let t = o.traits();
        let values = [
            t.speed() as f64,
            t.strength(),
            t.max_health(),
            t.lifespan() as f64,
            t.fertility(),
            t.vision() as f64,
            t.metabolic_multiplier(),
            t.preferred_temperature(),
            t.preferred_moisture(),
            t.climate_tolerance(),
            t.aggression(),
            t.risk_tolerance(),
        ];
        for (i, value) in values.into_iter().enumerate() {
            let (low, high) = DOMAINS[i];
            hist[i][o.kind().index()][bin(value, low, high)] += 1;
        }
    }
    let kinds: Vec<_> = Kind::ALL.into_iter().map(|kind| {
        let k=snapshot.kind(kind);
        json!({"population":snapshot.counts().get(kind).to_string(),"births":k.births.to_string(),"deaths":k.deaths.to_string(),"species":k.species.to_string(),"means":k.traits.0.map(|t|t.mean)})
    }).collect();
    let histograms: Vec<_> = LOCUS_NAMES.into_iter().enumerate().map(|(i,name)| {
        let (low,high)=DOMAINS[i];
        json!({"name":name,"edges":(0..=20).map(|b|low+(high-low)*b as f64/20.).collect::<Vec<_>>(),"counts":hist[i].map(|bins|bins.map(|n|n.to_string()))})
    }).collect();
    (
        json!({"tick":sim.tick().to_string(),"kinds":kinds}),
        json!({"tick":sim.tick().to_string(),"histograms":histograms}),
    )
}
pub(super) struct ChartHistory {
    points: VecDeque<Value>,
    cached_tick: u64,
    point: Value,
    current: Value,
}
impl ChartHistory {
    pub fn new(sim: &Simulation) -> Self {
        let (point, current) = capture(sim);
        Self {
            points: VecDeque::from([point.clone()]),
            cached_tick: sim.tick(),
            point,
            current,
        }
    }
    fn refresh(&mut self, sim: &Simulation) {
        if self.cached_tick != sim.tick() {
            (self.point, self.current) = capture(sim);
            self.cached_tick = sim.tick();
        }
    }
    pub fn after_tick(&mut self, sim: &Simulation) {
        if sim.tick() % 10 == 0 {
            self.refresh(sim);
            self.points.push_back(self.point.clone());
            if self.points.len() > CAPACITY {
                self.points.pop_front();
            }
        }
    }
    pub fn frame(&mut self, sim: &Simulation, epoch: u64) -> Value {
        self.refresh(sim);
        let mut points: Vec<_> = self.points.iter().cloned().collect();
        if points.last().unwrap()["tick"] != self.point["tick"] {
            points.push(self.point.clone());
        }
        json!({"chart_schema":1,"epoch":epoch.to_string(),"sample_every":"10","capacity":CAPACITY,"points":points,"current":self.current})
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::Config, persistence::state_hash};
    #[test]
    fn domains_and_bin_edges() {
        assert_eq!(LOCUS_NAMES.len(), DOMAINS.len());
        for (low, high) in DOMAINS {
            assert_eq!(bin(low, low, high), 0);
            assert_eq!(bin(high, low, high), 19);
            assert_eq!(bin((low + high) / 2., low, high), 10);
        }
        assert_eq!(bin(0.05, 0., 1.), 1);
        assert_eq!(bin(0.0499, 0., 1.), 0);
    }
    #[test]
    fn metrics_histograms_sampling_and_purity() {
        let mut sim = Simulation::new(Config::default()).unwrap();
        let mut direct = sim.clone();
        let mut history = ChartHistory::new(&sim);
        for tick in 0..=31 {
            let before = state_hash(&sim).unwrap();
            let f = history.frame(&sim, 3);
            assert_eq!(f, history.frame(&sim, 3));
            let points = f["points"].as_array().unwrap();
            let last = points.last().unwrap();
            assert_eq!(last["tick"], tick.to_string());
            let m = Snapshot::capture(&sim);
            for k in Kind::ALL {
                let i = k.index();
                assert_eq!(
                    last["kinds"][i]["population"],
                    m.counts().get(k).to_string()
                );
                assert_eq!(last["kinds"][i]["births"], m.kind(k).births.to_string());
                assert_eq!(last["kinds"][i]["deaths"], m.kind(k).deaths.to_string());
                assert_eq!(last["kinds"][i]["species"], m.kind(k).species.to_string());
                for t in 0..12 {
                    assert_eq!(
                        last["kinds"][i]["means"][t],
                        json!(m.kind(k).traits.0[t].mean)
                    );
                    let total: usize = f["current"]["histograms"][t]["counts"][i]
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|v| v.as_str().unwrap().parse::<usize>().unwrap())
                        .sum();
                    assert_eq!(total as u128, m.counts().get(k));
                }
            }
            assert_eq!(before, state_hash(&sim).unwrap());
            if tick < 31 {
                sim.advance_one_tick().unwrap();
                direct.advance_one_tick().unwrap();
                history.after_tick(&sim);
            }
        }
        assert_eq!(state_hash(&sim).unwrap(), state_hash(&direct).unwrap());
    }
    #[test]
    fn bounded_empty_history() {
        let c=Config::from_json(r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(c).unwrap();
        let mut h = ChartHistory::new(&sim);
        for _ in 0..20501 {
            sim.advance_one_tick().unwrap();
            h.after_tick(&sim);
        }
        let f = h.frame(&sim, 0);
        let p = f["points"].as_array().unwrap();
        assert_eq!(p.len(), 2049);
        assert_eq!(p[0]["tick"], "30");
        assert_eq!(p.last().unwrap()["tick"], "20501");
        assert_eq!(p[0]["kinds"][0]["means"][0], Value::Null);
    }
}

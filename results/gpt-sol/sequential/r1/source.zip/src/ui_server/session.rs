//! Application-only state and fake-time scheduler. Never encoded in checkpoints.
use super::{analytics::ChartHistory, snapshot};
use crate::{config::Config, organism::OrganismId, persistence, simulation::Simulation};
use serde_json::{Value, json};
use std::time::Duration;
#[derive(Clone, Copy, Debug, PartialEq)]
pub(super) enum Speed {
    Slow,
    Normal,
    Fast,
}
impl Speed {
    pub fn parse(s: &str) -> Result<Self, String> {
        match s {
            "slow" => Ok(Self::Slow),
            "normal" => Ok(Self::Normal),
            "fast" => Ok(Self::Fast),
            _ => Err("speed must be slow, normal or fast".into()),
        }
    }
    fn name(self) -> &'static str {
        match self {
            Self::Slow => "slow",
            Self::Normal => "normal",
            Self::Fast => "fast",
        }
    }
    fn interval(self) -> Duration {
        Duration::from_secs_f64(
            1. / match self {
                Self::Slow => 5.,
                Self::Normal => 20.,
                Self::Fast => 60.,
            },
        )
    }
}
pub(super) enum Command {
    Run,
    Pause,
    Step,
    Reset,
    SetSpeed(Speed),
    Select(OrganismId),
    ClearSelection,
}
pub(super) struct UiSession {
    pub sim: Simulation,
    pub epoch: u64,
    revision: u64,
    running: bool,
    ready: bool,
    speed: Speed,
    next: Duration,
    selected: Option<Value>,
    world: Value,
    charts: ChartHistory,
}
impl UiSession {
    pub fn new(config: Config) -> Result<Self, String> {
        let sim = Simulation::new(config).map_err(|e| e.to_string())?;
        let world = snapshot::world(&sim);
        let charts = ChartHistory::new(&sim);
        Ok(Self {
            charts,
            sim,
            world,
            epoch: 0,
            revision: 0,
            running: true,
            ready: false,
            speed: Speed::Normal,
            next: Duration::ZERO,
            selected: None,
        })
    }
    fn capacity(&mut self, replacement: bool) -> Result<(), String> {
        if self.revision == u64::MAX || (replacement && self.epoch == u64::MAX) {
            self.running = false;
            Err("UI revision capacity exhausted; restart UI".into())
        } else {
            Ok(())
        }
    }
    fn changed(&mut self) {
        self.revision += 1;
    }
    fn schedule(&mut self, now: Duration) {
        self.next = now.saturating_add(self.speed.interval());
    }
    pub fn ready(&mut self, now: Duration) -> Result<(), String> {
        if !self.ready {
            self.capacity(false)?;
            self.ready = true;
            self.schedule(now);
            self.changed();
        }
        Ok(())
    }
    fn advance(&mut self) -> Result<(), String> {
        if let Err(e) = self.capacity(false) {
            self.running = false;
            return Err(e);
        }
        if let Err(e) = self.sim.advance_one_tick() {
            self.running = false;
            self.changed();
            return Err(e.to_string());
        }
        self.charts.after_tick(&self.sim);
        self.refresh_selection();
        self.changed();
        Ok(())
    }
    pub fn on_due_tick(&mut self, now: Duration) -> Result<(), String> {
        if self.ready && self.running && now >= self.next {
            self.advance()?;
            self.schedule(now);
        }
        Ok(())
    }
    pub fn command(&mut self, command: Command, now: Duration) -> Result<(), String> {
        self.capacity(matches!(command, Command::Reset))?;
        let reschedule = matches!(
            command,
            Command::Run | Command::Reset | Command::SetSpeed(_)
        );
        match command {
            Command::Run => {
                if self.running {
                    return Ok(());
                }
                self.running = true;
            }
            Command::Pause => {
                if !self.running {
                    return Ok(());
                }
                self.running = false;
            }
            Command::Step => {
                self.running = false;
                self.advance()?;
                self.schedule(now);
                return Ok(());
            }
            Command::Reset => {
                let sim = Simulation::new(self.sim.config().clone()).map_err(|e| e.to_string())?;
                self.replace(sim);
            }
            Command::SetSpeed(speed) => self.speed = speed,
            Command::Select(id) => {
                self.selected =
                    Some(snapshot::inspector(&self.sim, id).ok_or("organism is no longer living")?);
            }
            Command::ClearSelection => self.selected = None,
        }
        if reschedule {
            self.schedule(now);
        }
        self.changed();
        Ok(())
    }
    fn replace(&mut self, sim: Simulation) {
        let world = snapshot::world(&sim);
        let charts = ChartHistory::new(&sim);
        self.sim = sim;
        self.charts = charts;
        self.world = world;
        self.running = false;
        self.selected = None;
        self.epoch += 1;
    }
    pub fn load_checkpoint(&mut self, bytes: &[u8], now: Duration) -> Result<(), String> {
        self.capacity(true)?;
        let sim = persistence::from_checkpoint_bytes(bytes)
            .map_err(|e| format!("Invalid checkpoint: {e}"))?;
        self.replace(sim);
        self.schedule(now);
        self.changed();
        Ok(())
    }
    pub fn start_config(&mut self, config: Config, now: Duration) -> Result<(), String> {
        self.capacity(true)?;
        let sim = Simulation::new(config).map_err(|e| e.to_string())?;
        self.replace(sim);
        self.schedule(now);
        self.changed();
        Ok(())
    }
    pub fn checkpoint_bytes(&self) -> Result<Vec<u8>, String> {
        persistence::checkpoint_bytes(&self.sim).map_err(|e| e.to_string())
    }
    fn refresh_selection(&mut self) {
        let Some(old) = self.selected.as_ref() else {
            return;
        };
        if old["status"] == "died" {
            return;
        }
        let id = OrganismId(old["id"].as_str().unwrap().parse().unwrap());
        if let Some(live) = snapshot::inspector(&self.sim, id) {
            self.selected = Some(live);
        } else {
            let mut dead = old.clone();
            dead["status"] = json!("died");
            if let Some(d) = self
                .sim
                .population()
                .death_records()
                .iter()
                .find(|d| d.id == id)
            {
                dead["death_tick"] = json!(d.tick.to_string());
                dead["death_cause"] = json!(format!("{:?}", d.cause));
            }
            self.selected = Some(dead);
        }
    }
    pub fn world(&self) -> Value {
        let mut w = self.world.clone();
        w["epoch"] = json!(self.epoch.to_string());
        w
    }
    pub fn frame(&mut self) -> Value {
        let mut f = snapshot::frame(&self.sim);
        f["charts"] = self.charts.frame(&self.sim, self.epoch);
        f["epoch"] = json!(self.epoch.to_string());
        f["revision"] = json!(self.revision.to_string());
        f["running"] = json!(self.running);
        f["ready"] = json!(self.ready);
        f["speed"] = json!(self.speed.name());
        f["selected"] = json!(self.selected);
        f
    }
}
#[cfg(test)]
mod tests;

use super::*;
use crate::persistence::state_hash;
fn make() -> UiSession {
    UiSession::new(Config::from_json(r#"{"seed":-99999999999999999999999999999999,"world":{"width":3,"height":2},"initial":{"plants":5,"herbivores":2,"carnivores":1}}"#).unwrap()).unwrap()
}
#[test]
fn controls_fake_time_and_exact_steps() {
    let mut s = make();
    let fresh = state_hash(&s.sim).unwrap();
    s.on_due_tick(Duration::from_secs(10)).unwrap();
    assert_eq!(s.sim.tick(), 0);
    s.ready(Duration::ZERO).unwrap();
    for (speed, nanos) in [
        (Speed::Slow, 200000000),
        (Speed::Normal, 50000000),
        (Speed::Fast, 16666667),
    ] {
        s.command(Command::SetSpeed(speed), Duration::ZERO).unwrap();
        let tick = s.sim.tick();
        s.on_due_tick(Duration::from_nanos(nanos - 1)).unwrap();
        assert_eq!(s.sim.tick(), tick);
        s.on_due_tick(Duration::from_nanos(nanos)).unwrap();
        assert_eq!(s.sim.tick(), tick + 1);
    }
    s.command(Command::Pause, Duration::ZERO).unwrap();
    let tick = s.sim.tick();
    s.on_due_tick(Duration::from_secs(100)).unwrap();
    assert_eq!(s.sim.tick(), tick);
    for _ in 0..3 {
        s.command(Command::Run, Duration::ZERO).unwrap();
        let tick = s.sim.tick();
        s.command(Command::Step, Duration::ZERO).unwrap();
        s.on_due_tick(Duration::from_secs(100)).unwrap();
        assert_eq!(s.sim.tick(), tick + 1);
        assert!(!s.running);
    }
    for _ in 0..2 {
        s.command(Command::Reset, Duration::ZERO).unwrap();
        assert_eq!(state_hash(&s.sim).unwrap(), fresh);
        assert!(!s.running);
    }
    for invalid in ["-1", "0", "60", "unknown", ""] {
        assert!(Speed::parse(invalid).is_err());
    }
}
#[test]
fn checkpoint_replacement_reset_and_purity() {
    let mut s = make();
    s.command(Command::Select(OrganismId(1)), Duration::ZERO)
        .unwrap();
    let hash = state_hash(&s.sim).unwrap();
    let before = s.frame();
    assert!(s.load_checkpoint(b"bad", Duration::ZERO).is_err());
    assert_eq!(s.frame(), before);
    assert_eq!(state_hash(&s.sim).unwrap(), hash);
    for speed in [Speed::Slow, Speed::Normal, Speed::Fast] {
        s.command(Command::SetSpeed(speed), Duration::ZERO).unwrap();
    }
    let bytes = s.checkpoint_bytes().unwrap();
    s.frame();
    s.world();
    assert_eq!(state_hash(&s.sim).unwrap(), hash);
    assert_eq!(
        state_hash(&persistence::from_checkpoint_bytes(&bytes).unwrap()).unwrap(),
        hash
    );
    let config=Config::from_json(r#"{"seed":987,"world":{"width":1,"height":9},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let mut other = Simulation::new(config.clone()).unwrap();
    for _ in 0..20 {
        other.advance_one_tick().unwrap();
    }
    s.load_checkpoint(
        &persistence::checkpoint_bytes(&other).unwrap(),
        Duration::ZERO,
    )
    .unwrap();
    assert_eq!(state_hash(&s.sim).unwrap(), state_hash(&other).unwrap());
    assert_eq!(s.world()["height"], 9);
    assert!(!s.running);
    assert!(s.selected.is_none());
    s.command(Command::Step, Duration::ZERO).unwrap();
    assert_eq!(s.sim.tick(), 21);
    s.command(Command::Reset, Duration::ZERO).unwrap();
    assert_eq!(
        state_hash(&s.sim).unwrap(),
        state_hash(&Simulation::new(config).unwrap()).unwrap()
    );
}
#[test]
fn inspector_exact_data_and_death_following() {
    let mut s = make();
    let id = s
        .sim
        .population()
        .iter()
        .find(|o| o.kind() == crate::organism::Kind::Carnivore)
        .unwrap()
        .id();
    s.command(Command::Select(id), Duration::ZERO).unwrap();
    let f = s.frame();
    let d = &f["selected"];
    assert_eq!(d["id"], id.value().to_string());
    assert_eq!(d["parents"], json!([]));
    assert_eq!(d["genome"]["alleles"], json!(vec![32768; 12]));
    assert_eq!(d["traits"].as_object().unwrap().len(), 12);
    for _ in 0..2200 {
        s.command(Command::Step, Duration::ZERO).unwrap();
        if s.frame()["selected"]["status"] == "died" {
            break;
        }
        let o = s.sim.population().get(id).unwrap().clone();
        assert_eq!(s.frame()["selected"]["age"], o.age().to_string());
        assert_eq!(s.frame()["selected"]["energy"], o.energy());
    }
    let dead = s.frame()["selected"].clone();
    assert_eq!(dead["status"], "died");
    let record = s
        .sim
        .population()
        .death_records()
        .iter()
        .find(|d| d.id == id)
        .unwrap();
    assert_eq!(dead["death_tick"], record.tick.to_string());
    s.command(Command::Step, Duration::ZERO).unwrap();
    assert_eq!(s.frame()["selected"], dead);
    assert!(
        s.command(Command::Select(OrganismId(u64::MAX)), Duration::ZERO)
            .is_err()
    );
    assert_eq!(s.frame()["selected"], dead);
}

#[test]
fn born_parent_species_and_exact_large_ids() {
    let c=Config::from_json(r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":2000,"herbivores":120,"carnivores":0}}"#).unwrap();
    let mut s = UiSession::new(c).unwrap();
    for _ in 0..301 {
        s.command(Command::Step, Duration::ZERO).unwrap();
    }
    for (kind, arity) in [
        (crate::organism::Kind::Plant, 1),
        (crate::organism::Kind::Herbivore, 2),
    ] {
        let o = s
            .sim
            .population()
            .iter()
            .find(|o| o.kind() == kind && o.generation() > 0)
            .unwrap();
        let id = o.id();
        let expected = o
            .parents()
            .iter()
            .map(|p| p.value().to_string())
            .collect::<Vec<_>>();
        let species = o.species_id();
        s.command(Command::Select(id), Duration::ZERO).unwrap();
        let d = s.frame()["selected"].clone();
        assert_eq!(d["parents"], json!(expected));
        assert_eq!(d["parents"].as_array().unwrap().len(), arity);
        assert_eq!(
            d["species_name"],
            s.sim.population().species().get(species).unwrap().name()
        );
    }
    // DTO uses strings rather than JS floating integers, including parent IDs.
    let mut o = s.sim.population().iter().next().unwrap().clone();
    o.id = OrganismId(9007199254740993);
    o.parents = vec![OrganismId(9007199254740992)];
    // Owner DTO helper covered directly without inserting incoherent engine state.
    let d = super::snapshot::organism_inspector(&s.sim, &o);
    assert_eq!(d["id"], "9007199254740993");
    assert_eq!(d["parents"][0], "9007199254740992");
}
#[test]
fn deadlines_idempotence_no_catchup_and_overflow() {
    let mut s = make();
    s.ready(Duration::ZERO).unwrap();
    s.ready(Duration::from_secs(1)).unwrap();
    s.command(Command::Run, Duration::from_secs(1)).unwrap();
    s.on_due_tick(Duration::from_millis(50)).unwrap();
    assert_eq!(s.sim.tick(), 1);
    s.on_due_tick(Duration::from_secs(100)).unwrap();
    assert_eq!(s.sim.tick(), 2);
    s.on_due_tick(Duration::from_secs(100)).unwrap();
    assert_eq!(s.sim.tick(), 2);
    s.command(Command::Pause, Duration::ZERO).unwrap();
    s.command(Command::Pause, Duration::ZERO).unwrap();
    let hash = state_hash(&s.sim).unwrap();
    s.revision = u64::MAX;
    assert!(s.command(Command::Step, Duration::ZERO).is_err());
    assert_eq!(state_hash(&s.sim).unwrap(), hash);
    s.revision = u64::MAX - 1;
    s.command(Command::Step, Duration::ZERO).unwrap();
    assert_eq!(s.revision, u64::MAX);
    assert!(!s.running);
    s.revision = 0;
    s.epoch = u64::MAX;
    let hash = state_hash(&s.sim).unwrap();
    assert!(s.command(Command::Reset, Duration::ZERO).is_err());
    assert_eq!(state_hash(&s.sim).unwrap(), hash);
}

#[test]
fn experiment_replacement_history_and_observation_boundary() {
    let mut s = make();
    s.command(Command::SetSpeed(Speed::Fast), Duration::ZERO)
        .unwrap();
    s.command(Command::Select(OrganismId(1)), Duration::ZERO)
        .unwrap();
    for _ in 0..11 {
        s.command(Command::Step, Duration::ZERO).unwrap();
    }
    let bytes = s.checkpoint_bytes().unwrap();
    let frame = s.frame();
    assert_eq!(frame["charts"]["points"].as_array().unwrap().len(), 3);
    // Validation and arbitrary draft reads cannot alter control, selection or history.
    assert!(super::super::configuration::validate(b"{\"seed\":null}").is_err());
    let _ = super::super::configuration::catalog(s.sim.config(), s.epoch);
    assert_eq!(s.frame(), frame);
    assert_eq!(s.checkpoint_bytes().unwrap(), bytes);
    let config = Config::preset("plant-only").unwrap();
    let mut direct = Simulation::new(config.clone()).unwrap();
    let epoch = s.epoch;
    s.start_config(config, Duration::ZERO).unwrap();
    assert_eq!(s.epoch, epoch + 1);
    assert_eq!(s.speed, Speed::Fast);
    assert!(!s.running);
    assert!(s.selected.is_none());
    assert_eq!(s.frame()["charts"]["points"].as_array().unwrap().len(), 1);
    assert_eq!(s.frame()["charts"]["points"][0]["tick"], "0");
    for _ in 0..13 {
        s.command(Command::Step, Duration::ZERO).unwrap();
        direct.advance_one_tick().unwrap();
    }
    assert_eq!(state_hash(&s.sim).unwrap(), state_hash(&direct).unwrap());
    s.load_checkpoint(&bytes, Duration::ZERO).unwrap();
    assert_eq!(s.frame()["charts"]["points"].as_array().unwrap().len(), 1);
    assert_eq!(s.frame()["charts"]["points"][0]["tick"], "11");
    s.command(Command::Reset, Duration::ZERO).unwrap();
    assert_eq!(s.frame()["charts"]["points"][0]["tick"], "0");
}

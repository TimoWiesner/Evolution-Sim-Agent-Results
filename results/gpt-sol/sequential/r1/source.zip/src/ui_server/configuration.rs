//! Exact numeric tokens across the browser boundary; the core owns validation.
use crate::config::Config;
use serde_json::{Value, json};
use std::collections::BTreeMap;

pub(super) fn describe(config: &Config) -> Value {
    let canonical = config.to_json().expect("validated config");
    let value: Value = serde_json::from_str(&canonical).expect("config JSON");
    let mut fields = BTreeMap::<String, String>::new();
    for (group, value) in value.as_object().unwrap() {
        if let Some(object) = value.as_object() {
            for (key, value) in object {
                fields.insert(format!("{group}.{key}"), value.to_string());
            }
        } else {
            fields.insert(group.clone(), value.to_string());
        }
    }
    json!({"canonical_json":canonical,"fields":fields})
}
pub(super) fn catalog(config: &Config, epoch: u64) -> Value {
    let presets: BTreeMap<_, _> = Config::preset_names()
        .iter()
        .map(|name| (*name, describe(&Config::preset(name).unwrap())))
        .collect();
    json!({"epoch":epoch.to_string(),"active":describe(config),"presets":presets})
}
pub(super) fn validate(bytes: &[u8]) -> Result<Config, Value> {
    let text =
        std::str::from_utf8(bytes).map_err(|e| json!({"path":"$","message":e.to_string()}))?;
    Config::from_json(text).map_err(|e| json!({"path":e.path(),"message":e.message()}))
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_roundtrip_all_presets_and_errors() {
        for name in Config::preset_names() {
            let config = Config::preset(name).unwrap();
            let dto = describe(&config);
            assert_eq!(dto["fields"].as_object().unwrap().len(), 21);
            assert_eq!(
                config,
                validate(dto["canonical_json"].as_str().unwrap().as_bytes()).unwrap()
            );
        }
        let mut c: Value = serde_json::from_str(&Config::default().to_json().unwrap()).unwrap();
        c["seed"] = serde_json::from_str("-1234567890123456789012345678901234567890").unwrap();
        c["climate"]["year_ticks"] = json!(u64::MAX);
        let config = validate(c.to_string().as_bytes()).unwrap();
        assert_eq!(
            describe(&config)["fields"]["climate.year_ticks"],
            u64::MAX.to_string()
        );
        assert_eq!(
            describe(&config)["fields"]["seed"],
            "-1234567890123456789012345678901234567890"
        );
        c["animals"]["basal_cost"] = json!(0);
        assert_eq!(
            validate(c.to_string().as_bytes()).unwrap_err()["path"],
            "animals.basal_cost"
        );
        assert_eq!(validate(b"{").unwrap_err()["path"], "$");
    }
}

//! Read-only application DTOs. Only the selected organism copies genetics.
use crate::{organism::Kind, simulation::Simulation};
use serde_json::{Value, json};
pub(super) fn world(sim: &Simulation) -> Value {
    let t = sim.world().topology();
    let cells: Vec<_> = (0..t.height())
        .flat_map(|y| {
            (0..t.width()).map(move |x| {
                sim.world()
                    .climate()
                    .base_at(t.cell(x as i128, y as i128))
                    .biome()
                    .name()
            })
        })
        .collect();
    json!({"ui_schema":3,"width":t.width(),"height":t.height(),"cells":cells})
}
pub(super) fn frame(sim: &Simulation) -> Value {
    let organisms: Vec<_> = sim
        .population()
        .iter()
        .map(|o| {
            json!([
                o.id().value().to_string(),
                match o.kind() {
                    Kind::Plant => 0,
                    Kind::Herbivore => 1,
                    Kind::Carnivore => 2,
                },
                o.position().x(),
                o.position().y()
            ])
        })
        .collect();
    let c = sim.population().counts();
    json!({"ui_schema":3,"tick":sim.tick().to_string(),"counts":[c.plants().to_string(),c.herbivores().to_string(),c.carnivores().to_string()],"organisms":organisms})
}
pub(super) fn inspector(sim: &Simulation, id: crate::organism::OrganismId) -> Option<Value> {
    let o = sim.population().get(id)?;
    Some(organism_inspector(sim, o))
}
pub(super) fn organism_inspector(sim: &Simulation, o: &crate::organism::Organism) -> Value {
    let id = o.id();
    let t = o.traits();
    let values = [
        t.speed() as f64,
        t.strength(),
        t.max_health(),
        t.lifespan() as f64,
        t.fertility(),
        t.vision() as f64,
        t.metabolic_multiplier(),
        t.preferred_temperature(),
        t.preferred_moisture(),
        t.climate_tolerance(),
        t.aggression(),
        t.risk_tolerance(),
    ];
    let traits: Value = crate::genome::LOCUS_NAMES
        .into_iter()
        .zip(values)
        .map(|(k, v)| (k.to_owned(), json!(v)))
        .collect();
    json!({"id":id.value().to_string(),"kind":format!("{:?}",o.kind()),"species_id":o.species_id().value().to_string(),"species_name":sim.population().species().get(o.species_id()).unwrap().name(),"age":o.age().to_string(),"energy":o.energy(),"health":o.health(),"position":[o.position().x(),o.position().y()],"generation":o.generation().to_string(),"parents":o.parents().iter().map(|p|p.value().to_string()).collect::<Vec<_>>(),"traits":traits,"genome":{"version":crate::genome::GENOME_VERSION,"names":crate::genome::LOCUS_NAMES,"alleles":o.genome().alleles()},"status":"living","observed_tick":sim.tick().to_string()})
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::Config, persistence::state_hash};
    #[test]
    fn exhaustive_read_only_dtos_and_continuation() {
        for (w, h) in [(1, 1), (1, 9), (7, 1), (8, 6)] {
            let config=Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":7,"herbivores":2,"carnivores":1}}}}"#)).unwrap();
            let mut sim = Simulation::new(config).unwrap();
            let mut direct = sim.clone();
            for _ in 0..15 {
                let before = state_hash(&sim).unwrap();
                let world = world(&sim);
                let f = frame(&sim);
                for y in 0..h {
                    for x in 0..w {
                        assert_eq!(
                            world["cells"][y * w + x],
                            sim.world()
                                .climate()
                                .base_at(sim.world().topology().cell(x as i128, y as i128))
                                .biome()
                                .name()
                        );
                    }
                }
                assert_eq!(world["cells"].as_array().unwrap().len(), w * h);
                assert_eq!(
                    f["organisms"].as_array().unwrap().len(),
                    sim.population().iter().count()
                );
                for (row, o) in f["organisms"]
                    .as_array()
                    .unwrap()
                    .iter()
                    .zip(sim.population().iter())
                {
                    assert_eq!(row[0], o.id().value().to_string());
                    assert_eq!(
                        row[1],
                        match o.kind() {
                            Kind::Plant => 0,
                            Kind::Herbivore => 1,
                            Kind::Carnivore => 2,
                        }
                    );
                    assert_eq!(row[2], o.position().x());
                    assert_eq!(row[3], o.position().y());
                }
                assert_eq!(before, state_hash(&sim).unwrap());
                sim.advance_one_tick().unwrap();
                direct.advance_one_tick().unwrap();
            }
            assert_eq!(state_hash(&sim).unwrap(), state_hash(&direct).unwrap());
        }
    }
}

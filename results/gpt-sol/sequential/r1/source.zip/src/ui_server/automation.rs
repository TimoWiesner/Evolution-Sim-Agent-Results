//! Driver child owns Chromium; group fallback reaps descendants on deadlines.
use super::Mode;
#[cfg(unix)]
use std::os::unix::process::CommandExt;
use std::path::PathBuf;
use std::process::{Child, Command};
pub(super) struct Driver {
    child: Child,
    profile: PathBuf,
}
impl Driver {
    pub(super) fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
        self.child.try_wait()
    }
}
impl Drop for Driver {
    fn drop(&mut self) {
        cleanup(&mut self.child);
        for _ in 0..10 {
            if std::fs::remove_dir_all(&self.profile).is_ok() || !self.profile.exists() {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(50));
        }
    }
}
pub(super) fn launch(url: &str, mode: &Mode) -> Result<Driver, String> {
    let base = std::env::current_dir().map_err(|e| e.to_string())?;
    let base = if base.join("target").is_dir() {
        base.join("target")
    } else {
        std::env::temp_dir()
    };
    let profile = base.join(format!(
        "evosim-owned-browser-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|e| e.to_string())?
            .as_nanos()
    ));
    std::fs::create_dir(&profile).map_err(|e| e.to_string())?;
    let mut command = Command::new("node");
    command.env("EVOSIM_UI_PROFILE", &profile);
    command
        .arg("-e")
        .arg(include_str!("../../ui/automation.cjs"))
        .arg(url);
    match mode {
        Mode::Screenshots(path) => {
            command.arg("100").arg(path);
        }
        _ => {
            command.arg("10").arg("");
        }
    }
    #[cfg(unix)]
    command.process_group(0);
    match command.spawn() {
        Ok(child) => Ok(Driver { child, profile }),
        Err(e) => {
            let _ = std::fs::remove_dir_all(profile);
            Err(format!("UI automation needs Node >=18: {e}"))
        }
    }
}
pub(super) fn cleanup(child: &mut Child) {
    // Driver normally removes profile and reaps Chromium before exiting.
    let _ = Command::new("kill")
        .args(["-TERM", "--", &format!("-{}", child.id())])
        .output();
    let _ = child.kill();
    let _ = child.wait();
}

//! Bounded blocking ingress isolated from the engine thread.
use std::sync::{Arc, Mutex, mpsc};
use tiny_http::Request;
pub(super) const LIMIT: usize = 64 * 1024 * 1024;
#[derive(Clone, Copy)]
pub(super) enum Operation {
    CheckpointLoad,
    ConfigValidate,
    ConfigStart,
}
impl Operation {
    pub fn limit(self) -> usize {
        match self {
            Self::CheckpointLoad => LIMIT,
            _ => 1024 * 1024,
        }
    }
}
pub(super) type Upload = (Request, u64, Operation);
pub(super) type Completion = (Request, u64, Operation, Result<Vec<u8>, String>);
pub(super) fn workers() -> Result<(mpsc::SyncSender<Upload>, mpsc::Receiver<Completion>), String> {
    let (tx, rx) = mpsc::sync_channel::<Upload>(2);
    let (done, complete) = mpsc::sync_channel(2);
    let rx = Arc::new(Mutex::new(rx));
    for i in 0..2 {
        let rx = rx.clone();
        let done = done.clone();
        std::thread::Builder::new()
            .name(format!("ui-upload-{i}"))
            .spawn(move || {
                loop {
                    let job = match rx.lock() {
                        Ok(r) => r.recv(),
                        Err(_) => break,
                    };
                    let Ok((mut req, epoch, operation)) = job else {
                        break;
                    };
                    let limit = operation.limit();
                    let expected = req.body_length().unwrap_or(0);
                    let mut bytes = Vec::new();
                    let result = std::io::Read::read_to_end(
                        &mut req.as_reader().take((limit + 1) as u64),
                        &mut bytes,
                    )
                    .map_err(|e| e.to_string())
                    .and_then(|_| {
                        if bytes.len() == expected && bytes.len() <= limit {
                            Ok(bytes)
                        } else {
                            Err("upload body truncated or too large".into())
                        }
                    });
                    let _ = done.try_send((req, epoch, operation, result));
                }
            })
            .map_err(|e| e.to_string())?;
    }
    Ok((tx, complete))
}
use std::io::Read;

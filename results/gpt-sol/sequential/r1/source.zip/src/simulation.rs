//! Deterministic simulation frame, shared by future headless and UI adapters.
//!
//! World owns geometry and climate; Population owns shared organism life state.
//! Plants consume bounded renewable cell resources; animals sense and navigate.
//! Temporal climate advances from the sole engine RNG during ClimateResources.
//! Shared aging and plant physiology consume no random draws. Accessors are observational.
use crate::{
    climate::Climate,
    config::Config,
    ecology::{
        animals::{next_toward, step_cost, wander_step},
        carnivores::{
            DENOMINATOR, HUNTING_MODEL_VERSION, attack_cost, hungry, kill_probability_numerator,
            nutrition_credit,
        },
        herbivores::{EFFICIENCY, accepts_food, bite_request, maintenance},
        plants::{child_energy, rates, sample_dispersal},
    },
    organism::{DeathCause, ENERGY_CAPACITY, Kind, OrganismId},
    population::{BirthPhase, BirthRequest, Population, PopulationError},
    resources::{ResourceError, ResourceField},
    rng::{Rng, RngState},
    temporal_climate::{CurrentClimate, TemporalClimate},
    topology::{Cell, Topology, TopologyError},
};
use std::{collections::BTreeSet, error::Error, fmt};

#[derive(Clone, Debug, PartialEq)]
pub struct World {
    topology: Topology,
    climate: Climate,
    temporal_climate: TemporalClimate,
    resources: ResourceField,
}
impl World {
    pub fn resources(&self) -> &ResourceField {
        &self.resources
    }
    pub fn temporal_climate(&self) -> &TemporalClimate {
        &self.temporal_climate
    }
    pub fn current_climate_at(&self, cell: Cell) -> CurrentClimate {
        self.temporal_climate.current_at(&self.climate, cell)
    }
    pub fn climate(&self) -> &Climate {
        &self.climate
    }
    pub fn topology(&self) -> Topology {
        self.topology
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TickPhase {
    Clock,
    ClimateResources,
    Plants,
    Herbivores,
    Carnivores,
    Reproduction,
    Commit,
}
pub const TICK_PHASES: [TickPhase; 7] = [
    TickPhase::Clock,
    TickPhase::ClimateResources,
    TickPhase::Plants,
    TickPhase::Herbivores,
    TickPhase::Carnivores,
    TickPhase::Reproduction,
    TickPhase::Commit,
];

/// Observational report of completed dispatches; never retained as engine state.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct TickReport {
    pub tick: u64,
    pub phases: [TickPhase; 7],
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SimulationError {
    Topology(TopologyError),
    TickOverflow,
    Population(PopulationError),
    Resources(ResourceError),
}
impl fmt::Display for SimulationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Resources(e) => write!(f, "resources: {e}"),
            Self::Population(e) => write!(f, "population: {e}"),
            Self::Topology(e) => write!(f, "world: {e}"),
            Self::TickOverflow => f.write_str("simulation tick overflow"),
        }
    }
}
impl Error for SimulationError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Resources(e) => Some(e),
            Self::Population(e) => Some(e),
            Self::Topology(e) => Some(e),
            Self::TickOverflow => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Simulation {
    config: Config,
    world: World,
    tick: u64,
    rng: Rng,
    population: Population,
}
impl Simulation {
    pub fn new(config: Config) -> Result<Self, SimulationError> {
        let topology = Topology::new(config.world().width(), config.world().height())
            .map_err(SimulationError::Topology)?;
        let resources =
            ResourceField::new(topology, config.plants()).map_err(SimulationError::Resources)?;
        let rng = Rng::from_seed(config.seed());
        let temporal_climate = TemporalClimate::new(config.climate().clone());
        let population = Population::initialize(topology, config.initial())
            .map_err(SimulationError::Population)?;
        Ok(Self {
            population,
            config,
            world: World {
                topology,
                climate: Climate::new(topology),
                temporal_climate,
                resources,
            },
            tick: 0,
            rng,
        })
    }
    pub fn population(&self) -> &Population {
        &self.population
    }
    pub fn config(&self) -> &Config {
        &self.config
    }
    pub fn world(&self) -> &World {
        &self.world
    }
    pub fn tick(&self) -> u64 {
        self.tick
    }
    pub fn rng_state(&self) -> RngState {
        self.rng.state()
    }

    /// Advance exactly once. Overflow leaves the entire state unchanged.
    pub fn advance_one_tick(&mut self) -> Result<TickReport, SimulationError> {
        let next_tick = self
            .tick
            .checked_add(1)
            .ok_or(SimulationError::TickOverflow)?;
        let mut phases = [TickPhase::Clock; 7];
        for (slot, phase) in phases.iter_mut().zip(TICK_PHASES) {
            match phase {
                TickPhase::Clock => self.tick = next_tick,
                TickPhase::ClimateResources => self.climate_resources(),
                TickPhase::Plants => self.plants(),
                TickPhase::Herbivores => self.herbivores(),
                TickPhase::Carnivores => self.carnivores(),
                TickPhase::Reproduction => self.reproduction(),
                TickPhase::Commit => self.commit(),
            }
            *slot = phase;
        }
        Ok(TickReport {
            tick: self.tick,
            phases,
        })
    }
    fn climate_resources(&mut self) {
        self.world
            .temporal_climate
            .advance_to(self.tick, &mut self.rng);
        let world = &mut self.world;
        world.resources.regenerate_rows(self.config.plants(), |y| {
            world
                .temporal_climate
                .current_at(&world.climate, world.topology.cell(0, y as i128))
                .precipitation()
        });
    }
    // All kinds use the same lifecycle walker; future ecology supplies actions.
    fn walk_kind(&mut self, kind: Kind, mut action: impl FnMut(&mut Self, OrganismId)) {
        let ids = self.population.phase_ids(kind);
        for id in ids {
            if self.population.age_before_action(id, self.tick) {
                action(self, id);
            }
        }
    }
    fn plants(&mut self) {
        self.walk_kind(Kind::Plant, |s, id| {
            let plant = s.population.get(id).expect("walker supplied living plant");
            let cell = plant.position();
            let climate = s.world.current_climate_at(cell);
            let rates = rates(
                plant.traits(),
                climate.temperature(),
                climate.precipitation(),
            );
            s.population
                .change_health(id, -rates.damage, s.tick, Some(DeathCause::Climate))
                .expect("finite plant climate damage");
            if s.population.get(id).is_none() {
                return;
            }
            s.population
                .change_energy(id, -rates.maintenance, s.tick)
                .expect("finite plant maintenance");
            let Some(plant) = s.population.get(id) else {
                return;
            };
            let headroom = ENERGY_CAPACITY - plant.energy();
            let eta = s.config.plants().growth_efficiency();
            if eta == 0. || rates.suitability == 0. || headroom == 0. {
                return;
            }
            let demand = (4. * rates.suitability).min(headroom / eta);
            let taken = s.world.resources.take(cell, demand);
            s.population
                .change_energy(id, eta * taken, s.tick)
                .expect("finite resource-backed plant gain");
        });
    }
    fn herbivores(&mut self) {
        self.walk_kind(Kind::Herbivore, Self::herbivore_action);
    }
    fn herbivore_action(&mut self, id: OrganismId) {
        let animal = self.population.get(id).expect("living herbivore action");
        let traits = animal.traits();
        let origin = animal.position();
        let cost = maintenance(
            traits,
            self.config.animals(),
            self.world.current_climate_at(origin).temperature(),
        );
        self.population
            .change_energy(id, -cost, self.tick)
            .expect("finite upkeep");
        if self.population.get(id).is_none() {
            return;
        }
        let sensed = self.population.sense(id).expect("herbivore senses");
        let predators: Vec<_> = sensed
            .iter()
            .filter_map(|id| self.population.get(*id))
            .filter(|o| o.kind() == Kind::Carnivore)
            .map(|o| o.position())
            .collect();
        let topology = self.world.topology;
        let target = sensed
            .iter()
            .filter_map(|id| self.population.get(*id))
            .filter(|o| {
                o.kind() == Kind::Plant && accepts_food(traits, topology, o.position(), &predators)
            })
            .min_by_key(|o| (topology.distance(origin, o.position()), o.id()))
            .map(|o| (o.id(), o.position()));
        self.move_toward_observed(id, target.map(|(_, cell)| cell), 1, |_, _, _| {});
        let Some((plant_id, _)) = target else {
            return;
        };
        let Some(animal) = self.population.get(id) else {
            return;
        };
        let Some(plant) = self.population.get(plant_id) else {
            return;
        };
        if plant.kind() != Kind::Plant || topology.distance(animal.position(), plant.position()) > 1
        {
            return;
        }
        let before = plant.energy();
        let request = bite_request(before, animal.energy());
        if request <= 0. {
            return;
        }
        self.population
            .change_energy(plant_id, -request, self.tick)
            .expect("finite bite");
        let after = self.population.get(plant_id).map_or(0., |p| p.energy());
        let removed = before - after;
        if removed > 0. {
            self.population
                .change_energy(id, EFFICIENCY * removed, self.tick)
                .expect("plant-backed gain");
        }
    }
    fn carnivores(&mut self) {
        self.walk_kind(Kind::Carnivore, Self::carnivore_action);
    }
    fn carnivore_action(&mut self, id: OrganismId) {
        let animal = self.population.get(id).expect("living carnivore action");
        let traits = animal.traits();
        let origin = animal.position();
        let cost = maintenance(
            traits,
            self.config.animals(),
            self.world.current_climate_at(origin).temperature(),
        );
        self.population
            .change_energy(id, -cost, self.tick)
            .expect("finite upkeep");
        if self.population.get(id).is_none() {
            return;
        }
        if !hungry(
            self.population
                .get(id)
                .expect("living after upkeep")
                .energy(),
        ) {
            return;
        }
        let topology = self.world.topology;
        let target = self
            .population
            .sense(id)
            .expect("carnivore senses")
            .into_iter()
            .filter_map(|other| self.population.get(other))
            .filter(|o| o.kind() == Kind::Herbivore)
            .min_by_key(|o| (topology.distance(origin, o.position()), o.id()))
            .map(|o| (o.id(), o.position()));
        self.move_toward_observed(id, target.map(|(_, cell)| cell), 1, |_, _, _| {});
        let Some((prey_id, _)) = target else {
            return;
        };
        let Some(animal) = self.population.get(id) else {
            return;
        };
        let Some(prey) = self.population.get(prey_id) else {
            return;
        };
        if prey.kind() != Kind::Herbivore
            || topology.distance(animal.position(), prey.position()) > 1
            || animal.energy() < attack_cost(traits)
        {
            return;
        }
        self.population
            .change_energy(id, -attack_cost(traits), self.tick)
            .expect("finite attack cost");
        let Some(animal) = self.population.get(id) else {
            return;
        };
        let prey = self.population.get(prey_id).expect("selected live prey");
        let n = kill_probability_numerator(traits, animal.health(), prey.traits(), prey.health());
        let prey_energy = prey.energy();
        let credit = nutrition_credit(prey_energy, animal.energy());
        if self
            .rng
            .chance(n, DENOMINATOR)
            .expect("interior hunt probability")
            && self
                .population
                .kill(prey_id, self.tick, DeathCause::Predation)
        {
            self.population
                .change_energy(id, credit, self.tick)
                .expect("prey-backed nutrition");
        }
    }
    // Navigation-only fixture adapter. Production uses the common executor below.
    #[cfg(test)]
    fn animal_movement(&mut self, id: OrganismId) {
        self.animal_movement_observed(id, |_, _, _| {});
    }
    // The callback observes the actual executor after each paid step. Production
    // supplies a no-op; tests verify intermediate cache/liveness invariants.
    #[cfg(test)]
    fn animal_movement_observed(&mut self, id: OrganismId, observe: impl FnMut(&Self, Cell, Cell)) {
        let animal = self.population.get(id).expect("living animal action");
        let origin = animal.position();
        let food = match animal.kind() {
            Kind::Herbivore => Kind::Plant,
            Kind::Carnivore => Kind::Herbivore,
            Kind::Plant => unreachable!("plant cannot navigate"),
        };
        let topology = self.world.topology;
        let target = self
            .population
            .sense(id)
            .expect("animal senses")
            .into_iter()
            .filter_map(|other| self.population.get(other))
            .filter(|o| o.kind() == food)
            .min_by_key(|o| (topology.distance(origin, o.position()), o.id()))
            .map(|o| o.position());
        self.move_toward_observed(id, target, 0, observe);
    }
    fn move_toward_observed(
        &mut self,
        id: OrganismId,
        target: Option<Cell>,
        stop_radius: usize,
        mut observe: impl FnMut(&Self, Cell, Cell),
    ) {
        let traits = self.population.get(id).expect("living mover").traits();
        let topology = self.world.topology;
        let cost = step_cost(traits, self.config.animals());
        for _ in 0..traits.speed() {
            let Some(animal) = self.population.get(id) else {
                break;
            };
            let from = animal.position();
            if target.is_some_and(|to| topology.distance(from, to) <= stop_radius)
                || animal.energy() < cost
            {
                break;
            }
            let destination = match target {
                Some(to) => next_toward(topology, from, to),
                None => wander_step(topology, from, &mut self.rng),
            };
            let Some(to) = destination else {
                break;
            };
            self.population
                .move_one_step(id, to)
                .expect("adjacent animal step");
            self.population
                .change_energy(id, -cost, self.tick)
                .expect("finite paid animal step");
            observe(self, from, to);
        }
    }
    pub(crate) fn queue_birth(&mut self, request: BirthRequest) -> Result<(), PopulationError> {
        self.population
            .queue_birth(request, self.config.genetics(), &mut self.rng)
    }
    fn reproduction(&mut self) {
        self.plant_reproduction();
        self.animal_reproduction(Kind::Herbivore);
        self.animal_reproduction(Kind::Carnivore);
    }
    fn animal_reproduction(&mut self, kind: Kind) {
        use crate::ecology::reproduction::*;
        assert_ne!(kind, Kind::Plant);
        let cost = self.config.animals().reproduction_energy();
        let cooldown = self.config.animals().reproduction_cooldown();
        let mut attempted = BTreeSet::new();
        let tick = self.tick;
        let eligible = |o: &crate::organism::Organism| {
            mature(o.age(), o.traits())
                && ready(o.last_reproduction_tick(), tick, cooldown)
                && birth_energy(o.energy(), o.energy(), cost).is_some()
        };
        for id in self.population.phase_ids(kind) {
            if attempted.contains(&id) {
                continue;
            }
            let Some(parent) = self.population.get(id).filter(|o| eligible(o)) else {
                continue;
            };
            let origin = parent.position();
            let mate = self
                .population
                .nearby(origin, 1, Some(kind))
                .into_iter()
                .filter(|other| *other != id && !attempted.contains(other))
                .filter_map(|other| {
                    let o = self.population.get(other)?;
                    (eligible(o)
                        && compatible(parent.genome(), o.genome())
                        && birth_energy(parent.energy(), o.energy(), cost).is_some())
                    .then_some((self.world.topology.distance(origin, o.position()), other))
                })
                .min()
                .map(|(_, other)| other);
            let Some(mate) = mate else {
                continue;
            };
            let other = self.population.get(mate).unwrap();
            let numerator = fertility_numerator(parent.genome(), other.genome());
            let position = if id < mate { origin } else { other.position() };
            attempted.insert(id);
            attempted.insert(mate);
            if !self
                .rng
                .chance(numerator, FERTILITY_DENOMINATOR)
                .expect("valid fertility product")
            {
                continue;
            }
            match self.queue_birth(BirthRequest {
                kind,
                position,
                energy: cost,
                health: 10.,
                parents: vec![id, mate],
                phase: BirthPhase::Reproduction,
            }) {
                Ok(()) => {
                    for parent in [id, mate] {
                        self.population
                            .change_energy(parent, -cost, self.tick)
                            .expect("validated paid animal birth");
                    }
                    self.population
                        .record_reproduction_pair([id, mate], self.tick)
                        .expect("validated living animal pair");
                }
                Err(PopulationError::IdExhausted | PopulationError::GenerationOverflow) => {}
                Err(error) => panic!("animal birth invariant: {error}"),
            }
        }
    }
    fn plant_reproduction(&mut self) {
        let cost = self.config.plants().reproduction_energy();
        let radius = self.config.plants().dispersal_radius() as usize;
        let mut reserved = BTreeSet::new();
        for id in self.population.phase_ids(Kind::Plant) {
            let Some(parent) = self.population.get(id) else {
                continue;
            };
            let Some(energy) = child_energy(parent.energy(), cost) else {
                continue;
            };
            let fertility = parent.genome().alleles()[4] as u64;
            let origin = parent.position();
            if !self.rng.chance(fertility, 65535).expect("valid fertility") {
                continue;
            }
            let cell = sample_dispersal(self.world.topology, origin, radius, &mut self.rng);
            let key = (cell.x(), cell.y());
            if !self
                .population
                .nearby(cell, 0, Some(Kind::Plant))
                .is_empty()
                || reserved.contains(&key)
                || self.world.resources.at(cell) < 1.
            {
                continue;
            }
            match self.queue_birth(BirthRequest {
                kind: Kind::Plant,
                position: cell,
                energy,
                health: 10.,
                parents: vec![id],
                phase: BirthPhase::Reproduction,
            }) {
                Ok(()) => {
                    self.population
                        .change_energy(id, -cost, self.tick)
                        .expect("validated paid birth");
                    assert_eq!(self.world.resources.take(cell, 1.), 1.);
                    reserved.insert(key);
                }
                Err(PopulationError::IdExhausted | PopulationError::GenerationOverflow) => {}
                Err(error) => panic!("plant birth invariant: {error}"),
            }
        }
    }
    fn commit(&mut self) {
        self.population.commit(self.tick);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn births_use_the_engine_stream_after_weather_and_replay_exactly() {
        use crate::{
            genome::Genome,
            population::{BirthPhase, BirthRequest},
        };
        for rate in [0, 1_000_000] {
            let config = Config::from_json(&format!(r#"{{"seed":17,"world":{{"width":1,"height":1}},"initial":{{"plants":2,"herbivores":2,"carnivores":2}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":1024}},"plants":{{"reproduction_energy":1001}}}}"#)).unwrap();
            let mut a = Simulation::new(config).unwrap();
            for id in a.population.phase_ids(Kind::Carnivore) {
                a.population.fixture_mut(id).energy = 0.5;
            }
            let mut b = a.clone();
            let mut reference = Rng::from_state(a.rng_state()).unwrap();
            a.advance_one_tick().unwrap();
            b.advance_one_tick().unwrap();
            // Enabled weather consumes two raw draws, in ClimateResources.
            assert!(a.config.climate().weather_amplitude() > 0.);
            reference.next_u64();
            reference.next_u64();
            // Keep genetics fixture parents alive: attacks are unaffordable.
            assert_eq!(reference.state(), a.rng_state());
            for kind in Kind::ALL {
                let parents: Vec<_> = a
                    .population
                    .phase_ids(kind)
                    .into_iter()
                    .take(if kind == Kind::Plant { 1 } else { 2 })
                    .collect();
                let expected = if kind == Kind::Plant {
                    Genome::founder().copy_child(a.config.genetics(), &mut reference)
                } else {
                    Genome::founder().crossover_child(
                        &Genome::founder(),
                        a.config.genetics(),
                        &mut reference,
                    )
                };
                let request = BirthRequest {
                    kind,
                    position: a.world.topology.cell(1, 1),
                    energy: 10.,
                    health: 5.,
                    parents,
                    phase: BirthPhase::Reproduction,
                };
                a.queue_birth(request.clone()).unwrap();
                b.queue_birth(request).unwrap();
                assert_eq!(a.rng_state(), reference.state());
                assert_eq!(a, b);
                let before = a.rng_state();
                a.commit();
                b.commit();
                assert_eq!(a.rng_state(), before);
                assert_eq!(a, b);
                let child = a
                    .population
                    .iter()
                    .find(|o| o.kind() == kind && o.birth_tick() == 1)
                    .unwrap();
                assert_eq!(child.genome(), &expected);
                assert_eq!(child.traits(), expected.traits());
                let observation = a.clone();
                let _ = child.genome().distance(&Genome::founder());
                assert_eq!(a, observation);
            }
        }
    }
    #[test]
    fn walker_observes_spatial_changes_before_commit_without_rng_draws() {
        use crate::{organism::DeathCause, population::BirthPhase};
        let config = Config::from_json(r#"{"seed":42,"world":{"width":7,"height":5},"initial":{"plants":3,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(config).unwrap();
        let ids = sim.population.phase_ids(Kind::Plant);
        let topology = sim.world.topology;
        let destination = topology.cell(3, 0);
        let nursery = topology.cell(-1, -1);
        let rng_before = sim.rng_state();
        let mut visited = vec![];
        sim.walk_kind(Kind::Plant, |s, id| {
            visited.push(id);
            if id == ids[0] {
                s.population.move_one_step(ids[2], destination).unwrap();
                assert!(
                    !s.population
                        .nearby(topology.cell(2, 0), 0, None)
                        .contains(&ids[2])
                );
                assert!(s.population.nearby(destination, 0, None).contains(&ids[2]));
                assert_eq!(s.rng_state(), rng_before);
                s.queue_birth(BirthRequest {
                    kind: Kind::Plant,
                    position: nursery,
                    energy: 10.,
                    health: 1.,
                    parents: vec![id],
                    phase: BirthPhase::Plants,
                })
                .unwrap();
                s.population.kill(id, 1, DeathCause::Injury);
            } else {
                assert!(
                    !s.population
                        .nearby(topology.cell(0, 0), 0, None)
                        .contains(&ids[0])
                );
                assert_eq!(s.population.nearby(destination, 0, None), vec![ids[2]]);
                assert!(s.population.nearby(nursery, 0, None).is_empty());
            }
        });
        assert_eq!(visited, ids);
        let rng_before_commit = sim.rng_state();
        sim.population.commit(1);
        assert_eq!(sim.rng_state(), rng_before_commit);
        assert_eq!(sim.population.nearby(nursery, 0, None).len(), 1);
    }

    #[test]
    fn overflow_is_atomic() {
        let mut sim = Simulation::new(Config::preset("baseline").unwrap()).unwrap();
        sim.tick = u64::MAX - 1;
        assert_eq!(sim.advance_one_tick().unwrap().tick, u64::MAX);
        let before = sim.clone();
        assert_eq!(sim.advance_one_tick(), Err(SimulationError::TickOverflow));
        assert_eq!(sim, before);
    }
    #[test]
    fn real_walker_rechecks_liveness_and_newborns_wait_until_next_tick() {
        use crate::{
            organism::DeathCause,
            population::{BirthPhase, BirthRequest},
        };
        for kind in Kind::ALL {
            let config=Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":3,"herbivores":3,"carnivores":3}}"#).unwrap();
            let mut sim = Simulation::new(config).unwrap();
            let ids = sim.population.phase_ids(kind);
            let first = ids[0];
            let later = ids[2];
            let parents = if kind == Kind::Plant {
                vec![first]
            } else {
                vec![ids[1], first]
            };
            let mut visited = vec![];
            sim.tick = 1;
            sim.walk_kind(kind, |s, id| {
                visited.push(id);
                if id == first {
                    s.queue_birth(BirthRequest {
                        kind,
                        position: s.world.topology.cell(0, 0),
                        energy: 10.,
                        health: 5.,
                        parents: parents.clone(),
                        phase: BirthPhase::Reproduction,
                    })
                    .unwrap();
                    assert!(s.population.kill(later, 1, DeathCause::Predation));
                    assert!(s.population.kill(first, 1, DeathCause::Injury));
                }
            });
            assert_eq!(visited, vec![first, ids[1]]);
            assert!(sim.population.get(later).is_none());
            sim.commit();
            let child = sim
                .population
                .iter()
                .find(|o| o.birth_tick() == 1)
                .unwrap()
                .id();
            assert_eq!(sim.population.get(child).unwrap().age(), 0);
            assert_eq!(sim.population.totals().births.get(kind), 1);
            assert_eq!(sim.population.totals().deaths.get(kind), 2);
            assert_eq!(
                sim.population
                    .death_records()
                    .iter()
                    .map(|d| d.id)
                    .collect::<Vec<_>>(),
                vec![later, first]
            );
            sim.tick += 1;
            sim.walk_kind(kind, |_, _| {});
            sim.commit();
            assert_eq!(sim.population.get(child).unwrap().age(), 1);
            assert_eq!(sim.population.get(ids[1]).unwrap().age(), 2);
        }
    }

    #[test]
    fn lifespan_expiry_prevents_action_for_every_kind() {
        let config = Config::from_json(r#"{"seed":42,"world":{"width":3,"height":2},"initial":{"plants":3,"herbivores":2,"carnivores":1},"plants":{"reproduction_energy":1001},"animals":{"reproduction_energy":1001},"climate":{"season_temperature_amplitude":0,"season_precipitation_amplitude":0,"weather_amplitude":0}}"#).unwrap();
        let mut sim = Simulation::new(config).unwrap();
        for _ in 0..1099 {
            sim.advance_one_tick().unwrap();
        }
        sim.tick = 1100;
        for kind in Kind::ALL {
            sim.walk_kind(kind, |_, _| panic!("expired organism acted"));
        }
        sim.commit();
        assert_eq!(sim.population.iter().count(), 0);
        for kind in Kind::ALL {
            assert_eq!(
                sim.population.totals().initial.get(kind),
                sim.population.totals().deaths.get(kind)
            );
        }
    }
}

#[cfg(test)]
mod plant_tests {
    use super::*;
    use crate::{genome::Genome, temporal_climate::WeatherState};

    fn fixture(count: usize, capacity: f64, regeneration: f64, eta: f64) -> Simulation {
        let config = Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":2,"height":2}},"initial":{{"plants":{count},"herbivores":0,"carnivores":0}},"climate":{{"season_temperature_amplitude":0,"season_precipitation_amplitude":0,"weather_amplitude":1}},"plants":{{"reproduction_energy":1001,"resource_capacity":{capacity},"resource_regeneration":{regeneration},"growth_efficiency":{eta}}}}}"#)).unwrap();
        let mut sim = Simulation::new(config).unwrap();
        for id in sim.population.phase_ids(Kind::Plant) {
            sim.population.change_energy(id, -900., 0).unwrap();
        }
        sim
    }
    // Restore valid persistent weather whose next recurrence yields the requested
    // climate. This controls input, while the actual tick still advances weather,
    // resources, plant actions and Commit with its normal RNG stream.
    fn next_climate(sim: &mut Simulation, temperature: f64, precipitation: f64) {
        let base = sim.world.climate.base_at(sim.world.topology.cell(0, 0));
        let mut reference = sim.rng.clone();
        let mut offsets = [
            temperature - base.temperature(),
            precipitation - base.precipitation(),
        ];
        for offset in &mut offsets {
            let innovation = 2. * ((reference.next_u64() >> 11) as f64 / 9007199254740992.) - 1.;
            *offset = (*offset - 0.25 * innovation) / 0.75;
        }
        let state = WeatherState::new(1, sim.tick, offsets[0], offsets[1]).unwrap();
        sim.world.temporal_climate =
            TemporalClimate::from_state(sim.config.climate().clone(), state).unwrap();
    }
    fn close(a: f64, b: f64) {
        assert!((a - b).abs() < 1e-10, "{a} != {b}");
    }
    fn first(sim: &Simulation) -> OrganismId {
        sim.population.phase_ids(Kind::Plant)[0]
    }

    #[test]
    fn actual_ticks_isolate_cold_and_dry_and_match_current_climate_ledger() {
        let original = fixture(1, 100., 3., 0.5);
        let id = first(&original);
        let mut gains = vec![];
        for (temperature, precipitation) in [(0.5, 0.5), (0., 0.5), (0.5, 0.)] {
            let mut sim = original.clone();
            let cell = sim.population.get(id).unwrap().position();
            sim.world.resources.take(cell, 99.);
            next_climate(&mut sim, temperature, precipitation);
            let mut rng = sim.rng.clone();
            rng.next_u64();
            rng.next_u64();
            sim.advance_one_tick().unwrap();
            assert_eq!(sim.rng_state(), rng.state());
            let current = sim.world.current_climate_at(cell);
            close(current.temperature(), temperature);
            close(current.precipitation(), precipitation);
            let traits = original.population.get(id).unwrap().traits();
            let t = traits.preferred_temperature();
            let p = traits.preferred_moisture();
            let w = traits.climate_tolerance();
            let suitability = (1. - (temperature - t).abs() / w).max(0.)
                * (1. - (precipitation - p).abs() / w).max(0.);
            let supply = 1. + 3. * precipitation;
            let uptake = supply.min(4. * suitability);
            close(sim.world.resources.at(cell), supply - uptake);
            let gain = sim.population.get(id).unwrap().energy() - 100.;
            close(gain, 0.5 * uptake - 0.2 * traits.metabolic_multiplier());
            gains.push(gain);
            let before = sim.clone();
            let _ = sim.world.resources.at(cell);
            let _ = sim.world.current_climate_at(cell);
            assert_eq!(sim, before);
        }
        assert!(gains[0] > 0. && gains[0] > gains[1] && gains[0] > gains[2]);
    }
    #[test]
    fn shared_cell_competition_and_128_tick_energy_budget() {
        let mut isolated = fixture(2, 1., 0., 1.);
        let ids = isolated.population.phase_ids(Kind::Plant);
        let cell = isolated.population.get(ids[0]).unwrap().position();
        let other = isolated.population.get(ids[1]).unwrap().position();
        let mut shared = isolated.clone();
        shared.population.move_one_step(ids[1], cell).unwrap();
        next_climate(&mut isolated, 0.5, 0.5);
        next_climate(&mut shared, 0.5, 0.5);
        isolated.advance_one_tick().unwrap();
        shared.advance_one_tick().unwrap();
        close(shared.world.resources.at(cell), 0.);
        close(shared.world.resources.at(other), 1.);
        let maintenance = 0.2 * Genome::founder().traits().metabolic_multiplier();
        close(
            shared.population.get(ids[0]).unwrap().energy(),
            101. - maintenance,
        );
        close(
            shared.population.get(ids[1]).unwrap().energy(),
            100. - maintenance,
        );
        close(
            isolated.population.get(ids[1]).unwrap().energy(),
            101. - maintenance,
        );
        let mut sim = fixture(2, 0.7, 0.3, 0.5);
        sim.population.move_one_step(ids[1], cell).unwrap();
        let mut inflow = 0.;
        let mut credit = 0.;
        for _ in 0..128 {
            let before_energy: f64 = sim.population.iter().map(|o| o.energy()).sum();
            let before_stock = sim.world.resources.at(cell);
            next_climate(&mut sim, 0.5, 0.5);
            sim.advance_one_tick().unwrap();
            inflow += (0.7 - before_stock).min(0.15);
            let after_energy: f64 = sim.population.iter().map(|o| o.energy()).sum();
            credit += after_energy - before_energy + 2. * maintenance;
            // Independent aggregate energy ledger, including remaining supply.
            close(credit / 0.5 + sim.world.resources.at(cell), 0.7 + inflow);
            assert!(credit <= 0.5 * (0.7 + inflow) + 1e-10);
        }
    }
    #[test]
    fn efficiency_endpoints_headroom_and_finite_tiny_efficiency() {
        for eta in [0., f64::from_bits(1), f64::MIN_POSITIVE, 1.] {
            let mut sim = fixture(1, 100., 0., eta);
            let id = first(&sim);
            sim.population.fixture_mut(id).energy = ENERGY_CAPACITY;
            next_climate(&mut sim, 0.5, 0.5);
            sim.advance_one_tick().unwrap();
            let energy = sim.population.get(id).unwrap().energy();
            assert!(energy.is_finite() && energy <= ENERGY_CAPACITY);
            let used = 100. - sim.world.resources.at(sim.world.topology.cell(0, 0));
            if eta == 0. {
                close(used, 0.);
            }
            if eta == 1. {
                close(energy, ENERGY_CAPACITY);
                close(
                    used,
                    0.2 * Genome::founder().traits().metabolic_multiplier(),
                );
            }
        }
    }
    #[test]
    fn mortality_causes_remove_once_before_uptake_and_conserve() {
        for cause in [
            DeathCause::OldAge,
            DeathCause::Starvation,
            DeathCause::Climate,
        ] {
            let mut sim = fixture(1, 100., 0., 0.5);
            let id = first(&sim);
            let plant = sim.population.fixture_mut(id);
            match cause {
                DeathCause::OldAge => plant.age = plant.traits().lifespan() - 1,
                DeathCause::Starvation => plant.energy = 0.01,
                DeathCause::Climate => plant.health = 0.01,
                _ => unreachable!(),
            }
            next_climate(
                &mut sim,
                if cause == DeathCause::Climate {
                    0.
                } else {
                    0.5
                },
                0.5,
            );
            sim.advance_one_tick().unwrap();
            assert!(sim.population.get(id).is_none());
            assert!(
                sim.population
                    .nearby(sim.world.topology.cell(0, 0), 0, None)
                    .is_empty()
            );
            assert_eq!(sim.population.deaths_by_cause(Kind::Plant, cause), 1);
            assert_eq!(
                sim.population.totals().initial.get(Kind::Plant)
                    - sim.population.totals().deaths.get(Kind::Plant),
                0
            );
            close(sim.world.resources.at(sim.world.topology.cell(0, 0)), 100.);
            sim.advance_one_tick().unwrap();
            assert_eq!(sim.population.death_records().len(), 1);
        }
        // Accumulated climate damage kills despite ample energy; no fixture damage.
        let mut sim = fixture(1, 100., 0., 1.);
        let id = first(&sim);
        for _ in 0..100 {
            next_climate(&mut sim, 0., 0.5);
            sim.advance_one_tick().unwrap();
            if sim.population.get(id).is_none() {
                break;
            }
        }
        assert_eq!(
            sim.population
                .deaths_by_cause(Kind::Plant, DeathCause::Climate),
            1
        );
    }
    #[test]
    fn immutable_dna_controls_actual_growth_tolerance_and_maintenance() {
        for locus in [6, 7, 8, 9] {
            let mut outcomes = vec![];
            for allele in [0, u16::MAX] {
                let mut sim = fixture(1, 100., 0., 1.);
                let id = first(&sim);
                let mut dna = [32768; 12];
                dna[locus] = allele;
                sim.population.fixture_mut(id).genome = Genome::from_alleles(dna);
                let (t, p) = match locus {
                    7 => (0., 0.5),
                    8 => (0.5, 0.),
                    9 => (0.7, 0.5),
                    _ => (0.5, 0.5),
                };
                next_climate(&mut sim, t, p);
                sim.advance_one_tick().unwrap();
                let plant = sim.population.get(id).unwrap();
                assert_eq!(plant.genome().alleles(), &dna);
                outcomes.push((plant.energy(), plant.health()));
            }
            if locus == 9 {
                assert!(outcomes[1].0 > outcomes[0].0 && outcomes[1].1 > outcomes[0].1);
            } else {
                assert!(outcomes[0].0 > outcomes[1].0, "locus {locus}: {outcomes:?}");
            }
        }
    }
}

#[cfg(test)]
mod reproduction_tests {
    use super::*;
    use crate::genome::Genome;
    fn fixture(
        seed: u64,
        w: usize,
        h: usize,
        plants: usize,
        capacity: f64,
        radius: u32,
        rate: u32,
    ) -> Simulation {
        let config=Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{plants},"herbivores":1,"carnivores":0}},"climate":{{"weather_amplitude":0,"season_temperature_amplitude":0,"season_precipitation_amplitude":0}},"plants":{{"resource_capacity":{capacity},"resource_regeneration":0,"growth_efficiency":0,"dispersal_radius":{radius}}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":1}}}}"#)).unwrap();
        let mut s = Simulation::new(config).unwrap();
        // Isolate plant establishment from grazing; this animal expires at upkeep.
        let animal = s.population.phase_ids(Kind::Herbivore)[0];
        s.population.fixture_mut(animal).energy = f64::from_bits(1);
        for id in s.population.phase_ids(Kind::Plant) {
            let mut dna = [32768; 12];
            dna[4] = 65535;
            s.population.fixture_mut(id).genome = Genome::from_alleles(dna);
        }
        s
    }
    fn free_site_fixture(rate: u32) -> Simulation {
        (0..1000)
            .map(|seed| fixture(seed, 3, 2, 1, 10., 3, rate))
            .find(|s| {
                let mut r = s.rng.clone();
                sample_dispersal(
                    s.world.topology,
                    s.population.get(first(s)).unwrap().position(),
                    3,
                    &mut r,
                ) != s.population.get(first(s)).unwrap().position()
            })
            .expect("finite seed search has a free site")
    }
    fn first(s: &Simulation) -> OrganismId {
        s.population.phase_ids(Kind::Plant)[0]
    }
    fn close(a: f64, b: f64) {
        assert!((a - b).abs() < 1e-10, "{a} != {b}");
    }
    fn raw_below(r: &mut Rng, b: u64) -> u64 {
        let threshold = b.wrapping_neg() % b;
        loop {
            let n = r.next_u64();
            if n >= threshold {
                return n % b;
            }
        }
    }
    #[test]
    fn full_ticks_pay_parent_and_site_inherit_mutate_and_cross_all_seams() {
        for (origin, target) in [
            ((0, 0), (6, 0)),
            ((0, 0), (0, 4)),
            ((0, 0), (6, 4)),
            ((6, 4), (0, 4)),
            ((6, 4), (6, 0)),
            ((6, 4), (0, 0)),
        ] {
            for rate in [0, 1_000_000] {
                // Bounded deterministic search, followed by one actual complete tick.
                let mut chosen = None;
                for seed in 0..1000 {
                    let mut s = fixture(seed, 7, 5, 1, 10., 1, rate);
                    let id = first(&s);
                    let t = s.world.topology;
                    s.population
                        .move_one_step(id, t.cell(origin.0, origin.1))
                        .unwrap();
                    let mut reference = s.rng.clone();
                    let dx = raw_below(&mut reference, 3) as i128;
                    let dy = raw_below(&mut reference, 3) as i128;
                    let dest = t.cell(origin.0 - 1 + dx, origin.1 - 1 + dy);
                    if dest != t.cell(target.0, target.1) {
                        continue;
                    }
                    let parent = s.population.get(id).unwrap().clone();
                    let mut dna = *parent.genome().alleles();
                    if rate > 0 {
                        for a in &mut dna {
                            let step = if raw_below(&mut reference, 2) == 0 {
                                -1
                            } else {
                                1
                            };
                            *a = (*a as i32 + step).clamp(0, 65535) as u16;
                        }
                    }
                    s.advance_one_tick().unwrap();
                    let child = s.population.iter().find(|o| o.birth_tick() == 1).unwrap();
                    assert_eq!(child.position(), dest);
                    let ddx = origin.0.abs_diff(target.0) as usize;
                    let ddy = origin.1.abs_diff(target.1) as usize;
                    assert!(ddx.min(7 - ddx).max(ddy.min(5 - ddy)) <= 1);
                    assert_eq!(child.genome().alleles(), &dna);
                    assert_eq!(child.parents(), &[id]);
                    assert_eq!(
                        (child.generation(), child.age(), child.birth_tick()),
                        (1, 0, 1)
                    );
                    assert_eq!((child.energy(), child.health()), (10., 10.));
                    assert_eq!(s.population.get(id).unwrap().genome(), parent.genome());
                    close(
                        s.population.get(id).unwrap().energy(),
                        1000. - 0.2 * parent.traits().metabolic_multiplier() - 20.,
                    );
                    close(s.world.resources.at(dest), 9.);
                    assert_eq!(
                        s.population.nearby(dest, 0, Some(Kind::Plant)),
                        vec![child.id()]
                    );
                    assert_eq!(s.rng, reference);
                    assert_eq!(s.population.totals().births.get(Kind::Plant), 1);
                    let cid = child.id();
                    s.advance_one_tick().unwrap();
                    assert_eq!(s.population.get(cid).unwrap().age(), 1);
                    chosen = Some(s);
                    break;
                }
                assert!(chosen.is_some(), "no seed for {origin:?} {target:?}");
            }
        }
    }
    #[test]
    fn blocked_sites_tiny_worlds_and_resource_threshold_charge_nothing() {
        for (w, h, n, r, c) in [
            (1, 1, 1, 3, 100.),
            (1, 5, 5, 3, 100.),
            (5, 1, 5, 3, 100.),
            (3, 2, 6, 3, 100.),
            (3, 2, 1, 0, 100.),
            (3, 2, 1, 3, 0.5),
        ] {
            let mut s = fixture(42, w, h, n, c, r, 0);
            let before = s
                .population
                .iter()
                .filter(|o| o.kind() == Kind::Plant)
                .map(|o| (o.id(), o.energy(), o.traits().metabolic_multiplier()))
                .collect::<Vec<_>>();
            s.advance_one_tick().unwrap();
            assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
            for (id, e, m) in before {
                close(s.population.get(id).unwrap().energy(), e - 0.2 * m);
            }
            for y in 0..h {
                for x in 0..w {
                    close(
                        s.world
                            .resources
                            .at(s.world.topology.cell(x as i128, y as i128)),
                        c,
                    );
                }
            }
        }
        // Same selected destination, test stock just below / exactly the establishment cost.
        for c in [0., 0.999999, 1.] {
            let mut s = free_site_fixture(0);
            let id = first(&s);
            let mut r = s.rng.clone();
            let dest = sample_dispersal(
                s.world.topology,
                s.population.get(id).unwrap().position(),
                3,
                &mut r,
            );
            assert_ne!(dest, s.population.get(id).unwrap().position());
            s.world.resources.take(dest, 10. - c);
            s.advance_one_tick().unwrap();
            assert_eq!(
                s.population.totals().births.get(Kind::Plant),
                u128::from(c == 1.)
            );
            close(s.world.resources.at(dest), if c == 1. { 0. } else { c });
        }
    }
    #[test]
    fn pending_site_reservation_blocks_second_parent_even_with_surplus_resources() {
        let mut found = false;
        for seed in 0..1000 {
            let mut s = fixture(seed, 3, 1, 2, 100., 3, 0);
            let ids = s.population.phase_ids(Kind::Plant);
            let mut r = s.rng.clone();
            let dest = s.world.topology.cell(2, 0);
            if sample_dispersal(
                s.world.topology,
                s.population.get(ids[0]).unwrap().position(),
                3,
                &mut r,
            ) != dest
            {
                continue;
            }
            if sample_dispersal(
                s.world.topology,
                s.population.get(ids[1]).unwrap().position(),
                3,
                &mut r,
            ) != dest
            {
                continue;
            }
            s.advance_one_tick().unwrap();
            assert_eq!(s.population.totals().births.get(Kind::Plant), 1);
            close(s.world.resources.at(dest), 99.);
            assert_eq!(s.population.nearby(dest, 0, Some(Kind::Plant)).len(), 1);
            for (i, id) in ids.into_iter().enumerate() {
                close(
                    s.population.get(id).unwrap().energy(),
                    1000.
                        - 0.2 * Genome::founder().traits().metabolic_multiplier()
                        - if i == 0 { 20. } else { 0. },
                );
            }
            assert_eq!(s.rng, r);
            found = true;
            break;
        }
        assert!(found);
    }
    #[test]
    fn fertility_energy_and_generation_rejections_have_exact_draw_and_cost_semantics() {
        for fertility in [0, 32768, 65535] {
            for energy in [19., 20., 20.1, 1000.] {
                let mut s = fixture(42, 3, 2, 1, 100., 3, 0);
                let id = first(&s);
                let plant = s.population.fixture_mut(id);
                let mut dna = *plant.genome().alleles();
                dna[4] = fertility;
                plant.genome = Genome::from_alleles(dna);
                plant.energy = energy;
                let mut r = s.rng.clone();
                let post = energy - 0.2 * Genome::founder().traits().metabolic_multiplier();
                let attempt = post > 20.
                    && (fertility == 65535
                        || (fertility > 0 && raw_below(&mut r, 65535) < fertility as u64));
                if attempt {
                    raw_below(&mut r, 3);
                    raw_below(&mut r, 2);
                }
                s.advance_one_tick().unwrap();
                assert_eq!(s.rng, r);
                let births = s.population.totals().births.get(Kind::Plant);
                close(
                    s.population.get(id).unwrap().energy(),
                    post - 20. * births as f64,
                );
            }
        }
        let mut s = free_site_fixture(1_000_000);
        let id = first(&s);
        s.population.fixture_mut(id).generation = u64::MAX;
        let mut r = s.rng.clone();
        raw_below(&mut r, 3);
        raw_below(&mut r, 2);
        s.advance_one_tick().unwrap();
        assert_eq!(s.rng, r);
        assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
        close(
            s.population.get(id).unwrap().energy(),
            1000. - 0.2 * Genome::founder().traits().metabolic_multiplier(),
        );
        for y in 0..2 {
            for x in 0..3 {
                close(s.world.resources.at(s.world.topology.cell(x, y)), 10.);
            }
        }
    }
    #[test]
    fn last_parent_dies_before_reproduction_and_never_reappears() {
        for cause in [
            DeathCause::OldAge,
            DeathCause::Starvation,
            DeathCause::Climate,
        ] {
            let mut s = fixture(42, 3, 2, 1, 100., 3, 0);
            let id = first(&s);
            let p = s.population.fixture_mut(id);
            match cause {
                DeathCause::OldAge => p.age = p.traits().lifespan() - 1,
                DeathCause::Starvation => p.energy = 0.01,
                _ => {
                    p.health = 0.01;
                    let mut dna = *p.genome().alleles();
                    dna[7] = 0;
                    dna[8] = 0;
                    dna[9] = 0;
                    p.genome = Genome::from_alleles(dna);
                }
            }
            // The deliberately narrow zero-optimum genome experiences lethal stress.
            for _ in 0..2200 {
                s.advance_one_tick().unwrap();
            }
            assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
            assert_eq!(s.population.counts().get(Kind::Plant), 0);
            assert_eq!(s.population.deaths_by_cause(Kind::Plant, cause), 1);
        }
    }
    #[test]
    fn exhausted_ids_skip_birth_without_mutation_or_payment() {
        let mut s = free_site_fixture(1_000_000);
        let id = first(&s);
        let mut reference = s.rng.clone();
        raw_below(&mut reference, 3);
        raw_below(&mut reference, 2);
        s.population.fixture_exhaust_ids();
        s.advance_one_tick().unwrap();
        assert_eq!(s.rng, reference);
        assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
        close(
            s.population.get(id).unwrap().energy(),
            1000. - 0.2 * Genome::founder().traits().metabolic_multiplier(),
        );
        for y in 0..2 {
            for x in 0..3 {
                close(s.world.resources.at(s.world.topology.cell(x, y)), 10.);
            }
        }
    }
    #[test]
    fn weather_attempt_and_mutation_share_the_single_engine_stream() {
        let mut saw_birth = false;
        for fertility in [0, 32768, 65535] {
            let s = free_site_fixture(1_000_000);
            let mut value: serde_json::Value =
                serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
            value["climate"]["weather_amplitude"] = serde_json::json!(0.1);
            let mut s = Simulation::new(Config::from_json(&value.to_string()).unwrap()).unwrap();
            let id = first(&s);
            let mut dna = [32768; 12];
            dna[4] = fertility;
            s.population.fixture_mut(id).genome = Genome::from_alleles(dna);
            let mut r = s.rng.clone();
            r.next_u64();
            r.next_u64();
            let attempt = fertility == 65535
                || (fertility > 0 && raw_below(&mut r, 65535) < fertility as u64);
            let mut expected = None;
            if attempt {
                let cell = s
                    .world
                    .topology
                    .cell(raw_below(&mut r, 3) as i128, raw_below(&mut r, 2) as i128);
                if cell != s.population.get(id).unwrap().position() {
                    for a in &mut dna {
                        let step = if raw_below(&mut r, 2) == 0 { -1 } else { 1 };
                        *a = (*a as i32 + step).clamp(0, 65535) as u16;
                    }
                    expected = Some(dna);
                }
            }
            s.advance_one_tick().unwrap();
            assert_eq!(s.rng, r);
            assert_eq!(
                s.population.totals().births.get(Kind::Plant),
                u128::from(expected.is_some())
            );
            if let Some(dna) = expected {
                saw_birth = true;
                assert_eq!(
                    s.population
                        .iter()
                        .find(|o| o.birth_tick() == 1)
                        .unwrap()
                        .genome()
                        .alleles(),
                    &dna
                );
            }
        }
        assert!(
            saw_birth,
            "reference must exercise actual mutation after weather"
        );
    }
    #[test]
    fn production_policy_captures_recursive_lineage_and_survives_later_parent_death() {
        let mut s = free_site_fixture(0);
        let founder = first(&s);
        s.advance_one_tick().unwrap();
        let child = s
            .population
            .iter()
            .find(|o| o.birth_tick() == 1)
            .unwrap()
            .id();
        assert_eq!(s.population.get(child).unwrap().generation(), 1);
        // Supply a controlled existing reserve to isolate recursive policy/lineage.
        s.population.fixture_mut(child).energy = 1000.;
        s.population.kill(founder, 1, DeathCause::Injury);
        s.commit();
        let mut accepted = false;
        for _ in 0..100 {
            s.advance_one_tick().unwrap();
            if let Some(grandchild) = s.population.iter().find(|o| o.parents() == [child]) {
                assert_eq!(grandchild.generation(), 2);
                assert_eq!(grandchild.age(), 0);
                accepted = true;
                break;
            }
        }
        assert!(accepted);
        let mut s = free_site_fixture(0);
        let id = first(&s);
        s.tick = 1;
        s.reproduction(); // Actual policy captures a paid child before Commit.
        s.population.kill(id, 1, DeathCause::Injury);
        s.commit();
        let child = s
            .population
            .iter()
            .find(|o| o.kind() == Kind::Plant)
            .unwrap();
        assert_eq!(child.parents(), [id]);
        assert_eq!(child.generation(), 1);
    }
    #[test]
    fn stacked_founders_and_animal_only_sites_allow_one_new_plant() {
        let mut found = false;
        for seed in 0..1000 {
            let mut s = fixture(seed, 2, 1, 3, 100., 3, 0);
            let ids = s.population.phase_ids(Kind::Plant);
            let home = s.world.topology.cell(0, 0);
            // A full animal remains on the adjacent feeding site; no pursuit step.
            let animal = s.population.phase_ids(Kind::Herbivore)[0];
            s.population.fixture_mut(animal).energy = 1000.;
            // Three stacked plants; herbivore already occupies the other cell.
            s.population.move_one_step(ids[1], home).unwrap();
            s.advance_one_tick().unwrap();
            if s.population.totals().births.get(Kind::Plant) > 0 {
                assert_eq!(s.population.totals().births.get(Kind::Plant), 1);
                assert_eq!(
                    s.population
                        .nearby(s.world.topology.cell(1, 0), 0, None)
                        .len(),
                    2
                );
                found = true;
                break;
            }
        }
        assert!(found);
    }
}

#[cfg(test)]
mod animal_tests {
    use super::*;
    use crate::genome::Genome;

    fn fixture(w: usize, h: usize, p: usize, herb: usize, carn: usize, cost: f64) -> Simulation {
        Simulation::new(Config::from_json(&format!(r#"{{"seed":17,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{p},"herbivores":{herb},"carnivores":{carn}}},"animals":{{"movement_cost":{cost}}},"plants":{{"reproduction_energy":1001}},"climate":{{"weather_amplitude":0}}}}"#)).unwrap()).unwrap()
    }
    fn dna(s: &mut Simulation, id: OrganismId, speed: u16, vision: u16, metabolism: u16) {
        let mut a = [32768; 12];
        a[0] = speed;
        a[5] = vision;
        a[6] = metabolism;
        s.population.fixture_mut(id).genome = Genome::from_alleles(a);
    }
    fn place(s: &mut Simulation, id: OrganismId, to: Cell) {
        while s.population.get(id).unwrap().position() != to {
            let from = s.population.get(id).unwrap().position();
            s.population
                .move_one_step(id, next_toward(s.world.topology, from, to).unwrap())
                .unwrap();
        }
    }
    #[test]
    fn vision_from_dna_matches_unsigned_oracle_at_seams_and_tiny_axes() {
        for (w, h) in [(19, 19), (1, 19), (19, 1), (1, 1)] {
            let mut s = fixture(w, h, w * h, 2, 1, 1.);
            let id = s.population.phase_ids(Kind::Herbivore)[0];
            let t = s.world.topology;
            place(&mut s, id, t.cell(0, 0));
            for allele in [0, 9363, 32768, 65535] {
                dna(&mut s, id, 0, allele, 0);
                let before = s.clone();
                let radius = s.population.get(id).unwrap().traits().vision() as usize;
                let expected: Vec<_> = s
                    .population
                    .iter()
                    .filter(|o| {
                        let dx = o.position().x().abs_diff(0);
                        let dy = o.position().y().abs_diff(0);
                        o.id() != id && dx.min(w - dx).max(dy.min(h - dy)) <= radius
                    })
                    .map(|o| o.id())
                    .collect();
                assert_eq!(s.population.sense(id), Some(expected));
                assert_eq!(s, before);
            }
            let plant = s.population.phase_ids(Kind::Plant)[0];
            assert_eq!(s.population.sense(plant), None);
            s.population.kill(id, 1, DeathCause::Injury);
            assert_eq!(s.population.sense(id), None);
        }
    }
    #[test]
    fn executor_steps_are_adjacent_paid_and_indexed_for_every_speed_and_metabolism() {
        for (allele, speed) in [(0, 1), (21845, 2), (43690, 3), (65535, 4)] {
            for (met, multiplier) in [(0, 0.5), (65535, 2.)] {
                for distance in [1, 4] {
                    let mut s = fixture(13, 11, 1, 1, 0, 2.);
                    let id = s.population.phase_ids(Kind::Herbivore)[0];
                    let t = s.world.topology;
                    let food = s.population.phase_ids(Kind::Plant)[0];
                    dna(&mut s, id, allele, 65535, met);
                    place(&mut s, id, t.cell(0, 0));
                    place(
                        &mut s,
                        food,
                        t.cell(-(distance as i128), -(distance as i128)),
                    );
                    let mut production = s.clone();
                    production.animal_movement(id);
                    let before = s.rng_state();
                    let mut n = 0;
                    s.animal_movement_observed(id, |state, from, to| {
                        n += 1;
                        assert_eq!(state.world.topology.distance(from, to), 1);
                        assert!(!state.population.nearby(from, 0, None).contains(&id));
                        assert!(state.population.nearby(to, 0, None).contains(&id));
                        assert_eq!(
                            state.population.get(id).unwrap().energy(),
                            1000. - n as f64 * 2. * speed as f64 * multiplier
                        );
                    });
                    assert_eq!(
                        production.population.get(id).unwrap().position(),
                        s.population.get(id).unwrap().position()
                    );
                    assert_eq!(
                        production.population.get(id).unwrap().energy(),
                        s.population.get(id).unwrap().energy()
                    );
                    assert_eq!(n, speed.min(distance));
                    assert_eq!(s.rng_state(), before);
                    assert_eq!(
                        s.population.get(id).unwrap().position(),
                        t.cell(-(n as i128), -(n as i128))
                    );
                }
            }
        }
    }
    #[test]
    fn energy_thresholds_zero_max_cost_and_exact_exhaustion_remove_immediately() {
        for cost in [0., 1., 1_000_000.] {
            for targeted in [false, true] {
                for energy in [0.5, 1., 3., 8., 16., 1000.] {
                    let mut s = fixture(9, 9, usize::from(targeted), 1, 0, cost);
                    let id = s.population.phase_ids(Kind::Herbivore)[0];
                    let t = s.world.topology;
                    dna(&mut s, id, 65535, 65535, 65535); // c = cost * 8
                    place(&mut s, id, t.cell(4, 4));
                    s.population.fixture_mut(id).energy = energy;
                    let rng = s.rng_state();
                    let mut n = 0;
                    s.animal_movement_observed(id, |state, from, to| {
                        n += 1;
                        assert!(!state.population.nearby(from, 0, None).contains(&id));
                        assert_eq!(
                            state.population.nearby(to, 0, None).contains(&id),
                            state.population.get(id).is_some()
                        );
                    });
                    let expected_steps = if cost == 0. {
                        4
                    } else {
                        ((energy / (cost * 8.)).floor() as usize).min(4)
                    };
                    assert_eq!(n, expected_steps);
                    let remaining = energy - n as f64 * cost * 8.;
                    if remaining == 0. {
                        assert!(s.population.get(id).is_none());
                    } else {
                        assert_eq!(s.population.get(id).unwrap().energy(), remaining);
                    }
                    if energy < cost * 8. {
                        assert_eq!(n, 0);
                        assert_eq!(s.rng_state(), rng);
                    }
                    if cost == 0. {
                        assert_eq!(n, 4);
                        assert_eq!(s.population.get(id).unwrap().energy(), energy);
                    }
                }
            }
        }
        let mut s = fixture(7, 7, 0, 1, 0, 1.);
        let id = s.population.phase_ids(Kind::Herbivore)[0];
        dna(&mut s, id, 65535, 0, 0);
        s.population.fixture_mut(id).energy = 2.;
        let mut n = 0;
        s.animal_movement_observed(id, |state, _, to| {
            n += 1;
            assert!(state.population.get(id).is_none());
            assert!(!state.population.nearby(to, 0, None).contains(&id));
        });
        assert_eq!(n, 1);
        s.commit();
        assert_eq!(
            s.population
                .deaths_by_cause(Kind::Herbivore, DeathCause::Starvation),
            1
        );
        s.advance_one_tick().unwrap();
        assert_eq!(s.population.totals().deaths.get(Kind::Herbivore), 1);
    }
    #[test]
    fn production_tick_ties_invisible_food_colocation_and_sequential_sensing() {
        let mut s = fixture(11, 11, 2, 2, 1, 1.);
        let t = s.world.topology;
        let plants = s.population.phase_ids(Kind::Plant);
        let herbs = s.population.phase_ids(Kind::Herbivore);
        let carn = s.population.phase_ids(Kind::Carnivore)[0];
        for id in &herbs {
            dna(&mut s, *id, 0, 65535, 0);
            place(&mut s, *id, t.cell(0, 0));
        }
        dna(&mut s, carn, 0, 65535, 0);
        place(&mut s, carn, t.cell(0, 0));
        place(&mut s, plants[0], t.cell(-2, 0));
        place(&mut s, plants[1], t.cell(2, 0));
        s.herbivores();
        s.animal_movement(carn);
        for id in &herbs {
            assert_eq!(s.population.get(*id).unwrap().position(), t.cell(-1, 0));
        }
        // Carnivore acts after both herbivores and sees their new positions.
        assert_eq!(s.population.get(carn).unwrap().position(), t.cell(-1, 0));
        assert_eq!(
            s.population.sense(carn),
            Some(vec![plants[0], plants[1], herbs[0], herbs[1]])
        );
        place(&mut s, plants[0], t.cell(-1, 0));
        let energy = s.population.get(herbs[0]).unwrap().energy();
        let rng = s.rng_state();
        s.animal_movement(herbs[0]);
        assert_eq!(s.population.get(herbs[0]).unwrap().energy(), energy);
        assert_eq!(s.rng_state(), rng);
        // Invisible plants do not turn exploration into pursuit; reference wander draws.
        let mut s = fixture(19, 19, 1, 1, 0, 0.);
        let id = s.population.phase_ids(Kind::Herbivore)[0];
        dna(&mut s, id, 0, 0, 0);
        let t = s.world.topology;
        place(&mut s, id, t.cell(8, 8));
        let mut r = s.rng.clone();
        let expected = wander_step(t, t.cell(8, 8), &mut r).unwrap();
        s.advance_one_tick().unwrap();
        assert_eq!(s.rng, r);
        assert_eq!(s.population.get(id).unwrap().position(), expected);
    }
    #[test]
    fn exploration_every_speed_matches_reference_steps_and_real_ticks() {
        for (allele, speed) in [(0, 1), (21845, 2), (43690, 3), (65535, 4)] {
            let mut s = fixture(3, 7, 0, 1, 0, 1.);
            let id = s.population.phase_ids(Kind::Herbivore)[0];
            dna(&mut s, id, allele, 0, 0);
            let mut production = s.clone();
            let mut r = s.rng.clone();
            let t = s.world.topology;
            let mut at = s.population.get(id).unwrap().position();
            let mut expected = vec![];
            for _ in 0..speed {
                at = wander_step(t, at, &mut r).unwrap();
                expected.push(at);
            }
            let mut actual = vec![];
            s.animal_movement_observed(id, |state, from, to| {
                actual.push(to);
                assert_eq!(state.world.topology.distance(from, to), 1);
                assert!(!state.population.nearby(from, 0, None).contains(&id));
                assert_eq!(state.population.nearby(to, 0, None), vec![id]);
            });
            assert_eq!(actual, expected);
            assert_eq!(s.rng, r);
            assert_eq!(
                s.population.get(id).unwrap().energy(),
                1000. - (speed * speed) as f64 * 0.5
            );
            production.advance_one_tick().unwrap();
            assert_eq!(production.population.get(id).unwrap().position(), at);
            assert_eq!(
                production.population.get(id).unwrap().energy(),
                s.population.get(id).unwrap().energy()
                    - maintenance(
                        s.population.get(id).unwrap().traits(),
                        s.config.animals(),
                        production
                            .world
                            .current_climate_at(t.cell(0, 0))
                            .temperature()
                    )
            );
            assert_eq!(production.rng, r);
        }
    }
    #[test]
    fn weather_then_both_animal_walkers_then_plant_reproduction_share_stream() {
        let mut s = fixture(19, 19, 1, 1, 1, 0.);
        // This draw-order fixture explicitly exercises a hungry predator.
        for id in s.population.phase_ids(Kind::Carnivore) {
            s.population.fixture_mut(id).energy = 100.;
        }
        let t = s.world.topology;
        let herb = s.population.phase_ids(Kind::Herbivore)[0];
        let carn = s.population.phase_ids(Kind::Carnivore)[0];
        dna(&mut s, herb, 0, 0, 0);
        dna(&mut s, carn, 0, 0, 0);
        place(&mut s, herb, t.cell(6, 6));
        place(&mut s, carn, t.cell(12, 12));
        // Enable actual weather and reproduction, preserving initial fixture state.
        let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
        v["climate"]["weather_amplitude"] = serde_json::json!(0.1);
        v["plants"]["reproduction_energy"] = serde_json::json!(100);
        v["genetics"]["mutation_per_million"] = serde_json::json!(0);
        s.config = Config::from_json(&v.to_string()).unwrap();
        s.world.temporal_climate = TemporalClimate::new(s.config.climate().clone());
        let plant = s.population.phase_ids(Kind::Plant)[0];
        let mut alleles = *s.population.get(plant).unwrap().genome().alleles();
        alleles[4] = 65535;
        s.population.fixture_mut(plant).genome = Genome::from_alleles(alleles);
        let mut r = s.rng.clone();
        r.next_u64();
        r.next_u64();
        let h = wander_step(t, t.cell(6, 6), &mut r).unwrap();
        let c = wander_step(t, t.cell(12, 12), &mut r).unwrap();
        sample_dispersal(
            t,
            t.cell(0, 0),
            s.config.plants().dispersal_radius() as usize,
            &mut r,
        );
        s.advance_one_tick().unwrap();
        assert_eq!(s.rng, r);
        assert_eq!(s.population.get(herb).unwrap().position(), h);
        assert_eq!(s.population.get(carn).unwrap().position(), c);
    }
}

#[cfg(test)]
mod herbivore_tests;

#[cfg(test)]
mod carnivore_tests;

#[cfg(test)]
mod animal_reproduction_tests;

#[cfg(test)]
mod species_tests;

impl Simulation {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.bytes(b"EVOSIM-STATE")?;
        w.u32(crate::canonical::STATE_SCHEMA)?;
        for (name, version) in [
            ("scheduler", 1),
            ("base climate", crate::climate::CLIMATE_MODEL_VERSION),
            (
                "temporal climate",
                crate::temporal_climate::TEMPORAL_CLIMATE_MODEL_VERSION,
            ),
            ("resource", crate::resources::RESOURCE_MODEL_VERSION),
            ("genome", crate::genome::GENOME_VERSION),
            ("traits", 1),
            ("species", crate::species::SPECIES_MODEL_VERSION),
            ("plant physiology", 1),
            ("plant reproduction", 1),
            ("animal navigation", 1),
            ("grazing", 1),
            ("hunting", HUNTING_MODEL_VERSION),
            ("mating", 1),
        ] {
            w.string(name)?;
            w.u32(version)?;
        }
        self.config.write_canonical(w)?;
        w.u64(self.tick)?;
        self.rng.state().write_canonical(w)?;
        self.world.topology.write_canonical(w)?;
        self.world.climate.write_canonical(w)?;
        self.world.temporal_climate.write_canonical(w)?;
        self.world.resources.write_canonical(w)?;
        self.population.write_canonical(w)
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let base = Simulation::new(Config::default()).unwrap();
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut Simulation| {
            v.tick += 1;
        });
        changed!(|v: &mut Simulation| {
            v.config = v.config.with_seed(crate::config::Seed::from_i64(-1));
        });

        for index in 0..4 {
            changed!(|v: &mut Simulation| {
                let mut state = v.rng.state();
                state.words[index] ^= 1;
                v.rng = Rng::from_state(state).unwrap();
            });
        }
    }
}

impl Simulation {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        use crate::canonical::require;
        require(r.bytes(12)? == b"EVOSIM-STATE", "invalid state magic")?;
        require(
            r.u32()? == crate::canonical::STATE_SCHEMA,
            "unsupported state schema",
        )?;
        for (name, version) in [
            ("scheduler", 1),
            ("base climate", crate::climate::CLIMATE_MODEL_VERSION),
            (
                "temporal climate",
                crate::temporal_climate::TEMPORAL_CLIMATE_MODEL_VERSION,
            ),
            ("resource", crate::resources::RESOURCE_MODEL_VERSION),
            ("genome", crate::genome::GENOME_VERSION),
            ("traits", 1),
            ("species", crate::species::SPECIES_MODEL_VERSION),
            ("plant physiology", 1),
            ("plant reproduction", 1),
            ("animal navigation", 1),
            ("grazing", 1),
            ("hunting", HUNTING_MODEL_VERSION),
            ("mating", 1),
        ] {
            require(
                r.string()? == name && r.u32()? == version,
                "unsupported state model",
            )?;
        }
        let config = Config::read_canonical(r)?;
        let tick = r.u64()?;
        let rng = Rng::read_canonical(r)?;
        let topology = Topology::read_canonical(r)?;
        require(
            topology.width() == config.world().width()
                && topology.height() == config.world().height(),
            "world dimensions mismatch",
        )?;
        let climate = Climate::read_canonical(r, topology)?;
        let temporal_climate = TemporalClimate::read_canonical(r, config.climate(), tick)?;
        let resources =
            ResourceField::read_canonical(r, topology, config.plants().resource_capacity())?;
        let population = Population::read_canonical(r, topology, config.initial(), tick)?;
        Ok(Self {
            config,
            tick,
            rng,
            world: World {
                topology,
                climate,
                temporal_climate,
                resources,
            },
            population,
        })
    }
}

#[cfg(test)]
mod checkpoint_validation_tests {
    use super::*;
    use crate::persistence::{checkpoint_bytes, from_checkpoint_bytes};
    #[test]
    fn checksummed_semantically_invalid_states_are_rejected() {
        let base=Simulation::new(Config::from_json(r#"{"seed":42,"world":{"width":2,"height":2},"initial":{"plants":2,"herbivores":2,"carnivores":1}}"#).unwrap()).unwrap();
        let reject = |s: &Simulation| {
            let bytes = checkpoint_bytes(s).unwrap();
            assert!(from_checkpoint_bytes(&bytes).is_err());
        };
        let id = OrganismId(1);
        macro_rules! invalid {
            ($field:ident,$value:expr) => {{
                let mut s = base.clone();
                s.population.fixture_mut(id).$field = $value;
                reject(&s);
            }};
        }
        invalid!(id, OrganismId(0));
        invalid!(species_id, crate::organism::SpeciesId(999));
        invalid!(age, 1);
        invalid!(birth_tick, 1);
        invalid!(energy, f64::NAN);
        invalid!(health, f64::INFINITY);
        invalid!(energy, -1.);
        invalid!(health, 1000.);
        invalid!(position, Topology::new(4, 4).unwrap().cell(3, 3));
        invalid!(generation, 1);
        invalid!(parents, vec![OrganismId(1)]);
        invalid!(last_reproduction_tick, Some(0));
        let mut s = base.clone();
        s.tick = 1;
        reject(&s);
        let mut s = base.clone();
        s.world.climate = Climate::new(Topology::new(3, 3).unwrap());
        reject(&s);
        let mut s = base.clone();
        s.world.temporal_climate = TemporalClimate::from_state(
            s.config.climate().clone(),
            crate::temporal_climate::WeatherState::new(1, 1, 0., 0.).unwrap(),
        )
        .unwrap();
        reject(&s);
        let mut s = base.clone();
        s.world.resources =
            ResourceField::new(Topology::new(1, 1).unwrap(), s.config.plants()).unwrap();
        reject(&s);
    }
}

use std::{env, io, process::ExitCode};

fn main() -> ExitCode {
    // Reject non-Unicode arguments without panicking.
    let args: Result<Vec<_>, _> = env::args_os()
        .skip(1)
        .map(|arg| arg.into_string())
        .collect();
    let Ok(args) = args else {
        eprintln!("evosim: arguments must be valid Unicode");
        return ExitCode::from(2);
    };
    match evosim::cli::dispatch(&args, &mut io::stdout().lock(), &mut io::stderr().lock()) {
        Ok(status) => ExitCode::from(status),
        Err(error) => {
            eprintln!("evosim: {error}");
            ExitCode::from(2)
        }
    }
}

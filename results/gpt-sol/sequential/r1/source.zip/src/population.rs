//! Deterministic living storage and internal lifecycle transactions (ADR-007).
//! No public spawn, mutable record access or autonomous reproduction is exposed.
use crate::{
    config::{GeneticsConfig, InitialConfig},
    genome::Genome,
    organism::{DeathCause, ENERGY_CAPACITY, Kind, Organism, OrganismId},
    rng::Rng,
    spatial::SpatialIndex,
    species::{SpeciesId, SpeciesRegistry},
    topology::{Cell, Topology},
};
use std::{collections::BTreeMap, error::Error, fmt};

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct Counts([u128; 3]);
impl Counts {
    pub fn get(self, kind: Kind) -> u128 {
        self.0[kind.index()]
    }
    pub fn plants(self) -> u128 {
        self.get(Kind::Plant)
    }
    pub fn herbivores(self) -> u128 {
        self.get(Kind::Herbivore)
    }
    pub fn carnivores(self) -> u128 {
        self.get(Kind::Carnivore)
    }
}
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct Totals {
    pub initial: Counts,
    pub births: Counts,
    pub deaths: Counts,
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct DeathRecord {
    pub id: OrganismId,
    pub kind: Kind,
    pub tick: u64,
    pub cause: DeathCause,
}
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PopulationError {
    IdExhausted,
    InvalidVitals,
    NonfiniteDelta,
    MissingOrganism,
    InvalidParents,
    GenerationOverflow,
    SpatialAllocation,
    NonAdjacentMove,
}
impl fmt::Display for PopulationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::IdExhausted => "organism ID capacity exhausted",
            Self::InvalidVitals => "vitals must be finite, positive and within capacity",
            Self::NonfiniteDelta => "vital change must be finite",
            Self::MissingOrganism => "organism is not living",
            Self::InvalidParents => "invalid parent arity, identity or kind",
            Self::SpatialAllocation => "cannot allocate dense spatial buckets",
            Self::NonAdjacentMove => "movement destination must be within one cell",
            Self::GenerationOverflow => "generation capacity exhausted",
        })
    }
}
impl Error for PopulationError {}

/// Ordering of accepted births, independent of the simulation dispatcher type.
#[allow(dead_code)] // Called by future ecological stages.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub(crate) enum BirthPhase {
    Plants,
    Herbivores,
    Carnivores,
    Reproduction,
}

#[derive(Clone, Debug, PartialEq)]
pub(crate) struct BirthRequest {
    pub kind: Kind,
    pub position: Cell,
    pub energy: f64,
    pub health: f64,
    pub parents: Vec<OrganismId>,
    pub phase: BirthPhase,
}
#[derive(Clone, Debug, PartialEq)]
struct PendingBirth {
    request: BirthRequest,
    genome: Genome,
    generation: u64,
    sequence: u128,
    parent_species: SpeciesId,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Population {
    topology: Topology,
    spatial: SpatialIndex,
    living: BTreeMap<OrganismId, Organism>,
    species: SpeciesRegistry,
    next_id: Option<u64>,
    counts: Counts,
    totals: Totals,
    cause_totals: [[u128; 5]; 3],
    death_records: Vec<DeathRecord>,
    pending_deaths: Vec<DeathRecord>,
    pending_births: Vec<PendingBirth>,
    request_sequence: u128,
}
impl Population {
    pub(crate) fn initialize(
        topology: Topology,
        initial: &InitialConfig,
    ) -> Result<Self, PopulationError> {
        let sizes = [initial.plants(), initial.herbivores(), initial.carnivores()];
        let total: u128 = sizes.iter().map(|&n| n as u128).sum();
        if total > u64::MAX as u128 {
            return Err(PopulationError::IdExhausted);
        }
        let mut p = Self {
            topology,
            spatial: SpatialIndex::new(topology).map_err(|_| PopulationError::SpatialAllocation)?,
            living: BTreeMap::new(),
            species: SpeciesRegistry::new(),
            next_id: Some(1),
            counts: Counts::default(),
            totals: Totals::default(),
            cause_totals: [[0; 5]; 3],
            death_records: vec![],
            pending_deaths: vec![],
            pending_births: vec![],
            request_sequence: 0,
        };
        let genome = Genome::founder();
        let traits = genome.traits();
        let mut ordinal = 0usize;
        for (kind, size) in Kind::ALL.into_iter().zip(sizes) {
            for _ in 0..size {
                let index = ordinal % topology.area();
                let id = p.allocate();
                let species_id = p.species.assign(kind, genome, id, None, 0);
                p.living.insert(
                    id,
                    Organism {
                        id,
                        kind,
                        species_id,
                        position: topology.cell(
                            (index % topology.width()) as i128,
                            (index / topology.width()) as i128,
                        ),
                        age: 0,
                        energy: ENERGY_CAPACITY,
                        health: traits.max_health(),
                        genome,
                        parents: vec![],
                        generation: 0,
                        birth_tick: 0,
                        last_reproduction_tick: None,
                    },
                );
                p.spatial.insert(id, kind, p.living[&id].position);
                p.counts.0[kind.index()] += 1;
                ordinal += 1;
            }
        }
        p.totals.initial = p.counts;
        Ok(p)
    }
    fn allocate(&mut self) -> OrganismId {
        let id = self.next_id.expect("validated ID reservation");
        self.next_id = id.checked_add(1);
        OrganismId(id)
    }
    #[cfg(test)]
    pub(crate) fn fixture_exhaust_ids(&mut self) {
        self.next_id = None;
    }
    #[cfg(test)]
    pub(crate) fn fixture_mut(&mut self, id: OrganismId) -> &mut Organism {
        self.living.get_mut(&id).unwrap()
    }
    /// Establish coherent controlled founders before a test fixture starts ticking.
    #[cfg(test)]
    pub(crate) fn fixture_species_from_genomes(&mut self) {
        assert!(self.pending_births.is_empty() && self.pending_deaths.is_empty());
        self.species = SpeciesRegistry::new();
        for o in self.living.values_mut() {
            assert_eq!(o.birth_tick, 0);
            o.species_id = self.species.assign(o.kind, o.genome, o.id, None, 0);
        }
    }
    pub fn get(&self, id: OrganismId) -> Option<&Organism> {
        self.living.get(&id)
    }
    pub fn iter(&self) -> impl DoubleEndedIterator<Item = &Organism> {
        self.living.values()
    }
    /// Inclusive toroidal Chebyshev lookup, ascending IDs, including self.
    /// Foreign cells are normalized. Queries never mutate records or the RNG.
    pub fn nearby(&self, center: Cell, radius: usize, kind: Option<Kind>) -> Vec<OrganismId> {
        self.spatial.query(center, radius, kind)
    }
    /// Animal perception: inclusive inherited vision, all kinds, excluding self.
    /// Missing observers and plants cannot sense. No state or RNG is changed.
    pub fn sense(&self, observer: OrganismId) -> Option<Vec<OrganismId>> {
        let animal = self.get(observer)?;
        if animal.kind() == Kind::Plant {
            return None;
        }
        Some(
            self.nearby(animal.position(), animal.traits().vision() as usize, None)
                .into_iter()
                .filter(|id| *id != observer)
                .collect(),
        )
    }
    /// Adjacent relocation primitive; Simulation selects and pays for animal steps.
    pub(crate) fn move_one_step(
        &mut self,
        id: OrganismId,
        destination: Cell,
    ) -> Result<(), PopulationError> {
        let destination = self
            .topology
            .cell(destination.x() as i128, destination.y() as i128);
        let o = self
            .living
            .get_mut(&id)
            .ok_or(PopulationError::MissingOrganism)?;
        if self.topology.distance(o.position, destination) > 1 {
            return Err(PopulationError::NonAdjacentMove);
        }
        self.spatial.relocate(id, o.kind, o.position, destination);
        o.position = destination;
        Ok(())
    }
    pub fn species(&self) -> &SpeciesRegistry {
        &self.species
    }
    pub fn counts(&self) -> Counts {
        self.counts
    }
    pub fn totals(&self) -> Totals {
        self.totals
    }
    pub fn death_records(&self) -> &[DeathRecord] {
        &self.death_records
    }
    pub fn deaths_by_cause(&self, kind: Kind, cause: DeathCause) -> u128 {
        self.cause_totals[kind.index()][cause.index()]
    }
    pub(crate) fn phase_ids(&self, kind: Kind) -> Vec<OrganismId> {
        self.iter()
            .filter(|o| o.kind == kind)
            .map(|o| o.id)
            .collect()
    }
    pub(crate) fn kill(&mut self, id: OrganismId, tick: u64, cause: DeathCause) -> bool {
        let Some(o) = self.living.remove(&id) else {
            return false;
        };
        assert!(
            self.spatial.remove(id, o.position),
            "missing spatial occupant"
        );
        self.counts.0[o.kind.index()] -= 1;
        self.species.remove_member(o.species_id);
        self.pending_deaths.push(DeathRecord {
            id,
            kind: o.kind,
            tick,
            cause,
        });
        true
    }
    pub(crate) fn age_before_action(&mut self, id: OrganismId, tick: u64) -> bool {
        let Some(o) = self.living.get_mut(&id) else {
            return false;
        };
        o.age += 1; // A valid living age is below lifespan <= 2000.
        if o.age >= o.traits().lifespan() {
            self.kill(id, tick, DeathCause::OldAge);
            false
        } else {
            true
        }
    }
    /// Validate both parents before writing either authoritative cooldown.
    pub(crate) fn record_reproduction_pair(
        &mut self,
        ids: [OrganismId; 2],
        tick: u64,
    ) -> Result<(), PopulationError> {
        if ids[0] == ids[1] {
            return Err(PopulationError::InvalidParents);
        }
        let a = self.get(ids[0]).ok_or(PopulationError::MissingOrganism)?;
        let b = self.get(ids[1]).ok_or(PopulationError::MissingOrganism)?;
        if a.kind() == Kind::Plant || a.kind() != b.kind() {
            return Err(PopulationError::InvalidParents);
        }
        for id in ids {
            self.living.get_mut(&id).unwrap().last_reproduction_tick = Some(tick);
        }
        Ok(())
    }
    pub(crate) fn change_energy(
        &mut self,
        id: OrganismId,
        delta: f64,
        tick: u64,
    ) -> Result<(), PopulationError> {
        if !delta.is_finite() {
            return Err(PopulationError::NonfiniteDelta);
        }
        let o = self
            .living
            .get_mut(&id)
            .ok_or(PopulationError::MissingOrganism)?;
        o.energy = bounded_change(o.energy, delta, ENERGY_CAPACITY);
        if o.energy == 0. {
            self.kill(id, tick, DeathCause::Starvation);
        }
        Ok(())
    }
    pub(crate) fn change_health(
        &mut self,
        id: OrganismId,
        delta: f64,
        tick: u64,
        cause: Option<DeathCause>,
    ) -> Result<(), PopulationError> {
        if !delta.is_finite() {
            return Err(PopulationError::NonfiniteDelta);
        }
        let o = self
            .living
            .get_mut(&id)
            .ok_or(PopulationError::MissingOrganism)?;
        o.health = bounded_change(o.health, delta, o.traits().max_health());
        if o.health == 0. {
            self.kill(id, tick, cause.unwrap_or(DeathCause::Injury));
        }
        Ok(())
    }
    pub(crate) fn queue_birth(
        &mut self,
        mut r: BirthRequest,
        settings: &GeneticsConfig,
        rng: &mut Rng,
    ) -> Result<(), PopulationError> {
        if !r.energy.is_finite()
            || !r.health.is_finite()
            || r.energy <= 0.
            || r.energy > ENERGY_CAPACITY
            || r.health <= 0.
        {
            return Err(PopulationError::InvalidVitals);
        }
        r.parents.sort_unstable();
        let arity = if r.kind == Kind::Plant { 1 } else { 2 };
        if r.parents.len() != arity || r.parents.windows(2).any(|w| w[0] == w[1]) {
            return Err(PopulationError::InvalidParents);
        }
        let mut generation = 0;
        for id in &r.parents {
            let parent = self.get(*id).ok_or(PopulationError::MissingOrganism)?;
            if parent.kind != r.kind {
                return Err(PopulationError::InvalidParents);
            }
            generation = generation.max(
                parent
                    .generation
                    .checked_add(1)
                    .ok_or(PopulationError::GenerationOverflow)?,
            );
        }
        let remaining = self.next_id.map_or(0, |n| u64::MAX as u128 - n as u128 + 1);
        if self.pending_births.len() as u128 >= remaining {
            return Err(PopulationError::IdExhausted);
        }
        r.position = self
            .topology
            .cell(r.position.x() as i128, r.position.y() as i128);
        let mut staged_rng = rng.clone();
        let first = self.get(r.parents[0]).unwrap().genome();
        let genome = if r.kind == Kind::Plant {
            first.copy_child(settings, &mut staged_rng)
        } else {
            first.crossover_child(
                self.get(r.parents[1]).unwrap().genome(),
                settings,
                &mut staged_rng,
            )
        };
        if r.health > genome.traits().max_health() {
            return Err(PopulationError::InvalidVitals);
        }
        let parent_species = self.get(r.parents[0]).unwrap().species_id;
        *rng = staged_rng;
        self.pending_births.push(PendingBirth {
            request: r,
            genome,
            generation,
            sequence: self.request_sequence,
            parent_species,
        });
        self.request_sequence += 1; // Bounded by the lifetime u64 ID capacity.
        Ok(())
    }
    pub(crate) fn commit(&mut self, tick: u64) {
        self.pending_births.sort_by(|a, b| {
            (a.request.phase, &a.request.parents, a.sequence).cmp(&(
                b.request.phase,
                &b.request.parents,
                b.sequence,
            ))
        });
        for b in std::mem::take(&mut self.pending_births) {
            let id = self.allocate();
            let r = b.request;
            let species_id =
                self.species
                    .assign(r.kind, b.genome, id, Some(b.parent_species), tick);
            self.living.insert(
                id,
                Organism {
                    id,
                    kind: r.kind,
                    species_id,
                    position: r.position,
                    age: 0,
                    energy: r.energy,
                    health: r.health,
                    genome: b.genome,
                    parents: r.parents,
                    generation: b.generation,
                    birth_tick: tick,
                    last_reproduction_tick: None,
                },
            );
            self.spatial.insert(id, r.kind, r.position);
            self.counts.0[r.kind.index()] += 1;
            self.totals.births.0[r.kind.index()] += 1;
        }
        for d in self.pending_deaths.drain(..) {
            self.totals.deaths.0[d.kind.index()] += 1;
            self.cause_totals[d.kind.index()][d.cause.index()] += 1;
            self.death_records.push(d);
        }
        self.species.finalize_extinctions(tick);
    }
}
fn bounded_change(value: f64, delta: f64, cap: f64) -> f64 {
    if delta >= cap - value {
        cap
    } else if delta <= -value {
        0.
    } else {
        value + delta
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::Config, rng::Rng};
    fn queue(p: &mut Population, r: BirthRequest) -> Result<(), PopulationError> {
        let c = Config::preset("baseline").unwrap();
        let mut rng = Rng::from_seed(c.seed());
        let before_rng = rng.state();
        let result = p.queue_birth(r, c.genetics(), &mut rng);
        if result.is_err() {
            assert_eq!(rng.state(), before_rng);
        }
        result
    }
    fn population() -> Population {
        let c = Config::from_json(r#"{"seed":42,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":2,"carnivores":2}}"#).unwrap();
        Population::initialize(Topology::new(3, 2).unwrap(), c.initial()).unwrap()
    }
    fn request(p: &Population, kind: Kind) -> BirthRequest {
        BirthRequest {
            kind,
            position: Topology::new(99, 99).unwrap().cell(98, 98),
            energy: 10.,
            health: 5.,
            parents: p
                .phase_ids(kind)
                .into_iter()
                .take(if kind == Kind::Plant { 1 } else { 2 })
                .collect(),
            phase: BirthPhase::Reproduction,
        }
    }
    fn assert_invariants(p: &Population) {
        for kind in Kind::ALL {
            let pending = p.pending_deaths.iter().filter(|d| d.kind == kind).count() as u128;
            assert_eq!(
                p.totals.initial.get(kind) + p.totals.births.get(kind)
                    - p.totals.deaths.get(kind)
                    - pending,
                p.counts.get(kind)
            );
            assert_eq!(
                p.iter().filter(|o| o.kind == kind).count() as u128,
                p.counts.get(kind)
            );
            assert_eq!(
                DeathCause::ALL
                    .into_iter()
                    .map(|c| p.deaths_by_cause(kind, c))
                    .sum::<u128>(),
                p.totals.deaths.get(kind)
            );
        }
        for o in p.iter() {
            assert!(o.energy > 0. && o.energy <= ENERGY_CAPACITY);
            assert!(o.health > 0. && o.health <= o.traits().max_health());
            assert!(o.age < o.traits().lifespan());
        }
    }
    #[test]
    fn inherited_dna_is_captured_before_parent_death_and_commit_draws_nothing() {
        for rate in [0, 1_000_000] {
            let c = Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":3,"height":2}},"initial":{{"plants":2,"herbivores":2,"carnivores":2}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":1024}}}}"#)).unwrap();
            let mut p = population();
            let mut rng = Rng::from_seed(c.seed());
            for kind in Kind::ALL {
                let r = request(&p, kind);
                for (i, id) in r.parents.iter().enumerate() {
                    let o = p.living.get_mut(id).unwrap();
                    o.genome = Genome::from_alleles([20000 + i as u16 * 20000; 12]);
                    o.health = o.traits().max_health();
                }
                let mut reference = rng.clone();
                let first = p.get(r.parents[0]).unwrap().genome;
                let expected = if kind == Kind::Plant {
                    first.copy_child(c.genetics(), &mut reference)
                } else {
                    first.crossover_child(
                        p.get(r.parents[1]).unwrap().genome(),
                        c.genetics(),
                        &mut reference,
                    )
                };
                p.queue_birth(r.clone(), c.genetics(), &mut rng).unwrap();
                assert_eq!(rng, reference);
                if rate == 0 && kind == Kind::Plant {
                    assert_eq!(expected, first);
                }
                if rate > 0 {
                    assert_ne!(expected, first);
                }
                for id in r.parents {
                    p.kill(id, 1, DeathCause::Injury);
                }
                let before = rng.state();
                p.commit(1);
                assert_eq!(rng.state(), before);
                let child = p
                    .iter()
                    .find(|o| o.kind == kind && o.birth_tick == 1)
                    .unwrap();
                assert_eq!(child.genome(), &expected);
                assert_eq!(child.traits(), expected.traits());
                assert_eq!(child.age(), 0);
                assert_invariants(&p);
            }
        }
    }
    #[test]
    fn post_mutation_vital_rejection_rolls_back_population_and_rng() {
        let c = Config::from_json(r#"{"seed":42,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":2,"carnivores":2},"genetics":{"mutation_per_million":1000000,"mutation_max_step":1}}"#).unwrap();
        let mut p = population();
        let mut rng = Rng::from_seed(c.seed());
        for kind in Kind::ALL {
            let mut r = request(&p, kind);
            for id in &r.parents {
                let o = p.living.get_mut(id).unwrap();
                o.genome = Genome::from_alleles([0; 12]);
                o.health = o.traits().max_health();
            }
            r.health = 20.; // Legal global health, above every possible child's max.
            let before = p.clone();
            let before_rng = rng.clone();
            assert_eq!(
                p.queue_birth(r, c.genetics(), &mut rng),
                Err(PopulationError::InvalidVitals)
            );
            assert_eq!(p, before);
            assert_eq!(rng, before_rng);
        }
    }
    #[test]
    fn bounded_vitals_first_cause_and_no_resurrection() {
        let mut p = population();
        for kind in Kind::ALL {
            let ids = p.phase_ids(kind);
            let a = ids[0];
            let b = ids[1];
            for bad in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
                let before = p.clone();
                assert_eq!(
                    p.change_energy(a, bad, 1),
                    Err(PopulationError::NonfiniteDelta)
                );
                assert_eq!(
                    p.change_health(a, bad, 1, Some(DeathCause::Injury)),
                    Err(PopulationError::NonfiniteDelta)
                );
                assert_eq!(p, before);
            }
            p.change_energy(a, -999., 1).unwrap();
            assert_eq!(p.get(a).unwrap().energy, 1.);
            p.change_energy(a, f64::MAX, 1).unwrap();
            assert_eq!(p.get(a).unwrap().energy, 1000.);
            p.change_health(a, 1. - Genome::founder().traits().max_health(), 1, None)
                .unwrap();
            assert_eq!(p.get(a).unwrap().health, 1.);
            p.change_health(a, f64::MAX, 1, Some(DeathCause::Injury))
                .unwrap();
            assert_eq!(
                p.get(a).unwrap().health,
                Genome::founder().traits().max_health()
            );
            p.change_energy(a, -f64::MAX, 1).unwrap();
            assert!(p.get(a).is_none());
            assert!(!p.kill(a, 1, DeathCause::Predation));
            assert_eq!(
                p.change_health(a, 20., 1, Some(DeathCause::Injury)),
                Err(PopulationError::MissingOrganism)
            );
            assert_eq!(
                p.change_energy(a, 20., 1),
                Err(PopulationError::MissingOrganism)
            );
            p.change_health(b, -f64::MAX, 1, Some(DeathCause::Predation))
                .unwrap();
            assert!(!p.age_before_action(b, 1));
            assert_invariants(&p);
        }
        p.commit(1);
        assert_invariants(&p);
        assert_eq!(p.death_records().len(), 6);
        for kind in Kind::ALL {
            assert_eq!(p.totals.deaths.get(kind), 2);
            assert_eq!(p.deaths_by_cause(kind, DeathCause::Starvation), 1);
            assert_eq!(p.deaths_by_cause(kind, DeathCause::Predation), 1);
        }
        let before = p.clone();
        p.commit(1);
        assert_eq!(p, before);
    }
    #[test]
    fn ordinary_lethal_health_change_records_injury() {
        let mut p = population();
        let id = p.phase_ids(Kind::Plant)[0];
        p.change_health(id, -f64::MAX, 1, None).unwrap();
        p.commit(1);
        assert_eq!(p.death_records()[0].cause, DeathCause::Injury);
        assert_eq!(p.deaths_by_cause(Kind::Plant, DeathCause::Injury), 1);
        assert_invariants(&p);
    }

    #[test]
    fn accepted_lineage_survives_parent_death_and_normalizes_position() {
        let mut p = population();
        for kind in Kind::ALL {
            let mut r = request(&p, kind);
            r.parents.reverse();
            for (i, id) in r.parents.iter().enumerate() {
                p.living.get_mut(id).unwrap().generation = 3 + i as u64;
            }
            let expected_generation = if kind == Kind::Plant { 4 } else { 5 };
            let mut parents = r.parents.clone();
            parents.sort_unstable();
            queue(&mut p, r.clone()).unwrap();
            for id in &parents {
                assert!(p.kill(*id, 1, DeathCause::Injury));
            }
            let before = p.clone();
            assert_eq!(queue(&mut p, r), Err(PopulationError::MissingOrganism));
            assert_eq!(p, before);
            p.commit(1);
            let child = p
                .iter()
                .filter(|o| o.kind == kind && o.birth_tick == 1)
                .last()
                .unwrap();
            assert_eq!(child.parents, parents);
            assert_eq!(child.generation, expected_generation);
            assert_eq!(child.position, p.topology.cell(98, 98));
            assert_eq!((child.age, child.energy, child.health), (0, 10., 5.));
            assert_eq!(p.totals.births.get(kind), 1);
            assert_invariants(&p);
        }
    }
    #[test]
    fn invalid_requests_are_atomic_including_generation_and_reserved_capacity() {
        let mut p = population();
        let base = request(&p, Kind::Herbivore);
        let mut cases = vec![];
        for parents in [
            vec![],
            vec![OrganismId(3)],
            vec![OrganismId(3), OrganismId(3)],
            vec![OrganismId(1), OrganismId(3)],
            vec![OrganismId(3), OrganismId(99)],
            vec![OrganismId(3), OrganismId(4), OrganismId(5)],
        ] {
            let mut r = base.clone();
            r.parents = parents;
            cases.push(r);
        }
        let mut plant = request(&p, Kind::Plant);
        plant.parents.push(OrganismId(2));
        cases.push(plant);
        for value in [0., -1., 1001., f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let mut r = base.clone();
            r.energy = value;
            cases.push(r);
        }
        for value in [0., -1., 56., f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            let mut r = base.clone();
            r.health = value;
            cases.push(r);
        }
        for r in cases {
            let before = p.clone();
            assert!(queue(&mut p, r).is_err());
            assert_eq!(p, before);
        }
        p.living.get_mut(&OrganismId(3)).unwrap().generation = u64::MAX;
        let before = p.clone();
        assert_eq!(
            queue(&mut p, base.clone()),
            Err(PopulationError::GenerationOverflow)
        );
        assert_eq!(p, before);
        p.living.get_mut(&OrganismId(3)).unwrap().generation = u64::MAX - 1;
        p.next_id = Some(u64::MAX);
        queue(&mut p, base.clone()).unwrap();
        let before = p.clone();
        assert_eq!(
            queue(&mut p, base.clone()),
            Err(PopulationError::IdExhausted)
        );
        assert_eq!(p, before);
        p.commit(1);
        let child = p.get(OrganismId(u64::MAX)).unwrap();
        assert_eq!(child.generation, u64::MAX);
        assert_eq!(p.next_id, None);
        assert!(p.kill(OrganismId(u64::MAX), 2, DeathCause::OldAge));
        p.commit(2);
        let before = p.clone();
        assert_eq!(queue(&mut p, base), Err(PopulationError::IdExhausted));
        assert_eq!(p, before);
    }
    #[test]
    fn commit_order_is_phase_then_sorted_parents_then_sequence() {
        let mut a = population();
        // Reinsert existing records in reverse order: storage history must not affect birth IDs.
        let mut b = a.clone();
        let records: Vec<_> = b.living.values().cloned().rev().collect();
        b.living.clear();
        for o in records {
            b.living.insert(o.id, o);
        }
        for p in [&mut a, &mut b] {
            for (parent, phase, energy) in [
                (2, BirthPhase::Reproduction, 11.),
                (2, BirthPhase::Plants, 12.),
                (1, BirthPhase::Plants, 13.),
                (1, BirthPhase::Plants, 14.),
            ] {
                let mut r = request(p, Kind::Plant);
                r.parents = vec![OrganismId(parent)];
                r.phase = phase;
                r.energy = energy;
                queue(p, r).unwrap();
            }
            p.commit(7);
        }
        assert_eq!(a, b);
        assert_eq!(
            a.iter()
                .skip(6)
                .map(|o| (o.id.value(), o.energy))
                .collect::<Vec<_>>(),
            vec![(7, 13.), (8, 14.), (9, 12.), (10, 11.)]
        );
    }
    #[test]
    fn repeated_multi_kind_birth_death_cycles_never_reuse_ids() {
        let mut p = population();
        p.kill(OrganismId(2), 0, DeathCause::Injury);
        p.commit(0);
        let mut used: std::collections::BTreeSet<_> = p.iter().map(|o| o.id).collect();
        let mut previous = 6;
        for tick in 1..=12 {
            for (kind, phase) in Kind::ALL.into_iter().zip([
                BirthPhase::Plants,
                BirthPhase::Herbivores,
                BirthPhase::Carnivores,
            ]) {
                // Keep two parents alive for animals; replace both through accepted births.
                let mut r = request(&p, kind);
                r.phase = phase;
                queue(&mut p, r.clone()).unwrap();
                if kind != Kind::Plant {
                    queue(&mut p, r.clone()).unwrap();
                }
                for id in r.parents {
                    assert!(p.kill(id, tick, DeathCause::Injury));
                }
            }
            p.commit(tick);
            for o in p.iter().filter(|o| o.birth_tick == tick) {
                assert!(used.insert(o.id));
                assert!(o.id.value() > previous);
                previous = o.id.value();
                assert_eq!(o.generation, tick);
            }
            assert_invariants(&p);
            for kind in Kind::ALL {
                let arity = if kind == Kind::Plant { 1 } else { 2 };
                assert_eq!(p.totals.births.get(kind), tick as u128 * arity);
                assert_eq!(
                    p.totals.deaths.get(kind),
                    tick as u128 * arity + if kind == Kind::Plant { 1 } else { 0 }
                );
            }
        }
    }

    #[test]
    fn seeded_event_sequences_conserve_bounds_ids_and_replay() {
        for seed in [0, 1, 42, 999] {
            let mut p = population();
            let mut replay = p.clone();
            let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
            let mut seen = std::collections::BTreeSet::new();
            let mut max_id = 0;
            for tick in 1..=256 {
                let choice = rng.next_u64();
                for state in [&mut p, &mut replay] {
                    let ids: Vec<_> = state.iter().map(|o| o.id).collect();
                    if !ids.is_empty() {
                        let id = ids[choice as usize % ids.len()];
                        match choice % 5 {
                            0 => {
                                let r = request(state, Kind::Plant);
                                let _ = queue(state, r);
                            }
                            1 => {
                                state.kill(id, tick, DeathCause::Climate);
                            }
                            2 => {
                                state
                                    .change_energy(
                                        id,
                                        if choice & 8 == 0 { -500. } else { 500. },
                                        tick,
                                    )
                                    .unwrap();
                            }
                            3 => {
                                state
                                    .change_health(id, -10., tick, Some(DeathCause::Injury))
                                    .unwrap();
                            }
                            _ => {
                                state.age_before_action(id, tick);
                            }
                        }
                    }
                    assert_invariants(state);
                    state.commit(tick);
                    assert_invariants(state);
                }
                assert_eq!(p, replay);
                for o in p.iter() {
                    if seen.insert(o.id) {
                        assert!(o.id.value() > max_id);
                        max_id = o.id.value();
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod spatial_tests {
    use super::*;
    use crate::config::{Config, Seed};
    fn make(w: usize, h: usize) -> (Population, Config) {
        let config = Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":12,"herbivores":12,"carnivores":12}}}}"#)).unwrap();
        (
            Population::initialize(Topology::new(w, h).unwrap(), config.initial()).unwrap(),
            config,
        )
    }
    fn check_rebuild(p: &Population) {
        let mut rebuilt = SpatialIndex::new(p.topology).unwrap();
        // Reverse insertion proves canonical bucket order is history-independent.
        for o in p.iter().rev() {
            rebuilt.insert(o.id, o.kind, o.position);
        }
        assert_eq!(p.spatial, rebuilt);
    }
    fn oracle(p: &Population, center: Cell, radius: usize, kind: Option<Kind>) -> Vec<OrganismId> {
        let (w, h) = (p.topology.width(), p.topology.height());
        p.iter()
            .filter(|o| {
                let dx = o.position.x().abs_diff(center.x() % w);
                let dy = o.position.y().abs_diff(center.y() % h);
                dx.min(w - dx).max(dy.min(h - dy)) <= radius && kind.is_none_or(|k| k == o.kind)
            })
            .map(|o| o.id)
            .collect()
    }
    #[test]
    fn randomized_4096_queries_with_real_lifecycle_events_and_rebuilds() {
        let mut comparisons = 0;
        for (w, h) in [
            (1, 1),
            (1, 9),
            (9, 1),
            (2, 2),
            (3, 8),
            (8, 3),
            (17, 12),
            (64, 48),
        ] {
            for seed in [1, 42, 991, 987654] {
                let (mut p, c) = make(w, h);
                let mut rng = Rng::from_seed(&Seed::from_u64(seed));
                let mut genetics_rng = Rng::from_seed(c.seed());
                for step in 0..128 {
                    let ids: Vec<_> = p.iter().map(|o| o.id).collect();
                    if !ids.is_empty() {
                        let id = ids[rng.below(ids.len() as u64).unwrap() as usize];
                        match step % 4 {
                            0 => {
                                let o = p.get(id).unwrap();
                                let dest = p.topology.cell(
                                    o.position.x() as i128 + rng.below(3).unwrap() as i128 - 1,
                                    o.position.y() as i128 + rng.below(3).unwrap() as i128 - 1,
                                );
                                let before = p.clone();
                                p.move_one_step(id, dest).unwrap();
                                let mut expected = before.living[&id].clone();
                                expected.position = dest;
                                assert_eq!(p.living[&id], expected);
                                assert_eq!(p.counts, before.counts);
                                assert_eq!(p.totals, before.totals);
                            }
                            1 => {
                                p.kill(id, step, DeathCause::Predation);
                            }
                            2 => {
                                let kind = p.get(id).unwrap().kind;
                                let parents: Vec<_> = p
                                    .phase_ids(kind)
                                    .into_iter()
                                    .take(if kind == Kind::Plant { 1 } else { 2 })
                                    .collect();
                                if parents.len() == if kind == Kind::Plant { 1 } else { 2 } {
                                    let before = p.spatial.clone();
                                    p.queue_birth(
                                        BirthRequest {
                                            kind,
                                            position: p.topology.cell(
                                                rng.next_u64() as i128,
                                                rng.next_u64() as i128,
                                            ),
                                            energy: 10.,
                                            health: 1.,
                                            parents,
                                            phase: BirthPhase::Reproduction,
                                        },
                                        c.genetics(),
                                        &mut genetics_rng,
                                    )
                                    .unwrap();
                                    assert_eq!(p.spatial, before);
                                }
                            }
                            _ => {
                                p.commit(step);
                            }
                        }
                    }
                    let center = Topology::new(999, 997)
                        .unwrap()
                        .cell(rng.next_u64() as i128, rng.next_u64() as i128);
                    let radius = match step % 8 {
                        0 => 0,
                        1 => 1,
                        2 => usize::MAX,
                        3 => w + h + 100,
                        _ => rng.below(20).unwrap() as usize,
                    };
                    let kind = match step % 4 {
                        0 => None,
                        n => Some(Kind::ALL[n as usize - 1]),
                    };
                    let before = p.clone();
                    let found = p.nearby(center, radius, kind);
                    assert_eq!(
                        found,
                        oracle(&p, center, radius, kind),
                        "world {w}x{h} seed {seed} step {step}"
                    );
                    assert!(found.windows(2).all(|x| x[0] < x[1]));
                    assert_eq!(found, p.nearby(center, radius, kind));
                    assert_eq!(p, before);
                    check_rebuild(&p);
                    comparisons += 1;
                }
                p.commit(129);
                check_rebuild(&p);
            }
        }
        assert_eq!(comparisons, 4096);
    }
    #[test]
    fn seam_moves_noops_and_rejections_are_atomic() {
        let (mut p, _) = make(7, 5);
        let id = p.iter().next().unwrap().id;
        for (x, y) in [(-1, 0), (0, 0), (0, -1), (0, 0), (-1, -1), (0, 0)] {
            let old = p.get(id).unwrap().position;
            let dest = p.topology.cell(x, y);
            let before = p.clone();
            p.move_one_step(id, dest).unwrap();
            assert!(p.nearby(dest, 0, None).contains(&id));
            if old != dest {
                assert!(!p.nearby(old, 0, None).contains(&id));
            }
            let mut expected = before.living[&id].clone();
            expected.position = dest;
            assert_eq!(p.living[&id], expected);
            assert_eq!(p.counts, before.counts);
            assert_eq!(p.totals, before.totals);
            check_rebuild(&p);
        }
        let before = p.clone();
        p.move_one_step(id, p.get(id).unwrap().position).unwrap();
        assert_eq!(p, before);
        assert_eq!(
            p.move_one_step(id, p.topology.cell(3, 2)),
            Err(PopulationError::NonAdjacentMove)
        );
        assert_eq!(p, before);
        assert!(p.kill(id, 1, DeathCause::Injury));
        let before = p.clone();
        assert_eq!(
            p.move_one_step(id, p.topology.cell(0, 0)),
            Err(PopulationError::MissingOrganism)
        );
        assert!(!p.kill(id, 2, DeathCause::Starvation));
        assert_eq!(p, before);
        check_rebuild(&p);
        // Foreign destination normalizes before adjacency validation.
        let other = p.iter().next().unwrap().id;
        let foreign = Topology::new(100, 100).unwrap().cell(99, 99);
        let dest = p.topology.cell(99, 99);
        // Walk to the normalized foreign destination cell-by-cell first.
        while p.get(other).unwrap().position != dest {
            let pos = p.get(other).unwrap().position;
            let d = p.topology.displacement(pos, dest);
            p.move_one_step(
                other,
                p.topology.cell(
                    pos.x() as i128 + d.dx.signum(),
                    pos.y() as i128 + d.dy.signum(),
                ),
            )
            .unwrap();
        }
        let before = p.clone();
        p.move_one_step(other, foreign).unwrap();
        assert_eq!(p, before);
    }
    #[test]
    fn births_wait_for_commit_and_all_death_paths_remove_immediately() {
        for kind in Kind::ALL {
            let (mut p, c) = make(4, 3);
            let ids = p.phase_ids(kind);
            let mut rng = Rng::from_seed(c.seed());
            let dest = p.topology.cell(-1, -1);
            p.queue_birth(
                BirthRequest {
                    kind,
                    position: dest,
                    energy: 10.,
                    health: 1.,
                    parents: ids
                        .iter()
                        .copied()
                        .take(if kind == Kind::Plant { 1 } else { 2 })
                        .collect(),
                    phase: BirthPhase::Reproduction,
                },
                c.genetics(),
                &mut rng,
            )
            .unwrap();
            let before_ids = p.nearby(dest, 0, None);
            p.change_health(ids[0], -f64::MAX, 1, None).unwrap();
            assert!(!p.nearby(dest, usize::MAX, None).contains(&ids[0]));
            p.change_energy(ids[1], -f64::MAX, 1).unwrap();
            assert!(!p.nearby(dest, usize::MAX, None).contains(&ids[1]));
            p.living.get_mut(&ids[2]).unwrap().age = 1099;
            assert!(!p.age_before_action(ids[2], 1));
            assert!(!p.nearby(dest, usize::MAX, None).contains(&ids[2]));
            assert!(
                p.nearby(dest, 0, None)
                    .iter()
                    .all(|id| before_ids.contains(id))
            );
            p.commit(1);
            let child = p.iter().find(|o| o.birth_tick == 1).unwrap();
            assert!(p.nearby(dest, 0, Some(kind)).contains(&child.id));
            assert_eq!(child.age, 0);
            check_rebuild(&p);
        }
    }
}

#[cfg(test)]
mod species_tests;

impl Population {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        if !self.pending_deaths.is_empty() || !self.pending_births.is_empty() {
            return Err(std::io::Error::other(
                "state hash requires a completed tick",
            ));
        }
        self.topology.write_canonical(w)?;
        w.option(self.next_id)?;
        w.u128(self.request_sequence)?;
        for counts in [
            self.counts,
            self.totals.initial,
            self.totals.births,
            self.totals.deaths,
        ] {
            for kind in Kind::ALL {
                w.u128(counts.get(kind))?;
            }
        }
        for counts in self.cause_totals {
            for n in counts {
                w.u128(n)?;
            }
        }
        w.usize(self.living.len())?;
        for o in self.living.values() {
            o.write_canonical(w)?;
        }
        self.species.write_canonical(w)?;
        w.usize(self.death_records.len())?;
        for d in &self.death_records {
            w.u64(d.id.value())?;
            d.kind.write_canonical(w)?;
            w.u64(d.tick)?;
            d.cause.write_canonical(w)?;
        }
        w.usize(self.pending_deaths.len())?;
        w.usize(self.pending_births.len())
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let c = crate::config::Config::default();
        let mut base = Population::initialize(Topology::new(64, 48).unwrap(), c.initial()).unwrap();
        base.kill(OrganismId(1), 1, DeathCause::Climate);
        base.kill(OrganismId(2), 1, DeathCause::Injury);
        base.commit(1);
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut Population| {
            v.topology = Topology::new(48, 64).unwrap();
        });
        changed!(|v: &mut Population| {
            v.next_id = None;
        });
        changed!(|v: &mut Population| {
            v.next_id = Some(v.next_id.unwrap() + 1);
        });
        changed!(|v: &mut Population| {
            v.request_sequence += 1;
        });
        changed!(|v: &mut Population| {
            v.living.pop_first();
        });
        changed!(|v: &mut Population| {
            v.death_records[0].id.0 += 1;
        });
        changed!(|v: &mut Population| {
            v.death_records[0].kind = Kind::Herbivore;
        });
        changed!(|v: &mut Population| {
            v.death_records[0].tick += 1;
        });
        changed!(|v: &mut Population| {
            v.death_records[0].cause = DeathCause::Starvation;
        });
        changed!(|v: &mut Population| {
            v.death_records.reverse();
        });

        for kind in 0..3 {
            changed!(|v: &mut Population| {
                v.counts.0[kind] += 1;
            });
            changed!(|v: &mut Population| {
                v.totals.initial.0[kind] += 1;
            });
            changed!(|v: &mut Population| {
                v.totals.births.0[kind] += 1;
            });
            changed!(|v: &mut Population| {
                v.totals.deaths.0[kind] += 1;
            });
            for cause in 0..5 {
                changed!(|v: &mut Population| {
                    v.cause_totals[kind][cause] += 1;
                });
            }
        }
        let mut rebuilt = base.clone();
        rebuilt.spatial = SpatialIndex::new(base.topology).unwrap();
        for o in base.iter().rev() {
            rebuilt.spatial.insert(o.id, o.kind, o.position);
        }
        assert_eq!(original, collect(|w| rebuilt.write_canonical(w)));
        let mut pending = base.clone();
        pending.kill(OrganismId(3), 2, DeathCause::Injury);
        assert!(
            pending
                .write_canonical(&mut crate::canonical::Encoder(Vec::new()))
                .is_err()
        );
        let mut pending = base.clone();
        let mut rng = Rng::from_seed(c.seed());
        pending
            .queue_birth(
                BirthRequest {
                    kind: Kind::Plant,
                    position: base.topology.cell(0, 0),
                    energy: 10.,
                    health: 1.,
                    parents: vec![OrganismId(3)],
                    phase: BirthPhase::Plants,
                },
                c.genetics(),
                &mut rng,
            )
            .unwrap();
        assert!(
            pending
                .write_canonical(&mut crate::canonical::Encoder(Vec::new()))
                .is_err()
        );
    }
}

impl Population {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        expected: Topology,
        initial: &InitialConfig,
        tick: u64,
    ) -> std::io::Result<Self> {
        use crate::canonical::{invalid, require};
        use std::collections::BTreeSet;
        require(
            Topology::read_canonical(r)? == expected,
            "population topology mismatch",
        )?;
        let next_id = r.option()?;
        let request_sequence = r.u128()?;
        let mut all = [Counts::default(); 4];
        for c in &mut all {
            for v in &mut c.0 {
                *v = r.u128()?;
            }
        }
        let [counts, initial_counts, births, deaths] = all;
        let totals = Totals {
            initial: initial_counts,
            births,
            deaths,
        };
        let mut cause_totals = [[0; 5]; 3];
        for c in &mut cause_totals {
            for v in c {
                *v = r.u128()?;
            }
        }
        let n = r.count(106)?;
        let mut living = BTreeMap::new();
        let mut previous = 0;
        for _ in 0..n {
            let o = Organism::read_canonical(r, expected, tick)?;
            require(o.id.0 > previous, "unordered living IDs")?;
            previous = o.id.0;
            living.insert(o.id, o);
        }
        let species = SpeciesRegistry::read_canonical(r, tick)?;
        let n = r.count(18)?;
        let mut death_records = Vec::new();
        death_records.try_reserve_exact(n).map_err(invalid)?;
        let mut dead_ids = BTreeSet::new();
        let mut observed_deaths = Counts::default();
        let mut observed_causes = [[0; 5]; 3];
        let mut previous_tick = 0;
        for _ in 0..n {
            let d = DeathRecord {
                id: OrganismId(r.u64()?),
                kind: Kind::read_canonical(r)?,
                tick: r.u64()?,
                cause: DeathCause::read_canonical(r)?,
            };
            require(
                d.id.0 > 0 && !living.contains_key(&d.id) && dead_ids.insert(d.id),
                "invalid death ID",
            )?;
            require(
                d.tick > 0 && d.tick >= previous_tick && d.tick <= tick,
                "invalid death chronology",
            )?;
            previous_tick = d.tick;
            observed_deaths.0[d.kind.index()] += 1;
            observed_causes[d.kind.index()][d.cause.index()] += 1;
            death_records.push(d);
        }
        require(
            r.usize()? == 0 && r.usize()? == 0,
            "pending transactions in checkpoint",
        )?;
        require(
            deaths == observed_deaths && cause_totals == observed_causes,
            "death counters mismatch",
        )?;
        let configured = [initial.plants(), initial.herbivores(), initial.carnivores()];
        let mut observed = Counts::default();
        let mut memberships = BTreeMap::<SpeciesId, u128>::new();
        for o in living.values() {
            observed.0[o.kind.index()] += 1;
            let s = species
                .get(o.species_id)
                .ok_or_else(|| invalid("missing member species"))?;
            require(
                s.kind() == o.kind
                    && s.origin_tick() <= o.birth_tick
                    && s.extinction_tick().is_none(),
                "invalid species membership",
            )?;
            *memberships.entry(o.species_id).or_default() += 1;
            for parent in &o.parents {
                require(
                    living.contains_key(parent) || dead_ids.contains(parent),
                    "unallocated parent",
                )?;
                if let Some(p) = living.get(parent) {
                    require(
                        p.kind == o.kind
                            && p.birth_tick < o.birth_tick
                            && p.generation < o.generation,
                        "invalid living parent lineage",
                    )?;
                }
            }
            if !o.parents.is_empty() && o.parents.iter().all(|p| living.contains_key(p)) {
                let max = o
                    .parents
                    .iter()
                    .map(|p| living[p].generation)
                    .max()
                    .unwrap();
                require(
                    max.checked_add(1) == Some(o.generation),
                    "generation mismatch",
                )?;
            }
        }
        let initial_total = initial_counts
            .0
            .iter()
            .try_fold(0u128, |a, b| a.checked_add(*b))
            .ok_or_else(|| invalid("initial overflow"))?;
        let dead_by_id: BTreeMap<_, _> = death_records.iter().map(|d| (d.id, d)).collect();
        let kind_for = |id: OrganismId| {
            living
                .get(&id)
                .map(|o| o.kind)
                .or_else(|| dead_by_id.get(&id).map(|d| d.kind))
        };
        for o in living.values() {
            require(
                (o.id.0 as u128 <= initial_total) == (o.generation == 0),
                "founder allocation mismatch",
            )?;
            for p in &o.parents {
                require(kind_for(*p) == Some(o.kind), "parent kind mismatch")?;
            }
        }
        for s in species.iter() {
            let founder = OrganismId(s.id().0);
            require(kind_for(founder) == Some(s.kind()), "founder kind mismatch")?;
            if let Some(o) = living.get(&founder) {
                require(
                    o.birth_tick == s.origin_tick()
                        && &o.genome == s.founder_genome()
                        && o.species_id == s.id(),
                    "founder record mismatch",
                )?;
            } else if let Some(d) = dead_by_id.get(&founder) {
                require(
                    d.tick >= s.origin_tick(),
                    "founder died before species origin",
                )?;
            }
        }
        require(observed == counts, "living counters mismatch")?;
        let mut allocated = 0u128;
        let mut total_births = 0u128;
        for kind in Kind::ALL {
            let i = kind.index();
            require(
                initial_counts.0[i] == configured[i] as u128,
                "initial counters mismatch",
            )?;
            let made = initial_counts.0[i]
                .checked_add(births.0[i])
                .ok_or_else(|| invalid("counter overflow"))?;
            require(
                made.checked_sub(deaths.0[i]) == Some(counts.0[i]),
                "lifecycle accounting mismatch",
            )?;
            allocated = allocated
                .checked_add(made)
                .ok_or_else(|| invalid("allocation overflow"))?;
            total_births = total_births
                .checked_add(births.0[i])
                .ok_or_else(|| invalid("birth overflow"))?;
        }
        require(
            allocated <= u64::MAX as u128 && request_sequence == total_births,
            "invalid allocation/sequence",
        )?;
        let highest = living
            .keys()
            .map(|id| id.0)
            .chain(dead_ids.iter().map(|id| id.0))
            .max()
            .unwrap_or(0);
        require(
            highest as u128 == allocated
                && living.len() as u128 + dead_ids.len() as u128 == allocated,
            "noncontiguous allocated IDs",
        )?;
        require(next_id == highest.checked_add(1), "invalid next ID")?;
        for s in species.iter() {
            require(
                s.id().0 <= highest
                    && (living.contains_key(&OrganismId(s.id().0))
                        || dead_ids.contains(&OrganismId(s.id().0))),
                "invalid species founder ID",
            )?;
            require(
                s.living_members() == memberships.get(&s.id()).copied().unwrap_or(0),
                "species membership counter mismatch",
            )?;
        }
        let mut spatial = SpatialIndex::new(expected).map_err(invalid)?;
        for o in living.values() {
            spatial.insert(o.id, o.kind, o.position);
        }
        Ok(Self {
            topology: expected,
            spatial,
            living,
            species,
            next_id,
            counts,
            totals,
            cause_totals,
            death_records,
            pending_deaths: vec![],
            pending_births: vec![],
            request_sequence,
        })
    }
}

#[cfg(test)]
mod checkpoint_validation_tests {
    use super::*;
    use crate::canonical::{Decoder, collect};
    #[test]
    fn private_accounting_allocation_and_history_validation() {
        let config = crate::config::Config::default();
        let t = Topology::new(config.world().width(), config.world().height()).unwrap();
        let base = Population::initialize(t, config.initial()).unwrap();
        let reject = |p: &Population| {
            let bytes = collect(|w| p.write_canonical(w));
            assert!(
                Population::read_canonical(&mut Decoder::new(&bytes), t, config.initial(), 0)
                    .is_err()
            );
        };
        let mut p = base.clone();
        p.counts.0[0] += 1;
        reject(&p);
        let mut p = base.clone();
        p.totals.initial.0[0] += 1;
        reject(&p);
        let mut p = base.clone();
        p.totals.births.0[0] += 1;
        reject(&p);
        let mut p = base.clone();
        p.totals.deaths.0[0] += 1;
        reject(&p);
        let mut p = base.clone();
        p.cause_totals[0][0] += 1;
        reject(&p);
        let mut p = base.clone();
        p.next_id = None;
        reject(&p);
        let mut p = base.clone();
        p.next_id = Some(0);
        reject(&p);
        let mut p = base.clone();
        p.request_sequence = 1;
        reject(&p);
        let mut p = base.clone();
        p.death_records.push(DeathRecord {
            id: OrganismId(1),
            kind: Kind::Plant,
            tick: 0,
            cause: DeathCause::OldAge,
        });
        reject(&p);
        // Pending lengths are encoded at the tail of every completed-tick payload.
        let mut bytes = collect(|w| base.write_canonical(w));
        let n = bytes.len();
        bytes[n - 8..].copy_from_slice(&1u64.to_le_bytes());
        assert!(
            Population::read_canonical(&mut Decoder::new(&bytes), t, config.initial(), 0).is_err()
        );
    }
}

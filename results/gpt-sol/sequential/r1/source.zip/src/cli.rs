//! Process-independent command dispatch. Includes observational base-climate export.
use std::io::{self, Write};

mod batch;
mod output;
mod run;
mod runner;
mod ui;

const HELP: &str = "Evolution Simulation\n\nUsage: evosim <command>\n\nAvailable commands:\n  ui [--config FILE] [--smoke-test | --screenshots DIR]\n  run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--save FILE]\n  run --load FILE --ticks N --out FILE [--sample-every K] [--save FILE]\n  batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR [--sweep 'group.key=[values]']\n  climate --config FILE --out FILE  Export base climate JSON\n  version     Print version and interface contract JSON\n  --help, -h  Show this help\n";

/// Execute a command, returning its process status. I/O failures are propagated.
pub fn dispatch(args: &[String], out: &mut impl Write, err: &mut impl Write) -> io::Result<u8> {
    match args {
        [command, rest @ ..] if command == "ui" => match ui::execute(rest) {
            Ok(()) => Ok(0),
            Err(message) => {
                writeln!(err, "evosim: {message}")?;
                Ok(2)
            }
        },
        [command, rest @ ..] if command == "run" => match run::execute(rest) {
            Ok(()) => Ok(0),
            Err(message) => {
                writeln!(err, "evosim: {message}")?;
                Ok(2)
            }
        },
        [command, rest @ ..] if command == "batch" => match batch::execute(rest) {
            Ok(()) => Ok(0),
            Err(message) => {
                writeln!(err, "evosim: {message}")?;
                Ok(2)
            }
        },
        [command, rest @ ..] if command == "climate" => match export_climate(rest) {
            Ok(()) => Ok(0),
            Err(message) => {
                writeln!(err, "evosim: {message}")?;
                Ok(2)
            }
        },
        [command] if command == "version" => {
            writeln!(
                out,
                "{{\"name\":\"Evolution Simulation\",\"version\":\"{}\",\"contract\":1}}",
                env!("CARGO_PKG_VERSION")
            )?;
            Ok(0)
        }
        [command] if command == "--help" || command == "-h" => {
            write!(out, "{HELP}")?;
            Ok(0)
        }
        _ => {
            writeln!(
                err,
                "evosim: expected run, batch, version, climate --config FILE --out FILE, or --help"
            )?;
            Ok(2)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn writer_failure_is_propagated() {
        struct FailedWriter;
        impl Write for FailedWriter {
            fn write(&mut self, _: &[u8]) -> io::Result<usize> {
                Err(io::Error::other("output unavailable"))
            }
            fn flush(&mut self) -> io::Result<()> {
                Ok(())
            }
        }
        assert!(dispatch(&["version".into()], &mut FailedWriter, &mut Vec::new()).is_err());
    }
}

fn export_climate(args: &[String]) -> Result<(), String> {
    let mut config_path = None;
    let mut out_path = None;
    if args.len() != 4 {
        return Err("climate requires --config FILE --out FILE".into());
    }
    for pair in args.chunks_exact(2) {
        let slot = match pair[0].as_str() {
            "--config" => &mut config_path,
            "--out" => &mut out_path,
            _ => return Err(format!("unknown climate option: {}", pair[0])),
        };
        if slot.is_some() || pair[1].starts_with("--") {
            return Err("duplicate option or missing climate path".into());
        }
        *slot = Some(&pair[1]);
    }
    let config = crate::config::Config::load(config_path.ok_or("missing --config")?)
        .map_err(|e| e.to_string())?;
    let sim = crate::simulation::Simulation::new(config).map_err(|e| e.to_string())?;
    let file = std::fs::File::create(out_path.ok_or("missing --out")?)
        .map_err(|e| format!("climate output: {e}"))?;
    let mut writer = io::BufWriter::new(file);
    sim.world()
        .climate()
        .write_json(&mut writer)
        .and_then(|()| writer.flush())
        .map_err(|e| format!("climate output: {e}"))
}

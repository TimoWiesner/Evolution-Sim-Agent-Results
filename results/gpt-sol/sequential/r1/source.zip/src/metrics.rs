//! Read-only completed-tick analytics. Wire format: docs/METRICS.md.
use crate::{
    genome::LOCUS_NAMES,
    organism::{DeathCause, Kind},
    population::{Counts, Population},
    simulation::Simulation,
};
use serde_json::{Value, json};

pub const METRICS_SCHEMA: u32 = 1;
const KIND_NAMES: [&str; 3] = ["plants", "herbivores", "carnivores"];
const CAUSE_NAMES: [&str; 5] = ["starvation", "injury", "predation", "old_age", "climate"];

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct TraitSummary {
    pub mean: Option<f64>,
    pub standard_deviation: Option<f64>,
    pub min: Option<f64>,
    pub max: Option<f64>,
}
impl TraitSummary {
    fn to_json(self) -> Value {
        json!({"mean":self.mean,"standard_deviation":self.standard_deviation,"min":self.min,"max":self.max})
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct TraitMetrics(pub [TraitSummary; 12]);
impl TraitMetrics {
    pub fn to_json(&self) -> Value {
        LOCUS_NAMES
            .into_iter()
            .zip(self.0)
            .map(|(key, value)| (key.to_owned(), value.to_json()))
            .collect()
    }
}
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct GenerationSummary {
    pub highest: Option<u64>,
    pub mean: Option<f64>,
}
impl GenerationSummary {
    fn to_json(self) -> Value {
        json!({"highest":self.highest,"mean":self.mean})
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct KindMetrics {
    pub births: u128,
    pub deaths: u128,
    /// Order is DeathCause::ALL.
    pub deaths_by_cause: [u128; 5],
    pub species: usize,
    pub traits: TraitMetrics,
    pub generation: GenerationSummary,
}
impl KindMetrics {
    pub fn to_json(&self) -> Value {
        let causes: Value = CAUSE_NAMES
            .into_iter()
            .zip(self.deaths_by_cause)
            .map(|(key, n)| (key.to_owned(), json!(n)))
            .collect();
        json!({"births":self.births,"deaths":self.deaths,"deaths_by_cause":causes,"species":self.species,"traits":self.traits.to_json(),"generation":self.generation.to_json()})
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct Snapshot {
    tick: u64,
    counts: Counts,
    kinds: [KindMetrics; 3],
    generation: GenerationSummary,
}
impl Snapshot {
    pub fn capture(simulation: &Simulation) -> Self {
        Self::from_population(simulation.tick(), simulation.population())
    }
    fn from_population(tick: u64, population: &Population) -> Self {
        let mut traits = [[Accumulator::default(); 12]; 3];
        let mut generations = [Generations::default(); 3];
        let mut all = Generations::default();
        for o in population.iter() {
            let t = o.traits();
            let values = [
                t.speed() as f64,
                t.strength(),
                t.max_health(),
                t.lifespan() as f64,
                t.fertility(),
                t.vision() as f64,
                t.metabolic_multiplier(),
                t.preferred_temperature(),
                t.preferred_moisture(),
                t.climate_tolerance(),
                t.aggression(),
                t.risk_tolerance(),
            ];
            for (acc, value) in traits[o.kind().index()].iter_mut().zip(values) {
                acc.add(value);
            }
            generations[o.kind().index()].add(o.generation());
            all.add(o.generation());
        }
        let totals = population.totals();
        Self {
            tick,
            counts: population.counts(),
            kinds: Kind::ALL.map(|kind| KindMetrics {
                births: totals.births.get(kind),
                deaths: totals.deaths.get(kind),
                deaths_by_cause: DeathCause::ALL
                    .map(|cause| population.deaths_by_cause(kind, cause)),
                species: population.species().living_count(kind),
                traits: TraitMetrics(traits[kind.index()].map(Accumulator::finish)),
                generation: generations[kind.index()].finish(),
            }),
            generation: all.finish(),
        }
    }
    pub fn tick(&self) -> u64 {
        self.tick
    }
    pub fn counts(&self) -> Counts {
        self.counts
    }
    pub fn kind(&self, kind: Kind) -> &KindMetrics {
        &self.kinds[kind.index()]
    }
    pub fn generation(&self) -> GenerationSummary {
        self.generation
    }
    /// Full contract-compatible series row, including analytics.
    pub fn to_json(&self) -> Value {
        let mut analytics: Value = KIND_NAMES
            .into_iter()
            .zip(&self.kinds)
            .map(|(key, k)| (key.to_owned(), k.to_json()))
            .collect();
        analytics["generation"] = self.generation.to_json();
        json!({"tick":self.tick,"plants":self.counts.plants(),"herbivores":self.counts.herbivores(),"carnivores":self.counts.carnivores(),"analytics":analytics})
    }
}
#[derive(Clone, Copy, Debug, Default)]
struct Accumulator {
    n: u128,
    mean: f64,
    m2: f64,
    min: f64,
    max: f64,
}
impl Accumulator {
    fn add(&mut self, x: f64) {
        self.n += 1;
        if self.n == 1 {
            self.min = x;
            self.max = x;
        }
        self.min = self.min.min(x);
        self.max = self.max.max(x);
        let delta = x - self.mean;
        self.mean += delta / self.n as f64;
        self.m2 += delta * (x - self.mean);
    }
    fn finish(self) -> TraitSummary {
        if self.n == 0 {
            return TraitSummary::default();
        }
        TraitSummary {
            mean: Some(self.mean),
            standard_deviation: Some((self.m2 / self.n as f64).max(0.).sqrt()),
            min: Some(self.min),
            max: Some(self.max),
        }
    }
}
#[derive(Clone, Copy, Default)]
struct Generations {
    values: Accumulator,
    highest: Option<u64>,
}
impl Generations {
    fn add(&mut self, generation: u64) {
        self.values.add(generation as f64);
        self.highest = Some(self.highest.map_or(generation, |old| old.max(generation)));
    }
    fn finish(self) -> GenerationSummary {
        GenerationSummary {
            highest: self.highest,
            mean: self.values.finish().mean,
        }
    }
}
#[cfg(test)]
mod tests;

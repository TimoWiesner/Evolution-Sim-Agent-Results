//! Fixtures alter existing records only; every assertion exercises production actions.
use super::*;
use crate::genome::Genome;

fn fixture(
    w: usize,
    h: usize,
    plants: usize,
    herbs: usize,
    predators: usize,
    movement: f64,
    basal: f64,
) -> Simulation {
    Simulation::new(Config::from_json(&format!(r#"{{"seed":17,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{plants},"herbivores":{herbs},"carnivores":{predators}}},"animals":{{"movement_cost":{movement},"basal_cost":{basal}}},"plants":{{"growth_efficiency":0,"reproduction_energy":1001}},"climate":{{"weather_amplitude":0,"season_temperature_amplitude":0,"season_precipitation_amplitude":0}}}}"#)).unwrap()).unwrap()
}
fn ids(s: &Simulation, kind: Kind) -> Vec<OrganismId> {
    s.population.phase_ids(kind)
}
fn place(s: &mut Simulation, id: OrganismId, x: i128, y: i128) {
    let t = s.world.topology;
    let to = t.cell(x, y);
    while s.population.get(id).unwrap().position() != to {
        let from = s.population.get(id).unwrap().position();
        s.population
            .move_one_step(id, next_toward(t, from, to).unwrap())
            .unwrap();
    }
}
fn dna(s: &mut Simulation, id: OrganismId, speed: u16, vision: u16, risk: u16) {
    let mut a = [32768; 12];
    a[0] = speed;
    a[5] = vision;
    a[11] = risk;
    s.population.fixture_mut(id).genome = Genome::from_alleles(a);
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() <= 1e-10, "{a} != {b}");
}
fn upkeep(s: &Simulation, id: OrganismId) -> f64 {
    let a = s.population.get(id).unwrap();
    let t = a.traits();
    let stress = ((s.world.current_climate_at(a.position()).temperature()
        - t.preferred_temperature())
    .abs()
        / t.climate_tolerance()
        - 1.)
        .clamp(0., 1.);
    s.config.animals().basal_cost().max(1e-9) * t.metabolic_multiplier() * (1. + stress)
}
fn distance(s: &Simulation, a: Cell, b: Cell) -> usize {
    let x = a.x().abs_diff(b.x());
    let y = a.y().abs_diff(b.y());
    x.min(s.world.topology.width() - x)
        .max(y.min(s.world.topology.height() - y))
}

#[test]
fn feeding_reach_seams_degenerate_axes_and_full_tick_plant_ledger() {
    for (w, h) in [(11, 9), (1, 9), (11, 1), (1, 1)] {
        for (x, y) in [(0, 0), (1, 0), (0, 1), (1, 1), (-1, 0), (0, -1), (-1, -1)] {
            let mut s = fixture(w, h, 1, 1, 0, 0., 0.1);
            let p = ids(&s, Kind::Plant)[0];
            let a = ids(&s, Kind::Herbivore)[0];
            place(&mut s, a, 0, 0);
            place(&mut s, p, x, y);
            s.population.fixture_mut(a).energy = 100.;
            let loss = 0.2 * s.population.get(p).unwrap().traits().metabolic_multiplier();
            let cost = upkeep(&s, a);
            let rng = s.rng_state();
            s.advance_one_tick().unwrap();
            assert_eq!(
                s.population.get(a).unwrap().position(),
                s.world.topology.cell(0, 0)
            );
            assert!(
                distance(
                    &s,
                    s.population.get(p).unwrap().position(),
                    s.population.get(a).unwrap().position()
                ) <= 1
            );
            close(s.population.get(p).unwrap().energy(), 1000. - loss - 4.);
            close(s.population.get(a).unwrap().energy(), 100. - cost + 3.2);
            assert_eq!(s.rng_state(), rng);
        }
    }
}

#[test]
fn visible_boundary_pursuit_speed_and_no_remote_bites() {
    for speed in [0, 65535] {
        for d in [1, 2, 3, 8, 9] {
            let mut s = fixture(25, 25, 1, 1, 0, 0., 0.1);
            let p = ids(&s, Kind::Plant)[0];
            let a = ids(&s, Kind::Herbivore)[0];
            place(&mut s, a, 0, 0);
            place(&mut s, p, d, 0);
            dna(&mut s, a, speed, 65535, 65535);
            s.population.fixture_mut(a).energy = 100.;
            let mut reference = s.rng.clone();
            let steps = if speed == 0 { 1 } else { 4 };
            let mut expected = s.world.topology.cell(0, 0);
            if d <= 8 {
                expected = s.world.topology.cell((d - 1).min(steps), 0);
            } else {
                for _ in 0..steps {
                    expected = wander_step(s.world.topology, expected, &mut reference).unwrap();
                }
            }
            s.herbivores();
            assert_eq!(s.population.get(a).unwrap().position(), expected);
            let bites = d <= 8 && d - steps <= 1;
            close(
                s.population.get(p).unwrap().energy(),
                1000. - if bites { 4. } else { 0. },
            );
            assert_eq!(s.rng, reference);
        }
    }
    // Vision 1 cannot select a plant two cells away, even if exploration nears it.
    let mut s = fixture(9, 9, 1, 1, 0, 0., 0.1);
    let p = ids(&s, Kind::Plant)[0];
    let a = ids(&s, Kind::Herbivore)[0];
    place(&mut s, a, 0, 0);
    place(&mut s, p, 2, 0);
    dna(&mut s, a, 0, 0, 65535);
    s.population.fixture_mut(a).energy = 100.;
    s.herbivores();
    assert_eq!(s.population.get(p).unwrap().energy(), 1000.);
}

#[test]
fn bite_cap_capacity_roundoff_partial_depletion_and_one_target_only() {
    for plant_energy in [f64::from_bits(1), 0.5, 4., 5., 1000.] {
        for energy in [100., 999.9, 1000. - 1e-12, 1000.] {
            let mut s = fixture(1, 1, 2, 1, 0, 0., 0.1);
            let ps = ids(&s, Kind::Plant);
            let a = ids(&s, Kind::Herbivore)[0];
            s.population.fixture_mut(ps[0]).energy = plant_energy;
            s.population.fixture_mut(a).energy = energy;
            let cost = upkeep(&s, a);
            let rng = s.rng_state();
            s.herbivores();
            let remaining = s.population.get(ps[0]).map_or(0., |p| p.energy());
            let removed = plant_energy - remaining;
            let gain = s.population.get(a).unwrap().energy() - (energy - cost);
            assert!(removed >= 0. && removed <= 4. + 1e-10 && gain <= removed + 1e-10);
            close(gain, 0.8 * removed);
            assert_eq!(s.population.get(ps[1]).unwrap().energy(), 1000.);
            if remaining == 0. {
                assert!(
                    !s.population
                        .nearby(s.world.topology.cell(0, 0), 0, None)
                        .contains(&ps[0])
                );
            }
            s.commit();
            assert_eq!(
                s.population
                    .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
                u128::from(remaining == 0.)
            );
            assert_eq!(s.rng_state(), rng);
        }
    }
}

#[test]
fn depleted_plant_is_absent_for_later_grazers_and_reproduction() {
    let mut s = fixture(1, 1, 1, 2, 0, 0., 0.1);
    let p = ids(&s, Kind::Plant)[0];
    let hs = ids(&s, Kind::Herbivore);
    s.population.fixture_mut(p).energy = 1.;
    for a in &hs {
        s.population.fixture_mut(*a).energy = 100.;
    }
    let costs: Vec<_> = hs.iter().map(|a| upkeep(&s, *a)).collect();
    s.herbivores();
    close(
        s.population.get(hs[0]).unwrap().energy(),
        100. - costs[0] + 0.8,
    );
    close(s.population.get(hs[1]).unwrap().energy(), 100. - costs[1]);
    assert!(s.population.get(p).is_none());
    s.reproduction();
    s.commit();
    assert_eq!(
        s.population
            .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
        1
    );
    assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
    for _ in 0..4 {
        s.advance_one_tick().unwrap();
    }
    assert_eq!(s.population.totals().deaths.get(Kind::Plant), 1);
    assert_eq!(s.population.counts().get(Kind::Plant), 0);
    // Separate full tick: plant physiology occurs before its lethal bite.
    let mut s = fixture(1, 1, 1, 1, 0, 0., 0.1);
    let p = ids(&s, Kind::Plant)[0];
    let a = ids(&s, Kind::Herbivore)[0];
    s.population.fixture_mut(p).energy = 1.;
    s.population.fixture_mut(a).energy = 100.;
    let available = 1. - 0.2 * s.population.get(p).unwrap().traits().metabolic_multiplier();
    let cost = upkeep(&s, a);
    s.advance_one_tick().unwrap();
    assert!(s.population.get(p).is_none());
    close(
        s.population.get(a).unwrap().energy(),
        100. - cost + 0.8 * available,
    );
}

#[test]
fn upkeep_kills_before_food_age_expiry_precedes_upkeep_and_no_draws() {
    for basal in [f64::from_bits(1), 0.1, 1_000_000.] {
        let s = fixture(1, 1, 1, 1, 0, 0., basal);
        let a = ids(&s, Kind::Herbivore)[0];
        let p = ids(&s, Kind::Plant)[0];
        let cost = upkeep(&s, a);
        for energy in [cost * 0.5, cost] {
            let mut s = s.clone();
            // Values above capacity are not valid fixture reserves.
            if energy > 1000. {
                continue;
            }
            s.population.fixture_mut(a).energy = energy;
            let r = s.rng_state();
            s.herbivores();
            assert!(s.population.get(a).is_none());
            assert_eq!(s.population.get(p).unwrap().energy(), 1000.);
            assert_eq!(s.rng_state(), r);
            s.commit();
            assert_eq!(
                s.population
                    .deaths_by_cause(Kind::Herbivore, DeathCause::Starvation),
                1
            );
        }
        let mut s = s.clone();
        s.herbivores();
        if cost >= 1000. {
            assert!(s.population.get(a).is_none());
        } else {
            assert!(s.population.get(a).unwrap().energy() <= 1000.);
        }
    }
    let mut s = fixture(1, 1, 1, 1, 0, 0., 1_000_000.);
    let a = ids(&s, Kind::Herbivore)[0];
    s.population.fixture_mut(a).age = 1099;
    s.herbivores();
    s.commit();
    assert_eq!(
        s.population
            .deaths_by_cause(Kind::Herbivore, DeathCause::OldAge),
        1
    );
    assert_eq!(
        s.population
            .deaths_by_cause(Kind::Herbivore, DeathCause::Starvation),
        0
    );
}

#[test]
fn climate_genes_and_current_weather_change_real_tick_cost() {
    let mut s = fixture(1, 4, 0, 1, 0, 0., 1.);
    let a = ids(&s, Kind::Herbivore)[0];
    let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
    v["climate"]["weather_amplitude"] = serde_json::json!(1.);
    v["climate"]["season_temperature_amplitude"] = serde_json::json!(1.);
    v["climate"]["year_ticks"] = serde_json::json!(4);
    s.config = Config::from_json(&v.to_string()).unwrap();
    s.world.temporal_climate = TemporalClimate::new(s.config.climate().clone());
    let mut costs = vec![];
    for pref in [0, 65535] {
        let mut s = s.clone();
        let mut alleles = [32768; 12];
        alleles[7] = pref;
        alleles[9] = 65535;
        s.population.fixture_mut(a).genome = Genome::from_alleles(alleles);
        let mut reference = s.clone();
        reference.tick = 1;
        reference.climate_resources();
        let expected = upkeep(&reference, a);
        let base = reference
            .world
            .climate
            .base_at(reference.world.topology.cell(0, 0))
            .temperature();
        assert_ne!(
            reference
                .world
                .current_climate_at(reference.world.topology.cell(0, 0))
                .temperature(),
            base
        );
        s.advance_one_tick().unwrap();
        close(1000. - s.population.get(a).unwrap().energy(), expected);
        costs.push(expected);
    }
    assert_ne!(costs[0], costs[1]);
}

#[test]
fn risk_only_genomes_make_different_actual_decisions_and_safe_alternative() {
    for risk in [0, 32767, 32768, 65535] {
        let mut s = fixture(11, 11, 2, 1, 1, 0., 0.1);
        let ps = ids(&s, Kind::Plant);
        let a = ids(&s, Kind::Herbivore)[0];
        let c = ids(&s, Kind::Carnivore)[0];
        place(&mut s, a, 0, 0);
        place(&mut s, ps[0], -2, 0);
        place(&mut s, ps[1], 2, 0);
        place(&mut s, c, -3, 0);
        s.population.fixture_mut(c).energy = upkeep(&s, c) + 0.01;
        dna(&mut s, a, 0, 65535, risk);
        s.population.fixture_mut(a).energy = 100.;
        let rng = s.rng_state();
        s.advance_one_tick().unwrap();
        assert_eq!(
            s.population.get(a).unwrap().position(),
            s.world.topology.cell(if risk < 32768 { 1 } else { -1 }, 0)
        );
        let baseline = 1000. - 0.2 * Genome::founder().traits().metabolic_multiplier();
        close(
            s.population
                .get(ps[usize::from(risk < 32768)])
                .unwrap()
                .energy(),
            baseline - 4.,
        );
        assert_eq!(s.rng_state(), rng);
    }
    // Only dangerous food: cautious explores without biting, bold pursues.
    let mut s = fixture(11, 11, 1, 1, 1, 0., 0.1);
    let p = ids(&s, Kind::Plant)[0];
    let a = ids(&s, Kind::Herbivore)[0];
    let c = ids(&s, Kind::Carnivore)[0];
    place(&mut s, a, 0, 0);
    place(&mut s, p, -2, 0);
    place(&mut s, c, -3, 0);
    s.population.fixture_mut(c).energy = upkeep(&s, c) + 0.01;
    s.population.fixture_mut(a).energy = 100.;
    let mut bold = s.clone();
    dna(&mut s, a, 0, 65535, 0);
    dna(&mut bold, a, 0, 65535, 65535);
    let mut r = s.rng.clone();
    let expected = wander_step(s.world.topology, s.world.topology.cell(0, 0), &mut r).unwrap();
    s.herbivores();
    bold.herbivores();
    assert_eq!(s.population.get(a).unwrap().position(), expected);
    assert_eq!(s.rng, r);
    close(s.population.get(p).unwrap().energy(), 1000.);
    close(bold.population.get(p).unwrap().energy(), 996.);
    assert_ne!(
        s.population.get(a).unwrap().energy(),
        bold.population.get(a).unwrap().energy()
    );
}

#[test]
fn hidden_predator_does_not_affect_risk_and_no_predator_is_same_for_both_genomes() {
    for predator in [false, true] {
        let mut s = fixture(19, 19, 1, 1, usize::from(predator), 0., 0.1);
        let a = ids(&s, Kind::Herbivore)[0];
        let p = ids(&s, Kind::Plant)[0];
        place(&mut s, a, 0, 0);
        place(&mut s, p, 1, 0);
        if predator {
            let c = ids(&s, Kind::Carnivore)[0];
            place(&mut s, c, 2, 0);
        }
        s.population.fixture_mut(a).energy = 100.;
        let mut b = s.clone();
        dna(&mut s, a, 0, 0, 0);
        dna(&mut b, a, 0, 0, 65535);
        s.herbivores();
        b.herbivores();
        assert_eq!(s.population.get(p).unwrap().energy(), 996.);
        assert_eq!(s.population.get(p), b.population.get(p));
        assert_eq!(
            s.population.get(a).unwrap().energy(),
            b.population.get(a).unwrap().energy()
        );
        assert_eq!(s.rng, b.rng);
    }
}

#[test]
fn lethal_or_unaffordable_movement_cannot_create_remote_gain() {
    for energy in [0.1, 0.6, 1.1, 2.] {
        let mut s = fixture(11, 11, 1, 1, 0, 1., 0.1);
        let a = ids(&s, Kind::Herbivore)[0];
        let p = ids(&s, Kind::Plant)[0];
        place(&mut s, a, 0, 0);
        place(&mut s, p, 3, 0);
        let mut alleles = [32768; 12];
        alleles[0] = 0;
        alleles[6] = 0;
        alleles[5] = 65535;
        s.population.fixture_mut(a).genome = Genome::from_alleles(alleles);
        s.population.fixture_mut(a).energy = energy;
        let cost = upkeep(&s, a);
        s.herbivores();
        assert_eq!(s.population.get(p).unwrap().energy(), 1000.);
        if let Some(animal) = s.population.get(a) {
            let steps = usize::from(energy - cost >= 0.5);
            close(animal.energy(), energy - cost - steps as f64 * 0.5);
        }
    }
    // Exact paid step exhaustion removes immediately, before an adjacent bite.
    let mut s = fixture(11, 11, 1, 1, 0, 1., 0.1);
    let a = ids(&s, Kind::Herbivore)[0];
    let p = ids(&s, Kind::Plant)[0];
    place(&mut s, a, 0, 0);
    place(&mut s, p, 2, 0);
    dna(&mut s, a, 0, 65535, 65535);
    // Binary subtraction need not return exactly step; choose a representable
    // basal setting and metabolism for exact equality.
    let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
    v["animals"]["basal_cost"] = serde_json::json!(1.);
    s.config = Config::from_json(&v.to_string()).unwrap();
    let mut alleles = [32768; 12];
    alleles[0] = 0;
    alleles[6] = 0;
    alleles[9] = 65535;
    alleles[5] = 65535;
    s.population.fixture_mut(a).genome = Genome::from_alleles(alleles);
    s.population.fixture_mut(a).energy = 1.;
    s.herbivores();
    assert!(s.population.get(a).is_none());
    assert_eq!(s.population.get(p).unwrap().energy(), 1000.);
}

#[test]
fn production_pursuit_pays_every_step_for_all_speeds_and_metabolic_endpoints() {
    for (speed, n) in [(0, 1), (21845, 2), (43690, 3), (65535, 4)] {
        for (met, m) in [(0, 0.5), (65535, 2.)] {
            let mut s = fixture(19, 19, 1, 1, 0, 1., 0.1);
            let a = ids(&s, Kind::Herbivore)[0];
            let p = ids(&s, Kind::Plant)[0];
            place(&mut s, a, 0, 0);
            place(&mut s, p, 4, 0);
            let mut alleles = [32768; 12];
            alleles[0] = speed;
            alleles[5] = 65535;
            alleles[6] = met;
            s.population.fixture_mut(a).genome = Genome::from_alleles(alleles);
            s.population.fixture_mut(a).energy = 100.;
            let cost = upkeep(&s, a);
            let rng = s.rng_state();
            s.advance_one_tick().unwrap();
            let steps = n.min(3);
            assert_eq!(
                s.population.get(a).unwrap().position(),
                s.world.topology.cell(steps, 0)
            );
            let bite = if steps == 3 { 3.2 } else { 0. };
            close(
                s.population.get(a).unwrap().energy(),
                100. - cost - steps as f64 * n as f64 * m + bite,
            );
            assert_eq!(s.rng_state(), rng);
        }
    }
}

#[test]
fn affordable_adjacent_bite_and_newborn_first_upkeep_next_tick() {
    let mut s = fixture(1, 1, 1, 2, 0, 1_000_000., 0.1);
    let hs = ids(&s, Kind::Herbivore);
    let p = ids(&s, Kind::Plant)[0];
    for id in &hs {
        s.population.fixture_mut(*id).energy = 100.;
    }
    s.tick = 1;
    s.herbivores(); // No affordable move is needed to eat the adjacent plant.
    assert_eq!(s.population.get(p).unwrap().energy(), 992.);
    s.queue_birth(BirthRequest {
        kind: Kind::Herbivore,
        position: s.world.topology.cell(0, 0),
        energy: 10.,
        health: 5.,
        parents: hs,
        phase: BirthPhase::Reproduction,
    })
    .unwrap();
    s.commit();
    let child = s
        .population
        .iter()
        .find(|o| o.birth_tick() == 1)
        .unwrap()
        .id();
    assert_eq!(s.population.get(child).unwrap().age(), 0);
    assert_eq!(s.population.get(child).unwrap().energy(), 10.);
    s.advance_one_tick().unwrap();
    let newborn = s.population.get(child).unwrap();
    assert_eq!(newborn.age(), 1);
    assert!(newborn.energy() > 10. && newborn.energy() < 13.2);
}

#[test]
fn sequential_bites_share_only_the_remaining_stock_and_grazing_preempts_paid_reproduction() {
    let mut s = fixture(1, 1, 1, 3, 0, 0., 0.1);
    let p = ids(&s, Kind::Plant)[0];
    let hs = ids(&s, Kind::Herbivore);
    s.population.fixture_mut(p).energy = 6.;
    for id in &hs {
        s.population.fixture_mut(*id).energy = 100.;
    }
    let cost = upkeep(&s, hs[0]);
    s.herbivores();
    for (id, gain) in hs.iter().zip([3.2, 1.6, 0.]) {
        close(s.population.get(*id).unwrap().energy(), 100. - cost + gain);
    }
    assert!(s.population.get(p).is_none());

    let mut observed = false;
    for seed in 0..32 {
        let mut s = fixture(2, 1, 1, 1, 0, 0., 0.1);
        let mut value: serde_json::Value =
            serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
        value["seed"] = serde_json::json!(seed);
        value["plants"]["reproduction_energy"] = serde_json::json!(0.1);
        s = Simulation::new(Config::from_json(&value.to_string()).unwrap()).unwrap();
        let p = ids(&s, Kind::Plant)[0];
        let a = ids(&s, Kind::Herbivore)[0];
        let mut alleles = [32768; 12];
        alleles[4] = 65535;
        s.population.fixture_mut(p).genome = Genome::from_alleles(alleles);
        s.population.fixture_mut(p).energy = 0.5;
        s.population.fixture_mut(a).energy = 100.;
        let mut control = s.clone();
        control.population.kill(a, 0, DeathCause::Injury);
        control.commit();
        control.advance_one_tick().unwrap();
        if control.population.totals().births.get(Kind::Plant) == 0 {
            continue;
        }
        s.advance_one_tick().unwrap();
        assert!(s.population.get(p).is_none());
        assert_eq!(s.population.totals().births.get(Kind::Plant), 0);
        assert_eq!(
            s.population
                .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
            1
        );
        observed = true;
        break;
    }
    assert!(observed, "control must actually reproduce without the bite");
}

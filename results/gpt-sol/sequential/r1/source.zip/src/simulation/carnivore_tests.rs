//! Fixtures alter existing records only; every assertion exercises production actions.
use super::*;
use crate::genome::Genome;

fn fixture(
    w: usize,
    h: usize,
    plants: usize,
    herbs: usize,
    predators: usize,
    movement: f64,
    basal: f64,
) -> Simulation {
    let mut s = Simulation::new(Config::from_json(&format!(r#"{{"seed":17,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":{plants},"herbivores":{herbs},"carnivores":{predators}}},"animals":{{"movement_cost":{movement},"basal_cost":{basal}}},"plants":{{"growth_efficiency":0,"reproduction_energy":1001}},"climate":{{"weather_amplitude":0,"season_temperature_amplitude":0,"season_precipitation_amplitude":0}}}}"#)).unwrap()).unwrap();
    // Hunting fixtures start hungry; satiety is tested separately.
    for id in s.population.phase_ids(Kind::Carnivore) {
        s.population.fixture_mut(id).energy = 100.;
    }
    s
}
fn ids(s: &Simulation, kind: Kind) -> Vec<OrganismId> {
    s.population.phase_ids(kind)
}
fn place(s: &mut Simulation, id: OrganismId, x: i128, y: i128) {
    let t = s.world.topology;
    let to = t.cell(x, y);
    while s.population.get(id).unwrap().position() != to {
        let from = s.population.get(id).unwrap().position();
        s.population
            .move_one_step(id, next_toward(t, from, to).unwrap())
            .unwrap();
    }
}
fn dna(s: &mut Simulation, id: OrganismId, speed: u16, vision: u16, risk: u16) {
    let mut a = [32768; 12];
    a[0] = speed;
    a[5] = vision;
    a[11] = risk;
    s.population.fixture_mut(id).genome = Genome::from_alleles(a);
}
fn close(a: f64, b: f64) {
    assert!((a - b).abs() <= 1e-10, "{a} != {b}");
}
fn upkeep(s: &Simulation, id: OrganismId) -> f64 {
    let a = s.population.get(id).unwrap();
    let t = a.traits();
    let stress = ((s.world.current_climate_at(a.position()).temperature()
        - t.preferred_temperature())
    .abs()
        / t.climate_tolerance()
        - 1.)
        .clamp(0., 1.);
    s.config.animals().basal_cost().max(1e-9) * t.metabolic_multiplier() * (1. + stress)
}
fn distance(s: &Simulation, a: Cell, b: Cell) -> usize {
    let x = a.x().abs_diff(b.x());
    let y = a.y().abs_diff(b.y());
    x.min(s.world.topology.width() - x)
        .max(y.min(s.world.topology.height() - y))
}

fn pair(seed: u64) -> (Simulation, OrganismId, OrganismId) {
    let mut s = fixture(1, 1, 0, 1, 1, 0., 0.1);
    s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
    let h = ids(&s, Kind::Herbivore)[0];
    let c = ids(&s, Kind::Carnivore)[0];
    s.population.fixture_mut(h).energy = 10.;
    s.population.fixture_mut(c).energy = 100.;
    (s, h, c)
}
fn independent_odds(s: &Simulation, c: OrganismId, h: OrganismId) -> u64 {
    let c = s.population.get(c).unwrap();
    let h = s.population.get(h).unwrap();
    let a = c.traits().strength() * (1. + c.traits().aggression()) * c.health()
        / c.traits().max_health();
    let d = h.traits().strength() * (1. + h.traits().speed() as f64 / 4.) * h.health()
        / h.traits().max_health();
    ((a / (a + d)).clamp(0.1, 0.9) * 1_000_000.).floor() as u64
}
#[test]
fn many_actual_attacks_match_independent_formula_rng_and_exact_energy_death_ledgers() {
    let mut kills = 0;
    for seed in 0..512 {
        let (mut s, h, c) = pair(seed);
        let mut reference = s.rng.clone();
        let success = reference
            .chance(independent_odds(&s, c, h), 1_000_000)
            .unwrap();
        let expected = 100.
            - upkeep(&s, c)
            - 0.5 * s.population.get(c).unwrap().traits().metabolic_multiplier();
        s.carnivores();
        assert_eq!(s.rng, reference);
        assert_eq!(s.population.get(h).is_none(), success);
        close(
            s.population.get(c).unwrap().energy(),
            expected + if success { 8. } else { 0. },
        );
        if success {
            kills += 1;
            assert!(
                !s.population
                    .nearby(s.world.topology.cell(0, 0), 0, None)
                    .contains(&h)
            );
            assert!(!s.population.sense(c).unwrap().contains(&h));
            assert!(!s.population.kill(h, 0, DeathCause::Predation));
        } else {
            assert_eq!(s.population.get(h).unwrap().energy(), 10.);
        }
        s.commit();
        s.commit();
        assert_eq!(
            s.population
                .deaths_by_cause(Kind::Herbivore, DeathCause::Predation),
            u128::from(success)
        );
        assert_eq!(s.population.death_records().len(), usize::from(success));
        assert_eq!(
            s.population.totals().initial.get(Kind::Herbivore)
                - s.population.totals().deaths.get(Kind::Herbivore),
            s.population.counts().get(Kind::Herbivore)
        );
    }
    assert!(
        (150..350).contains(&kills),
        "kills={kills}, escapes={}",
        512 - kills
    );
}
#[test]
fn paired_traits_change_odds_and_actual_shared_trials_monotonically() {
    // Change one inherited trait at a time; health is an independent vital.
    let (base, h, c) = pair(0);
    for (id, locus, increases) in [(c, 1, true), (h, 1, false), (c, 10, true), (h, 0, false)] {
        let mut low = base.clone();
        let mut high = base.clone();
        let mut a = [32768; 12];
        a[locus] = 0;
        low.population.fixture_mut(id).genome = Genome::from_alleles(a);
        a[locus] = 65535;
        high.population.fixture_mut(id).genome = Genome::from_alleles(a);
        let n0 = independent_odds(&low, c, h);
        let n1 = independent_odds(&high, c, h);
        assert_eq!(n1 > n0, increases);
        let mut totals = [0, 0];
        for seed in 0..4096 {
            let mut outcomes = [false; 2];
            for (i, fixture) in [&low, &high].iter().enumerate() {
                let mut s = (*fixture).clone();
                s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
                s.carnivores();
                outcomes[i] = s.population.get(h).is_none();
                totals[i] += usize::from(outcomes[i]);
            }
            assert!(!outcomes[usize::from(!increases)] || outcomes[usize::from(increases)]);
        }
        assert_eq!(totals[1] > totals[0], increases);
        assert_ne!(totals[0], totals[1]);
    }
    let n = independent_odds(&base, c, h);
    let mut s = base.clone();
    s.population.fixture_mut(c).health *= 0.5;
    assert!(independent_odds(&s, c, h) < n);
    let mut s = base.clone();
    s.population.fixture_mut(h).health *= 0.5;
    assert!(independent_odds(&s, c, h) > n);
}
#[test]
fn pursuit_reach_vision_all_speeds_and_wrapped_axes() {
    for (w, hgt) in [(19, 19), (1, 19), (19, 1), (1, 1)] {
        for (x, y) in [(0, 0), (1, 0), (0, 1), (1, 1), (-1, 0), (0, -1), (-1, -1)] {
            let mut s = fixture(w, hgt, 0, 1, 1, 1., 0.1);
            let h = ids(&s, Kind::Herbivore)[0];
            let c = ids(&s, Kind::Carnivore)[0];
            place(&mut s, c, 0, 0);
            place(&mut s, h, x, y);
            let mut r = s.rng.clone();
            let success = r.chance(independent_odds(&s, c, h), 1_000_000).unwrap();
            s.carnivores();
            assert_eq!(s.rng, r);
            assert_eq!(s.population.get(h).is_none(), success);
            assert_eq!(
                s.population.get(c).unwrap().position(),
                s.world.topology.cell(0, 0)
            );
        }
    }
    for (speed, n) in [(0, 1), (21845, 2), (43690, 3), (65535, 4)] {
        for d in [1, 2, 4, 8, 9] {
            let mut s = fixture(25, 25, 0, 1, 1, 1., 0.1);
            let h = ids(&s, Kind::Herbivore)[0];
            let c = ids(&s, Kind::Carnivore)[0];
            place(&mut s, c, 0, 0);
            place(&mut s, h, d, 0);
            dna(&mut s, c, speed, 65535, 65535);
            let mut r = s.rng.clone();
            let mut expected = s.world.topology.cell(0, 0);
            let steps = if d <= 8 { (d - 1).min(n) } else { n };
            if d <= 8 {
                expected = s.world.topology.cell(steps, 0);
            } else {
                for _ in 0..n {
                    expected = wander_step(s.world.topology, expected, &mut r).unwrap();
                }
            }
            let attack = d <= 8 && d - steps <= 1;
            let success = attack && r.chance(independent_odds(&s, c, h), 1_000_000).unwrap();
            let cost = upkeep(&s, c);
            let step = step_cost(s.population.get(c).unwrap().traits(), s.config.animals());
            let before = s.population.get(c).unwrap().energy();
            s.carnivores();
            assert_eq!(s.rng, r);
            assert_eq!(s.population.get(c).unwrap().position(), expected);
            assert_eq!(s.population.get(h).is_none(), success);
            if !success {
                close(
                    s.population.get(c).unwrap().energy(),
                    before
                        - cost
                        - steps as f64 * step
                        - if attack {
                            attack_cost(s.population.get(c).unwrap().traits())
                        } else {
                            0.
                        },
                );
            }
            assert!(distance(&s, s.world.topology.cell(0, 0), expected) <= n as usize);
        }
    }
}
#[test]
fn sequential_competition_first_success_removes_prey_and_failure_leaves_it_available() {
    let mut observed = [false; 2];
    for seed in 0..128 {
        let mut s = fixture(1, 1, 0, 1, 2, 0., 0.1);
        s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
        let h = ids(&s, Kind::Herbivore)[0];
        let cs = ids(&s, Kind::Carnivore);
        s.population.fixture_mut(h).energy = 10.;
        for c in &cs {
            s.population.fixture_mut(*c).energy = 100.;
        }
        let mut r = s.rng.clone();
        let first = r.chance(independent_odds(&s, cs[0], h), 1_000_000).unwrap();
        let second = !first && r.chance(independent_odds(&s, cs[1], h), 1_000_000).unwrap();
        s.carnivores();
        assert_eq!(s.rng, r);
        for (i, c) in cs.iter().enumerate() {
            let attacks = i == 0 || !first;
            close(
                s.population.get(*c).unwrap().energy(),
                100. - upkeep(&s, *c)
                    - if attacks {
                        attack_cost(s.population.get(*c).unwrap().traits())
                    } else {
                        0.
                    }
                    + if [first, second][i] { 8. } else { 0. },
            );
        }
        s.commit();
        assert_eq!(
            s.population.death_records().len(),
            usize::from(first || second)
        );
        assert_eq!(
            s.population
                .deaths_by_cause(Kind::Herbivore, DeathCause::Predation),
            u128::from(first || second)
        );
        observed[0] |= first;
        observed[1] |= !first && second;
    }
    assert!(observed.into_iter().all(|x| x));
}
#[test]
fn production_nutrition_is_conservative_even_for_subnormal_prey_and_saturation() {
    let seed = (0..128)
        .find(|seed| {
            let (s, h, c) = pair(*seed);
            s.rng
                .clone()
                .chance(independent_odds(&s, c, h), 1_000_000)
                .unwrap()
        })
        .unwrap();
    for p in [f64::from_bits(1), f64::MIN_POSITIVE, 1e-14, 0.5, 4., 1000.] {
        for energy in [100., 749., 999.9, 1000. - 1e-12, 1000.] {
            let (mut s, h, c) = pair(seed);
            s.population.fixture_mut(h).energy = p;
            s.population.fixture_mut(c).energy = energy;
            if energy - upkeep(&s, c) >= 750. {
                let r = s.rng_state();
                let expected = energy - upkeep(&s, c);
                s.carnivores();
                assert_eq!(s.rng_state(), r);
                assert!(s.population.get(h).is_some());
                close(s.population.get(c).unwrap().energy(), expected);
                continue;
            }
            let baseline =
                energy - upkeep(&s, c) - attack_cost(s.population.get(c).unwrap().traits());
            s.carnivores();
            assert!(s.population.get(h).is_none());
            let gain = s.population.get(c).unwrap().energy() - baseline;
            assert!(gain >= 0. && gain <= p, "gain {gain} prey {p}");
            assert!(s.population.get(c).unwrap().energy() <= 1000.);
        }
    }
}
#[test]
fn unaffordable_lethal_upkeep_attack_movement_and_age_skip_trial() {
    for mode in 0..5 {
        let (mut s, h, c) = pair(0);
        // Exact binary costs: ideal maintenance=.5, attack=.25, step=.5.
        let mut a = [32768; 12];
        a[0] = 0;
        a[6] = 0;
        a[9] = 65535;
        s.population.fixture_mut(c).genome = Genome::from_alleles(a);
        let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
        v["animals"]["basal_cost"] = serde_json::json!(1.);
        s.config = Config::from_json(&v.to_string()).unwrap();
        let cost = upkeep(&s, c);
        s.population.fixture_mut(c).energy = match mode {
            0 => cost,
            1 => cost + 0.125,
            2 => cost + 0.25,
            _ => 100.,
        };
        if mode == 3 {
            s.population.fixture_mut(c).age = 1099;
        }
        if mode == 4 {
            s = fixture(11, 11, 0, 1, 1, 1., 1.);
            let mut a = [32768; 12];
            a[0] = 0;
            a[6] = 0;
            a[9] = 65535;
            s.population.fixture_mut(c).genome = Genome::from_alleles(a);
            place(&mut s, c, 0, 0);
            place(&mut s, h, 2, 0);
            s.population.fixture_mut(c).energy = upkeep(&s, c) + 0.5;
        }
        let r = s.rng_state();
        s.carnivores();
        assert_eq!(s.rng_state(), r);
        assert!(s.population.get(h).is_some());
        if mode == 1 {
            assert!(s.population.get(c).is_some());
        } else {
            assert!(s.population.get(c).is_none());
        }
        s.commit();
        assert_eq!(
            s.population.deaths_by_cause(
                Kind::Carnivore,
                if mode == 3 {
                    DeathCause::OldAge
                } else {
                    DeathCause::Starvation
                }
            ),
            u128::from(mode != 1)
        );
    }
}
#[test]
fn nearest_then_id_target_and_newborn_first_hunt_next_tick() {
    let mut s = fixture(11, 11, 0, 2, 1, 0., 0.1);
    let hs = ids(&s, Kind::Herbivore);
    let c = ids(&s, Kind::Carnivore)[0];
    place(&mut s, c, 0, 0);
    place(&mut s, hs[0], -3, 0);
    place(&mut s, hs[1], 3, 0);
    dna(&mut s, c, 0, 65535, 65535);
    s.carnivores();
    assert_eq!(
        s.population.get(c).unwrap().position(),
        s.world.topology.cell(-1, 0)
    );
    place(&mut s, hs[1], 0, 1);
    s.carnivores();
    assert_eq!(
        s.population.get(c).unwrap().position(),
        s.world.topology.cell(-1, 0)
    );
    // Pending carnivore is absent from the phase snapshot, enters only at Commit.
    let mut s = fixture(1, 1, 0, 1, 2, 0., 0.1);
    let cs = ids(&s, Kind::Carnivore);
    let h = ids(&s, Kind::Herbivore)[0];
    for c in &cs {
        s.population.fixture_mut(*c).energy = upkeep(&s, *c) + 0.01;
    }
    s.tick = 1;
    s.queue_birth(BirthRequest {
        kind: Kind::Carnivore,
        position: s.world.topology.cell(0, 0),
        energy: 100.,
        health: 5.,
        parents: cs,
        phase: BirthPhase::Reproduction,
    })
    .unwrap();
    let r = s.rng_state();
    s.carnivores();
    assert_eq!(s.rng_state(), r);
    s.commit();
    let child = s
        .population
        .iter()
        .find(|o| o.birth_tick() == 1)
        .unwrap()
        .id();
    assert_eq!(s.population.get(child).unwrap().age(), 0);
    assert_eq!(s.population.get(child).unwrap().energy(), 100.);
    let mut expected = s.rng.clone();
    expected
        .chance(independent_odds(&s, child, h), 1_000_000)
        .unwrap();
    s.tick = 2;
    s.carnivores();
    assert_eq!(s.rng, expected);
    assert_eq!(s.population.get(child).unwrap().age(), 1);
}
#[test]
fn full_tick_weather_herbivore_wander_then_hunt_trial_order_and_prey_energy_snapshot() {
    let (mut s, h, c) = pair(42);
    let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
    v["climate"]["weather_amplitude"] = serde_json::json!(1.);
    s.config = Config::from_json(&v.to_string()).unwrap();
    s.world.temporal_climate = TemporalClimate::new(s.config.climate().clone());
    let mut reference = s.clone();
    reference.tick = 1;
    reference.climate_resources();
    let prey_energy = 10. - upkeep(&reference, h);
    let baseline =
        100. - upkeep(&reference, c) - attack_cost(reference.population.get(c).unwrap().traits());
    let n = independent_odds(&reference, c, h);
    let success = reference.rng.chance(n, 1_000_000).unwrap();
    s.advance_one_tick().unwrap();
    assert_eq!(s.rng, reference.rng);
    assert_eq!(s.population.get(h).is_none(), success);
    close(
        s.population.get(c).unwrap().energy(),
        baseline + if success { 0.8 * prey_energy } else { 0. },
    );
    // Nondegenerate empty-food herbivore wandering draws precede pursuit/trial.
    let mut s = fixture(3, 3, 0, 1, 1, 0., 0.1);
    let h = ids(&s, Kind::Herbivore)[0];
    let c = ids(&s, Kind::Carnivore)[0];
    let mut r = s.rng.clone();
    let mut position = s.population.get(h).unwrap().position();
    for _ in 0..s.population.get(h).unwrap().traits().speed() {
        position = wander_step(s.world.topology, position, &mut r).unwrap();
    }
    r.chance(independent_odds(&s, c, h), 1_000_000).unwrap();
    s.advance_one_tick().unwrap();
    assert_eq!(s.rng, r);
}
#[test]
fn hidden_prey_never_receives_opportunistic_attack_and_one_target_only() {
    let mut s = fixture(11, 11, 0, 1, 1, 0., 0.1);
    let h = ids(&s, Kind::Herbivore)[0];
    let c = ids(&s, Kind::Carnivore)[0];
    dna(&mut s, c, 0, 0, 65535);
    place(&mut s, c, 0, 0);
    place(&mut s, h, 2, 0);
    let mut r = s.rng.clone();
    let to = wander_step(s.world.topology, s.world.topology.cell(0, 0), &mut r).unwrap();
    s.carnivores();
    assert_eq!(s.rng, r);
    assert_eq!(s.population.get(c).unwrap().position(), to);
    assert_eq!(s.population.get(h).unwrap().energy(), 1000.);
    // Even stacked alternatives do not permit a second attempt in the action.
    for seed in 0..32 {
        let mut s = fixture(1, 1, 0, 3, 1, 0., 0.1);
        let hs = ids(&s, Kind::Herbivore);
        let c = ids(&s, Kind::Carnivore)[0];
        s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
        let mut r = s.rng.clone();
        let success = r.chance(independent_odds(&s, c, hs[0]), 1_000_000).unwrap();
        s.carnivores();
        assert_eq!(s.rng, r);
        assert_eq!(s.population.get(hs[0]).is_none(), success);
        assert!(hs[1..].iter().all(|h| s.population.get(*h).is_some()));
    }
}
#[test]
fn tiny_positive_basal_and_current_thermal_cost_apply_to_carnivores() {
    for basal in [f64::from_bits(1), 0.1] {
        let mut s = fixture(1, 4, 0, 0, 1, 1_000_000., basal);
        let c = ids(&s, Kind::Carnivore)[0];
        for pref in [0, 65535] {
            let mut a = [32768; 12];
            a[7] = pref;
            a[9] = 0;
            s.population.fixture_mut(c).genome = Genome::from_alleles(a);
            let before = s.population.get(c).unwrap().energy();
            let cost = upkeep(&s, c);
            let r = s.rng_state();
            s.carnivores();
            let after = s.population.get(c).unwrap().energy();
            assert!(after < before);
            close(before - after, cost);
            assert_eq!(s.rng_state(), r);
        }
    }
}

#[test]
fn satiety_gate_after_upkeep_preserves_age_cost_and_rng_at_boundary() {
    for post in [749.999, 750., 750.001] {
        let (mut s, h, c) = pair(17);
        let cost = upkeep(&s, c);
        s.population.fixture_mut(c).energy = post + cost;
        let rng = s.rng.clone();
        let mut expected = rng.clone();
        if post < 750. {
            expected
                .chance(independent_odds(&s, c, h), 1_000_000)
                .unwrap();
        }
        s.carnivores();
        assert_eq!(s.population.get(c).unwrap().age(), 1);
        assert_eq!(s.rng, expected);
        if post >= 750. {
            assert!(s.population.get(h).is_some());
            close(s.population.get(c).unwrap().energy(), post);
        }
    }
    // A real completed tick: no prey/no action draws while satiated, then hunger
    // eventually enables paid exploration, without any change to maintenance.
    let mut s = fixture(19, 19, 0, 0, 1, 0.2, 0.1);
    let c = ids(&s, Kind::Carnivore)[0];
    s.population.fixture_mut(c).energy = 750.5;
    let origin = s.population.get(c).unwrap().position();
    let rng = s.rng_state();
    s.advance_one_tick().unwrap();
    assert_eq!(s.rng_state(), rng);
    assert_eq!(s.population.get(c).unwrap().position(), origin);
    assert_eq!(s.population.get(c).unwrap().age(), 1);
    assert!(s.population.get(c).unwrap().energy() < 750.5);
    for _ in 0..10 {
        s.advance_one_tick().unwrap();
    }
    assert_ne!(s.rng_state(), rng);
}

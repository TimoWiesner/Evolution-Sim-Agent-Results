//! Coherent founder fixtures; actual full-tick policies and raw-draw DNA oracle.
use super::*;
use crate::genome::Genome;
fn raw_below(r: &mut Rng, bound: u64) -> u64 {
    let threshold = bound.wrapping_neg() % bound;
    loop {
        let v = r.next_u64();
        if v >= threshold {
            return v % bound;
        }
    }
}
fn child_reference(a: Genome, b: Option<Genome>, r: &mut Rng) -> Genome {
    let mut dna = *a.alleles();
    if let Some(b) = b {
        let cut = 1 + raw_below(r, 11) as usize;
        let orientation = raw_below(r, 2);
        for (i, v) in dna.iter_mut().enumerate() {
            *v = if (i < cut) == (orientation == 0) {
                a.alleles()[i]
            } else {
                b.alleles()[i]
            };
        }
    }
    for v in &mut dna {
        let z = raw_below(r, 131070) as i32;
        let delta = if z < 65535 { z - 65535 } else { z - 65535 + 1 };
        *v = (i32::from(*v) + delta).clamp(0, 65535) as u16;
    }
    Genome::from_alleles(dna)
}
fn fixture(kind: Kind, seed: u64) -> Simulation {
    let (plants, herbs, carns, w) = match kind {
        Kind::Plant => (1, 0, 0, 2),
        Kind::Herbivore => (0, 2, 0, 1),
        Kind::Carnivore => (0, 0, 2, 1),
    };
    let config=Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":{w},"height":1}},"initial":{{"plants":{plants},"herbivores":{herbs},"carnivores":{carns}}},"genetics":{{"mutation_per_million":1000000,"mutation_max_step":65535}},"animals":{{"movement_cost":0,"basal_cost":0.000001}},"climate":{{"weather_amplitude":0}},"plants":{{"growth_efficiency":0,"resource_capacity":10,"resource_regeneration":0,"dispersal_radius":1}}}}"#)).unwrap();
    let mut s = Simulation::new(config).unwrap();
    for (i, id) in s.population.phase_ids(kind).into_iter().enumerate() {
        let o = s.population.fixture_mut(id);
        let mut dna = [32768 + 8000 * i as u16; 12];
        dna[4] = 65535;
        o.genome = Genome::from_alleles(dna);
        o.health = 1.;
        o.age = 200;
    }
    s.population.fixture_species_from_genomes();
    s
}
#[test]
fn full_tick_plant_and_both_animal_policies_force_split_with_raw_dna_oracle() {
    for kind in Kind::ALL {
        let mut found = None;
        for seed in 0..256 {
            let mut s = fixture(kind, seed);
            let ids = s.population.phase_ids(kind);
            let parents: Vec<_> = ids
                .iter()
                .map(|id| s.population.get(*id).unwrap().clone())
                .collect();
            if kind != Kind::Plant {
                assert_ne!(parents[0].species_id(), parents[1].species_id());
                assert!(5 * parents[0].genome().distance_sum(parents[1].genome()) <= 786420);
            }
            let mut full = s.clone();
            full.advance_one_tick().unwrap();
            s.tick = 1;
            s.climate_resources();
            s.plants();
            s.herbivores();
            s.carnivores();
            let mut reference = s.rng.clone();
            // Max fertility has no probability draw. Plant chooses one of two cells.
            if kind == Kind::Plant {
                let x = raw_below(&mut reference, 2);
                assert_eq!(raw_below(&mut reference, 1), 0);
                if x == 0 {
                    continue;
                }
            }
            let expected = child_reference(
                *parents[0].genome(),
                parents.get(1).map(|p| *p.genome()),
                &mut reference,
            );
            if parents
                .iter()
                .any(|p| 10 * expected.distance_sum(p.genome()) <= 786420)
            {
                continue;
            }
            s.reproduction();
            s.commit();
            assert_eq!(s, full);
            let child = s
                .population
                .iter()
                .find(|o| o.birth_tick() == 1)
                .expect("actual paid policy child");
            assert_eq!(child.genome(), &expected);
            assert_eq!(s.rng, reference);
            assert_eq!(child.parents(), ids.as_slice());
            assert_eq!(child.age(), 0);
            let id = child.id();
            let species = child.species_id();
            let record = s.population.species().get(species).unwrap();
            assert_eq!(record.id().value(), id.value());
            assert_eq!(record.parent_species(), Some(parents[0].species_id()));
            assert_eq!(record.origin_tick(), 1);
            assert_eq!(record.founder_genome(), &expected);
            for p in &parents {
                assert_eq!(
                    s.population.get(p.id()).unwrap().species_id(),
                    p.species_id()
                );
            }
            s.advance_one_tick().unwrap();
            if let Some(c) = s.population.get(id) {
                assert_eq!(c.age(), 1);
                assert_eq!(c.species_id(), species);
            }
            found = Some(seed);
            break;
        }
        assert!(
            found.is_some(),
            "no divergent production birth for {kind:?}"
        );
        eprintln!(
            "species full-tick divergence {kind:?}: seed {}",
            found.unwrap()
        );
    }
}

#[test]
fn checkpoint_preserves_forced_speciation_cooldowns_and_future() {
    use crate::persistence::{checkpoint_bytes, from_checkpoint_bytes};
    for kind in Kind::ALL {
        let mut found = false;
        for seed in 0..256 {
            let mut s = fixture(kind, seed);
            // Make the controlled mature founders' clocks coherent for restoration.
            s.tick = 200;
            s.world.temporal_climate = TemporalClimate::from_state(
                s.config.climate().clone(),
                crate::temporal_climate::WeatherState::new(1, 200, 0., 0.).unwrap(),
            )
            .unwrap();
            s.advance_one_tick().unwrap();
            if s.population.totals().births.get(kind) == 0
                || s.population.species().iter().count() < if kind == Kind::Plant { 2 } else { 3 }
            {
                continue;
            }
            let mut restored = from_checkpoint_bytes(&checkpoint_bytes(&s).unwrap()).unwrap();
            assert_eq!(s, restored);
            for _ in 0..100 {
                s.advance_one_tick().unwrap();
                restored.advance_one_tick().unwrap();
                assert_eq!(s, restored);
            }
            found = true;
            break;
        }
        assert!(found, "no forced speciation fixture for {kind:?}");
    }
}

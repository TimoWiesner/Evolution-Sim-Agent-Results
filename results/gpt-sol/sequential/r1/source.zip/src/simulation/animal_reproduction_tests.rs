//! Controlled existing-record fixtures, always invoking production mating policy.
use super::*;
use crate::genome::Genome;
fn fixture(kind: Kind, n: usize, w: usize, h: usize, fertility: u16, rate: u32) -> Simulation {
    let (herbs, carns) = if kind == Kind::Herbivore {
        (n, 0)
    } else {
        (0, n)
    };
    let mut s=Simulation::new(Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":0,"herbivores":{herbs},"carnivores":{carns}}},"animals":{{"basal_cost":0.000001,"movement_cost":0}},"plants":{{"reproduction_energy":1001}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":1024}},"climate":{{"weather_amplitude":0}}}}"#)).unwrap()).unwrap();
    for id in s.population.phase_ids(kind) {
        let o = s.population.fixture_mut(id);
        o.age = 110;
        let mut a = [32768; 12];
        a[4] = fertility;
        o.genome = Genome::from_alleles(a);
    }
    s.tick = 10;
    s
}
fn place(s: &mut Simulation, id: OrganismId, x: i128, y: i128) {
    let t = s.world.topology;
    let to = t.cell(x, y);
    while s.population.get(id).unwrap().position() != to {
        let from = s.population.get(id).unwrap().position();
        s.population
            .move_one_step(id, next_toward(t, from, to).unwrap())
            .unwrap();
    }
}
fn set_config(s: &mut Simulation, key: &str, value: serde_json::Value) {
    let mut v: serde_json::Value = serde_json::from_str(&s.config.to_json().unwrap()).unwrap();
    v["animals"][key] = value;
    s.config = Config::from_json(&v.to_string()).unwrap();
}
#[test]
fn both_kinds_contact_seams_and_degenerate_axes_pay_and_record_lineage() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for (w, h) in [(7, 7), (1, 7), (7, 1), (1, 1)] {
            for (x, y) in [
                (0, 0),
                (1, 0),
                (0, 1),
                (1, 1),
                (-1, 0),
                (0, -1),
                (-1, -1),
                (2, 0),
            ] {
                let mut s = fixture(kind, 2, w, h, 65535, 0);
                let ids = s.population.phase_ids(kind);
                place(&mut s, ids[0], 0, 0);
                place(&mut s, ids[1], x, y);
                let distance = s.world.topology.distance(
                    s.population.get(ids[0]).unwrap().position(),
                    s.population.get(ids[1]).unwrap().position(),
                );
                s.population.fixture_mut(ids[0]).generation = 3;
                s.population.fixture_mut(ids[1]).generation = 7;
                let mut r = s.rng.clone();
                let expected = s.population.get(ids[0]).unwrap().genome().crossover_child(
                    s.population.get(ids[1]).unwrap().genome(),
                    s.config.genetics(),
                    &mut r,
                );
                s.animal_reproduction(kind);
                for id in &ids {
                    let p = s.population.get(*id).unwrap();
                    assert_eq!(p.energy(), if distance <= 1 { 970. } else { 1000. });
                    assert_eq!(p.last_reproduction_tick(), (distance <= 1).then_some(10));
                }
                let before = s.rng.clone();
                s.commit();
                assert_eq!(s.rng, before);
                assert_eq!(
                    s.population.counts().get(kind),
                    if distance <= 1 { 3 } else { 2 }
                );
                if distance <= 1 {
                    assert_eq!(s.rng, r);
                    let c = s.population.iter().find(|o| o.generation() == 8).unwrap();
                    assert_eq!(c.genome(), &expected);
                    assert_eq!(c.parents(), ids.as_slice());
                    assert_eq!(c.position(), s.world.topology.cell(0, 0));
                    assert_eq!(c.age(), 0);
                    assert_eq!(c.energy(), 30.);
                    assert_eq!(c.health(), 10.);
                    assert_eq!(c.birth_tick(), 10);
                    assert_eq!(c.last_reproduction_tick(), None);
                    assert!(
                        s.population
                            .nearby(c.position(), 0, Some(kind))
                            .contains(&c.id())
                    );
                }
            }
        }
    }
}
#[test]
fn eligibility_gates_draw_nothing_and_never_pay() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for mode in 0..11 {
            let mut s = fixture(kind, 2, 7, 7, 65535, 0);
            let ids = s.population.phase_ids(kind);
            place(&mut s, ids[0], 0, 0);
            place(&mut s, ids[1], 0, 0);
            match mode {
                0 => s.population.fixture_mut(ids[0]).age = 109,
                1 => s.population.fixture_mut(ids[1]).age = 109,
                2 => s.population.fixture_mut(ids[0]).energy = 30.,
                3 => s.population.fixture_mut(ids[1]).energy = 29.,
                4 => s.population.fixture_mut(ids[0]).last_reproduction_tick = Some(9),
                5 => s.population.fixture_mut(ids[1]).last_reproduction_tick = Some(11),
                6 => s.population.fixture_mut(ids[1]).genome = Genome::from_alleles([0; 12]),
                7 => place(&mut s, ids[1], 2, 0),
                8 => {
                    s.population.kill(ids[1], 10, DeathCause::Predation);
                }
                9 => set_config(&mut s, "reproduction_energy", serde_json::json!(1001)),
                10 => set_config(
                    &mut s,
                    "reproduction_energy",
                    serde_json::json!(f64::from_bits(1)),
                ),
                _ => unreachable!(),
            }
            let before = s.clone();
            s.animal_reproduction(kind);
            assert_eq!(s, before, "mode {mode}");
        }
        let mut s = fixture(kind, 1, 1, 1, 65535, 0);
        let before = s.clone();
        s.animal_reproduction(kind);
        assert_eq!(s, before);
    }
    let mut s=Simulation::new(Config::from_json(r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":1,"carnivores":1}}"#).unwrap()).unwrap();
    for id in s
        .population
        .phase_ids(Kind::Herbivore)
        .into_iter()
        .chain(s.population.phase_ids(Kind::Carnivore))
    {
        s.population.fixture_mut(id).age = 110;
    }
    let before = s.clone();
    s.reproduction();
    assert_eq!(s, before);
}
#[test]
fn independent_trial_crossover_mutation_reference_and_fertility_monotonicity() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for rate in [0, 1_000_000] {
            let mut successes = 0;
            for seed in 0..512 {
                let mut s = fixture(kind, 2, 1, 1, 32768, rate);
                let ids = s.population.phase_ids(kind);
                let mut a = [30000; 12];
                a[4] = 32768;
                let mut b = [35000; 12];
                b[4] = 40000;
                s.population.fixture_mut(ids[0]).genome = Genome::from_alleles(a);
                s.population.fixture_mut(ids[0]).age = 200;
                s.population.fixture_mut(ids[1]).age = 200;
                s.population.fixture_mut(ids[1]).genome = Genome::from_alleles(b);
                s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
                let mut r = s.rng.clone();
                let success = r.chance(32768 * 40000, 65535 * 65535).unwrap();
                let expected = if success {
                    let boundary = 1 + r.below(11).unwrap() as usize;
                    let reverse = r.below(2).unwrap() == 1;
                    let mut child = [0; 12];
                    for i in 0..12 {
                        child[i] = if (i < boundary) != reverse {
                            a[i]
                        } else {
                            b[i]
                        };
                        if rate != 0 {
                            let z = r.below(2048).unwrap() as i32;
                            let d = if z < 1024 { z - 1024 } else { z - 1023 };
                            child[i] = (child[i] as i32 + d).clamp(0, 65535) as u16;
                        }
                    }
                    Some(Genome::from_alleles(child))
                } else {
                    None
                };
                s.animal_reproduction(kind);
                assert_eq!(s.rng, r);
                s.commit();
                assert_eq!(s.rng, r);
                assert_eq!(s.population.totals().births.get(kind), u128::from(success));
                for id in ids {
                    assert_eq!(
                        s.population.get(id).unwrap().energy(),
                        if success { 970. } else { 1000. }
                    );
                }
                if let Some(expected) = expected {
                    successes += 1;
                    assert_eq!(s.population.iter().last().unwrap().genome(), &expected);
                }
            }
            assert!(successes > 50 && successes < 400);
        }
        let mut totals = [0, 0];
        for seed in 0..4096 {
            let mut outcomes = [false; 2];
            for (i, f) in [20000, 50000].into_iter().enumerate() {
                let mut s = fixture(kind, 2, 1, 1, f, 0);
                s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
                s.animal_reproduction(kind);
                s.commit();
                outcomes[i] = s.population.totals().births.get(kind) > 0;
                totals[i] += usize::from(outcomes[i]);
            }
            assert!(!outcomes[0] || outcomes[1]);
        }
        assert!(totals[1] > totals[0]);
        for f in [0, 65535] {
            let mut s = fixture(kind, 2, 1, 1, f, 0);
            let mut r = s.rng.clone();
            if f != 0 {
                r.below(11).unwrap();
                r.below(2).unwrap();
            }
            s.animal_reproduction(kind);
            s.commit();
            assert_eq!(s.rng, r);
            assert_eq!(s.population.totals().births.get(kind), u128::from(f != 0));
        }
    }
}
#[test]
fn cooldown_both_parents_exact_boundaries_clone_and_no_third_partner_reuse() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for cooldown in [1, 20, u64::MAX] {
            let mut s = fixture(kind, 3, 1, 1, 65535, 0);
            set_config(&mut s, "reproduction_cooldown", serde_json::json!(cooldown));
            let ids = s.population.phase_ids(kind);
            s.tick = 0;
            s.animal_reproduction(kind);
            s.commit();
            assert_eq!(s.population.totals().births.get(kind), 1);
            for id in &ids[..2] {
                assert_eq!(
                    s.population.get(*id).unwrap().last_reproduction_tick(),
                    Some(0)
                );
            }
            assert_eq!(
                s.population.get(ids[2]).unwrap().last_reproduction_tick(),
                None
            );
            let mut clone = s.clone();
            let ticks: Vec<_> = if cooldown == 20 {
                (0..=20).collect()
            } else {
                vec![0, cooldown - 1, cooldown]
            };
            for tick in ticks {
                for x in [&mut s, &mut clone] {
                    x.tick = tick;
                    x.animal_reproduction(kind);
                    x.commit();
                }
                assert_eq!(s, clone);
                assert_eq!(
                    s.population.totals().births.get(kind),
                    if tick == cooldown { 2 } else { 1 }
                );
            }
        }
    }
}
#[test]
fn failures_reserve_attempts_but_not_energy_or_cooldown_and_request_errors_rollback() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        let mut s = fixture(kind, 4, 1, 1, 32768, 0);
        let ids = s.population.phase_ids(kind);
        let mut r = s.rng.clone();
        let a = r.chance(32768 * 32768, 65535 * 65535).unwrap();
        if a {
            r.below(11).unwrap();
            r.below(2).unwrap();
        }
        let b = r.chance(32768 * 32768, 65535 * 65535).unwrap();
        if b {
            r.below(11).unwrap();
            r.below(2).unwrap();
        }
        s.animal_reproduction(kind);
        assert_eq!(s.rng, r);
        s.commit();
        assert_eq!(
            s.population.totals().births.get(kind),
            u128::from(a) + u128::from(b)
        );
        for (pair, ok) in [(0, a), (2, b)] {
            for id in &ids[pair..pair + 2] {
                assert_eq!(
                    s.population.get(*id).unwrap().last_reproduction_tick(),
                    ok.then_some(10)
                );
            }
        }
        for overflow in [false, true] {
            let mut s = fixture(kind, 2, 1, 1, 32768, 1_000_000);
            let ids = s.population.phase_ids(kind);
            if overflow {
                s.population.fixture_mut(ids[1]).generation = u64::MAX;
            } else {
                s.population.fixture_exhaust_ids();
            }
            let seed = (0..128)
                .find(|seed| {
                    Rng::from_seed(&crate::config::Seed::from_u64(*seed))
                        .chance(32768 * 32768, 65535 * 65535)
                        .unwrap()
                })
                .unwrap();
            s.rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
            let mut expected = s.clone();
            assert!(expected.rng.chance(32768 * 32768, 65535 * 65535).unwrap());
            s.animal_reproduction(kind);
            assert_eq!(s, expected);
        }
    }
}
#[test]
fn nearest_eligible_then_id_and_incompatible_nearest_skipped() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for incompatible in [false, true] {
            let mut s = fixture(kind, 4, 7, 7, 65535, 0);
            let ids = s.population.phase_ids(kind);
            for (id, x, y) in [
                (ids[0], 0, 0),
                (ids[1], 1, 1),
                (ids[2], 0, 0),
                (ids[3], -1, 0),
            ] {
                place(&mut s, id, x, y);
            }
            if incompatible {
                s.population.fixture_mut(ids[2]).genome = Genome::from_alleles([0; 12]);
            }
            s.animal_reproduction(kind);
            s.commit();
            let first = s
                .population
                .iter()
                .find(|o| o.parents().contains(&ids[0]))
                .unwrap();
            assert_eq!(
                first.parents(),
                &[ids[0], if incompatible { ids[1] } else { ids[2] }]
            );
        }
    }
}
#[test]
fn real_tick_births_age_zero_and_earlier_deaths_preempt_mating() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        let mut s = fixture(kind, 2, 1, 1, 65535, 1_000_000);
        let ids = s.population.phase_ids(kind);
        let mut reference = s.clone();
        reference.tick += 1;
        reference.climate_resources();
        reference.plants();
        reference.herbivores();
        reference.carnivores();
        let e = reference.population.get(ids[0]).unwrap().energy();
        reference.reproduction();
        reference.commit();
        s.advance_one_tick().unwrap();
        assert_eq!(s, reference);
        let child = s.population.iter().last().unwrap();
        assert_eq!(child.age(), 0);
        assert_eq!(child.energy(), 30.);
        let child = child.id();
        assert_eq!(s.population.get(ids[0]).unwrap().energy(), e - 30.);
        s.advance_one_tick().unwrap();
        assert_eq!(s.population.get(child).unwrap().age(), 1);
        for mode in 0..3 {
            let mut s = fixture(kind, 2, 1, 1, 65535, 0);
            let ids = s.population.phase_ids(kind);
            match mode {
                0 => s.population.fixture_mut(ids[0]).age = 1099,
                1 => s.population.fixture_mut(ids[0]).energy = f64::from_bits(1),
                _ => {
                    s.population.kill(ids[0], s.tick, DeathCause::Predation);
                }
            }
            s.advance_one_tick().unwrap();
            assert_eq!(s.population.totals().births.get(kind), 0);
        }
    }
}

#[test]
fn actual_energy_budgets_thresholds_and_either_parent_zero_fertility() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for cost in [
            f64::from_bits(1),
            f64::MIN_POSITIVE,
            1e-14,
            30.,
            999.,
            1000.,
            1001.,
        ] {
            for (e1, e2) in [(1000., 1000.), (30., 1000.), (30.00000001, 999.9)] {
                let mut s = fixture(kind, 2, 1, 1, 65535, 0);
                set_config(&mut s, "reproduction_energy", serde_json::json!(cost));
                let ids = s.population.phase_ids(kind);
                s.population.fixture_mut(ids[0]).energy = e1;
                s.population.fixture_mut(ids[1]).energy = e2;
                let residuals = [e1 - cost, e2 - cost];
                let expected = cost <= 1000.
                    && e1 > cost
                    && e2 > cost
                    && e1 - residuals[0] > 0.
                    && e2 - residuals[1] > 0.
                    && (e1 - residuals[0]) + (e2 - residuals[1]) >= cost;
                let before = s.clone();
                s.animal_reproduction(kind);
                s.commit();
                assert_eq!(s.population.totals().births.get(kind), u128::from(expected));
                if expected {
                    let loss = (e1 - s.population.get(ids[0]).unwrap().energy())
                        + (e2 - s.population.get(ids[1]).unwrap().energy());
                    assert!(loss >= s.population.iter().last().unwrap().energy());
                    for (i, id) in ids.iter().enumerate() {
                        assert_eq!(s.population.get(*id).unwrap().energy(), residuals[i]);
                    }
                } else {
                    assert_eq!(s, before);
                }
            }
        }
        for zero in 0..2 {
            let mut s = fixture(kind, 2, 1, 1, 65535, 0);
            let ids = s.population.phase_ids(kind);
            let mut a = [32768; 12];
            a[4] = 0;
            s.population.fixture_mut(ids[zero]).genome = Genome::from_alleles(a);
            let before = s.clone();
            s.animal_reproduction(kind);
            assert_eq!(s, before);
        }
    }
}
#[test]
fn accepted_paid_child_survives_parent_death_and_pair_stamp_validates_atomically() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        let mut s = fixture(kind, 2, 1, 1, 65535, 0);
        let ids = s.population.phase_ids(kind);
        let before = s.population.clone();
        assert_eq!(
            s.population.record_reproduction_pair([ids[0], ids[0]], 10),
            Err(PopulationError::InvalidParents)
        );
        assert_eq!(s.population, before);
        s.animal_reproduction(kind);
        s.population.kill(ids[0], 10, DeathCause::Predation);
        s.population.kill(ids[1], 10, DeathCause::Starvation);
        let before = s.population.clone();
        assert_eq!(
            s.population.record_reproduction_pair([ids[0], ids[1]], 10),
            Err(PopulationError::MissingOrganism)
        );
        assert_eq!(s.population, before);
        let r = s.rng.clone();
        s.commit();
        assert_eq!(s.rng, r);
        assert_eq!(s.population.counts().get(kind), 1);
        let c = s.population.iter().next().unwrap();
        assert_eq!(c.parents(), ids.as_slice());
        assert_eq!(c.energy(), 30.);
        assert_eq!(
            s.population.totals().initial.get(kind) + s.population.totals().births.get(kind)
                - s.population.totals().deaths.get(kind),
            1
        );
    }
}
#[test]
fn full_tick_orders_weather_actions_plant_birth_then_both_sexual_births() {
    let mut observed = false;
    for seed in 0..64 {
        let config=Config::from_json(&format!(r#"{{"seed":{seed},"world":{{"width":2,"height":1}},"initial":{{"plants":1,"herbivores":2,"carnivores":2}},"animals":{{"movement_cost":0,"basal_cost":0.000001,"reproduction_energy":0.01}},"climate":{{"weather_amplitude":1}}}}"#)).unwrap();
        let mut s = Simulation::new(config).unwrap();
        let ids: Vec<_> = s.population.iter().map(|o| o.id()).collect();
        for id in ids {
            let o = s.population.fixture_mut(id);
            let mut a = [32768; 12];
            a[4] = 65535;
            o.genome = Genome::from_alleles(a);
            if o.kind() != Kind::Plant {
                o.age = 110;
            }
            if o.kind() == Kind::Carnivore {
                o.energy = 0.1;
            }
        }
        let mut reference = s.clone();
        reference.tick = 1;
        reference.climate_resources();
        reference.plants();
        reference.herbivores();
        reference.carnivores();
        reference.plant_reproduction();
        let mut probe = reference.clone();
        probe.commit();
        if probe.population.totals().births.get(Kind::Plant) == 0 {
            continue;
        }
        reference.animal_reproduction(Kind::Herbivore);
        reference.animal_reproduction(Kind::Carnivore);
        reference.commit();
        s.advance_one_tick().unwrap();
        assert_eq!(s, reference);
        for kind in Kind::ALL {
            assert_eq!(s.population.totals().births.get(kind), 1);
        }
        for child in s.population.iter().filter(|o| o.generation() == 1) {
            assert_eq!(child.age(), 0);
            assert_eq!(child.birth_tick(), 1);
            assert_eq!(child.last_reproduction_tick(), None);
        }
        observed = true;
        break;
    }
    assert!(observed, "no seed exercised all three production births");
}

#[test]
fn policy_uses_inclusive_integer_compatibility_threshold() {
    for kind in [Kind::Herbivore, Kind::Carnivore] {
        for sum in [157283, 157284, 157285] {
            let mut s = fixture(kind, 2, 1, 1, 65535, 0);
            let ids = s.population.phase_ids(kind);
            let mut a = [0; 12];
            a[4] = 65535;
            let mut b = a;
            b[0] = 65535;
            b[1] = 65535;
            b[2] = (sum - 131070) as u16;
            for (id, dna) in [(ids[0], a), (ids[1], b)] {
                let o = s.population.fixture_mut(id);
                o.genome = Genome::from_alleles(dna);
                o.health = 10.;
            }
            let before = s.clone();
            s.animal_reproduction(kind);
            s.commit();
            assert_eq!(
                s.population.totals().births.get(kind),
                u128::from(sum <= 157284)
            );
            if sum > 157284 {
                assert_eq!(s, before);
            }
        }
    }
}

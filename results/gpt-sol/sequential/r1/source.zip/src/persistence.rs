//! Complete-state hashing and versioned, validated checkpoint restoration.
use crate::{canonical::Encoder, simulation::Simulation};
use sha2::{Digest, Sha256};
use std::io::{self, Write};
pub const STATE_HASH_SCHEMA: u32 = crate::canonical::STATE_SCHEMA;
struct HashWriter(Sha256);
impl Write for HashWriter {
    fn write(&mut self, bytes: &[u8]) -> io::Result<usize> {
        self.0.update(bytes);
        Ok(bytes.len())
    }
    fn flush(&mut self) -> io::Result<()> {
        Ok(())
    }
}
/// Hash every authoritative field at a completed tick, without drawing RNG.
pub fn state_hash(simulation: &Simulation) -> io::Result<String> {
    let mut encoder = Encoder(HashWriter(Sha256::new()));
    simulation.write_canonical(&mut encoder)?;
    Ok(format!("{:x}", encoder.0.0.finalize()))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{canonical::collect, config::Config};
    #[test]
    fn sha256_known_vectors_and_independent_canonical_fixture() {
        assert_eq!(
            format!("{:x}", Sha256::digest(b"")),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
        assert_eq!(
            format!("{:x}", Sha256::digest(b"abc")),
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        );
        let sim = Simulation::new(Config::from_json(r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap()).unwrap();
        let bytes = collect(|w| sim.write_canonical(w));
        assert_eq!(&bytes[..16], b"EVOSIM-STATE\x01\x00\x00\x00");
        let mut child = std::process::Command::new("python3")
            .args([
                "-c",
                "import sys,hashlib; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())",
            ])
            .stdin(std::process::Stdio::piped())
            .stdout(std::process::Stdio::piped())
            .spawn()
            .unwrap();
        child.stdin.take().unwrap().write_all(&bytes).unwrap();
        let output = child.wait_with_output().unwrap();
        assert!(output.status.success());
        let hash = state_hash(&sim).unwrap();
        assert_eq!(String::from_utf8(output.stdout).unwrap().trim(), hash);
        assert_eq!(
            hash,
            "95453b3903f1d49e65d01fc7f06b8ae6596e95988da05afc4ae315c8f493d522"
        );
    }
}

const CHECKPOINT_MAGIC: &[u8; 17] = b"EVOSIM-CHECKPOINT";
pub const CHECKPOINT_VERSION: u32 = 1;
/// Encode a completed tick without consuming random numbers or changing state.
pub fn checkpoint_bytes(simulation: &Simulation) -> io::Result<Vec<u8>> {
    let mut payload = Encoder(Vec::new());
    simulation.write_canonical(&mut payload)?;
    let mut out = Encoder(Vec::new());
    out.bytes(CHECKPOINT_MAGIC)?;
    out.u32(CHECKPOINT_VERSION)?;
    out.usize(payload.0.len())?;
    out.bytes(&payload.0)?;
    let checksum = Sha256::digest(&out.0);
    out.bytes(&checksum)?;
    Ok(out.0)
}
/// Validate the envelope and every owner before exposing a restored engine.
pub fn from_checkpoint_bytes(bytes: &[u8]) -> io::Result<Simulation> {
    use crate::canonical::{Decoder, require};
    let mut r = Decoder::new(bytes);
    require(r.bytes(17)? == CHECKPOINT_MAGIC, "invalid checkpoint magic")?;
    require(
        r.u32()? == CHECKPOINT_VERSION,
        "unsupported checkpoint version",
    )?;
    let n = r.usize()?;
    let payload = r.bytes(n)?;
    let checksum = r.bytes(32)?;
    require(r.finished(), "trailing checkpoint bytes")?;
    require(
        &Sha256::digest(&bytes[..bytes.len() - 32])[..] == checksum,
        "checkpoint checksum mismatch",
    )?;
    let mut state = Decoder::new(payload);
    let simulation = Simulation::read_canonical(&mut state)?;
    require(state.finished(), "trailing state bytes")?;
    let mut encoded = Encoder(Vec::new());
    simulation.write_canonical(&mut encoded)?;
    require(encoded.0 == payload, "noncanonical checkpoint state")?;
    Ok(simulation)
}
/// Load only regular files, avoiding blocking reads from special files.
pub fn load_checkpoint(path: impl AsRef<std::path::Path>) -> io::Result<Simulation> {
    let path = path.as_ref();
    crate::canonical::require(
        std::fs::symlink_metadata(path)?.file_type().is_file(),
        "checkpoint must be a regular file",
    )?;
    from_checkpoint_bytes(&std::fs::read(path)?)
        .map_err(|e| crate::canonical::invalid(format!("checkpoint {}: {e}", path.display())))
}

#[cfg(test)]
mod checkpoint_semantic_tests {
    use super::*;
    use crate::{
        canonical::{Encoder, collect},
        config::Config,
    };
    fn replace(bytes: &mut [u8], needle: &[u8], offset: usize, replacement: &[u8]) {
        let positions: Vec<_> = bytes[..bytes.len() - 32]
            .windows(needle.len())
            .enumerate()
            .filter_map(|(i, b)| (b == needle).then_some(i))
            .collect();
        assert_eq!(positions.len(), 1, "fixture must locate one record");
        let i = positions[0] + offset;
        bytes[i..i + replacement.len()].copy_from_slice(replacement);
        let n = bytes.len() - 32;
        let sum = Sha256::digest(&bytes[..n]);
        bytes[n..].copy_from_slice(&sum);
    }
    #[test]
    fn recomputed_checksum_does_not_bypass_model_rng_weather_resource_or_length_validation() {
        let sim = Simulation::new(Config::default()).unwrap();
        let original = checkpoint_bytes(&sim).unwrap();
        let rng = collect(|w| sim.rng_state().write_canonical(w));
        for (offset, value) in [(0, 2u32.to_le_bytes().to_vec()), (4, vec![0; 32])] {
            let mut b = original.clone();
            replace(&mut b, &rng, offset, &value);
            assert!(from_checkpoint_bytes(&b).is_err());
        }
        let weather = collect(|w| sim.world().temporal_climate().write_canonical(w));
        let mut b = original.clone();
        replace(
            &mut b,
            &weather,
            weather.len() - 8,
            &f64::NAN.to_bits().to_le_bytes(),
        );
        assert!(from_checkpoint_bytes(&b).is_err());
        let resources = collect(|w| sim.world().resources().write_canonical(w));
        for (offset, value) in [
            (16, u64::MAX.to_le_bytes()),
            (24, f64::INFINITY.to_bits().to_le_bytes()),
        ] {
            let mut b = original.clone();
            replace(&mut b, &resources, offset, &value);
            assert!(from_checkpoint_bytes(&b).is_err());
        }
        let model = collect(|w| {
            w.string("scheduler")?;
            w.u32(1)
        });
        let mut b = original.clone();
        replace(&mut b, &model, model.len() - 4, &2u32.to_le_bytes());
        assert!(from_checkpoint_bytes(&b).is_err());
        let mut b = original.clone();
        let schema = b[29..45].to_vec();
        replace(&mut b, &schema, 12, &2u32.to_le_bytes());
        assert!(from_checkpoint_bytes(&b).is_err());
        for n in [0, u64::MAX] {
            let mut b = original.clone();
            b[21..29].copy_from_slice(&n.to_le_bytes());
            assert!(from_checkpoint_bytes(&b).is_err());
        }
        // A valid checksum around an arbitrary byte corpus must not panic either.
        let mut word = 7u64;
        for n in 0..512 {
            let payload: Vec<_> = (0..n)
                .map(|_| {
                    word = word.wrapping_mul(6364136223846793005).wrapping_add(1);
                    (word >> 32) as u8
                })
                .collect();
            let mut w = Encoder(Vec::new());
            w.bytes(CHECKPOINT_MAGIC).unwrap();
            w.u32(1).unwrap();
            w.usize(n).unwrap();
            w.bytes(&payload).unwrap();
            let checksum = Sha256::digest(&w.0);
            w.bytes(&checksum).unwrap();
            assert!(from_checkpoint_bytes(&w.0).is_err());
        }
    }
}

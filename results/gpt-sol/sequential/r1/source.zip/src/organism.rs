//! Shared life records with immutable DNA and derived phenotype.
use crate::genome::Genome;
use crate::topology::Cell;
pub use crate::traits::{TraitError, TraitValues, Traits};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum Kind {
    Plant,
    Herbivore,
    Carnivore,
}
impl Kind {
    pub const ALL: [Self; 3] = [Self::Plant, Self::Herbivore, Self::Carnivore];
    pub(crate) fn index(self) -> usize {
        self as usize
    }
}
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct OrganismId(pub(crate) u64);
impl OrganismId {
    pub fn value(self) -> u64 {
        self.0
    }
}

/// Permanent genetic classification; IDs may have gaps.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SpeciesId(pub(crate) u64);
impl SpeciesId {
    pub fn value(self) -> u64 {
        self.0
    }
}

pub const ENERGY_CAPACITY: f64 = 1000.;
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub enum DeathCause {
    Starvation,
    Injury,
    Predation,
    OldAge,
    Climate,
}
impl DeathCause {
    pub const ALL: [Self; 5] = [
        Self::Starvation,
        Self::Injury,
        Self::Predation,
        Self::OldAge,
        Self::Climate,
    ];
    pub(crate) fn index(self) -> usize {
        self as usize
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct Organism {
    pub(crate) id: OrganismId,
    pub(crate) kind: Kind,
    pub(crate) species_id: SpeciesId,
    pub(crate) position: Cell,
    pub(crate) age: u64,
    pub(crate) energy: f64,
    pub(crate) health: f64,
    pub(crate) genome: Genome,
    pub(crate) parents: Vec<OrganismId>,
    pub(crate) generation: u64,
    pub(crate) birth_tick: u64,
    pub(crate) last_reproduction_tick: Option<u64>,
}
impl Organism {
    pub fn id(&self) -> OrganismId {
        self.id
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    pub fn species_id(&self) -> SpeciesId {
        self.species_id
    }
    pub fn position(&self) -> Cell {
        self.position
    }
    pub fn age(&self) -> u64 {
        self.age
    }
    pub fn energy(&self) -> f64 {
        self.energy
    }
    pub fn health(&self) -> f64 {
        self.health
    }
    pub fn genome(&self) -> &Genome {
        &self.genome
    }
    pub fn traits(&self) -> Traits {
        self.genome.traits()
    }
    pub fn parents(&self) -> &[OrganismId] {
        &self.parents
    }
    pub fn generation(&self) -> u64 {
        self.generation
    }
    /// Last accepted sexual birth; None for founders/newborns (unused on plants).
    pub fn last_reproduction_tick(&self) -> Option<u64> {
        self.last_reproduction_tick
    }
    pub fn birth_tick(&self) -> u64 {
        self.birth_tick
    }
}

impl Organism {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.u64(self.id.0)?;
        self.kind.write_canonical(w)?;
        w.u64(self.species_id.0)?;
        w.usize(self.position.x())?;
        w.usize(self.position.y())?;
        w.u64(self.age)?;
        w.f64(self.energy)?;
        w.f64(self.health)?;
        self.genome.write_canonical(w)?;
        w.usize(self.parents.len())?;
        for p in &self.parents {
            w.u64(p.0)?;
        }
        w.u64(self.generation)?;
        w.u64(self.birth_tick)?;
        w.option(self.last_reproduction_tick)
    }
}

impl Kind {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.u8(match self {
            Self::Plant => 0,
            Self::Herbivore => 1,
            Self::Carnivore => 2,
        })
    }
}
impl DeathCause {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.u8(match self {
            Self::Starvation => 0,
            Self::Injury => 1,
            Self::Predation => 2,
            Self::OldAge => 3,
            Self::Climate => 4,
        })
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let c = crate::config::Config::default();
        let p = crate::population::Population::initialize(
            crate::topology::Topology::new(64, 48).unwrap(),
            c.initial(),
        )
        .unwrap();
        let base = p.iter().next().unwrap().clone();
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut Organism| {
            v.id.0 += 1;
        });
        changed!(|v: &mut Organism| {
            v.kind = Kind::Carnivore;
        });
        changed!(|v: &mut Organism| {
            v.species_id.0 += 1;
        });
        changed!(|v: &mut Organism| {
            v.position = crate::topology::Topology::new(64, 48).unwrap().cell(1, 1);
        });
        changed!(|v: &mut Organism| {
            v.age += 1;
        });
        changed!(|v: &mut Organism| {
            v.energy = f64::from_bits(v.energy.to_bits() + 1);
        });
        changed!(|v: &mut Organism| {
            v.health = f64::from_bits(v.health.to_bits() + 1);
        });
        changed!(|v: &mut Organism| {
            v.parents.push(OrganismId(99));
        });
        changed!(|v: &mut Organism| {
            v.generation += 1;
        });
        changed!(|v: &mut Organism| {
            v.birth_tick += 1;
        });
        changed!(|v: &mut Organism| {
            v.last_reproduction_tick = Some(0);
        });

        changed!(|v: &mut Organism| {
            v.position = crate::topology::Topology::new(64, 48).unwrap().cell(1, 0);
        });
        changed!(|v: &mut Organism| {
            v.position = crate::topology::Topology::new(64, 48).unwrap().cell(0, 1);
        });
        let mut cooldown = base.clone();
        cooldown.last_reproduction_tick = Some(0);
        let zero = collect(|w| cooldown.write_canonical(w));
        cooldown.last_reproduction_tick = Some(1);
        assert_ne!(zero, collect(|w| cooldown.write_canonical(w)));
        for locus in 0..12 {
            changed!(|v: &mut Organism| {
                let mut alleles = *v.genome.alleles();
                alleles[locus] += 1;
                v.genome = Genome::from_alleles(alleles);
            });
        }
        let mut a = base.clone();
        a.parents = vec![OrganismId(1), OrganismId(2)];
        let mut b = a.clone();
        b.parents.reverse();
        assert_ne!(
            collect(|w| a.write_canonical(w)),
            collect(|w| b.write_canonical(w))
        );
    }
}

impl Kind {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        Self::ALL
            .get(r.u8()? as usize)
            .copied()
            .ok_or_else(|| crate::canonical::invalid("invalid kind"))
    }
}
impl DeathCause {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        Self::ALL
            .get(r.u8()? as usize)
            .copied()
            .ok_or_else(|| crate::canonical::invalid("invalid death cause"))
    }
}
impl Organism {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        topology: crate::topology::Topology,
        tick: u64,
    ) -> std::io::Result<Self> {
        use crate::canonical::require;
        let id = OrganismId(r.u64()?);
        let kind = Kind::read_canonical(r)?;
        let species_id = SpeciesId(r.u64()?);
        let x = r.usize()?;
        let y = r.usize()?;
        require(
            x < topology.width() && y < topology.height(),
            "cell outside world",
        )?;
        let position = topology.cell(x as i128, y as i128);
        let age = r.u64()?;
        let energy = r.f64()?;
        let health = r.f64()?;
        let genome = Genome::read_canonical(r)?;
        let n = r.count(8)?;
        require(n <= 2, "invalid parent count")?;
        let mut parents = Vec::new();
        for _ in 0..n {
            parents.push(OrganismId(r.u64()?));
        }
        let generation = r.u64()?;
        let birth_tick = r.u64()?;
        let last_reproduction_tick = r.option()?;
        require(id.0 > 0 && species_id.0 > 0, "zero organism/species ID")?;
        require(
            energy.is_finite()
                && energy > 0.
                && energy <= ENERGY_CAPACITY
                && health.is_finite()
                && health > 0.
                && health <= genome.traits().max_health(),
            "invalid living vitals",
        )?;
        require(
            birth_tick <= tick && age == tick - birth_tick,
            "invalid birth/age chronology",
        )?;
        require(
            last_reproduction_tick
                .is_none_or(|t| kind != Kind::Plant && t >= birth_tick && t <= tick),
            "invalid cooldown chronology",
        )?;
        require(
            (generation == 0 && birth_tick == 0 && parents.is_empty())
                || (generation > 0
                    && birth_tick > 0
                    && n == if kind == Kind::Plant { 1 } else { 2 }),
            "invalid lineage",
        )?;
        require(
            parents.iter().all(|p| p.0 > 0 && p.0 < id.0) && (n < 2 || parents[0] < parents[1]),
            "invalid parent IDs",
        )?;
        Ok(Self {
            id,
            kind,
            species_id,
            position,
            age,
            energy,
            health,
            genome,
            parents,
            generation,
            birth_tick,
            last_reproduction_tick,
        })
    }
}

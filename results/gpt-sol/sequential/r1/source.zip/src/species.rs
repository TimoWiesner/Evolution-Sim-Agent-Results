//! Stable immutable-founder classification and retained lineage (ADR-004).
use crate::genome::{Genome, MAX_DISTANCE_SUM};
pub use crate::organism::SpeciesId;
use crate::organism::{Kind, OrganismId};
use std::collections::BTreeMap;

pub const SPECIES_MODEL_VERSION: u32 = 1;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SpeciesRecord {
    id: SpeciesId,
    kind: Kind,
    name: String,
    founder_genome: Genome,
    parent_species: Option<SpeciesId>,
    origin_tick: u64,
    extinction_tick: Option<u64>,
    living_members: u128,
}
impl SpeciesRecord {
    pub fn id(&self) -> SpeciesId {
        self.id
    }
    pub fn kind(&self) -> Kind {
        self.kind
    }
    pub fn name(&self) -> &str {
        &self.name
    }
    pub fn founder_genome(&self) -> &Genome {
        &self.founder_genome
    }
    pub fn parent_species(&self) -> Option<SpeciesId> {
        self.parent_species
    }
    pub fn origin_tick(&self) -> u64 {
        self.origin_tick
    }
    pub fn extinction_tick(&self) -> Option<u64> {
        self.extinction_tick
    }
    pub fn living_members(&self) -> u128 {
        self.living_members
    }
}

#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct SpeciesRegistry {
    records: BTreeMap<SpeciesId, SpeciesRecord>,
}
impl SpeciesRegistry {
    pub(crate) fn new() -> Self {
        Self::default()
    }
    pub fn get(&self, id: SpeciesId) -> Option<&SpeciesRecord> {
        self.records.get(&id)
    }
    pub fn iter(&self) -> impl DoubleEndedIterator<Item = &SpeciesRecord> {
        self.records.values()
    }
    /// Current living species, including between internal death and Commit stages.
    pub fn living_count(&self, kind: Kind) -> usize {
        self.iter()
            .filter(|r| r.kind == kind && r.living_members > 0)
            .count()
    }
    pub(crate) fn assign(
        &mut self,
        kind: Kind,
        genome: Genome,
        first_member: OrganismId,
        parent_species: Option<SpeciesId>,
        tick: u64,
    ) -> SpeciesId {
        let nearest = self
            .iter()
            .filter(|r| r.kind == kind && r.extinction_tick.is_none())
            .map(|r| (genome.distance_sum(&r.founder_genome), r.id))
            .filter(|(s, _)| 10 * s <= MAX_DISTANCE_SUM)
            .min();
        if let Some((_, id)) = nearest {
            self.records.get_mut(&id).unwrap().living_members += 1;
            return id;
        }
        if let Some(parent) = parent_species {
            assert_eq!(self.records[&parent].kind, kind);
        }
        let id = SpeciesId(first_member.value());
        let prefix = match kind {
            Kind::Plant => "plant",
            Kind::Herbivore => "herbivore",
            Kind::Carnivore => "carnivore",
        };
        let old = self.records.insert(
            id,
            SpeciesRecord {
                id,
                kind,
                name: format!("{prefix}-{}", id.value()),
                founder_genome: genome,
                parent_species,
                origin_tick: tick,
                extinction_tick: None,
                living_members: 1,
            },
        );
        assert!(old.is_none(), "species first-member ID reused");
        id
    }
    pub(crate) fn remove_member(&mut self, id: SpeciesId) {
        let record = self.records.get_mut(&id).expect("missing member species");
        record.living_members = record
            .living_members
            .checked_sub(1)
            .expect("species count underflow");
    }
    pub(crate) fn finalize_extinctions(&mut self, tick: u64) {
        for r in self.records.values_mut() {
            if r.living_members == 0 && r.extinction_tick.is_none() {
                r.extinction_tick = Some(tick);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn g(sum: u32) -> Genome {
        let mut a = [0; 12];
        let mut left = sum;
        for v in &mut a {
            *v = left.min(65535) as u16;
            left -= u32::from(*v);
        }
        assert_eq!(left, 0);
        Genome::from_alleles(a)
    }
    #[test]
    fn exact_threshold_all_loci_kinds_and_immutable_founder() {
        for distance in [78641, 78642, 78643] {
            let mut r = SpeciesRegistry::new();
            let root = r.assign(Kind::Plant, g(0), OrganismId(1), None, 0);
            let genome = g(distance);
            let oracle: u32 = genome.alleles().iter().map(|&x| u32::from(x)).sum();
            assert_eq!(oracle, distance);
            let child = r.assign(Kind::Plant, genome, OrganismId(2), Some(root), 7);
            assert_eq!(child == root, distance <= 78642);
            assert_eq!(r.get(root).unwrap().founder_genome(), &g(0));
            assert_eq!(
                r.get(child).unwrap().origin_tick(),
                if child == root { 0 } else { 7 }
            );
            let herb = r.assign(Kind::Herbivore, genome, OrganismId(3), None, 0);
            let carn = r.assign(Kind::Carnivore, genome, OrganismId(4), None, 0);
            assert_ne!(child, herb);
            assert_ne!(herb, carn);
        }
        // Small steps do not move the founder or permit transitive chaining.
        let mut r = SpeciesRegistry::new();
        let root = r.assign(Kind::Plant, g(0), OrganismId(1), None, 0);
        assert_eq!(
            r.assign(Kind::Plant, g(50000), OrganismId(2), Some(root), 1),
            root
        );
        let split = r.assign(Kind::Plant, g(100000), OrganismId(3), Some(root), 2);
        assert_ne!(split, root);
        let next = r.assign(Kind::Plant, g(200000), OrganismId(4), Some(split), 3);
        assert_eq!(r.get(split).unwrap().parent_species(), Some(root));
        assert_eq!(r.get(next).unwrap().parent_species(), Some(split));
        assert_eq!(r.get(root).unwrap().living_members(), 2);
        // An inactive plant locus contributes equally.
        let mut a = [0; 12];
        a[10] = 65535;
        a[11] = 13108;
        assert_ne!(
            r.assign(
                Kind::Plant,
                Genome::from_alleles(a),
                OrganismId(5),
                Some(root),
                4
            ),
            root
        );
    }
    #[test]
    fn nearest_then_smallest_id_independent_of_map_insertion_order() {
        let mut r = SpeciesRegistry::new();
        let low = r.assign(Kind::Plant, g(0), OrganismId(1), None, 0);
        let high = r.assign(Kind::Plant, g(100000), OrganismId(2), None, 0);
        let mut reverse = SpeciesRegistry::new();
        for record in r.iter().rev() {
            reverse.records.insert(record.id, record.clone());
        }
        for (id, distance, expected) in [(3, 50000, low), (4, 60000, high)] {
            assert_eq!(
                r.assign(Kind::Plant, g(distance), OrganismId(id), Some(low), 1),
                expected
            );
            assert_eq!(
                reverse.assign(Kind::Plant, g(distance), OrganismId(id), Some(low), 1),
                expected
            );
        }
        assert_eq!(r, reverse);
        assert_eq!(r.get(high).unwrap().parent_species(), None);
    }
    #[test]
    fn zero_members_can_receive_pending_child_but_extinct_records_never_reactivate() {
        let mut r = SpeciesRegistry::new();
        let old = r.assign(Kind::Carnivore, g(0), OrganismId(1), None, 0);
        r.remove_member(old);
        assert_eq!(r.living_count(Kind::Carnivore), 0);
        assert_eq!(r.get(old).unwrap().extinction_tick(), None);
        assert_eq!(
            r.assign(Kind::Carnivore, g(0), OrganismId(2), Some(old), 4),
            old
        );
        r.finalize_extinctions(4);
        assert_eq!(r.get(old).unwrap().extinction_tick(), None);
        r.remove_member(old);
        r.finalize_extinctions(5);
        r.finalize_extinctions(6);
        let new = r.assign(Kind::Carnivore, g(0), OrganismId(3), Some(old), 7);
        assert_ne!(old, new);
        assert_eq!(r.get(old).unwrap().extinction_tick(), Some(5));
        assert_eq!(r.get(new).unwrap().parent_species(), Some(old));
        assert_eq!(r.get(new).unwrap().name(), "carnivore-3");
    }
}

impl SpeciesRegistry {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.usize(self.records.len())?;
        for s in self.records.values() {
            w.u64(s.id.value())?;
            s.kind.write_canonical(w)?;
            w.string(&s.name)?;
            s.founder_genome.write_canonical(w)?;
            w.option(s.parent_species.map(|id| id.value()))?;
            w.u64(s.origin_tick)?;
            w.option(s.extinction_tick)?;
            w.u128(s.living_members)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let c = crate::config::Config::default();
        let p = crate::population::Population::initialize(
            crate::topology::Topology::new(64, 48).unwrap(),
            c.initial(),
        )
        .unwrap();
        let base = p.species().clone();
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.id.0 += 1;
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.kind = Kind::Carnivore;
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.name.push_str("x");
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.parent_species = Some(s.id);
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.origin_tick += 1;
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.extinction_tick = Some(0);
        });
        changed!(|v: &mut SpeciesRegistry| {
            let s = v.records.values_mut().next().unwrap();
            s.living_members += 1;
        });

        let mut extinct = base.clone();
        let first = *extinct.records.keys().next().unwrap();
        let record = extinct.records.get_mut(&first).unwrap();
        record.living_members = 0;
        record.extinction_tick = Some(10);
        let before = collect(|w| extinct.write_canonical(w));
        extinct
            .records
            .get_mut(&first)
            .unwrap()
            .name
            .push_str("history");
        assert_ne!(before, collect(|w| extinct.write_canonical(w)));
        for locus in 0..12 {
            changed!(|v: &mut SpeciesRegistry| {
                let s = v.records.values_mut().next().unwrap();
                let mut a = *s.founder_genome.alleles();
                a[locus] += 1;
                s.founder_genome = Genome::from_alleles(a);
            });
        }
        changed!(|v: &mut SpeciesRegistry| {
            v.records.pop_first();
        });
    }
}

impl SpeciesRegistry {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        tick: u64,
    ) -> std::io::Result<Self> {
        use crate::canonical::require;
        let n = r.count(67)?;
        let mut records = BTreeMap::new();
        let mut previous = 0;
        for _ in 0..n {
            let id = SpeciesId(r.u64()?);
            let kind = Kind::read_canonical(r)?;
            let name = r.string()?;
            let founder_genome = Genome::read_canonical(r)?;
            let parent_species = r.option()?.map(SpeciesId);
            let origin_tick = r.u64()?;
            let extinction_tick = r.option()?;
            let living_members = r.u128()?;
            require(id.0 > previous, "unordered species IDs")?;
            previous = id.0;
            let prefix = match kind {
                Kind::Plant => "plant",
                Kind::Herbivore => "herbivore",
                Kind::Carnivore => "carnivore",
            };
            require(name == format!("{prefix}-{}", id.0), "invalid species name")?;
            require(
                origin_tick <= tick
                    && extinction_tick.is_none_or(|t| t >= origin_tick && t <= tick)
                    && (living_members == 0) == extinction_tick.is_some(),
                "invalid species chronology/count",
            )?;
            require(
                (origin_tick == 0) == parent_species.is_none(),
                "invalid species ancestry origin",
            )?;
            if let Some(parent) = parent_species {
                let p: &SpeciesRecord = records
                    .get(&parent)
                    .ok_or_else(|| crate::canonical::invalid("missing ancestor species"))?;
                require(
                    p.kind == kind
                        && p.origin_tick <= origin_tick
                        && p.extinction_tick.is_none_or(|t| t >= origin_tick),
                    "invalid species ancestor",
                )?;
            }
            records.insert(
                id,
                SpeciesRecord {
                    id,
                    kind,
                    name,
                    founder_genome,
                    parent_species,
                    origin_tick,
                    extinction_tick,
                    living_members,
                },
            );
        }
        Ok(Self { records })
    }
}

#[cfg(test)]
mod checkpoint_validation_tests {
    use super::*;
    use crate::canonical::{Decoder, collect};
    #[test]
    fn history_names_ancestry_and_membership_flags_validate() {
        let mut base = SpeciesRegistry::new();
        base.assign(Kind::Plant, Genome::founder(), OrganismId(1), None, 0);
        let reject = |v: &SpeciesRegistry| {
            let bytes = collect(|w| v.write_canonical(w));
            assert!(SpeciesRegistry::read_canonical(&mut Decoder::new(&bytes), 1).is_err());
        };
        macro_rules! bad {
            ($field:ident,$value:expr) => {{
                let mut v = base.clone();
                v.records.get_mut(&SpeciesId(1)).unwrap().$field = $value;
                reject(&v);
            }};
        }
        bad!(name, "bogus".into());
        bad!(id, SpeciesId(0));
        bad!(origin_tick, 2);
        bad!(origin_tick, 1);
        bad!(parent_species, Some(SpeciesId(99)));
        bad!(living_members, 0);
        bad!(extinction_tick, Some(0));
    }
}

//! Loopback application adapter. Exactly one Simulation owner, no core reverse edge.
mod analytics;
mod automation;
mod configuration;
mod session;
mod snapshot;
mod transport;
use crate::config::Config;
use session::{Command, Speed, UiSession};
use std::{
    io::Read,
    path::PathBuf,
    time::{Duration, Instant},
};
use tiny_http::{Header, Method, Request, Response, Server, StatusCode};
// Slow local clients cannot block the engine owner or automation deadlines.
// Only owned response bytes cross this bounded channel; never Simulation.
type Reply = (Request, Response<std::io::Cursor<Vec<u8>>>);
fn response_workers() -> Result<std::sync::mpsc::SyncSender<Reply>, String> {
    use std::sync::{Arc, Mutex, mpsc};
    let (tx, rx) = mpsc::sync_channel::<Reply>(4);
    let rx = Arc::new(Mutex::new(rx));
    for i in 0..4 {
        let rx = rx.clone();
        std::thread::Builder::new()
            .name(format!("ui-response-{i}"))
            .spawn(move || {
                loop {
                    let job = match rx.lock() {
                        Ok(lock) => lock.recv(),
                        Err(_) => break,
                    };
                    match job {
                        Ok((req, response)) => {
                            let _ = req.respond(response);
                        }
                        Err(_) => break,
                    }
                }
            })
            .map_err(|e| format!("UI response worker: {e}"))?;
    }
    Ok(tx)
}
pub(crate) enum Mode {
    Normal,
    Smoke,
    Screenshots(PathBuf),
}
pub(crate) fn serve(config: Config, mode: Mode) -> Result<(), String> {
    let mut session = UiSession::new(config)?;
    let (uploads, completed) = transport::workers()?;
    let replies = response_workers()?;
    let mut entropy = [0u8; 24];
    std::fs::File::open("/dev/urandom")
        .and_then(|mut f| f.read_exact(&mut entropy))
        .map_err(|e| e.to_string())?;
    let token: String = entropy.iter().map(|b| format!("{b:02x}")).collect();
    let server = Server::http("127.0.0.1:0").map_err(|e| format!("UI server: {e}"))?;
    let authority = server.server_addr().to_string();
    let origin = format!("http://{authority}");
    let url = format!("{origin}/#{token}");
    let limit = match &mode {
        Mode::Normal => None,
        Mode::Smoke => Some(10),
        Mode::Screenshots(_) => Some(100),
    };
    let timeout = if limit == Some(10) { 45 } else { 105 };
    eprintln!("Evolution Simulation UI: {url}");
    let mut child = if limit.is_some() {
        Some(automation::launch(&url, &mode)?)
    } else {
        None
    };
    let start = Instant::now();

    let result = (|| {
        loop {
            if let Some(child) = child.as_mut() {
                if let Some(status) = child.try_wait().map_err(|e| e.to_string())? {
                    return if status.success() {
                        Ok(())
                    } else {
                        Err(format!("UI browser automation failed: {status}"))
                    };
                }
                if start.elapsed() > Duration::from_secs(timeout) {
                    return Err("UI automation deadline exceeded".into());
                }
            }
            while let Ok((req, epoch, operation, bytes)) = completed.try_recv() {
                let (code, body) = if epoch != session.epoch {
                    (409, "stale world epoch".into())
                } else {
                    match operation {
                        transport::Operation::CheckpointLoad => {
                            match bytes.and_then(|b| session.load_checkpoint(&b, start.elapsed())) {
                                Ok(()) => (200, session.frame().to_string()),
                                Err(e) => (400, e),
                            }
                        }
                        operation => {
                            let result = bytes
                                .map_err(|e| serde_json::json!({"path":"$","message":e}))
                                .and_then(|b| configuration::validate(&b));
                            match result {
                                Err(e) => (400, e.to_string()),
                                Ok(config) => {
                                    if matches!(operation, transport::Operation::ConfigStart) {
                                        match session.start_config(config,start.elapsed()) {
                                            Ok(()) => (200,serde_json::json!({"config":configuration::describe(session.sim.config()),"epoch":session.epoch.to_string(),"frame":session.frame()}).to_string()),
                                            Err(e) => (400,serde_json::json!({"path":"$","message":e}).to_string())
                                        }
                                    } else {
                                        (200,serde_json::json!({"config":configuration::describe(&config),"epoch":session.epoch.to_string()}).to_string())
                                    }
                                }
                            }
                        }
                    }
                };
                send_reply(
                    &replies,
                    req,
                    code,
                    "application/json",
                    body.into_bytes(),
                    None,
                );
            }
            if limit.is_none_or(|n| session.sim.tick() < n) {
                session.on_due_tick(start.elapsed())?;
            }
            let Some(req) = server
                .recv_timeout(Duration::from_millis(10))
                .map_err(|e| e.to_string())?
            else {
                continue;
            };
            let header = |name: &'static str| {
                req.headers()
                    .iter()
                    .find(|h| h.field.equiv(name))
                    .map(|h| h.value.as_str())
            };
            let trusted = header("Host") == Some(authority.as_str())
                && header("Origin").is_none_or(|o| o == origin);
            let authorized = header("X-Evosim-Token") == Some(token.as_str());
            let path = req.url().to_owned();
            let mutation = path.starts_with("/api/control/")
                || path.starts_with("/api/checkpoint/")
                || path.starts_with("/api/config/");
            let epoch = header("X-Evosim-Epoch").and_then(|s| s.parse::<u64>().ok());
            let upload_operation = match path.as_str() {
                "/api/checkpoint/load" => Some(transport::Operation::CheckpointLoad),
                "/api/config/validate" => Some(transport::Operation::ConfigValidate),
                "/api/config/start" => Some(transport::Operation::ConfigStart),
                _ => None,
            };
            if upload_operation.is_some()
                && trusted
                && authorized
                && req.method() == &Method::Post
                && epoch == Some(session.epoch)
            {
                let operation = upload_operation.unwrap();
                let mime = if matches!(operation, transport::Operation::CheckpointLoad) {
                    "application/octet-stream"
                } else {
                    "application/json"
                };
                let error = if header("Transfer-Encoding").is_some()
                    || req
                        .body_length()
                        .is_none_or(|n| n == 0 || n > operation.limit())
                {
                    Some((413, "upload requires Content-Length within operation limit"))
                } else if header("Content-Type") != Some(mime) {
                    Some((415, "incorrect upload Content-Type"))
                } else {
                    None
                };
                if let Some((code, msg)) = error {
                    send_reply(
                        &replies,
                        req,
                        code,
                        "text/plain",
                        msg.as_bytes().to_vec(),
                        None,
                    );
                } else if let Err(e) = uploads.try_send((req, session.epoch, operation)) {
                    let (req, _, _) = match e {
                        std::sync::mpsc::TrySendError::Full(v)
                        | std::sync::mpsc::TrySendError::Disconnected(v) => v,
                    };
                    send_reply(
                        &replies,
                        req,
                        503,
                        "text/plain",
                        b"upload capacity busy".to_vec(),
                        None,
                    );
                }
                continue;
            }
            let mut attachment = None;
            let (status, mime, body): (u16, &str, Vec<u8>) = if !trusted {
                (403, "text/plain", b"foreign host/origin".to_vec())
            } else if mutation && !authorized {
                (403, "text/plain", b"invalid capability".to_vec())
            } else if mutation && req.method() != &Method::Post {
                (405, "text/plain", b"method not allowed".to_vec())
            } else if mutation && epoch != Some(session.epoch) {
                (409, "text/plain", b"stale world epoch".to_vec())
            } else if req.body_length().unwrap_or(0) > 0 || header("Transfer-Encoding").is_some() {
                (413, "text/plain", b"request body not accepted".to_vec())
            } else if mutation {
                if path == "/api/checkpoint/save" {
                    match session.checkpoint_bytes() {
                        Ok(bytes) => {
                            attachment = Some(format!(
                                "attachment; filename=evosim-tick-{}.evo",
                                session.sim.tick()
                            ));
                            (200, "application/octet-stream", bytes)
                        }
                        Err(e) => (400, "text/plain", e.into_bytes()),
                    }
                } else {
                    match parse_command(&path).and_then(|c| session.command(c, start.elapsed())) {
                        Ok(()) => (
                            200,
                            "application/json",
                            session.frame().to_string().into_bytes(),
                        ),
                        Err(e) => (400, "text/plain", e.into_bytes()),
                    }
                }
            } else {
                let (code,mime,body)=match (req.method(),path.as_str()) {
                (&Method::Get,"/") => (200,"text/html; charset=utf-8",include_str!("../ui/index.html").into()),
                (&Method::Get,"/style.css") => (200,"text/css",include_str!("../ui/style.css").into()),
                (&Method::Get,"/camera.js") => (200,"text/javascript",include_str!("../ui/camera.js").into()),
                (&Method::Get,"/configuration.js") => (200,"text/javascript",include_str!("../ui/configuration.js").into()),
                (&Method::Get,"/charts.js") => (200,"text/javascript",include_str!("../ui/charts.js").into()),
                (&Method::Get,"/experiments.js") => (200,"text/javascript",include_str!("../ui/experiments.js").into()),
                (&Method::Get,"/api/config") => (200,"application/json",configuration::catalog(session.sim.config(),session.epoch).to_string()),
                (&Method::Get,"/app.js") => (200,"text/javascript",include_str!("../ui/app.js").into()),
                (&Method::Get,"/api/world") => (200,"application/json",session.world().to_string()),
                (&Method::Get,"/api/frame") => (200,"application/json",session.frame().to_string()),
                (&Method::Get,"/api/diagnostics") if authorized && limit.is_some() => (200,"application/json",serde_json::json!({"tick":session.sim.tick().to_string(),"state_hash":crate::persistence::state_hash(&session.sim).map_err(|e|e.to_string())?}).to_string()),
                (&Method::Post,"/api/ready") if authorized => {session.ready(start.elapsed())?;(200,"application/json","{}".into())},
                (&Method::Post,"/api/ready") => (403,"text/plain","invalid capability".into()),
                (_,"/api/ready" | "/" | "/app.js" | "/style.css" | "/camera.js" | "/api/world" | "/api/frame" | "/api/config" | "/configuration.js" | "/charts.js" | "/experiments.js") => (405,"text/plain","method not allowed".into()),
                _ => (404,"text/plain","not found".into()),
                };
                (code, mime, body.into_bytes())
            };
            send_reply(&replies, req, status, mime, body, attachment);
        }
    })();
    drop(child);
    result
}

fn parse_command(path: &str) -> Result<Command, String> {
    let command = path
        .strip_prefix("/api/control/")
        .ok_or("unknown control")?;
    Ok(match command {
        "run" => Command::Run,
        "pause" => Command::Pause,
        "step" => Command::Step,
        "reset" => Command::Reset,
        "clear-selection" => Command::ClearSelection,
        s if s.starts_with("speed/") => Command::SetSpeed(Speed::parse(&s[6..])?),
        s if s.starts_with("select/") => {
            let id = s[7..].parse::<u64>().map_err(|_| "invalid organism ID")?;
            if id == 0 {
                return Err("invalid organism ID".into());
            }
            Command::Select(crate::organism::OrganismId(id))
        }
        _ => return Err("unknown control".into()),
    })
}
fn send_reply(
    replies: &std::sync::mpsc::SyncSender<Reply>,
    req: Request,
    status: u16,
    mime: &str,
    body: Vec<u8>,
    attachment: Option<String>,
) {
    let mut response=Response::from_data(body).with_status_code(StatusCode(status))
 .with_header(Header::from_bytes("Content-Type",mime).unwrap())
 .with_header(Header::from_bytes("Cache-Control","no-store").unwrap())
 .with_header(Header::from_bytes("X-Content-Type-Options","nosniff").unwrap())
 .with_header(Header::from_bytes("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'").unwrap());
    if let Some(a) = attachment {
        response = response.with_header(Header::from_bytes("Content-Disposition", a).unwrap());
    }
    let _ = replies.try_send((req, response));
}

//! Immutable, procedural base climate. See docs/CLIMATE.md for model units and topology.
use crate::topology::{Cell, Topology};
use std::io::{self, Write};

pub const CLIMATE_MODEL_VERSION: u32 = 1;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Biome {
    Polar,
    Tundra,
    Temperate,
    Dry,
    Tropical,
}
impl Biome {
    pub fn name(self) -> &'static str {
        match self {
            Self::Polar => "polar",
            Self::Tundra => "tundra",
            Self::Temperate => "temperate",
            Self::Dry => "dry",
            Self::Tropical => "tropical",
        }
    }
    fn from_temperature(q: f64) -> Self {
        if q < 0.10 {
            Self::Polar
        } else if q < 0.25 {
            Self::Tundra
        } else if q < 0.60 {
            Self::Temperate
        } else if q < 0.85 {
            Self::Dry
        } else {
            Self::Tropical
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BaseClimate {
    biome: Biome,
    temperature: f64,
    precipitation: f64,
}
impl BaseClimate {
    pub fn biome(self) -> Biome {
        self.biome
    }
    pub fn temperature(self) -> f64 {
        self.temperature
    }
    pub fn precipitation(self) -> f64 {
        self.precipitation
    }
}

const KNOTS: [(f64, f64); 6] = [
    (0., 0.15),
    (0.10, 0.25),
    (0.25, 0.60),
    (0.60, 0.20),
    (0.85, 0.35),
    (1., 1.),
];
fn precipitation(q: f64) -> f64 {
    for pair in KNOTS.windows(2) {
        let [(a, pa), (b, pb)] = [pair[0], pair[1]];
        if q <= b {
            let t = ((q - a) / (b - a)).clamp(0., 1.);
            return (pa + (pb - pa) * t * t * (3. - 2. * t)).clamp(0., 1.);
        }
    }
    1.
}

/// O(1) storage and lookup; no RNG draws, raster allocation or temporal state.
#[derive(Clone, Debug, PartialEq)]
pub struct Climate {
    topology: Topology,
}
impl Climate {
    pub fn new(topology: Topology) -> Self {
        Self { topology }
    }

    /// Coordinates from other topologies are normalized to this world.
    pub fn base_at(&self, cell: Cell) -> BaseClimate {
        let cell = self.topology.cell(cell.x() as i128, cell.y() as i128);
        let h = self.topology.height();
        let d = cell.y().min(h - 1 - cell.y());
        let v = (d as f64 + 0.5) / h as f64;
        let q = ((1. - (std::f64::consts::TAU * v).cos()) / 2.).clamp(0., 1.);
        BaseClimate {
            biome: Biome::from_temperature(q),
            temperature: q,
            precipitation: precipitation(q),
        }
    }

    /// Stream row-major records with bounded memory. A write error may leave partial output.
    pub fn write_json(&self, writer: &mut impl Write) -> io::Result<()> {
        write!(
            writer,
            "{{\"climate_model\":{},\"width\":{},\"height\":{},\"temperature_units\":\"normalized\",\"precipitation_units\":\"normalized\",\"cells\":[",
            CLIMATE_MODEL_VERSION,
            self.topology.width(),
            self.topology.height()
        )?;
        for y in 0..self.topology.height() {
            for x in 0..self.topology.width() {
                if x != 0 || y != 0 {
                    writer.write_all(b",")?;
                }
                let base = self.base_at(self.topology.cell(x as i128, y as i128));
                let value = serde_json::json!({"x":x,"y":y,"biome":base.biome().name(),"base_temperature":base.temperature(),"base_precipitation":base.precipitation()});
                serde_json::to_writer(&mut *writer, &value).map_err(io::Error::other)?;
            }
        }
        writer.write_all(b"]}\n")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn thresholds_and_smooth_knots() {
        for (q, colder, warmer) in [
            (0.10, Biome::Polar, Biome::Tundra),
            (0.25, Biome::Tundra, Biome::Temperate),
            (0.60, Biome::Temperate, Biome::Dry),
            (0.85, Biome::Dry, Biome::Tropical),
        ] {
            assert_eq!(Biome::from_temperature(q - 1e-12), colder);
            assert_eq!(Biome::from_temperature(q), warmer);
            assert_eq!(Biome::from_temperature(q + 1e-12), warmer);
        }
        for (q, p) in KNOTS {
            assert!((precipitation(q) - p).abs() < 1e-14);
            for delta in [-1e-7, 1e-7] {
                assert!((precipitation((q + delta).clamp(0., 1.)) - p).abs() < 1e-10);
            }
        }
        for i in 0..=10000 {
            assert!((0.0..=1.0).contains(&precipitation(i as f64 / 10000.)));
        }
    }
}

impl Climate {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        self.topology.write_canonical(w)?;
        w.u32(CLIMATE_MODEL_VERSION)
    }
}

#[cfg(test)]
mod canonical_tests {
    use super::*;
    use crate::canonical::collect;
    #[test]
    fn every_authoritative_field_changes_encoding() {
        let base = Climate::new(crate::topology::Topology::new(3, 2).unwrap());
        let original = collect(|w| base.write_canonical(w));
        macro_rules! changed {
            ($edit:expr) => {{
                let mut value = base.clone();
                ($edit)(&mut value);
                assert_ne!(
                    original,
                    collect(|w| value.write_canonical(w)),
                    "{}",
                    stringify!($edit)
                );
            }};
        }
        changed!(|v: &mut Climate| {
            v.topology = crate::topology::Topology::new(2, 3).unwrap();
        });
    }
}

impl Climate {
    pub(crate) fn read_canonical(
        r: &mut crate::canonical::Decoder<'_>,
        expected: crate::topology::Topology,
    ) -> std::io::Result<Self> {
        crate::canonical::require(
            crate::topology::Topology::read_canonical(r)? == expected,
            "climate topology mismatch",
        )?;
        crate::canonical::require(
            r.u32()? == CLIMATE_MODEL_VERSION,
            "climate version mismatch",
        )?;
        Ok(Self::new(expected))
    }
}

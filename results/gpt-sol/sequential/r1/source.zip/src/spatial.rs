//! Population-owned derived cache. No organism or RNG state is authoritative here.
use crate::{
    organism::{Kind, OrganismId},
    topology::{Cell, Topology},
};
use std::{error::Error, fmt};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) struct SpatialError;
impl fmt::Display for SpatialError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("cannot allocate dense spatial buckets")
    }
}
impl Error for SpatialError {}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct Occupant {
    id: OrganismId,
    kind: Kind,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SpatialIndex {
    topology: Topology,
    buckets: Vec<Vec<Occupant>>,
}
impl SpatialIndex {
    pub(crate) fn new(topology: Topology) -> Result<Self, SpatialError> {
        let mut buckets = Vec::new();
        buckets
            .try_reserve_exact(topology.area())
            .map_err(|_| SpatialError)?;
        buckets.resize_with(topology.area(), Vec::new);
        Ok(Self { topology, buckets })
    }
    fn address(&self, cell: Cell) -> usize {
        (cell.y() % self.topology.height()) * self.topology.width()
            + cell.x() % self.topology.width()
    }
    // Caller guarantees globally unique living IDs; no reverse directory needed.
    pub(crate) fn insert(&mut self, id: OrganismId, kind: Kind, cell: Cell) {
        let address = self.address(cell);
        let bucket = &mut self.buckets[address];
        let slot = bucket
            .binary_search_by_key(&id, |o| o.id)
            .expect_err("duplicate spatial occupant");
        bucket.insert(slot, Occupant { id, kind });
    }
    pub(crate) fn remove(&mut self, id: OrganismId, cell: Cell) -> bool {
        let address = self.address(cell);
        let bucket = &mut self.buckets[address];
        if let Ok(slot) = bucket.binary_search_by_key(&id, |o| o.id) {
            bucket.remove(slot);
            true
        } else {
            false
        }
    }
    pub(crate) fn relocate(&mut self, id: OrganismId, kind: Kind, old: Cell, new: Cell) {
        if self.address(old) == self.address(new) {
            return;
        }
        assert!(self.remove(id, old), "missing spatial occupant");
        self.insert(id, kind, new);
    }
    pub(crate) fn query(&self, center: Cell, radius: usize, kind: Option<Kind>) -> Vec<OrganismId> {
        let mut result = Vec::new();
        for cell in self.topology.cells_within(center, radius) {
            for o in &self.buckets[self.address(cell)] {
                if kind.is_none_or(|k| k == o.kind) {
                    result.push(o.id);
                }
            }
        }
        result.sort_unstable();
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn capacity_failure_without_huge_allocation() {
        assert_eq!(
            SpatialIndex::new(Topology::new(usize::MAX, 1).unwrap()),
            Err(SpatialError)
        );
    }
    #[test]
    fn sorted_buckets_normalization_and_rebuild() {
        let t = Topology::new(3, 2).unwrap();
        let foreign = Topology::new(100, 100).unwrap().cell(99, 99);
        let mut a = SpatialIndex::new(t).unwrap();
        for id in [3, 1, 2] {
            a.insert(OrganismId(id), Kind::Plant, foreign);
        }
        assert_eq!(
            a.query(t.cell(0, 1), 0, None),
            vec![OrganismId(1), OrganismId(2), OrganismId(3)]
        );
        a.relocate(OrganismId(2), Kind::Plant, foreign, t.cell(2, 0));
        assert!(a.remove(OrganismId(1), foreign));
        assert!(!a.remove(OrganismId(1), foreign));
        let mut b = SpatialIndex::new(t).unwrap();
        b.insert(OrganismId(2), Kind::Plant, t.cell(2, 0));
        b.insert(OrganismId(3), Kind::Plant, t.cell(0, 1));
        assert_eq!(a, b);
        assert_eq!(a.query(foreign, usize::MAX, Some(Kind::Herbivore)), vec![]);
    }
}

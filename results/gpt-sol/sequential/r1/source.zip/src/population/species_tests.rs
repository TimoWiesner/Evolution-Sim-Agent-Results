use super::*;
use crate::config::Config;
fn config(rate: u32) -> Config {
    Config::from_json(&format!(r#"{{"seed":42,"world":{{"width":3,"height":2}},"initial":{{"plants":2,"herbivores":2,"carnivores":2}},"genetics":{{"mutation_per_million":{rate},"mutation_max_step":65535}}}}"#)).unwrap()
}
fn fixture() -> Population {
    Population::initialize(Topology::new(3, 2).unwrap(), config(0).initial()).unwrap()
}
fn request(p: &Population, kind: Kind) -> BirthRequest {
    BirthRequest {
        kind,
        position: p.topology.cell(0, 0),
        energy: 10.,
        health: 1.,
        parents: p
            .phase_ids(kind)
            .into_iter()
            .take(if kind == Kind::Plant { 1 } else { 2 })
            .collect(),
        phase: BirthPhase::Reproduction,
    }
}
fn counts(p: &Population) {
    for r in p.species.iter() {
        assert_eq!(
            r.living_members(),
            p.iter().filter(|o| o.species_id == r.id()).count() as u128
        );
    }
}
#[test]
fn accepted_matching_children_survive_parent_death_without_extinction_or_rng_draws() {
    for kind in Kind::ALL {
        let mut p = fixture();
        let r = request(&p, kind);
        let old = p.get(r.parents[0]).unwrap().species_id;
        let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(42));
        let registry = p.species.clone();
        p.queue_birth(r.clone(), config(0).genetics(), &mut rng)
            .unwrap();
        assert_eq!(p.species, registry); // No provisional record or count.
        for id in p.phase_ids(kind) {
            assert!(p.kill(id, 8, DeathCause::Injury));
            assert!(!p.kill(id, 8, DeathCause::Injury));
        }
        counts(&p);
        assert_eq!(p.species.living_count(kind), 0);
        assert_eq!(p.species.get(old).unwrap().extinction_tick(), None);
        let before = rng.clone();
        p.commit(8);
        assert_eq!(rng, before);
        counts(&p);
        let c = p.iter().find(|o| o.birth_tick == 8).unwrap();
        assert_eq!(c.species_id, old);
        assert_eq!(c.parents, r.parents);
        assert_eq!(p.species.get(old).unwrap().extinction_tick(), None);
        let child = c.id;
        p.kill(child, 9, DeathCause::OldAge);
        counts(&p);
        p.commit(9);
        p.commit(10);
        assert_eq!(p.species.get(old).unwrap().extinction_tick(), Some(9));
    }
}
#[test]
fn divergent_inherited_children_capture_dead_parent_species_for_all_kinds() {
    for kind in Kind::ALL {
        let mut p = fixture();
        let r = request(&p, kind);
        let parent = p.get(r.parents[0]).unwrap().species_id;
        let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(0));
        // Reference uses actual genetics stream; large mutation supplies divergence.
        let first = *p.get(r.parents[0]).unwrap().genome();
        let mut reference = rng.clone();
        let expected = if kind == Kind::Plant {
            first.copy_child(config(1_000_000).genetics(), &mut reference)
        } else {
            first.crossover_child(
                p.get(r.parents[1]).unwrap().genome(),
                config(1_000_000).genetics(),
                &mut reference,
            )
        };
        assert!(10 * expected.distance_sum(&first) > 786420);
        p.queue_birth(r.clone(), config(1_000_000).genetics(), &mut rng)
            .unwrap();
        assert_eq!(rng, reference);
        for id in p.phase_ids(kind) {
            p.kill(id, 5, DeathCause::Predation);
        }
        p.commit(5);
        counts(&p);
        let c = p.iter().find(|o| o.birth_tick == 5).unwrap();
        assert_eq!(c.genome, expected);
        assert_eq!(c.parents, r.parents);
        assert_ne!(c.species_id, parent);
        let record = p.species.get(c.species_id).unwrap();
        assert_eq!(record.id().value(), c.id.value());
        assert_eq!(record.parent_species(), Some(parent));
        assert_eq!(record.origin_tick(), 5);
        assert_eq!(p.species.get(parent).unwrap().extinction_tick(), Some(5));
    }
}
#[test]
fn commit_order_and_first_new_founder_are_canonical_not_request_order() {
    let mut a = fixture();
    let mut requests: Vec<_> = Kind::ALL.into_iter().map(|k| request(&a, k)).collect();
    let mut b = a.clone();
    // Each request gets the same controlled stream in either submission order;
    // this isolates Commit sorting from acceptance-time mutation draw order.
    let rng = Rng::from_seed(&crate::config::Seed::from_u64(0));
    for r in &requests {
        a.queue_birth(r.clone(), config(1_000_000).genetics(), &mut rng.clone())
            .unwrap();
    }
    requests.reverse();
    for r in requests {
        b.queue_birth(r, config(1_000_000).genetics(), &mut rng.clone())
            .unwrap();
    }
    // A second plant birth must join the first new founder in this same Commit.
    for p in [&mut a, &mut b] {
        p.queue_birth(
            request(p, Kind::Plant),
            config(1_000_000).genetics(),
            &mut rng.clone(),
        )
        .unwrap();
        p.commit(4);
        counts(p);
    }
    assert_eq!(a, b);
    let children: Vec<_> = a.iter().filter(|o| o.birth_tick == 4).collect();
    assert_eq!(children[0].species_id, children[1].species_id);
    assert_eq!(
        a.species
            .get(children[0].species_id)
            .unwrap()
            .living_members(),
        2
    );
    for c in children {
        assert_eq!(a.species.get(c.species_id).unwrap().origin_tick(), 4);
    }
}
#[test]
fn every_birth_rejection_preserves_registry_population_and_rng() {
    for mode in 0..7 {
        let mut p = fixture();
        let mut r = request(&p, Kind::Herbivore);
        match mode {
            0 => r.parents[0] = OrganismId(999),
            1 => r.parents[0] = p.phase_ids(Kind::Plant)[0],
            2 => r.parents[1] = r.parents[0],
            3 => p.living.get_mut(&r.parents[0]).unwrap().generation = u64::MAX,
            4 => p.next_id = None,
            5 => r.health = 1000.,
            6 => r.health = f64::NAN,
            _ => unreachable!(),
        }
        let before = p.clone();
        let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(0));
        let old = rng.clone();
        assert!(
            p.queue_birth(r, config(1_000_000).genetics(), &mut rng)
                .is_err()
        );
        assert_eq!(p, before);
        assert_eq!(rng, old);
    }
}

#[test]
fn post_mutation_health_rejection_is_transactional_including_species() {
    let mut p = fixture();
    let mut r = request(&p, Kind::Plant);
    let parent = *p.get(r.parents[0]).unwrap().genome();
    r.health = parent.traits().max_health();
    let seed = (0..256)
        .find(|&seed| {
            let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
            parent
                .copy_child(config(1_000_000).genetics(), &mut rng)
                .traits()
                .max_health()
                < r.health
        })
        .expect("bounded reference finds lower health child");
    let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
    let before = p.clone();
    let old = rng.clone();
    assert_eq!(
        p.queue_birth(r, config(1_000_000).genetics(), &mut rng),
        Err(PopulationError::InvalidVitals)
    );
    assert_eq!(p, before);
    assert_eq!(rng, old);
}
#[test]
fn same_commit_children_can_found_distinct_species_and_extinct_history_is_retained() {
    let mut p = fixture();
    let r = request(&p, Kind::Plant);
    let old = p.get(r.parents[0]).unwrap().species_id;
    let original = *p.get(r.parents[0]).unwrap().genome();
    let mut chosen = Vec::new();
    for seed in 0..256 {
        let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(seed));
        let child = original.copy_child(config(1_000_000).genetics(), &mut rng);
        if 10 * child.distance_sum(&original) > 786420
            && chosen
                .iter()
                .all(|(_, g): &(u64, Genome)| 10 * child.distance_sum(g) > 786420)
        {
            chosen.push((seed, child));
            if chosen.len() == 2 {
                break;
            }
        }
    }
    assert_eq!(chosen.len(), 2);
    for (seed, _) in &chosen {
        let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(*seed));
        p.queue_birth(r.clone(), config(1_000_000).genetics(), &mut rng)
            .unwrap();
    }
    for id in p.phase_ids(Kind::Plant) {
        p.kill(id, 11, DeathCause::Climate);
    }
    p.commit(11);
    counts(&p);
    let children: Vec<_> = p.iter().filter(|o| o.kind == Kind::Plant).collect();
    assert_eq!(children.len(), 2);
    assert_ne!(children[0].species_id, children[1].species_id);
    assert_eq!(p.species.living_count(Kind::Plant), 2);
    assert_eq!(p.species.get(old).unwrap().extinction_tick(), Some(11));
    for (c, (_, dna)) in children.iter().zip(chosen) {
        assert_eq!(c.genome, dna);
        let record = p.species.get(c.species_id).unwrap();
        assert_eq!(record.parent_species(), Some(old));
        assert_eq!(record.origin_tick(), 11);
    }
}

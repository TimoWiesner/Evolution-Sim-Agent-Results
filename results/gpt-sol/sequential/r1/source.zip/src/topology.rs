//! Integer geometry on a rectangular torus, using inclusive Chebyshev distance.
//!
//! Radius one includes the origin and up to eight neighbors. Movement callers
//! must exclude the origin. No world raster or spatial index is allocated.
//!
//! ```
//! use evosim::topology::Topology;
//! let world = Topology::new(7, 4)?;
//! let origin = world.cell(0, 0);
//! let across = world.cell(-1, -1);
//! assert_eq!(world.distance(origin, across), 1);
//! assert_eq!(world.displacement(origin, across).dx, -1);
//! assert_eq!(world.cells_within(origin, usize::MAX).count(), 28);
//! # Ok::<(), evosim::topology::TopologyError>(())
//! ```

use std::{error::Error, fmt};

/// A normalized position. Cells are values, not tied to a particular topology.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct Cell {
    x: usize,
    y: usize,
}

impl Cell {
    pub fn x(self) -> usize {
        self.x
    }
    pub fn y(self) -> usize {
        self.y
    }
}

/// Shortest signed axis offsets, rather than a normalized unit direction.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Displacement {
    pub dx: i128,
    pub dy: i128,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TopologyError {
    ZeroWidth,
    ZeroHeight,
    AreaOverflow,
}

impl fmt::Display for TopologyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::ZeroWidth => "topology width must be positive",
            Self::ZeroHeight => "topology height must be positive",
            Self::AreaOverflow => "topology area exceeds usize",
        })
    }
}
impl Error for TopologyError {}

/// Positive machine-sized dimensions with a representable area, without allocation.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Topology {
    width: usize,
    height: usize,
    area: usize,
}

impl Topology {
    pub fn new(width: usize, height: usize) -> Result<Self, TopologyError> {
        if width == 0 {
            return Err(TopologyError::ZeroWidth);
        }
        if height == 0 {
            return Err(TopologyError::ZeroHeight);
        }
        let area = width
            .checked_mul(height)
            .ok_or(TopologyError::AreaOverflow)?;
        Ok(Self {
            width,
            height,
            area,
        })
    }

    pub fn width(self) -> usize {
        self.width
    }
    pub fn height(self) -> usize {
        self.height
    }
    pub fn area(self) -> usize {
        self.area
    }

    /// Wrap the full signed i128 domain, including i128::MIN.
    /// usize dimensions convert exactly on the supported 32/64-bit targets.
    pub fn cell(self, x: i128, y: i128) -> Cell {
        Cell {
            x: x.rem_euclid(self.width as i128) as usize,
            y: y.rem_euclid(self.height as i128) as usize,
        }
    }

    /// Normalize inputs to this world, then choose the shortest offset per axis.
    /// Exact even half-axis ties choose positive in *both* argument orders:
    /// displacement is deliberately not antisymmetric at those ties.
    pub fn displacement(self, from: Cell, to: Cell) -> Displacement {
        Displacement {
            dx: axis_displacement(from.x % self.width, to.x % self.width, self.width),
            dy: axis_displacement(from.y % self.height, to.y % self.height, self.height),
        }
    }

    /// Toroidal Chebyshev distance: maximum absolute shortest axis offset.
    pub fn distance(self, from: Cell, to: Cell) -> usize {
        let delta = self.displacement(from, to);
        delta.dx.abs().max(delta.dy.abs()) as usize
    }

    /// Unique cells at distance <= radius, including the normalized center.
    ///
    /// Lazy O(1) auxiliary memory, O(returned cells) work. Each covered axis
    /// enumerates ascending from zero; a partial axis starts at center-radius
    /// and wraps. The Cartesian product visits y outermost, x innermost.
    /// All usize radii are accepted, including usize::MAX. A huge valid world
    /// can still take area time to enumerate. Foreign-world cells are normalized.
    pub fn cells_within(self, center: Cell, radius: usize) -> CellsWithin {
        let x = Axis::new(center.x % self.width, radius, self.width);
        let y = Axis::new(center.y % self.height, radius, self.height);
        CellsWithin {
            x,
            y,
            x_offset: 0,
            y_offset: 0,
        }
    }
}

fn axis_displacement(from: usize, to: usize, size: usize) -> i128 {
    let forward = (to as i128 - from as i128).rem_euclid(size as i128);
    let backward = size as i128 - forward;
    if forward <= backward {
        forward
    } else {
        -backward
    }
}

#[derive(Clone, Copy, Debug)]
struct Axis {
    start: usize,
    count: usize,
    size: usize,
}
impl Axis {
    fn new(center: usize, radius: usize, size: usize) -> Self {
        if radius >= size / 2 {
            Self {
                start: 0,
                count: size,
                size,
            }
        } else {
            // The branch guarantees 2*radius+1 < size, so doubling is safe.
            Self {
                start: (center as i128 - radius as i128).rem_euclid(size as i128) as usize,
                count: 2 * radius + 1,
                size,
            }
        }
    }
    fn at(self, offset: usize) -> usize {
        // Avoid overflowing start+offset for maximum machine-sized dimensions.
        let until_wrap = self.size - self.start;
        if offset >= until_wrap {
            offset - until_wrap
        } else {
            self.start + offset
        }
    }
}

/// Owned deterministic radius iterator; no allocation or topology borrow.
#[derive(Clone, Debug)]
pub struct CellsWithin {
    x: Axis,
    y: Axis,
    x_offset: usize,
    y_offset: usize,
}
impl Iterator for CellsWithin {
    type Item = Cell;
    fn next(&mut self) -> Option<Cell> {
        if self.y_offset == self.y.count {
            return None;
        }
        let cell = Cell {
            x: self.x.at(self.x_offset),
            y: self.y.at(self.y_offset),
        };
        self.x_offset += 1;
        if self.x_offset == self.x.count {
            self.x_offset = 0;
            self.y_offset += 1;
        }
        Some(cell)
    }
}

impl Topology {
    pub(crate) fn write_canonical(
        &self,
        w: &mut crate::canonical::Encoder<impl std::io::Write>,
    ) -> std::io::Result<()> {
        w.usize(self.width())?;
        w.usize(self.height())
    }
}

impl Topology {
    pub(crate) fn read_canonical(r: &mut crate::canonical::Decoder<'_>) -> std::io::Result<Self> {
        Self::new(r.usize()?, r.usize()?).map_err(crate::canonical::invalid)
    }
}

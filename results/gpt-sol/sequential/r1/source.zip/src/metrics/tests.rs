use super::*;
use crate::{
    config::{Config, Seed},
    genome::Genome,
    population::{BirthPhase, BirthRequest},
    rng::Rng,
    topology::Topology,
};
fn config() -> Config {
    Config::from_json(r#"{"seed":42,"world":{"width":8,"height":8},"initial":{"plants":6,"herbivores":6,"carnivores":6},"genetics":{"mutation_per_million":0}}"#).unwrap()
}
#[test]
fn accumulator_hand_oracles() {
    assert_eq!(Accumulator::default().finish(), TraitSummary::default());
    for (values, mean, deviation) in [
        (vec![3.], 3., 0.),
        (vec![1., 3.], 2., 1.),
        (vec![7.; 20], 7., 0.),
        (vec![1e12 + 1., 1e12 + 3.], 1e12 + 2., 1.),
    ] {
        let mut a = Accumulator::default();
        for x in &values {
            a.add(*x);
        }
        let s = a.finish();
        assert_eq!(s.mean, Some(mean));
        assert_eq!(s.standard_deviation, Some(deviation));
        assert_eq!(s.min, Some(values[0]));
        assert_eq!(s.max, values.last().copied());
    }
}
#[test]
fn heterogeneous_endpoint_traits_and_weighted_generations() {
    let c = Config::from_json(r#"{"seed":42,"world":{"width":8,"height":8},"initial":{"plants":2,"herbivores":1,"carnivores":0}}"#).unwrap();
    let mut p = Population::initialize(Topology::new(8, 8).unwrap(), c.initial()).unwrap();
    let ids: Vec<_> = p.iter().map(|o| o.id()).collect();
    for (id, allele, generation) in [(ids[0], 0, 0), (ids[1], 65535, 2), (ids[2], 0, 4)] {
        let o = p.fixture_mut(id);
        o.genome = Genome::from_alleles([allele; 12]);
        o.health = o.traits().max_health();
        o.generation = generation;
    }
    p.fixture_species_from_genomes();
    let s = Snapshot::from_population(4, &p);
    let low = [1., 1., 10., 200., 0., 1., 0.5, 0., 0., 0.05, 0., 0.];
    let high = [4., 10., 100., 2000., 1., 8., 2., 1., 1., 0.5, 1., 1.];
    for ((summary, lo), hi) in s.kind(Kind::Plant).traits.0.iter().zip(low).zip(high) {
        assert!((summary.mean.unwrap() - (lo + hi) / 2.).abs() < 1e-12);
        assert!((summary.standard_deviation.unwrap() - (hi - lo) / 2.).abs() < 1e-12);
        assert_eq!(summary.min, Some(lo));
        assert_eq!(summary.max, Some(hi));
    }
    assert_eq!(
        s.kind(Kind::Plant).generation,
        GenerationSummary {
            highest: Some(2),
            mean: Some(1.)
        }
    );
    assert_eq!(
        s.generation(),
        GenerationSummary {
            highest: Some(4),
            mean: Some(2.)
        }
    );
    assert_eq!(s.kind(Kind::Plant).species, 2);
    assert_eq!(s.kind(Kind::Herbivore).species, 1);
    assert_eq!(
        s.kind(Kind::Carnivore).generation,
        GenerationSummary::default()
    );
}
#[test]
fn committed_births_every_death_cause_and_extinct_species() {
    let c = config();
    let mut p = Population::initialize(Topology::new(8, 8).unwrap(), c.initial()).unwrap();
    let mut rng = Rng::from_seed(&Seed::from_u64(42));
    for kind in Kind::ALL {
        let ids: Vec<_> = p
            .iter()
            .filter(|o| o.kind() == kind)
            .map(|o| o.id())
            .collect();
        p.queue_birth(
            BirthRequest {
                kind,
                position: p.get(ids[0]).unwrap().position(),
                energy: 10.,
                health: 1.,
                parents: if kind == Kind::Plant {
                    vec![ids[0]]
                } else {
                    vec![ids[0], ids[1]]
                },
                phase: BirthPhase::Reproduction,
            },
            c.genetics(),
            &mut rng,
        )
        .unwrap();
        for (id, cause) in ids.iter().zip(DeathCause::ALL) {
            assert!(p.kill(*id, 1, cause));
            assert!(!p.kill(*id, 1, cause));
        }
    }
    p.commit(1);
    let snapshot = Snapshot::from_population(1, &p);
    for kind in Kind::ALL {
        let k = snapshot.kind(kind);
        assert_eq!(
            (k.births, k.deaths, k.deaths_by_cause, k.species),
            (1, 5, [1; 5], 1)
        );
        assert_eq!(snapshot.counts().get(kind), 2);
        assert_eq!(
            k.generation,
            GenerationSummary {
                highest: Some(1),
                mean: Some(0.5)
            }
        );
        let unique: std::collections::BTreeSet<_> = p
            .iter()
            .filter(|o| o.kind() == kind)
            .map(|o| o.species_id())
            .collect();
        assert_eq!(k.species, unique.len());
    }
    let ids: Vec<_> = p.iter().map(|o| o.id()).collect();
    for id in ids {
        p.kill(id, 2, DeathCause::OldAge);
    }
    p.commit(2);
    let empty = Snapshot::from_population(2, &p);
    for kind in Kind::ALL {
        assert_eq!(empty.kind(kind).species, 0);
        assert_eq!(empty.kind(kind).deaths, 7);
    }
    assert_eq!(p.species().iter().count(), 3);
}
#[test]
fn wide_exact_integer_serialization() {
    let mut g = Generations::default();
    g.add(u64::MAX);
    assert_eq!(
        g.finish().to_json()["highest"].to_string(),
        u64::MAX.to_string()
    );
    let mut s = Snapshot::capture(&Simulation::new(config()).unwrap());
    let n = u64::MAX as u128 + 123;
    s.kinds[0].births = n;
    s.kinds[0].deaths = n;
    s.kinds[0].deaths_by_cause = [n; 5];
    let j = s.to_json();
    for key in ["births", "deaths"] {
        assert_eq!(j["analytics"]["plants"][key].to_string(), n.to_string());
    }
    assert_eq!(
        j["analytics"]["plants"]["deaths_by_cause"]["climate"].to_string(),
        n.to_string()
    );
}

//! Stateless model-1 navigation. Population/Simulation retain all state ownership.
use crate::{
    config::AnimalConfig,
    rng::Rng,
    topology::{Cell, Topology},
    traits::Traits,
};

pub(crate) fn next_toward(topology: Topology, from: Cell, target: Cell) -> Option<Cell> {
    let delta = topology.displacement(from, target);
    if delta.dx == 0 && delta.dy == 0 {
        return None;
    }
    Some(topology.cell(
        from.x() as i128 + delta.dx.signum(),
        from.y() as i128 + delta.dy.signum(),
    ))
}

pub(crate) fn step_cost(traits: Traits, config: &AnimalConfig) -> f64 {
    config.movement_cost() * f64::from(traits.speed()) * traits.metabolic_multiplier()
}

pub(crate) fn wander_step(topology: Topology, from: Cell, rng: &mut Rng) -> Option<Cell> {
    let mut neighbors: Vec<_> = topology
        .cells_within(from, 1)
        .filter(|cell| *cell != from)
        .collect();
    neighbors.sort_by_key(|cell| (cell.y(), cell.x()));
    if neighbors.is_empty() {
        return None;
    }
    Some(
        neighbors[rng
            .below(neighbors.len() as u64)
            .expect("nonempty neighbors") as usize],
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    fn distance(t: Topology, a: Cell, b: Cell) -> usize {
        let x = a.x().abs_diff(b.x());
        let y = a.y().abs_diff(b.y());
        x.min(t.width() - x).max(y.min(t.height() - y))
    }
    #[test]
    fn exhaustive_shortest_paths_and_positive_half_ties() {
        for w in 1..=8 {
            for h in 1..=8 {
                let t = Topology::new(w, h).unwrap();
                for a in t.cells_within(t.cell(0, 0), usize::MAX) {
                    for b in t.cells_within(a, usize::MAX) {
                        let mut at = a;
                        for remaining in (1..=distance(t, a, b)).rev() {
                            let next = next_toward(t, at, b).unwrap();
                            assert_eq!(distance(t, at, next), 1);
                            assert_eq!(distance(t, next, b), remaining - 1);
                            at = next;
                        }
                        assert_eq!(at, b);
                        assert_eq!(next_toward(t, at, b), None);
                    }
                }
            }
        }
        let t = Topology::new(8, 6).unwrap();
        assert_eq!(
            next_toward(t, t.cell(0, 0), t.cell(4, 3)),
            Some(t.cell(1, 1))
        );
        assert_eq!(
            next_toward(t, t.cell(4, 3), t.cell(0, 0)),
            Some(t.cell(5, 4))
        );
    }
    #[test]
    fn wander_matches_independent_sorted_unique_neighbors_and_draws() {
        for w in 1..=5 {
            for h in 1..=5 {
                let t = Topology::new(w, h).unwrap();
                let mut rng = Rng::from_seed(&crate::config::Seed::from_u64(17));
                let mut reference = rng.clone();
                for from in t.cells_within(t.cell(0, 0), usize::MAX) {
                    let expected: Vec<_> = (0..h)
                        .flat_map(|y| (0..w).map(move |x| t.cell(x as i128, y as i128)))
                        .filter(|c| *c != from && distance(t, from, *c) == 1)
                        .collect();
                    let chosen = if expected.is_empty() {
                        None
                    } else {
                        Some(expected[reference.below(expected.len() as u64).unwrap() as usize])
                    };
                    assert_eq!(wander_step(t, from, &mut rng), chosen);
                    assert_eq!(rng, reference);
                }
            }
        }
    }
}

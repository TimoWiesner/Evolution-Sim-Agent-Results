//! Stateless hunting model 2 (ADR-012); Simulation owns trials and ledgers.
use crate::traits::Traits;

pub(crate) const HUNTING_MODEL_VERSION: u32 = 2;
pub(crate) fn hungry(energy: f64) -> bool {
    energy < 750.
}

pub(crate) const DENOMINATOR: u64 = 1_000_000;
pub(crate) fn attack_cost(predator: Traits) -> f64 {
    0.5 * predator.metabolic_multiplier()
}
pub(crate) fn kill_probability_numerator(
    c: Traits,
    health: f64,
    h: Traits,
    prey_health: f64,
) -> u64 {
    let mut attack = c.strength() * (1. + c.aggression()) * (health / c.max_health());
    let mut defense = h.strength() * (1. + h.speed() as f64 / 4.) * (prey_health / h.max_health());
    // Ratios of two subnormal positive vitals can both round to zero.
    // Rescale their common factor only in that case, preserving the equation.
    if attack + defense == 0. {
        let scale = health.max(prey_health);
        attack = c.strength() * (1. + c.aggression()) * (health / scale) / c.max_health();
        defense =
            h.strength() * (1. + h.speed() as f64 / 4.) * (prey_health / scale) / h.max_health();
    }
    ((attack / (attack + defense)).clamp(0.1, 0.9) * DENOMINATOR as f64).floor() as u64
}
pub(crate) fn nutrition_credit(prey_energy: f64, predator_energy: f64) -> f64 {
    let delta = (0.8 * prey_energy).min((1000. - predator_energy).max(0.));
    let realized = (predator_energy + delta).min(1000.) - predator_energy;
    if realized > prey_energy { 0. } else { delta }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::genome::Genome;
    #[test]
    fn hunger_boundaries() {
        assert!(hungry(749.999));
        assert!(!hungry(750.));
        assert!(!hungry(1000.));
    }
    #[test]
    fn endpoints_health_and_conservative_floating_nutrition() {
        let base = Genome::founder().traits();
        for allele in [0, 65535] {
            let t = Genome::from_alleles([allele; 12]).traits();
            assert!((0.25..=1.).contains(&attack_cost(t)));
            for health in [f64::MIN_POSITIVE, t.max_health()] {
                let n = kill_probability_numerator(t, health, base, base.max_health());
                assert!((100000..=900000).contains(&n));
            }
        }
        assert!((100000..=900000).contains(&kill_probability_numerator(
            base,
            f64::from_bits(1),
            base,
            f64::from_bits(1)
        )));
        for p in [f64::from_bits(1), f64::MIN_POSITIVE, 1e-14, 0.5, 4., 1000.] {
            for c in [0., 100., 999.9, 1000. - 1e-12, 1000.] {
                let d = nutrition_credit(p, c);
                let gain = (c + d).min(1000.) - c;
                assert!(d >= 0. && gain >= 0. && gain <= p);
            }
        }
    }
}

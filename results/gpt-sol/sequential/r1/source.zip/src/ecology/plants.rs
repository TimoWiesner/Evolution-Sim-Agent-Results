//! Pure model-v1 plant physiology; orchestration belongs to Simulation.
use crate::{
    rng::Rng,
    topology::{Cell, Topology},
    traits::Traits,
};
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct Rates {
    pub suitability: f64,
    pub damage: f64,
    pub maintenance: f64,
}
pub(crate) fn rates(traits: Traits, temperature: f64, precipitation: f64) -> Rates {
    let dt = (temperature - traits.preferred_temperature()).abs();
    let dp = (precipitation - traits.preferred_moisture()).abs();
    let w = traits.climate_tolerance();
    Rates {
        suitability: (1. - dt / w).clamp(0., 1.) * (1. - dp / w).clamp(0., 1.),
        damage: (dt.max(dp) / w - 1.).clamp(0., 1.),
        maintenance: 0.2 * traits.metabolic_multiplier(),
    }
}

/// Paid seed budget, including representable-debit checks for tiny costs.
pub(crate) fn child_energy(energy: f64, cost: f64) -> Option<f64> {
    let child = (cost / 2.).min(1000.);
    let remainder = energy - cost;
    (energy > cost
        && child > 0.
        && remainder > 0.
        && remainder < energy
        && energy - remainder >= child)
        .then_some(child)
}
fn axis(center: usize, size: usize, radius: usize) -> (i128, usize) {
    if radius >= size / 2 {
        (0, size)
    } else {
        (center as i128 - radius as i128, 2 * radius + 1)
    }
}
/// Uniform unique wrapped cells, with constant work even for huge radii.
pub(crate) fn sample_dispersal(
    topology: Topology,
    center: Cell,
    radius: usize,
    rng: &mut Rng,
) -> Cell {
    let (x, nx) = axis(center.x(), topology.width(), radius);
    let (y, ny) = axis(center.y(), topology.height(), radius);
    let dx = rng.below(nx as u64).expect("positive axis length");
    let dy = rng.below(ny as u64).expect("positive axis length");
    topology.cell(x + dx as i128, y + dy as i128)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::genome::Genome;
    #[test]
    fn exact_optima_cold_dry_and_genetic_tolerance() {
        let traits = Genome::founder().traits();
        let t = traits.preferred_temperature();
        let p = traits.preferred_moisture();
        let favorable = rates(traits, t, p);
        assert_eq!(favorable.suitability, 1.);
        assert_eq!(favorable.damage, 0.);
        for (cold, dry) in [(0., p), (t, 0.)] {
            let hostile = rates(traits, cold, dry);
            assert_eq!(hostile.suitability, 0.);
            assert!(hostile.damage > 0.);
        }
        let mut narrow = [32768; 12];
        narrow[9] = 0;
        let mut broad = narrow;
        broad[9] = u16::MAX;
        assert!(
            rates(Genome::from_alleles(broad).traits(), 0.7, p).suitability
                > rates(Genome::from_alleles(narrow).traits(), 0.7, p).suitability
        );
    }
}

#[cfg(test)]
mod reproduction_tests {
    use super::*;
    use crate::config::Config;
    #[test]
    fn numeric_seed_budgets_are_paid_and_retain_living_parent() {
        for (e, cost) in [
            (0., 20.),
            (19., 20.),
            (20., 20.),
            (1000., 1001.),
            (1000., f64::from_bits(1)),
            (1000., f64::MIN_POSITIVE),
            (1000., 1e-20),
        ] {
            assert_eq!(child_energy(e, cost), None, "{e} {cost}");
        }
        for (e, cost) in [(20.00000001, 20.), (1000., 20.), (1e-300, 1e-301)] {
            let b = child_energy(e, cost).unwrap();
            assert_eq!(b, cost / 2.);
            assert!(e - cost > 0. && e - (e - cost) >= b);
        }
    }
    #[test]
    fn exhaustive_unique_axis_mapping_matches_independent_distance_oracle() {
        for w in 1..=8 {
            for h in 1..=8 {
                let t = Topology::new(w, h).unwrap();
                for x in 0..w {
                    for y in 0..h {
                        for radius in [0, 1, 3, u32::MAX as usize, usize::MAX] {
                            let (sx, nx) = axis(x, w, radius);
                            let (sy, ny) = axis(y, h, radius);
                            let mut mapped = std::collections::HashSet::new();
                            for dx in 0..nx {
                                for dy in 0..ny {
                                    assert!(
                                        mapped.insert(t.cell(sx + dx as i128, sy + dy as i128))
                                    );
                                }
                            }
                            let mut expected = std::collections::HashSet::new();
                            for xx in 0..w {
                                for yy in 0..h {
                                    let dx = x.abs_diff(xx);
                                    let dy = y.abs_diff(yy);
                                    if dx.min(w - dx).max(dy.min(h - dy)) <= radius {
                                        expected.insert(t.cell(xx as i128, yy as i128));
                                    }
                                }
                            }
                            assert_eq!(mapped, expected);
                            assert_eq!(
                                mapped,
                                t.cells_within(t.cell(x as i128, y as i128), radius)
                                    .collect()
                            );
                        }
                    }
                }
            }
        }
    }
    #[test]
    fn sampler_draws_x_then_y_even_for_unit_axes_and_huge_radius() {
        let c = Config::preset("baseline").unwrap();
        for (w, h) in [(1, 1), (1, 9), (8, 1), (7, 4)] {
            for r in [0, 1, usize::MAX] {
                let t = Topology::new(w, h).unwrap();
                let center = t.cell(-1, -1);
                let mut rng = Rng::from_seed(c.seed());
                let mut reference = rng.clone();
                let (x, nx) = axis(center.x(), w, r);
                let (y, ny) = axis(center.y(), h, r);
                let expected = t.cell(
                    x + reference.below(nx as u64).unwrap() as i128,
                    y + reference.below(ny as u64).unwrap() as i128,
                );
                assert_eq!(sample_dispersal(t, center, r, &mut rng), expected);
                assert_eq!(rng, reference);
            }
        }
    }
}

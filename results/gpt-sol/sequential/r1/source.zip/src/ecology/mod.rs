pub(crate) mod animals;
pub(crate) mod carnivores;
pub(crate) mod herbivores;
pub(crate) mod plants;
pub(crate) mod reproduction;

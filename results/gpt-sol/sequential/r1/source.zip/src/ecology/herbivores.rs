//! Stateless grazing model 1 (ADR-011). All ledgers remain Simulation-owned.
use crate::{
    config::AnimalConfig,
    topology::{Cell, Topology},
    traits::Traits,
};

pub(crate) const EFFICIENCY: f64 = 0.8;
pub(crate) const BITE_CAP: f64 = 4.;

pub(crate) fn maintenance(traits: Traits, config: &AnimalConfig, temperature: f64) -> f64 {
    let stress =
        ((temperature - traits.preferred_temperature()).abs() / traits.climate_tolerance() - 1.)
            .clamp(0., 1.);
    config.basal_cost().max(1e-9) * traits.metabolic_multiplier() * (1. + stress)
}

pub(crate) fn accepts_food(
    traits: Traits,
    topology: Topology,
    plant: Cell,
    visible_predators: &[Cell],
) -> bool {
    traits.risk_tolerance() >= 0.5
        || !visible_predators
            .iter()
            .any(|p| topology.distance(plant, *p) <= 1)
}

pub(crate) fn bite_request(plant_energy: f64, herbivore_energy: f64) -> f64 {
    BITE_CAP
        .min(plant_energy)
        .min((1000. - herbivore_energy).max(0.) / EFFICIENCY)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{config::Config, genome::Genome};
    #[test]
    fn maintenance_bounds_thermal_thresholds_genetics_and_numeric_extremes() {
        for basal in [f64::from_bits(1), 0.1, 1_000_000.] {
            let c = Config::from_json(&format!(r#"{{"seed":0,"world":{{"width":1,"height":1}},"initial":{{"plants":0,"herbivores":0,"carnivores":0}},"animals":{{"basal_cost":{basal}}}}}"#)).unwrap();
            for met in [0, 65535] {
                let mut a = [32768; 12];
                a[6] = met;
                a[7] = 0;
                a[9] = 0;
                let t = Genome::from_alleles(a).traits();
                let ideal = basal.max(1e-9) * t.metabolic_multiplier();
                assert_eq!(maintenance(t, c.animals(), 0.), ideal);
                assert_eq!(maintenance(t, c.animals(), t.climate_tolerance()), ideal);
                assert_eq!(maintenance(t, c.animals(), 1.), 2. * ideal);
                assert!(ideal > 0. && ideal.is_finite());
            }
        }
    }
    #[test]
    fn risk_threshold_wrap_and_bite_budget() {
        let t = Topology::new(9, 7).unwrap();
        for risk in [0, 32767, 32768, 65535] {
            let mut a = [32768; 12];
            a[11] = risk;
            let traits = Genome::from_alleles(a).traits();
            assert_eq!(
                accepts_food(traits, t, t.cell(0, 0), &[t.cell(-1, -1)]),
                risk >= 32768
            );
            assert!(accepts_food(traits, t, t.cell(0, 0), &[t.cell(2, 0)]));
            assert!(accepts_food(traits, t, t.cell(0, 0), &[]));
        }
        for p in [f64::from_bits(1), 0.5, 4., 1000.] {
            for h in [0., 999., 1000. - f64::EPSILON * 1024., 1000.] {
                let b = bite_request(p, h);
                assert!(b.is_finite() && b >= 0. && b <= 4. && b <= p);
                assert!(h + b * EFFICIENCY <= 1000. + 1e-10);
            }
        }
    }
}

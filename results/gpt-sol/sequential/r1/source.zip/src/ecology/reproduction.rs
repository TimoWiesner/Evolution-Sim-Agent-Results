//! Pure model-1 sexual reproduction gates (ADR-013).
use crate::{
    genome::{Genome, MAX_DISTANCE_SUM},
    traits::Traits,
};

pub(crate) const FERTILITY_DENOMINATOR: u64 = 65535 * 65535;
pub(crate) fn mature(age: u64, traits: Traits) -> bool {
    age >= (traits.lifespan() / 10).max(1)
}
pub(crate) fn ready(last: Option<u64>, tick: u64, cooldown: u64) -> bool {
    last.is_none_or(|last| {
        tick.checked_sub(last)
            .is_some_and(|elapsed| elapsed >= cooldown)
    })
}
pub(crate) fn compatible(a: &Genome, b: &Genome) -> bool {
    5 * a.distance_sum(b) <= MAX_DISTANCE_SUM
}
pub(crate) fn fertility_numerator(a: &Genome, b: &Genome) -> u64 {
    u64::from(a.alleles()[4]) * u64::from(b.alleles()[4])
}
pub(crate) fn birth_energy(e1: f64, e2: f64, cost: f64) -> Option<f64> {
    if !cost.is_finite() || cost <= 0. || cost > 1000. {
        return None;
    }
    let debit = |e: f64| {
        let residual = e - cost;
        (e.is_finite()
            && e <= 1000.
            && e > cost
            && residual > 0.
            && residual.is_finite()
            && e - residual > 0.)
            .then_some(e - residual)
    };
    (debit(e1)? + debit(e2)? >= cost).then_some(cost)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn boundaries_and_conservative_budgets() {
        let g = Genome::founder();
        assert!(!mature(109, g.traits()));
        assert!(mature(110, g.traits()));
        for c in [1, 20, u64::MAX] {
            assert!(ready(None, 0, c));
            assert!(!ready(Some(0), c - 1, c));
            assert!(ready(Some(0), c, c));
            assert!(!ready(Some(u64::MAX), u64::MAX, c));
            assert!(!ready(Some(2), 1, c));
        }
        assert!(ready(Some(u64::MAX - 20), u64::MAX, 20));
        for sum in [157283, 157284, 157285] {
            let a = Genome::from_alleles([0; 12]);
            let mut b = [0; 12];
            b[0] = 65535;
            b[1] = 65535;
            b[2] = (sum - 131070) as u16;
            let b = Genome::from_alleles(b);
            assert_eq!(compatible(&a, &b), sum <= 157284);
            assert_eq!(compatible(&a, &b), compatible(&b, &a));
        }
        for cost in [
            f64::from_bits(1),
            f64::MIN_POSITIVE,
            1e-14,
            30.,
            999.,
            1000.,
            1001.,
        ] {
            for e in [cost, 30., 30.00000001, 999.9, 1000.] {
                if let Some(child) = birth_energy(e, e, cost) {
                    assert!(e - cost > 0.);
                    assert!(e - (e - cost) > 0.);
                    assert!(child <= 2. * (e - (e - cost)));
                }
            }
        }
        assert_eq!(birth_energy(1000., 1000., 30.), Some(30.));
        assert_eq!(birth_energy(30., 1000., 30.), None);
        assert_eq!(birth_energy(1000., 1000., f64::from_bits(1)), None);
        for a in [0, 32768, 65535] {
            for b in [0, 12345, 65535] {
                let mut x = [0; 12];
                x[4] = a;
                let mut y = [0; 12];
                y[4] = b;
                assert_eq!(
                    fertility_numerator(&Genome::from_alleles(x), &Genome::from_alleles(y)),
                    a as u64 * b as u64
                );
            }
        }
    }
}

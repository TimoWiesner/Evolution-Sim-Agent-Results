//! Sequential, observational batch orchestration. See ADR-017 and docs/BATCH.md.
use super::{output, run::natural, runner::simulate};
use crate::config::{Config, Seed};
use serde_json::{Value, json};
use std::os::unix::fs::MetadataExt;
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
};

const KINDS: [&str; 3] = ["plants", "herbivores", "carnivores"];
const HEADER: &str = "row_type,run_id,variant_index,result_file,seed,parameters,tick_start,tick_end,state_hash,kind,final_population,extinct,mean,min,max,extinction_count,extinction_fraction,run_count";

struct Plan {
    config_path: PathBuf,
    root: PathBuf,
    ticks: u64,
    seeds: Vec<Seed>,
    variants: Vec<Config>,
    sweep: Value,
    count: usize,
}
impl Plan {
    fn parse(args: &[String]) -> Result<Self, String> {
        if args.len() % 2 != 0 {
            return Err("batch requires option/value pairs".into());
        }
        let mut options = BTreeMap::new();
        for pair in args.chunks_exact(2) {
            if !["--config", "--seeds", "--ticks", "--out-dir", "--sweep"]
                .contains(&pair[0].as_str())
            {
                return Err(format!("unknown batch option: {}", pair[0]));
            }
            if pair[1].starts_with("--")
                || options.insert(pair[0].as_str(), pair[1].as_str()).is_some()
            {
                return Err("duplicate option or missing value".into());
            }
        }
        let required = |key| {
            options
                .get(key)
                .copied()
                .ok_or_else(|| format!("missing {key}"))
        };
        let config_path = PathBuf::from(required("--config")?);
        let root = PathBuf::from(required("--out-dir")?);
        if root.as_os_str().is_empty() {
            return Err("batch output directory must not be empty".into());
        }
        let ticks = natural(required("--ticks")?, 0)?;
        let base = Config::load(&config_path).map_err(|e| e.to_string())?;
        let mut seeds = Vec::new();
        let mut seen = BTreeSet::new();
        for text in required("--seeds")?.split(',') {
            let seed = Seed::from_decimal(text).map_err(|e| e.to_string())?;
            if !seen.insert(seed.as_decimal().to_owned()) {
                return Err("duplicate normalized seed".into());
            }
            seeds
                .try_reserve(1)
                .map_err(|e| format!("seed allocation: {e}"))?;
            seeds.push(seed);
        }
        let mut variants = Vec::new();
        let mut sweep = Value::Null;
        if let Some(spec) = options.get("--sweep") {
            let (path, text) = spec.split_once('=').ok_or("sweep requires PATH=[values]")?;
            let parts: Vec<_> = path.split('.').collect();
            if parts.len() != 2 {
                return Err("sweep path must be group.key".into());
            }
            let original: Value = serde_json::from_str(&base.to_json().map_err(|e| e.to_string())?)
                .map_err(|e| e.to_string())?;
            if !original
                .get(parts[0])
                .and_then(|v| v.get(parts[1]))
                .is_some_and(Value::is_number)
            {
                return Err("sweep must name an existing numeric configuration leaf".into());
            }
            let values: Value =
                serde_json::from_str(text).map_err(|e| format!("sweep JSON: {e}"))?;
            let values = values
                .as_array()
                .filter(|v| !v.is_empty())
                .ok_or("sweep requires nonempty numeric array")?;
            variants
                .try_reserve(values.len())
                .map_err(|e| format!("variant allocation: {e}"))?;
            let mut effective = Vec::new();
            effective
                .try_reserve(values.len())
                .map_err(|e| format!("sweep allocation: {e}"))?;
            for value in values {
                if !value.is_number() {
                    return Err("sweep values must be numbers".into());
                }
                let mut candidate = original.clone();
                candidate[parts[0]][parts[1]] = value.clone();
                let config =
                    Config::from_json(&candidate.to_string()).map_err(|e| e.to_string())?;
                let exported: Value =
                    serde_json::from_str(&config.to_json().map_err(|e| e.to_string())?)
                        .map_err(|e| e.to_string())?;
                let normalized = exported[parts[0]][parts[1]].clone();
                if effective.contains(&normalized) {
                    return Err("duplicate effective sweep value".into());
                }
                effective.push(normalized);
                variants.push(config);
            }
            sweep = json!({"path":path,"values":effective});
        } else {
            variants.push(base);
        }
        let count = variants
            .len()
            .checked_mul(seeds.len())
            .ok_or("batch cardinality overflow")?;
        Ok(Self {
            config_path,
            root,
            ticks,
            seeds,
            variants,
            sweep,
            count,
        })
    }
    fn relative(&self, variant: usize, seed: &Seed) -> PathBuf {
        let name = format!("seed-{}.json", seed.as_decimal());
        if self.sweep.is_null() {
            PathBuf::from(name)
        } else {
            PathBuf::from(format!("variant-{variant}")).join(name)
        }
    }
    fn preflight(&self) -> Result<(), String> {
        ensure_dir(&self.root)?;
        for (index, _) in self.variants.iter().enumerate() {
            for seed in &self.seeds {
                let path = self.root.join(self.relative(index, seed));
                ensure_dir(path.parent().ok_or("missing result parent")?)?;
                self.check_file(&path)?;
            }
        }
        for name in ["summary.json", "summary.csv"] {
            self.check_file(&self.root.join(name))?;
        }
        Ok(())
    }
    fn check_file(&self, path: &Path) -> Result<(), String> {
        output::validate_destination(path)?;
        if let Ok(meta) = fs::metadata(path) {
            let source = fs::metadata(&self.config_path).map_err(|e| e.to_string())?;
            if meta.dev() == source.dev() && meta.ino() == source.ino() {
                return Err("output aliases input configuration".into());
            }
        }
        Ok(())
    }
}
fn ensure_dir(path: &Path) -> Result<(), String> {
    if path.as_os_str().is_empty() {
        return Ok(());
    }
    // Validate ancestors as well: create_dir_all would otherwise follow symlinks.
    if let Some(parent) = path.parent() {
        ensure_dir(parent)?;
    }
    match fs::symlink_metadata(path) {
        Ok(m) if m.file_type().is_dir() => Ok(()),
        Ok(_) => Err(format!(
            "batch directory must be a real directory: {}",
            path.display()
        )),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
            fs::create_dir(path).map_err(|e| format!("batch directory: {e}"))
        }
        Err(e) => Err(format!("batch directory: {e}")),
    }
}
struct Stage(PathBuf);
impl Stage {
    fn new(root: &Path) -> Result<Self, String> {
        for attempt in 0..128 {
            let path = root.join(format!(
                ".evosim-batch-{}-{attempt}.tmp",
                std::process::id()
            ));
            match fs::create_dir(&path) {
                Ok(()) => return Ok(Self(path)),
                Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
                Err(e) => return Err(format!("batch staging: {e}")),
            }
        }
        Err("cannot reserve batch staging directory".into())
    }
}
impl Drop for Stage {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[derive(Default)]
struct Aggregate {
    sum: u128,
    min: Option<u128>,
    max: u128,
    extinct: usize,
}
impl Aggregate {
    fn add(&mut self, n: u128) -> Result<(), String> {
        self.sum = self
            .sum
            .checked_add(n)
            .ok_or("population aggregate sum overflow")?;
        self.min = Some(self.min.map_or(n, |old| old.min(n)));
        self.max = self.max.max(n);
        self.extinct = self
            .extinct
            .checked_add(usize::from(n == 0))
            .ok_or("extinction count overflow")?;
        Ok(())
    }
    fn to_json(&self, count: usize) -> Value {
        json!({"mean": self.sum as f64 / count as f64, "min":self.min.unwrap(), "max":self.max,
            "extinction_count":self.extinct,"extinction_fraction":self.extinct as f64/count as f64})
    }
}
fn integer(value: &Value) -> Result<u128, String> {
    value
        .as_number()
        .ok_or("expected population integer")?
        .to_string()
        .parse()
        .map_err(|_| "invalid population integer".into())
}
fn json_bytes(value: &Value) -> Result<Vec<u8>, String> {
    let mut bytes = serde_json::to_vec(value).map_err(|e| e.to_string())?;
    bytes.push(b'\n');
    Ok(bytes)
}
pub(super) fn execute(args: &[String]) -> Result<(), String> {
    execute_using(args, output::publish, |from, to| fs::rename(from, to))
}
// Fault injection covers staging and promotion when root bypasses permissions.
fn execute_using(
    args: &[String],
    mut write: impl FnMut(&Path, &[u8]) -> Result<(), String>,
    rename: impl FnMut(&Path, &Path) -> std::io::Result<()>,
) -> Result<(), String> {
    let plan = Plan::parse(args)?;
    plan.preflight()?;
    let stage = Stage::new(&plan.root)?;
    let mut runs = Vec::new();
    runs.try_reserve(plan.count)
        .map_err(|e| format!("batch record allocation: {e}"))?;
    let mut aggregates: [Aggregate; 3] = std::array::from_fn(|_| Aggregate::default());
    let mut files = Vec::new();
    files
        .try_reserve(plan.count.checked_add(2).ok_or("file count overflow")?)
        .map_err(|e| format!("batch path allocation: {e}"))?;
    for (index, variant) in plan.variants.iter().enumerate() {
        let mut parameters: Value =
            serde_json::from_str(&variant.to_json().map_err(|e| e.to_string())?)
                .map_err(|e| e.to_string())?;
        parameters
            .as_object_mut()
            .ok_or("invalid config export")?
            .remove("seed");
        for seed in &plan.seeds {
            let result = simulate(
                variant.with_seed(seed.clone()),
                plan.ticks,
                (plan.ticks / 100).max(1),
            )?;
            let relative = plan.relative(index, seed);
            let destination = stage.0.join(&relative);
            ensure_dir(destination.parent().ok_or("missing staging parent")?)?;
            write(&destination, &json_bytes(&result)?)?;
            let mut extinct = json!({});
            for (kind, aggregate) in KINDS.iter().zip(&mut aggregates) {
                let n = integer(&result["final"][kind])?;
                aggregate.add(n)?;
                extinct[kind] = json!(n == 0);
            }
            runs.push(
                json!({"run_id":runs.len(),"variant_index":index,"seed":result["seed"],
                "parameters":parameters,"tick_start":0,"tick_end":plan.ticks,
                "result_file":relative.to_str().ok_or("non-Unicode result path")?,
                "final":result["final"],"state_hash":result["state_hash"],"extinct":extinct}),
            );
            files.push(relative);
        }
    }
    let mut totals = json!({});
    for (kind, aggregate) in KINDS.iter().zip(&aggregates) {
        totals[kind] = aggregate.to_json(plan.count);
    }
    let summary = json!({"batch_schema":1,"contract":1,"ticks":plan.ticks,"run_count":plan.count,
        "sweep":plan.sweep,"runs":runs,"aggregates":totals});
    write(&stage.0.join("summary.csv"), csv(&summary).as_bytes())?;
    write(&stage.0.join("summary.json"), &json_bytes(&summary)?)?;
    files.extend([PathBuf::from("summary.csv"), PathBuf::from("summary.json")]);
    promote(&plan, &stage, &files, rename)
}
fn promote(
    plan: &Plan,
    stage: &Stage,
    files: &[PathBuf],
    mut rename: impl FnMut(&Path, &Path) -> std::io::Result<()>,
) -> Result<(), String> {
    // Check everything before invalidating the previous completion marker.
    plan.preflight()?;
    let marker = plan.root.join("summary.json");
    match fs::remove_file(&marker) {
        Ok(()) => (),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
        Err(e) => return Err(format!("batch completion marker: {e}")),
    }
    for relative in files {
        let destination = plan.root.join(relative);
        // Single writer only; recheck directories and destination before each rename.
        ensure_dir(destination.parent().ok_or("missing publication parent")?)?;
        plan.check_file(&destination)?;
        rename(&stage.0.join(relative), &destination)
            .map_err(|e| format!("batch promotion: {e}"))?;
    }
    Ok(())
}
fn escape(field: &str) -> String {
    if field.contains([',', '"', '\r', '\n']) {
        format!("\"{}\"", field.replace('"', "\"\""))
    } else {
        field.to_owned()
    }
}
fn row(out: &mut String, fields: &[String]) {
    out.push_str(
        &fields
            .iter()
            .map(|f| escape(f))
            .collect::<Vec<_>>()
            .join(","),
    );
    out.push_str("\r\n");
}
fn cell(value: &Value) -> String {
    value
        .as_str()
        .map_or_else(|| value.to_string(), str::to_owned)
}
fn csv(summary: &Value) -> String {
    let mut out = format!("{HEADER}\r\n");
    let count = summary["run_count"].to_string();
    for run in summary["runs"].as_array().unwrap() {
        for kind in KINDS {
            let mut fields = vec!["run".to_owned()];
            for key in [
                "run_id",
                "variant_index",
                "result_file",
                "seed",
                "parameters",
                "tick_start",
                "tick_end",
                "state_hash",
            ] {
                fields.push(cell(&run[key]));
            }
            fields.extend([
                kind.to_owned(),
                cell(&run["final"][kind]),
                cell(&run["extinct"][kind]),
            ]);
            fields.extend(std::iter::repeat_n(String::new(), 5));
            fields.push(count.clone());
            row(&mut out, &fields);
        }
    }
    for kind in KINDS {
        let mut fields = vec!["aggregate".to_owned()];
        fields.extend(std::iter::repeat_n(String::new(), 8));
        fields.push(kind.to_owned());
        fields.extend([String::new(), String::new()]);
        for key in [
            "mean",
            "min",
            "max",
            "extinction_count",
            "extinction_fraction",
        ] {
            fields.push(cell(&summary["aggregates"][kind][key]));
        }
        fields.push(count.clone());
        row(&mut out, &fields);
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn csv_escaping() {
        assert_eq!(escape("plain"), "plain");
        assert_eq!(escape("a,\"b\r\nc"), "\"a,\"\"b\r\nc\"");
    }
    #[test]
    fn exact_aggregates_and_overflow() {
        let n = (1u128 << 80) + 17;
        let mut a = Aggregate::default();
        for v in [0, n, n] {
            a.add(v).unwrap();
        }
        let result = a.to_json(3);
        assert_eq!(integer(&result["max"]).unwrap(), n);
        assert_eq!(integer(&result["min"]).unwrap(), 0);
        assert_eq!(result["extinction_count"], 1);
        assert_eq!(result["mean"].as_f64().unwrap(), (n * 2) as f64 / 3.);
        let mut a = Aggregate::default();
        a.add(u128::MAX).unwrap();
        assert!(a.add(1).is_err());
    }
    #[test]
    fn promotion_failure_invalidates_marker_and_cleans_stage() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("batch-unit-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let config = root.join("config.json");
        fs::write(&config, r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
        let args: Vec<String> = [
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "0",
            "--seeds",
            "1",
            "--out-dir",
            root.to_str().unwrap(),
        ]
        .iter()
        .map(|s| s.to_string())
        .collect();
        let plan = Plan::parse(&args).unwrap();
        fs::write(root.join("summary.json"), "old").unwrap();
        {
            let stage = Stage::new(&root).unwrap();
            fs::write(stage.0.join("seed-1.json"), "new").unwrap();
            assert!(
                promote(&plan, &stage, &["seed-1.json".into()], |_, _| Err(
                    std::io::Error::other("injected")
                ))
                .is_err()
            );
            assert!(!root.join("summary.json").exists());
        }
        assert_eq!(fs::read_dir(&root).unwrap().count(), 1);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn staging_failures_preserve_old_batch_and_promotion_failures_remove_marker() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("batch-faults-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let config = root.join("config.json");
        fs::write(&config, r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
        let args: Vec<String> = [
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "0",
            "--seeds",
            "1",
            "--out-dir",
            root.to_str().unwrap(),
        ]
        .iter()
        .map(|s| s.to_string())
        .collect();
        for fail_at in 0..3 {
            fs::write(root.join("summary.json"), "old summary").unwrap();
            fs::write(root.join("seed-1.json"), "old result").unwrap();
            let mut index = 0;
            let result = execute_using(
                &args,
                |path, bytes| {
                    output::publish(path, bytes)?;
                    let fail = index == fail_at;
                    index += 1;
                    if fail {
                        Err("injected staging failure".into())
                    } else {
                        Ok(())
                    }
                },
                |from, to| fs::rename(from, to),
            );
            assert!(result.is_err());
            assert_eq!(
                fs::read_to_string(root.join("summary.json")).unwrap(),
                "old summary"
            );
            assert_eq!(
                fs::read_to_string(root.join("seed-1.json")).unwrap(),
                "old result"
            );
            assert_eq!(fs::read_dir(&root).unwrap().count(), 3);
        }
        for fail_at in 0..3 {
            fs::write(root.join("summary.json"), "old summary").unwrap();
            let mut index = 0;
            let result = execute_using(&args, output::publish, |from, to| {
                let fail = index == fail_at;
                index += 1;
                if fail {
                    Err(std::io::Error::other("injected promotion failure"))
                } else {
                    fs::rename(from, to)
                }
            });
            assert!(result.is_err());
            assert!(!root.join("summary.json").exists());
            assert!(!fs::read_dir(&root).unwrap().any(|p| {
                p.unwrap()
                    .file_name()
                    .to_string_lossy()
                    .starts_with(".evosim")
            }));
        }
        fs::remove_dir_all(root).unwrap();
    }
}

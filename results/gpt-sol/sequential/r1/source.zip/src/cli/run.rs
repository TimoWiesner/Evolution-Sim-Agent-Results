//! Standalone headless argument adapter.
use super::{
    output::{publish, validate_destination},
    runner::simulate_state,
};
use crate::{
    config::{Config, Seed},
    persistence,
    simulation::Simulation,
};
use std::{collections::BTreeMap, path::Path};
pub(super) fn natural(token: &str, minimum: u64) -> Result<u64, String> {
    if token.is_empty() || !token.bytes().all(|b| b.is_ascii_digit()) {
        return Err("expected unsigned decimal integer".into());
    }
    let value = token.parse::<u64>().map_err(|_| "integer exceeds u64")?;
    if value < minimum {
        return Err(format!("integer must be >= {minimum}"));
    }
    Ok(value)
}
pub(super) fn execute(args: &[String]) -> Result<(), String> {
    if args.len() % 2 != 0 {
        return Err("run requires option/value pairs".into());
    }
    let mut options = BTreeMap::new();
    for pair in args.chunks_exact(2) {
        if ![
            "--config",
            "--out",
            "--ticks",
            "--seed",
            "--sample-every",
            "--save",
            "--load",
        ]
        .contains(&pair[0].as_str())
        {
            return Err(format!("unknown run option: {}", pair[0]));
        }
        if pair[1].starts_with("--") || options.insert(pair[0].as_str(), pair[1].as_str()).is_some()
        {
            return Err("duplicate option or missing value".into());
        }
    }
    let required = |key| {
        options
            .get(key)
            .copied()
            .ok_or_else(|| format!("missing {key}"))
    };
    let input = match (options.get("--config"), options.get("--load")) {
        (Some(p), None) | (None, Some(p)) => Path::new(p),
        _ => return Err("exactly one of --config/--load is required".into()),
    };
    if options.contains_key("--load") && options.contains_key("--seed") {
        return Err("--seed requires --config".into());
    }
    let destination = Path::new(required("--out")?);
    let ticks = natural(required("--ticks")?, 0)?;
    let interval = match options.get("--sample-every") {
        Some(s) => natural(s, 1)?,
        None => (ticks / 100).max(1),
    };
    validate_destination(destination)?;
    reject_alias(destination, input)?;
    let save = options.get("--save").map(Path::new);
    if let Some(path) = save {
        validate_destination(path)?;
        reject_alias(path, destination)?;
        if options.contains_key("--config") {
            reject_alias(path, input)?;
        }
    }
    let mut simulation = if options.contains_key("--load") {
        persistence::load_checkpoint(input).map_err(|e| e.to_string())?
    } else {
        let mut config = Config::load(input).map_err(|e| e.to_string())?;
        if let Some(seed) = options.get("--seed") {
            config = config.with_seed(Seed::from_decimal(seed).map_err(|e| e.to_string())?);
        }
        Simulation::new(config).map_err(|e| e.to_string())?
    };
    let result = simulate_state(&mut simulation, ticks, interval)?;
    let checkpoint = save
        .map(|_| persistence::checkpoint_bytes(&simulation))
        .transpose()
        .map_err(|e| e.to_string())?;
    let mut bytes = serde_json::to_vec(&result).map_err(|e| e.to_string())?;
    bytes.push(b'\n');
    publish_results(
        save.zip(checkpoint.as_deref()),
        destination,
        &bytes,
        publish,
    )
}

fn publish_results(
    save: Option<(&Path, &[u8])>,
    destination: &Path,
    result: &[u8],
    mut publisher: impl FnMut(&Path, &[u8]) -> Result<(), String>,
) -> Result<(), String> {
    if let Some((path, bytes)) = save {
        publisher(path, bytes)?;
    }
    publisher(destination, result)
}

fn reject_alias(a: &Path, b: &Path) -> Result<(), String> {
    use std::fs;
    fn identity(p: &Path) -> Result<std::path::PathBuf, String> {
        if p.exists() {
            return fs::canonicalize(p).map_err(|e| e.to_string());
        }
        let parent = p
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .unwrap_or(Path::new("."));
        Ok(fs::canonicalize(parent)
            .map_err(|e| e.to_string())?
            .join(p.file_name().ok_or("missing filename")?))
    }
    if identity(a)? == identity(b)? {
        return Err("input/output paths alias".into());
    }
    #[cfg(unix)]
    {
        use std::os::unix::fs::MetadataExt;
        if let (Ok(a), Ok(b)) = (fs::metadata(a), fs::metadata(b)) {
            if a.dev() == b.dev() && a.ino() == b.ino() {
                return Err("input/output hard links alias".into());
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn save_failure_blocks_result_and_result_failure_retains_save() {
        let mut published = Vec::new();
        let save = Path::new("checkpoint");
        let out = Path::new("result");
        assert!(
            publish_results(Some((save, b"state")), out, b"json", |_, _| Err(
                "save failure".into()
            ))
            .is_err()
        );
        assert!(
            publish_results(Some((save, b"state")), out, b"json", |path, bytes| {
                if path == out {
                    return Err("result failure".into());
                }
                published.push((path.to_path_buf(), bytes.to_vec()));
                Ok(())
            })
            .is_err()
        );
        assert_eq!(published, vec![(save.to_path_buf(), b"state".to_vec())]);
    }
}

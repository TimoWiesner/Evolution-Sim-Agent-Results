//! Headless process adapter. Engine state never contains clocks or samples.
use crate::{
    config::Config,
    metrics::{METRICS_SCHEMA, Snapshot},
    organism::Kind,
    persistence,
    population::Counts,
    simulation::Simulation,
};
use serde_json::{Number, Value, json};
use std::time::{Duration, Instant};
fn counts(c: Counts) -> Value {
    json!({"plants":c.plants(),"herbivores":c.herbivores(),"carnivores":c.carnivores()})
}
fn sample(sim: &Simulation, series: &mut Vec<Value>) -> Result<(), String> {
    series
        .try_reserve(1)
        .map_err(|e| format!("sample allocation: {e}"))?;
    series.push(Snapshot::capture(sim).to_json());
    Ok(())
}
pub(super) fn simulate(config: Config, ticks: u64, interval: u64) -> Result<Value, String> {
    let mut simulation = Simulation::new(config).map_err(|e| e.to_string())?;
    simulate_state(&mut simulation, ticks, interval)
}
pub(super) fn simulate_state(
    simulation: &mut Simulation,
    ticks: u64,
    interval: u64,
) -> Result<Value, String> {
    let tick_start = simulation.tick();
    tick_start.checked_add(ticks).ok_or("tick overflow")?;
    if interval == 0 {
        return Err("sample interval must be positive".into());
    }
    let mut series = Vec::new();
    sample(&simulation, &mut series)?;
    let mut elapsed = Duration::ZERO;
    for advanced in 1..=ticks {
        let start = Instant::now();
        simulation.advance_one_tick().map_err(|e| e.to_string())?;
        elapsed = elapsed
            .checked_add(start.elapsed())
            .ok_or("duration overflow")?;
        if advanced % interval == 0 {
            sample(&simulation, &mut series)?;
        }
    }
    if ticks % interval != 0 {
        sample(&simulation, &mut series)?;
    }
    let population = simulation.population();
    let mut final_counts = counts(population.counts());
    final_counts["species"] = json!({"plants":population.species().living_count(Kind::Plant),"herbivores":population.species().living_count(Kind::Herbivore),"carnivores":population.species().living_count(Kind::Carnivore)});
    let seconds = elapsed.as_secs_f64();
    let rate = if seconds > 0. {
        ticks as f64 / seconds
    } else {
        0.
    };
    if !seconds.is_finite() || !rate.is_finite() {
        return Err("nonfinite timing".into());
    }
    let result = json!({
        "contract":1,"metrics_schema":METRICS_SCHEMA,"seed":simulation.config().seed().as_decimal().parse::<Number>().map_err(|e|e.to_string())?,
        "tick_start":tick_start,"tick_end":simulation.tick(),
        "world":{"width":simulation.config().world().width(),"height":simulation.config().world().height()},
        "final":final_counts,"totals":{"births":counts(population.totals().births),"deaths":counts(population.totals().deaths)},
        "series":series,"state_hash":persistence::state_hash(&simulation).map_err(|e|e.to_string())?,
        "state_hash_schema":persistence::STATE_HASH_SCHEMA,"elapsed_seconds":seconds,"ticks_per_second":rate
    });
    Ok(result)
}

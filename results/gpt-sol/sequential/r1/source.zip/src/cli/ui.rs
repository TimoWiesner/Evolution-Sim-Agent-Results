//! UI argument adapter; validate before launching any processes.
use crate::{
    config::Config,
    ui_server::{self, Mode},
};
use std::path::PathBuf;
pub(super) fn execute(args: &[String]) -> Result<(), String> {
    let mut config = None;
    let mut mode = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--config" | "--screenshots" => {
                let flag = &args[i];
                i += 1;
                let value = args
                    .get(i)
                    .filter(|s| !s.starts_with("--"))
                    .ok_or("missing UI option value")?;
                if flag == "--config" {
                    if config.replace(value).is_some() {
                        return Err("duplicate --config".into());
                    }
                } else {
                    if mode.is_some() {
                        return Err("only one UI automation mode is allowed".into());
                    }
                    let path = PathBuf::from(value);
                    if !path.is_dir() {
                        return Err("screenshot directory must exist".into());
                    }
                    let probe = path.join(format!(".evosim-write-probe-{}", std::process::id()));
                    let file = std::fs::OpenOptions::new()
                        .write(true)
                        .create_new(true)
                        .open(&probe)
                        .map_err(|e| format!("screenshot directory: {e}"))?;
                    drop(file);
                    std::fs::remove_file(probe).map_err(|e| e.to_string())?;
                    mode = Some(Mode::Screenshots(
                        std::fs::canonicalize(path).map_err(|e| e.to_string())?,
                    ));
                }
            }
            "--smoke-test" => {
                if mode.replace(Mode::Smoke).is_some() {
                    return Err("only one UI automation mode is allowed".into());
                }
            }
            other => return Err(format!("unknown UI option: {other}")),
        }
        i += 1;
    }
    let config = match config {
        Some(path) => Config::load(path),
        None => Config::preset("baseline"),
    }
    .map_err(|e| e.to_string())?;
    ui_server::serve(config, mode.unwrap_or(Mode::Normal))
}

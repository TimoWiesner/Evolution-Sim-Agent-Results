//! Regular-file atomic publication helpers; no engine dependencies.
use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
};
pub(super) fn validate_destination(path: &Path) -> Result<(), String> {
    match fs::symlink_metadata(path) {
        Ok(m) if !m.file_type().is_file() => {
            Err("output must be a regular file, not a symlink or special file".into())
        }
        Ok(_) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(e) => Err(format!("output: {e}")),
    }
}
pub(super) fn publish(path: &Path, bytes: &[u8]) -> Result<(), String> {
    publish_using(
        path,
        bytes,
        |file, bytes| {
            file.write_all(bytes)?;
            file.flush()
        },
        |from, to| fs::rename(from, to),
    )
}
// Injection isolates write/rename failures even when tests execute as root.
fn publish_using(
    path: &Path,
    bytes: &[u8],
    write: impl FnOnce(&mut fs::File, &[u8]) -> std::io::Result<()>,
    rename: impl FnOnce(&Path, &Path) -> std::io::Result<()>,
) -> Result<(), String> {
    validate_destination(path)?;
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    for attempt in 0..128 {
        let temporary = parent.join(format!(
            ".evosim-result-{}-{attempt}.tmp",
            std::process::id()
        ));
        let mut file = match OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)
        {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(e) => return Err(format!("output: {e}")),
        };
        let result = write(&mut file, bytes);
        drop(file);
        let result = result.and_then(|()| {
            validate_destination(path).map_err(std::io::Error::other)?;
            rename(&temporary, path)
        });
        if result.is_err() {
            let _ = fs::remove_file(&temporary);
        }
        return result.map_err(|e| format!("output: {e}"));
    }
    Err("cannot reserve temporary output file".into())
}
#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    #[test]
    fn wide_counts_remain_json_integers() {
        let n = (u64::MAX as u128) + 100;
        // The same arbitrary-precision Value conversion used for lifecycle counts.
        assert_eq!(json!(n).to_string(), n.to_string());
    }
    #[test]
    fn failures_preserve_destination_and_cleanup() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("target")
            .join(format!("publish-test-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let out = root.join("out");
        fs::write(&out, b"sentinel").unwrap();
        for fail_write in [true, false] {
            assert!(
                publish_using(
                    &out,
                    b"new",
                    |f, b| {
                        f.write_all(b)?;
                        if fail_write {
                            Err(std::io::Error::other("injected write"))
                        } else {
                            Ok(())
                        }
                    },
                    |_, _| Err(std::io::Error::other("injected rename"))
                )
                .is_err()
            );
            assert_eq!(fs::read(&out).unwrap(), b"sentinel");
            assert_eq!(fs::read_dir(&root).unwrap().count(), 1);
        }
        fs::remove_dir_all(root).unwrap();
    }
}

#!/usr/bin/env python3
"""External delivery evidence; never imported by the engine."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time
import balance_report

ROOT = Path(__file__).resolve().parents[1]
NAMES = balance_report.NAMES


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def coexistence(zeros, ticks):
    first = min((v for v in zeros if v is not None), default=None)
    return dict(first_zero=first, positive_completed_ticks=ticks if first is None else max(0, first-1), right_censored=first is None)


class Recorder:
    def __init__(self, folder):
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)
        self.records = []

    def run(self, args, timeout=300, expected=0, **kwargs):
        index = len(self.records)
        start = stamp()
        clock = time.monotonic()
        timed_out = False
        env = os.environ.copy()
        env.pop('DISPLAY', None)
        env.pop('WAYLAND_DISPLAY', None)
        try:
            p = subprocess.run(list(map(str, args)), cwd=ROOT, env=env,
                               capture_output=True, timeout=timeout, **kwargs)
            code, stdout, stderr = p.returncode, p.stdout, p.stderr
        except subprocess.TimeoutExpired as e:
            timed_out = True
            code, stdout, stderr = None, e.stdout or b'', e.stderr or b''
        paths = []
        for suffix, data in [('stdout', stdout), ('stderr', stderr)]:
            path = self.folder / f'command-{index:03}.{suffix}'
            path.write_bytes(data)
            paths.append(str(path.relative_to(ROOT)))
        self.records.append(dict(argv=list(map(str, args)), cwd=str(ROOT),
                                 environment={'DISPLAY': None, 'WAYLAND_DISPLAY': None},
                                 start=start, end=stamp(), wall_seconds=time.monotonic()-clock,
                                 returncode=code, timeout=timed_out, deadline_seconds=timeout,
                                 stdout=paths[0], stderr=paths[1], expected_returncode=expected))
        (self.folder/'commands.json').write_text(json.dumps(self.records, indent=2)+'\n')
        assert code == expected, self.records[-1]
        return stdout, stderr


def validate_long(folder):
    summary = balance_report.validate(folder)
    observer = json.loads((folder/'observer.json').read_text())
    summary['runs'] = []
    for run in observer['runs']:
        cli_path = folder/f'seed-{run["seed"]}.json'
        assert cli_path.exists(), cli_path
        cli = json.loads(cli_path.read_text())
        assert cli['tick_end'] >= 10000
        summary['runs'].append(dict(seed=run['seed'], per_kind_first_zero=run['first_zero'],
                                    **coexistence(run['first_zero'], run['tick_end']),
                                    final=cli['final'], state_hash=cli['state_hash'],
                                    elapsed_seconds=cli['elapsed_seconds'], ticks_per_second=cli['ticks_per_second']))
    (folder/'validated.json').write_text(json.dumps(summary, indent=2)+'\n')
    return summary


def long(args, rec):
    assert args.ticks >= 10000
    config = args.config.resolve()
    config.relative_to(ROOT)
    (args.out_dir/'input.json').write_bytes(config.read_bytes())
    for seed in args.seeds.split(','):
        rec.run([ROOT/'evosim', 'run', '--config', config, '--seed', seed, '--ticks', args.ticks,
                 '--out', args.out_dir/f'seed-{seed}.json'], timeout=300 if args.label=='fixed' else 900)
    rec.run([ROOT/'target/release/examples/balance_report', '--config', config, '--seeds', args.seeds,
             '--ticks', args.ticks, '--out-dir', args.out_dir], timeout=900)
    validate_long(args.out_dir)


def contract(args, rec):
    folder=args.out_dir
    config=folder/'config.json'
    config.write_text(json.dumps({'seed':42,'world':{'width':8,'height':6},'initial':{'plants':20,'herbivores':8,'carnivores':2}}))
    for binary in [ROOT/'evosim', ROOT/'dist/evosim']:
        out,err=rec.run([binary,'version']); assert json.loads(out)['contract']==1 and not err
        results=[]
        for i in range(2):
            path=folder/f'replay-{binary.parent.name}-{i}.json'
            out,err=rec.run([binary,'run','--config',config,'--ticks',300,'--sample-every',7,'--out',path]);assert not out and not err
            data=json.loads(path.read_text());assert [s['tick'] for s in data['series']]==list(range(0,301,7))+[300]
            for key in ('elapsed_seconds','ticks_per_second'):assert data.pop(key)>=0
            results.append(data)
        assert results[0]==results[1]
        for split in [0,37,117]:
            save=folder/'checkpoint.evo'; first=folder/'first.json'; resumed=folder/'resumed.json'
            rec.run([binary,'run','--config',config,'--ticks',split,'--out',first,'--save',save])
            rec.run([binary,'run','--load',save,'--ticks',300-split,'--out',resumed,'--save',save])
            data=json.loads(resumed.read_text());assert data['tick_start']==split and data['tick_end']==300
            for k in ('final','totals','state_hash'):assert data[k]==results[0][k]
        batch=folder/f'batch-{binary.parent.name}'
        rec.run([binary,'batch','--config',config,'--seeds','1,2,3','--ticks',17,'--out-dir',batch])
        for seed in [1,2,3]:
            path=folder/'standalone.json';rec.run([binary,'run','--config',config,'--seed',seed,'--ticks',17,'--out',path])
            a=json.loads(path.read_text());b=json.loads((batch/f'seed-{seed}.json').read_text())
            for k in ('final','totals','series','state_hash'):assert a[k]==b[k]
        bad=folder/'bad.json';bad.write_text('{')
        for flags in [[],['--config',bad],['--load',bad],['--config',folder/'missing']]:
            path=folder/'must-not-exist.json'
            out,err=rec.run([binary,'run',*flags,'--ticks',1,'--out',path],expected=2)
            assert not out and err and not path.exists()
    # Unlike chmod under root, dropping numeric uid/gid proves an unreadable file.
    if os.geteuid()==0:
        secret=folder/'unreadable.json';secret.write_bytes(config.read_bytes());secret.chmod(0o600)
        folder.chmod(0o777)
        path=folder/'unreadable-result.json'
        out,err=rec.run([ROOT/'evosim','run','--config',secret,'--ticks',0,'--out',path],expected=2,user=65534,group=65534)
        assert not out and err and not path.exists()
    (folder/'assertions.json').write_text(json.dumps({'complete':True,'assertions':['host and musl replay','split continuation 0/37/117','batch 1/2/3 parity','exit2 no output','numeric uid unreadability']},indent=2)+'\n')


def provenance(folder):
    def output(argv):
        p=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True)
        return {'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    paths=list((ROOT/'src').rglob('*'))+[ROOT/'Cargo.toml',ROOT/'Cargo.lock']
    data={'recorded':stamp(),'platform':platform.platform(),'processor':platform.processor(),
          'build_profile':'release','revision':output(['git','rev-parse','HEAD']),
          'working_diff':output(['git','diff']),
          'working_status':output(['git','status','--short']),
          'delivery_sources':{str(p.relative_to(ROOT)):digest(p) for base in ['tools','tests','ui'] for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts},
          'sources':{str(p.relative_to(ROOT)):digest(p) for p in paths if p.is_file()},
          'binaries':{str(p.relative_to(ROOT)):digest(p) for p in [ROOT/'target/release/evosim',ROOT/'target/release/examples/balance_report',ROOT/'dist/evosim'] if p.exists()},
          'tools':{name:output(argv) for name,argv in {'rustc':['rustc','--version'],'cargo':['cargo','--version'],'python':['python3','--version'],'node':['node','--version'],'chromium':['chromium','--version'],'cpu':['lscpu']}.items()}}
    (folder/'provenance.json').write_text(json.dumps(data,indent=2)+'\n')


def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['contract','long','validate'],required=True);p.add_argument('--out-dir',type=Path,required=True);p.add_argument('--config',type=Path);p.add_argument('--seeds',default='42,43,44');p.add_argument('--ticks',type=int,default=10000);p.add_argument('--label',default='demo');args=p.parse_args()
    args.out_dir=args.out_dir.resolve();args.out_dir.relative_to(ROOT)
    if args.mode=='validate':
        reports=list(args.out_dir.rglob('observer.json'));assert reports
        for path in reports:validate_long(path.parent)
        files={str(path.relative_to(args.out_dir)):digest(path) for path in sorted(args.out_dir.rglob('*')) if path.is_file() and path.name!='manifest.json'}
        (args.out_dir/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
        print(f'Validated {len(reports)} observer reports and {len(files)} artifact digests')
    else:
        rec=Recorder(args.out_dir);provenance(args.out_dir)
        (long if args.mode=='long' else contract)(args,rec)


if __name__=='__main__':main()

#!/usr/bin/env python3
"""Validate ecological curves against completed-tick counters and batch results."""
import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

NAMES = ('plants', 'herbivores', 'carnivores')
CAUSES = ('Starvation', 'Injury', 'Predation', 'OldAge', 'Climate')


def check_counters(counters, row):
    for name in NAMES:
        for key, suffix in [('count', ''), ('births', '_births'), ('deaths', '_deaths')]:
            assert counters[name][key] == int(row[name + suffix])
        for cause in CAUSES:
            assert counters[name]['causes'][cause] == int(row[name + '_' + cause])


def draw_curves(directory, run, rows):
    """Independent per-kind y scales; logarithmic time exposes early collapse."""
    parts = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="650" '
        'viewBox="0 0 1000 650"><rect width="1000" height="650" fill="white"/>',
        f'<text x="20" y="25">Seed {run["seed"]}: population curves; '
        f'x=log(1+tick), 0..{run["tick_end"]}; independent y scales</text>',
    ]
    for index, (name, color) in enumerate(zip(NAMES, ('green', 'blue', 'red'))):
        maximum = max(1, max(int(row[name]) for row in rows))
        top = 60 + index * 190
        parts.append(
            f'<text x="20" y="{top}">{name}: 0..{maximum}; '
            f'first zero {run["first_zero"][index]}</text>'
        )
        points = ' '.join(
            f'{20 + 960 * math.log1p(int(row["tick"])) / max(1, math.log1p(run["tick_end"])):.2f},'
            f'{top + 160 - 150 * int(row[name]) / maximum:.2f}'
            for row in rows
        )
        parts.append(f'<polyline fill="none" stroke="{color}" stroke-width="1" points="{points}"/>')
    (directory / f'seed-{run["seed"]}.svg').write_text(''.join(parts) + '</svg>')


def validate(directory):
    directory = Path(directory)
    report = json.loads((directory / 'observer.json').read_text())
    assert len({run['seed'] for run in report['runs']}) == len(report['runs'])
    for run in report['runs']:
        with (directory / f'seed-{run["seed"]}.csv').open() as stream:
            rows = list(csv.DictReader(stream))
        assert run['tick_end'] == report['ticks']
        assert [int(row['tick']) for row in rows] == list(range(run['tick_end'] + 1))
        for index, name in enumerate(NAMES):
            zeros = [int(row['tick']) for row in rows if int(row[name]) == 0]
            assert run['first_zero'][index] == (zeros[0] if zeros else None)
            previous = {key: 0 for key in ['births', 'deaths', *CAUSES]}
            for row in rows:
                assert run['final'][name]['initial'] + int(row[name + '_births']) - int(row[name + '_deaths']) == int(row[name])
                assert sum(int(row[name + '_' + cause]) for cause in CAUSES) == int(row[name + '_deaths'])
                for key in previous:
                    value = int(row[name + '_' + key])
                    assert value >= previous[key]
                    previous[key] = value
            if zeros:
                assert all(int(row[name]) == 0 for row in rows[zeros[0]:])
                assert all(row[name + '_births'] == rows[zeros[0]][name + '_births'] for row in rows[zeros[0]:])
                extinction = run['extinctions'][name]
                assert extinction['tick'] == zeros[0]
                check_counters(extinction['counters'], rows[extinction['tick']])
        check_counters(run['final'], rows[-1])
        score = min((tick for tick in run['first_zero'] if tick is not None), default=run['tick_end'])
        assert run['coexistence'] == score
        assert run['right_censored'] == all(tick is None for tick in run['first_zero'])
        assert run['first_kinds'] == [name for name, tick in zip(NAMES, run['first_zero']) if tick == score]
        batch_path = directory / f'seed-{run["seed"]}.json'
        if batch_path.exists():
            batch = json.loads(batch_path.read_text())
            assert batch['state_hash'] == run['state_hash']
            assert batch['tick_start'] == 0 and batch['tick_end'] == run['tick_end']
            for name in NAMES:
                assert batch['final'][name] == run['final'][name]['count']
                for key in ('births', 'deaths'):
                    assert batch['totals'][key][name] == run['final'][name][key]
        draw_curves(directory, run, rows)
    return {
        'seeds': [run['seed'] for run in report['runs']],
        'horizon': report['ticks'],
        'first_zero': [run['first_zero'] for run in report['runs']],
        'coexistence_median': statistics.median(run['coexistence'] for run in report['runs']),
        'coexistence_range': [min(run['coexistence'] for run in report['runs']), max(run['coexistence'] for run in report['runs'])],
    }


def validate_experiment(root, results):
    trials = json.loads((root / 'trials.json').read_text())
    assert all(trial.get('expected') and trial.get('outcome') for trial in trials)
    for trial in trials:
        patch = root / trial['patch']
        assert hashlib.sha256(patch.read_bytes()).hexdigest() == trial['patch_sha256']
        for suffix, horizon in [('screen', 2000), ('full', 10000)]:
            result = results[trial['id'] + '-' + suffix]
            assert result['horizon'] == horizon
            assert result['seeds'] == [str(seed) for seed in trial['seeds']]
    selection = json.loads((root / 'selection.json').read_text())
    assert selection['chosen'] in [trial['id'] for trial in trials]
    diagnosis = json.loads((root / 'baseline-analysis.json').read_text())
    for name, digest in diagnosis['inputs'].items():
        # Manifest paths were recorded relative to the project root.
        path = root.parents[2] / name
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    assert diagnosis['recorded_before_ecology_edit'] < trials[0]['recorded'] < selection['frozen_at']
    assert json.loads((root / 'fixed.json').read_text()) == {
        'seed': 42, 'world': {'width': 64, 'height': 48},
        'initial': {'plants': 400, 'herbivores': 120, 'carnivores': 20},
    }
    assert results['baseline']['horizon'] == 10000 and len(results['baseline']['seeds']) >= 10
    heldout = results['chosen-heldout']
    assert set(heldout['seeds']).isdisjoint(results['baseline']['seeds'])
    assert heldout['horizon'] == 10000 and len(heldout['seeds']) >= 5
    assert heldout['seeds'] == [str(seed) for seed in selection['heldout_seeds']]
    assert results['baseline-heldout']['seeds'] == heldout['seeds']
    for name in ['baseline', 'baseline-heldout', 'chosen-heldout']:
        for seed in results[name]['seeds']:
            assert (root / name / f'seed-{seed}.json').is_file()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--validate', required=True)
    root = Path(parser.parse_args().validate).resolve()
    results = {
        str(path.parent.relative_to(root)): validate(path.parent)
        for path in sorted(root.rglob('observer.json'))
    }
    assert results
    validate_experiment(root, results)
    (root / 'aggregate.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()

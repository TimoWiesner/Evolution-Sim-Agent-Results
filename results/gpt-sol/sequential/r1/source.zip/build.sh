#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
cargo build --locked --release --target x86_64-unknown-linux-musl
mkdir -p dist
install -m 755 target/x86_64-unknown-linux-musl/release/evosim dist/evosim

(function(root){
'use strict';
const Camera={
 fit(w,h,vw,vh){const scale=Math.max(.01,Math.min(160,(vw-48)/w,(vh-48)/h));return {x:(vw-w*scale)/2,y:(vh-h*scale)/2,scale};},
 worldToScreen(c,x,y){return {x:c.x+x*c.scale,y:c.y+y*c.scale};},
 screenToWorld(c,x,y){return {x:(x-c.x)/c.scale,y:(y-c.y)/c.scale};},
 zoomAt(c,x,y,factor){const p=this.screenToWorld(c,x,y);const scale=Math.max(.01,Math.min(160,c.scale*factor));return {x:x-p.x*scale,y:y-p.y*scale,scale};}
};
if(typeof module!=='undefined') module.exports=Camera; else root.Camera=Camera;
})(globalThis);

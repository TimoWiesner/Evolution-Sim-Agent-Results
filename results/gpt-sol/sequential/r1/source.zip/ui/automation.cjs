'use strict';
const {spawn}=require('node:child_process');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
// CDP over inherited pipes: no websocket packages or externally reachable debug port.
class CDP {
 constructor(child){this.child=child;this.seq=0;this.pending=new Map();this.errors=[];this.failure=null;
 const abort=e=>{this.failure=e;for(const p of this.pending.values())p.reject(e);this.pending.clear();};
 child.stdio[3].on('error',abort);child.stdio[4].on('error',abort);
 let buffer='';child.stdio[4].on('data',data=>{buffer+=data.toString();let p;while((p=buffer.indexOf('\0'))>=0){const raw=buffer.slice(0,p);buffer=buffer.slice(p+1);if(!raw)continue;const m=JSON.parse(raw);if(m.id){const q=this.pending.get(m.id);if(q){this.pending.delete(m.id);m.error?q.reject(Error(JSON.stringify(m.error))):q.resolve(m.result);}}else if(m.method==='Runtime.exceptionThrown')this.errors.push(m.params.exceptionDetails);}});child.on('error',e=>{for(const p of this.pending.values())p.reject(e);this.pending.clear();});child.on('exit',()=>{for(const p of this.pending.values())p.reject(Error('Chromium exited'));this.pending.clear();});}
 send(method,params={},sessionId){if(this.failure)return Promise.reject(this.failure);return new Promise((resolve,reject)=>{const id=++this.seq;this.pending.set(id,{resolve,reject});this.child.stdio[3].write(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})})+'\0');});}
 async evaluate(expression){const r=await this.send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},this.session);if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;}
 async wait(expression,timeout=30000){const start=Date.now();while(Date.now()-start<timeout){const r=await this.evaluate(expression);if(r)return r;await new Promise(r=>setTimeout(r,50));}throw Error('Browser readiness timeout: '+expression);}
}
async function open(url){
 const base=fs.existsSync(path.join(process.cwd(),'target'))?path.join(process.cwd(),'target'):os.tmpdir();
 const profile=process.env.EVOSIM_UI_PROFILE||fs.mkdtempSync(path.join(base,'evosim-browser-'));
 const executable=process.env.CHROME_BIN||process.env.PUPPETEER_EXECUTABLE_PATH||'chromium';
 const child=spawn(executable,['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-first-run','--no-default-browser-check','--disable-background-networking','--remote-debugging-pipe','--window-size=1440,900','--user-data-dir='+profile,...(!process.env.DISPLAY?['--headless=new']:[]),'about:blank'],{stdio:['ignore','ignore','ignore','pipe','pipe']});
 child.on('error',e=>{console.error('Chromium prerequisite unavailable: '+e.message);});
 const cdp=new CDP(child);
 async function close(){try{await Promise.race([cdp.send('Browser.close'),new Promise(r=>setTimeout(r,1000))]);}catch{}if(child.exitCode===null&&child.pid){await Promise.race([new Promise(r=>child.once('exit',r)),new Promise(r=>setTimeout(r,1000))]);if(child.exitCode===null){child.kill('SIGKILL');await new Promise(r=>child.once('exit',r));}}fs.rmSync(profile,{recursive:true,force:true,maxRetries:10,retryDelay:100});}
 cdp.close=close;
 try{const {targetId}=await cdp.send('Target.createTarget',{url:'about:blank'});const {sessionId}=await cdp.send('Target.attachToTarget',{targetId,flatten:true});cdp.session=sessionId;await cdp.send('Page.enable',{},sessionId);await cdp.send('Runtime.enable',{},sessionId);await cdp.send('Emulation.setDeviceMetricsOverride',{width:1440,height:900,deviceScaleFactor:1,mobile:false},sessionId);await cdp.send('Page.navigate',{url},sessionId);return cdp;}catch(e){await close();throw e;}
}
async function main(){const[url,target,dir]=process.argv.slice(1);let cdp;const deadline=setTimeout(()=>{console.error('Browser automation deadline');process.exitCode=2;if(cdp)cdp.close().finally(()=>process.exit(2));else process.exit(2);},target==='10'?40000:100000);
 try{cdp=await open(url);await cdp.wait(`window.evosim && !evosim.error && evosim.renderedTick !== null && BigInt(evosim.renderedTick)>=${target}n && evosim.draws>0`);await cdp.evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))');
 const evidence=await cdp.evaluate(`({tick:evosim.renderedTick,draws:evosim.draws,width:document.querySelector('#world').width,height:document.querySelector('#world').height,legend:document.querySelector('#legend').innerText,counts:[...document.querySelectorAll('.species')].map(e=>e.innerText)})`);
 if(cdp.errors.length||!evidence.width||!evidence.height||evidence.counts.length!==3||!evidence.legend.includes('Tropical'))throw Error('Render/legend assertion failed '+JSON.stringify(cdp.errors));
 const diagnostics=await cdp.evaluate(`fetch('/api/diagnostics',{headers:{'X-Evosim-Token':location.hash.slice(1)}}).then(r=>r.json())`);
 if(dir){const shot=await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},cdp.session);const png=Buffer.from(shot.data,'base64');if(png.readUInt32BE(16)<1280||png.readUInt32BE(20)<720)throw Error('Screenshot too small');fs.writeFileSync(path.join(dir,'main.png'),png);
 await cdp.evaluate('document.querySelector("#charts-tab").click()');
 await cdp.wait(`evosim.chartDraws>0 && evosim.chartTick===evosim.renderedTick`);
 const charts=await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},cdp.session);fs.writeFileSync(path.join(dir,'charts.png'),Buffer.from(charts.data,'base64'));
 await cdp.evaluate('document.querySelector("#world-tab").click()');
 await cdp.evaluate('new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve(true))))');
 // Optional second view uses the same real map selection flow, without ticking.
 const point=await cdp.evaluate(`(()=>{const o=evosim.frame.organisms[0];if(!o)return null;const r=document.querySelector('#world').getBoundingClientRect(),p=Camera.worldToScreen(evosim.camera,o[2]+.5,o[3]+.5);return {x:r.x+p.x,y:r.y+p.y};})()`);
 if(point){for(const type of ['mousePressed','mouseReleased'])await cdp.send('Input.dispatchMouseEvent',{type,...point,button:'left',clickCount:1},cdp.session);
 await cdp.wait('evosim.frame.selected || document.querySelectorAll("#chooser button").length');
 await cdp.evaluate('document.querySelector("#chooser button")?.click()');await cdp.wait('evosim.frame.selected');
 const inspector=await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},cdp.session);fs.writeFileSync(path.join(dir,'inspector.png'),Buffer.from(inspector.data,'base64'));}
 }
 console.error('UI automation '+JSON.stringify({...evidence,...diagnostics}));
 }finally{clearTimeout(deadline);if(cdp)await cdp.close();}}
module.exports={open,CDP};
if(!module.parent)main().catch(e=>{console.error('UI automation: '+e.stack);process.exitCode=2;});

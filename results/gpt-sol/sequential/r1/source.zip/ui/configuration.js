/* Pure exact-token form logic. No numeric coercion of configuration values. */
(function(root,factory){const api=factory();if(typeof module==='object')module.exports=api;else root.Configuration=api;})(this,()=>{
'use strict';
const fields=[
 ['seed','Seed · integer','int'],['world.width','Width · cells ≥ 1','uint'],['world.height','Height · cells ≥ 1','uint'],
 ...['plants','herbivores','carnivores'].map(k=>['initial.'+k,'Initial '+k+' · individuals ≥ 0','uint']),
 ['climate.year_ticks','Year length · ticks ≥ 1','uint'],
 ...['season_temperature_amplitude','season_precipitation_amplitude','weather_amplitude'].map(k=>['climate.'+k,k.replaceAll('_',' ')+' · 0–1','real']),
 ['genetics.mutation_per_million','Mutation · per million, 0–1000000','uint'],['genetics.mutation_max_step','Mutation step · 1–65535','uint'],
 ['plants.resource_capacity','Resource capacity · (0, 1000000]','real'],['plants.resource_regeneration','Resource regeneration · [0, 1000000] / tick','real'],['plants.growth_efficiency','Growth efficiency · 0–1','real'],['plants.reproduction_energy','Plant reproduction energy · (0, 1000000]','real'],['plants.dispersal_radius','Dispersal radius · cells, 0–4294967295','uint'],
 ['animals.movement_cost','Movement cost · [0, 1000000] energy','real'],['animals.basal_cost','Basal cost · (0, 1000000] energy / tick','real'],['animals.reproduction_energy','Animal reproduction energy · (0, 1000000]','real'],['animals.reproduction_cooldown','Reproduction cooldown · ticks ≥ 1','uint']
];
const integer=/^-?(0|[1-9]\d*)$/, unsigned=/^(0|[1-9]\d*)$/, real=/^-?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?$/;
function assemble(tokens){const errors={};for(const [path,,type] of fields){const v=tokens[path];if(typeof v!=='string'||!(type==='int'?integer:type==='uint'?unsigned:real).test(v))errors[path]='Enter a '+(type==='real'?'JSON number':'whole number')+' (no spaces).';}
 if(Object.keys(errors).length)return {errors};
 const groups={};for(const [path]of fields){const parts=path.split('.');if(parts.length===1)continue;(groups[parts[0]]||=([])).push(JSON.stringify(parts[1])+':'+tokens[path]);}
 return {json:'{"seed":'+tokens.seed+','+Object.entries(groups).map(([k,v])=>JSON.stringify(k)+':{'+v.join(',')+'}').join(',')+'}',errors};
}
function affected(path){if(path==='world.width/world.height')return ['world.width','world.height'];if(path==='initial')return fields.filter(f=>f[0].startsWith('initial.')).map(f=>f[0]);return fields.some(f=>f[0]===path)?[path]:[];}
return {fields,assemble,affected};
});

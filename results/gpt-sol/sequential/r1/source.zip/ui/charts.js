/* Pure chart selections/scales: exact decimal labels, relative BigInt x offsets. */
(function(root,factory){const api=factory();if(typeof module==='object')module.exports=api;else root.Charts=api;})(this,()=>{
'use strict';
const kinds=['Plants','Herbivores','Carnivores'],colors=['#a8df72','#fff0ca','#ff826e'];
function lines(points,type,trait=0){if(!['population','events','species','means'].includes(type))throw Error('Unknown chart');if(!Number.isInteger(trait)||trait<0||trait>=12)throw Error('Unknown trait');const out=[];for(let k=0;k<3;k++)for(const key of type==='events'?['births','deaths']:[type])out.push({name:kinds[k]+(type==='events'?' '+key:''),color:colors[k],dashed:key==='deaths',values:points.map(p=>({tick:p.tick,value:key==='means'?p.kinds[k].means[trait]:p.kinds[k][key]}))});return out;}
function geometry(series){const values=series.flatMap(s=>s.values);const first=values[0]?.tick||'0',last=values.at(-1)?.tick||first;const span=Number(BigInt(last)-BigInt(first))||1;const numeric=values.filter(v=>v.value!==null).map(v=>Number(v.value)).filter(Number.isFinite);const max=Math.max(1,...numeric);return {first,last,max,series:series.map(s=>({...s,values:s.values.map(v=>({...v,x:Number(BigInt(v.tick)-BigInt(first))/span,y:v.value===null?null:1-Number(v.value)/max}))}))};}
function histogram(current,trait){if(!Number.isInteger(trait)||trait<0||trait>=12)throw Error('Unknown trait');const h=current.histograms[trait];return {...h,max:Math.max(1,...h.counts.flat().map(Number)),tick:current.tick};}
return {kinds,colors,lines,geometry,histogram};
});

'use strict';
(async()=>{
const canvas=document.querySelector('#world'),ctx=canvas.getContext('2d'),viewport=document.querySelector('#viewport'),status=document.querySelector('#status');
const palette={polar:'#677d89',tundra:'#768b77',temperate:'#566c45',dry:'#a38b52',tropical:'#2e6654'};
const token=location.hash.slice(1);let camera,world,frame,drag,dirty=true,width=0,height=0;
const observation=window.evosim={draws:0,frames:[],renderedTick:null,initialCount:null,camera:null,error:null,palette};
let queue=Promise.resolve();const feedback=document.querySelector('#feedback');
function serial(fn){const task=queue.then(fn);queue=task.catch(()=>{});return task;}
function fail(e){observation.error=String(e);status.textContent='Connection interrupted: '+e;}
async function get(path){const r=await fetch(path);if(!r.ok)throw Error(path+': '+r.status);return r.json();}
try{
 world=await get('/api/world');frame=await get('/api/frame');while(world.epoch!==frame.epoch){world=await get('/api/world');frame=await get('/api/frame');}observation.initialCount=frame.organisms.length;
 document.querySelector('#dimensions').textContent=world.width+' × '+world.height+' CELLS';
 const layer=document.createElement('canvas');
 function buildWorld(){layer.width=world.width;layer.height=world.height;const bg=layer.getContext('2d');world.cells.forEach((b,i)=>{bg.fillStyle=palette[b];bg.fillRect(i%world.width,Math.floor(i/world.width),1,1);});document.querySelector('#dimensions').textContent=world.width+' × '+world.height+' CELLS';}
 buildWorld();
 function fit(){camera=Camera.fit(world.width,world.height,width,height);dirty=true;}
 function resize(){const r=viewport.getBoundingClientRect();if(r.width<3||r.height<3)return;width=r.width-2;height=r.height-2;const dpr=devicePixelRatio||1;canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);fit();}
 new ResizeObserver(resize).observe(viewport);resize();
 function zoom(x,y,f){camera=Camera.zoomAt(camera,x,y,f);dirty=true;}
 canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoom(e.clientX-r.left,e.clientY-r.top,Math.exp(-e.deltaY*.0015));},{passive:false});
 canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);drag={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY,moved:false};});
 canvas.addEventListener('pointermove',e=>{if(!drag)return;if(Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)>4)drag.moved=true;if(drag.moved){camera.x+=e.clientX-drag.x;camera.y+=e.clientY-drag.y;camera.x=Math.max(-world.width*camera.scale+24,Math.min(width-24,camera.x));camera.y=Math.max(-world.height*camera.scale+24,Math.min(height-24,camera.y));dirty=true;}drag.x=e.clientX;drag.y=e.clientY;});
 canvas.addEventListener('pointerup',e=>{if(drag&&!drag.moved){const r=canvas.getBoundingClientRect(),x=Math.floor((e.clientX-r.left-camera.x)/camera.scale),y=Math.floor((e.clientY-r.top-camera.y)/camera.scale);choose(frame.organisms.filter(o=>o[2]===x&&o[3]===y));}drag=null;});
 for(const event of ['pointercancel','lostpointercapture'])canvas.addEventListener(event,()=>drag=null);
 document.querySelector('#plus').onclick=()=>zoom(width/2,height/2,1.35);document.querySelector('#minus').onclick=()=>zoom(width/2,height/2,1/1.35);document.querySelector('#fit').onclick=fit;
 function draw(){
  if(dirty){dirty=false;ctx.clearRect(0,0,width,height);ctx.save();ctx.translate(camera.x,camera.y);ctx.scale(camera.scale,camera.scale);ctx.imageSmoothingEnabled=false;ctx.drawImage(layer,0,0);ctx.beginPath();ctx.rect(0,0,world.width,world.height);ctx.clip();
   if(camera.scale>=12){ctx.strokeStyle='#101c1620';ctx.lineWidth=1/camera.scale;ctx.beginPath();for(let x=0;x<=world.width;x++){ctx.moveTo(x,0);ctx.lineTo(x,world.height);}for(let y=0;y<=world.height;y++){ctx.moveTo(0,y);ctx.lineTo(world.width,y);}ctx.stroke();}
   const stacks=new Map();for(let kind=0;kind<3;kind++)for(const [id,k,x,y]of frame.organisms){if(k!==kind)continue;const key=x+','+y;stacks.set(key,(stacks.get(key)||0)+1);const px=x+[.30,.60,.65][k],py=y+[.65,.35,.70][k],r=[.13,.18,.22][k];ctx.fillStyle=['#a8df72','#fff0ca','#ff826e'][k];ctx.strokeStyle='#152319';ctx.lineWidth=.045;ctx.beginPath();if(k===2){ctx.moveTo(px,py-r);ctx.lineTo(px+r,py+r);ctx.lineTo(px-r,py+r);ctx.closePath();}else ctx.arc(px,py,r,0,Math.PI*2);ctx.fill();ctx.stroke();}
   if(camera.scale>=24){ctx.font='.23px Arial';ctx.textAlign='left';for(const [key,n]of stacks){if(n<2)continue;const[x,y]=key.split(',').map(Number);ctx.fillStyle='#07120fdd';ctx.fillRect(x+.03,y+.02,.42,.28);ctx.fillStyle='#fff';ctx.fillText(String(n),x+.07,y+.24);}}
   if(frame.selected?.status==='living'){const [x,y]=frame.selected.position;ctx.strokeStyle='#fff';ctx.lineWidth=2/camera.scale;ctx.strokeRect(x+.05,y+.05,.9,.9);}
   ctx.restore();observation.draws++;observation.camera={...camera};
   if(observation.renderedTick!==frame.tick){observation.frames.push({tick:frame.tick,time:performance.now(),count:frame.organisms.length});if(observation.frames.length>600)observation.frames.shift();}
   observation.renderedTick=frame.tick;observation.epoch=frame.epoch;observation.revision=frame.revision;observation.frame=frame;
   window.experiments?.update(frame);
   document.querySelector('#tick').textContent='TICK '+frame.tick;document.querySelector('#mobile-tick').textContent='TICK '+frame.tick;['plants','herbivores','carnivores'].forEach((id,i)=>{document.getElementById(id).textContent=frame.counts[i];document.getElementById('mobile-'+id).textContent=frame.counts[i];});renderInspector();document.querySelector('#mode').textContent=frame.running?'Running':'Paused';document.querySelector('#speed').value=frame.speed;
  }
  requestAnimationFrame(draw);
 }
 status.textContent='';draw();
 const ready=await fetch('/api/ready',{method:'POST',headers:{'X-Evosim-Token':token}});if(!ready.ok)throw Error('startup handshake: '+ready.status);
 async function accept(latest){
  if(BigInt(latest.revision)<BigInt(frame.revision))return;
  if(latest.epoch!==world.epoch){const nextWorld=await get('/api/world');if(nextWorld.epoch!==latest.epoch)return;world=nextWorld;buildWorld();fit();document.querySelector('#chooser').replaceChildren();}
  frame=latest;dirty=true;
 }
 function busy(value){document.querySelectorAll('.controls button,.controls select').forEach(b=>b.disabled=value);}
 async function post(path,body,epoch=frame.epoch){const r=await fetch(path,{method:'POST',headers:{'X-Evosim-Token':token,'X-Evosim-Epoch':epoch,...(body?{'Content-Type':'application/octet-stream'}:{})},body});if(!r.ok)throw Error(await r.text());return r;}
 function command(name){const epoch=frame.epoch;return serial(async()=>{busy(true);try{await accept(await (await post('/api/control/'+name,undefined,epoch)).json());feedback.textContent='';}catch(e){feedback.textContent=String(e);}finally{busy(false);}});}
 for(const name of ['run','pause','step','reset','clear-selection'])document.getElementById(name).onclick=()=>command(name);
 document.querySelector('#speed').onchange=e=>command('speed/'+e.target.value);
 document.querySelector('#save').onclick=()=>{const epoch=frame.epoch;return serial(async()=>{busy(true);try{const r=await post('/api/checkpoint/save',undefined,epoch),blob=await r.blob();if(epoch!==frame.epoch)return;const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=(r.headers.get('Content-Disposition')||'').match(/filename=(.+)/)?.[1]||'evosim.evo';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);feedback.textContent='Download prepared';}catch(e){feedback.textContent=String(e);}finally{busy(false);}});};
 const input=document.querySelector('#checkpoint-file');document.querySelector('#load').onclick=()=>{input.value='';input.click();};
 input.onchange=()=>{const file=input.files[0],epoch=frame.epoch;if(!file)return;serial(async()=>{busy(true);try{if(file.size>64*1024*1024)throw Error('UI upload limit is 64MiB');await accept(await (await post('/api/checkpoint/load',file,epoch)).json());feedback.textContent='Checkpoint loaded · paused';}catch(e){feedback.textContent=String(e);}finally{busy(false);}});};
 function choose(rows){const chooser=document.querySelector('#chooser');chooser.replaceChildren();if(!rows.length)return;
  rows.sort((a,b)=>BigInt(a[0])<BigInt(b[0])?-1:1);if(rows.length===1){command('select/'+rows[0][0]);return;}
  for(const [id,k]of rows){const button=document.createElement('button');button.textContent=['Plant','Herbivore','Carnivore'][k]+' #'+id;button.onclick=()=>{command('select/'+id);chooser.replaceChildren();};chooser.append(button);}
 }
 function renderInspector(){const panel=document.querySelector('#inspector'),s=frame.selected,scroll=panel.scrollTop,oldId=panel.dataset.id;panel.replaceChildren();panel.dataset.id=s?.id||'';document.querySelector('#selection-hint').textContent=s?'Following #'+s.id+' · click another cell to change.':'Click a map cell to inspect its inhabitants.';if(!s)return;
  function line(tag,text,cls){const el=document.createElement(tag);el.textContent=text;if(cls)el.className=cls;panel.append(el);}
  function fields(rows){const dl=document.createElement('dl');for(const[k,v]of rows){const dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=k;dd.textContent=String(v);dl.append(dt,dd);}panel.append(dl);}
  line('h3',s.kind+' #'+s.id);line('p',s.status==='died'?'Died at tick '+s.death_tick+' · '+s.death_cause:'Living',s.status==='died'?'dead':'');
  if(s.status==='died')line('p','Last observed at tick '+s.observed_tick);
  fields([['ID',s.id],['Kind',s.kind],['Species',s.species_name+' (#'+s.species_id+')'],['Age (ticks)',s.age],['Energy',s.energy.toFixed(3)],['Health',s.health.toFixed(3)],['Generation',s.generation],['Parents',s.parents.length?s.parents.join(', '):'None (initial organism)']]);
  line('h3','Expressed traits');fields(Object.entries(s.traits).map(([k,v])=>[k,Number(v.toPrecision(6))]));
  line('h3','Genome · version '+s.genome.version);fields(s.genome.names.map((k,i)=>[k,s.genome.alleles[i]]));if(oldId===s.id)panel.scrollTop=scroll;
 }
 window.experiments=Experiments.mount({serial,accept,getFrame:()=>frame,token});
 async function poll(){try{await serial(async()=>accept(await get('/api/frame')));status.textContent='';}catch(e){fail(e);}finally{setTimeout(poll,100);}}

 poll();
}catch(e){fail(e);}
})();

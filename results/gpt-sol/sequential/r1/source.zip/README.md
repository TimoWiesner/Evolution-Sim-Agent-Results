# Evolution Simulation

A locally runnable grid-world ecological evolution game with seeded climate,
plants, herbivores and carnivores, heritable DNA, mutation and species formation.
The headless CLI and live browser UI use the same Rust engine.

After setup, start the demo with one command:

```sh
./evosim ui --config scenarios/demo.json
```

Open the local URL printed by the command. The demo is a64×48 world with2,000
plants,60 herbivores and8 carnivores, resource regeneration4 and animal reproduction
cooldown300; other parameters retain the defaults. These are initial conditions
and uniform ecological parameters, without population rescue.

Fresh10,000-tick validation on hunting model2 measured:

| Input | Seed | First zero of any kind (tick F) | Positive completed ticks before F |
|---|---:|---:|---:|
| Contract section3 fixed-only example |42|315|314|
| Contract section3 fixed-only example |43|315|314|
| Contract section3 fixed-only example |44|310|309|
| Demo |42|1111|1110|
| Demo |43|1113|1112|
| Demo |44|1112|1111|

All three kinds are present in interval[0,F); plants disappear first in these
runs. Every run completed all10,000 ticks without errors and ended empty.
Durable coexistence was not reached. Four candidate inputs were compared on
separate seeds0,1,2 before freezing the demo. Exact per-kind extinction ticks,
hashes, timings, trial selection and commands are in
[verification evidence](docs/VERIFICATION.md). The
[project self-audit](docs/SELF_AUDIT.md) records partly met goals and limitations,
including the absence of a dedicated generation-trend chart (generation data is
exported in result series).

On Ubuntu 24.04 x86-64, install and build with:

```sh
./setup.sh
./evosim version
./evosim --help
```

Setup is non-interactive and idempotent. It needs Rust 1.85+ with Cargo and rustup
(the benchmark container provides them), a C toolchain and internet access. When
missing, it installs musl-tools using apt as root and adds Rust's
`x86_64-unknown-linux-musl` target. Both host and static release executables are
built with the committed Cargo.lock. Configuration uses serde_json; resolved crate versions are pinned in Cargo.lock.
Run setup again if system packages do not persist between containers.

Build the portable distribution:

```sh
./build.sh
./dist/evosim version
```

Copy the whole `dist/` directory to a Linux x86-64 machine and execute its `evosim`.
The executable is statically linked against musl; it requires no installed Rust,
Python, Node, shared libraries, or workspace files. All runtime commands work offline. Headless version/run/batch need no display;
UI requires a local browser. Automated UI smoke/screenshots also need Node >=18
and Chromium (provided by the benchmark). Setup/build may use the network. Root scripts resolve their
own directory and work from any caller directory. The workspace launcher executes
the existing host release binary; rerun setup after changing source.

Run the complete test suite with one command (after setup):

```sh
./test.sh
```

Tests use Cargo's built-in unit/integration runner and Python 3.11+ stdlib unittest.
The packaging tests also require `readelf` (Ubuntu `binutils`), Git, and `chroot`
(Ubuntu `coreutils`), provided in the benchmark container. They run setup twice,
build dist, inspect ELF dependencies, and execute a copied executable inside an
otherwise empty root directory. That last check requires root and is explicitly
skipped on non-root developer machines. Temporary test files stay under ignored
`target/`; `dist/`, compiler output, and Python caches are also ignored.

Source layout: `src/lib.rs` exposes the library, `src/cli.rs` dispatches commands,
`src/main.rs` handles process I/O, and `tests/` holds process/packaging checks.
Design and engine boundaries are in `docs/ARCHITECTURE.md` and ADRs.

Typed JSON configuration and named presets are available through the Rust library;
see [configuration schema and API](docs/CONFIGURATION.md). Inspect climate with
`./evosim climate --config FILE --out FILE`; see the reproducible example, model
and topology compromise in [base climate documentation](docs/CLIMATE.md).

Measure ecology through the public library (five seeds, exactly 10,000 ticks each):

```sh
env -u DISPLAY cargo run --locked --release --example ecology_report > target/ecology.json
```

See [ecology order, defaults, scenarios and recorded outcomes](docs/ECOLOGY.md).

Run a seeded simulation and write the benchmark result JSON:

```sh
mkdir -p target
cat > target/run-config.json <<'JSON'
{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}
JSON
./evosim run --config target/run-config.json --ticks 1000 --out target/result.json --seed 42 --sample-every 10
```

`--ticks 0` is valid. Runs advance the full requested duration through extinction.
Samples include tick zero, every interval, and the final tick once; the default
interval is `max(1, ticks / 100)`. `--seed` overrides a valid configuration seed
and accepts arbitrarily large signed decimal integers. Successful runs print
nothing; errors print to stderr and exit 2. Output is published atomically after
success; an existing regular result is preserved on errors. Parent directories
must exist. Symlink, directory and special-file output destinations are rejected.
Save a complete checkpoint and continue it later (using the config above):

```sh
./evosim run --config target/run-config.json --ticks 53 --out target/first.json --save target/world.evo
./evosim run --load target/world.evo --ticks 147 --out target/resumed.json --save target/world.evo
```

The second command reaches absolute tick 200 and replaces the checkpoint.
Loaded samples start at the saved tick, with intervals measured from that start.
Use `--ticks 0` to save initial state. A loaded run retains its seed; `--seed`
requires `--config`. See [checkpoint format, validation and file publication](docs/CHECKPOINTS.md).

Results include complete-state SHA-256 (`state_hash_schema: 1`); sampling and
wall-clock timings are excluded from state. Compare deterministic results after
removing `elapsed_seconds` and `ticks_per_second`. Timing measures engine tick
calls only, and both measurements are zero for zero ticks. See
[canonical state schema](docs/decisions/ADR-015-canonical-state-and-run.md).

Every result also includes `metrics_schema: 1` and evolution analytics in every
`series` sample: cumulative births/deaths and causes, living species, all twelve
trait means/spreads/minima/maxima, and generation summaries. The example above
samples every ten ticks; inspect `series[0].analytics.plants.traits.strength`
or `series[0].analytics.generation`. See [metrics format and API](docs/METRICS.md)
for units, empty-world nulls, precision, and a complete example.


Run multiple seeds and export comparative JSON and CSV summaries (using the
configuration created above):

```sh
./evosim batch --config target/run-config.json --seeds 1,2 --ticks 100 --out-dir target/batch
./evosim batch --config target/run-config.json --seeds 7,11 --ticks 17 --out-dir target/matrix --sweep 'plants.resource_regeneration=[1,2]'
```

The second command runs a two-value by two-seed matrix. Results live in indexed
variant directories, while `summary.json` and `summary.csv` list runs and final
population/extinction aggregates. Summaries omit timings and repeat identically
on the same build. See [batch options, schemas and publication rules](docs/BATCH.md).


Start the live world view:

```sh
./evosim ui
./evosim ui --config target/run-config.json
```

Open the complete local URL printed on stderr in your browser. The simulation
starts after its first rendered frame; Ctrl-C in the terminal stops the server.
Drag to pan, scroll to zoom, or use the +/- and Fit world camera buttons. The
legend identifies climate colours, green plants, ivory herbivores and coral
predators. Opposite edges of the map connect. Run controls and inspection are
available, along with New experiment and Charts. See [UI protocol and dependencies](docs/UI.md).

Exercise the real UI without interaction, or capture the actual interface:

```sh
xvfb-run -a ./evosim ui --smoke-test
mkdir -p target/ui-shots
xvfb-run -a ./evosim ui --screenshots target/ui-shots
```

These modes advance10/100 ticks and shut down automatically; screenshots write
`main.png` and `charts.png` at1440×900, plus `inspector.png` when an organism is available. Without DISPLAY they use headless Chromium. Browser discovery
uses CHROME_BIN, PUPPETEER_EXECUTABLE_PATH, then chromium on PATH. setup installs
Node if absent; Chromium and xvfb are benchmark prerequisites for these checks.


The live UI includes Run/Pause/Step/Reset, three speeds, a map-click organism
inspector and browser checkpoint Save/Load. Step pauses and advances one tick;
Reset uses the current configuration/seed. Load pauses and adopts its checkpoint's
configuration for subsequent reset. Checkpoints interoperate with the CLI; browser
uploads are limited to64MiB. See [UI controls and files](docs/UI.md) for semantics,
selection/death details and local protocol limits.

New experiment lets you select a preset and edit every configuration parameter.
Start world validates the draft and pauses the new world at tick0. Import JSON
and Export JSON round-trip the effective configuration without changing the active
world. Errors appear beside the affected inputs. Charts shows population, cumulative
births/deaths, living species, trait means and selectable trait distributions;
run controls stay available. Charts retain the latest2048 ten-tick samples plus
current data; reset/start/load begin a fresh window. See [experiment and chart
semantics](docs/UI.md) for precision, file limits and protocol details.


Configuration parameters are documented with every default, type and range in
[CONFIGURATION.md](docs/CONFIGURATION.md). Required keys are `seed`,
`world.width/height`, and `initial.plants/herbivores/carnivores`. Optional groups:

| Group | Parameters |
|---|---|
| `climate` | `year_ticks`, `season_temperature_amplitude`, `season_precipitation_amplitude`, `weather_amplitude` |
| `genetics` | `mutation_per_million`, `mutation_max_step` |
| `plants` | `resource_capacity`, `resource_regeneration`, `growth_efficiency`, `reproduction_energy`, `dispersal_radius` |
| `animals` | `movement_cost`, `basal_cost`, `reproduction_energy`, `reproduction_cooldown` |

Use JSON numbers, with integer tokens for integer parameters. Unknown keys and
invalid values exit2 with a field/path error. Zero initial populations are valid;
zero width/height is invalid. UI New experiment edits the same parameters.

Reproduce the delivery measurements after setup (Python3 required for the
external observer validator):

```sh
cargo build --locked --release --example balance_report
python3 tools/release_verify.py --mode long --config scenarios/demo.json --seeds 42,43,44 --ticks 10000 --label demo --out-dir target/demo-verification
```

This runner writes CLI results, exact per-tick observer CSVs, a command ledger and
validated coexistence summaries. It is separate from the ordinary `./test.sh`
suite. See [VERIFICATION.md](docs/VERIFICATION.md) for full release reproduction,
static/offline proof and all known validation limits.

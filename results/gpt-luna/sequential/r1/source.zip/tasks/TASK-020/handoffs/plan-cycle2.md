# TASK-020 PLAN cycle 2

## Replan trigger and dependency inspection

This replan closes REVIEW cycle 1's only finding, GAP-020-R1. The sampled
metrics implementation, CLI schema/alignment and read-only observer are
already present. The failing criterion is specifically independent,
hand-verifiable test evidence for trait spread and nonzero generations.

Read the TASK-020 plan, implementation and review cycle 1 handoffs, ADR-020,
and dependency handoffs for TASK-017, TASK-018 and TASK-019. Dependency review
status: TASK-017 PASS, TASK-018 cycle 1 FAIL followed by cycle 2 PASS, and
TASK-019 PASS. Their currently used interfaces are present: organisms expose
traits/genomes/generation, World exposes ordered live organisms and species /
lifecycle queries, and Simulation exposes a stable state hash. In
`src/metrics.rs`, the current test constructs random genomes and derives its
expected mean from those same organisms; it does not assert standard deviation
or nonzero generation statistics. The `metrics` test module can set explicit
organism fields through the crate-visible world map, avoiding production API
changes. Initial reproduction/lifecycle behavior does not need to be run for
the fixture.

## Cycle 2 implementation plan

1. In `src/metrics.rs` tests, create a compact simulation with exactly two
   plants and no other organisms. Set their genomes to explicit speed values
   10 and 14, update their phenotype traits consistently with those genomes,
   and set their generations to 2 and 4. Capture one `MetricsSample`.
2. Assert the sample has plant speed mean `12.0` and population standard
   deviation `2.0`, plant generation highest `Some(4)` and mean `Some(3.0)`.
   Also assert the sample's plant population is two. These expected values must
   be literals derived by hand, not computed from the fixture under test.
3. Keep the existing `repeated_observation_does_not_change_future_seeded_simulation`
   hash regression intact. Keep existing cause/lifecycle/null assertions and
   CLI sample alignment coverage. Do not change metric schema or engine code.
4. Update ADR-020 and task-local implementation handoffs with exact outcomes;
   the review cycle's fail-to-pass gap closure should be explicit. Update
   architecture/state only to keep their implementation and review status
   accurate.
5. Run `cargo test metrics::tests -- --nocapture`, the focused CLI metrics
   alignment test, full `cargo test`, `cargo fmt --all -- --check`,
   `git diff --check`, JSON validation for handoffs, and inspect
   `git remote -v`. Do not run expensive ecology benchmarks for this test-only
   change. Record real outputs and any failures.

## Decisions and risks

- Preserve the cycle 1 additive `metrics` array format and observer design.
- Prefer modifying the already-small metrics fixture over introducing a new
  helper abstraction or production API. Ensure the fixture's genome and
  derived `Traits` remain consistent, so the test represents valid organisms.
- Fixed `f64` assertions are exact for these chosen values (integers and an
  exactly representable standard deviation of 2), while empty-population and
  animal-only null behavior remains covered by existing tests.
- No system dependency, crate or production behavior change is expected.

## Plan verification

This PLAN cycle runs documentation/handoff validation only. Product tests are
reserved for IMPLEMENT cycle 2; results must be recorded there rather than
claimed here.

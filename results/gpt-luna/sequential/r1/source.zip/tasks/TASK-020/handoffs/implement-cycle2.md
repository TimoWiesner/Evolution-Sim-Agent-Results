# TASK-020 IMPLEMENT cycle 2

Closed REVIEW cycle 1 gap GAP-020-R1 by replacing the inferred plant-speed mean in the metrics unit fixture with an explicit two-organism setup. Plant genomes and phenotypes are set consistently to speeds 10 and 14; generations are set to 2 and 4. Assertions verify population 2, mean speed 12.0, population standard deviation 2.0, highest generation 4, and mean generation 3.0. Existing empty-kind and plant-inapplicable null checks, death-cause coverage, and read-only state-hash regression remain. A `#[cfg(test)]` mutable world accessor on `Simulation` supports fixture setup and is absent from production builds.

Verification:

- `cargo test metrics::tests -- --nocapture` — 3 passed, 0 failed.
- `cargo test --test cli run_is_headless_deterministic_and_emits_contract_shape -- --nocapture` — 1 passed, 0 failed.
- `cargo test` — 75 passed, 0 failed, 1 ignored. Ecology tests took 47.55 seconds and simulation tests 34.41 seconds.
- `cargo fmt --all -- --check` — passed.
- `git diff --check` — passed.
- `git remote -v` — no remotes listed.

No dependencies or system packages were added. Metrics remain read-only and the output schema is unchanged. Sampling still scans live organisms and accumulated death history.

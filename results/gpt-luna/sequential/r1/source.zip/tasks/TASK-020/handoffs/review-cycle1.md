# TASK-020 REVIEW cycle 1

## Review result: FAIL

The implementation emits the additive `metrics` array at each existing
population sample, including tick zero and the final tick. `MetricsSample`
observes the simulation through read-only queries, derives cause counts from
death history, reports all eight declared trait fields and generation
statistics, and does not change canonical state. ADR-020 and README document
the result schema. The CLI integration test checks one-to-one tick alignment,
population alignment, field presence, deterministic result fields, and
different-seed hashes.

**GAP-020-R1:** TASK-020 requires tests with values verifiable by hand. The
current hand-checkability test seeds a world with generated genomes and
calculates its expected mean from the same initialized organisms. It does not
assert a known mean or standard deviation. Its generation assertions only
cover generation zero. As a result, no test independently verifies the trait
aggregation (especially spread) against known inputs. Add a deterministic
fixture with explicit known trait values and assert fixed mean and population
standard deviation, plus nonzero generation high/mean. Keep the hash
invariance regression.

## Verification

- `cargo test metrics::tests -- --nocapture` — 3 passed.
- `cargo test --test cli run_is_headless_deterministic_and_emits_contract_shape -- --nocapture` — 1 passed.
- `cargo test` — 75 passed, 0 failed, 1 ignored; ecology 47.33 seconds and simulation 34.54 seconds.
- `cargo fmt --all -- --check && git diff --check` — passed.
- `git remote -v` — no remotes listed.

No implementation changes or system dependencies were made during review.

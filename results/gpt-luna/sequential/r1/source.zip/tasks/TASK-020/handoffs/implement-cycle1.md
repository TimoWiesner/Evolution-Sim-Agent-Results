# TASK-020 IMPLEMENT cycle 1

Implemented `MetricsSample` as a read-only observer in `src/metrics.rs` and
added it to each CLI `run` result. The metrics array is aligned one-to-one with
`series`, including tick zero, interval samples, and the final tick. Each item
contains population, cumulative births/deaths, living species, cumulative
deaths by kind and cause, means/population standard deviations for each
applicable trait, and highest/mean generation. Empty-kind statistics and
plant-inapplicable behavioral traits serialize as null. The full schema and
tradeoffs are documented in ADR-020 and briefly in README.

Verification:

- `cargo test metrics::tests -- --nocapture`: 3 passed, 0 failed. The tests
  cover small-world counts and nulls, each of the six cause values, and equal
  state hashes after repeated observation versus no observation.
- `cargo test --test cli run_is_headless_deterministic_and_emits_contract_shape -- --nocapture`:
  1 passed, checking sample alignment and preservation of result fields.
- `cargo test`: 75 passed, 0 failed, 1 ignored. Ecology integration took
  47.33 seconds and simulation integration took 34.50 seconds.
- `cargo fmt --all -- --check` and `git diff --check` passed.
- `git remote -v` listed no remotes. No network Git operation was performed.

No dependencies or system packages were added. Main remaining cost risk is
that each sample scans living organisms and accumulated death history.

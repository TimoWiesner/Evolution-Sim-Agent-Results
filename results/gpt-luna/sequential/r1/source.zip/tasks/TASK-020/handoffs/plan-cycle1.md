# TASK-020 PLAN cycle 1

## Inspection and dependency state

- Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md`, then read
  `docs/PROJECT.md`, `docs/CONTRACT.md`, `docs/STATE.md`,
  `docs/ARCHITECTURE.md`, TASK-020's task and JSON, and the PLAN skill.
- Read dependency handoffs and decisions for TASK-017 (species), TASK-018
  (ecology and lifecycle), and TASK-019 (headless CLI/hash). Their latest
  implementation/review handoffs report PASS. TASK-018's review cycle 2
  closes its only earlier gap. No TASK-020 phase handoffs existed at entry.
- Inspected `src/entity.rs`, `src/genome.rs`, `src/world.rs`,
  `src/simulation.rs`, `src/cli.rs`, `tests/cli.rs`, and
  `tests/simulation.rs`. Existing CLI `series` is sampled at tick zero,
  intervals, and the final tick. World already exposes living organisms,
  lifecycle counts, death history, and living species counts. Organisms expose
  all trait values, genome and generation. `Simulation::state_hash` hashes its
  own canonical state; it does not depend on result serialization.
- `git status --short` was clean before planning edits and `git remote -v`
  printed no entries. No Git network actions were taken.

## Decisions

- Add analytics to the headless run result as `metrics`, an array aligned
  exactly with `series` ticks. The contract allows extra result keys, so this
  avoids another flag and output-file lifecycle.
- At each sampled tick report per-kind population, cumulative births/deaths
  since tick zero, living species, death counts cross-tabulated by kind and
  cause, trait summaries, and generation statistics. This is cumulative to
  keep values comparable to result totals and preserve exact lifecycle
  accounting at every sample.
- Report arithmetic mean and population standard deviation for every declared
  trait. Plant-inapplicable animal tendencies (`risk_tolerance`, `aggression`,
  `foraging_bias`) are `null`; all trait/generation statistics for an empty
  kind are `null`. Generation is highest plus arithmetic mean per kind. Cause
  keys are always present for all `DeathCause` values, including zero counts.
- Make capture a read-only observer over `&Simulation` in a separate
  `src/metrics.rs`; do not add simulation counters/state or consume RNG. Derive
  death-cause breakdowns from existing ordered death history. Use integer
  accumulators before converting means/spreads to JSON numbers.
- Documented schema and rationale in proposed ADR-020; implementation should
  also explain the result's additive `metrics` field in README and architecture
  / state ledgers.

## Ordered implementation plan

1. Add serializable metric DTOs and `MetricsSample::capture(&Simulation)` in
   `src/metrics.rs`; export the module from `src/lib.rs`. Use existing public
   world queries. Ensure every sample is immutable observation and cause
   aggregation handles each `DeathRecord` once per capture.
2. Implement deterministic per-kind aggregate helpers. Accumulate trait sums
   and squared sums in integer types, compute population standard deviation,
   and represent empty/inapplicable metrics as `Option` serialized to `null`.
   Keep death-cause key ordering and JSON struct field ordering explicit.
3. In `src/cli.rs`, add `metrics: Vec<MetricsSample>` to `ResultFile`, capture
   the initial tick and every same interval/final tick where `series` is
   captured, and leave result contract keys and engine loop semantics intact.
4. Add focused unit coverage for a small hand-verifiable organism set and
   lifecycle/death/species counts. Include known trait mean/standard deviation,
   generation high/mean, every death cause, kind partitioning, nulls, and
   population/lifecycle accounting. Construct explicit genomes/organisms in
   a module test fixture rather than relying on arbitrary random values.
5. Add CLI integration coverage in `tests/cli.rs` for metrics tick alignment,
   all required keys/trait values and preservation of existing result fields.
   Add a paired seeded simulation regression that captures metrics between
   ticks in one run and never captures in another, then compares final hashes.
6. Update ADR-020 to implemented status, document the JSON schema in README,
   and update `docs/ARCHITECTURE.md`/`docs/STATE.md` with actual behavior and
   evidence. Record exact commands, outcomes, risks and no-system-dependency
   status in implementation handoffs.
7. Run focused metrics and CLI tests, `cargo test`,
   `cargo fmt --all -- --check`, `git diff --check`, handoff JSON validation,
   and `git remote -v`. Record actual results. Do not change task state or
   commit.

## Risks and limits

- Sampling requires O(live organisms) for population trait/generation
  summaries, plus a scan of death history for cause counts. Very small sample
  intervals or large death histories add reporting time, though they cannot
  alter simulation state.
- Floating output for mean and population standard deviation is analytics only;
  accumulators and underlying trait values remain deterministic integers. Test
  exact known examples and tolerance for the final square-root representation.
- The `metrics` key is additive but consumers assuming a closed JSON object
  may need to tolerate it. The benchmark contract explicitly permits added
  result keys.
- No system packages, Cargo dependencies, or product behavior changes are
  planned.

## PLAN checks

No product tests were run and no feature code was changed. Plan documentation
and handoff JSON were validated after writing; exact results are in
`plan-cycle1.json`.

# TASK-010 PLAN cycle 1

## Inspection

Confirmed the required workspace files exist. Read the agent contract, project
brief, fixed CLI contract, state/architecture ledgers, TASK-010 task and JSON,
ADR-003/ADR-006, current PLAN skill, and prior dependency handoffs. Existing
TASK-001 and TASK-004 decisions provide a row-major toroidal grid and unique
`Grid::neighborhood`; TASK-008/009 provide canonical ascending-ID
`BTreeMap<OrganismId, Organism>` storage and deferred birth/death boundaries.
TASK-013 lists TASK-010 as a dependency and expects the index to remain current
for sensing and movement. No TASK-010 handoffs or TASK-013 dependent handoffs
exist yet.

## Decisions and implementation sequence

Use a derived `Vec<Vec<OrganismId>>`, one bucket per row-major grid cell,
owned by `World` alongside its canonical organism map. Query with
`World::organisms_within(center, radius, kind: Option<OrganismKind>)`, returning
`Vec<&Organism>` in ascending ID order. The inclusive radius metric is the
existing toroidal Chebyshev distance; enumerate unique candidate cells with
`Grid::neighborhood`, collect IDs, sort, and resolve through the map. Add a
checked `World::move_organism` operation that updates index membership and
position together. Insert IDs for initial organisms and births at Finalize;
remove IDs at Mortality. Reconstruct index state from canonical positions
rather than serializing the derived structure.

Implementation steps: create and unit-test bucket membership; integrate all
lifecycle insertion/removal paths and movement; expose the query; add edge,
kind filter, ordering, alias/duplicate, and move/add/remove checks; compare at
least 1,000 deterministic randomized queries against a simple organism scan
on small and degenerate worlds and oversized radii; benchmark roughly 2,000
organisms against brute force and record the exact command, setup, and timings
in `docs/STATE.md`.

## Risks and scope

Mutable positions must not escape in a way that can bypass the index. Keeping
`Organism.position` public is safe only while World returns immutable
references; future mutable access must be mediated by World. Queries pay sorting
cost proportional to the number of returned organisms, which provides stable
ID order independent of bucket mutation history. Large radii touch many cells
and may approach brute-force cost, but correctness remains bounded by unique
cell enumeration. No system packages or new dependencies are planned. This is
planning only; no product tests were run.

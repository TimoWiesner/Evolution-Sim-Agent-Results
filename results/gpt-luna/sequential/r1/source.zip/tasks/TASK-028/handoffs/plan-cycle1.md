# TASK-028 PLAN cycle 1

## Scope and entry findings

Implement only TASK-028: prove reliability and prepare the local product
handoff. Do not change task specs, the external contract, benchmark state,
orchestration files, or start REVIEW. Dependent tasks TASK-018, -021, -022,
-025, -026 and -027 have implementation/review handoffs; their latest reviews
pass with no open gaps. Relevant product state and existing evidence were
inspected, including `docs/BALANCE.md`, `docs/PERFORMANCE.md`, ADR-019,
ADR-021, ADR-022, ADR-025, ADR-026 and ADR-027. The working tree was clean at
entry and `git remote -v` returned no entries.

Notable uncovered requirements: there is no `scenarios/` directory or demo
config, README does not document the configuration schema/defaults or demo
launch, and no single consolidated project self-audit/contract evidence
document exists. Existing tests cover many focused cases, but no broad
randomized test checks lifecycle accounting, ranges, wrapping and deterministic
state across many configurations. Contract batch syntax without `--vary` is
not currently accepted according to TASK-027's recorded workaround; test and
fix this mismatch within TASK-028. Existing default 10,000-tick measurements
show animals going extinct early; this is an outcome to report, not a failure
criterion.

## Decisions

ADR-028 records the evidence location, deterministic randomized test strategy,
demo tuning approach, distribution check, test aggregation and risks. Use
`docs/VERIFICATION.md` for the requirement audit and measured command evidence;
summarize coexistence in README. Start demo tuning from 96×72 with 1,600 plants,
160 herbivores and 8 carnivores, with a fixed seed. This starts with more
habitat and a smaller predator-to-prey ratio than defaults, but is only a
candidate; use bounded trials, obey contract runtime limits, and report every
final outcome. Existing config controls and local mechanisms only. No apt
packages or dependencies are planned.

## Ordered implementation

1. Inspect CLI/config/UI/build behavior against contract sections 1–7 and
   create `docs/VERIFICATION.md` as a coverage checklist. Verify config defaults
   and error semantics, output schema and timing, CLI invocation from another
   working directory, checkpoint state continuity/invalid files, and batch
   schema/validation. Remove the mandatory `--vary` requirement for ordinary
   contract batch runs, if confirmed, without changing sweep behavior. Add or
   update `tests/cli.rs` regressions for base batch command, repeatability,
   invalid inputs and no output where applicable.
2. Add `tests/reliability.rs`: use a documented deterministic PRNG to create at
   least dozens of small valid dimension/population/seed configurations. For
   each, advance bounded ticks and assert `initial + births - deaths == final`
   by kind, model values stay within declared bounds, opposite edges are
   toroidal neighbors (including 1-cell dimensions), and two same-seed
   simulations match hashes/results. Keep runtime suitable for normal
   `cargo test`; state generator and case counts in the file and report.
3. Tune a demo candidate using allowed configuration settings. Measure short
   candidate trials first; select a small enough world to meet 900 seconds per
   10,000 ticks. Add `scenarios/demo.json`, then run the final demo and exact
   contract example (64×48, 400/120/20, fixed keys only) for at least three
   seeds each, capturing exact first-zero ticks with interval-1 series and
   recording final counts and commands. Reuse only existing results where
   they are demonstrably same code/config and provide all required per-seed
   facts; otherwise rerun. Store concise evidence in `docs/VERIFICATION.md`.
4. Add a complete `docs/PROJECT.md` self-audit in `docs/VERIFICATION.md`,
   marking every required behavior/bullet met, partly met or missing and citing
   implementation/evidence/limitations. Include the current honest result that
   no minimum coexistence duration is guaranteed.
5. Update README with setup/install, exact `run`, `batch`, `ui` commands, all
   config fields and defaults, config import/export/seed usage if supported,
   one demo launch command, and measured demo/default coexistence summary.
6. Define one plainly named documented suite command (prefer `./test.sh` or
   equivalent) which invokes Rust, Node and the UI HTTP probe suites, and report
   individual counts. Add `scripts/verify_contract.sh` only if it keeps the
   full command audit repeatable and readable. Run formatting, full suite,
   `./setup.sh`, `./build.sh`, version/run/batch behavior, UI smoke and
   screenshots, and `git diff --check`.
7. Test `dist/evosim` after copying it to a temporary directory and running
   outside the checkout; inspect `ldd` and invoke version and a small run with
   a minimal PATH and no repository data. Remove test temp files. Record
   dynamic OS-library requirements and prove no Rust/Cargo/Node or network is
   needed by the executable.
8. Update ADR-028 with measured final results, `docs/STATE.md`,
   `docs/ARCHITECTURE.md`, README and the implementation handoff. Revalidate
   every JSON/doc artifact; do not commit.

## Test and evidence matrix

- One full command: `./test.sh` (or its selected equivalent) runs `cargo test`,
  `node --test tests-js/*.test.js` and `python3 tests/ui_http_probe.py`.
- Contract runs: verify `version`; `run` fixed-only JSON, seed override,
  sampling, zero ticks, deterministic/different seeds, exact accounting,
  extinction advancement, save/load split equivalence, malformed arguments,
  config/checkpoint errors and absence of result output on errors; `batch`
  documented form, per-seed/summary output and errors; `ui` live start, smoke
  within 60s, screenshots within 120s and 1280×720 PNG dimensions; setup and
  build idempotence/entry-point executability.
- Reliability properties: randomized lifecycle accounting, bounded
  populations/traits/resources/climate, wrap geometry and determinism.
- Delivery: copied distribution outside workspace, `ldd`, minimal PATH version
  and run.
- Ecology: 6 release/default and demo runs at 10,000 ticks, at least three
  distinct seeds per config; report coexistence lengths and final population.
- Documentation: README command/schema check, contract coverage matrix, and
  complete project requirement audit.

## Risks / assumptions

- The proposed larger demo may cost proportionally more climate work. Use
  bounded trials and reduce dimensions/populations before the final 10,000
  tick runs if needed.
- `tests/reliability.rs` should assert existing semantics rather than invent
  new ecological requirements or flaky thresholds.
- Existing benchmark evidence and worktree results must be checked for exact
  configuration/build compatibility before reusing them.
- Contract section 6 allows the target Ubuntu base ABI; ordinary libc/system
  libraries are acceptable if they are present on the stated base system.
- No system dependencies were installed or tests run during PLAN.


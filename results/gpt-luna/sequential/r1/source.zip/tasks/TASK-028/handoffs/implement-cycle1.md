# TASK-028 IMPLEMENT cycle 1

## Changes

- Removed the batch parser's unintended mandatory `--vary`; fixed seed batches
  now accept the command shown in `docs/CONTRACT.md`, and parameter sweeps still
  use the existing Cartesian matrix path.
- Added a regression for ordinary batch syntax and `tests/reliability.rs` with
  32 deterministic xorshift-generated small configs. Each advances two equal
  simulations in lockstep and checks hashes, lifecycle arithmetic, organism
  position/energy/health/trait structure, climate/resource ranges, and
  toroidal opposite-edge distance (including one-cell axes).
- Added `test.sh` as the one documented aggregate command for Rust, Node and UI
  HTTP checks. Added `scenarios/demo.json`; updated README, architecture/state,
  ADR-028 and `docs/VERIFICATION.md` with user docs, results, contract evidence
  and the PROJECT self-audit.

## Measured outcomes

Exact contract-default config (`examples/minimal.json`) completed seeds 1–3 at
10,000 ticks in 35.15, 35.16 and 34.95 seconds. Exact first-zero ticks were:
herbivores 214/174/196, carnivores 303/282/293, plants survived. Final counts
were (11004,0,0), (11050,0,0), and (11003,0,0).

Demo config (64×48, 1,200/160/4) completed seeds 1, 2 and 4 in 45.42, 39.32
and 38.24 seconds; exact interval-1 runs took 54.49, 48.18 and 47.05 seconds.
All three kinds first reached zero at ticks: seed 1 carnivores 1101; seed 2
carnivores 1153; seed 4 herbivores 1135 (carnivores 1232). Plants survived all
10,000 ticks. Final counts were (10988,25,0), (10975,2,0), and (10980,0,0).

An initial seed-3 demo batch trial had completed seeds 1 and 2, but was stopped
with no seed-3 result while it was still running. Based on total batch elapsed
time less the completed seed durations, it had run for approximately 864
seconds. Whether it would have finished within the 900-second limit is
unknown. This uncertainty is in ADR-028 and `docs/VERIFICATION.md`; seeds 1, 2
and 4 form the reported final set.

## Verification

- Focused: `cargo test --test reliability --test cli` — 12 passed, 0 failed.
- Aggregate: `./test.sh` — 86 Rust passed, 1 ignored, 0 failed; 7 Node passed;
  UI HTTP probe passed.
- Setup/build: `./setup.sh` and `./build.sh` succeeded.
- UI: `xvfb-run -a ./evosim ui --smoke-test` succeeded; screenshot mode wrote
  `main.png` and `charts.png`, each 1440×1400.
- Distribution: copied `dist/evosim` to `/tmp`, invoked version and a two-tick
  run with `PATH=/usr/bin:/bin` from `/tmp`; `ldd` lists only Ubuntu base
  libraries.
- Contract extras: no-plants run reached requested tick 1000 with all kinds
  extinct; malformed JSON returned status 2/stderr and created no output;
  custom sample spacing yielded ticks 0,3,6,7; invoking root launcher from
  `/tmp` succeeded.
- `cargo fmt --all -- --check` and `git diff --check` passed. `git remote -v`
  listed no remotes. No dependencies or system packages were added.

No implementation acceptance gap remains. The seed-3 candidate trial is an
unresolved run-time observation, not a required demo-seed failure; report it as
a risk and retain the completed final seed set. Harness owns review and phase
transition; this implementation does not start another phase.

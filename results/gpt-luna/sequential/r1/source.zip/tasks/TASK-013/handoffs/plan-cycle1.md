# TASK-013 PLAN cycle 1

## Inspection

Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` exist. Read the
product brief, fixed interface contract, project state and architecture, the
TASK-013 task specification/JSON, current PLAN skill, ADR-003/004/006/010/011,
and all PLAN/IMPLEMENT/REVIEW cycle 1 handoffs for dependencies TASK-008 and
TASK-010. There are no prior TASK-013 handoffs or dependent task handoffs.

The current engine has genome-backed `speed` traits, canonical ascending-ID
organism storage, a fixed `AnimalMovement` phase, toroidal `Grid::direction`,
and `World::organisms_within` backed by the maintained per-cell index. The
public `Simulation::move_organism` path synchronously updates canonical
positions and index buckets. Energy is bounded and readable, but there is no
animal movement/perception behavior yet. Existing tests in
`tests/spatial_index.rs` verify the query/index across wrap and lifecycle
changes.

## Decisions

Record the movement design in ADR-013. Keep the genome schema unchanged and
derive movement range (1..=4 steps) and vision (1..=8 cells) from normalized
speed. Perception uses the existing inclusive toroidal Chebyshev query. Pick
the nearest visible edible-kind organism (herbivore -> plant, carnivore ->
herbivore), tie-breaking by ID; approach with shortest wrapped directions but
do not feed/attack. With no such target, select one of eight neighboring
directions using the simulation RNG. Each actual displaced cell costs
`100 + speed / 256` energy; insufficient energy truncates the path. Allow
unrestricted sharing of cells; destination occupancy never blocks an animal.
Capture starting animal IDs and process in ascending order; later actors see
earlier moves. Every position mutation goes through the existing Simulation /
World move API.

## Ordered implementation and verification

1. Add `src/animal.rs` for pure speed-to-range, speed-to-vision, and movement
   cost helpers; export through `src/lib.rs`.
2. Implement sensing, edible target selection, shortest-path step generation,
   seeded wandering and exact energy-limited movement in the existing
   `AnimalMovement` section of `src/simulation.rs`.
3. Add helper and integration tests for trait endpoints; visible entities
   across each edge and inclusive radius; self-exclusion; target priority and
   ID ties; wrapped shortest movement; per-tick step limits; cost increasing
   with speed/distance; insufficient-energy truncation; deterministic seeded
   wandering; unrestricted shared cells; and spatial-index synchronization.
4. Run focused animal/movement tests, full `cargo test`, formatter and
   `git diff --check`; record actual results and update ADR-013, architecture,
   STATE, and the implementation handoff.

No system packages or Cargo dependencies are planned. No product code or tests
were run in PLAN. The speed correlation between vision and travel, sequential
same-tick visibility of earlier moves, and simplified local cost scale are
documented limitations, not new configuration requirements.

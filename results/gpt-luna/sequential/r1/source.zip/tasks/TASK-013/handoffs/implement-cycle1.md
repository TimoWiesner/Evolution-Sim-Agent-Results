# TASK-013 IMPLEMENT cycle 1

Implemented animal movement in `src/animal.rs` and the existing
AnimalMovement slot in `src/simulation.rs`. Speed maps to 1..=4 cell steps and
1..=8 inclusive toroidal Chebyshev vision cells. Herbivores select plants and
carnivores select herbivores, choosing by distance and then ID. Actors follow
the shortest wrapped path, or use a seeded eight-direction walk when no edible
target is visible. Actual cell displacements cost `100 + speed / 256` energy;
movement is truncated to the affordable prefix. Cells remain unrestricted for
sharing, and each move uses the index-maintaining World API.

Five focused animal tests cover mapping/cost boundaries, sensing across all
four edges and a corner, wrapped cardinal/diagonal approach, carnivore target
kind, distance/ID ordering, one- and four-step bounds, cost, low-energy
truncation, seeded wandering, and index state after movement and mortality.
The first focused compile attempt exposed a test privacy/import issue; the next
run exposed two incorrect expected boundary/index values. These were corrected
and the final focused test run passed. No system package or Cargo dependency
was added.

`cargo test` passed all 47 tests before the final test-only addition verifying
carnivore-to-herbivore target selection; the final five-test focused run
passed after that addition. Formatting and whitespace checks passed. The exact
commands and results are in `implement-cycle1.json`. No known acceptance gaps
remain; the simplified energy scale and speed-correlated vision are documented
in ADR-013.

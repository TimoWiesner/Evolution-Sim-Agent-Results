# TASK-008 PLAN cycle 1

Reviewed the task specification, current Rust engine and climate/world state,
TASK-005 dependency handoffs, project contract, architecture, state, decisions,
and PLAN skill. TASK-005 dependency review is PASS; no prior TASK-008 handoffs
were present. Product source currently has no organism types or lifecycle state.

Decision details and ordered implementation/test plan are in
`docs/decisions/ADR-010-organisms-lifecycle.md` and
`docs/ARCHITECTURE.md`. Use bounded integer traits and energy/health, an
ascending-ID ordered live arena, deterministic initialization, checked
monotonic IDs, per-kind counts, and mortality/finalize staging. The same-tick
rule is that deaths of existing organisms resolve in Mortality and pending
births become live only at Finalize; newborns cannot act or die in their birth
tick. This excludes behavior/genomes in line with task scope.

No source code was changed and no product tests were run. No system packages
or new dependencies are planned. Reinstall requirements: none.

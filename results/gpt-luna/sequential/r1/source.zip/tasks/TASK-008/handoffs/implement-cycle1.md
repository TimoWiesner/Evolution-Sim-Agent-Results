# TASK-008 IMPLEMENT cycle 1

Implemented organism types and bounded lifecycle state in `src/entity.rs`.
`World` now stores live organisms and pending births in ascending-ID maps,
allocates IDs monotonically, tracks per-kind initial/birth/death counters, and
records removed organisms with tick and cause. `Simulation::new` constructs
initial populations in stable Plant, Herbivore, Carnivore order using the
simulation RNG for cell positions. The lifecycle APIs queue births and deaths;
Mortality resolves deaths (first cause wins), then Finalize exposes pending
births. Existing organisms age once per tick; newborns remain age zero until
the following tick. Snapshot state includes organisms and lifecycle state.

Tests cover seeded initialization and ID/kind ordering, counters, bounds,
lineage metadata, death records/removal, first-cause semantics, newborn staging,
newborn exclusion from death requests, and non-reused IDs. No behavior,
genomes, or speciation were added. No system packages or new Cargo crates are
required. See the JSON handoff for exact commands and results.

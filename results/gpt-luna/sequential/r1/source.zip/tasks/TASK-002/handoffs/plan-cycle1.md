# TASK-002 PLAN cycle 1

## Scope and inspected context

The task is limited to establishing a runnable project skeleton and quality gates. Simulation behavior, `run`, `batch`, and `ui` are explicitly out of scope. The external contract requires root entry points, exact version JSON, top-level help, and unknown-command status 2. TASK-001 selected a Rust library/CLI and a local browser UI for later work. Its final review passed, including the architecture dependency boundary; its three cycle handoffs show no open findings. No TASK-002 or dependent-task handoffs exist yet. No product source tree currently exists.

## Decisions

- Use a root Cargo package with `src/main.rs` for dispatch, `src/lib.rs` for testable bootstrap behavior, and `tests/` for CLI integration coverage.
- Use the built-in Rust test harness. `cargo test` is the documented single command for the complete suite.
- Keep the bootstrap dependency-free. `setup.sh` checks for `rustc` and `cargo` and compiles the package; no system package installation is planned in the supplied Ubuntu/Rust environment.
- `evosim` resolves its own workspace location and launches the Cargo-built executable, independent of the caller's current directory.
- `build.sh` stages the release executable as `dist/evosim`. The initial binary needs only the host Ubuntu system ABI, not a Rust runtime. If later UI or data assets are runtime-loaded, embed or package them and verify operation outside the source tree.
- Ignore `target/` and `dist/` in `.gitignore`.
- Initial command surface is `version`, `--help`/`help`, and unknown-command error status 2. Do not implement task-owned future commands in this task.

## Ordered implementation and verification

1. Add `Cargo.toml`, minimal library and binary entry points, with no third-party dependencies.
2. Add `setup.sh`, `evosim`, and `build.sh`, all executable, plus `.gitignore` entries for build output.
3. Add `README.md` instructions for setup, build, and the single full-suite test command.
4. Add unit coverage and CLI integration tests for exact version JSON, help listing, and unknown command status 2.
5. Run `cargo test`, `./setup.sh`, `./evosim version`, `./evosim --help`, and an unknown-command status check.
6. Run `./build.sh`; invoke `dist/evosim version` from outside `/workspace`; inspect that `dist/evosim` is executable and `dist/` contains what it needs.
7. Run `git diff --check` and parse the task handoff JSON before phase completion.

## Risks and constraints

- A Rust executable is self-contained with respect to the Rust runtime but still targets the Ubuntu host ABI. This matches the specified Ubuntu 24.04 x86-64 distribution target; avoid dynamic non-system libraries.
- Scripts must derive paths from their own location so contract commands work from any current directory.
- Do not claim setup/build or packaging success until those commands run in implementation. No tests are run in this PLAN phase because no implementation exists.
- No apt dependencies are currently required. Any later system dependency must be recorded with its exact install command in `docs/STATE.md` and the relevant phase handoff.

## PLAN phase checks

- Read the mandatory project, contract, state, architecture, task and phase skill documents, all four architecture ADRs, and TASK-001 plan/implement/review cycle 3 handoffs.
- Confirmed TASK-002 has no previous handoff and the workspace currently has no product files.
- No product tests or runtime commands apply to this planning-only phase.

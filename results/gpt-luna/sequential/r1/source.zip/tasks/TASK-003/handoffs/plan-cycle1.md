# TASK-003 PLAN cycle 1

## Scope and inspected context

TASK-003 depends on completed TASK-002 bootstrap (Rust package, entry points, `cargo test`) and owns typed configuration plus presets. Its explicit exclusions are simulation use and `run` CLI behavior. The external contract requires `seed`, `world.width/height`, and all three `initial` counts; width and height are at least one, populations may be zero. TASK-001 architecture selects Rust, with the engine independent from CLI/UI. Prior TASK-002 plan/implementation/review handoffs and TASK-001 final planning/review handoffs were read; no TASK-003 handoffs exist. No dependent-task handoffs exist. `git remote -v` returned no entries.

## Decisions

- Add `serde` derive and `serde_json` dependencies for typed JSON parsing and complete serialization. JSON is the only required format.
- Require the fixed keys exactly as contract-defined. Add optional `climate`, `ecology`, and `genetics` groups with defaults for the group and every member.
- Reject unknown keys in all objects so typos are actionable.
- Use integer fields and fixed-point units for bounded settings; validate explicitly and return errors that name the offending dotted field.
- Expose a library preset constructor and ordered listing for `balanced`, `lush`, and `harsh`. Do not add CLI preset-selection behavior.
- Record exact types, units, defaults, bounds, and preset differences in `docs/decisions/ADR-005-configuration.md`.

## Ordered implementation and interfaces

1. Add `src/config.rs` containing public `Config`, `WorldConfig`, `InitialConfig`, `ClimateConfig`, `EcologyConfig`, and `GeneticsConfig`, plus `ConfigError`.
2. Provide `Config::from_json(&str) -> Result<Config, ConfigError>`, `Config::to_json(&self) -> Result<String, ConfigError>`, `Config::validate()`, `Config::preset(name: &str) -> Result<Config, ConfigError>`, and `Config::available_presets() -> &'static [&'static str]`.
3. Use required `seed: u64`; `world.width/height: u32` in 1..=4096; and `initial.*: u32` in 0..=1,000,000. Optional groups and fields default. Group fields, units and limits are enumerated in ADR-005.
4. Normalize parse/type/missing/range errors to include a field key/path, including nested keys where available. Add strict unknown-field rejection.
5. Presets share fixed-key defaults (seed 42, 64×48, 400/120/20); balanced retains all defaults, lush and harsh modify climate and ecology settings as detailed in ADR-005.
6. Export the module/types in `src/lib.rs`. Keep `src/main.rs` and `dispatch` unchanged for this task.
7. Add `tests/config.rs` tests for fixed-only input, zero populations, wrong type, missing each fixed key, out-of-range fixed and added values, unknown fields, defaults, full serialization round trip, and preset list/name/validity/meaningful differences.
8. Update `Cargo.toml`/`Cargo.lock`, and current architecture/state documentation after implementation. No system packages are expected.

## Verification plan

Implementation should run focused `cargo test --test config`, full `cargo test`, `./setup.sh`, existing version/help/unknown-command checks, `./build.sh`, and `git diff --check`; parse the implementation handoff JSON. This PLAN phase adds no behavior, so only documentation assertions, JSON/handoff validation, and whitespace checks apply here.

## Risks

- Serde's normal missing-field and type errors may not carry complete nested paths; tests must assert the required offending key is named.
- Applying defaults to all fields must not accidentally make contract-fixed keys optional.
- Chosen upper bounds are defensive limits beyond the contract minima and must be explicit in docs and error messages.
- Preset differences should be meaningful while staying within the same validation rules.
- No OS packages are planned. Dependency download/build is via Cargo; if implementation adds apt dependencies, record exact install commands in `docs/STATE.md` and the implementation handoff.

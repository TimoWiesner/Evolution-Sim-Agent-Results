# TASK-003 PLAN cycle 2

## Replan scope and finding

This is a replan after `tasks/TASK-003/handoffs/review-cycle1.json` returned
FAIL with gap `CFG-JSON-END`. The acceptance criteria, approved configuration
schema, presets, and TASK-003 scope remain unchanged. Review evidence states
that the focused and full suites passed, but the temporary probe showed
`Config::from_json` accepted a valid configuration followed by `{}`. The
current `src/config.rs` confirms the reason: `serde_path_to_error::deserialize`
returns one typed value, after which `validate()` runs, without checking the
underlying `serde_json::Deserializer` for end-of-input.

The dependent TASK-002 handoffs show the Rust bootstrap is complete and the
root launcher/package workflow exists. TASK-001 handoffs were inspected for
the architecture constraints; the library config API remains separate from
CLI dispatch and engine behavior. No downstream/dependent task handoffs exist
in the workspace. `git remote -v` returned no entries. No system package is
required or planned.

## Gap closure and decisions

- Require one complete JSON document in `Config::from_json`.
- Preserve the current typed/nested error mapping from
  `serde_path_to_error::deserialize`. Once that succeeds, call
  `serde_json::Deserializer::end()` on the same deserializer; map an error to
  a root-level `ConfigError` such as `configuration: ...`, since trailing data
  has no config field path.
- Keep legal JSON whitespace after the object accepted. Reject both an
  additional JSON value and trailing non-whitespace content.
- Add regression tests in `tests/config.rs`; do not alter the schema, presets,
  public API, CLI dispatch, simulation, or task specification.
- Update ADR-005, architecture plan, and `docs/STATE.md` to preserve this
  finding and ordered remediation for a fresh IMPLEMENT process.

## Ordered IMPLEMENT steps

1. In `src/config.rs::Config::from_json`, retain the mutable
   `serde_json::Deserializer`, deserialize through
   `serde_path_to_error`, then call `deserializer.end()` before validation.
   Convert the end check failure into `ConfigError` with a clear configuration
   context. Avoid changing existing nested type/missing-field messages.
2. In `tests/config.rs`, add a test using the fixed-only JSON fixture followed
   by a second object (e.g. `{}`) and assert rejection. Also append non-JSON
   trailing text and assert rejection. Assert that appending whitespace only
   still parses successfully. Keep tests independent of exact serde wording;
   assert failure and an actionable configuration context if consistently
   available.
3. Preserve all current behavior and run `cargo test --test config` followed
   by `cargo test`. Also run `./setup.sh`, existing CLI bootstrap checks,
   `./build.sh`, `git diff --check`, and validate the implementation handoff
   JSON. Record actual command outputs and package facts in the implementation
   handoff and update docs only as needed.

## Planned verification and current evidence

No implementation tests were run during this PLAN phase; no product code or
product tests were changed. The prior review handoff provides actual evidence:
`cargo test --test config` and `cargo test` both passed before the gap was
identified, and its probe demonstrated the trailing-value acceptance (probe
exit 101 was intentional after `unwrap_err()` observed unexpected success).
Planning documentation checks and this cycle's handoff validation are recorded
in `plan-cycle2.json`. No apt dependencies were added; Rust/Cargo crate
retrieval remains managed by Cargo.

## Risks and limits

- Checking the wrong deserializer or consuming it incorrectly could leave the
  bug open; the new tests must pass through the public `Config::from_json` API.
- Error conversion must not regress field-qualified parse errors or turn legal
  trailing whitespace into a failure.
- This cycle only plans the remediation. It does not claim the parser gap is
  fixed; implementation and review remain harness-controlled later phases.

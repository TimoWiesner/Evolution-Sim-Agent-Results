# TASK-005 PLAN cycle 1

## Scope and inspected context

This plan covers the clock, simulation-owned random stream, and tick scheduler
only. The task explicitly excludes climate, plant, and animal behavior. The
Rust project, config (`Config`), and toroidal `Grid` already exist. TASK-003
review cycle 2 and TASK-004 review cycle 2 both report PASS; their current
implementations provide the intended dependencies. No previous TASK-005
handoff exists, and no dependent task has a handoff yet. `git remote -v` showed
no entries. No system packages are required or planned.

## Decisions

See `docs/decisions/ADR-007-clock-rng-scheduler.md` for alternatives and
rationale. Preserve the earlier architecture decision to use `ChaCha8Rng`,
seed it deterministically from `Config.seed` using a fixed SplitMix64 expansion
to 32 bytes, and represent restorable position explicitly as seed bytes,
stream selector, and word position. Test restore using mixed-width reads to
catch buffering/position mistakes. Lock the chosen crate/API behavior with a
golden vector.

`Simulation` owns `tick: u64`, the generator, and a `World` that initially
wraps `Grid`. `step_one_tick` increments exactly once and reports the stable
phase sequence: Climate, PlantGrowth, AnimalMovement, Feeding, Reproduction,
Mortality, Finalize. These are scheduler slots only; do not implement their
ecological actions. Future actors run in ascending stable ID, ties resolve by
ascending ID then row-major cell order, and buffered creation/removal applies
in stable ID order at documented boundaries. Outcomes never depend on wall
time, UI, hash iteration, or a global RNG.

## Ordered implementation work

1. Add the locked `rand_chacha` and `rand_core` dependencies to
   `Cargo.toml`/`Cargo.lock`; record no OS dependency.
2. Implement `src/rng.rs` with deterministic seed expansion, `next_u32`,
   `next_u64`, `RngState`, export, and exact restore. Add unit tests for seed
   expansion/output vectors and continuation after mixed-width draws.
3. Add `src/world.rs` with a validated `Grid` wrapper; do not add entities or
   ecology.
4. Add `src/simulation.rs` with `Simulation::new(&Config)`,
   `step_one_tick() -> TickReport`, tick access, world access, and RNG snapshot.
   Represent phase/report order with vectors/enums, not unordered maps.
5. Export types from `src/lib.rs`; add `tests/simulation.rs` for exact tick
   increments, fixed phase order, same-seed identical 100+ tick traces,
   different-seed distinct traces, and RNG restore. Trace snapshots include
   RNG state; do not consume arbitrary random values in empty phases just to
   produce varying traces.
6. Run focused RNG/scheduler tests and `cargo test`; run `git diff --check` and
   validate the implementation handoff JSON. Report commands and outcomes.

## Risks and test intent

The main technical risk is exact ChaCha word-position restoration after
buffered reads; the mixed `u32`/`u64` continuation test addresses it. Document
seed byte order/constants and golden vectors. Keep the no-op status of phase
slots explicit so future phases add behavior without confusing the scheduler
frame for a complete simulation. Planning did not run product tests.

The next phase should implement only the ordered work above. Do not start
checkpoint, CLI, UI, or ecology work; the harness controls phase transitions.

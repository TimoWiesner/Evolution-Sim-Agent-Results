# TASK-015 IMPLEMENT cycle 1

Implemented the approved plan. `animal::hunting_chance_bp` applies the ADR-015
integer formula. The Feeding phase now invokes `hunt_herbivores` after herbivore
grazing. Hunters are captured and processed in ascending ID order; each picks
the nearest living, non-pending herbivore in toroidal radius one. A successful
attack queues predation before later hunters select prey, transfers no more
than prey energy or hunter capacity, and every hunter pays 500 energy. Zero
energy queues starvation.

Tests cover chance clamps and trait direction, a 100-seed kill/escape sweep,
toroidal adjacent targeting, no repeat consumption after predation, exact
predation death recording, bounded energy transfer, miss/no-prey costs and
zero-energy starvation. Existing AnimalMovement pursuit remains in place.

Verification:

- `cargo test animal::tests::hunting_chance_is_trait_sensitive_and_clamped -- --nocapture` — passed (1 test).
- `cargo test hunting_tests -- --nocapture` — passed (2 tests).
- `cargo test` — passed (56 tests total across all targets, no failures).
- `cargo fmt --all -- --check` — passed.
- `git diff --check` — passed.

Updated ADR-015 status and implementation notes in `docs/ARCHITECTURE.md` and
`docs/STATE.md`. No crates or system packages were added. No known acceptance
gaps remain.

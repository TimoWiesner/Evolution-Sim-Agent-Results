# TASK-015 PLAN cycle 1

## Findings

- `src/animal.rs` already provides speed-derived vision, nearest visible edible
  target selection, and herbivore foraging/maintenance helpers.
- `Simulation::step_one_tick` orders `AnimalMovement`, `Feeding`,
  `Reproduction`, `Mortality`, then `Finalize`. `feed_herbivores` currently
  processes stable ascending herbivore IDs and can be followed by a carnivore
  hunt routine in the same Feeding slot.
- `World::organisms_within` queries the toroidal spatial index and returns IDs
  in stable order. `World::is_pending_death` and `queue_death` support exclusion
  and exactly-once deferred predation. `set_organism_energy` bounds energy to
  `MAX_ENERGY`; mortality records first cause and removes each live organism
  once.
- Carnivores already move toward the nearest visible herbivore. No TASK-015
  handoffs existed at PLAN entry. TASK-013 and TASK-014 dependency plans,
  implementations and reviews were read; both reviews passed. No relevant
  implementation gap needs replanning.

## Decisions and implementation order

1. In `src/animal.rs`, add an integer attack-chance helper taking attacker
   strength/aggression and prey speed/risk. Use ADR-015's exact formula:
   `clamp(4000 + strength*3000/65535 + aggression*2500/65535 -
   speed*2500/65535 - risk*1500/65535, 1000, 9000)` basis points, with integer
   floor per term. Roll `rng.next_u32() % 10000`; success is draw < chance.
2. In `src/simulation.rs`, after `feed_herbivores()` in the existing Feeding
   slot, process the carnivore IDs captured at hunt-phase start in ascending
   order. For each, query radius one with `World::organisms_within`, exclude
   pending-death herbivores, and select nearest distance then lower ID. This
   allows attacks only at same/adjacent toroidal cells. Movement pursuit
   remains unchanged; no adjacent prey means no attack.
3. Permit at most one attack attempt per carnivore per tick. A miss leaves prey
   eligible for later carnivores; a success queues `DeathCause::Predation`
   before the next actor, making that prey unavailable to later hunters.
   Transfer `min(prey.energy, MAX_ENERGY - hunter.energy)` only on success.
4. Charge 500 energy for every carnivore each tick after its attack/no-target
   decision. Misses and no-prey turns pay the same cost. Queue starvation when
   the resulting energy is zero. Use existing first-cause deferred mortality;
   do not add global population checks or replenishment.
5. Update ADR-015, architecture, STATE and the implementation handoff with
   actual behavior and verification. No configuration, genome, checkpoint,
   dependency or system-package changes are planned.

## Acceptance-focused verification for IMPLEMENT

- Unit tests: attack chance lower and upper clamps; monotonic effect of hunter
  strength/aggression and prey speed/risk; deterministic chance for fixed
  traits.
- Integration tests: carnivores pursue visible herbivores through existing
  movement; attack is possible at same/adjacent toroidal cells and impossible
  beyond distance one; across a deterministic large fixture/seed sweep, assert
  at least one kill and one escape.
- Verify successful prey produces exactly one death record with
  `DeathCause::Predation`, is not consumed by a later carnivore, and the hunter
  gain is at most prey energy and remaining capacity. Verify miss energy cost,
  no-prey energy cost, and starvation at zero. Verify same-seed attack traces
  match.
- Run `cargo test animal::hunting_tests -- --nocapture`,
  `cargo test`, `cargo fmt --all -- --check`, and `git diff --check`; report
  actual command outputs and outcomes in the implementation handoff.

## Risks

- Sequential movement and hunts let later IDs observe changed positions and
  pending kills in the same tick. Stable IDs make these effects reproducible.
- Basis-point mappings, modulo roll, and fixed 500-energy cost are simplified
  ecological parameters; they are documented and must be locked by tests.
- A prey killed after herbivore Feeding may already have grazed this tick; this
  is a direct consequence of the documented scheduler order.

No product tests were run during PLAN. No system package installation is
required; existing Cargo dependencies are unchanged.

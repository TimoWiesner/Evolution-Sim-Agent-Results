# TASK-012 PLAN cycle 1

## Scope and findings

This task adds plant reproduction only. Existing `Simulation::step_one_tick`
contains a named Reproduction slot, but currently implements climate, plant
growth, aging and mortality before committing queued births. `Simulation` owns
the seeded RNG and exposes `child_genome_one`; `World` already stages births
with parent IDs/generation, maintains cell occupancy on birth/death/movement,
and owns bounded soil water. `Grid::wrap` and unique toroidal neighborhoods
provide wrap-aware geometry. The configured mutation probability and step are
already used by the one-parent genome helper. No TASK-012-local handoffs or
TASK-014 dependent handoffs exist yet. TASK-009 and TASK-011 implementation and
review handoffs report PASS and their acceptance tests passing.

## Decisions

- Asexual reproduction only, using the existing one-parent genome mutation
  helper. Pollination would add an unnecessary mate requirement for this task.
- Existing Reproduction phase; process the plant IDs alive at phase start in
  ascending order. At most one child attempt per plant per tick.
- Reproduce at energy >= 60,000, costing 20,000 energy only after successful
  queued insertion.
- Sample one nonzero offset in the square radius-two dispersal pattern with
  the simulation RNG; wrap it through `Grid::wrap`. A failed target is not
  retried. Failure consumes no energy and creates no child.
- Establishment needs positive soil water and fewer than four live-or-pending
  plants in the target cell. This is a local resource and crowding rule, never
  a global population rule.
- Child has `[Some(parent_id), None]`, checked parent generation + 1 and a
  mutated copy of the parent genome. Finalize makes it live at age zero.

Rationale and consequences are recorded in ADR-012. Implementation detail and
ordered steps are in `docs/ARCHITECTURE.md`.

## Planned implementation

1. Add a World helper for plant occupancy including pending births and an
   establishment eligibility query that includes local soil water/capacity.
2. Implement the Reproduction scheduler loop using stable plant IDs, seeded
   toroidal candidate offsets, configured genome mutation, queued birth and
   post-success energy deduction.
3. Add deterministic tests for threshold/cost, no cost on blocked attempts,
   occupancy/resource rejection, edge wrapping/distance, genome mutation and
   parent/generation metadata, one offspring per parent, delayed newborn
   activity, and zero plants remaining zero.
4. Run focused tests and full `cargo test`; run formatter and whitespace checks.
   Update ADR, architecture and STATE with results and exact commands.

No package/system dependencies or config changes are planned. A small chance
of a valid nearby site being missed is intentional under the one-candidate
choice; this models failed dispersal and bounds work.

## PLAN evidence

- Required `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` existence
  checked before reading.
- Read project brief, fixed interface contract, current state and architecture,
  TASK-012 spec/JSON, PLAN skill, dependency handoffs TASK-009/TASK-011 and
  ADR-004/010/011; inspected simulation/world/plant/entity/config interfaces.
- `git remote -v` returned no entries. No Git network operation was performed.
- Product tests were not run because this is PLAN and no product code changed.

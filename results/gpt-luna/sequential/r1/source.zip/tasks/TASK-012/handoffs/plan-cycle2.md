# TASK-012 PLAN cycle 2

## Replan and review-gap closure

This plan responds to review cycle 1 FAIL gaps TASK-012-R1-G1 and
TASK-012-R1-G2. The reproduction implementation is already in
`src/simulation.rs`; cycle 2 is limited to regression tests that directly prove
energy eligibility/accounting and failed-establishment behavior, plus accurate
documentation. No feature behavior change is planned unless a new assertion
shows the implementation violates the recorded policy.

## Findings from current code

`step_one_tick` advances climate and replenishes water, performs plant growth,
then considers plants for reproduction using post-growth energy. It skips
plants that will die from age or hostile climate, samples one seeded nonzero
offset, rejects a destination through `World::can_establish_plant`, and only
then mutates/queues a child; the 20,000 cost is applied only after queue success.
Mortality and Finalize follow, so committed offspring are age zero. The current
reproduction integration test uses lush growth, a high-energy parent and an
upper-bound energy assertion. The local establishment test checks the query
rather than driving a rejected reproduction attempt. Thus both review gaps are
valid even though code inspection matches intended behavior.

## Ordered implementation plan

1. Extend `plant_lifecycle_tests` in `src/simulation.rs` with an energy-policy
   integration test. Use one plant, no animals, benign climate, zero plant
   growth, a sufficiently long-lived plant and deterministic seed. At energy
   59,999, step once and assert no birth and exact unchanged energy. At
   60,000, use an open/wet sampled destination and assert one birth and exact
   post-step parent energy 40,000. This proves both the inclusive threshold
   and exactly 20,000 cost while excluding growth as a confounder. If configuration
   helpers cannot set growth to zero without unrelated consequences, assert
   expected post-growth energy immediately before accounting through a focused
   helper or use a controlled fixture; preserve an end-to-end tick assertion.
2. Add a blocked-attempt integration assertion using a fixed seed and a parent
   position selected from the known RNG candidate. Drain destination water (or
   fill the sampled cell to four live/pending plants) before stepping. Assert
   the parent met the threshold, no child was created, and parent energy is
   unchanged from its value after growth. Prefer zero growth to make that value
   exact; test resource rejection and/or capacity rejection end-to-end while
   retaining existing direct helper assertions for both constraints.
3. Keep the existing seeded inheritance, lineage, toroidal distance/seam,
   local-occupancy, newborn timing, and zero-plant tests. Avoid relying on an
   unseeded/random destination or asserting only an inequality for energy.
4. Run focused plant lifecycle tests and the full suite, then formatting and
   whitespace checks. Update ADR-012, `docs/ARCHITECTURE.md`, `docs/STATE.md`,
   and implementation handoff in the IMPLEMENT phase with exact evidence.

## Decisions and risks

No simulation policy changes: asexual one-parent reproduction; post-growth
threshold >=60,000; successful cost 20,000 only after staged queue success;
one radius-two nonzero toroidal candidate; local positive-water and fewer-than-
four live-plus-pending establishment constraints; Finalize birth timing.

The integration test must be deterministic and robust to climate advancement.
Disable weather and seasonal temperature variation, choose a benign climate
cell, and seed/position the candidate intentionally. If forcing a particular
destination by RNG state proves awkward, search a small fixed seed range in the
test and keep the selected seed explicit once identified; do not weaken the
assertion or rely on broad probabilistic success. No new packages, system
packages, config keys or dependencies are needed.

## PLAN evidence

- Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` before reading.
- Read the project brief, fixed contract, state and architecture, TASK-012 spec
  and task JSON, PLAN skill, cycle 1 plan/implementation/review handoffs,
  TASK-009 and TASK-011 implementation/review handoffs, and ADR-004/010/011/012.
- Inspected current reproduction and plant lifecycle code in
  `src/simulation.rs`, plant establishment in `src/world.rs`, test configuration
  and relevant architecture/state notes.
- `git remote -v` returned no output; no Git network operations were performed.
- No product tests were run in PLAN; no product code was changed.

# TASK-012 IMPLEMENT cycle 1

Implemented plant reproduction in the existing Reproduction scheduler slot. Plants are visited by stable ID after growth. A plant at 60,000 or more energy samples a nonzero offset in the radius-two square, with each axis drawn from -2 through 2 and the center rejected. The destination wraps through the toroidal grid. Establishment requires positive local soil water and fewer than four live plus pending plants. A successful queued child costs the parent 20,000 energy, carries a one-parent mutated genome, records parent ID and checked generation, and becomes live at Finalize.

Plants already due to die from lifespan or hostile climate do not reproduce that tick. This was added after the existing lifespan test showed that a doomed parent otherwise staged offspring immediately before mortality. The lifecycle integration fixture was also adjusted to set its intentionally dying plant's energy to zero, keeping that test focused on queued death/birth ordering.

Focused tests cover zero-plants persistence, mutation and lineage, toroidal radius and seam wrapping over fixed seeds, child age zero at birth, and water/crowding establishment rejection. The final full suite passes. Exact command results, including the initial failures and corrections, are in `implement-cycle1.json`. No system packages or dependencies were added.

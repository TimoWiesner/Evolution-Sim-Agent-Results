# TASK-017 PLAN cycle 1

## Inspected state

Verified required `/workspace/AGENTS.md` and `docs/STATE.md`, then read the
project brief, fixed interface contract, current state and architecture,
TASK-017 specification/metadata, and PLAN skill. Read relevant ADRs 004, 010,
012 and 016, plus the TASK-009, TASK-012 and TASK-016 plan/implementation/
review handoffs. TASK-009 review passed and provides `Genome::distance`
(absolute-difference sum across eight u16 loci); TASK-012 and TASK-016 handoffs
show plants and animals stage births for Finalize and retain parent IDs and
generation. TASK-016 review passed and uses the same 65,536 genome-distance
compatibility threshold.

Inspected `src/entity.rs`, `src/genome.rs`, `src/world.rs`, and the scheduler,
snapshot, initialization and birth APIs in `src/simulation.rs`. Organisms
currently have genomes and parent IDs but no species ID. World owns live
organisms in a BTreeMap, queues births/deaths, removes deaths in Mortality and
commits births in Finalize. `WorldClimateState` snapshots the entity vectors;
it will need species records and next ID. Initial organisms are created in
stable Plant/Herbivore/Carnivore order. No TASK-017 handoffs existed. `git
remote -v` produced no entries; no network Git actions were performed.

## Decisions

- Use fixed immutable founder representatives. Compare same-kind representative
  genomes using `Genome::distance`; a distance <=65,536 (mean normalized
  difference <=8,192) belongs to that species. Exactly at the threshold joins;
  one point beyond it creates a new species if no nearer representative passes.
- Assign once at initial organism creation or birth queue time. Find the
  nearest same-kind representative, breaking ties by species ID. If none
  qualifies, create a species. Never merge or reclassify existing organisms.
- Species records store kind, representative genome, parent species ID,
  `arose_at_tick`, and optional `extinct_at_tick`. A new species' ancestry
  points to the species of parent 1 if present, otherwise parent 2; initial
  founders have no parent species. This ancestry does not override genetic
  classification.
- IDs are globally monotonic from 1, allocated in deterministic creation
  order. Names are kind prefix plus six-digit padded global ID; padding does
  not truncate larger IDs. Initial species arise at tick 0; queued birth
  species use the current simulation tick.
- Reconcile extinction after death resolution and birth commit at end of
  Finalize. Set a missing extinction tick once, when a species has no live
  members. Count by kind only records without an extinction tick.
- Persist species ID on each organism and species records/allocator in world
  snapshot state for future canonical serialization. See ADR-017 for rationale
  and exact policy.

## Ordered implementation

1. Add species ID to `Organism` and define a species record/type and stable
   naming behavior in `src/entity.rs`; update construction and test fixtures.
2. Add ordered species storage and checked monotonic allocator to `World` in
   `src/world.rs`. Centralize species assignment: nearest same-kind founder
   genome by `Genome::distance`, tie by ID, inclusive threshold 65,536; else
   create with parent species ancestry and current tick.
3. Assign initial organisms during existing stable initialization and newborns
   in `queue_birth`, using parent organism species for lineage. Keep the record
   alive even after extinction; add a `living_species_count(kind)` query.
4. Reconcile extinctions at the end of `Finalize`, after mortality and births,
   to avoid incorrectly marking a species extinct on a tick when a queued child
   joins it. Include species records and next ID in `WorldClimateState` / the
   snapshot state.
5. Add focused entity/world tests and scheduler integration tests for initial
   assignment, kind partitioning, nearest/tie selection, exact threshold and
   over-threshold split, forced divergent offspring, deterministic IDs/names,
   ancestry, count queries and extinction timing after births/deaths.
6. Run focused species tests, `cargo test`, `cargo fmt --all -- --check`,
   `git diff --check`, and JSON handoff validation. Update ADR-017,
   `docs/ARCHITECTURE.md`, `docs/STATE.md`, and the implementation handoff with
   exact implementation evidence.

## Risks and tests

Founder representative assignment is intentionally order-dependent on first
creation, but the current creation order and organism IDs are stable; tests
must lock this order. A fixed representative model can permit descendants to
drift beyond their founder genome while retaining membership; this is the
chosen stable membership policy. Parent species ancestry and nearest-genome
classification can differ for cross-species offspring; both fields have
distinct meanings and need direct assertions. Extinction must be reconciled
after births commit, and never reversed. Since checkpoint serialization is not
yet implemented, snapshot coverage is the in-scope persistence contract; later
canonical checkpoint/hash code must include both organism species IDs and
species records/allocator. No product tests were run and no code was changed
in PLAN. No additional dependencies or system packages are planned.

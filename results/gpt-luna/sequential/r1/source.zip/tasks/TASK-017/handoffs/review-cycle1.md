# TASK-017 review cycle 1

Verdict: PASS.

I inspected the task specification, phase plan and implementation handoffs, ADR-017, and the implementation in `src/entity.rs`, `src/world.rs`, `src/simulation.rs`, and `src/lib.rs`. Organisms receive a same-kind species at initialization or birth staging. `World::assign_species` uses the immutable representative genome, inclusive distance threshold 65,536, nearest distance, then lower ID; it creates monotonic global IDs and kind-prefixed names when no living species qualifies. Births retain parent organism IDs and new species records use the first available parent's species as ancestry. Finalize commits births before `reconcile_species_extinctions`, which records the current tick; the query counts non-extinct records by kind. Snapshot state includes ordered records and the next ID.

The focused tests in `world.rs` exercise the tie and threshold boundaries, a forced split above threshold, ancestry and arose tick, snapshot contents, exact extinction tick, and living counts. The split assertion is made through the same assignment helper used by initial creation and birth staging. No acceptance gap was found.

Independent verification:

- `cargo test -q`: passed, 64 tests, 0 failures.
- `cargo fmt --all -- --check`: passed.
- `git diff --check`: passed.
- `python3 -m json.tool tasks/TASK-017/handoffs/implement-cycle1.json`: passed.
- `git remote -v`: empty.

No product-code or docs changes were necessary. Future checkpoint/hash work must include organism species identity and the species registry/allocator.

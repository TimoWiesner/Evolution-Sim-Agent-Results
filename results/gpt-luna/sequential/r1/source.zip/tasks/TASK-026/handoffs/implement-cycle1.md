# TASK-026 IMPLEMENT cycle 1

## Implementation

Added the fixed `benchmarks/performance.json` workload and harness-free release
benchmark `benches/simulation.rs`. It constructs the shared engine, warms 50
ticks, then measures 300 ticks and prints fixed seed, population samples,
elapsed time and ticks per second. Added `tests/performance.rs`, which warms a
2,000-plant setup for five ticks and enforces a 1 tick/s floor over 20 timed
ticks while checking population remains above 1,900.

Before optimization, three release runs measured 190.37, 194.93 and 194.90
ticks/s (median 194.90). The workload's 3,000 plants reached 12,307 after
warm-up and remained at least 10,412 at sampled points. `perf` and `valgrind`
were unavailable. Temporary per-phase timers, removed before final runs,
measured 350 ticks and attributed 54.7% of grouped phase time to reproduction
and 23.4% to mortality/finalization. Inspection found species reconciliation
scanned the entire population once per living species. Replaced this with one
pass into a transient `HashSet` and membership checks. No RNG, actor ordering,
state transitions or serialized state changes.

Three post-optimization runs measured 241.28, 241.34 and 239.86 ticks/s (median
241.28), a 23.8% median gain. Initial, warm-up, final, sampled minimum and mean
populations matched baseline. Host and full details are in
`docs/PERFORMANCE.md`; decisions and architecture/state summaries are in
ADR-026, `docs/ARCHITECTURE.md` and `docs/STATE.md`.

## Verification

- `cargo test --test performance`: passed (1 test, 4.61 s).
- `cargo test`: passed (83 passed, 1 ignored). Includes deterministic CLI,
  state-hash and checkpoint continuation tests; ecology took 46.28 s and
  simulation integration took 33.80 s.
- `cargo fmt --all -- --check`: passed.
- `git diff --check`: passed.
- `python3 -m json.tool benchmarks/performance.json >/dev/null`: passed.
- `python3 -m json.tool tasks/TASK-026/task.json >/dev/null`: passed.
- `git remote -v`: no remotes listed.

An initial benchmark compile caught a `usize` to `u64` conversion error in the
sample accumulator; explicit casts fixed it before any benchmark result was
reported. No system packages or crates were installed or added.

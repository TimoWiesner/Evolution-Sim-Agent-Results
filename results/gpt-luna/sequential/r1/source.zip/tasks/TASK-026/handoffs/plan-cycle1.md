# TASK-026 PLAN cycle 1

## Scope and inspected state

The task depends on the shared Rust engine, per-cell spatial index, headless
run/batch and metrics. `Simulation::step_one_tick` is the direct one-tick API;
`Simulation::new` performs initialization; `MetricsSample::capture` is read-only
but walks living organisms and death history. Current headless CLI timing wraps
only its own loop, but initializing via a CLI command also includes result
construction/reporting and does not provide a measured-window population
assertion. TASK-010's 2,000-organism spatial-query result is a debug microbench,
not a whole-tick throughput result. TASK-018's five-seed ecology report took
184.40 s for 50,000 ticks and animals went extinct early, so it is not a stable
dense multi-kind throughput fixture. Relevant dependency implementation
handoffs were read; TASK-026 has no prior handoffs. No system dependencies are
currently listed or needed. The local CPU reports AMD Ryzen 5 7500F, 6 cores /
12 threads, x86_64; `rustc 1.100.0`; `perf` is not present on PATH at planning
time. Workspace git status was clean at inspection; no remote check/network
operation was needed.

## Decisions and ordered implementation

1. Add `benchmarks/performance.json` using a fixed seed and a plant-only
   64x48 world initialized above 2,000. During implementation, validate that
   its living count stays near or above 2,000 after warm-up and during the
   measurement window; tune only the benchmark fixture/count/window if needed.
2. Add `benches/simulation.rs` with `harness = false` in Cargo.toml. Use public
   `Config::from_json` and `Simulation`, warm up a fixed number of ticks, then
   time a stated measured count with `Instant`. Print a clear machine-readable
   or stable text summary with fixed seed, warm-up, measured ticks, initial /
   final / sampled population, elapsed time and ticks per second. Use
   `cargo bench --bench simulation`; do not time CLI startup or JSON result
   serialization.
3. Record at least three baseline runs and a release profile before source
   optimization. Try `cargo flamegraph` / Linux perf sampling against the
   benchmark process. `perf` was not found during PLAN, so document and resolve
   tooling/access in IMPLEMENT; if unavailable, use temporary measurement
   instrumentation, remove it before final measurements and report the
   limitation honestly. No profiler dependency is selected yet.
4. Optimize the dominant profiled engine work with minimal changes. Preserve
   organism iteration order, RNG draws/order, phase order, state transitions,
   state hash contents and checkpoint serialization. Do not tune ecological
   behavior or introduce count-based mechanisms.
5. Add `tests/performance.rs` for a short deterministic ~2,000-organism,
   20-tick throughput guard. Start with a lower bound around 1 tick/second,
   validate overhead and choose a loose threshold that catches gross
   regressions without making routine tests brittle. Keep the multi-run report
   and profiler out of normal test execution.
6. Add `docs/PERFORMANCE.md` with host/container and toolchain, fixed config,
   exact command and counts, baseline/final repeated results, profile summary,
   optimization rationale and remaining bottleneck. Update ADR-026,
   `docs/ARCHITECTURE.md` and `docs/STATE.md` with implemented facts.
7. Verify the performance guard, all existing tests including determinism and
   checkpoints, repeat benchmark/profile, `cargo fmt --all -- --check`,
   `git diff --check`, and JSON handoff syntax. Report every exact command and
   outcome; install nothing without documenting its exact package command in
   STATE and reinstallation implications.

Planned files: `Cargo.toml`, `benchmarks/performance.json`,
`benches/simulation.rs`, `tests/performance.rs`, `docs/PERFORMANCE.md`,
`docs/decisions/ADR-026-performance.md`, `docs/ARCHITECTURE.md`, `docs/STATE.md`,
and TASK-026 phase-local handoffs.

## Risks

- Plants-only is a repeatable density fixture but does not measure a balanced
  food chain; disclose the workload. Population drift can invalidate density,
  so record counts throughout.
- `perf` is not installed in the current PATH and kernel profiler permissions
  are unknown. A profile remains an acceptance requirement; choose an
  available sampling or temporary phase-timing fallback and state its limits.
- CPU contention/frequency variation can make short timing guards flaky. Keep
  the guard short and loose; use a longer warm-up/window and repeated runs for
  the report.
- Reordering hot loops or caching derived data can change RNG consumption,
  lifecycle ordering, or checkpoint continuation. Preserve current semantics
  and retain the full deterministic/checkpoint suite.
- No benchmark result exists yet. Performance report values must be measured
  during implementation, not inferred from earlier spatial-index timings.

## PLAN verification

No product code or product tests were changed or run in this phase. Required
project/task/architecture and dependent handoffs were inspected. Documentation
and handoff syntax checks are recorded in `plan-cycle1.json`.

# TASK-021 PLAN cycle 1

## Implementation plan

1. In `src/cli.rs`, refactor the existing run execution path into a reusable
   internal function that accepts a fully validated `Config` and tick count,
   returns the same result DTO, and can write a selected path. Preserve run's
   current argument/error behavior and tick/sample/hash semantics.
2. Implement strict batch parsing for `--config`, `--seeds`, `--ticks`,
   `--out-dir`, one or more `--vary FIELD=VALUE,...`, and optional `--csv`.
   Parse unsigned values without narrowing first; support integer leaves
   `initial.plants`, `initial.herbivores`, `initial.carnivores`, `world.width`,
   `world.height`, and `ecology.resource_capacity`. Reject duplicate seeds or
   values, malformed/unknown paths, duplicate flags and empty lists.
3. Expand sweep dimensions in flag and value order, combine with seeds in
   input order, override the cloned config, and validate the complete matrix
   before running. Execute one simulation at a time. Preserve the required
   `seed-<seed>.json` naming when no multi-value/multi-field collision exists;
   add deterministic sanitized field/value suffixes when combinations need
   unique filenames.
4. Write ordinary TASK-019/TASK-020 result JSON to each per-run output. Build
   a typed ordered `summary.json` with each run's seed, parameter map, ticks,
   filename, final populations and extinct flags, then population mean/min/max
   and extinction count per kind. Do not include timing in the summary.
5. When `--csv` is present, write a deterministic header and one row per run
   after successful completion. Sort parameter columns by field path and use
   correct CSV quoting for filenames/values. Summary and CSV should be written
   only after all simulations succeed; already completed result files can
   remain after a later runtime/write failure.
6. Add small-world integration coverage in `tests/cli.rs` for two values × two
   seeds. Assert four distinct files, run-result compatibility, every summary
   row, hand-calculable aggregates/extinction counts, CSV output, invalid
   argument/config behavior, and identical summary values from two invocations.
   Keep the existing run regressions intact.
7. Update ADR-021 implementation record, README usage, architecture and state
   ledgers, then run focused batch/CLI tests, full `cargo test`, formatting,
   whitespace, setup/build, JSON validation, and remote checks. No system
   packages or crates are planned.

## Decisions and constraints

- Sweep syntax is repeated `--vary dotted.path=v1,v2`; multiple flags make a
  Cartesian product. The initial supported scalar leaves are those listed
  above. This keeps the batch interface concise and validation delegated to
  `Config`.
- Batch execution is sequential and preserves request order. Each seed and
  parameter tuple gets an independent simulation initialized from a cloned
  base config.
- The summary omits elapsed time/ticks-per-second, so the complete summary can
  compare identically across repeated batch invocations. Ordinary per-run JSON
  retains those measurements.
- Run result paths follow the contract for simple seeds. Parameterized
  matrices add stable names to prevent overwriting same-seed runs.
- Errors should return code 2 and stderr like `run`. Validate all arguments
  and candidate configs before opening outputs. The output directory must
  exist; no interactive prompts or directory creation are needed.

## Risks

- The current `run_inner` owns both execution and writing. Refactoring should
  preserve behavior without making batch result JSON diverge from ordinary
  `run` output.
- Config field widths vary (`u32` dimensions/counts and resource capacity), so
  parsed `u64` sweep values need checked conversion and config validation.
- Filename construction must remain deterministic and avoid path traversal.
- Runtime or disk failures after some runs may leave partial per-run files;
  summary/CSV should not imply completion in that case.
- Large Cartesian products can run for a long time. Keep tests tiny and ensure
  errors/validation happen before the first simulation.

## PLAN verification

No product tests were run in this planning phase. The phase checks below
validate documentation/handoff syntax and confirm the workspace has no remote.

# TASK-021 REVIEW cycle 1

## Review result: PASS

Independently reviewed the implementation against TASK-021, its plan and implementation handoffs, ADR-021, and the shared execution/result code. The implementation meets the acceptance criteria.

`batch` requires the configuration, seed list, tick count, an existing output directory, and at least one supported integer sweep. Parsing rejects repeated flags, empty/malformed lists, duplicate seeds or field values, unsupported fields, and values outside the target configuration width. It constructs and validates the complete seed/configuration matrix before running simulations. Matrix runs are sequential and each uses `execute`, also used by `run`.

Each matrix entry writes an ordinary contract result JSON. The summary stores ordered runs with seed, parameters, ticks, filename, final counts, and per-kind extinction flags. It computes mean, minimum, maximum, and extinct run count for plants, herbivores, and carnivores. The summary excludes timings. Optional CSV uses sorted parameter columns and the same row order, with CSV escaping. The integration test runs a two-value by two-seed matrix, checks its four outputs, summary equality across two invocations, population aggregates, and CSV equality.

No code or project documentation changes were needed during review. Known partial-output behavior on runtime or CSV write failures is documented in ADR-021 and the implementation handoff.

## Verification

- `cargo test --test cli -- --nocapture` — 8 passed, 0 failed.
- `cargo test` — 76 passed, 0 failed, 1 ignored; ecology tests 47.16 s and simulation integration tests 34.58 s.
- `cargo fmt --all -- --check` — passed.
- `git diff --check` — passed.
- `python3 -m json.tool tasks/TASK-021/handoffs/implement-cycle1.json >/dev/null` — passed.
- `git remote -v` — no remotes listed; no Git network operations were performed.

No review gaps remain. External harness checks remain authoritative.

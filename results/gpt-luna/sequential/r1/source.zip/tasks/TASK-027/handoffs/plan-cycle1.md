# TASK-027 PLAN cycle 1

## Scope and baseline-first rule

Implement only TASK-027. The first runnable measurement must use the unchanged
engine and the fixed-key example configuration from CONTRACT section 3. No
production ecology source, default or mechanism may change until its baseline
batch has completed and its first-extinction cause and all three population
curves have been analyzed and recorded in `docs/BALANCE.md`.

Prior TASK-018 measurements are context, not a substitute: seeds 1–5 lost
herbivores at ticks 32–46 and carnivores at 168–199 while plants survived to
10,000 ticks. The task requires a new batch baseline on at least ten seeds.

## Ordered implementation plan

1. Add `tasks/TASK-027/fixtures/default.json` containing exactly the fixed
   CONTRACT keys/values. Before changing engine code, run the required baseline
   using the current batch command and defaults: `./evosim batch --config
   tasks/TASK-027/fixtures/default.json --seeds
   1,2,3,4,5,6,7,8,9,10 --ticks 10000 --out-dir
   results/TASK-027/baseline-batch`. Preserve its generated summary and files
   locally through analysis; do not tune defaults or ecology behavior first.
2. The current batch default samples at roughly 100 intervals and cannot report
   the exact first-zero tick. Supplement the batch baseline, still before any
   ecology change, with ten `./evosim run` commands for the same config/seeds
   and `--sample-every 1`. These sampled results provide exact extinction ticks,
   per-kind deaths by cause, and full population curves while the required batch
   remains the baseline measurement. Large per-tick result files can be removed
   after extracting compact findings for `docs/BALANCE.md`.
3. Analyze the first kind to reach zero per seed, exact tick, per-kind
   `deaths_by_cause`, and all three `series` curves. Report the first-extinction
   cause using the recorded death-cause totals and timing, then write the
   findings, command, seed table, and baseline curve summaries in
   `docs/BALANCE.md` before editing any ecological mechanism. Validate each
   selected first-zero tick against adjacent samples/population monotonicity.
4. Choose one local, population-count-independent behavior that addresses the
   measured limiting cause. The leading candidate to investigate is animal
   mate discovery: currently compatible adults must be within toroidal
   Chebyshev distance 1. If baseline births/compatibility and deaths support
   encounter limitation, change this to a bounded local distance 2 and add
   deterministic tests for distance-2 mating, toroidal seams, and no birth
   outside the bound. If the baseline instead identifies another dominant
   local cause, document the evidence and choose one mechanism at the closest
   owner (`src/animal.rs`, `src/plant.rs`, or `src/simulation.rs`) before
   implementation. Never use global population/species counts, protection,
   forced births or stored as a balancing switch. Document the selected
   formula, expected response, tradeoffs and alternatives in ADR-027.
5. Record every trial in `docs/BALANCE.md` with the code/parameter change,
   expected effect, command/seeds/duration, actual coexistence duration,
   first-extinction kind/tick/cause, population curve observations and
   throughput. Keep tuning seeds 1–10. Run a compact fixed-seed/shorter trial
   first where useful; run full 10,000-tick batches when comparing material
   candidate changes. Include trials that regress or do not help. Stop after
   the best evidence-supported natural mechanism is selected; no minimum
   coexistence duration is an acceptance condition.
6. Measure the selected defaults on held-out seeds 11–15 for 10,000 ticks
   using the same fixed-key config, `--sample-every 1`, and batch schema. Do not
   tune from these outcomes; record per-kind extinction/survival, coexistence
   duration, causes and curves separately from tuning trials.
7. Rerun `cargo bench --bench simulation` for the selected defaults, comparing
   with TASK-026's 241.28 ticks/s recorded median (note that this bench is
   plant-heavy and does not represent the mixed food chain). Add deterministic
   focused mechanism regression coverage, then run relevant focused tests,
   `cargo test`, formatting, `git diff --check`, `./setup.sh`, and inspect
   deterministic/checkpoint/ecology regressions. Update `docs/STATE.md`,
   `docs/ARCHITECTURE.md`, ADR-027, and `docs/BALANCE.md`; record exact evidence
   in the implementation handoff. No system package or new crate is expected.

## Decisions and risks

- Exact extinction ticks require interval-1 samples; the existing `run`
  command provides this without altering batch or engine behavior. This keeps
  the required batch baseline truly first, before code changes.
- Metrics capture scans living organisms and accumulated death history. At
  interval 1 this may increase report time significantly and result files can
  be large. Measure under the 60-minute phase limit and remove bulky result
  files after extracting the compact findings.
- Mate-search radius 2 is only a candidate, not a precommitted change. The
  baseline diagnosis must come first. Any chosen mechanic must affect each
  organism under the same local conditions at every population size.
- Stochastic runs can show a poor or noisy outcome. Report it honestly; the
  acceptance criteria require measurement and a measured mechanism trial,
  not guaranteed coexistence.
- Results are local and can be regenerated from the checked-in fixture and
  commands; avoid checking in ten large per-tick JSON files.

## Verification in PLAN

No tests or simulation commands were run: planning phase only. Required source
and handoff documents were inspected. Current worktree state was inspected
before adding this plan; no implementation or tests were changed/run.

# TASK-027 IMPLEMENT cycle 1

Implemented a natural, local carnivore handling interval after confirming the
unchanged baseline first. Baseline batch seeds 1–10 used the contract's fixed
configuration for 10,000 ticks. Every seed first lost herbivores at ticks
32–96; each of the initial 120 herbivores died by predation with no births.
Carnivores later died by starvation. Plants persisted and reached their local
occupancy ceiling. The full cause analysis and curves are in `docs/BALANCE.md`.

Carnivores now receive a 20-tick `hunting_cooldown` after a successful kill.
The next 20 Feeding passes do not allow an attack, but each pass still applies
the existing 500-energy cost. Misses and prey-free passes do not start a
cooldown. The state is serialized and hashed, and old organism JSON defaults
the field to zero. No global population counts, forced reproduction or energy
sources were added.

On tuning seeds 1–10, first herbivore extinction moved to ticks 174–229 (mean
195.3 versus baseline 52.7); all populations except plants were extinct by
10,000 ticks. Only two runs had herbivore births. On held-out seeds 11–15,
herbivores reached zero at ticks 155–245 and carnivores at ticks 261–386;
plants survived to 10,000 ticks. The goal of all-three-kind coexistence was not
reached and is stated openly in `docs/BALANCE.md`.

The repeated `cargo bench --bench simulation` final run measured 239.00 ticks/s
versus TASK-026's 241.28 ticks/s median, above the 100 ticks/s target. Full
`cargo test` passed (84 passed, 1 ignored). `./setup.sh`, formatting and
whitespace checks passed. No system packages, Cargo crates or Git remotes were
added. Trial result files were removed after the measured data and curve
summaries were recorded.

The contract-valid batch command without `--vary` currently exits 2 with
`missing --vary`; the no-op single-value argument `--vary initial.plants=400`
was used for the required unchanged baseline, trial and held-out batches. This
limitation is also recorded in `docs/BALANCE.md`.

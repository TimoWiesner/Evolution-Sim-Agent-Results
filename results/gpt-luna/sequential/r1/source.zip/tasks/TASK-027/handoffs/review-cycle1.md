# TASK-027 REVIEW cycle 1

## Verdict: PASS

Reviewed TASK-027 acceptance criteria against the implementation, measurement report, ADR, architecture/state notes, and dependent TASK-018/020/021/022/025/026 review handoffs. The cycle-1 implementation changed only the local carnivore handling mechanism and associated state/documentation. `git status --short` and `git diff --stat` were empty at review start; the implementation had already been persisted by the orchestrator.

The documented baseline uses the fixed-key 64x48, 400/120/20 configuration and seeds 1–10 for 10,000 ticks before the source change. The `docs/BALANCE.md` report records per-seed first extinction, causes, secondary carnivore extinction, and sampled population curves. The report also gives the measured first-extinction diagnosis: herbivores were first to disappear, all baseline herbivore deaths were predation, and plants were abundant. It records the mechanism trial and held-out seeds 11–15, their failures to sustain all three kinds, and a repeat TASK-026 benchmark. The outcome is stated honestly; coexistence is not claimed.

The code applies a serialized 20-pass cooldown only after a successful kill, blocks attacks while it is positive, and continues the 500-energy feeding cost. It consults no population count and adds no births or energy source. The unit tests cover starting and decrementing handling, continued maintenance, successful kill behavior, toroidal targeting, and energy bounds. Existing checkpoint continuation and seeded-repeatability tests remain in the suite.

One pre-existing interface discrepancy remains visible: `src/cli.rs` rejects `./evosim batch` without `--vary`, although the contract's batch syntax makes `--vary` optional. The implementation report disclosed this and ran the exact fixed configuration with the no-op `--vary initial.plants=400`. This does not invalidate TASK-027's baseline or measurement criteria, so it is recorded as a residual risk rather than a TASK-027 review gap.

## Independent verification

- `cargo test`: passed independently, 84 passed, 1 ignored, 0 failed. Ecology tests took 47.69 seconds, the dense performance floor passed in 4.59 seconds, and simulation integrations passed in 40.89 seconds.
- `git remote -v`: no remotes listed.
- The required `--vary` behavior was confirmed by inspecting `src/cli.rs` (empty `varies` returns `missing --vary`). No product code or docs required changes during review.

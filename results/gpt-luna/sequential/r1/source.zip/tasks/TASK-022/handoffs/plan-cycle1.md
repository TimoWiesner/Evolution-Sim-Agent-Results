# TASK-022 PLAN cycle 1

## Findings

- TASK-022 had no prior handoffs on entry. All four declared dependency tasks
  (TASK-005, TASK-007, TASK-017, TASK-019) have review-cycle1 handoffs recording
  PASS; their plans, implementations, and reviews were inspected. No dependency
  remediation is pending for this task.
- `Simulation::canonical_state_json` already serializes a versioned canonical
  DTO with config, tick, dimensions, RNG state, and `WorldClimateState`. That
  world DTO captures base/current climate, weather, soil water/capacity,
  organisms/genomes, pending births/deaths, death history, lifecycle totals,
  species records, and allocators/current tick. Spatial index is derived.
- `DeterministicRng::from_state` restores ChaCha8 continuation. However,
  `Simulation` fields and `World` construction are private and no restore path
  or checkpoint CLI path exists. `WorldClimateState` currently derives only
  `Serialize`, so typed deserialization support and validation are needed.
- Existing run CLI requires `--config`, initializes a fresh simulation, and
  reports start tick zero. It parses only config/out/ticks/seed/sample flags.
  Result `totals` already use cumulative world lifecycle counters.

## Decisions and implementation sequence

1. Use uncompressed UTF-8 JSON. Introduce an explicit checkpoint envelope
   version, independent of canonical hash version. Reuse explicit state DTO
   fields and stable ordered vectors; avoid opaque serialization of private
   engine structs.
2. Add `Deserialize` support for checkpoint DTO components as needed. In
   `src/world.rs`, restore serialized world values into a validated `World`
   and rebuild its derived `SpatialIndex` from dimensions and live organisms.
   Validate vector sizes, all cell/entity coordinates, resource bounds,
   monotonic next IDs, lifecycle accounting, species references/extinction
   state, and current-tick agreement. Reject rather than normalize corrupt
   state.
3. In `src/simulation.rs`, add a restore constructor taking validated config,
   absolute tick, `RngState`, and world state. It must not call `Simulation::new`
   or consume initialization RNG draws. The config in the checkpoint remains
   the effective config for future behavior.
4. In `src/cli.rs`, accept exactly one of `--config FILE` or `--load FILE`,
   permit seed override only with config, and add `--save FILE`. Save the full
   final state after a successful run. For loaded runs report checkpoint tick
   as `tick_start`; preserve cumulative births/deaths and absolute tick end.
   Validate inputs before writing any output; malformed checkpoints return 2
   and leave `--out` absent.
5. Add `tests/cli.rs` coverage for save/load equivalence with split points
   including A=0 and two nonzero split locations; compare `state_hash`, final
   populations/species, and totals to an uninterrupted A+B run. Add missing,
   invalid JSON, truncated, wrong-version, and invalid-state tests asserting
   exit 2 and no result file; verify checkpoint format version and roundtrip.
   Add focused engine validation tests for restored invariants.
6. Run focused tests, full `cargo test`, `cargo fmt --all -- --check`,
   `git diff --check`, and JSON validation of handoffs. No new crates or system
   packages are planned.

## Risks

- Duplicating the canonical-state layout for checkpoints can cause fields to
  drift. Prefer shared serializable DTOs or a single canonical DTO embedded in
  the envelope while keeping checkpoint version explicit.
- `WorldClimateState` is currently a snapshot projection, not a directly
  validated constructor input. A careless restore can omit hidden state or
  create a spatial index inconsistent with organism positions.
- Reusing the config parser's validation alone is insufficient: checkpoint
  structural/state validation must also guard dimensions, lengths, IDs,
  counters, positions, and resource capacity before constructing the engine.
- Existing checkpoint/result output uses ordinary file writes. Ensure the
  checkpoint is not written on failed simulation or serialization and the
  result file remains absent on invalid load.
- JSON checkpoints can be large because death history is cumulative; no
  compression is planned unless measured size becomes an actual constraint.

## Verification record

Planning only; no product tests were run. Commands and document checks are in
`plan-cycle1.json`.

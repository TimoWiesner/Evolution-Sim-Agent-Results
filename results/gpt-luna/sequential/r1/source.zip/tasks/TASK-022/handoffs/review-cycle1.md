# TASK-022 REVIEW cycle 1

## Findings

The implementation meets all five acceptance criteria. The `run` CLI enforces
exactly one of `--config` and `--load`, applies seed overrides only to fresh
runs, and supports `--save`. Checkpoints use an explicit format version and
carry the validated effective configuration, absolute tick, exported RNG
continuation, and complete world state including climate/weather, resources,
organisms/genomes, pending lifecycle data, cumulative counters, death history,
and species state.

Restore validates configuration and RNG seed, clock agreement, climate and
weather consistency, grid vector lengths, resource bounds, organism IDs,
positions and traits, species references/extinction state, lifecycle totals,
and death history before constructing the resumed simulation. It restores RNG
without initialization draws and rebuilds the derived spatial index.

CLI integration coverage compares resumed and uninterrupted final counts,
totals, and state hash at save splits 0, 5, and 13. Error cases cover missing,
damaged, truncated, unsupported-version, and inconsistent-clock checkpoints;
each asserts exit status 2 and no result output. Dependency review records
PASS for TASK-005, TASK-007, TASK-017, and TASK-019.

## Verification

- `cargo test --test cli checkpoint -- --nocapture`: 2 passed.
- `cargo test`: 78 passed, 1 ignored, 0 failed.
- `cargo fmt --all -- --check`: passed.
- `git diff --check`: passed.
- `git remote -v`: empty.

No product changes were needed during review. The only noted operational risk is
that uncompressed JSON size grows with the cumulative death history, as already
documented in ADR-022.

## Verdict

PASS; no gaps.

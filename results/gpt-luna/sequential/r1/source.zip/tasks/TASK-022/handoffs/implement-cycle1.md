# TASK-022 IMPLEMENT cycle 1

Implemented version 1 uncompressed JSON checkpoints for `evosim run`. The
checkpoint carries the effective config, absolute tick, exported ChaCha RNG
position, and complete serialized world projection. Restore validates the
envelope/version, config and RNG seed, clock agreement, climate against grid
and weather, vector sizes and resource bounds, organism traits/positions/IDs,
species references/extinction state, allocator ordering, and lifecycle/death
history. It restores without initialization draws and rebuilds the derived
spatial index.

CLI accepts exactly one of `--config` and `--load`, restricts `--seed` to a
fresh config run, and writes a final state with `--save`. Loaded result series
start at the absolute checkpoint tick and totals remain cumulative. Invalid
checkpoint inputs are rejected before result output.

CLI integration tests compare save/resume with uninterrupted simulation at
splits 0, 5 and 13, including state hash, final counts/species and totals.
Negative cases cover missing, damaged, truncated, wrong-version, and
clock-inconsistent checkpoints, each with status 2 and no result file. Full
`cargo test` completed successfully: 78 passed and 1 existing ecology test was
ignored. Formatting and whitespace checks passed. `./setup.sh` rebuilt the
release launcher and a root-launcher save/load smoke check passed. No crates or
system packages were added.

The first direct launcher smoke attempt encountered the repository's existing
stale release binary; rebuilding with `./setup.sh` resolved it. The attempted
demo config path was absent, so the launcher smoke used an equivalent local
config file instead.

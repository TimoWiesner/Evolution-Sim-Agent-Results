# TASK-011 IMPLEMENT cycle 1

Implemented a bounded, row-major soil-water pool in `World`. The pool starts
at `ecology.resource_capacity`, refills once per tick from current
precipitation up to capacity, and is captured in `WorldClimateState` snapshots.
Plants grow in ascending ID order using integer fixed-point temperature,
precipitation, configured-growth, and genome-fertility factors. Growth is
rounded to 100-energy quanta; exactly one soil-water unit funds each quantum.
No water is used when the plant is already energy-full.

After plant growth, existing entities age once and queued deaths resolve at the
existing Mortality boundary. Plants die at genome lifespan, at zero energy, or
under hostile climate via `DeathCause::Age`, `Starvation`, or `Climate`.
Reproduction and grazing were not added. ADR-011, architecture, and state docs
now describe the implemented formulas, limits, and energy source.

Verification:

- `cargo test plant_lifecycle_tests -- --nocapture` — exit 0; lifespan and
  hostile-climate mortality passed.
- `cargo test` — exit 0; 38 tests passed across library, CLI, config,
  simulation, and spatial-index suites; doc tests passed (0 tests).
- `cargo fmt --all -- --check` — exit 0.
- `git diff --check` — exit 0.

The initial full suite run failed because the new test expected precipitation
replenishment to remain after a plant consumed the one available resource unit.
The test was corrected to assert the deterministic consumption and starvation
of the competing plant; the final suite passes. No system dependencies or new
Cargo dependencies were added. Complete checkpoint/state-hash serialization
must include the resource vector when those interfaces are implemented.

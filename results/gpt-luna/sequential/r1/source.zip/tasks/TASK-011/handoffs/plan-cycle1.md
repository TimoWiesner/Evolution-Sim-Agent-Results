# TASK-011 PLAN cycle 1

## Scope and current interfaces

Implement plant growth/resource use and plant age, energy, and hostile-climate
mortality only. Do not add plant reproduction (TASK-012) or grazing (TASK-014).
The current engine provides `World::current_climate(Cell)`, ordered live
organisms, `World::organisms_within`, `Organism::energy/set_energy`, genome
derived `Traits`, `DeathCause`, `Simulation::queue_death`, and a fixed tick
phase list. `Simulation::step_one_tick` currently advances climate, ages live
organisms, resolves deaths, and finalizes births, while its ecology phases are
still scheduler slots. Implementer must move age advancement to its documented
phase position if needed so newly scheduled age death sees age incremented
exactly once and the plant growth system observes a clear tick order.

## Decisions

See `docs/decisions/ADR-011-plant-growth-resources.md`. Use a per-cell soil
water pool (`Vec<u32>` row-major in `World`), capacity from the existing
`EcologyConfig.resource_capacity`, initial value at capacity, precipitation
replenishment per tick, and consumption to support sunlight-powered plant
energy growth at 100 energy per water unit. This is a simplified soil-water
limitation on photosynthesis: sunlight is the energy source, precipitation
replenishes available water, and no plant energy may be granted without a
matching pool deduction. Growth uses existing configured maximum
growth permille, normalized genome fertility, current temperature and current
precipitation. Integer/fixed-point functions avoid introducing stochastic
draws or platform-dependent outcome changes.

Per-tick update order: Climate; in PlantGrowth, replenish each cell once, then
process plants by ascending ID, calculate available gain and deduct consumed
resource; age existing organisms once (place this before mortality and ensure
it does not increment newborns); schedule plant age/starvation/climate deaths;
then preserve the existing Mortality removal and Finalize birth boundaries.
If implementation keeps age advancement centralized, age-death checks must
use the incremented age and plants must be processed only once. The first death
cause rule in TASK-008 remains in force.

## Ordered implementation work

1. Add pure plant growth helpers in `src/plant.rs` with explicit integer
   formulas for temperature suitability, precipitation suitability, fertility
   scaling, potential energy gain, resource consumption, and hostile-climate
   predicate. Export only the API needed by simulation/tests from `src/lib.rs`.
2. Extend `World` in `src/world.rs` with a row-major water pool initialized to
   the resource cap; provide checked cell query/access and a deterministic
   PlantGrowth update that replenishes up to cap. Include resource state in
   `WorldClimateState`/`SimulationSnapshot` if that type is the current complete
   snapshot surface. Ensure cloned worlds preserve the pool.
3. Retain `EcologyConfig` in `Simulation`, then implement the PlantGrowth phase
   in `src/simulation.rs`: replenish once, traverse plants by stable ID, read
   current climate and fertility, grant only the energy funded by cell water,
   deduct resource, and queue `Age`, `Starvation`, or a dedicated `Climate`
   death cause through
   existing APIs. Maintain deterministic ID order and no new RNG draws.
4. Add unit tests for temperature suitability bounds and peak, water scaling,
   fertility zero/maximum behavior, resource conversion/capping, and climate
   hostility thresholds in `src/plant.rs`.
5. Add integration tests in `tests/simulation.rs` for equal plants in favorable
   vs too-cold and too-dry climates; same-cell plants competing for a bounded
   pool in stable ID order; resource caps and reductions; no gain without a
   deduction; energy cap; fertility affecting gain; age, starvation and climate
   mortality; deterministic same-seed traces and unchanged RNG state from this
   deterministic phase; and zero initial plants remain zero. Tests should set
   energy/genomes/resources directly through narrow test/public APIs as needed,
   without exposing mutable internals unnecessarily.
6. Update ADR-011, `docs/ARCHITECTURE.md`, and `docs/STATE.md` with final
   implementation behavior and exact test evidence. Run `cargo test` (plus
   focused plant tests), `cargo fmt --all -- --check`, and `git diff --check`.
   No long simulation benchmark is needed; no apt package or new crate is
   planned.

## Risks and constraints

- The initial pool full-at-cap is a one-time starting environmental condition;
  long-term supply is precipitation-limited. Keep this explicit so a reviewer
  can distinguish initial stock from unbounded energy creation.
- The configured default growth permille could exhaust initial pools quickly;
  tune only if local behavior/math tests reveal an incoherent conversion, and
  document any change to ADR-011 before implementation evidence is claimed.
- Existing `age_live` currently occurs after climate but outside the named
  scheduler body. The implementation must make phase timing explicit without
  breaking the TASK-008 rule that newborns start at age zero and cannot act in
  their birth tick.
- Add a dedicated `Climate` death cause to `src/entity.rs`; update exhaustive
  matches and death-cause tests so the reason remains observable.
- Soil-water state must be included in future full checkpoints/state hashes;
  current snapshots are not yet the contract's full checkpoint format.
- No dependent implementation/review handoffs exist yet for TASK-012 or
  TASK-014. Their specs were inspected: TASK-012 will need a read-only resource
  availability check for establishment; TASK-014 will need plant energy
  mutation access while keeping resource use and plant death accounting
  consistent. Keep those future APIs narrow and avoid implementing either task
  here.

# TASK-018 IMPLEMENT cycle 2

## Changes

Closed REVIEW cycle 1 gap GAP-018-R1 by replacing the abundant-herbivore test's
8x8, 40-plant, maximum-growth, zero-mutation setup with the fixed-key default
64x48 world and 400 plants. The test asserts climate, ecology, and genetics
match the `balanced` preset defaults. Only the seed and zero initial animal
counts differ from fixed-key JSON. Two compatible high-fertility herbivore
test founders are queued at the same cell; normal climate, growth, mutation,
movement, feeding, reproduction, and mortality run for 300 ticks. Every tick
checks per-kind lifecycle accounting and permanent extinction. The final
assertions verify plants remained, herbivores survived, and at least one
herbivore birth occurred.

No production behavior, parameters, dependencies, or system packages changed.
No system dependency installation is required. Existing tick order and the
previous five-seed measurement remain valid because runtime behavior did not
change.

## Verification

- `cargo test --test ecology abundant_plants_support_herbivore_survival_and_reproduction -- --nocapture` — exit 0; 1 passed in 47.01 s.
- `cargo test --test ecology -- --nocapture` — exit 0; 5 passed, 1 ignored, 0 failed in 47.38 s.
- `cargo test` — exit 0; 69 passed, 1 ignored, 0 failed. Ecology integration took 47.38 s; simulation integration took 34.28 s.
- `cargo fmt --all -- --check && git diff --check && git remote -v` — exit 0; formatting and whitespace checks passed; no remotes listed.
- `python3 -m json.tool tasks/TASK-018/handoffs/implement-cycle2.json` — validated after writing.

## Follow-up

GAP-018-R1 is addressed by evidence under default climate/ecology/genetics
settings. The controlled founders isolate genetic compatibility; this is a
mechanism test and does not claim randomly initialized default animals will
reproduce or that all kinds coexist. Continue only when the harness starts the
TASK-018 REVIEW phase.

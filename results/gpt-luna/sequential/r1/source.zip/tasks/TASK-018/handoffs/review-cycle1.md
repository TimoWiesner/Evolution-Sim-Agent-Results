# TASK-018 REVIEW cycle 1

## Verdict

FAIL. The scheduler and extinction/accounting scenarios are implemented and
the reported five-seed run is documented, but the herbivore default-parameter
acceptance criterion is not demonstrated by the current integration test.

## Review findings

- `Simulation::step_one_tick` follows the documented order: climate/weather
  and soil water, plant growth, animal movement, herbivore grazing, carnivore
  hunting, plant then animal reproduction, aging/mortality, birth finalization,
  and species extinction reconciliation. Its public phase trace is asserted.
- The fixed-key configuration advances 1,000 ticks. Scenario tests assert
  per-kind lifecycle accounting every tick, permanent extinction after zero,
  no-plants herbivore-before-carnivore extinction, no-herbivore carnivore
  extinction, and plants-only persistence and births.
- The long-run test reports first extinction ticks (or `survived`) for all
  kinds in five fixed-key seeds over 10,000 ticks. The implementation report
  gives plants surviving all five, herbivores extinct at 46, 46, 39, 32, 40,
  carnivores at 199, 170, 191, 180, 168.
- **GAP-018-R1:** `abundant_plants_support_herbivore_survival_and_reproduction`
  changes `genetics.mutation_probability_bp` from its default 250 to 0 and
  `ecology.plant_growth_per_tick_permille` from its default 35 to 1000. The
  task requires herbivore survival and reproduction with plenty of plants
  under default parameters. Staging compatible founders is acceptable for a
  deterministic mechanism test, but the changed mutation and growth settings
  mean this test does not establish that requirement. Add a test retaining
  every default ecology/genetics value while providing abundant plants and
  compatible founders, or tune generally applied defaults and document the
  rationale; then rerun the extinction and lifecycle regressions.

## Verification

- `cargo test --test ecology -- --nocapture` — exit 0; 5 passed, 1 ignored,
  0 failed (47.46 seconds).
- `cargo test` — exit 0; 69 passed, 1 ignored, 0 failed; ecology suite took
  47.43 seconds and simulation integration suite 34.26 seconds.
- `cargo fmt --all -- --check && git diff --check && python3 -m json.tool /workspace/tasks/TASK-018/handoffs/implement-cycle1.json >/dev/null && git remote -v`
  — exit 0; formatting, whitespace, implementation JSON validation passed;
  no remotes were listed.
- The explicit command
  `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`
  is documented as having passed during IMPLEMENT (184.40 seconds). It was
  not rerun during this review.

No product code or architecture decisions were changed during review.

# TASK-018 PLAN cycle 1

## Inspection and baseline

- Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` exist.
- Read the project brief, binding interface contract, state and architecture
  ledgers, TASK-018 spec/JSON, PLAN skill, ADRs 010-017, and dependency task
  handoffs for TASK-012, 014, 015, 016 and 017.
- Dependency implementation/review handoffs report PASS. Their behavior is
  already in `src/simulation.rs`: climate and soil water; plant growth; animal
  movement; herbivore feeding and carnivore hunting; plant then animal
  reproduction; age/death resolution; birth finalization; species extinction
  reconciliation.
- `World::lifecycle_counts`, `World::count`, and species-count queries already
  provide observability. No task-local handoff existed on entry. The working
  tree was clean and `git remote -v` returned no entries.
- PLAN is documentation-only; no product tests were run. No system package or
  crate is planned.

## Ordered implementation plan

1. Inspect current `TickPhase::ORDER`, `Simulation::step_one_tick`, lifecycle
   counters, age/death queue behavior and existing test fixtures in
   `src/simulation.rs`, `src/world.rs`, and `tests/simulation.rs`. Add a focused
   scheduler-order assertion if existing coverage does not prove plant growth,
   movement, herbivore feeding, carnivore hunting, reproduction, mortality,
   Finalize, and final species reconciliation order. Preserve the existing
   seven public scheduler phases; feeding currently contains grazing then hunt.
2. Add integration tests in `tests/ecology.rs` (or an existing appropriate
   integration test file) using the public `Config`, `Simulation`, `World`
   queries and lifecycle counters. A fixed-key-only JSON config must parse,
   construct the engine and advance exactly 1,000 ticks without panic/error.
   After every tick and for each kind assert `initial + births - deaths ==
   living`; use checked arithmetic where test helpers permit.
3. Add deterministic lifecycle scenarios: (a) zero plants with herbivores and
   carnivores eventually leaves both animal kinds extinct and neither returns;
   (b) zero herbivores with carnivores eventually leaves carnivores extinct;
   (c) plants-only world retains living plants and produces plant births; assert
   no kind returns after its first zero. Choose compact worlds/seeds and
   bounded tick limits from the organism lifespan/costs, not global-count
   runtime rules. Check accounting each tick in these cases too.
4. Add default-balance regressions: use the fixed-key defaults with plants only
   to prove plants survive and reproduce; provide abundant plants and
   herbivores under default behavior to prove herbivores survive and reproduce
   for several hundred ticks. Fix and document deterministic seeds. First run
   with current defaults; if either criterion fails, tune only existing local
   ecology defaults or globally applied organism constants, documenting the
   formula, local mechanism and tradeoff in ADR-018 and retesting all scenarios.
   Avoid introducing new config keys or population-aware behavior.
5. Add an ignored reporting test in `tests/ecology.rs` (preferred over an
   undocumented scratch command) that runs the fixed-key defaults for seeds
   1-5, 10,000 ticks each. Track the first tick where each kind reaches zero;
   report `survived` for kinds that never do. Continue all ticks after
   extinction. The test is observational and must not require coexistence.
   Document invocation as
   `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`.
   Run it, capture all 15 per-seed/per-kind outcomes and elapsed time, and
   record them in `tasks/TASK-018/handoffs/implement-cycle1.md` and
   `docs/STATE.md`.
6. Run focused ecology tests, the full suite, formatting and whitespace checks.
   Update ADR-018 with any balancing changes and actual results; update
   `docs/ARCHITECTURE.md` and `docs/STATE.md` with the implemented behavior,
   commands and measured outcomes. Record exact commands/results and remaining
   risks in the implementation handoff. Do not add dependencies/system
   packages unless newly justified; record exact apt install commands in
   STATE if one becomes necessary.

## Test plan

- `cargo test --test ecology -- --nocapture` — focused scenarios, lifecycle
  accounting and reproduction checks.
- `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`
  — required 5 x 10,000 reporting run (actual report is implementation
  evidence, not a planning result).
- `cargo test` — complete regressions.
- `cargo fmt --all -- --check && git diff --check` — formatting and whitespace.
- Validate the implementation handoff with
  `python3 -m json.tool tasks/TASK-018/handoffs/implement-cycle1.json`.

## Risks and constraints

- Default persistence/reproduction could fail under random initial genomes or
  climate; choose a reproducible seed and tune only general/local mechanisms.
- Plant reproduction has local water/cell-capacity constraints, herbivores
  lose energy to movement/maintenance, and carnivores pay costs even without
  prey. Changing one parameter can therefore shift all trophic levels.
- Climate and actors consume the shared seeded RNG in fixed order; adding
  random draws can change outcomes, so avoid incidental RNG changes.
- The five-seed report is a performance-heavy measurement and cannot prove
  guaranteed coexistence. Keep it ignored and separately invoked; do not let
  extinction truncate the required 10,000 ticks.
- No system dependency, external interface, task spec, contract, phase skill,
  benchmark state, or code file is to be changed during PLAN.

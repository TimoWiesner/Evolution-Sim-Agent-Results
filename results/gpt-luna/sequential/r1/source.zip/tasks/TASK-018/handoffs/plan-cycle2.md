# TASK-018 PLAN cycle 2

## Replan and review-gap closure

Cycle 1 REVIEW failed only on GAP-018-R1: the 300-tick herbivore scenario
changed plant growth from the default 35 permille to 1000 and mutation from
the default 250 basis points to zero. Compatible deterministic founders are
acceptable, but the environment and genetics must retain default settings to
prove the task's default-parameter criterion.

Cycle 2 implementation must replace that evidence with a controlled abundant-
plant scenario that leaves all `EcologyConfig` and `GeneticsConfig` defaults
untouched. Use `Config::default()` (or fixed-key JSON parsed without editing
those sub-configs), a large plant population (prefer the default 400 on the
standard 64x48 world), zero initial animal populations, and two compatible
high-fertility herbivores staged as test founders at the same cell. The founder
fixture isolates mating compatibility while the simulation still exercises
production movement, feeding, mutation, reproduction, mortality, climate, and
resources. Run for at least 300 ticks, checking lifecycle accounting each tick,
plant availability, surviving herbivores, and at least one herbivore birth.
Retain a deterministic seed and report it. Assert the ecology and genetics
values equal `Config::default()` before execution so future fixture edits cannot
silently weaken the criterion.

If this scenario fails, investigate with deterministic seed/genome fixture
changes first. Only if the failure is attributable to actual defaults should
implementation tune existing generally applied ecology defaults or documented
behavior constants, with rationale in ADR-018 and regression runs for every
extinction scenario. Do not add global-count-dependent behavior, replenishment,
new configuration keys, or anti-extinction protection. Re-run the existing
no-plants, no-herbivores, plants-only and per-tick accounting scenarios after
any behavior/default change. The cycle 1 five-seed measurement is already
recorded; if production behavior/defaults change, rerun its required report and
replace the prior observations with actual results.

## Ordered implementation plan

1. Inspect `tests/ecology.rs`, `src/config.rs`, `src/simulation.rs`,
   `src/world.rs`, and ADR-018. Preserve the documented scheduler phase order
   and current lifecycle semantics.
2. Correct only the abundant-herbivore integration fixture in
   `tests/ecology.rs`: keep all default ecology/genetics fields, supply 400
   plants on the default-sized grid, stage deterministic compatible founders,
   and check the default sub-config values explicitly. Advance 300+ ticks and
   assert plants remain available, herbivores survive and reproduce, and
   `initial + births - deaths == living` for all kinds after every tick.
3. Run the focused herbivore scenario. If it fails, diagnose before changing
   behavior. Any actual parameter changes must be local/ecologically grounded,
   documented in `docs/decisions/ADR-018-ecology-integration.md`, and followed
   by all extinction, persistence and accounting regressions.
4. Run `cargo test --test ecology -- --nocapture`, then `cargo test`,
   `cargo fmt --all -- --check`, `git diff --check`, and validate relevant JSON
   handoffs. If runtime/defaults changed, rerun
   `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`
   and record exact output and environment in the implementation handoff and
   `docs/STATE.md`.
5. Update ADR-018, `docs/ARCHITECTURE.md`, and `docs/STATE.md` only to reflect
   implementation facts. Record exact tests, outcomes, any tuning, and
   limitations in `tasks/TASK-018/handoffs/implement-cycle2.md` and JSON.

## Risks

- 400 plants may not remain abundant under default climate/resource and
  predation-adjacent effects; the test must demonstrate actual persistence,
  not infer it from initial count.
- Mutation can shift child genomes and alter later mating compatibility.
  Compatible founders establish a reproducible starting pair, but descendants
  and mating remain governed by default mutation and fertility.
- Expanding the ecology fixture to the default 64x48 world may increase test
  runtime; keep the required proof at 300 ticks unless evidence requires more.
- Any production tuning affects seed reports and extinction scenarios; changes
  must remain independent of global population counts.

## Commands and evidence

Planning did not run product tests. Inspection verified that current defaults
are plant growth 35 permille and mutation probability 250 basis points, and
that the cycle 1 test overrides both. Cycle 1's review result is recorded in
`tasks/TASK-018/handoffs/review-cycle1.json`.

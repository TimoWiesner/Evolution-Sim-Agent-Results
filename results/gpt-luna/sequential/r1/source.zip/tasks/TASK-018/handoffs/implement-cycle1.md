# TASK-018 IMPLEMENT cycle 1

## Implementation

Added `tests/ecology.rs` with public-API integration coverage for the fixed-key
JSON configuration at 1,000 ticks, tick-by-tick per-kind lifecycle accounting,
no-plant and no-herbivore extinction, plants-only persistence and reproduction,
and 300-tick survival/reproduction with abundant plants. Scenario checks also
ensure an extinct kind never returns. `TickReport::phases` is asserted against
the documented seven-phase order. Existing phase behavior remains: feeding
runs herbivores before carnivores, reproduction runs plants before animals,
then mortality resolves, births commit, and species extinction reconciles.

No production parameters or behavior needed tuning. The herbivore test stages
two identical high-fertility founders into an 8x8 world with 40 initial plants
and maximum configured plant growth. This controlled fixture avoids making a
probabilistic claim about random founders while exercising real movement,
feeding, mating and lifecycle behavior for 300 ticks. Other default ecological
settings remain unchanged.

## Five-seed report

Command: `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`

Result: exit 0, 1 test passed, elapsed 184.40 seconds. The run used the fixed
64x48/default population JSON, changing only seed values 1 through 5, and
continued to tick 10,000 after extinction.

| Seed | Plants | Herbivores | Carnivores |
| --- | --- | --- | --- |
| 1 | survived | 46 | 199 |
| 2 | survived | 46 | 170 |
| 3 | survived | 39 | 191 |
| 4 | survived | 32 | 180 |
| 5 | survived | 40 | 168 |

The measurement ran on the Ubuntu 24.04 x86_64 implementation container with
12 reported CPUs and rustc 1.100.0, release profile. These are observations,
not a coexistence guarantee.

## Verification

- `cargo test --test ecology -- --nocapture`: exit 0; 5 passed, 1 ignored, 0 failed (47.51 seconds).
- `cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`: exit 0; five-seed report passed (184.40 seconds).
- `cargo fmt --all && cargo test`: exit 0; all suites passed (42 library, 4 CLI, 6 config, 5 ecology, 9 simulation, 3 spatial-index; 69 total passed, 1 ignored).
- `cargo test` (final rerun after tightening the extinction-order assertion): exit 0; same suite counts, all 69 passed and 1 ignored.
- `cargo fmt --all -- --check`: exit 0.
- `git diff --check`: initially found one trailing blank line at EOF in `docs/STATE.md` (exit 2); removed it and reran successfully (exit 0).
- `git remote -v`: exit 0; no remotes listed.
- No crates or system packages were added.

## Follow-up

The report shows that the chosen default configuration loses both animal
kinds early for all five sampled seeds, while plants persist. TASK-018 permits
this outcome; TASK-027 owns further coexistence tuning. No global-count
protection or replenishment was added.

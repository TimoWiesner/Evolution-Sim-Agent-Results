# TASK-009 PLAN cycle 1

The plan adds genome state and deterministic phenotype derivation to the existing TASK-008 organisms. Current code has `Traits` in `src/entity.rs`, ordered living and pending-birth records in `src/world.rs`, initial placement and an owned `DeterministicRng` in `src/simulation.rs`, and mutation probability/step configuration in `src/config.rs`. There is no genome module yet. No TASK-009 handoffs existed on entry; dependency evidence comes from TASK-001 and TASK-008 plan/implement/review handoffs.

## Decisions

- Add `Genome` in `src/genome.rs` as eight named normalized `u16` loci: `speed`, `strength`, `max_health`, `fertility`, `risk_tolerance`, `aggression`, `foraging_bias`, and `lifespan`. The eighth locus covers existing `Traits::max_lifespan_ticks`; add `risk_tolerance` and `foraging_bias` to `Traits`. Derive all phenotype fields from genome deterministically, including lifespan. Existing max-health bounds remain enforced by the organism setter.
- Sample initial genome loci from the simulation-owned ChaCha8 stream in stable kind, ID, then locus order. Store genome on `Organism`; do not permit a stored genome/traits mismatch. Adapt the existing initialization and queued birth path. Preserve existing lifecycle semantics: newborns are committed at Finalize and start acting next tick.
- Offer one-parent and two-parent child constructors that accept `&mut DeterministicRng` and `&GeneticsConfig`. One-parent inheritance copies all loci before mutation. Two-parent inheritance chooses each parent's allele independently at 50/50 per locus before mutation. Each locus has an independent configured probability trial; mutation magnitude is 1..=configured step, sign is seeded, and the result clamps to 0..=65535. A zero mutation step cannot change loci. Define the exact random draw order in code and tests.
- Use existing `genetics.mutation_probability_bp` and `genetics.mutation_step` fields (already range-validated by config); add no config keys. Use sum of absolute differences over the eight loci, an integer-scaled mean that preserves strict ordering for distance. Keep speciation assignment out of scope.
- No new crate or OS package is planned. Genome data will eventually be part of versioned checkpoint state; checkpoint implementation is outside TASK-009 unless the implementation task explicitly owns a state schema surface.

## Ordered implementation

1. Add genome type, locus access/constructors, trait mapping, child constructors, mutation, and distance in `src/genome.rs`.
2. Extend `Traits` and `Organism` in `src/entity.rs` to hold genome and derive/check the phenotype at construction; update equality and lifecycle APIs as needed.
3. Update `World`/`Simulation` initialization and queued birth APIs to create consistent genome/trait records using the owned RNG and `Config.genetics`.
4. Export genome APIs through `src/lib.rs` and document actual interfaces/any deviations in ADR-004, `docs/ARCHITECTURE.md`, and `docs/STATE.md`.
5. Add focused genome and simulation tests for bounds/derivation, deterministic initial genomes, exact one-parent inheritance at mutation rate zero, per-locus two-parent inheritance at rate zero, positive mutation differences over a sufficiently large deterministic batch, and distance identity/symmetry/monotonicity.
6. Run focused genome tests, `cargo test`, formatting check, and `git diff --check`; record exact commands/results in the implementation handoff.

## Risks and test notes

- The eighth locus expands the originally seven-locus ADR schema and must be treated as a checkpoint schema change when checkpoints arrive.
- New initial-genome random draws change later climate/weather RNG progression; this is expected and must be stable and documented.
- Mutation tests should use a fixed seed and enough offspring to avoid relying on a lucky individual event; assert observed batch differences, not a probabilistic claim without reproducible evidence.
- Trait mapping must preserve all existing valid ranges, especially max health being no greater than the normalized max-health trait.
- Avoid assigning genome separately from traits via public APIs, which could create inconsistent records.

No product tests were run during PLAN. No system dependencies were installed or required. `git remote -v` returned no entries; no Git network operations were performed.

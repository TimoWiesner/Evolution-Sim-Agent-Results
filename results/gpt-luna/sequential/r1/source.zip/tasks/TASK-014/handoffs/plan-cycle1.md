# TASK-014 PLAN cycle 1

## Inspection

Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` exist. Read the
project brief, fixed interface contract, state and architecture ledgers,
TASK-014 markdown/JSON, PLAN skill, relevant plant/genome/lifecycle/scheduler
ADRs, and TASK-011/TASK-013 dependency plan/implementation/review handoffs.
TASK-014 has no prior handoffs or dependent-task handoffs. The working tree was
clean at entry; `git remote -v` listed no remotes.

The engine is Rust. `Feeding` is already ordered after AnimalMovement and
before Reproduction and Mortality. `Simulation::move_animals` currently uses
`animal::nearest_edible`, speed-derived vision, and ordered actors. `World`
has indexed `organisms_within`, bounded energy access through
`Simulation::set_organism_energy`, and staged death handling. Plant energy is
bounded; `World`'s organism map and mutable organism records are crate-visible
to simulation code. Current climate is available by cell. Animal genomes
already expose `foraging_bias`, `risk_tolerance`, and `aggression`; no schema
change is needed.

## Decisions

Record the behavior and rationale in ADR-014. Use a deterministic score that
blends normalized plant energy with proximity, weighted by the existing
`foraging_bias` locus. A bias of zero prefers proximity; maximum bias prefers
plant energy; score ties resolve by ascending plant ID. Apply gene-driven
selection in both herbivore movement target selection and feeding candidate
selection. Carnivore targeting remains unchanged.

Herbivores can transfer energy only from plants in the same or one adjacent
toroidal Chebyshev cell, even if plants farther away are visible. Limit to one
5,000-energy bite per herbivore/tick and transfer exactly the minimum of the
bite cap, plant energy, and herbivore headroom. On zero-energy plant, queue
starvation and exclude it from later bites before deferred Mortality. Charge
herbivore maintenance after feeding: 100 base energy plus 100 per started 1 C
outside -5 C..=35 C, with surcharge capped at 500. Queue herbivore starvation
at zero energy. Process actor IDs ascending; no global population checks or
new configuration keys.

## Ordered implementation and verification

1. Add `docs/decisions/ADR-014-herbivore-feeding.md` with exact fixed-point
   target score, ties, feeding reach, bite/transfer bounds, maintenance formula,
   scheduler behavior and alternatives.
2. Add/adjust pure decision helpers in `src/animal.rs`. Update
   `Simulation::move_animals` to use gene-driven plant target selection for
   herbivores while preserving existing carnivore target selection.
3. Implement herbivore processing in the existing Feeding section of
   `src/simulation.rs`. Use `World::organisms_within` for local edible plants,
   bounded energy transfer, current climate, maintenance and queued starvation.
   Keep all plant energy removal behind one helper so transfer conservation is
   explicit and zero-energy/pending-death plants cannot be consumed twice.
4. Add helper tests for score endpoints, score ties, maintenance bands/cap and
   bite limits. Add integration coverage in `tests/simulation.rs` or focused
   simulation unit tests for: visible target selection; same-cell and adjacent
   seam/corner feeding; no transfer from distance >1; exact plant/animal energy
   accounting; bite and herbivore capacity bounds; depleted plant mortality;
   per-tick maintenance and starvation; cold/heat surcharge; and two genomes
   selecting different movement/action outcomes in the same fixed setup.
5. Update ADR-014, `docs/ARCHITECTURE.md`, `docs/STATE.md`, and implementation
   handoff with actual behavior and results. Run focused feeding tests,
   `cargo test`, `cargo fmt --all -- --check`, and `git diff --check`.

No system package or new crate is planned. Product tests were not run during
PLAN. Contract-facing CLI behavior is outside TASK-014.

## Risks

- The integer score and selected bite/maintenance magnitudes are simplified
  ecology parameters, so tests must lock down their boundaries and the gene
  difference case.
- Movement precedes feeding and actors are processed sequentially; later
  herbivores see earlier movement and plant depletion. Stable IDs make outcomes
  deterministic.
- Mortality is deferred; zero-energy plants must be filtered from feeding
  candidates after the first bite, or another herbivore could transfer energy
  from a plant already scheduled to die.
- Maintenance after feeding lets a herbivore eat before it incurs that tick's
  cost. Keep this order explicit and test the final energy arithmetic.

# TASK-023 PLAN cycle 1

## Scope and inspected state

Implement only TASK-023's live browser window and world map. TASK-024 owns run
controls/inspection and TASK-025 owns parameter editing/charts. Read the
product brief, binding interface contract, current architecture/state,
TASK-023 specification, PLAN skill, and dependency TASK-006/TASK-013/TASK-019
handoffs. Their reviews pass; climate is queryable by cell, organisms are
ordered and spatially indexed, and the CLI uses the public `Simulation`
engine. No TASK-023 handoffs existed at entry. No product tests were run during
PLAN.

ADR-002 already selects a Rust-served local browser UI; TASK-023 confirms that
choice. See ADR-023 for alternatives, payload/rendering choices, and smoke /
screenshot lifecycle. Current bootstrap dispatches only `run`/`batch`; add a
UI dispatch branch and a UI module. The manifest currently has serde and
serde_json but no HTTP/UI dependency. The benchmark provides Chromium and
virtual display support. Plan no apt packages and no new Rust crate.

## Ordered implementation plan

1. Add `src/ui.rs` with strict `ui` argument/config handling, a loopback-only
   listener, static asset responses, compact JSON snapshot serialization,
   and lifecycle management for the simulation/browser process. Construct a
   single `Simulation` from the optional `--config` or default preset and
   advance it only through `step_one_tick`. Use a lock-protected shared
   simulation and a modest background tick cadence; snapshot reads are
   read-only and should remain cheap at 1,000 entities.
2. Define a stable snapshot containing dimensions, per-cell current climate or
   biome (including each cell exactly once), and living organisms' kind and
   cell coordinates in ascending ID order. Do not serialize full genomes or
   duplicate engine rules into JavaScript. Test JSON shape, cell coverage,
   kind mapping, and stable ordering.
3. Add `ui/index.html`, `ui/style.css`, and `ui/app.js`. Draw all cells and
   organisms on a responsive canvas, distinguish three organism kinds by
   shape/color, and show an always-visible explanatory legend. Implement drag
   pan and wheel zoom, requestAnimationFrame rendering, and modest polling so
   the interface updates several times per second. Reserve layout space for
   later controls/charts without implementing them.
4. Implement the real-page automation lifecycle. `--smoke-test` starts the
   service, launches headless Chromium under the supplied display environment,
   advances at least 10 engine ticks, verifies page-render completion, then
   shuts down with status 0. `--screenshots DIR` advances at least 100 ticks,
   captures the real canvas/page at >=1280x720 to `DIR/main.png`, and cleans
   up. Use `CHROME_BIN` or `chromium`; enforce the 60/120 second limits and
   preserve stderr diagnostics/status 2 for failures. The normal `ui` command
   opens the browser at the loopback URL and keeps the server available.
5. Add UI/API-focused tests (argument/config validation, snapshot coverage and
   determinism, server endpoints, automation result handling, pan/zoom logic as
   practical). Update README with `./evosim ui` startup instructions and
   relevant state/architecture/ADR notes. Run focused tests, full `cargo test`,
   formatter, diff check, setup, virtual-display smoke test, screenshot capture
   and image dimension/content inspection. Record exact commands/results and
   any environment dependencies in the implementation handoff and docs.

## Likely files

`src/ui.rs`, `src/lib.rs`, `ui/index.html`, `ui/style.css`, `ui/app.js`,
`tests/ui.rs` or `tests/cli.rs`, `README.md`, `docs/decisions/ADR-023-ui-world-view.md`,
`docs/ARCHITECTURE.md`, `docs/STATE.md`, and task-local implementation handoffs.
No system package installation is planned. If implementation installs any,
record its exact command in `docs/STATE.md` and repeat the install when absent.

## Risks and acceptance mapping

- A handwritten HTTP server can mishandle request framing or leak browser
  subprocesses. Keep the protocol surface tiny, bind only to loopback, cap
  request size, and test cleanup/error paths.
- Browser-based acceptance depends on finding Chromium and rendering completion
  reliably. Use explicit automation completion, a deadline, and actual output
  verification rather than assuming a screenshot command succeeded.
- Snapshot serialization and canvas work may limit refresh rate for dense
  worlds. Keep payload limited to climate plus kind/coordinates, batch drawing,
  and measure the 1,000-organism path.
- A canvas map needs clear legend and input affordances; ensure pan and zoom do
  not prevent seeing cells at default view and are reachable with mouse wheel
  and drag.

## PLAN verification

No product code or tests were run during this phase. Required files, task and
dependency specs/handoffs, interface/architecture decisions, and engine API
were inspected. Exact planning checks are recorded in `plan-cycle1.json`.

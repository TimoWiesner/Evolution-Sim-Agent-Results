# TASK-023 IMPLEMENT cycle 1

## Implementation

Added `src/ui.rs` and bundled static assets in `ui/`. The `ui` dispatcher starts
one shared Rust `Simulation`, binds an ephemeral listener to `127.0.0.1`, serves
the page and a compact JSON snapshot, and advances the engine at approximately
10 ticks per second. Snapshot climate is row-major and current-weather adjusted;
living organisms are emitted in ascending ID order with kind and cell position.
The browser uses a responsive canvas, climate color gradient, plant dots,
herbivore triangles, carnivore squares, legend, drag-to-pan and wheel-to-zoom.
It polls around every 180 ms. Genome and internal simulation state are not sent.

`--config` is validated with the existing Config parser. `--smoke-test` and
`--screenshots DIR` launch real Chromium with bounded 60/120 second deadlines;
the smoke path requires the page's rendered marker after at least 10 explicit
engine ticks. Screenshot mode advances at least 100 engine ticks, captures the
same UI page and verifies `main.png` signature and minimum dimensions. Normal
mode attempts to open the loopback URL with `BROWSER` or `xdg-open` and keeps
the service alive. README and architecture/state records were updated. No
system package or Rust dependency was installed.

## Evidence

- Snapshot unit test verifies complete cell coverage and deterministic ID/kind
  ordering.
- Full suite: 79 passed, 1 ignored, 0 failed (46 library, 10 CLI, 6 config,
  5 ecology, 9 simulation, 3 spatial index); doc tests pass.
- Chromium smoke test passed through `./evosim ui --smoke-test`, including with
  a 1,000 organism initial configuration.
- `./evosim ui --screenshots /tmp/evosim-ui-shot` passed; Python verified a
  valid 1440x900 PNG (288,536 bytes in the final run). Visual inspection showed
  the full climate map, entity markers, and legend.
- `./setup.sh`, `./build.sh`, and `./dist/evosim ui --smoke-test` passed.
- `cargo fmt --all -- --check` and `git diff --check` passed.

An initial compile found a moved screenshot-path value and the first Chromium
smoke exposed query-string routing on `/`; both were corrected. No tests were
added for a measured sustained frame rate. Poll cadence is 180 ms and the real
browser completed with 1,000 initial organisms, but a long-running visual update
rate measurement remains a review follow-up. Chromium is supplied by the
benchmark; no apt install command was needed. The host lacks the optional `file`
utility, so PNG dimensions were checked directly from the PNG header with
Python instead.

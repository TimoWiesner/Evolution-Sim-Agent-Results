# TASK-016 IMPLEMENT cycle 1

Implemented sexual reproduction for herbivores and carnivores in the existing
Reproduction phase, after plant reproduction. Animal candidates are considered
in ascending ID order. A valid pair consists of two distinct living animals of
the same kind, each age 10 or older with at least 60,000 energy, no active
cooldown, no pending death, and no lifespan death due this tick. Mates must be
within toroidal Chebyshev distance one and have genome distance at most 65,536.
Candidates sort by distance, then ID; a successful parent is unavailable for
another mating that tick.

Each parent receives an independent seeded fertility trial from 5% to 50%.
Both rolls are drawn in parent ID order for every otherwise eligible pair. A
successful pair queues one deferred child at one parent's cell, crosses and
mutates the parents' genomes through `Simulation::child_genome_two`, records
both sorted IDs and `max(generation) + 1`, charges each parent exactly 20,000
energy, and assigns a 20-pass cooldown. Existing cooldowns block their current
pass and decrement afterward; newly assigned cooldowns do not decrement on the
birth tick. This preserves 20 complete blocked passes.

## Verification

- `cargo test animal_reproduction_tests -- --nocapture`: passed 4 tests,
  including the singleton acceptance case, lineage, inherited parental alleles,
  configured mutation, exact cost, fertility endpoints, and cooldown behavior.
- `cargo test mate_choice_requires_eligible -- --nocapture`: passed the
  candidate selection and rejection boundary test.
- `cargo test`: passed 62 total tests (40 library, 4 CLI, 6 config, 9
  simulation integration, 3 spatial index), zero failures. The simulation
  integration tests took 26.89 seconds.
- `cargo fmt --all -- --check && git diff --check`: passed.
- `python3 -m json.tool /workspace/tasks/TASK-016/handoffs/implement-cycle1.json`:
  passed.

An early development run failed because the crossover test's proposed parent
genomes exceeded the approved compatibility distance. The fixture was adjusted
to a compatible pair, and the focused and full suites pass afterward. No system
packages or crates were added. Future checkpoint serialization needs to include
the cooldown field; checkpoint work is outside this task.

# TASK-016 PLAN cycle 1

## Inspected state

The workspace includes the required project and contract docs, current
`docs/STATE.md` / `docs/ARCHITECTURE.md`, TASK-016 spec and metadata, and PLAN
skill. TASK-016 had no prior handoffs. Dependent evidence inspected: TASK-009
plan/implementation/review, TASK-013 implementation, TASK-014 implementation,
and TASK-015 plan/implementation. TASK-009 provides eight-locus genomes,
`Genome::distance`, `Simulation::child_genome_two`, configured mutation, and
organism parent IDs/generation. TASK-013 through TASK-015 establish ascending-ID
animal movement/feeding behavior. `Simulation::step_one_tick` already has a
Reproduction slot and queues births until Finalize; animal reproduction is
currently absent. `World::organisms_within`, `World::is_pending_death`, bounded
energy accessors, and lifespan traits provide integration points.

## Decisions

- Use the existing Reproduction slot after plant reproduction. Process live
  animal IDs ascending and mark each successfully mated parent as used for the
  tick. This preserves prior plant RNG ordering and prevents double mating.
- Mate only distinct, same-kind animals at toroidal Chebyshev distance <=1.
  Choose nearest, then lower ID, among candidates passing all eligibility
  checks. Require genetic distance <=65,536 (mean normalized difference <=8,192).
- Both parents must be age >=10, have >=60,000 energy, have zero cooldown, be
  non-pending-death, and not reach lifespan mortality this tick. Fertility
  determines each parent's independent seeded success trial with chance
  `500 + floor(fertility * 4,500 / 65,535)` basis points (5%..=50%). Trial in
  ascending ID order only after all non-random checks pass.
- Successful mating queues one child with crossed and mutated genome through
  `Simulation::child_genome_two`, at one parent's current cell chosen by a
  seeded 50/50 draw. Store parent IDs ascending and checked
  `max(parent generation)+1`. Charge 20,000 energy to each parent and set a
  20-tick cooldown only after successful queueing. Add per-organism cooldown
  state initialized to zero; tick it down once per Reproduction pass. Newborns
  remain deferred to Finalize and cannot reproduce in their birth tick.
- Animals have unrestricted cell sharing, so no destination cap is needed.
  Add no config keys, packages or crates. No species naming/assignment is in
  scope.

## Ordered implementation

1. Add `reproduction_cooldown` to `src/entity.rs`; initialize zero and ensure
   staged child records use the same canonical constructor.
2. Add deterministic fertility, genetic compatibility, and mate selection
   helpers in `src/animal.rs`, using the existing `Grid` and `World` queries.
3. Add the animal pairing loop in `src/simulation.rs`'s Reproduction stage,
   after plants. Snapshot initial animal IDs; exclude pending deaths and used
   parents; only consume RNG for fertility after deterministic eligibility,
   then choose child cell and crossover; charge/set cooldown after queue success.
4. Add unit/integration coverage for the criteria below, including regressions
   for existing plant reproduction.
5. Update ADR-016, `docs/ARCHITECTURE.md`, `docs/STATE.md`, and the
   implementation handoff with actual interfaces and evidence.
6. Run focused reproduction tests, full `cargo test`,
   `cargo fmt --all -- --check`, and `git diff --check`.

## Required test evidence

Cover one animal alone never reproducing; no self-mating; distinct same-kind
parents only; rejection of mixed-kind, distant, incompatible, immature,
underfunded, pending-death, lifespan-expiring, or cooling-down candidates;
wrapped adjacency and deterministic nearest/ID choice; fertility probability
endpoints and seeded repeatability; both parental alleles in mutation-free
crossover and configured mutation use; parent IDs/generation; exact 20,000
cost each; 20-tick cooldown and no second mating; at most one child per pair;
delayed newborn action; and continued plant lifecycle behavior. Tests should
exercise real tick reproduction, with internal state fixtures where needed.

## Risks and limits

The random stream is shared with plant reproduction earlier in the same phase;
stable draw order is important for replay. Fertility draw timing, pairing and
cooldown boundaries need direct tests. Mating chance, maturity, energy, wait
time, radius and compatibility are simplified ecological values. A later
checkpoint implementation must persist cooldown state. No product tests were
run in PLAN; no system dependencies or crates were installed or planned. The
repository has no Git remotes; no Git network operations were performed.

# TASK-024 PLAN cycle 1

## Scope and findings

Read the binding task, project brief, contract, state/architecture ledgers,
PLAN skill, all available TASK-020/TASK-022/TASK-023 handoffs, and the relevant
metrics/checkpoint/UI ADRs. Dependency review evidence: TASK-022 and TASK-023
have PASS reviews; TASK-020 passed after cycle 2 remediation (75 passed, 1
ignored). TASK-024 has no prior task-local handoffs. The server and browser
assets are `src/ui.rs` and `ui/{index.html,app.js,style.css}`. Current `Snapshot`
contains tick, dimensions, climate cells, and only kind/position entities;
`respond` reads a single 8 KiB buffer. The server advances continuously at about
10 ticks/s even without a browser command. `World` exposes stable ordered live
organisms, lookup by ID, death history, and lifecycle totals. Organism energy
and health have public read accessors, while traits/genome/parents/species are
public fields. `Simulation::new` uses the config seed; `Simulation::restore`
validates a checkpoint but is crate-visible. CLI checkpoint envelope and
load/save routines are currently private to `src/cli.rs`.

## Decisions

- Browser-owned scheduling sends explicit whole-tick requests; server does no
  background stepping. Start paused. Provide run, pause, one tick, reset, and
  positive 1/5/20 ticks-per-second levels. Step always requests one tick and
  leaves run/pause state unchanged. Reset starts from the currently loaded or
  initially supplied effective config and seed.
- Persistent header shows tick and plant/herbivore/carnivore populations.
  Stable organism IDs are included in map snapshots for hit-testing. Fetch
  selected details separately and refresh on snapshots; keep following a
  selected ID when it moves or dies. Show all requested fields and the ordered
  eight-locus genome as labeled text.
- Browser save downloads the existing complete versioned JSON checkpoint;
  browser load posts the selected file and only replaces live state after the
  shared restore validation succeeds. Factor the CLI codec for reuse.
- Keep the existing canvas and loopback server architecture; no third-party
  UI/runtime dependencies or OS packages are planned.

## Ordered implementation plan

1. Extract the existing `Checkpoint` DTO/encode/decode and full restore path
   from `src/cli.rs` into a shared crate module or shared `Simulation` helpers.
   Preserve CLI JSON shape, error handling, state hash, and split-run behavior;
   expose the stored effective config as needed for reset/save.
2. Add UI control state and deterministic control helpers in a small Rust or
   JS module with display-free tests. Prefer a JS pure controller if it owns
   browser timer/selection behavior; use Node's built-in test runner, no npm
   dependencies. Define run/pause/step/reset/speed behavior, serial request
   scheduling, and selection persistence explicitly.
3. Extend `src/ui.rs` API: rich but compact world snapshots with IDs/counts;
   selected-ID lookup that returns live organism fields or matched death
   record; exact `advance`; reset to validated effective config; shared
   checkpoint GET/POST. Parse request method/path and Content-Length, read the
   complete bounded upload body, and ensure invalid uploads leave the current
   simulation untouched.
4. Update `ui/index.html`, `ui/app.js`, and `ui/style.css` with the controls,
   speed choices, persistent counters, canvas organism hit testing/highlight,
   inspector, genome/parent display, and checkpoint file download/upload.
   Preserve pan/zoom and ensure inspector/status fit at 1280x720.
5. Add focused no-display tests: pure control transitions and speed bounds;
   exactly-one-tick step and paused no-advance; same-seed reset hash equality;
   population/tick DTO and complete organism fields; selected live-to-dead
   follow behavior; valid checkpoint round-trip; invalid upload does not
   mutate the old state. Add Node tests for browser scheduler/selection if
   those semantics live in JS.
6. Verify through actual Chromium automation that run/pause/step/reset/speed,
   selection/inspector/death updates, and checkpoint save/load work. Preserve
   `./evosim ui --smoke-test` and `./evosim ui --screenshots DIR` contract
   commands and `main.png`. Run `cargo test`, `cargo fmt --all -- --check`,
   `git diff --check`, and `./setup.sh`; record exact commands and outcomes.
7. Update ADR-024 implementation status, `docs/ARCHITECTURE.md`, `docs/STATE.md`,
   and task implementation handoff with actual behavior, test evidence, and
   any dependencies.

## Interfaces and risks

Keep the checkpoint envelope exactly aligned with ADR-022: format version,
effective config, absolute tick, RNG continuation, and complete world state.
Use selected-ID lookup rather than shipping all genomes/history each refresh.
Serialize advance calls so timer overlap cannot duplicate or reorder ticks.
Reset/load must clear or re-resolve selected IDs and refresh all UI status.
Checkpoint upload size needs an explicit defensible cap and full Content-Length
handling; current HTTP parser is insufficient for file upload. Detailed dead
inspection must find only the selected record to avoid serializing/scanning all
history unnecessarily.

## Tests run during PLAN

No product tests were run in PLAN. Planning checks and their results are in the
JSON handoff.

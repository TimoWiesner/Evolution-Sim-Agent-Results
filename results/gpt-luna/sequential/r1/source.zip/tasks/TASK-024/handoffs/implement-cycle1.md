# TASK-024 IMPLEMENT cycle 1

## Implementation

- Replaced implicit server stepping with explicit browser requests. The page
  starts paused and provides Run, Pause, one-tick Step, Reset, and speed choices
  of 1/5/20 ticks per second.
- Added persistent tick and per-kind population counts; stable-ID map hit testing
  and highlighting; a selected-organism inspector with species, age, energy,
  health, traits, all genome loci, parents, generation and live/dead status.
- Added reset, detail, config and checkpoint endpoints. Request bodies are read
  fully by Content-Length and limited to 32 MiB. Invalid loads are parsed and
  validated before replacing the active simulation.
- Extracted the CLI checkpoint envelope and restore path into `src/checkpoint.rs`
  and reused it from UI save/load.
- Updated ADR-024, architecture and state docs. No dependencies or system
  packages were added.

## Verification

See the paired JSON handoff for exact command records. `cargo test` completed
with 81 passed, 1 ignored, 0 failed. Four Node controller tests passed. Setup,
Chromium smoke, and screenshot mode passed; `main.png` is 1440×900. A Python
HTTP probe verified exact one-tick advancement, detail lookup, checkpoint save
and restore, invalid-load atomicity, and reset. Formatting, whitespace and
remote checks passed.

## Verification limit

The real Chromium page was rendered in both automation modes, but individual
button and map-selection clicks were not driven by browser automation. The
controller and HTTP mutation paths were checked separately without conflating
those checks with a browser click test.

# TASK-007 PLAN cycle 1

## Existing state and dependency findings

TASK-006 is reviewed PASS (`tasks/TASK-006/handoffs/review-cycle1.json`). It
provides immutable row-major base `Climate` values from `Climate::at`, a
`World::climate(Cell)` query, and a periodic toroidal latitude proxy described
in ADR-008. TASK-005 is reviewed PASS and provides `Simulation`'s absolute
tick, deterministic ChaCha8 `DeterministicRng`, serializable RNG continuation
state, and the ordered `Climate` scheduler phase. The phase is currently a
no-op. `ClimateConfig` already contains a configurable year length, seasonal
temperature amplitude, and precipitation seasonality, but has no weather
toggle. No TASK-007 prior handoffs exist. No open dependency review gap applies.

The simulation currently increments its tick before returning a report. Make
the climate phase update the climate for the newly reached absolute tick, so
`world().climate(cell)` after `step_one_tick()` reports climate at
`simulation.tick()`. Initial tick zero should expose season phase zero and zero
weather deviations.

## Decisions

See ADR-009. Use the existing season settings and add a default-true optional
`climate.weather_enabled` field. Seasonal temperature is a sine wave whose
configured amplitude is scaled by distance from the warmest base-climate belt;
precipitation is a cosine wave scaled by the configured seasonality. Quantize
to integers and clamp to documented global bounds. Keep biome labels from
base climate rather than seasonally reclassifying cells.

Each climate tick draws independent bounded temperature and precipitation
deviations per cell from the simulation-owned RNG, in row-major order. Store
these deviations/current values in `World`. When weather is disabled, draw
nothing and use zero deviations, making climate a pure function of cell and
absolute tick. Any weather carryover must be included in simulation snapshots
and future checkpoints/canonical serialization. The task adds climate
behavior only; plant and animal effects remain excluded.

## Ordered implementation plan

1. Update `src/config.rs` with `ClimateConfig.weather_enabled`, its default,
   validation if needed, and JSON compatibility coverage. Update ADR-005's
   implemented schema/default table to reflect the field.
2. Add seasonal computation in `src/climate.rs`, retaining base climate and
   biome APIs. Use integer outputs, explicit phase and rounding rules, and the
   conservative bounds in ADR-009.
3. Extend `src/world.rs` with row-major current climate and explicit weather
   deviation state. Preserve base climate access and expose a current climate
   query for every valid `Cell`.
4. Implement the `TickPhase::Climate` action in `src/simulation.rs`: after
   advancing the tick, compute seasonal climate at that tick and draw weather
   from `DeterministicRng` in stable row-major cell order only when enabled.
   Define a small RNG sampling helper if needed without changing the generator.
5. Extend `SimulationSnapshot`/state capture to include the per-cell state
   needed to continue exactly. Keep all state in deterministic row-major form.
6. Add focused climate and simulation tests: tick-zero behavior; exact full-map
   equality at `t` and `t + year_length` with weather disabled; custom year
   length; same-seed weather equality and distinct-seed variation; weather RNG
   progression/state visibility; temperature/precipitation extremes and
   clamps; 1×1, 1×N, N×1 and ordinary grids. Existing static climate and
   scheduler tests must continue to pass.
7. Run focused tests and `cargo test`, plus formatting, `git diff --check`,
   and JSON handoff validation. Record exact commands/results in the
   IMPLEMENT handoff. No system packages/new crates are expected.

## Risks

- Floating trigonometric calculations can vary slightly by platform; make
  quantization and rounding explicit and test exact repetition within a build.
- Per-cell independent weather is spatially uncorrelated. This is an accepted
  simple model; future work can add correlated weather only with explicit
  deterministic state and checkpoint coverage.
- Adding a config field requires preserving old fixed-key-only JSON behavior
  through serde defaults and updating schema documentation.
- Any per-cell weather fields omitted from snapshots/checkpoints would break
  continuation and state hashing once those features are implemented.
- Precipitation seasonal/weather contributions can exceed base values, so
  clamping must be applied after all additions and documented.

## Environment and tests

No system packages or apt commands are needed. This was a planning phase; no
product test suite was run. Dependency handoffs were read and checked as
reviewed PASS. Git remote inspection returned no configured remotes.

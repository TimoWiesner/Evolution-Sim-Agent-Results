# TASK-001 PLAN cycle 1 handoff

## Scope and findings

Read the project brief, binding CLI/package contract, starter state, architecture ledger, task specification and JSON, ADR instructions, and PLAN skill. The task has no dependencies and the starter contains no product implementation or existing task handoffs. The repository has no configured remotes. No dependent task handoffs were present.

## Decisions

- Rust stable simulation library and CLI; package a native executable plus bundled UI assets.
- Local browser UI served by the executable; it calls the shared engine through a local JSON API.
- Row-major per-cell occupancy buckets; toroidal neighbor queries wrap cell coordinates and deduplicate aliases.
- Bounded integer fixed-schema loci, clonal plant inheritance and mutation, animal two-parent per-locus recombination and mutation, with stable representative-distance species assignment.
- A single checkpointed seeded PRNG, stable entity ordering, canonical serialization/hash order, and no wall-clock/unordered iteration dependence for outcomes.

See ADR-001 through ADR-004 and the planned module/dependency map and ordered implementation plan in `docs/ARCHITECTURE.md`.

## Verification and constraints

No product tests were run because no product code exists and this is a planning phase. Handoff JSON parsing and whitespace/diff checks are recorded in the JSON handoff. There are no system packages to install at this stage; if that changes, record exact apt commands in `docs/STATE.md` and the next handoff.

## Next steps

Implementation phase should translate the ordered architecture plan into Cargo modules, preserve the documented engine/UI dependency boundary, and add tests as modules are introduced. Do not treat suggested commands as already executed.

# TASK-001 PLAN cycle 2 handoff

## Replan scope

This cycle addresses both findings from REVIEW cycle 1. ADR-003 now states that occupancy buckets are in-memory engine data reconstructed from canonical entity positions, with no separate package dependency or index asset. ADR-004 now states that genomes and lineage metadata use versioned checkpoint serialization and that schema changes require checkpoint migration/versioning verified against the packaged executable.

## Ordered implementation plan

The existing implementation order and module boundaries remain in `docs/ARCHITECTURE.md`: (1) create the Cargo library and deterministic primitives in `src/config.rs`, `src/rng.rs`, `src/genome.rs`, `src/entity.rs`, and `src/world.rs`; (2) implement ordered ecology phases in `src/engine.rs`; (3) add full checkpoint serialization and canonical state hashing in `src/checkpoint.rs`; (4) implement contract commands and JSON output in `src/cli.rs`; (5) add `src/ui_server.rs` and `ui/` as adapters over the same engine; and (6) provide root launch/setup/build scripts and stage a self-contained `dist/`. Each module gets focused tests, followed by CLI contract, deterministic replay, checkpoint equivalence, UI smoke/screenshot, and packaged/offline checks. No product code belongs to TASK-001.

Interfaces: engine types are exposed through `src/lib.rs`; config parsing produces validated `Config`; CLI and UI both operate on public `Simulation` APIs; checkpoint load restores canonical state and reconstructs spatial buckets. Engine modules do not depend on CLI/UI, wall clock, unordered iteration, or browser assets. Algorithms and constants are specified in ADR-001 through ADR-004.

## Verification and constraints

No simulation tests are applicable in this planning-only task. This cycle runs documentation assertions, JSON validation and whitespace checks. No system packages are required. The workspace has no configured Git remote; no Git network operation was performed.

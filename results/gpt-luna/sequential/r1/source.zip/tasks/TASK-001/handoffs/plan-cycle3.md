# TASK-001 PLAN cycle 3 handoff

## Replan and review-gap closure

This cycle closes GAP-003 from REVIEW cycle 2. ADR-002 now explicitly compares native desktop rendering with the selected browser UI: native rendering avoids browser startup, local HTTP transfer, snapshot serialization and browser allocations, while the browser pays snapshot/request/render costs. The choice is justified by benchmark Chromium automation and flexible visualization. The simulation engine remains Rust and UI-independent; browser snapshot work is outside the headless simulation hot path. The implementation plan requires compact snapshots at displayed update intervals and measurement of payload size, request latency and rendering responsiveness at representative sizes.

## Ordered implementation plan

Keep the existing sequence in `docs/ARCHITECTURE.md`: first establish the Cargo library and deterministic config, RNG, genome, entity and world primitives; then ordered ecology tick phases; complete checkpoint serialization and canonical state hashing; CLI contract commands; browser server/UI over the shared engine; and finally setup/launcher/build packaging into self-contained `dist/`. Add focused tests with each owned implementation slice, then run contract, deterministic replay/checkpoint equivalence, torus/genetics, UI smoke/screenshot and offline packaged-executable checks. Preserve the dependency rule that engine modules cannot depend on CLI, UI server/assets, wall clock or unordered iteration.

## Verification and constraints

The focused documentation audit passed for all four ADRs (alternatives, decision, consequences, verification strategy and `dist/`), the explicit ADR-002 performance rationale, architecture dependency plan and absence of `src/` and `tests/`. `git diff --check` passed. `git remote -v` returned no entries. `find /workspace/tasks -path '*/handoffs/*' -type f -print` showed only TASK-001 handoffs, so there are no dependent-task handoffs. No product tests apply because TASK-001 excludes product code. No system packages were installed or added.

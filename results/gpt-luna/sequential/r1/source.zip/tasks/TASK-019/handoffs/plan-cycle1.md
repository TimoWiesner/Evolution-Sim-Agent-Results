# TASK-019 PLAN cycle 1

## Scope and inspected state

This plan covers only the headless `run` command, its result JSON, deterministic state hash, README example, and related documentation/tests. `--save`, `--load`, and `batch` remain explicitly out of scope. Dependencies TASK-003 and TASK-018 are complete; their handoffs establish strict JSON configuration/defaults and deterministic integrated ecology/lifecycle behavior.

The current binary dispatcher is in `src/main.rs`; `src/lib.rs` has bootstrap `dispatch`, and `tests/cli.rs` tests current entry points. `Config::from_json` provides strict typed config parsing. `Simulation::new`, `step_one_tick`, `world`, and `snapshot` are public. The snapshot includes tick/dimensions/RNG and `WorldClimateState`, but this is not complete: base climate and config are missing, resource capacity is missing, and no canonical serializer/hash exists. `World` iteration and state records are ordered; the spatial index is derived from organism positions. No TASK-019 handoffs existed on entry. No system packages are required.

## Decisions and ordered implementation

See `docs/decisions/ADR-019-headless-cli.md` for alternatives, tradeoffs, hash/state definition, and risks. Summary: implement the fixed run flags with a strict stdlib parser in `src/cli.rs`; use the existing config parser and seeded engine; use an explicit serialized canonical state DTO with ordered fields/vectors and SHA-256; measure only the tick loop; sample initial, interval, and final ticks; default sample spacing to `max(1, ceil(N/100))`; defer result-file creation until successful completion.

Implementation sequence:

1. Add canonical serialization access covering tick, dimensions, effective config, RNG continuation, all climate/weather/resource vectors, live organisms and genomes/traits, pending lifecycle queues, death history, lifecycle totals, species records, and ID allocators. Exclude only the reconstructible spatial index.
2. Add SHA-256 dependency and deterministic lowercase digest over canonical JSON bytes. Validate complete-field inclusion and state-mutation sensitivity.
3. Add run parsing, config loading, seed override, exact loop, result DTO/metrics, sampling, and delayed result writing. Keep all logs/errors on stderr and version stdout unchanged.
4. Extend CLI integration tests and README example. Verify fixed-key and zero-count configs, zero ticks, post-extinction exact advancement, deterministic repeats/hash, different-seed hash, sampling endpoints, and status 2/no-result behavior.
5. Update `docs/ARCHITECTURE.md` and `docs/STATE.md`; run and record focused/full tests and packaging checks in implementation handoff.

Likely paths: `src/cli.rs`, `src/metrics.rs`, `src/lib.rs`, `src/main.rs`, `src/simulation.rs`, `src/world.rs`, relevant state structs in `src/entity.rs`, `src/genome.rs`, `src/climate.rs`, `Cargo.toml`, `Cargo.lock`, `tests/cli.rs` (or `tests/run.rs`), `README.md`, `docs/decisions/ADR-019-headless-cli.md`, `docs/ARCHITECTURE.md`, and `docs/STATE.md`.

## PLAN verification

No product code or product tests were changed/run in this planning phase. Validation is limited to reading dependency/task documents and auditing interfaces. Exact planning checks are in `plan-cycle1.json`.

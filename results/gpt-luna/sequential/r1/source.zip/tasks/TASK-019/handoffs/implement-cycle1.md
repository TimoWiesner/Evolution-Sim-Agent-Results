# TASK-019 IMPLEMENT cycle 1

Implemented `evosim run` with strict flags, strict configuration loading, exact tick advancement, seed override, start/interval/final sampling, lifecycle totals, living species counts, finite timing metrics, delayed result writing, and status-2 diagnostics. No display is used. Checkpoint flags and batch are not implemented.

The state hash uses a versioned canonical JSON DTO and SHA-256. It includes the complete effective config and dimensions, clock, RNG continuation, world base/current climate, weather, resource vector/capacity, live and pending organisms, death history, lifecycle counters, species, and monotonic allocators. Ordered maps feed stable vectors; the derived spatial index is omitted. `sha2` is locked as a Cargo dependency. No system packages were installed.

The fixed-key runnable example is `examples/minimal.json`, referenced by README. The planned `scenarios/demo.json` was not present, so this change does not invent or claim to provide the separate demo scenario.

Verification: `cargo test --test cli` passed 7 tests and final-code `cargo test` passed 72 tests with 1 ignored. `./setup.sh`, the manual 100-tick headless run plus JSON parse, `./build.sh`, source/distributable version invocations from `/tmp`, `cargo fmt --all -- --check`, `git diff --check`, and `git remote -v` all succeeded (no remotes listed). No system dependency install commands are needed.

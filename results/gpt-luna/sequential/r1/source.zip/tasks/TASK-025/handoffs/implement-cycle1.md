# TASK-025 IMPLEMENT cycle 1

Implemented the approved scenario editor and chart dashboard on the TASK-024
browser UI. The existing Rust `Config` remains authoritative: `/api/presets`
serves ordered `balanced`, `lush`, and `harsh` configurations, while the form
edits all sixteen configuration leaves. `ui/config-model.js` normalizes the
complete schema, validates fields/ranges, rejects unknown and missing required
JSON keys, and handles normalized JSON import/export. Field errors display next
to their controls and block the start action. The server validates again before
resetting the simulation.

`/api/charts` returns UI-only observation history and current living values for
a selected kind and trait. History begins at world creation/reset/checkpoint
restore, appends after explicit advances, and retains at most 1,000 samples.
It stays outside checkpoints and engine hashes. `ui/chart-data.js` provides
pure time-series and distribution transforms. `ui/charts.js` draws labeled SVG
population, cumulative births/deaths, living species, mean speed, and
selectable trait distribution charts with legends. No chart library or runtime
network access was added.

Screenshot automation captures the real browser UI in `main.png` and the
chart view in `charts.png`, each 1440x1400, after 100 explicit ticks per page.
Both were written under `/tmp/task025-shots` during verification and visually
inspected. Chromium was already available. No system packages, Cargo crates,
or npm packages were added; no system installation command is required.

## Verification

- `node --test tests-js/*.test.js` — passed 7 tests (four prior controller tests and three TASK-025 config/chart tests).
- `python3 tests/ui_http_probe.py` — passed; checked preset ordering, initial and post-advance chart samples, valid reset, and that an invalid reset returns 400 without replacing the current world.
- `cargo test` — passed 82 tests, 1 ignored, 0 failures across library, CLI, configuration, ecology, simulation and spatial-index suites; doc tests passed (0 tests). Ecology suite reported 47.41 seconds; simulation suite 34.85 seconds.
- `./setup.sh` — passed; release binary built.
- `xvfb-run -a ./evosim ui --smoke-test` — passed.
- `xvfb-run -a ./evosim ui --screenshots /tmp/task025-shots` — passed; valid 1440x1400 PNGs for `main.png` and `charts.png`.
- `cargo fmt --all -- --check` — passed.
- `git diff --check` — passed.
- `git remote -v` — no remotes listed.

## Risks and follow-up

Chart resolution follows browser advance requests (1, 5, or 20 ticks in the
current controls), and older samples are dropped after 1,000 points. JavaScript
field metadata duplicates Rust bounds and defaults, so future config changes
must update both. The UI server remains the final validation authority. The
benchmark screenshot files are generated at runtime and are not committed as
assets. No review verdict is assigned in IMPLEMENT.

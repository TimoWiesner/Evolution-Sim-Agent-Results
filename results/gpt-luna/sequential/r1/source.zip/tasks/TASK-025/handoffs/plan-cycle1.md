# TASK-025 PLAN cycle 1

## Inspection and dependency state

- Verified `/workspace/AGENTS.md` and `/workspace/docs/STATE.md`, read the
  product brief, binding contract, architecture/state ledgers, task spec/JSON,
  PLAN skill, and relevant ADR-005, ADR-020, ADR-023 and ADR-024.
- Inspected dependency handoffs for TASK-003, TASK-020, TASK-021 and TASK-024.
  Their latest available review handoffs report PASS. TASK-003 provides
  `Config`, strict JSON parsing, full normalization, nested validation and
  `balanced`/`lush`/`harsh` presets. TASK-020 provides read-only
  `MetricsSample::capture`. TASK-021 is headless batch functionality and needs
  no UI changes. TASK-024 provides the loopback UI, `/api/config`, validated
  `/api/reset`, explicit advance, shared checkpoint endpoints, browser
  controller and display-free Node tests.
- Inspected `src/ui.rs`, `src/config.rs`, `src/metrics.rs`, `ui/index.html`,
  `ui/app.js`, `ui/controller.js`, `ui/style.css`, and existing Rust/Node test
  locations. UI snapshots currently include map/climate and organism positions;
  there is no chart endpoint/history or setup form. The page bundles assets
  with `include_str!`, so new static modules need explicit server routes.
- `git status --short` was empty and `git remote -v` listed no remotes. No
  product tests were run in PLAN; no product code changed.

## Decisions

- Canonical model is existing Rust `Config`; use its three presets and add
  ordered `/api/presets` serialization. Expose all 9 optional climate/ecology/
  genetics settings, in addition to seed/world/initial values.
- Create pure `ui/config-model.js` for normalization, defaults, schema/range
  validation, preset changes, and JSON import/export. Inline field errors block
  UI reset/start; `/api/reset` still performs authoritative Rust validation.
- Create pure `ui/chart-data.js` for deterministic chart transforms and use
  hand-written SVG (no chart library/package). Charts: population by kind,
  cumulative births/deaths by kind, living species by kind, mean speed by kind;
  selectable kind/trait distribution from current live organisms. Include
  labeled axes and legends.
- Extend `AppState` with up to 1,000 read-only `MetricsSample` values, seeded on
  initial/reset/restored worlds and appended once after each explicit
  `/api/advance` request. Add `/api/charts` to return ordered series and
  current trait values. Reset and checkpoint load begin a new sample segment.
  Do not add chart data to checkpoints or canonical engine state.
- Keep map/inspector and controls. Add a chart view and preserve the existing
  main screenshot while generating `charts.png` from a real chart view after
  at least 100 ticks.

## Ordered implementation plan

1. Implement the pure config module and Node tests first. Define known schema
   metadata (input key, type, default, lower/upper bound, display unit),
   `normalizeConfig`, `validateConfig`, preset cloning, and JSON import/export.
   Compare the defaults and ranges against `src/config.rs` and ADR-005. Ensure
   a file import/export round trip preserves the normalized complete config.
2. Implement pure chart transformations and fixed-fixture Node tests for all
   four time charts and selected distribution. Keep ticks ascending, map
   missing/empty metrics to stable empty chart data, and expose axis titles and
   legend entries independently from SVG rendering.
3. Update `src/ui.rs`: provide `/api/presets` and static routes for pure browser
   modules; store chart history in `AppState`; capture at world construction,
   successful reset, successful checkpoint restore and after each explicit
   advance; enforce the 1,000-point bound; implement chart query parsing and
   distribution values from living organisms. Add focused Rust tests for
   presets, sample lifecycle/bound, trait selection and invalid selection.
4. Build setup controls in `ui/index.html` and render/validate them in a new
   `ui/scenarios.js` or existing app module: preset selector, all editable
   values, adjacent error elements, import picker and JSON export download.
   Use one normalized draft for both reset and export. Preset changes replace
   draft, edits update it, import populates it, and reset sends only if valid.
5. Add chart navigation and SVG renderers in a separate `ui/charts.js` using
   the pure transform output. Poll chart API at the visible run cadence, keep
   axis labels/legends, update selectable trait/kind distribution, and keep
   map/run/inspector usable. Avoid external CDN or runtime network fetches.
6. Extend UI automation to capture `main.png` and `charts.png` from the actual
   bundled page, both at >=1280x720. Ensure screenshot mode advances >=100
   ticks, preloads enough sample data, and meets the contract timeout. Preserve
   current `main.png` semantics and smoke-test automation.
7. Update ADR-025 implementation evidence, `docs/ARCHITECTURE.md`,
   `docs/STATE.md`, and task implementation handoff with actual interfaces,
   tests, screenshot evidence, risks and system dependency facts.
8. Run display-free JS tests, focused Rust UI tests, full Rust suite, formatting,
   setup, Chromium smoke and screenshots, then whitespace/handoff validation.
   Record each real command and exit status; do not alter task state or commit.

## Verification plan and known limits

No product test was run because PLAN changes only planning documents and an
ADR. The implementation must demonstrate the acceptance points individually:
all requested editable values and preset path; field-local errors and blocked
start; import/export equality; four updating time series; a selectable current
trait distribution; chart labels and legends; display-free config/chart tests;
and real main plus charts screenshots. There are no planned new crates, npm
packages or system dependencies. The charts history is bounded to 1,000
samples and is intentionally a UI observation buffer, not a saved simulation
state field.

See `docs/decisions/ADR-025-ui-scenarios-charts.md` for alternatives, API/data
decisions, and risks.

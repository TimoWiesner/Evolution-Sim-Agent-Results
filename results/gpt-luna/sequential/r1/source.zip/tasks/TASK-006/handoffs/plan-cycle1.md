# TASK-006 PLAN cycle 1

## Scope and existing APIs

TASK-006 depends on TASK-004 and TASK-005. `Grid` provides validated positive `u32` dimensions, row-major cells by coordinate convention, and toroidal wrapping; `World` currently contains only a `Grid`. `Simulation` owns `World`, deterministic RNG and tick, and its ordered phase list already includes `Climate`. The climate scheduler slot is currently empty. `Config` exposes season settings, but temporal change is explicitly out of scope here. No existing TASK-006 handoff exists. TASK-004 review's prior gap (explicit cardinal edge assertions) was addressed in its implementation cycle 2; it is unrelated to this task and no TASK-006 replan gap is open.

## Decisions

See `docs/decisions/ADR-008-climate-biomes.md`. Use a static, analytic, seeded-independent periodic latitude proxy. Cell-center warmth varies as a cosine around the torus; base temperature is linear in warmth, while precipitation is high at cold/tropical ends and low in the subtropical dry range. Thresholded biomes represent polar, tundra, temperate, savanna/desert, and tropical. No noise/elevation is included in this task. Numeric constants must be explicit in implementation and checked at thresholds. Tiny worlds remain valid but need not display every category.

## Ordered implementation plan

1. Add `src/climate.rs` with public `Biome`, `Climate` (or equivalent value containing biome, base temperature and precipitation), and deterministic `Climate::at(grid, cell)` / map construction APIs. Choose documented fixed-point integer outputs (recommended centi-degrees Celsius and integer precipitation units) to avoid floating-point map instability; compute the cosine only during map construction if needed, then quantize deterministically. If the implementation uses floating-point trig, pin seam/category tests with tolerances and do not use hash iteration.
2. Extend `src/world.rs` so every valid grid cell has an addressable immutable base climate, initialized in stable row-major order. Keep `World::new`/`from_grid` behavior source-compatible where practical; do not add time evolution or organism effects.
3. Add a deterministic library formatter/export in `src/climate.rs` or `World` that emits all biome cells in row-major rows and supports inspection without a UI. Inspect CLI command scope: if this task owns an available CLI extension point, add a climate-map command; otherwise document and test the public text export without expanding unrelated CLI behavior.
4. Add `docs/decisions/ADR-008-climate-biomes.md` (formulas, thresholds, topology compromise, tradeoffs), update `docs/ARCHITECTURE.md` to record climate ownership/API and implementation order, and update `docs/STATE.md` with TASK-006 status and system-dependency note.
5. Test all five required zone classes on a tall representative grid, expected cold-to-warm ordering and dry savanna/desert distinction, exact threshold classifications, finite/bounded output, determinism, and text output dimensions/order.
6. Test toroidal continuity: compare every adjacent vertical climate difference including last-to-first with neighboring-row differences for heights large enough to resolve the profile; assert horizontal edge equality. Also test 1×1, 1×N, N×1 and small rectangular grids for complete valid values and no panic. Keep expectations honest about bands that cannot fit on tiny grids.
7. Run focused climate tests, `cargo test`, formatter on touched Rust files, `git diff --check`, and validate the phase handoff JSON. Record exact commands and output in the implementation handoff.

## Risks and constraints

- A naive linear latitude field creates a top/bottom discontinuity; all values and biome classification must derive from the same periodic coordinate.
- Cosine plus a linear temperature mapping may produce a visible warm double-equator / cold polar-seam compromise; explain this in user documentation.
- Floating point may vary slightly by target; quantize once and test seam limits with deliberate headroom, or use a deterministic lookup/fixed representation if reproducibility evidence is weak.
- Small heights cannot represent all biomes; acceptance should verify validity, not impossible label completeness for those worlds.
- The biome print/export must be available outside a UI and deterministic. If exposed only as a library method, verify the task's interpretation by documenting a direct way to call it or wire a minimal CLI command where appropriate.
- Climate stays static; do not implement seasons, weather, or ecological effects. No apt/system packages are anticipated; existing Cargo lockfile dependencies suffice.

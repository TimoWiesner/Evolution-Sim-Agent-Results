# TASK-004 PLAN cycle 2

## Replan scope and gap closure

REVIEW cycle 1 returned FAIL for `GRID-EDGE-TESTS`. The reviewer found that
`src/grid.rs::tests::wraps_all_edges_corners_negative_and_multiple_worlds`
asserts diagonal wrapping and values on selected boundaries, but does not
independently assert crossing each cardinal edge. The geometry implementation
and its other acceptance evidence were accepted; this plan changes test
coverage only.

## Ordered implementation plan

1. In `src/grid.rs`, extend or rename the existing wrap test. On a non-square
   grid, assert west-to-east with `x = -1` and east-to-west with `x = width`,
   keeping `y` valid and unchanged. Assert north-to-south with `y = -1` and
   south-to-north with `y = height`, keeping `x` valid and unchanged.
2. Add explicit corner wrap assertions crossing both axes (including at least
   one corner in each diagonal direction). Preserve the existing negative and
   multiply wrapped assertions and the separate 1x1 test.
3. Do not change `Grid`, `Cell`, `Direction`, production code, public API,
   architecture decisions, CLI, spatial index, or dependencies. This is a
   narrowly scoped test remediation for the failed review criterion.
4. Run the focused geometry test (for example,
   `cargo test grid::tests::wraps_all_edges_corners_negative_and_multiple_worlds`;
   update the filter if the test is renamed), then `cargo test`,
   `git diff --check`, and JSON validation of the implementation handoff.
   Report the exact commands and outcomes in IMPLEMENT cycle 2. The pre-existing
   crate-wide `cargo fmt --check` issue in `tests/cli.rs` remains unrelated.

## Acceptance mapping

- West-to-east and east-to-west are separate assertions with only x crossing.
- North-to-south and south-to-north are separate assertions with only y
  crossing.
- Corners are explicitly asserted, in addition to each cardinal crossing.
- Existing negative/multiply wrapped inputs, non-square grids and 1x1 coverage
  remain present. No behavior beyond those test assertions is changed.

## Risks and dependencies

The main risk is writing assertions that only normalize a boundary coordinate
without actually crossing it; use `-1` and the exact dimension as input and
assert the opposite edge result. The implementation is otherwise already
present. TASK-002 supplies the Rust/Cargo project; no system packages or new
Cargo dependencies are required. `git remote -v` was not needed for this
replan; local-only Git policy remains in force.

# TASK-004 PLAN cycle 1

## Scope and findings

TASK-004 depends on the implemented TASK-002 Rust/Cargo bootstrap. The product
already uses a root Cargo package and `cargo test`; no geometry module exists
yet. TASK-001/ADR-003 describes row-major per-cell indexing and wrapped square
offset queries, so the grid API should supply the same neighborhood metric and
deterministic wrapped coordinates. TASK-010 owns the later spatial index and is
out of scope here. There are no TASK-004 prior handoffs to close. The TASK-002
handoffs confirm that no OS packages are needed and that the harness owns
commits/stage transitions. `git remote -v` produced no entries.

## Decisions

- Use toroidal Chebyshev distance: max of shortest absolute wrapped x/y
  displacements. A radius therefore denotes a square of cell steps and aligns
  with the planned spatial index's square offset enumeration.
- Store valid positions as `Cell { x: u32, y: u32 }`; store nonzero dimensions
  in `Grid { width: u32, height: u32 }`. `Grid::new` rejects zero dimensions.
- Accept signed `i64` input coordinates and wrap with `rem_euclid`; return
  direction as signed `i32` components from source to destination. On an exact
  half-world tie for an even dimension choose the negative direction.
- Neighborhood radius is `u32`, includes cells at exactly the radius, and
  returns unique cells in row-major order. Use an all-cells fast path when the
  radius covers the greatest possible toroidal distance; otherwise enumerate
  offsets, deduplicate wrapped aliases, and sort. This handles dimensions of
  one and large radii without iterating an unbounded range.
- Add geometry only; no organisms, climate, index, CLI behavior, or external
  dependencies.

## Ordered implementation plan

1. Add `docs/decisions/ADR-006-grid-geometry.md` with metric, types, tie rule,
   coordinate convention, radius semantics, alternatives and tests.
2. Implement `src/grid.rs`: `Grid`, `Cell`, `Direction`, dimension validation,
   wrapping, shortest displacement, distance, and neighborhood enumeration.
3. Export `grid` and public geometry types in `src/lib.rs` without changing
   command dispatch.
4. Add focused tests (prefer unit tests beside the module, with an integration
   test only if the public API needs an external-use check). Cover all four
   edge crossings, corners, negative and multiple wraps, non-square grids,
   shortest direction and distance on both axes, even-axis antipodal ties,
   neighborhood boundaries/uniqueness/order, radius larger than dimensions,
   1x1, 1xN, and zero-dimension rejection. Add deterministic small-grid oracle
   comparisons against brute-force toroidal Chebyshev filtering.
5. Run focused tests and `cargo test`, check formatting/whitespace with
   `git diff --check`, and parse the handoff JSON. Record exact results in the
   implementation handoff.

## Risks and follow-up

Rust's `%` preserves a negative remainder, so coordinate wrapping must use
`rem_euclid`. Offset arithmetic can overflow for a large `u32` radius; use the
full-grid shortcut and bound enumeration before forming ranges. Deduplication
must not leak hash iteration order into the returned vector. The antipodal tie
cannot be symmetric in both directions on a torus, so the negative tie-break
is explicit and tested. TASK-010 should use the grid distance/neighborhood
semantics rather than introducing a conflicting metric.

No tests or implementation commands were run in this PLAN phase. No system
dependencies or install commands are needed.

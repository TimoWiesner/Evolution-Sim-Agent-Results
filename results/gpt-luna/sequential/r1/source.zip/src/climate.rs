//! Static, deterministic base climate and biome classification.
use crate::{Cell, ClimateConfig, Grid};
use serde::{Deserialize, Serialize};

/// A coarse climate zone. Savanna and desert are precipitation subtypes of the dry belt.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum Biome {
    Polar,
    Tundra,
    Temperate,
    Savanna,
    Desert,
    Tropical,
}

impl Biome {
    pub fn code(self) -> &'static str {
        match self {
            Self::Polar => "PO",
            Self::Tundra => "TU",
            Self::Temperate => "TE",
            Self::Savanna => "SA",
            Self::Desert => "DE",
            Self::Tropical => "TR",
        }
    }
}

/// Base climate for a cell. Temperature uses centi-degrees Celsius; precipitation is
/// an arbitrary but stable 0..=1000 annual-moisture index.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Climate {
    pub biome: Biome,
    pub temperature_centi_c: i16,
    pub precipitation: u16,
    /// Equatorial warmth on a 0..=10000 scale; useful for inspection and stable thresholds.
    pub warmth: u16,
}

impl Climate {
    pub fn at(grid: Grid, cell: Cell) -> Self {
        assert!(
            cell.x < grid.width() && cell.y < grid.height(),
            "cell outside grid"
        );
        let phase = std::f64::consts::TAU * (f64::from(cell.y) + 0.5) / f64::from(grid.height());
        let warmth =
            (((1.0 - phase.cos()) * 0.5 * 10_000.0).round() as i32).clamp(0, 10_000) as u16;
        let w = u32::from(warmth);
        let temperature_centi_c = (-2500_i32 + (w * 5500 / 10_000) as i32) as i16;
        // Wet polar/tropical ends, dry subtropical belt; piecewise linear and continuous.
        let precipitation = if w <= 5500 {
            700_u32.saturating_sub(w * 600 / 5500)
        } else {
            100 + (w - 5500) * 900 / 4500
        }
        .min(1000) as u16;
        let biome = classify(w, precipitation);
        Self {
            biome,
            temperature_centi_c,
            precipitation,
            warmth,
        }
    }
}

/// Calculate the seasonal component of climate at an absolute simulation tick.
pub fn seasonal(base: Climate, config: &ClimateConfig, tick: u64) -> Climate {
    let phase = std::f64::consts::TAU * (tick % u64::from(config.season_length_ticks)) as f64
        / f64::from(config.season_length_ticks);
    let seasonal_strength = 1.0 - f64::from(base.warmth) / 10_000.0;
    let temp_delta = (f64::from(config.seasonal_temperature_amplitude_centi_c)
        * seasonal_strength
        * phase.sin())
    .round() as i32;
    let precip_amplitude = (u32::from(config.precipitation_seasonality_bp) * 250 / 10_000) as f64;
    let precip_delta = (precip_amplitude * phase.cos()).round() as i32;
    Climate {
        temperature_centi_c: (i32::from(base.temperature_centi_c) + temp_delta).clamp(-8_800, 9_100)
            as i16,
        precipitation: (i32::from(base.precipitation) + precip_delta).clamp(0, 1000) as u16,
        ..base
    }
}

fn classify(w: u32, precipitation: u16) -> Biome {
    if w < 1000 {
        Biome::Polar
    } else if w < 2500 {
        Biome::Tundra
    } else if w < 5000 {
        Biome::Temperate
    } else if w < 7500 {
        if precipitation < 250 {
            Biome::Desert
        } else {
            Biome::Savanna
        }
    } else {
        Biome::Tropical
    }
}

/// Row-major two-letter biome codes, one line per grid row.
pub fn format_biome_map(grid: Grid) -> String {
    let mut out = String::new();
    for y in 0..grid.height() {
        if y != 0 {
            out.push('\n');
        }
        for x in 0..grid.width() {
            if x != 0 {
                out.push(' ');
            }
            out.push_str(Climate::at(grid, Cell { x, y }).biome.code());
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    fn grid(w: u32, h: u32) -> Grid {
        Grid::new(w, h).unwrap()
    }

    #[test]
    fn all_zones_appear_in_cold_to_warm_order_and_dry_subtypes() {
        let g = grid(3, 200);
        let zones: Vec<_> = (0..g.height())
            .map(|y| Climate::at(g, Cell { x: 0, y }).biome)
            .collect();
        for biome in [
            Biome::Polar,
            Biome::Tundra,
            Biome::Temperate,
            Biome::Desert,
            Biome::Savanna,
            Biome::Tropical,
        ] {
            assert!(zones.contains(&biome), "missing {biome:?}");
        }
        assert!(zones
            .windows(2)
            .any(|pair| pair == [Biome::Polar, Biome::Tundra]));
        assert!(zones
            .windows(2)
            .any(|pair| pair == [Biome::Tundra, Biome::Temperate]));
        assert!(zones
            .windows(2)
            .any(|pair| pair == [Biome::Temperate, Biome::Desert]));
        assert!(zones
            .windows(2)
            .any(|pair| pair == [Biome::Savanna, Biome::Tropical]));
    }

    #[test]
    fn periodic_seams_and_horizontal_climate_are_continuous() {
        for h in [2, 7, 32, 128] {
            let g = grid(5, h);
            let rows: Vec<_> = (0..h).map(|y| Climate::at(g, Cell { x: 0, y })).collect();
            let max_regular = rows
                .windows(2)
                .map(|p| climate_delta(p[0], p[1]))
                .max()
                .unwrap_or(0);
            assert!(climate_delta(rows[0], rows[h as usize - 1]) <= max_regular.max(1));
            for y in 0..h {
                assert_eq!(
                    Climate::at(g, Cell { x: 0, y }),
                    Climate::at(g, Cell { x: 4, y })
                );
            }
        }
    }

    fn climate_delta(a: Climate, b: Climate) -> u16 {
        a.warmth
            .abs_diff(b.warmth)
            .max(a.temperature_centi_c.abs_diff(b.temperature_centi_c))
            .max(a.precipitation.abs_diff(b.precipitation))
    }

    #[test]
    fn tiny_worlds_are_defined_and_map_is_stable_row_major() {
        for (w, h) in [(1, 1), (1, 8), (8, 1), (2, 3)] {
            let g = grid(w, h);
            for y in 0..h {
                for x in 0..w {
                    let c = Climate::at(g, Cell { x, y });
                    assert!((-2500..=3000).contains(&c.temperature_centi_c));
                    assert!(c.precipitation <= 1000);
                }
            }
            let map = format_biome_map(g);
            assert_eq!(map, format_biome_map(g));
            assert_eq!(map.lines().count(), h as usize);
            assert!(map
                .lines()
                .all(|line| line.split_whitespace().count() == w as usize));
        }
    }

    #[test]
    fn biome_thresholds_have_explicit_inclusive_boundaries() {
        assert_eq!(classify(999, 700), Biome::Polar);
        assert_eq!(classify(1000, 700), Biome::Tundra);
        assert_eq!(classify(2500, 700), Biome::Temperate);
        assert_eq!(classify(5000, 249), Biome::Desert);
        assert_eq!(classify(5000, 250), Biome::Savanna);
        assert_eq!(classify(7500, 0), Biome::Tropical);
    }
}

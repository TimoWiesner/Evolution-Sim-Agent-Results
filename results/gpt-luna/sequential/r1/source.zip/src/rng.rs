//! Seeded simulation-owned ChaCha8 random stream with an explicit replay position.

use rand_chacha::ChaCha8Rng;
use rand_core::{RngCore, SeedableRng};
use serde::{Deserialize, Serialize};

/// Complete continuation state for a deterministic RNG.
#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct RngState {
    pub seed: [u8; 32],
    pub stream: u64,
    pub word_position: u128,
}

/// ChaCha8 stream used by all stochastic simulation decisions.
#[derive(Clone, Debug)]
pub struct DeterministicRng {
    rng: ChaCha8Rng,
    seed: [u8; 32],
    stream: u64,
}

impl DeterministicRng {
    pub fn from_seed(seed: u64) -> Self {
        let expanded = expand_seed(seed);
        Self {
            rng: ChaCha8Rng::from_seed(expanded),
            seed: expanded,
            stream: 0,
        }
    }

    pub fn next_u32(&mut self) -> u32 {
        self.rng.next_u32()
    }
    pub fn next_u64(&mut self) -> u64 {
        self.rng.next_u64()
    }

    pub fn export_state(&self) -> RngState {
        RngState {
            seed: self.seed,
            stream: self.stream,
            word_position: self.rng.get_word_pos(),
        }
    }

    pub fn from_state(state: RngState) -> Self {
        let mut rng = ChaCha8Rng::from_seed(state.seed);
        rng.set_stream(state.stream);
        rng.set_word_pos(state.word_position);
        Self {
            rng,
            seed: state.seed,
            stream: state.stream,
        }
    }
}

/// Expand a u64 through four SplitMix64 outputs, each serialized little-endian.
pub fn expand_seed(seed: u64) -> [u8; 32] {
    let mut state = seed;
    let mut out = [0; 32];
    for chunk in out.chunks_exact_mut(8) {
        state = state.wrapping_add(0x9E3779B97F4A7C15);
        let mut z = state;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58476D1CE4E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D049BB133111EB);
        z ^= z >> 31;
        chunk.copy_from_slice(&z.to_le_bytes());
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn seed_expansion_and_chacha8_golden_vector() {
        let mut rng = DeterministicRng::from_seed(42);
        assert_eq!(
            expand_seed(42),
            [
                0x95, 0x6e, 0xeb, 0x2f, 0x26, 0x32, 0xd7, 0xbd, 0x03, 0xf1, 0x66, 0xb2, 0x33, 0xe3,
                0xef, 0x28, 0x52, 0x9f, 0x0f, 0x13, 0x57, 0x67, 0x52, 0x47, 0x94, 0xe3, 0x4a, 0x0e,
                0xff, 0xe1, 0x1c, 0x58,
            ]
        );
        assert_eq!(rng.next_u32(), 2_278_103_804);
    }

    #[test]
    fn restores_exactly_after_mixed_width_draws() {
        let mut original = DeterministicRng::from_seed(0x1234_5678);
        let _ = original.next_u32();
        let _ = original.next_u64();
        let _ = original.next_u32();
        let state = original.export_state();
        let expected = (
            original.next_u32(),
            original.next_u64(),
            original.next_u32(),
        );
        let mut restored = DeterministicRng::from_state(state);
        assert_eq!(
            (
                restored.next_u32(),
                restored.next_u64(),
                restored.next_u32()
            ),
            expected
        );
    }
}

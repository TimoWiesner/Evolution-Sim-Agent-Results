//! Headless result-producing command line.
use crate::checkpoint::Checkpoint;
use crate::{Config, MetricsSample, OrganismKind, Simulation};
use serde::Serialize;
use std::collections::BTreeMap;
use std::fs;
use std::time::Instant;

#[derive(Serialize)]
struct Species {
    plants: usize,
    herbivores: usize,
    carnivores: usize,
}
#[derive(Serialize)]
struct Totals {
    births: Counts64,
    deaths: Counts64,
}
#[derive(Serialize)]
struct Counts64 {
    plants: u64,
    herbivores: u64,
    carnivores: u64,
}
#[derive(Serialize)]
struct Sample {
    tick: u64,
    plants: usize,
    herbivores: usize,
    carnivores: usize,
}
#[derive(Serialize)]
struct ResultFile {
    contract: u32,
    seed: u64,
    tick_start: u64,
    tick_end: u64,
    world: WorldSize,
    #[serde(rename = "final")]
    final_counts: FinalCounts,
    totals: Totals,
    series: Vec<Sample>,
    metrics: Vec<MetricsSample>,
    state_hash: String,
    elapsed_seconds: f64,
    ticks_per_second: f64,
}
#[derive(Serialize)]
struct FinalCounts {
    plants: usize,
    herbivores: usize,
    carnivores: usize,
    species: Species,
}
#[derive(Serialize)]
struct WorldSize {
    width: u32,
    height: u32,
}

pub fn run(args: &[String]) -> (i32, String, bool) {
    match run_inner(args) {
        Ok(()) => (0, String::new(), false),
        Err(e) => (2, format!("evosim: {e}\n"), true),
    }
}

fn run_inner(args: &[String]) -> Result<(), String> {
    let mut config_path = None;
    let mut load_path = None;
    let mut save_path = None;
    let mut out_path = None;
    let mut ticks = None;
    let mut seed = None;
    let mut sample_every = None;
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].as_str();
        if !matches!(
            flag,
            "--config" | "--load" | "--save" | "--out" | "--ticks" | "--seed" | "--sample-every"
        ) {
            return Err(format!("unknown run argument '{flag}'"));
        }
        i += 1;
        let value = args
            .get(i)
            .ok_or_else(|| format!("{flag} requires a value"))?;
        if flag == "--config" {
            if config_path.replace(value.clone()).is_some() {
                return Err("duplicate --config".into());
            }
        } else if flag == "--load" {
            if load_path.replace(value.clone()).is_some() {
                return Err("duplicate --load".into());
            }
        } else if flag == "--save" {
            if save_path.replace(value.clone()).is_some() {
                return Err("duplicate --save".into());
            }
        } else if flag == "--out" {
            if out_path.replace(value.clone()).is_some() {
                return Err("duplicate --out".into());
            }
        } else {
            let parsed = value
                .parse::<u64>()
                .map_err(|_| format!("{flag} must be an unsigned integer"))?;
            match flag {
                "--ticks" => {
                    if ticks.replace(parsed).is_some() {
                        return Err("duplicate --ticks".into());
                    }
                }
                "--seed" => {
                    if seed.replace(parsed).is_some() {
                        return Err("duplicate --seed".into());
                    }
                }
                _ => {
                    if sample_every.replace(parsed).is_some() {
                        return Err("duplicate --sample-every".into());
                    }
                }
            }
        }
        i += 1;
    }
    if config_path.is_some() == load_path.is_some() {
        return Err("provide exactly one of --config or --load".into());
    }
    if load_path.is_some() && seed.is_some() {
        return Err("--seed cannot be used with --load".into());
    }
    let out_path = out_path.ok_or("missing --out")?;
    let ticks = ticks.ok_or("missing --ticks")?;
    let (config, sim) = if let Some(path) = config_path {
        let mut config = Config::from_json(
            &fs::read_to_string(path).map_err(|e| format!("cannot read configuration: {e}"))?,
        )
        .map_err(|e| format!("invalid configuration: {e}"))?;
        if let Some(seed) = seed {
            config.seed = seed;
        }
        let sim = Simulation::new(&config);
        (config, sim)
    } else {
        let path = load_path.expect("one input selected");
        let bytes = fs::read(path).map_err(|e| format!("cannot read checkpoint: {e}"))?;
        Checkpoint::restore(
            serde_json::from_slice(&bytes).map_err(|e| format!("invalid checkpoint: {e}"))?,
        )
        .map_err(|e| format!("invalid checkpoint: {e}"))?
    };
    let interval =
        sample_every.unwrap_or_else(|| (ticks / 100 + u64::from(ticks % 100 != 0)).max(1));
    if interval == 0 {
        return Err("--sample-every must be greater than zero".into());
    }
    let (file, checkpoint) = execute(&config, sim, ticks, interval)?;
    if let Some(path) = save_path {
        write_json(path, &checkpoint, "checkpoint")?;
    }
    write_json(out_path, &file, "result")
}

fn execute(
    config: &Config,
    mut sim: Simulation,
    ticks: u64,
    interval: u64,
) -> Result<(ResultFile, Checkpoint), String> {
    let start_tick = sim.tick();
    let mut series = vec![sample(&sim)];
    let mut metrics = vec![MetricsSample::capture(&sim)];
    let started = Instant::now();
    for step in 1..=ticks {
        sim.step_one_tick();
        if step % interval == 0 || step == ticks {
            series.push(sample(&sim));
            metrics.push(MetricsSample::capture(&sim));
        }
    }
    let elapsed = started.elapsed().as_secs_f64();
    let world = sim.world();
    let lc = world.lifecycle_counts();
    let final_counts = FinalCounts {
        plants: world.count(OrganismKind::Plant),
        herbivores: world.count(OrganismKind::Herbivore),
        carnivores: world.count(OrganismKind::Carnivore),
        species: Species {
            plants: world.living_species_count(OrganismKind::Plant),
            herbivores: world.living_species_count(OrganismKind::Herbivore),
            carnivores: world.living_species_count(OrganismKind::Carnivore),
        },
    };
    let result = ResultFile {
        contract: 1,
        seed: config.seed,
        tick_start: start_tick,
        tick_end: sim.tick(),
        world: WorldSize {
            width: config.world.width,
            height: config.world.height,
        },
        final_counts,
        totals: Totals {
            births: Counts64 {
                plants: lc.plants.births,
                herbivores: lc.herbivores.births,
                carnivores: lc.carnivores.births,
            },
            deaths: Counts64 {
                plants: lc.plants.deaths,
                herbivores: lc.herbivores.deaths,
                carnivores: lc.carnivores.deaths,
            },
        },
        series,
        metrics,
        state_hash: sim
            .state_hash()
            .map_err(|e| format!("cannot hash state: {e}"))?,
        elapsed_seconds: elapsed,
        ticks_per_second: if ticks == 0 {
            0.0
        } else {
            ticks as f64 / elapsed.max(f64::MIN_POSITIVE)
        },
    };
    let checkpoint = Checkpoint::capture(&sim, config.clone());
    Ok((result, checkpoint))
}

fn write_json<T: Serialize>(path: String, value: &T, label: &str) -> Result<(), String> {
    let json =
        serde_json::to_vec_pretty(value).map_err(|e| format!("cannot serialize {label}: {e}"))?;
    fs::write(path, json).map_err(|e| format!("cannot write {label}: {e}"))
}

fn sample(sim: &Simulation) -> Sample {
    let w = sim.world();
    Sample {
        tick: sim.tick(),
        plants: w.count(OrganismKind::Plant),
        herbivores: w.count(OrganismKind::Herbivore),
        carnivores: w.count(OrganismKind::Carnivore),
    }
}

#[derive(Serialize)]
struct BatchSummary {
    schema_version: u32,
    ticks: u64,
    runs: Vec<BatchRun>,
    aggregates: BTreeMap<String, Aggregate>,
}
#[derive(Serialize)]
struct BatchRun {
    seed: u64,
    parameters: BTreeMap<String, u64>,
    ticks: u64,
    file: String,
    final_counts: Counts64,
    extinct: BTreeMap<String, bool>,
}
#[derive(Serialize)]
struct Aggregate {
    mean: f64,
    min: usize,
    max: usize,
    extinct_runs: usize,
}

pub fn batch(args: &[String]) -> (i32, String, bool) {
    match batch_inner(args) {
        Ok(()) => (0, String::new(), false),
        Err(e) => (2, format!("evosim: {e}\n"), true),
    }
}

fn batch_inner(args: &[String]) -> Result<(), String> {
    let mut config_path = None;
    let mut seeds_raw = None;
    let mut ticks = None;
    let mut out_dir = None;
    let mut csv = None;
    let mut varies: Vec<(String, Vec<u64>)> = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].as_str();
        if !matches!(
            flag,
            "--config" | "--seeds" | "--ticks" | "--out-dir" | "--vary" | "--csv"
        ) {
            return Err(format!("unknown batch argument '{flag}'"));
        }
        i += 1;
        let value = args
            .get(i)
            .ok_or_else(|| format!("{flag} requires a value"))?
            .clone();
        match flag {
            "--config" => set_once(&mut config_path, value, flag)?,
            "--seeds" => set_once(&mut seeds_raw, value, flag)?,
            "--ticks" => set_once(&mut ticks, parse_num(&value, flag)?, flag)?,
            "--out-dir" => set_once(&mut out_dir, value, flag)?,
            "--csv" => set_once(&mut csv, value, flag)?,
            "--vary" => {
                let (path, values) = value.split_once('=').ok_or("--vary must be FIELD=V1,V2")?;
                let supported = [
                    "initial.plants",
                    "initial.herbivores",
                    "initial.carnivores",
                    "world.width",
                    "world.height",
                    "ecology.resource_capacity",
                ];
                if !supported.contains(&path) || varies.iter().any(|(p, _)| p == path) {
                    return Err(format!("unknown or duplicate --vary field '{path}'"));
                }
                let vals = parse_list(values, "--vary")?;
                if vals
                    .iter()
                    .copied()
                    .collect::<std::collections::BTreeSet<_>>()
                    .len()
                    != vals.len()
                {
                    return Err(format!("duplicate values for {path}"));
                }
                varies.push((path.to_owned(), vals));
            }
            _ => unreachable!(),
        }
        i += 1;
    }
    let config_path = config_path.ok_or("missing --config")?;
    let seeds_raw = seeds_raw.ok_or("missing --seeds")?;
    let ticks = ticks.ok_or("missing --ticks")?;
    let out_dir = out_dir.ok_or("missing --out-dir")?;
    if !std::path::Path::new(&out_dir).is_dir() {
        return Err("--out-dir must be an existing directory".into());
    }
    let seeds = parse_list(&seeds_raw, "--seeds")?;
    if seeds
        .iter()
        .copied()
        .collect::<std::collections::BTreeSet<_>>()
        .len()
        != seeds.len()
    {
        return Err("duplicate seeds".into());
    }
    let base = Config::from_json(
        &fs::read_to_string(config_path).map_err(|e| format!("cannot read configuration: {e}"))?,
    )
    .map_err(|e| format!("invalid configuration: {e}"))?;
    let interval = (ticks / 100 + u64::from(ticks % 100 != 0)).max(1);
    let mut combos: Vec<BTreeMap<String, u64>> = vec![BTreeMap::new()];
    for (path, values) in &varies {
        let mut next = Vec::new();
        for prior in &combos {
            for value in values {
                let mut row = prior.clone();
                row.insert(path.clone(), *value);
                next.push(row);
            }
        }
        combos = next;
    }
    let mut matrix = Vec::new();
    for seed in &seeds {
        for params in &combos {
            let mut cfg = base.clone();
            cfg.seed = *seed;
            for (path, value) in params {
                set_config(&mut cfg, path, *value)?;
            }
            cfg.validate()
                .map_err(|e| format!("invalid swept configuration: {e}"))?;
            matrix.push((*seed, params.clone(), cfg));
        }
    }
    let varied = combos.len() > 1;
    let mut records = Vec::new();
    let mut populations: BTreeMap<String, Vec<usize>> = BTreeMap::new();
    let mut extinctions: BTreeMap<String, usize> = BTreeMap::new();
    for (seed, params, cfg) in matrix {
        let filename = if !varied {
            format!("seed-{seed}.json")
        } else {
            let suffix = params
                .iter()
                .map(|(k, v)| format!("{}-{v}", k.replace('.', "-")))
                .collect::<Vec<_>>()
                .join("-");
            format!("seed-{seed}-{suffix}.json")
        };
        let (result, _) = execute(&cfg, Simulation::new(&cfg), ticks, interval)?;
        let f = &result.final_counts;
        let vals = [
            ("plants", f.plants),
            ("herbivores", f.herbivores),
            ("carnivores", f.carnivores),
        ];
        let mut extinct = BTreeMap::new();
        for (name, n) in vals {
            populations.entry(name.into()).or_default().push(n);
            let dead = n == 0;
            extinct.insert(name.into(), dead);
            if dead {
                *extinctions.entry(name.into()).or_default() += 1;
            }
        }
        write_json(format!("{out_dir}/{filename}"), &result, "result")?;
        records.push(BatchRun {
            seed,
            parameters: params,
            ticks,
            file: filename,
            final_counts: Counts64 {
                plants: f.plants as u64,
                herbivores: f.herbivores as u64,
                carnivores: f.carnivores as u64,
            },
            extinct,
        });
    }
    let mut aggregates = BTreeMap::new();
    for name in ["plants", "herbivores", "carnivores"] {
        let xs = &populations[name];
        let sum: usize = xs.iter().sum();
        aggregates.insert(
            name.into(),
            Aggregate {
                mean: sum as f64 / xs.len() as f64,
                min: *xs.iter().min().unwrap(),
                max: *xs.iter().max().unwrap(),
                extinct_runs: extinctions.get(name).copied().unwrap_or(0),
            },
        );
    }
    let summary = BatchSummary {
        schema_version: 1,
        ticks,
        runs: records,
        aggregates,
    };
    write_json(format!("{out_dir}/summary.json"), &summary, "summary")?;
    if let Some(path) = csv {
        write_csv(path, &summary)?;
    }
    Ok(())
}

fn set_once<T>(slot: &mut Option<T>, val: T, flag: &str) -> Result<(), String> {
    if slot.replace(val).is_some() {
        Err(format!("duplicate {flag}"))
    } else {
        Ok(())
    }
}
fn parse_num(value: &str, flag: &str) -> Result<u64, String> {
    if value.is_empty() || !value.bytes().all(|b| b.is_ascii_digit()) {
        return Err(format!("{flag} must be an unsigned integer"));
    }
    value
        .parse()
        .map_err(|_| format!("{flag} integer is out of range"))
}
fn parse_list(value: &str, flag: &str) -> Result<Vec<u64>, String> {
    if value.is_empty() {
        return Err(format!("{flag} list cannot be empty"));
    }
    value.split(',').map(|v| parse_num(v, flag)).collect()
}
fn set_config(c: &mut Config, p: &str, v: u64) -> Result<(), String> {
    let n = u32::try_from(v).map_err(|_| format!("{p} value out of range"))?;
    match p {
        "initial.plants" => c.initial.plants = n,
        "initial.herbivores" => c.initial.herbivores = n,
        "initial.carnivores" => c.initial.carnivores = n,
        "world.width" => c.world.width = n,
        "world.height" => c.world.height = n,
        "ecology.resource_capacity" => c.ecology.resource_capacity = n,
        _ => return Err(format!("unknown field {p}")),
    };
    Ok(())
}
fn csv_cell(s: &str) -> String {
    if s.contains([',', '"', '\n', '\r']) {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_owned()
    }
}
fn write_csv(path: String, s: &BatchSummary) -> Result<(), String> {
    let mut fields = std::collections::BTreeSet::new();
    for r in &s.runs {
        fields.extend(r.parameters.keys().cloned());
    }
    let mut head = vec!["seed".to_owned(), "ticks".into()];
    head.extend(fields.iter().cloned());
    head.extend([
        "plants".into(),
        "herbivores".into(),
        "carnivores".into(),
        "plants_extinct".into(),
        "herbivores_extinct".into(),
        "carnivores_extinct".into(),
    ]);
    let mut out = head.join(",");
    out.push('\n');
    for r in &s.runs {
        let mut row = vec![r.seed.to_string(), r.ticks.to_string()];
        row.extend(
            fields
                .iter()
                .map(|f| r.parameters.get(f).map(u64::to_string).unwrap_or_default()),
        );
        row.extend([
            r.final_counts.plants.to_string(),
            r.final_counts.herbivores.to_string(),
            r.final_counts.carnivores.to_string(),
            r.extinct["plants"].to_string(),
            r.extinct["herbivores"].to_string(),
            r.extinct["carnivores"].to_string(),
        ]);
        out.push_str(
            &row.iter()
                .map(|v| csv_cell(v))
                .collect::<Vec<_>>()
                .join(","),
        );
        out.push('\n');
    }
    fs::write(path, out).map_err(|e| format!("cannot write CSV: {e}"))
}

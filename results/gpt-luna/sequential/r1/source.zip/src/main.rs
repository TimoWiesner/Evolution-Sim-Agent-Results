use std::io::{self, Write};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let (code, output, stderr) = if args.first().map(String::as_str) == Some("climate-map") {
        climate_map(&args[1..])
    } else {
        evosim::dispatch(&args)
    };
    if stderr {
        let _ = io::stderr().write_all(output.as_bytes());
    } else {
        let _ = io::stdout().write_all(output.as_bytes());
        if args.first().map(String::as_str) == Some("version") {
            let _ = io::stdout().write_all(b"\n");
        }
    }
    std::process::exit(code);
}

fn climate_map(args: &[String]) -> (i32, String, bool) {
    if args.len() != 2 {
        return (2, "usage: evosim climate-map WIDTH HEIGHT\n".into(), true);
    }
    let parsed = args[0]
        .parse::<u32>()
        .ok()
        .zip(args[1].parse::<u32>().ok())
        .and_then(|(w, h)| evosim::Grid::new(w, h).ok());
    match parsed {
        Some(grid) => (0, format!("{}\n", evosim::format_biome_map(grid)), false),
        None => (
            2,
            "evosim: width and height must be positive integers\n".into(),
            true,
        ),
    }
}

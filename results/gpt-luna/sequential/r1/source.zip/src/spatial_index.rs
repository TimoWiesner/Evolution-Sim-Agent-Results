//! Derived per-cell occupancy index for discrete toroidal worlds.

use crate::OrganismId;
use crate::{Cell, Grid};

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct SpatialIndex {
    buckets: Vec<Vec<OrganismId>>,
}

impl SpatialIndex {
    pub(crate) fn new(grid: Grid) -> Self {
        Self {
            buckets: vec![Vec::new(); (grid.width() as usize) * (grid.height() as usize)],
        }
    }

    fn bucket(&self, grid: Grid, cell: Cell) -> Option<usize> {
        if cell.x >= grid.width() || cell.y >= grid.height() {
            return None;
        }
        Some((cell.y * grid.width() + cell.x) as usize)
    }

    pub(crate) fn insert(&mut self, grid: Grid, cell: Cell, id: OrganismId) {
        let index = self
            .bucket(grid, cell)
            .expect("organism position must be valid");
        self.buckets[index].push(id);
    }

    pub(crate) fn remove(&mut self, grid: Grid, cell: Cell, id: OrganismId) {
        let index = self
            .bucket(grid, cell)
            .expect("organism position must be valid");
        let bucket = &mut self.buckets[index];
        let index = bucket
            .iter()
            .position(|candidate| *candidate == id)
            .expect("organism must exist in its indexed cell");
        bucket.swap_remove(index);
    }

    pub(crate) fn move_id(&mut self, grid: Grid, from: Cell, to: Cell, id: OrganismId) {
        if from != to {
            self.remove(grid, from, id);
            self.insert(grid, to, id);
        }
    }

    pub(crate) fn ids_in(&self, grid: Grid, cell: Cell) -> &[OrganismId] {
        &self.buckets[self.bucket(grid, cell).expect("query cell must be valid")]
    }
}

//! Deterministic clock and ordered scheduler with climate, plant, and animal behavior.
use crate::animal;
use crate::entity::{DeathCause, OrganismId, OrganismKind};
use crate::plant;
use crate::world::WorldClimateState;
use crate::Cell;
use crate::{
    ClimateConfig, Config, DeterministicRng, EcologyConfig, GeneticsConfig, Genome, Grid, RngState,
    World,
};
use serde::Serialize;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum TickPhase {
    Climate,
    PlantGrowth,
    AnimalMovement,
    Feeding,
    Reproduction,
    Mortality,
    Finalize,
}

impl TickPhase {
    pub const ORDER: [Self; 7] = [
        Self::Climate,
        Self::PlantGrowth,
        Self::AnimalMovement,
        Self::Feeding,
        Self::Reproduction,
        Self::Mortality,
        Self::Finalize,
    ];
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TickEvent {}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TickReport {
    pub tick: u64,
    pub phases: Vec<TickPhase>,
    pub events: Vec<TickEvent>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SimulationSnapshot {
    pub tick: u64,
    pub width: u32,
    pub height: u32,
    pub rng: RngState,
    pub climate: WorldClimateState,
}

#[derive(Clone, Debug)]
pub struct Simulation {
    tick: u64,
    rng: DeterministicRng,
    world: World,
    climate_config: ClimateConfig,
    genetics_config: GeneticsConfig,
    ecology_config: EcologyConfig,
    config: Config,
}

impl Simulation {
    pub fn new(config: &Config) -> Self {
        let grid = Grid::new(config.world.width, config.world.height)
            .expect("validated config dimensions");
        let mut world =
            World::from_grid_with_resource_capacity(grid, config.ecology.resource_capacity);
        world.initialize_climate(&config.climate);
        let mut simulation = Self {
            tick: 0,
            rng: DeterministicRng::from_seed(config.seed),
            world,
            climate_config: config.climate.clone(),
            genetics_config: config.genetics.clone(),
            ecology_config: config.ecology.clone(),
            config: config.clone(),
        };
        for (kind, count) in [
            (OrganismKind::Plant, config.initial.plants),
            (OrganismKind::Herbivore, config.initial.herbivores),
            (OrganismKind::Carnivore, config.initial.carnivores),
        ] {
            for _ in 0..count {
                let position = Cell {
                    x: simulation.rng.next_u32() % grid.width(),
                    y: simulation.rng.next_u32() % grid.height(),
                };
                let genome = Genome::sample(&mut simulation.rng);
                simulation.world.initialize_organism(kind, position, genome);
            }
        }
        simulation
    }
    pub(crate) fn restore(
        config: Config,
        tick: u64,
        rng: RngState,
        world: WorldClimateState,
    ) -> Result<Self, String> {
        config
            .validate()
            .map_err(|e| format!("invalid checkpoint configuration: {e}"))?;
        if world.current_tick != tick {
            return Err("checkpoint clock does not match world tick".into());
        }
        if rng.seed != crate::rng::expand_seed(config.seed) {
            return Err("checkpoint RNG seed does not match configuration".into());
        }
        let grid = Grid::new(config.world.width, config.world.height).map_err(|e| e.to_string())?;
        let cells = (grid.width() as usize) * (grid.height() as usize);
        if world.base_climate.len() != cells
            || world.current_climate.len() != cells
            || world.weather.len() != cells
        {
            return Err("checkpoint climate vector length mismatch".into());
        }
        for index in 0..cells {
            let cell = Cell {
                x: index as u32 % grid.width(),
                y: index as u32 / grid.width(),
            };
            let base = crate::Climate::at(grid, cell);
            if world.base_climate[index] != base {
                return Err("checkpoint base climate does not match world geometry".into());
            }
            let deviation = world.weather[index];
            if deviation.temperature_centi_c.abs() > 300
                || deviation.precipitation.abs() > 100
                || (!config.climate.weather_enabled
                    && (deviation.temperature_centi_c != 0 || deviation.precipitation != 0))
            {
                return Err("checkpoint weather deviation is invalid".into());
            }
            let mut current = crate::climate::seasonal(base, &config.climate, tick);
            current.temperature_centi_c = (i32::from(current.temperature_centi_c)
                + i32::from(deviation.temperature_centi_c))
            .clamp(-8_800, 9_100) as i16;
            current.precipitation = (i32::from(current.precipitation)
                + i32::from(deviation.precipitation))
            .clamp(0, 1000) as u16;
            if world.current_climate[index] != current {
                return Err("checkpoint current climate does not match clock and weather".into());
            }
        }
        let world = World::restore(grid, world)?;
        if world.resource_capacity() != config.ecology.resource_capacity {
            return Err("checkpoint resource capacity does not match configuration".into());
        }
        Ok(Self {
            tick,
            rng: DeterministicRng::from_state(rng),
            world,
            climate_config: config.climate.clone(),
            genetics_config: config.genetics.clone(),
            ecology_config: config.ecology.clone(),
            config,
        })
    }
    pub fn tick(&self) -> u64 {
        self.tick
    }
    pub fn tick_index(&self) -> u64 {
        self.tick
    }
    pub fn config(&self) -> &Config {
        &self.config
    }
    pub fn world(&self) -> &World {
        &self.world
    }

    #[cfg(test)]
    pub(crate) fn world_mut(&mut self) -> &mut World {
        &mut self.world
    }
    pub fn set_organism_energy(&mut self, id: OrganismId, energy: u32) -> Result<(), &'static str> {
        self.world.set_organism_energy(id, energy)
    }
    pub fn move_organism(&mut self, id: OrganismId, destination: Cell) -> Result<(), &'static str> {
        self.world.move_organism(id, destination)
    }
    pub fn child_genome_one(&mut self, parent: Genome) -> Genome {
        Genome::child_one(parent, &mut self.rng, &self.genetics_config)
    }
    pub fn child_genome_two(&mut self, a: Genome, b: Genome) -> Genome {
        Genome::child_two(a, b, &mut self.rng, &self.genetics_config)
    }
    /// Queue a newborn for the current tick's Finalize boundary. It is assigned a
    /// permanent ID immediately, but cannot be inspected as live until commit.
    pub fn queue_birth(
        &mut self,
        kind: OrganismKind,
        position: Cell,
        genome: Genome,
        parents: [Option<OrganismId>; 2],
        generation: u64,
    ) -> Result<OrganismId, &'static str> {
        self.world
            .queue_birth(kind, position, genome, parents, generation)
    }
    pub fn queue_death(&mut self, id: OrganismId, cause: DeathCause) -> bool {
        self.world.queue_death(id, cause)
    }
    pub fn rng_state(&self) -> RngState {
        self.rng.export_state()
    }
    pub fn snapshot(&self) -> SimulationSnapshot {
        let grid = self.world.grid();
        SimulationSnapshot {
            tick: self.tick,
            width: grid.width(),
            height: grid.height(),
            rng: self.rng.export_state(),
            climate: self.world.state(),
        }
    }
    /// Canonical versioned JSON representation of every continuation-relevant state field.
    pub fn canonical_state_json(&self) -> Result<Vec<u8>, serde_json::Error> {
        #[derive(Serialize)]
        struct CanonicalState<'a> {
            format_version: u32,
            tick: u64,
            width: u32,
            height: u32,
            config: &'a Config,
            rng: RngState,
            world: WorldClimateState,
        }
        let grid = self.world.grid();
        serde_json::to_vec(&CanonicalState {
            format_version: 1,
            tick: self.tick,
            width: grid.width(),
            height: grid.height(),
            config: &self.config,
            rng: self.rng.export_state(),
            world: self.world.state(),
        })
    }

    pub fn state_hash(&self) -> Result<String, serde_json::Error> {
        use sha2::{Digest, Sha256};
        let bytes = self.canonical_state_json()?;
        Ok(format!("{:x}", Sha256::digest(bytes)))
    }
    pub fn step_one_tick(&mut self) -> TickReport {
        self.tick = self.tick.checked_add(1).expect("simulation tick overflow");
        self.world.set_current_tick(self.tick);
        self.world
            .advance_climate(&self.climate_config, self.tick, &mut self.rng);
        self.world.replenish_soil_water();
        let plants: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind == OrganismKind::Plant)
            .map(|o| o.id)
            .collect();
        for id in plants {
            let (position, climate, energy, lifespan) = {
                let organism = self
                    .world
                    .organism(id)
                    .expect("plant remains live until mortality");
                (
                    organism.position,
                    self.world.current_climate(organism.position),
                    organism.energy(),
                    u64::from(organism.traits.max_lifespan_ticks),
                )
            };
            let available = self.world.soil_water(position);
            let gain = {
                let organism = self
                    .world
                    .organisms
                    .get_mut(&id)
                    .expect("plant remains live");
                plant::grow(
                    organism,
                    climate,
                    available,
                    self.ecology_config.plant_growth_per_tick_permille,
                )
            };
            let spent = gain / plant::ENERGY_PER_WATER_UNIT;
            if spent > 0 {
                self.world.consume_soil_water(position, spent);
                let organism = self
                    .world
                    .organisms
                    .get_mut(&id)
                    .expect("plant remains live");
                organism.set_energy(energy.saturating_add(gain));
            }
            if let Some(organism) = self.world.organisms.get(&id) {
                if organism.age.saturating_add(1) >= lifespan {
                    self.world.queue_death(id, DeathCause::Age);
                } else if organism.energy() == 0 {
                    self.world.queue_death(id, DeathCause::Starvation);
                } else if plant::hostile_climate(climate) {
                    self.world.queue_death(id, DeathCause::Climate);
                }
            }
        }
        self.move_animals();
        self.feed_herbivores();
        self.hunt_herbivores();
        // Reproduction uses the post-growth energy and only actors alive at
        // phase start. Births remain pending until Finalize.
        let parents: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind == OrganismKind::Plant)
            .map(|o| o.id)
            .collect();
        for id in parents {
            let parent = self
                .world
                .organism(id)
                .expect("plant remains live until mortality");
            let climate = self.world.current_climate(parent.position);
            if parent.energy() < PLANT_REPRODUCTION_THRESHOLD
                || parent.age.saturating_add(1) >= u64::from(parent.traits.max_lifespan_ticks)
                || plant::hostile_climate(climate)
            {
                continue;
            }
            let origin = parent.position;
            // Draw a pair uniformly from the radius-two square, rejecting its
            // center so the offspring always disperses at least one cell.
            let (dx, dy) = loop {
                let dx = (self.rng.next_u32() % 5) as i64 - 2;
                let dy = (self.rng.next_u32() % 5) as i64 - 2;
                if dx != 0 || dy != 0 {
                    break (dx, dy);
                }
            };
            let destination = self
                .world
                .grid()
                .wrap(i64::from(origin.x) + dx, i64::from(origin.y) + dy);
            if !self.world.can_establish_plant(destination) {
                continue;
            }
            let (genome, generation) = {
                let parent = self
                    .world
                    .organism(id)
                    .expect("plant remains live until mortality");
                (
                    parent.genome,
                    parent
                        .generation
                        .checked_add(1)
                        .expect("plant generation overflow"),
                )
            };
            let child_genome = self.child_genome_one(genome);
            if self
                .world
                .queue_birth(
                    OrganismKind::Plant,
                    destination,
                    child_genome,
                    [Some(id), None],
                    generation,
                )
                .is_ok()
            {
                self.world
                    .set_organism_energy(
                        id,
                        self.world.organism(id).unwrap().energy() - PLANT_REPRODUCTION_COST,
                    )
                    .expect("parent remains live until mortality");
            }
        }
        self.reproduce_animals();
        // Existing actors age once, then Mortality removes queued deaths. Pending
        // births are committed only afterward, so newborns start at age zero.
        self.world.age_live();
        self.world.resolve_deaths(self.tick);
        self.world.finalize_births();
        self.world.reconcile_species_extinctions(self.tick);
        TickReport {
            tick: self.tick,
            phases: TickPhase::ORDER.to_vec(),
            events: Vec::new(),
        }
    }

    fn move_animals(&mut self) {
        let actors: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind != OrganismKind::Plant)
            .map(|o| o.id)
            .collect();
        // Actor order is stable; actors later in this list sense already moved
        // positions of earlier actors, while the set of actors stays fixed.
        for id in actors {
            let Some(actor) = self.world.organism(id) else {
                continue;
            };
            let kind = actor.kind;
            let origin = actor.position;
            let speed = actor.traits.speed;
            let foraging_bias = actor.traits.foraging_bias.unwrap_or(0);
            let energy = actor.energy();
            let vision = animal::vision_range(speed);
            let target = if kind == OrganismKind::Herbivore {
                animal::best_plant(&self.world, origin, vision, foraging_bias)
            } else {
                animal::nearest_edible(&self.world, id, kind, origin, vision)
            };
            let requested = animal::movement_range(speed);
            let wander_direction = if target.is_none() {
                const DIRECTIONS: [(i32, i32); 8] = [
                    (-1, -1),
                    (0, -1),
                    (1, -1),
                    (-1, 0),
                    (1, 0),
                    (-1, 1),
                    (0, 1),
                    (1, 1),
                ];
                let (dx, dy) = DIRECTIONS[(self.rng.next_u32() % 8) as usize];
                Some(crate::Direction { x: dx, y: dy })
            } else {
                None
            };
            let per_cell = animal::movement_cost_per_cell(speed);
            let affordable = (energy / per_cell).min(requested);
            let mut position = origin;
            let mut moved = 0;
            for _ in 0..affordable {
                let direction = target
                    .map(|(destination, _, _)| self.world.grid().direction(position, destination))
                    .or(wander_direction)
                    .expect("target or wander direction exists");
                if direction.x == 0 && direction.y == 0 {
                    break;
                }
                let next = self.world.grid().wrap(
                    i64::from(position.x) + i64::from(direction.x.signum()),
                    i64::from(position.y) + i64::from(direction.y.signum()),
                );
                if next == position {
                    break;
                }
                position = next;
                moved += 1;
            }
            if moved > 0 {
                self.world
                    .move_organism(id, position)
                    .expect("valid wrapped movement destination");
                self.world
                    .set_organism_energy(id, energy - per_cell * moved)
                    .expect("moving actor remains live");
            }
        }
    }

    fn feed_herbivores(&mut self) {
        let actors: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind == OrganismKind::Herbivore)
            .map(|o| o.id)
            .collect();
        for id in actors {
            let Some(herbivore) = self.world.organism(id) else {
                continue;
            };
            let position = herbivore.position;
            let energy_before = herbivore.energy();
            let bias = herbivore.traits.foraging_bias.unwrap_or(0);
            let climate = self.world.current_climate(position);
            let candidates: Vec<_> = self
                .world
                .organisms_within(position, 1, Some(OrganismKind::Plant))
                .into_iter()
                .filter(|plant| plant.energy() > 0 && !self.world.is_pending_death(plant.id))
                .map(|plant| (plant.id, plant.position, plant.energy()))
                .collect();
            let target = candidates.into_iter().max_by(|a, b| {
                let distance_a = self.world.grid().distance(position, a.1);
                let distance_b = self.world.grid().distance(position, b.1);
                animal::foraging_score(bias, a.2, distance_a, 1)
                    .cmp(&animal::foraging_score(bias, b.2, distance_b, 1))
                    .then_with(|| b.0.cmp(&a.0))
            });
            let transfer = target.map_or(0, |(plant_id, _, plant_energy)| {
                let amount = animal::HERBIVORE_BITE_ENERGY
                    .min(plant_energy)
                    .min(crate::MAX_ENERGY - energy_before);
                if amount > 0 {
                    self.world
                        .set_organism_energy(plant_id, plant_energy - amount)
                        .expect("selected plant remains live");
                    self.world
                        .set_organism_energy(id, energy_before + amount)
                        .expect("herbivore remains live");
                    if plant_energy == amount {
                        self.world.queue_death(plant_id, DeathCause::Starvation);
                    }
                }
                amount
            });
            let energy_after_bite = energy_before + transfer;
            let cost = animal::feeding_maintenance_cost(climate.temperature_centi_c);
            self.world
                .set_organism_energy(id, energy_after_bite.saturating_sub(cost))
                .expect("herbivore remains live until mortality");
            if energy_after_bite <= cost {
                self.world.queue_death(id, DeathCause::Starvation);
            }
        }
    }

    fn hunt_herbivores(&mut self) {
        let hunters: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind == OrganismKind::Carnivore)
            .map(|o| o.id)
            .collect();
        for id in hunters {
            let Some(hunter) = self.world.organism(id) else {
                continue;
            };
            let origin = hunter.position;
            let strength = hunter.traits.strength;
            let aggression = hunter.traits.aggression.unwrap_or(0);
            let handling = hunter.hunting_cooldown;
            if handling > 0 {
                self.world
                    .organisms
                    .get_mut(&id)
                    .expect("hunter remains live")
                    .hunting_cooldown = handling - 1;
            }
            let prey = if handling == 0 {
                self.world
                    .organisms_within(origin, 1, Some(OrganismKind::Herbivore))
                    .into_iter()
                    .filter(|o| o.energy() > 0 && !self.world.is_pending_death(o.id))
                    .map(|o| (self.world.grid().distance(origin, o.position), o.id))
                    .min_by_key(|(distance, prey_id)| (*distance, *prey_id))
            } else {
                None
            };
            if let Some((_, prey_id)) = prey {
                let prey = self.world.organism(prey_id).expect("selected prey is live");
                let chance = animal::hunting_chance_bp(
                    strength,
                    aggression,
                    prey.traits.speed,
                    prey.traits.risk_tolerance.unwrap_or(0),
                );
                if self.rng.next_u32() % 10_000 < chance {
                    let prey_energy = prey.energy();
                    let hunter_energy = self
                        .world
                        .organism(id)
                        .expect("hunter remains live")
                        .energy();
                    let gain = prey_energy.min(crate::MAX_ENERGY - hunter_energy);
                    self.world.queue_death(prey_id, DeathCause::Predation);
                    self.world
                        .set_organism_energy(id, hunter_energy + gain)
                        .expect("hunter remains live");
                    self.world
                        .organisms
                        .get_mut(&id)
                        .expect("hunter remains live")
                        .hunting_cooldown = animal::CARNIVORE_HANDLING_TICKS;
                }
            }
            let energy = self
                .world
                .organism(id)
                .expect("hunter remains live")
                .energy();
            let remaining = energy.saturating_sub(500);
            self.world
                .set_organism_energy(id, remaining)
                .expect("hunter remains live");
            if remaining == 0 {
                self.world.queue_death(id, DeathCause::Starvation);
            }
        }
    }

    fn reproduce_animals(&mut self) {
        let actors: Vec<_> = self
            .world
            .organisms()
            .filter(|o| o.kind != OrganismKind::Plant)
            .map(|o| o.id)
            .collect();
        // Capture cooldowns already active at phase entry. They remain
        // ineligible for this entire tick; decrement only after selection so
        // a value of 20 blocks the next 20 reproduction passes.
        let cooling: Vec<_> = actors
            .iter()
            .copied()
            .filter(|id| {
                self.world
                    .organism(*id)
                    .is_some_and(|organism| organism.reproduction_cooldown > 0)
            })
            .collect();
        let mut used = std::collections::BTreeSet::new();
        for id in actors {
            if used.contains(&id) || self.world.is_pending_death(id) {
                continue;
            }
            let Some(mate) = animal::nearest_mate(&self.world, id, &used) else {
                continue;
            };
            let (mate_id, kind, parent_a, parent_b, generation, fertility_a, fertility_b) = {
                let a = self.world.organism(id).expect("eligible parent is live");
                let b = self.world.organism(mate.id).expect("eligible mate is live");
                (
                    b.id,
                    a.kind,
                    a.genome,
                    b.genome,
                    a.generation
                        .max(b.generation)
                        .checked_add(1)
                        .expect("animal generation overflow"),
                    a.traits.fertility,
                    b.traits.fertility,
                )
            };
            let roll_a = self.rng.next_u32() % 10_000;
            let roll_b = self.rng.next_u32() % 10_000;
            if roll_a >= animal::reproduction_chance_bp(fertility_a)
                || roll_b >= animal::reproduction_chance_bp(fertility_b)
            {
                continue;
            }
            let (position_a, position_b) = (
                self.world.organism(id).unwrap().position,
                self.world.organism(mate_id).unwrap().position,
            );
            let position = if self.rng.next_u32() % 2 == 0 {
                position_a
            } else {
                position_b
            };
            let genome = self.child_genome_two(parent_a, parent_b);
            let parents = [Some(id.min(mate_id)), Some(id.max(mate_id))];
            if self
                .world
                .queue_birth(kind, position, genome, parents, generation)
                .is_ok()
            {
                for parent_id in [id, mate_id] {
                    let parent = self.world.organisms.get_mut(&parent_id).unwrap();
                    parent.set_energy(
                        parent
                            .energy()
                            .saturating_sub(animal::ANIMAL_REPRODUCTION_COST),
                    );
                    parent.reproduction_cooldown = animal::ANIMAL_REPRODUCTION_COOLDOWN;
                }
                used.insert(id);
                used.insert(mate_id);
            }
        }
        for id in cooling {
            if let Some(parent) = self.world.organisms.get_mut(&id) {
                parent.reproduction_cooldown = parent.reproduction_cooldown.saturating_sub(1);
            }
        }
    }
}

const PLANT_REPRODUCTION_THRESHOLD: u32 = 60_000;
const PLANT_REPRODUCTION_COST: u32 = 20_000;

#[cfg(test)]
mod plant_lifecycle_tests {
    use super::*;
    use crate::entity::OrganismKind;

    #[test]
    fn plants_die_at_genome_lifespan_and_in_hostile_climate() {
        let mut config = Config::preset("balanced").unwrap();
        config.world.width = 1;
        config.world.height = 100;
        config.initial.plants = 1;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.genetics.mutation_probability_bp = 10_000;
        config.genetics.mutation_step = 1;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        let mut sim = Simulation::new(&config);
        let (id, lifespan) = sim
            .world
            .organisms()
            .next()
            .map(|o| (o.id, u64::from(o.traits.max_lifespan_ticks)))
            .unwrap();
        sim.world.organisms.get_mut(&id).unwrap().age = lifespan - 1;
        sim.step_one_tick();
        assert_eq!(sim.world.death_history()[0].cause, DeathCause::Age);

        config.climate.season_length_ticks = 4;
        config.climate.seasonal_temperature_amplitude_centi_c = 6000;
        let mut sim = Simulation::new(&config);
        let id = sim.world.organisms().next().unwrap().id;
        sim.world.move_organism(id, Cell { x: 0, y: 0 }).unwrap();
        sim.step_one_tick();
        sim.step_one_tick();
        sim.step_one_tick();
        assert_eq!(sim.world.count(OrganismKind::Plant), 0);
        assert_eq!(sim.world.death_history()[0].cause, DeathCause::Climate);
    }

    #[test]
    fn plant_reproduction_records_lineage_and_wraps_within_radius_two() {
        let mut config = Config::preset("lush").unwrap();
        config.world.width = 8;
        config.world.height = 8;
        config.initial.plants = 1;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.genetics.mutation_probability_bp = 10_000;
        config.genetics.mutation_step = 1;
        let mut saw_wrapped_dispersal = false;
        for seed in 0..100 {
            config.seed = seed;
            let mut sim = Simulation::new(&config);
            let parent_id = sim.world.organisms().next().unwrap().id;
            let origin = Cell { x: 0, y: 0 };
            sim.move_organism(parent_id, origin).unwrap();
            sim.set_organism_energy(parent_id, 100_000).unwrap();
            sim.step_one_tick();
            let child = sim
                .world
                .organisms()
                .find(|o| o.id != parent_id)
                .expect("eligible plant reproduces at an open site");
            assert_eq!(child.parent_ids, [Some(parent_id), None]);
            assert_eq!(child.generation, 1);
            assert_ne!(child.genome, sim.world.organism(parent_id).unwrap().genome);
            assert!(sim.world.grid().distance(origin, child.position) <= 2);
            assert_ne!(origin, child.position);
            assert!(sim.world.organism(parent_id).unwrap().energy() <= 80_000);
            assert_eq!(child.age, 0, "newborn does not age in its birth tick");
            if child.position.x >= 6 || child.position.y >= 6 {
                saw_wrapped_dispersal = true;
                break;
            }
        }
        assert!(
            saw_wrapped_dispersal,
            "fixed seed set exercises seam wrapping"
        );
    }

    fn reproduction_fixture(seed: u64, plants: u32) -> (Config, Simulation, OrganismId) {
        let mut config = Config::preset("balanced").unwrap();
        config.seed = seed;
        config.world.width = 8;
        config.world.height = 8;
        config.initial.plants = plants;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        config.genetics.mutation_probability_bp = 0;
        let mut sim = Simulation::new(&config);
        // Config validation requires positive growth, but the engine's zero
        // setting is useful here to isolate reproduction's energy accounting.
        sim.ecology_config.plant_growth_per_tick_permille = 0;
        let parent = sim.world.organisms().next().unwrap().id;
        (config, sim, parent)
    }

    fn sampled_destination(sim: &Simulation, origin: Cell) -> Cell {
        let mut rng = sim.rng.clone();
        let (dx, dy) = loop {
            let dx = (rng.next_u32() % 5) as i64 - 2;
            let dy = (rng.next_u32() % 5) as i64 - 2;
            if dx != 0 || dy != 0 {
                break (dx, dy);
            }
        };
        sim.world
            .grid()
            .wrap(i64::from(origin.x) + dx, i64::from(origin.y) + dy)
    }

    #[test]
    fn plant_reproduction_energy_threshold_and_successful_cost_are_exact() {
        let origin = Cell { x: 3, y: 3 };
        for (starting_energy, expected_energy, expected_births) in
            [(59_999, 59_999, 0), (60_000, 40_000, 1)]
        {
            let (_, mut sim, parent) = reproduction_fixture(21, 1);
            sim.move_organism(parent, origin).unwrap();
            let target = sampled_destination(&sim, origin);
            assert!(!plant::hostile_climate(sim.world.current_climate(target)));
            sim.set_organism_energy(parent, starting_energy).unwrap();
            sim.step_one_tick();
            assert_eq!(
                sim.world.organism(parent).unwrap().energy(),
                expected_energy
            );
            assert_eq!(sim.world.count(OrganismKind::Plant), 1 + expected_births);
        }
    }

    #[test]
    fn blocked_sampled_plant_destination_causes_no_birth_or_reproduction_cost() {
        let origin = Cell { x: 3, y: 3 };
        let (_, mut sim, parent) = reproduction_fixture(37, 5);
        sim.move_organism(parent, origin).unwrap();
        let target = sampled_destination(&sim, origin);
        assert_ne!(target, origin);
        assert!(!plant::hostile_climate(sim.world.current_climate(target)));
        let others: Vec<_> = sim
            .world
            .organisms()
            .filter(|o| o.id != parent)
            .map(|o| o.id)
            .collect();
        for id in others {
            sim.move_organism(id, target).unwrap();
            // Zero energy would queue starvation before the reproduction
            // occupancy check. One energy keeps each blocker alive this tick.
            sim.set_organism_energy(id, 1).unwrap();
        }
        sim.set_organism_energy(parent, 60_000).unwrap();
        let before = sim.world.count(OrganismKind::Plant);
        sim.step_one_tick();
        assert_eq!(sim.world.organism(parent).unwrap().energy(), 60_000);
        assert_eq!(sim.world.count(OrganismKind::Plant), before);
    }

    #[test]
    fn zero_plants_stay_zero_and_local_establishment_checks_water_and_pending_occupancy() {
        let mut config = Config::preset("balanced").unwrap();
        config.world.width = 2;
        config.world.height = 2;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        let mut sim = Simulation::new(&config);
        for _ in 0..20 {
            sim.step_one_tick();
        }
        assert_eq!(sim.world.count(OrganismKind::Plant), 0);

        let cell = Cell { x: 0, y: 0 };
        assert!(sim.world.can_establish_plant(cell));
        sim.world.consume_soil_water(cell, u32::MAX);
        assert!(!sim.world.can_establish_plant(cell));
        let mut crowded = Simulation::new(&config);
        for _ in 0..4 {
            crowded
                .world
                .queue_birth(
                    OrganismKind::Plant,
                    cell,
                    Genome::default(),
                    [None, None],
                    1,
                )
                .unwrap();
        }
        assert!(!crowded.world.can_establish_plant(cell));
    }
}

#[cfg(test)]
mod herbivore_feeding_tests {
    use super::*;

    fn empty_sim(width: u32, height: u32) -> Simulation {
        let mut config = Config::preset("balanced").unwrap();
        config.world.width = width;
        config.world.height = height;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.ecology.plant_growth_per_tick_permille = 1;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        let mut sim = Simulation::new(&config);
        // Isolate feeding/movement accounting in this test-only fixture.
        sim.ecology_config.plant_growth_per_tick_permille = 0;
        sim
    }

    #[test]
    fn grazing_transfers_at_most_one_bite_and_zeroes_plant_before_death() {
        let mut sim = empty_sim(8, 8);
        let cell = Cell { x: 3, y: 3 };
        let genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
        let plant = sim
            .queue_birth(OrganismKind::Plant, cell, genome, [None, None], 0)
            .unwrap();
        let herb = sim
            .queue_birth(OrganismKind::Herbivore, cell, genome, [None, None], 0)
            .unwrap();
        sim.step_one_tick(); // commit staged setup organisms
        sim.set_organism_energy(plant, 20_000).unwrap();
        sim.set_organism_energy(herb, 1_000).unwrap();
        sim.step_one_tick();
        assert_eq!(sim.world.organism(plant).unwrap().energy(), 15_000);
        assert_eq!(
            sim.world.organism(herb).unwrap().energy(),
            5_000 + 1_000 - 100
        );
    }

    #[test]
    fn adjacent_toroidal_corner_feeding_respects_herbivore_capacity() {
        let mut sim = empty_sim(8, 8);
        let genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, u16::MAX, u16::MAX]);
        let herb = sim
            .queue_birth(
                OrganismKind::Herbivore,
                Cell { x: 0, y: 0 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        let plant = sim
            .queue_birth(
                OrganismKind::Plant,
                Cell { x: 7, y: 7 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        sim.step_one_tick();
        sim.set_organism_energy(herb, crate::MAX_ENERGY - 2_000)
            .unwrap();
        sim.set_organism_energy(plant, 10_000).unwrap();
        sim.feed_herbivores();
        let cost = animal::feeding_maintenance_cost(
            sim.world
                .current_climate(Cell { x: 0, y: 0 })
                .temperature_centi_c,
        );
        assert_eq!(sim.world.organism(plant).unwrap().energy(), 8_000);
        assert_eq!(
            sim.world.organism(herb).unwrap().energy(),
            crate::MAX_ENERGY - cost
        );
    }

    #[test]
    fn only_adjacent_plants_feed_and_depleted_source_is_removed() {
        let mut sim = empty_sim(20, 8);
        let genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
        let herb = sim
            .queue_birth(
                OrganismKind::Herbivore,
                Cell { x: 1, y: 1 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        let plant = sim
            .queue_birth(
                OrganismKind::Plant,
                Cell { x: 5, y: 1 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        sim.step_one_tick();
        sim.set_organism_energy(herb, 10_000).unwrap();
        sim.set_organism_energy(plant, 2_000).unwrap();
        sim.step_one_tick();
        let cost = animal::feeding_maintenance_cost(
            sim.world
                .current_climate(Cell { x: 1, y: 1 })
                .temperature_centi_c,
        );
        let after_first = sim.world.organism(herb).unwrap();
        let first_move = sim
            .world
            .grid()
            .distance(Cell { x: 1, y: 1 }, after_first.position);
        assert!(
            sim.world
                .grid()
                .distance(after_first.position, Cell { x: 5, y: 1 })
                > 1
        );
        let expected = 10_000 - first_move * animal::movement_cost_per_cell(0) - cost;
        assert_eq!(after_first.energy(), expected);
        assert!(sim.world.organism(plant).is_some());
        sim.move_organism(herb, Cell { x: 4, y: 1 }).unwrap();
        sim.set_organism_energy(plant, 2_000).unwrap();
        sim.step_one_tick();
        assert!(sim.world.organism(plant).is_none());
        let death = sim.world.death_history().last().unwrap();
        assert_eq!(death.organism.id, plant);
        assert_eq!(death.cause, DeathCause::Starvation);
        assert_eq!(
            sim.world.organism(herb).unwrap().energy(),
            expected + 2_000 - 100 - cost
        );
    }

    #[test]
    fn herbivores_pay_maintenance_and_climate_surcharge_can_starve_them() {
        let mut sim = empty_sim(3, 200);
        let cold_cell = Cell { x: 1, y: 0 };
        let cold_cost = animal::feeding_maintenance_cost(
            sim.world.current_climate(cold_cell).temperature_centi_c,
        );
        let genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
        let herb = sim
            .queue_birth(OrganismKind::Herbivore, cold_cell, genome, [None, None], 0)
            .unwrap();
        sim.step_one_tick();
        sim.set_organism_energy(herb, cold_cost).unwrap();
        sim.step_one_tick();
        assert!(sim.world.organism(herb).is_none());
        assert_eq!(
            sim.world.death_history().last().unwrap().cause,
            DeathCause::Starvation
        );
        assert!(cold_cost > animal::feeding_maintenance_cost(0));
    }

    #[test]
    fn foraging_genes_choose_different_targets_in_the_same_setup() {
        let run = |bias: u16| {
            let mut sim = empty_sim(15, 9);
            let near = Cell { x: 5, y: 4 };
            let rich = Cell { x: 8, y: 4 };
            let origin = Cell { x: 4, y: 4 };
            let plant_genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
            let near_id = sim
                .queue_birth(OrganismKind::Plant, near, plant_genome, [None, None], 0)
                .unwrap();
            let rich_id = sim
                .queue_birth(OrganismKind::Plant, rich, plant_genome, [None, None], 0)
                .unwrap();
            let herb = sim
                .queue_birth(
                    OrganismKind::Herbivore,
                    origin,
                    Genome::from_loci([u16::MAX, 0, u16::MAX, 0, 0, 0, bias, u16::MAX]),
                    [None, None],
                    0,
                )
                .unwrap();
            sim.step_one_tick();
            sim.set_organism_energy(near_id, 10_000).unwrap();
            sim.set_organism_energy(rich_id, 90_000).unwrap();
            sim.set_organism_energy(herb, 50_000).unwrap();
            sim.step_one_tick();
            let result = sim.world.organism(herb).unwrap().position;
            result
        };
        assert_eq!(run(0), Cell { x: 5, y: 4 });
        assert_eq!(run(u16::MAX), Cell { x: 8, y: 4 });
    }
}

#[cfg(test)]
mod animal_reproduction_tests {
    use super::*;

    fn empty_sim(seed: u64, carnivores: u32) -> Simulation {
        let mut config = Config::preset("balanced").unwrap();
        config.seed = seed;
        config.world.width = 1;
        config.world.height = 1;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = carnivores;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        config.genetics.mutation_probability_bp = 0;
        let mut sim = Simulation::new(&config);
        // Suppress plant-side resource effects; there are no plants in this fixture.
        sim.ecology_config.plant_growth_per_tick_permille = 0;
        sim
    }

    fn make_mature(sim: &mut Simulation) -> Vec<OrganismId> {
        let ids: Vec<_> = sim.world.organisms().map(|o| o.id).collect();
        for id in &ids {
            let parent = sim.world.organisms.get_mut(id).unwrap();
            parent.age = animal::ANIMAL_MATURITY_TICKS;
            parent.set_energy(100_000);
            parent.genome = Genome::from_loci([0, 0, u16::MAX, u16::MAX, 0, 0, 0, u16::MAX]);
            parent.traits = parent.genome.traits(parent.kind);
        }
        ids
    }

    #[test]
    fn one_animal_alone_never_produces_offspring() {
        let mut sim = empty_sim(12, 1);
        make_mature(&mut sim);
        sim.step_one_tick();
        assert_eq!(sim.world.count(OrganismKind::Carnivore), 1);
        assert_eq!(sim.world.lifecycle_counts().carnivores.births, 0);
    }

    #[test]
    fn successful_pair_records_lineage_generation_cost_and_cooldown() {
        let mut success = None;
        for seed in 0..100 {
            let mut sim = empty_sim(seed, 2);
            let ids = make_mature(&mut sim);
            let alternate = Genome::from_loci([
                8_000,
                8_000,
                u16::MAX,
                u16::MAX,
                8_000,
                8_000,
                8_000,
                u16::MAX,
            ]);
            let second = sim.world.organisms.get_mut(&ids[1]).unwrap();
            second.genome = alternate;
            second.traits = alternate.traits(second.kind);
            assert!(animal::genetically_compatible(
                sim.world.organism(ids[0]).unwrap().genome,
                sim.world.organism(ids[1]).unwrap().genome
            ));
            assert!(animal::reproduction_eligible(
                sim.world.organism(ids[0]).unwrap()
            ));
            assert!(animal::reproduction_eligible(
                sim.world.organism(ids[1]).unwrap()
            ));
            let before: Vec<_> = ids
                .iter()
                .map(|id| sim.world.organism(*id).unwrap().energy())
                .collect();
            sim.step_one_tick();
            if sim.world.count(OrganismKind::Carnivore) == 3 {
                success = Some((sim, ids, before));
                break;
            }
        }
        let (sim, ids, before) = success.expect("fixed seed sweep should include a mating");
        let child = sim
            .world
            .organisms()
            .find(|o| !ids.contains(&o.id))
            .unwrap();
        assert_eq!(child.parent_ids, [Some(ids[0]), Some(ids[1])]);
        assert_eq!(child.generation, 1);
        assert_eq!(child.age, 0);
        let first_genome = sim.world.organism(ids[0]).unwrap().genome;
        let second_genome = sim.world.organism(ids[1]).unwrap().genome;
        assert!(child
            .genome
            .loci()
            .iter()
            .zip(first_genome.loci().into_iter().zip(second_genome.loci()))
            .all(|(child, (first, second))| *child == first || *child == second));
        for (index, id) in ids.iter().enumerate() {
            let parent = sim.world.organism(*id).unwrap();
            // Carnivores pay 500 hunting maintenance and 20,000 reproduction cost.
            assert_eq!(parent.energy(), before[index] - 20_500);
            assert_eq!(
                parent.reproduction_cooldown,
                animal::ANIMAL_REPRODUCTION_COOLDOWN
            );
        }
    }

    #[test]
    fn fertility_probability_has_documented_endpoints_and_cooldown_blocks_mating() {
        assert_eq!(animal::reproduction_chance_bp(0), 500);
        assert_eq!(animal::reproduction_chance_bp(u16::MAX), 5_000);
        let mut sim = empty_sim(5, 2);
        let ids = make_mature(&mut sim);
        for id in &ids {
            sim.world
                .organisms
                .get_mut(id)
                .unwrap()
                .reproduction_cooldown = 3;
        }
        sim.step_one_tick();
        assert_eq!(sim.world.count(OrganismKind::Carnivore), 2);
        assert_eq!(sim.world.organism(ids[0]).unwrap().reproduction_cooldown, 2);

        let mut sim = empty_sim(5, 2);
        let ids = make_mature(&mut sim);
        for id in &ids {
            sim.world
                .organisms
                .get_mut(id)
                .unwrap()
                .reproduction_cooldown = 1;
        }
        sim.step_one_tick();
        assert_eq!(sim.world.count(OrganismKind::Carnivore), 2);
        assert_eq!(sim.world.organism(ids[0]).unwrap().reproduction_cooldown, 0);
    }

    #[test]
    fn configured_mutation_changes_the_crossed_animal_genome() {
        let mut matched = None;
        for seed in 0..100 {
            let mut sim = empty_sim(seed, 2);
            sim.genetics_config.mutation_probability_bp = 10_000;
            sim.genetics_config.mutation_step = 3;
            let ids = make_mature(&mut sim);
            let genome = Genome::from_loci([
                30_000, 30_000, 30_000, 30_000, 30_000, 30_000, 30_000, 30_000,
            ]);
            for id in &ids {
                let parent = sim.world.organisms.get_mut(id).unwrap();
                parent.genome = genome;
                parent.traits = genome.traits(parent.kind);
            }
            sim.step_one_tick();
            if sim.world.count(OrganismKind::Carnivore) == 3 {
                let child = sim
                    .world
                    .organisms()
                    .find(|o| !ids.contains(&o.id))
                    .unwrap();
                assert_ne!(child.genome, genome);
                assert_eq!(child.parent_ids, [Some(ids[0]), Some(ids[1])]);
                matched = Some(());
                break;
            }
        }
        assert!(
            matched.is_some(),
            "fixed seeds should include a successful mating"
        );
    }
}

#[cfg(test)]
mod hunting_tests {
    use super::*;
    use crate::{DeathCause, Genome};

    fn staged(seed: u64, hunters: usize, prey_energy: u32) -> (Simulation, Vec<u64>, u64) {
        let mut config = Config::preset("balanced").unwrap();
        config.seed = seed;
        config.world.width = 8;
        config.world.height = 8;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        config.genetics.mutation_probability_bp = 0;
        let mut sim = Simulation::new(&config);
        let hunter_genome = Genome::from_loci([0, u16::MAX, u16::MAX, 0, 0, u16::MAX, 0, u16::MAX]);
        let prey_genome = Genome::from_loci([0, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
        let hunters = (0..hunters)
            .map(|_| {
                sim.queue_birth(
                    OrganismKind::Carnivore,
                    Cell { x: 0, y: 0 },
                    hunter_genome,
                    [None, None],
                    0,
                )
                .unwrap()
            })
            .collect::<Vec<_>>();
        let prey = sim
            .queue_birth(
                OrganismKind::Herbivore,
                Cell { x: 7, y: 0 },
                prey_genome,
                [None, None],
                0,
            )
            .unwrap();
        sim.step_one_tick();
        sim.set_organism_energy(prey, prey_energy).unwrap();
        for id in &hunters {
            sim.set_organism_energy(*id, 20_000).unwrap();
        }
        // Restore adjacent placement after movement and isolate the feeding slot.
        for id in &hunters {
            sim.move_organism(*id, Cell { x: 0, y: 0 }).unwrap();
        }
        sim.move_organism(prey, Cell { x: 7, y: 0 }).unwrap();
        (sim, hunters, prey)
    }

    #[test]
    fn seeded_trait_based_attacks_include_kills_and_escapes() {
        let (mut kills, mut escapes) = (0, 0);
        for seed in 1..=100 {
            let (mut sim, hunters, prey) = staged(seed, 1, 12_345);
            let energy = sim.world.organism(hunters[0]).unwrap().energy();
            sim.hunt_herbivores();
            if sim.world.is_pending_death(prey) {
                kills += 1;
            } else {
                escapes += 1;
                assert_eq!(
                    sim.world.organism(hunters[0]).unwrap().energy(),
                    energy - 500
                );
                assert_eq!(sim.world.organism(hunters[0]).unwrap().hunting_cooldown, 0);
            }
        }
        assert!(kills > 0, "no attacks killed prey");
        assert!(escapes > 0, "no attacks missed");
    }

    #[test]
    fn attack_is_toroidally_adjacent_once_and_energy_is_bounded() {
        let mut found = None;
        for seed in 1..=100 {
            let (mut sim, hunters, prey) = staged(seed, 2, 7_000);
            let before = sim.world.organism(hunters[0]).unwrap().energy();
            sim.hunt_herbivores();
            if sim.world.is_pending_death(prey) {
                found = Some((sim, hunters, prey, before));
                break;
            }
        }
        let (mut sim, hunters, prey, before) = found.expect("seed sweep should include a kill");
        assert!(sim.world.is_pending_death(prey));
        assert_eq!(
            sim.world.organism(hunters[0]).unwrap().energy(),
            before + 6_500
        );
        assert_eq!(
            sim.world.organism(hunters[0]).unwrap().hunting_cooldown,
            animal::CARNIVORE_HANDLING_TICKS
        );
        assert_eq!(sim.world.organism(hunters[1]).unwrap().energy(), 19_500);
        sim.world.age_live();
        sim.world.resolve_deaths(sim.tick);
        assert_eq!(
            sim.world
                .death_history()
                .iter()
                .filter(|d| d.organism.id == prey)
                .count(),
            1
        );
        assert_eq!(
            sim.world
                .death_history()
                .iter()
                .find(|d| d.organism.id == prey)
                .unwrap()
                .cause,
            DeathCause::Predation
        );

        let (mut capped, hunters, _) = staged(12, 1, 7_000);
        capped
            .set_organism_energy(hunters[0], crate::MAX_ENERGY - 200)
            .unwrap();
        capped.hunt_herbivores();
        assert!(capped.world.organism(hunters[0]).unwrap().energy() <= crate::MAX_ENERGY - 300);

        // A zero energy hunter pays the full hunting cost and is queued for starvation.
        let (mut no_prey, hunters, _) = staged(5, 1, 12_345);
        no_prey.set_organism_energy(hunters[0], 400).unwrap();
        no_prey
            .move_organism(hunters[0], Cell { x: 4, y: 4 })
            .unwrap();
        no_prey.hunt_herbivores();
        assert_eq!(no_prey.world.organism(hunters[0]).unwrap().energy(), 0);
        assert_eq!(
            no_prey.world.organism(hunters[0]).unwrap().hunting_cooldown,
            0
        );
        assert!(no_prey.world.is_pending_death(hunters[0]));
    }

    #[test]
    fn successful_kill_blocks_attacks_during_handling_and_still_costs_energy() {
        let mut observed_kill_after_handling = false;
        for seed in 1..=100 {
            let (mut sim, hunters, prey) = staged(seed, 1, 12_345);
            let hunter = hunters[0];
            sim.world
                .organisms
                .get_mut(&hunter)
                .unwrap()
                .hunting_cooldown = 1;
            let energy = sim.world.organism(hunter).unwrap().energy();

            sim.hunt_herbivores();
            assert!(!sim.world.is_pending_death(prey));
            assert_eq!(sim.world.organism(hunter).unwrap().hunting_cooldown, 0);
            assert_eq!(sim.world.organism(hunter).unwrap().energy(), energy - 500);

            sim.hunt_herbivores();
            if sim.world.is_pending_death(prey) {
                assert_eq!(
                    sim.world.organism(hunter).unwrap().hunting_cooldown,
                    animal::CARNIVORE_HANDLING_TICKS
                );
                observed_kill_after_handling = true;
                break;
            }
        }
        assert!(
            observed_kill_after_handling,
            "seed sweep should include a kill"
        );
    }
}

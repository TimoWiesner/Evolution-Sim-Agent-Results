//! Read-only, deterministic summaries of simulation state at a sampled tick.
use crate::{DeathCause, Organism, OrganismKind, Simulation, Traits};
use serde::Serialize;

#[derive(Clone, Debug, Serialize)]
pub struct MetricsSample {
    pub tick: u64,
    pub population: Counts,
    pub births: Counts,
    pub deaths: Counts,
    pub living_species: Counts,
    pub deaths_by_cause: CauseCounts,
    pub traits: KindTraits,
    pub generation: KindGeneration,
}

#[derive(Clone, Debug, Serialize)]
pub struct Counts {
    pub plants: u64,
    pub herbivores: u64,
    pub carnivores: u64,
}
#[derive(Clone, Debug, Serialize)]
pub struct CauseCounts {
    pub plants: Causes,
    pub herbivores: Causes,
    pub carnivores: Causes,
}
#[derive(Clone, Debug, Default, Serialize)]
pub struct Causes {
    pub starvation: u64,
    pub predation: u64,
    pub age: u64,
    pub climate: u64,
    pub injury: u64,
    pub other: u64,
}
#[derive(Clone, Debug, Serialize)]
pub struct KindTraits {
    pub plants: TraitSummary,
    pub herbivores: TraitSummary,
    pub carnivores: TraitSummary,
}
#[derive(Clone, Debug, Serialize)]
pub struct TraitSummary {
    pub speed: Option<Spread>,
    pub strength: Option<Spread>,
    pub fertility: Option<Spread>,
    pub max_health: Option<Spread>,
    pub max_lifespan_ticks: Option<Spread>,
    pub risk_tolerance: Option<Spread>,
    pub aggression: Option<Spread>,
    pub foraging_bias: Option<Spread>,
}
#[derive(Clone, Copy, Debug, PartialEq, Serialize)]
pub struct Spread {
    pub mean: f64,
    pub standard_deviation: f64,
}
#[derive(Clone, Debug, Serialize)]
pub struct KindGeneration {
    pub plants: Generation,
    pub herbivores: Generation,
    pub carnivores: Generation,
}
#[derive(Clone, Copy, Debug, Serialize)]
pub struct Generation {
    pub highest: Option<u64>,
    pub mean: Option<f64>,
}

impl MetricsSample {
    pub fn capture(sim: &Simulation) -> Self {
        let world = sim.world();
        let lifecycle = world.lifecycle_counts();
        let births = Counts {
            plants: lifecycle.plants.births,
            herbivores: lifecycle.herbivores.births,
            carnivores: lifecycle.carnivores.births,
        };
        let deaths = Counts {
            plants: lifecycle.plants.deaths,
            herbivores: lifecycle.herbivores.deaths,
            carnivores: lifecycle.carnivores.deaths,
        };
        let population = Counts {
            plants: world.count(OrganismKind::Plant) as u64,
            herbivores: world.count(OrganismKind::Herbivore) as u64,
            carnivores: world.count(OrganismKind::Carnivore) as u64,
        };
        let living_species = Counts {
            plants: world.living_species_count(OrganismKind::Plant) as u64,
            herbivores: world.living_species_count(OrganismKind::Herbivore) as u64,
            carnivores: world.living_species_count(OrganismKind::Carnivore) as u64,
        };
        let mut deaths_by_cause = CauseCounts {
            plants: Causes::default(),
            herbivores: Causes::default(),
            carnivores: Causes::default(),
        };
        for record in world.death_history() {
            let causes = match record.organism.kind {
                OrganismKind::Plant => &mut deaths_by_cause.plants,
                OrganismKind::Herbivore => &mut deaths_by_cause.herbivores,
                OrganismKind::Carnivore => &mut deaths_by_cause.carnivores,
            };
            *match record.cause {
                DeathCause::Starvation => &mut causes.starvation,
                DeathCause::Predation => &mut causes.predation,
                DeathCause::Age => &mut causes.age,
                DeathCause::Climate => &mut causes.climate,
                DeathCause::Injury => &mut causes.injury,
                DeathCause::Other => &mut causes.other,
            } += 1;
        }
        let organisms: Vec<_> = world.organisms().collect();
        let by_kind = |kind| {
            organisms
                .iter()
                .copied()
                .filter(|o| o.kind == kind)
                .collect::<Vec<_>>()
        };
        let plants = by_kind(OrganismKind::Plant);
        let herbivores = by_kind(OrganismKind::Herbivore);
        let carnivores = by_kind(OrganismKind::Carnivore);
        Self {
            tick: sim.tick(),
            population,
            births,
            deaths,
            living_species,
            deaths_by_cause,
            traits: KindTraits {
                plants: summarize_traits(&plants),
                herbivores: summarize_traits(&herbivores),
                carnivores: summarize_traits(&carnivores),
            },
            generation: KindGeneration {
                plants: summarize_generation(&plants),
                herbivores: summarize_generation(&herbivores),
                carnivores: summarize_generation(&carnivores),
            },
        }
    }
}

fn spread(values: impl Iterator<Item = u16>, count: usize) -> Option<Spread> {
    if count == 0 {
        return None;
    }
    let (sum, squares) = values.fold((0_u128, 0_u128), |(s, q), v| {
        let v = u128::from(v);
        (s + v, q + v * v)
    });
    let n = count as f64;
    let mean = sum as f64 / n;
    Some(Spread {
        mean,
        standard_deviation: ((squares as f64 / n - mean * mean).max(0.0)).sqrt(),
    })
}
fn summarize_traits(orgs: &[&Organism]) -> TraitSummary {
    let n = orgs.len();
    let field = |f: fn(&Traits) -> Option<u16>| {
        let values: Vec<_> = orgs.iter().filter_map(|o| f(&o.traits)).collect();
        spread(values.iter().copied(), values.len())
    };
    TraitSummary {
        speed: spread(orgs.iter().map(|o| o.traits.speed), n),
        strength: spread(orgs.iter().map(|o| o.traits.strength), n),
        fertility: spread(orgs.iter().map(|o| o.traits.fertility), n),
        max_health: spread(orgs.iter().map(|o| o.traits.max_health), n),
        max_lifespan_ticks: spread(orgs.iter().map(|o| o.traits.max_lifespan_ticks), n),
        risk_tolerance: field(|t| t.risk_tolerance),
        aggression: field(|t| t.aggression),
        foraging_bias: field(|t| t.foraging_bias),
    }
}
fn summarize_generation(orgs: &[&Organism]) -> Generation {
    if orgs.is_empty() {
        return Generation {
            highest: None,
            mean: None,
        };
    }
    Generation {
        highest: orgs.iter().map(|o| o.generation).max(),
        mean: Some(
            orgs.iter().map(|o| o.generation as u128).sum::<u128>() as f64 / orgs.len() as f64,
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Config;
    #[test]
    fn metrics_are_hand_checkable_and_do_not_change_state_hash() {
        let config=Config::from_json(r#"{"seed":7,"world":{"width":2,"height":1},"initial":{"plants":2,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(&config);
        for (id, speed, generation) in [(1, 10, 2), (2, 14, 4)] {
            let organism = sim.world_mut().organisms.get_mut(&id).unwrap();
            organism.genome = crate::Genome::from_loci([speed, 0, 100, 20, 0, 0, 0, 200]);
            organism.traits = organism.genome.traits(OrganismKind::Plant);
            organism.generation = generation;
        }
        let hash = sim.state_hash().unwrap();
        let m = MetricsSample::capture(&sim);
        assert_eq!(hash, sim.state_hash().unwrap());
        assert_eq!(
            (
                m.population.plants,
                m.population.herbivores,
                m.population.carnivores
            ),
            (2, 0, 0)
        );
        assert_eq!(
            (
                m.births.plants,
                m.deaths.plants,
                m.living_species.carnivores
            ),
            (0, 0, 0)
        );
        assert_eq!(m.deaths_by_cause.plants.starvation, 0);
        assert_eq!(m.traits.plants.speed.unwrap().mean, 12.0);
        assert_eq!(m.traits.plants.speed.unwrap().standard_deviation, 2.0);
        assert_eq!(m.traits.plants.aggression, None);
        assert_eq!(m.generation.carnivores.mean, None);
        assert_eq!(m.generation.plants.highest, Some(4));
        assert_eq!(m.generation.plants.mean, Some(3.0));
    }

    #[test]
    fn repeated_observation_does_not_change_future_seeded_simulation() {
        let config=Config::from_json(r#"{"seed":41,"world":{"width":4,"height":3},"initial":{"plants":8,"herbivores":2,"carnivores":1}}"#).unwrap();
        let mut observed = Simulation::new(&config);
        let mut unobserved = Simulation::new(&config);
        for _ in 0..12 {
            let _ = MetricsSample::capture(&observed);
            observed.step_one_tick();
            unobserved.step_one_tick();
        }
        assert_eq!(
            observed.state_hash().unwrap(),
            unobserved.state_hash().unwrap()
        );
    }

    #[test]
    fn death_causes_are_partitioned_by_kind_and_cumulative_count() {
        let config=Config::from_json(r#"{"seed":7,"world":{"width":6,"height":1},"initial":{"plants":6,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(&config);
        for (id, cause) in [
            DeathCause::Starvation,
            DeathCause::Predation,
            DeathCause::Age,
            DeathCause::Climate,
            DeathCause::Injury,
            DeathCause::Other,
        ]
        .into_iter()
        .enumerate()
        {
            assert!(sim.queue_death(id as u64 + 1, cause));
        }
        sim.step_one_tick();
        let m = MetricsSample::capture(&sim);
        assert_eq!(m.deaths.plants, 6);
        assert_eq!(
            (
                m.deaths_by_cause.plants.starvation,
                m.deaths_by_cause.plants.predation,
                m.deaths_by_cause.plants.age,
                m.deaths_by_cause.plants.climate,
                m.deaths_by_cause.plants.injury,
                m.deaths_by_cause.plants.other
            ),
            (1, 1, 1, 1, 1, 1)
        );
        assert_eq!(m.deaths_by_cause.herbivores.predation, 0);
    }
}

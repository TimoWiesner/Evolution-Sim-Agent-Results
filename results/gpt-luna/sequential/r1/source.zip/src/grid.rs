//! Integer geometry for a finite rectangular world with wrapping edges.

use serde::{Deserialize, Serialize};
use std::collections::HashSet;

/// A valid cell. `x` is the column and `y` is the row.
#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, Serialize, Deserialize)]
pub struct Cell {
    pub x: u32,
    pub y: u32,
}

/// A shortest signed displacement from one cell to another.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Direction {
    pub x: i32,
    pub y: i32,
}

/// Grid dimensions and toroidal geometry operations.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Grid {
    width: u32,
    height: u32,
}

impl Grid {
    /// Construct a grid. Both dimensions must be nonzero.
    pub fn new(width: u32, height: u32) -> Result<Self, GridError> {
        if width == 0 || height == 0 {
            return Err(GridError);
        }
        Ok(Self { width, height })
    }

    pub fn width(self) -> u32 {
        self.width
    }
    pub fn height(self) -> u32 {
        self.height
    }

    /// Map any signed coordinate pair onto a valid cell.
    pub fn wrap(self, x: i64, y: i64) -> Cell {
        Cell {
            x: x.rem_euclid(i64::from(self.width)) as u32,
            y: y.rem_euclid(i64::from(self.height)) as u32,
        }
    }

    /// Return the shortest signed direction from `from` to `to`.
    /// Exact antipodal ties on even axes use the negative direction.
    pub fn direction(self, from: Cell, to: Cell) -> Direction {
        Direction {
            x: shortest_axis(from.x, to.x, self.width),
            y: shortest_axis(from.y, to.y, self.height),
        }
    }

    /// Toroidal Chebyshev distance, in cell steps.
    pub fn distance(self, a: Cell, b: Cell) -> u32 {
        let d = self.direction(a, b);
        d.x.unsigned_abs().max(d.y.unsigned_abs())
    }

    /// List all cells within inclusive toroidal Chebyshev `radius`, in row-major order.
    pub fn neighborhood(self, center: Cell, radius: u32) -> Vec<Cell> {
        let max_distance = (self.width / 2).max(self.height / 2);
        if radius >= max_distance {
            return (0..self.height)
                .flat_map(|y| (0..self.width).map(move |x| Cell { x, y }))
                .collect();
        }

        let r = i64::from(radius);
        let mut unique = HashSet::new();
        for dy in -r..=r {
            for dx in -r..=r {
                unique.insert(self.wrap(i64::from(center.x) + dx, i64::from(center.y) + dy));
            }
        }
        let mut cells: Vec<_> = unique.into_iter().collect();
        cells.sort_unstable_by_key(|cell| (cell.y, cell.x));
        cells
    }
}

fn shortest_axis(from: u32, to: u32, size: u32) -> i32 {
    let forward = (u64::from(to) + u64::from(size) - u64::from(from)) % u64::from(size);
    if forward * 2 >= u64::from(size) {
        (forward as i64 - i64::from(size)) as i32
    } else {
        forward as i32
    }
}

/// Error returned for invalid grid dimensions.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct GridError;

impl std::fmt::Display for GridError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("grid dimensions must be nonzero")
    }
}

impl std::error::Error for GridError {}

#[cfg(test)]
mod tests {
    use super::*;

    fn grid(w: u32, h: u32) -> Grid {
        Grid::new(w, h).unwrap()
    }

    #[test]
    fn wraps_all_edges_corners_negative_and_multiple_worlds() {
        let g = grid(5, 3);
        // Cross each cardinal edge independently while keeping the other axis in range.
        assert_eq!(g.wrap(-1, 1), Cell { x: 4, y: 1 });
        assert_eq!(g.wrap(5, 1), Cell { x: 0, y: 1 });
        assert_eq!(g.wrap(2, -1), Cell { x: 2, y: 2 });
        assert_eq!(g.wrap(2, 3), Cell { x: 2, y: 0 });

        // Cross both axes at corners in opposite diagonal directions.
        assert_eq!(g.wrap(-1, -1), Cell { x: 4, y: 2 });
        assert_eq!(g.wrap(5, 3), Cell { x: 0, y: 0 });
        assert_eq!(g.wrap(11, 7), Cell { x: 1, y: 1 });
        assert_eq!(g.wrap(-11, -7), Cell { x: 4, y: 2 });
        assert_eq!(g.wrap(4, 1), Cell { x: 4, y: 1 });
        assert_eq!(g.wrap(0, 1), Cell { x: 0, y: 1 });
        assert_eq!(g.wrap(2, 2), Cell { x: 2, y: 2 });
        assert_eq!(g.wrap(0, 0), Cell { x: 0, y: 0 });
    }

    #[test]
    fn direction_distance_and_even_ties_are_shortest_on_both_axes() {
        let g = grid(8, 6);
        let d = g.direction(Cell { x: 7, y: 5 }, Cell { x: 0, y: 0 });
        assert_eq!(d, Direction { x: 1, y: 1 });
        assert_eq!(g.distance(Cell { x: 7, y: 5 }, Cell { x: 0, y: 0 }), 1);
        assert_eq!(
            g.direction(Cell { x: 0, y: 0 }, Cell { x: 4, y: 3 }),
            Direction { x: -4, y: -3 }
        );
        let rect = grid(7, 4);
        assert_eq!(
            rect.direction(Cell { x: 0, y: 0 }, Cell { x: 6, y: 3 }),
            Direction { x: -1, y: -1 }
        );
    }

    #[test]
    fn neighborhoods_are_unique_row_major_and_match_brute_force_oracle() {
        for width in 1..=8 {
            for height in 1..=7 {
                let g = grid(width, height);
                for y in 0..height {
                    for x in 0..width {
                        let center = Cell { x, y };
                        for radius in 0..=10 {
                            let actual = g.neighborhood(center, radius);
                            let mut expected: Vec<_> = (0..height)
                                .flat_map(|cy| (0..width).map(move |cx| Cell { x: cx, y: cy }))
                                .filter(|cell| g.distance(center, *cell) <= radius)
                                .collect();
                            expected.sort_unstable_by_key(|cell| (cell.y, cell.x));
                            assert_eq!(
                                actual, expected,
                                "{width}x{height} at {center:?}, r={radius}"
                            );
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn degenerate_dimensions_and_invalid_dimensions() {
        let one = grid(1, 1);
        assert_eq!(
            one.neighborhood(Cell { x: 0, y: 0 }, 0),
            vec![Cell { x: 0, y: 0 }]
        );
        assert_eq!(
            one.direction(Cell { x: 0, y: 0 }, Cell { x: 0, y: 0 }),
            Direction { x: 0, y: 0 }
        );
        let line = grid(1, 5);
        assert_eq!(
            line.direction(Cell { x: 0, y: 0 }, Cell { x: 0, y: 4 }),
            Direction { x: 0, y: -1 }
        );
        assert_eq!(line.neighborhood(Cell { x: 0, y: 0 }, 20).len(), 5);
        assert!(Grid::new(0, 1).is_err());
        assert!(Grid::new(1, 0).is_err());
    }
}

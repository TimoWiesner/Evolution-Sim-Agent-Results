//! Initial world container; domain state is added by later tasks.
use crate::climate::{format_biome_map, seasonal, Climate};
use crate::config::ClimateConfig;
use crate::entity::{
    DeathCause, DeathRecord, LifecycleCounts, Organism, OrganismId, OrganismKind, SpeciesId,
};
use crate::grid::{Cell, Grid};
use crate::spatial_index::SpatialIndex;
use crate::DeterministicRng;
use crate::Genome;
use serde::{Deserialize, Serialize};
use std::collections::{BTreeMap, HashSet};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct WeatherDeviation {
    pub temperature_centi_c: i16,
    pub precipitation: i16,
}

pub const SPECIES_DISTANCE_THRESHOLD: u32 = 65_536;

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct SpeciesRecord {
    pub id: SpeciesId,
    pub name: String,
    pub kind: OrganismKind,
    pub representative: Genome,
    pub parent_species_id: Option<SpeciesId>,
    pub arose_at_tick: u64,
    pub extinct_at_tick: Option<u64>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct World {
    grid: Grid,
    climate: Vec<Climate>,
    current_climate: Vec<Climate>,
    weather: Vec<WeatherDeviation>,
    soil_water: Vec<u32>,
    resource_capacity: u32,
    pub(crate) organisms: BTreeMap<OrganismId, Organism>,
    spatial_index: SpatialIndex,
    next_organism_id: OrganismId,
    pending_births: BTreeMap<OrganismId, Organism>,
    pending_deaths: BTreeMap<OrganismId, DeathCause>,
    death_history: Vec<DeathRecord>,
    lifecycle: LifecycleCounts,
    species: BTreeMap<SpeciesId, SpeciesRecord>,
    next_species_id: SpeciesId,
    current_tick: u64,
}

impl World {
    pub(crate) fn resource_capacity(&self) -> u32 {
        self.resource_capacity
    }
    pub(crate) fn restore(grid: Grid, state: WorldClimateState) -> Result<Self, String> {
        let cells = (grid.width() as usize)
            .checked_mul(grid.height() as usize)
            .ok_or("world dimensions overflow")?;
        if state.base_climate.len() != cells
            || state.current_climate.len() != cells
            || state.weather.len() != cells
            || state.soil_water.len() != cells
        {
            return Err("checkpoint climate/resource vector length mismatch".into());
        }
        if state.resource_capacity == 0
            || state
                .soil_water
                .iter()
                .any(|v| *v > state.resource_capacity)
        {
            return Err("checkpoint has invalid soil-water values".into());
        }
        let WorldClimateState {
            base_climate,
            current_climate,
            soil_water,
            weather,
            organisms,
            next_organism_id,
            pending_births,
            pending_deaths,
            death_history,
            lifecycle,
            species,
            next_species_id,
            resource_capacity,
            current_tick,
        } = state;
        let mut world = Self::from_grid_with_resource_capacity(grid, resource_capacity);
        world.climate = base_climate;
        world.current_climate = current_climate;
        world.weather = weather;
        world.soil_water = soil_water;
        let live_len = organisms.len();
        world.organisms = organisms.into_iter().map(|o| (o.id, o)).collect();
        world.next_organism_id = next_organism_id;
        let pending_len = pending_births.len();
        world.pending_births = pending_births.into_iter().map(|o| (o.id, o)).collect();
        let pending_death_len = pending_deaths.len();
        world.pending_deaths = pending_deaths.into_iter().collect();
        let species_len = species.len();
        world.death_history = death_history;
        world.lifecycle = lifecycle;
        world.species = species.into_iter().map(|s| (s.id, s)).collect();
        world.next_species_id = next_species_id;
        world.current_tick = current_tick;
        if world.organisms.len() != live_len
            || world.pending_births.len() != pending_len
            || world.pending_deaths.len() != pending_death_len
            || world.species.len() != species_len
        {
            return Err("checkpoint contains duplicate organism IDs".into());
        }
        let mut ids = std::collections::BTreeSet::new();
        let max_id = world
            .organisms
            .values()
            .chain(world.pending_births.values())
            .map(|o| o.id)
            .chain(world.death_history.iter().map(|d| d.organism.id))
            .max()
            .unwrap_or(0);
        let max_species = world.species.keys().copied().max().unwrap_or(0);
        if world.next_organism_id <= max_id
            || world.next_species_id <= max_species
            || world.current_tick > u64::MAX - 1
        {
            return Err("checkpoint allocator or tick is invalid".into());
        }
        let known_species: std::collections::BTreeSet<_> = world.species.keys().copied().collect();
        for organism in world
            .organisms
            .values()
            .chain(world.pending_births.values())
        {
            if organism.id == 0
                || !ids.insert(organism.id)
                || organism.position.x >= grid.width()
                || organism.position.y >= grid.height()
                || organism.energy() > crate::MAX_ENERGY
                || organism.health() > u32::from(organism.traits.max_health).min(crate::MAX_HEALTH)
                || organism.traits != organism.genome.traits(organism.kind)
                || !organism.traits.valid_for(organism.kind)
                || !known_species.contains(&organism.species_id)
            {
                return Err("checkpoint contains an invalid organism".into());
            }
        }
        for record in &world.death_history {
            if record.organism.id == 0
                || !ids.insert(record.organism.id)
                || record.tick > current_tick
                || record.organism.position.x >= grid.width()
                || record.organism.position.y >= grid.height()
                || !known_species.contains(&record.organism.species_id)
            {
                return Err("checkpoint contains an invalid death record".into());
            }
        }
        if world
            .pending_deaths
            .keys()
            .any(|id| !world.organisms.contains_key(id))
        {
            return Err("checkpoint pending death references missing organism".into());
        }
        for (kind, counts) in [
            (OrganismKind::Plant, lifecycle.plants),
            (OrganismKind::Herbivore, lifecycle.herbivores),
            (OrganismKind::Carnivore, lifecycle.carnivores),
        ] {
            let live = world.count(kind) as u64;
            if counts
                .initial
                .checked_add(counts.births)
                .and_then(|n| n.checked_sub(counts.deaths))
                != Some(live)
                || world
                    .death_history
                    .iter()
                    .filter(|d| d.organism.kind == kind)
                    .count() as u64
                    != counts.deaths
            {
                return Err(
                    "checkpoint lifecycle counters do not match history and population".into(),
                );
            }
        }
        for record in world.species.values() {
            if record.id == 0
                || record.arose_at_tick > current_tick
                || record.extinct_at_tick.is_some_and(|t| t > current_tick)
                || record
                    .parent_species_id
                    .is_some_and(|id| !known_species.contains(&id))
            {
                return Err("checkpoint contains an invalid species record".into());
            }
            let has_member = world.organisms.values().any(|o| o.species_id == record.id)
                || world
                    .pending_births
                    .values()
                    .any(|o| o.species_id == record.id);
            if has_member == record.extinct_at_tick.is_some() {
                return Err("checkpoint species extinction state is inconsistent".into());
            }
        }
        for organism in world.organisms.values() {
            world
                .spatial_index
                .insert(grid, organism.position, organism.id);
        }
        for organism in world.pending_births.values() {
            if organism.id >= world.next_organism_id || organism.species_id == 0 {
                return Err("checkpoint pending birth is invalid".into());
            }
        }
        Ok(world)
    }
    pub fn new(width: u32, height: u32) -> Result<Self, crate::grid::GridError> {
        Ok(Self::from_grid(Grid::new(width, height)?))
    }
    pub fn from_grid(grid: Grid) -> Self {
        Self::from_grid_with_resource_capacity(grid, 1000)
    }
    pub(crate) fn from_grid_with_resource_capacity(grid: Grid, resource_capacity: u32) -> Self {
        let climate: Vec<Climate> = (0..grid.height())
            .flat_map(|y| (0..grid.width()).map(move |x| Climate::at(grid, Cell { x, y })))
            .collect();
        Self {
            grid,
            current_climate: climate.clone(),
            weather: vec![
                WeatherDeviation {
                    temperature_centi_c: 0,
                    precipitation: 0
                };
                climate.len()
            ],
            climate,
            soil_water: vec![resource_capacity; (grid.width() * grid.height()) as usize],
            resource_capacity,
            organisms: BTreeMap::new(),
            spatial_index: SpatialIndex::new(grid),
            next_organism_id: 1,
            pending_births: BTreeMap::new(),
            pending_deaths: BTreeMap::new(),
            death_history: Vec::new(),
            lifecycle: LifecycleCounts::default(),
            species: BTreeMap::new(),
            next_species_id: 1,
            current_tick: 0,
        }
    }
    pub fn grid(&self) -> Grid {
        self.grid
    }

    pub fn soil_water(&self, cell: Cell) -> u32 {
        self.soil_water[(cell.y * self.grid.width() + cell.x) as usize]
    }

    /// Whether a plant can establish at this cell, including births already
    /// staged for this tick. The limit is local to the destination cell.
    pub(crate) fn can_establish_plant(&self, cell: Cell) -> bool {
        if cell.x >= self.grid.width() || cell.y >= self.grid.height() || self.soil_water(cell) == 0
        {
            return false;
        }
        let live = self
            .spatial_index
            .ids_in(self.grid, cell)
            .iter()
            .filter(|id| {
                self.organisms
                    .get(id)
                    .is_some_and(|o| o.kind == OrganismKind::Plant)
            })
            .count();
        let pending = self
            .pending_births
            .values()
            .filter(|o| o.kind == OrganismKind::Plant && o.position == cell)
            .count();
        live + pending < 4
    }

    pub(crate) fn replenish_soil_water(&mut self) {
        for (water, climate) in self.soil_water.iter_mut().zip(&self.current_climate) {
            let amount = (u64::from(climate.precipitation) * u64::from(self.resource_capacity)
                + 99_999)
                / 100_000;
            *water = water
                .saturating_add(amount as u32)
                .min(self.resource_capacity);
        }
    }

    pub(crate) fn consume_soil_water(&mut self, cell: Cell, amount: u32) -> u32 {
        let index = (cell.y * self.grid.width() + cell.x) as usize;
        let consumed = amount.min(self.soil_water[index]);
        self.soil_water[index] -= consumed;
        consumed
    }

    pub fn set_organism_energy(&mut self, id: OrganismId, energy: u32) -> Result<(), &'static str> {
        self.organisms
            .get_mut(&id)
            .ok_or("organism not found")?
            .set_energy(energy);
        Ok(())
    }

    pub fn organisms(&self) -> impl Iterator<Item = &Organism> {
        self.organisms.values()
    }
    pub fn organism(&self, id: OrganismId) -> Option<&Organism> {
        self.organisms.get(&id)
    }
    pub fn death_history(&self) -> &[DeathRecord] {
        &self.death_history
    }
    pub fn lifecycle_counts(&self) -> LifecycleCounts {
        self.lifecycle
    }

    pub fn species(&self) -> impl Iterator<Item = &SpeciesRecord> {
        self.species.values()
    }
    pub fn living_species_count(&self, kind: OrganismKind) -> usize {
        self.species
            .values()
            .filter(|s| s.kind == kind && s.extinct_at_tick.is_none())
            .count()
    }

    pub(crate) fn is_pending_death(&self, id: OrganismId) -> bool {
        self.pending_deaths.contains_key(&id)
    }
    pub fn count(&self, kind: OrganismKind) -> usize {
        self.organisms.values().filter(|o| o.kind == kind).count()
    }

    /// Return organisms within inclusive toroidal Chebyshev radius, ordered by ID.
    /// An invalid center cell has no occupants and returns an empty result.
    pub fn organisms_within(
        &self,
        center: Cell,
        radius: u32,
        kind: Option<OrganismKind>,
    ) -> Vec<&Organism> {
        if center.x >= self.grid.width() || center.y >= self.grid.height() {
            return Vec::new();
        }
        let mut ids: Vec<_> = self
            .grid
            .neighborhood(center, radius)
            .into_iter()
            .flat_map(|cell| self.spatial_index.ids_in(self.grid, cell).iter().copied())
            .collect();
        ids.sort_unstable();
        ids.into_iter()
            .filter_map(|id| self.organisms.get(&id))
            .filter(|organism| kind.is_none_or(|wanted| organism.kind == wanted))
            .collect()
    }

    /// Move an organism to a valid cell, updating canonical position and index together.
    pub fn move_organism(&mut self, id: OrganismId, destination: Cell) -> Result<(), &'static str> {
        if destination.x >= self.grid.width() || destination.y >= self.grid.height() {
            return Err("destination outside world");
        }
        let organism = self.organisms.get(&id).ok_or("organism not found")?;
        let from = organism.position;
        self.spatial_index.move_id(self.grid, from, destination, id);
        self.organisms
            .get_mut(&id)
            .expect("organism checked above")
            .position = destination;
        Ok(())
    }

    pub(crate) fn initialize_organism(
        &mut self,
        kind: OrganismKind,
        position: Cell,
        genome: Genome,
    ) {
        let id = self.allocate_id();
        let species_id = self.assign_species(kind, genome, None, 0);
        let organism = Organism::new(id, kind, position, genome, [None, None], 0, species_id);
        self.spatial_index.insert(self.grid, position, id);
        self.organisms.insert(id, organism);
        self.lifecycle.kind_mut(kind).initial += 1;
    }

    pub(crate) fn queue_birth(
        &mut self,
        kind: OrganismKind,
        position: Cell,
        genome: Genome,
        parents: [Option<OrganismId>; 2],
        generation: u64,
    ) -> Result<OrganismId, &'static str> {
        if position.x >= self.grid.width() || position.y >= self.grid.height() {
            return Err("position outside world");
        }
        let id = self.allocate_id();
        let parent_species = parents
            .iter()
            .flatten()
            .find_map(|parent| self.organisms.get(parent).map(|o| o.species_id));
        let species_id = self.assign_species(kind, genome, parent_species, self.current_tick);
        self.pending_births.insert(
            id,
            Organism::new(id, kind, position, genome, parents, generation, species_id),
        );
        Ok(id)
    }
    pub(crate) fn queue_death(&mut self, id: OrganismId, cause: DeathCause) -> bool {
        if !self.organisms.contains_key(&id) {
            return false;
        }
        self.pending_deaths.entry(id).or_insert(cause);
        true
    }
    pub(crate) fn resolve_deaths(&mut self, tick: u64) {
        let deaths = std::mem::take(&mut self.pending_deaths);
        for (id, cause) in deaths {
            if let Some(organism) = self.organisms.remove(&id) {
                self.spatial_index.remove(self.grid, organism.position, id);
                self.lifecycle.kind_mut(organism.kind).deaths += 1;
                self.death_history.push(DeathRecord {
                    organism,
                    tick,
                    cause,
                });
            }
        }
    }
    pub(crate) fn finalize_births(&mut self) {
        let births = std::mem::take(&mut self.pending_births);
        for (id, organism) in births {
            self.lifecycle.kind_mut(organism.kind).births += 1;
            self.spatial_index.insert(self.grid, organism.position, id);
            self.organisms.insert(id, organism);
        }
    }
    pub(crate) fn reconcile_species_extinctions(&mut self, tick: u64) {
        let living_species: HashSet<_> = self.organisms.values().map(|o| o.species_id).collect();
        for record in self.species.values_mut() {
            if record.extinct_at_tick.is_none() && !living_species.contains(&record.id) {
                record.extinct_at_tick = Some(tick);
            }
        }
        self.current_tick = tick;
    }
    pub(crate) fn set_current_tick(&mut self, tick: u64) {
        self.current_tick = tick;
    }
    fn assign_species(
        &mut self,
        kind: OrganismKind,
        genome: Genome,
        parent_species_id: Option<SpeciesId>,
        tick: u64,
    ) -> SpeciesId {
        if let Some((id, _)) = self
            .species
            .values()
            .filter(|s| s.kind == kind && s.extinct_at_tick.is_none())
            .map(|s| (s.id, s.representative.distance(genome)))
            .filter(|(_, d)| *d <= SPECIES_DISTANCE_THRESHOLD)
            .min_by_key(|(id, distance)| (*distance, *id))
        {
            return id;
        }
        let id = self.next_species_id;
        self.next_species_id = id.checked_add(1).expect("species ID overflow");
        let prefix = match kind {
            OrganismKind::Plant => "Plant",
            OrganismKind::Herbivore => "Herbivore",
            OrganismKind::Carnivore => "Carnivore",
        };
        self.species.insert(
            id,
            SpeciesRecord {
                id,
                name: format!("{prefix}-{id:06}"),
                kind,
                representative: genome,
                parent_species_id,
                arose_at_tick: tick,
                extinct_at_tick: None,
            },
        );
        id
    }
    pub(crate) fn age_live(&mut self) {
        for organism in self.organisms.values_mut() {
            organism.age = organism.age.saturating_add(1);
        }
    }
    fn allocate_id(&mut self) -> OrganismId {
        let id = self.next_organism_id;
        self.next_organism_id = id.checked_add(1).expect("organism ID overflow");
        id
    }

    /// Immutable climate at a valid cell.
    pub fn climate(&self, cell: Cell) -> Climate {
        self.climate[(cell.y * self.grid.width() + cell.x) as usize]
    }

    /// Current seasonal and weather-adjusted climate at a valid cell.
    pub fn current_climate(&self, cell: Cell) -> Climate {
        self.current_climate[(cell.y * self.grid.width() + cell.x) as usize]
    }

    pub fn weather_deviations(&self) -> &[WeatherDeviation] {
        &self.weather
    }

    pub(crate) fn advance_climate(
        &mut self,
        config: &ClimateConfig,
        tick: u64,
        rng: &mut DeterministicRng,
    ) {
        for (index, base) in self.climate.iter().copied().enumerate() {
            let deviation = if config.weather_enabled {
                WeatherDeviation {
                    temperature_centi_c: (rng.next_u32() % 601) as i16 - 300,
                    precipitation: (rng.next_u32() % 201) as i16 - 100,
                }
            } else {
                WeatherDeviation {
                    temperature_centi_c: 0,
                    precipitation: 0,
                }
            };
            let mut current = seasonal(base, config, tick);
            current.temperature_centi_c = (i32::from(current.temperature_centi_c)
                + i32::from(deviation.temperature_centi_c))
            .clamp(-8_800, 9_100) as i16;
            current.precipitation = (i32::from(current.precipitation)
                + i32::from(deviation.precipitation))
            .clamp(0, 1000) as u16;
            self.weather[index] = deviation;
            self.current_climate[index] = current;
        }
    }

    pub(crate) fn initialize_climate(&mut self, config: &ClimateConfig) {
        for (current, base) in self
            .current_climate
            .iter_mut()
            .zip(self.climate.iter().copied())
        {
            *current = seasonal(base, config, 0);
        }
    }

    pub(crate) fn state(&self) -> WorldClimateState {
        WorldClimateState {
            current_climate: self.current_climate.clone(),
            base_climate: self.climate.clone(),
            soil_water: self.soil_water.clone(),
            weather: self.weather.clone(),
            organisms: self.organisms.values().cloned().collect(),
            next_organism_id: self.next_organism_id,
            pending_births: self.pending_births.values().cloned().collect(),
            pending_deaths: self
                .pending_deaths
                .iter()
                .map(|(id, cause)| (*id, *cause))
                .collect(),
            death_history: self.death_history.clone(),
            lifecycle: self.lifecycle,
            species: self.species.values().cloned().collect(),
            next_species_id: self.next_species_id,
            resource_capacity: self.resource_capacity,
            current_tick: self.current_tick,
        }
    }

    /// Export stable two-letter biome codes in row-major order.
    pub fn biome_map(&self) -> String {
        format_biome_map(self.grid)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct WorldClimateState {
    pub base_climate: Vec<Climate>,
    pub current_climate: Vec<Climate>,
    pub soil_water: Vec<u32>,
    pub weather: Vec<WeatherDeviation>,
    pub organisms: Vec<Organism>,
    pub next_organism_id: OrganismId,
    pub pending_births: Vec<Organism>,
    pub pending_deaths: Vec<(OrganismId, DeathCause)>,
    pub death_history: Vec<DeathRecord>,
    pub lifecycle: LifecycleCounts,
    pub species: Vec<SpeciesRecord>,
    pub next_species_id: SpeciesId,
    pub resource_capacity: u32,
    pub current_tick: u64,
}

#[cfg(test)]
mod species_tests {
    use super::*;
    use crate::Grid;

    fn genome(value: u16) -> Genome {
        Genome::from_loci([value; 8])
    }

    #[test]
    fn species_assignment_is_kind_scoped_nearest_and_inclusive_at_threshold() {
        let mut world = World::from_grid(Grid::new(2, 2).unwrap());
        let first = world.assign_species(OrganismKind::Plant, genome(0), None, 0);
        assert_eq!(
            world.assign_species(OrganismKind::Plant, genome(8192), None, 0),
            first
        );
        let second = world.assign_species(OrganismKind::Plant, genome(16_000), None, 0);
        assert_ne!(second, first);
        assert_eq!(
            world.assign_species(OrganismKind::Plant, genome(8_000), None, 0),
            first
        );
        let beyond = world.assign_species(
            OrganismKind::Plant,
            Genome::from_loci([u16::MAX; 8]),
            None,
            0,
        );
        assert_ne!(beyond, first);
        let herb = world.assign_species(OrganismKind::Herbivore, genome(0), None, 0);
        assert_ne!(herb, first);
    }

    #[test]
    fn species_ids_names_ancestry_snapshot_and_extinction_tick_are_stable() {
        let mut world = World::from_grid(Grid::new(2, 2).unwrap());
        world.initialize_organism(OrganismKind::Plant, Cell { x: 0, y: 0 }, genome(0));
        let plant_species = world.organism(1).unwrap().species_id;
        world.initialize_organism(OrganismKind::Herbivore, Cell { x: 1, y: 0 }, genome(0));
        let herb_species = world.organism(2).unwrap().species_id;
        assert_eq!(world.species().next().unwrap().name, "Plant-000001");
        assert_eq!(world.living_species_count(OrganismKind::Plant), 1);

        world.set_current_tick(7);
        world
            .queue_birth(
                OrganismKind::Plant,
                Cell { x: 0, y: 1 },
                genome(20_000),
                [Some(1), None],
                1,
            )
            .unwrap();
        let child_species = world.pending_births.values().next().unwrap().species_id;
        world.finalize_births();
        assert_eq!(
            world
                .species()
                .find(|s| s.id == child_species)
                .unwrap()
                .parent_species_id,
            Some(plant_species)
        );
        assert_eq!(
            world
                .species()
                .find(|s| s.id == child_species)
                .unwrap()
                .arose_at_tick,
            7
        );
        assert_ne!(child_species, herb_species);
        let state = world.state();
        assert_eq!(state.next_species_id, world.next_species_id);
        assert_eq!(state.species, world.species().cloned().collect::<Vec<_>>());

        world.queue_death(1, DeathCause::Age);
        world.resolve_deaths(8);
        world.finalize_births();
        world.reconcile_species_extinctions(8);
        assert_eq!(
            world
                .species()
                .find(|s| s.id == plant_species)
                .unwrap()
                .extinct_at_tick,
            Some(8)
        );
        assert_eq!(world.living_species_count(OrganismKind::Plant), 1);
        assert_eq!(world.living_species_count(OrganismKind::Herbivore), 1);
    }
}

//! Validated, serializable simulation configuration and built-in presets.

use serde::{Deserialize, Serialize};
use std::{error::Error, fmt};

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConfigError(String);

impl ConfigError {
    fn new(message: impl Into<String>) -> Self {
        Self(message.into())
    }
}
impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}
impl Error for ConfigError {}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Config {
    pub seed: u64,
    pub world: WorldConfig,
    pub initial: InitialConfig,
    #[serde(default)]
    pub climate: ClimateConfig,
    #[serde(default)]
    pub ecology: EcologyConfig,
    #[serde(default)]
    pub genetics: GeneticsConfig,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WorldConfig {
    pub width: u32,
    pub height: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct InitialConfig {
    pub plants: u32,
    pub herbivores: u32,
    pub carnivores: u32,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ClimateConfig {
    pub season_length_ticks: u32,
    pub seasonal_temperature_amplitude_centi_c: u16,
    pub precipitation_seasonality_bp: u16,
    pub weather_enabled: bool,
}
impl Default for ClimateConfig {
    fn default() -> Self {
        Self {
            season_length_ticks: 240,
            seasonal_temperature_amplitude_centi_c: 1800,
            precipitation_seasonality_bp: 2500,
            weather_enabled: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct EcologyConfig {
    pub plant_growth_per_tick_permille: u16,
    pub resource_capacity: u32,
    pub animal_metabolism_per_tick: u16,
    pub reproduction_energy_threshold: u16,
}
impl Default for EcologyConfig {
    fn default() -> Self {
        Self {
            plant_growth_per_tick_permille: 35,
            resource_capacity: 1000,
            animal_metabolism_per_tick: 3,
            reproduction_energy_threshold: 100,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct GeneticsConfig {
    pub mutation_probability_bp: u16,
    pub mutation_step: u16,
}
impl Default for GeneticsConfig {
    fn default() -> Self {
        Self {
            mutation_probability_bp: 250,
            mutation_step: 2048,
        }
    }
}

impl Config {
    pub fn from_json(json: &str) -> Result<Self, ConfigError> {
        let mut deserializer = serde_json::Deserializer::from_str(json);
        let parsed: Self = serde_path_to_error::deserialize(&mut deserializer).map_err(|e| {
            let path = e.path().to_string();
            let path = if path.is_empty() {
                "configuration".to_owned()
            } else {
                path.replace(".", ".")
            };
            ConfigError::new(format!("{path}: {}", e.inner()))
        })?;
        deserializer
            .end()
            .map_err(|e| ConfigError::new(format!("configuration: {e}")))?;
        parsed.validate()?;
        Ok(parsed)
    }

    pub fn to_json(&self) -> Result<String, ConfigError> {
        self.validate()?;
        serde_json::to_string_pretty(self)
            .map_err(|e| ConfigError::new(format!("configuration: {e}")))
    }

    pub fn validate(&self) -> Result<(), ConfigError> {
        range("world.width", self.world.width, 1, 4096)?;
        range("world.height", self.world.height, 1, 4096)?;
        range("initial.plants", self.initial.plants, 0, 1_000_000)?;
        range("initial.herbivores", self.initial.herbivores, 0, 1_000_000)?;
        range("initial.carnivores", self.initial.carnivores, 0, 1_000_000)?;
        range(
            "climate.season_length_ticks",
            self.climate.season_length_ticks,
            1,
            100_000,
        )?;
        range(
            "climate.seasonal_temperature_amplitude_centi_c",
            self.climate.seasonal_temperature_amplitude_centi_c,
            0,
            6000,
        )?;
        range(
            "climate.precipitation_seasonality_bp",
            self.climate.precipitation_seasonality_bp,
            0,
            10_000,
        )?;
        range(
            "ecology.plant_growth_per_tick_permille",
            self.ecology.plant_growth_per_tick_permille,
            1,
            1000,
        )?;
        range(
            "ecology.resource_capacity",
            self.ecology.resource_capacity,
            1,
            1_000_000,
        )?;
        range(
            "ecology.animal_metabolism_per_tick",
            self.ecology.animal_metabolism_per_tick,
            0,
            10_000,
        )?;
        range(
            "ecology.reproduction_energy_threshold",
            self.ecology.reproduction_energy_threshold,
            1,
            10_000,
        )?;
        range(
            "genetics.mutation_probability_bp",
            self.genetics.mutation_probability_bp,
            0,
            10_000,
        )?;
        range(
            "genetics.mutation_step",
            self.genetics.mutation_step,
            0,
            65_535,
        )?;
        Ok(())
    }

    pub fn preset(name: &str) -> Result<Self, ConfigError> {
        let mut c = Self {
            seed: 42,
            world: WorldConfig {
                width: 64,
                height: 48,
            },
            initial: InitialConfig {
                plants: 400,
                herbivores: 120,
                carnivores: 20,
            },
            climate: ClimateConfig::default(),
            ecology: EcologyConfig::default(),
            genetics: GeneticsConfig::default(),
        };
        match name {
            "balanced" => {}
            "lush" => {
                c.climate.seasonal_temperature_amplitude_centi_c = 900;
                c.climate.precipitation_seasonality_bp = 1000;
                c.ecology.plant_growth_per_tick_permille = 70;
                c.ecology.resource_capacity = 1500;
            }
            "harsh" => {
                c.climate.seasonal_temperature_amplitude_centi_c = 3500;
                c.climate.precipitation_seasonality_bp = 8000;
                c.ecology.plant_growth_per_tick_permille = 12;
                c.ecology.resource_capacity = 500;
            }
            _ => {
                return Err(ConfigError::new(format!(
                    "preset: unknown preset '{name}' (available: balanced, lush, harsh)"
                )))
            }
        }
        c.validate()?;
        Ok(c)
    }

    pub fn available_presets() -> &'static [&'static str] {
        &["balanced", "lush", "harsh"]
    }
}

fn range<T>(name: &str, value: T, min: T, max: T) -> Result<(), ConfigError>
where
    T: PartialOrd + fmt::Display,
{
    if value < min || value > max {
        Err(ConfigError::new(format!(
            "{name}: value {value} is outside {min}..={max}"
        )))
    } else {
        Ok(())
    }
}

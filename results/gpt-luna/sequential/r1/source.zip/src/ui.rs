//! Loopback browser UI for controlling and inspecting the shared simulation.
use crate::checkpoint;
use crate::{Cell, Config, MetricsSample, OrganismKind, Simulation};
use serde::Serialize;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

const MAX_BODY: usize = 32 * 1024 * 1024;
struct AppState {
    config: Config,
    sim: Simulation,
    chart_history: Vec<MetricsSample>,
}
#[derive(Serialize)]
struct Snapshot {
    tick: u64,
    width: u32,
    height: u32,
    plants: usize,
    herbivores: usize,
    carnivores: usize,
    cells: Vec<CellView>,
    organisms: Vec<EntityView>,
}
#[derive(Serialize)]
struct CellView {
    temperature: i16,
    precipitation: u16,
}
#[derive(Serialize)]
struct EntityView {
    id: u64,
    kind: &'static str,
    x: u32,
    y: u32,
}
fn kind_name(k: OrganismKind) -> &'static str {
    match k {
        OrganismKind::Plant => "plant",
        OrganismKind::Herbivore => "herbivore",
        OrganismKind::Carnivore => "carnivore",
    }
}
fn snapshot(sim: &Simulation) -> Snapshot {
    let w = sim.world();
    let grid = w.grid();
    let cells = (0..grid.height())
        .flat_map(|y| (0..grid.width()).map(move |x| w.current_climate(Cell { x, y })))
        .map(|c| CellView {
            temperature: c.temperature_centi_c,
            precipitation: c.precipitation,
        })
        .collect();
    let organisms = w
        .organisms()
        .map(|o| EntityView {
            id: o.id,
            kind: kind_name(o.kind),
            x: o.position.x,
            y: o.position.y,
        })
        .collect();
    Snapshot {
        tick: sim.tick(),
        width: grid.width(),
        height: grid.height(),
        plants: w.count(OrganismKind::Plant),
        herbivores: w.count(OrganismKind::Herbivore),
        carnivores: w.count(OrganismKind::Carnivore),
        cells,
        organisms,
    }
}
#[derive(Serialize)]
struct Detail {
    id: u64,
    kind: String,
    species_id: u64,
    species: String,
    age: u64,
    energy: u32,
    health: u32,
    traits: crate::Traits,
    genome: crate::Genome,
    parents: [Option<u64>; 2],
    generation: u64,
    status: &'static str,
    death_tick: Option<u64>,
    death_cause: Option<String>,
}
fn detail(sim: &Simulation, id: u64) -> Option<Detail> {
    let w = sim.world();
    if let Some(o) = w.organism(id) {
        let species = w.species().find(|s| s.id == o.species_id)?;
        return Some(Detail {
            id,
            kind: kind_name(o.kind).into(),
            species_id: o.species_id,
            species: species.name.clone(),
            age: o.age,
            energy: o.energy(),
            health: o.health(),
            traits: o.traits,
            genome: o.genome,
            parents: o.parent_ids,
            generation: o.generation,
            status: "alive",
            death_tick: None,
            death_cause: None,
        });
    }
    let d = w.death_history().iter().find(|d| d.organism.id == id)?;
    let o = &d.organism;
    let species = w.species().find(|s| s.id == o.species_id)?;
    Some(Detail {
        id,
        kind: kind_name(o.kind).into(),
        species_id: o.species_id,
        species: species.name.clone(),
        age: o.age,
        energy: o.energy(),
        health: o.health(),
        traits: o.traits,
        genome: o.genome,
        parents: o.parent_ids,
        generation: o.generation,
        status: "dead",
        death_tick: Some(d.tick),
        death_cause: Some(format!("{:?}", d.cause)),
    })
}
fn response(stream: &mut TcpStream, status: &str, mime: &str, body: &[u8]) {
    let _=write!(stream,"HTTP/1.1 {status}\r\nContent-Type: {mime}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n",body.len());
    let _ = stream.write_all(body);
}
fn json<T: Serialize>(v: &T) -> Vec<u8> {
    serde_json::to_vec(v).unwrap_or_else(|_| b"{}".to_vec())
}
fn query(path: &str, key: &str) -> Option<String> {
    path.split('?').nth(1)?.split('&').find_map(|part| {
        let (k, v) = part.split_once('=')?;
        (k == key).then(|| v.replace('+', " "))
    })
}
fn respond(mut stream: TcpStream, state: Arc<Mutex<AppState>>) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(5)));
    let mut req = Vec::new();
    let mut buf = [0u8; 8192];
    let split;
    loop {
        match stream.read(&mut buf) {
            Ok(0) | Err(_) => return,
            Ok(n) => {
                req.extend_from_slice(&buf[..n]);
                if req.len() > MAX_BODY + 65536 {
                    return;
                }
                if let Some(i) = req.windows(4).position(|w| w == b"\r\n\r\n") {
                    split = i + 4;
                    break;
                }
            }
        }
    }
    let header = String::from_utf8_lossy(&req[..split]).into_owned();
    let mut parts = header.lines().next().unwrap_or("").split_whitespace();
    let method = parts.next().unwrap_or("GET");
    let path = parts.next().unwrap_or("/");
    let route = path.split('?').next().unwrap_or(path);
    let length = header
        .lines()
        .find_map(|l| {
            l.split_once(':')
                .filter(|(k, _)| k.eq_ignore_ascii_case("content-length"))
                .and_then(|(_, v)| v.trim().parse::<usize>().ok())
        })
        .unwrap_or(0);
    if length > MAX_BODY {
        response(
            &mut stream,
            "413 Payload Too Large",
            "text/plain",
            b"request too large",
        );
        return;
    }
    while req.len() < split + length {
        match stream.read(&mut buf) {
            Ok(0) | Err(_) => return,
            Ok(n) => req.extend_from_slice(&buf[..n]),
        }
    }
    let body = &req[split..split + length];
    let result: Result<(&'static str, &'static str, Vec<u8>), (&'static str, String)> = (|| match (
        method, route,
    ) {
        ("GET", "/") => Ok((
            "200 OK",
            "text/html; charset=utf-8",
            include_str!("../ui/index.html").as_bytes().to_vec(),
        )),
        ("GET", "/app.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/app.js").as_bytes().to_vec(),
        )),
        ("GET", "/controller.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/controller.js").as_bytes().to_vec(),
        )),
        ("GET", "/config-model.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/config-model.js").as_bytes().to_vec(),
        )),
        ("GET", "/chart-data.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/chart-data.js").as_bytes().to_vec(),
        )),
        ("GET", "/scenarios.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/scenarios.js").as_bytes().to_vec(),
        )),
        ("GET", "/charts.js") => Ok((
            "200 OK",
            "application/javascript",
            include_str!("../ui/charts.js").as_bytes().to_vec(),
        )),
        ("GET", "/style.css") => Ok((
            "200 OK",
            "text/css",
            include_str!("../ui/style.css").as_bytes().to_vec(),
        )),
        ("GET", "/api/config") => {
            let s = state.lock().unwrap();
            Ok(("200 OK", "application/json", json(&s.config)))
        }
        ("GET", "/api/presets") => {
            let presets: Vec<_> = Config::available_presets()
                .iter()
                .map(|name| (*name, Config::preset(name).unwrap()))
                .collect();
            Ok(("200 OK", "application/json", json(&presets)))
        }
        ("GET", "/api/charts") => {
            let s = state.lock().unwrap();
            let kind = query(path, "kind").unwrap_or_else(|| "herbivore".into());
            let trait_name = query(path, "trait").unwrap_or_else(|| "speed".into());
            let k = match kind.as_str() {
                "plant" => OrganismKind::Plant,
                "herbivore" => OrganismKind::Herbivore,
                "carnivore" => OrganismKind::Carnivore,
                _ => return Err(("400 Bad Request", "invalid kind".into())),
            };
            let allowed = [
                "speed",
                "strength",
                "fertility",
                "max_health",
                "max_lifespan_ticks",
                "risk_tolerance",
                "aggression",
                "foraging_bias",
            ];
            if !allowed.contains(&trait_name.as_str()) {
                return Err(("400 Bad Request", "invalid trait".into()));
            }
            let values: Vec<u16> = s
                .sim
                .world()
                .organisms()
                .filter(|o| o.kind == k)
                .filter_map(|o| match trait_name.as_str() {
                    "speed" => Some(o.traits.speed),
                    "strength" => Some(o.traits.strength),
                    "fertility" => Some(o.traits.fertility),
                    "max_health" => Some(o.traits.max_health),
                    "max_lifespan_ticks" => Some(o.traits.max_lifespan_ticks),
                    "risk_tolerance" => o.traits.risk_tolerance,
                    "aggression" => o.traits.aggression,
                    _ => o.traits.foraging_bias,
                })
                .collect();
            Ok((
                "200 OK",
                "application/json",
                json(
                    &serde_json::json!({"history":s.chart_history,"kind":kind,"trait":trait_name,"values":values}),
                ),
            ))
        }
        ("GET", "/api/snapshot") => {
            let s = state.lock().unwrap();
            Ok(("200 OK", "application/json", json(&snapshot(&s.sim))))
        }
        ("GET", "/api/advance") => {
            let n = path
                .split("ticks=")
                .nth(1)
                .and_then(|s| s.split('&').next())
                .and_then(|s| s.parse::<u32>().ok())
                .ok_or(("400 Bad Request", "ticks required".into()))?
                .min(10000);
            let mut s = state.lock().unwrap();
            for _ in 0..n {
                s.sim.step_one_tick();
            }
            let sample = MetricsSample::capture(&s.sim);
            s.chart_history.push(sample);
            if s.chart_history.len() > 1000 {
                s.chart_history.remove(0);
            }
            Ok(("200 OK", "application/json", json(&snapshot(&s.sim))))
        }
        ("GET", "/api/detail") => {
            let id = path
                .split("id=")
                .nth(1)
                .and_then(|s| s.split('&').next())
                .and_then(|s| s.parse::<u64>().ok())
                .ok_or(("400 Bad Request", "id required".into()))?;
            let s = state.lock().unwrap();
            match detail(&s.sim, id) {
                Some(d) => Ok(("200 OK", "application/json", json(&d))),
                None => Ok((
                    "404 Not Found",
                    "application/json",
                    b"{\"status\":\"unavailable\"}".to_vec(),
                )),
            }
        }
        ("POST", "/api/reset") => {
            let cfg: Config =
                serde_json::from_slice(body).map_err(|e| ("400 Bad Request", e.to_string()))?;
            cfg.validate()
                .map_err(|e| ("400 Bad Request", e.to_string()))?;
            let mut s = state.lock().unwrap();
            s.sim = Simulation::new(&cfg);
            s.config = cfg;
            s.chart_history = vec![MetricsSample::capture(&s.sim)];
            Ok(("200 OK", "application/json", json(&snapshot(&s.sim))))
        }
        ("GET", "/api/checkpoint") => {
            let s = state.lock().unwrap();
            let b = checkpoint::encode(&s.sim, s.config.clone())
                .map_err(|e| ("500 Internal Server Error", e))?;
            Ok(("200 OK", "application/json", b))
        }
        ("POST", "/api/checkpoint") => {
            let (cfg, sim) = checkpoint::decode(body).map_err(|e| ("400 Bad Request", e))?;
            let mut s = state.lock().unwrap();
            s.sim = sim;
            s.config = cfg;
            s.chart_history = vec![MetricsSample::capture(&s.sim)];
            Ok(("200 OK", "application/json", json(&snapshot(&s.sim))))
        }
        _ => Err(("404 Not Found", "not found".into())),
    })();
    match result {
        Ok((st, m, b)) => response(&mut stream, st, m, &b),
        Err((st, e)) => response(&mut stream, st, "text/plain", e.as_bytes()),
    }
}
pub fn run(args: &[String]) -> (i32, String, bool) {
    match run_inner(args) {
        Ok(()) => (0, String::new(), false),
        Err(e) => (2, format!("evosim ui: {e}\n"), true),
    }
}
fn run_inner(args: &[String]) -> Result<(), String> {
    let mut config_path = None;
    let mut smoke = false;
    let mut screenshots = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--config" => {
                i += 1;
                let v = args.get(i).ok_or("--config requires a file")?;
                if config_path.replace(v.clone()).is_some() {
                    return Err("duplicate --config".into());
                }
            }
            "--smoke-test" => smoke = true,
            "--screenshots" => {
                i += 1;
                let v = args.get(i).ok_or("--screenshots requires a directory")?;
                if screenshots.replace(v.clone()).is_some() {
                    return Err("duplicate --screenshots".into());
                }
            }
            x => return Err(format!("unknown argument '{x}'")),
        }
        i += 1
    }
    if smoke && screenshots.is_some() {
        return Err("--smoke-test and --screenshots cannot be combined".into());
    }
    let config = if let Some(p) = config_path {
        Config::from_json(&std::fs::read_to_string(p).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?
    } else {
        Config::from_json(r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#).unwrap()
    };
    let sim = Simulation::new(&config);
    let chart_history = vec![MetricsSample::capture(&sim)];
    let state = Arc::new(Mutex::new(AppState {
        sim,
        chart_history,
        config,
    }));
    let listener = TcpListener::bind("127.0.0.1:0").map_err(|e| e.to_string())?;
    listener.set_nonblocking(true).map_err(|e| e.to_string())?;
    let url = format!(
        "http://{}/",
        listener.local_addr().map_err(|e| e.to_string())?
    );
    let running = Arc::new(AtomicBool::new(true));
    let run = running.clone();
    let st = state.clone();
    let server = thread::spawn(move || {
        let end = std::time::Instant::now() + Duration::from_secs(125);
        while run.load(Ordering::Relaxed) && std::time::Instant::now() < end {
            match listener.accept() {
                Ok((sock, _)) => respond(sock, st.clone()),
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    thread::sleep(Duration::from_millis(8))
                }
                Err(_) => break,
            }
        }
    });
    if smoke || screenshots.is_some() {
        if let Some(d) = &screenshots {
            if !std::path::Path::new(d).is_dir() {
                return Err("screenshot directory must already exist".into());
            }
        }
        let browser = std::env::var("CHROME_BIN").unwrap_or_else(|_| "chromium".into());
        let auto = if screenshots.is_some() { 100 } else { 10 };
        let mut cmd = Command::new(browser.clone());
        cmd.arg("--headless")
            .arg("--no-sandbox")
            .arg("--disable-gpu")
            .arg("--virtual-time-budget=20000");
        if let Some(d) = &screenshots {
            cmd.arg("--window-size=1440,1400")
                .arg(format!("--screenshot={d}/main.png"));
        } else {
            cmd.arg("--dump-dom");
        }
        cmd.arg(format!("{url}?auto={auto}"));
        cmd.stdout(Stdio::piped()).stderr(Stdio::null());
        let out = cmd
            .output()
            .map_err(|e| format!("could not start Chromium: {e}"))?;
        if !out.status.success()
            || (screenshots.is_none()
                && !String::from_utf8_lossy(&out.stdout).contains("EVOSIM_RENDERED"))
        {
            running.store(false, Ordering::Relaxed);
            let _ = server.join();
            return Err("Chromium UI automation failed".into());
        }
        if let Some(d) = screenshots {
            let png = std::fs::read(format!("{d}/main.png")).map_err(|e| e.to_string())?;
            if png.len() < 24
                || &png[..8] != b"\x89PNG\r\n\x1a\n"
                || u32::from_be_bytes(png[16..20].try_into().unwrap()) < 1280
                || u32::from_be_bytes(png[20..24].try_into().unwrap()) < 720
            {
                return Err("invalid or undersized screenshot".into());
            }
            let charts = Command::new(browser)
                .arg("--headless")
                .arg("--no-sandbox")
                .arg("--disable-gpu")
                .arg("--virtual-time-budget=20000")
                .arg("--window-size=1440,1400")
                .arg(format!("--screenshot={d}/charts.png"))
                .arg(format!("{url}?auto=100&charts=1"))
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status()
                .map_err(|e| e.to_string())?;
            if !charts.success() {
                return Err("Chromium charts screenshot failed".into());
            }
            let png = std::fs::read(format!("{d}/charts.png")).map_err(|e| e.to_string())?;
            if png.len() < 24
                || &png[..8] != b"\x89PNG\r\n\x1a\n"
                || u32::from_be_bytes(png[16..20].try_into().unwrap()) < 1280
                || u32::from_be_bytes(png[20..24].try_into().unwrap()) < 720
            {
                return Err("invalid or undersized charts screenshot".into());
            }
        }
    } else {
        let browser = std::env::var("BROWSER").unwrap_or_else(|_| "xdg-open".into());
        let _ = Command::new(browser).arg(&url).spawn();
        eprintln!("Evolution Simulation UI: {url}");
        loop {
            thread::sleep(Duration::from_secs(3600))
        }
    }
    running.store(false, Ordering::Relaxed);
    let _ = server.join();
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn snapshot_counts_and_stable_ids() {
        let c=Config::from_json(r#"{"seed":1,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":1,"carnivores":1}}"#).unwrap();
        let s = snapshot(&Simulation::new(&c));
        assert_eq!(s.cells.len(), 6);
        assert_eq!((s.plants, s.herbivores, s.carnivores), (2, 1, 1));
        assert_eq!(s.organisms.len(), 4);
        assert!(s.organisms.windows(2).all(|w| w[0].id < w[1].id));
    }
    #[test]
    fn detail_reports_live_and_dead() {
        let c=Config::from_json(r#"{"seed":1,"world":{"width":3,"height":2},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(&c);
        let id = sim.world().organisms().next().unwrap().id;
        assert_eq!(detail(&sim, id).unwrap().status, "alive");
        sim.set_organism_energy(id, 0).unwrap();
        sim.step_one_tick();
        assert_eq!(detail(&sim, id).unwrap().status, "dead");
    }
    #[test]
    fn config_presets_are_ordered_and_chart_trait_validation_is_strict() {
        assert_eq!(Config::available_presets(), &["balanced", "lush", "harsh"]);
        assert!(
            query("/api/charts?kind=herbivore&trait=speed", "kind").as_deref() == Some("herbivore")
        );
        assert!(query("/api/charts?kind=plant", "trait").is_none());
    }
}

//! Organism identity, traits, and shared life/death records.
use crate::{Cell, Genome};
use serde::{Deserialize, Serialize};

pub type OrganismId = u64;
pub type SpeciesId = u64;
pub const MAX_ENERGY: u32 = 100_000;
pub const MAX_HEALTH: u32 = 100_000;

#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd, Serialize, Deserialize)]
pub enum OrganismKind {
    Plant,
    Herbivore,
    Carnivore,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Traits {
    pub speed: u16,
    pub strength: u16,
    pub fertility: u16,
    pub max_health: u16,
    pub max_lifespan_ticks: u16,
    /// Plants have no animal behavioral tendencies.
    pub risk_tolerance: Option<u16>,
    pub aggression: Option<u16>,
    pub foraging_bias: Option<u16>,
}

impl Traits {
    pub fn for_kind(kind: OrganismKind) -> Self {
        Self {
            speed: 0,
            strength: 0,
            fertility: 0,
            max_health: u16::MAX,
            max_lifespan_ticks: u16::MAX,
            risk_tolerance: (kind != OrganismKind::Plant).then_some(0),
            aggression: (kind != OrganismKind::Plant).then_some(0),
            foraging_bias: (kind != OrganismKind::Plant).then_some(0),
        }
    }
    pub fn valid_for(self, kind: OrganismKind) -> bool {
        let animal = kind != OrganismKind::Plant;
        self.aggression.is_some() == animal
            && self.risk_tolerance.is_some() == animal
            && self.foraging_bias.is_some() == animal
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Organism {
    pub id: OrganismId,
    pub kind: OrganismKind,
    pub position: Cell,
    pub age: u64,
    /// Ticks remaining before this animal may reproduce again.
    pub reproduction_cooldown: u32,
    /// Carnivore digestion time; attacks are unavailable while this is positive.
    #[serde(default)]
    pub hunting_cooldown: u32,
    energy: u32,
    health: u32,
    pub traits: Traits,
    pub genome: Genome,
    pub parent_ids: [Option<OrganismId>; 2],
    pub generation: u64,
    pub species_id: SpeciesId,
}

impl Organism {
    pub(crate) fn new(
        id: OrganismId,
        kind: OrganismKind,
        position: Cell,
        genome: Genome,
        parent_ids: [Option<OrganismId>; 2],
        generation: u64,
        species_id: SpeciesId,
    ) -> Self {
        let traits = genome.traits(kind);
        let max_health = u32::from(traits.max_health).min(MAX_HEALTH);
        Self {
            id,
            kind,
            position,
            age: 0,
            reproduction_cooldown: 0,
            hunting_cooldown: 0,
            energy: MAX_ENERGY,
            health: max_health,
            traits,
            genome,
            parent_ids,
            generation,
            species_id,
        }
    }
    pub fn set_energy(&mut self, value: u32) {
        self.energy = value.min(MAX_ENERGY);
    }
    pub fn energy(&self) -> u32 {
        self.energy
    }
    pub fn health(&self) -> u32 {
        self.health
    }
    pub fn set_health(&mut self, value: u32) {
        self.health = value.min(MAX_HEALTH).min(u32::from(self.traits.max_health));
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub enum DeathCause {
    Starvation,
    Predation,
    Age,
    Climate,
    Injury,
    Other,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct DeathRecord {
    pub organism: Organism,
    pub tick: u64,
    pub cause: DeathCause,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct KindCounts {
    pub initial: u64,
    pub births: u64,
    pub deaths: u64,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct LifecycleCounts {
    pub plants: KindCounts,
    pub herbivores: KindCounts,
    pub carnivores: KindCounts,
}

impl LifecycleCounts {
    pub fn for_kind(&self, kind: OrganismKind) -> KindCounts {
        match kind {
            OrganismKind::Plant => self.plants,
            OrganismKind::Herbivore => self.herbivores,
            OrganismKind::Carnivore => self.carnivores,
        }
    }
    pub(crate) fn kind_mut(&mut self, kind: OrganismKind) -> &mut KindCounts {
        match kind {
            OrganismKind::Plant => &mut self.plants,
            OrganismKind::Herbivore => &mut self.herbivores,
            OrganismKind::Carnivore => &mut self.carnivores,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn energy_and_health_mutators_keep_values_in_range() {
        let mut organism = Organism::new(
            1,
            OrganismKind::Plant,
            Cell { x: 0, y: 0 },
            Genome::from_loci([0, 0, 123, 0, 0, 0, 0, 0]),
            [None, None],
            0,
            1,
        );
        organism.set_energy(u32::MAX);
        organism.set_health(u32::MAX);
        assert_eq!(organism.energy, MAX_ENERGY);
        assert_eq!(organism.health, 123);
        organism.set_health(0);
        organism.set_energy(0);
        assert_eq!((organism.health, organism.energy), (0, 0));
    }
}

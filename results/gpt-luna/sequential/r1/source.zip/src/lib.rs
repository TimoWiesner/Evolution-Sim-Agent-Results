//! Minimal command-line bootstrap. Simulation behavior is added by later tasks.

pub mod animal;
pub mod checkpoint;
pub mod cli;
pub mod climate;
pub mod config;
pub mod entity;
pub mod genome;
pub mod grid;
pub mod metrics;
pub mod plant;
pub mod rng;
pub mod simulation;
mod spatial_index;
pub mod ui;
pub mod world;
pub use climate::{format_biome_map, Biome, Climate};
pub use config::{
    ClimateConfig, Config, ConfigError, EcologyConfig, GeneticsConfig, InitialConfig, WorldConfig,
};
pub use entity::{
    DeathCause, DeathRecord, KindCounts, LifecycleCounts, Organism, OrganismId, OrganismKind,
    SpeciesId, Traits, MAX_ENERGY, MAX_HEALTH,
};
pub use genome::Genome;
pub use grid::{Cell, Direction, Grid};
pub use metrics::MetricsSample;
pub use rng::{DeterministicRng, RngState};
pub use simulation::{Simulation, TickEvent, TickPhase, TickReport};
pub use world::{SpeciesRecord, World, SPECIES_DISTANCE_THRESHOLD};

/// Return the fixed version response from interface contract version 1.
pub fn version_json() -> &'static str {
    r#"{"name":"evosim","version":"0.1.0","contract":1}"#
}

/// Help text for the commands currently implemented by the bootstrap.
pub fn help_text() -> &'static str {
    "Evolution Simulation\n\nUSAGE:\n    evosim <COMMAND>\n\nCOMMANDS:\n    version    Print product and contract version as JSON\n    help       Print this help message\n    --help     Print this help message\n"
}

/// Dispatch bootstrap commands. Returns a process exit code, output text and stderr flag.
pub fn dispatch(args: &[String]) -> (i32, String, bool) {
    match args.first().map(String::as_str) {
        Some("run") => cli::run(&args[1..]),
        Some("batch") => cli::batch(&args[1..]),
        Some("ui") => ui::run(&args[1..]),
        Some("version") if args.len() == 1 => (0, version_json().to_owned(), false),
        Some("help") | Some("--help") | Some("-h") if args.len() == 1 => {
            (0, help_text().to_owned(), false)
        }
        None => (0, help_text().to_owned(), false),
        Some(command) => (
            2,
            format!("evosim: unknown command or arguments: {command}\n"),
            true,
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn version_matches_contract() {
        assert_eq!(
            version_json(),
            r#"{"name":"evosim","version":"0.1.0","contract":1}"#
        );
    }
}

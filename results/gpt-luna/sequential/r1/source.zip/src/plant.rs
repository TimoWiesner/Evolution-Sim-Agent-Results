//! Fixed-point plant growth limited by current climate and shared cell water.
use crate::climate::Climate;
use crate::entity::{Organism, MAX_ENERGY};

pub const ENERGY_PER_WATER_UNIT: u32 = 100;

/// Suitability rises from -10 C to 20 C and falls to zero at 50 C.
pub fn temperature_suitability(temperature_centi_c: i16) -> u32 {
    let t = i32::from(temperature_centi_c);
    if t < -1000 || t > 5000 {
        0
    } else if t <= 2000 {
        ((t + 1000) * 1000 / 3000) as u32
    } else {
        ((5000 - t) * 1000 / 3000) as u32
    }
}

pub fn precipitation_suitability(precipitation: u16) -> u32 {
    u32::from(precipitation).min(1000)
}

pub fn hostile_climate(climate: Climate) -> bool {
    climate.temperature_centi_c < -4000
        || climate.temperature_centi_c > 6000
        || climate.precipitation < 20
}

/// Calculate funded gain. Gains are whole 100-energy quanta so resource use is exact.
pub fn potential_gain(climate: Climate, fertility: u16, growth_permille: u16) -> u32 {
    let mut gain = u64::from(MAX_ENERGY) * u64::from(growth_permille.min(1000)) / 1000;
    gain = gain * u64::from(temperature_suitability(climate.temperature_centi_c)) / 1000;
    gain = gain * u64::from(precipitation_suitability(climate.precipitation)) / 1000;
    gain = gain * u64::from(fertility) / 65_535;
    (gain as u32 / ENERGY_PER_WATER_UNIT) * ENERGY_PER_WATER_UNIT
}

pub(crate) fn grow(
    organism: &mut Organism,
    climate: Climate,
    available_water: u32,
    growth_permille: u16,
) -> u32 {
    let remaining = MAX_ENERGY.saturating_sub(organism.energy());
    potential_gain(climate, organism.traits.fertility, growth_permille)
        .min(remaining / ENERGY_PER_WATER_UNIT * ENERGY_PER_WATER_UNIT)
        .min(available_water.saturating_mul(ENERGY_PER_WATER_UNIT))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::climate::Biome;

    fn climate(temp: i16, rain: u16) -> Climate {
        Climate {
            biome: Biome::Temperate,
            temperature_centi_c: temp,
            precipitation: rain,
            warmth: 5000,
        }
    }

    #[test]
    fn suitability_and_growth_are_bounded_and_climate_sensitive() {
        assert_eq!(temperature_suitability(-1000), 0);
        assert_eq!(temperature_suitability(2000), 1000);
        assert_eq!(temperature_suitability(5000), 0);
        assert!(
            potential_gain(climate(2000, 1000), u16::MAX, 100)
                > potential_gain(climate(-5000, 1000), u16::MAX, 100)
        );
        assert!(
            potential_gain(climate(2000, 20), u16::MAX, 100)
                < potential_gain(climate(2000, 1000), u16::MAX, 100)
        );
        assert!(
            potential_gain(climate(2000, 1000), u16::MAX, 100)
                > potential_gain(climate(2000, 1000), 100, 100)
        );
    }
}

//! Shared versioned checkpoint codec used by CLI and browser UI.
use crate::world::WorldClimateState;
use crate::{Config, RngState, Simulation};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Checkpoint {
    pub format_version: u32,
    pub config: Config,
    pub tick: u64,
    pub rng: RngState,
    pub world: WorldClimateState,
}

impl Checkpoint {
    pub fn capture(sim: &Simulation, config: Config) -> Self {
        Self {
            format_version: 1,
            config,
            tick: sim.tick(),
            rng: sim.rng_state(),
            world: sim.snapshot().climate,
        }
    }
    pub fn restore(self) -> Result<(Config, Simulation), String> {
        if self.format_version != 1 {
            return Err(format!(
                "unsupported checkpoint format version {}",
                self.format_version
            ));
        }
        let sim = Simulation::restore(self.config.clone(), self.tick, self.rng, self.world)?;
        Ok((self.config, sim))
    }
}

pub fn encode(sim: &Simulation, config: Config) -> Result<Vec<u8>, String> {
    serde_json::to_vec_pretty(&Checkpoint::capture(sim, config)).map_err(|e| e.to_string())
}
pub fn decode(bytes: &[u8]) -> Result<(Config, Simulation), String> {
    let checkpoint: Checkpoint = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
    checkpoint.restore()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn shared_codec_round_trips_and_rejects_invalid_without_a_replacement() {
        let config = Config::from_json(r#"{"seed":9,"world":{"width":3,"height":2},"initial":{"plants":2,"herbivores":1,"carnivores":0}}"#).unwrap();
        let mut sim = Simulation::new(&config);
        for _ in 0..3 {
            sim.step_one_tick();
        }
        let saved = encode(&sim, config.clone()).unwrap();
        let (loaded_config, loaded) = decode(&saved).unwrap();
        assert_eq!(loaded_config, config);
        assert_eq!(loaded.state_hash().unwrap(), sim.state_hash().unwrap());
        assert_eq!(loaded.tick(), 3);
        let before = loaded.state_hash().unwrap();
        assert!(decode(b"{invalid").is_err());
        assert_eq!(loaded.state_hash().unwrap(), before);
    }
}

//! Fixed-schema heritable DNA and deterministic phenotype/inheritance rules.
use crate::{DeterministicRng, GeneticsConfig, OrganismKind, Traits};
use serde::{Deserialize, Serialize};

/// Eight normalized loci, in the canonical mutation and distance order.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub struct Genome {
    pub speed: u16,
    pub strength: u16,
    pub max_health: u16,
    pub fertility: u16,
    pub risk_tolerance: u16,
    pub aggression: u16,
    pub foraging_bias: u16,
    pub lifespan: u16,
}

impl Genome {
    pub const LOCUS_COUNT: usize = 8;

    pub fn from_loci(loci: [u16; Self::LOCUS_COUNT]) -> Self {
        Self {
            speed: loci[0],
            strength: loci[1],
            max_health: loci[2],
            fertility: loci[3],
            risk_tolerance: loci[4],
            aggression: loci[5],
            foraging_bias: loci[6],
            lifespan: loci[7],
        }
    }
    pub fn loci(self) -> [u16; Self::LOCUS_COUNT] {
        [
            self.speed,
            self.strength,
            self.max_health,
            self.fertility,
            self.risk_tolerance,
            self.aggression,
            self.foraging_bias,
            self.lifespan,
        ]
    }
    pub fn sample(rng: &mut DeterministicRng) -> Self {
        Self::from_loci(std::array::from_fn(|_| rng.next_u32() as u16))
    }
    pub fn traits(self, kind: OrganismKind) -> Traits {
        Traits {
            speed: self.speed,
            strength: self.strength,
            fertility: self.fertility,
            max_health: self.max_health,
            max_lifespan_ticks: self.lifespan,
            risk_tolerance: (kind != OrganismKind::Plant).then_some(self.risk_tolerance),
            aggression: (kind != OrganismKind::Plant).then_some(self.aggression),
            foraging_bias: (kind != OrganismKind::Plant).then_some(self.foraging_bias),
        }
    }
    pub fn child_one(parent: Self, rng: &mut DeterministicRng, config: &GeneticsConfig) -> Self {
        Self::mutate(parent, rng, config)
    }
    pub fn child_two(
        a: Self,
        b: Self,
        rng: &mut DeterministicRng,
        config: &GeneticsConfig,
    ) -> Self {
        let aa = a.loci();
        let bb = b.loci();
        let inherited = std::array::from_fn(|i| {
            if rng.next_u32() % 2 == 0 {
                aa[i]
            } else {
                bb[i]
            }
        });
        Self::mutate(Self::from_loci(inherited), rng, config)
    }
    fn mutate(mut self, rng: &mut DeterministicRng, config: &GeneticsConfig) -> Self {
        let mut loci = self.loci();
        for locus in &mut loci {
            if rng.next_u32() % 10_000 < u32::from(config.mutation_probability_bp)
                && config.mutation_step != 0
            {
                let magnitude = 1 + rng.next_u32() % u32::from(config.mutation_step);
                let delta = if rng.next_u32() & 1 == 0 {
                    magnitude as i32
                } else {
                    -(magnitude as i32)
                };
                *locus = (i32::from(*locus) + delta).clamp(0, i32::from(u16::MAX)) as u16;
            }
        }
        self = Self::from_loci(loci);
        self
    }
    /// Sum of absolute allele differences (eight times the mean normalized distance).
    pub fn distance(self, other: Self) -> u32 {
        self.loci()
            .into_iter()
            .zip(other.loci())
            .map(|(a, b)| u32::from(a.abs_diff(b)))
            .sum()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::DeterministicRng;

    #[test]
    fn phenotype_is_deterministic_and_preserves_locus_bounds() {
        for kind in [
            OrganismKind::Plant,
            OrganismKind::Herbivore,
            OrganismKind::Carnivore,
        ] {
            let genome = Genome::from_loci([0, 1, 2, 3, 4, 5, 6, 7]);
            let traits = genome.traits(kind);
            assert_eq!(traits.speed, 0);
            assert_eq!(traits.max_health, 2);
            assert_eq!(traits.max_lifespan_ticks, 7);
            assert_eq!(traits.strength, 1);
            assert_eq!(traits.fertility, 3);
            assert_eq!(
                traits.risk_tolerance,
                (kind != OrganismKind::Plant).then_some(4)
            );
            assert_eq!(
                traits.aggression,
                (kind != OrganismKind::Plant).then_some(5)
            );
            assert_eq!(
                traits.foraging_bias,
                (kind != OrganismKind::Plant).then_some(6)
            );
            assert!(traits.valid_for(kind));
            assert_eq!(traits, genome.traits(kind));
        }
        assert_eq!(
            Genome::from_loci([u16::MAX; 8])
                .traits(OrganismKind::Plant)
                .max_lifespan_ticks,
            u16::MAX
        );
    }

    #[test]
    fn inheritance_mutation_and_distance_obey_contract() {
        let a = Genome::from_loci([100; 8]);
        let b = Genome::from_loci([200; 8]);
        let no_mutation = GeneticsConfig {
            mutation_probability_bp: 0,
            mutation_step: 100,
            ..Default::default()
        };
        let mut rng = DeterministicRng::from_seed(4);
        assert_eq!(Genome::child_one(a, &mut rng, &no_mutation), a);
        for _ in 0..100 {
            let child = Genome::child_two(a, b, &mut rng, &no_mutation);
            assert!(child.loci().into_iter().all(|x| x == 100 || x == 200));
        }
        let always = GeneticsConfig {
            mutation_probability_bp: 10_000,
            mutation_step: 20,
            ..Default::default()
        };
        let mut rng = DeterministicRng::from_seed(5);
        assert!((0..100).any(|_| Genome::child_one(a, &mut rng, &always) != a));
        assert_eq!(a.distance(a), 0);
        assert_eq!(a.distance(b), b.distance(a));
        assert!(a.distance(Genome::from_loci([201; 8])) > a.distance(b));
    }
}

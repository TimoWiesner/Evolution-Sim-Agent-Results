//! Trait-derived animal sensing and movement rules.
use crate::{OrganismId, OrganismKind};

/// Maximum cell steps an animal can move during one tick (1..=4).
pub fn movement_range(speed: u16) -> u32 {
    1 + u32::from(speed) * 3 / u32::from(u16::MAX)
}

/// Inclusive toroidal Chebyshev sensing radius (1..=8 cells).
pub fn vision_range(speed: u16) -> u32 {
    1 + u32::from(speed) * 7 / u32::from(u16::MAX)
}

/// Energy charged for each actual cell displacement.
pub fn movement_cost_per_cell(speed: u16) -> u32 {
    100 + u32::from(speed) / 256
}

pub(crate) fn edible_kind(kind: OrganismKind) -> Option<OrganismKind> {
    match kind {
        OrganismKind::Herbivore => Some(OrganismKind::Plant),
        OrganismKind::Carnivore => Some(OrganismKind::Herbivore),
        OrganismKind::Plant => None,
    }
}

pub(crate) fn nearest_edible(
    world: &crate::World,
    actor: OrganismId,
    kind: OrganismKind,
    origin: crate::Cell,
    vision: u32,
) -> Option<(crate::Cell, u32, OrganismId)> {
    let edible = edible_kind(kind)?;
    world
        .organisms_within(origin, vision, Some(edible))
        .into_iter()
        .filter(|candidate| candidate.id != actor)
        .map(|candidate| {
            (
                candidate.position,
                world.grid().distance(origin, candidate.position),
                candidate.id,
            )
        })
        .min_by_key(|(_, distance, id)| (*distance, *id))
}

/// Fixed-point gene-weighted score for visible plant targets. Higher is better.
pub fn foraging_score(bias: u16, plant_energy: u32, distance: u32, vision: u32) -> u64 {
    let vision = vision.max(1);
    let food = (u64::from(plant_energy.min(crate::MAX_ENERGY)) * 65_535
        / u64::from(crate::MAX_ENERGY)) as u32;
    let near = (vision.saturating_sub(distance).min(vision) * 65_535 / vision) as u32;
    u64::from(bias) * u64::from(food) + u64::from(u16::MAX - bias) * u64::from(near)
}

/// Choose visible live, nonempty plants by gene-weighted food/proximity score.
pub(crate) fn best_plant(
    world: &crate::World,
    origin: crate::Cell,
    vision: u32,
    bias: u16,
) -> Option<(crate::Cell, u32, OrganismId)> {
    world
        .organisms_within(origin, vision, Some(OrganismKind::Plant))
        .into_iter()
        .filter(|plant| plant.energy() > 0)
        .map(|plant| {
            let distance = world.grid().distance(origin, plant.position);
            (plant.position, distance, plant.id, plant.energy())
        })
        .max_by(|a, b| {
            foraging_score(bias, a.3, a.1, vision)
                .cmp(&foraging_score(bias, b.3, b.1, vision))
                // max_by keeps the greater item: reverse IDs so lower ID wins ties.
                .then_with(|| b.2.cmp(&a.2))
        })
        .map(|(cell, distance, id, _)| (cell, distance, id))
}

pub fn feeding_maintenance_cost(temperature_centi_c: i16) -> u32 {
    let outside_centi = if temperature_centi_c < -500 {
        i32::from(-500_i16 - temperature_centi_c)
    } else if temperature_centi_c > 3500 {
        i32::from(temperature_centi_c - 3500_i16)
    } else {
        0
    };
    let started_degrees = (outside_centi + 99) / 100;
    100 + (started_degrees as u32).min(5) * 100
}

pub const HERBIVORE_BITE_ENERGY: u32 = 5_000;

pub const ANIMAL_MATURITY_TICKS: u64 = 10;
pub const ANIMAL_REPRODUCTION_ENERGY: u32 = 60_000;
pub const ANIMAL_REPRODUCTION_COST: u32 = 20_000;
pub const ANIMAL_REPRODUCTION_COOLDOWN: u32 = 20;
/// Full Feeding passes spent handling a successful kill before another attack.
pub const CARNIVORE_HANDLING_TICKS: u32 = 20;
pub const MAX_MATE_GENETIC_DISTANCE: u32 = 65_536;

/// Fertility maps linearly to a 5%..=50% per-parent mating trial.
pub fn reproduction_chance_bp(fertility: u16) -> u32 {
    500 + u32::from(fertility) * 4_500 / u32::from(u16::MAX)
}

pub(crate) fn genetically_compatible(a: crate::Genome, b: crate::Genome) -> bool {
    a.distance(b) <= MAX_MATE_GENETIC_DISTANCE
}

pub(crate) fn reproduction_eligible(organism: &crate::Organism) -> bool {
    organism.kind != OrganismKind::Plant
        && organism.age >= ANIMAL_MATURITY_TICKS
        && organism.energy() >= ANIMAL_REPRODUCTION_ENERGY
        && organism.reproduction_cooldown == 0
        && organism.age.saturating_add(1) < u64::from(organism.traits.max_lifespan_ticks)
}

/// Select nearest compatible eligible mate, then lowest ID, across toroidal adjacency.
pub(crate) fn nearest_mate<'a>(
    world: &'a crate::World,
    actor: OrganismId,
    unavailable: &std::collections::BTreeSet<OrganismId>,
) -> Option<&'a crate::Organism> {
    let parent = world.organism(actor)?;
    if !reproduction_eligible(parent) || world.is_pending_death(actor) {
        return None;
    }
    world
        .organisms_within(parent.position, 1, Some(parent.kind))
        .into_iter()
        .filter(|candidate| {
            candidate.id != actor
                && !world.is_pending_death(candidate.id)
                && !unavailable.contains(&candidate.id)
                && reproduction_eligible(candidate)
                && genetically_compatible(parent.genome, candidate.genome)
        })
        .min_by_key(|candidate| {
            (
                world.grid().distance(parent.position, candidate.position),
                candidate.id,
            )
        })
}

/// Attack success probability in basis points, using both hunter and prey traits.
pub fn hunting_chance_bp(strength: u16, aggression: u16, prey_speed: u16, prey_risk: u16) -> u32 {
    (4_000_i64
        + i64::from(strength) * 3_000 / i64::from(u16::MAX)
        + i64::from(aggression) * 2_500 / i64::from(u16::MAX)
        - i64::from(prey_speed) * 2_500 / i64::from(u16::MAX)
        - i64::from(prey_risk) * 1_500 / i64::from(u16::MAX))
    .clamp(1_000, 9_000) as u32
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{Cell, Config, Genome, Simulation};

    #[test]
    fn reproduction_rules_bound_fertility_and_genetic_distance() {
        assert_eq!(reproduction_chance_bp(0), 500);
        assert_eq!(reproduction_chance_bp(u16::MAX), 5_000);
        let a = Genome::from_loci([0; 8]);
        assert!(genetically_compatible(a, Genome::from_loci([8_192; 8])));
        assert!(!genetically_compatible(a, Genome::from_loci([8_193; 8])));
    }

    #[test]
    fn mate_choice_requires_eligible_distinct_same_kind_compatible_neighbor() {
        let mut world = crate::World::new(5, 5).unwrap();
        let genome = Genome::from_loci([0, 0, u16::MAX, u16::MAX, 0, 0, 0, u16::MAX]);
        world.initialize_organism(OrganismKind::Carnivore, Cell { x: 0, y: 0 }, genome);
        world.initialize_organism(OrganismKind::Carnivore, Cell { x: 4, y: 0 }, genome);
        world.initialize_organism(OrganismKind::Carnivore, Cell { x: 1, y: 0 }, genome);
        world.initialize_organism(OrganismKind::Herbivore, Cell { x: 0, y: 1 }, genome);
        world.initialize_organism(OrganismKind::Carnivore, Cell { x: 3, y: 3 }, genome);
        world.initialize_organism(
            OrganismKind::Carnivore,
            Cell { x: 0, y: 1 },
            Genome::from_loci([u16::MAX; 8]),
        );
        let (actor, near, farther, mixed, distant, incompatible) = (1, 2, 3, 4, 5, 6);
        for id in [actor, near, farther, mixed, distant, incompatible] {
            let organism = world.organisms.get_mut(&id).unwrap();
            organism.age = ANIMAL_MATURITY_TICKS;
            organism.set_energy(100_000);
            organism.traits = organism.genome.traits(organism.kind);
        }
        let unavailable = std::collections::BTreeSet::new();
        assert_eq!(nearest_mate(&world, actor, &unavailable).unwrap().id, near);
        world.organisms.get_mut(&near).unwrap().age = ANIMAL_MATURITY_TICKS - 1;
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        {
            let organism = world.organisms.get_mut(&near).unwrap();
            organism.age = ANIMAL_MATURITY_TICKS;
            organism.set_energy(ANIMAL_REPRODUCTION_ENERGY - 1);
        }
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        {
            let organism = world.organisms.get_mut(&near).unwrap();
            organism.set_energy(100_000);
            organism.reproduction_cooldown = 1;
        }
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        {
            let organism = world.organisms.get_mut(&near).unwrap();
            organism.reproduction_cooldown = 0;
            organism.traits.max_lifespan_ticks = (organism.age + 1) as u16;
        }
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        world
            .organisms
            .get_mut(&near)
            .unwrap()
            .traits
            .max_lifespan_ticks = u16::MAX;
        let unavailable = std::collections::BTreeSet::from([near]);
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        world.queue_death(near, crate::DeathCause::Predation);
        let unavailable = std::collections::BTreeSet::new();
        assert_eq!(
            nearest_mate(&world, actor, &unavailable).unwrap().id,
            farther
        );
        world.queue_death(farther, crate::DeathCause::Predation);
        assert_eq!(nearest_mate(&world, actor, &unavailable), None);
    }

    fn movement_fixture(seed: u64, with_plant: bool) -> (Simulation, OrganismId) {
        let mut config = Config::preset("balanced").unwrap();
        config.seed = seed;
        config.world.width = 9;
        config.world.height = 7;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        config.ecology.plant_growth_per_tick_permille = 1;
        config.climate.weather_enabled = false;
        config.climate.seasonal_temperature_amplitude_centi_c = 0;
        let mut sim = Simulation::new(&config);
        let genome = Genome::from_loci([u16::MAX, 0, u16::MAX, 0, 0, 0, 0, u16::MAX]);
        if with_plant {
            sim.queue_birth(
                OrganismKind::Plant,
                Cell { x: 8, y: 3 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        }
        let herbivore = sim
            .queue_birth(
                OrganismKind::Herbivore,
                Cell { x: 0, y: 3 },
                genome,
                [None, None],
                0,
            )
            .unwrap();
        sim.step_one_tick();
        (sim, herbivore)
    }

    #[test]
    fn speed_mappings_and_cost_cover_trait_endpoints() {
        assert_eq!(
            (
                movement_range(0),
                movement_range(21_845),
                movement_range(43_690),
                movement_range(65_535)
            ),
            (1, 2, 3, 4)
        );
        assert_eq!(
            (
                vision_range(0),
                vision_range(9_363),
                vision_range(18_725),
                vision_range(65_535)
            ),
            (1, 2, 3, 8)
        );
        assert_eq!(
            (
                movement_cost_per_cell(0),
                movement_cost_per_cell(255),
                movement_cost_per_cell(256),
                movement_cost_per_cell(65_535)
            ),
            (100, 100, 101, 355)
        );
    }

    #[test]
    fn foraging_scores_and_maintenance_have_documented_boundaries() {
        assert!(foraging_score(0, 1, 0, 8) > foraging_score(0, 1, 1, 8));
        assert!(foraging_score(u16::MAX, 100_000, 7, 8) > foraging_score(u16::MAX, 50_000, 0, 8));
        assert_eq!(feeding_maintenance_cost(-501), 200);
        assert_eq!(feeding_maintenance_cost(-600), 200);
        assert_eq!(feeding_maintenance_cost(3500), 100);
        assert_eq!(feeding_maintenance_cost(3501), 200);
        assert_eq!(feeding_maintenance_cost(9000), 600);
        assert_eq!(HERBIVORE_BITE_ENERGY, 5_000);
    }

    #[test]
    fn hunting_chance_is_trait_sensitive_and_clamped() {
        assert_eq!(hunting_chance_bp(0, 0, u16::MAX, u16::MAX), 1_000);
        assert_eq!(hunting_chance_bp(u16::MAX, u16::MAX, 0, 0), 9_000);
        let baseline = hunting_chance_bp(20_000, 20_000, 20_000, 20_000);
        assert!(hunting_chance_bp(30_000, 20_000, 20_000, 20_000) > baseline);
        assert!(hunting_chance_bp(20_000, 30_000, 20_000, 20_000) > baseline);
        assert!(hunting_chance_bp(20_000, 20_000, 30_000, 20_000) < baseline);
        assert!(hunting_chance_bp(20_000, 20_000, 20_000, 30_000) < baseline);
    }

    #[test]
    fn senses_and_approaches_nearest_food_across_wrap_and_keeps_index_current() {
        let (mut sim, herbivore) = movement_fixture(1, true);
        let plant = sim
            .world()
            .organisms()
            .find(|o| o.kind == OrganismKind::Plant)
            .unwrap()
            .id;
        sim.move_organism(plant, Cell { x: 8, y: 3 }).unwrap();
        sim.set_organism_energy(plant, 1_000).unwrap();
        sim.set_organism_energy(herbivore, 10_000).unwrap();
        assert_eq!(
            nearest_edible(
                sim.world(),
                herbivore,
                OrganismKind::Herbivore,
                Cell { x: 0, y: 3 },
                1
            ),
            Some((Cell { x: 8, y: 3 }, 1, plant))
        );
        sim.step_one_tick();
        assert_eq!(
            sim.world().organism(herbivore).unwrap().position,
            Cell { x: 8, y: 3 }
        );
        assert_eq!(sim.world().organism(herbivore).unwrap().energy(), 10_545);
        assert_eq!(
            sim.world()
                .organisms_within(Cell { x: 8, y: 3 }, 0, None)
                .iter()
                .map(|o| o.id)
                .collect::<Vec<_>>(),
            vec![herbivore]
        );
    }

    #[test]
    fn perception_includes_each_toroidal_edge_and_corner() {
        let (mut sim, herbivore) = movement_fixture(7, true);
        let plant = sim
            .world()
            .organisms()
            .find(|o| o.kind == OrganismKind::Plant)
            .unwrap()
            .id;
        for (observer, food) in [
            (Cell { x: 0, y: 3 }, Cell { x: 8, y: 3 }),
            (Cell { x: 8, y: 3 }, Cell { x: 0, y: 3 }),
            (Cell { x: 4, y: 0 }, Cell { x: 4, y: 6 }),
            (Cell { x: 4, y: 6 }, Cell { x: 4, y: 0 }),
            (Cell { x: 0, y: 0 }, Cell { x: 8, y: 6 }),
        ] {
            sim.move_organism(herbivore, observer).unwrap();
            sim.move_organism(plant, food).unwrap();
            assert_eq!(
                nearest_edible(sim.world(), herbivore, OrganismKind::Herbivore, observer, 1),
                Some((food, 1, plant))
            );
        }
        // The last pair crosses both axes; movement follows the same shortest
        // wrapped step that the perception query measured.
        sim.step_one_tick();
        assert_eq!(
            sim.world().organism(herbivore).unwrap().position,
            Cell { x: 8, y: 6 }
        );
    }

    #[test]
    fn equal_distance_targets_use_lowest_id_and_max_range_allows_four_steps() {
        let mut world = crate::World::new(9, 7).unwrap();
        let center = Cell { x: 4, y: 3 };
        world.initialize_organism(OrganismKind::Herbivore, center, Genome::default());
        world.initialize_organism(OrganismKind::Plant, Cell { x: 3, y: 3 }, Genome::default());
        world.initialize_organism(OrganismKind::Plant, Cell { x: 5, y: 3 }, Genome::default());
        assert_eq!(
            nearest_edible(&world, 1, OrganismKind::Herbivore, center, 1),
            Some((Cell { x: 3, y: 3 }, 1, 2))
        );
        world.initialize_organism(OrganismKind::Carnivore, center, Genome::default());
        assert_eq!(
            nearest_edible(&world, 4, OrganismKind::Carnivore, center, 1),
            Some((center, 0, 1))
        );

        let (mut sim, herbivore) = movement_fixture(8, true);
        let plant = sim
            .world()
            .organisms()
            .find(|o| o.kind == OrganismKind::Plant)
            .unwrap()
            .id;
        sim.move_organism(herbivore, Cell { x: 0, y: 3 }).unwrap();
        sim.move_organism(plant, Cell { x: 5, y: 3 }).unwrap();
        sim.set_organism_energy(herbivore, 10_000).unwrap();
        sim.step_one_tick();
        assert_eq!(
            sim.world().organism(herbivore).unwrap().position,
            Cell { x: 5, y: 3 }
        );
        assert_eq!(sim.world().organism(herbivore).unwrap().energy(), 13_480);
    }

    #[test]
    fn energy_truncates_steps_and_uninteresting_wander_is_seeded() {
        let (mut sim, herbivore) = movement_fixture(15, false);
        sim.move_organism(herbivore, Cell { x: 4, y: 3 }).unwrap();
        // The fixture's queued herbivore has maximum-speed genome.
        sim.set_organism_energy(herbivore, 710).unwrap(); // exactly two 355-cost steps
        sim.step_one_tick();
        let first = &sim
            .world()
            .death_history()
            .iter()
            .find(|death| death.organism.id == herbivore)
            .unwrap()
            .organism;
        assert_eq!(first.energy(), 0);
        assert_eq!(
            sim.world()
                .grid()
                .distance(Cell { x: 4, y: 3 }, first.position),
            2
        );

        let (mut a, aid) = movement_fixture(99, false);
        let (mut b, bid) = movement_fixture(99, false);
        a.step_one_tick();
        b.step_one_tick();
        assert_eq!(
            a.world().organism(aid).unwrap().position,
            b.world().organism(bid).unwrap().position
        );
        assert_eq!(
            a.world().organism(aid).unwrap().energy(),
            b.world().organism(bid).unwrap().energy()
        );

        let mut config = Config::preset("balanced").unwrap();
        config.world.width = 11;
        config.world.height = 7;
        config.initial.plants = 0;
        config.initial.herbivores = 0;
        config.initial.carnivores = 0;
        let mut slow = Simulation::new(&config);
        let id = slow
            .queue_birth(
                OrganismKind::Herbivore,
                Cell { x: 5, y: 3 },
                Genome::default(),
                [None, None],
                0,
            )
            .unwrap();
        slow.step_one_tick();
        slow.step_one_tick();
        let moved = slow.world().organism(id).unwrap();
        assert_eq!(
            slow.world()
                .grid()
                .distance(Cell { x: 5, y: 3 }, moved.position),
            1
        );
        assert_eq!(moved.energy(), 99_800);
    }
}

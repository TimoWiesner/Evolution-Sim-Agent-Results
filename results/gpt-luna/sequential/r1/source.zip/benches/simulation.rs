use evosim::{Config, Simulation};
use std::time::Instant;

const WARMUP_TICKS: u64 = 50;
const MEASURED_TICKS: u64 = 300;
const SAMPLE_EVERY: u64 = 25;

fn main() {
    let json = include_str!("../benchmarks/performance.json");
    let config = Config::from_json(json).expect("fixed benchmark configuration is valid");
    let mut simulation = Simulation::new(&config);
    let initial = simulation.world().organisms().count();
    for _ in 0..WARMUP_TICKS {
        simulation.step_one_tick();
    }
    let warmup_population = simulation.world().organisms().count();
    let mut sampled_min = warmup_population;
    let mut sampled_sum = warmup_population as u64;
    let mut samples = 1_u64;
    let started = Instant::now();
    for tick in 1..=MEASURED_TICKS {
        simulation.step_one_tick();
        if tick % SAMPLE_EVERY == 0 || tick == MEASURED_TICKS {
            let population = simulation.world().organisms().count();
            sampled_min = sampled_min.min(population);
            sampled_sum += population as u64;
            samples += 1;
        }
    }
    let elapsed = started.elapsed().as_secs_f64();
    let final_population = simulation.world().organisms().count();
    println!(
        "seed={} warmup_ticks={} measured_ticks={} initial_population={} warmup_population={} final_population={} sampled_min={} sampled_mean={:.1} elapsed_seconds={:.6} ticks_per_second={:.2}",
        config.seed,
        WARMUP_TICKS,
        MEASURED_TICKS,
        initial,
        warmup_population,
        final_population,
        sampled_min,
        sampled_sum as f64 / samples as f64,
        elapsed,
        MEASURED_TICKS as f64 / elapsed,
    );
}

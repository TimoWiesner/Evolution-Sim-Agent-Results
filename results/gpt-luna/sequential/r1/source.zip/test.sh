#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
cargo test
node --test tests-js/*.test.js
python3 tests/ui_http_probe.py

# Evolution Simulation

Evolution Simulation is a deterministic, seed-based raster food-chain model. It
runs headlessly for experiments or in a local browser UI.

## Install and test

On Ubuntu 24.04 with Rust/Cargo, Node.js and Python 3 installed:

```sh
./setup.sh
./test.sh
```

`./setup.sh` builds the release launcher; `./evosim` can also build on first
use. `./test.sh` runs Rust, JavaScript and UI HTTP tests. To make a distributable
use `./build.sh`, which creates `dist/evosim`.

The distributable runs outside the source tree without Rust/Cargo, Node or
project files; it uses the target Ubuntu system ABI.

## Headless runs

```sh
./evosim run --config examples/minimal.json --ticks 1000 --out result.json
./evosim run --config examples/minimal.json --seed 7 --ticks 1000 --sample-every 10 --out result.json --save checkpoint.json
./evosim run --load checkpoint.json --ticks 1000 --out resumed.json
```

`run` writes result JSON with final populations, lifecycle totals, sampled
series, species and trait metrics, state hash, and elapsed time. `--seed`
overrides the file seed. A loaded run advances the requested additional ticks.

## Batch runs

```sh
./evosim batch --config examples/minimal.json --seeds 1,2,3 --ticks 1000 --out-dir results
```

The output directory must already exist. Each seed gets a result JSON and the
directory gets `summary.json`. Integer parameter sweeps can be added with
`--vary initial.plants=300,400`; repeated `--vary` options form a Cartesian
product. Optional `--csv FILE` writes a summary table.

## Browser UI

```sh
./evosim ui
```

The browser interface includes map pan/zoom, run/pause/step, reset, speed
selection, configuration presets and JSON import/export, charts, organism
inspection, and checkpoint download/upload. Supply `--config FILE` to start
from a configuration. For automated checks, `--smoke-test` and
`--screenshots DIR` run the real interface in Chromium.

## Configuration

Configuration is JSON. The fixed keys below are sufficient; all other groups
are optional and default as shown. Integer ranges are inclusive.

| Field | Default | Valid range |
|---|---:|---:|
| `seed` | `42` in the example | required unsigned 64-bit integer |
| `world.width` | `64` in the example | required, 1–4096 cells |
| `world.height` | `48` in the example | required, 1–4096 cells |
| `initial.plants` | `400` in the example | required, 0–1,000,000 |
| `initial.herbivores` | `120` in the example | required, 0–1,000,000 |
| `initial.carnivores` | `20` in the example | required, 0–1,000,000 |
| `climate.season_length_ticks` | `240` | 1–100,000 |
| `climate.seasonal_temperature_amplitude_centi_c` | `1800` | 0–6,000 |
| `climate.precipitation_seasonality_bp` | `2500` | 0–10,000 basis points |
| `climate.weather_enabled` | `true` | boolean |
| `ecology.plant_growth_per_tick_permille` | `35` | 1–1,000 permille |
| `ecology.resource_capacity` | `1000` | 1–1,000,000 per cell |
| `ecology.animal_metabolism_per_tick` | `3` | 0–10,000 |
| `ecology.reproduction_energy_threshold` | `100` | 1–10,000 |
| `genetics.mutation_probability_bp` | `250` | 0–10,000 basis points |
| `genetics.mutation_step` | `2048` | 0–65,535 |

For example, copy `examples/minimal.json` and edit any fields. The UI can
import/export JSON configurations.

## Demo and measured ecology

Start the bundled scenario with one command:

```sh
./evosim run --config scenarios/demo.json --ticks 10000 --out demo-result.json
```

The demo uses a 64×48 grid with 1,200 plants, 160 herbivores and 4 carnivores;
it uses the documented default climate, ecology and genetics settings. Three
10,000-tick runs (seeds 1, 2 and 4) had all three kinds coexisting for 1,101,
1,153 and 1,135 ticks, respectively. On the exact contract defaults, seeds 1,
2 and 3 coexisted for 214, 174 and 196 ticks. These are observations, not a
guarantee of coexistence; extinction remains possible. Per-kind extinction
ticks and final populations are in
[docs/VERIFICATION.md](docs/VERIFICATION.md).

## Verification and architecture

See [docs/VERIFICATION.md](docs/VERIFICATION.md) for the contract evidence
matrix and project self-audit, and [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
for the engine overview. `docs/decisions/` contains implementation decisions.

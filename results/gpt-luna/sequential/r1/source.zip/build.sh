#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
"$ROOT/setup.sh"
mkdir -p "$ROOT/dist"
install -m 0755 "$ROOT/target/release/evosim" "$ROOT/dist/evosim"

# TASK-027 Ecosystem balance measurements

## Baseline before ecology changes

The pristine baseline used the fixed-key example from CONTRACT section 3:
`tasks/TASK-027/fixtures/default.json` (64x48, 400 plants, 120 herbivores,
20 carnivores, seed overridden per run). The required batch command was:

```sh
./evosim batch --config tasks/TASK-027/fixtures/default.json --seeds 1,2,3,4,5,6,7,8,9,10 --ticks 10000 --out-dir results/TASK-027/baseline-batch --vary initial.plants=400
```

The single-value `--vary initial.plants=400` is a no-op compatibility argument:
the current batch implementation rejects the contract-valid command without
`--vary`. No simulation source or parameters were changed before this batch.
The batch completed successfully (10 seeds, 10,000 ticks each). Its summary
is `results/TASK-027/baseline-batch/summary.json`; per-seed output also records
all cumulative deaths by cause.

Exact extinction ticks and population curves were collected with the same
configuration using interval-1 runs through tick 250:

```sh
seq 1 10 | xargs -P 4 -I{} sh -c './evosim run --config tasks/TASK-027/fixtures/default.json --seed "$1" --ticks 250 --sample-every 1 --out "results/TASK-027/baseline-curves/seed-$1.json"' _ {}
```

All runs started at (plants, herbivores, carnivores) = (400, 120, 20). The
first zero was herbivores for every seed. Every herbivore death at that point
was recorded as predation (120/120); there were no herbivore births. Plants
were still alive at tick 250 and in all ten 10,000-tick batch results. The
secondary carnivore extinction occurred after herbivore extinction and all 20
carnivore deaths were starvation by tick 10,000. Thus the first limiting cause
is carnivore predation eliminating the herbivore population, followed by
starvation of the predator population. This is direct cause-of-death evidence,
not an inference from the final counts alone.

| Seed | First extinction | Tick | Herbivore deaths by cause at zero | Carnivore zero tick | Batch plants at 10,000 |
|---:|---|---:|---|---:|---:|
| 1 | herbivores | 46 | predation 120 | 199 | 10,956 |
| 2 | herbivores | 46 | predation 120 | 170 | 11,032 |
| 3 | herbivores | 39 | predation 120 | 191 | 11,091 |
| 4 | herbivores | 32 | predation 120 | 180 | 11,001 |
| 5 | herbivores | 40 | predation 120 | 168 | 10,913 |
| 6 | herbivores | 71 | predation 120 | 200 | 10,899 |
| 7 | herbivores | 51 | predation 120 | 185 | 10,996 |
| 8 | herbivores | 58 | predation 120 | 200 | 10,937 |
| 9 | herbivores | 48 | predation 120 | 173 | 10,934 |
| 10 | herbivores | 96 | predation 120 | 202 | 10,976 |

Across the exact curves, the mean population (range across the ten seeds) at
selected ticks was:

| Tick | Plants | Herbivores | Carnivores |
|---:|---:|---:|---:|
| 0 | 400 (400–400) | 120 (120–120) | 20 (20–20) |
| 10 | 12,287 (12,283–12,288) | 69 (59–81) | 20 (20–20) |
| 20 | 12,288 (12,288–12,288) | 35 (25–47) | 20 (20–20) |
| 30 | 12,288 (12,286–12,288) | 15 (1–26) | 20 (20–20) |
| 40 | 12,288 (12,288–12,288) | 5 (0–17) | 20 (20–20) |
| 50 | 12,288 (12,288–12,288) | 1 (0–6) | 20 (20–20) |
| 75 | 12,217 (12,196–12,229) | 0.1 (0–1) | 20 (20–20) |
| 100 | 12,141 (12,102–12,163) | 0 (0–0) | 17 (15–19) |
| 150 | 11,832 (11,796–11,873) | 0 (0–0) | 7 (5–12) |
| 200 | 10,667 (10,590–10,739) | 0 (0–0) | 0.1 (0–1) |
| 250 | 12,287 (12,284–12,288) | 0 (0–0) | 0 (0–0) |

The batch's complete 10,000-tick cause totals agree: each seed had 120
herbivore deaths, all predation; 20 carnivore deaths, all starvation; and
roughly 399,999–406,360 plant deaths, mostly climate (398,529–404,551) with
1,183–1,966 age deaths. Plants reproduced 410,555–416,897 times and remained
at 10,899–11,091 individuals. Plant population is not the limiting food source
in this baseline. The major early signal is sustained predator activity with
no predator handling delay, erasing prey before the first reproductive event.

This diagnosis was written after the unchanged batch and interval-1 baseline
runs, and before the first ecology source change.

## Trial 1: local carnivore handling delay

- **Changed:** After each successful predation event, that carnivore cannot
  attack for the next 20 Feeding passes. Its usual 500-energy cost continues.
  The delay applies to each carnivore regardless of population size.
- **Expected:** Slow the kill rate enough for herbivores to feed and reproduce
  before predators remove them, extending coexistence without changing attack
  odds or adding a population rule.
- **Measured:** Required 10,000-tick batch on tuning seeds 1–10, with the same
  fixed-key config and a single-value no-op sweep for the batch parser. Exact
  interval-1 curves were collected through tick 250.
- **Per-seed first zero:**

| Seed | First extinction | Tick | Herbivore deaths at zero | Herbivore births by 10,000 | 10,000-tick result |
|---:|---|---:|---|---:|---|
| 1 | herbivores | 214 | predation 120 | 0 | plants only |
| 2 | herbivores | 174 | predation 120 | 0 | plants only |
| 3 | herbivores | 196 | predation 120 | 0 | plants only |
| 4 | herbivores | 189 | predation 120 | 0 | plants only |
| 5 | herbivores | 186 | predation 120 | 0 | plants only |
| 6 | herbivores | 229 | predation 120 | 0 | plants only |
| 7 | herbivores | 174 | predation 120 | 0 | plants only |
| 8 | herbivores | 197 | predation 120 | 0 | plants only |
| 9 | herbivores | 179 | predation 122 | 2 | plants only |
| 10 | herbivores | 215 | predation 130 | 10 | plants only |

Mean first-extinction tick was 195.3 versus 52.7 at baseline (3.71 times as
long). Across the ten full batch runs, every herbivore and carnivore population
was zero by tick 10,000; carnivore deaths were starvation. Plants ended at
10,960–11,050. Herbivore births occurred in only two of ten seeds and did not
prevent extinction. This is a clear but incomplete improvement; it does not
reach long coexistence.

The trial's interval-1 mean population curves (range across seeds) show the
mechanism's effect and eventual failure:

| Tick | Plants | Herbivores | Carnivores |
|---:|---:|---:|---:|
| 0 | 400 (400–400) | 120 (120–120) | 20 (20–20) |
| 10 | 12,287 (12,281–12,288) | 102 (101–104) | 20 (20–20) |
| 30 | 12,288 (12,286–12,288) | 85 (82–89) | 20 (20–20) |
| 50 | 12,288 (12,288–12,288) | 70 (67–75) | 20 (20–20) |
| 100 | 12,142 (12,123–12,174) | 37 (30–47) | 20.1 (20–21) |
| 150 | 11,838 (11,819–11,871) | 13 (7–23) | 20.3 (20–22) |
| 200 | 10,670 (10,557–10,754) | 1 (0–4) | 17.5 (15–21) |
| 250 | 12,287 (12,281–12,288) | 0 (0–0) | 8.3 (4–15) |

Population curves show herbivores remain available roughly three to four times
longer, while carnivores remain near 20 during much of that interval. They
still decline after prey loss, and the plants refill their occupancy cap.

Trial and baseline batch throughput were similar on this host: mean 290.29
versus 292.42 ticks/s across ten runs (median 290.19 versus 292.38). These
batch `ticks_per_second` values are run-specific observations, not the TASK-026
dense benchmark.

## Held-out defaults check: seeds 11–15

The chosen 20-tick handling delay was frozen before this check. Each seed ran
10,000 ticks through `./evosim batch`; interval-1 `run` measurements through
tick 1,000 establish exact extinction ticks and causes. The batch confirms the
same populations remain extinct at tick 10,000. Results:

| Seed | First extinction | Tick | Herbivore deaths at zero | Carnivore extinction | Carnivore deaths | Plants at 10,000 |
|---:|---|---:|---|---:|---|---:|
| 11 | herbivores | 214 | predation 120 | 331 | starvation 20 | 10,966 |
| 12 | herbivores | 245 | predation 137 | 386 | starvation 20 | 10,984 |
| 13 | herbivores | 155 | predation 120 | 261 | starvation 20 | 10,943 |
| 14 | herbivores | 224 | predation 120 | 328 | starvation 20 | 10,995 |
| 15 | herbivores | 186 | predation 120 | 313 | starvation 20 | 10,940 |

Held-out mean coexistence was 204.8 ticks. Herbivore reproduction occurred in
one seed (17 births in seed 12), but all herbivores still died by predation.
All three kinds did not coexist to 10,000 ticks on any held-out seed. The
result is consistent with the tuning batch and does not support claiming the
goal was reached.

### Repeat performance benchmark

`cargo bench --bench simulation` passed twice on the TASK-026 fixed workload.
Both runs used seed 26026, 50 warm-up ticks, 300 measured ticks, initial
population 3,000, warm-up population 12,307, final population 11,964, sampled
minimum 10,412 and sampled mean 11,931.7. The first run measured 230.52 ticks/s
in 1.301419 seconds; the final run after the code cleanup measured 239.00
ticks/s in 1.255204 seconds. The final run is 0.95% below TASK-026's recorded
241.28 ticks/s median and remains above its 100 ticks/s target. The workload is
plant-heavy and does not represent mixed food-chain throughput.

# Architecture ledger

## TASK-025 UI scenarios and charts plan (PLAN cycle 1)

Extend the TASK-024 browser UI with a full editable draft of the existing
`Config`: preset selection (`balanced`, `lush`, `harsh`), seed, dimensions,
initial populations, and every climate/ecology/genetics parameter. A pure
`ui/config-model.js` mirrors Rust defaults and validation ranges, reports
errors by field, normalizes JSON import/export, and prevents reset while any
field is invalid; Rust `/api/reset` validation remains authoritative. Add
ordered preset data from `/api/presets`.

Add display-free `ui/chart-data.js` transforms and dependency-free SVG charts
for population, cumulative births/deaths, living species, mean speed, and a
selectable current-population trait distribution. Each chart has labeled axes
and a legend. `src/ui.rs` keeps up to 1,000 read-only `MetricsSample` values,
seeds them at initial/reset/restored state, and appends once per explicit
advance request. `/api/charts` exposes ordered samples and current trait
values. This observer data is outside checkpoints and canonical state. Extend
real Chromium screenshot automation to write both required `main.png` and
`charts.png` views after at least 100 ticks. Ordered steps and verification are
in `tasks/TASK-025/handoffs/plan-cycle1.md`; ADR-025 records tradeoffs. No new
runtime packages or system dependencies are planned.

## TASK-023 UI world view plan (PLAN cycle 1)

Build the browser interface selected by ADR-002. `src/ui.rs` will serve a
loopback-only local page and a compact ordered snapshot from the shared Rust
`Simulation`; bundled static assets in `ui/` will draw every cell's current
climate/biome and overlay distinct plant, herbivore and carnivore symbols on a
canvas. Include a visible legend, drag pan and wheel zoom, and reserve layout
space for TASK-024/025. Smoke and screenshot modes will automate the real page
with Chromium, advance at least 10/100 engine ticks, and enforce contract
timeouts. See ADR-023 and `tasks/TASK-023/handoffs/plan-cycle1.md`. No new
crate or system package is planned.

## TASK-022 savegames and checkpoints (PLAN cycle 1)

Implement `--save` and mutually exclusive `--config`/`--load` in
`src/cli.rs`, using a versioned UTF-8 JSON checkpoint with no compression.
The envelope carries effective config, absolute tick, complete ChaCha8
continuation state, and the complete ordered `WorldClimateState`. Add an
explicit restore constructor across `src/simulation.rs` and `src/world.rs`;
validate serialized invariants before restoring and rebuild only the derived
spatial index. Preserve absolute ticks and cumulative lifecycle counters when
continuing. Save only after the requested ticks complete. Add split-run
equivalence coverage including tick zero and malformed/missing/truncated/
unsupported-version no-output CLI cases. See ADR-022 and
`tasks/TASK-022/handoffs/plan-cycle1.json`.

## TASK-020 metrics implementation (IMPLEMENT cycle 2)

Add read-only sampled analytics as an additive `metrics` array in the existing
`evosim run` result, one record at each existing `series` sample tick. Each
record carries per-kind population, cumulative birth/death counts, living
species, death counts cross-tabulated by kind and cause, mean and population
standard deviation for every applicable trait, and highest/mean generation
per kind. Empty-population statistics and traits that do not apply to plants
are JSON `null`; all six death-cause keys are present. Proposed ADR-020 defines
the exact format and rationale.

`src/metrics.rs` implements the read-only sampler over `&Simulation`, captured
alongside CLI `series` samples. The explicit two-plant fixture sets speed to 10
and 14 and generation to 2 and 4, asserting mean 12, population standard
deviation 2, highest generation 4, and mean generation 3. Lifecycle/cause and
null checks, CLI sample alignment, and the paired observed/unobserved state-hash
regression remain covered. IMPLEMENT cycle 2 passes focused metrics tests (3),
the CLI metrics alignment test (1), full `cargo test` (75 passed, 1 ignored),
formatting, and whitespace checks. No dependency or system package was added.
Reporting costs O(live population plus death history) at each sample. See
`tasks/TASK-020/handoffs/implement-cycle2.json` for exact evidence.

## TASK-021 batch runs and parameter sweeps (PLAN cycle 1)

Extend the shared headless CLI in `src/cli.rs` and dispatcher in `src/lib.rs`
with `evosim batch --config FILE --seeds S1,S2 --ticks N --out-dir DIR
--vary FIELD=V1,V2 [--vary FIELD=... ] [--csv FILE]`. Sweeps use supported
dotted integer configuration leaves and expand as a Cartesian product; all
candidate configs are validated before simulation. Runs execute sequentially
in listed seed/value order and reuse the ordinary run result schema. Output
files use the contract `seed-<seed>.json` for a single variation and stable
parameter suffixes when needed to prevent collisions.

Write ordered per-run metadata and deterministic per-kind final population
mean/min/max and extinction counts to `summary.json`. Summary data excludes
wall-clock timing; individual run files retain the ordinary timing fields.
Optional CSV is a deterministic row-per-run export of the same summary data.
Add CLI integration tests for a 2-value by 2-seed matrix, aggregates, CSV,
invalid input, and exact repeated summary equality. ADR-021 records exact
parsing, output, and failure decisions. No dependencies or system packages
are planned.

## TASK-018 ecology integration implementation

## TASK-018 ecology integration implementation

Preserve the seven-stage schedule in `Simulation::step_one_tick`: climate and
weather, plant growth/resources, animal movement, herbivore feeding followed by
carnivore hunting, plant reproduction followed by animal reproduction, aging
and mortality, then birth finalization and species extinction reconciliation.
Exercise this as one food chain. Detailed sub-order is climate/weather and
soil replenishment, plant growth, animal movement, herbivore grazing then
carnivore hunting, plant then animal reproduction, aging and mortality, birth
commit, and species extinction reconciliation. The existing seven
`TickReport::phases` are Climate, PlantGrowth, AnimalMovement, Feeding,
Reproduction, Mortality, Finalize. Focused tests prove fixed-key 1,000-tick
execution, lifecycle accounting after each tick, no-plant and no-herbivore
extinction, plants-only persistence/reproduction, and well-fed herbivore
survival/reproduction for 300 ticks. The herbivore fixture retains default
climate, ecology, and genetics values on the fixed-key 64x48 world with 400
plants; compatible high-fertility founders are staged at one cell. Defaults
needed no tuning and no global population count behavior was added. The
ignored five-seed, 10,000-tick test
is invoked with `cargo test --release --test ecology
report_five_seeds_10000_ticks -- --ignored --nocapture`; actual outcomes are
recorded in ADR-018 and the TASK-018 implementation handoff. No crates or
system packages were added.

## TASK-017 species and family tree implementation

`Organism` retains its species ID. `World` assigns organisms once at initial
creation or birth queue time against immutable founder representatives of the
same kind, using inclusive `Genome::distance <= 65,536` (mean normalized
distance <=8,192), nearest distance then species ID. Species have global
monotonic IDs and deterministic kind-prefixed padded names. Records retain
representative genome, parent species, origin tick, and extinction tick.
Extinct species are excluded from future assignment. The scheduler reconciles
extinction after deaths and committed births, and `World::living_species_count`
reports per-kind live species. `WorldClimateState` snapshots include species
records and the next species ID. See ADR-017 and the TASK-017 implementation
handoff for tests and evidence; no dependency or system package was added.

## TASK-016 animal reproduction plan

Extend the existing `Reproduction` slot in `src/simulation.rs` after asexual
plant reproduction. Add per-organism animal cooldown state in `src/entity.rs`;
initialize it to zero and update it once per tick. Resolve potential pairs in
ascending ID order. Use `World::organisms_within` and toroidal Chebyshev radius
one to find a distinct same-kind, living, non-pending-death mate. Choose nearest
distance, then lower ID, among genetically compatible candidates, defined as
ADR-004 genome distance <=65,536. Require both animals to be age >=10, energy
>=60,000, cooldown zero and not due for lifespan death. Each must pass a seeded
fertility trial at `500 + floor(fertility * 4,500 / 65,535)` basis points;
resolve those trials in ID order only once a pair is otherwise eligible. Track
used parents during the tick so no parent mates twice.

On success, choose one parent's current cell with a seeded 50/50 draw, call
`Simulation::child_genome_two`, and queue one same-kind child with parent IDs in
ascending order and checked `max(parent generation)+1`. Deduct 20,000 energy from
each parent and set a 20-tick cooldown only after successful queueing. Animals
may share cells without a local cap. Finalize continues to defer newborn
activation. The exact decision and draw order are in ADR-016.

Implementation order: add the cooldown field and tests; add animal eligibility,
mate selection, fertility and compatibility helpers in `src/animal.rs`; add
the stable pairing loop to `src/simulation.rs`; verify deterministic crossover,
mutated genomes, lineage, costs, cooldown and newborn timing; retain and rerun
plant reproduction tests; update ADR-016, architecture, STATE and phase
handoffs. Run focused reproduction tests, `cargo test`,
`cargo fmt --all -- --check`, and `git diff --check`. No crate or system
package is planned.

Risks: reproduction follows plant reproduction in the same RNG stream, so
random draw order depends on existing plant attempts and must remain stable.
Cooldown decrement timing, pair ownership and failed fertility trials must be
explicitly tested to prevent repeat charges or order-dependent double mating.
The selected local radius, fixed energy values, fertility mapping and genetic
threshold are simplified ecological parameters. Future checkpoint support must
include the added cooldown field.

## TASK-015 carnivore hunting plan

Keep attacks in the existing `Feeding` slot in `src/simulation.rs`, after
herbivore grazing and after the shared `AnimalMovement` slot. Carnivores already
approach the nearest visible herbivore. Resolve one attack attempt per
carnivore, in ascending ID order, against the nearest living herbivore at
toroidal Chebyshev distance 0 or 1. Filter pending-death prey. Roll a bounded
10,000-outcome chance based on both animals' strength, aggression, speed and
risk tolerance using the simulation RNG; the exact basis-point formula is in
ADR-015. On success queue `DeathCause::Predation` and transfer only
`min(prey.energy, MAX_ENERGY - hunter.energy)`. Each carnivore pays 500 energy
per tick whether it attacks, misses or has no adjacent prey, and queues
starvation at zero. Stable sequential order means a miss leaves prey available
to later IDs, while a successful queued kill is unavailable to them.

Implementation order: add pure attack-chance and cost helpers in
`src/animal.rs`; add a carnivore hunting routine called from the existing
Feeding phase in `src/simulation.rs`; use `World::organisms_within` and
`World::is_pending_death`, with existing energy setters and deferred death
queue; then test target pursuit/attack distance, both attack outcomes across
many deterministic attempts, trait effects, one-time predation accounting,
bounded energy transfer, missed/no-prey costs and starvation. Update ADR-015,
architecture, STATE and task handoffs with exact verification. No new phase,
configuration key, crate or system package is planned.

## TASK-014 herbivore feeding and behavior plan

Keep feeding in the existing `Feeding` scheduler slot after AnimalMovement and
before reproduction/mortality. Add pure integer helpers to `src/animal.rs` for
foraging target scoring, per-tick bite bounds, and herbivore maintenance cost.
Herbivores consider living plants in their existing speed-derived inclusive
toroidal vision radius. Rank candidates with a deterministic score that blends
normalized plant energy and proximity using the genome-derived
`foraging_bias`: zero favors proximity and maximum bias favors stored plant
energy. Break score ties by stable organism ID. Use the same rule for local
feeding candidates, but permit energy transfer only at toroidal Chebyshev
distance zero or one (same or adjacent cell, including diagonals).

Each herbivore gets at most one bite of at most 5,000 energy per tick. Transfer
no more than the plant's current energy or the herbivore's remaining energy
capacity; deduct exactly what is granted from the plant and grant exactly that
amount to the herbivore. A plant reduced to zero queues `DeathCause::Starvation`
for existing Mortality processing and is excluded from later bites that tick.
Herbivores pay 100 energy maintenance per tick plus 100 per each 10 C beyond a
documented comfortable range of -5 C through 35 C, capped at 500 extra. Charge
after feeding; queue starvation when resulting energy is zero. Climate comes
from the herbivore's current cell. Keep actors in ascending ID order and use
existing staged death/mortality behavior; no new configuration key or global
population check is introduced. Keep carnivore feeding/attacks out of scope.

Implementation sequence: (1) document the exact integer score, tie-break,
bite and maintenance formula in ADR-014; (2) add bounded World/Simulation
energy-transfer access that cannot create energy, or use an existing
crate-visible bounded mutator behind a single simulation helper; (3) make
herbivore movement target selection use the foraging gene while preserving
carnivore selection behavior; (4) implement ordered herbivore local feeding,
maintenance, zero-energy plant exclusion and starvation queuing; (5) add pure
helper tests plus integration cases for vision/range, same/adjacent versus
far cells, exact plant-to-animal accounting, bite and capacity limits,
depleted plant mortality, per-tick maintenance, extreme climate costs, and two
genomes choosing different actions in one fixed world; (6) update ADR-014,
architecture, STATE and handoffs with actual verification. No package or crate
is planned. Run focused tests, `cargo test`, `cargo fmt --all -- --check`, and
`git diff --check` during implementation.

Risks: movement and feeding are ordered sequentially, so later herbivores may
observe energy already removed by earlier actors; ascending IDs make this
repeatable. The blended foraging score and energy scale are simplified model
choices, not empirical physiology. Existing mortality resolves after all
feeding, so zero-energy plants must be filtered from candidate queries while
pending death to prevent a second transfer.

## TASK-013 animal sensing and movement implementation

Implement animal-only perception and motion in the existing `AnimalMovement`
slot in `src/simulation.rs`; do not add feeding or attack behavior. Add
`src/animal.rs` pure helpers for trait mappings: normalized speed maps to 1..=4
cell steps per tick and 1..=8 cells of inclusive toroidal Chebyshev vision.
Use `World::organisms_within` for indexed perception. For each visible animal,
select the nearest non-self edible kind (plants for herbivores, herbivores for
carnivores), breaking ties by ascending ID. Walk the shortest `Grid::direction`
one cell at a time, up to the speed-derived range or target. With no visible
edible target, choose one of eight adjacent directions using the simulation
RNG and walk up to the same range. Do not eat or attack.

Charge `100 + speed / 256` energy per actual cell of displacement. If current
energy funds only a prefix of the chosen path, perform only that prefix and
deduct its exact cost; zero energy prevents movement. Cells have unrestricted
sharing for every kind, so occupied destinations never block movement. All
movement calls use `Simulation::move_organism` to keep `World`'s derived
spatial index current. Capture starting live animal IDs before processing so
newborns cannot act in the same tick. Process IDs ascending; because movement
is sequential, later actors see earlier actors' new positions. The complete
decision and rationale are in ADR-013.

`src/animal.rs` contains the documented mapping and target-selection helpers;
`Simulation::move_animals` runs at the existing AnimalMovement slot. Tests
cover mapping and cost boundaries, indexed food sensing across all four edges
and a corner, shortest wrapped cardinal and diagonal approach, one-step and
four-step movement bounds, equal-distance target ID ordering, per-cell cost,
energy truncation, repeatable seeded wandering, and index consistency when
occupants share a destination and mortality removes a plant. Exact commands
and results are recorded in the TASK-013 implementation handoff. No system
packages or new crates were added.

## TASK-012 plant reproduction

Implement asexual reproduction in the existing `Reproduction` slot in
`src/simulation.rs`; do not add a reproduction phase or configuration keys.
Process a snapshot of living plant IDs in ascending order after growth and
before mortality/finalization. A plant with at least 60,000 energy attempts at
most one child per tick; successful reproduction costs 20,000 energy. Use the
simulation RNG to sample one nonzero offset in the square `[-2, 2] x [-2, 2]`,
then use `Grid::wrap` so dispersal works across torus seams. The attempt fails
without cost if the destination has four plants already (count live and
pending births) or has no soil water. Do not scan/retry alternate cells.
Generate a mutated one-parent genome with `child_genome_one` only after the
destination passes; queue the plant birth with its parent ID and checked next
generation, then deduct energy only after queueing succeeds. Existing Finalize
commits the child at age zero, so it cannot act in the birth tick. The exact
rationale and simplified local carrying capacity are in ADR-012.

Implementation sequence: (1) add a World query/helper that counts live and
pending plants at a cell and checks local establishment capacity/resources;
(2) implement the ordered Reproduction loop, candidate wrapping, parent cost,
mutated genome, lineage metadata and staged insertion; (3) test eligibility,
cost/no-cost outcomes, local cap/resource rejection, torus dispersal,
inheritance/mutation and lineage, maximum one child per parent, newborn timing,
and zero-plant persistence; (4) run focused and complete tests, formatter and
diff checks; (5) update ADR-012, STATE and this ledger with actual results.
`World::can_establish_plant` checks local soil water and counts indexed live
plants plus staged births at the destination. Plants due to die from lifespan
or hostile climate are skipped in reproduction. Focused tests exercise lineage,
mutation, radius and seam wrapping, delayed newborn age, local water/cap
rejection, and persistence of a zero-plant world. No system packages or Cargo
dependencies were added.

## TASK-010 spatial search implementation

Implement `SpatialIndex` in `src/spatial_index.rs` as a `Vec<Vec<OrganismId>>`
with one bucket per row-major grid cell. `World` owns it and remains the only
owner of mutable organism positions. Add `World::move_organism(id, destination)`
to validate the cell and update the old/new buckets together with the canonical
organism position; index initialization adds initial organisms and finalized
births, while mortality removes IDs. The public query is
`World::organisms_within(center, radius, kind: Option<OrganismKind>)`, returning
organism references sorted by ascending stable ID. It uses
`Grid::neighborhood(center, radius)` (inclusive toroidal Chebyshev metric,
unique row-major cells), gathers bucket IDs, sorts them, and resolves each once
through the `BTreeMap`. No bucket iteration order becomes observable. Keep the
index derived rather than serialized in snapshots/checkpoints; reconstruct it
from canonical organism positions. If organism positions become mutable via an
API, route those changes through `World` so index maintenance cannot be
bypassed.

`src/spatial_index.rs` implements the derived buckets. `World` exposes
`organisms_within`; `World::move_organism` and the `Simulation` forwarding
method validate and synchronously update the canonical position and bucket.
Initial placement, finalized births, and mortality removals update membership.
The index is excluded from snapshots and reconstructs from canonical positions
on world construction. `tests/spatial_index.rs` covers movement and lifecycle
maintenance, ordering, filtering, invalid query centers, and 6,000 deterministic
queries compared with a brute-force oracle across degenerate/small worlds and
oversized radii. The benchmark command and measured timings are recorded in
`docs/STATE.md`. No new crate or system dependency was added. TASK-013 depends
on this API for sensing and movement.

## TASK-008 organisms and shared lifecycle

`src/entity.rs` defines `OrganismKind`, bounded `Traits`, `Organism`, death
records and per-kind initial/birth/death counters. `World` stores live entities
in a `BTreeMap` keyed by monotonically allocated IDs; its read-only iterator is
ascending by ID. Initial entities are built by `Simulation::new` in Plant,
Herbivore, Carnivore order with two deterministic RNG coordinate draws each.
Energy is private and clamped to 0..=100,000; health is private and clamped to
0..=the trait maximum (itself u16). `Simulation::queue_death` records the
first requested cause for a live ID. `Simulation::queue_birth` assigns an ID
immediately but stages the entity until Finalize. Each tick ages the existing
set, resolves ordered deaths at Mortality, then commits births at Finalize, so
newborns begin at age zero and cannot be removed or act in their birth tick.
Snapshots capture live/pending entities, next ID, counts and ordered death
history alongside climate/RNG state. This task adds no behavior, genome, or
species logic. Focused coverage is in `tests/simulation.rs` and
`src/entity.rs`; no OS packages or new Cargo dependencies are needed.

## TASK-005 clock, RNG, and scheduler

TASK-005 adds the deterministic frame around the existing `Config` and `Grid`;
it does not add climate, plant, or animal behavior. Follow ADR-007 for seed
expansion, state export, scheduler phases, and stable tie-breaking.

Planned interfaces and files:

- `Cargo.toml` / `Cargo.lock`: add `rand_chacha` and `rand_core` (ChaCha8 and
  seed/RNG traits); no system packages.
- `src/rng.rs`: `DeterministicRng::from_seed(u64)`, `next_u32`, `next_u64`,
  `export_state() -> RngState`, and `from_state(RngState)`. RngState is the
  expanded seed bytes, stream, and word position. Fix a SplitMix64 expansion
  and golden output tests.
- `src/world.rs`: initial `World` owns validated `Grid`; expose grid read-only.
- `src/simulation.rs`: `Simulation::new(&Config)`, `tick()`,
  `step_one_tick() -> TickReport`, `tick_index()`, `world()`, and RNG state
  snapshot. A single call increments the absolute tick exactly once. Tick
  reports carry the ordered phase sequence and any future ordered events.
- `src/lib.rs`: export the simulation, world, RNG and scheduler types; engine
  modules must not import UI/CLI modules.
- `tests/simulation.rs` and `src/rng.rs` unit tests: RNG golden vector and
  restoration; exact tick increments and phase order; equal-seed trace equality
  for 100+ ticks and distinct-seed trace inequality. Trace snapshots include
  RNG state, so different initial seeds remain distinguishable before ecology
  exists; stepping itself must not consume purposeless random draws.

Tick phase order is fixed as Climate, PlantGrowth, AnimalMovement, Feeding,
Reproduction, Mortality, Finalize. Empty phases are named scheduler slots for
later tasks, not implemented behaviors. When populated, process actor IDs
ascending; resolve ties by ascending ID then row-major cell. Buffer births and
deaths and apply them in stable ID order at documented phase boundaries. All
stochastic decisions use `Simulation`'s RNG. No clock/wall-time APIs or UI
dependencies enter this core.

Implementation sequence: (1) add ADR-007 and locked ChaCha8 dependencies;
(2) implement seed expansion, RNG state export/restore and golden tests;
(3) add `World` as a `Grid` wrapper; (4) implement simulation state, ordered
phase/report types and exact one-tick advancement; (5) add public exports and
120-tick deterministic trace/state restoration integration tests; (6) run
focused tests, `cargo test`, `git diff --check`, and validate the handoff JSON.
Do not implement ecology, CLI commands, checkpoints, UI, or unrelated cleanup.

Implementation status: The planned modules and public APIs are implemented.
ChaCha8 state restoration is tested after mixed-width draws; an integration
trace compares same-seed runs for 120 ticks and verifies different seeds
differ. Scheduler phases remain intentionally empty. Tick overflow panics
rather than wrapping. No OS packages are required.

Risks: rand_chacha's word-position API and buffer semantics must restore the
next mixed-width draw exactly; test after both `u32` and `u64` draws. The
seed-expansion byte order and constants must be specified in code/docs and
locked in vectors. Named no-op phases must not be mistaken for completed
climate/ecology behavior.

## TASK-004 toroidal grid geometry plan

TASK-004 implements reusable geometry primitives before organisms or a spatial
index. Use `src/grid.rs` for `Grid`, `Cell`, and `Direction`, and export the
module and public types from `src/lib.rs`. `Grid::new(width: u32, height: u32)`
returns a validation error for either zero dimension. `Grid::wrap(x: i64, y:
i64) -> Cell` maps arbitrary signed coordinates by Euclidean remainder.
`Grid::direction(from: Cell, to: Cell) -> Direction` returns shortest signed
axis displacements; exact half-world ties on even dimensions choose the
negative displacement. `Grid::distance(from, to) -> u32` uses Chebyshev distance
(max absolute wrapped axis displacement). `Grid::cells_within(center, radius:
u32) -> Vec<Cell>` returns unique qualifying cells sorted by row then column.
The full interface and rationale are recorded in ADR-006.

Implementation order:

1. Add ADR-006 and geometry unit tests for valid/invalid dimensions, wrapping,
   shortest directions/distances, boundaries, and degenerate worlds.
2. Add `src/grid.rs` with validated dimensions, `Cell { x: u32, y: u32 }`,
   `Direction { dx: i32, dy: i32 }`, Euclidean wrapping and integer torus
   geometry. Keep coordinate conversion independent of organisms and climate.
3. Implement neighborhoods with radius-inclusive Chebyshev filtering. Return
   all cells immediately if the radius covers the maximum toroidal distance;
   otherwise enumerate wrapped offsets, deduplicate aliases, and sort in
   row-major order. Avoid constructing an unbounded `-radius..=radius` range
   when radius is larger than the grid.
4. Export `grid` and its public types from `src/lib.rs`; do not alter CLI
   behavior or add the TASK-010 spatial index.
5. Add deterministic exhaustive/brute-force oracle coverage for small
   non-square dimensions and radii larger than dimensions, plus explicit
   1x1, 1xN, all-edge, corner, negative, and multiply wrapped cases.
6. Run focused grid tests, the complete `cargo test` suite, `git diff --check`,
   and validate the phase handoff JSON. Record exact commands and results in
   the implementation handoff.

Risks: signed remainder in Rust can be negative, so wrapping must use
`rem_euclid`; radius-offset arithmetic can overflow if used naively, so the
all-world fast path and bounded iteration must be tested; even-dimension
antipodal direction is ambiguous and needs the documented deterministic tie;
returned neighborhood ordering must not depend on hash iteration. No system
packages or new runtime dependencies are planned. TASK-010 may later use these
functions and should compare its spatial index with the same distance oracle.

### PLAN cycle 2 remediation: GRID-EDGE-TESTS

REVIEW cycle 1 found that the wrap test used diagonal examples and did not
independently assert all four cardinal crossings. In the next authorized
IMPLEMENT cycle, change only `src/grid.rs` tests: on a non-square grid, assert
west-to-east (`x = -1`), east-to-west (`x = width`), north-to-south (`y = -1`),
and south-to-north (`y = height`) while holding the other coordinate in range.
Also make explicit corner crossing assertions. Keep negative and multiply
wrapped inputs, all existing geometry behavior, and the 1x1 case covered. Do
not change geometry APIs or production code for this gap. Run the focused grid
test and full `cargo test`, then `git diff --check` and JSON validation. This
closes review gap `GRID-EDGE-TESTS` if the new assertions independently show
each requested crossing and pass.

## TASK-003 typed configuration plan

### Implementation status (IMPLEMENT cycle 1)

The configuration API is implemented in `src/config.rs` and re-exported from
`src/lib.rs`. JSON deserialization uses `serde_path_to_error` so parse errors
include nested paths; range validation is explicit. Review cycle 1 found that
the parser must also check end-of-input after the typed value; TASK-003 PLAN
cycle 2 adds `Deserializer::end()` and regression coverage to the ordered
implementation plan. Integration coverage is in `tests/config.rs`. The
implementation follows ADR-005 and leaves CLI dispatch and simulation behavior
unchanged. See `tasks/TASK-003/handoffs/implement-cycle1.json` for prior
command evidence and `tasks/TASK-003/handoffs/review-cycle1.json` for the gap.

TASK-003 adds configuration types and presets only; it does not connect them to
simulation behavior or add `run` CLI handling. Implement this first so later
engine and CLI work share one validated representation.

### Planned files and interfaces

- `Cargo.toml` / `Cargo.lock`: add `serde` with derive support and `serde_json`;
  keep JSON as the required and only input/output format for now.
- `src/config.rs`: public `Config`, `WorldConfig`, `InitialConfig`, and grouped
  `ClimateConfig`, `EcologyConfig`, and `GeneticsConfig` types. Expose
  `Config::from_json(&str) -> Result<Config, ConfigError>`,
  `Config::to_json(&self) -> Result<String, ConfigError>`,
  `Config::validate()`, and `Config::preset(name: &str) -> Result<Config,
  ConfigError>` plus a preset-name listing API. Keep custom validation errors
  field-qualified (for example `world.width`, `initial.plants`,
  `ecology.plant_growth_per_tick`).
- `src/lib.rs`: expose the config module and public types without adding CLI
  dispatch or simulation use.
- `tests/config.rs`: integration coverage for fixed-key-only JSON, zero
  populations, each validation category, serialization round trip, and all
  named presets.
- `docs/decisions/ADR-005-configuration.md`: record the schema and parser
  decisions and their tradeoffs.

The fixed fields retain contract names and integer semantics: `seed: u64`,
`world.width/height: u32` in 1..=4096, and `initial.*: u32` in 0..=1,000,000
(including zero). The extra upper bounds are defensive and documented. Optional
group objects and every member have serde defaults so fixed-key-only input stays
valid. The exact climate, ecology and genetics fields, integer units, ranges and
defaults are recorded in `docs/decisions/ADR-005-configuration.md`; basis-point
and per-mille fields avoid floating-point equality and JSON round-trip drift.

Unknown object keys are errors. Use strict deserialization (`deny_unknown_fields`)
and map parser/type/missing-field errors to the offending dotted or field name;
perform explicit range validation after parsing. Keep serde's missing-field
behavior customized so the three fixed top-level keys are required, while
every additional field defaults. Ensure a malformed nested value names its
full path in the returned message.

Preset API names are `balanced`, `lush`, and `harsh`; each starts from valid
defaults and changes multiple climate/ecology settings in a documented way.
Presets return ordinary `Config` values and do not add command-line selection,
which remains outside this task. Serialization emits a canonical complete
configuration including defaults; deserialize/serialize equality is the
round-trip invariant.

### Ordered implementation and verification

1. Add ADR-005 with the exact field schema, validation bounds, unknown-key
   policy, and three preset differences.
2. Add serde dependencies and config types/defaults, JSON parser/serializer,
   strict key handling, field-qualified errors, and validation.
3. Add preset constructor/listing API and verify each preset validates and
   differs meaningfully.
4. Export the module from `src/lib.rs`; do not change command dispatch or wire
   settings into the engine.
5. Add integration tests for fixed-only JSON, zero populations, wrong types,
   each missing fixed key, out-of-range values, unknown keys, round trips and
   preset selection/validity.
6. Require complete-document parsing: after `serde_path_to_error` successfully
   deserializes one `Config`, call `serde_json::Deserializer::end()` and map
   any trailing-content error to `ConfigError`. Add regression tests proving a
   second JSON value and trailing non-whitespace text are rejected, and
   trailing whitespace is accepted.
7. Run `cargo test --test config`, `cargo test`, `./setup.sh`, existing
   version/help/error checks, `./build.sh`, `git diff --check`, and parse the
   implementation handoff JSON.

No OS packages are planned. Cargo dependency retrieval is permitted and does
not require an apt install command. Risks are accidental serde defaults making
fixed required keys optional, terse serde errors losing field names, and a
configuration shape that later tasks cannot consume cleanly. The tests and ADR
schema are intended to lock those boundaries before simulation implementation.

## TASK-002 bootstrap plan

Create a standard Cargo package at the workspace root: `Cargo.toml`, `src/main.rs`, `src/lib.rs`, and `tests/` for integration-level contract checks. Keep `src/main.rs` limited to CLI dispatch and expose a small library function for the bootstrap version/help behavior so it can be unit-tested. Use Rust's built-in `cargo test` harness; document `cargo test` as the single whole-suite command in `README.md`. The initial package deliberately has no third-party Rust dependencies, so setup needs no apt or package-manager install step beyond checking that the supplied `rustc` and `cargo` are available.

Add executable root scripts `setup.sh`, `evosim`, and `build.sh`. `setup.sh` checks Rust tooling and runs a release build; `evosim` locates the project relative to its own path and dispatches the locally built executable (building it if setup has not already produced it is acceptable). The initial CLI implements only `version`, top-level `--help`/`help`, and unknown-command exit status 2. `build.sh` copies the release executable to executable `dist/evosim`; the native binary has no Rust runtime dependency and relies only on the Ubuntu system ABI. Future runtime assets, if introduced, must be embedded or copied by the packaging script and remain addressable when the binary runs outside the project directory.

Ignore Cargo `target/` and `dist/` in `.gitignore`. Add at least one standard Rust unit test and a small CLI integration test covering the contract version JSON, help command listing, and status 2 for an unknown command. Bootstrap acceptance evidence also includes running setup, building `dist/`, and invoking both entry points from a working directory outside the workspace. The plan does not implement the later `run`, `batch`, or `ui` behaviors.

## Planned system (TASK-001)

The product will use a Rust simulation library and CLI, with a local browser UI. The engine is independent of the UI and owns all simulation state. The CLI and UI call the same engine APIs. See ADR-001 through ADR-004 for alternatives and tradeoffs.

### Planned modules and dependency direction

```text
src/main.rs (CLI dispatch) ──> src/cli.rs ──> src/engine/*
src/main.rs (UI dispatch)  ──> src/ui_server.rs ──> src/engine/*
                                           └──> ui/ static browser assets
src/engine/* ──> deterministic RNG, config/state types, algorithms
tests/* ──> public library APIs and CLI contract
```

- `src/lib.rs`: public engine API, re-exports stable `Config`, `World`, `Simulation`, and result/checkpoint types.
- `src/config.rs`: JSON parsing, defaults, fixed contract key validation, and parameter validation; no engine/UI dependency.
- `src/rng.rs`: simulation-owned ChaCha8 PRNG seeded from the configured 64-bit seed through fixed seed expansion; serialize stream state and lock behavior with golden-vector tests. All random choices flow through it.
- `src/genome.rs`: eight bounded unsigned 16-bit loci (`speed`, `strength`, `max_health`, `fertility`, `risk_tolerance`, `aggression`, `foraging_bias`, `lifespan`), deterministic trait derivation, single- and two-parent inheritance, configured per-locus mutation, and scaled integer mean absolute genetic distance (sum of absolute differences). Stable representative species assignment (threshold 8192/65535) remains TASK-017.
- `src/world.rs`: finite toroidal grid, per-cell climate/resources and cell-local entity indices; climate wraps continuously.
- `src/entity.rs`: plant and animal records, energy/age/health and lineage/species identifiers.
- `src/engine.rs`: ordered tick phases, movement, feeding, reproduction, mortality, and cumulative counters.
- `src/metrics.rs`: snapshots, series, diversity and population/genetic statistics.
- `src/checkpoint.rs`: complete versioned serialization, including RNG and cumulative state.
- `src/cli.rs`: `version`, `run`, and `batch` argument handling and contract JSON output.
- `src/ui_server.rs`: localhost server and JSON API; submits controls and requests snapshots from the same engine.
- `ui/`: browser application for map, controls, inspection and charts; rendering only, with no second simulation.
- `tests/`: unit, integration, property/regression and CLI contract tests, added by the implementation tasks.

### TASK-009 genome implementation

`src/genome.rs` implements eight named `u16` loci. `Genome::traits(kind)` maps
the loci directly to bounded phenotype values, and `Organism::new` derives and
stores both genome and phenotype together. Animal-only behavior fields are
`Option<u16>`; plants retain the loci while those phenotype fields are absent.
Initial genomes are sampled from the simulation ChaCha8 RNG in the existing
stable kind/ID order, after each organism's position draws. `Genome::child_one`
copies parental loci and `Genome::child_two` selects one allele independently
per locus before mutation. Each mutation trial draws a probability word; a
successful nonzero-step mutation then draws magnitude and sign, clamps to the
u16 range, and uses only the simulation RNG. `Simulation` exposes child-genome
helpers wired to configured genetics. Distance is the sum of absolute
difference over eight loci (eight times the normalized mean). Species
assignment and reproduction scheduling remain out of scope. No new crates or
system packages were added.

Acceptance tests: generated loci/traits are bounded and repeat for identical
seeds; one-parent inheritance with zero mutation is exact; two-parent
inheritance with zero mutation selects only parental alleles; positive mutation
changes at least one locus over a sufficiently large deterministic offspring
batch; distance is zero for equality, symmetric, bounded, and increases for a
controlled larger difference; every stored organism's traits equal its
genome-derived phenotype. Implemented tests are in `src/genome.rs` and
`tests/simulation.rs`; run `cargo test` and `cargo fmt --all -- --check`.
- `setup.sh`, `evosim`, `build.sh`: external entry points; `build.sh` stages the Rust binary and UI assets under `dist/`.

Dependency rule: engine modules may depend on engine data types and deterministic utility modules only. They must not depend on `cli`, `ui_server`, browser assets, wall clock, or unordered iteration for outcomes. CLI/UI adapt inputs and outputs around the engine; neither may fork simulation rules.

### Ordered implementation plan

1. Add Cargo project and deterministic primitive types (`Config`, PRNG, genomes, entities, world); record exact dependency/build assumptions in `docs/STATE.md`. Add focused tests for validation, torus indexing, PRNG repeatability, and genome inheritance/mutation/species criterion.
2. Implement ordered tick pipeline and ecology in `src/engine.rs`; add unit/property tests for wrapping movement, resource bounds, birth/death accounting, and no replenishment. Add seeded repeatability and multi-thousand-tick regressions.
3. Implement complete checkpoint serialization and state hashing. Test uninterrupted A+B against saved A then loaded B, including totals and random continuation.
4. Implement `evosim version/run/batch`, JSON validation/output and error handling; add CLI contract tests for valid/invalid configs, zero ticks, extinction, sampling, and batch seeds.
5. Implement browser server and static UI using engine snapshots/actions; add smoke and screenshot automation to exercise the real UI and its shared simulation.
6. Implement idempotent `setup.sh`, launcher and self-contained `build.sh` packaging. Verify from a clean build, inspect the distributable contents, and run contract commands from a different working directory.
7. Tune only through measured profiling and disclose setup/hardware with performance results; run the requested seed and long-duration workloads within task time limits.

Suggested verification commands once implementation exists: `cargo test`; `./setup.sh`; `./evosim version`; `./evosim run --config <fixture> --ticks 100 --out <tmp-result>`; `./evosim ui --smoke-test`; `./evosim ui --screenshots <existing-dir>`; `./build.sh`; then `dist/evosim version`. Exact fixtures/flags should follow the contract and the task that introduces each entry point.

### Current status

TASK-002 IMPLEMENT cycle 1 establishes the planned root Cargo package and path-resolving entry-point scripts. The implemented CLI surface is intentionally limited to `version`, help, and status-2 unknown-command errors; later tasks own simulation commands. `cargo test` is the documented complete current test suite. The release executable is copied to `dist/`; the package currently contains no runtime-loaded assets or third-party dependencies. No system packages are required. Exact implementation verification is in `tasks/TASK-002/handoffs/implement-cycle1.json`.

TASK-004 IMPLEMENT cycle 1 implements the planned `Grid`, `Cell`, and
`Direction` API in `src/grid.rs`, exported from `src/lib.rs`. Toroidal
Chebyshev distance, signed shortest directions, Euclidean coordinate wrapping,
and unique row-major radius queries are tested, including small-grid oracle
comparisons. `cargo test` passed all current tests; details are in
`tasks/TASK-004/handoffs/implement-cycle1.json`.


## TASK-006 climate zones and biomes

TASK-006 adds static, deterministic base climate to every cell in `World` and a
non-UI row-major biome map export. Follow ADR-008 for the periodic latitude
proxy, temperature/precipitation outputs, biome thresholds, tiny-world behavior,
and the toroidal topology compromise. `Grid` remains the source of dimensions;
climate values belong to `World` and are computed once from cell position.
Climate is not seasonally advanced and does not affect organisms in this task.
Implementation should expose a climate value lookup and whole-map text export;
if CLI surface permits, provide a direct CLI inspection path as well.

Planned verification covers all biome zones on a suitably tall grid, dry-belt
subtypes, boundary thresholds, same-value left/right seam, bounded last-to-first
vertical differences, deterministic export, and 1x1/1xN/Nx1 worlds. No system
packages are planned.

TASK-006 implementation: `src/climate.rs` provides quantized `Climate`, `Biome`, and `format_biome_map`. `World` stores immutable per-cell climate in row-major order and exposes `climate(Cell)` / `biome_map()`. `evosim climate-map WIDTH HEIGHT` prints two-letter codes without starting a UI. See ADR-008 for formulas, units, and the torus compromise.

## TASK-007 seasons and weather

TASK-007 extends the static base climate from TASK-006 with a time-varying
current climate. Follow ADR-009 for seasonal waveforms, zone scaling, weather
draws, bounds and the weather toggle. Keep base climate immutable and store
current weather deviations/current values per cell in row-major order in
`World`. The `Climate` scheduler phase updates every cell using the absolute
simulation tick and draws weather only from the simulation-owned RNG, in stable
cell order. Expose the current value for any valid cell through the existing
world query. Include any carried weather fields in snapshots and, when added,
checkpoint/canonical state serialization. Weather-off climate must be a pure
function of cell and tick so one configured year repeats exactly. Do not add
plant or animal effects in this task.

Implementation order:

1. Add a backward-compatible `climate.weather_enabled` config field, defaulting
   to true, and document it in the config API/ADR-005 as implemented.
2. Define seasonal temperature and precipitation calculations from base
   `Climate`, warmth and `season_length_ticks`; quantize and clamp to the
   ADR-009 bounds.
3. Extend `World` with current climate and explicit per-cell weather state;
   update it during `Simulation`'s Climate phase using stable row-major RNG
   draws. Add a current climate query while retaining access to base values if
   existing callers need them.
4. Expand simulation snapshots/state representation to contain current climate
   and weather deviations. Preserve RNG progression and deterministic tick
   ordering.
5. Add tests for exact annual repetition with weather disabled, configured
   period, deterministic same-seed weather, bounds, query validity, state
   capture and edge-sized worlds. Run focused tests and `cargo test`.

No system packages or new crates are planned. Tests should avoid long
simulations; a full-year run at a compact grid is sufficient.

TASK-007 implementation: `World` retains base climate and exposes seasonal,
weather-adjusted values through `current_climate(Cell)`. The Climate scheduler
phase applies the configured year and row-major bounded weather draws. Weather
deviations and current climate values are captured in `SimulationSnapshot`.
Weather is disabled only by the optional `climate.weather_enabled: false`
setting; fixed-key configurations retain weather by default.

## TASK-008 organisms and shared lifecycle plan

TASK-008 adds organism identity and common lifecycle state only. Follow
ADR-010. Keep feeding, movement, reproduction behavior, genomes and species
assignment out of scope. `src/entity.rs` defines the entity and lineage
records; `World` owns live organisms in ascending-ID order, a monotonic ID
allocator, queued additions/removals, ordered death history and per-kind
initial/birth/death counters. Public APIs should allow deterministic creation,
read-only lookup/iteration, queuing a death with cause, and querying counts;
mutations should preserve energy/health bounds and never reuse IDs.

Initialize configured populations in stable kind order (plants, herbivores,
carnivores), with positions assigned deterministically using the simulation
RNG. IDs start at 1 and increment with checked arithmetic. Parent IDs are
optional for initial organisms and both optional slots are recorded for later
sexual lineages; generation is zero for initial organisms. Lifespan and
fertility are recorded traits, not behavior in this task. Energy starts at a
valid documented capacity, and health starts within both the shared health
range and the organism's `max_health` trait.

Lifecycle ordering in `Simulation::step_one_tick`: retain the current Climate
and PlantGrowth/AnimalMovement/Feeding/Reproduction/Mortality/Finalize order.
At tick start, the live set is the actor set. Births requested during the tick
are assigned IDs but become live only at Finalize; queued death requests are
applied in Mortality, removed organisms are written to ordered history and
cannot act again. First death cause wins for duplicate requests. Thus a
newborn cannot die or act in its birth tick. Initial counts are separate from
birth totals; committed births and actual live removals update per-kind
counters so `initial + births - deaths == live` always holds. No arbitrary
replenishment is permitted.

Implementation order: (1) add ADR-010 and public entity types/ranges; (2) add
ordered live storage, monotonic IDs, initial population construction and
counters to `World`/`Simulation`; (3) add deferred birth/death lifecycle APIs
at Finalize/Mortality boundaries and deterministic death records; (4) include
organism and lifecycle state in snapshots; (5) add focused unit/integration
tests for bounds, lineage, stable ordering, no ID reuse, removal/no future
action, per-kind accounting and same-tick semantics; (6) run focused tests,
full `cargo test`, formatting and diff checks. No system packages or new
crates are planned.

Risks: the chosen `u16` trait scale is normalized and should not be mistaken
for physical units; later behavior tasks must document mappings. Death history
can grow with runtime and must be deliberately serialized by later checkpoint
work. Initialization positions consume deterministic RNG draws, so document
stable order and lock it with tests. Ordered-map overhead is an explicit
simplicity/determinism tradeoff and can be measured at target populations.

## TASK-011 plant growth and resources

TASK-011 adds a bounded row-major soil-water pool to `World` and deterministic
plant growth in the existing `PlantGrowth` slot. `src/plant.rs` owns pure
fixed-point suitability and conversion calculations; `src/world.rs` owns and
updates the cell resource vector; `src/simulation.rs` coordinates plants in
ascending ID order and queues mortality through the existing lifecycle API.
The existing `ecology.resource_capacity` is the per-cell resource cap and
`ecology.plant_growth_per_tick_permille` is maximum potential energy gain as a
fraction of `MAX_ENERGY`. The soil-water pool starts at capacity, is
replenished from current precipitation up to that cap, and is consumed to
support sunlight-powered photosynthesis at a documented 100 energy units per
resource unit. Growth is scaled by current temperature, current precipitation,
and genome-derived fertility. See ADR-011 for exact formula bounds,
hostile-climate thresholds, and resource accounting.

The pool starts full; each tick replenishes it by `ceil(precipitation *
capacity / 100000)`, capped at capacity. Temperature suitability ramps from
zero at -10 C to full at 20 C and back to zero at 50 C; precipitation
suitability is the 0..=1000 current precipitation index. Potential energy is
scaled by configured growth permille and normalized genome fertility, then
rounded down to multiples of 100. Each granted 100 energy deducts exactly one
water unit. Growth runs before the shared age increment, and plant mortality
checks the incremented age before Mortality. Plants die when age reaches their
genome lifespan, energy is zero, or temperature is below -40 C/above 60 C or
precipitation is below 20. The water vector is carried in snapshots. Plant
energy represents sunlight captured through photosynthesis; water is the
limiting material input, while climate, finite cell stock, and per-cell
replenishment cap the gain.

Plants age under the existing once-per-tick age update, and TASK-011 schedules
age, zero-energy starvation, and hostile-climate deaths (with an explicit
`DeathCause::Climate`) through the ordered Mortality phase. No reproduction or
grazing is added. Focused tests cover pure climate suitability, favorable-cell
growth, shared-resource competition, precipitation cap, and starvation. No new
crate or system package is planned. Future complete checkpoints and state
hashes must carry the soil-water vector.

## TASK-012 plant reproduction regression coverage

Plant reproduction remains the TASK-012 cycle 1 policy in ADR-012. Cycle 2
adds deterministic tick-level tests in `src/simulation.rs` for the inclusive
60,000 energy threshold, the exact 20,000 successful cost, and no birth/cost
when the exact sampled target already holds four living plants. The test-only
fixture sets internal growth to zero (outside validated user configuration)
and predicts the draw by cloning the deterministic RNG; it does not alter
runtime behavior or configuration. See the cycle 2 implementation handoff for
commands and outcomes.

## TASK-014 herbivore feeding and gene-driven foraging

Herbivores use the inherited `foraging_bias` locus for visible plant selection
and local meal choice. The fixed-point score blends normalized plant energy
and proximity; lower bias favors proximity and higher bias favors food energy,
with lower organism ID breaking ties. Carnivore movement targeting is
unchanged. In Feeding, ascending-ID herbivores can take one 5,000-energy bite
from a live plant at toroidal Chebyshev distance at most one. The transfer is
bounded by plant energy and herbivore capacity and is deducted/credited equally.
A depleted plant is queued for starvation and cannot be bitten again that
tick. Herbivores then pay 100 maintenance plus 100 per started Celsius degree
outside -5 C..=35 C, capped at 500 climate surcharge; zero energy queues
starvation for Mortality. The engine phase order remains unchanged. See
ADR-014 and the TASK-014 implementation handoff for exact formula and test
evidence. No crates or system packages were added.

## TASK-015 carnivore hunting implementation

After herbivore grazing in the existing Feeding slot, `Simulation::hunt_herbivores`
processes carnivores by ascending ID. Each makes at most one attack against the
nearest living herbivore at toroidal Chebyshev distance 0 or 1, with lower prey
ID breaking ties. The attack chance is the clamped 1,000..9,000 basis-point
formula in ADR-015, using hunter strength/aggression and prey speed/risk, and a
simulation RNG draw modulo 10,000. Success queues predation before the next
hunter; a miss leaves prey eligible. Successful energy transfer is bounded by
both prey energy and hunter capacity. Every hunter then spends 500 energy even
without adjacent prey or after a miss; zero energy queues starvation. This
resolves contention without reservations and prevents a killed or otherwise
pending-death animal being consumed twice. No dependency or system package was
added.

## TASK-016 animal reproduction implementation

After plant reproduction in the existing Reproduction phase, the simulation
processes a snapshot of animal IDs in ascending order. Cooldowns active at
phase entry block the full pass and decrement once afterward; newly assigned
cooldowns do not decrement on the birth tick, so 20 means 20 complete blocked
passes. Eligible adults must be
age 10 or older, retain at least 60,000 energy after earlier tick behaviors,
have zero cooldown, be alive/not pending death, and not reach lifespan this
tick. A mate must be a distinct same-kind animal within toroidal Chebyshev
distance one, satisfy the same eligibility, and have genome distance at most
65,536. Selection is by distance then ID and skips parents already used in a
successful mating this tick.

Each parent's fertility maps linearly to a seeded 500..=5,000 basis-point
trial. For eligible pairs, both rolls are consumed in parent ID order. Success
queues one deferred newborn at a seeded choice of either parent cell with
`child_genome_two` crossover and configured mutation, sorted parent IDs, and
checked `max(generation)+1`. Each parent then loses 20,000 energy and receives
a 20-tick cooldown. Newborns cannot act in their birth tick. Cooldown is stored
on the organism. The constants and simplified assumptions are in ADR-016;
focused and full-suite evidence is in the TASK-016 implementation handoff. No
crates or system packages were added.

## TASK-019 headless CLI implementation

TASK-019 implements `evosim run` in `src/cli.rs` behind the existing
dispatcher. Strict standard-library flag parsing and `Config::from_json` drive
the shared `Simulation` engine without a display. A versioned canonical JSON
state DTO includes tick, dimensions, effective config, RNG continuation,
base/current climate and weather, resources/capacity, organisms, pending
lifecycle state, death history, cumulative counters, species records, and
allocators. SHA-256 hashes those bytes. The derived spatial index is excluded
because organism positions reconstruct it. Result JSON includes contract
counts, species, totals and series; output is written only after the run
completes. Run results include sampled, read-only evolution metrics aligned
one-for-one with the population series: cumulative lifecycle and death-cause
counts, living species, per-trait mean/population standard deviation, and
generation extrema/mean. Metrics live outside simulation state and do not draw
randomness. Checkpoint and batch commands remain out of scope. See ADR-019,
ADR-020, and the TASK-019/TASK-020 implementation handoffs.

## TASK-021 batch runs implementation

`evosim batch` executes seed/configuration matrices sequentially through the
same headless simulation and result builder as `run`. Repeated `--vary
FIELD=V1,V2` options accept the integer leaves documented in ADR-021 and form a
Cartesian product. All matrix configurations are validated before execution.
Per-run contract result JSON is placed in the required output directory;
`summary.json` carries ordered run rows and population/extinction aggregates.
Optional `--csv FILE` exports the same rows with sorted parameter columns.
Summary data omits wall-clock timings. See ADR-021 for the summary and CSV
schemas and filename policy.

## TASK-022 versioned checkpoints

`evosim run --save FILE` writes an uncompressed UTF-8 JSON envelope containing
format version 1, the effective validated configuration, absolute tick, RNG
continuation, and complete `WorldClimateState`. `--load FILE` restores these
values without initialization draws, validates climate/weather, vectors,
resources, entity/species IDs and references, lifecycle counters and death
history, then rebuilds the derived spatial index. A resumed result starts its
series at the checkpoint tick and retains cumulative totals. Invalid files
return status 2 before result output. See ADR-022 and the TASK-022 implementation
handoff for verification details.

## TASK-023 browser world view

`evosim ui` serves bundled `ui/` assets and a compact JSON snapshot from a
loopback-only Rust TCP listener. The UI reads the same `Simulation` engine as
the CLI; the server advances it at about ten ticks per second. Snapshot cells
are row-major current climate values and entities are in stable organism-ID
order with only kind and position exposed. Canvas renders climate cells and
three distinct organism symbols, with drag pan, wheel zoom and an always-visible
legend. `--smoke-test` and `--screenshots DIR` exercise this page in Chromium.

## TASK-024 UI controls and inspector plan (PLAN cycle 1)

Extend `src/ui.rs` with explicit snapshot, advance, selected-organism detail,
reset, save-checkpoint, and load-checkpoint API paths over the shared
`Simulation`; remove implicit server-side ticking so the browser controls every
advance. Add `ui/controller.js` (or an equivalent pure controller module) for
run/pause/one-tick/speed state and exercise it without a display. Extend
`ui/index.html`, `ui/app.js`, and `ui/style.css` with persistent tick/population
status, 1/5/20 ticks-per-second choices, map selection/highlighting, an
inspector for all requested lineage/trait/genome fields and death status, and
checkpoint download/upload. Snapshot records carry stable IDs and kind/position;
fetch full details only for the selected ID. Reset reinitializes from current
validated config/seed. UI save/load must share the versioned DTO and full
validation path used by CLI checkpoints in `src/cli.rs`, not define another
format. Add display-free controller and Rust API/serialization/checkpoint tests,
then real Chromium control and screenshot checks while preserving existing UI
smoke/screenshot behavior. ADR-024 records the interface and tradeoffs. No new
system dependency or package is planned.

## TASK-024 UI controls and inspector implementation

The browser owns tick scheduling and starts paused. Each advance request runs
an explicit whole number of ticks through the shared engine; there is no
background server stepping. The page provides run/pause, exact one-tick step,
deterministic reset from the current effective configuration, and 1/5/20
ticks-per-second settings. Persistent counters show tick and per-kind living
populations. Map snapshots include stable IDs while selected organism details
are looked up separately, including species, lineage, traits, genome and death
records. Checkpoint UI endpoints use the same shared version-1 codec as CLI
save/load and validate before replacing state; uploads are fully read with a
32 MiB limit. See ADR-024 and the TASK-024 implementation handoff.

## TASK-025 UI experiments and charts

The browser exposes the three canonical Rust presets and edits the complete
configuration (seed, grid, initial populations, climate, ecology and genetics)
through a field-validated draft. `ui/config-model.js` supplies defaults,
normalization, JSON import/export and inline range/type errors; `/api/reset`
remains authoritative. `ui/chart-data.js` derives four time series and a
current-population distribution, and `ui/charts.js` renders labeled SVG without
runtime dependencies. `/api/charts` serves a UI-only history capped at 1,000
`MetricsSample`s, seeded at world creation/reset/checkpoint restore and sampled
after each explicit advance. The observer history does not enter checkpoints
or engine hashes. Screenshot automation captures the world and charts pages.

## TASK-026 performance measurement and optimization

`cargo bench --bench simulation` runs the fixed seed-26026 plant workload with
50 warm-up and 300 measured ticks. It starts at 3,000 plants and reaches about
12,000 due to the per-cell plant establishment cap; samples stayed above
10,000. Temporary phase timers identified reproduction and mortality/finalize
as the dominant buckets. `World::reconcile_species_extinctions` previously
scanned every organism once for each species. It now collects living species
IDs in one transient `HashSet` pass and reconciles records by membership. This
does not alter ordering, RNG, state representation, or checkpoint data. The
release median improved from 194.90 to 241.28 ticks/s. `tests/performance.rs`
guards the dense workload at a loose 1 tick/s floor. Host details, runs and
profiling limitations are in `docs/PERFORMANCE.md` and ADR-026.

## TASK-027 ecosystem handling interval

Carnivores that successfully kill prey receive a serialized 20-tick
`hunting_cooldown`. They cannot attack during those 20 Feeding passes and still
pay the usual 500 energy per tick. Missed attacks and prey-free passes do not
start handling. Cooldown state is part of organism/world snapshots, checkpoint
continuation and canonical state hashes; older organism JSON records default
to zero cooldown. This is a local mechanism applied at every population size,
with no global count checks or forced replenishment. Baseline diagnosis, tuning
seed measurements, held-out results and repeat benchmark are in
`docs/BALANCE.md` and ADR-027.

## TASK-028 reliability and delivery

The ordinary contract batch command accepts a seed list without requiring an
optional parameter sweep; `--vary` still creates Cartesian sweeps when
supplied. `tests/reliability.rs` uses a fixed local xorshift generator across
32 small world cases to check deterministic state hashes, lifecycle accounting,
value bounds, and toroidal wrap distances. `./test.sh` is the aggregate Rust,
Node, and UI HTTP test entry point. `docs/VERIFICATION.md` records contract
evidence, delivery checks, multi-seed ecology results, and the PROJECT.md
self-audit.

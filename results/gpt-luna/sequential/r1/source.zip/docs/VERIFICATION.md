# TASK-028 verification and project audit

Evidence below is for the TASK-028 IMPLEMENT cycle. Commands are run from the
workspace root unless stated. `./test.sh` is the single aggregate suite command;
other commands specifically exercise the external contract or delivery.

## Contract-to-evidence matrix

| Contract requirement | Evidence / result |
|---|---|
| Root entry points, any-CWD behavior | `./setup.sh`, `./build.sh`, and copied-distribution checks below. |
| `version` JSON and clean stdout | Direct `./evosim version` check and `./test.sh`. |
| `run` config/load, exact ticks, sample endpoints, save, result schema | `./test.sh`; sample endpoint and split-checkpoint tests passed, plus direct sampling command below. |
| `batch` fixed syntax, per-seed result and summary | `./test.sh` including no-sweep and Cartesian sweep tests; direct 3-seed default and demo runs below. |
| UI live, smoke, screenshots and dimensions | `xvfb-run -a ./evosim ui --smoke-test`; screenshots and PNG dimensions below. |
| JSON configuration required keys/ranges and invalid errors | `./test.sh`; direct error/no-result check below. |
| Determinism and different seeds | `./test.sh` CLI determinism test and randomized reliability replay test. |
| Checkpoint continuation and invalid checkpoint | `./test.sh` passed checkpoint split/resume, invalid-file and no-result tests. |
| No replenishment / fixed-tick extinction | `./test.sh` ecology tests; direct zero-plant run below. |
| Packaging works without project/language runtimes | copied `dist/evosim` check below; base Ubuntu dynamic libraries are listed there. |
| Demo scenario (section 7) | `scenarios/demo.json`, README launch example, and measurements below. |

## Ten-thousand-tick coexistence measurements

Each configuration was run as `./evosim batch --config CONFIG --seeds 1,2,3
--ticks 10000 --out-dir DIR`. This completes a full 10,000-tick run for each
seed and writes per-seed result JSON plus summary. A kind's coexistence duration
is its first zero population tick; zero already at tick 0 is duration 0. A
population surviving to tick 10,000 is reported as `>10000`.

| Configuration | Seed | First plants zero | First herbivores zero | First carnivores zero | Final plants / herbivores / carnivores | Run ticks/s |
|---|---:|---:|---:|---:|---|---:|
| contract defaults | 1 | >10000 | 214 | 303 | 11004 / 0 / 0 | 284.5 |
| contract defaults | 2 | >10000 | 174 | 282 | 11050 / 0 / 0 | 284.4 |
| contract defaults | 3 | >10000 | 196 | 293 | 11003 / 0 / 0 | 286.1 |
| demo | 1 | >10000 | >10000 | 1101 | 10988 / 25 / 0 | 220.2 |
| demo | 2 | >10000 | >10000 | 1153 | 10975 / 2 / 0 | 254.3 |
| demo | 4 | >10000 | 1135 | 1232 | 10980 / 0 / 0 | 261.5 |

Default run config is exactly the CONTRACT section 3 fixed-key example. Demo
config is [`scenarios/demo.json`](../scenarios/demo.json). Exact first-zero
ticks are collected from interval-1 result series. The 10,000-tick batch result
files and summary confirm the complete run and final populations.

Default batch command:

```sh
./evosim batch --config examples/minimal.json --seeds 1,2,3 --ticks 10000 --out-dir /tmp/task028-default
```

Demo batch command:

```sh
./evosim batch --config scenarios/demo.json --seeds 1,2,4 --ticks 10000 --out-dir /tmp/task028-demo-final
```

The demo candidate's seed 3 trial had no result when stopped manually. It was
still running after approximately 864 seconds for that seed (about 948 seconds
total batch elapsed minus 84 seconds for seeds 1 and 2); whether it would
complete within 900 seconds is unknown. It is disclosed here rather than
counted as a successful result. Seeds 1, 2 and 4 were selected for the
completed set; each finished in 38.2–45.4 simulation seconds. The exact
interval-1 curve runs for those seeds took 47.0–54.5 seconds each. The default
runs completed in 34.9–35.2 seconds each. Joint all-three coexistence ended at
ticks 214, 174, 196 for the default seeds and 1101, 1153, 1135 for the
measured demo seeds.

## Self-audit against `docs/PROJECT.md`

Status labels: **Met**, **Partly met**, or **Missing**. The project brief's
requirements are listed here individually; the notes identify concrete limits.

| Requirement | Status | Evidence / limitation |
|---|---|---|
| Finite toroidal grid, cell movement, wrap-aware perception and lookup | Met | `src/grid.rs`, `src/spatial_index.rs`, `tests/spatial_index.rs`, randomized one-cell/opposite-edge checks. |
| Configurable grid and initial populations | Met | JSON `world`/`initial` config; `tests/config.rs`. |
| Latitudinal climate with smooth torus seam, temperature and precipitation | Partly met | `src/climate.rs`, ADR-008; periodic latitude keeps the scalar field continuous, but the warm belt/cold polar seam is a simplified torus compromise rather than a physically consistent sphere. |
| Seasonal and weather tick variation affecting entities | Met | `src/climate.rs`, `src/simulation.rs`, ADR-009. |
| Plants consume resources, grow, reproduce, mutate and speciate | Met | `src/plant.rs`, ADR-011/012/017, lifecycle and species tests. |
| Herbivores eat plants; carnivores eat herbivores | Met | Feeding/hunting implementations and integration tests. |
| Traits include speed, strength, health, fertility, lifespan and behavior | Met | `src/genome.rs`, `src/entity.rs`; behavioral loci apply to animals. |
| Internally coherent simplified nutrition, cost, lifespan and reproduction | Partly met | Fixed-point transfers/costs and explicit mortality; simplified equations are described by ADR-010–018. |
| Two-parent animal reproduction, inherited/mutated DNA | Met | `src/simulation.rs`, ADR-016 and reproduction tests. |
| Explicit stable species criterion and lineage | Met | Genome-distance threshold and immutable representatives, ADR-017. |
| 1,000–5,000 target and >=100 ticks/s at 2,000 organisms | Partly met | TASK-026 dense plant-heavy benchmark exceeds the target; it is not a balanced mixed ecology workload. See `docs/PERFORMANCE.md`. |
| Headless and live UI share engine | Met | CLI and `src/ui.rs` use `Simulation`. |
| Climate map, entity distinction, pan/zoom, run/pause/reset/step/speed/inspect | Met | Browser UI and TASK-023–025 handoffs; screenshot/smoke evidence below. |
| UI parameter editing, presets, config import/export, seed control | Met | TASK-025 implementation; browser config model and UI tests. |
| Full save/load of DNA, RNG and climate | Met | Shared versioned checkpoint DTO, ADR-022; split-run tests. |
| Headless multi-seed/batch and parameter sweeps | Met | `evosim batch`, including fixed syntax without a sweep; CLI tests. |
| Population, births/deaths, diversity, genetic and generation visualization | Met | Result metrics and UI charts; see ADR-020/025. |
| Unit, integration, regression, property-style, long-run tests | Partly met | Suite includes focused tests, randomized bounded integration cases, and long-run recorded runs. It is not an exhaustive proof and has one documented ignored report test. |
| Seed-based repeatability | Met | CLI, checkpoint and randomized replay hash checks. |
| Populations may collapse; all three-kind long coexistence is the aim | Partly met | No forced protection/replenishment; measured defaults/demo may collapse. No minimum coexistence is guaranteed. |
| No arbitrary population replenishment or global count triggers | Met | Initializers and deferred reproduction are the only birth paths; local rules documented in ADRs. |
| Benchmark product interface is runnable and packaged | Met | Contract matrix and distribution evidence above/below. |

## Delivery and command evidence

- `./setup.sh` succeeded, then `./build.sh` succeeded (which also reruns
  setup). No OS packages were installed.
- `./evosim version` printed exactly `{"name":"evosim","version":"0.1.0","contract":1}`
  plus its newline.
- `./evosim run --config examples/minimal.json --ticks 7 --sample-every 3`
  produced series ticks `[0,3,6,7]`, confirming configured spacing and final
  endpoint inclusion.
- From `/tmp`, `/workspace/evosim version` succeeded and
  `/workspace/evosim run --config /workspace/examples/minimal.json --ticks 1
  --out /tmp/task028-othercwd.json` wrote a result ending at tick 1.
- A zero-plant config advanced exactly 1,000 ticks and ended with zero plants,
  herbivores and carnivores. A malformed JSON config returned status 2 with
  stderr and did not create a result file.
- `xvfb-run -a ./evosim ui --smoke-test` succeeded in 0.3 seconds. The real UI
  screenshot command `xvfb-run -a ./evosim ui --screenshots /tmp/task028-shots`
  produced `main.png` and `charts.png`, both 1440×1400 PNGs.
- `xvfb-run -a ./evosim ui --smoke-test --config scenarios/demo.json` also
  succeeded, confirming the UI accepts an explicit configuration.
- `./build.sh` produced `dist/evosim`. After copying it to
  `/tmp/evosim-dist-check` and changing cwd to `/tmp`, invoking it with
  `PATH=/usr/bin:/bin` printed the version and completed a two-tick run. Thus
  Rust/Cargo/Node and workspace files were absent from PATH/cwd. `ldd` showed
  only Ubuntu base libraries: `libgcc_s.so.1`, `libm.so.6`, `libc.so.6`,
  `ld-linux-x86-64.so.2` (plus `linux-vdso.so.1`). No network access was used
  for either invocation.
- `./test.sh` passed: Rust 86 passed / 1 ignored / 0 failed (50 unit, 11 CLI,
  6 config, 5 ecology plus 1 ignored, 1 performance, 1 reliability, 9
  simulation, 3 spatial); Node 7 passed; `tests/ui_http_probe.py` passed.
- The `batch` fixed-seed syntax without `--vary` passed in
  `cargo test --test reliability --test cli` and in the two direct three-seed
  commands above. Existing Cartesian sweep coverage also passed in that
  focused CLI run.
- `cargo fmt --all -- --check`, `git diff --check`, handoff JSON validation and
  local-only Git checks are recorded in the IMPLEMENT handoff.

TASK-020 IMPLEMENT cycle 2 closes GAP-020-R1. The metrics unit fixture now sets
plant speeds to 10 and 14 and generations to 2 and 4, then asserts fixed mean
12, population standard deviation 2, maximum generation 4 and mean generation
3. The state-hash observation regression remains. Metrics-focused tests (3),
CLI alignment test (1), full suite (75 passed, 1 ignored), formatting, and
whitespace checks passed. No system dependencies or crates were added. See
`tasks/TASK-020/handoffs/implement-cycle2.json` and ADR-020.

TASK-017 IMPLEMENT cycle 1 adds species identity to organisms and ordered
species records/allocator to `World`. Assignment occurs at initialization or
birth queue time using immutable same-kind representatives and inclusive
distance <=65,536; nearest distance and then lower species ID break ties.
Species IDs are global and monotonic; names use kind prefix and six-digit
minimum padding. Each record retains parent species, representative genome,
arose tick and optional extinction tick. Species extinction is reconciled
after mortality and committed births; extinct records are excluded from future
assignment. `World::living_species_count` queries living species by kind, and
world snapshots include species state and allocator. ADR-017 and
`tasks/TASK-017/handoffs/implement-cycle1.json` contain exact policy and test
evidence. No crates or system packages were added.

TASK-016 IMPLEMENT cycle 1 implements animal-only sexual reproduction after
plant reproduction in the existing Reproduction phase. Eligible distinct
same-kind adults mate within toroidal Chebyshev distance one when genome
distance is at most 65,536. Candidate choice is distance then ID; successful
parents are used at most once per tick. Fertility gives each parent an
independent seeded 5%..50% trial. Successful pairs queue a deferred,
crossed/mutated offspring at a parent cell, record sorted parent IDs and
checked next generation, pay 20,000 energy each, and receive 20 cooldown ticks.
Organisms carry cooldown state. Focused reproduction tests passed; full suite,
format and whitespace results are in
`tasks/TASK-016/handoffs/implement-cycle1.json`. No crates or system packages
were added.

TASK-015 IMPLEMENT cycle 1 implements carnivore hunting in the existing Feeding
slot after herbivore grazing. Carnivores resolve in ascending ID order, select
the nearest non-pending-death herbivore at toroidal Chebyshev distance 0 or 1,
and make at most one attempt. Chance uses attacker strength/aggression and prey
speed/risk via the clamped basis-point formula in ADR-015 and the simulation RNG.
A successful attack queues `DeathCause::Predation`, transfers at most prey
energy and remaining hunter capacity, and excludes the prey from later hunters.
Every hunter pays 500 energy regardless of outcome/no target; zero energy queues
starvation. Details and actual test commands are in the TASK-015 implementation
handoff. No system packages or new crates were added.

# Project status (agent-maintained human-readable summary)

TASK-028 IMPLEMENT adds a 32-case deterministic randomized invariant test,
removes the batch CLI's unintended requirement for `--vary`, and documents the
configuration schema and demo launch in README. `./test.sh` aggregates Rust,
Node, and UI HTTP tests; the full command passed 86 Rust tests plus one ignored,
7 Node tests, and the UI HTTP probe. The demo completed 10,000 ticks on seeds
1, 2 and 4; all-three coexistence lasted 1,101–1,153 ticks. The exact contract
defaults ended all-three coexistence at ticks 174, 196 and 214 on seeds 2, 3
and 1, respectively. A seed-3 demo trial was stopped while still running after
approximately 864 seconds for that seed; its completion against the 900-second
limit is unknown, so it was excluded from the selected final set. The
contract matrix, self-audit, distribution and UI evidence are in
`docs/VERIFICATION.md`. No system packages or crate dependencies were added;
Rust/Cargo, Node and Python are existing build/test tools, and Chromium is
supplied by the benchmark contract.

TASK-025 PLAN cycle 1 chooses existing `Config` and presets as the canonical
experiment model, a pure browser config module with field-level validation and
normalized JSON import/export, and dependency-free SVG charts. Planned chart
data comes from a bounded 1,000-sample UI observer buffer using existing
`MetricsSample`; the buffer is sampled after explicit advance requests and is
not part of checkpoints or simulation hashes. The UI will expose four time
series plus a selectable current trait distribution and capture `main.png`
and `charts.png` from the real page. Details, implementation order and tests
are in ADR-025 and `tasks/TASK-025/handoffs/plan-cycle1.md`. No system
dependencies or packages are planned; PLAN made no product code changes.

TASK-013 IMPLEMENT cycle 1 implements animal sensing and movement in
`src/animal.rs` and the AnimalMovement portion of `Simulation::step_one_tick`.
Normalized speed determines 1..=4 movement steps and 1..=8 inclusive toroidal
Chebyshev vision cells. Animals approach the nearest visible edible-kind
organism (distance then ID tie-break), using shortest wrapped directions; with
no edible target they choose a seeded eight-direction random walk. Movement
costs `100 + speed / 256` energy per actual cell; low energy truncates the
path. Any number and kind of organisms may share cells, and all moves remain
World-mediated to preserve the index. Movement does not include feeding or
attacks. Focused animal tests passed; full-suite/formatting/diff results and
coverage details are recorded in the TASK-013 implementation handoff.
No system packages or new crates were added.

TASK-013 final implementation verification: `cargo test` passed 47 tests (25
library, 4 CLI, 6 config, 9 simulation, and 3 spatial-index; 0 failures), with
0 doc tests. The focused `animal::tests` target passed 5 tests. Formatting and
whitespace checks passed. No system packages or new dependencies were added.

TASK-012 PLAN cycle 2 replans the test work after review cycle 1 identified
missing direct assertions for the 60,000 energy threshold, exact 20,000
successful cost, and no cost/no offspring on a blocked sampled destination.
The existing implementation is intended to retain the cycle 1 behavior: use
post-growth energy in Reproduction, permit one asexual child per eligible
plant, sample one nonzero toroidal radius-two target, require positive local
water and fewer than four live or pending plants, and deduct energy only after
queueing. The cycle 2 implementation plan isolates growth (zero growth,
benign fixed climate) and exercises real tick paths with deterministic seeds,
while preserving existing lineage, mutation, seam, newborn and zero-plant
coverage. Details and explicit closure of review gaps are in
`tasks/TASK-012/handoffs/plan-cycle2.md` and `.json`. No system packages or new
dependencies are planned; no product tests were run during PLAN.

TASK-012 IMPLEMENT cycle 2 adds direct reproduction energy and blocked-target
regressions in `src/simulation.rs`. With growth disabled inside a test-only
simulation fixture, 59,999 energy yields no birth and is unchanged; 60,000
energy yields one birth and ends at 40,000. A separate test predicts the exact
seeded destination, fills it with four living plants, and confirms no offspring
and no reproduction cost. Existing implementation behavior is unchanged. No
system packages or dependencies were added. Focused plant lifecycle tests and
`cargo test` passed; see
`tasks/TASK-012/handoffs/implement-cycle2.json` for exact results.

TASK-010 IMPLEMENT cycle 1 adds the derived per-cell occupancy index in
`src/spatial_index.rs`. `World::organisms_within` uses unique toroidal
neighborhood cells and returns matching live organisms in ascending ID order;
`World::move_organism` and `Simulation::move_organism` keep cell membership
synchronized. Initial organisms, committed births, and mortality removals also
update the index. Index data is not part of snapshots. `cargo test --test
spatial_index -- --nocapture` passed 3 tests, including 6,000 randomized
brute-force comparisons and lifecycle/movement regressions. Its 2,000-organism
benchmark used a 100x80 world, 1,000 randomized radius-2 queries, and recorded
18.012 ms indexed versus 131.443 ms brute force (6,203 matching results each)
on AMD Ryzen 5 7500F, x86_64, in the debug test build. Command:
`cargo test --test spatial_index -- --nocapture`. This is a single local sample,
not a cross-platform performance guarantee. No system packages or dependencies
were added. Implementation details and exact suite results are in
`tasks/TASK-010/handoffs/implement-cycle1.json`.

TASK-008 IMPLEMENT cycle 1 adds bounded shared organism records and lifecycle
staging in `src/entity.rs`, `World`, and `Simulation`. Live entities use
ascending-ID `BTreeMap` order; initial placement is deterministic using the
simulation RNG. Deaths are applied at Mortality with first-cause-wins history;
staged births commit at Finalize and start at age zero. Per-kind initial,
birth, and death counts plus organism queues/history are included in snapshots.
Energy and health have bounded accessors/setters, and no feeding, movement,
reproduction behavior, genomes, or speciation was added. No system packages or
new crates are needed; Rust dependencies remain those in Cargo.lock. Evidence
is in `tasks/TASK-008/handoffs/implement-cycle1.json`.

TASK-009 IMPLEMENT cycle 1 adds public `Genome` DNA with eight normalized u16
loci, direct deterministic phenotype derivation, and genome-backed organisms.
Initial genes are sampled from the simulation RNG in stable kind/ID/locus order
(after position draws). One-parent copy and two-parent per-locus crossover
constructors apply configured per-locus mutation using the same RNG; distance
is the sum of absolute locus differences. `Simulation` exposes configured
child-genome helpers, while birth insertion accepts genome and derives traits
atomically. Tests cover trait bounds/mapping, mutation-free inheritance,
positive mutation, distance properties, and newborn genome/phenotype equality.
`cargo test` passed (30 tests total); `cargo fmt --all` was run. No system
dependencies or new crates were added. Implementation details and remaining
scope are in `docs/ARCHITECTURE.md`, ADR-004, and the implementation handoff.

TASK-007 PLAN cycle 1 selects a global configurable year phase, zone-scaled
seasonal changes, and bounded per-cell seeded weather generated in row-major
order from the simulation-owned ChaCha8 stream. The default-enabled
`climate.weather_enabled` switch allows exact annual-repeat tests with weather
off. Current climate/weather deviations belong to `World` and its snapshots;
the Climate scheduler phase updates them. Details and bounds are in
`docs/decisions/ADR-009-seasons-weather.md`. The plan is recorded in
`tasks/TASK-007/handoffs/plan-cycle1.md`. No system packages or new crates are
planned. No product tests were run during planning.

TASK-007 IMPLEMENT cycle 1 adds the default-true weather toggle, seasonal
current climate, and bounded per-cell weather updates in the Climate scheduler
phase. Base climate and biome labels remain available; `World::current_climate`
exposes current values. `SimulationSnapshot` includes current climate and
weather deviations in addition to RNG state. Weather uses two bounded ChaCha8
draws per cell per tick when enabled and consumes no draws when disabled. Off-
weather annual repetition, deterministic seeded weather, and bounds are covered
by tests. No system packages or new crates are required. See ADR-009 and
`tasks/TASK-007/handoffs/implement-cycle1.json` for implementation evidence.

TASK-005 IMPLEMENT cycle 1 implements `rand_chacha` ChaCha8 with a fixed SplitMix64
expansion from the config's u64 seed, and explicit stream/word-position RNG
state export/restore (ADR-007). The planned `Simulation` owns tick, RNG and a
`World` wrapping `Grid`; one `step_one_tick` call advances exactly one tick
through named ordered slots: climate, plant growth, animal movement, feeding,
reproduction, mortality, finalize. These are empty scheduler slots in TASK-005;
ecology remains out of scope. Future actor processing is stable ascending ID,
with row-major cell order as the secondary tie-break and buffered births/deaths
applied in stable ID order. Implemented modules are `src/rng.rs`,
`src/world.rs`, and `src/simulation.rs`; snapshots contain tick, dimensions,
and complete RNG continuation state. Seed expansion uses four SplitMix64
outputs encoded little-endian; seed 42's first ChaCha8 `u32` is 2278103804.
No system packages are required; Cargo dependencies are locked in Cargo.lock.
Implementation evidence is in `tasks/TASK-005/handoffs/implement-cycle1.json`.
The orchestrator owns phase completion and commits.

TASK-004 PLAN cycle 1 selects toroidal Chebyshev distance for square cell
neighborhoods and deterministic shortest directions, with a negative tie-break
for exactly antipodal cells on even-sized axes. The planned API is `Grid` with
nonzero `u32` dimensions, `Cell` positions in `u32`, signed `i64` input
coordinates wrapped by Euclidean remainder, and signed `i32` direction
components. Radius neighborhoods are unique and row-major, with a full-grid
shortcut and offset deduplication for wrapped aliases. Ordered implementation
steps and the acceptance test matrix are in `docs/ARCHITECTURE.md`; rationale
and conventions are in `docs/decisions/ADR-006-grid-geometry.md`. TASK-004 does
not add organisms or the TASK-010 spatial index. No system packages or new
dependencies are planned; run `cargo test` in implementation. The runner owns
phase completion and commits.

PLAN TASK-003 cycle 1 selects a strict JSON configuration API in Rust with
serde/serde_json, contract-fixed required keys, defaults for all added grouped
settings, field-qualified errors, and named `balanced`, `lush`, and `harsh`
presets. The exact schema and limits are in ADR-005; implementation order and
test matrix are in `docs/ARCHITECTURE.md`. TASK-003 is config/preset modeling
only: no simulation consumption or `run` command changes. Unknown keys are
planned errors. No OS package is planned; Cargo dependencies require no apt
installation. The runner owns phase state and commits.

Status: TASK-002 IMPLEMENT cycle 1 adds a dependency-free root Cargo bootstrap, unit/integration tests, README, and executable `setup.sh`, `evosim`, and `build.sh` entry points. The bootstrap implements only version/help/error behavior; simulation and UI commands remain for later tasks. No apt-installed system dependencies are required; `setup.sh` checks the supplied `rustc` and `cargo` and builds the release binary. Run the complete current suite with `cargo test`. The orchestrator owns phase completion and task status.

Status: TASK-001 implementation (cycle 3) completed as a documentation-only scope check after PLAN cycle 3 closed the ADR-002 performance-tradeoff finding. No simulation implementation exists because TASK-001 explicitly excludes product code. Task selection and machine state live outside the workspace with the harness and take precedence over this overview.

On each phase, update concise progress, interface decisions, risks and exact test commands. Do not claim task completion: only the harness decides DONE.

TASK-001 planning selected a Rust simulation core/CLI, local browser UI, row-major per-cell occupancy buckets for toroidal lookup, and fixed-schema bounded integer genomes with deterministic recombination/mutation and representative-distance species assignment. Details and alternatives are in `docs/decisions/ADR-001-runtime.md` through `ADR-004-genome.md`; planned modules, dependency direction, build steps and test strategy are in `docs/ARCHITECTURE.md`.

No system packages are currently required or planned. The benchmark environment provides Rust, Node, Python, build tools and Chromium for UI automation. If implementation requires apt packages, record each exact install command here and in the relevant phase handoff; reinstall when absent in a fresh phase.

PLAN cycle 1 recorded architecture choices. IMPLEMENT cycle 1 tightened the genome and determinism choices in ADR-004 and `docs/ARCHITECTURE.md`; it added no product code under TASK-001's scope. REVIEW cycle 1 identified missing `dist/` implications in ADR-003 and ADR-004. PLAN cycle 2 adds explicit packaging/checkpoint implications to both ADRs; product code remains absent. No system packages are required or installed. Product implementation tests are not applicable yet; planning documentation checks and handoff validation are recorded in the cycle 2 handoff. Planned product verification commands are listed in `docs/ARCHITECTURE.md` and each ADR.

IMPLEMENT cycle 2 rechecked the approved plan and the two prior review gaps. All four ADRs include alternatives, decision, consequences, verification strategy, and `dist/` implications; the architecture dependency boundary is present. No source or test code was added because TASK-001 explicitly excludes product implementation. No dependent-task handoffs or system package requirements were present. Verification commands and their actual results are in `tasks/TASK-001/handoffs/implement-cycle2.json`.


REVIEW cycle 2 found ADR-003 and ADR-004 now document their self-contained `dist/` implications, closing the cycle 1 findings. The review still fails because ADR-002 does not explain the performance tradeoff between native desktop rendering and the selected local browser UI, as required for every decision record. No product code or tests exist, consistent with TASK-001 scope. The focused documentation audit passed for the other ADRs, architecture dependency boundary and documentation-only scope; see `tasks/TASK-001/handoffs/review-cycle2.json`. No dependent task handoffs or system package requirements were present.

PLAN cycle 3 addresses that remaining review gap in ADR-002: native desktop rendering avoids local HTTP and snapshot serialization, while the selected browser UI incurs those costs at displayed update intervals; the Rust simulation hot path remains independent of the UI. The browser choice prioritizes Chromium-based smoke/screenshot automation and flexible rendering, and requires measuring payload/latency and throttling compact canvas snapshots during implementation. The full ordered implementation plan and dependency boundary remain in `docs/ARCHITECTURE.md`. No product code or system dependency was added. No dependent-task handoffs are present.


IMPLEMENT cycle 3 rechecked the approved PLAN cycle 3 and all TASK-001 criteria. All four ADRs cover alternatives, decisions, consequences, verification, and self-contained `dist/` implications; ADR-002 now explicitly compares browser snapshot/request/render costs with native desktop rendering and explains the selection. The architecture plan and engine/UI dependency boundary remain present. No product code, product tests, or system packages were added because implementation is out of scope for this task. The focused audit passed; exact results are in `tasks/TASK-001/handoffs/implement-cycle3.json`. No dependent-task handoffs were present.

REVIEW cycle 3 passes TASK-001: the prior ADR-002 performance-tradeoff finding is closed, all four ADRs satisfy the decision-record criteria, the architecture lists modules and preserves an engine/UI dependency boundary, and no product code exists. The focused acceptance audit, `git diff --check`, prior handoff JSON parsing, and remote check passed; exact review evidence is in `tasks/TASK-001/handoffs/review-cycle3.json`. No dependent-task handoffs or system package requirements were present. Product behavior remains unimplemented by design and belongs to later tasks.

TASK-002 bootstrap files are `Cargo.toml`, `src/lib.rs`, and `src/main.rs`; CLI contract tests live in `tests/cli.rs`. Release distribution copies the native executable into ignored `dist/`. Rust/Cargo versions observed during implementation: rustc 1.100.0, cargo 1.100.0; no system package install command was needed.

REVIEW cycle 1 passes TASK-002: the three executable entry points, contract version JSON, help and unknown-command status 2, README install/build/test instructions, test suite, and ignored `target/` and `dist/` outputs are present and verified. `cargo test` passed 1 unit and 3 integration tests; setup and packaging succeeded, and both launcher and distributable worked from `/workspace/docs`. No system package installation was required. Exact evidence is in `tasks/TASK-002/handoffs/review-cycle1.json`.

TASK-003 IMPLEMENT cycle 1 adds the ADR-005 schema as `Config` and grouped
configuration types in `src/config.rs`, exports them from the library, and
provides strict JSON parse/serialize, range validation, and balanced/lush/harsh
presets. Tests cover fixed-only defaults, zero populations, missing and
wrong-type required fields, nested type/range paths, unknown keys, round-trip
equality, and preset validity/differences. `cargo test --test config` passed 5
tests and `cargo test` passed all 9 tests. Cargo downloaded the Rust crates
recorded in `Cargo.lock`; no system packages were installed or are needed.
Exact setup/package/CLI verification and handoff validation are recorded in
`tasks/TASK-003/handoffs/implement-cycle1.json`.

REVIEW TASK-003 cycle 1 found a parser correctness gap: `Config::from_json` deserializes one value with `serde_path_to_error` but does not call `serde_json::Deserializer::end()`, so a valid config followed by a second JSON value is accepted. This is not valid single-document JSON and should be rejected. Focused and full tests pass, but review verdict is FAIL pending an end-of-input check and regression test. Review evidence and exact repro are in `tasks/TASK-003/handoffs/review-cycle1.json`. No system packages are required.


TASK-003 PLAN cycle 2 responds to REVIEW cycle 1 gap `CFG-JSON-END`: the
current `Config::from_json` parses one typed value but does not require end of
input, so a valid configuration followed by another JSON value is accepted.
The next implementation cycle must call `serde_json::Deserializer::end()`
after successful `serde_path_to_error` deserialization and map trailing-content
errors into `ConfigError`. Add tests rejecting a second JSON value and trailing
non-whitespace text while accepting legal trailing whitespace. This does not
change the config schema or task scope. No system packages are needed; no
product source or test files were changed during that PLAN phase. IMPLEMENT
cycle 2 now calls `Deserializer::end()` after typed parsing, reports trailing
content as a root `configuration` error, and has regression coverage for a
second JSON value, arbitrary trailing text, and legal whitespace. Verification
passed with `cargo test --test config` (6 tests), `cargo test` (10 tests plus
doc tests), `./setup.sh`, version/help and status-2 unknown-command checks,
`./build.sh`, and source/distributable version commands from `/workspace/docs`.
No system packages were installed or are required. Exact results are in
`tasks/TASK-003/handoffs/implement-cycle2.json`.

REVIEW TASK-003 cycle 2 passes. The cycle 1 `CFG-JSON-END` gap is closed: `Config::from_json` invokes `serde_json::Deserializer::end()` on the same deserializer after `serde_path_to_error` successfully parses the typed config, and the public API regression test rejects a second JSON value and non-whitespace trailing text while accepting trailing whitespace. Review independently inspected the implementation, tests, ADR-005, plan and prior gap; focused config tests (6) and the full suite (10 plus doc tests) passed. Fixed-only input/defaults, zero counts, key-named validation, round trips and all three presets remain covered. No source changes were made in review and no system packages are needed. Exact evidence is in `tasks/TASK-003/handoffs/review-cycle2.json`.

TASK-004 IMPLEMENT cycle 1 adds `src/grid.rs` with validated nonzero grid
dimensions, signed Euclidean wrapping, shortest toroidal directions, Chebyshev
distance, and unique row-major inclusive-radius neighborhoods. Public `Grid`,
`Cell`, and `Direction` types are exported by `src/lib.rs`. Tests cover
negative and multiple wraps, even-axis ties, non-square and 1x1/1xN worlds,
invalid dimensions, and brute-force neighborhood comparisons for small grids
and radii. REVIEW cycle 1 failed only because all four cardinal crossings were
not independently asserted. PLAN cycle 2 scopes the remediation to explicit
cardinal and corner assertions in `src/grid.rs` tests; no API or behavior
change is planned. `cargo test` previously passed all 14 tests plus doc tests;
`rustfmt --edition 2021 --check src/grid.rs` and `git diff --check` passed. The
crate-wide formatter still reports pre-existing formatting differences in
`tests/cli.rs`. No system packages or new dependencies are required. Review
finding and replan are in `tasks/TASK-004/handoffs/review-cycle1.json` and
`tasks/TASK-004/handoffs/plan-cycle2.json`.

TASK-004 IMPLEMENT cycle 2 closes that test-coverage gap by independently
asserting x=-1, x=width, y=-1, and y=height crossings on a non-square grid,
plus opposite diagonal corner wraps. Existing negative/multiple-wrap and 1x1
coverage remains. Production geometry and public API are unchanged. Exact
verification is recorded in `tasks/TASK-004/handoffs/implement-cycle2.json`.

TASK-004 REVIEW cycle 2 confirms the cycle 1 edge-wrap coverage gap is closed:
the tests independently cross all four cardinal edges and both diagonal corner
directions. The review suite passes; the grid module passes its rustfmt check.
Crate-wide `cargo fmt --check` still fails only on existing formatting in
`tests/cli.rs`, outside this remediation. Review evidence is in
`tasks/TASK-004/handoffs/review-cycle2.json`.


TASK-006 PLAN cycle 1 selects static analytic base climate on the torus. A
cell-center periodic cosine supplies equatorial warmth; temperature is mapped
from cold to hot and precipitation produces a dry subtropical belt, with
thresholded polar, tundra, temperate, savanna/desert and tropical biomes. See
ADR-008 and `tasks/TASK-006/handoffs/plan-cycle1.md` for exact planned API,
seam criteria, tiny-world behavior, and implementation/test order. `World`
currently only wraps `Grid`, so TASK-006 will add per-cell climate storage and a
stable row-major non-UI map export. Climate remains static; seasons and entity
effects are out of scope. No system dependencies are planned and no apt
commands are required; existing Cargo dependencies are sufficient.

TASK-006 IMPLEMENT cycle 1 implements `src/climate.rs`: deterministic periodic cosine warmth quantized to 0..10000, base temperature in centi-degrees C, precipitation index 0..1000, and six labels (polar, tundra, temperate, desert, savanna, tropical). `World` now owns a row-major climate vector and exposes `climate(Cell)` and `biome_map()`. `evosim climate-map WIDTH HEIGHT` prints the map. Exact formulas and the warm equator/cold polar seam compromise are in ADR-008. No system packages were installed or required; dependencies are in Cargo.lock. Verification and gaps are in `tasks/TASK-006/handoffs/implement-cycle1.json`.

TASK-008 PLAN cycle 1 selects `src/entity.rs` organism records with integer
normalized trait ranges, an ordered `BTreeMap` live arena in `World`, monotonic
never-reused IDs, per-kind lifecycle accounting, and ordered death history.
Initial populations are to be constructed in plants/herbivores/carnivores
order; IDs start at 1 and generation at 0. During a tick deaths apply in
Mortality; births enter the live set at Finalize, so newborns do not act or die
in their birth tick. See ADR-010 and `docs/ARCHITECTURE.md` for the detailed
plan and acceptance-test matrix. No system packages or new crates are planned;
no product tests were run during planning. The plan handoff is
`tasks/TASK-008/handoffs/plan-cycle1.json`.

TASK-009 REVIEW cycle 1 independently verified the implementation against all
five acceptance criteria and returned PASS. `cargo test` passed all 30 tests;
`cargo fmt --all -- --check` and `git diff --check` passed. The review found no
acceptance gaps. Full evidence is in
`tasks/TASK-009/handoffs/review-cycle1.json`.

TASK-010 PLAN cycle 1 selects a derived per-cell `Vec<Vec<OrganismId>>`
index owned by `World`, with synchronous maintenance on initial insertion,
finalized births, mortality, and a new checked movement method. The query
returns references sorted by ascending ID and accepts an optional kind filter;
its radius uses unique cells from `Grid::neighborhood` and inclusive toroidal
Chebyshev distance. Index state is reconstructed from organism positions, not
serialized. Implementation will compare at least 1,000 deterministic random
queries against brute force and record a reproducible 2,000-organism timing
comparison. No system packages or new crates are planned. Detailed plan is in
`docs/ARCHITECTURE.md`, algorithm/interface rationale in ADR-003, and phase
evidence in `tasks/TASK-010/handoffs/plan-cycle1.json`.

TASK-011 IMPLEMENT cycle 1 adds deterministic fixed-point plant growth and
bounded per-cell soil water. Pools start at `ecology.resource_capacity` and
replenish by `ceil(current precipitation * capacity / 100000)` per tick.
Temperature suitability peaks at 20 C between -10 C and 50 C; precipitation
and genome fertility further scale potential growth. Gains are rounded to
100-energy quanta, with one water unit deducted per 100 energy. The `PlantGrowth`
phase processes plants by ID, then existing organisms age once before queued
deaths resolve. Plants queue age, starvation, and hostile-climate mortality;
the soil-water vector is included in snapshots. `Simulation::set_organism_energy`
supports bounded direct energy changes for tests and later feeding behavior.
Tests and exact results are recorded in
`tasks/TASK-011/handoffs/implement-cycle1.json`. No system packages or Cargo
dependencies were added. Complete checkpoint/state-hash serialization remains
future work.

TASK-012 IMPLEMENT cycle 1 adds asexual plant reproduction in the existing
Reproduction slot. Eligible plants have at least 60,000 post-growth energy;
successful births cost 20,000. A single seeded nonzero offset in the radius-two
square wraps through the toroidal grid. Establishment requires positive local
soil water and fewer than four live or pending plants in the destination.
Children use the configured one-parent mutation path, record parent ID and
checked generation, and become live at Finalize. Plants due to die from age or
hostile climate do not reproduce that tick. Focused tests and the full suite,
format and whitespace results are recorded in
`tasks/TASK-012/handoffs/implement-cycle1.json`. No system dependencies or Cargo
crates were added.

TASK-012 REVIEW cycle 1 independently inspected the reproduction scheduler,
local establishment check, implementation handoff, and dependency reviews. The
focused command `cargo test plant_lifecycle_tests -- --nocapture` passed all 3
plant lifecycle tests. `cargo test` passed 40 tests (18 library, 4 CLI, 6
config, 9 simulation, 3 spatial-index; 0 failures), and the combined
`cargo fmt --all -- --check && git diff --check` checks passed. Review verdict is
FAIL because current tests do not directly prove the energy threshold and exact
20,000 energy charge, or successful-parent energy preservation when a sampled
destination fails establishment. The implementation code appears to enforce
these rules, but acceptance evidence must be strengthened in a follow-up cycle.
See `tasks/TASK-012/handoffs/review-cycle1.json` for actionable gap IDs.

TASK-012 REVIEW cycle 2 independently inspected the cycle 2 source changes,
plan, implementation handoff, ADR, and TASK-009/TASK-011 dependency handoffs.
The deterministic lifecycle tests now assert that 59,999 energy produces no
offspring and retains its energy, 60,000 produces one offspring and leaves
exactly 40,000, and four living plants at the actual sampled destination block
birth without charging the parent. The direct establishment test still covers
zero-water rejection; the zero-plant test proves plants do not appear without
parents. `cargo test plant_lifecycle_tests -- --nocapture` passed all 5 focused
tests; `cargo test` passed 42 tests (20 library, 4 CLI, 6 config, 9 simulation,
3 spatial-index; 0 failures). Formatting, whitespace, JSON parsing, and no-remote
checks passed. Review verdict: PASS; see
`tasks/TASK-012/handoffs/review-cycle2.json`.

TASK-014 PLAN cycle 1 selects a deterministic `foraging_bias` score blending
plant energy and proximity for herbivore movement and local feeding; grazing is
limited to same/adjacent cells and transfers at most 5,000 energy per tick,
bounded by both plant energy and herbivore capacity. Herbivores pay 100 energy
maintenance plus a capped surcharge outside -5 C to 35 C. Zero-energy plants
and herbivores queue starvation for existing Mortality. Exact formulas, risks,
implementation order and tests are in ADR-014 and
`tasks/TASK-014/handoffs/plan-cycle1.md`. No system packages or crates are
planned; PLAN ran no product tests.

TASK-014 IMPLEMENT cycle 1 implements heritable plant selection and bounded
herbivore grazing in the existing AnimalMovement and Feeding phases. Herbivores
score visible plants with `foraging_bias`, eat only within toroidal Chebyshev
distance 0..=1, transfer at most 5,000 energy subject to both source and
consumer bounds, and pay climate-sensitive maintenance each tick. Starvation
uses existing deferred Mortality. Focused and full-suite evidence is in
`tasks/TASK-014/handoffs/implement-cycle1.json`; no system packages or crates
were added.

## TASK-015 carnivore hunting

PLAN cycle 1 proposes to resolve one carnivore hunt per tick in the existing
Feeding slot after herbivore grazing. Carnivores retain nearest visible
herbivore pursuit from TASK-013, and can attack one non-pending-death herbivore
at same/adjacent toroidal cells. ADR-015 defines a basis-point attack chance
from hunter strength/aggression and prey speed/risk, rolled with the simulation
RNG, with a 10%..90% clamp. A successful attack queues predation and transfers
no more than the prey's energy or hunter capacity. Every carnivore pays 500
energy per tick, including misses and no-prey turns; zero energy queues
starvation. Carnivores resolve ascending by ID: misses leave prey available,
successful pending kills are filtered from later hunts. The ordered
implementation and acceptance-test plan is in
`tasks/TASK-015/handoffs/plan-cycle1.md`. No product tests were run in PLAN; no
new crates or system packages are planned.
TASK-018 PLAN cycle 1 records integration order and acceptance-driven
verification in ADR-018 and `docs/ARCHITECTURE.md`. The existing order remains
climate/weather, resource replenishment and plant growth, animal movement,
herbivore feeding, carnivore hunting, plant then animal reproduction, aging
and mortality, birth commit, and species extinction reconciliation. The plan
calls for tick-by-tick lifecycle accounting, fixed-key 1,000-tick execution,
the extinction/persistence scenarios, reproduction checks, and an explicitly
invoked five-seed 10,000-tick extinction report. Validate defaults before any
parameter changes. No product tests were run during PLAN. No crates or system
packages are planned.
TASK-018 IMPLEMENT cycle 1 integrates and verifies the existing food-chain
engine without changing default parameters. Tick order is climate/weather and
soil-water replenishment; plant growth; animal movement; herbivore grazing;
carnivore hunting; plant reproduction; animal reproduction; aging/mortality;
birth finalization; species-extinction reconciliation. Lifecycle accounting
(`initial + births - deaths == living`) is checked after each tick in the
integration scenarios. Fixed-key configuration advanced 1,000 ticks; plants
alone persisted and reproduced, and a well-fed compatible herbivore lineage
survived and reproduced over 300 ticks. No plants caused herbivores and then
carnivores to become extinct; no herbivores caused carnivore extinction.
The default ecological parameters required no tuning. The ignored measurement
command `cargo test --release --test ecology
report_five_seeds_10000_ticks -- --ignored --nocapture` passed in 184.40 s on
the Ubuntu 24.04 container with rustc 1.100.0: plants survived in all five
seeds; herbivores went extinct at ticks 46, 46, 39, 32, 40 and carnivores at
199, 170, 191, 180, 168 for seeds 1–5. Extinction remains permanent and no
population-count protection was added. Exact tests and outcomes are in
`tasks/TASK-018/handoffs/implement-cycle1.md` and ADR-018. No dependencies or
system packages were added.
TASK-018 IMPLEMENT cycle 2 closes review gap GAP-018-R1: the 300-tick
abundant-herbivore integration scenario now retains default climate, ecology
and genetics settings on the fixed-key 64x48/400-plant world. It asserts those
sub-configs equal the `balanced` preset defaults and stages two compatible
high-fertility founders at one cell. The scenario passes with plant presence,
herbivore survival and reproduction, and lifecycle accounting after every
tick. Focused test passed in 47.01 s; `cargo test --test ecology -- --nocapture`
passed (5 passed, 1 ignored; 47.38 s); full `cargo test` passed (69 passed,
1 ignored; ecology 47.38 s and simulation integration 34.28 s). No production
behavior, default parameters, dependencies, or system packages changed. Exact
cycle 2 evidence is in `tasks/TASK-018/handoffs/implement-cycle2.md`.

TASK-019 IMPLEMENT cycle 1 adds the headless `run` command with strict stdlib
argument parsing, strict config validation, exact tick advancement, interval
and endpoint samples, lifecycle totals, species counts, and SHA-256 of a
versioned canonical state representation. The hash includes config, dimensions,
RNG continuation, base/current climate and weather, water/capacity, organisms
and genomes/traits, queued births/deaths, death history, lifecycle counters,
species records, and both ID allocators; only the derived spatial index is
omitted. `examples/minimal.json` and README provide a runnable invocation.
Exact test evidence is in `tasks/TASK-019/handoffs/implement-cycle1.json`.
`sha2` is locked in Cargo.lock; no system packages are needed.

TASK-019 REVIEW cycle 1 passes. Independent inspection confirmed the CLI's strict `--config/--ticks/--out` parsing, optional seed/sample interval handling, exact tick loop, endpoint sampling, lifecycle result fields, deferred output writing, and canonical SHA-256 state coverage. The canonical DTO includes serialized config, RNG continuation, and the complete ordered world state; the derived spatial index is reconstructible from dimensions and organism positions. `cargo test --test cli` passed (7 tests), and `cargo test` passed (72 passed, 1 ignored). Two actual `./evosim run` invocations with the same seed matched in final counts, totals, series, state hash, and tick bounds. Formatting and whitespace checks passed; no Git remotes are configured. No system packages are needed. Detailed evidence is in `tasks/TASK-019/handoffs/review-cycle1.json`.

TASK-020 IMPLEMENT cycle 1 adds `MetricsSample` as a read-only observer and an
additive `metrics` array aligned with every `series` sample in CLI run results.
It reports per-kind population, cumulative births/deaths, living species,
cumulative deaths by each cause, mean/population standard deviation for all
traits, and highest/mean generation. Empty populations and plant-inapplicable
animal behavior traits are null. Death causes are derived from death history;
capture does not affect state hashing. The JSON schema is in ADR-020 and
README. No system packages or crates were added.

TASK-021 PLAN cycle 1 specifies sequential deterministic batch runs in
`src/cli.rs`, dispatched through `src/lib.rs`, reusing the existing run result
and metrics behavior. `--vary FIELD=V1,V2` supports dotted integer config
leaves and Cartesian products; `--csv FILE` optionally exports ordered
summary rows. Summary JSON includes every run's seed/parameters/ticks, final
counts, extinction flags, and per-kind final population mean/min/max and
extinction counts, while excluding timings so repeated summaries compare
exactly. The implementation must test a 2-value by 2-seed matrix, CSV,
aggregates, validation, and determinism. No new Cargo or system dependency is
planned. See ADR-021 and `tasks/TASK-021/handoffs/plan-cycle1.json`.

TASK-021 IMPLEMENT cycle 1 adds sequential `evosim batch` execution, Cartesian
integer sweeps, per-run contract result files, deterministic population and
extinction aggregates in `summary.json`, and optional CSV export. Batch shares
the `run` result builder. Summary omits timing data. A 2-value by 2-seed
integration regression checks output files, aggregates, CSV, and repeatability.
Exact executed commands and outcomes are recorded in
`tasks/TASK-021/handoffs/implement-cycle1.json`; no system dependencies or
crates were added.

TASK-022 IMPLEMENT cycle 1 adds versioned JSON `--save`/`--load` checkpoints
to `evosim run`. Restoration validates the effective config, absolute clock,
RNG seed, climate/weather, resource vectors, organisms, species, allocator
ordering, and lifecycle/death history before reconstructing the spatial index.
Split-run tests cover save ticks 0, 5 and 13; invalid checkpoint tests cover
missing, damaged, truncated, wrong-version, and clock-inconsistent files.
Exact test results and any caveats are in
`tasks/TASK-022/handoffs/implement-cycle1.json`. No system dependencies or
crates were added.

TASK-022 PLAN cycle 1 selects readable, uncompressed UTF-8 JSON checkpoints
with an explicit versioned envelope containing config, absolute tick, RNG
continuation, and complete world state. Restore must validate state and rebuild
the derived spatial index without rerunning initialization. `--load` runs
additional ticks while preserving absolute tick and cumulative totals;
`--save` records final state. Planned tests compare uninterrupted and resumed
runs at multiple split points including tick zero and verify invalid
checkpoints produce status 2 without result files. No new crates or system
packages are planned. See ADR-022 and
`tasks/TASK-022/handoffs/plan-cycle1.json`.
## TASK-023 UI world view (PLAN cycle 1)

TASK-023 selects the existing ADR-002 local-browser architecture. The plan is
to serve a compact climate/biome plus organism-position snapshot from the
shared Rust `Simulation`, draw the full map and kind-specific symbols on a
canvas with legend, pan and zoom, and automate real Chromium for smoke and
screenshot modes. Implementation steps, acceptance evidence, risks, and
planned files are in `tasks/TASK-023/handoffs/plan-cycle1.md` and ADR-023. No
system dependencies are planned or installed in PLAN.

## TASK-023 live world view

Implemented the bundled local-browser canvas UI in `src/ui.rs` and `ui/`.
The loopback server serves ordered climate/entity snapshots from the shared
Rust simulation, advancing the world at roughly 10 ticks per second. The page
supports drag pan, wheel zoom, climate coloring, three organism markers and a
legend. Run with `./evosim ui`; contract automation is available through
`./evosim ui --smoke-test` and `./evosim ui --screenshots DIR`. Chromium must
be available for those two automation modes (the benchmark supplies it); no
system packages or Rust dependencies were added. See ADR-023 and the
TASK-023 implementation handoff for evidence and limitations.

TASK-024 PLAN cycle 1 selects browser-owned explicit tick control over the
shared Rust simulation. The UI starts paused; Run/Pause controls explicit
browser requests at 1, 5, or 20 ticks per second, while Step requests exactly
one tick and Reset rebuilds from the current config/seed. The persistent status
shows absolute tick and per-kind populations. Map snapshots add stable organism
IDs; a selected-ID endpoint supplies species, age, energy, health, traits,
eight ordered genome loci, parent IDs, and live/death information, refreshed
while selection remains active. UI checkpoint download/upload must use the
same validated version-1 JSON codec as CLI save/load, and successful load
replaces the reset baseline. A display-free controller plus Rust detail,
reset, and checkpoint tests are planned; real Chromium interaction checks must
preserve TASK-023 smoke and screenshot flows. See ADR-024 and
`tasks/TASK-024/handoffs/plan-cycle1.md`. No system dependency is planned.

## TASK-024 UI controls and inspector implementation

Implemented the control bar, persistent tick/population counts, stable-ID map
selection and live/dead inspector, explicit advance/reset endpoints, and UI
checkpoint save/load. The browser starts paused; selected speed determines a
whole-tick request batch once per second. Checkpoint capture/decode is shared
with the CLI and upload validation completes before state replacement. HTTP
request bodies are capped at 32 MiB. Rust detail, snapshot and shared codec
tests and Node controller tests were added. Exact execution evidence and any
remaining verification gaps are in
`tasks/TASK-024/handoffs/implement-cycle1.json`. No system packages or crate
dependencies were added.

TASK-025 IMPLEMENT cycle 1 adds complete preset-driven experiment editing,
inline field validation, JSON configuration import/export, four labeled SVG
time-series charts and a selectable current trait distribution. Browser logic
is display-free and covered by Node tests. `/api/charts` provides a UI-only
1,000-sample metrics buffer, seeded on world creation/reset/checkpoint restore
and appended after each explicit advance; it remains outside checkpoints and
simulation hashes. Screenshot mode now produces `main.png` and `charts.png`
from Chromium. No system dependencies, Cargo crates or npm packages were
added. See ADR-025 and `tasks/TASK-025/handoffs/implement-cycle1.json` for exact
evidence and remaining limitations.

TASK-026 IMPLEMENT cycle 1 adds a reproducible release tick benchmark and a
loose 1 tick/s regression guard. `World::reconcile_species_extinctions` now
collects living species IDs once before checking records, eliminating the
per-species full-population scans. The fixed plant workload reached 12,307
organisms after warm-up and sampled at least 10,412 through the measured run.
Release median throughput improved from 194.90 to 241.28 ticks/s. `perf` and
`valgrind` were unavailable; temporary per-phase `Instant` measurements
identified reproduction (54.7%) and mortality/finalize (23.4%) as largest
costs, and the instrumentation was removed before final runs. No system
dependencies or crates were added. Full evidence and limitations are in
`docs/PERFORMANCE.md`, ADR-026, and
`tasks/TASK-026/handoffs/implement-cycle1.json`.

TASK-027 IMPLEMENT cycle 1 starts from a pristine fixed-key baseline on seeds
1–10: plants persist, herbivores first reach zero at ticks 32–96 (all 120
herbivore deaths are predation, with no births), and carnivores later starve.
The selected local mechanism gives carnivores 20 Feeding passes of handling
after a successful kill while retaining ordinary energy costs. On tuning seeds
1–10, first herbivore extinction moved to ticks 174–229 (mean 195.3); all runs
still eventually collapsed, so the result is a measured extension rather than
coexistence. Organism `hunting_cooldown` is serialized and participates in
state hashes/checkpoints. See ADR-027, `docs/BALANCE.md`, and the TASK-027
implementation handoff for complete held-out, suite and performance evidence.

TASK-027 held-out seeds 11–15 had exact first herbivore-extinction ticks
214, 245, 155, 224 and 186, followed by carnivore starvation at ticks 331,
386, 261, 328 and 313. No held-out run maintained all three kinds to 10,000
ticks. `cargo bench --bench simulation` measured 239.00 ticks/s on its final run after the
change versus the prior 241.28 median; it remains above the 100 ticks/s target.
The full suite passed (84 passed, 1 ignored), including checkpoint and seeded
repeatability coverage. Full commands and results are in `docs/BALANCE.md` and
the TASK-027 implementation handoff.

TASK-028 PLAN cycle 1 selects `docs/VERIFICATION.md` for contract evidence and
the project self-audit, `scenarios/demo.json` for a measured non-default demo,
and deterministic bounded randomized integration tests for lifecycle
accounting, bounded values, wrapping and repeatability. The implementation
must verify a copied `dist/evosim` outside the source tree, real browser smoke
and screenshot paths, all contract entry points, one aggregate test command,
and three-seed 10,000-tick results for both defaults and demo. Existing
TASK-027 evidence documents the default extinction pattern; batch's no-op
`--vary` compatibility workaround must be tested or corrected and reported.
No system dependency is currently planned; record exact installation
commands here if that changes. Ordered implementation work, alternatives and
risks are in ADR-028 and `tasks/TASK-028/handoffs/plan-cycle1.md`.

# Simulation performance

## Reproducible workload

Run from the repository root:

```sh
cargo bench --bench simulation
```

This builds and runs the release-profile, harness-free `benches/simulation.rs`.
It reads `benchmarks/performance.json` (seed 26026, 64×48, 3,000 plants, no
animals), constructs the shared `Simulation`, warms it for 50 ticks, then times
300 `step_one_tick` calls. It samples population every 25 measured ticks and
reports elapsed time and throughput. Configuration parsing, simulation
construction, warm-up and output are outside the timed window. Population
queries every 25 measured ticks are inside it; the sampled mean also includes
the post-warm-up population as its initial sample. The benchmark performs no
state serialization or result metrics.

The plants reproduce until constrained by the existing maximum of four plants
per cell. The initial count is 3,000; after warm-up it was 12,307, the final
count was 11,964, and the minimum sampled population was 10,412. Thus this is a
plant-heavy, roughly 12,000-organism load, not a balanced food-chain workload.
The benchmark guard separately initializes the same world at 2,000 plants,
warms for five ticks, and checks 20 measured ticks.

## Host and results

Measured in the Ubuntu 24.04 benchmark container on an AMD Ryzen 5 7500F
(6 cores / 12 threads, x86_64), with Rust `rustc 1.100.0`. Build profile was
Cargo `bench` (optimized release). No system packages or Cargo crates were
added.

| Stage | Three measured ticks/s | Median | Elapsed time at median |
|---|---:|---:|---:|
| Before optimization | 190.37, 194.93, 194.90 | 194.90 | 1.539 s |
| After optimization | 241.28, 241.34, 239.86 | 241.28 | 1.243 s |

Median throughput increased 23.8%. Counts at warm-up, final, and sampled
minimum/mean were identical before and after, as the optimization does not
alter the simulation's decisions.

## Profile and change

Neither `perf` nor `valgrind` was available in the container. Rather than claim
a sampling profile, temporary `Instant` timers were added around the existing
tick phase groups, run for the 50-tick warm-up plus 300-tick measurement, and
removed before the final benchmark. Summed phase time shares were:

| Phase group | Share |
|---|---:|
| Reproduction | 54.7% |
| Mortality and finalization | 23.4% |
| Plant growth | 18.9% |
| Climate and resources | 1.2% |
| Feeding and hunting | 1.2% |
| Animal movement | 0.7% |

The profile led to inspection of birth and extinction finalization. In
`World::reconcile_species_extinctions`, each living species previously scanned
the entire organism map to determine whether it remained represented. The
implementation now builds a transient `HashSet` of living species IDs in one
organism pass, then checks each species record by membership. This removes the
species-count × population-count scan. It preserves the existing species
extinction predicate and reconciliation tick, and does not draw randomness,
change actor order, or alter serialized state. The benchmark's phase timings
are diagnostic instrumentation rather than statistical sampling; further
sampling profiling would be useful where profiler permissions and tooling are
available. Reproduction remains the largest cost center and was not changed in
this task.

## Regression guard

`cargo test --test performance` runs the same dense plant setup for five
unmeasured ticks and 20 timed ticks. It checks that population stays above
1,900 and requires at least 1 tick/s, a deliberately loose floor intended to
catch gross slowdowns rather than enforce machine-specific performance. The
measured test passed in 4.61 seconds in this container.

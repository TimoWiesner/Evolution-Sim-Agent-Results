# ADR-019: Headless run command and canonical state hash

## Status

Accepted for TASK-019 IMPLEMENT cycle 1.

## Context

The contract requires a headless `evosim run` command that validates arguments/configuration, advances an exact tick count, writes result JSON, reports cumulative lifecycle metrics, and hashes the complete state deterministically. `Simulation` already owns seeded ChaCha8 and exposes ordered tick advancement. Its current snapshot omits base climate, configuration, resource capacity, pending lifecycle state, and several parts of the complete world, so it cannot yet directly satisfy the hash requirement.

## Decisions

- Implement the `run` command in `src/cli.rs`, dispatched from `src/lib.rs`/`src/main.rs`, using the standard library argument parser. Keep the engine independent of CLI and wall-clock code.
- Accept `--config FILE --ticks N --out FILE [--seed N] [--sample-every K]`. Reject unknown, duplicate, missing, malformed, or out-of-range flags with status 2, stderr diagnostics, and no result file. Do not create/open the output until all inputs validate and the simulation completes; output writing errors also return status 2.
- Parse config with existing strict `Config::from_json`; an optional seed replaces only `Config.seed` before constructing `Simulation`.
- Use `u64` for ticks, sample intervals, and seeds. Tick advancement is an explicit loop for exactly N invocations, including when all kinds are extinct and for N=0. Sampling includes the initial absolute tick, each interval boundary, and final tick exactly once. When omitted, K is `max(1, ceil(N/100))`; N=0 uses K=1.
- Emit the contract result fields, with sorted ascending kind order represented by fixed named keys. Counts and living species come from `World`; cumulative births/deaths come from lifecycle counters and preserve `initial + births - deaths = final`. `elapsed_seconds` measures only the simulation loop; `ticks_per_second` is zero for N=0, otherwise N divided by loop duration (guarding timer resolution).
- Serialize an explicit versioned canonical-state DTO with `serde_json`, using only ordered fields and vectors sourced from existing `BTreeMap`/stable world iteration. Include absolute tick, dimensions, the full effective config, RNG seed/stream/word-position, base/current climate and weather, soil water/resource capacity, all live organisms including genome/traits/lineage/energy/health/cooldown/species, pending births/deaths, death history, lifecycle totals, species records and both monotonic allocators. Derived spatial index is omitted because it is reconstructed from organism positions and is not independent state.
- Hash canonical serialized bytes with SHA-256 (`sha2` crate, version locked in `Cargo.lock`) and lowercase hexadecimal. Fixed DTO field order, stable vector order, and explicit hash-format version make identical states hash identically and make omissions reviewable. Hashing is performed after the last requested tick, including at tick zero.
- Keep save/load/checkpoint flags and batch out of scope. The hash DTO is a shared foundation that TASK-022 can extend or reuse, but no checkpoint behavior is introduced here.

## Alternatives and tradeoffs

- A hand-written FNV hash is dependency-free but has weaker collision resistance and would require bespoke encoding rules for every state field. SHA-256 adds a small Rust dependency and provides a standard digest; it does not substitute for a canonical serialization definition.
- Hashing the existing `SimulationSnapshot` is simpler but provably incomplete. Canonical serialization costs some work and temporary memory proportional to world state, but the benchmark output already needs final metrics and correctness requires inclusion of all continuation-relevant state.
- A CLI parsing crate would reduce parser code but adds a dependency and no user-visible need here; the small fixed flag surface is handled with a strict standard-library parser.
- A default sample interval based on floor division could yield more than 100 intermediate samples. Use ceiling division so the default is at most approximately 100 intervals while honoring the contract's “1/100 of N” guidance.

## Implementation record

The implementation is in `src/cli.rs`, with canonical serialization and SHA-256 in `src/simulation.rs` and complete ordered world-state data in `src/world.rs`. The result DTO is colocated with CLI parsing rather than a separate metrics module because only this command consumes it. A runnable fixed-key example lives at `examples/minimal.json`; `scenarios/demo.json` is not present yet, so the README uses the available file. Derives were added to stable state types solely to support the explicit canonical DTO. No simulation behavior changed.

Verification covers repeatability, different seeds, zero ticks, no-plant extinction while advancing, hash sensitivity to organism energy, result schema and sample endpoints, argument errors/no-output, headless execution, full tests, setup/build, JSON parsing, formatting, whitespace and remote checks. Exact commands and results are in `tasks/TASK-019/handoffs/implement-cycle1.json`.

## Risks

- The current snapshot types do not capture all complete simulation state. Hashing must not ship until a field-by-field completeness audit and mutation-sensitivity tests cover every canonical state section.
- `serde_json` map ordering is not a safe implicit contract for arbitrary maps; the canonical DTO must use structs and ordered vectors only.
- Wall-clock duration can be below timer resolution; ensure finite nonnegative metrics and avoid NaN/Infinity in JSON.
- Result-file creation must happen after validation and simulation so rejected input never leaves a partial result at the requested path.
- Large configured populations and long tick runs can consume substantial memory/time; retain existing configuration bounds and avoid extra per-tick full-world clones.

No system packages are planned. `sha2` is a Cargo dependency and needs no apt install command.

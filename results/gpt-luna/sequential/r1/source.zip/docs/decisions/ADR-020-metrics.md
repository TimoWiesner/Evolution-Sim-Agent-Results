# ADR-020: Sampled evolution metrics

## Status

Implemented for TASK-020 IMPLEMENT cycle 1; IMPLEMENT cycle 2 closes
GAP-020-R1 with fixed-value trait spread and nonzero generation assertions.

## Context

TASK-020 requires population, lifecycle, species, trait, and generation metrics
at every requested sample tick. The existing `evosim run` result already has a
sampled `series`, and the interface contract permits additional result keys.
`World` exposes ordered organisms, cumulative lifecycle counts, living species
counts, and ordered death history. `Simulation::state_hash` hashes simulation
state independently from result serialization.

## Decision

- Add a `metrics` JSON array to the `evosim run` result, aligned one-for-one
  with `series`. Each record uses the same absolute tick. No new flag or
  separate metrics file is needed.
- At each sample, record per-kind living population, cumulative births and
  deaths since tick zero, per-kind living species count, cumulative death
  counts cross-tabulated by kind and cause, and generation/trait statistics
  grouped by kind.
- Report highest and arithmetic mean generation per kind. For each trait,
  report arithmetic mean and population standard deviation over living
  organisms of that kind at that sample. Compute means and standard deviations
  from integer sums/sums-of-squares and expose them as JSON numbers. Empty
  populations have `null` generation and trait statistics. A trait that does
  not apply to a kind (risk tolerance, aggression, or foraging bias for plants)
  is `null`; applicable traits in an empty population also have `null` values.
- The trait list follows `Traits`: speed, strength, fertility, max_health,
  max_lifespan_ticks, risk_tolerance, aggression, and foraging_bias. Death
  causes follow `DeathCause`: starvation, predation, age, climate, injury, and
  other. All cause keys are present, including zeros.
- Metrics collection is a read-only observer over `&Simulation`. It holds no
  state in the simulation and draws no random values. Death-by-cause counts are
  derived from ordered death history during capture. The canonical simulation
  serialization/hash remains unchanged by collection.
- The result remains JSON. `metrics` is additive and does not change the
  existing result keys or their meanings.

Each array item has this shape (count values are integers; means and standard
deviations are JSON numbers):

```json
{
  "tick": 10,
  "population": {"plants": 0, "herbivores": 0, "carnivores": 0},
  "births": {"plants": 0, "herbivores": 0, "carnivores": 0},
  "deaths": {"plants": 0, "herbivores": 0, "carnivores": 0},
  "living_species": {"plants": 0, "herbivores": 0, "carnivores": 0},
  "deaths_by_cause": {
    "plants": {"starvation": 0, "predation": 0, "age": 0, "climate": 0, "injury": 0, "other": 0},
    "herbivores": {"starvation": 0, "predation": 0, "age": 0, "climate": 0, "injury": 0, "other": 0},
    "carnivores": {"starvation": 0, "predation": 0, "age": 0, "climate": 0, "injury": 0, "other": 0}
  },
  "traits": {
    "plants": {"speed": null, "strength": null, "fertility": null, "max_health": null, "max_lifespan_ticks": null, "risk_tolerance": null, "aggression": null, "foraging_bias": null},
    "herbivores": {"speed": null, "strength": null, "fertility": null, "max_health": null, "max_lifespan_ticks": null, "risk_tolerance": null, "aggression": null, "foraging_bias": null},
    "carnivores": {"speed": null, "strength": null, "fertility": null, "max_health": null, "max_lifespan_ticks": null, "risk_tolerance": null, "aggression": null, "foraging_bias": null}
  },
  "generation": {
    "plants": {"highest": null, "mean": null},
    "herbivores": {"highest": null, "mean": null},
    "carnivores": {"highest": null, "mean": null}
  }
}
```

For a non-empty kind, each applicable trait entry is
`{"mean": <number>, "standard_deviation": <number>}`; an inapplicable
behavioral trait and every trait for an empty kind serialize as `null`.
Generation's two fields are `null` for an empty kind.

## Alternatives and tradeoffs

- A separate file/CLI option could avoid increasing the ordinary result, but
  would add command-line surface and file error cases. An additive result key
  keeps one atomic artifact and is permitted by the contract.
- Per-interval births/deaths are useful for rates, but cumulative values are
  unambiguous, directly comparable to contract totals, and preserve the
  existing accounting identity at each tick.
- Standard deviation describes variation around the mean; min/max range is
  simpler but does not distinguish concentrated from broadly distributed
  populations. Integer accumulators make the chosen statistic deterministic;
  conversion to JSON floating point occurs only in reporting.
- Storing cause counters in `World` would require another canonical state
  field. Deriving them from existing death history avoids simulation-state and
  hash changes, at the cost of reading history at samples.

## Verification plan

Add focused metrics tests for known hand-built organisms/counts and a small
world, including empty populations, plants' inapplicable traits, every death
cause, species, births/deaths, and known trait/generation mean and spread. Add
a regression that captures metrics in one seeded simulation while advancing a
second identical simulation without capture, then compares final canonical
state hashes. Add a CLI integration test confirming metrics appear at every
series tick and that existing contract fields remain intact. Run focused
metrics/CLI tests, full `cargo test`, formatting, whitespace, and JSON handoff
validation. No system package or dependency is planned.

## Risks

Cycle 2 follow-up for GAP-020-R1: set two plant organisms to explicit speed
values 10 and 14 and generations 2 and 4, then assert speed mean 12, population
standard deviation 2, highest generation 4, and mean generation 3. Keep the
existing state-hash invariance regression. This replaces inferred expectations
from generated genomes with values independently verifiable by hand.

- Computing organism summaries is O(live population) per sample; frequent
  `--sample-every 1` requests add reporting work even though they do not change
  simulation outcomes.
- Cause counts read death history, whose size grows with total mortality. If
  measurement shows this dominates reporting time, a later design can maintain
  derived observer cursors without making analytics affect the engine.
- JSON consumers may need to tolerate the new additive `metrics` key and
  nullable values; the fixed contract allows additional result keys.

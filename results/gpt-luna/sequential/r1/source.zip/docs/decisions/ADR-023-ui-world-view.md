# ADR-023: Browser UI and live world view

## Status

Accepted and implemented for TASK-023.

## Context

TASK-023 requires a live climate/biome map with all organisms, a legend,
pan/zoom, responsive updates at 1,000 organisms, and real-browser smoke and
screenshot flows. TASK-001 already chose a local browser UI served by the Rust
executable (ADR-002). TASK-006 exposes deterministic cell climate/biome data;
TASK-013 moves animals through the indexed toroidal world; TASK-019 runs the
same `Simulation` engine headlessly.

## Decisions

- Keep the local browser UI selected by ADR-002. Implement UI command/server
  behavior in `src/ui.rs`, dispatch `evosim ui` from `src/lib.rs`, and bundle
  static HTML/CSS/JavaScript in `ui/` (embedded at compile time with
  `include_str!` or copied alongside the executable only if packaging requires
  it). No UI framework or runtime network dependency is needed for a canvas
  view.
- The Rust server owns one `Simulation` created from the optional validated
  config (or the default preset). It serves current-cell climate/biome values
  and ordered living organism positions from `World`; it must not implement a
  second simulation or mutate entities outside the engine APIs. A small
  versioned JSON snapshot is the browser boundary.
- Use a single HTML canvas for the grid and overlay. Paint every grid cell from
  its climate/biome and draw living plants, herbivores, and carnivores with
  distinct shapes/colors. A visible legend names both the climate palette and
  organism symbols. Use device-pixel-ratio-aware canvas sizing and batch draw
  calls by kind to keep 1,000+ entities responsive.
- Support drag-to-pan and wheel-to-zoom in cell/world coordinates, clamping
  zoom to usable bounds while retaining access to every cell. Keep the header
  and a reserved lower/sidebar region available for TASK-024 controls and
  TASK-025 parameter/chart work; those features are not added here.
- Serve through a loopback-only `std::net` HTTP listener and static assets.
  Prefer the standard library and add no system package or Rust dependency;
  use `CHROME_BIN` when set and otherwise the benchmark's `chromium` executable
  for automation. Interactive launch should open the local URL in a browser.
- For `--smoke-test` and `--screenshots DIR`, run the real page in headless
  Chromium. A query-driven automation mode asks the same engine to advance at
  least 10 or 100 ticks, waits for the drawn snapshot, and reports completion
  to the process. Smoke exits zero only after a rendered frame; screenshots
  capture the real page at 1280x720 or larger into `DIR/main.png`. Bound child
  process and server waits to the contract's 60/120 second limits and clean up
  the server on success or failure.

## Alternatives and tradeoffs

- A native renderer would avoid HTTP/JSON transfer and browser startup, but
  conflicts with the established ADR-002 browser choice and complicates the
  contract's real-browser screenshot automation.
- Per-cell DOM/SVG is straightforward for small worlds but creates many
  elements and layout work. Canvas gives one draw surface and direct control
  over redraw cost; individual cell/entity inspection is outside this task.
- A third-party web framework or async runtime could simplify routing, but
  increases dependencies and packaging work for a small local API. A bounded,
  loopback-only standard-library server is adequate if request parsing and
  child lifetimes are explicitly tested.
- Streaming the entire simulation state every frame wastes bandwidth and
  couples the UI to internal structures. A compact ordered snapshot containing
  cell climate and visible entity coordinates is enough for this view.

## Verification plan

Add snapshot/HTTP and rendering behavior tests for every cell's climate,
organism-kind encoding and stable order; verify loopback service and config
validation. Run the contract smoke command under `xvfb-run` and the screenshot
command into an existing directory, verify `main.png` is PNG and at least
1280x720, and inspect that it contains the world, legend, and entity overlays.
Exercise pan/zoom handlers in browser automation or focused JS behavior checks.
Measure repeated page snapshots/rendering with a 1,000-organism world and
record the observed update rate. Finally run `cargo test`, `cargo fmt --all --
--check`, `git diff --check`, `./setup.sh`, and the UI contract commands. No
system dependency install is planned.

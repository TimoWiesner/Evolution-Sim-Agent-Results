# ADR-007: Simulation clock, random stream, and tick scheduler

- Status: Accepted for TASK-005 implementation planning.
- Context: Every later simulation feature must advance from one seeded state, in
  a fixed order, and checkpoints must restore the random stream exactly. The
  existing architecture calls for ChaCha8 and stable ID ordering. TASK-005
  builds the scheduler frame only; ecology behavior remains out of scope.
- Alternatives considered:
  - A small hand-written generator (such as xoshiro): easy to serialize as a
    few words, but departs from ADR-004's already selected ChaCha8 stream and
    creates a second generator decision to maintain.
  - `rand_chacha` ChaCha8: established deterministic algorithm with explicit
    stream-position controls and a fixed seed; adds a small Cargo dependency
    tree but no OS/runtime dependency.
  - Wall-clock or global RNG: rejected because it breaks replay and checkpoint
    equivalence.
- Decision: Use `rand_chacha::ChaCha8Rng` with `rand_core::SeedableRng` and
  `RngCore`. Expand configured `u64` seed into a 32-byte seed with a documented
  fixed SplitMix64 sequence (fixed constants and little-endian word layout).
  A public `RngState` stores the 32-byte seed, ChaCha word position (`u128`),
  and stream selector (`u64`). Export reads position/stream from the RNG;
  restore constructs from seed, applies stream and word position, and must
  reproduce the next output exactly. Pin compatible crate versions in
  `Cargo.lock`; tests lock seed expansion and output vectors so dependency
  changes cannot silently alter replay.
- Scheduler: `Simulation` owns absolute `tick: u64`, `DeterministicRng`, and
  `World`. `step_one_tick` advances exactly once and returns an ordered
  `TickReport`/event list. The initial fixed phase order is:
  `Climate`, `PlantGrowth`, `AnimalMovement`, `Feeding`, `Reproduction`,
  `Mortality`, `Finalize`. Phases are explicit stable enum values even while
  feature behavior is a no-op in this task. Within phases, process stable
  entity IDs ascending; ties use ascending ID and then row-major cell order.
  New births and removals are deferred to phase boundaries and applied by
  ascending ID, so iteration does not depend on container or hash order.
  Record each visited phase in the report; do not consume random values merely
  to create test variation. Future phase implementations must draw only from
  the simulation-owned RNG.
- State/events: expose a compact serializable state snapshot sufficient for
  trace comparison: tick, grid dimensions, and `RngState`; phase/event order
  is a vector, never a map. `World` initially wraps the validated `Grid`; later
  tasks add contents without changing the clock/RNG ownership contract. Keep
  `step_one_tick` independent of CLI/UI modules and wall time.
- Consequences: fixed integer state and ordered phases make repeatability and
  save/restore testable. ChaCha's stream is tied to the chosen crate algorithm
  and must be version-locked by vectors. The no-ecology scheduler proves clock
  progression and state replay, but later behavior tasks must add domain events
  and expand traces without weakening stable ordering.
- Verification: test seed expansion/golden output, export/restore after mixed
  `next_u32`/`next_u64` draws, exact one-tick progression and phase order,
  identical traces over 100 ticks for equal seeds, differing traces for
  distinct seeds, and that engine modules import no UI/CLI code. Run focused
  scheduler/RNG tests and full `cargo test`; no apt packages are planned.

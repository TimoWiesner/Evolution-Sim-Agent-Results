# ADR-026: Measure and optimize simulation throughput

## Status

Accepted and implemented for TASK-026. The release benchmark and regression
guard are in place. A quadratic species-extinction scan was replaced with one
pass collecting living species IDs. Measured release throughput improved from
194.90 to 241.28 ticks/s median in the documented plant-heavy workload; see
`docs/PERFORMANCE.md`.

## Context

TASK-026 needs a reproducible throughput command at approximately 2,000 living
organisms, a profile of expensive code, before/after numbers, and a stable
regression guard. The engine is Rust; `Simulation::step_one_tick` is the shared
headless/UI engine entry point. Existing evidence includes a debug spatial-index
microbenchmark (2,000 organisms, radius-two queries) and a 50,000-tick ecology
report, but neither measures release whole-tick throughput with a fixed dense
population.

## Decision

- Add a fixed benchmark config under `benchmarks/performance.json`, with seed
  26026, a 64x48 world, and a plant-only initial population sized above 2,000.
  Plant-only removes the variable cost of predation while exercising climate,
  growth, occupancy, reproduction, lifecycle and finalization. During
  implementation, validate after warm-up that the chosen config maintains at
  least approximately 2,000 living organisms throughout the measured window;
  adjust only benchmark config/measurement duration if necessary, not ecology.
- Add a dedicated `benches/simulation.rs` harness-free benchmark executable.
  It constructs one `Simulation`, advances a documented warm-up, then times a
  fixed measured tick count using `Instant`; it reports initial/final and
  sampled mean population, ticks, elapsed seconds and ticks/second. It must not
  serialize results or include startup in the timed region. Command:
  `cargo bench --bench simulation` (release profile, fixed seed/config and
  tick counts embedded in source/config).
- Capture the pre-optimization run and a CPU profile before editing hot-path
  behavior. Prefer Linux `perf`/`cargo flamegraph` sampling on the release
  benchmark executable. If the container cannot provide perf-event access,
  record the limitation and use targeted temporary phase timing/instrumentation
  that is removed before final results; profiling support must not affect RNG,
  state, or benchmark output semantics.
- Optimize only the dominant measured work, in small changes. Preserve actor
  ordering, RNG draw count/order, all simulation state transitions, and
  serialization/checkpoint formats. Avoid changing ecology constants or
  behaviors to improve throughput.
- `World::reconcile_species_extinctions` now builds a `HashSet` of species IDs
  represented by living organisms, then checks each species record once. This
  replaces a full population scan for every species while preserving the same
  extinction predicate and tick boundary. The hash set is transient derived
  state and does not enter serialization or RNG behavior.
- No system packages or Cargo dependencies were added. `perf` and `valgrind`
  were unavailable, so temporary per-phase `Instant` instrumentation was used
  to profile 350 benchmark ticks and removed before final measurements.
- The automated guard in `tests/performance.rs` runs a fixed-seed 2,000-plant
  workload through public `Simulation` APIs, warms five ticks, measures 20
  ticks, and requires at least 1 tick/s while keeping population above 1,900.
  The longer report/profile remains separate from ordinary tests.
- Write `docs/PERFORMANCE.md` with CPU/container/toolchain/build profile, exact
  commands, fixed workload and warm-up/measured counts, baseline and final
  throughput, profile findings, changes and remaining bottleneck. Update
  `docs/STATE.md` and `docs/ARCHITECTURE.md` with final evidence. No apt package
  or crate is currently planned; if implementation installs one, record the
  exact install command in `docs/STATE.md` and the phase handoff.

## Alternatives and tradeoffs

- Timing `evosim run` would include initialization, JSON output and sampled
  metrics, obscuring the tick-loop rate. A dedicated Cargo bench isolates the
  engine while retaining an executable reproducible command.
- A plant-heavy population gives repeatable density without reliance on animal
  mating compatibility or fragile food-chain survival. It does not represent
  the exact species mix of a complete ecosystem; the report will state this.
- Criterion adds a dependency and statistical harness that is unnecessary for
  this fixed workload. A small standard-library `Instant` benchmark has no
  runtime dependency and is easy to reproduce, though repeated runs remain
  important.
- A very strict throughput test would be hardware-sensitive. The loose floor
  guards catastrophic slowdowns; the dedicated benchmark supplies meaningful
  performance evidence.
- Release flamegraphs can identify hot functions with low source impact, but
  depend on profiler tooling and kernel permissions. Temporary phase timing is
  a fallback and must be removed before final measurement.

## Verification plan

Run baseline and final `cargo bench --bench simulation` at least three times,
report median and range, and capture a release CPU profile. Confirm the timed
window maintains roughly 2,000 or more living organisms. Run the new performance
guard and the complete existing suite, explicitly retaining determinism,
checkpoint continuation and state-hash regressions. Run formatting and
whitespace checks. Compare deterministic outputs/hashes for unchanged fixture
seeds where applicable. Record exact command results in TASK-026 handoffs and
`docs/PERFORMANCE.md`.

## Risks

- A benchmark population that grows or declines quickly can make the density
  misleading; record start/end and sampled population and tune the workload
  before any optimization.
- Optimization can accidentally change iteration ordering or random-number
  consumption even when visible population counts look similar. Existing
  repeatability and checkpoint tests plus targeted state-hash comparisons are
  mandatory.
- Container CPU sharing and frequency scaling make short timings noisy; use a
  warm-up, sufficiently long measured window and multiple runs.
- `perf` may be absent or blocked in the benchmark container. The fallback
  profiling approach and any limitation must be explicit in the final report.

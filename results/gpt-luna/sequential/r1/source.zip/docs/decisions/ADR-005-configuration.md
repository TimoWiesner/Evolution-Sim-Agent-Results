# ADR-005: Typed configuration and presets

- Status: Accepted for TASK-003 implementation planning.
- Context: The external JSON contract requires three fixed top-level keys and permits no extra required keys. Later engine tasks need a typed, validated shared configuration. TASK-003 also requires default values, field-named validation errors, serialization round trips, and built-in presets.
- Alternatives considered:
  - Handwritten JSON parsing/serialization: avoids dependencies but creates substantial parser, type-error, and escaping code and makes malformed-field reporting easy to get wrong.
  - `serde` with `serde_json`: conventional Rust typed JSON support with custom validation; adds Cargo crates but no OS packages and supports native packaging.
  - Accept unknown keys for forward compatibility: convenient for hand-edited files, but silently ignores misspellings and invalid tunables.
- Decision: Use `serde` derive and `serde_json`; JSON is the sole required format in this task. Unknown keys at every object level are errors. Require fixed fields, apply defaults to optional configuration groups and all their fields, validate bounds explicitly, and report the offending field path in `ConfigError`. `Config::to_json` writes every field and default; loading that output must equal the original value.

## Schema and defaults

All numeric settings are integers with explicit units. `Config` has required fields `seed: u64`, `world: WorldConfig`, and `initial: InitialConfig`; `WorldConfig.width/height: u32` each have range `1..=4096`, and `InitialConfig.plants/herbivores/carnivores: u32` each have range `0..=1_000_000`. The upper limits guard unreasonable allocations while preserving the contract's stated lower-bound inputs.

Optional `climate`, `ecology`, and `genetics` objects default as a whole when absent and each field defaults when omitted:

| Field | Type / unit | Default | Valid range |
|---|---|---:|---:|
| `climate.season_length_ticks` | `u32`, ticks | 240 | 1..=100000 |
| `climate.seasonal_temperature_amplitude_centi_c` | `u16`, 0.01 °C | 1800 | 0..=6000 |
| `climate.precipitation_seasonality_bp` | `u16`, basis points | 2500 | 0..=10000 |
| `climate.weather_enabled` | `bool` | true | true or false |
| `ecology.plant_growth_per_tick_permille` | `u16`, per mille of capacity | 35 | 1..=1000 |
| `ecology.resource_capacity` | `u32`, resource units per cell | 1000 | 1..=1000000 |
| `ecology.animal_metabolism_per_tick` | `u16`, energy units | 3 | 0..=10000 |
| `ecology.reproduction_energy_threshold` | `u16`, energy units | 100 | 1..=10000 |
| `genetics.mutation_probability_bp` | `u16`, basis points | 250 | 0..=10000 |
| `genetics.mutation_step` | `u16`, normalized gene units | 2048 | 0..=65535 |

The field bounds are configuration acceptance bounds, not a claim about final ecological calibration. Engine tasks may consume these values according to their units but must preserve the config API absent an explicit architecture change.

## Presets

`Config::preset(name)` accepts exactly `balanced`, `lush`, and `harsh`; `available_presets()` returns those names in that order. Each preset starts from the full defaults, including seed 42, a 64×48 world, and 400/120/20 initial counts.

- `balanced`: all defaults.
- `lush`: seasonal temperature amplitude 900 centi-°C, precipitation seasonality 1000 bp, plant growth 70 permille, capacity 1500.
- `harsh`: seasonal temperature amplitude 3500 centi-°C, precipitation seasonality 8000 bp, plant growth 12 permille, capacity 500.

Preset selection is a library API only; CLI handling is outside TASK-003. Presets differ in climate and resource behavior settings, remain within validation limits, and ordinary JSON can serialize them.

## Parser completeness finding (TASK-003 PLAN cycle 2)

`Config::from_json` must accept exactly one complete JSON document. The first
implementation deserializes the typed configuration through
`serde_path_to_error`, but does not check the underlying
`serde_json::Deserializer` after that value. Review cycle 1 demonstrated that
`<valid-config>{}` therefore returns success. The implementation must call
`Deserializer::end()` after successful typed deserialization and convert any
trailing-content error into `ConfigError`. Preserve path-qualified errors for
the initial typed parse; an end-of-input failure can identify the root as
`configuration` because the unexpected content follows the complete value.

Add regression coverage for at least a second JSON value and non-whitespace
trailing text. Whitespace after the sole config remains valid JSON and should
continue to parse. This closes review gap `CFG-JSON-END` without changing the
schema, presets, or public API.

## Consequences and verification

Strict unknown-key rejection catches spelling mistakes but makes schema evolution explicit. Adding a field requires a default and round-trip tests. Integer fixed-point values avoid float equality instability. `serde_json` errors must be normalized to include the relevant key path for type and missing-field failures; range checks return the same path format. Tests cover each fixed field's missing/type/range cases, grouped field type/range failures, unknown keys, zero populations, fixed-only input, complete round trips, all presets, and strict end-of-input handling (reject trailing second values or non-whitespace text while accepting trailing whitespace). Cargo dependencies are built into the native executable; no runtime service, external data file, or system package is needed for the config module or `dist/`.

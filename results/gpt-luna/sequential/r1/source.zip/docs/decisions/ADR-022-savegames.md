# ADR-022: Versioned savegames and checkpoints

- Status: Implemented for TASK-022 cycle 1; review pending.
- Context: `evosim run` currently builds a fresh `Simulation` and hashes a
  canonical version-1 JSON DTO. TASK-022 must save every continuation-relevant
  value, reject invalid files without writing results, and resume bit-for-bit
  deterministically.
- Alternatives considered:
  - Reuse canonical JSON as a checkpoint: human-readable, directly inspectable,
    easy to validate, and uses existing `serde_json`; larger files and parse
    cost are acceptable for this local simulation.
  - Binary encoding: smaller/faster, but harder to inspect and more coupled to
    Rust data layout/versioning.
  - Compression (for example gzip/zstd): reduces size but introduces another
    dependency and a second failure surface without a current size requirement.
- Decision: Use UTF-8 JSON and no compression. Checkpoint envelope version 1
  contains `format_version`, the validated effective `Config`, absolute tick,
  complete exported `RngState`, and the ordered `WorldClimateState` used by the
  canonical state DTO. Keep the state schema explicit and versioned; unknown,
  missing, malformed, truncated, and unsupported-version data fail closed.
  Deserialize into a DTO first, validate dimensions/vector lengths, resource
  and organism invariants, allocator ordering, lifecycle accounting, and
  matching current tick, then construct `Simulation` and rebuild the derived
  spatial index. Do not partially initialize from the configured population.
- CLI decision: `run` accepts exactly one of `--config FILE` or `--load FILE`;
  `--seed` is valid only with config. `--save FILE` writes the final state only
  after successful simulation. A loaded invocation reports the checkpoint's
  absolute tick as `tick_start`, and its cumulative counters remain cumulative
  from tick zero. Reject invalid input before result output is created.
- Consequences: Canonical state and checkpoint world data stay structurally
  aligned, though checkpoint envelope versioning is independent from the hash
  DTO version. JSON size scales with organism and death history. No OS packages
  or new Cargo crates are required.
- Implementation: Checkpoint restore validates climate against geometry and
  clock/weather, vector lengths and resource bounds, organism and species
  invariants, allocator ordering, lifecycle counters and death history, then
  reconstructs the derived spatial index. CLI integration tests compare
  resumed and uninterrupted results at split ticks 0, 5, and 13 and reject
  absent, damaged, truncated, wrong-version, and clock-inconsistent files.
- Verification: Round-trip a tick-zero checkpoint and at least two split
  points, compare resumed and uninterrupted `state_hash`, `final`, and
  `totals`; exercise absent, damaged/truncated, and wrong-version inputs and
  assert status 2 plus no result file. Run focused CLI tests, full `cargo test`,
  formatting and whitespace checks.

# ADR-025: UI scenarios, editable configuration, and charts

## Status

Accepted and implemented for TASK-025.

## Context

TASK-025 extends the local browser UI delivered by TASK-024. `Config` already
contains validated nested climate, ecology, and genetics settings; it exposes
the `balanced`, `lush`, and `harsh` presets and JSON round trips. `POST
/api/reset` already validates a `Config` before replacing the shared
simulation. TASK-020 exposes a read-only `MetricsSample::capture` with
population, cumulative births/deaths, living species and mean traits, but no UI
chart history. UI checkpoints preserve simulation state and are separate from
experiment configuration files.

## Decisions

- Keep the Rust `Config` as the canonical experiment schema. Add `GET
  /api/presets` with ordered preset configurations; the existing reset endpoint
  remains authoritative for simulation creation. No new simulation feature or
  checkpoint format is introduced.
- Render editable controls for seed, width, height, all three initial
  populations, and all configurable fields under `climate`, `ecology`, and
  `genetics` (nine further parameters). The selected preset supplies a baseline;
  edits update that complete configuration. Preset selection replaces the
  current draft, and subsequent edits are preserved on reset/import/export.
- Add display-free browser modules `ui/config-model.js` and
  `ui/chart-data.js`. The config module owns preset application, JSON import /
  export, type/range validation and field-keyed errors. Import accepts only the
  same complete JSON shape as the Rust configuration, with optional groups and
  omitted nested fields receiving the established Rust defaults. Export writes
  the normalized full configuration. Before reset, every field is validated;
  errors are shown adjacent to controls and no request is sent while any error
  remains. Rust validation remains the final authority.
- Use hand-written SVG charts with no runtime package or network access. A
  pure chart-data module converts ordered metric samples and current trait
  values into labeled series, axes, legends and selectable-trait distribution
  bins. Render population, cumulative births/deaths, living species and mean
  speed over time, plus a selectable trait distribution for a selected kind.
  Each chart has explicit tick/value axes and a legend.
- Extend `AppState` with a bounded history of `MetricsSample` observations.
  Seed it at world creation/reset/load and append after each explicit advance
  request, at that request's final absolute tick. Keep at most 1,000 samples,
  retaining the newest data. This gives charts a stable display-free API and
  avoids a metrics scan on every internal engine tick at 20 ticks/s. Chart
  observation is read-only and does not affect RNG, simulation hashes or
  checkpoints; checkpoint load starts a new UI chart-history segment at the
  restored absolute tick. A `/api/charts` response returns history and current
  living trait values, with an optional validated kind/trait selection.
- Keep run/pause/step/reset and map/inspector from TASK-024. Add a navigation
  affordance for chart view while preserving the map as the main view. The
  screenshot automation writes `main.png` from the real main page and a second
  `charts.png` from the real chart page after at least 100 ticks.

## Alternatives and tradeoffs

- Use a chart package: it offers polished charts quickly but adds installation,
  packaging and offline supply concerns. Native SVG provides labeled, crisp,
  real-interface output and needs no dependency.
- Capture metrics on every engine tick: this gives dense data but repeatedly
  scans organisms and accumulated death history, especially at speed 20. One
  sample after each explicit advance request aligns with visible update cadence;
  the bounded history makes chart rendering predictable.
- Add configurable simulation fields beyond the minimum five: exposing all
  current settings makes presets and experiments coherent, at the cost of a
  longer form. Group them by the existing nested schema.
- Keep experiment import/export distinct from save/load checkpoint: a config
  describes a new experiment while a checkpoint contains a complete running
  world, RNG and history. The UI labels and handlers remain separate.

## Verification plan

- Add Node tests for all preset values, preset-then-edit behavior, normalized
  JSON export/import equality, valid boundary values, malformed/missing/wrong
  types and field-specific range errors. Assert invalid configuration does not
  invoke the reset/start callback.
- Add Node tests for chart transforms using fixed metric samples: population,
  births/deaths, living species, mean trait, selectable trait distribution,
  empty populations and ordered tick/value axes plus legends.
- Add Rust tests for ordered preset serialization, initial/reset/load chart
  history, sample append after advance, the 1,000-sample bound, selected
  kind/trait validation and current trait values. Keep metrics out of canonical
  simulation state and assert state-hash stability around observation.
- Verify config import/export round trip through the pure module and the real
  browser UI; verify invalid field feedback blocks `/api/reset`; verify each
  chart receives data while running and trait/kind selection changes the
  distribution. Preserve TASK-024 checkpoint/reset controls and TASK-023
  smoke behavior.
- Run `node --test tests-js/*.test.js`, focused Rust UI tests, `cargo test`,
  `cargo fmt --all -- --check`, `./setup.sh`, `xvfb-run -a ./evosim ui
  --smoke-test`, screenshot mode, and `git diff --check`. Validate both PNG
  dimensions and handoff JSON. No system packages, npm packages or Cargo
  crates are planned.

## Risks

- JavaScript validation must match Rust's integer types, ranges, defaults and
  strict unknown-key policy closely enough that bad drafts get useful inline
  errors before the server rejects them. Rust validation remains authoritative.
- Sampling only after each advance request means chart resolution follows
  browser cadence, and the 1,000 point cap drops older history on long sessions.
- Chart rendering must escape or construct SVG safely from numeric data and
  labels; fixed field labels should be used instead of inserting imported text
  as markup.
- The screenshot path must capture both views from the bundled page and finish
  within the existing 120-second contract limit.


## Implementation notes

Implemented in TASK-025 IMPLEMENT cycle 1. Static pure modules are bundled
through explicit local routes. The form exposes all sixteen configuration
leaves, imports and exports normalized complete JSON, and reports field-level
validation errors before invoking reset. The chart endpoint returns observer
history and living trait samples; SVG renders population, cumulative births and
deaths, living species, mean speed, and current trait distribution. The UI
screenshot mode captures the main world and a second chart view from Chromium.
Display-free test command: `node --test tests-js/*.test.js`. No dependency was
added. Detailed run evidence is in the implementation handoff.

# ADR-015: Carnivore hunting

- Status: Implemented in TASK-015 IMPLEMENT cycle 1.
- Context: TASK-013 already makes carnivores pursue the nearest visible herbivore,
  and TASK-014 provides herbivore feeding in the existing `Feeding` scheduler
  slot. Hunting must use the same toroidal geometry, deterministic actor order,
  deferred death queue, and simulation-owned random stream.
- Alternatives considered:
  - Resolve attacks during movement: this couples combat to path traversal and
    risks multiple attack opportunities per tick. A separate Feeding action
    gives one explicit attempt after all animals move.
  - Let every carnivore reserve its target: reservation avoids contention but
    needs additional per-tick state and can let a failed hunter block later
    hunters. Stable sequential resolution naturally makes the first successful
    hunter remove a prey from later candidates.
  - Use fixed attack odds: simple, but it discards the inherited strength,
    aggression, speed and risk traits that distinguish the two animals.
- Decision:
  - Preserve the current movement target rule: nearest visible living
    herbivore by toroidal Chebyshev distance, then ascending organism ID.
  - After herbivore grazing in `Feeding`, process carnivore IDs in ascending
    order. Each carnivore selects the nearest living, non-pending-death
    herbivore at distance 0 or 1 (including diagonals). A carnivore may make at
    most one attack attempt per tick; no adjacent prey means it pursues via the
    existing movement behavior but does not attack.
  - Compute attack chance in basis points as
    `clamp(4000 + floor(attacker.strength*3000/65535) +
    floor(attacker.aggression*2500/65535) -
    floor(prey.speed*2500/65535) -
    floor(prey.risk_tolerance*1500/65535), 1000, 9000)`. Draw
    `simulation_rng.next_u32() % 10000`; the attack succeeds when the draw is
    less than the chance. Both animals' traits affect the outcome, and the
    seeded RNG makes it reproducible.
  - On success, request `DeathCause::Predation` exactly once. Grant energy equal
    to `min(prey.energy, MAX_ENERGY - carnivore.energy)`; prey energy is the
    only energy source and no transfer can exceed it. Filter pending-death prey
    before target selection, so neither a prior kill nor another cause of death
    can be consumed again.
  - Charge every living carnivore 500 energy per tick after its attack/no-prey
    decision. Thus misses and ticks without adjacent prey cost energy too. If
    remaining energy is zero, queue `DeathCause::Starvation`. Existing
    Mortality resolves deaths after Reproduction; first queued cause wins.
  - With multiple carnivores targeting one prey, ascending IDs resolve first.
    A miss leaves the prey available to later carnivores; a successful kill
    queues its death and removes it from later candidates in the same tick.
    There is no target reservation and no global population rule.
- Consequences: Attack behavior is local and toroidal; movement, combat and
  lifecycle changes use existing World APIs. Trait scaling and 500 energy are
  simplified model parameters. Modulo sampling has a negligible distribution
  bias, accepted for the bounded 10,000-outcome roll. No configuration, genome,
  checkpoint schema, crate, or system package changes are needed.
- Verification strategy: Add pure formula boundary checks and deterministic
  integration coverage for visible pursuit, same/adjacent attacks and exclusion
  beyond adjacency; across a fixed large set of attack draws prove both kills
  and escapes. Verify the attack depends on both actors' traits, a successful
  prey has exactly one Predation record, later attackers cannot eat it again,
  energy gain never exceeds prey energy or carnivore capacity, misses and
  no-prey turns pay the same cost, starvation occurs at zero, and equal seeds
  reproduce the same attack trace. Run focused hunting tests, full `cargo
  test`, formatter and whitespace checks. No system dependencies are planned.

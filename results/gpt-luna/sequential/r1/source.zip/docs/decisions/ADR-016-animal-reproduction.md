# ADR-016: Sexual reproduction for animals

- Status: Implemented for TASK-016 cycle 1; review pending.
- Context: Plants reproduce asexually in the existing `Reproduction` scheduler
  slot. TASK-016 adds two-parent reproduction for herbivores and carnivores,
  using TASK-009's crossed/mutated genome constructor and TASK-008's deferred
  birth/lineage lifecycle. Reproduction must not use global population counts.
- Alternatives considered:
  - Randomly search the whole world for mates: can pair distant animals and
    requires an unbounded or separately capped search.
  - Pair animals in the same or adjacent cells: uses the existing toroidal
    spatial index, is local, and naturally supports wraparound.
  - Let every eligible parent independently queue offspring: risks one animal
    being charged multiple times or paired inconsistently in one tick.
  - Resolve mutual pairs in stable ID order and mark both parents used for the
    tick: adds a small per-tick set but gives explicit one-mating-per-parent
    semantics.
- Decision:
  - Retain plant reproduction, then process animal actors in ascending ID order
    in the existing `Reproduction` phase. A candidate mate must be a different
    living animal of the same kind within inclusive toroidal Chebyshev distance
    1 (same, cardinal, or diagonal cell), not pending death, and not already
    used as a parent this tick. Select the nearest compatible candidate, then
    lower ID. Candidate genomes are compatible when their ADR-004 genetic
    distance (sum across eight loci) is at most 65,536, equivalent to mean
    normalized locus distance at most 8,192. No species records are added.
  - Require each parent to be at least 10 ticks old, to have energy at least
    60,000, to have zero reproduction cooldown, and not to be due for lifespan
    death at the end of this tick. Before mating, each parent's independent
    seeded fertility trial succeeds when `next_u32() % 10,000` is below
    `500 + floor(fertility * 4,500 / 65,535)` basis points (5%..=50%). Draw
    trials in parent ID order only after a compatible pair satisfies all
    non-random eligibility checks. A failed trial has no cost and consumes no
    cooldown.
  - Successful mating immediately queues one child of the parents' kind at a
    seeded random cell among the two parent cells (50/50); the cell can contain
    any number of animals. Use `Simulation::child_genome_two` for per-locus
    crossover and configured mutation. Record both IDs in ascending order and
    `max(parent.generation) + 1` with checked arithmetic. Each parent pays
    exactly 20,000 energy, and receives a 20-tick reproduction cooldown only
    after the birth is successfully queued. Births remain deferred until
    Finalize, so offspring cannot act in their birth tick. Fertility affects
    successful-mating likelihood, not litter size.
  - Add an animal cooldown field to `Organism`, initialized to zero. A cooldown
    positive at phase entry blocks the entire current selection pass, then
    decrements once after selection; a newly assigned cooldown does not
    decrement on its birth pass. This preserves 20 complete blocked passes
    after a successful mating. Keep cooldown, age and genome data in canonical
    organism state for future checkpoint work.
- Consequences: Stable ID order, indexed toroidal neighbor queries, and the
  simulation RNG make outcomes reproducible. Reproduction is local and subject
  to all animals regardless of population size. The energy threshold, costs,
  fertility probabilities, compatibility threshold, maturity and cooldown are
  simplified model parameters. A pair consumes two fertility draws and one
  location draw only after non-random eligibility; exact draw order must be
  locked with tests. Animals have no separate reproduction config keys.
- Verification: Add focused tests for helper formulas and genetic compatibility;
  single-animal non-reproduction; distinct same-kind parent requirement; mixed
  kinds, nonlocal, incompatible, immature, low-energy, pending-death and
  cooldown exclusion; toroidal adjacent pairing; deterministic mate choice and
  seeded fertility; two-parent genome provenance and mutation; exact lineage,
  generation, parental costs and cooldown; maximum one mating per parent;
  newborn delay; and plant reproduction regression. Run focused animal
  reproduction tests, the complete `cargo test` suite, formatter and whitespace
  checks. No new crate or system package is planned.
- Implementation note: `Organism::reproduction_cooldown` starts at zero. In
  each Reproduction pass, animal actors are snapshotted by ID. Cooldowns active
  at phase entry block the full pass and decrease once after mate selection;
  newly assigned 20-tick cooldowns are not decremented on the birth tick. This
  preserves 20 complete blocked passes. `animal::nearest_mate` applies
  eligibility, compatibility, pending-death and unavailable-parent filters,
  then selects by wrapped distance and ID. A successful mating queues through
  `World::queue_birth`; only then are both parents charged and set to 20
  cooldown ticks. Both fertility rolls are drawn, in parent ID order, before
  deciding whether either failed. Executed verification is in the TASK-016
  implementation handoff.

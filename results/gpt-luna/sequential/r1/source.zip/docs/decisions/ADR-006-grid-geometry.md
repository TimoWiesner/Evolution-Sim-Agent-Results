# ADR-006: Grid coordinates and toroidal geometry

- Status: Accepted for TASK-004 planning.
- Context: The simulation world is a rectangular finite grid joined at both
  pairs of opposite edges. Geometry must support wrapped coordinates,
  shortest directions and distances, and unique radius neighborhoods on
  rectangular and degenerate dimensions. TASK-010 will build spatial search on
  these primitives.
- Alternatives considered for distance:
  - Manhattan distance is useful for axis-aligned movement budgets, but makes
    the cells within a radius diamond-shaped while the planned spatial index
    enumerates square cell offsets.
  - Euclidean distance is familiar geometrically, but requires squared or
    floating point comparisons and yields a circular neighborhood whose
    raster boundary needs an additional convention.
  - Chebyshev distance makes the radius neighborhood a square in cell steps,
    matches the per-cell square-offset query plan in ADR-003, and uses exact
    integer arithmetic.
- Decision: Use toroidal Chebyshev distance everywhere in grid geometry.
  Compute the shortest signed displacement independently on x and y, then
  define distance as the maximum absolute component. The direction vector points
  from the source cell to the destination cell. When a dimension is even and
  cells are exactly half a world apart, choose the negative displacement as a
  stable tie-break; that torus direction is inherently ambiguous.
- Types: Store valid cell positions as `Cell { x: u32, y: u32 }` and dimensions
  in `Grid { width: u32, height: u32 }`; `Grid` construction rejects zero
  dimensions. Accept arbitrary signed `i64` coordinate inputs for wrapping and
  use Euclidean remainder before converting to a `Cell`. Return shortest
  direction components as signed `i32`, which safely covers half of any `u32`
  dimension. Distance and neighborhood radius are `u32` cell-step values.
- Coordinate convention: x is the column and increases rightward; y is the row
  and increases downward. Cell ordering used for returned lists is row-major:
  `(y, x)`.
- Neighborhoods: A cell is within radius `r` when its toroidal Chebyshev
  distance from the center is at most `r`. Return each valid cell once in
  row-major order. If `r` covers the maximum possible toroidal distance, return
  all cells directly. Otherwise enumerate wrapped offsets, deduplicate aliases
  (needed when only one axis is covered or a dimension is 1), then sort
  row-major. This supports radii larger than either dimension without integer
  range overflow or duplicate output.
- Consequences: Geometry remains deterministic, integer-only, and directly
  reusable by the per-cell spatial index. The choice models a radius as a
  square neighborhood rather than a circle or diamond; callers must use this
  same metric for filtering and queries. `u32` dimensions and `i64` coordinate
  inputs cover the configuration limits and ordinary signed coordinate APIs.
- Verification strategy: Unit and integration tests cover all four edge
  crossings, corners, negative and multiply wrapped coordinates, shortest
  direction and distance on both axes, even-dimension direction ties,
  non-square worlds, radii that alias one or both dimensions, row-major unique
  output, 1x1 and 1xN worlds, and rejection of zero dimensions. Include a
  deterministic property/oracle test comparing returned neighborhoods with a
  brute-force scan of all cells for varied small dimensions and radii.

# ADR-024: UI run controls, organism inspector, and checkpoints

## Status

Accepted and implemented in TASK-024 IMPLEMENT cycle 1.

## Context

TASK-023 provides a loopback Rust HTTP server, a browser canvas, and a shared
`Simulation`, but the server currently advances continuously and its snapshot
contains only organism kind and position. TASK-024 needs direct run control,
rich selection, live/dead inspection, and checkpoint save/load without a
separate engine or display-dependent control tests. The binding checkpoint
format and validation already live in ADR-022 and `src/cli.rs`.

## Decisions

- Keep controls in the browser and state transitions in a small pure controller
  module that can be exercised with Node without Chromium. The server remains
  the authority for simulation state; all requested ticks go through the
  existing `Simulation::step_one_tick`.
- Provide Run, Pause, Step, Reset, and speed choices of 1, 5, and 20 ticks per
  second. Pause is the initial state. A browser timer schedules whole-tick
  `/api/advance` requests according to the selected speed; the server no longer
  advances implicitly. Step always requests exactly one tick and does not
  change the run/pause state. Reset constructs a new simulation from the UI's
  current effective config and seed. Clamp speed to the explicit positive
  choices; there is no negative or zero speed setting (pause is separate).
- Put tick and plant/herbivore/carnivore population totals in a persistent
  header/status strip fed by every snapshot. Extend map entities with stable ID
  so canvas hit-testing can select an organism without changing pan/zoom.
- Add a detail query for one selected ID, returning ID, kind, species ID/name,
  age, energy, health, all derived traits, genome loci, parent IDs, and live or
  death status/cause/tick. Re-query after each snapshot while selected; retain
  selection when its organism is missing from the living set and display its
  death record rather than clearing the inspector. Treat an unknown ID as an
  explicit unavailable state.
- Add checkpoint download/upload endpoints backed by the same version-1 JSON
  envelope and validation used by CLI checkpoints: effective config, tick, RNG
  state, and complete `WorldClimateState`. Factor the DTO/encode/decode path so
  UI and CLI cannot silently diverge. Browser save downloads the JSON file;
  load uses a file picker and replaces the server simulation only after full
  validation. The loaded config becomes the reset baseline. Bound and fully
  read request bodies using Content-Length, reject malformed or oversized
  checkpoint data without replacing the current world, and preserve the
  browser/server's no-network runtime behavior.
- Keep genome display explicit and compact: show all eight ordered integer
  loci in a labeled monospace block; show traits as labeled values rather than
  introducing a separate chart. Add selected-marker highlighting and a
  distinct death status in the inspector.
- Keep one HTTP request handler authoritative for mutations. Run schedules a
  batch of the selected number of whole ticks once per second; the client never
  starts another advance while its current request is in flight. Invalid
  checkpoint data is decoded and restored before the shared state lock is taken.
- Bound request bodies to 32 MiB and read the declared Content-Length fully.
- Preserve `--smoke-test` and `--screenshots` automation. Keep `/api/advance` for
  deterministic automation and have its explicit request return the post-step
  snapshot. Extend screenshot automation optionally with a selected-organism
  view only if it can be done through the real page without destabilizing the
  required `main.png`.

## Alternatives and tradeoffs

- Server-driven continuous stepping is simple, but pause/single-step semantics
  become timing-dependent and reset/load race ongoing work. Browser-scheduled
  explicit tick requests make each action precise and permit display-free tests
  of the control state machine; browser timer throttling affects cadence, not
  the number of ticks per request.
- A native HTML range speed slider could create arbitrary rates and confusing
  zero/negative edge cases. Three named positive rates plus a separate Pause
  state satisfy control needs with clear semantics.
- Including all genomes and life history in every world snapshot simplifies
  rendering and inspector updates but grows transfer cost. Keep map snapshots
  to stable IDs and population counts, and fetch full data only for the selected
  ID. If death history is large, resolve selected dead organisms by ID from the
  existing ordered death history.
- A text genome dump is low-cost and makes inheritance loci inspectable; custom
  charts add visual interpretation without a task requirement.
- Duplicating checkpoint structs in `ui.rs` would be expedient but risks UI/CLI
  format drift. Share the versioned codec/DTO and existing restore validation.

## Verification plan

- Add display-free unit tests for controller transitions (initial pause, run,
  pause, step exactly one tick, allowed speed values/clamping, reset to
  reproducible initial hash, and no implicit advancement while paused), plus
  selected-organism lookup for live and dead cases.
- Add Rust tests for rich organism detail serialization, counts/tick, detail
  status after death, checkpoint round-trip and invalid upload leaving the
  existing simulation unchanged. Verify reset gives the initial canonical
  state for the same effective config/seed.
- Add Node tests for any browser-only scheduling, selection persistence, and
  stable selected ID behavior without a display; avoid adding npm packages.
- Run focused Rust tests, `cargo test`, `cargo fmt --all -- --check`,
  `git diff --check`, `./setup.sh`, the contract smoke test and screenshot test.
  In a real Chromium flow verify pause, one step, run/pause, reset, speed, map
  selection, inspector details/death follow, and checkpoint save/load.
- No OS packages or Rust/npm dependencies are planned. If Chromium is absent in
  a future fresh environment, use the documented bundled/container Chromium
  expectation; record any exact system installation command if needed.

## Risks

- CLI checkpoint DTO visibility and serialization helpers are private today;
  extracting a shared codec must preserve existing error semantics and split-run
  determinism.
- HTTP request parsing is currently one bounded 8 KiB read and cannot accept a
  complete checkpoint reliably; body framing and limits need careful handling.
- Browser polling can overlap tick requests unless requests are serialized;
  schedule the next advance only after the prior response completes.
- Large death histories make checkpoint and selected-death lookup increasingly
  costly. Selected death lookup should stop at a matching ID; checkpoint size is
  already the documented ADR-022 tradeoff.
- Reset and checkpoint load replace all simulation state; client selection and
  map state must be reconciled after the returned snapshot.

## Implementation evidence

Cycle 1 added four Node controller tests and Rust tests for snapshot IDs/counts,
live-to-dead detail, and checkpoint codec round-trip/rejection. The full Rust
suite passed (81 passed, 1 ignored), and the HTTP integration probe verified
one-tick advance, detail, save/load, invalid-load atomicity, and reset. Chromium
smoke and screenshot modes passed; the screenshot was 1440×900. The page was
rendered in Chromium, but individual button and map-selection clicks were not
automated end-to-end. See
`tasks/TASK-024/handoffs/implement-cycle1.json` for exact commands and results.

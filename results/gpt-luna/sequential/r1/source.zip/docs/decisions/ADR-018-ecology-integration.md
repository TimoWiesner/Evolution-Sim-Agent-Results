# ADR-018: Ecology integration and extinction

## Status

Implemented for TASK-018. No global population-sensitive rules or ecology
parameter changes were needed.

## Context

TASK-018 connects climate, plant resources/growth/reproduction, animal
movement/feeding/hunting/reproduction, lifecycle, and species systems. It must
permit extinction without population-count based protection or replenishment.
The current engine already exposes an ordered scheduler and cumulative
per-kind lifecycle counters.

## Decisions

1. Preserve the existing tick order: advance tick and climate/weather;
   replenish soil water; grow and check plants; move animals; let herbivores
   graze; let carnivores hunt; reproduce plants, then animals; age existing
   organisms; resolve deaths; commit queued births; reconcile species
   extinctions. Newborns cannot act or die in their birth tick, and species
   extinction is checked after births commit.
2. Keep population changes local and organism-driven. Plants use bounded
   precipitation-fed soil water, climate suitability, finite energy capacity,
   and local establishment capacity. Herbivores rely on local plants and pay
   feeding/climate maintenance. Carnivores rely on local herbivore encounters,
   hunting success, and a per-tick cost. No rule may inspect global population
   counts to protect, create, or preferentially reproduce organisms.
3. Begin with fixed-key configuration defaults. Change only existing ecology
   defaults or documented fixed behavioral constants if deterministic tests
   show plant-only persistence or several-hundred-tick herbivore
   survival/reproduction fails. Any change must retain energy/resource bounds,
   have a local ecological rationale, and be rechecked for no-plant and
   no-herbivore extinction. Add no configuration keys in this task.
4. Add deterministic Rust tests for the fixed-key config at 1,000 ticks;
   lifecycle accounting after every tick; no-plants, no-herbivores, and
   plants-only scenarios; plant reproduction alone; and herbivore
   survival/reproduction with abundant plants for several hundred ticks. Add
   an ignored, explicitly invoked multi-seed test or script for five seeds x
   10,000 ticks. It reports each kind's first zero-population tick or
   `survived`, and actual outcomes plus runtime/hardware are recorded in the
   implementation handoff and STATE. It must not assert carnivore survival.

## Alternatives considered

- Add anti-extinction protection or seed organisms after collapse: rejected by
  `docs/PROJECT.md` and this task's extinction goal.
- Tune solely from the five-seed long run: rejected because short deterministic
  scenarios diagnose failures more directly; the long run is observational.
- Commit births before mortality: rejected because it changes established
  deferred lifecycle semantics and lets newborns affect their birth tick.

## Consequences and verification

`Simulation::step_one_tick` retains the approved order and
`TickReport::phases` reports Climate, PlantGrowth, AnimalMovement, Feeding,
Reproduction, Mortality, Finalize. Feeding does herbivore grazing before
carnivore hunting; reproduction does plants before animals; Finalize commits
births before species extinction reconciliation. Tests use lifecycle counters
and public counts after every tick. Plants-only and compatible, well-fed
herbivore scenarios establish local reproduction and persistence; no-plant
and no-herbivore scenarios establish permanent extinction. No global count
is consulted by simulation behavior.

The explicit command
`cargo test --release --test ecology report_five_seeds_10000_ticks -- --ignored --nocapture`
passed in 184.40 seconds on the implementation container (Ubuntu 24.04,
container CPU; `rustc 1.100.0`, release profile). For seeds 1 through 5,
plants survived 10,000 ticks; herbivores first reached zero at ticks 46, 46,
39, 32, and 40; carnivores first reached zero at ticks 199, 170, 191, 180,
and 168 respectively. The report is observational and does not promise
coexistence. No external dependencies or system packages were added.

### Cycle 2 default-settings regression

The TASK-018 REVIEW cycle 1 found that the original abundant-herbivore test
overrode plant growth and mutation. IMPLEMENT cycle 2 replaces that fixture
with fixed-key JSON on the default 64x48 world and 400 plants. It asserts that
climate, ecology, and genetics equal the `balanced` preset defaults; only the
seed and zero initial animal counts differ from the fixed-key configuration.
Two compatible high-fertility herbivore founders are queued at one cell to
isolate mating compatibility. The simulation then runs 300 ticks under normal
growth, mutation, climate, movement, feeding, reproduction, and mortality.
Plants remained available, herbivores survived and reproduced, and lifecycle
accounting was checked each tick. No behavior or default parameter changes
were necessary.

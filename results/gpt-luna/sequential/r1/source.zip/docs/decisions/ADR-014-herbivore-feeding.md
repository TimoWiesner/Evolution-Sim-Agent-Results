# ADR-014: Herbivore feeding and gene-driven foraging

- Status: Implemented in TASK-014 IMPLEMENT cycle 1.
- Context: Herbivores already sense plants and move toward the nearest visible
  edible organism (ADR-013), but do not feed or lose energy. TASK-014 requires
  local-only grazing, bounded energy transfer, maintenance mortality, a climate
  consequence, and demonstrably different behavior from different genomes.
- Alternatives considered:
  - Always choose the nearest plant: simple and deterministic, but ignores the
    existing heritable foraging tendency.
  - Always choose the plant with the most energy: makes grazing gene-blind and
    can encourage long pursuit of a rich but remote plant.
  - Blend plant energy and proximity with `foraging_bias`: uses an existing
    inherited locus, supports a continuum of strategies, and has deterministic
    integer scoring at the cost of a small amount of scoring logic.
  - Add a new gene or configuration setting: allows direct tuning, but expands
    the fixed genome/config/checkpoint schema unnecessarily for this task.
- Decision: Keep the existing genome schema. For each candidate plant with
  positive energy in the herbivore's inclusive speed-derived toroidal vision
  radius, compute `food = floor(plant_energy * 65535 / MAX_ENERGY)` and
  `near = floor((vision - distance) * 65535 / vision)`, where distance is
  toroidal Chebyshev distance and vision is in 1..=8. Score as
  `foraging_bias * food + (65535 - foraging_bias) * near`; maximize score and
  break ties by ascending plant ID. Thus bias zero chooses nearest, maximum
  bias chooses most-energy food, and intermediate values interpolate. Use this
  decision for herbivore target selection in AnimalMovement and for choosing
  among plants that are locally edible in Feeding. Feeding candidates must be
  at distance 0 or 1; no energy transfers from farther cells even when visible.
- Feeding and energy accounting: Each herbivore takes at most one bite of
  5,000 energy per tick. Actual transfer is the minimum of 5,000, plant energy,
  and herbivore remaining capacity (`MAX_ENERGY - current_energy`). Subtract
  exactly the transfer from the plant and add exactly the same amount to the
  herbivore. A plant reaching zero queues `DeathCause::Starvation`; zero-energy
  and already-pending-death plants are not eligible for another transfer in
  that tick. Herbivores pay maintenance after the bite: 100 base energy plus
  100 for each started 1 C outside the -5 C to 35 C comfort interval, with
  the climate surcharge capped at 500. Use current climate at the herbivore's
  cell. Queue starvation if energy is zero after maintenance. All costs and
  transfers use bounded integer energy; energy has no source other than the
  plant transfer in this task.
- Tick behavior: Keep the scheduler phase order. Process herbivore IDs in
  ascending order; movement happens before Feeding, and later actors observe
  energy transferred by earlier actors. Mortality remains the existing
  deferred queue at the Mortality boundary. Carnivores receive no feeding
  behavior in this task. No global counts, replenishment or configuration
  settings are added.
- Consequences: `foraging_bias` now affects actual approach and meal selection,
  and transfer is bounded by both source and consumer energy. Local feeding
  uses the existing spatial index and toroidal geometry. Sequential feeding
  allows earlier herbivores to deplete a plant before later ones; stable actor
  order keeps this deterministic. Bite size, energy units and the comfort band
  are simplified ecology parameters rather than claims of physical units.
- Verification strategy: Pure helper tests cover endpoint/intermediate gene
  scores, deterministic ID ties, bite and maintenance boundaries. Integration
  tests cover indexed vision, actual target movement, eating at same/adjacent
  toroidal cells but not farther cells, source/consumer energy conservation,
  bite and capacity limits, plant starvation removal, herbivore maintenance
  starvation and cold/heat cost increases, plus two different foraging genomes
  taking different actions in the same setup. Run focused tests and `cargo
  test`, then formatting and whitespace checks. No system package or new crate
  is required.

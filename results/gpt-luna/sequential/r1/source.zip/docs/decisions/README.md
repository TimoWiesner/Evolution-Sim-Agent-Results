# ADRs

- ADR-018: Ecology integration and extinction (`ADR-018-ecology-integration.md`)
- ADR-022: Savegames and checkpoints (`ADR-022-savegames.md`)
Create numbered ADRs for language and runtime, UI technology, spatial indexing and genome design in TASK-001. State status, context, considered alternatives, decision, consequences and verification strategy.

TASK-014's proposed herbivore foraging, bounded grazing transfer and climate-
sensitive maintenance decision is recorded in ADR-014.

TASK-015's proposed trait-based carnivore attack, sequential prey contention,
bounded energy transfer and hunting cost decision is recorded in ADR-015.

# ADR-027: Evidence-led ecosystem balance

- Status: Implemented in TASK-027 IMPLEMENT cycle 1.
- Context: The fixed-key 64x48, 400/120/20, 10,000-tick baseline was run on
  seeds 1–10 before changing ecology code. Every seed first lost herbivores
  (ticks 32–96); their 120 deaths were all predation and they had no births.
  Carnivores later starved; plants remained abundant and near the 12,288-cell
  occupancy cap. Details and population curves are in `docs/BALANCE.md`.
- Alternatives considered:
  - Increase mate discovery radius: could address encounter limitation, but the
    recorded first extinction cause was 120 predation deaths with no births,
    and the predator population was still intact during most of the herbivore
    collapse. It does not address the measured dominant cause directly.
  - Reduce hunting odds globally: would change the inherited-trait attack
    formula and reduce every attempt, even when prey is locally plentiful.
  - Add an attack handling interval after successful predation: adds a local,
    per-organism constraint to consecutive successful kills and leaves missed
    attacks and prey-free behavior unchanged. Selected and measured.
  - Use prey counts to protect survivors, add births, or impose a species
    threshold: rejected because `docs/PROJECT.md` forbids population-dependent
    anti-extinction rules.
- Decision: After a carnivore successfully kills prey, set its serialized
  `hunting_cooldown` to 20. For the next 20 Feeding passes, it cannot attack;
  cooldown decrements once per pass. Handling does not exempt it from the
  existing 500-energy maintenance cost. After the counter reaches zero, ordinary
  toroidal prey selection, inherited-trait success odds, energy transfer and
  death handling resume. Misses and passes without adjacent prey do not start a
  cooldown. No population or species count is consulted.
- Consequences: This mechanism increases time between kills without weakening
  the trait-based hunting formula. The state is part of organism serialization,
  hashes and checkpoints; `serde(default)` treats older checkpoint organism
  records as having no active handling interval. Successful kill energy still
  comes only from the prey. It adds no dependency, system package or config key.
  A fixed 20-tick handling duration is a simplified digestive assumption.
- Measurement: With this mechanism on tuning seeds 1–10 for 10,000 ticks,
  herbivores still went extinct in every run, but the interval-1 first-zero
  ticks ranged 174–229 (mean 195.3), versus baseline 32–96 (mean 52.7). The
  outcome is a material delay, not coexistence. Held-out seeds 11–15 and the
  repeat performance benchmark are recorded in `docs/BALANCE.md` and the
  TASK-027 implementation handoff.
- Verification: Direct tests assert cooldown starts after a successful kill,
  prevents attacks while active, decrements once per pass, and still charges
  maintenance. Existing attack chance, toroidal targeting, prey-energy bounds,
  first-cause and lifecycle behavior remain covered. Full test and benchmark
  evidence is recorded in the implementation handoff.

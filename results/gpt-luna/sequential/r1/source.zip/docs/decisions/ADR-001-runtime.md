# ADR-001: Simulation language and runtime

- Status: Accepted for implementation planning (TASK-001).
- Context: The same deterministic engine must power headless runs and UI, handle thousands of entities, and later ship in a self-contained `dist/` folder.
- Alternatives considered:
  - Python 3: excellent iteration and testing; adequate for small worlds, but per-entity work at thousands of ticks risks the performance target and packaging a standalone runtime requires bundling a large interpreter/dependencies.
  - TypeScript/Node: convenient shared UI/server language and strong tooling; standalone distribution still needs a bundled runtime, and engine throughput requires careful optimization.
  - Rust: native performance, strong type checks and mature testing/serialization ecosystem; takes more initial implementation effort, but produces a single native executable suitable for a self-contained distribution.
- Decision: Rust stable for the simulation library and CLI. Prefer a small dependency set and statically linked or otherwise self-contained Linux binary as practical; bundle required UI assets alongside it.
- Consequences: Engine correctness can be tested independently with Cargo unit/integration tests and deterministic seeded scenarios. Compile/build time is higher than scripting alternatives; setup/build scripts must install or use Rust as allowed by the benchmark environment and stage all runtime assets. Release builds should be profiled against disclosed workloads before optimization claims.
- Verification strategy: `cargo test`, contract CLI integration tests, deterministic replay/checkpoint tests, and timed 2,000-entity workloads; build `dist/` and verify it from a directory without project sources.

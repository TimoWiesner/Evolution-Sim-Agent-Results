# ADR-013: Animal sensing and cell movement

- Status: Accepted and implemented in TASK-013 IMPLEMENT cycle 1.
- Context: Herbivores and carnivores need heritable, deterministic sensing and
  cell-by-cell motion on the toroidal grid. TASK-010 already provides
  `World::organisms_within` and checked, index-maintaining `Simulation::move_organism`.
- Alternatives considered:
  - Add a separate vision locus: directly tunable, but changes the fixed genome
    schema and mutation/checkpoint format for one behavior task.
  - Derive vision from speed: reuses an existing heritable trait and keeps
    genome and checkpoint formats stable, though locomotion and perception
    become correlated.
  - Block entry into occupied cells: models collision/territory, but creates
    ordering conflicts in simultaneous movement and conflicts with initial
    placement and colocated populations.
  - Allow stacking: simple and order-independent for occupancy, with crowding
    left to later ecology rules.
- Decision: Keep the existing eight-locus genome. Map `speed` (0..=65535) to
  `movement_range = 1 + floor(speed * 3 / 65535)` cells per tick (1..=4), and
  `vision_range = 1 + floor(speed * 7 / 65535)` cells (1..=8). Use inclusive
  toroidal Chebyshev radius and `World::organisms_within`; perception is
  read-only and includes all kinds, including the observer itself when in range.
  A target is selected from visible non-self organisms edible by that animal
  (plants for herbivores, herbivores for carnivores), minimizing toroidal
  distance and then organism ID. Movement follows `Grid::direction` toward that
  target, advancing one adjacent wrapped cell per step and stopping at the
  target or movement range. Direction tie behavior remains ADR-006's negative
  antipodal tie-break. This only approaches a target; it does not feed or attack.
  If there is no edible target in sight, choose one of eight neighboring
  directions with the simulation-owned RNG and move up to the same trait-limited
  range, wrapping each step. Degenerate dimensions may wrap a step back to the
  same cell; such a step is not charged as movement.
- Movement cost: Charge only when position changes. Cost per moved cell is
  `100 + floor(speed / 256)` energy, so both longer distance and higher speed
  increase cost. Spend no more than current energy: if energy funds fewer steps
  than selected, move only the affordable prefix. Energy zero permits no move.
- Cell sharing: Any number and kind of organisms may occupy a cell. Movement
  never rejects a destination based on occupancy; plant establishment's
  existing local limit remains a separate reproduction rule. All position
  changes go through `Simulation::move_organism` / `World::move_organism`, which
  synchronously updates the spatial index.
- Consequences: Outcomes remain deterministic through ascending organism-ID
  actor order, stable target tie-breaking, fixed geometry, and the seeded RNG
  only for un-targeted movement. Speed correlates perception and travel
  capability. Sequential movement means later actors perceive earlier actors'
  updated positions in the same tick; the living actor ID set is captured at
  AnimalMovement phase start. No new crate or system dependency is required.
- Verification: Test trait mapping endpoints, perception at all seams and
  inclusive radius boundaries against indexed query results, self exclusion
  during target selection, target priority/ties, shortest wrapped target
  movement, step bounds, speed/distance energy costs, insufficient-energy
  truncation, seeded wandering repeatability, unlimited cell sharing, and index
  correctness after movement. Run focused tests, full `cargo test`, formatting,
  whitespace and handoff JSON checks.

# ADR-021: Batch runs, parameter sweeps, and exports

## Status

Accepted and implemented in TASK-021 IMPLEMENT cycle 1.

## Context

TASK-021 adds `evosim batch` on top of the validated `run` behavior from
TASK-019 and sampled metrics from TASK-020. The batch command must run a seed
set, vary at least one parameter across several values, write one ordinary
result JSON per run, aggregate final population/extinction counts, export CSV,
and produce a summary whose values are repeatable.

## Decisions

- Add `batch` to `src/cli.rs` and dispatch it from `src/lib.rs`. Keep parsing,
  configuration validation, simulation advancement, and result construction
  shared with the current run implementation so batch and run cannot diverge
  ecologically or in result shape.
- CLI shape: `evosim batch --config FILE --seeds S1,S2 --ticks N --out-dir DIR`
  with required `--vary FIELD=V1,V2` and optional `--csv FILE`. `FIELD` is a
  dotted path into the deserialized configuration. Initially support scalar
  integer leaves needed for useful sweeps: `initial.plants`,
  `initial.herbivores`, `initial.carnivores`, `world.width`,
  `world.height`, and `ecology.resource_capacity`. Values are unsigned decimal
  integers and each candidate config must pass `Config::validate`. Multiple
  `--vary` flags may form a Cartesian product.
- Reject empty lists, duplicate seeds, duplicate values for a field, unknown
  fields, duplicate flags, malformed integers, and a zero tick-independent
  invalid configuration using status 2 and stderr; validate all combinations
  before starting simulation or opening outputs. The output directory must
  already exist as specified by CONTRACT. Per-run names remain
  `seed-<seed>.json` for one varied dimension/value and otherwise use stable
  `seed-<seed>-<field>-<value>...json` names to avoid overwrites.
- Execute combinations sequentially in the input seed order and value order.
  RNG remains per-simulation, and the stable sequence makes failures and
  resource use straightforward to reproduce. Parallel execution is deferred
  unless measurement shows it is needed.
- `summary.json` contains a schema version, requested ticks, an ordered `runs`
  array with seed, varied parameters, ticks, output filename, final counts,
  and per-kind extinct booleans, plus per-kind final-population mean/min/max
  and extinction run counts. Do not place elapsed time, ticks/second, or other
  wall-clock values in this summary, making its bytes semantically repeatable
  and allowing a direct run-to-run equality test. Individual result files
  retain normal run timing fields.
- `--csv FILE` writes one deterministic header and one row per summary run,
  flattening parameters in sorted field-name order and including seed, ticks,
  final populations, and extinction flags. Use standard CSV quoting and write
  only after all runs succeed. JSON summary remains the canonical aggregate.
- Build JSON values through typed Rust structs or ordered structures, not
  unordered maps. Use `serde_json::Value` mutation only at known config paths
  if that keeps validation centralized; ordering of exposed summary fields is
  fixed by structs and parameter keys are sorted.

## Alternatives and tradeoffs

- A separate sweep file offers richer types but adds another configuration
  format and validation surface. Repeated `--vary FIELD=LIST` is compact,
  shell-friendly, and can still cover a Cartesian matrix.
- Overwriting `seed-<seed>.json` for each variation loses matrix results.
  Preserve this required contract filename for the simple single-value case;
  include stable parameter suffixes for multi-variation cases.
- Running in parallel could improve throughput but complicates deterministic
  error order, resource consumption, and integration tests. Sequential runs
  retain deterministic output ordering; simulation determinism does not rely
  on parallel scheduling.
- Including elapsed measurements in the summary would require tests to ignore
  unstable fields. Keep timings in the per-run files and exclude them from
  summary data instead.

## Implementation and verification plan

1. Refactor `src/cli.rs` to expose an internal validated `RunOptions` / result
   writer or equivalent shared helper while preserving `run` behavior and its
   current tests.
2. Add strict batch argument parsing, dotted-path sweep parsing, candidate
   config validation, Cartesian expansion and collision-free stable filenames.
3. Run each candidate by overriding config seed and requested parameter, then
   write the existing run-result schema at `out-dir/<name>.json`.
4. Aggregate ordered run records and per-kind mean/min/max/extinction counts;
   write `summary.json` and optional CSV with deterministic ordering/quoting.
5. Add CLI integration coverage for a 2-value × 2-seed matrix, run result
   files, all summary aggregates, CSV content, invalid input/no outputs,
   distinct parameter outputs, and repeated summaries. Keep the matrix small
   (few ticks and small world) so the test is fast. Add unit cases for parser,
   expansion and CSV escaping as appropriate.
6. Run focused batch and existing CLI tests, full `cargo test`, formatting,
   whitespace checks, setup/build and handoff JSON validation; record exact
   commands. No system package or dependency is expected.

## Risks

- CLI `--vary` values and JSON numeric widths must be checked before casting
  into configuration fields; every generated config should be validated
  before any expensive run or output mutation.
- Parameterized output naming must be unambiguous for multiple fields and
  should not permit path separators from user-supplied values/field names.
- Writing per-run output before all runs complete can leave partial results on
  a later error. Keep all input/config validation upfront; document that
  runtime/write failures may leave already-completed run files, while summary
  and CSV are emitted only after successful completion.
- Summary equality should compare the full JSON summary across independent
  batch invocations, not merely aggregates; ensure it contains no elapsed
  fields or nondeterministic map iteration.
- Cartesian products can become large. This task can reject or document a
  reasonable maximum only if necessary; avoid arbitrary low limits that make
  ordinary sweeps unusable.

No system packages or new Cargo dependencies are planned.

## Implementation record

The CLI dispatches `batch` to `src/cli.rs`. The run execution/result creation
was extracted into a shared helper. The batch parser requires `--config`,
`--seeds`, `--ticks`, `--out-dir`, and at least one `--vary`; it also accepts
`--csv`. It rejects duplicate flags/seeds/field values, malformed unsigned
integers, unsupported leaves, and invalid generated configurations. Swept
leaves are the six listed above. Matrix entries retain seed order and
Cartesian value order and execute sequentially.

Summary JSON is deterministic and contains `schema_version`, `ticks`, ordered
`runs` with seed, parameter map, tick count, result filename, final counts and
extinct flags, and an `aggregates` object with mean/min/max and `extinct_runs`
for each kind. CSV columns use sorted sweep fields and the same run order.
Individual result files retain the ordinary result schema and timing fields.
The focused 2x2 integration regression and complete CLI/full-suite results
are in `tasks/TASK-021/handoffs/implement-cycle1.json`.

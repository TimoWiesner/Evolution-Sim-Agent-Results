const test=require('node:test');const assert=require('node:assert/strict');const {Controller}=require('../ui/controller.js');
test('starts paused; run and pause transition without changing speed',()=>{const c=new Controller();assert.equal(c.running,false);c.run();assert.equal(c.running,true);c.pause();assert.equal(c.running,false);assert.equal(c.speed,1)});
test('step always requests exactly one tick and preserves run state',()=>{const c=new Controller();assert.equal(c.step(),1);assert.equal(c.running,false);c.run();assert.equal(c.step(),1);assert.equal(c.running,true)});
test('speed accepts only positive supported levels',()=>{const c=new Controller();for(const n of [1,5,20])assert.equal(c.setSpeed(n),n);for(const n of [0,-1,2,100])assert.equal(c.setSpeed(n),1)});
test('reset pauses and clears selection',()=>{const c=new Controller();c.run();c.setSpeed(20);c.select(42);c.reset();assert.equal(c.running,false);assert.equal(c.selected,null);assert.equal(c.speed,20)});

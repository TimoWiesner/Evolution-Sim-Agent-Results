use std::process::Command;
use std::{
    fs,
    path::PathBuf,
    sync::atomic::{AtomicUsize, Ordering},
};

static NEXT: AtomicUsize = AtomicUsize::new(0);
fn temp_path(label: &str) -> PathBuf {
    std::env::temp_dir().join(format!(
        "evosim-{label}-{}-{}.json",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ))
}

fn binary() -> Command {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
}

#[test]
fn version_prints_contract_json() {
    let output = binary().arg("version").output().unwrap();
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "{\"name\":\"evosim\",\"version\":\"0.1.0\",\"contract\":1}\n"
    );
    assert!(output.stderr.is_empty());
}

#[test]
fn help_lists_available_bootstrap_commands() {
    let output = binary().arg("--help").output().unwrap();
    assert!(output.status.success());
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(text.contains("COMMANDS:"));
    assert!(text.contains("version"));
    assert!(text.contains("help"));
}

#[test]
fn unknown_command_exits_two_with_stderr_message() {
    let output = binary().arg("not-a-command").output().unwrap();
    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8(output.stderr)
        .unwrap()
        .contains("unknown command"));
}

#[test]
fn climate_map_command_prints_row_major_codes_without_ui() {
    let output = binary().args(["climate-map", "3", "2"]).output().unwrap();
    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "DE DE DE\nDE DE DE\n"
    );
    assert!(output.stderr.is_empty());
}

fn run(config: &PathBuf, out: &PathBuf, ticks: &str, seed: &str) -> std::process::Output {
    binary()
        .args([
            "run",
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            ticks,
            "--out",
            out.to_str().unwrap(),
            "--seed",
            seed,
        ])
        .output()
        .unwrap()
}

#[test]
fn run_is_headless_deterministic_and_emits_contract_shape() {
    let config = temp_path("config");
    let a = temp_path("a");
    let b = temp_path("b");
    fs::write(&config, r#"{"seed":42,"world":{"width":3,"height":2},"initial":{"plants":0,"herbivores":1,"carnivores":1}}"#).unwrap();
    let first = run(&config, &a, "8", "7");
    let second = run(&config, &b, "8", "7");
    assert!(
        first.status.success(),
        "{}",
        String::from_utf8_lossy(&first.stderr)
    );
    assert!(
        second.status.success(),
        "{}",
        String::from_utf8_lossy(&second.stderr)
    );
    assert!(first.stdout.is_empty());
    let ja: serde_json::Value = serde_json::from_slice(&fs::read(&a).unwrap()).unwrap();
    let jb: serde_json::Value = serde_json::from_slice(&fs::read(&b).unwrap()).unwrap();
    for key in [
        "contract",
        "seed",
        "tick_start",
        "tick_end",
        "world",
        "final",
        "totals",
        "series",
        "metrics",
        "state_hash",
    ] {
        assert_eq!(ja[key], jb[key], "{key}");
    }
    assert_eq!(ja["seed"], 7);
    assert_eq!(ja["tick_end"], 8);
    assert_eq!(ja["series"][0]["tick"], 0);
    assert_eq!(
        ja["metrics"].as_array().unwrap().len(),
        ja["series"].as_array().unwrap().len()
    );
    for (metric, sample) in ja["metrics"]
        .as_array()
        .unwrap()
        .iter()
        .zip(ja["series"].as_array().unwrap())
    {
        assert_eq!(metric["tick"], sample["tick"]);
        assert_eq!(metric["population"]["plants"], sample["plants"]);
        assert!(metric["traits"]["plants"]
            .get("max_lifespan_ticks")
            .is_some());
        assert!(metric["deaths_by_cause"]["carnivores"]
            .get("predation")
            .is_some());
    }
    assert_eq!(
        ja["series"][ja["series"].as_array().unwrap().len() - 1]["tick"],
        8
    );
    assert_eq!(ja["final"]["plants"], 0);
    assert_eq!(ja["state_hash"].as_str().unwrap().len(), 64);
    let c = temp_path("c");
    let diff = run(&config, &c, "8", "8");
    assert!(diff.status.success());
    let jc: serde_json::Value = serde_json::from_slice(&fs::read(&c).unwrap()).unwrap();
    assert_ne!(ja["state_hash"], jc["state_hash"]);
    for p in [config, a, b, c] {
        let _ = fs::remove_file(p);
    }
}

#[test]
fn run_zero_ticks_and_invalid_inputs_have_required_behavior() {
    let config = temp_path("zero-config");
    let out = temp_path("zero-out");
    fs::write(&config, r#"{"seed":3,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let zero = binary()
        .args([
            "run",
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "0",
            "--out",
            out.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert!(zero.status.success());
    let j: serde_json::Value = serde_json::from_slice(&fs::read(&out).unwrap()).unwrap();
    assert_eq!(j["tick_start"], 0);
    assert_eq!(j["tick_end"], 0);
    assert_eq!(j["series"].as_array().unwrap().len(), 1);
    let invalid = binary()
        .args([
            "run",
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "1",
            "--out",
            out.to_str().unwrap(),
            "--sample-every",
            "0",
        ])
        .output()
        .unwrap();
    assert_eq!(invalid.status.code(), Some(2));
    assert!(!invalid.stderr.is_empty());
    let missing = temp_path("missing");
    let bad = binary()
        .args([
            "run",
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "1",
            "--out",
            missing.to_str().unwrap(),
        ])
        .arg("--bogus")
        .output()
        .unwrap();
    assert_eq!(bad.status.code(), Some(2));
    assert!(!missing.exists());
    let invalid_result = temp_path("invalid-config-result");
    let invalid_config = temp_path("unreadable-config");
    let unreadable = binary()
        .args([
            "run",
            "--config",
            invalid_config.to_str().unwrap(),
            "--ticks",
            "1",
            "--out",
            invalid_result.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert_eq!(unreadable.status.code(), Some(2));
    assert!(!unreadable.stderr.is_empty());
    assert!(!invalid_result.exists());
    for p in [config, out] {
        let _ = fs::remove_file(p);
    }
}

#[test]
fn batch_accepts_contract_syntax_without_sweep() {
    let config = temp_path("batch-config");
    let out_dir = std::env::temp_dir().join(format!(
        "evosim-batch-{}-{}",
        std::process::id(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    fs::create_dir(&out_dir).unwrap();
    fs::write(&config, r#"{"seed":42,"world":{"width":2,"height":2},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#).unwrap();
    let output = binary()
        .args([
            "batch",
            "--config",
            config.to_str().unwrap(),
            "--seeds",
            "1,2",
            "--ticks",
            "0",
            "--out-dir",
            out_dir.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let summary: serde_json::Value =
        serde_json::from_slice(&fs::read(out_dir.join("summary.json")).unwrap()).unwrap();
    assert_eq!(summary["runs"].as_array().unwrap().len(), 2);
    for seed in [1, 2] {
        let result: serde_json::Value =
            serde_json::from_slice(&fs::read(out_dir.join(format!("seed-{seed}.json"))).unwrap())
                .unwrap();
        assert_eq!(result["tick_end"], 0);
    }
    let _ = fs::remove_file(config);
    let _ = fs::remove_dir_all(out_dir);
}

#[test]
fn canonical_hash_changes_when_organism_energy_changes() {
    let config = evosim::Config::from_json(
        r#"{"seed":42,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":0,"carnivores":0}}"#,
    ).unwrap();
    let mut sim = evosim::Simulation::new(&config);
    let before = sim.state_hash().unwrap();
    sim.set_organism_energy(1, 99_999).unwrap();
    assert_ne!(before, sim.state_hash().unwrap());
}

#[test]
fn checkpoint_resume_matches_uninterrupted_at_zero_and_two_split_points() {
    let config = temp_path("checkpoint-config");
    fs::write(&config, r#"{"seed":19,"world":{"width":4,"height":3},"initial":{"plants":8,"herbivores":3,"carnivores":1}}"#).unwrap();
    for split in [0, 5, 13] {
        let checkpoint = temp_path("checkpoint-save");
        let partial = temp_path("checkpoint-partial");
        let resumed = temp_path("checkpoint-resumed");
        let uninterrupted = temp_path("checkpoint-full");
        let first = binary()
            .args([
                "run",
                "--config",
                config.to_str().unwrap(),
                "--ticks",
                &split.to_string(),
                "--out",
                partial.to_str().unwrap(),
                "--save",
                checkpoint.to_str().unwrap(),
            ])
            .output()
            .unwrap();
        assert!(
            first.status.success(),
            "{}",
            String::from_utf8_lossy(&first.stderr)
        );
        let saved: serde_json::Value =
            serde_json::from_slice(&fs::read(&checkpoint).unwrap()).unwrap();
        assert_eq!(saved["format_version"], 1);
        let resume = binary()
            .args([
                "run",
                "--load",
                checkpoint.to_str().unwrap(),
                "--ticks",
                "17",
                "--out",
                resumed.to_str().unwrap(),
            ])
            .output()
            .unwrap();
        assert!(
            resume.status.success(),
            "{}",
            String::from_utf8_lossy(&resume.stderr)
        );
        let full = binary()
            .args([
                "run",
                "--config",
                config.to_str().unwrap(),
                "--ticks",
                &(split + 17).to_string(),
                "--out",
                uninterrupted.to_str().unwrap(),
            ])
            .output()
            .unwrap();
        assert!(
            full.status.success(),
            "{}",
            String::from_utf8_lossy(&full.stderr)
        );
        let resumed_json: serde_json::Value =
            serde_json::from_slice(&fs::read(&resumed).unwrap()).unwrap();
        let full_json: serde_json::Value =
            serde_json::from_slice(&fs::read(&uninterrupted).unwrap()).unwrap();
        for key in ["state_hash", "final", "totals"] {
            assert_eq!(resumed_json[key], full_json[key], "split {split}: {key}");
        }
        assert_eq!(resumed_json["tick_start"], split);
        for path in [checkpoint, partial, resumed, uninterrupted] {
            let _ = fs::remove_file(path);
        }
    }
    let _ = fs::remove_file(config);
}

#[test]
fn invalid_checkpoints_exit_two_without_result_file() {
    let config = temp_path("checkpoint-bad-config");
    let valid = temp_path("checkpoint-valid");
    fs::write(&config, r#"{"seed":2,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let saved = binary()
        .args([
            "run",
            "--config",
            config.to_str().unwrap(),
            "--ticks",
            "0",
            "--out",
            temp_path("unused").to_str().unwrap(),
            "--save",
            valid.to_str().unwrap(),
        ])
        .output()
        .unwrap();
    assert!(
        saved.status.success(),
        "{}",
        String::from_utf8_lossy(&saved.stderr)
    );
    let original: serde_json::Value = serde_json::from_slice(&fs::read(&valid).unwrap()).unwrap();
    let mut wrong_version = original.clone();
    wrong_version["format_version"] = 99.into();
    let mut invalid_state = original;
    invalid_state["tick"] = 9.into();
    let cases = [
        (None, "missing"),
        (Some(b"{".to_vec()), "damaged"),
        (Some(b"{\"format_version\":1".to_vec()), "truncated"),
        (
            Some(serde_json::to_vec(&wrong_version).unwrap()),
            "wrong-version",
        ),
        (
            Some(serde_json::to_vec(&invalid_state).unwrap()),
            "invalid-state",
        ),
    ];
    for (bytes, label) in cases {
        let checkpoint = temp_path(label);
        if let Some(bytes) = bytes {
            fs::write(&checkpoint, bytes).unwrap();
        }
        let out = temp_path("checkpoint-no-result");
        let result = binary()
            .args([
                "run",
                "--load",
                checkpoint.to_str().unwrap(),
                "--ticks",
                "1",
                "--out",
                out.to_str().unwrap(),
            ])
            .output()
            .unwrap();
        assert_eq!(
            result.status.code(),
            Some(2),
            "{label}: {}",
            String::from_utf8_lossy(&result.stderr)
        );
        assert!(!out.exists(), "{label} created result file");
        let _ = fs::remove_file(checkpoint);
    }
    let _ = fs::remove_file(config);
    let _ = fs::remove_file(valid);
}

#[test]
fn batch_matrix_writes_results_summary_csv_and_is_repeatable() {
    let config = temp_path("batch-config");
    let dir = temp_path("batch-out");
    let dir2 = temp_path("batch-out-repeat");
    fs::create_dir(&dir).unwrap();
    fs::create_dir(&dir2).unwrap();
    fs::write(&config, r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":0,"herbivores":0,"carnivores":0}}"#).unwrap();
    let invoke = |out: &PathBuf, csv: &PathBuf| {
        binary()
            .args([
                "batch",
                "--config",
                config.to_str().unwrap(),
                "--seeds",
                "3,4",
                "--ticks",
                "0",
                "--out-dir",
                out.to_str().unwrap(),
                "--vary",
                "initial.plants=0,1",
                "--csv",
                csv.to_str().unwrap(),
            ])
            .output()
            .unwrap()
    };
    let csv = temp_path("batch.csv");
    let csv2 = temp_path("batch2.csv");
    let a = invoke(&dir, &csv);
    let b = invoke(&dir2, &csv2);
    assert!(a.status.success(), "{}", String::from_utf8_lossy(&a.stderr));
    assert!(b.status.success(), "{}", String::from_utf8_lossy(&b.stderr));
    let ja: serde_json::Value =
        serde_json::from_slice(&fs::read(dir.join("summary.json")).unwrap()).unwrap();
    let jb: serde_json::Value =
        serde_json::from_slice(&fs::read(dir2.join("summary.json")).unwrap()).unwrap();
    assert_eq!(ja, jb);
    assert_eq!(ja["runs"].as_array().unwrap().len(), 4);
    assert_eq!(ja["aggregates"]["plants"]["mean"], 0.5);
    assert_eq!(ja["aggregates"]["plants"]["min"], 0);
    assert_eq!(ja["aggregates"]["plants"]["max"], 1);
    assert_eq!(ja["aggregates"]["plants"]["extinct_runs"], 2);
    for run in ja["runs"].as_array().unwrap() {
        let filename = run["file"].as_str().unwrap();
        let result: serde_json::Value =
            serde_json::from_slice(&fs::read(dir.join(filename)).unwrap()).unwrap();
        assert_eq!(result["contract"], 1);
    }
    let csv_text = fs::read_to_string(&csv).unwrap();
    assert_eq!(csv_text.lines().count(), 5);
    assert_eq!(fs::read(&csv).unwrap(), fs::read(&csv2).unwrap());
    for p in [config, csv, csv2] {
        let _ = fs::remove_file(p);
    }
    for d in [dir, dir2] {
        let _ = fs::remove_dir_all(d);
    }
}

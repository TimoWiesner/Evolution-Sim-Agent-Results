use evosim::{Cell, Config, OrganismKind, Simulation};

// Fixed xorshift64* stream: deterministic randomized coverage without an added crate.
struct Cases(u64);
impl Cases {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.0 = x;
        x.wrapping_mul(0x2545_f491_4f6c_dd1d)
    }
    fn range(&mut self, max: u64) -> u64 {
        self.next() % max
    }
}

#[test]
fn randomized_small_worlds_preserve_accounting_ranges_wrapping_and_replay() {
    let mut cases = Cases(0x028_5eed_cafe_beef);
    for case in 0..32 {
        let width = 1 + cases.range(8) as u32;
        let height = 1 + cases.range(8) as u32;
        let config = Config::from_json(&format!(
            r#"{{"seed":{},"world":{{"width":{},"height":{}}},"initial":{{"plants":{},"herbivores":{},"carnivores":{}}}}}"#,
            cases.next(), width, height,
            cases.range(15), cases.range(8), cases.range(5)
        )).unwrap();
        let initial = config.initial.clone();
        let mut a = Simulation::new(&config);
        let mut b = Simulation::new(&config);

        // Opposite edges are one cell apart on every torus, including 1-cell axes.
        for organism in a.world().organisms() {
            let opposite_x = Cell {
                x: (organism.position.x + width - 1) % width,
                y: organism.position.y,
            };
            let opposite_y = Cell {
                x: organism.position.x,
                y: (organism.position.y + height - 1) % height,
            };
            assert!(a.world().grid().distance(organism.position, opposite_x) <= 1);
            assert!(a.world().grid().distance(organism.position, opposite_y) <= 1);
        }

        let ticks = 8 + cases.range(17);
        for _ in 0..ticks {
            a.step_one_tick();
            b.step_one_tick();
            assert_eq!(
                a.state_hash().unwrap(),
                b.state_hash().unwrap(),
                "case {case}"
            );
            let world = a.world();
            let counts = world.lifecycle_counts();
            for (kind, start, births, deaths) in [
                (
                    OrganismKind::Plant,
                    initial.plants,
                    counts.plants.births,
                    counts.plants.deaths,
                ),
                (
                    OrganismKind::Herbivore,
                    initial.herbivores,
                    counts.herbivores.births,
                    counts.herbivores.deaths,
                ),
                (
                    OrganismKind::Carnivore,
                    initial.carnivores,
                    counts.carnivores.births,
                    counts.carnivores.deaths,
                ),
            ] {
                assert_eq!(
                    start as usize + births as usize - deaths as usize,
                    world.count(kind),
                    "case {case}, {kind:?}"
                );
            }
            for organism in world.organisms() {
                assert!(organism.position.x < width && organism.position.y < height);
                assert!(organism.energy() <= 100_000 && organism.health() <= 100_000);
                assert!(organism.traits.valid_for(organism.kind));
                assert!(organism.traits.max_health > 0);
                assert!(organism.traits.max_lifespan_ticks > 0);
            }
            for y in 0..height {
                for x in 0..width {
                    let climate = world.current_climate(Cell { x, y });
                    assert!((-20_000..=20_000).contains(&climate.temperature_centi_c));
                    assert!((0..=1_000).contains(&climate.precipitation));
                    assert!(world.soil_water(Cell { x, y }) <= config.ecology.resource_capacity);
                }
            }
        }
    }
}

use evosim::{Cell, Config, Simulation, TickPhase};

fn config(seed: u64) -> Config {
    let mut config = Config::preset("balanced").unwrap();
    config.seed = seed;
    config
}

fn trace(seed: u64) -> Vec<evosim::simulation::SimulationSnapshot> {
    let mut simulation = Simulation::new(&config(seed));
    let mut trace = vec![simulation.snapshot()];
    for expected_tick in 1..=120 {
        let report = simulation.step_one_tick();
        assert_eq!(report.tick, expected_tick);
        assert_eq!(simulation.tick(), expected_tick);
        assert_eq!(report.phases, TickPhase::ORDER);
        trace.push(simulation.snapshot());
    }
    trace
}

#[test]
fn seeded_traces_repeat_and_distinct_seeds_differ() {
    assert_eq!(trace(812), trace(812));
    assert_ne!(trace(812), trace(813));
}

#[test]
fn simulation_owns_configured_world_clock_rng_and_fixed_phase_order() {
    let mut simulation = Simulation::new(&config(9));
    assert_eq!(simulation.tick_index(), 0);
    assert_eq!(simulation.world().grid().width(), 64);
    assert_eq!(simulation.world().grid().height(), 48);
    let report = simulation.step_one_tick();
    assert_eq!(simulation.tick_index(), 1);
    assert_eq!(report.phases, TickPhase::ORDER);
    assert!(report.events.is_empty());
}

#[test]
fn weather_off_climate_repeats_exactly_after_configured_year() {
    let mut c = config(9);
    c.world.width = 3;
    c.world.height = 5;
    c.climate.season_length_ticks = 17;
    c.climate.precipitation_seasonality_bp = 10_000;
    c.climate.weather_enabled = false;
    let mut sim = Simulation::new(&c);
    let tick_zero: Vec<_> = (0..5)
        .flat_map(|y| (0..3).map(move |x| Cell { x, y }))
        .map(|p| sim.world().current_climate(p))
        .collect();
    for (index, climate) in tick_zero.iter().enumerate() {
        let cell = Cell {
            x: (index % 3) as u32,
            y: (index / 3) as u32,
        };
        assert_eq!(
            climate.precipitation,
            (sim.world().climate(cell).precipitation + 250).min(1000)
        );
    }
    let mut first_year = Vec::new();
    for _ in 0..17 {
        sim.step_one_tick();
        first_year.push(
            (0..5)
                .flat_map(|y| (0..3).map(move |x| Cell { x, y }))
                .map(|p| sim.world().current_climate(p))
                .collect::<Vec<_>>(),
        );
    }
    let mut second_year = Vec::new();
    for _ in 0..17 {
        sim.step_one_tick();
        second_year.push(
            (0..5)
                .flat_map(|y| (0..3).map(move |x| Cell { x, y }))
                .map(|p| sim.world().current_climate(p))
                .collect::<Vec<_>>(),
        );
    }
    assert_eq!(
        sim.world()
            .weather_deviations()
            .iter()
            .filter(|d| d.temperature_centi_c != 0 || d.precipitation != 0)
            .count(),
        0
    );
    assert_eq!(first_year, second_year);
}

#[test]
fn seeded_weather_is_repeatable_bounded_and_captured_in_snapshot() {
    fn weather(seed: u64) -> Vec<evosim::simulation::SimulationSnapshot> {
        let mut c = config(seed);
        c.world.width = 2;
        c.world.height = 3;
        let mut sim = Simulation::new(&c);
        for _ in 0..4 {
            sim.step_one_tick();
        }
        let snapshot = sim.snapshot();
        assert_eq!(snapshot.climate.weather.len(), 6);
        assert!(snapshot
            .climate
            .weather
            .iter()
            .all(|d| (-300..=300).contains(&d.temperature_centi_c)
                && (-100..=100).contains(&d.precipitation)));
        assert!((0..3)
            .flat_map(|y| (0..2).map(move |x| Cell { x, y }))
            .all(|cell| {
                let climate = sim.world().current_climate(cell);
                (-8800..=9100).contains(&climate.temperature_centi_c)
                    && climate.precipitation <= 1000
            }));
        vec![snapshot]
    }
    assert_eq!(weather(41), weather(41));
    assert_ne!(weather(41), weather(42));
}

#[test]
fn lifecycle_initialization_is_ordered_seeded_and_accounted() {
    use evosim::OrganismKind::*;
    let mut c = config(42);
    c.world.width = 5;
    c.world.height = 3;
    c.initial.plants = 2;
    c.initial.herbivores = 1;
    c.initial.carnivores = 1;
    let a = Simulation::new(&c);
    let b = Simulation::new(&c);
    assert_eq!(a.snapshot(), b.snapshot());
    let ids: Vec<_> = a.world().organisms().map(|o| o.id).collect();
    assert_eq!(ids, vec![1, 2, 3, 4]);
    assert_eq!(a.world().organism(1).unwrap().kind, Plant);
    assert_eq!(a.world().organism(3).unwrap().kind, Herbivore);
    assert_eq!(a.world().organism(4).unwrap().kind, Carnivore);
    let counts = a.world().lifecycle_counts();
    assert_eq!(
        (
            counts.plants.initial,
            counts.herbivores.initial,
            counts.carnivores.initial
        ),
        (2, 1, 1)
    );
}

#[test]
fn deaths_resolve_before_births_and_newborns_are_not_aged_or_killed() {
    use evosim::{DeathCause, Genome, OrganismKind};
    let mut c = config(8);
    c.world.width = 4;
    c.world.height = 4;
    c.initial.plants = 1;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    let mut sim = Simulation::new(&c);
    let parent = sim.world().organisms().next().unwrap().id;
    sim.set_organism_energy(parent, 0).unwrap();
    assert!(sim.queue_death(parent, DeathCause::Predation));
    assert!(sim.queue_death(parent, DeathCause::Age));
    let child = sim
        .queue_birth(
            OrganismKind::Herbivore,
            Cell { x: 1, y: 2 },
            Genome::from_loci([321; 8]),
            [Some(parent), None],
            1,
        )
        .unwrap();
    assert!(sim.world().organism(child).is_none());
    assert!(!sim.queue_death(child, DeathCause::Injury));
    sim.step_one_tick();
    assert!(sim.world().organism(parent).is_none());
    let newborn = sim.world().organism(child).unwrap();
    assert_eq!(newborn.age, 0);
    assert_eq!(newborn.parent_ids, [Some(parent), None]);
    assert_eq!(newborn.generation, 1);
    assert_eq!(newborn.genome, Genome::from_loci([321; 8]));
    assert_eq!(
        newborn.traits,
        newborn.genome.traits(OrganismKind::Herbivore)
    );
    assert_eq!(
        sim.world().organisms().map(|o| o.id).collect::<Vec<_>>(),
        vec![child]
    );
    assert_eq!(sim.world().death_history()[0].cause, DeathCause::Predation);
    assert_eq!(sim.world().death_history()[0].tick, 1);
    let counts = sim.world().lifecycle_counts();
    assert_eq!(
        (
            counts.plants.initial,
            counts.plants.births,
            counts.plants.deaths
        ),
        (1, 0, 1)
    );
    assert_eq!(
        (
            counts.herbivores.initial,
            counts.herbivores.births,
            counts.herbivores.deaths
        ),
        (0, 1, 0)
    );
    sim.step_one_tick();
    assert!(sim.world().organism(parent).is_none());
    assert_eq!(sim.world().organism(child).unwrap().age, 1);
    let later = sim
        .queue_birth(
            OrganismKind::Plant,
            Cell { x: 0, y: 0 },
            Genome::default(),
            [None, None],
            0,
        )
        .unwrap();
    assert!(later > child);
}

#[test]
fn plants_gain_funded_energy_and_compete_for_bounded_cell_water() {
    use evosim::OrganismKind;
    let mut c = config(3);
    c.world.width = 3;
    c.world.height = 100;
    c.initial.plants = 2;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.weather_enabled = false;
    c.climate.seasonal_temperature_amplitude_centi_c = 0;
    c.ecology.resource_capacity = 1;
    let mut sim = Simulation::new(&c);
    let ids: Vec<_> = sim.world().organisms().map(|o| o.id).collect();
    let favorable = Cell { x: 0, y: 50 };
    assert!(sim.world().current_climate(favorable).temperature_centi_c > 2000);
    for id in &ids {
        sim.move_organism(*id, favorable).unwrap();
        sim.set_organism_energy(*id, 0).unwrap();
    }
    assert_eq!(sim.world().soil_water(favorable), 1);
    assert_eq!(
        sim.snapshot().climate.soil_water[(favorable.y * 3 + favorable.x) as usize],
        1
    );
    sim.step_one_tick();
    assert_eq!(sim.world().organism(ids[0]).unwrap().energy(), 100);
    assert!(
        sim.world().organism(ids[1]).is_none(),
        "the unfunded plant starves"
    );
    assert!(sim.world().soil_water(favorable) <= c.ecology.resource_capacity);
    assert_eq!(
        sim.world().soil_water(favorable),
        0,
        "the first plant consumes the one replenished unit"
    );
    assert_eq!(sim.world().count(OrganismKind::Plant), 1);
    assert_eq!(
        sim.world().death_history()[0].cause,
        evosim::DeathCause::Starvation
    );
}

#[test]
fn zero_energy_plants_die_of_starvation_without_replenishment_or_rng_draws() {
    use evosim::{DeathCause, OrganismKind};
    let mut c = config(17);
    c.world.width = 1;
    c.world.height = 100;
    c.initial.plants = 1;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    c.climate.weather_enabled = false;
    c.climate.seasonal_temperature_amplitude_centi_c = 0;
    let mut sim = Simulation::new(&c);
    let id = sim.world().organisms().next().unwrap().id;
    sim.move_organism(id, Cell { x: 0, y: 0 }).unwrap();
    sim.set_organism_energy(id, 0).unwrap();
    sim.step_one_tick();
    assert_eq!(sim.world().count(OrganismKind::Plant), 0);
    assert_eq!(sim.world().death_history()[0].cause, DeathCause::Starvation);
}

#[test]
fn zero_initial_plants_stay_extinct() {
    use evosim::OrganismKind;
    let mut c = config(23);
    c.world.width = 2;
    c.world.height = 2;
    c.initial.plants = 0;
    c.initial.herbivores = 0;
    c.initial.carnivores = 0;
    let mut sim = Simulation::new(&c);
    for _ in 0..10 {
        sim.step_one_tick();
    }
    assert_eq!(sim.world().count(OrganismKind::Plant), 0);
}

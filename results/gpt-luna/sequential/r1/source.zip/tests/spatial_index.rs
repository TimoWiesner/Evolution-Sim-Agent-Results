use evosim::{Cell, Config, Genome, OrganismKind, Simulation};
use std::time::Instant;

fn setup(width: u32, height: u32, plants: u32) -> Simulation {
    let mut config = Config::preset("balanced").unwrap();
    config.seed = 731;
    config.world.width = width;
    config.world.height = height;
    config.initial.plants = plants;
    config.initial.herbivores = 0;
    config.initial.carnivores = 0;
    Simulation::new(&config)
}

fn expected(sim: &Simulation, center: Cell, radius: u32, kind: Option<OrganismKind>) -> Vec<u64> {
    let grid = sim.world().grid();
    sim.world()
        .organisms()
        .filter(|organism| {
            grid.distance(center, organism.position) <= radius
                && kind.is_none_or(|wanted| organism.kind == wanted)
        })
        .map(|organism| organism.id)
        .collect()
}

#[test]
fn queries_match_randomized_brute_force_with_small_worlds_and_mutations() {
    let mut random = 0x4d595df4d0f33173_u64;
    for (width, height) in [(1, 1), (1, 5), (6, 1), (3, 4), (7, 6)] {
        let mut sim = setup(width, height, 35);
        let mut ids: Vec<_> = sim.world().organisms().map(|o| o.id).collect();
        for query in 0..1_200_u32 {
            random ^= random << 13;
            random ^= random >> 7;
            random ^= random << 17;
            let center = Cell {
                x: (random as u32) % width,
                y: ((random >> 32) as u32) % height,
            };
            let radius = ((random >> 12) as u32) % (width.max(height) + 5);
            let kind = match (random >> 27) % 4 {
                0 => Some(OrganismKind::Plant),
                1 => Some(OrganismKind::Herbivore),
                2 => Some(OrganismKind::Carnivore),
                _ => None,
            };
            let actual: Vec<_> = sim
                .world()
                .organisms_within(center, radius, kind)
                .into_iter()
                .map(|o| o.id)
                .collect();
            assert_eq!(
                actual,
                expected(&sim, center, radius, kind),
                "{width}x{height}, query {query}"
            );

            if query % 40 == 0 && !ids.is_empty() {
                let index = (random as usize) % ids.len();
                let id = ids[index];
                if query % 80 == 0 {
                    let destination = Cell {
                        x: ((random >> 8) as u32) % width,
                        y: ((random >> 40) as u32) % height,
                    };
                    sim.move_organism(id, destination).unwrap();
                } else {
                    assert!(sim.queue_death(id, evosim::DeathCause::Other));
                    sim.step_one_tick();
                    ids.remove(index);
                }
            }
        }
    }
}

#[test]
fn index_tracks_initial_birth_movement_death_and_orders_ids() {
    let mut sim = setup(5, 3, 0);
    let first = sim
        .queue_birth(
            OrganismKind::Plant,
            Cell { x: 0, y: 1 },
            Genome::default(),
            [None, None],
            1,
        )
        .unwrap();
    let second = sim
        .queue_birth(
            OrganismKind::Herbivore,
            Cell { x: 4, y: 1 },
            Genome::default(),
            [None, None],
            1,
        )
        .unwrap();
    sim.step_one_tick();
    assert_eq!(
        sim.world()
            .organisms_within(Cell { x: 0, y: 1 }, 1, None)
            .iter()
            .map(|o| o.id)
            .collect::<Vec<_>>(),
        vec![first, second]
    );
    sim.move_organism(second, Cell { x: 2, y: 1 }).unwrap();
    assert_eq!(
        sim.world()
            .organisms_within(Cell { x: 4, y: 1 }, 0, None)
            .len(),
        0
    );
    assert_eq!(
        sim.world().organisms_within(Cell { x: 2, y: 1 }, 0, None)[0].id,
        second
    );
    assert!(sim.queue_death(first, evosim::DeathCause::Other));
    sim.step_one_tick();
    assert!(sim
        .world()
        .organisms_within(Cell { x: 0, y: 1 }, 1, None)
        .iter()
        .all(|o| o.id != first));
    assert!(sim
        .world()
        .organisms_within(Cell { x: 2, y: 1 }, 0, Some(OrganismKind::Plant))
        .is_empty());
    assert!(sim
        .world()
        .organisms_within(Cell { x: 99, y: 99 }, 5, None)
        .is_empty());
}

#[test]
fn indexed_queries_outperform_brute_force_for_2000_organisms() {
    let sim = setup(100, 80, 2_000);
    let mut random = 0x9e3779b97f4a7c15_u64;
    let centers: Vec<_> = (0..1_000)
        .map(|_| {
            random = random.wrapping_mul(6364136223846793005).wrapping_add(1);
            Cell {
                x: (random as u32) % 100,
                y: ((random >> 32) as u32) % 80,
            }
        })
        .collect();
    let start = Instant::now();
    let mut indexed_total = 0;
    for center in &centers {
        indexed_total += sim.world().organisms_within(*center, 2, None).len();
    }
    let indexed = start.elapsed();
    let start = Instant::now();
    let mut scanned_total = 0;
    for center in &centers {
        scanned_total += expected(&sim, *center, 2, None).len();
    }
    let brute_force = start.elapsed();
    eprintln!("2,000 organism / 1,000 radius-2 queries: indexed={indexed:?}, brute_force={brute_force:?}, matches={indexed_total}/{scanned_total}");
    assert_eq!(indexed_total, scanned_total);
    assert!(
        indexed < brute_force,
        "index {indexed:?} must beat scan {brute_force:?}"
    );
}

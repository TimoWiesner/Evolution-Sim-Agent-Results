"""Loopback integration probe for TASK-025 UI preset, validation and chart APIs."""
import json
import os
import subprocess
import urllib.error
import urllib.request


def main():
    env = os.environ.copy()
    env["BROWSER"] = "/bin/true"
    process = subprocess.Popen(
        ["/workspace/evosim", "ui"], env=env, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True
    )
    try:
        line = process.stderr.readline().strip()
        assert line.startswith("Evolution Simulation UI: "), line
        base = line.rsplit(" ", 1)[1].rstrip("/")

        def get(path):
            with urllib.request.urlopen(base + path, timeout=4) as response:
                return response.status, json.loads(response.read())

        _, presets = get("/api/presets")
        assert [name for name, _ in presets] == ["balanced", "lush", "harsh"]
        _, chart = get("/api/charts")
        assert len(chart["history"]) == 1
        get("/api/advance?ticks=2")
        _, chart = get("/api/charts")
        assert len(chart["history"]) == 2 and chart["history"][-1]["tick"] == 2

        valid = {"seed": 8, "world": {"width": 4, "height": 4},
                 "initial": {"plants": 1, "herbivores": 0, "carnivores": 0}}

        def reset(body):
            request = urllib.request.Request(
                base + "/api/reset", data=json.dumps(body).encode(),
                headers={"Content-Type": "application/json"}, method="POST"
            )
            return urllib.request.urlopen(request, timeout=4)

        with reset(valid) as response:
            snap = json.loads(response.read())
            assert snap["tick"] == 0 and snap["plants"] == 1
        try:
            reset({"seed": 0})
            raise AssertionError("invalid configuration accepted")
        except urllib.error.HTTPError as error:
            assert error.code == 400
        _, snap = get("/api/snapshot")
        assert snap["tick"] == 0 and snap["plants"] == 1
        print("UI HTTP integration passed: preset order, chart sampling, valid reset, invalid reset rejection without state replacement")
    finally:
        process.terminate()
        process.wait(timeout=5)


if __name__ == "__main__":
    main()

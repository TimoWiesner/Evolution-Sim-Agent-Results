use evosim::Config;

const FIXED: &str = r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#;

#[test]
fn fixed_only_defaults_and_zero_populations_are_accepted() {
    let c = Config::from_json(FIXED).unwrap();
    assert_eq!(c.climate.season_length_ticks, 240);
    assert!(c.climate.weather_enabled);
    assert_eq!(c.ecology.resource_capacity, 1000);
    assert_eq!(c.genetics.mutation_step, 2048);
    let zero = FIXED
        .replace("400", "0")
        .replace("120", "0")
        .replace("20", "0");
    assert_eq!(Config::from_json(&zero).unwrap().initial.plants, 0);
}

#[test]
fn required_missing_and_wrong_type_errors_name_the_field() {
    for (json, field) in [
        (
            r#"{"world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#,
            "seed",
        ),
        (
            r#"{"seed":1,"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#,
            "world",
        ),
        (r#"{"seed":1,"world":{"width":1,"height":1}}"#, "initial"),
        (
            r#"{"seed":"bad","world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#,
            "seed",
        ),
        (
            r#"{"seed":1,"world":{"width":"bad","height":1},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#,
            "world.width",
        ),
        (
            r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":"bad","carnivores":1}}"#,
            "initial.herbivores",
        ),
        (
            r#"{"seed":1,"world":{"width":1,"height":1},"initial":{"plants":1,"herbivores":1,"carnivores":1},"ecology":{"resource_capacity":"bad"}}"#,
            "ecology.resource_capacity",
        ),
    ] {
        let e = Config::from_json(json).unwrap_err().to_string();
        assert!(e.contains(field), "expected {field} in {e}");
    }
}

#[test]
fn all_range_categories_are_rejected_with_field_names() {
    for (json, field) in [
        (FIXED.replace("\"width\":64", "\"width\":0").as_str().to_owned(), "world.width"),
        (FIXED.replace("\"plants\":400", "\"plants\":1000001").as_str().to_owned(), "initial.plants"),
        (FIXED.replace("\"height\":48", "\"height\":4097"), "world.height"),
        (r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":0,"herbivores":0,"carnivores":0},"ecology":{"plant_growth_per_tick_permille":0}}"#.to_owned(), "ecology.plant_growth_per_tick_permille"),
    ] {
        let e = Config::from_json(&json).unwrap_err().to_string();
        assert!(e.contains(field), "expected {field} in {e}");
    }
}

#[test]
fn unknown_fields_are_errors_and_round_trip_is_equal() {
    let unknown = r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20},"typo":1}"#;
    assert!(Config::from_json(unknown)
        .unwrap_err()
        .to_string()
        .contains("typo"));
    let c = Config::from_json(FIXED).unwrap();
    assert_eq!(Config::from_json(&c.to_json().unwrap()).unwrap(), c);
}

#[test]
fn parser_requires_exactly_one_complete_json_document() {
    let second_value = format!("{FIXED} {{}}");
    let error = Config::from_json(&second_value).unwrap_err().to_string();
    assert!(error.contains("configuration"), "unexpected error: {error}");

    let trailing_text = format!("{FIXED} trailing");
    let error = Config::from_json(&trailing_text).unwrap_err().to_string();
    assert!(error.contains("configuration"), "unexpected error: {error}");

    let trailing_whitespace = format!("{FIXED} \n\t ");
    assert!(Config::from_json(&trailing_whitespace).is_ok());
}

#[test]
fn presets_are_named_valid_and_meaningfully_different() {
    assert_eq!(Config::available_presets(), &["balanced", "lush", "harsh"]);
    let balanced = Config::preset("balanced").unwrap();
    let lush = Config::preset("lush").unwrap();
    let harsh = Config::preset("harsh").unwrap();
    for c in [&balanced, &lush, &harsh] {
        c.validate().unwrap();
    }
    assert_ne!(balanced.ecology, lush.ecology);
    assert_ne!(balanced.climate, harsh.climate);
    assert!(Config::preset("unknown")
        .unwrap_err()
        .to_string()
        .contains("preset"));
}

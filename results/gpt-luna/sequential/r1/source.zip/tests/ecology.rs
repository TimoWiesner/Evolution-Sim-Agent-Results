use evosim::entity::OrganismKind;
use evosim::{Cell, Config, Genome, Simulation, TickPhase};

const FIXED_KEYS: &str = r#"{"seed":42,"world":{"width":64,"height":48},"initial":{"plants":400,"herbivores":120,"carnivores":20}}"#;
const KINDS: [OrganismKind; 3] = [
    OrganismKind::Plant,
    OrganismKind::Herbivore,
    OrganismKind::Carnivore,
];

fn fixed_config() -> Config {
    Config::from_json(FIXED_KEYS).expect("fixed-key configuration is valid")
}

fn assert_accounting(sim: &Simulation) {
    let counts = sim.world().lifecycle_counts();
    for kind in KINDS {
        let ledger = counts.for_kind(kind);
        assert_eq!(
            ledger.initial + ledger.births - ledger.deaths,
            sim.world().count(kind) as u64,
            "lifecycle accounting for {kind:?} at tick {}",
            sim.tick()
        );
    }
}

fn advance_and_check(sim: &mut Simulation, ticks: u64) {
    let mut extinct = [false; 3];
    for _ in 0..ticks {
        let report = sim.step_one_tick();
        assert_eq!(report.phases, TickPhase::ORDER);
        assert_accounting(sim);
        for (index, kind) in KINDS.into_iter().enumerate() {
            let count = sim.world().count(kind);
            assert!(
                !extinct[index] || count == 0,
                "{kind:?} returned after extinction"
            );
            extinct[index] |= count == 0;
        }
    }
}

#[test]
fn fixed_key_configuration_advances_exactly_one_thousand_ticks() {
    let mut sim = Simulation::new(&fixed_config());
    advance_and_check(&mut sim, 1_000);
    assert_eq!(sim.tick(), 1_000);
}

#[test]
fn absent_plants_cause_herbivore_then_carnivore_extinction() {
    let mut config = fixed_config();
    config.seed = 101;
    config.world.width = 8;
    config.world.height = 8;
    config.initial.plants = 0;
    config.initial.herbivores = 12;
    config.initial.carnivores = 4;
    let mut sim = Simulation::new(&config);
    advance_and_check(&mut sim, 2_000);
    assert_eq!(sim.world().count(OrganismKind::Plant), 0);
    assert_eq!(sim.world().count(OrganismKind::Herbivore), 0);
    assert_eq!(sim.world().count(OrganismKind::Carnivore), 0);
    let herbivore_death = sim
        .world()
        .death_history()
        .iter()
        .filter(|death| death.organism.kind == OrganismKind::Herbivore)
        .map(|death| death.tick)
        .max()
        .unwrap();
    let carnivore_death = sim
        .world()
        .death_history()
        .iter()
        .filter(|death| death.organism.kind == OrganismKind::Carnivore)
        .map(|death| death.tick)
        .max()
        .unwrap();
    assert!(herbivore_death < carnivore_death);
}

#[test]
fn absent_herbivores_cause_carnivore_extinction() {
    let mut config = fixed_config();
    config.seed = 202;
    config.world.width = 8;
    config.world.height = 8;
    config.initial.herbivores = 0;
    config.initial.carnivores = 4;
    config.initial.plants = 5;
    let mut sim = Simulation::new(&config);
    advance_and_check(&mut sim, 2_000);
    assert_eq!(sim.world().count(OrganismKind::Herbivore), 0);
    assert_eq!(sim.world().count(OrganismKind::Carnivore), 0);
}

#[test]
fn plants_alone_persist_and_reproduce() {
    let mut config = fixed_config();
    config.seed = 303;
    config.world.width = 16;
    config.world.height = 16;
    config.initial.plants = 100;
    config.initial.herbivores = 0;
    config.initial.carnivores = 0;
    let mut sim = Simulation::new(&config);
    advance_and_check(&mut sim, 1_000);
    assert!(sim.world().count(OrganismKind::Plant) > 0);
    assert!(sim.world().lifecycle_counts().plants.births > 0);
}

#[test]
fn abundant_plants_support_herbivore_survival_and_reproduction() {
    let mut config = fixed_config();
    config.seed = 404;
    let defaults = Config::preset("balanced").unwrap();
    assert_eq!(config.ecology, defaults.ecology);
    assert_eq!(config.genetics, defaults.genetics);
    assert_eq!(config.climate, defaults.climate);
    assert_eq!(config.world.width, 64);
    assert_eq!(config.world.height, 48);
    config.initial.plants = 400;
    config.initial.herbivores = 0;
    config.initial.carnivores = 0;
    let mut sim = Simulation::new(&config);
    let genome = Genome::from_loci([0, 40_000, 60_000, u16::MAX, 0, 0, 0, u16::MAX]);
    for _ in 0..2 {
        sim.queue_birth(
            OrganismKind::Herbivore,
            Cell { x: 32, y: 24 },
            genome,
            [None, None],
            0,
        )
        .unwrap();
    }
    sim.step_one_tick();
    advance_and_check(&mut sim, 300);
    assert!(sim.world().count(OrganismKind::Plant) > 0);
    assert!(sim.world().count(OrganismKind::Herbivore) > 0);
    assert!(sim.world().lifecycle_counts().herbivores.births > 0);
}

#[test]
#[ignore = "explicit 5-seed x 10,000-tick ecology measurement"]
fn report_five_seeds_10000_ticks() {
    let mut report = String::new();
    for seed in 1..=5 {
        let mut config = fixed_config();
        config.seed = seed;
        let mut sim = Simulation::new(&config);
        let mut extinction = [None; 3];
        for _ in 0..10_000 {
            sim.step_one_tick();
            for (index, kind) in KINDS.into_iter().enumerate() {
                if extinction[index].is_none() && sim.world().count(kind) == 0 {
                    extinction[index] = Some(sim.tick());
                }
            }
        }
        let result = KINDS
            .into_iter()
            .enumerate()
            .map(|(index, kind)| {
                format!(
                    "{kind:?}={}",
                    extinction[index]
                        .map_or_else(|| "survived".to_owned(), |tick| tick.to_string())
                )
            })
            .collect::<Vec<_>>()
            .join(", ");
        report.push_str(&format!("seed {seed}: {result}\n"));
    }
    println!("{report}");
}

use evosim::{Config, Simulation};
use std::time::Instant;

#[test]
fn dense_simulation_has_a_minimum_throughput_floor() {
    let mut config = Config::from_json(include_str!("../benchmarks/performance.json")).unwrap();
    config.initial.plants = 2_000;
    let mut simulation = Simulation::new(&config);
    for _ in 0..5 {
        simulation.step_one_tick();
    }
    let initial = simulation.world().organisms().count();
    let started = Instant::now();
    for _ in 0..20 {
        simulation.step_one_tick();
    }
    let elapsed = started.elapsed().as_secs_f64();
    let final_population = simulation.world().organisms().count();
    let ticks_per_second = 20.0 / elapsed;
    assert!(
        initial >= 1_900,
        "warm workload had only {initial} organisms"
    );
    assert!(
        final_population >= 1_900,
        "measured workload had only {final_population} organisms"
    );
    assert!(
        ticks_per_second >= 1.0,
        "throughput was {ticks_per_second:.2} ticks/s"
    );
}

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
for tool in rustc cargo; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "setup.sh: required tool not found: $tool" >&2
    exit 1
  fi
done
cd "$ROOT"
cargo build --release

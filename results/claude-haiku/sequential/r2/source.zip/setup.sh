#!/usr/bin/env bash
# Installs and builds everything the product needs (docs/CONTRACT.md section 1).
# Idempotent. Runs from any working directory. Needs network only if no Rust toolchain exists.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

log() { echo "[setup] $*" >&2; }

find_cargo() {
    if command -v cargo >/dev/null 2>&1; then
        command -v cargo
    elif [ -x /opt/rust/cargo/bin/cargo ]; then
        echo /opt/rust/cargo/bin/cargo
    elif [ -x "${HOME:-/root}/.cargo/bin/cargo" ]; then
        echo "${HOME:-/root}/.cargo/bin/cargo"
    fi
}

CARGO="$(find_cargo || true)"
if [ -z "$CARGO" ]; then
    log "no cargo found; installing a minimal stable Rust toolchain with rustup"
    if ! command -v curl >/dev/null 2>&1; then
        log "error: curl is required to install rustup"
        exit 1
    fi
    curl -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal --default-toolchain stable >&2
    CARGO="$(find_cargo || true)"
    if [ -z "$CARGO" ]; then
        log "error: cargo still not found after rustup install"
        exit 1
    fi
fi
export PATH="$(dirname "$CARGO"):$PATH"
log "using $(cargo --version)"

log "cargo fetch --locked"
cargo fetch --locked >&2
log "cargo build --release --locked"
cargo build --release --locked >&2
log "setup finished; binary at $ROOT/target/release/evosim"

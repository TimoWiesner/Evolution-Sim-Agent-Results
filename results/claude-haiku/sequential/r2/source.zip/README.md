# Evolution Simulation

A locally runnable grid-world ecology simulation: a finite toroidal grid with climate zones, seasons and weather,
plants with DNA, herbivores and carnivores with sexual reproduction and heritable behaviour, species emerging from
genetic distance, and mutation. The same engine drives the headless command line and a local browser UI.
There is no forced anti-extinction: a kind whose count reaches zero stays at zero.

Status: the product is complete for the benchmark contract (`docs/CONTRACT.md`, version 1). The requirement-by-requirement
self-audit, the evidence and the known limitations are in `docs/VERIFICATION.md`. Read the limitations section below
before you rely on the simulation's ecology.

## Requirements and installation

- Ubuntu 24.04 x86-64 with build tools. Rust/Cargo 1.100 is used here (`/opt/rust/cargo/bin`, or `cargo` on `PATH`,
  or `~/.cargo/bin`). `./setup.sh` installs a minimal stable toolchain with rustup only if none of these exists
  (needs network). No apt package is needed.
- The browser UI's headless checks (`ui --smoke-test`, `ui --screenshots`) use a Chromium binary: the container's
  `chromium` (`/usr/local/bin/chromium`), or `CHROME_BIN` pointing to another Chromium. The simulation, the
  `run` and `batch` commands and `dist/evosim` do not need a browser.
- No third-party Rust crates are used, so the build needs no network once Rust is present.

```sh
./setup.sh        # idempotent: cargo fetch --locked and cargo build --release --locked
./evosim version  # {"name": "evosim", "version": "0.1.0", "contract": 1}
```

`./evosim` works from any directory; if the binary is missing it builds it first (offline).

### Distributable

```sh
./build.sh        # writes dist/evosim (git-ignored)
```

`dist/evosim` is one executable, linked only against glibc, `libgcc_s.so.1`, `libm.so.6` and the dynamic loader
(checked by `ldd` in `scripts/test.sh`). It accepts the same commands as `./evosim`, needs no project files and no
language runtime. It was checked from an empty directory outside the workspace with `env -i`: `version`, `run` and
`--help` (see `docs/VERIFICATION.md`). A clean Ubuntu 24.04 machine was not available for this check.

## Commands

Errors (bad arguments, an unreadable or invalid configuration, an invalid checkpoint, an unwritable output) exit with
status 2, print a message on stderr and write no result file. Extinction is not an error. Only `version` and the
result files print to stdout or disk; logs go to stderr.

### `run`: one headless simulation

```sh
./evosim run --config examples/config.json --ticks 10000 --out results/run.json
./evosim run --config scenarios/demo.json --ticks 10000 --seed 3 --out results/demo-3.json
```

- `--config FILE` (JSON, see the parameter table below) or `--load FILE` (a checkpoint); the two cannot be combined.
- `--ticks N`: exactly `N` ticks (`0` is valid); the run goes on after extinction.
- `--seed N`: replaces the seed of the configuration.
- `--out FILE`: the result JSON (parent directories are created). Its keys follow `docs/CONTRACT.md` section 4:
  `tick_start`, `tick_end`, `world`, `final` (living individuals and species per kind), `totals` (births and deaths per
  kind since tick 0, plus the initial counts), `series` (population per kind every `K` ticks), `state_hash`,
  `elapsed_seconds`, `ticks_per_second`, plus `totals.initial`, `sample_every`, `state_format`, `hash_algorithm` and
  `species_recognised` (ADR-0020).
- `--sample-every K`: spacing of the series (default: 1/100 of `N`, at least 1).
- `--metrics FILE`: also writes the evolution metrics (population, births and deaths, causes of death, species,
  generation, trait means and spread); layout in `docs/METRICS.md`.
- `--save FILE` / `--load FILE`: a checkpoint of the complete state (organisms with genomes, world, climate, clock,
  random generator, species records). A run of `A` ticks with `--save`, continued with `--load --ticks B`, gives the same
  `final`, `totals` and `state_hash` as one run of `A + B` ticks (tested; the CLI test script checks it).

Same seed, same configuration and same build give identical results, except `elapsed_seconds` and `ticks_per_second`.

### `batch`: several seeds and parameter sweeps

```sh
./evosim batch --config scenarios/demo.json --seeds 1,2,3 --ticks 10000 --out-dir results/demo
./evosim batch --config examples/config.json --seeds 1,2 --ticks 500 \
    --vary initial.plants=200,400 --vary herbivores.reproduction_energy=40,60 --csv --jobs 4 --out-dir results/sweep
```

- `--seeds S1,S2,...` (required), `--ticks N`, `--out-dir DIR` (created if missing).
- `--vary KEY=V1,V2,...` (repeatable): the cartesian product of all values is run; `KEY` is a configuration key in
  dotted form (`initial.plants`, `plants.seed_radius`, ...). Unknown keys and invalid values are rejected before the
  first run and nothing is written.
- `--sample-every K`, `--jobs J` (threads; the output does not depend on `J`), `--csv` (also writes `runs.csv` and
  `aggregates.csv`).
- Output: `DIR/seed-<seed>.json` for each run (same schema as `run`; with `--vary` in `DIR/case-NN/`), and
  `DIR/summary.json`, written last. The summary holds, per case and kind, the mean, minimum, maximum, population
  standard deviation and the number of extinct runs.

### `ui`: the world view in the browser

```sh
./evosim ui                                         # 127.0.0.1, ephemeral port; prints the URL
./evosim ui --port 8080 --config scenarios/demo.json  # the demo scenario on a fixed port
./evosim ui --smoke-test --config scenarios/demo.json  # headless check: exit 0 when the page rendered at tick >= 10
./evosim ui --screenshots DIR --config examples/config.json   # writes DIR/main.png (1280x807) and DIR/charts.png
```

Open the printed `http://127.0.0.1:PORT/` in a browser. Each cell is drawn in its climate colour, the organisms on top
(plant: green square, herbivore: amber circle, carnivore: red triangle). Controls: run (toggles to pause), step, reset, faster and
slower, save and load a checkpoint, drag to pan, wheel to zoom, double-click to fit. The inspector shows one organism (traits, energy, age,
generation, parents, species, tendencies). Charts: population over time, births and deaths per tick, species alive,
mean of a selected trait, and the distribution of a selected trait for each kind. The UI can edit the initial
parameters and start a new world from a preset, check and import or export a configuration as JSON, and download or
upload a checkpoint (the complete state). Stop the server with Ctrl+C.

Screenshots of the current build are in `docs/results/TASK-028/screenshots/`.

## Configuration

A configuration is a JSON object. Only the first three keys are required; every other key has a default. Unknown keys
and out-of-range values exit with status 2 and name the key. Example: `examples/config.json` (the example of
`docs/CONTRACT.md` section 3, the fixed keys only).

```json
{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}
```

| key | type | range | default | meaning |
|---|---|---|---|---|
| `seed` | integer | any `u64` | required | seed of the random generator |
| `world.width`, `world.height` | integer | 1 .. 4096 | required | grid size in cells (the torus wraps at both edges) |
| `initial.plants`, `.herbivores`, `.carnivores` | integer | 0 .. 1,000,000 | required | individuals at tick 0; no replenishment |
| `climate.season_length` | integer | 1 .. 100,000 | 240 | ticks per seasonal cycle |
| `climate.weather_amplitude` | real | 0 .. 1 | 0.15 | size of the weather variation relative to the seasonal swing |
| `plants.growth_rate` | real | 0 .. 1 | 0.1 | **accepted but has no effect** (superseded, see limitations) |
| `plants.reproduction_chance` | real | 0 .. 1 | 0.05 | chance per tick that a mature plant seeds |
| `plants.seed_radius` | integer | 0 .. 16 | 2 | dispersal radius in cells (Chebyshev, on the torus) |
| `plants.max_age` | integer | 1 .. 100,000 | 1500 | lifespan centre of plants, ticks |
| `herbivores.metabolism`, `carnivores.metabolism` | real | 0 .. 100 | 0.8, 1.2 | **accepted but has no effect** (superseded, see limitations) |
| `herbivores.reproduction_energy`, `carnivores.reproduction_energy` | real | 0 .. 1000 | 60, 90 | energy needed to breed |
| `herbivores.max_age`, `carnivores.max_age` | integer | 1 .. 100,000 | 300, 400 | lifespan centre, ticks |
| `genetics.mutation_rate` | real | 0 .. 1 | 0.002 | per locus, per reproduction |
| `genetics.mutation_strength` | integer | 1 .. 255 | 8 | largest step of one mutation |
| `species.distance` | real | 0 .. 1 | 0.06 | genetic distance threshold for one species |
| `species.check_interval` | integer | 1 .. 10,000 | 25 | ticks between species checks |
| `species.persistence_checks` | integer | 1 .. 1000 | 4 | consecutive checks needed to recognise a species |

The configuration formats: JSON is the required format and is supported by `--config`, the UI import and export.
TOML and YAML are not supported. Presets (`balanced`, `arid`, `continent`, `herbivore-only`) are available in the UI.
The authoritative definitions are `crates/evosim-core/src/config.rs` and `docs/decisions/ADR-0006`.

## The demo scenario

`scenarios/demo.json` is the demo configuration (64 x 48 cells, 400 plants, 120 herbivores, 20 carnivores, as the
example, with two non-fixed keys changed):

```json
{ "seed": 1, "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 },
  "plants": { "reproduction_chance": 0.2, "seed_radius": 4 } }
```

The one command that starts the demo in the browser:

```sh
./evosim ui --config scenarios/demo.json
```

How it was chosen: six candidate configurations were measured, each on tuning seeds 1 to 10 for 10,000 ticks, scored by the median coexistence length `L` (the first tick at which some kind has no living individuals). The
candidate with the highest median won (`docs/VERIFICATION.md` section 4 has all candidates). The chosen candidate was
then run once on held-out seeds 101 to 110. No mechanism was added; the demo changes only two configuration keys.
The demo's median is only 13 ticks above the example's on the held-out seeds (271.5 against 258.5), which is within the
spread of the seeds, so the demo is not a meaningfully better world.

## Measured coexistence

Plants, herbivores and carnivores coexisted for the following number of ticks (10,000-tick runs, `--sample-every 1`).
`L` is the first tick at which one of the three kinds has no living individuals; `L = 10,000` would mean all three
survived the whole run. The table gives the tick of each kind's extinction (`survives` = alive at tick 10,000).

Demo scenario (`scenarios/demo.json`), seeds 1 to 5, `docs/results/TASK-028/long-demo/`:

| seed | plants | herbivores | carnivores | L |
|---|---|---|---|---|
| 1 | survives | 317 | 230 | 230 |
| 2 | survives | 335 | 412 | 335 |
| 3 | survives | 572 | 374 | 374 |
| 4 | 1541 | 450 | 186 | 186 |
| 5 | 3812 | 569 | 178 | 178 |

Example configuration (`examples/config.json`), seeds 1 to 5, `docs/results/TASK-028/long-example/`:

| seed | plants | herbivores | carnivores | L |
|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 |
| 2 | survives | 480 | 385 | 385 |
| 3 | survives | 540 | 258 | 258 |
| 4 | 1547 | 487 | 262 | 262 |
| 5 | 5255 | 592 | 167 | 167 |

Summary:

- Demo, seeds 1 to 5: median `L` 230 (min 178). Example, seeds 1 to 5: median `L` 258 (min 157).
- Held-out seeds 101 to 110, each run once: demo median `L` 271.5 (min 103); example median `L` 258.5 (min 143,
  from the TASK-027 record).
- Seeds with all three kinds alive at tick 10,000: **0 of 5** (demo and example), **0 of 10** (demo, held-out) and
  0 of 20 (example, tuning seeds 1 to 20, TASK-027).

**The goal of a food chain that lasts as long as possible is not reached.** In every run here one kind dies out
between tick 157 and tick 385 in the ten 10,000-tick runs (103 in the held-out runs), and the carnivores are usually the first to go, after the herbivores have been
eaten and carnivore births are close to zero. The mechanisms that would fix this (for example the handling time after
a kill, or a larger breeding reserve) were not implemented in this task; see the limitations. No rule was added that
looks at population counts, and none was added to keep a kind alive.

## Tests

```sh
./scripts/test.sh
```

This one command runs, in order: the ADR and record checks (`scripts/check_adrs.sh`), the workspace unit and
integration tests (`cargo test --workspace --locked`), `./setup.sh`, `./build.sh`, the black-box checks of `./evosim` and
`dist/evosim` (exact output, exit codes, working directory independence, `ldd`), the headless `run` and `batch`
checks (same-seed determinism, checkpoint split runs, sweep validation), the demo scenario and the example
configuration run for 10,000 ticks with seeds 1 to 3, the browser smoke test and screenshots for the demo and the
example configuration, and the release-mode randomised invariant tests (200 random cases per property).
It stops at the first failure and exits non-zero. The evidence and the commands of each requirement are in
`docs/VERIFICATION.md`.

## Known limitations

- **Coexistence is not reached.** See "Measured coexistence". The demo is the best of six parameter candidates tried;
  it is not a tuned equilibrium, and no result of any seed keeps the three kinds alive to 10,000 ticks.
- **Three configuration keys have no effect**: `plants.growth_rate` (replaced by the regrowth constant of ADR-0012),
  `herbivores.metabolism` and `carnivores.metabolism` (replaced by the base costs of ADR-0015 and ADR-0016). They are
  accepted and validated so that existing files keep working. Wiring or removing them is a later decision.
- Carnivores almost never reproduce in practice (0 to 4 births per seed in 10,000 ticks), and herbivores breed rarely
  (0 to 31 births per seed). Attack efficiency and the absence of a handling time are the measured causes; see
  `docs/BALANCE.md`.
- Plant extinction after 1,500 to 8,000 ticks happens in some seeds; its cause is not analysed.
- Performance: about 1,000 ticks per second at 2,000 organisms on the reference machine in `docs/PERFORMANCE.md`
  (target 100). Other machines were not measured.
- Floating-point results are reproducible on the same machine and build; differences between platforms are allowed
  by the contract but were not tested.
- The browser UI needs Chromium only for its headless checks; the interactive UI runs in any modern browser, but only
  Chromium 131 was tested.
- The sample of seeds is small (5 to 20 per configuration); the coexistence numbers are estimates.

## Layout

```
Cargo.toml, Cargo.lock      workspace (Cargo.lock committed; binary product)
crates/evosim-core/         simulation library (no UI or CLI dependency)
crates/evosim-cli/          binary `evosim` (commands, argument parsing, exit codes)
crates/evosim-ui/           local browser UI server and web assets (web/)
setup.sh build.sh evosim    contract entry points (docs/CONTRACT.md section 1)
examples/                   example configurations (config.json: CONTRACT section 3; perf-2000.json; ui-1000.json)
scenarios/demo.json         the demo scenario
scripts/test.sh             the one test command (ADR-0005)
scripts/check_adrs.sh       ADR and record checks
scripts/perf.sh             ticks per second and phase profile (docs/PERFORMANCE.md)
scripts/balance_*.py        extinction tables and death causes from batch and metrics output (python3 -I)
docs/                       product brief, contract, decisions (ADRs), architecture, balance, performance, verification
docs/results/               raw evidence of the balance, verification and demo runs
tasks/                      task specifications and phase handoffs
```

## Git

The workspace is a local Git repository with no remote. Do not add one. Build output (`target/`, `dist/`) is ignored.

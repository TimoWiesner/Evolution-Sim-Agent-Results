# TASK-015 REVIEW cycle 1: carnivore hunting

Verdict: PASS. Independent check of the IMPLEMENT diff (commit 8234ab0) against the task's five acceptance points.

## Acceptance points
1. Pursuit within vision, attacks only from same/adjacent cell: met.
   - `hunting::tests::pursuit_uses_vision_range` (vision 1: prey at distance 2 ignored, distance 1 pursued),
     `hunting::tests::attacks_reach_only_same_or_adjacent_cells_including_seams` (distance 2 across the seam: no attempt and no
     draw; distance 1 across the seam and same cell: attempt), `hunting::tests::satiated_carnivore_neither_pursues_nor_attacks`,
     `sim::hunting_tests::attack_from_across_the_seam_is_resolved_and_outside_reach_is_not`.
   - Code read: `attack` uses `spatial.within(cell, HUNT_REACH=1, Herbivore)` after all carnivore moves; `carnivore_heading`
     uses the `perceive` list, which is limited by `vision_radius`.
2. Outcome depends on both traits and the generator; kills and escapes occur: met.
   - `many_attacks_give_kills_and_escapes` (2,000 seeded attacks, both kinds occur, fraction within 0.05 of the formula),
     `fast_strong_attackers_kill_more` (1300+ vs under 200 kills of 2,000), `attack_draws_exactly_one_random_number_when_it_attempts`.
   - `attack_chance` is pure, clamped to [0.05, 0.9], and uses speed and strength of both animals plus prey caution.
3. Killed herbivore dies once, cause Predation, cannot be eaten twice: met.
   - `kill_marks_prey_once_as_predation`, `second_attacker_finds_no_second_kill`, `dead_prey_still_in_the_index_is_not_a_target`,
     `sim::hunting_tests::predation_counts_once_in_bookkeeping_over_a_mixed_run` (150 ticks, check_balance and check_spatial each tick,
     each predated id recorded once, removed from store and index).
   - Code read: `damage(health, Predation)` sets the cause only when none is set; `nearest_living_herbivore` filters `is_alive`.
     `drain_energy` sets Starvation the moment energy reaches 0, so a herbivore with energy 0 is not alive and cannot be attacked.
4. Gain at most prey energy: met.
   - `gain_never_exceeds_prey_energy` (prey energies 0.5 to 100), `sim::...gains_at_most_the_prey_energy` (exact arithmetic).
   - Gain = 0.8 * min(e, 30) <= e for e >= 0; living prey always has e > 0.
5. Hunting costs energy on success and failure; carnivore without prey starves: met.
   - `sim::hunting_tests::carnivore_pays_attack_and_base_costs_and_gains_at_most_the_prey_energy` (200 seeds, kills and escapes,
     exact per-tick energy), `carnivore_without_prey_starves` (energy falls every tick, Starvation death, no predation),
     `carnivore_costs_add_movement_base_and_thermal`.

## Other checks
- G-051 (TASK-014 REVIEW): `movement::plan_moves` maps `Away(own cell)` to `wander`. Test
  `movement::tests::away_from_a_threat_on_the_same_cell_wanders` passes. Fixed.
- Several carnivores on one herbivore: sequential ascending id, first successful roll kills, later carnivores retarget or make no
  attempt, only the killer gains. Documented in ADR-0016 and covered at unit level.
- Determinism: `sim::hunting_tests::same_seed_same_hunts_and_different_seeds_differ` passes.
- Phase order: herbivores move and feed before carnivores; the spatial index is updated by `move_organism`, so reach uses current
  cells. Deaths removes killed prey afterwards.
- No new state. The checkpoint layout is unchanged.

## Commands run in REVIEW (exit codes)
- `cargo test -p evosim-core --locked`: 0 (313 passed, 1 ignored, 0 failed).
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: 0, no warnings.
- `rustfmt --edition 2021 --check` on hunting.rs, movement.rs, sim.rs: 0.
- `bash scripts/check_adrs.sh`: 0 (153 checks, failed=0), also after the status edit.
- `bash scripts/test.sh`: 0 ("ALL TESTS PASSED").
- `cargo build --release --locked -p evosim-cli`: built.
- `./evosim run --config ... --ticks 10`: exit 2, "unknown command 'run'". The headless run is not implemented yet, so the
  informational default-config survival run could not be done. Not a gate for this task.

## Edits made in REVIEW
- `docs/decisions/ADR-0016-...md` status: Proposed -> Accepted. `docs/decisions/README.md` index line updated.
- `docs/STATE.md` REVIEW section appended. `docs/ARCHITECTURE.md` REVIEW note appended.
- No product code, tests, task.md/task.json, benchmark files, or commits.

## Non-blocking gaps
- G-052: no sim-level test with two carnivores on one herbivore (unit-level only).
- G-053: long-run carnivore survival not measured (no headless run command yet). TASK-018 and TASK-027.
- G-054: the `core::ecology` row in `docs/ARCHITECTURE.md` still lists hunting and handling time. The implemented rules are in
  `core::hunting`, and handling time is approximated by satiation.
- Carried: TASK-013 REVIEW gap 2 (reversed-order `plan_moves` test) and G-046 (stale overlay query cost, not measured).
- Attack constants are uncalibrated (ADR-0016; TASK-018, TASK-027).

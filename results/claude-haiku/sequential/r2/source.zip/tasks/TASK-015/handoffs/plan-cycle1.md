# TASK-015 PLAN cycle 1: carnivore hunting

Design: `docs/decisions/ADR-0016-carnivore-hunting-and-predation.md` (Proposed). This file is the ordered implementation plan.
No product code changed in PLAN.

## Baseline (checked in PLAN)
- `export PATH=/opt/rust/cargo/bin:$PATH; cargo test -p evosim-core --locked` -> exit 0, 294 passed, 1 ignored (log of the run:
  `/tmp/plan15_baseline.log`, not kept in the workspace).
- `git remote -v | wc -l` = 0. `git status` clean at start.

## Decisions (summary; full text in ADR-0016)
- Pursuit: nearest living herbivore in vision, `Towards`, only while energy < `SATIATION_CARNIVORE` (70); else `Wander`.
- Reach 1 (own or adjacent cell, after all carnivore moves), one attempt per carnivore per tick, nearest prey, ties lowest id.
- Chance: `clamp(0.5 + 0.3*(c.speed-p.speed)/4 + 0.2*(c.strength-p.strength)/10 - 0.3*p.caution, 0.05, 0.9)`; one `rng.chance` per attempt.
- Kill: `damage(prey.health, Predation)`; carnivore gains `0.8 * min(prey.energy, 30)` (at most prey energy).
- Escape: no effect on prey. Attack cost 0.5 on every attempt.
- Costs per tick: movement (ADR-0014), base 0.4, thermal (`feeding::thermal_cost`) at the cell after the move.
- Several carnivores on one prey: sequential in ascending id; a dead prey is not attacked again; a carnivore with no prey in
  reach makes no attempt and pays no attack cost.
- G-051 fix (TASK-014 REVIEW gap): `plan_moves` turns `Away` with the threat on the own cell into a `Wander` step.

## Ordered steps (IMPLEMENT)
1. **movement.rs (G-051)**: in `plan_moves`, if `Heading::Away(threat)` and `threat == o.cell()`, use `wander`. Add a unit test
   `away_from_a_threat_on_the_same_cell_wanders` (step count = steps, cell on torus). Update ADR-0015 wording only if needed.
2. **hunting.rs (new, `crates/evosim-core/src/hunting.rs`, `pub mod hunting` in `lib.rs`)**. Depends on `entities`, `spatial`,
   `movement`, `feeding` (`thermal_cost` only), `rng`, `world`. Contents:
   - consts `HUNT_REACH: u32 = 1`, `SATIATION_CARNIVORE: f32 = 70.0`, `MEAL_MAX: f32 = 30.0`, `ASSIMILATION_CARNIVORE: f32 = 0.8`,
     `ATTACK_COST: f32 = 0.5`, `BASE_COST_CARNIVORE: f32 = 0.4`, `P_BASE 0.5`, `W_SPEED 0.3`, `W_STRENGTH 0.2`, `W_CAUTION 0.3`,
     `P_MIN 0.05`, `P_MAX 0.9`.
   - `pub fn attack_chance(attacker: &Traits, prey: &Traits, prey_caution: f32) -> f64` (pure, clamped).
   - `pub fn carnivore_heading(entities: &Entities, spatial: &SpatialIndex, o: &Organism, perceived: &[OrganismId]) -> Heading`
     (ascending perceived; herbivores only, living only; satiation check).
   - `pub enum AttackOutcome { NoPrey, Kill { prey: OrganismId, gained: f32 }, Escape { prey: OrganismId } }`.
   - `pub fn attack(entities: &mut Entities, spatial: &SpatialIndex, rng: &mut Rng, id: OrganismId) -> AttackOutcome`
     (checks carnivore alive and below satiation; picks nearest living herbivore in reach; one `rng.chance`; kill or escape;
     does not charge costs; the phase charges `ATTACK_COST` for `Kill`/`Escape`).
   - `pub fn carnivore_costs(distance: u32, speed: f32, temperature: f32) -> f32` = movement + base + thermal (pure).
3. **sim.rs**: replace the Carnivores arm (`animal_phase(Kind::Carnivore)`) with `carnivore_phase()`:
   - plan: `movement::plan_moves(..., Kind::Carnivore, rng, |o, p| hunting::carnivore_heading(&self.entities, &self.spatial, o, p))`;
   - apply moves in ascending id via `move_organism`;
   - attack in ascending id via `hunting::attack`; charge `ATTACK_COST` when outcome is not `NoPrey`;
   - charge costs (`carnivore_costs`) for every planned carnivore that is still alive, ascending id.
   - `animal_phase` becomes unused for carnivores; remove it if no caller remains (herbivores use `herbivore_phase`).
   - Keep the Deaths phase unchanged (predation kills are removed there; `spatial.remove` already runs for every death).
4. **Tests (hunting.rs unit tests)**: see ADR-0016 Verification strategy. Names planned:
   `attack_chance_stays_in_bounds_and_is_monotone`, `many_attacks_give_kills_and_escapes`, `fast_strong_attackers_kill_more`,
   `kill_marks_prey_once_as_predation`, `second_attacker_finds_no_second_kill`, `gain_never_exceeds_prey_energy`,
   `attacks_reach_only_same_or_adjacent_cells_including_seams`, `attack_draws_exactly_one_random_number`,
   `satiated_carnivore_neither_pursues_nor_attacks`, `pursuit_uses_vision_range`.
5. **Tests (sim.rs `carnivore_tests` module)**: `carnivore_pays_attack_and_base_costs_on_escape_and_kill` (exact energy
   arithmetic for one tick), `carnivore_without_prey_starves`, `predation_counts_once_in_bookkeeping` (`check_balance` each tick),
   `mixed_500_tick_run_keeps_index_and_balance`, `same_seed_same_hunts_and_different_seeds_differ`.
   Adjust existing tests only with a reason written in the IMPLEMENT note: `moving_organism_starves_through_the_phase_and_leaves_the_index`
   (carnivore, energy 1.0, expected to still starve), and `a_tick_moves_animals...` is herbivore-only (no change expected).
6. **ADR-0016**: after tests pass, set Status to Accepted at REVIEW (not in IMPLEMENT); add implementation notes.
   Add `ADR-0016-carnivore-hunting-and-predation.md` to the `ADRS` list in `scripts/check_adrs.sh`, and a line in
   `docs/decisions/README.md`. Update `docs/ARCHITECTURE.md` (module table row `core::hunting`, TASK-015 note).
7. **Verification commands for IMPLEMENT** (exit codes recorded in the handoff):
   - `cargo test -p evosim-core --locked`
   - `cargo test --workspace --locked`
   - `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`
   - `rustfmt --edition 2021 --check` on changed files only (NOT lib.rs: it formats every child module; see TASK-013 IMPLEMENT note)
   - `bash scripts/check_adrs.sh`
   - `bash scripts/test.sh` (full gate)

## Test evidence strategy for the acceptance points
- Pursuit within vision and attacks only from same/adjacent cell: unit tests in `hunting` plus one sim-level test.
- Outcome depends on both traits and on the generator: sweep test (kills and escapes both > 0 over >= 2000 seeded attacks) and
  trait-contrast test (fast/strong vs slow/weak).
- Single death with predation, no double eating: `kill_marks_prey_once`, `second_attacker_finds_no_second_kill`, bookkeeping test.
- Gain <= prey energy: sweep test.
- Costs on success and failure; starvation without prey: sim-level tests above.

## Risks
- R1 Carnivore collapse: carnivores with base 0.4 + move + thermal costs and only 20 founders may die out quickly in the
  default configuration. Expected and allowed; calibration in TASK-018/027. Not measured yet (no run in PLAN).
- R2 Behaviour change for existing TASK-013 tests that use carnivores (see step 5). Mitigation: run the full suite first.
- R3 Performance: an extra `within` query per carnivore per tick; G-046 stale-overlay cost still open. Not measured.
- R4 Attack chance constants are a guess; the sweep tests check shape, not calibration.
- R5 Satiation as a handling-time substitute: a carnivore at energy >= 70 stops hunting, which may keep carnivore energy near
  70 when prey is plentiful. Documented; measured in TASK-018.

## Open gaps carried
- TASK-013 REVIEW gap 2 (reversed-order `plan_moves` test) remains open: not an acceptance point; do it only if cheap.
- G-046 (stale overlay cost), G-045/TASK-022 (checkpoint must save new state if any: none is added by TASK-015).

## System dependencies
None new. Toolchain: `export PATH=/opt/rust/cargo/bin:$PATH`.

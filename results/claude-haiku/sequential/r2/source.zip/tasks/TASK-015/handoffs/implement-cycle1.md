# TASK-015 IMPLEMENT cycle 1: carnivore hunting

Design: `docs/decisions/ADR-0016-carnivore-hunting-and-predation.md` (Proposed until REVIEW). Plan: `plan-cycle1.md`.
Code: `crates/evosim-core/src/hunting.rs` (new), `sim.rs` (`carnivore_phase`, `hunting_tests`), `movement.rs` (G-051), `lib.rs`.

Acceptance points and where they are tested:
- Pursuit within vision, attacks only from same/adjacent cell: `hunting::tests::pursuit_uses_vision_range`,
  `attacks_reach_only_same_or_adjacent_cells_including_seams`, `satiated_carnivore_neither_pursues_nor_attacks`;
  sim: `attack_from_across_the_seam_is_resolved_and_outside_reach_is_not`.
- Outcome depends on both traits and on the generator; kills and escapes both occur:
  `many_attacks_give_kills_and_escapes` (2,000 seeded attacks), `fast_strong_attackers_kill_more`,
  `attack_draws_exactly_one_random_number_when_it_attempts`.
- Killed herbivore dies once with Predation, cannot be eaten twice: `kill_marks_prey_once_as_predation`,
  `second_attacker_finds_no_second_kill`, `dead_prey_still_in_the_index_is_not_a_target`,
  sim: `predation_counts_once_in_bookkeeping_over_a_mixed_run`.
- Gain at most prey energy: `gain_never_exceeds_prey_energy`; sim: `carnivore_pays_attack_and_base_costs_and_gains_at_most_the_prey_energy`.
- Hunting costs energy on success and failure; starvation without prey: `carnivore_pays_...` (exact arithmetic),
  `carnivore_without_prey_starves`, `carnivore_costs_add_movement_base_and_thermal`.

Commands and exit codes (see the JSON `tests` list): core tests 0 (313 passed, 1 ignored), workspace tests 0, clippy 0 without
warnings, rustfmt check on the three touched files 0, `scripts/check_adrs.sh` 0 (153 checks), `scripts/test.sh` 0.

Deviations: `AttackOutcome::NoAttempt` (plan said `NoPrey`). Two of my own statistical test expectations were wrong on the first
run (they ignored the caution term); corrected to use `attack_chance` directly. The engine was not changed for that.

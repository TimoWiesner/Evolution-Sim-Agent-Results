# TASK-003 PLAN cycle 1: typed configuration and presets

Inputs read: AGENTS.md, docs/PROJECT.md, docs/CONTRACT.md (sections 2, 3, 5, 7), docs/STATE.md,
docs/ARCHITECTURE.md (module table: `core::config`), ADR-0001 (no serde, hand-written JSON), ADR-0004 (placeholder
keys `mutation_rate`, `mutation_strength`, `species_distance`, `species_check_interval`, persistence checks),
ADR-0005, tasks/TASK-003/task.md and task.json, TASK-002 handoffs (review cycle 1 PASS), dependents TASK-005,
TASK-019, TASK-025 (they read the configuration; TASK-019 needs the fixed keys and error exit 2).
Environment checked: cargo 1.100.0, rustc 1.100.0; `cargo test -p evosim-core --locked` runs (0 tests yet).

## Decisions (full rationale in docs/decisions/ADR-0006-configuration-format-and-presets.md)
1. JSON only, hand-written parser and canonical writer (no crate). TOML/YAML not added.
2. Unknown keys are an error, reported with the full dotted path.
3. Fixed keys required; every other parameter has a default and its group may be absent.
4. Parameter groups: `climate`, `plants`, `herbivores`, `carnivores`, `genetics`, `species`; 24 tunable keys with
   type, inclusive range and default as in the ADR table. Genetics/species keys are the ADR-0004 placeholders.
5. Strict typing: integers are JSON numbers without `.`/exponent; `64.0` for a width is a wrong-type error.
6. `seed` is u64 (0 .. 2^64-1). Negative seeds are out of range.
7. Four presets: `balanced`, `arid`, `continent`, `herbivore-only`; lookup by name, no CLI option here.
8. `to_json` writes all keys in fixed order; reals use shortest round-trip formatting so load(save(c)) == c.

## Files (all new or changed in IMPLEMENT; no other crate touched)
- `crates/evosim-core/src/lib.rs`: add `pub mod config;` (keep the existing `CONTRACT_VERSION` and its test).
- `crates/evosim-core/src/config.rs`: `pub struct Config` with nested structs `World`, `Initial`, `Climate`, `Plants`,
  `Herbivores`, `Carnivores`, `Genetics`, `Species`; all `#[derive(Clone, Debug, PartialEq)]`.
  `Config::new(seed, width, height, initial) -> Result<Config, ConfigError>` (fills defaults, validates);
  `Config::from_json(&str)`, `Config::to_json(&self) -> String`, `Config::load(&Path)`, `Config::save(&self, &Path)`.
  `pub struct ConfigError { pub key: Option<String>, pub message: String }` with `Display` that always includes the key
  when there is one. Field-level default constants are `pub const` (e.g. `DEFAULT_PLANTS_GROWTH_RATE`).
  A single `fn validate(&Config)` is not needed for construction because `from_json` builds through typed setters;
  implement validation in one table-driven helper: `check_int(key, value, min, max)`, `check_real(key, value, min, max)`.
- `crates/evosim-core/src/config/json.rs`: `enum Value { Null, Bool(bool), Int(i128), Real(f64), Str(String),
  Array(Vec<Value>), Object(Vec<(String, Value)>) }`; recursive-descent parser with line/column in error text;
  rejects trailing data, duplicate keys in an object, leading `+`, leading zeros, NaN/Infinity; `write_pretty`.
  Integers beyond i128 are a parse error with no key ("integer too large").
- `crates/evosim-core/src/config/presets.rs`: `pub const NAMES: &[&str]`, `pub fn get(name: &str) -> Option<Config>`.
- `crates/evosim-core/src/config/tests.rs` (`#[cfg(test)] mod tests;` in config.rs): all tests below.
- `docs/decisions/ADR-0006-...md` (done in PLAN), `docs/ARCHITECTURE.md` (config row points to ADR-0006 and
  the key list), `docs/STATE.md` (PLAN block).

## Ordered IMPLEMENT steps
1. Write `config/json.rs` and its unit tests first (parse each value type, escapes `\uXXXX` and `\"`, nested
   objects, error positions, duplicate key, trailing comma, leading zero, `1.` invalid, `1e400` parses to inf
   and is rejected later by config range checks).
2. Write `config.rs`: types, defaults, `Config::new`, `from_json` (walk object, reject unknown keys, check types,
   check ranges, required keys), `to_json`, `load`/`save`.
3. Write `config/presets.rs` with the four presets; each built through `Config::new` plus field overrides,
   so validation runs for them.
4. Write `config/tests.rs`; run `cargo test -p evosim-core --locked`; fix until green.
5. Run `cargo test --workspace --locked`, `bash scripts/check_adrs.sh`, `bash scripts/test.sh`.
6. Record evidence (commands, exit codes, test counts) in `tasks/TASK-003/handoffs/implement-cycle1.md/.json`
   and update docs/STATE.md.

## Tests (required by task.md; each named case must exist)
Acceptance:
- `fixed_keys_only_file_is_valid`: the contract example text loads; all defaults applied.
- `zero_initial_populations_are_valid`: `initial` all zero loads and round-trips.
- `every_extra_parameter_has_default`: a file with only fixed keys equals `Config::new(...)` with defaults; also
  every group key absent yields default.
- Wrong type, one test per kind of value: string for `world.width`, real `64.0` for `world.width`, bool for `seed`,
  array for `initial`, object for `world.height`, string for `climate.season_length`, integer where a real is
  expected is accepted (`plants.growth_rate: 1` -> ok, as a real) - tested as valid.
  Each asserts `err.key == Some("world.width")` and `message` mentions the expected type.
- Missing fixed key: remove each of `seed`, `world`, `world.width`, `world.height`, `initial`, `initial.plants`,
  `initial.herbivores`, `initial.carnivores` (one test per key or a table-driven test); asserts key named.
- Out of range: width 0, width 4097, height 0, `width*height` over the cap (e.g. 4096x4096), negative initial,
  initial above 1000000, seed -1, `genetics.mutation_strength` 0 and 256, `plants.growth_rate` -0.1 and 1.5,
  `1e400`, `climate.season_length` 0, `species.check_interval` 0. Asserts the key named.
- Unknown keys: top-level `"foo"`, nested `"climate.weathr"`, unknown group `"fish"`. Asserts full path in key.
- Parse errors: trailing comma, unclosed brace, duplicate key `"seed"` twice, leading zero, NaN; each has
  `key == None` and a line/column in the message.
- Round trip: `from_json(to_json(c)) == c` for defaults, every preset, a random-ish grid of values (boundary
  values min and max of each range, e.g. `1e-300`, `1e300`, `0.1+0.2`, u64::MAX seed).
- Presets: `NAMES` has four entries; each `get(name)` is `Some` and valid; unknown name is `None`; pairwise
  distinct (differ in at least one parameter with a different value, plus at least one pair differing in world
  size); `balanced` equals contract example with defaults.
- Writer: `to_json` output contains every key once, in the fixed order.
- File round trip: `save` then `load` through a temp directory under `std::env::temp_dir()` with a unique name
  (process id); removed after the test.
- Float edge: `1e-7` written as `1e-7` and read back equal.

## Risks
- Hand-written JSON parser bugs (escapes, number grammar). Mitigation: strict grammar, parser tests, and only
  ASCII keys are used by this project; string values are never valid parameters, so escape handling matters
  only for error text and must not panic.
- Float formatting: `Debug` of f64 is shortest round-trip on Rust 1.100; verified by the round-trip test.
- Default values are placeholders (ADR-0004); calibration in TASK-009 may change them, which changes `state_hash`
  for the same seed (allowed, but documented here).
- Strictness (unknown keys error) may reject files written for later tasks. Mitigation: the set of keys is in
  ADR-0006; later tasks add keys to the table, and tests cover the table.
- The cross-field rule is only the cell-count cap; energy and age combinations are unchecked (documented).
- Time limit: 30 min per phase; IMPLEMENT must keep the parser small (~250 lines).

## Not part of this task
- Using parameters in the simulation (TASK-005 onward), CLI `--preset` or config-file option of `run` (TASK-019).
- TOML/YAML import/export (optional; not planned).

## Next steps
- IMPLEMENT (TASK-003 cycle 1) follows the ordered steps above.
- Keep `crates/evosim-core` free of UI/CLI references (check_adrs.sh greps for crate names; avoid those words
  in doc comments).

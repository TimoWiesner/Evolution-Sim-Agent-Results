# TASK-003 IMPLEMENT cycle 2 — notes

Implements `tasks/TASK-003/handoffs/plan-cycle2.md`, closing REVIEW cycle 1 gaps G-019, G-020, G-016 and G-021 (wording).
Machine-readable record: `implement-cycle2.json`.

## Result
- `cargo test -p evosim-core --locked`: 44 passed, exit 0 (43 config tests + contract test).
- `cargo clippy -p evosim-core --locked --all-targets`: exit 0, 0 warnings.
- `cargo test --workspace --locked`: exit 0 (core 44, cli 9).
- `bash scripts/check_adrs.sh`: exit 0, checks=54 failed=0 (before and after the ADR edit).
- `bash scripts/test.sh`: exit 0, "ALL TESTS PASSED".
- `git remote -v | wc -l`: 0.

## Changes
- `config/json.rs`: `Value::BigInt(String)`; integer literals beyond i128 are kept as text. Surrogate pairs decode to one
  scalar; a lone low surrogate, a high surrogate without a following `\u` escape, or a high surrogate followed by a
  non-low escape is a parse error with line and column.
- `config.rs`: `kind()` reports `integer` for `BigInt`; `int()` reports `"<literal>" is out of range min..=max` with the key;
  `real()` reads `BigInt` as `f64` (infinity when too large, rejected as out of range); `save()` creates parent directories.
- `config/tests.rs`: `json_integer_too_large_is_error` replaced by `json_big_integer_is_kept_as_text`; added surrogate-pair
  tests (valid pair, lone high, lone low), oversized-integer tests for `seed` (positive and negative), `world.width`,
  a real key and an object key, and `save_creates_parent_directories`.
- `docs/decisions/ADR-0006-...md`: implementation notes for cycle 2; status still Proposed.
- `docs/STATE.md`: status line and an IMPLEMENT (cycle 2) block.

## Deviations from the plan
- None in design. Test counts: the plan did not give totals; the actual count is 43 config tests plus the contract test.
- The `real()` path for `BigInt` uses `unwrap_or(f64::INFINITY)`. Parsing a validated digit string cannot fail in practice;
  the fallback keeps the function free of `unwrap`.

## Open items for REVIEW
- Confirm G-019, G-020, G-016 and G-021 by reading the code and the new tests.
- ADR-0006 status to Accepted only if REVIEW agrees (it is still Proposed).
- Not covered by any test: a surrogate pair combined with a BigInt value, and the CLI (no CLI command exists yet, TASK-019).

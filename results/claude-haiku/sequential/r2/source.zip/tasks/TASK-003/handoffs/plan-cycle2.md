# TASK-003 PLAN cycle 2: replan closing REVIEW cycle 1 gaps

Inputs read: AGENTS.md, docs/PROJECT.md, docs/CONTRACT.md (sections 3, 4, 5.4), docs/STATE.md, docs/ARCHITECTURE.md,
ADR-0006 (Proposed), tasks/TASK-003/task.md and task.json, tasks/TASK-003/handoffs/{plan,implement,review}-cycle1.{md,json},
the current sources `crates/evosim-core/src/config.rs`, `config/json.rs`, `config/tests.rs`, `config/presets.rs`.
Dependents: TASK-005 (seeded randomness from config), TASK-019 (`run` reads config, exit 2 on invalid config),
TASK-021 (batch), TASK-024 (ui --config), TASK-025 (presets, export/import of configuration JSON). None has a handoff yet.
Environment: `git remote -v | wc -l` = 0; `bash scripts/check_adrs.sh` = checks=54 failed=0 (run in this phase, exit 0).
No code changed in PLAN; only ADR-0006 and docs/STATE.md.

## Gaps to close (from tasks/TASK-003/handoffs/review-cycle1.json)
| Gap | Blocking | Closure in IMPLEMENT |
|---|---|---|
| G-019: integer literal beyond i128 gives "JSON syntax error ... integer too large" with no key | yes | `Value::BigInt(String)`; range or type error names the key (see below) |
| G-020: valid surrogate pairs (`😀`) rejected | no | decode pairs; lone or misordered surrogates still rejected |
| G-021: ADR-0006 names `config::validate`, code is `from_fields` | no | ADR wording fixed in this phase (done); status set to Accepted in REVIEW only |
| G-016: `Config::save` does not create parent directories | no | `create_dir_all` on the parent before writing |

## Decisions
1. **Oversized integers (G-019).** `json.rs` keeps an integer literal that does not fit `i128` as
   `Value::BigInt(String)` holding the literal text with its sign. It is not a parse error.
   - Integer key (`int()` in `config.rs`): `BigInt` -> `ConfigError::key(key, "<literal> is out of range <min>..=<max>")`.
   - Real key (`real()`): `BigInt` -> `f64` parse of the text (huge magnitudes become `inf`, which the existing range
     check rejects as out of range).
   - Any other kind: `kind()` returns `"integer"` for `BigInt`, so wrong-type errors read `expected string, found integer`.
   - Rationale: keeps the message in the same form as other range errors; no new error class; no `u128`/big-int crate.
2. **Surrogate pairs (G-020).** In `hex4`-based `\u` handling: a value in `D800..=DBFF` must be followed by `\u` and a
   value in `DC00..=DFFF`; the pair is combined as `0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00)`. A high surrogate
   without a valid low escape, or a lone low surrogate, is `invalid surrogate` (parse error, line and column).
3. **Save (G-016).** `Config::save` calls `std::fs::create_dir_all` on `path.parent()` when it is non-empty, then writes.
   Errors keep the `cannot write <path>: <io error>` form.
4. **Unchanged.** Grammar, unknown-key rule, defaults, ranges, presets, `to_json` format and every existing test
   expectation stay as they are, except `json_integer_too_large_is_error`, which is replaced (see tests).
5. **ADR-0006.** Wording fixed (`from_fields`). Its "Implementation notes" must be updated in IMPLEMENT: the sentence
   "integers beyond i128 are a parse error" becomes the BigInt rule above. Status stays Proposed until REVIEW.
6. **Scope.** No change to any crate other than `evosim-core`; no CLI change; no new dependency.

## Ordered IMPLEMENT steps
1. `config/json.rs`: add `Value::BigInt(String)`; in `number()` return it on `i128` parse overflow; add the surrogate-pair
   logic to the `\u` branch; keep `write` unchanged for values built by the code (BigInt is only produced by the parser,
   writer prints the text if it ever sees one).
2. `config.rs`: `kind()` handles `BigInt` as integer; `int()` and `real()` handle `BigInt` as above; `save()` creates the
   parent directory. Update the `Value` import if needed. Keep `from_fields` as the only validation point.
3. `config/tests.rs`: replace `json_integer_too_large_is_error` by the tests below; add the others. Keep all 34 existing
   config tests passing.
4. `docs/decisions/ADR-0006-...md`: update the implementation notes (BigInt rule, surrogate pairs, save creates parents).
5. Run and record: `cargo test -p evosim-core --locked`, `cargo clippy -p evosim-core --locked --all-targets`,
   `cargo test --workspace --locked`, `bash scripts/check_adrs.sh`, `bash scripts/test.sh`.
6. Record in `tasks/TASK-003/handoffs/implement-cycle2.{md,json}` and `docs/STATE.md`.

## Tests (new or changed; names are the required ones)
- `huge_integer_for_seed_names_key`: `"seed": 10^40` -> key `seed`, message contains `out of range 0..=18446744073709551615`.
- `huge_negative_integer_for_seed_names_key`: `"seed": -10^40` -> key `seed`, `out of range`.
- `huge_integer_for_width_names_key`: `world.width` = 10^40 -> key `world.width`, `out of range 1..=4096`.
- `huge_integer_for_real_key_names_key`: `plants.growth_rate` = 10^40 (integer literal) -> key `plants.growth_rate`, `out of range`.
- `huge_integer_for_string_key_is_wrong_type`: `world.width` as string is unchanged; a huge integer where a string is
  expected -> key named, `found integer`. (Use `climate` as an object key, i.e. `"climate": 10^40` -> key `climate`,
  `expected object, found integer`.)
- `json_big_integer_is_kept_as_text`: `json::parse("1000...0")` (45 digits) -> `Value::BigInt` with that text (replaces `json_integer_too_large_is_error`).
- `json_surrogate_pair_decodes`: `"😀"` -> `"😀"`.
- `json_lone_high_surrogate_is_error`: `"\uD83D"` and `"\uD83Dx"` -> error, message contains `surrogate`.
- `json_lone_low_surrogate_is_error`: `"\uDE00"` -> error.
- `json_high_then_non_low_escape_is_error`: `"\uD83DA"` -> error.
- `save_creates_parent_directories`: save to `<temp>/<pid>/a/b/config.json`, then load equals; directory removed after.
- Existing `out_of_range_values_name_the_key` and round-trip tests stay as they are.

## Risks
- `f64` parse of a very long literal: Rust's parser is correct for all lengths; an input of many thousands of digits is
  still O(n). Not a DoS concern for a local file; no limit added.
- A BigInt for a real key with a mantissa-like form is not affected (only digits without `.`/`e` reach BigInt).
- Changing an error message text may break a test that matches the old "integer too large" text; only
  `json_integer_too_large_is_error` does, and it is replaced.
- Time: the change is about 60 lines plus about 12 tests; within the phase budget.

## Not part of this task
- CLI handling of config errors and parent directories for `run --save` (TASK-019).
- Using any parameter in the simulation (TASK-005 onward).
- Calibrating the genetics and species defaults (TASK-009).

## Next steps
- IMPLEMENT cycle 2 follows the ordered steps above; then REVIEW cycle 2 re-checks every Must-have point and the gap table.

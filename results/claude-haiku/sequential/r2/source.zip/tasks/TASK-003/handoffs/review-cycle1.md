# TASK-003 REVIEW cycle 1 — notes

Verdict: FAIL. One blocking gap (G-019). Everything else checked passes.

## Checked against task.md "Must have"
1. Fixed keys from CONTRACT section 3 accepted from JSON; file with only those keys valid — PASS
   (`fixed_keys_only_file_is_valid`; the probe confirms the contract example loads).
2. Zero initial populations accepted — PASS (`zero_initial_populations_are_valid`, `zero_plants_only_is_valid`).
3. Every non-fixed parameter has a default — PASS (`every_extra_parameter_has_default`, `explicit_defaults_equal_absent_groups`).
4. Invalid configs rejected, message names the key, for wrong type, missing fixed key, out of range —
   PARTIAL. Wrong type, missing fixed key and the out-of-range table pass with the key named. FAILS for integer literals
   beyond i128 (about 1.7e38), for any key: the parser returns `config: JSON syntax error at line 1, column N: integer too
   large` with `key = None`. Example: `{"seed":100000000000000000000000000000000000000000000,...}` (scratch probe, outside repo).
   This is a value out of range, and no test covers it. -> G-019.
5. Round trip `from_json(to_json(c)) == c` — PASS (`round_trip_defaults_equal`, `round_trip_boundary_values`,
   `round_trip_awkward_floats`, `file_round_trip_through_temp_dir`).
6. At least three presets, valid, selectable by name, meaningfully different — PASS (four presets; `presets::get(name)`;
   `presets_differ_meaningfully`). Selection by CLI option is TASK-019 scope, not this task.

## Decisions (task.md "Your decisions")
- Parameters and groups: 24 tunable keys in six groups, listed in ADR-0006 with type, range and default. Reasonable; the
  table matches `config.rs` `from_fields` (checked each range and default by reading the code).
- Unknown keys are an error with the full dotted path, documented in ADR-0006 — PASS (`unknown_keys_are_errors_with_full_path`).
- JSON only; no TOML/YAML (optional). Documented.

## Commands run in this REVIEW
- `cargo test -p evosim-core --locked` -> exit 0, 35 passed, 0 failed.
- `cargo clippy -p evosim-core --locked --all-targets` -> exit 0, 0 warnings.
- `bash scripts/test.sh` -> exit 0, "ALL TESTS PASSED" (incremental build, 1.8 s wall; no clean rebuild).
- Probes in `/tmp/probe-src` (scratch crate depending on `crates/evosim-core` by path, not in the repo):
  - huge integer for `seed`, for `plants.growth_rate`, for `plants.max_age` -> all `key=None` (G-019).
  - `"seed": 1e3` and `"seed": 1.0` -> `key=seed`, expected integer (correct).
  - `"world": null` -> `key=world`, expected object (correct). `{}` -> `key=seed`, missing (correct).
  - `"growth_rate": -0.0` accepted; `"growth_rate": "0.1"` -> wrong type named (correct).
  - Unknown key `foo` with a wrong-typed `seed` -> unknown key reported first (documented order).
  - Surrogate-pair escape `😀` in a key -> "invalid \u escape" (G-020).

## Gaps
- G-019 (blocking): see item 4. Remediation: an integer literal beyond i128 must become a range error that names its key
  (store the literal text or keep it as an out-of-range value and check it in `from_fields`). Add tests: oversized
  `seed`, `world.width`, and an oversized value for a real-typed key (`plants.growth_rate`).
  Keep `from_json` strictness otherwise unchanged.
- G-020 (non-blocking): RFC 8259 surrogate pairs are rejected; lone surrogates correctly rejected. Decode valid pairs,
  add a test. No task criterion depends on it (keys and parameters are ASCII).
- G-021 (non-blocking): ADR-0006 "Decision" says `config::validate`; the code is `from_fields`. Fix the name when G-019 is
  fixed, then set ADR-0006 to Accepted (it stays Proposed now, because of G-019).
- G-016 (carried, non-blocking): `Config::save` does not create parent directories. TASK-019 owns the CLI side.

## Not checked
- Dependent tasks (TASK-005, TASK-019, TASK-024, TASK-025) are not implemented yet; no dependent handoffs exist.
  TASK-025 needs `presets::get` and `presets::NAMES`, which exist.
- Default values are placeholders (ADR-0004); calibration is TASK-009.

## Changes in this phase
- `docs/STATE.md`: status line and a REVIEW (TASK-003 cycle 1) block.
- Handoff files `tasks/TASK-003/handoffs/review-cycle1.{json,md}`.
- No code, no ADR edits, no task.md/task.json, no commits.

# TASK-003 IMPLEMENT cycle 1 — notes

Implements `tasks/TASK-003/handoffs/plan-cycle1.md` with the deviations listed below. Machine-readable record: `implement-cycle1.json`.

## Result
- `cargo test -p evosim-core --locked`: 35 passed (exit 0).
- `cargo test --workspace --locked`: exit 0.
- `cargo clippy -p evosim-core --locked --all-targets`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: checks=54 failed=0, exit 0.
- `bash scripts/test.sh`: exit 0, "ALL TESTS PASSED".

## Files
- `crates/evosim-core/src/config.rs`: `Config` and its sections, defaults, `ConfigError`, `from_json`, `to_json`, `load`, `save`, `new`.
- `crates/evosim-core/src/config/json.rs`: strict parser and canonical writer.
- `crates/evosim-core/src/config/presets.rs`: four presets as JSON text, `NAMES`, `get`.
- `crates/evosim-core/src/config/tests.rs`: 34 config tests.
- `crates/evosim-core/src/lib.rs`: `pub mod config;`.
- `docs/decisions/ADR-0006-...md`: cap rule reworded; implementation notes added. Status stays Proposed for REVIEW.
- `docs/STATE.md`: IMPLEMENT block and status line.

## Deviations from the plan (all recorded in ADR-0006)
1. Herbivores and carnivores share one struct (`config::Animal`), since their parameters are identical.
2. The cell-count cap is not a separate check. Both sides are capped at 4096, so the product cannot exceed 16,777,216.
3. Presets are JSON text parsed through `from_json`, not built from typed setters, so they use the same validation path as user files.

## Open items for REVIEW
- Confirm ADR-0006 and set it to Accepted if the key table holds.
- Check the Must-have points against the test list in `implement-cycle1.json`.
- `Config::save` does not create parent directories (G-016).

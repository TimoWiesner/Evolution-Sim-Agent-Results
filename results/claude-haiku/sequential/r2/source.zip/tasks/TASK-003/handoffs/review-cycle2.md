# TASK-003 REVIEW cycle 2 — notes

Verdict: **PASS**. Independent check of the code, tests and records against `tasks/TASK-003/task.md` and the REVIEW cycle 1 gaps.

## Must-have points (task.md)

| Point | Evidence |
|---|---|
| Fixed keys accepted from JSON; fixed-keys-only file valid | `config/tests.rs` `fixed_keys_only_file_is_valid`; probe: `{seed, world, initial}` loads |
| Zero initial populations accepted | `zero_initial_populations_are_valid`, `zero_plants_only_is_valid`; `herbivore-only` preset |
| Every non-fixed parameter has a default | `every_extra_parameter_has_default`, `explicit_defaults_equal_absent_groups`; defaults table in ADR-0006 matches `config.rs` `DEFAULT_*` constants |
| Invalid configs rejected, message names key (wrong type, missing fixed key, out of range), tested per case | `wrong_type_*` (6 tests), `missing_fixed_keys_are_named`, `out_of_range_values_name_the_key`, `unknown_keys_are_errors_with_full_path`; probes below |
| Save/load round trip equal | `round_trip_defaults_equal`, `round_trip_boundary_values`, `round_trip_awkward_floats`, `file_round_trip_through_temp_dir`; probe: round trip `true` for every accepted input |
| >= 3 presets, meaningfully different, valid, selectable by name | `presets_are_valid_and_selectable_by_name`, `presets_differ_meaningfully`; four presets in `config/presets.rs` |

## REVIEW cycle 1 gaps

- **G-019 (blocking) — closed.** Integer literals beyond i128 become `Value::BigInt` and are reported as range errors naming the key. Probe results (scratch crate `/tmp/review2-probe`, outside the repo):
  - `seed` = 60 nines → `key=seed`, "... is out of range 0..=18446744073709551615"
  - `seed` = 2^64 → `key=seed`, out of range; `seed` = u64::MAX → accepted, round trip equal
  - `plants.growth_rate` = 60 nines → `key=plants.growth_rate`
  - `plants.seed_radius`, `plants.max_age`, `world.width` (45 digits), `herbivores.metabolism` (negative BigInt) → each names its key
  - Tests: `huge_integer_for_seed_names_key`, `huge_negative_integer_for_seed_names_key`, `huge_integer_for_width_names_key`, `huge_integer_for_real_key_names_key`, `json_big_integer_is_kept_as_text`.
- **G-020 (non-blocking) — closed.** `json_surrogate_pair_decodes` (`"😀"` → U+1F600, also mid-string); lone high, high followed by non-low, and lone low are errors (`json_lone_high_surrogate_is_error`, `json_lone_low_surrogate_is_error`). Config-level string values do not exist, so the parser test is the only place this is observable (as expected).
- **G-021 (non-blocking) — closed.** ADR-0006 names `from_fields`; `grep` in `config.rs` confirms the function exists and is the only validator.
- **G-016 (non-blocking, core part) — closed.** `save_creates_parent_directories` writes to `a/b/config.json` under a temp dir and reloads it. The CLI error text remains TASK-019.

## Additional probes (scratch crate, no repo change)

- `1e400` and `-1e400` for `plants.growth_rate` → named key, "inf"/"-inf is out of range".
- `1e-400` for a real → accepted as 0.0 (underflow; not a spec issue, not documented).
- `1e2` for `world.width` → named key, "expected integer, found real number".
- `4097` width, `256` mutation_strength → named key, out of range.
- Unknown nested key `world.depth` → named as `world.depth`.
- Duplicate key, `+1`, empty input, BOM → parse errors with line/column and no key (ADR-0006 specifies this; the task's named error classes are wrong type, missing fixed key, out of range — all named).
- `{}` → key `seed`, missing required key.

## Test evidence

- `cargo test -p evosim-core --locked` → exit 0, 44 passed (43 `#[test]` in `config/tests.rs` + `contract_version_is_one`).
- `cargo clippy -p evosim-core --locked --all-targets` → exit 0, 0 warning lines.
- `bash scripts/check_adrs.sh` → exit 0, checks=54 failed=0 (run before and after the ADR status edit).
- `bash scripts/test.sh` → exit 0, "ALL TESTS PASSED" (log `/tmp/review2-test.log`).

## Non-blocking observations (not gaps for this task)

- G-022 (cosmetic): for a huge integer literal on a real key the message shows the f64 value (e.g. `1e60`), not the literal as written. It still names the key and the range. Fix if desired in a later task.
- Underflowing reals (`1e-400`) silently read as 0.0. Harmless with ranges starting at 0.0; could be documented later.
- Parse errors and duplicate keys carry no key by design (ADR-0006); the task's named classes are all named.
- Default `genetics.*` and `species.*` values are placeholders from ADR-0004 until TASK-009 calibration.
- The configuration is not yet used by the simulation or any CLI command (TASK-005, TASK-019).

## Dependent tasks

`TASK-005`, `TASK-019` and `TASK-025` list TASK-003 as dependency (`tasks/*/task.json`). They have no handoffs yet, so nothing to check against.

## Records changed in this phase

- `docs/decisions/ADR-0006-configuration-format-and-presets.md`: status set to Accepted (REVIEW cycle 2). `scripts/check_adrs.sh` still exits 0.
- `docs/STATE.md`: REVIEW cycle 2 section added.
- No code, task.md, task.json, benchmark state or commits.

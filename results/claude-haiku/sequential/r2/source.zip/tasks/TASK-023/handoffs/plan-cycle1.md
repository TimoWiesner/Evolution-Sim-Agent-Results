# TASK-023 PLAN cycle 1: UI window and world view

Verdict field: N/A (PLAN). Machine-readable record: `plan-cycle1.json`. Decisions: `docs/decisions/ADR-0024-ui-world-view.md`
(Proposed). Technology: `docs/decisions/ADR-0002-ui-technology.md` (Accepted; local browser UI, Chromium for smoke and screenshots).

No product code was changed in PLAN. Planning documents only.

## Findings from reading the code (PLAN)
- Dependencies are done: TASK-006 (`World.climate`, `Climate::at(cell).biome`, `biome_map_text`), TASK-013 (movement, living
  organisms with cells), TASK-019 (`run`, `runner`, `Config::load`, `load_config` in `evosim-cli/src/main.rs`).
- `crates/evosim-ui/src/lib.rs` is a placeholder. `crates/evosim-cli/src/args.rs` has `Command::{Version, Help, Climate, Run, Batch}`;
  `ui` is missing. `help_text()` says "Further commands (ui) are added by later tasks".
- Core API needed by the UI, all existing and read-only: `Simulation::{new, tick, tick_count, entities, world, spatial}`;
  `Entities::living()` (ascending id); `Organism::{id, kind, cell, species, age, energy, health}`; `Kind::{ALL, index}`;
  `World.topology` (`Torus::{width, height}`); `World.climate.at(cell).biome` (`Biome::glyph`, `Biome::name`).
- `Config` has no `Default`. The built-in default configuration will be the example of CONTRACT section 3, embedded as a string.
- `Simulation` derives `Clone, Debug, PartialEq`. `Send` is not yet verified; IMPLEMENT step 1 checks it (the simulation thread
  owns the value, so `Send` is needed).
- `chromium` 131 is at `/usr/local/bin/chromium`, `xvfb-run` at `/usr/bin/xvfb-run`.
- **Feasibility spike (run in PLAN, scratch files in /tmp/spike, outside the workspace):** a Python 3 static server on
  127.0.0.1 serving a page whose JavaScript `fetch`es `/api/state` three times, draws on a canvas and sets the title.
  `chromium --headless --no-sandbox --disable-gpu --virtual-time-budget=5000 --dump-dom URL` printed the title marker
  (`frames=1 tick=12`), exit 0 in 0.29 s. `--screenshot=PATH` wrote a 5,237-byte PNG, exit 0. Stderr shows only D-Bus
  "bus.cc" messages (harmless). So `fetch` and canvas work under virtual time. The real server is **not yet** verified, which is
  IMPLEMENT step 6.

## Decisions (summary; full text in ADR-0024)
1. Browser UI in `crates/evosim-ui`, std only (no new crate), served on `127.0.0.1` (ADR-0002, ADR-0024 D2).
2. `evosim ui [--config FILE] [--port N]`, `--smoke-test`, `--screenshots DIR` (ADR-0024 D1). Invalid use exits 2.
3. The simulation runs on its own thread at 20 ticks/s; it publishes pre-encoded snapshot bytes; HTTP threads never touch
   the `Simulation` (ADR-0024 D2).
4. Static biome base layer from `/api/climate` (once per page load). Live organisms from `/api/state` (5 Hz poll) as
   `[id, kind, x, y]` (ADR-0024 D3, D4).
5. Drawing: canvas 2D. Biome colours per cell. Plants = green square, herbivores = amber circle, carnivores = red triangle.
   Pan by drag, zoom by wheel around the cursor (2 to 64 px per cell), fit by default, double-click resets (ADR-0024 D5).
6. Layout reserves ids `#controls`, `#inspector`, `#charts` for TASK-024 and TASK-025 (ADR-0024 D6).
7. Smoke test and screenshots drive the real server through Chromium with `--virtual-time-budget` and `--dump-dom` or
   `--screenshot` (ADR-0024 D7, D8).

## Planned interfaces
- `crates/evosim-ui/src/lib.rs`: `pub struct UiArgs { config: Option<PathBuf>, port: u16, mode: UiMode }`,
  `pub enum UiMode { Serve, SmokeTest, Screenshots(PathBuf) }`, `pub fn run(args: &UiArgs) -> Result<(), String>`,
  `pub const DEFAULT_CONFIG: &str` (CONTRACT section 3 example).
- `crates/evosim-ui/src/snapshot.rs`: `pub fn state_json(sim: &Simulation) -> String` and `pub fn climate_json(sim: &Simulation) -> String`
  (pure functions, unit-testable), `pub const MAX_ORGANISMS: usize = 10_000`.
- `crates/evosim-ui/src/server.rs`: `pub struct Shared { state: Mutex<Arc<Vec<u8>>>, climate: Vec<u8>, ... }`,
  `pub fn route(method, path, shared) -> Response` (pure, unit-tested), `pub fn serve(listener, shared)`.
- `crates/evosim-ui/src/driver.rs`: simulation thread (`pace` to 20 ticks/s, publish snapshot), smoke and screenshot drivers,
  `find_chromium()` (`CHROME_BIN` then PATH), `run_chromium(url, args, timeout)`.
- `crates/evosim-ui/web/{index.html, app.js, style.css}`: embedded with `include_str!`.
- `crates/evosim-cli/src/args.rs`: `Command::Ui(UiArgs)` and `parse_ui`. `main.rs` dispatch to `evosim_ui::run`, errors to stderr, exit 2
  on invalid arguments, exit 1 on a runtime failure (the smoke test or screenshot failed).
- `crates/evosim-cli/Cargo.toml` gains `evosim-ui = { path = "../evosim-ui" }`. `evosim-ui/Cargo.toml` gains
  `evosim-core = { path = "../evosim-core" }`.

## Ordered IMPLEMENT steps
1. Check that `Simulation` is `Send` (a compile-time assertion in a test). Add the two Cargo dependencies. Add the empty module
   layout. `cargo build --workspace --locked` must pass.
2. `snapshot.rs`: `state_json`, `climate_json`, `MAX_ORGANISMS` cap. Unit tests on a small hand-built simulation: tick and counts
   match `Entities`; organisms in ascending id; kind codes 0, 1, 2; cap; climate string length `W*H` and glyphs in `PRHTD`.
3. `server.rs`: `route()` and the HTTP reader/writer (`GET` only, `Content-Length`, `Connection: close`, path without query).
   Unit tests: `/`, `/app.js`, `/style.css`, `/api/climate`, `/api/state`, 404, 405 for `POST` (no commands yet), query string ignored.
4. `driver.rs`: simulation thread with pacing, snapshot publishing, `serve` mode (prints `evosim ui: http://127.0.0.1:PORT/` to
   stderr and runs until killed), smoke and screenshot modes with timeouts and the marker check. Integration test: start on
   port 0, read `/api/state` twice, tick increases.
5. `web/`: `index.html` (header, canvas, sidebar with legend and empty `#controls` and `#inspector`, bottom `#charts`),
   `style.css` (palette, dark or light by choice), `app.js` (climate load, state poll at 200 ms, canvas drawing, pan and zoom,
   `?smoke=1` and `?shot=1` modes that set the title marker or stop polling after two frames).
6. CLI: `args.rs` `parse_ui` and tests (every flag combination, `--smoke-test` with `--screenshots` is exit 2, missing
   `DIR` is exit 2, bad `--port` is exit 2); `main.rs` dispatch; help text lists `ui`.
7. Run `./build.sh`, then `./evosim ui --smoke-test` (exit 0 within 60 s; record the time) and
   `./evosim ui --screenshots /tmp/x` (exit 0 within 120 s; check `main.png` IHDR >= 1280x720 with a small python3 -I
   script in `scripts/`). View `main.png` (Read tool) to check the legend, biomes and three organism shapes.
8. 1,000-organism check: a configuration `examples/ui-1000.json` (96x72 world, 700 plants, 250 herbivores, 50 carnivores, fixed
   keys only). Record the snapshot build and encode time per tick over 200 ticks (a `#[ignore]` test with `--nocapture`, same
   style as `bench_index_vs_brute_force`) and the tick rate of `evosim run` on the same file. Optional real-time FPS check with
   a non-virtual-time headless run.
9. Add `scripts/ui_check.sh` (smoke, screenshot, PNG check, exit codes) and a step in `scripts/test.sh` that calls it. Add
   ADR-0024 to `scripts/check_adrs.sh` and to `docs/decisions/README.md`.
10. README "UI" section: how to start (`./setup.sh`, `./evosim ui`, open the printed URL), the smoke and screenshot commands,
    `CHROME_BIN`, and the legend. `docs/ARCHITECTURE.md` UI section and `docs/STATE.md` IMPLEMENT record.
11. Run the gates (see Tests). Record exit codes in the IMPLEMENT handoff. Do not commit.

## Tests and commands planned for IMPLEMENT
- `cargo test --workspace --locked` (exit 0 required; baseline cli 32 unit + batch_cli 8 + run_cli 9, core 423 passed per TASK-022).
- `cargo clippy -p evosim-core -p evosim-cli -p evosim-ui --locked --all-targets` (no warnings).
- `bash scripts/check_adrs.sh`, `bash scripts/test.sh` (exit 0), `git remote -v | wc -l` (0).
- `./build.sh`; `./evosim ui --smoke-test; echo $?`; `./evosim ui --screenshots DIR; echo $?`; `python3 -I scripts/...` PNG check.
- Negative: `./evosim ui --smoke-test --screenshots /tmp/x` exit 2; `./evosim ui --config missing.json` exit 2; `./evosim ui --port x` exit 2.
- `./evosim ui --port 0` started in the background, `curl -s http://127.0.0.1:PORT/api/state` (or a Rust test), then killed.

## Risks
1. **Virtual-time behaviour with the real server.** The spike used a Python server; the real server is Rust. Mitigation: IMPLEMENT
   step 7 runs it first. If the marker is not written, use `chromium --remote-debugging-port` with a small CDP client, or make
   the page request the frame count through `/api/smoke` (a read-only endpoint), not via timing. Record the result either way.
2. **Chromium timing for screenshots.** The screenshot is taken after the virtual budget; if the first `/api/state` is slow,
   the picture may be empty. Mitigation: the page draws the biome base immediately and marks `shot=1` after two organism
   frames; check the image visually.
3. **Frame rate at 1,000 organisms in software rendering.** Canvas 2D at 1,000 small shapes per frame should be fine; the
   measured number may not reach 60 fps. The contract asks for several updates per second; the poll is 5 Hz and drawing happens
   on each response. If the real-time check fails, record it as a gap.
4. **Simulation thread and `Send`.** If `Simulation` is not `Send`, the driver must build it inside its own thread (the
   config is `Send`). Low risk.
5. **Cell stacking.** Plants may share cells (cap per cell, ADR-0013); jitter avoids complete overlap but not all overlap.
   Acceptable for the view; the inspector (TASK-024) gives exact identity.
6. **Default population collapse.** With the default config herbivores and carnivores die out after some ticks (TASK-018/027
   balance issue, allowed by CONTRACT 5.3). The screenshot at tick 100 may show few animals. Record the counts in the handoff;
   the balance is not a TASK-023 criterion.
7. **Layout constraints for TASK-024/025.** Reserved ids and the sidebar and bottom strip are the only contract; later tasks may
   restyle.
8. **Tool availability.** `file` is not installed in the container; use a python3 -I PNG header check. Chromium runs as root
   only with `--no-sandbox`. The D-Bus messages on stderr are harmless.

## Dependencies on the container
- Chromium 131 at `/usr/local/bin/chromium`: present (verified in PLAN with the spike, see above).
- `xvfb-run` at `/usr/bin/xvfb-run`: present; not required for the browser UI, which needs no display.
- No new system packages are needed for IMPLEMENT. Python 3 is used only for the PNG header check in `scripts/`.

## Not changed in PLAN
task.md, task.json, benchmark files, contract, AGENTS.md, CLAUDE.md, product code, Cargo files, no commit.

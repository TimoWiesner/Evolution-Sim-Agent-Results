# TASK-023 REVIEW cycle 2: UI window and world view

Verdict: **FAIL**. Machine-readable record: `review-cycle2.json`. ADR-0024 stays `Proposed` (set to Accepted only on PASS).
No product code, task.md, task.json, benchmark files, ADR or commits were changed in REVIEW.

## Must-have results (task.md)
| # | Requirement | Result | Evidence (this cycle) |
|---|---|---|---|
| M1 | `./evosim ui` serves the same engine | PASS | `timeout 5 ./evosim ui --port 8080 --config examples/ui-1000.json` printed `evosim ui: http://127.0.0.1:8080/`, exit 124 (serving until stopped). |
| M2 | Cells coloured by biome, organisms on top, three kinds distinguishable | PASS | `--screenshots` image viewed (`main-1000` run, tick 104): biome bands, green squares (plants), amber circles (herbivores), red triangles (carnivores). |
| M3 | Legend explains colours and symbols | PASS | Right sidebar in the viewed image: five climate classes and three organism shapes. |
| M4 | Pan and zoom, verified by a recorded command | PASS (synthetic input) | `bash scripts/ui_check.sh` exit 0: drag `dx=100.00 dy=50.00 fit=false`; zoom-anchor `at=300.00,200.00`; zoom-clamp max and min true; dblclick-fit `scale=9.486 expected=9.486`. Input is synthetic DOM events (`?check=1`), not OS or CDP input. |
| M5 | With 1,000 organisms the view stays usable and updates several times per second | **NOT MET** | See below. |
| M6 | `./evosim ui --smoke-test` (CONTRACT 2) | PASS | Exit 0, `evosim ui: smoke test passed (smoke frames=1 tick=15)`. |
| M7 | README explains how to start the UI | PASS | README example `./evosim ui --port 8080 --config examples/ui-1000.json` now uses an existing file and serves (exit 124 on timeout). The earlier `scenarios/demo.json` defect is gone. |

Screenshot point (recorded, not a fail reason): `./evosim ui --screenshots DIR --config examples/ui-1000.json` wrote a
1280x807 `main.png` (exit 0) and that image was viewed: legend, header counts, all three kinds. The default-config screenshot was
not re-run in this cycle.

### M5 detail (why it fails)
- `examples/ui-1000.json` starts with 1,000 organisms (700/250/50 on 96x72). `./evosim run --ticks 600 --sample-every 100` (re-run here) gives
  living totals 1000 (tick 0), 866 (100), 511 (200), 285 (300), 251 (400), 228 (500), 226 (600). Final herbivores 0, carnivores 0.
- The UI check window (`scripts/ui_check.sh`, ticks 13 to 209) reports living min 488, max 1353. So 1,000 organisms are not held
  during the measured window.
- The in-browser frame rate and the snapshot time at 1,000 organisms were not measured. The ignored test
  `ui_1000_organisms_timing` still builds the inline 700/250/50 world, not `examples/ui-1000.json` as the plan said; it was not run this cycle.
- The 4.98 responses/s figure is a server-side state-poll rate. It shows the page keeps polling, not that the view handles 1,000 organisms.
- IMPLEMENT cycle 2 itself records M5 as NOT MET. The 48-candidate sweep is in `docs/STATE.md`; I did not re-run it (scratch
  directory already deleted).

## Other checks (this cycle)
- `cargo test --workspace --locked`: exit 0. cli unit 36, batch_cli 8, checkpoint_cli 2, run_cli 9, core 423 (1 ignored), ui 15 (1 ignored).
- `bash scripts/check_adrs.sh`: exit 0, `checks=153 failed=0`. ADR-0024 is still not in the list (G4 open).
- `bash scripts/ui_check.sh`: exit 0, `ui_check: PASS`, total 10.7 s.
- `./evosim ui --smoke-test`: exit 0.
- `./evosim ui --screenshots DIR --config examples/ui-1000.json`: exit 0, 1280x807 PNG.
- `git remote -v | wc -l` = 0. `git status` clean at the end of REVIEW.
- Not run this cycle: `cargo clippy` (implement cycle 2 reported no warnings), `scripts/test.sh`, the negative exit-2 cases,
  `node --check app.js`, and the ignored timing test. These are not evidence for this review.

## Gap status vs REVIEW cycle 1
- G1 (M4 pan/zoom): closed by `scripts/ui_check.sh`. Limitation: synthetic events, not OS input.
- G2 (M5, 1,000 organisms): **open**. No sustained 1,000 config exists with the current engine balance. The implement cycle
  chose the fallback (document NOT MET). The timing at 1,000 organisms was not measured in-browser.
- G3 (README example): closed.
- G4 (docs/ADR): **open**. ADR-0024 is not in `scripts/check_adrs.sh`. `docs/ARCHITECTURE.md` has TASK-023 notes but no UI module section.
  ADR remains Proposed.
- G5 (driver budgets): closed in code (`SMOKE_WAIT` 10 s + `SMOKE_CHROMIUM` 35 s; `SHOT_WAIT` 30 s + `SHOT_CHROMIUM` 60 s). Worst cases 45 s and 90 s, normal runs about 1 s and 5 s.
- G6 (climate-load failure): closed in code (`poll()` retries `loadClimate()` while climate is null).

## Remediation for the next PLAN (gap IDs)
- **G2 / M5 (must-have, open).** Decide the 1,000-organism criterion and record it in ADR-0024:
  (a) Measure the view with 1,000 organisms present in a real-time run from tick 0 (in-browser frame rate and snapshot encode/draw timing
  at 1,000), and state the exact window in which living >= 1,000 holds. Or
  (b) Escalate that the engine cannot hold 1,000 for a usable window with fixed keys. Any fix must come from the ecology mechanisms in
  `docs/PROJECT.md` (cell regeneration, density dependence, handling time, cover), in the engine tasks (TASK-018/027). No anti-extinction
  rule and no fabricated population in the UI.
  Either way, run the `ui_1000_organisms_timing` test against the chosen config and record its output.
- **G4 (docs).** Add ADR-0024 to `scripts/check_adrs.sh`. Add a UI section to `docs/ARCHITECTURE.md`. Set ADR-0024 to Accepted only at REVIEW PASS.
- Optional: add the in-browser frame-rate measurement (CDP or `?check=1` timing), since the server poll rate is not a frame rate.

## Verdict basis
FAIL because M5 (1,000 organisms, several updates per second with 1,000 present) is NOT MET, which the task's Must-have rule makes
decisive. M1 to M4, M6 and M7 pass with evidence from this cycle. The screenshot point passes and is not a fail reason.

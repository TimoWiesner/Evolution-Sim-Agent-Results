# TASK-023 REVIEW cycle 3: UI window and world view

Verdict: **PASS**, on the reading of M5 stated below. Machine-readable record: `review-cycle3.json`. Numbers: `docs/STATE.md` (TASK-023 REVIEW cycle 3).
ADR-0024 set to **Accepted**. No product code, task files, benchmark files or commits were changed. Git remotes: 0.

## Must-have results
| # | Requirement | Result | Evidence (this cycle) |
|---|---|---|---|
| M1 | `./evosim ui` serves the same engine | PASS | Cycle 2 evidence stands; server code unchanged in cycle 3. `ui_check.sh` drove the live server. |
| M2 | Cells coloured by climate or biome, organisms on top, three kinds apart | PASS | Both screenshots viewed: biome bands, plant squares, herbivore circles, carnivore triangles. |
| M3 | Legend explains colours and symbols | PASS | Right sidebar: five climate classes, three organism shapes. |
| M4 | Pan and zoom, recorded | PASS (synthetic input) | `scripts/ui_check.sh` exit 0: drag, zoom anchor, clamp, dblclick-fit. |
| M5 | With 1,000 organisms the view stays usable and updates several times per second | PASS on the D14 (a)+(b) reading; (c) not met | See below. |
| M6 | `./evosim ui --smoke-test` | PASS | Exit 0, `smoke frames=1 tick=14`. |
| M7 | README explains how to start the UI | PASS | README lines 70 to 85 name existing files; the 1,000 example is a start configuration, not a claim of sustained coexistence. |

Screenshot point: both `--screenshots` runs exit 0 and write a 1280x807 `main.png`. Not a fail reason in any case.

## M5 detail
- (a) Renderer cost, `python3 -I scripts/ui_fps.py fixture`, exit 0: 60.2 rAF fps in real time over 5 s with 1,000 synthetic organisms; redraw mean 1.73 ms.
- (b) Live, `python3 -I scripts/ui_fps.py live`, exit 0: living >= 1,000 for ticks 4 to 62 (2.86 s). Inside that window the page ran 60.1 frames/s and 4.71 state updates/s.
- Extra: `ui_check.sh` ran the real page for 10 s from a 1,000-start configuration (ticks 12 to 209): 4.97 updates/s, living between 488 and 1,357.
- (c) Sustained 1,000 for a long run is **not met and not claimed**: living is 514 at tick 199 and 226 at tick 600 for `examples/ui-1000.json`. The engine owns this (TASK-018, TASK-027). The ignored timing test records living=511 at tick 200.

### Why PASS and not FAIL
The must-have is about how the view behaves with 1,000 organisms present. Those organisms are present in the real live run for about 3 s, and the view met both thresholds (fps and updates per second) during that time. It also kept updating about 5 times per second through the rest of the run. Requiring a long run at 1,000 would make the view's pass depend on an engine property that this task cannot change.

**The orchestrator must confirm this reading.** If M5 is read as requiring 1,000 organisms to persist, the verdict is FAIL and the item is blocked on TASK-018 and TASK-027. Since `max_cycles` is 3 and this is cycle 3, a FAIL would end the task.

## Gap status vs REVIEW cycle 2
- G1 (pan and zoom): closed by `ui_check.sh`. Limitation: synthetic events.
- G2 (M5): closed on the (a)+(b) reading above. (c) remains an engine item.
- G3 (README): closed.
- G4 (ADR and docs): closed. ADR-0024 is in `check_adrs.sh` (checks=164, failed=0); ARCHITECTURE has the UI module section; ADR-0024 is Accepted.
- G5 (driver budgets) and G6 (climate-load retry): closed in code, unchanged this cycle.

## Limitations (not gaps)
- Live window: one run per check (plus one in IMPLEMENT cycle 3). Variance is not established over many runs.
- The fixture is synthetic and renderer-only; it is not a simulation result.
- The DevTools client in `scripts/ui_fps.py` has no unit test.

# TASK-023 PLAN cycle 3: close REVIEW cycle 2 gaps G2 (M5) and G4

Machine-readable record: `plan-cycle3.json`. Decisions: `docs/decisions/ADR-0024-ui-world-view.md` (PLAN cycle 3 amendments D14 to D18, still Proposed).
No product code, task.md, task.json, benchmark files or commits were changed in PLAN.

## Starting facts (verified this cycle)
- `examples/ui-1000.json` starts at 1,000 organisms (96x72; 700/250/50). Living falls to about 866 at tick 100, 511 at 200, 226 at 600 (herbivores and carnivores 0). The sweep (48 candidates, seeds 42 and 7) found no candidate that keeps living >= 1,000.
- The browser check window of `scripts/ui_check.sh` (ticks 13 to 209) has living min 488.
- No in-browser frame rate has been measured. `--dump-dom` returns at load and cannot time a real-time run (probe: returned at 0.25 s, ignoring timers).
- `ui_1000_organisms_timing` (crates/evosim-ui/src/driver.rs, ignored) still uses the inline 700/250/50 world, not the UI config.
- `scripts/check_adrs.sh` does not list ADR-0024. `docs/ARCHITECTURE.md` has no UI module section.
- Dependent tasks TASK-006, TASK-013, TASK-018, TASK-019, TASK-027 are PENDING. The sustained-coexistence part of M5 depends on TASK-018 and TASK-027 (engine balance, PROJECT.md "Extinction and stabilising mechanisms").

## Gap closure
- **G2 / M5.** Split into three parts (ADR-0024 D14):
  (a) renderer cost with 1,000 synthetic organisms in a page mode `?fixture=1000` (never used by smoke, screenshots or the live server): >= 30 rAF fps in real time and mean redraw <= 16 ms;
  (b) live run of `examples/ui-1000.json` in real time, the exact window where living >= 1,000 reported (about the first 50 ticks), >= 3 state updates/s and >= 30 fps in that window, with a window under 2 s reported as too short;
  (c) sustained coexistence at 1,000 is not claimed (engine item, TASK-018/027). No anti-extinction rule, no fabricated population, no `evosim-core` change.
- **G2 test.** `ui_1000_organisms_timing` switched to `examples/ui-1000.json` and its output recorded (D16).
- **G4.** ADR-0024 added to `scripts/check_adrs.sh`; "UI module (TASK-023)" section in `docs/ARCHITECTURE.md`; ADR stays Proposed (D17).

## Ordered implementation plan (IMPLEMENT cycle 3)
1. Baseline: `export PATH=/opt/rust/cargo/bin:$PATH; cargo test --workspace --locked`, `bash scripts/check_adrs.sh`, `bash scripts/ui_check.sh`. Record exit codes.
2. `crates/evosim-ui/web/app.js`: add `?fixture=1000` (deterministic synthetic organisms on the real climate grid, labelled "synthetic fixture" in the header and in the title). Keep `window.evosim` read-only.
3. `scripts/ui_fps.py` (run with `python3 -I`): DevTools (`--remote-debugging-port=0`, read `DevToolsActivePort`), stdlib WebSocket client, `Runtime.evaluate` with `awaitPromise` for a 5 s rAF count and `window.evosim.timing(50)`. Modes: `fixture` (D14a) and `live` (D14b: starts `evosim ui --config examples/ui-1000.json --port <free>` and records living per tick from `/api/state` at the same time). Exit 0 only when thresholds hold. Probe first that rAF runs in headless real time; if it does not, report that and stop (no fake numbers).
4. `driver.rs`: point `ui_1000_organisms_timing` at `examples/ui-1000.json`; run it with `cargo test -p evosim-ui --release -- --ignored --nocapture ui_1000_organisms_timing` and record output.
5. `scripts/check_adrs.sh`: add ADR-0024 to the list. `docs/ARCHITECTURE.md`: UI module section.
6. Re-run: `scripts/ui_check.sh`, `scripts/ui_fps.py` (fixture and live), `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR` (default config and `examples/ui-1000.json`; view `main.png`), `cargo clippy -p evosim-ui --all-targets`, `node --check crates/evosim-ui/web/app.js`, `git remote -v | wc -l`.
7. Record numbers for D14 (a) and (b) in `docs/STATE.md` and `implement-cycle3.json`. Do not present (c) as passed.

## Tests and evidence REVIEW will need
- `scripts/ui_fps.py fixture` exit 0 with fps and redraw ms; `scripts/ui_fps.py live` exit 0 or a recorded "window too short" result with the exact tick window.
- Timing test output (living every 10 ticks, tick and snapshot means).
- Existing gates: cargo tests, check_adrs (ADR-0024 now included), ui_check, smoke, screenshots.

## Risks
- Headless Chromium may not run requestAnimationFrame in real time at all in this container. Then (a) and (b) cannot be measured, and M5 stays NOT MET on evidence.
- The live window of >= 1,000 organisms is short (about 2.5 s at 20 ticks/s). That is a real property of the engine, not a UI defect; it is reported as is.
- The fixture measures the renderer, not the simulation. It must not be presented as a simulation result.
- The DevTools WebSocket client is new code (about 60 lines). It needs a test (for example a frame-count check against a known page).
- Overall verdict expectation: M5 cannot be met in full in this task. Escalation to the orchestrator is needed if the must-have is kept as written.

## Container and system dependencies
- Chromium 131 at `/usr/local/bin/chromium` (container standard; `CHROME_BIN` honoured). Python 3 stdlib only. No new packages. Install command: none required.
- Probe result: `chromium --headless --dump-dom` returns at page load and ignores timers (scratch probe in /tmp, deleted by the same step as the report).

## Gaps open at PLAN
- M5 (c) sustained 1,000 is an engine property (TASK-018, TASK-027), not closable in this task.
- Real-time rAF in headless Chromium is unverified.

# TASK-023 PLAN cycle 2: UI window and world view (replan after REVIEW cycle 1 FAIL)

Verdict field: N/A (PLAN). Machine-readable record: `plan-cycle2.json`. Decisions: `docs/decisions/ADR-0024-ui-world-view.md`
(still Proposed; amended in this cycle with D10 to D13). No product code, Cargo files, task.md, task.json, benchmark files
or commits were changed in PLAN.

## Inputs read on entry
AGENTS.md, docs/PROJECT.md, docs/CONTRACT.md (sections 1 to 7), docs/STATE.md (TASK-023 PLAN, IMPLEMENT and REVIEW cycle 1
records), docs/ARCHITECTURE.md, tasks/TASK-023/task.md and task.json, plan-cycle1.md/json, implement-cycle1.json,
review-cycle1.md/json, ADR-0024, crates/evosim-ui/src/driver.rs, crates/evosim-ui/web/app.js, README UI section.

## Closing the REVIEW gaps (every gap is answered)
| Gap | Plan answer | Where it is done |
|---|---|---|
| G1 (M4) pan and zoom have no recorded check | A real-browser check driven through the Chrome DevTools Protocol (CDP): `chromium --remote-debugging-port` plus a stdlib-only Python WebSocket client in `scripts/ui_check.py`. It sends real mouse drag, wheel and double-click input and reads the view state through a read-only hook. Recorded as a command with exit code. | IMPLEMENT step 4 |
| G2 (M5) 1,000 organisms not sustained; real-time rate not measured | (a) A documented config `examples/ui-1000.json` whose live population stays at or above 1,000 over the measurement window (found by a sweep of fixed/documented keys with `evosim run`; the simulation code is not changed). (b) A real-time (no virtual time) headless run with CDP: counts poll responses and animation frames over 10 s and records tick, living count at the end, and min living over the window. (c) Snapshot build+encode and draw time at 1,000 organisms recorded by a `#[ignore]` test and an in-page timing hook. If no sweep config holds 1,000 for the window, the fallback is stated in the handoff as NOT MET; no fabricated population is drawn. | IMPLEMENT steps 3, 5 |
| G3 (M7) README example uses missing `scenarios/demo.json` | README example switched to `examples/ui-1000.json` (or `examples/config.json`); the command is re-run and its exit code recorded. | IMPLEMENT step 7 |
| G4 (docs) ADR-0024 not in `check_adrs.sh`; no ARCHITECTURE UI section | Add ADR-0024 to the check list and to the index, add an ARCHITECTURE UI section; set ADR-0024 to Accepted only at REVIEW PASS. | IMPLEMENT step 7 |
| G5 driver worst-case timeouts above CONTRACT budgets | Smoke: wait for tick 10 at most 10 s, Chromium at most 35 s (worst case about 45 s, under 60 s). Screenshots: wait for tick 100 at most 30 s, Chromium at most 60 s (worst case about 90 s, under 120 s). Normal runs take 0.8 s and 5.4 s. | IMPLEMENT step 2 |
| G6 failed climate load leaves the page blank | `app.js`: start polling regardless of the climate load; `poll()` retries `loadClimate()` while `climate` is null; `render()` draws only with climate. | IMPLEMENT step 5 |
| Screenshot 1,000-organism image not inspected | Take `main-1000.png` (optional extra file, name is our choice) from the sustained config and view it with the Read tool. | IMPLEMENT step 8 |

## Facts verified in PLAN (container)
- `node` is v18.19.1: no built-in global `WebSocket` (Node 22+ only). No `puppeteer` or `playwright` installed. Therefore the CDP
  client must be written in Python 3 stdlib (`socket`, `base64`, `hashlib`, `struct`, `json`), run with `python3 -I`.
  No new system package and no pip package is needed.
- `CHROME_BIN` and `PUPPETEER_EXECUTABLE_PATH` both point to `/usr/local/bin/chromium`.
- `python3 -c "import websocket"` fails (module absent); not needed.
- `driver.rs` lines 90 to 130: `smoke_test` (30 s + 50 s) and `screenshots` (60 s + 100 s) timeouts confirmed (G5).
- `app.js`: `loadClimate().then(() => poll())` with an empty catch: polling never starts on failure (G6), confirmed.
- README line 71 uses `scenarios/demo.json`, which does not exist (G3, confirmed). `examples/` holds only `config.json`.
- `Config` has no `Default`; `config.rs` exposes `plants`, `herbivores`, `carnivores` sections with `growth_rate`,
  `reproduction_chance`, `seed_radius`, `max_age`, `metabolism`, `reproduction_energy`, `mutation_rate`, climate and species
  settings. The population-sustaining sweep uses these existing keys only (the engine is not changed).
- The 1,000 population of the review config (96x72, 700/250/50) falls to 737 at tick 81 and 338 at tick 200, so a sweep is required.

## Decisions (new in cycle 2; full text in ADR-0024 D10 to D13)
1. **D10 Test hook.** The page exposes a read-only object `window.evosim` with `view()` (scale, ox, oy, fit, cssW, cssH,
   worldW, worldH), `stats()` (polls, frames, lastTick, living, updatesLastSecond) and `timing(n)` (draws n synthetic-free
   frames of the current organisms and returns the mean ms; it does not change state). No command endpoint is added.
2. **D11 Interaction check.** `scripts/ui_check.py` (run as `python3 -I scripts/ui_check.py`) starts `evosim ui --port 0`
   with the sustained config and a headless Chromium with `--remote-debugging-port=0 --user-data-dir=<tmp>`; reads the
   DevTools port from `DevToolsActivePort`; connects to the page target; runs these checks and prints one line per check:
   - drag: mousePressed at (cx, cy), mouseMoved by (+100, +50) in 5 steps, mouseReleased; expected `ox` and `oy` change by exactly
     the drag delta and `fit` becomes false.
   - wheel zoom anchored at the cursor: mouseWheel deltaY -300 at point P; the world cell under P stays under P within 0.5 px.
   - clamp: 40 wheel-in events give scale 64; 40 wheel-out events give scale 2.
   - double-click fit: clickCount 2 at the canvas centre; scale equals `min(cssW/W, cssH/H)`, `fit` true.
   - real-time rate: over 10 s wall clock (no virtual time), count state responses and animation frames; require at least 3 state
     responses per second and record the frame rate; record min living count over the window.
   Exit 0 only if every check passes; exit 1 on a failed check; exit 2 on a setup error. The output is kept in
   `docs/STATE.md` and the IMPLEMENT handoff.
3. **D12 Sustained 1,000 config.** `examples/ui-1000.json` is documented in the README and in ADR-0024. Selection rule: a
   candidate whose `evosim run --ticks 600 --sample-every 10` keeps living >= 1,000 at every sampled tick from tick 0 to tick 600
   for seed 42 and at least one other seed. Candidates vary world size (96x72 to 128x96) and existing keys (`plants.growth_rate`,
   `plants.reproduction_chance`, `plants.seed_radius`); the fixed keys in CONTRACT section 3 are kept. If no candidate holds 1,000
   in the sweep within the time budget, the best candidate is used, the gap is recorded as M5 NOT MET, and the M5 measurement
   reports the real population it actually had.
4. **D13 Timeouts.** Driver budgets as in G5 above; the 60 s and 120 s CONTRACT budgets become the documented upper bounds.

## Ordered IMPLEMENT steps (each step is independent enough to record on its own)
1. `driver.rs` and `app.js` (G5, G6): tighten the timeouts; start polling regardless of the climate load; retry the climate load
   in `poll()`. Unit test for the timeout constants (a `const` assertion: smoke worst case <= 60 s, screenshots worst case <= 120 s).
2. `app.js`: add the read-only `window.evosim` hook (D10). `draw()` is unchanged except for the stats counters.
3. Sweep (D12): write candidate configs under a scratch directory outside `crates/` (use `mktemp -d` and delete it after), run
   `./evosim run --config C --ticks 600 --sample-every 10 --out R` for each, pick the config per the selection rule. Record the
   candidate table in `docs/STATE.md`. Save the chosen config as `examples/ui-1000.json` with a short comment-free README note.
4. `scripts/ui_check.py` (D11, G1, G2) and `scripts/ui_check.sh` (wrapper that calls `python3 -I` and checks the exit code).
   Run it; record exit code and output. Add it to `scripts/test.sh` only if the whole run takes under 60 s.
5. Snapshot timing (G2c): the `#[ignore]` test `ui_1000_organisms_timing` uses the chosen config (not the inline 700/250/50
   world) and reports living at tick 0, 100, 200, and the snapshot encode time at 1,000 organisms.
6. `docs/decisions/ADR-0024` stays Proposed in IMPLEMENT; add D10 to D13 as implemented. Add ADR-0024 to `scripts/check_adrs.sh`
   and confirm it is in `docs/decisions/README.md`.
7. README (G3): UI section uses `./evosim ui --port 8080 --config examples/ui-1000.json`; add `./evosim ui --screenshots /tmp/shots`
   example and the ui_check command. `docs/ARCHITECTURE.md`: add the UI section (G4).
8. `main-1000.png`: `./evosim ui --screenshots DIR --config examples/ui-1000.json` writes `main.png`; copy or re-run into a second
   directory to produce a 1,000-organism image; view it with the Read tool.
9. Gates: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli -p evosim-ui --locked --all-targets`,
   `bash scripts/check_adrs.sh`, `bash scripts/test.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR`,
   `python3 -I scripts/ui_check.py`, the README example, the negative cases (exit 2), `git remote -v | wc -l` (must be 0).
   Record every exit code. Do not commit.

## Tests planned for IMPLEMENT
- Rust: timeout constants; `route()` and snapshot tests already exist (keep); `ui_1000_organisms_timing` (ignored; run with
  `--release -- --ignored --nocapture`); sweep runs via `evosim run`.
- Browser: `scripts/ui_check.py` checks in D11 (drag, zoom anchor, clamp, double-click fit, real-time rate and min living).
- Smoke and screenshots as before with the tighter budgets; PNG IHDR >= 1280x720.

## Risks
1. **No sustained 1,000 config found.** The engine's balance decides this; the plan does not change it (CONTRACT 5.3, no
   replenishment). Mitigation: the candidate sweep is wide (world size and three existing keys); if still no hit, M5 is recorded
   NOT MET with the real measured population, and the review decides. This is the biggest risk to a PASS.
2. **CDP client correctness.** A hand-written WebSocket client may fail on frame lengths or masking. Mitigation: client only sends
   masked text frames and reads unmasked server frames with 7-bit, 16-bit and 64-bit lengths; ping frames are answered with pong.
   If it fails, fall back to an in-page synthetic-event test (dispatching `PointerEvent`, `WheelEvent`, `MouseEvent`) and record
   that the input path is synthetic.
3. **Double-click in CDP.** Chromium generates `dblclick` from two `mousePressed`/`mouseReleased` pairs with `clickCount` 1 and 2.
   If not generated, the check reports it and uses the in-page fallback for this single check.
4. **Real-time measurement noise.** Software rendering in a container may give low frame rates; the check records the number and
   the threshold applied is the update rate of state responses (5 Hz design), not the frame rate.
5. **Driver timeouts.** Tightened budgets may fail on a loaded machine; the normal runs are far below the limits.
6. **Layout for TASK-024/025.** Unchanged element ids (`#controls`, `#inspector`, `#charts`).

## Container dependencies
No new system packages. Chromium 131 at `/usr/local/bin/chromium` (verified present in PLAN). Python 3 stdlib only.
Node is v18.19.1 and is not used by the UI checks.

## Not changed in PLAN
Product code, Cargo files, task.md, task.json, benchmark files, contract, AGENTS.md, CLAUDE.md, examples, scripts. No commit.
The ADR-0024 and docs/STATE.md edits are planning records only.

# TASK-023 REVIEW cycle 1: UI window and world view

Verdict: **FAIL**. Machine-readable record: `review-cycle1.json`. ADR-0024 stays `Proposed` (it is set to Accepted only on PASS).
No product code, task.md, task.json, benchmark files or commits were changed in REVIEW.

## What was checked
- Read AGENTS.md, PROJECT.md, CONTRACT.md (sections 1 to 5), STATE.md (TASK-023 plan and implement records), ARCHITECTURE.md,
  task.md/task.json, plan and implement handoffs, ADR-0024, and the diff of commits a785ca5 and c62b76c.
- Read the UI source: `crates/evosim-ui/src/{lib,driver,server,snapshot}.rs`, `web/{index.html,app.js,style.css}`,
  `crates/evosim-cli/src/{args,main}.rs`, README UI section.

## Must-have results
| # | Requirement | Result | Evidence |
|---|---|---|---|
| M1 | `./evosim ui` starts a local server driving the same engine | PASS | `./evosim ui --port 0` printed `evosim ui: http://127.0.0.1:PORT/` and served until killed (`timeout 5` gave 124). Uses `evosim_core::sim::Simulation` + `populate_initial`, as `runner::run_config` does. |
| M2 | Cells coloured by biome; organisms on top; plants, herbivores, carnivores distinguishable | PASS | `/tmp/review-shots/main.png` (1280x807) viewed: biome bands, green squares, amber circles, red triangles, counts in header. |
| M3 | Legend explains colours and symbols | PASS | Sidebar legend in the screenshot lists the five biomes and three shapes. |
| M4 | Pan and zoom | **NOT VERIFIED (FAIL)** | Implemented in `app.js` (drag pans; wheel zooms around the cursor, 2 to 64 px per cell; double-click fits). No automated test and no recorded command exercises it. The Must-have rule requires a test or a recorded command. |
| M5 | 1,000 organisms: usable, updates several times per second | **NOT DEMONSTRATED (FAIL)** | Population from the 1,000-founder config (96x72, 700/250/50) falls quickly: living 1116 at tick 20, 737 at tick 81, 338 at tick 200 (`ui_1000` test, implement record). So 1,000 live organisms exist only for the first ~10 to 20 ticks. The snapshot cost is measured at 0.066 ms average at 338 organisms, not at 1,000. The page update rate (5 Hz poll, 20 ticks/s simulation) is by design; the real-time browser frame rate was not measured. |
| M6 | `./evosim ui --smoke-test` passes (CONTRACT 2) | PASS | Exit 0, `smoke test passed (smoke frames=1 tick=14)`, 0.77 s (implement); re-run in review with the same result. |
| M7 | README explains how to start the UI | PASS with defect | Section "UI: the world view" exists. Its second example `./evosim ui --port 8080 --config scenarios/demo.json` fails: `scenarios/demo.json` does not exist, exit 2. |

Screenshot point (not a fail reason alone): `./evosim ui --screenshots DIR` wrote `main.png` 1280x807 (IHDR), exit 0, 5.4 s.

## Other checks
- `cargo test --workspace --locked`: exit 0. cli unit 36, batch_cli 8, checkpoint_cli 2, run_cli 9, core 423 (1 ignored), ui 14 (1 ignored).
  Note: the implement run had 33 cli unit tests before its last edits; the 3 `ui_` parser tests added after that run account for 36.
- `cargo clippy -p evosim-core -p evosim-cli -p evosim-ui --locked --all-targets`: finished with no warnings (exit status not captured through the pipe).
- `bash scripts/check_adrs.sh`: exit 0, checks=153 failed=0 (ADR-0024 is not in the check list yet).
- Negative CLI cases, all exit 2 as specified: `--smoke-test --screenshots /tmp`, `--config /nonexistent.json`,
  `--screenshots /nonexistent-dir`, `--port x`, and the README example with the missing `scenarios/demo.json`.
- `git remote -v | wc -l` = 0.

## Gaps (remediation for the next PLAN)
- **G1 (M4) pan and zoom unverified.** Add a recorded check: a script or page mode that sends wheel and pointer events to the real page (for example via Chromium `--remote-debugging-port` and a small CDP client, or a `?interact=1` test mode that performs synthetic drag and wheel events and writes the resulting view scale and offset into the title), and record exit code and output. Include the zoom clamp (2 to 64) and the fit reset.
- **G2 (M5) 1,000 organisms not shown as a sustained state.** Either choose a configuration whose live population stays at about 1,000 for the check window (fixed keys only, for example higher plant growth or a larger world; this must be a documented config, not a code change to the simulation), or measure the page with 1,000 organisms present at the start. Record: snapshot build and encode time at 1,000 organisms, page poll and draw rate in a real-time headless run (not virtual time), and the number of organisms at the time of measurement.
- **G3 (M7) README example broken.** Change the example to an existing file (for example add `examples/ui-1000.json` or use `examples/` configs that exist), and re-run the example command.
- **G4 (ADR and docs).** Add ADR-0024 to `scripts/check_adrs.sh` and `docs/decisions/README.md` (already in the index), add the ARCHITECTURE UI section, and set ADR-0024 to Accepted once G1 and G2 pass. Not a criterion, but the plan asked for it.
- **G5 (smoke and screenshot budgets, minor).** `driver::smoke_test` waits up to 30 s for tick 10 and then up to 50 s for Chromium, so the worst case exceeds the 60 s budget; `driver::screenshots` allows 60 s plus 100 s against the 120 s budget. The normal runs are far below the limits. Tighten the timeouts so the worst case is within the contract budgets, or document the bound.
- **G6 (minor, not a criterion).** `app.js`: if `loadClimate()` fails, `poll()` never starts and the page stays blank with no retry. Start polling regardless, or retry the climate load.

## Verdict basis
FAIL, because M4 (pan and zoom) has no test or recorded command and M5 (1,000 organisms) is not demonstrated as a sustained update rate. M1, M2, M3, M6 and the screenshot path pass with evidence. M7 needs the README fix (G3).

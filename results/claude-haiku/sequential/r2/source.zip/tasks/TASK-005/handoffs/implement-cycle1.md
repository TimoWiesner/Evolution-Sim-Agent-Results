# TASK-005 IMPLEMENT cycle 1 — notes

Scope: clock, random numbers and tick scheduler (`tasks/TASK-005/task.md`), following `tasks/TASK-005/handoffs/plan-cycle1.md`
and ADR-0008. Verdict is N/A (IMPLEMENT).

## What was built
- `crates/evosim-core/src/rng.rs`: `Rng` (xoshiro256**, SplitMix64 seeding), `RngError::AllZeroState`, `fingerprint` (crate-private).
  Methods: `from_seed`, `from_state`, `state`, `next_u64`, `next_below` (rejection, panics on 0), `next_f64`, `chance`.
- `crates/evosim-core/src/sim.rs`: `Phase` (9 variants), `PHASE_ORDER`, `TraceRecord`, `World { topology: Torus }`,
  `SimError` (`Topology`, `SideTooLarge`), `Simulation` (`new(&Config)`, `from_parts`, `tick`, `run`, `tick_count`,
  `rng_state`, `rng_mut`, `world`, `set_trace`, `trace`).
- `lib.rs`: `pub mod rng; pub mod sim;`.
- `scripts/check_adrs.sh`: ADR-0008 added to the checked list (65 checks).
- Docs: ADR-0008 (Implementation notes; status still Proposed), `docs/STATE.md` (IMPLEMENT block), `docs/ARCHITECTURE.md` (status line).

## Acceptance criteria -> evidence
1. Tick counter, RNG and world in one state; one function advances exactly one tick:
   `sim::tests::tick_advances_counter_by_exactly_one`, `new_uses_config_seed_and_world_size`.
2. All randomness from a config-seeded generator; no wall clock or unseeded generator:
   `new_uses_config_seed_and_world_size`; grep for `SystemTime|Instant|thread_rng|rand::` in `crates/evosim-core/src` -> no match.
3. Fixed, documented step order and stable tie rule: `phase_order_is_fixed`, `trace_has_nine_records_per_tick_in_order`
   (module doc in `sim.rs` documents the order; ties by ascending id per ADR-0008).
4. RNG state exported and restored exactly: `rng::tests::state_export_restore_continues_identically`,
   `restore_rng_mid_run_reproduces_rest_of_trace` (run 50, export, `from_parts`, run 50 more; trace equal to the uninterrupted run).
5. Same seed -> identical trace over 100 ticks; different seed -> different trace:
   `trace_identical_for_same_seed_over_100_ticks` (900 records), `trace_differs_for_different_seed_over_100_ticks`.
6. Core has no UI dependency: `check_adrs.sh` grep check (PASS).

## Commands and exit codes (from /workspace, PATH includes /opt/rust/cargo/bin)
| Command | Exit | Result |
|---|---|---|
| `cargo test -p evosim-core --locked` | 0 | 97 passed |
| `cargo clippy -p evosim-core --locked --all-targets` | 0 | 0 warning lines (one doc-list warning fixed first) |
| `cargo test --workspace --locked` | 0 | core 97, cli 9 |
| `rustfmt --edition 2021 --check` on the two new files | 0 | formatted |
| `bash scripts/check_adrs.sh` | 0 | checks=65 failed=0 |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED |
| `git remote -v \| wc -l` | 0 | 0 |

No system packages were installed.

## Deviations from plan (details in ADR-0008 Implementation notes)
- `from_parts` returns `Result` (rejects all-zero RNG state).
- `SimError::SideTooLarge` added for sides beyond `u32`.
- `Simulation::world()` and `rng_mut()` added; `rng_mut` is the route for later phases to draw.

## Known weakness for REVIEW
- Phase bodies are empty, so no draw happens inside a tick: every trace record of tick t has the same fingerprint.
  The trace tests pass, but they only show the seed sets the initial state. Judge with this in mind; the trace
  becomes meaningful once TASK-006+ draw.
- ADR-0008 status is left at Proposed for REVIEW to set Accepted.

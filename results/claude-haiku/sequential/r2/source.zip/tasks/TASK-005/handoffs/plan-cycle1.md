# TASK-005 PLAN cycle 1: clock, random numbers and tick scheduler

No feature code changed in this phase. Decisions are in `docs/decisions/ADR-0008-random-generator-and-tick-scheduler.md`
(Proposed). This file is the ordered IMPLEMENT recipe.

## Scope recap (from tasks/TASK-005/task.md)
- One `Simulation` state holding tick counter, RNG and world; one function advances it by exactly one tick.
- All randomness from a generator seeded by the configuration. No wall clock, no unseeded global generator.
- Fixed, documented step order and organism order; stable tie rule.
- Generator state exportable and restorable exactly (for checkpoints, TASK-022).
- Tests: same seed gives identical trace over >= 100 ticks; different seed gives a different trace.
- Core has no UI dependency.
- Not in scope: climate, plant, animal behaviour (TASK-006 onwards).

## Decisions (summary; full text in ADR-0008)
1. Generator: xoshiro256** (four `u64` words), seeded by SplitMix64 from one `u64`. In-house, no crate.
   Reason: small exportable state, fast, public reference vectors, no dependency (ADR-0001 keeps crates minimal).
2. Tick order (fixed `PHASE_ORDER`, each phase once per tick): Climate, SpatialIndex, Plants, Herbivores,
   Carnivores, Reproduction, Deaths, Species, Counters. Then the tick counter increases by one.
   Reason: matches `docs/ARCHITECTURE.md` determinism rule 2; each phase has a clear boundary.
3. Sampling is outside `tick()` (read-only observer). Reason: it cannot change state.
4. Organism order: ascending id everywhere; any tie falls back to id. Ids come from a `u64` counter (TASK-008).
5. Step/event representation: phase enum plus direct state mutation; no event queue. Counters are plain fields.
   Optional trace `Vec<TraceRecord { tick, phase, rng_fingerprint }>`, off by default.

## Interfaces (planned, `crates/evosim-core`)
- `src/rng.rs` (new): `pub struct Rng`, `pub enum RngError { AllZeroState }`,
  `Rng::from_seed(u64) -> Rng`, `Rng::from_state([u64;4]) -> Result<Rng, RngError>`, `Rng::state(&self) -> [u64;4]`,
  `next_u64(&mut self) -> u64`, `next_below(&mut self, n: u64) -> u64` (panics if n == 0; rejection sampling),
  `next_f64(&mut self) -> f64` in `[0,1)`, `chance(&mut self, p: f64) -> bool`.
  Private helpers: `splitmix64(&mut u64) -> u64`, `fingerprint(state) -> u64` (fixed 64-bit mix used by the trace).
- `src/sim.rs` (new): `pub enum Phase` (9 variants, `Copy`, `Debug`, `Eq`), `pub const PHASE_ORDER: [Phase; 9]`,
  `pub struct TraceRecord { pub tick: u64, pub phase: Phase, pub rng_fingerprint: u64 }`,
  `pub struct World { pub topology: Torus }` (climate and organisms added by later tasks),
  `pub struct Simulation { tick, rng, world, trace: Option<Vec<TraceRecord>> }`,
  `Simulation::new(&Config) -> Result<Simulation, SimError>` (uses `config.seed` and `config.world`; converts
  `u64` sizes to `u32` through `Torus::new`, mapping failure to `SimError`),
  `Simulation::from_parts(tick, rng, world)` (for checkpoint restore later; not used in TASK-005 except tests),
  `tick(&mut self)`, `run(&mut self, n: u64)`, `tick_count(&self) -> u64`, `rng_state(&self) -> [u64;4]`,
  `set_trace(&mut self, on: bool)`, `trace(&self) -> &[TraceRecord]`.
  `pub enum SimError { Topology(TopologyError) }` with `Display` and `Error`.
- `src/lib.rs`: add `pub mod rng;` and `pub mod sim;`. Existing `pub mod config; pub mod world;` unchanged.
- No changes to `Cargo.toml` (no new crate). No changes to `evosim-cli` or `evosim-ui`.

## Ordered IMPLEMENT steps
1. Create `src/rng.rs` with SplitMix64 and xoshiro256** exactly as ADR-0008 describes; add the unit tests in a
   `#[cfg(test)] mod tests` at the bottom of the file (test names below).
2. Add `pub mod rng;` to `lib.rs`. Run `cargo test -p evosim-core --locked`; expected 74 + new rng tests, exit 0.
3. Create `src/sim.rs` with `Phase`, `PHASE_ORDER`, `TraceRecord`, `World`, `Simulation`, `SimError`.
   `tick()` does: for each phase in `PHASE_ORDER` call `self.run_phase(phase)` (a `match`; all arms empty in TASK-005
   except that each arm is the place where the later task adds code), then push a trace record if tracing is on,
   then `self.tick += 1`. Trace records carry the tick being simulated (`t`), so the first tick has `tick = 0`.
   Document the order and the rule in the module doc comment.
4. Add `pub mod sim;` to `lib.rs`. Add tests (module `sim` tests, inline or in `src/sim/tests.rs` if long).
5. Documentation during IMPLEMENT: update `docs/STATE.md` (IMPLEMENT block with exact commands and exit codes),
   `docs/ARCHITECTURE.md` status line, ADR-0008 status to Accepted only if all its verification items pass.
   Add an "Implementation notes" section to ADR-0008 for anything that differs from this plan.
6. Optional but recommended: extend `scripts/check_adrs.sh` ADR list with ADR-0008 (headings check). It currently
   checks ADR-0001..0004 only; if extended, the check count changes and STATE must say so.
7. Run and record the commands listed under Tests. Check `git remote -v | wc -l` = 0. Do not commit.

## Tests (names are planned; the IMPLEMENT phase may add more, not fewer)
rng (in `rng.rs`):
- `splitmix64_seed0_first_output_matches_reference`: `0xE220A8397B1DCDAF`.
- `xoshiro_reference_vector_state_1_2_3_4`: first output `11520`.
- `same_seed_same_sequence` (10,000 draws), `different_seed_different_sequence` (seeds 1 and 2 differ in first 16 draws).
- `seed_zero_is_valid` (no panic, not all-zero state).
- `from_state_rejects_all_zero`; `state_export_restore_continues_identically` (draw 1000, export, restore, compare 1000 more).
- `next_below_stays_in_range_and_covers_small_n` (n = 1 gives 0 always; n = 3 and n = 7 hit every value over 10,000 draws);
  `next_below_zero_panics`.
- `next_f64_in_unit_interval` (10,000 draws in [0,1)); `chance_extremes` (p = 0 never, p = 1 always).

sim (in `sim.rs` or `sim/tests.rs`):
- `phase_order_is_fixed` (equals the nine names in the documented order).
- `tick_advances_counter_by_exactly_one` (tick_count 0 -> 1 -> 2; `run(5)` gives 5 more).
- `new_uses_config_seed_and_world_size` (Config from `Config::new(seed, w, h, initial)`; `rng_state` equals
  `Rng::from_seed(seed).state()`; topology width and height match).
- `new_rejects_bad_world_size` only if `Config` allows it; otherwise `SimError` path tested via `Torus::new(0, 1)` mapping.
- `trace_has_nine_records_per_tick_in_order` (tick 0..2, nine records each, phases in `PHASE_ORDER`, ticks non-decreasing).
- `trace_identical_for_same_seed_over_100_ticks`: two `Simulation`s from the same config, trace on, run 100 ticks, traces
  equal (`PartialEq` on `Vec<TraceRecord>`).
- `trace_differs_for_different_seed_over_100_ticks`: seeds 1 and 2, same config otherwise; traces differ.
- `trace_off_by_default_and_records_nothing`.
- `restore_rng_mid_run_reproduces_rest_of_trace`: run 50 ticks, export `rng_state` and `tick_count`, rebuild with
  `Simulation::from_parts`, run 50 more on both; traces for ticks 50..100 are equal. This is the checkpoint precondition.
- `core_has_no_ui_or_cli_dependency`: covered by `scripts/check_adrs.sh` (existing check); not a Rust test.
- Static: `grep -rn 'SystemTime\|Instant\|thread_rng\|rand::' crates/evosim-core/src` returns no lines (grep exit 1).

## Commands for the IMPLEMENT phase (run from /workspace; PATH must contain /opt/rust/cargo/bin)
- `cargo test -p evosim-core --locked` (exit 0, expected count 74 + new tests)
- `cargo clippy -p evosim-core --locked --all-targets` (exit 0, no `warning` lines)
- `cargo test --workspace --locked` (exit 0; cli 9 tests unchanged)
- `bash scripts/check_adrs.sh` (exit 0, checks=54 failed=0 unless the optional ADR-0008 extension changes the count)
- `bash scripts/test.sh` (exit 0, "ALL TESTS PASSED"; includes setup and build, so it needs network only if cargo
  fetch is needed; the crate set is unchanged)
- `git remote -v | wc -l` (= 0)

## Risks
1. **Trace may look trivial.** With all phases empty in TASK-005, the RNG state never changes during a tick, so the
   per-phase fingerprint is constant within a run and differs between seeds only through the initial state. The
   test still shows what the task asks, but a reviewer may judge it weak. Mitigation in IMPLEMENT: the
   `restore_rng_mid_run_reproduces_rest_of_trace` test and the reference vectors give non-trivial coverage; the
   trace becomes meaningful once TASK-006+ draws. Record this in the REVIEW input.
2. **Reference vector values.** The SplitMix64 seed-0 value and the xoshiro state `[1,2,3,4]` value are taken from
   the public algorithms as written in ADR-0008. If the implementation disagrees, check the implementation first,
   then recompute with an independent script (Python 3 `-I`, outside the workspace) before changing the test.
3. **Rejection loop in `next_below`.** Deterministic (same stream, same result). The expected draws per call are below 2.
   No risk of non-termination for n >= 1.
4. **Config size conversion.** `Config` stores `u64`; `Torus::new` takes `u32`. Use `u32::try_from`; the config
   validator already caps sides at 4096, so the conversion cannot fail for a validated config, but the code must not
   panic on a hand-built one.
5. **Future drift of phase order.** Later tasks must not reorder `PHASE_ORDER` without a new ADR; the test
   `phase_order_is_fixed` is the guard.
6. **Trace memory.** Off by default. With trace on, 9 records per tick; 10,000 ticks use about 2 MB.
7. **Carried gaps (not blocking TASK-005):** G-023 (no compass-direction helper, TASK-004 review), G-024
   (`neighbours` allocates a Vec, unmeasured), G-016 (`Config::save` does not create parent directories, owned by TASK-019),
   G-022 (cosmetic message wording, TASK-003).

## Environment (checked in PLAN)
- `cargo --version` = cargo 1.100.0 (`/opt/rust/cargo/bin`).
- `cargo test -p evosim-core --locked`: exit 0, 74 passed, 0 failed (baseline before any TASK-005 change).
- `bash scripts/check_adrs.sh`: checks=54 failed=0, exit 0.
- `git remote -v | wc -l` = 0. `git status` was clean at the start of the phase.
- System dependencies: none needed for TASK-005 (no apt packages). Nothing installed in PLAN.

## Dependencies on other tasks
- Consumes TASK-003 (`Config`, seed, world size) and TASK-004 (`Torus`).
- Provides the frame for TASK-006 (climate in `World`), TASK-008 (organism store in `World`, id counter), TASK-022
  (checkpoint of `rng_state`, `tick_count`), TASK-011/TASK-010 (phase bodies).

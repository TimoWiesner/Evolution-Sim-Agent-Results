# TASK-005 REVIEW cycle 1 — notes

Verdict: **PASS**. Reviewed the IMPLEMENT cycle 1 code (commit a86a4a8): `crates/evosim-core/src/rng.rs`,
`crates/evosim-core/src/sim.rs`, `lib.rs`, `scripts/check_adrs.sh`, plus ADR-0008, the plan and implement handoffs.

## Acceptance criteria -> evidence
1. One state holds tick, RNG and world; one function advances exactly one tick: `Simulation::tick` (sim.rs),
   tests `tick_advances_counter_by_exactly_one`, `new_uses_config_seed_and_world_size`.
2. All randomness from a config-seeded generator; no wall clock or unseeded generator: `Rng::from_seed(config.seed)`
   in `Simulation::new`; grep for `SystemTime|Instant|thread_rng|rand::` in `crates/evosim-core/src` is empty.
3. Fixed, documented step order; stable tie rule: `PHASE_ORDER` with test `phase_order_is_fixed`; order documented in
   sim.rs module doc and ADR-0008. Organism order is ascending id by rule; no organisms exist yet, so it is not exercised.
4. Generator state exported and restored exactly: `Rng::state`, `Rng::from_state`, `Simulation::from_parts`; tests
   `state_export_restore_continues_identically`, `restore_rng_mid_run_reproduces_rest_of_trace`.
5. Same seed, identical 100-tick trace; different seed, different trace: tests
   `trace_identical_for_same_seed_over_100_ticks` (900 records) and `trace_differs_for_different_seed_over_100_ticks`.
   Caveat recorded as G-025 (non-blocking): the trace is one RNG fingerprint per run because no phase draws yet.
6. Core has no UI or CLI dependency: grep for `evosim_ui|evosim-ui|evosim_cli|evosim-cli` in the core is empty;
   `check_adrs.sh` PASS.

## Commands re-run in this phase (from /workspace, PATH includes /opt/rust/cargo/bin)
| Command | Exit | Result |
|---|---|---|
| `cargo test -p evosim-core --locked` | 0 | 97 passed |
| `cargo clippy -p evosim-core --locked --all-targets` | 0 | 0 warning lines |
| `cargo test --workspace --locked` | 0 | core 97, cli 9 |
| `bash scripts/check_adrs.sh` | 0 | checks=65 failed=0 |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED |
| `git remote -v \| wc -l` | 0 | 0 |

Independent check: the SplitMix64 seed-0 vector and the xoshiro256** `[1,2,3,4]` vector were recomputed with
Python 3 (`python3 -I`, scratch script in `/tmp/review5-probe`, outside the repo). Both match the code.
I also read the xoshiro256** update step by hand against the reference algorithm; it matches.

## Findings
- G-025 (non-blocking, test-coverage): the trace tests pass for any scheduler that seeds the RNG, because the trace
  holds a constant fingerprint. Fix in TASK-006 or later: add a test where a draw inside a phase changes the trace.
- Observations, not gaps: `Config` fields are public, so an unvalidated config can reach `Simulation::new`; zero and
  oversized sides are still rejected there (`SimError`), so no panic was found. `rng_mut()` is public; later phases
  must draw only inside `run_phase`.

## Docs changed in this phase
- `docs/decisions/ADR-0008-random-generator-and-tick-scheduler.md`: status Accepted, review note appended.
- `docs/STATE.md`: status line and a REVIEW (TASK-005 cycle 1) block.
- `docs/ARCHITECTURE.md`: TASK-005 status line.
- Not changed: code, tests, Cargo files, CLI, UI, `task.md`, `task.json`. Nothing committed.

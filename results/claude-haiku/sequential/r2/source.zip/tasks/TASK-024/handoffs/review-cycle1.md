# TASK-024 REVIEW cycle 1: run controls and inspector

Verdict: **PASS**. No product code changed in REVIEW. Machine-readable handoff: `review-cycle1.json`.

## Criteria
| Criterion | Evidence |
|---|---|
| Run, pause, single step, reset, speed; step = one tick | Browser check (buttons and `.` key, 40/40 checks); `control.rs` tests; `control_check.py` |
| Reset gives the same starting world | `control.rs` reset tests (state_hash); HTTP checkpoint bytes equal; browser reset to tick 0 |
| Speed >= 3 levels, never negative | `SPEED_LEVELS = [1, 5, 20, 60]`; browser clamps at 1 and 60 |
| Tick and per-kind counts visible | Header in browser check and screenshots |
| Inspector: ID, kind, species, age, energy, health, traits, genome, parents | Browser check text assertions; `inspector.rs` tests |
| Follows while running; shows death | Browser: followed herbivore #700, "died at tick 14: predation, cell (76, 0)" |
| Checkpoint save and load in UI | Browser: download 195016 bytes; reload restored tick 149; invalid upload reported |
| Control logic without display | `control.rs`, `inspector.rs`, `server.rs` unit tests |

## Commands (all exit 0)
`cargo test --workspace --locked --offline`, `cargo clippy -p evosim-ui --all-targets --locked --offline`, `node --check app.js`, `scripts/check_adrs.sh` (175/0), `./build.sh`, `./evosim ui --smoke-test`, `scripts/ui_check.sh`, `./evosim ui --screenshots DIR`, `scripts/control_check.py`, `git remote -v | wc -l` = 0. Browser check: `review-evidence/review_ui_browser_check.py` 40/40. Speed 60: 59.8 ticks/s over 5 s.

## Open items (not failing)
- No `inspector.png`; `main.png` satisfies the screenshot point.
- The inspector is below the legend in the sidebar and needs scrolling at 1280x807.
- Browser load of a checkpoint with a different world size is unit-tested only.

Evidence is in `review-evidence/`. ADR-0025 is now Accepted. STATE.md has the REVIEW entry.

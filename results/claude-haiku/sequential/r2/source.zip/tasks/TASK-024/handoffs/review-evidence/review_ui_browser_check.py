"""REVIEW TASK-024 cycle 1: drive the real page in headless Chromium over CDP (real mouse and key events)."""
import base64, json, os, socket, subprocess, sys, tempfile, time, urllib.request, shutil
sys.path.insert(0, "/workspace/scripts")
import importlib.util
spec = importlib.util.spec_from_file_location("ui_fps_ws", "/workspace/scripts/ui_fps.py")
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
WS = m.WS
OUT = "/tmp/review"
CHROME = "/usr/local/bin/chromium"
results = []
def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""), flush=True)

port = m.free_port()
server = subprocess.Popen(["/workspace/evosim", "ui", "--port", str(port), "--config", "/workspace/examples/ui-1000.json"],
                          stdout=subprocess.DEVNULL, stderr=open(f"{OUT}/server.log", "w"))
api = f"http://127.0.0.1:{port}"
for _ in range(200):
    try:
        urllib.request.urlopen(api + "/api/climate", timeout=2).read(); break
    except OSError:
        time.sleep(0.05)
def state():
    return json.loads(urllib.request.urlopen(api + "/api/state", timeout=5).read())

chrome, ws = None, None
try:
    proc, prof, ws = m.start_chromium(CHROME, api + "/")
    chrome = (proc, prof)
    ok = m.wait_for(ws, "!!window.evosim && window.evosim.stats().tick >= 3", 30)
    check("page loads and the simulation runs", ok)
    time.sleep(0.5)

    def ev(expr, await_promise=False):
        return ws.evaluate(expr, await_promise=await_promise)
    def center(sel):
        return ev(f"(()=>{{const r=document.querySelector('{sel}').getBoundingClientRect();return [r.left+r.width/2, r.top+r.height/2]}})()")
    def click(sel):
        x, y = center(sel)
        ws.call("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": x, "y": y})
        ws.call("Input.dispatchMouseEvent", {"type": "mousePressed", "x": x, "y": y, "button": "left", "clickCount": 1})
        ws.call("Input.dispatchMouseEvent", {"type": "mouseReleased", "x": x, "y": y, "button": "left", "clickCount": 1})
        time.sleep(0.4)
    def key(k, code, text=None):
        p = {"key": k, "code": code, "windowsVirtualKeyCode": 0}
        if text is not None: p["text"] = text
        ws.call("Input.dispatchKeyEvent", dict(p, type="keyDown"))
        ws.call("Input.dispatchKeyEvent", dict(p, type="keyUp"))
        time.sleep(0.4)
    def btn_text(sel):
        return ev(f"document.querySelector('{sel}') && document.querySelector('{sel}').textContent")
    def btn_disabled(sel):
        return ev(f"document.querySelector('{sel}').disabled")
    def speed_label():
        return ev("document.getElementById('speed-label').textContent")
    def ctl():
        return state()["control"]
    time.sleep(0.5)

    # Initial visibility.
    s = state()
    check("header shows tick and per-kind counts", ev("document.getElementById('tick').textContent").startswith("tick ")
          and ev("document.getElementById('n-plants').textContent").startswith("plants ")
          and ev("document.getElementById('n-herbivores').textContent").startswith("herbivores ")
          and ev("document.getElementById('n-carnivores').textContent").startswith("carnivores "))
    check("initial state: running, default speed 20", s["control"]["running"] and s["control"]["speed"] == 20 and speed_label() == "20 ticks/s", speed_label())

    # Pause and single step.
    click("#btn-run")
    check("Run button pauses (label Run, not running)", btn_text("#btn-run") == "Run" and not ctl()["running"], btn_text("#btn-run"))
    check("Step enabled while paused", not btn_disabled("#btn-step"))
    time.sleep(0.5)
    t0 = state()["tick"]; time.sleep(1.0); t1 = state()["tick"]
    check("paused: tick does not advance", t0 == t1, f"{t0}->{t1}")
    for i in range(2):
        before = state()["tick"]
        click("#btn-step")
        after = state()["tick"]
        check(f"Step button advances exactly one tick (#{i+1})", after == before + 1, f"{before}->{after}")
    before = state()["tick"]; key(".", "Period", "."); after = state()["tick"]
    check("'.' shortcut steps exactly one tick", after == before + 1, f"{before}->{after}")

    # Space toggles run/pause.
    key(" ", "Space", " ")
    check("Space runs", ctl()["running"])
    time.sleep(1.0)
    check("running: tick advances", state()["tick"] > after)
    check("Step disabled while running", btn_disabled("#btn-step"))
    key(" ", "Space", " ")
    check("Space pauses again", not ctl()["running"])

    # Speed.
    click("#btn-faster")
    check("Faster gives 60 ticks/s", ctl()["speed"] == 60 and speed_label() == "60 ticks/s", speed_label())
    check("Faster disabled at top level", btn_disabled("#btn-faster"))
    click("#btn-slower"); click("#btn-slower"); click("#btn-slower"); click("#btn-slower")
    check("Slower clamps at 1 ticks/s, disabled", ctl()["speed"] == 1 and btn_disabled("#btn-slower"), speed_label())
    key("+", "Equal", "+")
    check("'+' shortcut gives 5 ticks/s", ctl()["speed"] == 5, speed_label())
    key("-", "Minus", "-"); key("-", "Minus", "-")
    check("'-' shortcut clamps at 1 ticks/s", ctl()["speed"] == 1)

    # Reset while paused gives tick 0 and keeps paused.
    click("#btn-faster"); click("#btn-faster"); click("#btn-faster")  # back to 60 for later
    click("#btn-reset")
    s = state()
    check("Reset button returns to tick 0 and keeps paused", s["tick"] == 0 and not s["control"]["running"], f"tick={s['tick']}")

    # Selection: pick the first living organism that is on screen, real mouse click.
    s = state()
    v = ev("window.evosim.view()")
    rect = ev("(()=>{const r=document.getElementById('world').getBoundingClientRect();return [r.left,r.top]})()")
    def fx(i):
        a = (i * 0.6180339887498949) % 1; b = (i * 0.3247179572447460) % 1
        return 0.2 + 0.6 * a, 0.2 + 0.6 * b
    target = None
    KN = {0: "plant", 1: "herbivore", 2: "carnivore"}
    for oid, kcode, x, y in s["organisms"]:
        kind = KN[kcode]
        if kind == "herbivore" or target is None:
            fxv, fyv = fx(oid)
            px = rect[0] + v["ox"] + (x + fxv) * v["scale"]
            py = rect[1] + v["oy"] + (y + fyv) * v["scale"]
            if 0 <= px <= v["cssW"] and 0 <= py <= v["cssH"]:
                target = (oid, kind, px, py)
                if kind == "herbivore":
                    break
    if target is None:
        check("found an organism on screen to click", False)
    else:
        oid, kind, px, py = target
        ws.call("Input.dispatchMouseEvent", {"type": "mouseMoved", "x": px, "y": py})
        ws.call("Input.dispatchMouseEvent", {"type": "mousePressed", "x": px, "y": py, "button": "left", "clickCount": 1})
        ws.call("Input.dispatchMouseEvent", {"type": "mouseReleased", "x": px, "y": py, "button": "left", "clickCount": 1})
        time.sleep(1.0)
        head = ev("(()=>{const h=document.querySelector('#inspector-body h3');return h?h.textContent:null})()")
        check("click selects organism; inspector header shows kind and id", head == f"{kind} #{oid}", f"{head} expected {kind} #{oid}")
        body = ev("document.getElementById('inspector-body').textContent")
        for word in ["species", "alive", "age", "energy", "health", "Traits", "Genome", "haplotype", "Parents", "generation"]:
            check(f"inspector shows '{word}'", word in body)
        check("selected organism in /api/state control.selected", state()["control"]["selected"] == oid)
        png = ws.call("Page.captureScreenshot", {"format": "png"})["data"]
        open(f"{OUT}/selected_paused.png", "wb").write(base64.b64decode(png))

        # Follow while running.
        click("#btn-run" if False else "#btn-run")  # run
        time.sleep(2.0)
        head2 = ev("(()=>{const h=document.querySelector('#inspector-body h3');return h?h.textContent:null})()")
        org = json.loads(urllib.request.urlopen(f"{api}/api/organism?id={oid}").read())
        dead_txt = ev("document.querySelector('#inspector-body .status') && document.querySelector('#inspector-body .status').textContent")
        check("inspector still follows the organism while running", head2 == f"{kind} #{oid}", f"{head2}; status={org['status']} age={org['organism']['age']}; line='{dead_txt}'")
        check("inspector status line agrees with /api/organism", (org["status"] == "dead") == (dead_txt or "").startswith("died at tick"), dead_txt)
        check("organism detail age increases while running", org["organism"]["age"] > 0)
        png = ws.call("Page.captureScreenshot", {"format": "png"})["data"]
        open(f"{OUT}/selected_running.png", "wb").write(base64.b64decode(png))
        click("#btn-run")  # pause
        # Escape clears the selection.
        key("Escape", "Escape")
        time.sleep(0.5)
        check("Escape clears selection", ctl()["selected"] is None and "Click an organism" in ev("document.getElementById('inspector-body').textContent"))

    # Checkpoint: download bytes, then load them back through the file input.
    raw_b64 = ev("(async()=>{const r=await fetch('/api/checkpoint');const b=new Uint8Array(await r.arrayBuffer());let s='';for(let i=0;i<b.length;i+=8192)s+=String.fromCharCode.apply(null,b.subarray(i,i+8192));return btoa(s)})()", await_promise=True)
    data = base64.b64decode(raw_b64)
    check("checkpoint download returns bytes", len(data) > 1000, f"{len(data)} bytes")
    path = f"{OUT}/saved.evockpt"; open(path, "wb").write(data)
    # Advance some ticks, then load the checkpoint back.
    saved_tick = state()["tick"]
    click("#btn-step"); click("#btn-step"); click("#btn-step")
    advanced = state()["tick"]
    root = ws.call("DOM.getDocument", {"depth": -1}) if False else None
    doc = ws.call("DOM.getDocument", {"depth": 1})
    node = ws.call("DOM.querySelector", {"nodeId": doc["root"]["nodeId"], "selector": "#file-load"})["nodeId"]
    ws.call("DOM.setFileInputFiles", {"files": [path], "nodeId": node})
    time.sleep(1.5)
    st = ev("document.getElementById('ctl-status').textContent")
    loaded_tick = state()["tick"]
    check("loading the checkpoint restores its tick", loaded_tick == saved_tick, f"saved={saved_tick} advanced={advanced} now={loaded_tick} status='{st}'")
    # Invalid upload is refused and reported.
    bad = f"{OUT}/bad.evockpt"; open(bad, "wb").write(b"not a checkpoint at all")
    ws.call("DOM.setFileInputFiles", {"files": [bad], "nodeId": node})
    time.sleep(1.5)
    st2 = ev("document.getElementById('ctl-status').textContent + '|' + document.getElementById('ctl-status').className")
    check("invalid checkpoint is reported on the page as an error", "error" in st2, st2)
    check("invalid checkpoint leaves the world unchanged", state()["tick"] == loaded_tick)

    # Climate refetch after load: climate_version changed, the page keeps drawing.
    check("page still reports stats after load", ev("window.evosim.stats().tick") is not None)
    ws.call("Page.captureScreenshot", {"format": "png"})
    png = ws.call("Page.captureScreenshot", {"format": "png"})["data"]
    open(f"{OUT}/page_final.png", "wb").write(base64.b64decode(png))
except Exception as e:
    check("review script ran without exception", False, repr(e))
finally:
    if chrome: m.stop(*chrome)
    server.kill(); server.wait()
ok_all = all(r[1] for r in results)
print("SUMMARY", sum(r[1] for r in results), "/", len(results), "PASS" if ok_all else "FAIL", flush=True)

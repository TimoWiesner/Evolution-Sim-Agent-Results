# TASK-024 PLAN cycle 1: run controls and inspector

Status: plan only. No product code, Cargo, task or benchmark files changed. No commit made by the agent.
Decisions: `docs/decisions/ADR-0025-ui-run-controls-inspector-and-checkpoints.md` (Proposed).

## Baseline (checked in PLAN)
- `cargo test --workspace --locked --offline`: exit 0. evosim-core 423 passed, 1 ignored; evosim-cli unit 36; batch_cli 8;
  checkpoint_cli 2; run_cli 9; evosim-ui 15 passed, 1 ignored. Wall time 23 s.
- `bash scripts/check_adrs.sh`: exit 0, checks=164 failed=0.
- `git remote -v | wc -l` = 0.
- Container: Rust at `/opt/rust/cargo/bin`; Chromium 131 at `/usr/local/bin/chromium`; Python 3 stdlib. No system packages
  needed for this task.

## What the code gives (verified by reading)
- `Entities::deaths_phase` removes dead organisms. `Entities::last_deaths()` holds the deaths of the most recent tick only.
  The inspector therefore records a death in the UI thread after each tick (ADR-0025 D4). No core change.
- `checkpoint::write_file(sim, seed)` and `checkpoint::read_file(bytes)` -> `Checkpoint { seed, sim }` exist.
- `Simulation::new(config)` plus `populate_initial(config)` is the start of the world (as `driver::start` does).
- `crates/evosim-ui/src/server.rs` is GET-only and has no body reader; `Shared.climate` is fixed at start.
- `index.html` has `#controls` and `#inspector` placeholders; `app.js` has pointer drag/zoom, `window.evosim` hook and `?check=1`.
- `genome::Genome::trait_means()` gives 8 slot means; `analytics::trait_names(kind)` gives trait names.
- `species::SpeciesRegistry::record(id)` gives `SpeciesRecord.name`.

## Ordered IMPLEMENT steps
1. **ADR and checker.** Add `ADR-0025-ui-run-controls-inspector-and-checkpoints.md` to the `ADRS` list in
   `scripts/check_adrs.sh`. Keep Proposed until REVIEW PASS.
2. **`control.rs` (new, pure).** `Session` with the fields and operations of ADR-0025 D1: `new(config)` (builds and populates),
   `run`, `pause`, `step`, `reset`, `faster`, `slower`, `select`, `deselect`, `load(bytes)`, `save()`, `pump(due_ticks)`,
   accessors `simulation()`, `running()`, `speed()`, `speed_index()`, `climate_version()`, `watch()`. `SPEED_LEVELS = [1, 5, 20, 60]`,
   default index 2. Export from `lib.rs`.
3. **Tests for `Session`** (ADR-0025 D6, first bullet group): step, pump, speed clamp, reset determinism, watch death, unknown id,
   save/load equality, invalid load unchanged, climate version and watch cleared. Run `cargo test -p evosim-ui --locked --offline`.
4. **`inspector.rs` (new, pure).** `detail_json(sim, organism) -> String` and `death_json(death) -> String`; `watch_json(session)`
   assembles `status`. Unit tests: fields present, founder parents null, animal-only fields, `slot_means == trait_means`,
   species null before founding, loci hex length (2 * 128 per animal, 128 per plant).
5. **`snapshot.rs`.** `state_json(sim)` gains a `control` block (from the session) and the `climate_version`. Existing tests
   updated; a new test checks the `control` keys.
6. **`server.rs`.** `Shared` holds `Sender<Command>` (plus the latest inspector bytes and climate bytes behind `Mutex`).
   Parser reads `Content-Length` bodies with a 64 MiB limit (413 before reading). Routes from ADR-0025 D2. Route unit tests
   with a fake command receiver (no socket).
7. **`driver.rs`.** Replace `simulate` loop with: drain commands; `pump` with ticks due from `Instant` elapsed and speed;
   publish state and inspector after each tick and after each command that changes state; sleep 10 ms when paused.
   `start` keeps its signature. `smoke_test` and `screenshots` keep working (session starts running).
8. **`web/app.js`, `index.html`, `style.css`.** Controls, keyboard shortcuts, click selection (4 px threshold), highlight ring,
   inspector panel, checkpoint save/load, climate refetch on `climate_version` change, status lines. Keep the existing hook
   `window.evosim` and `?check=1` working.
9. **Scripts.** Extend `scripts/ui_check.py` with the synthetic control check (Step while paused +1 tick; Run/Pause), keeping
   the existing checks. `scripts/test.sh`: add a black-box step only if it stays under the time budget; otherwise record it as a gap.
10. **Gates.** `cargo test --workspace --locked --offline`; `cargo clippy -p evosim-ui --all-targets --locked --offline`;
    `node --check crates/evosim-ui/web/app.js`; `bash scripts/check_adrs.sh`; `./build.sh`; `./evosim ui --smoke-test`;
    `./evosim ui --screenshots DIR` (main.png, and optionally `inspector.png` after a synthetic selection); `scripts/ui_check.sh`;
    `git remote -v | wc -l`. Record exit codes in STATE.md.
11. **Docs.** `docs/ARCHITECTURE.md` UI section gets the control and inspector routes; README controls list; STATE.md entry.

## Tests planned (no display needed)
- `control.rs`: the Session tests in ADR-0025 D6.
- `inspector.rs`: JSON field tests and slot-mean equality.
- `server.rs`: route and body-limit tests.
- `snapshot.rs`: control block keys.
- Existing `cargo test --workspace` must stay green.

## Risks and how they are handled
- **Dead-organism lookup**: solved by the watch record after each tick (ADR-0025 D4). If a selection arrives after the organism
  died, the reply is an error and the page says so.
- **Stale release binary**: `./evosim` runs `target/release/evosim` and only builds it when missing (TASK-020 REVIEW). After any
  source change IMPLEMENT must run `./build.sh` before the black-box checks. Launcher rebuild-on-change is not part of this task.
- **Climate base layer changes on load**: the climate is republished with `climate_version`; the page refetches it. Test in D6.
- **Command latency**: HTTP threads wait up to 5 s for the simulation thread. Checkpoint encode/decode at 5,000 organisms takes
  milliseconds (TASK-022: 1.36 MB file). Not measured in PLAN.
- **Speed and performance**: at 60 ticks per second the simulation thread must stay within one period. At 1,000 organisms one tick
  averages 0.8 ms (TASK-023 timing), so 60 ticks per second is about 5% of a core. Record the measured rate in IMPLEMENT.
- **Reset semantics** (decided here, the user may redirect): reset keeps run/pause state, rebuilds the configuration the session
  started with, and does not return to a loaded checkpoint.
- **Species before founding**: `species` is `null` for organisms not yet classified; the inspector shows "not yet recognised".
- **M5 carry-over**: TASK-023 accepted 1,000 organisms for about 60 ticks only (D14c not met). The controls make this visible
  but do not change it. Not a TASK-024 criterion.
- **Smoke and screenshot timing**: the session runs at 20 ticks per second from start, so the smoke wait (tick 10 in 10 s) and the
  screenshot wait (tick 100 in 30 s) keep their budgets.

## Must-have coverage plan
| Criterion | Evidence planned |
|---|---|
| Run, pause, single step, reset, speed; step = one tick | Session tests; ui_check synthetic step; the page buttons |
| Reset rebuilds same starting world | Session test: state_hash equal after two resets |
| Speed >= 3 levels, never negative | `SPEED_LEVELS` of 4; clamp test |
| Tick and per-kind population always visible | Existing header; `counts` in `/api/state` (unchanged) |
| Selecting opens inspector with ID, kind, species, age, energy, health, traits, genome, parents | inspector.rs tests; screenshot of inspector (optional) |
| Inspector follows while running; shows death | Session watch test over a real death; page status line |
| Checkpoint save and load in the UI | Session save/load equality test; route tests; page download and upload (ui_check or recorded manual step) |
| Control logic tested without display | Session, inspector, server route tests |

## Next steps for IMPLEMENT
- Start with steps 1 to 3 (core of the control logic) and run the tests before the HTTP and page work.
- Record the chosen speed levels and the reset semantics in `docs/STATE.md`; keep ADR-0025 Proposed until REVIEW.
- Keep `evosim-core` unchanged; if a change there seems necessary, record it as a blocker rather than making it.

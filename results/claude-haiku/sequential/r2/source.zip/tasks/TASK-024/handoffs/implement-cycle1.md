# TASK-024 IMPLEMENT cycle 1: run controls and inspector

Status: implemented; gates run (see implement-cycle1.json). REVIEW has not run. No commit made by the agent.

## What was built
- Pure session logic (`crates/evosim-ui/src/control.rs`): run, pause, step (one tick, refused while running), reset to the
  started configuration and seed, speed levels [1, 5, 20, 60] with clamped index, select/watch with death record, save/load.
- Inspector JSON (`crates/evosim-ui/src/inspector.rs`): id, kind, species, age, energy, health, traits, genome (slot means
  and hex per haplotype), parents, alive/dead status.
- HTTP: command channel to the simulation thread; `POST /api/command`, `GET|POST /api/checkpoint`, `GET /api/organism?id=N`;
  bodies up to 64 MiB (413 before reading).
- Page: controls, keyboard shortcuts (Space, `.`/`n`, `r`, `-`/`+`, Esc), click selection with highlight, inspector,
  checkpoint save (download) and load (upload).
- `evosim-core` unchanged.

## Evidence
- `cargo test --workspace --locked --offline`: exit 0.
- `python3 -I scripts/control_check.py`: exit 0, 36 HTTP checks (step = one tick, speed clamps, reset identical bytes,
  checkpoint round trip equal to an uninterrupted run, invalid uploads 422, error codes, inspector through death).
- `./build.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR`, `scripts/ui_check.sh`, `check_adrs.sh`: exit 0.
- Speed 60 measured by hand: about 60.4 ticks/s over 5 s. 1,000 organisms: sim tick 0.788 ms average.

## Not verified
- The page's buttons, shortcuts, click selection and inspector were not driven in a browser. Only the HTTP commands they
  send were tested, plus `node --check`. A REVIEW browser run is needed to close this.

## Decisions to confirm at REVIEW
- Reset returns to the configuration the session started with, not to a loaded checkpoint (ADR-0025).
- Step is immediate (no pending-step queue); the ADR text was updated to say so.

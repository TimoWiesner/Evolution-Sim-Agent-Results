import json, socket, subprocess, sys, time, urllib.request, urllib.error
ROOT = "/workspace"
s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
proc = subprocess.Popen([f"{ROOT}/evosim", "ui", "--port", str(port), "--config", f"/tmp/review/bb/contract.json"],
                        stdout=subprocess.DEVNULL, stderr=open("/tmp/review/bb/server.log", "w"))
base = f"http://127.0.0.1:{port}"
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond)))
    print(("PASS" if cond else "FAIL"), name, detail if not cond else "")
def req(method, path, body=None):
    data = None if body is None else (body if isinstance(body, bytes) else json.dumps(body).encode())
    r = urllib.request.Request(base + path, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(r, timeout=15) as resp:
            return resp.status, resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
try:
    for _ in range(100):
        try:
            if req("GET", "/api/state")[0] == 200: break
        except Exception: time.sleep(0.1)
    for _ in range(100):
        try:
            req("GET","/api/state"); break
        except Exception: time.sleep(0.1)
    st, body = req("GET", "/api/presets")
    presets = json.loads(body)
    check("presets 200 with 4 presets", st == 200 and len(presets) == 4, body[:200])
    bal = next(p for p in presets if p["name"] == "balanced")
    fields = dict(bal["fields"])
    check("preset has 18 fields", len(fields) == 18, str(len(fields)))
    # invalid width
    bad = dict(fields); bad["world.width"] = "wide"
    st, body = req("POST", "/api/world", {**bad, "base": bal["config"]})
    check("non-numeric width -> 422 keyed to field", st == 422 and json.loads(body)["errors"][0]["key"] == "world.width", f"{st} {body}")
    bad2 = dict(fields); bad2["genetics.mutation_rate"] = "2.5"
    st, body = req("POST", "/api/world", {**bad2, "base": bal["config"]})
    check("out-of-range mutation rate -> 422", st == 422 and json.loads(body)["errors"][0]["key"] == "genetics.mutation_rate", f"{st} {body}")
    # valid custom world with extreme seed and edited values
    good = dict(fields); good["seed"] = "18446744073709551615"; good["world.width"] = "40"; good["world.height"] = "30"
    good["initial.plants"] = "200"; good["initial.herbivores"] = "60"; good["initial.carnivores"] = "10"
    good["climate.season_length"] = "120"; good["species.distance"] = "0.1"
    st, body = req("POST", "/api/world", {**good, "base": bal["config"]})
    check("valid world accepted 200", st == 200, f"{st} {body}")
    st, body = req("GET", "/api/state"); state = json.loads(body)
    check("new world at tick 0", state.get("tick") == 0, body[:200])
    check("state reports paused", state.get("control", {}).get("running") is False, json.dumps(state.get("control"))[:300])
    # invalid world must leave the session unchanged
    st, body = req("POST", "/api/world", {**good, "world.width": "0", "base": bal["config"]})
    st2, body2 = req("GET", "/api/state")
    check("invalid start leaves tick unchanged", st == 422 and json.loads(body2)["tick"] == 0, f"{st} {body2[:100]}")
    # export then import
    st, body = req("POST", "/api/config/check", {**good, "base": bal["config"]})
    exported = json.loads(body)["config"] if st == 200 else None
    check("export 200", st == 200 and exported, body[:200])
    cfg = json.loads(exported)
    check("exported seed exact", cfg["seed"] == 18446744073709551615, str(cfg.get("seed")))
    st, body = req("POST", "/api/config/import", exported.encode())
    imp = json.loads(body)
    check("import 200 and fields carry the seed as text", st == 200 and imp["fields"]["seed"] == "18446744073709551615", body[:200])
    st, body = req("POST", "/api/config/check", {**imp["fields"], "base": exported})
    check("export after import is identical configuration", st == 200 and json.loads(body)["config"] == json.dumps(cfg) or json.loads(body)["config"] and json.loads(json.loads(body)["config"]) == cfg, body[:200])
    # import invalid file
    st, body = req("POST", "/api/config/import", b'{"seed": 1, "world": {"width": 0, "height": 2}, "initial": {"plants": 1, "herbivores": 1, "carnivores": 1}}')
    check("invalid import -> 422", st == 422 and json.loads(body)["errors"][0]["key"] == "world.width", f"{st} {body[:200]}")
    st, body = req("POST", "/api/config/import", b'{"seed": 1.5, "world": {"width": 2, "height": 2}, "initial": {"plants": 1, "herbivores": 1, "carnivores": 1}}')
    check("import seed as real -> 422", st == 422, f"{st} {body[:200]}")
    # run and watch series grow
    req("POST", "/api/command", b"action=run")
    time.sleep(2.0)
    st, body = req("GET", "/api/series?trait=speed")
    ser = json.loads(body)
    n1 = len(ser["tick"])
    check("series grows while running", n1 > 5 and ser["tick"] == sorted(ser["tick"]), f"n={n1}")
    last = ser["tick"][-1]
    time.sleep(1.0)
    st, body = req("GET", f"/api/series?trait=speed&since={last}")
    newer = json.loads(body)
    check("series since returns only newer ticks", all(t > last for t in newer["tick"]) and len(newer["tick"]) > 0, body[:120])
    check("series has population, births, deaths, species, trait mean per kind",
          all(k in ser[f] for f in ("population", "births", "deaths", "species") for k in ("plant", "herbivore", "carnivore")) and "mean" in ser["trait"],
          list(ser.keys()).__str__())
    st, body = req("GET", "/api/series?trait=nope")
    check("unknown trait -> 400", st == 400, str(st))
    st, body = req("GET", "/api/series?since=abc&trait=speed")
    check("bad since -> 400", st == 400, str(st))
    st, body = req("GET", "/api/distribution?kind=herbivore&trait=speed&bins=10")
    dist = json.loads(body)
    check("distribution counts sum to n", sum(dist["counts"]) == dist["n"] and dist["n"] > 0 and len(dist["counts"]) == 10 and len(dist["edges"]) == 11, body[:200])
    st, body = req("GET", "/api/distribution?kind=plant&trait=aggression&bins=10")
    check("distribution unknown trait for kind -> 400", st == 400, str(st))
    st, body = req("GET", "/api/distribution?kind=herbivore&trait=speed&bins=0")
    check("bins 0 -> 400", st == 400, str(st))
    st, body = req("POST", "/api/presets", b"{}")
    check("method not allowed -> 405", st == 405, str(st))
    st, body = req("GET", "/api/nothing")
    check("unknown route -> 405 (text, as before)", st == 405, str(st))
    st, body = req("POST", "/api/world", b"x" * (1024 * 1024 + 10))
    check("oversized body -> 413", st == 413, str(st))
    # charts describe axis labels etc. is page-side; check reset restores configuration
    st, body = req("POST", "/api/command", b"action=reset")
    st2, body2 = req("GET", "/api/state")
    check("reset returns to tick 0 of the new world", st == 200 and json.loads(body2)["tick"] == 0, body2[:100])
finally:
    proc.terminate(); proc.wait(timeout=10)
failed = [n for n, ok in results if not ok]
print(f"TOTAL {len(results)} failed {len(failed)}")

# TASK-025 PLAN cycle 1: UI scenarios, presets and charts

Status: plan only. No product code, Cargo, task, benchmark or script files changed. No commit made by the agent.
Decisions: `docs/decisions/ADR-0026-ui-scenarios-presets-and-charts.md` (Proposed), D1 to D10.

## Starting point (verified in the workspace)
- Baseline gates before any change: `cargo test --workspace --locked --offline` exit 0 (cli 36, batch 8, checkpoint 2,
  run 9, evosim-core 423 + 1 ignored, evosim-ui 49 + 1 ignored); `bash scripts/check_adrs.sh` exit 0 (checks=175 failed=0);
  `git remote -v | wc -l` = 0; `chromium` at `/usr/local/bin/chromium`; node v18.19.1.
- The page can only run the `--config` world. Sidebar has `#controls`, `#inspector`; bottom `#charts` is empty (ADR-0024 D6).
- Core has everything the charts need: `core::analytics::MetricsLog` (population, cumulative and per-interval births and
  deaths, species alive, trait mean/sd/min/max), `Config::from_json/to_json`, `config::presets::{NAMES, get}`.
- The core's private `analytics::trait_values` is needed for the histogram; it becomes `pub` (visibility only).
- Parameters NOT offered in the UI: `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism` (ADR-0006
  amendment: not used by the engine).

## Ordered implementation plan (IMPLEMENT)
1. **ADR and record.** Add ADR-0026 to the `ADRS` list in `scripts/check_adrs.sh` and to its keyword checks; keep status
   Proposed until REVIEW. Update `docs/ARCHITECTURE.md` (module table: `setup.rs`, `charts.rs`, web files) and `docs/STATE.md`.
2. **Core visibility.** `crates/evosim-core/src/analytics.rs`: `pub fn trait_values(o: &Organism, kind: Kind) -> Vec<f64>`
   (the existing private helper; no logic change). Test: existing analytics tests still pass.
3. **Configuration logic, pure.** `crates/evosim-ui/src/setup.rs` (new):
   - `FIELDS`: table of the 18 editable keys (6 required + 12 further, D1) with label, group, and kind (`Int` or `Real`).
   - `parse_fields(&[(String, String)]) -> Result<Config, Vec<FieldError>>` (D2): strings to JSON text with the grammar
     check per kind, then `Config::from_json`; `ConfigError.key` becomes `FieldError { key, message }`; keyless errors
     become form-level errors (`key: None`).
   - `fields_of(&Config) -> Vec<(String, String)>`: canonical strings for the form (seed as decimal text, never a number in JS).
   - `presets_json() -> String`: names, one-line descriptions (held here), field payloads from `config::presets::get`.
   - Tests: each error class (non-numeric, real typed as integer such as `64.0`, out of range, empty, unknown key via
     the core path, missing fixed key), round trip `Config == parse_fields(fields_of(c))` for defaults, all presets and a
     seed of 18446744073709551615, reals `0.1` and `1e-7`; field table matches `FIELDS` names.
4. **Chart data, pure.** `crates/evosim-ui/src/charts.rs` (new):
   - `ChartPoint { tick, population: [u64;3], births: [u64;3], deaths: [u64;3], species: [u64;3], trait_mean: [Vec<Option<f64>>;3] }`
     built from `analytics::Snapshot`.
   - `ChartLog`: `record(&Simulation)` after each tick, `MAX_POINTS = 2000`, thinning by merging pairs (sum births and
     deaths, later values otherwise), stride doubling (D6).
   - `series_json(&self, since: u64, kind, trait_name) -> Result<String, String>` (400 text for an unknown trait),
     `distribution(sim, kind, trait_name, bins) -> Result<Histogram, String>` and `histogram_json` (D7).
   - Tests: thinning keeps the sum of births and deaths over the span; population and species of the last point are the
     last recorded values; `series_json(since)` returns only newer ticks; histogram counts sum to `n`; empty population gives
     `n = 0`; unknown trait error; bins bounds 1..=100.
5. **Session.** `crates/evosim-ui/src/control.rs`:
   - `Command::NewWorld(Box<Config>)`, `Command::Series { since, kind, trait }`, `Command::Distribution { kind, trait, bins }`.
   - `Session` owns a `ChartLog`; `pump` records after each tick (same place as the death record); `reset`, `load` and
     `new_world` clear it (load starts a fresh log at the loaded tick).
   - `Session::new_world(config)`: builds the simulation, `populate_initial`, paused, watch cleared, `climate_version` bumped,
     the started configuration replaced (reset returns to it).
   - Tests: new world paused at tick 0 with the given seed and size; invalid payload never reaches the session (tested in
     `setup` plus the server route); reset after new world returns to the new configuration; series and distribution
     replies through `apply`.
6. **Server routes.** `crates/evosim-ui/src/server.rs` (extend `route`, `allowed_methods`):
   - `GET /api/presets` (presets_json), `POST /api/config/check` (fields JSON in, `{"ok":true,"config":<to_json>}` or 422
     with `errors`), `POST /api/config/import` (file text in; `{"ok":true,"fields":{...}}` or 422),
   - `POST /api/world` (fields in; 200 `{"ok":true}` after the session accepts, 422 with errors, 503 on timeout),
   - `GET /api/series?since=T&kind=K&trait=NAME` and `GET /api/distribution?kind=K&trait=NAME&bins=N` through
     `Command::Series` and `Command::Distribution` (400 for bad query, 503 on timeout).
   - Route tests for each status code: 200, 400, 404, 405, 413 (body limit), 422.
   - Export: the page downloads `config/check`'s `config` text (no separate GET; see ADR-0026 D3).
7. **Driver.** `crates/evosim-ui/src/driver.rs`: `screenshots` writes `main.png` (`?shot=1`) and `charts.png`
   (`?shot=1&view=charts`), both checked by `check_png_size(…, 1280, 720)`; `smoke_test` unchanged (marker still `frames=N`).
   Embed `web/charts.js` in the server's asset routes.
8. **Page.** `crates/evosim-ui/web/index.html`, `app.js`, `style.css`, new `charts.js`:
   - Sidebar `<details>` "New world": preset cards (name, description, click fills the form), text inputs for the 18 keys
     with an error element next to each input, buttons Start, Check, Export, Import (file input).
   - Start posts the typed strings to `/api/world`; errors shown per field; the world is not replaced on error.
   - `#charts` bottom strip: five canvases (population, births and deaths, species, mean trait, histogram) with axis
     labels, legends and a trait selector (`analytics::trait_names`) and kind selector. Poll `/api/series?since=` every
     1 s and `/api/distribution` on change of selector or every 2 s.
   - `view=charts` query: charts take the main area (for the screenshot).
   - `node --check` on `app.js` and `charts.js`.
9. **Checks.** `scripts/config_charts_check.py` (new, stdlib, `python3 -I`): HTTP black box (presets, invalid payloads per
   field, world start, series growing while running, distribution sum equals `n`, export then import equal, seed
   2^64-1) and a Chromium pass over the DevTools protocol with real mouse and key events (form fill, invalid field
   error next to its input, start, a chart point count rising, trait selector changes the histogram). Wire into
   `scripts/test.sh` if its runtime fits.
10. **Gates and evidence (record exit codes in STATE.md).** `cargo test --workspace --locked --offline`,
    `cargo clippy -p evosim-ui --all-targets --locked --offline`, `node --check` both files, `bash scripts/check_adrs.sh`,
    `./build.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR` (view `main.png` and `charts.png`),
    `python3 -I scripts/config_charts_check.py`, `bash scripts/ui_check.sh`, `python3 -I scripts/control_check.py`,
    `git remote -v | wc -l`. Measure the tick rate at 5,000 organisms with the chart log active (time per tick with and
    without `ChartLog::record`) and record it; if the 60 ticks/s target fails, record it as a gap, not a silent change.

## Test evidence for the Must-have points
| Must-have | Evidence |
|---|---|
| Start from UI with preset and 6 + 12 editable fields | `setup` tests, `config_charts_check.py` HTTP and browser pass |
| Invalid input shown next to field, no start | `setup` error tests, route 422 test, browser check of the error element and unchanged tick |
| Export and import equal | `setup` round-trip test (extreme seed, reals), black-box export then import |
| Charts update while running | `charts` tests, black-box series growth, browser check of point count rising |
| Distribution of a selectable trait | `charts` histogram tests, black-box `n` = living count, browser check of trait selector |
| Axis labels and legend | browser check of canvas text via a `window.evosim.charts()` description (read-only hook, like ADR-0024) and screenshot `charts.png` |
| Tests without display | all unit tests in `setup.rs`, `charts.rs`, `control.rs`, `server.rs` run with `cargo test` |

## Risks
- Seed precision in JavaScript: mitigated by strings end to end (D2, D3); the browser check uses 2^64-1.
- Per-tick trait statistics cost at 5,000 organisms; may cut the 60 ticks/s speed level. Measure; if too slow, record
  the figure and sample the trait statistics every k-th tick (a decision to write into ADR-0026 before changing it).
- Thinning changes the resolution of old data; totals stay exact by design, the curve becomes coarser after 2000 ticks.
- Form in the sidebar lengthens the page; `main.png` must still show the world at 1280x720 (the form sits in a `<details>`).
- Command-queue reads of charts wait for the simulation thread (up to 5 s, 503 otherwise); at 60 ticks/s a read waits at
  most one tick plus the pump cycle.
- Engine collapse: a 1,000-organism world still falls below 1,000 after about 60 ticks (TASK-023 carry-over). Charts show
  it truthfully; no engine change is part of this task.
- The `check_adrs.sh` keyword checks for ADR-0026 must be satisfied; the record must keep its six required headings.

## Open items for REVIEW
- Whether the chart set and the 12 further parameters satisfy the reviewer's reading of "at least five further parameters".
- Whether a paused start after "Start world" is the expected behaviour (recorded decision D4; the user can redirect).
- Whether the browser check should become a gate in `scripts/test.sh` (runtime to be measured in IMPLEMENT).

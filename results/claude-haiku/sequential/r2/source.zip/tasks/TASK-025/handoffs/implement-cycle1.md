# TASK-025 IMPLEMENT cycle 1: UI scenarios, presets and charts

Status: implemented; partly gated. The planned browser check script was not written (see gaps). No commit made by the agent.
Full record: `docs/STATE.md` (TASK-025 IMPLEMENT cycle 1) and `docs/decisions/ADR-0026-ui-scenarios-presets-and-charts.md`.
Handoff: `implement-cycle1.json`.

## What works (evidence)
- New world from the page: preset cards, 18 editable fields, errors shown next to the field, no start on invalid input (route tests `invalid_world_is_422_and_never_reaches_the_simulation`, `check_names_the_invalid_field_with_422`).
- Export and import JSON with an exact round trip, including seed 2^64-1 and reals 0.1 and 1e-7 (`setup` tests `export_then_import_gives_an_equal_configuration`).
- Charts: population per kind, births and deaths, species alive, mean of a selectable trait, histogram of a selectable trait and kind; axis labels and legends (`main.png`, `charts.png` viewed).
- Tests without display: `setup.rs`, `charts.rs`, `control.rs`, `server.rs` (95 ui tests pass).

## Gaps
- `scripts/config_charts_check.py` (HTTP black box and Chromium input-event pass) not written.
- `scripts/ui_check.sh` not re-run.
- Speed 60 with charts active and 5,000-organism chart cost not measured. At 511 organisms the tick cost rose from 0.788 ms to 0.881 ms.

# TASK-025 REVIEW cycle 1: UI scenarios, presets and charts

Verdict: PASS. All seven Must-have points are shown by executed checks, not only by reading code.
Handoff: `review-cycle1.json`. Evidence: `review-cycle1-evidence/`.

## Must-have evidence
| Must-have | Executed evidence |
|---|---|
| Start from UI: preset, then seed, size, initial pops and 5+ further parameters | HTTP black box: world start with seed 2^64-1, size 40x30, edited initial plants, climate and species fields, tick 0 and paused. Chromium: preset card, seed and fields typed, Start, tick 0. |
| Invalid input shown next to its field; no start | Chromium: `err-world.width` shows the core range message; `err-world.height` shows the grammar message; the error span follows its input; tick unchanged. HTTP: 422 keyed to `world.width`, `genetics.mutation_rate`, `seed`. |
| Export and import give the same configuration | HTTP: export, import, export again gives the same configuration; seed reads back as exact text. Cargo: `export_then_import_gives_an_equal_configuration` (extreme seed, reals 0.1 and 1e-7, hidden parameter kept). |
| Charts update while running | HTTP: series grows while running; `since=` returns only newer ticks. Chromium: points rise (246 at tick 245) and the simulation advances. |
| Population, births and deaths, species, mean trait over time | HTTP: all keys present per kind. Chromium: `window.evosim.charts()` lists the panels. Screenshot `charts.png`. |
| Histogram of a selectable trait | HTTP: bin counts sum to `n`; unknown trait for a kind gives 400. Screenshot shows the histogram. Selector change in the browser not run (gap). |
| Axis labels and legends | Chromium `describe()` lists legends per panel; `charts.png` shows axis titles and legends. |
| Tests without display | `cargo test --workspace` exit 0 (setup, charts, control, server tests). |

## Gates run
- `cargo test --workspace --locked --offline`: exit 0.
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0.
- `./build.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR`: exit 0.
- `bash scripts/check_adrs.sh`: 186 checks, 0 failed.
- `node --check` on the three page scripts: exit 0.
- `bash scripts/ui_check.sh`: PASS.
- `python3 -I scripts/control_check.py`: exit 1 once (1 failed), exit 0 in the next two runs. Intermittent (see gaps).
- `git remote -v | wc -l`: 0.

## Gaps (non-blocking)
1. `control_check.py` failed once in three runs ("faster from 5 returns to 20"). Manual trace is correct. Likely a state snapshot read right after a command.
2. The planned `scripts/config_charts_check.py` is not in the repo; reviewer scripts are in `review-cycle1-evidence/`.
3. Chart cost at 5,000 organisms is not measured; at 511 organisms it went from 0.788 to 0.881 ms per tick.
4. The trait selector changing the histogram was not exercised in the browser.
5. After a failed start the first error may be below the fold of the sidebar; the page does not scroll to it.
6. The form starts empty until a preset is chosen; Start then lists every untouched field as missing.
7. At 1280 px the chart strip is clipped (the fourth chart needs a horizontal scroll).
8. `scenarios/demo.json` does not exist; it belongs to TASK-028.

## Reviewer notes
- Two reviewer expectations in the HTTP script were wrong (unknown route is 404 by design; the body limit is 64 MiB). Both were re-checked with curl.
- The ADR-0026 status is now Accepted, as the ADR says for REVIEW PASS.

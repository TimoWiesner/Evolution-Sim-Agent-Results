import base64, json, os, socket, struct, subprocess, sys, tempfile, time, urllib.request
CHROME = "/usr/local/bin/chromium"
def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p
class WS:
    def __init__(self, url):
        host, rest = url[5:].split("/", 1); h, p = host.split(":")
        self.s = socket.create_connection((h, int(p)), timeout=20)
        key = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall((f"GET /{rest} HTTP/1.1\r\nHost: {host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                        f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        buf = b""
        while b"\r\n\r\n" not in buf: buf += self.s.recv(1)
        assert b" 101 " in buf.split(b"\r\n")[0], buf[:200]
        self.n = 0; self.pending = []
    def send(self, text):
        data = text.encode(); mask = os.urandom(4)
        head = bytes([0x81])
        if len(data) < 126: head += bytes([0x80 | len(data)])
        else: head += bytes([0x80 | 126]) + struct.pack(">H", len(data))
        self.s.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))
    def _exact(self, n):
        out = b""
        while len(out) < n:
            c = self.s.recv(n - len(out))
            if not c: raise EOFError
            out += c
        return out
    def recv(self):
        b1, b2 = self._exact(2)
        ln = b2 & 0x7f
        if ln == 126: ln = struct.unpack(">H", self._exact(2))[0]
        elif ln == 127: ln = struct.unpack(">Q", self._exact(8))[0]
        return self._exact(ln).decode("utf-8", "replace")
    def call(self, method, params=None):
        self.n += 1; my = self.n
        self.send(json.dumps({"id": my, "method": method, "params": params or {}}))
        while True:
            msg = json.loads(self.recv())
            if msg.get("id") == my: return msg.get("result", msg.get("error"))
    def evaluate(self, expr):
        r = self.call("Runtime.evaluate", {"expression": expr, "returnByValue": True, "awaitPromise": True})
        return r.get("result", {}).get("value")
results = []
def check(name, ok, detail=""):
    results.append(ok); print("PASS" if ok else "FAIL", name, "" if ok else detail)
server_port = int(sys.argv[1])
dbg = free_port(); prof = tempfile.mkdtemp()
chrome = subprocess.Popen([CHROME, "--headless", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
    f"--remote-debugging-port={dbg}", f"--user-data-dir={prof}", "--window-size=1280,807", "about:blank"],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
try:
    for _ in range(100):
        try:
            targets = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dbg}/json", timeout=2).read())
            page = next(t for t in targets if t["type"] == "page"); break
        except Exception: time.sleep(0.2)
    ws = WS(page["webSocketDebuggerUrl"])
    ws.call("Page.enable"); ws.call("Runtime.enable")
    ws.call("Page.navigate", {"url": f"http://127.0.0.1:{server_port}/"})
    time.sleep(3)
    ev = ws.evaluate
    check("form rendered with 18 inputs", ev("document.querySelectorAll('#fields input').length") == 18)
    check("preset cards rendered", ev("document.querySelectorAll('#presets > *').length") >= 4)
    # invalid: width 0 (core range) and non-numeric height
    ev("document.getElementById('newworld').open = true")
    ev("document.querySelector('#presets > *').click()")
    time.sleep(0.5)
    ev("document.getElementById('btn-start') && document.getElementById('field-seed').value.length > 0")
    ev("fetch('/api/command',{method:'POST',body:'action=pause'})")
    time.sleep(0.5)
    ev("(()=>{const i=document.getElementById('field-world.width'); i.value='0'; i.dispatchEvent(new Event('input'));})()")
    ev("document.getElementById('field-world.height').value='30'")
    time.sleep(0.5)
    tick_before = ev("document.getElementById('tick').textContent")
    ev("document.getElementById('btn-start').click()")
    time.sleep(1.5)
    ew = ev("document.getElementById('err-world.width').textContent")
    eh = ev("document.getElementById('err-world.height').textContent")
    adjacent = ev("document.getElementById('err-world.width').previousElementSibling.id")
    check("out-of-range width message shown in its field's error element", bool(ew), repr(ew))
    check("range message shown next to width (height valid)", 'out of range' in (ew or ''), repr(ew))
    check("error span sits right after its input", adjacent == "field-world.width", repr(adjacent))
    check("invalid start leaves the world untouched", ev("document.getElementById('tick').textContent") == tick_before, tick_before)
    ws.call("Page.captureScreenshot", {}) if False else None
    shot = ws.call("Page.captureScreenshot", {"format": "png"})
    open("/tmp/review/cdp/invalid.png", "wb").write(base64.b64decode(shot["data"]))
    # valid start with an extreme seed and edited values
    ev("document.getElementById('field-world.width').value='40'; document.getElementById('field-world.height').value='30'")
    ev("document.getElementById('field-seed').value='18446744073709551615'")
    ev("document.getElementById('field-initial.plants').value='200'")
    ev("document.getElementById('field-species.distance').value='0.1'")
    ev("document.getElementById('btn-start').click()")
    time.sleep(2)
    status = ev("document.getElementById('setup-status').textContent")
    check("valid start reports the seed exactly", "18446744073709551615" in (status or ""), status)
    check("new world starts at tick 0", ev("document.getElementById('tick').textContent").startswith("tick 0"), ev("document.getElementById('tick').textContent"))
    ev("fetch('/api/command',{method:'POST',body:'action=run'})")
    time.sleep(4)
    n_points = ev("(()=>{const s=JSON.stringify(window.evosim && window.evosim.charts ? window.evosim.charts() : null); return s;})()")
    check("charts describe themselves (labels and legend)", bool(n_points) and n_points != "null", str(n_points)[:200])
    # export: the page makes a Blob download; check the exported text by calling the same route the button uses
    tick_run = ev("document.getElementById('tick').textContent")
    check("simulation advances while charts are on", tick_run != "tick 0", tick_run)
    shot = ws.call("Page.captureScreenshot", {"format": "png"})
    open("/tmp/review/cdp/running.png", "wb").write(base64.b64decode(shot["data"]))
    desc = ev("JSON.stringify(window.evosim.charts())")
    print("charts description:", (desc or "")[:600])
finally:
    chrome.terminate()
print(f"TOTAL {len(results)} failed {results.count(False)}")

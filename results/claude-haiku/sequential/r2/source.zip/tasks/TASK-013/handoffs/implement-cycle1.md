# TASK-013 IMPLEMENT cycle 1: animal sensing and movement

Implements `docs/decisions/ADR-0014-animal-sensing-movement-and-sharing.md` (still Proposed; REVIEW sets Accepted on PASS).
Full record in `docs/STATE.md` (IMPLEMENT section) and `docs/ARCHITECTURE.md` (TASK-013 IMPLEMENT note).

## What was built
- `entities::vision_radius(&Genome)`: animal vision 1..5 cells from genome slot 7 (derived, not stored).
- `core::movement` (new): `steps_per_tick`, `move_cost` (0.2 * steps * (1 + 0.25 * speed)), `Heading`, `step_towards` (shortest
  8-neighbour path across edges), `wander` (one `next_below(8)` draw per step), `perceive`, `choose_heading` (always Wander),
  `plan_moves` (start-of-phase positions, ascending id).
- `Simulation::move_organism(id, cell)`: the single move path; refuses off-torus, dead or unknown organisms without changes;
  updates `Entities` and `SpatialIndex` together (closes G-047).
- `Simulation::animal_phase` runs in the Herbivores and Carnivores arms: plan, then apply moves and charge energy.
- `SimError::NotAlive` (new variant).

## Acceptance points
- Perception across edges: `movement::tests::perceive_*`, `perceive_on_thin_worlds_*`, `sim::movement_tests::perception_across_the_edge_*`.
- Steps limited by speed: `steps_follow_floor_of_speed`, `sim::movement_tests::a_tick_moves_animals_by_at_most_their_speed_and_charges_the_cost`,
  `slow_animals_do_not_move_and_pay_nothing`.
- Movement costs energy, more for further/faster: `move_cost_is_zero_without_distance_and_grows_*`, the tick test above
  (charge exactly 1.6 at speed 4), `moving_organism_starves_through_the_phase_and_leaves_the_index`.
- Shortest way across an edge: `step_towards_takes_the_short_way_across_the_west_edge`, `..._north_edge_diagonally`,
  `step_towards_taken_steps_equal_torus_distance_everywhere_on_small_torus`, `step_towards_even_size_tie_is_deterministic`.
- Cell-sharing rule (documented in ADR-0014, applied in `move_organism`): `two_animals_may_share_a_cell_and_both_are_indexed_there`.
- Index kept up to date and tested at edges: `move_organism_updates_entities_and_index_together`,
  `move_organism_refuses_off_torus_dead_and_unknown_without_changes`, `founders_populate_and_index_stays_in_sync_over_500_ticks_with_edges`
  (check_spatial after every tick), `same_seed_gives_identical_animal_positions_and_different_seeds_differ`.

## Deviations from the approved plan
- Not written: the "reversed input order" test for `plan_moves`. `Entities::living()` is always ascending, and `plan_moves` takes
  shared references only, so the start-of-phase guarantee is structural rather than tested by reordering.
- `SimError::NotAlive` added (the plan did not name the error variant).
- ADR-0014 wording clarified: cost `distance` is steps taken (wander counts every step even if net displacement is smaller);
  `perceive` takes `(spatial, id, cell, vision)`.
- `movement.rs` `perceive` and `plan_moves` names follow the plan; `choose_heading(kind, perceived)` takes the perceived list
  so later tasks can use it.

## Commands and results (exit codes)
- `cargo test -p evosim-core --locked` -> 0 (273 passed, 1 ignored; baseline was 247 passed).
- `cargo test --workspace --locked` -> 0 (core 273 passed, cli 16 passed).
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` -> 0, no warnings.
- `rustfmt --edition 2021 --check crates/evosim-core/src/{movement,sim,entities}.rs` -> 0.
- `bash scripts/check_adrs.sh` -> 0 (checks=131 failed=0; ADR-0014 added to the list).
- `bash scripts/test.sh` -> 0 ("ALL TESTS PASSED", includes workspace tests, setup, build, dist checks).

## Repo hygiene notes
- Running rustfmt on `lib.rs` also reformats child modules (config.rs, config/*.rs), which are not rustfmt-clean in the repo.
  Those edits were reverted; only the changed files were formatted.
- No commit made; task.md/task.json, benchmark state and tools untouched.

## Risks and open items
- Animals have no food until TASK-014; they will starve. Expected; not patched.
- Movement cost constants uncalibrated (TASK-018). Speed < 1 gives no movement; wander is memoryless (ADR-0014 trade-offs).
- Cell sharing: the plant birth cap (ADR-0013) is the only occupancy rule. REVIEW must judge whether this satisfies "applied everywhere" (R4).
- G-046 stale-overlay query cost is not measured with animals (R6).
- Checkpoint (TASK-022): no new state needed for this task.

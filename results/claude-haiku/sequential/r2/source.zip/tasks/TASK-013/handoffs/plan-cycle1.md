# TASK-013 PLAN cycle 1: animal sensing and movement

Design record: `docs/decisions/ADR-0014-animal-sensing-movement-and-sharing.md` (Proposed). ADR-0004 gets a TASK-013 amendment
(genome slot 7 is `vision` for animals). No product code, Cargo file, task file, benchmark file or commit was changed in this phase.

## Starting point (verified in PLAN)
- `cargo test -p evosim-core --locked`: 247 passed, 1 ignored (exit 0). `bash scripts/check_adrs.sh`: checks=120 failed=0 (exit 0).
  `git remote -v | wc -l` = 0. Toolchain: `export PATH=/opt/rust/cargo/bin:$PATH`.
- `sim.rs` `run_phase`: `Phase::Herbivores` and `Phase::Carnivores` are empty arms. `Phase::Deaths` already removes dead ids from the
  index. `add_founder`/`populate_initial` already insert into the index (`index_spawned`).
- `SpatialIndex` has `within(centre, r, filter)`, `insert`, `move_to`, `remove`, `position`; it allows several organisms per cell.
- `Torus` has `delta`, `distance`, `translate`, `step`, `neighbours`, `cell`; `Direction::ALL` (8 items) with `offset()`.
- `Entities` has `living()`, `living_mut()`, `get`, `get_mut`; `Organism::set_cell` (no torus check, G-041) and `drain_energy`
  (0 gives `Starvation`). Traits: `speed()` in `[0, 4]`.
- Genome: `Genome::trait_means()` returns 8 slot means; slot 7 is unused for animals (ADR-0004 amendment).
- Open gaps this task closes or must address: G-040 (use living-only iteration), G-041 (cells only from the torus), G-047 (a
  Simulation-level move helper that keeps the index in step). G-046 is a perf note (stale overlay), not closed here.

## Decisions (full text in ADR-0014)
1. Vision: `entities::vision_radius(&Genome) -> u32` = `min(5, 1 + floor(5 * mean(slot 7)))`, animals only, not stored.
2. Steps per tick: `floor(speed)`; each step is one of the 8 neighbour cells; speed < 1 means no move (no carry stored).
3. Heading: `enum Heading { Wander, Towards(Cell) }`. `Towards` uses `torus.delta` and diagonal steps (shortest 8-neighbour path,
   crosses an edge when shorter). `Wander` draws one direction per step with `rng.next_below(8)`. TASK-013 `choose_heading`
   returns `Wander` for all animals (target choice is TASK-014 to TASK-016).
4. Movement cost: `0.2 * distance * (1 + 0.25 * speed)` per tick, drained with `drain_energy`. Zero for zero distance; increasing
   in distance and in speed.
5. Cell sharing (the documented rule): any number of organisms of any kind may share a cell; no move is refused for occupancy.
   The ADR-0013 plant birth cap (`CELL_PLANT_CAP`) stays and governs births only. This is the one occupancy limit in the code;
   the reviewer should confirm that this reading of "applied everywhere" is acceptable.
6. Deferred moves: decisions for all animals of a kind are computed first (ascending id, reading start-of-phase positions), then
   moves and costs are applied (ascending id) through `Simulation::move_organism`.
7. No new checkpoint state: vision is derived from the genome, no heading or carry is stored.

## Ordered implementation plan (for IMPLEMENT)
1. `crates/evosim-core/src/entities.rs`: add `VISION_MIN = 1`, `VISION_MAX = 5` and `pub fn vision_radius(genome: &Genome) -> u32`
   (uses `trait_means()[7]`; animals only: return 0 for ploidy 1 is NOT allowed to silently pass, so take the genome and document that
   it is an animal function; `debug_assert` ploidy 2). Unit tests: boundaries, seeded sweep stays in `[1, 5]`.
2. `crates/evosim-core/src/movement.rs` (new; `pub mod movement` in `lib.rs`). Depends on `world`, `spatial`, `entities`, `genome`,
   `rng`. Contents:
   - `pub const MOVE_COST_CELL: f32 = 0.2`, `pub const MOVE_COST_SPEED: f32 = 0.25`;
   - `pub fn steps_per_tick(speed: f32) -> u32` = `floor(speed)` (clamped to `[0, 4]`, NaN rejected by the caller's trait range);
   - `pub fn move_cost(distance: u32, speed: f32) -> f32`;
   - `pub enum Heading { Wander, Towards(Cell) }`;
   - `pub fn step_towards(torus: &Torus, from: Cell, target: Cell, steps: u32) -> (Cell, u32)` (returns end cell and cells moved);
   - `pub fn wander(torus: &Torus, from: Cell, steps: u32, rng: &mut Rng) -> (Cell, u32)`;
   - `pub fn perceive(spatial: &SpatialIndex, id: OrganismId, cell: Cell, vision: u32) -> Vec<OrganismId>` (self removed);
   - `pub fn choose_heading(...) -> Heading` returning `Wander` (documented stub for TASK-014 to TASK-016);
   - `pub fn plan_moves(...) -> Vec<PlannedMove { id, to: Cell, distance: u32, speed: f32 }>` for one kind (ascending id,
     living only, reads snapshot of positions, draws RNG in id order).
3. `crates/evosim-core/src/sim.rs`:
   - `pub fn move_organism(&mut self, id, cell) -> Result<(), SimError>`: refuses a cell not on the torus (use the `check_birth_cell`
     pattern), `entities.get_mut(id)` living only, `spatial.move_to(id, cell)`, `set_cell`. Keeps entities and index in step (G-047).
   - `fn animal_phase(&mut self, kind: Kind)` (private): `plan_moves` for the kind; then for each planned move in ascending id order:
     `move_organism`, `drain_energy(move_cost(distance, speed))`. Herbivores arm calls it with `Kind::Herbivore`, Carnivores with
     `Kind::Carnivore`. Borrowing: plan with `&self.entities`, `&self.spatial`, `&mut self.rng` (distinct fields).
   - Errors from `move_organism` in the phase are impossible by construction (cells come from the torus); use `debug_assert!`.
4. `crates/evosim-core/src/lib.rs`: `pub mod movement;`.
5. Tests (in `movement.rs` and `sim.rs`), each mapped to an acceptance point:
   - Perception across edges: organism at x=0 perceives x=W-1 at vision 1; 1xN and Nx1 worlds; corners; no self; ascending.
   - Vision: `vision_radius` range and seeded sweep; perception radius equals vision.
   - Movement: `steps_per_tick` exact at 0, 0.99, 1, 3.5, 4; per tick moved `<= speed`; `Wander` lands on torus cells; `step_towards`
     from x=0 to x=W-1 is one west step across the seam; diagonal when both axes differ; stops at target; steps = `torus.distance`;
     even-size tie is deterministic.
   - Energy: `move_cost(0, s) == 0`; strictly increasing in distance and speed; drain to 0 gives `Starvation` (through the phase).
   - Cell sharing: two animals moved to one cell both appear in `spatial.within`; no move refused for occupancy.
   - Index: `check_spatial()` after each Herbivores/Carnivores phase in a seeded populated run; `move_organism` to an off-torus cell
     is refused and changes nothing.
   - Deferred moves: `plan_moves` result identical when the living order is reversed in the input (decisions read start positions).
   - Determinism: same seed gives identical positions after 50 ticks; different seeds differ.
   - Multi-tick run: 500 ticks with founders (no feeding yet): no panic, index in sync, all animals in torus, energy in range.
6. Docs (IMPLEMENT): ADR-0014 notes and Accepted at REVIEW; `scripts/check_adrs.sh` adds ADR-0014 to its list; ARCHITECTURE module
   row for `core::movement`; STATE.md IMPLEMENT section.

## Test commands (recorded in IMPLEMENT and REVIEW)
- `cargo test -p evosim-core --locked` (expect > 247 passed).
- `cargo test --workspace --locked`; `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`; `rustfmt --edition 2021 --check`
  on changed files; `bash scripts/check_adrs.sh`; `bash scripts/test.sh` (full; takes longer, run in REVIEW too).

## Risks
- R1: Animals have no food until TASK-014, and movement costs energy. Founders at energy 50 will starve in roughly 80 ticks at
  mean speed. Expected for this task; existing sim tests that run long with animals may see deaths and need adjusting (check
  `tests` in `sim.rs` after IMPLEMENT and record each change).
- R2: RNG consumption changes once animals move (wander draws), so any test pinned to an exact trace or hash value changes. Tests
  that compare two runs are unaffected.
- R3: Speed below 1 gives no movement; wandering is memoryless. Documented limits (ADR-0014 trade-offs), revisit in TASK-018.
- R4: The reading of "applied everywhere" for cell sharing (plant birth cap kept) may be judged strict. Mitigation: ADR-0014 names the
  exception explicitly; REVIEW decides.
- R5: Movement cost constants are uncalibrated (TASK-018).
- R6: Perception cost per animal per tick uses `within` with the stale overlay (G-046); no measurement planned here. Measure at
  2,000 animals in a later task if throughput is at risk.

## Not part of this task
Feeding, prey choice, mating, target choice, base metabolism, herbivore/carnivore reproduction (TASK-014 to TASK-016), checkpoint
(TASK-022), CLI wiring (TASK-019).

## System dependencies
None new. Toolchain already present at `/opt/rust/cargo/bin`.

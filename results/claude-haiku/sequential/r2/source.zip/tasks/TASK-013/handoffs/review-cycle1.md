# TASK-013 REVIEW cycle 1: animal sensing and movement

Verdict: **PASS**. Design record: ADR-0014 (now Accepted). Full notes: `docs/STATE.md` REVIEW section and ADR-0014 "Review notes".

## Acceptance criteria against code and tests
| Must-have | Evidence |
|---|---|
| Perception within vision range, across edges | `movement::tests::perceive_across_the_west_edge_*`, `perceive_across_the_north_edge_and_corner`, `perceive_on_thin_worlds_*`; `sim::movement_tests::perception_across_the_edge_*`; `vision_radius` tests (range 1..5, seeded sweep) |
| Cell-to-cell movement, distance per tick limited by speed | `steps_follow_floor_of_speed`; `plan_moves_reads_start_positions_and_is_ascending`; `a_tick_moves_animals_by_at_most_their_speed_and_charges_the_cost`; `slow_animals_do_not_move_and_pay_nothing` |
| Moving costs energy, more when faster or further | `move_cost_is_zero_without_distance_and_grows_*` (concrete 0.8 at distance 2, speed 4); tick test charges exactly 1.6; `moving_organism_starves_through_the_phase_and_leaves_the_index` |
| Shortest way to a target, across an edge when shorter | `step_towards_takes_the_short_way_across_the_west_edge`, `..._north_edge_diagonally`, `step_towards_taken_steps_equal_torus_distance_everywhere_on_small_torus` (exhaustive 6x5), `step_towards_even_size_tie_is_deterministic` |
| One documented cell-sharing rule, applied everywhere | ADR-0014 "Cell sharing"; `move_organism` has no occupancy check; `two_animals_may_share_a_cell_and_both_are_indexed_there` |
| Spatial index kept up to date; edge tests | `move_organism_updates_entities_and_index_together`, `move_organism_refuses_off_torus_dead_and_unknown_without_changes`, `founders_populate_and_index_stays_in_sync_over_500_ticks_with_edges` (check_spatial each tick) |

## Commands (exit codes, all run in this REVIEW)
- `cargo test -p evosim-core --locked`: 0 (273 passed, 1 ignored)
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: 0, 0 warnings
- `rustfmt --edition 2021 --check` on movement.rs, sim.rs, entities.rs: 0
- `bash scripts/check_adrs.sh`: 0 (checks=131 failed=0)
- `bash scripts/test.sh`: 0 ("ALL TESTS PASSED")

## Judgement calls
- Cell sharing: the rule holds for every move (no occupancy refusal). The ADR-0013 plant birth cap refuses plant births in a full
  cell; it is required by TASK-012 and is the only occupancy limit. A stricter reading of "applied everywhere" would make this a
  wording fix in ADR-0014, not a code change. Accepted as PASS.

## Gaps (non-blocking)
1. Perception result does not yet affect behaviour (`choose_heading` always returns `Wander`); tested via `perceive` only.
2. The reversed-input-order `plan_moves` test in ADR-0014's verification list was not written; the guarantee is structural.
3. Stale-overlay query cost (G-046) with animals not measured.
4. Movement cost constants and the speed < 1 no-move rule are uncalibrated (TASK-018).
5. Founders without food starve (expected until TASK-014; noted, not a failure).

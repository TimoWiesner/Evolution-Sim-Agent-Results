# TASK-012 PLAN cycle 1: plant reproduction and dispersal

Design record: `docs/decisions/ADR-0013-plant-reproduction-and-dispersal.md` (Proposed). No product code, Cargo file, task file or
benchmark file was changed in this phase. Docs changed: ADR-0013 (new), `docs/decisions/README.md` (index line),
`docs/ARCHITECTURE.md` (TASK-012 PLAN note), `docs/STATE.md` (PLAN section), this file and `plan-cycle1.json`.

## Starting point (verified in PLAN)
- `Phase::Reproduction` is an empty arm in `sim.rs` `run_phase` (between Carnivores and Deaths, ADR-0008 order).
- `Entities::spawn_child(birth, parents)` already exists: it checks parents are alive and plant parent shape `[Some, None]`,
  sets generation = parent + 1, and increments `births`. `Birth::from_genome` decodes traits from the genome.
- `genome::copy_child(parent, mutation, rng)` (plants, asexual) and `genome::Mutation` exist (ADR-0004).
- `SpatialIndex::within(centre, r, filter)` and `insert` exist; `add_founder` shows the index-insert pattern (`index_spawned`).
- `Torus::neighbours(centre, r)` returns each cell of the square once, wrapping both axes.
- `Simulation` does NOT store the configuration. Config values needed by reproduction must be stored in `Simulation`.
- Fertility is decoded for plants (genome slot 2, `decode_traits`), and ADR-0012 reserved it for this task.
- Config keys exist: `plants.reproduction_chance` (0.05), `plants.seed_radius` (2), `genetics.mutation_rate`, `genetics.mutation_strength`.
- Baseline: `cargo test -p evosim-core --locked` 228 passed, 1 ignored; `scripts/check_adrs.sh` checks=109 failed=0; 0 git remotes.

## Decisions (summary; full text in ADR-0013)
1. Asexual seeding only. Pollination is deferred (two-parent plants would need a mate search that TASK-016 builds for animals).
2. Dispersal: one uniform draw over `Torus::neighbours(parent_cell, seed_radius)`; the parent's cell is a candidate; no retry.
3. Cost: a seed attempt costs the parent `SEED_COST = 30`; seedling endowment `SEED_ENDOWMENT = 20`; threshold `SEED_ENERGY_MIN = 70`.
4. Room: at most `CELL_PLANT_CAP = 6` living plants in the target cell (spatial index count). Resource: target pool `>= SEED_RESOURCE_MIN = 5`.
5. Chance per mature plant per tick: `clamp(plants.reproduction_chance * 2 * fertility, 0, 1)`.
6. Mutation: `copy_child` with the configured `Mutation`. Child genome decodes to Plant traits (`Birth::from_genome`).
7. Seedling health = 0.5 × its `max_health`.

## Ordered implementation plan (for IMPLEMENT)
1. **`crates/evosim-core/src/reproduction.rs` (new)**, `pub mod reproduction` in `lib.rs`:
   - constants `SEED_ENERGY_MIN`, `SEED_COST`, `SEED_ENDOWMENT`, `SEED_HEALTH_FRACTION`, `CELL_PLANT_CAP`, `SEED_RESOURCE_MIN`;
   - `pub struct SeedingSettings { pub chance: f64, pub radius: u32, pub mutation: Mutation }` with
     `SeedingSettings::from_config(&Config) -> Result<SeedingSettings, GenomeError>` (uses `mutation_settings`) and a `new` validator
     (chance in [0,1], NaN rejected; radius from config is `u64` in 0..=16 -> `u32`);
   - `pub struct ReproductionReport { pub seeds: u64, pub placed: u64, pub refused_room: u64, pub refused_resources: u64 }`;
   - `pub fn reproduction_phase(entities: &mut Entities, spatial: &mut SpatialIndex, resources: &ResourceField, torus: &Torus,
     settings: &SeedingSettings, rng: &mut Rng, tick: u64) -> Result<ReproductionReport, SimError-or-EntityError/SpatialError>`.
     Steps: collect living plant ids ascending; per id: skip if dead or energy < `SEED_ENERGY_MIN`; `p = clamp(chance*2*fertility)`;
     `rng.chance(p)`; `drain_energy(SEED_COST)`; target via `neighbours` and `rng.next_below`; room and resource checks; `copy_child`;
     `Birth::from_genome`; `spawn_child`; `spatial.insert`. Keep the list-of-ids snapshot so newborns do not seed in their birth tick.
   - Error type: a `ReproductionError` wrapping `EntityError`, `SpatialError`, `GenomeError` (no panics in release paths).
2. **`entities.rs`**: no API change expected. If a helper is needed (for example `get` returning `&Organism` for the parent's cell and
   genome while mutating), read the fields first, then mutate (borrow order).
3. **`sim.rs`**:
   - field `seeding: SeedingSettings` in `Simulation`; `Simulation::new` sets it from `config`;
   - `from_parts(tick, rng_state, world, entities, seeding)`: fifth argument; update the four test call sites in `sim.rs`;
   - `run_phase` arm `Phase::Reproduction` calls `reproduction::reproduction_phase(&mut self.entities, &mut self.spatial,
     &self.world.resources, &self.world.topology, &self.seeding, &mut self.rng, self.tick)`; the report is discarded
     (metrics later), errors are asserted in debug builds;
   - Deaths arm unchanged (newborns are inserted into the spatial index at birth, removed by `Deaths` when dead).
4. **`lib.rs`**: `pub mod reproduction;`.
5. **Docs (IMPLEMENT)**: ADR-0013 to Accepted only at REVIEW; ARCHITECTURE module table row for `core::reproduction`; `scripts/check_adrs.sh`
   list entry for ADR-0013 (the ADR list is maintained in the script, as for ADR-0012); STATE IMPLEMENT section; ADR-0013 implementation notes.
6. **Close TASK-011 REVIEW gaps in tests (IMPLEMENT)**:
   - G-049: add `plant_only_population_bounded_and_survives` (see tests) in `reproduction.rs` or `sim.rs`;
   - G-050: replace the `>=` assertion in `ecology.rs` `cold_tolerance_gene_changes_growth_in_coldest_cell` with a strict comparison in a
     cell where the intolerant plant is damaged and the tolerant one is not.

## Tests to write in IMPLEMENT (each Must-have has at least one)
| Must-have | Test (planned name) |
|---|---|
| Reproduction only with energy, costs energy | `plant_below_threshold_never_seeds`; `seed_costs_parent_and_endows_child` |
| Dispersal distance, across edges | `seeds_land_within_radius_on_the_torus`; `seeds_wrap_across_both_edges` (8x8, radius 2, 2,000 seeds) ; `radius_zero_seeds_stay_on_parent_cell` |
| Inheritance with mutation; parent and generation | `child_genome_is_parent_with_bounded_mutation`; `mutation_rate_zero_copies_exactly`; `child_records_parent_and_generation` |
| No offspring without room or resources | `full_cell_refuses_seed_and_creates_nothing`; `empty_pool_refuses_seed_and_creates_nothing` (next_id, births unchanged) |
| Zero plants stays zero | `zero_initial_plants_stay_zero_with_animals_present` (500 ticks; proves no creation path) |
| Bookkeeping | `balance_holds_over_seeded_reproduction_run` (`check_balance` each tick) |
| Determinism | `reproduction_run_is_repeatable` (same seed twice gives equal `Simulation` and `state_hash`-equivalent equality) |
| Population (G-049) | `plant_only_population_bounded_and_survives` (>= 500 ticks, favourable 64x48, bound `CELL_PLANT_CAP x cells`, pool >= 0) |
| Settings | `seeding_settings_reject_bad_chance`; `from_config_maps_plant_keys` |

## Risks
- R1 calibration: `SEED_ENERGY_MIN` 70 may be unreachable in poor climates, so reproduction is rare there. That is ecology, but
  TASK-018 may need to adjust it. Uncalibrated.
- R2 density: `CELL_PLANT_CAP = 6` and the pool bound population; the cap is a hard "room" rule and not a global count. Check it does not
  make the favourable run flat-line at the cap for trivial reasons.
- R3 speed: one `within` and one `neighbours` vector per attempt; measure at 2,000 plants in IMPLEMENT (ADR-0012 R3 is still open).
- R4 checkpoint: `SeedingSettings` must be saved in TASK-022 along with `World.resources` (G-045). Until then `from_parts` requires the
  caller to supply it.
- R5 `from_parts` signature change touches four tests in `sim.rs`; low risk, the compiler finds them all.
- R6 borrow order: parent's genome and cell must be copied out before `spawn_child` (which needs `&mut Entities`).
- R7 energy overhead: `SEED_COST - SEED_ENDOWMENT` energy disappears per seed. This is documented; it never creates energy.

## Gaps carried into IMPLEMENT
- G-049 and G-050 (TASK-011 REVIEW gaps) are planned to be closed in IMPLEMENT (step 6 above).
- Release timing at 2,000 plants and the full `scripts/test.sh` run (`setup.sh`, `build.sh`, `dist/evosim`) are not run in PLAN; the
  IMPLEMENT phase should run `bash scripts/test.sh` if time allows (it builds `dist/`, which is git-ignored).

## Commands run in PLAN (exit codes)
- `export PATH=/opt/rust/cargo/bin:$PATH; cargo test -p evosim-core --locked` -> 0 (228 passed, 1 ignored).
- `bash scripts/check_adrs.sh` -> 0 (checks=109 failed=0), run after ADR-0013 was written; the script's fixed ADR list does not include ADR-0013 yet (IMPLEMENT adds it). ADR-0013 has all six required headings (Status, Context, Considered alternatives, Decision, Consequences, Verification strategy), checked by grep.
- `git remote -v | wc -l` -> 0.

# TASK-012 REVIEW cycle 1: plant reproduction and dispersal

Verdict: **PASS**.

## Acceptance criteria against tests (all pass)
| Must-have | Evidence |
|---|---|
| Reproduces only with enough energy; costs energy | `plant_below_threshold_never_seeds`, `plant_at_threshold_seeds_and_pays_the_cost`, `seed_costs_parent_and_endows_child` |
| Offspring within dispersal distance, across edges | `seeds_land_within_radius_on_the_torus_and_wrap_over_both_edges` (8x8, radius 2, 25 landing cells, x and y wrap reached), `radius_zero_seeds_stay_on_the_parent_cell` |
| Mutated inheritance; parent id and generation recorded | `child_records_parent_and_generation`, `mutation_rate_zero_copies_the_genome_exactly`, `child_genome_is_parent_with_bounded_mutation` |
| No offspring without room or resources | `full_cell_refuses_the_seed_and_creates_nothing`, `empty_pool_refuses_the_seed_and_creates_nothing` |
| Zero plants stays zero | `zero_initial_plants_stay_zero_with_animals_present` (500 ticks) |

Supporting tests: `balance_holds_over_a_seeded_reproduction_run`, `reproduction_run_is_repeatable_per_seed`, `plant_only_population_is_bounded_and_survives` (G-049).

## Commands
- `cargo test --workspace --locked`: exit 0 (core 247 passed, 1 ignored; cli 16 passed).
- `bash scripts/test.sh`: exit 0, "ALL TESTS PASSED".
- `bash scripts/check_adrs.sh`: exit 0, checks=120 failed=0.
- Release timing at 2,000 plants (temporary example, removed): 200 ticks in 0.055 s, about 3,650 ticks/s, plants only. This closes ADR-0012 R3 for plants.
- `./evosim run` is not implemented yet (a later task), so the CLI could not be used for timing.

## Gaps
1. `newborns_do_not_seed_in_their_birth_tick` only checks one mature parent gives one seed; it does not discriminate. Newborn exclusion rests on the id snapshot in `reproduction_phase` (code reading).
2. ADR-0013 verification text says "1,000 ticks"; the test runs 1,000 phase calls with fixed energy.
3. The calibration deviation (70/30/20 to 45/20/10) is accepted, but it was made in IMPLEMENT and not re-approved in a PLAN cycle.

## Changes in this phase
- ADR-0013 status set to Accepted, with review notes.
- `docs/decisions/README.md` index line updated.
- `docs/STATE.md` REVIEW section added.
- No code changes, no commits, no task.md/task.json changes.

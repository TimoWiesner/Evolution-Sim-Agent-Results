# TASK-012 IMPLEMENT cycle 1: plant reproduction and dispersal

Implements `docs/decisions/ADR-0013-plant-reproduction-and-dispersal.md` (still Proposed; Accepted only on REVIEW PASS).

- Code: `crates/evosim-core/src/reproduction.rs` (new), `sim.rs` (Reproduction arm, `SeedingSettings` field, `from_parts` fifth
  argument, `seeding()` accessor), `lib.rs`, `ecology.rs` (G-050 strict test).
- Docs: ADR-0013 (calibration deviation and implementation notes), `scripts/check_adrs.sh`, `docs/ARCHITECTURE.md`, `docs/STATE.md`.
- Calibration deviation: SEED_ENERGY_MIN 70 -> 45, SEED_COST 30 -> 20, SEED_ENDOWMENT 20 -> 10 (70 gave zero seeds because plant
  energy never exceeds about 55 under TASK-011). Measurements are in ADR-0013.
- Gaps closed: G-049 (plant-only population test), G-050 (strict cold-tolerance comparison).
- Verified commands and exit codes: see `implement-cycle1.json` `tests`; all exit 0.
- Not done: release timing at 2,000 plants; `scripts/test.sh` full run.
- Verdict N/A (IMPLEMENT). REVIEW must check each Must-have against the named tests and the ADR notes.

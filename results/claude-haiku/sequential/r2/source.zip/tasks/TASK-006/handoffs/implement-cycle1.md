# TASK-006 IMPLEMENT cycle 1: Climate zones and biomes

Scope: base climate only (no change over time, no effects on organisms). Plan followed: `tasks/TASK-006/handoffs/plan-cycle1.md`;
decisions: `docs/decisions/ADR-0009-climate-zones-and-biomes.md` (stays Proposed until REVIEW; implementation notes added).

## What was built
- `crates/evosim-core/src/climate.rs` (new). Latitude per row `90 * cos^2(pi * (y + 0.5) / H)` degrees, so the middle row is the
  equator and the top/bottom seam is polar. Five biomes by latitude (tropical < 20, dry 20-35, temperate 35-55, tundra 55-70,
  polar >= 70; half-open). Base temperature `28 - 50 (1 - cos phi)` C. Base precipitation
  `150 + 1600 exp(-(phi/14)^2) + 700 exp(-((phi-50)/14)^2)` mm/yr. Seeded regional variation: 3 to 5 cosine terms with integer
  wave numbers 0..=3 on x/W and y/H, weights summing to 1, amplitude 2.5 C and 8 % precipitation. Generator seeded with
  `seed XOR CLIMATE_SALT`, so the simulation RNG stream is unchanged.
- `World.climate` in `sim.rs`, built in `Simulation::new`. `World` and `Simulation` no longer derive `Eq` (f32 fields).
- Export without UI: `Climate::biome_map_text()`, `Climate::to_json()`, and `evosim climate --config FILE [--format text|json] [--out FILE]`.

## Deviations from the plan (also in ADR-0009 Implementation notes)
1. Variation terms store one normalised `weight` each, instead of separate temperature and precipitation amplitudes. The bounds
   stated in ADR-0009 are kept.
2. Documented temperature bounds are `-25..=31` C, not `-25..=30`: 28 C base plus 2.5 C variation reaches 30.5 C.
3. `dist/evosim` now links `libm.so.6` (for `cos` and `exp`). I added it to the allowlist in `scripts/test.sh` step 7. libm is
   part of glibc on Ubuntu 24.04, and ARCHITECTURE rule 5 already names the platform libm. This is a reading of the existing
   policy in ADR-0005, not a new dependency. Reviewer: please confirm this reading.

## Commands and exit codes (from /workspace, PATH includes /opt/rust/cargo/bin)
| Command | Exit | Result |
|---|---|---|
| `cargo test -p evosim-core --locked` | 0 | 112 passed (97 earlier + 15 climate) |
| `cargo test --workspace --locked` | 0 | core 112, cli 16 |
| `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` | 0 | 0 warning lines |
| `rustfmt --edition 2021 --check crates/evosim-core/src/climate.rs` | 0 | after formatting the file once |
| `bash scripts/check_adrs.sh` | 0 | checks=76 failed=0 (ADR-0009 added) |
| `./build.sh` | 0 | release build and `dist/evosim` written |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED (first run exit 1 on libm, fixed as in deviation 3, rerun exit 0) |
| `./evosim climate --config <64x48 example> --format text` | 0 | 48 lines of 64 glyphs: P 1024, U 256, T 512, D 256, R 1024 |
| `./evosim climate ... --format json --out DIR/x/c.json` | 0 | valid JSON (python3 -I json.load), 3072 cells, parents created |
| `./evosim climate ... --format bogus` | 2 | message on stderr, no stdout |
| `./evosim climate` (no --config) | 2 | message on stderr |
| `./evosim climate --config missing.json` | 2 | "cannot read" on stderr |
| `./evosim climate --config width-0.json` | 2 | "world.width: 0 is out of range 1..=4096" |
| `./evosim climate --config c.json --out x.txt --format json extra` | 2 | no output file created |
| `./evosim climate ... --format json` twice, `cmp` | 0 | byte-identical |
| `./evosim climate` on 1x1, 1x7, 7x1, 2x2 configs | 0 | correct line counts |
| `grep -rn 'SystemTime\|Instant\|thread_rng\|rand::' crates/evosim-core/src` | 1 | no match |
| `grep -rn 'evosim_ui\|evosim-ui\|evosim_cli\|evosim-cli' crates/evosim-core/` | 1 | no match |
| `git remote -v \| wc -l` | 0 | 0 |

Tests added (15 in `climate::tests`): biome rank order, names and glyphs, latitude formula points, temperature and precipitation
points, half-open thresholds, pole-to-equator order for H = 60 (all five zones), periodicity of the variation on the torus for seven
sizes including 1x1 and 200x3, seam no worse than interior (seven sizes, three seeds), every cell finite and in bounds with
its biome matching its latitude, weight bounds, same seed equal and different seed different, `from_parts` reproduces the climate,
small worlds, text map shape, JSON export finite and complete. CLI: 2 parser tests and 5 dispatch tests (file written with parent
directories, failed run writes nothing, bad config is an error).

## Verdict basis
Verdict is N/A (IMPLEMENT). The acceptance points are covered as follows:
- biome, base temperature and precipitation per cell from position: `every_cell_has_values_and_biome`, CLI JSON export;
- zone order: `biome_order_from_pole_to_equator`, `biome_rank_is_cold_to_hot`;
- no seam: `seam_is_no_worse_than_interior`, `variation_is_periodic_on_torus`;
- documentation of the compromise: ADR-0009 (Decision, Consequences), ARCHITECTURE status paragraph;
- printable or exportable without UI: `evosim climate` text and JSON, verified in the black-box runs above;
- any world size incl. very small: `small_worlds_work`, 1x1/1x7/7x1/2x2 CLI runs.

## Risks and open points
- Thresholds and formulas are a plausible shape, not calibrated. Later ecology tasks depend on them (ADR-0009: change only with the ADR).
- The equator is the middle row and the poles are the seam (documented compromise). A reader may expect two poles.
- The `./evosim` launcher builds only if `target/release/evosim` is missing, so it runs a stale binary after source edits (G-026,
  pre-existing). This phase used `./build.sh` before each black-box run.
- `scripts/test.sh` does not yet run the `evosim climate` black-box checks (G-027). They were run by hand and are listed above.
- The seam and order tests use fixed sizes and seeds, not property tests (G-028).
- Checkpoints (TASK-022) must save `Climate::terms()` or regenerate from the seed (`Climate::from_parts` is the hook). Not done here.
- Float results depend on libm `cos` and `exp` at world creation. Same build gives identical bytes; the contract allows last-bit differences across platforms.

## Not changed
task.md, task.json, benchmark files, contract, the `evosim` launcher, `setup.sh`, no commit, no `dist/` committed (git-ignored).

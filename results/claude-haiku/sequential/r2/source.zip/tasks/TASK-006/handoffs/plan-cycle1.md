# TASK-006 PLAN cycle 1: Climate zones and biomes

Scope: base climate only (no change over time, no effects on organisms). No feature code changed in PLAN.
Decisions are in `docs/decisions/ADR-0009-climate-zones-and-biomes.md` (Proposed). This file gives the order,
interfaces, tests and risks for IMPLEMENT.

## Starting state (checked in PLAN)
- `git status`: clean at start (HEAD `6c93008 TASK-005 review cycle 1 PASS`). `git remote -v` = 0 lines.
- `crates/evosim-core/src/`: `config.rs` (+ `config/`), `rng.rs`, `sim.rs`, `world.rs`, `lib.rs`. No `climate.rs`.
- `World { pub topology: Torus }` in `sim.rs`; `Simulation::new(&Config)` seeds `Rng::from_seed(config.seed)`;
  `Simulation::from_parts(tick, rng_state, world)` for checkpoint restore.
- `Torus` (`world.rs`) is `Copy`, has `width()`, `height()`, `cell_count()`, `cell(x,y)`, `wrap(Coord)`,
  `index(Cell)`, `cell_from_index(usize)`, `delta`, `distance`, `neighbours`. `Cell` fields are private (`x()`, `y()`).
- `config` already has `climate.season_length` and `climate.weather_amplitude` (TASK-007 uses them). No new config keys
  for TASK-006 (thresholds and formulas are constants in `climate.rs`, ADR-0009).
- Commands work: `cargo test -p evosim-core --locked`, `bash scripts/check_adrs.sh` (checks=65), `bash scripts/test.sh`.
  `PATH` must include `/opt/rust/cargo/bin`.

## Ordered IMPLEMENT steps
1. **`crates/evosim-core/src/climate.rs` (new).** Add `pub mod climate;` to `lib.rs`.
   - `pub enum Biome { Polar, Tundra, Temperate, Dry, Tropical }` with `rank() -> u8` (0..=4), `Ord` by rank,
     `name() -> &'static str` ("polar", "tundra", "temperate", "dry", "tropical"), `glyph() -> char` (P, U, T, D, R).
   - `pub struct CellClimate { pub latitude: f32, pub biome: Biome, pub temperature: f32, pub precipitation: f32 }`.
   - `pub struct Climate { torus: Torus, cells: Vec<CellClimate>, terms: Vec<WaveTerm> }`, `WaveTerm { i: u32, j: u32, phase: f64, amp_t: f64, amp_p: f64 }` (amplitudes as fractions).
   - `pub const CLIMATE_SALT: u64` (fixed constant, e.g. `0x434C_494D_4154_4500`).
   - `pub fn latitude_of_row(height: u32, y: u32) -> f64` = `90 * cos^2(pi * (y + 0.5)/H)`.
   - `pub fn base_temperature(lat_deg: f64) -> f64`, `pub fn base_precipitation(lat_deg: f64) -> f64`, `pub fn biome_for_latitude(lat_deg: f64) -> Biome` (ADR-0009 thresholds).
   - `Climate::new(torus: &Torus, seed: u64) -> Climate`: draws `terms` from `Rng::from_seed(seed ^ CLIMATE_SALT)`
     (3..=5 terms, `i, j` in `0..=3` not both zero, phase in `[0, 2pi)`, amplitudes temperature `<= 2.5` C and precipitation `<= 8 %`);
     fills `cells` in `Torus::index` order with f64 math, stored as f32.
   - Variation term: `cos(2*pi*(i*x/W + j*y/H) + phase)`; normalised by the sum of `|amp|` so the total is bounded by the stated amplitude.
   - `pub fn at(&self, cell: Cell) -> &CellClimate` (index via `torus.index`), `pub fn torus(&self) -> Torus`,
     `pub fn terms(&self) -> &[WaveTerm]`, `pub fn from_parts(torus, terms) -> Climate` (recomputes cells, for checkpoints).
   - `pub fn biome_map_text(&self) -> String`: H lines of W glyphs, each line ends with `\n`.
   - `pub fn to_json(&self) -> String`: `{"width":W,"height":H,"cells":[...]}` with per-cell `biome`, `latitude`, `temperature`, `precipitation`, row-major; formatted with `{}` on f32 (no NaN; checked in tests).
2. **`crates/evosim-core/src/sim.rs`.** `World` gains `pub climate: Climate`. `Simulation::new` builds
   `Climate::new(&topology, config.seed)`. `from_parts` unchanged in shape (the world carries the climate).
   Drop `Eq` from `World` and `Simulation` derives (f32 fields), keep `PartialEq`. Update the doc comment
   ("Climate and organisms are added by later tasks") and the `Climate` phase comment (still a no-op until TASK-007).
   The rng stream is untouched (climate uses its own generator), so `trace_identical_*` tests keep their meaning.
3. **`crates/evosim-cli/src/args.rs` and `main.rs` (+ a `commands/climate.rs` module if it keeps main small).**
   Add `evosim climate --config FILE [--format text|json] [--out FILE]`. Default `--format text`. Errors: invalid
   args, unreadable config, or unknown format -> exit 2, message on stderr, no output file. Text/JSON to stdout when
   `--out` is absent; with `--out`, the parent directory is created and the file is written. Logs only to stderr.
   Uses `config::Config::load` (existing) and `Simulation::new` or `Climate::new` directly. Check the CLI tests still pass (9 today).
4. **Tests in `climate.rs` (`#[cfg(test)] mod tests`).** See the list below.
5. **Docs.**
   - `docs/ARCHITECTURE.md`: replace the `core::climate` row text with the implemented design; add status paragraph for TASK-006 and "Compromise" pointer to ADR-0009; the module map row stays.
   - `docs/decisions/ADR-0009` status updated at REVIEW only; keep Proposed in IMPLEMENT and add "Implementation notes".
   - `docs/decisions/README.md` index already lists ADR-0009.
   - `docs/STATE.md`: status line and IMPLEMENT block with test names, commands, exit codes.
   - `scripts/check_adrs.sh`: add `ADR-0009-climate-zones-and-biomes.md` to the checked list and verify its six headings.
   - A short section in `README.md` on `evosim climate` (optional, only if README already lists commands).
6. **Run and record** the commands below. Record exact output in `implement-cycle1.md` and `.json`.

## Tests (names are planned; IMPLEMENT may add more)
- `biome_order_from_pole_to_equator`: for `H = 60`, along column 0 from the seam row (y=0) to the middle row, biome ranks go up monotonically Polar -> Tundra -> Temperate -> Dry -> Tropical, each of the five appears.
- `biome_rank_is_cold_to_hot`: `Biome::rank` 0..=4 in the order polar, tundra, temperate, dry, tropical; `Ord` agrees.
- `latitude_formula_points`: `latitude_of_row(H, y)` at `H = 1` gives 0; at the seam row it is close to 90 (within `90*(1-cos^2(pi/(2H)))`).
- `temperature_and_precipitation_points`: T(0)=28, T(90)=-22 (within 1e-9); precipitation at 0 about 1750, at 28 deg less than 300 (dry), at 50 deg more than 800.
- `biome_thresholds_half_open`: `biome_for_latitude` at 19.999, 20, 34.999, 35, 54.999, 55, 69.999, 70.
- `variation_is_periodic_on_torus`: for several sizes, the variation term at `x = 0` equals `x = W`, and `y = 0` equals `y = H` (f32 exact up to 1e-6).
- `seam_is_no_worse_than_interior`: for sizes `(1,1), (1,7), (7,1), (2,2), (3,5), (64,48), (200,3)` and 3 seeds: max abs difference across top/bottom and left/right neighbour pairs for temperature, precipitation and latitude is <= max over all other neighbour pairs (same metric). Use `torus.delta`/`neighbours` or plain index arithmetic; no UI.
- `every_cell_has_values_and_biome`: for each size the number of cells equals `W*H`, every value is finite, precipitation >= 0, temperature within `[-25, 30]` (documented bounds), biome matches `biome_for_latitude(latitude)`.
- `same_seed_same_climate` and `different_seed_different_variation` (for `64x48`, at least one cell differs).
- `small_worlds_work`: `1x1`, `1x7`, `7x1`, `2x2` build and produce one biome per cell without panic.
- `text_map_shape`: `biome_map_text` has `H` lines, each `W` glyphs; glyph set is `{P,U,T,D,R}`.
- `json_export_is_finite`: `to_json` contains no `NaN`/`inf` and has `W*H` cell objects (count `"biome"` occurrences).
- `sim`: `Simulation::new` gives a world whose `climate.torus()` equals the topology; trace tests from TASK-005 still pass.
- CLI tests (in `evosim-cli`): `climate` with `--format bogus` -> exit 2; `climate --config` with a valid config -> exit 0 and map rows count equals `height`.

## Commands to run (IMPLEMENT must record exit codes)
- `export PATH=/opt/rust/cargo/bin:$PATH; cargo test -p evosim-core --locked`
- `cargo clippy -p evosim-core --locked --all-targets`
- `cargo test --workspace --locked`
- `bash scripts/check_adrs.sh`
- `bash scripts/test.sh`
- `./evosim climate --config <tmp config> --format text` (exit 0, `height` lines) and `--format json` (valid JSON via `python3 -I -c 'import json,sys; json.load(sys.stdin)'`)
- `grep -rn 'SystemTime\|Instant\|thread_rng\|rand::' crates/evosim-core/src` (expect no match)
- `git remote -v | wc -l` (expect 0)

## Risks
- Thresholds and formulas are a plausible shape, not a calibrated model; later ecology tasks will depend on them. Mitigation: constants in one place, ADR-0009 required before change.
- The pole-on-seam compromise makes the seam polar; a reader may expect two poles. Mitigation: explain in ADR-0009 and ARCHITECTURE; screenshots (TASK-020+) show the layout.
- A 1-row world is all equator, and 2-row worlds are all 45 degrees: small worlds show few zones. Accepted: "works" means no panic and a valid map; the zone-order test uses `H >= 40`.
- `World` loses `Eq` (f32 fields). Any code relying on `Eq` breaks at compile time; only sim.rs and tests use it.
- Float determinism: values depend on libm `cos`/`exp`; same build gives same bytes. Cross-platform last-bit differences are allowed by the contract.
- Checkpoints (TASK-022) must store the wave terms or regenerate from the seed; `Climate::from_parts` is the hook. Not implemented here (out of scope).
- Clippy may flag casts (`u32` to `f64`); use `f64::from`.

## Next steps (for IMPLEMENT)
1. Write `climate.rs` and its tests; run `cargo test -p evosim-core --locked` until green.
2. Wire `World.climate`, `Simulation::new`, drop `Eq`; re-run the TASK-005 sim tests.
3. Add the CLI `climate` command and its tests; `cargo test --workspace --locked`.
4. Extend `scripts/check_adrs.sh` with ADR-0009; run `scripts/test.sh`.
5. Record evidence and update STATE, ARCHITECTURE and ADR-0009 implementation notes.

## Environment and checks in PLAN
- `cargo test -p evosim-core --locked` baseline: 97 passed (from TASK-005 review), not re-run in PLAN.
- `bash scripts/check_adrs.sh` (after ADR-0009 was added to docs): see handoff tests.
- `git remote -v | wc -l`: see handoff tests.
- No system packages needed.

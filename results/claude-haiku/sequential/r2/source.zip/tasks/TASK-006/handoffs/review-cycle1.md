# TASK-006 REVIEW cycle 1: Climate zones and biomes. Verdict: PASS

Scope of review: the diff of IMPLEMENT cycle 1 (commit eafaa8c tree, base 6c93008), `climate.rs`, `sim.rs`, the CLI `climate`
command, `scripts/test.sh` and `scripts/check_adrs.sh` changes, ADR-0009, ARCHITECTURE and STATE. No code was changed in REVIEW.

## Acceptance criteria (task.md "Must have")
1. Biome, base temperature and base precipitation per cell from position: met. `Climate::new` fills every cell from its row
   latitude; independent JSON check of `evosim climate --format json` on 64x48 gives 3072 cells with all three values.
2. Earth-like order polar, tundra, temperate, dry, tropical: met. Column 0 from the seam to the equator reads
   polar, tundra, temperate, dry, tropical (independent check; test `biome_order_from_pole_to_equator`).
3. No seam: met. Seam max neighbour difference (latitude 0, temperature 0.18 C, precipitation 3.2 mm) is below the interior
   maximum (5.9, 4.5, 386). Tests `seam_is_no_worse_than_interior` and `variation_is_periodic_on_torus`.
4. Compromise documented: met. ADR-0009 "Considered alternatives", "Decision: Compromise", "Consequences"; ARCHITECTURE status.
5. Printable or exported without UI: met. `evosim climate --config FILE --format text|json [--out FILE]`, exit 0; bad format exit 2.
6. Any world size incl. very small: met for the tested sizes (1x1, 1x7, 7x1, 2x2, 3x5, 64x48, 200x3 in unit tests; 1x1..2x2 CLI runs).

## Commands run in REVIEW (all from /workspace, PATH includes /opt/rust/cargo/bin)
- `cargo build --workspace --locked` exit 0.
- `cargo test --workspace --locked` exit 0 (core 112, cli 16).
- `cargo test -p evosim-core --locked climate` exit 0 (15).
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` exit 0, 0 warnings.
- `bash scripts/check_adrs.sh` exit 0 (76/0).
- `bash scripts/test.sh` exit 0 ("ALL TESTS PASSED").
- `target/debug/evosim climate ...` text/json/bogus exit 0/0/2; `dist/evosim climate` exit 0, 48 lines.
- `python3 -I` check of the JSON export (seam vs interior, zone order).
- `git remote -v | wc -l` = 0.

## Gaps (non-blocking; the verdict is PASS)
- G-027 (open): `scripts/test.sh` has no black-box step for `evosim climate`. Checked by hand in REVIEW.
- G-029: `crates/evosim-cli/src/args.rs` fails `rustfmt --check` after IMPLEMENT (it passed at TASK-005). `main.rs` was already unformatted at TASK-005. No format gate exists in scripts.
- G-030: `climate_run_with_zero_width_is_an_error` accepts either an error or success, so it proves nothing. Should assert the config is rejected.
- G-031: The seam test compares the seam with the maximum over all interior pairs. The polar seam is a flat extremum, so it passes easily. It meets the literal criterion but would not catch a jump located at a steep latitude. A stronger test would compare each seam pair to interior pairs at the same latitude band.
- G-026 (open): `./evosim` uses a stale release binary after source edits. Run `./build.sh` after changes.
- Design risks carried from ADR-0009: thresholds and formulas are not calibrated; the world has one equator and polar seam (no separate north and south poles); the libm dependency is allowed by reading ADR-0005 as "glibc incl. libm".

## Decision taken in REVIEW
- The libm reading (`dist/evosim` links `libm.so.6`) is accepted: libm ships with glibc on Ubuntu 24.04, and the `dist/` requirement is about runtimes and project dependencies, not libc parts. ADR-0005 wording is still "glibc, libgcc_s and the loader"; a later doc edit may align it.
- ADR-0009 status set to Accepted, as its own text requires for REVIEW PASS.

# TASK-018 IMPLEMENT cycle 1: food-chain integration

## Summary
Implemented ADR-0019 D2 (lifespan centred on the config `max_age` keys), the changed defaults with measured reasons, 12 library-level
tests, and the 10,000-tick survival command with recorded results. All gates pass (see the JSON handoff).

**Coexistence is not met.** At the default parameters, herbivores die out in all 10 measured seeds (143 to 604 ticks), carnivores in all
10 (167 to 409 ticks, 0 to 2 births per seed), and plants survive in 7 of 10. The task says coexistence is measured, not a pass point, so
REVIEW decides whether the other must-have points suffice.

## Must-have points and where they are shown
- Fixed-key 1,000-tick run: `food_chain_tests::fixed_key_configuration_runs_1000_ticks_without_error`.
- Scenarios: `without_plants_herbivores_then_carnivores_die_out`, `without_herbivores_carnivores_die_out`, `plants_alone_persist` (seeds 1 to 3).
- Never revive: `a_kind_that_reaches_zero_stays_at_zero` (10,000 ticks, seed 4).
- Conservation every tick: `per_kind_balance_holds_after_every_tick` (plus `check_balance`).
- Default parameters: `default_plants_survive_and_reproduce_on_their_own_for_1000_ticks`, `herbivores_with_plenty_of_plants_survive_and_breed_for_500_ticks`.
- Survival command: `bash scripts/survival.sh` (exit 0), held-out seeds 101 to 105 (exit 0); results in `docs/results/TASK-018-survival.md`.

## Changed defaults (ADR-0019 Implementation record)
- `plants.max_age` 500 to 1500: clonal founders grow old together; plants died at tick 588 in one seed at 500.
- `BITE_MAX` 2.0 to 0.5: at 2.0 plants crashed under 120 herbivores within about 150 ticks.
- `REGEN_RATE` 0.05 to 0.1: with the smaller bite.
- `SATIATION_CARNIVORE` 70 to 95: carnivores at 70 could never reach the mating threshold 90 (structural).

## Deviations
- `validate_genome` checks only the lifespan range (the store does not hold the centre).
- About 60 calibration candidates, above the 24 limit of ADR-0019 D4; selection by must-have points, not the median rule. Log: `docs/results/TASK-018-calibration.md`.

## Open
- Carnivore energy balance: not diagnosed; candidate constants did not help.
- Herbivore boom and bust with plants.
- Plant populations up to about 5,400 in some seeds.

## Gates
`cargo test -p evosim-core --locked` 356 passed, 1 ignored (exit 0); `cargo test --workspace --locked` exit 0; `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` exit 0 with no warnings; `bash scripts/check_adrs.sh` exit 0 (153 checks); `bash scripts/test.sh` exit 0; `git remote -v | wc -l` = 0.

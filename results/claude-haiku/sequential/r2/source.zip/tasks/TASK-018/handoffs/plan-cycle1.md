# TASK-018 PLAN cycle 1: food-chain integration and extinction

## Summary
The parts exist (ADR-0008 to ADR-0018), but the joined default run does not sustain the food chain. The main cause was found
by measurement: the lifespan trait maps to `[1, 10000]` ticks, so herbivores become mate-ready only after about 1,000 ticks,
and the config `*.max_age` keys (which ADR-0011 names as the intended centre) are unused. The plan centres lifespan on those keys,
keeps the tick order, adds only local mechanisms that already exist, and sets up a documented calibration and a 10,000-tick,
five-seed survival command. No product code was changed in PLAN.

## Measurements in PLAN (temporary probes, removed afterwards; release build)
Configuration: 64 x 48, fixed keys only, `populate_initial`, `tick`.
1. Plants only (0 herbivores, 0 carnivores), 2,000 ticks, seeds 1 to 5: plants survive in all five seeds, finals 485, 712, 380, 310, 395.
2. Plants 0, herbivores 120, carnivores 20, seeds 1 to 5: herbivores extinct at ticks 54, 55, 85, 54, 85; carnivores at 154, 118, 180, 154, 177.
3. Default 400/120/20, 2,000 ticks: herbivores extinct in seeds 2, 4, 5 (ticks 697, 1791, 464); seeds 1 and 3 keep one herbivore;
   carnivores extinct in all five seeds (ticks 270, 354, 285, 310, 215). Herbivore births 0 in seeds 1, 2, 3, 5; 23 in seed 4.
   Plant births are 119 to 366 per seed.
4. Seed 5 diagnostic, first 200 ticks: herbivores mean energy about 78, starvation/old-age/exposure deaths 0, births 0; mean herbivore
   `max_lifespan` 5,331; plant mean energy about 27 (below the growth reserve 40); plants fall from 449 to 103 by tick 200.

Interpretation: herbivores are not short of energy in the first 200 ticks. They cannot breed, because maturity is 20 % of a
lifespan of about 5,000 ticks. Herbivores then die of attrition from grazing pressure on plants (plants fall), and carnivores
lose their prey. This is a scale error, not a balance that a constant tweak alone would fix.

## Decisions (see docs/decisions/ADR-0019-food-chain-integration-and-balancing.md)
- D1 tick order: unchanged (Climate, SpatialIndex, Plants, Herbivores, Carnivores, Reproduction, Deaths, Species, Counters). Documented in ADR-0019 and in ARCHITECTURE.
- D2 lifespan centred on `plants.max_age`, `herbivores.max_age`, `carnivores.max_age`: lifespan = `floor(max_age * (0.5 + m))`, `m` the
  block mean of the lifespan slot. Through `entities::LifespanRanges` and `Birth::from_genome_in`; `Birth::from_genome` keeps the
  default centres so the existing call sites stay. Amends ADR-0011 and ADR-0004 as ADR-0011 already intended.
- D3 stabilising mechanisms: existing local ones only (cell resource pool, proportional sharing, satiation, prey caution and speed, climate
  zones, movement and metabolic costs). No new rule. No population-count rule.
- D4 balancing: apply D2 first and measure. Then, only if needed, plant-side constants, then herbivore intake and costs, then carnivore
  hunting constants. Calibration seeds 1 to 5, held-out seeds 101 to 105, at most 24 candidates, rule = maximise median coexistence,
  then the minimum over seeds. Every change is logged in `docs/results/TASK-018-calibration.md`.
- D5 command: `scripts/survival.sh` runs `cargo run --release -p evosim-core --example survival -- --ticks 10000 --seeds 1,2,3,4,5`
  and prints per seed and kind the extinction tick or "survived". Results go to `docs/results/TASK-018-survival.md`.
- Unused config keys `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism` stay unused and are recorded in ADR-0006 notes.

## Ordered implementation steps (IMPLEMENT)
1. `entities.rs`: `LifespanRanges { plants, herbivores, carnivores }` (u32 centres), `Birth::from_genome_in(kind, cell, genome, energy, health, &LifespanRanges)`.
   `decode_traits` takes the lifespan range as a parameter (or an internal `decode_traits_with`); `decode_traits` keeps its signature for tests.
   Test: centre mean within rounding; bounds `[floor(0.5c), ceil(1.5c)]`; `from_genome` equals `from_genome_in` with default centres.
2. `sim.rs`: build `LifespanRanges` from `Config` in `Simulation::new` (store it next to `seeding`, `mating`, `species`; a `from_parts`
   argument as for the other settings, with a clear test-helper default); use it in `populate_initial` and in reproduction and mating when
   births are built. Check that `reproduction.rs` and `mating.rs` construct newborns through the same helper.
3. Maturity check: test that a herbivore with `max_age` 300 is mate-ready between ticks 30 and 90 when energy allows (`mating::maturity_age`).
4. Scenario tests in a new `sim` test module `food_chain_tests` (library level, default world): (a) plants 0 -> herbivores extinct, then
   carnivores extinct not earlier than herbivores; (b) herbivores 0, plants 400, carnivores 20 -> carnivores extinct; (c) plants 400 only ->
   plants alive at tick 1,000 and births > 0 at tick 1,000.
5. Default-parameter tests: plants alone 1,000 ticks, births > 0; plants 1,500, herbivores 120, carnivores 0, 500 ticks: herbivores alive with
   births > 0 (the "plenty of plants" configuration; the value 1,500 is set in the test and in the record).
6. Conservation test: 1,000 ticks, default config, after every tick `initial + births - deaths == living` per kind and `check_balance()` is `Ok`.
   Never-revive test: after a kind reaches zero, its living count stays zero (10,000 ticks, one seed, every tick).
7. 1,000-tick smoke test with the fixed-key configuration (with `populate_initial`), no panic.
8. `examples/survival.rs` (new, in evosim-core) and `scripts/survival.sh`. Run for seeds 1 to 5 (report) and 101 to 105 (held-out) at 10,000 ticks;
   record per seed and kind the death tick or "survived" and the coexistence length; record timing (ticks per second) at 2,000 entities.
9. Calibration if needed (D4), each candidate logged; then the final defaults are recorded in ADR-0019 Decision (with the reason), and the
   constants stay in their ADRs (ADR-0012 to ADR-0016) with an amendment note.
10. Docs: ADR-0019 Accepted at REVIEW PASS; ADR-0011 `max_lifespan` row and ADR-0004 note; ADR-0006 notes on unused keys; ARCHITECTURE
    module table (`core::ecology` row, G-054) and tick order; STATE; `docs/results/`.
11. Gates: `cargo test -p evosim-core --locked`, `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
    `rustfmt --check` on touched files, `bash scripts/check_adrs.sh`, `bash scripts/test.sh`, `git remote -v | wc -l` = 0.

## Tests (planned names and checks)
See ADR-0019 Verification. Specific checks: maturity range 30 to 90 for `max_age` 300; scenario (a), (b), (c); plants-alone 1,000 ticks;
herbivores with 1,500 plants alive at 500 ticks with births > 0; conservation every tick; never-revive over 10,000 ticks; survival command exit 0.

## Risks
- R1 (high): the scale fix may still not produce a food chain at the default values. Calibration (D4) may need several cycles; it is time-bounded by the 60-minute phase limit, so IMPLEMENT must record partial results rather than hide them.
- R2: `LifespanRanges` touches decode and births in several modules (about 44 call sites in tests); the default-centre wrapper keeps test churn small.
- R3: plant lifespan (250 to 750 with the scale fix) changes plant-only persistence; it must be re-measured.
- R4: calibrating on the same seeds as the report overfits; held-out seeds 101 to 105 are used for the final check.
- R5: the 10,000-tick, five-seed run at larger populations may take minutes; the example must print progress to stderr and be run in the background if needed.
- R6: carnivore mating has never been exercised in a run (G-R3); the calibration may show that carnivores never reach maturity or energy. Recorded if it happens.
- R7: CLI wiring of `populate_initial` and of `final.species` is TASK-019 (G-037); TASK-018 tests use the library API.
- R8: the unused config keys may confuse a reader of the config; recorded in ADR-0006 notes, not wired in this task.

## Next steps
1. IMPLEMENT: steps 1 to 8 above (scale fix first, measurement second, calibration third).
2. REVIEW: independent re-run of the tests and of `scripts/survival.sh`; check every must-have with a named test or recorded command.

## Gaps
- G-037 (CLI wiring of founders and species in the result JSON): TASK-019.
- G-SP6 (no species split in default runs; calibration belongs to TASK-018/027, the rule must not be changed to force splits).
- G-R1/G-R2 (partner cooldown from the initiator's age; weak cooldown assertion): optional fix, not required for TASK-018.
- G-R3 (carnivore reproduction never exercised): addressed in step 5/8 measurements.
- G-046 (stale overlay query cost, not measured): performance measurement in step 8.
- TASK-013 REVIEW gap 2 (reversed-order `plan_moves` test) still open.
- G-054 (`docs/ARCHITECTURE.md` row for `core::ecology` mentions hunting and handling time): fixed in step 10.
- Unused config keys (see Decisions) and their ADR-0006 documentation.

## Checks run in PLAN (exit codes)
- `cargo test -p evosim-core --locked` -> exit 0, 344 passed, 1 ignored (baseline).
- `git remote -v | wc -l` -> 0.
- Temporary probe program (`crates/evosim-core/examples/plan18_probe.rs`, release, run three times with different arguments, then rewritten once for the diagnostic and deleted): exit 0 each run; no product code changed.
- `bash scripts/check_adrs.sh` was not re-run in PLAN, because ADR-0019 is not in its checked list; the new ADR follows the six-heading review checklist.

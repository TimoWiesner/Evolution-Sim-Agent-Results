# TASK-018 REVIEW cycle 1: food-chain integration

## Verdict: PASS

All seven acceptance criteria in `tasks/TASK-018/task.json` are met and shown by a named test or a recorded command. Coexistence of all three kinds is **not** met, and it is not a pass point: `task.md` says "Guaranteeing coexistence: populations may collapse... measured, but this task passes on the points above".

## Criteria check

| # | Criterion | Evidence (re-run in REVIEW) |
|---|---|---|
| 1 | One tick runs climate, plants, herbivores, carnivores, reproduction, deaths, species in a documented order | `sim::PHASE_ORDER` unchanged; ADR-0019 D1; ARCHITECTURE tick-order paragraphs. Order matches the criterion. |
| 2 | Fixed-key configuration runs at least 1,000 ticks without errors | `fixed_key_configuration_runs_1000_ticks_without_error` passes. |
| 3 | Births only as initial population or reproduction; a kind at zero stays at zero | Code: births come from `populate_initial` (tick 0) and `spawn_child` in `reproduction.rs` and `mating.rs`. Test: `a_kind_that_reaches_zero_stays_at_zero` (10,000 ticks, seed 4) passes. |
| 4 | Scenarios: no plants → herbivores then carnivores die; no herbivores → carnivores die; plants alone persist | `without_plants_herbivores_then_carnivores_die_out` (seeds 1-3, carnivore death tick ≥ herbivore death tick), `without_herbivores_carnivores_die_out`, `plants_alone_persist` all pass. |
| 5 | Per kind, initial + births − deaths = living after every tick | `per_kind_balance_holds_after_every_tick` (1,000 ticks, seed 3) and `check_balance` pass. Survival output lines also satisfy the identity. |
| 6 | Default parameters: plants survive and reproduce alone; herbivores with plenty of plants survive and breed for several hundred ticks | `default_plants_survive_and_reproduce_on_their_own_for_1000_ticks` passes (seeds 1-3). `herbivores_with_plenty_of_plants_survive_and_breed_for_500_ticks` passes with **1,500 plants** (see deviation D-1). |
| 7 | One documented command: default parameters, 10,000 ticks, at least five seeds, per seed and kind the death tick or "survived", recorded | `bash scripts/survival.sh` exit 0; held-out seeds 101-105 exit 0. Output reproduces `docs/results/TASK-018-survival.md` exactly. |

## Deviations and risks accepted in this review

- **D-1 (herbivore criterion scale).** The herbivore must-have is verified at 1,500 plants, not the default 400. At 400 plants, herbivores die out before reproducing in most seeds (for example seed 1: tick 157, 0 births). The phrase "plenty of plants" was read as a scenario condition, not as a changed default. A stricter reader could fail this point. Recommend that a later task (TASK-027) checks herbivore survival at the default 400 plants.
- **D-2 (coexistence).** No seed keeps all three kinds to 10,000 ticks. Herbivores die in 10 of 10 seeds (143-604 ticks); carnivores die in 10 of 10 (167-409 ticks, 0-2 births per run). Plants survive in 7 of 10. Recorded, not hidden, and not a pass point.
- **D-3 (calibration).** About 60 candidates were tried against the 24-candidate limit of ADR-0019 D4. Selection was by the must-have points, not the median-coexistence rule. Held-out seeds 101-105 were used after tuning, so they are not an unbiased estimate. The verdict does not depend on coexistence, so this does not change the result.
- **D-4 (lifespan validation).** `validate_genome` does not check the lifespan centre (ADR-0019 Implementation record). Fixed in TASK-022 with the checkpoint.

## Code reading notes

- Births: `sim::populate_initial` (tick 0) → `add_founder`/`spawn_founder`; reproduction: `reproduction.rs` (plant seeding, `Birth::from_genome_in` with `LifespanRanges`) and `mating.rs` (children) → `spawn_child`, which increments `births`. The `spawn_founder` calls in `feeding.rs`, `ecology.rs`, `hunting.rs`, `movement.rs` are in `#[cfg(test)]` modules.
- Lifespan scale: `LifespanRanges` from `plants/herbivores/carnivores.max_age`, lifespan = `floor(centre*(0.5+m))` clamped to `[1, 10000]`. Mean matches the centre within 5 % (test `lifespan_range_is_half_to_one_and_a_half_times_the_centre`).

## Gates re-run in REVIEW

- `cargo test -p evosim-core --locked`: exit 0, `356 passed; 0 failed; 1 ignored`.
- `bash scripts/survival.sh`: exit 0; seeds 1-5 reproduce the recorded table.
- Held-out `survival` run for seeds 101-105: exit 0; reproduces the recorded table.
- `bash scripts/check_adrs.sh`: exit 0, `checks=153 failed=0` (re-run after the ADR status edit).
- `git remote -v | wc -l`: 0.

Not re-run in REVIEW: `cargo test --workspace`, `cargo clippy`, `scripts/test.sh`. The IMPLEMENT handoff reports them passing; the changes in REVIEW are documentation only.

## Changes made in REVIEW (docs only)

- `docs/decisions/ADR-0019-food-chain-integration-and-balancing.md`: status Proposed → Accepted, with the review reference.
- `docs/STATE.md`: REVIEW cycle 1 entry appended.
- `tasks/TASK-018/handoffs/review-cycle1.json` and this file.

No product code, `task.md`, `task.json`, `AGENTS.md`, `CLAUDE.md`, `docs/CONTRACT.md`, or `.agents/skills/` was changed. Nothing was committed.

## Next steps (carried)

1. TASK-019: wire `populate_initial` and the survival run into `evosim batch` (G-037).
2. TASK-022: store `LifespanRanges` in the checkpoint; group the `from_parts` settings to drop the clippy allowance; make `validate_genome` check the lifespan centre.
3. TASK-027: diagnose the carnivore energy balance (energy, hunt attempts, meal size per carnivore per tick over 500 ticks); then herbivore boom-bust with plants; check herbivores at the default 400 plants; use new seeds for held-out checks.

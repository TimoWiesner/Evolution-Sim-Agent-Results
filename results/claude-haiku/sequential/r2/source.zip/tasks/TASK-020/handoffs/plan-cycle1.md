# TASK-020 PLAN cycle 1: metrics and evolution analytics

Decisions: `docs/decisions/ADR-0021-evolution-metrics.md` (Proposed). No product code was changed in PLAN. Docs changed:
ADR-0021 (new), `docs/decisions/README.md` (index lines for ADR-0020 and ADR-0021), `docs/ARCHITECTURE.md` (TASK-020 PLAN note),
`docs/STATE.md` (TASK-020 PLAN entry).

## Baseline (checked in PLAN, PATH includes /opt/rust/cargo/bin)
- `cargo test --workspace --locked` -> exit 0: evosim-core 388 passed, 1 ignored; evosim-cli unit 23 passed; `tests/run_cli.rs` 9 passed.
- `bash scripts/check_adrs.sh` -> exit 0, checks=153 failed=0 (ADR-0021 is not in the script's list; it is not checked mechanically).
- `git remote -v | wc -l` -> 0.
- No crate registry is cached; std only.

## Findings that shape the plan
- `metrics::sample` gives only the population per kind. `Entities` holds cumulative births, deaths, `deaths_by_cause` (kind x 5 causes),
  `initial`. `Entities::living()` iterates ascending id.
- `Organism` exposes `traits()` (speed, strength, fertility, max_lifespan, max_health), `tendencies()` (aggression, caution; animals),
  `generation()` (0 for founders, 1 + largest parent generation for children; test `generation_is_one_plus_the_largest_parent_generation`
  exists in entities.rs), `energy()`, `age()`, `genome()`.
- Plant-only traits are not in `Traits`: `ecology::PlantTraits::from_genome(&Genome)` gives cold_tolerance, drought_tolerance,
  yield_per_unit. Animal vision: `entities::vision_radius(&Genome)` (ploidy 2).
- `SpeciesRegistry::living_now(kind)` is `&self`; species are classified every `species.check_interval` ticks, so the count lags.
- `Simulation::add_founder(Birth)` is allowed only at tick 0 and uses explicit genomes (no RNG draws), so a 4x4 world can be built by hand.
- `Organism::damage(amount, cause)` and `Entities::deaths_phase(tick)` are public, so a death with a known cause is easy to produce in a test.
- `run_run` in `crates/evosim-cli/src/main.rs` already has the sampling loop at `metrics::series_ticks`; `write_atomically` exists.
- `args.rs` `parse_run` uses a repeated-option check per option; `RunArgs` has `config, ticks, out, seed, sample_every`.

## Ordered implementation steps (for IMPLEMENT)
1. `crates/evosim-core/src/analytics.rs` (new): `Stat`, `TraitStat` list per kind, `KindSample` (population, births, deaths,
   births_since_last, deaths_since_last, deaths_by_cause, species_living, species_recognised, generation max/mean, traits, mean_energy,
   mean_age), `Snapshot { tick, per kind }`, `MetricsLog` with `previous: Option<PerKind totals>`, `record(&mut self, &Simulation)`,
   `to_json(&self, info: &RunInfo) -> Result<String, String>` (reuses the fixed-layout writer of `metrics.rs`; make its `Node`
   writer `pub(crate)`; one sample per line). Two-pass sd, ascending id order, `Option` for empty sets (null).
2. `crates/evosim-core/src/lib.rs`: `pub mod analytics;`.
3. `crates/evosim-cli/src/args.rs`: `RunArgs.metrics: Option<PathBuf>`, `--metrics FILE` in `parse_run` (repeated = exit 2, missing value = exit 2),
   help text for `run` lists it. Error if equal to `--out` (exit 2).
4. `crates/evosim-cli/src/main.rs` `run_run`: if `--metrics`, create a `MetricsLog`, call `record` at each target tick (including tick
   start), build the metrics text before the run ends; write both temp files, then rename (metrics first, then result). Nothing printed
   to stdout. Measure `elapsed_seconds` only around the loop as now (the record calls are inside the loop, so they count; note this in
   the implement record and in `docs/METRICS.md`, or time the tick loop only, decided in IMPLEMENT and recorded).
5. `docs/METRICS.md` (new): the format reference (top-level keys, sample keys, trait lists per kind, null rule, interval rule, species
   lag, population sd divisor, units: speed cells per tick, vision cells, energy units as ADR-0011, age in ticks).
6. `README.md`: one example line with `--metrics`, link to `docs/METRICS.md`.
7. `docs/ARCHITECTURE.md` module row for `core::analytics`, and the TASK-020 IMPLEMENT note; `docs/STATE.md` IMPLEMENT entry; ADR-0021 status at
   REVIEW only.

## Planned tests (names are proposals)
Core (`analytics::tests`), hand-checkable world, width 4, height 4, seed fixed, no `populate_initial`:
- `two_plants_speed_mean_sd_min_max`: slot 0 loci all 0 (speed 0.0) and all 255 (speed 4.0): plants speed mean 2.0, sd 2.0, min 0.0, max 4.0.
  (Check the decode first: speed = 0 + 4 * mean, mean = L / 255 for ploidy 1; the plant genome has 128 loci, slot k = loci k*16..k*16+16.)
- `empty_herbivore_set_is_null_and_zero`: no herbivores -> population 0, herbivore traits and generation null, mean_energy null.
- `injury_death_is_counted_by_cause`: one plant at health 0 via `Organism::damage(.., Injury)` then `deaths_phase(0)`:
  `deaths_by_cause.plants.injury` 1, `deaths` 1, `deaths_since_last` 1 on the next sample, `population` one less.
- `interval_counts_are_differences_of_cumulative`: second sample, `births_since_last` = `births` - previous `births`; first sample 0.
- `generation_stats_from_a_known_parent`: founder (generation 0) and child by `spawn_child` (generation 1): max 1, mean 0.5. Uses the
  entities.rs rule (`1 + largest parent generation`). Note: `spawn_child` through `Simulation` needs `entities_mut()`.
- `species_living_matches_registry`: value equals `sim.species().living_now(kind)` after a tick (cross-check, no new rule).
- `sampling_does_not_change_the_state`: two identical sims, one recorded at every tick, the other not, after 200 ticks:
  `Simulation` `==` and `checkpoint::state_hash` equal.
- `to_json_is_valid_and_has_the_documented_keys`: parse with `config::json::parse`, every key of `docs/METRICS.md` present, `samples` length
  equals the series length.
- `to_json_one_sample_per_line`.
CLI (`crates/evosim-cli/tests/run_cli.rs`):
- `metrics_file_has_the_documented_shape_and_series_ticks`: `--metrics` and `--sample-every 100` on the example configuration:
  sample ticks equal the result `series` ticks, population equal.
- `metrics_does_not_change_the_state_hash`: with and without `--metrics`, same seed, same ticks: `state_hash` equal (and `final`, `totals`).
- `metrics_equal_to_out_is_an_error`: exit 2, no file. Repeated `--metrics`: exit 2. Missing value: exit 2.
- `failed_metrics_write_keeps_no_result_file`: unwritable metrics path (a directory) exits 2 and writes no result file.

Gates: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`, `bash scripts/check_adrs.sh`,
`./build.sh`, `bash scripts/test.sh`, `git remote -v | wc -l` = 0. Add a black-box step to `scripts/test.sh`: `./evosim run ... --metrics`
twice with the same seed, compare the metrics files after removing wall-clock lines (metrics have none) byte for byte.

Performance (IMPLEMENT measures, records in ADR-0021 Consequences): `--sample-every 1` at 2,000 organisms (examples/config.json scaled or a
test configuration) for 1,000 ticks, and at 5,000 organisms for 200 ticks, with and without `--metrics`.

## Risks
- R1 Sampling cost: trait decode per organism per sample (`trait_means` 8 slots x 128 loci). Mitigation: the decoded `Traits` are used for
  five traits; the genome is decoded only for vision and plant traits. Measure; if the cost is high, sample only at the series ticks (already the case).
- R2 `species_living` lags the population by up to `species.check_interval` ticks (ADR-0018). Documented, not fixed.
- R3 `null` for empty sets could surprise TASK-025 charts. Documented in `docs/METRICS.md`; TASK-025 must treat null as "no point".
- R4 Two-file write: if the second rename fails after the first succeeded, the metrics file exists without a result. Accepted; reported with
  exit 2; documented. Alternative (rename only after both are complete) cannot be fully atomic on POSIX.
- R5 The CLI option `--metrics` is an addition to CONTRACT section 2; the benchmark's listed commands are unchanged and the option is off by default.
  CONTRACT is not edited (benchmark owned).
- R6 Floating-point: sums in ascending id order, same build gives identical values; cross-platform differences are allowed by CONTRACT 5.1.
- R7 `elapsed_seconds` now includes sample work if the metrics are recorded inside the timed loop. Decide and document in IMPLEMENT.

## Open items handed to IMPLEMENT
- Confirm the decoded plant genome slot mapping in a test before the exact expected values are written.
- Choose and record whether `elapsed_seconds` includes metrics recording (R7).
- Record the performance numbers (R1) in ADR-0021 Consequences and `docs/METRICS.md`.

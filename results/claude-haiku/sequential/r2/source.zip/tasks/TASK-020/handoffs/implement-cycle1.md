# TASK-020 IMPLEMENT cycle 1 notes

Implemented ADR-0021 (PLAN cycle 1). Details of the format: `docs/METRICS.md`. Decisions: `implement-cycle1.json` `decisions`.

Test evidence (run in this cycle):
- `cargo test --workspace --locked`: exit 0. evosim-core 395 passed, 1 ignored; evosim-cli unit 26 passed; run_cli 9 passed.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: no diagnostics printed; exit status not recorded.
- `bash scripts/check_adrs.sh`: checks=153 failed=0.
- Debug-build cost run (120x120, 2,340 founders, 100 ticks, sample every tick): 2.67 s without `--metrics`, 2.97 s with it;
  state_hash identical (d7647085dfda2c953cd4bc300df3fea16d8f88f28f78a255199128e7644ad02e in both).

Not done: `scripts/test.sh` black-box step, `./build.sh`, `bash scripts/test.sh`, release-build cost measurement, ADR-0021 status
change (stays Proposed until REVIEW PASS).

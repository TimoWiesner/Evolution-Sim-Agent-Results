# TASK-016 PLAN cycle 1: animal sexual reproduction

Design: `docs/decisions/ADR-0017-animal-sexual-reproduction.md` (Proposed). This file is the ordered plan for IMPLEMENT.
No product code was changed in PLAN.

## Starting state (verified in PLAN)
- `cargo test -p evosim-core --locked`: exit 0, 313 passed, 1 ignored (run in this phase).
- Dependencies TASK-009 (genome, `crossover_child`, `genetic_distance`), TASK-013 (`move_organism`, `vision_radius`), TASK-014
  (herbivore arm), TASK-015 (carnivore arm) are accepted at REVIEW.
- `Entities::spawn_child` already enforces: animals name two distinct living parents; generation = 1 + max parent generation; `births`
  is counted. `SpatialIndex::within` is torus-aware, ascending, and lists dead-but-not-removed organisms (filter with `is_alive`).
- Config already has `herbivores.reproduction_energy` (60), `carnivores.reproduction_energy` (90), `*.max_age`, `genetics.*`.

## Ordered steps for IMPLEMENT
1. `entities.rs`: add `next_mate_age: u32` to `Organism` (0 in `push`, all births). Add `pub(crate) fn set_next_mate_age` on
   `Entities` (by id, living only). Add `Organism::maturity()` = `max(1, floor(0.2 × max_lifespan))` as a pure function. Update
   `check_invariants` only if a range rule is wanted (none needed). Doc comment for the field.
2. `mating.rs` (new; `pub mod mating;` in `lib.rs`): constants from ADR-0017 table, `MatingSettings` with `new` and
   `from_config` (uses `sim::mutation_settings` or the same `Mutation::new` path; validates thresholds are finite and ≥ 0),
   `MatingError` (wraps `GenomeError`, `EntityError`, `SpatialError`), `MatingReport`, pure helpers:
   `mating_chance(f_mean)`, `litter_size(draw)`, `parent_cost(litter)`, `is_mate_ready(o, threshold)`, `compatible(a, b)`,
   and `choose_partner(...)`.
3. `mating::mating_phase(entities, spatial, settings, rng) -> Result<MatingReport, MatingError>`: the procedure in ADR-0017
   (collect ids ascending, re-check eligibility, partner search before any draw, chance, litter draw, parent costs, crossover children,
   `spawn_child`, `spatial.insert`, `set_next_mate_age`).
4. `reproduction.rs` is untouched. `sim.rs`: add field `mating: MatingSettings`; `Simulation::new` builds it from config;
   `from_parts` takes a sixth argument (update the 4 existing test call sites in `sim.rs` and `from_parts` callers); accessor
   `mating()`; `SimError::Mating` with `From`; Reproduction arm: plant seeding first (unchanged), then `mating_phase`.
5. `sim.rs`: `populate_initial` and the founders are unchanged; founders have `next_mate_age` 0 and maturity from the genome.
6. Tests (see ADR-0017 verification): unit tests in `mating.rs`; sim-level tests in a new `mating_tests` module in `sim.rs`
   (single animal, positive control, seam partner, energy exactness, cooldown, balance and spatial over 2,000 ticks, determinism).
7. Docs in IMPLEMENT: ADR-0017 status to the implemented state (Proposed until REVIEW), implementation notes; ARCHITECTURE.md
   note; STATE.md IMPLEMENT section; `docs/decisions/README.md` line already added.
8. Commands in IMPLEMENT: `cargo test -p evosim-core --locked`, `cargo test --workspace --locked`,
   `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`, `rustfmt --edition 2021 --check` on the touched files,
   `bash scripts/check_adrs.sh`, `bash scripts/test.sh`. Record exit codes and counts in the implement handoff.

## Ordering rationale
Steps 1 and 2 are independent of the phase and are testable alone. Step 3 needs both. Step 4 is the only change to `Simulation`
and to the `from_parts` signature, so it comes after the module compiles. Tests come last, but each unit helper gets a test as it is written.

## Risks
- R1 (compatibility): random founders have mean distance about 0.333, so `COMPAT_MAX = 0.40` is the barrier that still lets founders
  mate. A tighter value would stop all founder matings. IMPLEMENT must measure the fraction of compatible founder pairs over seeds
  and record it.
- R2 (energy calibration): herbivore threshold 60 and carnivore threshold 90 may be rarely reached under the TASK-014/015 economy.
  If the first 1,000-tick probe shows no animal births, record it; do not add forced rules. Calibration belongs to TASK-018.
- R3 (existing exact tests): animals now may reach their thresholds, so exact-arithmetic tests in `herbivore_tests` and
  `hunting_tests` could change. Run them first; a change must be explained, not hidden.
- R4 (checkpoint): `next_mate_age` and `MatingSettings` are not saved until TASK-022; a loaded run cannot match an uninterrupted run
  until then. Record as a gap.
- R5 (cost of queries): one `within` and up to a few `genetic_distance` per eligible animal per tick. Not measured in PLAN; IMPLEMENT
  should time a 2,000-entity probe if the phase is in the test path, and record the number or say it was not measured.
- R6 (energy sink): the overhead removes `2 × MATE_OVERHEAD` per mating. This is intended; the exact-energy test covers it.

## Not part of this task
- Species naming and tracking (TASK-017); `species` checks are not run here.
- Checkpoint save and load of the new fields (TASK-022).
- Heritable mate preference, gestation, calibration of constants (TASK-018 and TASK-027).
- CLI `run` wiring (TASK-019).

## Gaps at PLAN time
- G-A1 to G-A4 as in ADR-0017 (calibration of the barrier, trait-free mate choice, no gestation, coexistence not yet measured).

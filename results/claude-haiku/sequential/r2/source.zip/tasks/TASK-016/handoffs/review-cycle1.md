# TASK-016 REVIEW cycle 1

Verdict: **PASS**. Every acceptance point in `tasks/TASK-016/task.md` is met and shown by a test or recorded command.

## Acceptance check
| Point | Evidence |
|---|---|
| Two different living same-kind mature animals, close, enough energy, compatible; never self | `mating.rs`: `is_mate_ready`, `choose_partner` (skips `initiator`, filters kind, range `MATE_RANGE`=2 Chebyshev torus, `compatible` <= 0.40). Tests: `readiness_requires_maturity_energy_cooldown_and_life`, `partner_choice_skips_self_other_kinds_and_non_mates`, `partner_across_the_seam_is_found`, `nearest_partner_wins_and_ties_go_to_the_lowest_id`, `partner_outside_range_or_incompatible_is_not_chosen`, `compatibility_uses_the_distance_barrier`. |
| Child genome = crossover of both parents + mutation; parent IDs and generation recorded | `mating_phase` calls `crossover_child(mother, father, mutation)`; `spawn_child` sets `parents` and `generation`. Test `mating_pays_both_parents_exactly_and_children_record_parents_and_generation` (parents [0,1], generation 1). |
| Reproduction costs both parents energy | `parent_cost(litter)` = litter*10+5 drained from both. Same test, exact values. |
| Cooldown after reproducing | `set_next_mate_age` for both parents; `parents_wait_out_the_cooldown_and_are_not_mate_ready_meanwhile` checks the stored value and that a second phase yields no litter. The final assertion of that test is weak (see gaps). |
| Fertility influences chance / litter | `mating_chance`, `litter_size` (fertility draw). Tests `chance_scales_with_fertility_and_is_clamped`, `litter_is_one_or_two_and_costs_match_the_formula`, `zero_fertility_never_mates`. |
| Single animal never produces offspring | `sim.rs` `mating_tests::single_animal_never_produces_offspring` (herbivore and carnivore, 4 seeds, 300 ticks, full energy, fertility 255). Positive control: `two_mature_neighbours_can_produce_offspring`. |

No global-count rule: eligibility reads only the animal, its partner, and its cell.

## Commands run in REVIEW
- `cargo test -p evosim-core --locked`: exit 0, 333 passed, 0 failed, 1 ignored.
- `cargo clippy -p evosim-core --locked --all-targets`: exit 0.
- `rustfmt --edition 2021 --check` on mating.rs, sim.rs, entities.rs: exit 0.
- `bash scripts/check_adrs.sh`: exit 0, checks=153 failed=0.
- `git remote -v | wc -l`: 0.
- Temporary probe (`sim.rs` appended test, run in release, then reverted with `git checkout`; tree clean afterwards):
  - Founder herbivore compatibility: 7140/7140 pairs <= 0.40 for seeds 1, 2, 3 (120 herbivores each). R1 is measured: the barrier does not block founders.
  - 2000 ticks, default-size world 64x48, initial 400/120/20: herbivore births reach 66, 66 and 88 (cumulative per seed). Herbivores drop to 0 in all three seeds. Carnivores are 0 from the first 500-tick sample, so carnivore matings never ran. R2 is measured: births occur, coexistence does not.
  - Elapsed about 0.25 to 0.35 s per 2000 ticks (release). R5 is only roughly measured; not a 2,000-entity timing.

## Gaps (non-blocking; for PLAN of a later task or a fix cycle)
- G-R1: Partner cooldown uses the initiator's age for both parents (`mating_phase`: `cooldown_until = my_age + MATE_COOLDOWN`). Because a lower id is never younger, the partner waits more than 20 ticks (by the age gap). Acceptance is still met (the wait is at least the required one). The ADR-0017 text matches the code, so the ADR may need a per-parent wording. Code reading only; not probed.
- G-R2: Test `parents_wait_out_the_cooldown_and_are_not_mate_ready_meanwhile` ends with `assert!(is_mate_ready(..) || energy < 60.0)`, which passes almost regardless. It does not prove the parents mate again after the wait.
- G-R3: Carnivore reproduction is never exercised in a run; carnivores die out at the start of the 2000-tick probe (TASK-015 economy, calibration in TASK-018/027).
- G-R4: Herbivores go extinct in all three probed seeds within 2000 ticks. Not a TASK-016 acceptance point; coexistence is TASK-018/027.
- G-R5: No checkpoint of `next_mate_age` and `MatingSettings` (TASK-022), so a loaded run does not match an uninterrupted run.
- G-R6: No CLI `run` yet (TASK-019); 10,000-tick and `state_hash` behaviour not checked.
- G-R7: Per-tick cost at 2,000 entities not timed against the 100 ticks/s goal.

## Changes made in REVIEW (docs only)
- `docs/decisions/ADR-0017-animal-sexual-reproduction.md`: status line set to Accepted (the ADR said it becomes Accepted at REVIEW PASS).
- `docs/STATE.md`: appended the TASK-016 REVIEW cycle 1 section.
- No product code changed. No commit made. `task.md`/`task.json` and benchmark tools untouched.

# TASK-022 PLAN cycle 1: savegames and checkpoints

Verdict field: N/A (PLAN). Machine-readable record: `plan-cycle1.json`. Decisions: `docs/decisions/ADR-0023-checkpoints-and-restore.md` (Proposed).

## Baseline (checked in PLAN, fresh context)
- `/workspace/AGENTS.md`, `docs/*`, `tasks/TASK-022/task.md|task.json`, handoffs of TASK-005, 007, 017, 019, 020, 021 read.
- `cargo test --workspace --locked` (toolchain `/opt/rust/cargo/bin`): exit 0. evosim-core 408 passed, 1 ignored; evosim-cli unit 32;
  `batch_cli` 8; `run_cli` 9. Log in `/tmp` only (not in the workspace).
- `git remote -v | wc -l` = 0. No system packages needed; std only. No product code changed in PLAN.

## What already exists (verified by reading the code)
- `checkpoint::encode_state` / `state_hash` (ADR-0020 D3) cover every state field. Each state module has `encode_state` with
  exhaustive destructuring: `rng.rs:128`, `world.rs:241` (Torus), `climate.rs:488,505` (WaveTerm, Climate), `ecology.rs:331`
  (ResourceField), `genome.rs:247,255` (Genome, Mutation), `entities.rs:986-1099` (Traits, Tendencies, LifespanRanges, Death,
  Organism, Entities), `species.rs:462-505` (SpeciesSettings, SpeciesRecord, Candidate, SpeciesRegistry), `reproduction.rs:214`
  (SeedingSettings), `mating.rs:293` (MatingSettings), `sim.rs:660,675` (World, Simulation).
- Restore constructors already present: `Simulation::from_parts` (`sim.rs:249`, rebuilds the spatial index, `trace: None`),
  `Climate::from_parts` (`climate.rs:305`, recomputes `cells`, validates), `ResourceField::from_values` (`ecology.rs:179`),
  `Rng::from_state` (`rng.rs:73`), `Genome::new` (`genome.rs:76`), `Tendencies::new` (`entities.rs:270`), `SeedingSettings::new`
  (`reproduction.rs:103`), `Torus::new` (`world.rs:144`), `SpeciesSettings::from_config`.
- Missing: any decoder (`decode_state`), the `Decoder`, the file container, CLI `--save`/`--load` (currently refused with exit 2 and
  "TASK-022" in the message: `args.rs:83,110,270`), the runner path that starts from a checkpoint (`runner.rs::run` always calls
  `populate_initial`).
- Accessors needed: `Simulation::tick_count()` (exists, `sim.rs:558`), `Simulation::check_spatial()` (exists, `sim.rs:521`),
  `Simulation::run(n)` (exists, `sim.rs:551`), `climate.torus()` (exists, `climate.rs:346`) for the result's width and height.

## Decisions (see ADR-0023)
- File: binary container `EVOSIMCK`, file format version 1, seed (metadata), body length, the existing `encode_state` body,
  SHA-256 trailer over everything before it. Atomic write (temp file and rename).
- Compression: none in version 1 (no crate offline; genome bytes and floats compress poorly; size measured in IMPLEMENT).
- Validation order D2 (length, magic, file version, exact length, digest, body version, decode with constructors, exact
  consumption, re-encode byte-equal, `check_spatial`). Every failure exit 2, no result file.
- `last_deaths` is saved (ADR-0020 D3 encodes it; ADR-0011's "not part of checkpoints" is superseded by ADR-0023 D4; ADR-0011 gets a
  pointer in IMPLEMENT).
- CLI: `--load` excludes `--config` and `--seed`; `--save` and `--out` may not be the same path; `--save` happens before the result
  is written.
- Resumed run: `seed`, `totals.initial`, `world`, `final`, `species_recognised`, `state_hash` from the checkpoint; `tick_start` =
  checkpoint tick; `sample_every` default from this invocation's `N`. Metrics log starts at the checkpoint tick (documented).

## Ordered IMPLEMENT steps
1. **Container and decoder primitives** (`crates/evosim-core/src/checkpoint.rs`): `Decoder` (bounded reads, `count` that cannot
   exceed remaining bytes, UTF-8 `str`, `opt_u64` tags 0/1, `finish`), `CheckpointError` (Truncated, NotACheckpoint,
   UnsupportedVersion{found, expected}, UnsupportedStateVersion, LengthMismatch, DigestMismatch, Trailing, NotCanonical,
   Invalid{what}, Spatial, plus Display text), `write_file(sim, seed) -> Vec<u8>`, `read_file(&[u8]) -> Result<Checkpoint,
   CheckpointError>` with `Checkpoint { seed: u64, sim: Simulation }`, `decode_state(body) -> Result<Simulation, _>`.
   The digest uses `sha256::digest`.
2. **Decoders, module by module, in the encoder's order** (each `pub(crate) fn decode_state(dec: &mut Decoder) -> Result<Self,
   CheckpointError>` next to its `encode_state`; fields are private, so the decoder lives in the owning module):
   - `rng.rs`: 4 words -> `Rng::from_state`.
   - `world.rs`: `Torus` from width/height (`Torus::new`).
   - `climate.rs`: `WaveTerm`, `ClimateParams` if encoded inline, then `Climate::from_parts(torus, terms, params, nodes, weather_tick)`.
   - `ecology.rs`: `ResourceField::from_values`.
   - `genome.rs`: `Genome` via `Genome::new(ploidy, loci)`; `Mutation` via `Mutation::new(rate, strength)`.
   - `entities.rs`: `Traits` (5 fields), `Tendencies::new`, `LifespanRanges`, `Death` (kind tag, cause tag), `Organism` (all fields,
     parents as two opt ids, cause tag, species opt id), `Entities` (organisms strictly ascending and `< next_id`, counters,
     `deaths_by_cause`, `last_deaths`).
   - `species.rs`: `SpeciesSettings`, `SpeciesRecord` (id equals position, kind tag, name, parent, ticks, reference genome),
     `Candidate`, `SpeciesRegistry` (settings, records, candidates `[Vec;3]`, `name_seq [u32;3]`).
   - `reproduction.rs`: `SeedingSettings::new(chance, radius, mutation)`; `mating.rs`: `MatingSettings` (mutation, threshold `[f32;2]`).
   - `sim.rs`: `World { topology, climate, resources }` in encoder order, then `Simulation::from_parts(...)`.
   Every struct is rebuilt with all its fields (no `..`), so a new field is a compile error as with the encoders.
3. **Round-trip check:** `read_file` ends with `write_file`-equivalent re-encoding of the decoded state, compared byte-for-byte with
   the body, then `check_spatial()`.
4. **Runner** (`crates/evosim-core/src/runner.rs`): split into `run_from(sim, seed, ticks, sample_every, with_metrics)`; `run`
   builds founders and calls it; `resume(checkpoint, ticks, sample_every, with_metrics)` calls it. `RunResult.seed` from the
   checkpoint, `width`/`height` from `sim`'s climate torus. Existing runner tests must still pass unchanged.
5. **CLI args** (`crates/evosim-cli/src/args.rs`): `RunArgs` gains `save: Option<PathBuf>`, `load: Option<PathBuf>`; `--config` required
   only without `--load`; the combinations of D5 are errors (exit 2). Replace the test `run_refuses_save_and_load_until_checkpoints_exist`
   (args.rs ~658) with tests for the accepted forms and each refused combination.
6. **CLI run** (`crates/evosim-cli/src/main.rs`): `run_run` loads a checkpoint when `--load` is given (file read, `read_file`) or
   builds the config path; creates the save parent directory; writes the checkpoint with a byte version of `write_atomically`
   (refactor `write_atomically` to take `&[u8]`, keep the existing text callers) before writing the result. Messages name the file.
7. **Tests** (see below), then update the three places that expect `--save` to be refused: `args.rs` test (step 5),
   `crates/evosim-cli/tests/run_cli.rs:264-266` (the `--save`/`--load` case), `scripts/test.sh:95-96`.
8. **Docs:** ADR-0023 status line and index entry (`docs/decisions/README.md`); ADR-0011 pointer to ADR-0023 D4 (`last_deaths`);
   `docs/ARCHITECTURE.md` checkpoint row and the `core::runner` row; `README.md` (the "Run" section mentions the refusal at line 48
   and line 93: update); `docs/STATE.md` IMPLEMENT and REVIEW entries; `scripts/check_adrs.sh` add ADR-0023 if it lists records.
9. **Measurements:** checkpoint size at about 5,000 entities (for example a 2,000-entity run and a 5,000-entity run from the
   configuration with larger `initial`), and resume overhead, recorded in the IMPLEMENT handoff.

## Tests (planned names and what they show)
Unit, `checkpoint.rs`:
- `decoder_primitives_reject_truncation_bad_tags_and_bad_utf8`.
- `round_trip_is_byte_equal_at_several_ticks`: states at tick 0, 1, 37, 150 of `examples/config.json` (weather on, `weather_amplitude`
  0.5 in a test config) decode and re-encode to the same bytes.
- `file_round_trip_restores_every_field_group`: one change per group before saving (tick, RNG word, organism energy, genome locus,
  species record, candidate, resource value, weather node, climate parameter, `next_id`, deaths counter, `last_deaths`, seeding,
  mating, lifespan, species settings) is visible after restore (hash changes before, equal after restore).
- `every_truncation_length_is_an_error_and_never_a_panic`: for all lengths 0..len-1 of a small file.
- `every_single_byte_flip_is_an_error`: flip each byte of a small file; each gives an error (digest or structural).
- `wrong_file_version_with_recomputed_digest_is_unsupported_version`; `wrong_state_version_with_recomputed_digest_is_refused`.
- `non_ascending_ids_are_invalid_even_with_a_valid_digest` (a hand-built body with a valid digest).
Integration, `runner.rs` or `checkpoint.rs`:
- `split_run_equals_uninterrupted_run`: run 300 ticks uninterrupted vs save at split s and resume for 300-s, for s in {0, 1, 37, 150}
  on `examples/config.json` seed 42 with weather on; compare `final`, `totals`, `state_hash`, and the per-tick `state_hash` after the
  split for every tick (catches divergence in any tick, not only at the end).
- `resume_never_populates_founders` (a loaded state has the same organisms as saved, not founders added).
CLI, `crates/evosim-cli/tests/checkpoint_cli.rs`:
- save at tick 0 and at 37 and 150, then `--load --ticks` the rest; `final`, `totals`, `state_hash`, `seed`, `tick_start` as expected
  (wall-clock lines removed for file comparisons).
- error cases each exit 2, message on stderr, no result file: missing checkpoint, truncated file, flipped byte, wrong file version,
  wrong magic (a result JSON given as checkpoint), `--seed` with `--load`, `--config` with `--load`, `--save` path equal to `--out`,
  unwritable save directory.
- a failed save (directory is a file) leaves no result file.
- `--ticks 0` load works and writes the same state hash as the checkpoint.
Black-box, `scripts/test.sh` (new step): `./evosim run --config examples/config.json --ticks 300 --out` and the split version
(`--ticks 37 --save`, then `--load --ticks 263 --out`); compare `final`, `totals`, `state_hash` after removing the wall-clock lines;
a corrupted copy of the checkpoint exits 2.
Gates after IMPLEMENT: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
`bash scripts/check_adrs.sh`, `./build.sh`, `bash scripts/test.sh`, `git remote -v | wc -l` = 0.

## Risks
1. **Size of the work.** About 20 decoders, the container, the runner split, the CLI and about 30 tests. Estimated 700 to 1,000 lines
   of Rust. This may not fit the 60-minute phase window with full gates. Mitigation: IMPLEMENT does steps 1 to 4 first, then the
   split-run test before CLI work; if the CLI or the black-box step cannot be finished, the handoff must say which steps are not
   done rather than claim them.
2. **Hidden state.** A field that is neither encoded nor decoded would not be in the hash and would not be restored. The split-run
   test over 300 ticks catches behavioural differences; the destructuring in `encode_state` catches new fields at compile time.
3. **Derived state.** The spatial index is rebuilt from organisms (`from_parts`); `Climate.cells` is recomputed from terms. Both are
   checked (`check_spatial`, round-trip). Other caches would be found by the split-run test only.
4. **`last_deaths` contradiction.** ADR-0011 excludes it, ADR-0020 includes it. Resolved in ADR-0023 D4 (included). Recorded so that the
   reviewer does not reopen it.
5. **Float bit patterns.** Restore uses `from_bits`; values must be bit-identical. Same-machine only, as the contract allows.
6. **Metrics log** of a resumed run is partial (starts at the checkpoint tick). Documented; not part of the acceptance criteria.
7. **File size** at 5,000 entities is unmeasured. Measured in IMPLEMENT step 9; compression deferred unless it is a problem.
8. **Unsafe input** (a hostile length prefix). `count` is checked against the remaining bytes before any allocation; the digest
   check precedes decoding, so random damage never reaches the decoder unless the digest is forged.

## Gaps carried into IMPLEMENT (not blockers)
- `deaths_by_cause` and `last_deaths` have no test that changes them alone (carried from TASK-019); the round-trip tests cover them once
  decoders exist.
- `scripts/check_adrs.sh` does not check ADR-0017 onward (G-021-1 from TASK-021); not changed by this task unless it is trivial.
- README `batch` coverage belongs to TASK-028; this task only updates the checkpoint text in the README.
- The UI save/load is TASK-024 (out of scope).

## Notes for the next phase
- Start with `Decoder` and `read_file`; the existing `checkpoint.rs` test helpers (`Parts`, `with_parts`) show how a state is
  changed field by field and can be reused for the round-trip tests.
- Keep the encoders unchanged (their bytes define the hash, ADR-0020 D3); only add decoders. If an encoder must change, bump the state
  format version and record it in ADR-0023.
- No commit by the agent. The orchestrator commits the phase.

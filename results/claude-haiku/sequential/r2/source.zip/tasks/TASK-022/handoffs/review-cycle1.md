# TASK-022 REVIEW cycle 1: savegames and checkpoints

Verdict: **PASS**. Machine-readable record: `review-cycle1.json`. ADR-0023 set to Accepted (`docs/decisions/ADR-0023-checkpoints-and-restore.md`, `docs/decisions/README.md`).

## Acceptance criteria (task.md "Must have")
1. `run --save/--load` reproduces `state_hash`, `final`, `totals` of an uninterrupted run.
   - Core: `runner::tests::split_run_equals_uninterrupted_run` (splits 0, 1, 37, 150, 299 of 300 ticks, weather on).
   - Core: `split_states_match_the_uninterrupted_run_at_every_later_tick` (hash compared at every tick 1..120 after splits 0, 37, 90).
   - CLI: `checkpoint_cli::save_and_resume_match_an_uninterrupted_run_at_several_split_points` (splits 0 and 25 of 60).
   - Black-box (`scripts/test.sh`, step 8): save at 37, resume 263 more, equal to a 300-tick run.
   - Independent (REVIEW): 2,000-entity world (96x64, seed 2, 2000 plants, 400 herbivores, 80 carnivores; at tick 400 all three kinds alive, with 24 herbivores and 4 carnivores). Resume from tick 97 and from tick 0 (both `--ticks` to 400): `state_hash`, `final`, `totals`, `seed`, `world` all equal to the uninterrupted run.
2. The checkpoint contains everything. `Simulation`, `World`, `Climate`, `ResourceField`, `Entities`, `Organism`, `Death`, `Genome`, `Traits`, `Tendencies`, `SpeciesRegistry`, `SpeciesRecord`, `Candidate`, `SeedingSettings`, `MatingSettings`, `LifespanRanges`, `Rng` each have an `encode_state` with exhaustive destructuring (compile-time coverage of encoders) and a `decode_state` that reads every field back, in the encoder's order. The only fields left out are the derived spatial index (rebuilt by `Simulation::assemble`, checked by `check_spatial`), the derived `Climate.cells` (recomputed by `Climate::from_parts`) and the diagnostic trace. Decoder completeness is checked by the byte-equal re-encode (`decode_body`, ADR-0023 D2 step 8), which fails if a decoder drops or reorders a field. Tests: `file_round_trip_restores_every_field_group`, `round_trip_is_byte_equal_at_several_ticks`.
3. Format version: `FILE_VERSION = 1` in the container and `FORMAT_VERSION = 1` in the body. Tests: `wrong_file_version_with_recomputed_digest_is_unsupported_version`, `wrong_state_version_with_recomputed_digest_is_refused`, CLI `damaged_missing_and_wrong_checkpoints_exit_2_and_write_no_result_...`.
4. Missing, damaged, truncated or wrong-version file gives exit 2 and no result file. Verified by hand (REVIEW) with the built binary: empty file, truncated to half, truncated by one byte, truncated to 40 bytes, one extra byte, flipped byte at offsets 0, 9, 13, 30, middle and last byte, file version 2, JSON result given as checkpoint, missing file. All exit 2, stderr has one message, no output file. Core tests `every_truncation_length_is_an_error_and_never_a_panic` and `every_single_byte_flip_is_an_error` cover every byte.
5. Tests compare uninterrupted and resumed runs for at least two split points including tick 0. Yes: core 0, 1, 37, 150, 299; CLI 0 and 25; black-box 37.

## Commands run in REVIEW (exit status)
- `cargo test --workspace --locked`: exit 0. evosim-core 423 passed, 1 ignored; CLI unit 33; batch_cli 8; checkpoint_cli 2; run_cli 9.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: exit 0, 0 warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=153 failed=0 (ADR-0023 is still not in the checked list; G-021-1 carried).
- `bash scripts/test.sh`: exit 0, "ALL TESTS PASSED".
- `git remote -v | wc -l`: 0.
- Independent black-box runs and corrupted-file runs listed above (scratch files were in `target/review`, removed afterwards).

## Code review notes
- Decoder order and tags match each encoder (checked module by module: rng, world, climate, ecology, genome, entities, species, reproduction, mating, sim). Death cause tag 0 is refused (encoder never writes it). Kind tags use `Kind::ALL`, which matches `Kind::index`.
- `read_file` order matches ADR-0023 D2. Digest is checked before the body is decoded.
- Length prefixes are bounded by remaining bytes (`Decoder::count`), so no length is trusted beyond the file.
- `runner::resume` never calls `populate_initial`; test `resume_never_populates_founders`.
- CLI: `--load` excludes `--config` and `--seed`; `--save` must differ from `--out`, `--metrics` and `--load`; checkpoint is written before the result; checkpoint write errors exit 2 with no result. `write_bytes_atomically` writes a temp file in the target directory and renames it.

## Gaps (non-blocking, not acceptance criteria)
- G-022-1: the forged-digest test with non-ascending organism ids (planned in PLAN, not written). The check exists (`Entities::decode_state`, `organism.id <= previous`) and is untested.
- G-022-2: `last_deaths` is not changed alone in any test. The byte-equal round trip covers it only when it is non-empty at the checkpoint.
- G-022-3: the CLI split tests use points 0 and 25; the planned 37 and 150 are only in the core tests and the black-box step (37).
- G-022-4: `Vec::with_capacity(count)` for organisms, deaths and species is bounded by the remaining byte count, not by the element size. A file with a valid forged digest could make the decoder allocate roughly 100 times the file size. Low risk for a local tool; the digest check comes first, so only a deliberately forged file reaches this.
- G-022-5 (doc drift): ADR-0023 D5 describes `run_from`/`resume` with positional arguments; the code uses `RunOptions`. The behaviour matches the ADR.
- G-022-6: a failing run leaves an older result file at `--out` untouched. The contract says "no result file"; this is only true for paths that did not exist before. Pre-existing behaviour of the result writer, not a regression.
- Carried: G-021-1 (`check_adrs.sh` does not list ADR-0017 onward, so ADR-0023 is not checked); resume overhead per tick not measured.

## Notes for next phase
- Nothing blocks TASK-022. If a later task changes the state, add the field to `encode_state`, `decode_state` and `Simulation::assemble` together and bump `FORMAT_VERSION` if the bytes change (ADR-0023 D3).
- No commit made by the agent; the orchestrator commits the phase.

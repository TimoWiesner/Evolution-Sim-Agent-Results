# TASK-022 IMPLEMENT cycle 1: savegames and checkpoints

Verdict field: N/A (IMPLEMENT). Machine-readable record: `implement-cycle1.json`. Decisions: `docs/decisions/ADR-0023-checkpoints-and-restore.md` (Proposed until REVIEW PASS).

## What was built
- `checkpoint.rs`: container `EVOSIMCK` (version 1; seed; body length; the canonical body from `encode_state`; SHA-256 trailer), `write_file`, `read_file` with the ADR-0023 D2 order, `Decoder`, `CheckpointError` (with Display text), and an explicit re-encode and `check_spatial` after decoding.
- `decode_state` next to every `encode_state` (rng, world, climate, ecology, genome, entities, species, reproduction, mating, sim). Encoders unchanged, so `state_hash` values are unchanged.
- `Simulation::assemble` builds the struct for both `from_parts` and the decoder, rebuilding the spatial index.
- `runner.rs`: `run_config`, `resume`, `run_from`, `RunOptions { sample_every, with_metrics, keep_state }`. `run` keeps its signature.
- CLI: `run --load FILE` (without `--config`/`--seed`) and `run --save FILE`. Refusals in `args.rs` (exit 2). `main.rs` writes checkpoint, then metrics, then result; a checkpoint write failure leaves no result.

## Tests run (exact commands, exit status)
- `cargo test --workspace --locked`: exit 0. Core 423 passed, 1 ignored; CLI unit 33; batch_cli 8; checkpoint_cli 2; run_cli 9.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0 (checks=153, failed=0).
- `./build.sh`: exit 0.
- `bash scripts/test.sh`: exit 0, "ALL TESTS PASSED". Step 8 now includes a save at 37 ticks, a resume to 300 ticks compared with the uninterrupted run (final, totals, state_hash, seed), and a truncated checkpoint that exits 2.
- `git remote -v | wc -l`: 0.

## Measurements
- Checkpoint size: 144,828 bytes for `examples/config.json` at tick 0; 1,359,024 bytes for 5,000 founders on 128x96.
- Loading the 5,000-entity checkpoint and running 0 ticks: 0.048 s wall time, same state hash before and after.
- Per-tick resume overhead: not measured.

## Deviations and gaps
- Not written: the forged-digest test with non-ascending organism ids (planned). The check exists in code.
- Not run: CLI split at tick 150 (the core covers it).
- Round-trip tests use a 16x12 weather world instead of `examples/config.json`, for speed.
- `last_deaths` has no test that changes it alone.
- ADR-0023 stays Proposed; `check_adrs.sh` does not list it (G-021-1).

## Notes for REVIEW
- Check each decoder against its encoder (the destructuring in `encode_state` catches a missed encoder field at compile time; a missed decoder field is not caught by the compiler).
- The split-run tests are in `runner.rs` (`split_run_equals_uninterrupted_run`, `split_states_match_the_uninterrupted_run_at_every_later_tick`) and the byte-level tests in `checkpoint.rs` (`mod file`).

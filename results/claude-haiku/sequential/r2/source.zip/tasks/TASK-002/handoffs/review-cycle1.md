# TASK-002 REVIEW cycle 1 — notes

Verdict: PASS (all six acceptance criteria met and shown by commands). Gaps G-011, G-012, G-013 are non-blocking.

## Checked against task.md "Must have"
1. Entry points exist: `setup.sh`, `evosim`, `build.sh` at the root; `scripts/test.sh` is the test command.
2. `./evosim version` prints `{"name": "evosim", "version": "0.1.0", "contract": 1}` after setup (exit 0, one trailing newline, nothing on stderr).
3. `./build.sh` writes `dist/evosim`; `dist/evosim version` prints the same JSON.
4. `./evosim --help` lists `version` and `--help`; unknown command exits 2 with a stderr message and empty stdout.
5. `bash scripts/test.sh` runs the whole suite: ADR/record check (54 checks, 0 failed), `cargo test --workspace --locked` (10 unit tests, all pass), setup, build, black-box checks, ldd allow-list. Exit 0, "ALL TESTS PASSED".
6. `README.md` covers install, build, test and layout; `.gitignore` ignores `dist/` and `target/`; `Cargo.lock` is tracked; no git remote.

## Findings
- G-011 (non-blocking): `find_cargo` takes the rustup proxy at `/opt/rust/cargo/bin/cargo` without checking it works.
  Without `RUSTUP_HOME`/`CARGO_HOME` (stripped env, `env -i HOME=/root PATH=/usr/bin:/bin`), `./setup.sh` exits 1 with
  "rustup could not choose a version of cargo". With those two variables set to `/opt/rust/rustup` and `/opt/rust/cargo`
  it exits 0 and `./evosim version` prints the exact JSON. The container image sets them, so the criteria are met there.
- G-012 (non-blocking): the rustup install branch of `setup.sh` was not executed (needs network; cargo present).
- G-013 (non-blocking): `dist/evosim` was not run on a clean Ubuntu 24.04 system. It runs with no Rust on PATH and `ldd`
  lists only glibc, libgcc_s and the loader.

## Environment at review time
cargo/rustc 1.100.0; RUSTUP_HOME=/opt/rust/rustup, CARGO_HOME=/opt/rust/cargo; git remote count 0.
Clean-state build was re-run from `rm -rf target dist`.

## Changes in this phase (docs only)
- `docs/STATE.md`: REVIEW cycle 1 block; status line updated; duplicated paragraph removed.
- `docs/decisions/ADR-0005-...md`: status confirmed in REVIEW; known limit G-011 noted.
- No code, task.md/task.json, benchmark files or commits.

# TASK-002 IMPLEMENT cycle 1 — notes

Implemented `tasks/TASK-002/handoffs/plan-cycle1.md` and ADR-0005.

Result: `bash scripts/test.sh` exit 0 ("ALL TESTS PASSED"): check_adrs 54/0 failed; `cargo test --workspace --locked`
10 passed; setup, build, black-box `evosim` and `dist/evosim` checks, and `ldd` all pass.

Deviations from the plan: none in design. One fix during the run: the core-to-UI grep in `check_adrs.sh` matched a
doc comment in `evosim-core/src/lib.rs`, which was reworded. `Cargo.lock` was generated with `cargo generate-lockfile`
because `--locked` cannot create one.

Not verified: the rustup install branch in `setup.sh`; `dist/evosim` on a clean Ubuntu without Rust.
Environment: cargo 1.100.0, no apt packages installed or needed. `git remote -v` = 0.

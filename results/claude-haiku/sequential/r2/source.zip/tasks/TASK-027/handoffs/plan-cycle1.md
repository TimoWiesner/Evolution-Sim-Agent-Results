# TASK-027 PLAN cycle 1: ecosystem balance

Status: PLAN done. No product code, no Cargo file, no task file, no benchmark file changed. No commit by the agent.
Machine-readable handoff: `plan-cycle1.json`. Decisions: `docs/decisions/ADR-0028-ecosystem-balance.md` (Proposed).
Probe evidence: `docs/results/TASK-027-plan-probe.md`.

## Summary of what PLAN found
- Baseline preview (unchanged code, example configuration of CONTRACT section 3, 10,000 ticks, seeds 1 to 10): herbivores
  die out first in all 10 seeds (ticks 309 to 610); carnivores die out in all 10 (ticks 167 to 411). Coexistence of all three
  kinds lasts 157 to 610 ticks. Plants survive to 10,000 in 6 of 10 seeds.
- First-extinction diagnostic (seed 1, metrics file): 117 of 120 herbivores are killed by predation within 100 ticks; herbivore
  births are 0 in that seed (0 to 31 over 10,000 ticks in all seeds); carnivores have 0 to 4 births in total and starve.
- Founders start at energy 50, below the herbivore mating threshold of 60, so few herbivores breed before predators reach them.
- Hypothesis (not yet checked): plant extinctions at 1,536 to 7,951 ticks come from founder cohort ageing (clones, similar
  lifespans around 1,500), not from grazing.
- `cargo test --workspace --locked --offline` exit 0 at HEAD 6c34696 (36 + 8 + 2 + 9 + 431 (1 ignored) + 95 (1 ignored)).
- `git remote -v | wc -l` = 0.

## Decisions (details in ADR-0028)
1. Mechanisms before parameters. First trial T1: crowding dilutes predation (attack chance falls with herbivores in the
   carnivore's own cell). T2: handling time after a kill (per-carnivore timer). T3 only after a read-only diagnostic of
   mating refusals. T4 optional. Parameter-only trials are capped at three and come after the mechanism trials.
2. Tuning seeds 1 to 20; held-out seeds 101 to 110, run once on the final defaults (task needs at least five).
3. Metric: per seed `L = min` extinction tick over the three kinds (10,000 if none dies); primary score median `L`;
   secondary the number of seeds with all three kinds alive at 10,000; tie-break minimum `L`.
4. Stop rule: after one improving mechanism trial plus one follow-up, or after two non-improving trials, or at 40 minutes
   of IMPLEMENT time.
5. Diagnostics (read-only counters) may be added first; they must leave every state hash unchanged.
6. The official baseline (task must-have 1) is measured in IMPLEMENT before the first change, with
   `./evosim batch --config examples/config.json --seeds 1,...,20 --ticks 10000 --sample-every 1` (or the 10-seed subset,
   recorded), and stored under `docs/results/TASK-027/`.
7. After the defaults are chosen: `bash scripts/perf.sh` is re-run (TASK-026 target 100 ticks/s; last median 1,081.7).

## Ordered plan for IMPLEMENT
1. Record the official baseline: `./evosim batch` for seeds 1 to 20 (10,000 ticks, `--sample-every 1`), copy the summary and a
   table of extinction ticks into `docs/results/TASK-027/baseline.md`. Confirm the exact extinction-tick extraction script
   (put it under `scripts/`, not in `dist/`).
2. Write the cause analysis of the first extinction for all 20 seeds with `./evosim run --metrics` (`deaths_by_cause`,
   population curves, mating refusals once counters exist). Write it into `docs/BALANCE.md` (new file) before any change.
3. Add read-only diagnostics: mating refusals by reason (`crates/evosim-core/src/mating.rs`), attacks by outcome and
   attack-chance factor (`hunting.rs`). Check that the state hash of seeds 1 and 2 at 1,000 ticks is unchanged.
4. Trial T1 in `crates/evosim-core/src/hunting.rs`: crowding factor in `attack_chance` (or at the call site in `attack`).
   Unit tests: factor 1 with one herbivore; monotone in crowding; deterministic. Run tuning seeds 1 to 20. Log the trial.
5. Trial T2: handling timer stored with the carnivore (encode/decode in the checkpoint, `checkpoint.rs` and the state
   modules) so `--save`/`--load` stays exact (CONTRACT section 5.2). Tests: attack blocked for exactly `HANDLING_TICKS`.
   Log the trial.
6. Trial T3 only if the diagnostic shows energy as the dominant mating refusal. Log the trial either way.
7. Choose the defaults by the D3 metric. Re-record regression values (state hashes) with the reason, in `BALANCE.md`
   and ADR-0028. Update `config.rs` defaults only if the config keys are the carrier; otherwise constants with ADR amendments.
8. Held-out run once: seeds 101 to 110, 10,000 ticks, `./evosim batch`, recorded in `docs/BALANCE.md`.
9. Gates: `cargo test --workspace --locked --offline`, `cargo clippy --workspace --all-targets --locked --offline`,
   `bash scripts/check_adrs.sh` (add ADR-0028 to the checked list if it has a list), `bash scripts/perf.sh` (TASK-026),
   `./build.sh` and `./dist/evosim version`, `git remote -v | wc -l` = 0.
10. Docs: `docs/BALANCE.md` (how long the three kinds coexisted before and after, whether the goal was reached, remaining
    limits), ADR-0028 status, `docs/STATE.md`, `docs/ARCHITECTURE.md`.

## Tests planned
- New unit tests per mechanism (above); the existing `per_kind_balance_holds_after_every_tick`, `never revive`, scenario tests
  and `check_balance` must stay green.
- A test that no new rule reads a population count (code review plus a grep check recorded in the handoff).
- Determinism: same seed twice gives the same `state_hash` after the change; checkpoint round trip after T2.

## Risks
- R1 (high): neither T1 nor T2 may produce coexistence; the outcome then is an honest negative result, which is acceptable
  under the task. The IMPLEMENT phase must still record the trials.
- R2: the 40-minute trial budget may cut the search short; record how many trials were run.
- R3: mechanism changes alter every state hash and therefore the TASK-018, TASK-026 and checkpoint regression values; must be
  re-recorded with the reason.
- R4: overfitting to tuning seeds 1 to 20; the held-out seeds 101 to 110 are the only acceptance evidence.
- R5: performance: an added per-attack factor is O(herbivores in cell) if counted naively; use the spatial index's cell
  bucket count. Checked by `scripts/perf.sh`.
- R6: plant cohort ageing (hypothesis) may be the limit after the animals are stable; it is to be checked, not fixed here
  unless it is a mechanism that is already local.

## Gaps
- `scenarios/demo.json` does not exist (CONTRACT section 7; `docs/STATE.md` G3). Owner is not clearly TASK-027; TASK-028
  (README) requires it. Not created in PLAN; recommended to the orchestrator for TASK-028 unless IMPLEMENT is asked to add it.
- The probe in PLAN used /tmp output and an unchanged build; the official baseline is still to be recorded in IMPLEMENT.
- Death-cause numbers for all 10 seeds are not yet recorded (only seed 1).
- Plants: whether founder cohort ageing is the cause of plant extinction is a hypothesis.

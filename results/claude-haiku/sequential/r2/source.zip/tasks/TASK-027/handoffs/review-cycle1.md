# TASK-027 REVIEW cycle 1 (ecosystem balance)

Verdict: **PASS**. Machine-readable handoff: `review-cycle1.json`.

## What was checked
- Acceptance criteria in `tasks/TASK-027/task.json` (eight points), each mapped to evidence below.
- Re-ran the official baseline (`./evosim batch`, example configuration, seeds 1 to 20, 10,000 ticks, `--sample-every 1`).
  The extinction table is identical to `docs/results/TASK-027/baseline-table.md`.
- Re-ran the held-out check (seeds 101 to 110 on the chosen defaults). Identical to `heldout-101-110-final-defaults.md`
  (median L 258.5, min 143, 0 of 10 all alive).
- Verified the T1a trial summary (herbivore extinction later in 12 of 20 seeds; carnivore extinction earlier in 11 of 20).
- Verified carnivore death causes from `baseline-causes.txt`: starvation in every seed (20 to 24 per seed), one old-age
  death in seeds 11 and 16, no predation deaths.
- Read the `hunting.rs` diff (`DILUTION = 0.0`, `dilution_factor`, `attack()` crowd count within the attacker's own cell).
  The rule reads only the attacker's cell, which the carnivore perceives; no global count is read; no organism is created.
- Gates: `cargo test --workspace --locked --offline` exit 0; `cargo clippy --workspace --all-targets --locked --offline`
  exit 0 with no warnings; `bash scripts/check_adrs.sh` exit 0 (197/0, before and after the edit); `./build.sh` and
  `./dist/evosim version` exit 0; `bash scripts/perf.sh` exit 0; `git remote -v | wc -l` = 0.

## Performance
`scripts/perf.sh` in this review: primary median 886.9 ticks/s (min 885.1, max 1,082.6), 2,173 living, state hash
`9fee0117...` (unchanged). The implement run recorded 1,084.9. Both are well above the 100 ticks/s target. The spread
between repetitions is machine noise; the code path and state hash are the same as the recorded run.

## Corrections made in this phase (docs only)
- `docs/BALANCE.md`: herbivore births are 0 to 31 per seed (was written as 0 to 40, twice). The carnivore death-cause
  statement now says starvation in all seeds except one old-age death in seeds 11 and 16 (was "20 of 20 in each seed").
- `docs/STATE.md`: the implement entry's "0 to 40" is corrected; a REVIEW cycle 1 record is appended.
- `docs/decisions/ADR-0028-ecosystem-balance.md`: status set to Accepted (its own status line requires this at REVIEW PASS);
  a correction notes that the PLAN-probe claim about herbivores dying first is wrong.

## Gaps (non-blocking; the task passes on its acceptance points)
- G-027-1: the coexistence goal is not reached (0 of 20 tuning and 0 of 10 held-out seeds). Stated openly in BALANCE.md.
- G-027-2: only one mechanism family (T1) was measured, with two trials, both not helpful, so the ADR-0028 stop rule applied.
  T2, T3, read-only counters and parameter trials were not run.
- G-027-3: "cause analysis written before the first change" is attested by the implement handoff, not by git (same commit).
- G-027-4: plant extinction (7 of 20 seeds) is unexplained; the cohort-ageing hypothesis is untested.
- G-027-5: `scenarios/demo.json` is missing; TASK-028 owns it per its task.md.

## Not done
- No commit (the runner commits the phase). `tasks/TASK-027/task.md` and `task.json` were not modified.

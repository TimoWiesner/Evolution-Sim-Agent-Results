# TASK-027 IMPLEMENT cycle 1 (ecosystem balance)

Status: implemented and gated; goal NOT reached (no seed keeps plants, herbivores and carnivores together to tick 10,000).
No commit by the agent. Machine-readable handoff: `implement-cycle1.json`. Full record: `docs/BALANCE.md`; ADR-0028 implementation record (Proposed).

- Baseline (before any change, `./evosim batch`, example configuration, seeds 1-20, 10,000 ticks): median L 337, min 157; 0 of 20 seeds with all kinds alive at the end.
- First extinction: carnivores in 18 of 20 seeds, by starvation (0-4 carnivore births). Herbivores in seeds 1 and 12, by predation (0-40 births). The PLAN claim "herbivores first in all seeds" was wrong.
- Trial T1 (crowding dilutes predation, `hunting::DILUTION`): 0.5 gives median L 312.5 (worse); 0.1 gives 337 (no change). Stop rule reached.
- Chosen default `DILUTION = 0.0`: mechanism present, behaviour identical; state hashes of seeds 1 and 2 at 1,000 ticks unchanged.
- Held-out seeds 101-110, chosen defaults: median L 258.5, min 143, 0 of 10 all alive.
- Not tried: T2 (handling time), T3 (mating diagnostic), parameter trials, the planned read-only counters.
- Gates (exit codes): cargo test --workspace 0; clippy 0 (no warnings); check_adrs 0 (197/0); build.sh 0; dist version 0; perf.sh 0 (median 1,084.9 ticks/s, target 100); git remote count 0.
- Tables: `docs/results/TASK-027/`. Scripts: `scripts/balance_table.py`, `scripts/balance_causes.py` (run with `python3 -I`).

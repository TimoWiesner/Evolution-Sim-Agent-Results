# TASK-028 PLAN cycle 1 (reliability and delivery)

Status: plan only. No product code, no scenario, no README, no commit. Machine-readable handoff: `plan-cycle1.json`.
Verdict: N/A (PLAN phase).

## Entry checks (this phase)
- `/workspace/AGENTS.md` and `/workspace/docs/STATE.md` exist. Read: AGENTS.md, docs/PROJECT.md, docs/CONTRACT.md,
  docs/STATE.md (headings, test commands, system deps, TASK-026/027 sections), docs/ARCHITECTURE.md (module map),
  tasks/TASK-028/task.md and task.json, handoffs of TASK-021, 022, 025, 027 (for the TASK-028 owner items), and
  `.agents/skills/plan/SKILL.md`.
- Owner items inherited by TASK-028 (from the handoffs, all grep-verified):
  - `scenarios/demo.json` missing (CONTRACT section 7; TASK-025 review, TASK-027 review gap G-027-5).
  - README does not describe `batch` (TASK-021 gap G-021-3; TASK-022 README checkpoint text is present).
  - README section "Not available yet" is out of date (it still lists batch, ui, presets, save/load as missing).
  - Coexistence goal of TASK-027 was NOT reached: median first extinction L = 337 (seeds 1 to 20, example config, 0 of 20
    with all three kinds alive at 10,000 ticks; held-out 101 to 110: median 258.5, 0 of 10).
  - Naming anomaly, to record in the self-audit (no history rewrite): commit 8966e78 is titled "TASK-026 review cycle 1 PASS"
    although the TASK-026 REVIEW cycle 1 verdict was FAIL.

## Environment facts verified in PLAN (exit codes from this phase)
| command | result |
|---|---|
| `cargo test --workspace --locked --offline` | exit 0, 22 s wall (cli 36 / batch 8 / checkpoint 2 / run 9; core 432 + 1 ignored; ui 95 + 1 ignored) |
| `./evosim run --config examples/config.json --ticks 10000 --seed 1 --out /tmp/...` | exit 0, 1.4 s (about 7,100 ticks/s); seed 1 at tick 10,000: 468 plants, 0 herbivores, 0 carnivores |
| `./evosim batch --config examples/config.json --seeds 1,2 --ticks 200 --out-dir DIR` | exit 0; layout `DIR/seed-1.json`, `DIR/seed-2.json`, `DIR/summary.json` (no `--vary`) |
| `./evosim ui --smoke-test --config examples/config.json` | exit 0, 0.9 s |
| `./evosim ui --screenshots DIR --config examples/config.json` (DIR existing) | exit 0, 5.9 s; writes `main.png` (1280x807) and `charts.png` |
| same with DIR not existing | exit 2 with message "screenshot directory ... does not exist" (matches CONTRACT: DIR must exist) |
| config `{"seed":1,"world":{...}}` without `initial` | exit 2, "initial.plants: missing required key" |
| config with `"seed":"x"` | exit 2, "seed: expected integer, found string" |
| config with `width: 0` | exit 2, "world.width: 0 is out of range 1..=4096" |
| `initial.plants = 0`, 5 herbivores, 300 ticks | exit 0; all kinds 0 at tick 300 (no replenishment, CONTRACT 5.3) |
| `./evosim run ... --ticks 0` | exit 0; `tick_end` 0 |
| `./evosim version` stdout | exactly `{"name": "evosim", "version": "0.1.0", "contract": 1}` plus newline |
| `chromium` | `/usr/local/bin/chromium`, used by smoke and screenshots; no apt package needed in PLAN |
No system packages were installed in PLAN. No apt command is required for TASK-028 so far.

## Findings that shape the plan
1. The configuration error handling and the screenshot contract already behave as CONTRACT section 5.4 and 2 require.
   IMPLEMENT must still prove each case with a recorded command (not assume it).
2. A 10,000-tick run of the example configuration takes about 1.5 s in release. Three seeds of two configurations, and a
   multi-seed scenario search, are cheap. The time budget is not the constraint; the number of candidates is a choice.
3. `cargo test` in debug takes 22 s wall now. Randomised invariant tests must fit into roughly 60 s in debug, or they run
   with a size set by an environment variable (see decision D3).
4. The example configuration is fixed (CONTRACT section 3). The demo scenario may use any non-fixed key that ADR-0006
   defines (ecology parameters), so the demo can differ from the example without changing the example's measured result.

## Decisions (what IMPLEMENT should do)
D1. **Evidence record.** Create `docs/VERIFICATION.md`. It holds: (a) the CONTRACT command matrix (section 2 and section 5
    items 1 to 5, section 6, section 7) with the exact command, exit code and the test or script that proves it; (b) the
    long-run results (10,000 ticks, at least three seeds, demo and example configuration); (c) the self-audit (D6);
    (d) known limitations. Raw run outputs go to `docs/results/TASK-028/` (JSON batch outputs and summary tables, one
    script per table). No new ADR is planned; the choices above are recorded in VERIFICATION.md. If IMPLEMENT changes a
    product rule (it should not, see D7), it must write an ADR first.

D2. **Demo scenario `scenarios/demo.json`.** Parameter-only search, no new mechanism (task "Not part of this task").
    - Candidates (at most six, fixed in advance and written into VERIFICATION.md before the first run): the example
      configuration as is; 128x96 with the same populations; 128x96 with 2,200/250/50 (the perf configuration, which
      coexists at least 100 ticks only, so this is a probe); 96x64 with 800/120/20; and two non-fixed ecology settings
      from ADR-0006 that act on plant regrowth or feeding (chosen from the parameter list in ADR-0006 at IMPLEMENT time).
    - Measure: per seed, the first tick with zero living individuals of a kind, using `batch --sample-every 1 --ticks 10000`
      on tuning seeds 1 to 10. Score = median of `L` (the same measure as BALANCE.md). Tie-break: seeds with all three
      kinds alive at 10,000.
    - Choose the best candidate. Run it once on held-out seeds 101 to 110. Record all candidates, even the failed ones.
    - Stop rule: after six candidates, or when a candidate has all three kinds alive at 10,000 in at least 5 of 10 tuning
      seeds (then stop and verify on held-out seeds).
    - No forced anti-extinction: no rule may read global or per-species counts, and no seed-specific setting may be used.
      The demo file contains only configuration keys. Code is not changed.
    - Result is stated in README as measured, whether or not all three kinds coexist.

D3. **Randomised invariant tests.** No third-party crate (none in Cargo.lock; no network needed by the build). Add
    `crates/evosim-core/src/invariant_tests.rs` (`#[cfg(test)]`, same pattern as `food_chain_tests.rs`), driven by
    `rng::Rng` with a fixed master seed. It generates N random configurations (grid 1..=64 by 1..=48, initial counts
    0..=300, seed random, 50 to 300 ticks) and checks, after every tick:
    - birth/death accounting: `initial + births - deaths = living` per kind, and the species counts are consistent;
    - value ranges: every trait within its declared range, energies and health non-negative, plant resources in range;
    - wrapping: every position is inside the torus after a move; `within()` equals a brute-force torus search for random
      centres across the seam (for example at x = 0 and x = width - 1);
    - determinism: two runs with the same configuration give equal `state_hash`; a checkpoint split run equals the
      uninterrupted run (`A + B` ticks);
    - the number of cases comes from `EVOSIM_INVARIANT_CASES` (default 24 in the debug test run, the figure IMPLEMENT
      measures to fit about 60 s). `scripts/test.sh` runs a larger count (for example 200) in release mode with
      `cargo test --release -p evosim-core invariant`. The release run is part of the one command, so the full count is
      always executed.
    IMPLEMENT must read the existing `sim.rs` tests and `check_balance`/`check_invariants` first; the new tests add
    random coverage, they do not replace them.

D4. **Long runs (acceptance: at least 10,000 ticks, at least three seeds, no errors).**
    - `./evosim batch --config scenarios/demo.json --seeds 1,2,3 --ticks 10000 --sample-every 1 --out-dir docs/results/TASK-028/demo` and
      the same for `examples/config.json` (the example configuration of CONTRACT section 3). Five seeds are preferred
      if the time allows (each run is about 1.5 s); three is the minimum.
    - Each run must exit 0, have `tick_end` 10,000, satisfy `initial + births - deaths = final` for each kind, and print
      the coexistence length `L` per seed.
    - These checks run in `scripts/test.sh` as a step that re-runs three seeds of each configuration to 10,000 ticks (about
      10 s), so the claim stays checkable.

D5. **Delivery, README, one test command.**
    - README: installation (`./setup.sh`; the toolchain search order; no apt package; chromium is needed only for
      `ui --smoke-test` and `--screenshots`), the `run`, `batch` (with `--vary`, `--csv`, `--jobs`, layout and
      summary) and `ui` commands with examples, the configuration parameters (keys, types, ranges and defaults, copied from
      ADR-0006 and checked against `config.rs`), the one demo command `./evosim ui --config scenarios/demo.json`, and the
      measured coexistence for the demo and the example configuration (table with seeds and L). Remove the out-of-date
      "Not available yet" section and replace it with the known limitations.
    - `scripts/test.sh` is the one documented test command. Add steps: screenshots (exit 0; `main.png` is PNG with
      width at least 1280 and height at least 720, read with `python3 -I` and struct), smoke test (exit 0), the release invariant
      run (D3), the long-run step (D4), the demo file loading through `run` and `ui --smoke-test --config scenarios/demo.json`,
      and the fresh-state step (`rm -rf target dist` then `./setup.sh`) only if its time fits; otherwise it is a recorded
      command outside the script. `scripts/check_adrs.sh` keeps running as now.
    - `dist/`: `build.sh` copies only the binary. Evidence for "self-contained": `ldd` (already in test.sh), and a copy of
      `dist/evosim` to an empty directory outside the workspace, run with `env -i PATH=/usr/bin:/bin` for `version`,
      `run` (with the example configuration copied to that directory), and `--help`. A plain Ubuntu system cannot be
      created here; record that limit.

D6. **Self-audit.** In `docs/VERIFICATION.md`, one row per requirement in `docs/PROJECT.md` (the nine Required behavior bullets,
    plus "Extinction and stabilising mechanisms" and the four agent-owned architecture decisions). Each row: met, partly met or missing,
    with the evidence (test name, command or document). Items IMPLEMENT must check and not assume:
    - population target 1,000 to 5,000 and >= 100 ticks/s at 2,000 (PERFORMANCE.md, 1,000+ ticks/s measured);
    - "no forced anti-extinction": grep the simulation code for uses of `living_count` and of per-kind totals inside rules
      (only reporting may use them); record the grep;
    - import/export of configuration: JSON only is enough (at least one); state it;
    - UI: edit initial parameters, presets, seed control, save/load (README says TASK-024 for UI save/load: check
      `crates/evosim-ui` and mark as met or missing), inspector, charts for population, births/deaths, diversity, genetic
      distributions and means, generation trends (TASK-025 charts: check which of these exist);
    - property-based tests: partly met unless D3 is written (hand-rolled randomised tests, not a property-testing library);
    - the TASK-026 commit-title anomaly and the TASK-027 non-reached coexistence goal, stated openly.
    Known limitations are stated in the same document and in README.

D7. **Scope discipline.** No new features and no rule changes. If a check fails (for example a command, a README item or
    a contract behaviour), fix the smallest thing and record it. If the fix would change simulation behaviour, do not make
    it: record it as a known limitation and tell the orchestrator in the handoff. The ecology stays as TASK-027 left it
    (`hunting::DILUTION = 0.0`).

## Ordered plan for IMPLEMENT
1. Record the baseline: `scripts/test.sh` run once (time it, exit code) and the list of CONTRACT items with the current
   command results (table in VERIFICATION.md, status "to verify").
2. Fix the README (D5) first, since it is independent of the code.
3. Write `invariant_tests.rs` (D3); measure debug time; add the release step.
4. Scenario search (D2): write the candidate list into VERIFICATION.md first; run tuning seeds 1 to 10; choose; run held-out
   seeds 101 to 110 once; write `scenarios/demo.json`.
5. Long runs (D4) for the demo and the example configuration; save outputs under `docs/results/TASK-028/`.
6. Dist self-containment (D5) and the fresh-state check (`rm -rf target dist && ./setup.sh`, then `./evosim version`).
7. Self-audit (D6) and known limitations; update `docs/STATE.md` with the IMPLEMENT entry; `docs/ARCHITECTURE.md` gets the
   invariant test module and the scenario in the layout.
8. Gates: `scripts/test.sh` exit 0 (record the time), `cargo clippy --workspace --all-targets --locked --offline`,
   `bash scripts/check_adrs.sh`, `./build.sh`, `git remote -v | wc -l` = 0.

## Tests planned for REVIEW (what REVIEW must re-run)
- `./scripts/test.sh` (exit 0, "ALL TESTS PASSED"); `cargo clippy` exit 0; `scripts/check_adrs.sh` exit 0.
- Every CONTRACT row in VERIFICATION.md re-run by hand from the recorded command (sample of at least five, including one
  checkpoint split and one screenshot).
- The 10,000-tick demo and example batches re-run for seeds 1 to 3 with the same state hashes as recorded.
- `dist/evosim` run from an empty directory outside the workspace.

## Risks
- R1: the demo search may find no candidate with all three kinds alive to 10,000 ticks. This is allowed by the task (the
  coexistence length is stated, not required). The risk is the time spent; the stop rule in D2 limits it.
- R2: the debug test time may exceed the budget for D3. Mitigation: the case count is an environment variable, the release
  run covers the full count.
- R3: the fresh-state check (`rm -rf target dist`) rebuilds Rust from the locked lockfile; it needs the toolchain at
  `/opt/rust/cargo/bin` (present). It may take several minutes; it can be run once and recorded outside the script.
- R4: "self-contained" cannot be tested on a plain Ubuntu system in this container; the limit is recorded.
- R5: the naming anomaly in history (8966e78) is not corrected (no history rewrite).
- R6: the README coexistence figures must be the figures of the final scenario file; any later edit of the scenario
  invalidates them, so IMPLEMENT writes them last.

## Gaps (open at the end of PLAN)
- G-028-1: no measurement of any candidate scenario yet (search is an IMPLEMENT step).
- G-028-2: `scripts/test.sh` run time unknown (not timed in PLAN; `cargo test` alone is 22 s).
- G-028-3: whether UI save/load, charts for diversity and genetic distributions exist is not verified in PLAN (D6 item).
- G-028-4: the four open non-blocking items of earlier phases (TASK-021 G-021-3 batch README, TASK-025 scenario, TASK-027
  G-027-5 scenario, TASK-022 README checkpoint text) are owned here; their closure is part of the IMPLEMENT entry.

## Changed files (this phase)
- `tasks/TASK-028/handoffs/plan-cycle1.md` (this file)
- `tasks/TASK-028/handoffs/plan-cycle1.json`
- `docs/STATE.md` (PLAN entry appended)
- Nothing else. `tasks/TASK-028/task.md` and `task.json` untouched.

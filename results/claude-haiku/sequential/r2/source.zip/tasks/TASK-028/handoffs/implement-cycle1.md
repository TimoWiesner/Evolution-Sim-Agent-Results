# TASK-028 IMPLEMENT cycle 1 (reliability and delivery)

Status: implemented and gated. REVIEW not run. Verdict N/A. No commit by the agent. Machine-readable handoff: `implement-cycle1.json`.
Evidence and self-audit: `docs/VERIFICATION.md`. Raw outputs: `docs/results/TASK-028/`.

## What was done (against the Must-have list of task.md)
1. Every CONTRACT command and behaviour verified and recorded (`docs/VERIFICATION.md` section 2; hand checks in
   `docs/results/TASK-028/contract-checks/contract-checks.txt`).
2. `./build.sh` self-contained: `dist/evosim` run from an empty directory outside the workspace with `env -i` (`version`, `run`,
   `--help` exit 0); `ldd` allows only glibc, libm, libgcc_s and the loader. Not tested on a plain Ubuntu system.
3. Runs of 10,000 ticks, seeds 1 to 5, demo and example, no errors (`docs/results/TASK-028/long-demo`, `long-example`).
4. Randomised invariant tests: `crates/evosim-core/src/invariant_tests.rs` (4 tests; debug 24 cases, release 200 cases).
5. Full suite with one documented command: `./scripts/test.sh`, exit 0, `ALL TESTS PASSED`, 1 min 07 s
   (`docs/results/TASK-028/test-run.log`).
6. `README.md` rewritten: install, `run`, `batch`, `ui`, configuration table, the demo command, the measured coexistence,
   tests and limitations.
7. Demo and example coexistence measured and stated in README and VERIFICATION.
8. Self-audit of `docs/PROJECT.md` (25 rows: 20 met, 5 partly, 0 missing) and the known limitations, in VERIFICATION section 7 and 8.

## Demo scenario (`scenarios/demo.json`)
- Procedure: six candidates measured on tuning seeds 1 to 10 (10,000 ticks), score = median coexistence length L; the chosen
  candidate was run once on held-out seeds 101 to 110.
- Medians (tuning): example 260.0; 128x96 208.5; growth_rate 0.3 (no-op key, identical to example) 260.0; reproduction
  energies 40/60 295.5; plant reproduction 0.2 and radius 4 **352.5 (chosen)**; 128x96 combined 267.5.
- Held-out (chosen): median 271.5, min 103, 0 of 10 all alive. Example on held-out seeds (TASK-027): 258.5. The difference is
  within the seed spread; the demo is not clearly better.
- Stop rule (5 of 10 seeds with all three kinds alive) never reached.
- One candidate (128x96 with growth 0.3) was killed by an agent error (a `pkill` pattern matched my own command) and not measured.

## Long runs (10,000 ticks, `--sample-every 1`)
| config | seeds | median L | min L | all three alive at end |
|---|---|---|---|---|
| demo | 1 to 5 | 230 | 178 | 0 of 5 |
| example | 1 to 5 | 258 | 157 | 0 of 5 |

Determinism: demo seed 1 re-run gives the same `state_hash` as the recorded batch file.

## Changes to code
- `crates/evosim-core/src/invariant_tests.rs` (new, `#[cfg(test)]`), one module registration in `crates/evosim-core/src/lib.rs`.
- No simulation rule, default, or CLI/UI behaviour was changed.

## Changes to scripts and docs
- `scripts/test.sh`: steps 10 (six long runs with accounting check, demo through `run`), 11 (UI smoke and screenshots on the
  demo and example, PNG size check), 12 (release invariants, 200 cases).
- `README.md` rewritten; the out-of-date "Not available yet" section removed.
- `docs/VERIFICATION.md` (new), `docs/ARCHITECTURE.md` and `docs/STATE.md` (TASK-028 IMPLEMENT entries).
- `scenarios/demo.json` (new), `docs/results/TASK-028/` (new, about 14 MB).

## Gates run in this phase (exit codes)
| command | exit |
|---|---|
| `bash scripts/test.sh` | 0 (1 min 07 s) |
| `cargo clippy --workspace --all-targets --locked --offline` | 0, 0 warnings |
| `bash scripts/check_adrs.sh` | 0 (checks=197 failed=0) |
| `./build.sh` | 0 (inside test.sh; also run before the dist check) |
| `git remote -v \| wc -l` | 0 |

## Deviations and decisions
- No new ADR: no product rule changed. Decisions are recorded in `docs/VERIFICATION.md`.
- The randomised tests use the library's generator and a fixed master seed; no third-party crate.
- The known-no-effect keys (`plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism`) are documented, not wired:
  wiring them changes the configuration surface and needs a decision (REVIEW or a later task).

## Blockers and gaps (open)
- The coexistence goal is not reached (see above). It is stated as measured, as the task allows.
- Self-audit partly met: no generation-trend chart; batch results have CSV and summary only; 5,000-entity ticks/s not measured; no clean-Ubuntu test of `dist/`.
- Commit `8966e78` titled "TASK-026 review cycle 1 PASS" although that verdict was FAIL: recorded, not rewritten.

## Next steps (for REVIEW)
1. Re-run `bash scripts/test.sh` and compare the long-run tables with `docs/results/TASK-028`.
2. Check the self-audit rows in `docs/VERIFICATION.md` section 7 against the code.
3. Decide whether to wire or remove the three no-effect keys.
4. Coexistence work (handling time after a kill, carnivore reproduction) would be a new task with an ADR; not part of TASK-028.

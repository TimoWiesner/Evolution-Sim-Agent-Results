# TASK-028 REVIEW cycle 1 (reliability and delivery)

Verdict: **PASS**. Machine-readable handoff: `review-cycle1.json`. No commit made by the agent.

## Scope of the review
Read: AGENTS.md, docs/PROJECT.md, docs/CONTRACT.md, docs/ARCHITECTURE.md (module map), docs/STATE.md (tail and TASK-028 entries),
tasks/TASK-028/task.md and task.json, plan-cycle1 and implement-cycle1 handoffs, docs/VERIFICATION.md, README.md,
scripts/test.sh, scenarios/demo.json, crates/evosim-core/src/invariant_tests.rs, and `.agents/skills/review/SKILL.md`.

## Independent checks (this phase)
| check | command | result |
|---|---|---|
| full suite, one documented command | `bash scripts/test.sh` | exit 0, `ALL TESTS PASSED` |
| fresh-state build | `rm -rf target dist && ./setup.sh && ./evosim version && ./build.sh` | all exit 0; version JSON exact |
| long-run reproduction, demo | `./evosim run --config scenarios/demo.json --ticks 10000 --seed 2` | exit 0; `state_hash`, `final`, `totals` equal to `docs/results/TASK-028/long-demo/seed-2.json` |
| long-run reproduction, example | `./evosim run --config examples/config.json --ticks 10000 --seed 2` | exit 0; equal to `long-example/seed-2.json` |
| UI without options | `./evosim ui --port 8099 --config examples/config.json` | prints `http://127.0.0.1:8099/`; HTTP 200; stopped by PID |
| no count-based rules | grep of `living_count`, `initial(` in rule modules, cut at `#[cfg(test)]` | only reporting, accounting and tests |
| L ranges in VERIFICATION section 8 | min/max of `L` in `docs/results/TASK-028/*.md` | tuning 94 to 413, matches |
| no remotes | `git remote -v \| wc -l` | 0 |

## Acceptance criteria
- CONTRACT commands and behaviour verified with recorded evidence: met (VERIFICATION section 2; the `ui` row was re-checked here).
- `./build.sh` self-contained: met in the container (empty directory, `env -i`, `ldd` allow-list). Not tested on a plain Ubuntu machine: recorded as a limitation.
- At least 10,000 ticks for at least three seeds without errors: met (5 seeds, both configurations; accounting checked).
- Randomised invariant tests over many seeds and configurations (accounting, value ranges, wrapping, determinism): met
  (`invariant_tests.rs`: 24 debug and 200 release random configurations; the checks are real assertions, not smoke runs).
- One documented test command passes: met.
- README covers installation, `run`, `batch`, `ui`, configuration parameters and the demo command: met.
- Demo and example coexistence measured at 10,000 ticks with at least three seeds and stated in README: met (0 of 5 keep all three kinds).
- Self-audit lists every PROJECT.md requirement with met, partly or missing, and limitations: met (25 rows; 20 met, 5 partly, 0 missing).

The goal "coexistence as long as possible" is not reached. TASK-028 does not require a particular result (task.md, out of scope), so this does not fail the task. It is stated openly in README and VERIFICATION.

## Findings (non-blocking)
1. The demo's advantage over the example is within seed spread (held-out 271.5 vs 258.5). README says so. No change needed.
2. Three config keys are accepted but have no effect (`plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism`). Documented in README and VERIFICATION. A user could be misled; wiring or removing them needs a decision (outside this task).
3. Self-audit "partly" rows are honest. The generation-trend chart is missing; the 5,000-entity ticks/s measurement is missing.
4. Commit `8966e78` is titled "TASK-026 review cycle 1 PASS" while that verdict was FAIL. History not rewritten; recorded.
5. Implement-phase tooling note: a shell `pkill -f` pattern matched its own command (exit 144). Process cleanup should use PIDs.

## Changed files in this phase
- `docs/STATE.md` (REVIEW entry appended)
- `tasks/TASK-028/handoffs/review-cycle1.md` and `.json` (this review)
- Build outputs regenerated (`target/`, `dist/`; git-ignored). No source, scenario, README, task file or benchmark file changed.

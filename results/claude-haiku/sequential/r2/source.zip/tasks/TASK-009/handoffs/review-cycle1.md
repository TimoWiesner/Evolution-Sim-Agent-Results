# TASK-009 REVIEW cycle 1: verdict PASS

Fresh-process review of the IMPLEMENT commit `93d6822`. No product code, task file, ADR text or benchmark file was changed.

## Acceptance criteria against evidence

| Criterion | Evidence |
|---|---|
| Every organism has a genome; traits deterministic from genome and in range | `Organism` and `Birth` carry a private `genome` (entities.rs). `decode_traits` is pure. `spawn_founder` and `spawn_child` reject traits or tendencies that differ from the decode (`traits_must_match_the_genome_at_spawn`). `check_invariants` re-decodes (`check_invariants_detects_traits_that_drift_from_the_genome`). 10,000 random genomes stay in range (`decoded_traits_stay_in_range_for_random_genomes`). |
| Child from one parent (copy) and two parents (crossover) | `copy_child`, `crossover_child` (genome.rs). Tests: `copy_with_rate_zero_is_the_parent_and_draws_nothing`, `crossover_with_rate_zero_takes_only_parental_material`, `crossover_rejects_haploid_parents`. |
| Mutation with configurable rate and strength, from the simulation generator | `Mutation::new` validates rate in [0,1] (NaN rejected) and strength in [1,255]. `mutate` takes `&mut Rng`. `sim::mutation_settings` reads `config.genetics`. Tests: `mutation_settings_are_validated`, `mutation_settings_come_from_the_config_genetics_section`, `mutation_is_deterministic_for_the_same_generator_seed`. |
| Rate 0: only parental material; rate > 0: differences over many offspring | `copy_with_rate_zero...` (identity, no RNG draw). `crossover_with_rate_zero...` (every child haplotype is a splice of a parent haplotype pair). `mutation_with_positive_rate_creates_small_differences_over_many_offspring` (about 2,560 expected changes; band 1,500 to 3,500; steps within strength). `mutation_clamps_at_the_bounds_and_never_wraps`. |
| Genetic distance: zero on identity, symmetric, larger for more different | `genetic_distance_is_zero_for_identical_symmetric_and_bounded` (1,000 pairs), `genetic_distance_grows_with_difference`, `genetic_distance_rejects_mismatched_genomes`. |

## Commands (exit codes)

- `cargo test -p evosim-core --locked` -> 0 (178 passed)
- `cargo test --workspace --locked` -> 0 (core 178, cli 16)
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` -> 0, no warnings
- `rustfmt --edition 2021 --check` on genome.rs, entities.rs, sim.rs -> 0
- `bash scripts/check_adrs.sh` -> 0 (checks=98 failed=0)
- `bash scripts/test.sh` -> 0 (ALL TESTS PASSED)
- `git remote -v | wc -l` -> 0

## Non-blocking gaps (new in this review)

- **G-042 (cosmetic):** `entities.rs` near line 436. The doc line `/// None while the organism is alive.` sits above `genome()`, and `cause()` lost its doc comment. Fix: move the line to `cause()` and give `genome()` its own doc.
- **G-043 (low):** `Simulation::populate_initial` checks only `tick == 0`. A second call doubles the founders, and `initial.*` then no longer equals the configured counts. Suggested guard: refuse unless `entities` is empty.
- **G-044 (low):** no direct test of `crossover_child` or `copy_child` with a positive rate. The mutation itself is covered through `mutate` and `copy_child`.
- **Style (not logged as a gap):** `sim.rs` places `mutation_settings` between the `use` lines. rustfmt passes, so this is cosmetic.

## Open items carried forward

- G-037: `populate_initial` is not called by `Simulation::new` or the CLI. Accepted for TASK-009; wiring belongs to TASK-019.
- R1 (lifespan calibration), R2 (256 draws per animal child; check at TASK-010), R4 (cached traits), R5 (distance scale; TASK-017).

# TASK-009 IMPLEMENT cycle 1

Genome, inheritance and mutation, implemented per `tasks/TASK-009/handoffs/plan-cycle1.md`.
Decisions and deviations are in ADR-0004 and ADR-0011 (Implementation notes / Amendment).
Gaps: populate_initial is not wired into `evosim run` (TASK-019); property tests are seeded loops (no proptest);
max_lifespan calibration deferred (R1 in the plan).

# TASK-009 PLAN cycle 1: genome, inheritance and mutation

Scope: plan only. No product code, test, Cargo file or task file was changed. ADR text changes listed below are for
IMPLEMENT (the ADR-0004 and ADR-0011 wording must match the code it describes, and IMPLEMENT is where that is checked).

## 1. State found on entry (verified in this phase)

- `AGENTS.md`, `docs/STATE.md`, `docs/PROJECT.md`, `docs/CONTRACT.md`, `docs/ARCHITECTURE.md`, `tasks/TASK-009/task.md|json` exist and were read.
- Baseline: `cargo test -p evosim-core --locked` -> `155 passed; 0 failed`, exit 0 (PATH includes `/opt/rust/cargo/bin`).
- `git remote -v | wc -l` -> 0.
- `crates/evosim-core/src/genome.rs` does NOT exist yet. `lib.rs` has no `pub mod genome`. `ARCHITECTURE` lists `core::genome` as planned.
- `entities.rs` (TASK-008): `Birth { kind, cell, traits, tendencies, energy, health }`; `spawn_founder`, `spawn_child(birth, parents)`;
  trait ranges are constants (`SPEED_RANGE` ... `TENDENCY_RANGE`, f64 pairs); `Traits::new`, `Tendencies::new` validate.
- `rng.rs`: `Rng::next_u64`, `next_below(n)` (unbiased), `next_f64`, `chance(p)`. Only randomness source.
- `config.rs`: `genetics.mutation_rate: f64` (default in [0,1]) and `genetics.mutation_strength: u64` in `[1,255]`; `initial.{plants,herbivores,carnivores}: u64`.
- `sim.rs`: `Simulation::rng_mut()` gives the simulation generator; `add_founder` allowed at tick 0 only; `Simulation::new` does not place founders.
- Gaps inherited: G-037 (founders not placed from `config.initial`), G-039 (trait ranges to be confirmed or changed by TASK-009),
  G-009 (ADR-0004 crossover wording, non-blocking), G-040 / G-041 (non-blocking, not this task).

## 2. Decisions (chosen; reasons in brackets)

### D1 Genome representation (ADR-0004 kept, with the amendments in section 4)
- `pub struct Genome { ploidy: u8, loci: Vec<u8> }`, length `ploidy * LOCI_PER_HAPLOTYPE`, `LOCI_PER_HAPLOTYPE = 128`.
  Plants ploidy 1, animals ploidy 2. Validated by `Genome::new(ploidy, loci) -> Result<Genome, GenomeError>`.
- Locus value `u8`; a locus is one byte, so mutation steps are integer and exact.

### D2 Gene-to-trait mapping (a fixed table, one block per trait)
- The haplotype is split into 8 slots of `LOCI_PER_SLOT = 16` loci (`TRAIT_SLOTS = 8`). Slot `s` covers loci `16*s .. 16*s+16` of every haplotype.
- Slot table (ADR-0011 names and ranges, unchanged):

| Slot | Trait | Range (ADR-0011) | Kinds |
|---|---|---|---|
| 0 | speed | [0, 4] | all |
| 1 | strength | [0, 10] | all |
| 2 | fertility | [0, 1] | all |
| 3 | max_lifespan | [1, 10000], integer (floor) | all |
| 4 | max_health | [1, 100] | all |
| 5 | aggression | [0, 1] | animals only |
| 6 | caution | [0, 1] | animals only |
| 7 | reserved | none | none (kept so the block layout is fixed; plant-only traits later) |

- Trait value: `m = (sum of the slot's loci over all haplotypes) / (count * 255)` with `count = ploidy * 16` (exact integer sum, then one f64 division, fixed order);
  `value = min + (max - min) * m`; for `max_lifespan` the value is `floor`, then clamped to `[1, 10000]`. Every value lies in its closed range by construction; decode still clamps as a guard.
- Split for acyclic modules (see R8): `genome::trait_means(&Genome) -> [f64; 8]` (block means, fixed order) lives in `genome.rs`; `entities::decode_traits(genome: &Genome, kind: Kind) -> Result<(Traits, Option<Tendencies>), EntityError>` maps means to the ranges and builds the validated values. Deterministic: a pure function of the genome. Plants never get tendencies.
- Reason: the mean over a block is additive, so one-locus changes change a trait by at most `range / (count*255)`; the 8-slot layout gives room for the ADR-0011 trait list without shifting loci later.

### D3 Founders
- `pub fn random_genome(ploidy, rng: &mut Rng) -> Genome` draws each locus with `rng.next_below(256)`. Founders with a random genome are the only place this task draws for a population.
- `Birth::from_genome(kind, cell, genome, energy, health) -> Result<Birth, EntityError>` computes `traits` and `tendencies` with `entities::decode_traits`. Keeps `Birth.traits` and `tendencies` as fields so TASK-008 tests keep their meaning.
- `Simulation::populate_initial(&mut self, config: &Config) -> Result<(), SimError>` (new, explicit, tick 0 only): places `initial.plants/herbivores/carnivores` founders at cells drawn from the simulation RNG (`next_below(W)`, `next_below(H)`), with random genomes from the same RNG, in kind order plants -> herbivores -> carnivores. **Not** called from `Simulation::new`: changing `new` would move the RNG stream and break the existing `new`-based tests (e.g. `sim.rs` test at line ~335 asserting the RNG state after `new`). The CLI `run` wiring (TASK-019) calls it. This closes G-037 at the API level; the production call is recorded as a deferred item (see section 7).

### D4 Copy (one parent, plants)
- `pub fn copy_child(parent: &Genome, mutation: Mutation, rng: &mut Rng) -> Genome`: `child.loci = parent.loci` (same ploidy), then `mutate`.

### D5 Meiosis and crossover (two parents, animals)
- `pub fn crossover_child(mother: &Genome, father: &Genome, mutation: Mutation, rng: &mut Rng) -> Result<Genome, GenomeError>`. Both parents must have ploidy 2 and equal length.
- For each parent: a gamete from its two haplotypes A (first 128 loci) and B (next 128). Draw order fixed:
  1. one crossover point `c = 1 + next_below(127)` (uniform in `1..=127`, so both segments are non-empty),
  2. one coin `first = next_below(2)` choosing which haplotype supplies the first segment (`0..c`); the other supplies `c..128`.
  Gamete = `[first_hap[0..c], second_hap[c..128]]`. This keeps both haplotypes equally likely as the start.
- Child = gamete(mother) ++ gamete(father) (length 256, ploidy 2), then `mutate`.
- The old ADR-0004 text "locus `c` in both `0..c` and `c..L`" (G-009) is fixed: segments are `0..c` and `c..L`, disjoint.

### D6 Mutation (configurable rate and strength, simulation RNG)
- `pub struct Mutation { pub rate: f64, pub strength: u8 }` built from `config.genetics` (`rate` in [0,1], `strength` in [1,255]; validated).
- `pub fn mutate(loci: &mut [u8], m: Mutation, rng: &mut Rng)`: if `rate == 0` return immediately (no RNG draw, so the stream is unchanged). Otherwise for each locus in index order: `if rng.chance(rate)` then draw `step = 1 + next_below(strength)` and `sign = next_below(2)`; `v = v + step` or `v - step`, clamped to `[0, 255]` (G-004: clamp, not wrap).
- Per-locus `chance` is O(L) draws per child (256 for animals). Accepted for this task; a geometric skip is noted as a later optimisation if the 100 ticks/s check fails (TASK-010).

### D7 Genetic distance
- `pub fn genetic_distance(a: &Genome, b: &Genome) -> Result<f64, GenomeError>`: error if ploidy or length differ. `sum = Σ |a_i - b_i|` as `u64`; `d = sum as f64 / (len as f64 * 255.0)`.
- Properties: `d(a,a) = 0`; symmetric (integer sum, identical operations); range `[0, 1]`; strictly larger when one locus is moved further from its partner (monotone in the sum).

### D8 Entities integration (ADR-0011 update in IMPLEMENT)
- `Organism` and `Birth` gain `genome: Genome`. `Entities::spawn_founder` / `spawn_child` validate that `birth.traits` and `birth.tendencies` equal `decode_traits(&birth.genome, birth.kind)`, and that the genome ploidy matches the kind (1 plant, 2 animal). New `EntityError::GenomeMismatch` and `EntityError::PloidyMismatch`. Checked before any state change.
- `check_invariants` also re-decodes every stored genome and compares with the stored traits (cheap; guards against a stale cache).
- Checkpoint (TASK-022) must now also save each `genome` (ploidy + loci). Recorded in ADR-0011 Consequences.

## 3. Ordered IMPLEMENT plan (cycle 1)

1. Create `crates/evosim-core/src/genome.rs` with: constants, `GenomeError`, `Genome`, `random_genome`, slot table and `decode_traits`, `Mutation` (+ `new` validation), `mutate`, `copy_child`, `crossover_child`, `genetic_distance`. Add `pub mod genome;` to `lib.rs`.
2. Unit tests in `genome.rs` (section 5).
3. Edit `entities.rs`: `genome` field on `Organism` and `Birth`, `Birth::from_genome`, the new checks in `validate_birth`/`spawn_*`, `check_invariants` re-decode, getter `genome()`. Update the TASK-008 test helpers that build `Birth` (add a genome; use `Birth::from_genome` where convenient).
4. `sim.rs`: `Simulation::populate_initial(&Config)` (tick 0 only, `SimError` variant for later ticks already exists as `FounderAfterStart`), using `rng_mut()`. Test: counts equal `config.initial` after populate; `initial` counts match; the function is deterministic per seed; calling it at tick > 0 errors.
5. Config: validate `genetics` into `Mutation` (helper `Config::mutation()` or a `From`), no new keys.
6. Docs: amend ADR-0004 (section 4), amend ADR-0011 (section 4), update `docs/ARCHITECTURE.md` (genome row: "May depend on rng, std"; entities row: "genome field added by TASK-009" is already there), update `docs/STATE.md`.
7. `scripts/check_adrs.sh`: add ADR-0004 and ADR-0011 wording checks only if the script already has a pattern for them (do not invent new checks in IMPLEMENT beyond what is needed).
8. Run the commands in section 6 and record exit codes in `implement-cycle1.json`.

## 4. ADR wording changes (IMPLEMENT applies these)

ADR-0004 (Accepted; amended by TASK-009, keep status Accepted, add "Amended in TASK-009 IMPLEMENT"):
- Traits: replace the trait list with the table in D2 (names and ranges as ADR-0011; `risk` becomes `caution`, `health` becomes `max_health`, `lifespan` becomes `max_lifespan`). Plant-only traits (growth, seed dispersal, niche) are deferred: niche belongs to species work (TASK-017), the others to plant tasks; the reserved slot 7 keeps the layout.
- Mapping formula: the block mean over all haplotypes, as in D2 (replaces "mean(loci_of_trait)" wording).
- Sexual inheritance: use the D5 wording (one crossover point `c` in `1..=127`, a coin picks the first haplotype, segments `0..c` and `c..128`).
- Mutation: `rate == 0` draws nothing; the step is `1 + next_below(strength)` with a sign; clamped to `[0,255]`.
- Distance: integer sum formula of D7.
- Species persistence wording unchanged (already "counted in checks").

ADR-0011 (Accepted; amended by TASK-009):
- Organism and Birth gain `genome`; traits are derived from it (`Birth::from_genome`); the consistency checks of D8.
- G-039 resolved: the trait ranges of the table are confirmed unchanged; the genome maps into them.
- Checkpoint list gains `genome` (ploidy and loci).

## 5. Tests (IMPLEMENT must add these; each maps to a must-have)

| Must-have | Test |
|---|---|
| Genome per organism; traits from genome, in range | `decode` all-0 gives exact minima, all-255 gives exact maxima (animals and plants); 10,000 seeded random genomes stay in range; decode is equal for equal genomes; plant has no tendencies; `Entities::spawn_*` rejects traits that do not match the genome; `check_invariants` detects a mismatch. |
| Copy from one parent | `copy_child` with rate 0 equals the parent loci exactly. |
| Crossover from two parents | With rate 0: every child locus equals the mother's or father's gamete locus at that index; each child haplotype half comes from one haplotype of its parent; over 1,000 children both segments occur, and the crossover point is never 0 or 128. Distinct-haplotype parents give gametes that differ from each whole haplotype. |
| Mutation rate 0 -> only parental material | Over 1,000 offspring with rate 0, each child locus equals one of the parental loci at that index, and the simulation RNG state is unchanged. |
| Rate > 0 gives differences over many offspring | Rate 0.01, strength 8, 1,000 offspring: count of differing loci > 0; every changed locus differs by 1..=strength from its parent (before clamp; after clamp still within bounds); all loci stay in `0..=255`; a locus at 255 never wraps to 0 (clamp test). |
| Mutation uses the simulation generator | `mutate` takes `&mut Rng`; test that two runs with the same seed give identical children and that the generator state advances when rate > 0. |
| Configurable rate and strength | `Mutation::new` rejects rate outside [0,1] (NaN too) and strength 0 or > 255; config values flow through `Config` helper (test). |
| Genetic distance | `d(a,a) = 0`; symmetric over 1,000 random pairs; in `[0,1]`; moving one locus further from its partner gives a strictly larger value; ploidy or length mismatch is an error. |
| Determinism | Same seed, same parents gives the same child genome; `populate_initial` gives the same states for the same seed (checked via `Simulation` equality or `Entities` equality). |

Property-style tests use the seeded `Rng` (no `proptest` needed yet). The ADR-0004 text mentions proptest; IMPLEMENT may add it as a dev-dependency only if the workspace already has it available offline. Otherwise seeded loops are used and the deviation is recorded.

## 6. Commands for IMPLEMENT and REVIEW (exact)

```
export PATH=/opt/rust/cargo/bin:$PATH
cargo test -p evosim-core --locked                  # expect >= 155 + new tests, 0 failed
cargo test --workspace --locked
cargo clippy -p evosim-core -p evosim-cli --locked --all-targets
rustfmt --edition 2021 --check crates/evosim-core/src/genome.rs crates/evosim-core/src/entities.rs crates/evosim-core/src/sim.rs
bash scripts/check_adrs.sh
bash scripts/test.sh
git remote -v | wc -l                               # expect 0
```

Baseline in this PLAN: `cargo test -p evosim-core --locked` = 155 passed, exit 0.

## 7. Risks and deferred items

- R1 `max_lifespan` maps across [1, 10000]; the genome mean of ~127 gives ~5,000 ticks. Few organisms will die of old age in a 10,000-tick run. Calibrate later (a per-kind centre would need an ADR-0011 change); not a must-have.
- R2 Per-locus `chance` costs 256 draws per animal child. Fine for the target; if TASK-010 measures a shortfall, switch to geometric skipping. The draw count is part of the determinism contract; any change needs an ADR note.
- R3 `populate_initial` is not called from `Simulation::new`. The CLI wiring is in TASK-019. Until then `evosim run` produces an empty world; G-037 is closed at API level only. REVIEW must decide whether that is acceptable for this task (the task's must-haves do not require a populated run).
- R4 Storing `traits` next to `genome` duplicates data. Accepted for the TASK-008 API; `check_invariants` guards it. A later cleanup could remove the cache.
- R5 `species_distance` 0.06 and the distance scale: a single-locus change moves the distance by at most 1/(256*255) (about 0.00002), so the species threshold is many mutations away. Calibration is for the species task (TASK-017).
- R6 Mutation at clamp boundary: loci at 0 or 255 move less than `step` on the clamped side; the small-change property still holds.
- R7 ADR-0004 mentions `proptest`; the workspace may not have it. Plan uses seeded loops. Deviation to be recorded in the IMPLEMENT notes.
- R8 Dependency: `entities.rs` needs `genome.rs`; if `genome.rs` also needed `entities` types, the modules would form a cycle, which ARCHITECTURE forbids. Resolution (fixed in D2): `genome.rs` depends only on `rng` and returns block means (`trait_means`); `entities.rs` owns `decode_traits`, which maps means to the ranges and constructs `Traits`/`Tendencies`. `core::genome` therefore depends only on `rng`, as ARCHITECTURE says.

## 8. Anomalies noticed (reported, not changed)

- None new in this phase. Previously reported: commit `0d96320` title vs TASK-001 verdict (orchestrator's record).

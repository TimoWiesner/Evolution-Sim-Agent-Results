# TASK-001 PLAN cycle 1 — notes

## What was planned
TASK-001 is an architecture-decision task. It has no product code. Its deliverables are the decision records,
the module map with dependency rules, and a determinism section. PLAN cycle 1 wrote these documents as drafts
(Status: Proposed) so that the IMPLEMENT phase can verify them, review them against the acceptance criteria, and
mark them Accepted.

## Decisions (summary; full reasoning in the ADRs)
| Area | Choice | Record |
|---|---|---|
| Core language/runtime | Rust stable, Cargo workspace; crates `evosim-core`, `evosim-cli` (bin `evosim`), `evosim-ui` | docs/decisions/ADR-0001-language-and-runtime.md |
| UI | Local browser page served by the `evosim` binary (std HTTP server, embedded assets); container chromium for screenshots/smoke | docs/decisions/ADR-0002-ui-technology.md |
| Neighbour search | Per-cell CSR buckets rebuilt per tick; torus-aware query with dedup; id-ordered results | docs/decisions/ADR-0003-neighbour-search.md |
| Genome | Diploid `u8` loci for animals, haploid for plants; polygenic traits; locus-wise distance; species = time-persistent single-linkage cluster at a distance threshold, no count-based rule | docs/decisions/ADR-0004-genome-and-species.md |
| Determinism | One xoshiro256** RNG from the seed; ascending-id processing; fixed phase order; no wall clock or hash-map iteration in state | docs/ARCHITECTURE.md ("Determinism") |

## Ordered plan for IMPLEMENT (TASK-001)
1. Re-read the four ADRs and `docs/ARCHITECTURE.md`. Check each ADR against the task's "Must have" list:
   at least two alternatives, the choice, reasons covering performance, testability and the self-contained
   `dist/` folder. Fix the wording in ADR-0003 under "Decision" about the radius cap (it currently says the cap
   is "only in the sense of deduplication", which is unclear). Keep the wording of the rest as is unless a
   contradiction is found.
2. Add a short "Review checklist" section to `docs/decisions/README.md` that lists the four required records and
   the required sections of each (Status, Context, Considered alternatives, Decision, Consequences,
   Verification strategy).
3. Add an explicit determinism test plan to `docs/ARCHITECTURE.md`, already drafted in the Determinism section;
   confirm it names the forbidden constructs and the tests that will enforce them (seed repeatability, checkpoint
   split equality, different-seed hash difference).
4. Verify the module table in `docs/ARCHITECTURE.md` has no dependency from `core::*` to `evosim-ui` or
   `evosim-cli`. Confirm with a grep recorded in the handoff (`grep -rn "evosim_ui\|evosim_cli" crates/evosim-core`
   once crates exist; before that, the table itself is the check).
5. Mark ADR-0001..0004 as "Accepted" only if steps 1–4 are done. Update `docs/STATE.md` with the test commands
   that were actually run.
6. Run the check script below and record its exit code in the IMPLEMENT handoff.

### Check script (to be written in IMPLEMENT, e.g. `scripts/check_adrs.sh`, plain bash, no network)
- For each of the four ADR files: exists, has the sections `Status:`, `## Context`, `## Considered alternatives`,
  `## Decision`, `## Consequences`, `## Verification strategy`, and mentions at least two alternatives
  (numbered items under "Considered alternatives").
- `docs/ARCHITECTURE.md` contains the strings "Determinism" and "may depend on" (module table).

## Non-goals for TASK-001 (per task.md)
- No Cargo workspace or crate is created in this task. That belongs to TASK-002 (bootstrap).
- No `setup.sh`, `build.sh`, `evosim` launcher yet (TASK-002).
- No measurement is claimed. Performance numbers are targets until TASK-010 and later tasks record them.

## Dependent tasks (from task.json dependencies)
- TASK-002 (bootstrap) depends on TASK-001 for the layout and build tool choice.
- TASK-009 (genome) follows ADR-0004 exactly; any change to the genome representation must update ADR-0004 first.
- TASK-010 (spatial search) follows ADR-0003; its benchmark numbers go into `docs/ARCHITECTURE.md`.

## Environment checks run in PLAN (exit codes recorded in the handoff)
- `cargo --version` → cargo 1.100.0, exit 0.
- `rustc --version` → rustc 1.100.0, exit 0.
- `chromium --version` → Chromium 131.0.6778.33, exit 0.
- `git remote -v | wc -l` → 0 (no remotes; local-only Git policy respected).

## Open risks
- The browser screenshot path (ADR-0002) is planned but not tested. Chromium `--virtual-time-budget` behaviour with
  a canvas-driven page must be verified in the phase that first builds the UI.
- Species thresholds and mutation defaults are placeholders (ADR-0004).
- The determinism claim relies on the single-threaded core; any later parallelism must follow the rule in
  `docs/ARCHITECTURE.md`.

# TASK-001 IMPLEMENT cycle 2 — notes

Scope: apply `plan-cycle2.md` (gap closure G-001..G-008 from REVIEW cycle 1). No product code, no crate, no build file.

## Applied
- G-001 ADR-0003 Consequences: added `dist/` paragraph (plain Rust in evosim-core, no runtime/data file/external crate, compiled into the single binary). Also added a `Testability:` line.
- G-002 `scripts/check_adrs.sh`: the dist check is now whole-word (`grep -qw dist`) on the Consequences section only (`has_dist_word`). Two self-tests added: `distance distinct` must NOT match; `the dist/ folder` must match.
- G-003 ADR-0001: explicit sentence that no JSON crate is used (hand-written `core::config::json`, `core::metrics`); runtime crates limited to `sha2`. `docs/ARCHITECTURE.md` core::config row changed from "std, serde (JSON)" to "std only; hand-written JSON reader/writer in `config/json.rs`".
- G-004 ADR-0004 mutation: "wrapped ... by clamping" replaced by "clamped to `[0, 255]`" with the reason (no wrap jump at 255).
- G-005 ADR-0004 inheritance: chromosome defined as one haplotype (one linkage group); exactly one crossover `c` in `1..L-1`; loci `0..c` from A, `c..L` from B; no crossover-rate key.
- G-006 ADR-0004 species persistence: "counted in checks, not in ticks" (default 4 consecutive checks = 100 ticks at interval 25).
- G-007 ADR-0002: Status line says the browser path is not yet executed and feasibility is unverified; Verification strategy has a matching note.
- G-008: no edit; noted in STATE.md (grep runs once TASK-002 creates crates).

## Deviations from plan-cycle2
- Plan step for testability said "keep `grep -qi 'testab'` and state why". Done: the check is now `grep -qi 'testab'` and the reason is a comment in the script. This stricter check exposed that ADR-0001 and ADR-0003 had no testability wording, so a `Testability:` line was added to each (the bare `test` substring check had been passing on words like "latest"/"contest" or on `cargo test`).
- ADR-0002 Status line now reads "confirmed in TASK-001 IMPLEMENT cycle 2" (it was cycle 1); it was edited in this cycle.
- The plan's grep `grep -n serde ...` "must be empty" is not literally empty: the only hit is ADR-0001 saying no serde is used. That is a negation, not a dependency.

## Verification
- `bash scripts/check_adrs.sh` -> checks=53 failed=0, exit 0 (SKIP for the crate grep, as before).
- Evidence greps listed in STATE.md.

## Not done / open
- Anomaly unchanged: commit `0d96320` is titled "review cycle 1 PASS" but review-cycle1.json says FAIL. Reported to the orchestrator; no history changed.
- The chromium smoke/screenshot path (ADR-0002) is not executed; it belongs to the UI task.
- Numeric defaults (species_distance 0.06, mutation_rate 0.002, persistence 4) remain placeholders until calibration (TASK-009+).
- The check script is textual; REVIEW cycle 2 must read the records to confirm G-001..G-008.

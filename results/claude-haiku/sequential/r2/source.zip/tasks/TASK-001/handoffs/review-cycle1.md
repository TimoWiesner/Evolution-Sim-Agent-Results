# TASK-001 REVIEW cycle 1 — notes

Verdict: FAIL. Next PLAN must address G-001..G-006 (see review-cycle1.json).

## Checked and accepted
- docs/decisions/ADR-0001..0004 exist; Status line and the six required headings present; each has at least two numbered alternatives.
- ADR-0004 covers representation, inheritance (asexual and sexual), mutation, genetic distance and the species rule without population counts.
- docs/ARCHITECTURE.md: Determinism section (single xoshiro256** RNG, ascending-id order, fixed phase order, no wall clock, no HashMap iteration); module table with "may depend on" rules; acyclic; core has no UI or CLI dependency.
- No product code, no remotes, `dist/` ignored by .gitignore.
- `bash scripts/check_adrs.sh`: exit 0, checks=51 failed=0 (one SKIP for the crate grep).

## Failed or weak
1. ADR-0003 has no dist/ statement (`grep -c 'dist/'` = 0). Must-have requires it for each record.
2. scripts/check_adrs.sh `grep -q dist` matches "distance"/"distinct"; it hid item 1.
3. ARCHITECTURE.md core::config allows serde (JSON); ADR-0001 allows only sha2/proptest + hand-written JSON.
4. ADR-0004 mutation: "wrapped" and "clamping" both used.
5. ADR-0004: "crossover point per chromosome" — chromosome undefined.
6. ADR-0004: species_persistence called "time-based" but counts checks.

## Non-blocking
- ADR-0002 browser smoke/screenshot path not executed; keep Accepted but say feasibility is unverified.
- Core/UI dependency rule is documented only until TASK-002 creates crates.

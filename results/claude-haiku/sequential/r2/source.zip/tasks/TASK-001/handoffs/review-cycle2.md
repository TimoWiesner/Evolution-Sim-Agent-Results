# TASK-001 REVIEW cycle 2 — notes

Verdict: PASS. Every task.md Must-have and task.json acceptance criterion is met.

## Checked (by reading and commands)
- docs/decisions/ADR-0001..0004: Status line, six headings, >= 2 numbered alternatives, performance, testability and dist/ coverage.
  ADR-0003 dist/ paragraph present (G-001). ADR-0004 mutation clamped (G-004), chromosome defined (G-005), persistence counted in checks (G-006).
  ADR-0002 states browser path unverified (G-007).
- docs/ARCHITECTURE.md: Determinism section (xoshiro256** master RNG, ascending-id order, fixed phase order, no Instant/SystemTime in state,
  no HashMap iteration). Module table with "may depend on"; acyclic; core has no UI/CLI dependency. core::config is "std only" (G-003).
- scripts/check_adrs.sh: checks=53 failed=0 exit 0; dist test whole-word on Consequences with self-tests (G-002).
- No tracked product code (no crates/, src/, Cargo, setup, build). `git remote -v` = 0.

## Non-blocking gaps
- G-009 (ADR-0004 Inheritance and Genetic distance): locus `c` appears in both `0..c` and `c..L`; `L` means LOCI_PER_HAPLOTYPE in
  Inheritance and the common-ploidy locus count (256 for animals) in Genetic distance. Fix: `[0, c)` and `[c, L)`, two symbols.
- G-010 (ADR-0002 Tauri alternative): "Node toolchain not present" is false (node v18.19.1). Only the webkit2gtk reason holds.
- G-011 (anomaly, orchestrator): commit 0d96320 "review cycle 1 PASS" versus review-cycle1.json verdict FAIL. Reported only.
- G-008 (carried): core-to-UI grep SKIP until TASK-002 creates crates/evosim-core.

## Not done
- No ADR, ARCHITECTURE, script, task.md, task.json or benchmark state was edited. No commit made.
- Keyword checks in check_adrs.sh cannot judge reasoning; the verdict rests on reading the records.

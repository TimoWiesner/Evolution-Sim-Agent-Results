# TASK-001 IMPLEMENT cycle 1 — notes

## Done
- ADR-0003: radius-cap sentence replaced (no cap; exact for any radius).
- ADR-0001: "Two crates" -> "Three crates". Added performance notes to ADR-0001, ADR-0002, ADR-0004; testability and dist/ notes where missing.
- ADR-0001..0004: Status set to Accepted (with placeholder caveat for ADR-0004 numeric defaults).
- docs/decisions/README.md: index and review checklist.
- docs/ARCHITECTURE.md: status line updated; prose dependency rule ("may depend on", acyclic).
- scripts/check_adrs.sh: structural and keyword checks; `bash scripts/check_adrs.sh` -> checks=51 failed=0, exit 0.
- docs/STATE.md: status and the test command that was run.

## Not done (deliberate)
- Crate-level grep for evosim-core -> evosim-ui/evosim-cli: no crates exist; the check is in the script and is skipped until TASK-002.
- Chromium path (ADR-0002) not executed.

## For REVIEW
- Read the four ADRs against task.md "Must have"; the script only checks structure and keywords.
- Re-run `bash scripts/check_adrs.sh`.

# TASK-001 PLAN cycle 2 — notes (replan after REVIEW cycle 1 FAIL)

Scope: close every REVIEW gap from `review-cycle1.json` (G-001..G-008). No product code, no crate, no build file.
The IMPLEMENT phase applies the edits listed below and re-runs the checks. This phase only fixes the decisions and
the exact wording, so IMPLEMENT can execute them without re-deriving anything.

## Environment facts verified in this PLAN
- `curl https://index.crates.io/config.json` → HTTP 200 (crates.io reachable at setup time). `~/.cargo/registry` has no cache yet.
- `grep -nw dist` matches `dist/folder` and `saves dist folder`, and does NOT match `distance` or `distinct`. `grep -cw dist ADR-0003` = 0 (confirms G-001).
- `git remote -v | wc -l` = 0.

## Gap closure table

| Gap | Decision (chosen) | Exact edit for IMPLEMENT |
|---|---|---|
| G-001 ADR-0003 has no dist/ statement | Add a dist/ paragraph to ADR-0003 **Consequences**. | Append: "`dist/`: the index is plain Rust inside `evosim-core` with no runtime, data file or external crate. It is compiled into the single `dist/evosim` binary and needs no file next to it." |
| G-002 check script 'dist' is a substring test | Use whole-word matching. | In `scripts/check_adrs.sh` replace `grep -q 'dist' "$f"` with a check run on the **Consequences** section only: `section "$f" "Consequences" \| grep -qw 'dist'`. Add a self-test: `printf 'distance distinct\n' \| grep -qw dist` must FAIL (so the check is shown not to match substrings). Make the test/performance keyword checks word-based too (`grep -qiw 'test\|testability\|testable'` is NOT used; keep `grep -qi 'testab'` and state why). |
| G-003 serde in ARCHITECTURE vs hand-written JSON in ADR-0001 | **Hand-written JSON, no serde.** Reason: ADR-0001 already prefers no extra runtime dependency; the JSON subset needed (config read, result write) is small; keeps the dependency list to `sha2` (+ `proptest` dev-only). | Change `docs/ARCHITECTURE.md` row `core::config` "May depend on" to `std only; hand-written JSON reader/writer in config/json.rs (ADR-0001)`. `sha2` stays limited to `core::checkpoint`. In ADR-0001 add one sentence: "No JSON crate is used; config and result JSON are read and written by hand-written modules (`core::config::json`, `core::metrics`)." Keep `sha2` as the only runtime crate. |
| G-004 mutation "wrapped" and "clamped" | **Clamp** to `[0, 255]`. Reason: a reflected or wrapped locus would make ±1 steps near 0/255 jump across the range, which breaks the "small mutation, small change" property ADR-0004 relies on. | In ADR-0004 Mutation: replace "wrapped to `[0, 255]` by clamping" with "clamped to `[0, 255]`". |
| G-005 "one crossover point per chromosome" undefined | **Define chromosome = one haplotype** (the `LOCI_PER_HAPLOTYPE` loci of one ploidy copy, one linkage group). Exactly **one** crossover per meiosis, point drawn uniformly from `1..L-1`; no crossover-rate config key (removes a knob). | Rewrite ADR-0004 Inheritance (sexual) as: "Meiosis: a gamete is built from the parent's two chromosomes (haplotypes). One crossover point `c`, drawn uniformly from `1..L-1` with the simulation RNG, gives loci `0..c` from haplotype A and loci `c..L` from haplotype B. Child = gamete of mother + gamete of father, length `2L`." Remove the "uniform recombination rate configurable" phrase. |
| G-006 "time-based" persistence | **Counted in checks**, not in ticks. | In ADR-0004 Species criterion, replace "(time-based, default 4 checks = 100 ticks)" with "(counted in checks, not in ticks: default 4 consecutive checks, which is 100 ticks at interval 25)". |
| G-007 ADR-0002 feasibility unverified (non-blocking) | Keep Accepted; state that the browser path is unverified. | ADR-0002 Status line: append "Browser smoke/screenshot path not yet executed; feasibility unverified until the UI task." Also in the Consequences/Verification strategy. |
| G-008 core-to-UI rule only documented (non-blocking, expected) | Keep the grep in `check_adrs.sh`; it runs once `crates/evosim-core` exists (TASK-002). | No edit beyond noting in STATE.md. |

## Ordered IMPLEMENT plan (cycle 2)
1. Edit ADR-0003 (G-001), ADR-0004 (G-004, G-005, G-006), ADR-0001 (G-003 sentence), ADR-0002 (G-007).
2. Edit `docs/ARCHITECTURE.md` `core::config` row (G-003).
3. Edit `scripts/check_adrs.sh` (G-002): whole-word dist check on the Consequences section; add the negative self-test; keep the check count printed.
4. Run `bash scripts/check_adrs.sh; echo exit=$?` and record checks/failed/exit.
5. Run the grep evidence from review-cycle1 again: `grep -cw dist docs/decisions/ADR-0003-neighbour-search.md` must be >= 1; `grep -n 'serde' docs/ARCHITECTURE.md docs/decisions/*.md` must be empty; `grep -n 'wrapped' docs/decisions/ADR-0004*.md` must be empty; `grep -n 'per chromosome\|time-based' docs/decisions/ADR-0004*.md` must be empty.
6. Update `docs/STATE.md` with these commands and exit codes.
7. Write `implement-cycle2.json/.md` with the same fields as cycle 1.

## Anomaly to report (not fixed here)
- Git commit `0d96320` is titled "TASK-001 review cycle 1 PASS", but `review-cycle1.json` has `verdict: FAIL`. The phase commit message does not match the handoff. This is for the orchestrator to check; no commit or history change was made by this phase.

## Non-goals (unchanged from task.md)
- No code, no crates, no Cargo.toml, no setup/build scripts.
- No performance measurement; numeric defaults stay placeholders.

## Risks carried into IMPLEMENT
- A grep-based check still cannot judge reasoning quality. REVIEW must read the records.
- `sha2` needs crates.io at `./setup.sh` time (reachable now, verified with HTTP 200).

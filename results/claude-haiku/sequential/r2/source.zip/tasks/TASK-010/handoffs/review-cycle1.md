# TASK-010 REVIEW cycle 1: spatial search

Verdict: **PASS**. Machine-readable record: `review-cycle1.json`.

## What was checked
- Read the task spec, plan and implement handoffs, ADR-0003 with its amendment, the ARCHITECTURE module table and measured-performance section,
  and the code: `crates/evosim-core/src/spatial.rs` in full, the `sim.rs` diff (`add_founder`, `populate_initial`, `from_parts`, SpatialIndex and
  Deaths phases, Counters check, `check_spatial`), `world.rs` (`neighbours`, `axis_window`), and `entities.rs` (`deaths_phase`, `last_deaths`).
- Reasoning on edge cases:
  - `axis_window` returns all cells when `2r+1 >= len`, otherwise distinct residues, so `neighbours` has no duplicates for any radius, including `u32::MAX`.
  - Snapshot entries are skipped when their id is stale. Stale ids are answered from `positions` with `Torus::distance`, so each id is counted once.
  - Removals from `Entities` go through `deaths_phase`'s `last_deaths`, the only removal path. `check_spatial` covers any other drift.
  - `BTreeMap`/`BTreeSet` only; no `HashMap` in `spatial.rs`.

## Acceptance criteria against evidence
1. Query correctness (radius, optional kind, edges, no duplicates): seam and corner tests, kind-filter test, 1x1 and radius > world tests, plus randomised comparisons.
2. Add, move, remove keep the index correct; the old place is never returned, before and after rebuild: move, remove, and reinsert tests; the compaction-invariance test; the Simulation-level death removal test.
3. Deterministic order: ascending by id; insertion-order test.
4. At least 1,000 randomised queries vs brute force: `randomised_queries_match_brute_force` (60 seeds, worlds 1..=9 per side, radius up to max side + 3, plus a final full sweep) and `randomised_large_world_matches_brute_force` (64x48, 2,000 organisms, 1,000 queries). Both pass in the default `cargo test`.
5. Benchmark, about 2,000 organisms, index faster than brute force, numbers recorded: re-run in this phase; 2.80x, 1.83x, 3.45x. Recorded in `docs/ARCHITECTURE.md` alongside the implement numbers.

## Changes made in this phase (docs only)
- `docs/decisions/ADR-0003-neighbour-search.md`: amendment status changed from Proposed to Accepted, as the amendment itself required.
- `docs/ARCHITECTURE.md`: REVIEW re-measurement table added under "Measured performance".
- `docs/STATE.md`: REVIEW block with commands and exit codes.
- No product code changed. Nothing committed. `task.md` and `task.json` not touched.

## Gaps (non-blocking)
- G-045, G-046, G-047 carried from earlier phases (see JSON).
- G-048 (new, cosmetic): the comment in `torus_distance_is_chebyshev_with_wrap` contradicts its radius-0 assertion. The assertion is correct.

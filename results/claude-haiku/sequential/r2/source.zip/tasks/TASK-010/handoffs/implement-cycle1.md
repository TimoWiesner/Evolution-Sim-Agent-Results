# TASK-010 IMPLEMENT cycle 1: spatial search

Summary: `core::spatial::SpatialIndex` is implemented as planned (ADR-0003 amendment: CSR snapshot + stale-id overlay) and
wired into `Simulation`. Machine-readable record: `implement-cycle1.json`. Verdict N/A (for REVIEW).

Results (all exit 0): `cargo test -p evosim-core --locked` 206 passed, 1 ignored; `cargo test --workspace --locked` ok;
clippy on core and cli no warnings; rustfmt check clean; `scripts/check_adrs.sh` 98/0; `scripts/test.sh` ALL TESTS PASSED.
Benchmark (release, ignored test, median of 3): index faster than brute force at 2,000 organisms in all three configurations
(2.71x at 64x48 r=2, 1.76x at r=5, 3.34x at 256x192 r=2). Numbers are in `docs/ARCHITECTURE.md`.

Known limits: the benchmark queries while 200 moves per tick are still unapplied, so the stale overlay is in the cost; the
speed-up is a lower bound for phase-ordered use. Direct `entities_mut` edits can desync the index (caught by `check_spatial`).
No system dependencies were added. Nothing was committed.

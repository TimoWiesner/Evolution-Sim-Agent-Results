# TASK-010 PLAN cycle 1: spatial search

Scope: plan only. No product code, Cargo file, task file or benchmark file was changed. Documentation changed:
`docs/decisions/ADR-0003-neighbour-search.md` (amendment section appended, Proposed until REVIEW PASS),
`docs/ARCHITECTURE.md` (the `core::spatial` row now lists the dependencies `world` and `entities`).

## 1. State found on entry (verified in this phase)

- `AGENTS.md`, `docs/STATE.md`, `docs/PROJECT.md`, `docs/CONTRACT.md`, `docs/ARCHITECTURE.md`, `docs/decisions/ADR-0003` and
  `ADR-0007` exist and were read. `tasks/TASK-010/task.md|json` were read.
- `crates/evosim-core/src/spatial.rs` does NOT exist. `lib.rs` has no `pub mod spatial`.
- Baseline: `cargo test -p evosim-core --locked` -> exit 0, `178 passed; 0 failed` (PATH includes `/opt/rust/cargo/bin`).
- `git remote -v | wc -l` -> 0. `nproc` -> 12.
- APIs used (verified in the source):
  - `world.rs`: `Torus::new(w,h)`, `Torus::width/height/cell_count`, `Torus::index(Cell)`, `Torus::neighbours(centre, r) -> Vec<Cell>`
    (each cell once, any radius), `Torus::distance(a,b) -> u32` (Chebyshev, ADR-0007), `Cell` is `Copy+Eq+Hash` with private fields,
    `Torus::cell(x,y) -> Option<Cell>`.
  - `entities.rs`: `OrganismId(pub u64)` (`Ord`, `Copy`), `Kind` (`Copy`, `Eq`, `Hash`, `index()`), `Entities::living()`,
    `Entities::get(id)`, `Entities::last_deaths() -> &[Death]` with `Death { id, kind, cell, tick, cause }`.
  - `rng.rs`: `Rng::next_below(n: u64) -> u64` (unbiased), `Rng::from_seed`. Tests use this and no new crate.
  - `sim.rs`: `Phase::SpatialIndex` is an empty arm (`run_phase`); `Phase::Deaths => self.entities.deaths_phase(self.tick)`;
    `Simulation` fields `tick, rng, world, entities, trace`; `add_founder` allowed at tick 0 only.
- No dependency on any crate is added (ADR-0003: plain Rust in `evosim-core`).

## 2. Decisions (with reasons)

### D1. Data structure: snapshot plus change overlay (amends ADR-0003)
ADR-0003 chose a CSR per-cell snapshot rebuilt once per tick. TASK-010 also requires that add, move and remove keep the index
correct at all times. A pure per-tick snapshot cannot give that without a rebuild after each change, and a pure
incremental structure (ADR-0003 option 4) was rejected there as easy to leave stale. The chosen design keeps both:

- `positions: BTreeMap<OrganismId, Placed { cell: Cell, kind: Kind }>`: current truth. A `BTreeMap`, not a `HashMap`
  (ARCHITECTURE rule 4). Lookup O(log n); n = 2,000 is tiny.
- CSR snapshot: `cell_start: Vec<u32>` (len `W*H+1`), `items: Vec<SnapEntry { id, kind }>`, built by counting sort from
  `positions` in ascending id order, so buckets are id-sorted.
- `stale: BTreeSet<OrganismId>`: ids inserted, moved or removed since the snapshot. Snapshot entries of stale ids are ignored;
  stale ids are answered from `positions`.
- Automatic compaction: when `stale.len() > max(32, positions.len()/4)`, rebuild and clear `stale`. Compaction timing never
  changes results.
- Cost: query = O(cells in the box + snapshot entries there + |stale| log n). Insert/move/remove = O(log n) plus the
  amortised rebuild O(n + W*H).

Why this is the best of the options: it is ADR-0003's counting-sort layout (cheap bulk rebuild, no per-bucket allocation),
with the correctness of an always-current structure. The stale set is bounded by compaction, so the overlay never grows.

### D2. Query interface
```rust
pub struct SpatialIndex { /* private */ }
pub struct SpatialError  // enum: DuplicateId(OrganismId), UnknownId(OrganismId), CellOutsideTorus? (not needed: Cell is valid by type)

impl SpatialIndex {
    pub fn new(torus: Torus) -> SpatialIndex;
    pub fn torus(&self) -> Torus;
    pub fn len(&self) -> usize;                       // indexed organisms
    pub fn insert(&mut self, id: OrganismId, cell: Cell, kind: Kind) -> Result<(), SpatialError>;
    pub fn move_to(&mut self, id: OrganismId, cell: Cell) -> Result<(), SpatialError>;
    pub fn remove(&mut self, id: OrganismId) -> Result<(), SpatialError>;
    pub fn position(&self, id: OrganismId) -> Option<(Cell, Kind)>;
    pub fn rebuild(&mut self);                        // compaction, no change of results
    pub fn within(&self, centre: Cell, radius: u32, filter: Option<Kind>) -> Vec<OrganismId>;  // ascending id, no duplicates
    pub fn within_into(&self, centre: Cell, radius: u32, filter: Option<Kind>, out: &mut Vec<OrganismId>); // clears out first
}
```
`within` is the public query; `within_into` avoids allocation in later hot loops. Radius is `u32` (any value; radii beyond the
world return every indexed organism within Chebyshev distance, each once). `filter: None` returns all kinds.
`Option<Kind>` for "optionally only of one kind".

Distance: `Torus::distance(centre, cell) <= radius`, the same metric as `Torus::neighbours` (ADR-0007), so the box and the
test agree. The result order is ascending `OrganismId`, which is fixed and independent of insertion order or compaction.

### D3. Wiring into `Simulation` (in scope: ADR-0008 step 2 says "no-op until TASK-010")
- `Simulation` gets a field `spatial: SpatialIndex`, created in `new` from the world's torus.
- `add_founder` also calls `spatial.insert(id, cell, kind)` after `entities.spawn_founder`.
- Phase `SpatialIndex`: `self.spatial.rebuild()` (compaction only).
- Phase `Deaths`: after `entities.deaths_phase(tick)`, for each `d` in `entities.last_deaths()` call `spatial.remove(d.id)`.
- Accessor `Simulation::spatial(&self) -> &SpatialIndex` for later tasks.
- `Simulation::check_spatial(&self) -> Result<(), SpatialError or String>`: every living organism is indexed with the same cell
  and kind, and no other id is indexed. Called in the Counters phase under `debug_assertions` and in tests.
- No behaviour uses the index yet (TASK-013 onwards). Movement, birth and death must go through `Simulation`-level helpers
  (`move_organism` etc.) in those tasks, so the index stays in sync. Direct `get_mut(id).set_cell(..)` (G-040/G-041) would
  desync it; `check_spatial` catches that.
- `from_parts`/checkpoint: the index is derived state and is not saved (ADR-0003 amendment). TASK-022 must rebuild it from `Entities`.

### D4. Dependency table
`core::spatial` may use `world` and `entities` (only `OrganismId`, `Kind`). Already written to `docs/ARCHITECTURE.md`.
Acyclic: `entities` does not depend on `spatial`.

### D5. Determinism rule for behaviour phases (documented, enforced by convention in later tasks)
Within a phase, a behaviour that moves organisms must defer the moves to the end of the phase; then queries in that phase see
the same state regardless of processing order. Written in the ADR-0003 amendment and in ARCHITECTURE determinism rule 2.
TASK-010 itself has no behaviour, so the rule is not exercised here.

## 3. Ordered steps for IMPLEMENT

1. `crates/evosim-core/src/spatial.rs` (new) with the types and functions of D1/D2. Module doc comment cites ADR-0003 and its
   amendment. Private `SnapEntry { id: OrganismId, kind: Kind }` and `Placed`.
2. `crates/evosim-core/src/lib.rs`: add `pub mod spatial;` in alphabetical order.
3. `crates/evosim-core/src/sim.rs`: field `spatial`, `new`, `add_founder`, the `SpatialIndex` and `Deaths` phase bodies, the
   Counters-phase debug check, `spatial()` accessor and `check_spatial()`. Keep the phase order and the trace unchanged.
   Existing sim tests must still pass unchanged.
4. Unit tests in `spatial.rs` (list below).
5. Randomised comparison and benchmark tests (list below).
6. `docs/decisions/ADR-0003` amendment: already written; set it to Accepted at REVIEW PASS, and add an implementation-notes
   block (names as implemented, any deviation).
7. `scripts/check_adrs.sh`: no change needed unless the checker lists headings; if it does, keep ADR-0003 headings valid.
8. `docs/ARCHITECTURE.md`: add "Measured performance" numbers for TASK-010 (see step 10) and update the `core::spatial` status line.
9. `docs/STATE.md`: IMPLEMENT section with the commands run and their exit codes.
10. Benchmark (recorded, not asserted for speed in the default run): see section 5.

## 4. Tests to write (IMPLEMENT)

Unit (default `cargo test`):
- Edges and seams: organisms at `(0,0)`, `(W-1,0)`, `(0,H-1)`, `(W-1,H-1)` find each other from the opposite corner with radius 1;
  a query at `x=0` with radius 1 includes `x=W-1`; the same for y.
- Radius: radius 0 returns only the organisms in the centre cell; radius `>= max(W,H)` on a small world returns every indexed
  organism once.
- Kind filter: `Some(Kind::Plant)` returns only plants; `None` returns all kinds; a kind with no organisms in range returns empty.
- Order and duplicates: ids inserted in descending order still come back ascending; no id appears twice in a 1x1 world with
  radius 5.
- Moves: after `move_to`, the id is not returned from the old cell (query at the old centre, radius 0) and is returned from
  the new cell; the same holds before and after `rebuild()`.
- Removal: after `remove`, the id is never returned; `remove` of an unknown id is `UnknownId`; a second `remove` is an error.
- Insert: duplicate id is `DuplicateId`; the index is unchanged after an error.
- Compaction does not change results: the same operations with and without `rebuild()` give equal `within` results.
- `within_into` clears the buffer first.
- Torus-wrap distance uses the Chebyshev metric: on a 10x10 world, the distance between x=0 and x=9 is 1 (radius 1 finds it).
- `Simulation` (sim.rs tests): `add_founder` inserts into the index; a starved founder removed by the Deaths phase is removed
  from the index; `check_spatial` holds after each `tick()` of a short run with founders.

Randomised (seeded, default `cargo test`, must stay fast, under about 2 s):
- Seeds 1..=40 (≥ 1,000 queries in total, plan: 40 seeds x 60 queries = 2,400). Each seed: world sides chosen from
  `1..=9` (includes `1x1`, `1xN`, `Nx1`), 0..=40 organisms, and a random sequence of 200 operations: insert (new id),
  move_to (random cell), remove, rebuild, and queries (random centre, radius `0..=max(W,H)+3`, random filter).
  Each query is compared with a brute-force reference that iterates all live organisms, computes the wrapped per-axis
  distance by its own formula `d = (a-b).rem_euclid(L); min(d, L-d)` and takes `max` over the two axes (not `Torus::distance`,
  so the reference is independent), filters by kind, and sorts by id.
- Larger worlds: 1,000 queries on a 64x48 world and 2,000 organisms, radius 0..=6 and filter variants, same comparison.

Ignored benchmark (release only, run by hand; see section 5):
- `#[ignore] fn bench_index_vs_brute_force()` in `spatial.rs` with `eprintln!` numbers, plus `assert!(index < brute)` only when
  built with `cfg(not(debug_assertions))`, so debug builds never fail on timing.

## 5. Benchmark design (the "about 2,000 organisms" measurement)

- Torus 64 x 48 (the default configuration size, `docs/CONTRACT.md` example), 2,000 organisms placed by seeded RNG
  (mixed kinds: 1,600 plants, 280 herbivores, 120 carnivores, or a uniform mix; the mix is written in the output).
- Workload per simulated tick: 2,000 queries (every organism queries radius 2, the 25-cell perception square of ADR-0007),
  then 10 % of organisms move one cell (`move_to`), then `rebuild()`. Run 200 ticks, seed fixed.
- Two numbers: ns per query for brute force (scan all 2,000, compute the distance per organism, filter), and ns per query for
  the index including the mutations and the amortised rebuild. The ratio is the speed-up.
- Also one extra row at radius 5 and one at a larger world (256 x 192, same 2,000 organisms) to show the density effect.
- Command (exact): `cargo test -p evosim-core --release --locked -- --ignored --nocapture bench_index_vs_brute_force`.
- Record the numbers, the machine (`nproc` 12, CPU model from `/proc/cpuinfo`), the rustc version, and the date in
  `docs/ARCHITECTURE.md` under "Measured performance". The brute-force numbers are the baseline the index must beat.
- Expectation (not a result): the index visits about 25 cells with about 0.65 organisms each at 2,000 / 3,072 cells, so it
  should be far faster than scanning 2,000 organisms. The measurement decides.

## 6. Commands for IMPLEMENT (exact)

- `export PATH=/opt/rust/cargo/bin:$PATH`
- `cargo test -p evosim-core --locked`
- `cargo test --workspace --locked`
- `cargo test -p evosim-core --release --locked -- --ignored --nocapture bench_index_vs_brute_force`
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`
- `rustfmt --edition 2021 --check crates/evosim-core/src/spatial.rs crates/evosim-core/src/sim.rs`
- `bash scripts/check_adrs.sh`
- `bash scripts/test.sh`
- `grep -rn 'HashMap\|HashSet' crates/evosim-core/src/spatial.rs` (expect exit 1, no match)
- `git remote -v | wc -l` (expect 0)

Baseline before IMPLEMENT: `cargo test -p evosim-core --locked` = 178 passed (exit 0).

## 7. Risks

- R1 (correctness of the overlay): a bug in stale handling gives a duplicate or a stale hit. Mitigation: the randomised
  brute-force comparison with move, remove and rebuild in the same sequence, plus the compaction-invariance test.
- R2 (desync with `Entities`): a caller changing a cell through `get_mut(..).set_cell` bypasses the index. Mitigation:
  `check_spatial` in debug Counters and in tests; TASK-013 must add a `Simulation`-level move helper.
- R3 (speed): the overlay makes `within` slower when many organisms are stale. Mitigation: compaction bound (stale <= n/4);
  the benchmark measures the mixed workload with 10 % moves per tick.
- R4 (benchmark noise): timings vary on a shared host. Mitigation: fixed seed, three repetitions with the median recorded;
  the speed assertion runs only in release and only in the ignored test.
- R5 (checkpoint): the index is not saved. TASK-022 must rebuild it on load, or a loaded run queries an empty index.
- R6 (phase convention): TASK-013+ must defer moves to the end of a phase (ADR-0003 amendment); the index cannot enforce it.
- R7 (ADR amendment): ADR-0003 changes its per-tick rule; it stays Proposed until REVIEW PASS, as the amendment says.

## 8. Gaps carried into IMPLEMENT (not blocking this task)

- G-037 (founders not placed from `config.initial`, closed only at API level; CLI wiring TASK-019).
- G-040 (`get_mut`, `heal`, `add_energy`, `set_cell` accept dead organisms; use `living()`), G-041 (`set_cell` does not check the torus).
  Both matter for TASK-013 and matter for the index sync (R2).
- G-042, G-043, G-044 (TASK-009 review; non-blocking).
- Gap G-045 (new, planning): the index has no save/load. Recorded in R5; TASK-022 owns it.

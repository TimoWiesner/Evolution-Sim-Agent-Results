# TASK-014 REVIEW cycle 1: herbivore feeding and behaviour, verdict PASS

Full record: `review-cycle1.json`. Design: `docs/decisions/ADR-0015-herbivore-feeding-and-behaviour.md` (now Accepted).

## Acceptance points (task.md "Must have")
1. Reach: `feeding::feed` uses `SpatialIndex::within(cell, FEED_REACH = 1, Plant)`. Tests `feed_takes_from_own_cell_and_adjacent_cells_only`, `feed_reaches_across_the_west_seam`, `vision_decides_whether_a_plant_at_distance_three_attracts_a_herbivore`. Met.
2. Cap and conservation: `BITE_MAX = 2.0` per tick; plant `drain_energy(eaten)`; herbivore gains `0.8 * eaten`. Tests `feed_never_takes_more_than_the_cap_and_gains_no_more_than_it_takes`, `feed_sums_several_small_plants_up_to_the_cap`, `a_plant_eaten_to_zero_is_removed_by_the_deaths_phase_as_starvation`, `feeding_never_creates_energy_in_the_herbivore_phase`. Met.
3. Energy loss and death: `herbivore_phase` charges move cost, `BASE_COST` 0.3 and thermal cost each tick; `drain_energy` sets `Starvation` at 0. Tests `a_still_herbivore_pays_base_metabolism_and_climate_cost_each_tick`, `a_herbivore_starves_through_the_phase_when_it_has_no_food`. Met.
4. Climate: `thermal_cost` is 0 in 5..30 C and 0.02 per degree outside, capped at 40 degrees. Tests `colder_cells_cost_a_herbivore_more_energy_than_mild_ones` (phase level, cold cell) and `thermal_cost_is_zero_inside_the_band_and_grows_outside`. Met.
5. Genes: `herbivore_heading` depends on caution against hunger. Test `two_herbivores_with_different_caution_act_differently_in_the_same_situation` gives Away for caution 230 and Towards for caution 20 in the same situation, and the cells differ after the phase. Met.

## Commands run in REVIEW (exit codes)
- `cargo test -p evosim-core --locked`: 0 (294 passed, 1 ignored).
- `cargo test --workspace --locked`: 0.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: 0, no warnings.
- `bash scripts/check_adrs.sh`: 0 (checks=142 failed=0).
- `git remote -v`: empty.

## Finding (non-blocking, G-051)
ADR-0015 (Consequences and implementation notes) says `Away` falls back to `Wander` when the danger is on the herbivore's own cell. The code does not do this. `movement.rs` `plan_moves` maps `Heading::Away(threat)` to `step_away`, which returns `(from, 0)` when `from == threat`. The herbivore therefore stays still, draws no random number and still pays its costs. `perceive` includes a carnivore on the same cell (distance 0), so this case can occur. Resolve it in a later phase that touches `movement.rs`: add a Wander fallback, or correct the ADR wording. Add a test either way.

## Other notes
- Satiation is checked before the bites (documented). A herbivore starting just under 80 can end slightly above 80.
- TASK-013 REVIEW gap 2 (reversed-order `plan_moves` test) is still open and is not an acceptance point.
- G-046 (animal query cost) is not measured.
- No product code, task file, benchmark file or commit was changed in this phase. Docs changed: ADR-0015 (status and review notes), `docs/decisions/README.md`, `docs/STATE.md` (REVIEW section).

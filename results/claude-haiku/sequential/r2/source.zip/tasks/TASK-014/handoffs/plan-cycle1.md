# TASK-014 PLAN cycle 1: herbivore feeding and behaviour

Design record: `docs/decisions/ADR-0015-herbivore-feeding-and-behaviour.md` (Proposed). No product code, Cargo file, task file,
benchmark file or commit was changed in this phase. Docs changed: the new ADR, `docs/decisions/README.md` index line,
`docs/ARCHITECTURE.md` TASK-014 PLAN note, `docs/STATE.md` PLAN section, this file and the plan JSON.

## Starting point (verified in PLAN)
- `cargo test -p evosim-core --locked`: exit 0, 273 passed, 1 ignored (baseline; TASK-013 REVIEW count). Toolchain at
  `/opt/rust/cargo/bin` (`export PATH=/opt/rust/cargo/bin:$PATH`).
- `bash scripts/check_adrs.sh`: exit 0, checks=131 failed=0. ADR-0015 is not in the script list yet (added at IMPLEMENT, as ADR-0014 was).
- `git status` clean at `e56d2a6`.
- `sim.rs` `run_phase`: `Phase::Herbivores => self.animal_phase(Kind::Herbivore)`; `Phase::Plants` runs before it (plant energy
  is up to date); `Phase::Deaths` removes dead ids from the index.
- `movement.rs`: `Heading { Wander, Towards(Cell) }`; `choose_heading(kind, perceived)` always `Wander`; `plan_moves` computes
  perception and heading for every living animal of the kind (ascending id) and includes zero-step plans.
- `entities.rs`: `Organism::drain_energy` (floors at 0, sets `Starvation` at 0), `add_energy` (caps at `ENERGY_MAX` 100),
  `Entities::get/get_mut/living`, `Tendencies::caution()` (genome slot 6), `Traits::speed()`, `vision_radius(genome)`.
- `SpatialIndex::within(centre, radius, Option<Kind>)`: Chebyshev, torus-aware, ascending ids, no duplicates.
- `Climate::conditions(cell).temperature` (degrees C, range `TEMPERATURE_RANGE`), the same source the Plants phase uses.
- `sim.rs` `FOUNDER_ENERGY` = 50.0; plants and animals are placed by `populate_initial`.
- Gaps this task touches: TASK-013 REVIEW gap 1 (perception does not change behaviour) is closed for herbivores; gap 2 (reversed-order
  `plan_moves` test) stays open as a non-blocking item unless IMPLEMENT adds it cheaply; G-046 (stale overlay cost) stays open.

## Decisions (full text in ADR-0015)
1. Feeding reach 1 (own or adjacent cell, `within(cell, 1, Plant)`); vision is only for finding food.
2. Feeding in the Herbivores phase after the moves, sequential in ascending id; plants visited in ascending id.
3. Intake cap `BITE_MAX = 2.0` per herbivore per tick; gain `ASSIMILATION (0.8) * eaten`; plant loses `eaten`.
4. Satiation: no bites at energy >= `SATIATION_ENERGY = 80`.
5. Every tick a herbivore pays: movement cost (ADR-0014), `BASE_COST = 0.3`, `thermal_cost(T)` with
   `THERMAL_COST = 0.02` per degree outside `[5, 30]` °C, excess capped at 40 degrees.
6. Decision rule: `hunger = 1 - energy/100`. Nearest carnivore in sight and `caution > hunger` gives `Away`; else nearest food
   plant (energy > 0, only while below satiation) in sight gives `Towards`; else `Wander`. Aggression has no herbivore effect yet.
7. Carnivores stay on the TASK-013 `animal_phase` (wander and movement cost only); their metabolism and hunting are TASK-015.

## Ordered implementation plan (for IMPLEMENT)
1. `crates/evosim-core/src/movement.rs`:
   - add `Heading::Away(Cell)` and `pub fn step_away(torus, from, threat, steps) -> (Cell, u32)` (per-axis `-sign` of
     `torus.delta(threat, from)`, diagonal when both axes are non-zero; returns `(from, 0)` if already on the threat cell, so the
     caller falls back to wander);
   - change `plan_moves` to take the heading rule: `choose: impl Fn(&Organism, &[OrganismId]) -> Heading` (replaces the call
     to `choose_heading`); `Heading::Away` is handled like the other arms. `choose_heading` stays for carnivores (TASK-013 behaviour).
   - Update the TASK-013 unit tests that call `plan_moves` (signature only; no expected value changes).
2. `crates/evosim-core/src/feeding.rs` (new; `pub mod feeding` in `lib.rs`): constants `FEED_REACH = 1`, `BITE_MAX = 2.0`,
   `ASSIMILATION = 0.8`, `SATIATION_ENERGY = 80.0`, `BASE_COST = 0.3`, `COMFORT_LOW = 5.0`, `COMFORT_HIGH = 30.0`,
   `THERMAL_COST = 0.02`, `THERMAL_STRESS_MAX = 40.0`; functions:
   - `pub fn thermal_cost(temperature: f32) -> f32`;
   - `pub fn herbivore_heading(entities: &Entities, spatial: &SpatialIndex, o: &Organism, perceived: &[OrganismId]) -> Heading`
     (the rule above; nearest with lowest id on ties; `perceived` is already ascending, so the first minimum wins);
   - `pub fn feed(entities: &mut Entities, spatial: &SpatialIndex, id: OrganismId) -> f32` (returns energy gained): reads the
     herbivore's cell and energy, takes bites from `within(cell, FEED_REACH, Some(Kind::Plant))` in ascending id order, stops at
     the cap or satiation, updates plant with `drain_energy` and herbivore with `add_energy`.
   - Unit tests for constants, `thermal_cost` (zero inside band, monotone outside, cap) and `herbivore_heading` (see tests).
3. `crates/evosim-core/src/movement.rs` (`Heading::Away`, `step_away`) and `sim.rs`:
   - new private `fn herbivore_phase(&mut self)`: `plan_moves(&self.entities, &self.spatial, &self.world.topology, Kind::Herbivore,
     &mut self.rng, |o, p| feeding::herbivore_heading(&self.entities, &self.spatial, o, p))`; apply moves in order with
     `move_organism` (debug-assert ok); then for each living herbivore in ascending id: `feeding::feed`; then charge
     `move_cost(distance, speed) + BASE_COST + thermal_cost(climate.conditions(cell).temperature)` with `drain_energy`.
   - `run_phase`: `Phase::Herbivores => self.herbivore_phase()`. `animal_phase` stays for Carnivores only.
   - Borrowing: the closure captures `self.entities` and `self.spatial` shared while `self.rng` is borrowed mutably (disjoint fields).
4. `lib.rs`: `pub mod feeding;`.
5. Docs in IMPLEMENT: ADR-0015 implementation notes (status Proposed until REVIEW), `scripts/check_adrs.sh` list gets
   `ADR-0015-herbivore-feeding-and-behaviour.md`, ARCHITECTURE module row for `core::feeding`, STATE.md IMPLEMENT section.
6. Existing tests: run `cargo test -p evosim-core --locked`. Tests that run herbivores for many ticks (for example
   `founders_populate_and_index_stays_in_sync_over_500_ticks_with_edges`, `same_seed_...`, `populated_world_keeps_invariants_over_ticks`)
   may see herbivore deaths; they must still assert their invariants. Any expected value that changes is listed in the IMPLEMENT
   handoff with the reason.

## Test plan (each maps to an acceptance point; IMPLEMENT writes them)
- Reach (acceptance 1): `feed` takes nothing from a plant at Chebyshev distance 2; takes from own cell and from an adjacent cell;
  across a seam (herbivore at x=0, plant at x=W-1). Perception across the edge is covered by ADR-0014 tests.
- Vision (acceptance 1): `herbivore_heading` gives `Towards` for a plant at distance 3 with vision 3 and `Wander` with vision 2.
- Cap and conservation (acceptance 2): one `feed` with a plant at energy 90 and a hungry herbivore: plant loses exactly `BITE_MAX`
  (2.0) and herbivore gains `0.8 * 2.0`; gain <= amount taken; several small plants sum to the cap.
- Plant death (acceptance 2): a plant with energy 0.5 is eaten to 0 and is removed by the Deaths phase with `Starvation`
  (`last_deaths`); the index has no entry for it (`check_spatial`).
- Satiation: a herbivore at energy 80 takes nothing.
- Metabolism (acceptance 3): speed 0, no plants, comfort cell: one `herbivore_phase` lowers energy by exactly `BASE_COST`.
  A herbivore at energy 0.2 and no food gets `Starvation` through the phase; the Deaths phase removes it.
- Climate (acceptance 4): at the same speed and energy, a herbivore on a cell with temperature -20 loses more than one at 15 °C.
  `thermal_cost` is 0 for 5..=30, monotone outside, capped at 0.8.
- Genes (acceptance 5): two herbivores in the same cell with a carnivore and a plant in sight and the same energy 50: caution 0.9
  gives `Away(carnivore cell)`, caution 0.1 gives `Towards(plant cell)`; after `herbivore_phase` their cells differ.
- Determinism: same seed gives identical herbivore cells and energies after 50 ticks; different seeds differ.
- Energy balance over a run: total energy of herbivores + plants does not increase from feeding alone (no births in this task).

## Test commands (IMPLEMENT and REVIEW record exit codes)
- `cargo test -p evosim-core --locked` (expect > 273 passed).
- `cargo test --workspace --locked`; `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`;
  `rustfmt --edition 2021 --check` on changed files only (never on `lib.rs`); `bash scripts/check_adrs.sh`; `bash scripts/test.sh`.

## Risks
- R1: Founders (energy 50) with base cost 0.3 plus movement cost starve unless plants are reachable; population outcome is
  uncalibrated (TASK-018). Tests use explicit small worlds.
- R2: Sequential feeding is order-dependent within a phase (deterministic, documented). A stricter reading of ADR-0014 "deferred
  moves" does not apply: feeding is not a move.
- R3: Carnivores have no base cost in this task, so only their movement cost drains them (TASK-015 must add metabolism).
- R4: Aggression is unused for herbivores (documented); the reviewer may ask for a use, but the brief only requires caution/behaviour
  genes to matter.
- R5: Thermal and base constants are uncalibrated (TASK-018).
- R6: Changes to RNG consumption are unchanged (herbivores do not draw new random numbers; wander draws occur as in TASK-013 for
  herbivores that wander), so determinism tests still hold, but exact-trace expectations may shift if a herbivore now moves.

## Not part of this task
Being hunted and carnivore hunting (TASK-015), reproduction (TASK-016), carnivore metabolism (TASK-015), checkpoint (TASK-022),
CLI wiring (TASK-019), calibration (TASK-018), plant regrowth changes.

## System dependencies
None new. Toolchain at `/opt/rust/cargo/bin`.

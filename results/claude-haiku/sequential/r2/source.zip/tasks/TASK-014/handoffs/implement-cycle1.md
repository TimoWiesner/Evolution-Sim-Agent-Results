# TASK-014 IMPLEMENT cycle 1: herbivore feeding and behaviour

Implements ADR-0015 as planned. Full record: `implement-cycle1.json` (summary, decisions, risks, commands with exit codes).

## Result
- `cargo test -p evosim-core --locked`: exit 0, 294 passed, 1 ignored (baseline 273 passed).
- `cargo test --workspace --locked`: exit 0.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: exit 0, no warnings.
- `rustfmt --edition 2021 --check` on feeding.rs, movement.rs, sim.rs: exit 0.
- `bash scripts/check_adrs.sh`: exit 0, checks=142 failed=0.

## Acceptance points, where each is shown
1. Reach: `feeding::tests::feed_takes_from_own_cell_and_adjacent_cells_only`, `feed_reaches_across_the_west_seam`, `vision_decides_whether_a_plant_at_distance_three_attracts_a_herbivore`.
2. Cap and conservation: `feed_never_takes_more_than_the_cap_and_gains_no_more_than_it_takes`, `feed_sums_several_small_plants_up_to_the_cap`, `a_plant_eaten_to_zero_is_removed_by_the_deaths_phase_as_starvation`, `sim::herbivore_tests::feeding_never_creates_energy_in_the_herbivore_phase`.
3. Energy loss and death: `sim::herbivore_tests::a_still_herbivore_pays_base_metabolism_and_climate_cost_each_tick`, `a_herbivore_starves_through_the_phase_when_it_has_no_food`.
4. Climate: `sim::herbivore_tests::colder_cells_cost_a_herbivore_more_energy_than_mild_ones`, `feeding::tests::thermal_cost_is_zero_inside_the_band_and_grows_outside`.
5. Genes: `sim::herbivore_tests::two_herbivores_with_different_caution_act_differently_in_the_same_situation`, `caution_against_hunger_decides_flight_from_a_carnivore`, `same_seed_gives_identical_herbivores_and_different_seeds_differ`.

## Changed expectations (TASK-013 tests)
- `a_tick_moves_animals_by_at_most_their_speed_and_charges_the_cost`: now also subtracts base metabolism and thermal cost.
- `slow_animals_do_not_move_and_pay_nothing` renamed `slow_animals_do_not_move_and_pay_only_metabolism_and_climate`; asserts a range.

## Open
- TASK-013 REVIEW gap 2 (reversed-order plan_moves test) still open. G-046 not measured. No population-level test (TASK-018).

# TASK-021 IMPLEMENT cycle 1: batch runs and export

Implements ADR-0022 (Proposed; Accepted only at REVIEW PASS). Machine-readable handoff: `implement-cycle1.json`.

## What was built
- `evosim batch --config FILE --seeds S1,S2,... --ticks N --out-dir DIR [--vary KEY=V1,V2,...]... [--sample-every K] [--jobs J] [--csv]`
- Without `--vary`: `DIR/seed-S.json` (CONTRACT section 2). With `--vary`: `DIR/case-NN/seed-S.json`.
- `DIR/summary.json` (format `evosim-batch-summary`, version 1): every run with case, seed, parameters, file, ticks, initial,
  final, species, extinct flags and state hash; aggregates per case and overall (final mean, min, max, population sd, extinct
  count and fraction per kind). No wall-clock values, so the same batch gives a byte-identical summary. Written last.
- `--csv`: `DIR/runs.csv` (one row per run) and `DIR/aggregates.csv` (one row per case and kind).
- `--jobs J` (default 1): worker threads; results are stored by run index, so output does not depend on J.
- The run loop moved from the CLI into `core::runner` (shared by `run` and `batch`); `core::batch` holds the pure logic.

## Verification (exit codes)
- `cargo test --workspace --locked`: 0 (core 408 passed, 1 ignored; CLI unit 32; batch_cli 8; run_cli 9).
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: 0, no warnings.
- `bash scripts/check_adrs.sh`: 0, checks=153 failed=0.
- `./build.sh`: 0.
- `bash scripts/test.sh`: 0, ALL TESTS PASSED (new step 9 covers the 2x2 matrix, jobs equality, CSV, repeatability and an
  invalid sweep key).
- State hash before and after the refactor (example configuration, seed 7, 300 ticks): `1f613fac...7db80b`, unchanged.

## Measurements (release build, 12 cores, this container)
- `run` of 10,000 ticks, example configuration, seed 42: 1.08 s (9,264 ticks/s).
- Batch of 4 seeds x 1,000 ticks: 0.555 s with `--jobs 1`, 0.151 s with `--jobs 4`; summaries byte-identical.

## Deviations and decisions
- No `Send` check was needed: each worker builds its own `Simulation`; only the plain `RunResult` crosses threads.
- Summary layout is one run, one aggregate and the base configuration per line (valid JSON, easy to diff).

## Open items for REVIEW and later
- README does not describe `batch` yet; TASK-028 owns the README.
- ADR-0022 status stays Proposed until REVIEW decides.
- `scripts/check_adrs.sh` still stops at ADR-0016 (G-021-1).
- Launcher `./evosim` does not rebuild after source changes; run `./build.sh` first (G-020-1).

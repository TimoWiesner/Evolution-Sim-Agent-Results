# TASK-021 PLAN cycle 1: batch runs and export

Design: `docs/decisions/ADR-0022-batch-runs-and-sweeps.md` (Proposed). No product code was changed in PLAN.

## Starting point (checked in PLAN)
- `cargo test --workspace --locked` exit 0: evosim-core 395 passed, 1 ignored; evosim-cli unit 26 passed; `tests/run_cli.rs` 9 passed.
- `bash scripts/check_adrs.sh` exit 0 (checks=153 failed=0) before the ADR-0022 file was added.
- `git remote -v` has no entries.
- `crates/evosim-cli/src/main.rs` holds `run_run` (the run loop lives in the CLI). No `batch` command exists yet; `args.rs`
  parses `run` and `climate`. `ARCHITECTURE.md` plans `core::batch`.
- No `Rc`, `RefCell` or raw pointers in `evosim-core`, so `Simulation` is expected to be `Send` (check in IMPLEMENT).
- `Config` has `to_json`, `from_json` (unknown keys rejected by name), `save`; `config::json` has `parse`, `write` and an ordered
  `Value::Object`.

## Decisions (details in ADR-0022)
1. Sweeps: generic `--vary KEY=V1,V2,...` (repeatable) on any dotted configuration key except `seed`; cartesian product, first
   `--vary` slowest; values are JSON scalars; each case is validated up front (exit 2 before any run).
2. Layout: no `--vary` gives exactly CONTRACT section 2 (`DIR/seed-<seed>.json`); with `--vary`, `DIR/case-NN/seed-<seed>.json`.
3. `summary.json`: format `evosim-batch-summary` v1; `runs` (case, seed, params, file, ticks, initial, final, species, extinct,
   state_hash), `aggregates` per case and `overall` (per kind: final mean, min, max, sd, extinct count and fraction). No wall-clock
   value, so the same batch gives a byte-identical summary. Written last.
4. CSV: `--csv` writes `DIR/runs.csv` (one row per run) and `DIR/aggregates.csv` (one row per case and kind).
5. Shared run path: move the loop of `run_run` into a new core module `core::runner` (`runner.rs`); `run` and `batch` both use it.
   This is a refactor of TASK-019/020 code that must keep their tests green.
6. Parallelism: `--jobs J`, default 1, `std::thread::scope` with an atomic run index; results collected by index, so the output
   does not depend on J.
7. "Extinct" = zero living individuals at `tick_end`. Valid because nothing replenishes a kind (CONTRACT 5.3).

## Ordered steps for IMPLEMENT
1. `core::runner` (`runner.rs`): `run(&Config, ticks, sample_every, with_metrics) -> Result<RunOutput, String>`, the loop of
   `run_run` moved unchanged (same founders, same sampling, `elapsed_seconds` around the loop only). `lib.rs` exports it.
   `run_run` calls it. Gate: existing `run_cli` and `main.rs` tests unchanged and green.
2. `core::batch` (`batch.rs`, pure, no files): `Vary { key, values: Vec<Value> }`, `expand_cases(&[Vary]) -> Vec<Case>`,
   `case_config(base, case, seed) -> Result<Config, ConfigError>` (JSON tree edit, then `Config::from_json`), `Aggregate` and
   `aggregate(&[RunSummary]) -> KindAggregate`, `summary_json(...)`, `csv_runs(...)`, `csv_aggregates(...)`. Dependencies:
   `sim`, `metrics`, `runner`, `config`, `analytics` (none on UI).
3. `args.rs`: `Command::Batch(BatchArgs)` with `parse_batch` (every error case of ADR-0022 D1). `--help` text lists `batch`.
4. `main.rs`: `run_batch`: validate all cases first; build the run list (case-major); execute (sequential or `thread::scope`
   with `--jobs`); write `seed-*.json` (or `case-NN/seed-*.json`), then CSV if asked, then `summary.json`, each through
   `write_atomically` (move the helper to a small shared CLI module, or keep it in `main.rs`).
   Warn on stderr when the run count exceeds 1,000.
5. Tests: unit tests of `core::batch` and `core::runner`; `args` error cases; `crates/evosim-cli/tests/batch_cli.rs` with the
   matrix, the equality with `evosim run --seed S`, repeatability, jobs equality, CSV, errors (see ADR-0022 Verification).
6. `scripts/test.sh`: add a batch step (2 x 2 matrix, `--ticks 50`, repeat and compare). `./build.sh` after the change, then
   run the step against `./evosim`.
7. Docs: ADR-0022 Implementation record and status update at REVIEW; `docs/ARCHITECTURE.md` module rows (`core::runner`, `core::batch`);
   `docs/STATE.md` IMPLEMENT entry; `README.md` batch example (only if TASK-028 is not already changing that section; otherwise note
   it as a gap).
8. Measure: the time of one default-configuration run of 10,000 ticks on this machine (for TASK-027's baseline planning) and
   the `--jobs 1` vs `--jobs 4` wall time of a 4-run batch, recorded in ADR-0022 Consequences.

## Tests (summary)
- Hand-checkable: `aggregate` on final plants `[10, 20, 0]`: mean 10.0, min 0, max 20, sd sqrt(200/3), extinct 1 of 3.
- Case expansion: two keys with 2 and 3 values give 6 cases in the documented order.
- Matrix end-to-end: `--vary initial.plants=200,400 --seeds 1,2 --ticks 50` gives four runs; aggregates recomputed from the files.
- Equality with `run`: each batch run's `state_hash`, `final`, `totals`, `series` equals `evosim run --seed S` on the same configuration.
- Repeatability: byte-identical `summary.json`; per-seed files equal after removing the two time lines.
- Jobs: `--jobs 2` output equals `--jobs 1` output.
- Errors: exit 2, message, no `summary.json`.

## Risks
- Refactor risk: moving `run_run`'s loop changes the code path of `run` (mitigated: the existing tests are the guard; the
  `state_hash` of the example configuration is recorded before and after the move).
- Runtime: a sweep of many cases at 10,000 ticks is long; `--jobs` is the mitigation; the runtime is not a TASK-021 criterion.
- Thread safety: expected to compile with `Send`; if not, `--jobs` is refused (ADR-0022 D5).
- Summary size: one object per run; fine at benchmark sizes.
- Overall aggregate mixes sweep cases; documented, readers use `aggregates`.
- The launcher `./evosim` does not rebuild after source changes (TASK-020 gap G-020-1): after IMPLEMENT edits, run `./build.sh`
  before any black-box check, or the old binary runs silently.

## Gaps and assumptions
- Checked: every configuration key is a number (`real`/`int` in `config.rs`); no string, boolean or list key exists, so `--vary` values are numbers in practice (booleans and strings are still accepted by the parser and rejected by validation).
- Assumed: per-seed files for a batch do not include metrics (`--metrics` is not part of batch in this task).
- Not planned: charts (out of scope), `--save`/`--load` in batch (TASK-022), UI batch.

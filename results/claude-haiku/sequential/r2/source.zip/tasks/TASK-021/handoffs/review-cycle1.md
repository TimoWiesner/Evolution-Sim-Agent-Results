# TASK-021 REVIEW cycle 1: batch runs and export

Verdict: **PASS**. Machine-readable handoff: `review-cycle1.json`. Reviewed commit state: `8e6fc3c` (IMPLEMENT PASS), working tree clean at start.

## Acceptance criteria against evidence

1. **`./evosim batch` writes per-seed results and a summary per CONTRACT section 2.** Met.
   - Without `--vary`: `DIR/seed-S.json` and `DIR/summary.json` (checked black-box with `--seeds 2`).
   - Per-seed files are the `run` result schema (`batch_cli.rs` equality test and my check: `evosim run --seed 2` equals `batch --seeds 2` after removing the two time lines).
2. **At least one parameter varied over several values; 2 values x 2 seeds matrix tested.** Met.
   - `crates/evosim-cli/tests/batch_cli.rs` `matrix_writes_one_file_per_case_and_seed_and_a_summary_of_every_run`.
   - Black-box: `batch --vary initial.plants=200,400 --seeds 1,2 --ticks 50` gives `case-00/seed-{1,2}.json`, `case-01/seed-{1,2}.json`.
3. **`summary.json` lists every run with seed, parameters, ticks; aggregates mean/min/max of final population per kind and extinction counts.** Met.
   - Recomputed independently with `python3 -I` from the four per-seed files: every mean, min, max, population sd, extinct count and per-run `final`/`state_hash`/`tick_end` matched (`ALL True`).
   - Extinction path exercised: `initial.plants=0` gives `extinct` true for plants, herbivores, carnivores with `extinct_runs` 2 and fraction 1.0; the CSV extinct columns are 1.
4. **CSV export.** Met: `--csv` writes `runs.csv` (1 + 4 lines) and `aggregates.csv` (1 + 2x3 lines); values agree with `summary.json` (`batch_cli.rs` CSV test; black-box).
5. **Same batch twice gives the same summary apart from time measurements.** Met.
   - `summary.json` contains no time key (tested `!text.contains("elapsed")`).
   - Black-box: `summary.json`, `runs.csv`, `aggregates.csv` byte-identical across `--jobs 1` and `--jobs 2`; per-seed files identical after removing `elapsed_seconds`/`ticks_per_second` lines.

## Gates run in REVIEW (exit codes)

| Command | Exit | Notes |
|---|---|---|
| `PATH=/opt/rust/cargo/bin:$PATH cargo test --workspace --locked` | 0 | evosim-core 408 passed, 1 ignored; evosim-cli unit 32; batch_cli 8; run_cli 9. Log `/tmp/rev21_test.log`. |
| `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` | 0 | 0 warnings. |
| `./build.sh` | 0 | Rebuilt `target/release/evosim` and `dist/evosim` before black-box checks (gap G-020-1). |
| `bash scripts/test.sh` | 0 | "ALL TESTS PASSED" including the batch step 9. |
| `bash scripts/check_adrs.sh` | 0 | checks=153 failed=0. |
| `git remote -v` | - | no entries (local-only policy respected). |

## Black-box checks performed in REVIEW (against `./evosim`, scratch dirs under /tmp)

- Matrix and repeatability, jobs 1 vs jobs 2: as above.
- `run --seed 2` vs `batch --seeds 2` (no vary): equal except time lines.
- Recomputed aggregates with an independent Python script (`python3 -I`, script kept outside the workspace).
- Errors, all exit 2 with a message on stderr and no `summary.json` or out-dir created:
  - `--vary initial.plants=-1,5` → range error naming the key.
  - `--vary seed=1,2` → rejected.
  - `--vary initial.plants=1.5` → "expected integer, found real number".
  - `--vary herbivores.nothing=1` → unknown key named.
  - `--vary herbivores.reproduction_energy=-3` → out of range.
  - `--vary herbivores.reproduction_energy=60.0,true` → "expected number, found boolean".
  - `--vary initial.plants=1 --vary initial.plants=2` → key given twice.
  - `--seeds 1,1`, `--jobs 0`, `--ticks -1` → exit 2.
- `--ticks 0` works: one sample at tick 0 per run.

## Review of the code

- `core::runner::run` is the former `run_run` loop, unchanged in behaviour. Its tests cover metrics-on vs off equal hashes, series ticks, zero ticks, seed sensitivity.
- `core::batch` is pure. Case expansion is case-major with the first sweep slowest; `run_config` sets values through the JSON tree and re-validates with `Config::from_json`, so out-of-range values and unknown keys are rejected before any run (`execute` is only called after all configs are built).
- `execute` writes results by run index, so output does not depend on worker count or thread timing. Each worker builds its own `Simulation` (no shared mutable state).
- Writes happen in the order per-seed files, CSV, `summary.json` (last), each through `write_atomically`. A failed batch therefore has no `summary.json`.
- Aggregates use integer sums and population sd (divisor n) as specified in ADR-0022 D3.

## Findings (non-blocking)

1. Error messages for two invalid inputs are unclear: `--seeds 1,1` reports `invalid value '1' for --seeds` (it does not say "duplicate seed"), and a repeated key reports `invalid value 'initial.plants (key given twice)' for --vary`. Both exit 2 correctly. Suggested wording fix in a later task.
2. Re-using an `--out-dir` leaves stale `case-NN/` directories and files from an earlier, larger sweep. Documented as a risk by IMPLEMENT (ADR-0022 consequences / implement risks); not a must-have.
3. Not covered: the overall aggregate mixes cases when `--vary` is used. Documented in ADR-0022 D3; readers must use `aggregates`.
4. `scripts/check_adrs.sh` list still stops at ADR-0016 (G-021-1, carried).
5. README does not describe `batch` yet (G-021-3, TASK-028 owns README).
6. Timings only measured in this container (G-021-5).

None of these is an acceptance criterion of TASK-021.

## Doc updates made in REVIEW

- `docs/decisions/ADR-0022-batch-runs-and-sweeps.md`: status Proposed to Accepted, with the cycle 1 PASS reference; the implementation record now points here.
- `docs/decisions/README.md`: index line for ADR-0022 set to Accepted.
- `docs/STATE.md`: TASK-021 REVIEW cycle 1 entry.
- No product code, tests, `task.md`, `task.json`, `AGENTS.md`, `CONTRACT.md` or skills were changed. No commit made.

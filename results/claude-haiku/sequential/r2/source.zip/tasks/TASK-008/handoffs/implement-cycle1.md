# TASK-008 IMPLEMENT cycle 1: Organisms and the life cycle

Implemented ADR-0011 (Proposed) as planned in `tasks/TASK-008/handoffs/plan-cycle1.md`.

## Files
- `crates/evosim-core/src/entities.rs` (new): `Kind`, `OrganismId`, `DeathCause`, `Death`, `Traits`, `Tendencies`, `Birth`,
  `Organism` (private fields, getters, clamping `add_energy`/`drain_energy`/`damage`/`heal`), `Entities` (store, spawn, lookup,
  `living()`, Deaths phase, `check_balance`, `check_invariants`), `EntityError`.
- `crates/evosim-core/src/sim.rs`: `entities` field; `add_founder` (tick 0 only, `SimError::FounderAfterStart`), `entities()` and
  `entities_mut()` accessors; Deaths phase runs `deaths_phase(tick)`; Counters phase runs the balance and invariant checks as
  debug assertions; `from_parts` takes `Entities` as a fourth argument.
- `crates/evosim-core/src/lib.rs`: `pub mod entities;`.
- `scripts/check_adrs.sh`: ADR-0011 added to the checked list.
- `docs/decisions/ADR-0011-organisms-and-life-cycle.md`: implementation notes appended (status still Proposed).
- `docs/ARCHITECTURE.md`, `docs/STATE.md`: status and IMPLEMENT entries.

## Decisions taken in IMPLEMENT
- Trait ranges as in ADR-0011: speed [0,4], strength [0,10], fertility [0,1], max_lifespan [1,10000], max_health [1,100],
  tendencies aggression and caution [0,1]. Validation rejects NaN and infinities and names the trait; nothing is clamped.
- Energy in [0,100]; health in [0, max_health]. Event methods clamp; invalid amounts are a debug assertion and a no-op in release.
- `spawn_child` validates everything (tendency rule, energy and health ranges, parent count, parents alive) before changing state.
  Animals need two distinct parents; plants need one.
- `check_invariants` checks the per-cause death sums before the balance, so a broken per-cause count reports `Invariant`.

## Tests run (exit codes)
- `cargo test -p evosim-core --locked`: 0, 155 passed (32 new: 28 in entities.rs, 4 in sim.rs; a release-only test is not run in debug).
- `cargo test --workspace --locked`: 0, core 155 and cli 16 passed.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`: 0.
- `rustfmt --edition 2021 --check crates/evosim-core/src/entities.rs crates/evosim-core/src/sim.rs`: 0 (rustfmt applied first).
- `bash scripts/check_adrs.sh`: 0, checks=98 failed=0.
- `bash scripts/test.sh`: 0, ALL TESTS PASSED.
- `git remote -v | wc -l`: 0.

## Gaps
- G-037: `Simulation::new` does not place founders from `config.initial`. Needs genome-derived traits (TASK-009).
- G-038: `last_deaths` is per tick and not checkpointed (by design).
- G-039: trait ranges and `max_lifespan` are placeholders until TASK-009 maps genomes to traits and calibrates them.

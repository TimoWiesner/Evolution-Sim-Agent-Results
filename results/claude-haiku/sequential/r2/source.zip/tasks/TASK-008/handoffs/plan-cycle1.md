# TASK-008 PLAN cycle 1: Organisms and the life cycle

Decisions: `docs/decisions/ADR-0011-organisms-and-life-cycle.md` (Proposed). This file gives the ordered steps for IMPLEMENT.

## Environment checked in PLAN
- Run from /workspace with `PATH` including `/opt/rust/cargo/bin`.
- `cargo test -p evosim-core --locked` -> exit 0, 123 passed (baseline before any TASK-008 change).
- `git remote -v | wc -l` -> 0.
- No system package needed. No code changed in PLAN.

## Decisions in short
- Kinds: `Plant`, `Herbivore`, `Carnivore`.
- One `Organism` type, `Kind` tag, stored in a `Vec` sorted by id (ascending). Ids are `u64` from `Entities::next_id`, never reused.
- Traits (ranges in ADR-0011): speed [0,4], strength [0,10], fertility [0,1], max_lifespan [1,10000] ticks, max_health [1,100];
  animals also have `Tendencies { aggression [0,1], caution [0,1] }` as `Option`.
- Energy [0, 100] and health [0, max_health] change only through clamping methods; constructors reject out-of-range input.
- Death causes: OldAge, Starvation, Predation, Exposure, Injury. Cause is set once; the first cause wins.
- Deaths phase: ages every alive organism by 1, then assigns causes to organisms with health 0, energy 0 or age >= max_lifespan
  (in that order), removes them with one order-preserving `retain`, and appends `Death { id, kind, cell, tick, cause }` to `last_deaths`.
- Bookkeeping per kind since tick 0: `initial` (founders only), `births`, `deaths`, `deaths_by_cause`. Invariant
  `initial + births - deaths = living`, checked by `check_balance`.
- Same-tick rule: Reproduction (births) runs before Deaths, so newborns are checked in their birth tick and a parent that reproduces
  and dies in the same tick is recorded as both. Action phases skip dead organisms (`living()`).

## Ordered steps for IMPLEMENT
1. `crates/evosim-core/src/entities.rs` (new), `lib.rs` (`pub mod entities;`):
   `Kind` (+ `ALL`, `index()`), `OrganismId`, `Cell` reuse from `world.rs`, `DeathCause`, `Death`, `Traits` and `Tendencies`
   (`new` with validation, `RangeError` naming the trait), `Organism` (private fields, getters, `add_energy`, `drain_energy`,
   `damage`, `heal`, `is_alive`), `Entities` (`spawn_founder`, `spawn_child`, `get`, `living`, `deaths_phase(tick)`,
   `check_balance`, `check_invariants`, getters for counters). No RNG draws.
2. `crates/evosim-core/src/sim.rs`: field `entities: Entities`; `Simulation::new` creates an empty store; `Phase::Deaths` calls
   `deaths_phase(tick)`; `Phase::Counters` calls `check_balance` (debug assertion plus test); `add_founder(...)` allowed only at
   tick 0 (new `SimError::FounderAfterStart`); `entities()` accessor; `from_parts` takes `Entities` as well (default empty for now,
   TASK-022 extends it). Remove nothing from the trace behaviour.
3. Tests (see list below) in `entities.rs` and `sim.rs`. Randomised tests use the existing `rng::Rng` with fixed seeds (no new crate:
   `crates/evosim-core/Cargo.toml` has no dependencies and none are added).
4. `scripts/check_adrs.sh`: add ADR-0011 to the checked list (headings, alternatives, performance, testability, dist/ statements).
5. ADR-0011 status: stays Proposed until REVIEW; implementation notes added at the end of the ADR.
6. Docs: `docs/STATE.md` IMPLEMENT section, `docs/ARCHITECTURE.md` entities status line, `README` only if a command changes (none planned).
7. Run the commands listed under Tests and record exit codes in `implement-cycle1.md` and `.json`.

## Tests to write (IMPLEMENT)
- Kinds: `Kind::ALL` order, indices 0..2, three distinct kinds.
- Trait ranges: each trait accepts its min and max, rejects below min, above max, NaN and infinity; error names the trait.
- Animal rule: `Tendencies` required for herbivores and carnivores and rejected for plants (constructor error).
- Ids: 1,000 seeded operations of spawn and death; ids strictly increase; no id is reused; `living()` ascending.
- Energy/health: 10,000 seeded add/drain/damage/heal operations keep values in range; exact bounds (0 and cap/max) tested; non-finite and
  negative inputs are rejected (debug assertion in debug build; no-op in release, both tested through the public method behaviour).
- Death causes: starvation (energy to 0), old age (age == max_lifespan), predation / exposure / injury (damage to 0); first cause wins;
  dead organism skipped by `living()`; `Death` record fields correct; removal happens only in `deaths_phase`.
- Ageing: a founder with max_lifespan L takes actions in ticks 0..L-1 and dies in the Deaths phase of tick L-1 with `OldAge`
  (age is L after that phase's increment). Test uses L = 5.
- Bookkeeping: seeded sequence of at least 1,000 ticks with spawns and deaths; `check_balance` holds at every tick; founders counted in
  `initial`, not `births`.
- Same-tick rule: (a) child born with energy 0 dies in its birth tick; births and deaths both +1 in that tick; (b) parent with energy
  that makes it reproduce then starve in the same tick: child and parent both recorded in that tick.
- Parents: child with a dead or unknown parent id is rejected; generation = 1 + max(parent generations); founders generation 0.
- Simulation: `add_founder` ok at tick 0, error after one tick; `tick()` removes a starved founder and keeps the trace of an empty-phase
  run unchanged (existing sim tests still pass).
- Static: `grep -rn 'HashMap\|HashSet' crates/evosim-core/src/entities.rs` -> exit 1 (no match).

## Commands for IMPLEMENT (exact)
- `cargo test -p evosim-core --locked`
- `cargo test --workspace --locked`
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`
- `rustfmt --edition 2021 --check crates/evosim-core/src/entities.rs crates/evosim-core/src/sim.rs`
- `bash scripts/check_adrs.sh`
- `bash scripts/test.sh`
- `git remote -v | wc -l`

## Risks
- R1: Same-tick rule may surprise later tasks (reproduction before death). Mitigation: documented in ADR-0011 and tests; TASK-012/016
  must keep the Reproduction-before-Deaths order (ADR-0008).
- R2: Founders from `config.initial` are not placed by TASK-008. The `scripts/test.sh` and contract runs cannot show a populated world
  yet. Mitigation: spawn API is ready; TASK-009 or the first task that needs a populated world must place them deterministically. Gap G-037.
- R3: Trait ranges and `max_lifespan` centres are placeholders until TASK-009 maps genomes to traits and calibrates with config `*.max_age`.
- R4: `f32` arithmetic: clamping makes results depend on operation order. Operations are fixed in code; no fast-math.
- R5: Plants carry an unused `Option` for tendencies (documented trade-off).
- R6: Checkpoint (TASK-022) must save all new fields, or the state hash will not match the uninterrupted run.

## Gaps opened in PLAN (non-blocking unless REVIEW says otherwise)
- G-037: `Simulation::new` does not create the initial population from `config.initial` (needs genome-derived traits, TASK-009).
- G-038: `last_deaths` is per tick and not checkpointed (by design); the cumulative per-cause counts are.
- G-039: trait ranges are chosen before genomes exist; TASK-009 must confirm or change them in an ADR update before code changes.

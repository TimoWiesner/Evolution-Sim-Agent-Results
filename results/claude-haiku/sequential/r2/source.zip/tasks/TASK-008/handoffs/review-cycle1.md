# TASK-008 REVIEW cycle 1: Organisms and the life cycle

Verdict: **PASS**. Fresh-process review of the IMPLEMENT commit (6c1cc28) against the task's six acceptance criteria.

## Criteria
1. Three kinds: `Kind::{Plant, Herbivore, Carnivore}`, `Kind::ALL`. Test `kinds_are_three_distinct_values_in_fixed_order`.
2. ID, kind, cell, age, energy, health, traits, parents, generation: all present as private fields with getters. IDs come from a counter that is never reused. Tests: `ids_strictly_increase_and_are_never_reused_over_random_operations`, `generation_is_one_plus_the_largest_parent_generation`.
3. Traits: speed, strength, fertility, max_lifespan, max_health; animals also have aggression and caution. Tests: `each_trait_accepts_its_bounds_and_rejects_outside_values`, `tendencies_accept_bounds_and_reject_outside_values`, `animals_need_tendencies_and_plants_reject_them`.
4. Energy and health stay in range (clamping, validated constructors). The dead are removed in the Deaths phase with a recorded cause and are skipped by `living()`. Tests: `energy_and_health_stay_in_range_over_random_operations`, `energy_and_health_hit_their_bounds_exactly`, `first_cause_wins`, `dead_organism_is_skipped_by_living_until_removed`, `death_record_has_cell_kind_tick_and_cause`, `tick_removes_a_starved_founder_and_records_it`.
5. Per-kind births and deaths since tick 0: `initial`, `births`, `deaths`, `deaths_by_cause`, with `check_balance`. Test `bookkeeping_balances_at_every_tick_over_1000_ticks`.
6. One documented same-tick rule (Reproduction before Deaths, ADR-0011). Tests `child_born_with_zero_energy_dies_in_its_birth_tick` and `parent_that_reproduces_then_starves_in_the_same_tick_is_both_birth_and_death`.

## Commands (fresh process, all exit 0)
- `cargo test -p evosim-core --locked`: 155 passed.
- `cargo test --workspace --locked`: core 155, cli 16.
- `cargo test -p evosim-core --locked --release entities`: 28 passed (includes the release-only no-op test).
- clippy on core and cli, all targets: no warnings.
- rustfmt check on the two touched files: clean.
- `bash scripts/check_adrs.sh`: 98 checks, 0 failed.
- HashMap/HashSet grep in entities.rs: no match. `git remote -v`: 0 remotes.

## Notes
- Founders count in `initial`, not `births`. ADR-0011 documents this. A stricter reading of "births since tick 0" could expect founders to count too. Not treated as a failure.
- A removed organism's cause is kept in the tick's `Death` record and in the cumulative counters, not on the organism (it is gone).
- G-040: `get_mut`, `heal`, `add_energy` and `set_cell` accept dead organisms. The never-acts-again rule holds because action phases use `living()`. Recommend a living-only mutable accessor in TASK-013 to TASK-016.
- G-041: `set_cell` has no torus membership check.
- ADR-0011 status changed to Accepted; `docs/STATE.md` has a REVIEW section.

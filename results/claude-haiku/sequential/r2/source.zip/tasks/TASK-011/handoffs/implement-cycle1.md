# TASK-011 IMPLEMENT cycle 1: plant growth and resources

Implements `docs/decisions/ADR-0012-plant-resources-and-growth.md` (still Proposed; Accepted only on REVIEW PASS).

- Code: `crates/evosim-core/src/ecology.rs` (new), `entities.rs` (`living_mut`), `sim.rs` (`World.resources`, Plants arm), `lib.rs`.
- Docs: ADR-0012 (cold-tolerance sign fix, implementation notes, testability and dist statements), ADR-0004 (plant meaning of slots 5-7),
  `scripts/check_adrs.sh` (ADR-0012 in list), `docs/ARCHITECTURE.md` (IMPLEMENT note), `docs/STATE.md` (IMPLEMENT section).
- Verified commands and exit codes: see `implement-cycle1.json` `tests`. All exit 0.
- Not done in this phase: release timing at 2,000 plants; full `scripts/test.sh` run.
- Verdict N/A (IMPLEMENT). Review must check each Must-have against the tests named in the JSON and the ADR notes.

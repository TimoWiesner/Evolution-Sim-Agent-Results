# TASK-011 PLAN cycle 1: plant growth and resources

Scope: plan only. No product code, Cargo file, task file, benchmark file or commit was touched.
Documentation changed: `docs/decisions/ADR-0012-plant-resources-and-growth.md` (new, Proposed), `docs/decisions/README.md`
(one index line), `docs/STATE.md` (PLAN section), `docs/ARCHITECTURE.md` (TASK-011 PLAN note in the module map).

## 1. State found on entry (verified in this phase)

- `AGENTS.md`, `docs/STATE.md`, `docs/PROJECT.md`, `docs/CONTRACT.md`, `docs/ARCHITECTURE.md`, `tasks/TASK-011/task.md|json`,
  `.agents/skills/plan/SKILL.md` were read. Dependencies TASK-006 (climate), TASK-008 (entities), TASK-009 (genome) were read
  through their REVIEW handoffs. TASK-010 (spatial index) is PASS and is not needed by the plant rules.
- `git status` clean on `main`; `git remote -v | wc -l` = 0.
- Baseline: `cargo test -p evosim-core --locked` -> exit 0, `206 passed; 0 failed; 1 ignored` (PATH includes `/opt/rust/cargo/bin`).
- `crates/evosim-core/src/ecology.rs` does not exist; `lib.rs` has no `pub mod ecology`. `Phase::Plants => {}` in `sim.rs::run_phase`.
- APIs used (verified in source):
  - `climate.rs`: `Climate::conditions(cell) -> Conditions { temperature: f32, precipitation: f32 }` (last advanced tick),
    `Climate::seasonal_conditions`, `ClimateParams`; `Climate::new(&torus, seed, params)`.
  - `world.rs`: `Torus::index(Cell) -> usize`, `Torus::cell_count()`, `Torus::cell_from_index(usize)`, `Cell` is `Copy + Eq + Hash`.
  - `entities.rs`: `Entities::living()`, `get`, `get_mut`, `spawn_founder`, `deaths_phase(tick)`, `check_balance`, `check_invariants`;
    `Organism` mutators `add_energy`, `drain_energy` (drain to 0 gives `Starvation`), `damage(x, cause)`, `heal(x)`; getters
    `kind, cell, age, energy, health, traits, genome, is_alive`; `ENERGY_MAX = 100.0`.
  - `genome.rs`: `Genome::trait_means() -> [f64; 8]` (block means in `[0,1]`), `Genome::ploidy()`, `random_genome(ploidy, &mut Rng)`.
  - `sim.rs`: `World { topology, climate }` (pub fields), `Simulation::new(&Config)`, `from_parts(tick, rng_state, world, entities)`,
    `populate_initial(&Config)` (tick 0 founders, energy 50, full health), `add_founder`, `entities()`, `entities_mut()`, `world()`,
    `tick()`, `run(n)`, `PHASE_ORDER`.
  - `config.rs`: `Config { seed, world: {width, height}, initial: {plants, herbivores, carnivores}, climate: {season_length, weather_amplitude}, genetics: {mutation_rate, mutation_strength} }`.
- Gaps carried into this task: G-037 (CLI does not place founders; TASK-019), G-040 (no living-only mutable accessor),
  G-041 (`set_cell` has no torus check), G-043 (populate_initial second call), G-045 (checkpoint), G-046 (spatial stale overlay).
  Plants do not move, so G-047 does not affect this task.

## 2. Decisions (full text in ADR-0012)

D1. **Resource model: one per-cell pool.** `World.resources: ResourceField` with one `f32` per cell in `[0, 100]`. The pool is the
only energy source for plants. It is refilled each tick toward a climate capacity `cap = 100 * f_T(T, 0.5) * f_W(P, 0.5)` at
rate 0.05 per tick. Light, nutrients and a separate water pool are not modelled; the simplification is that "climate
suitability" stands in for light, water and nutrients together. Alternatives and reasons: ADR-0012 section "Considered alternatives".

D2. **Gain depends on temperature and water.** `g = f_T * f_W`: temperature factor is a triangle with lower limit `L = -5 + 10*cold_tol`,
optimum 20 C, upper limit 40 C; water factor is 0 below 20 mm/yr and `P/(P+K)` above, with `K` in `[50, 400]` from drought tolerance.
A plant's demand is `4.0 * g * (1 - energy/100)`. `g = 0` means no growth at all.

D3. **Competition by proportional sharing.** Per cell, demands are summed; if the sum exceeds the pool, each plant takes its share
`demand * R / D`. Result is independent of id order and never overdraws the pool. Carrying capacity emerges from the pool
regeneration and this sharing; no rule looks at global counts.

D4. **Plant traits (5 of them, 3 new).** From the genome (ploidy 1): `cold_tolerance` (slot 5), `drought_tolerance` (slot 6),
`yield` (slot 7, `0.5 + 0.5*mean`, energy per resource unit, `<= 1`). Kept from ADR-0011: `max_health` (biomass cap),
`max_lifespan` (age limit). Not used by plants in TASK-011: speed, strength, fertility (fertility belongs to TASK-012).
Amendment of ADR-0004: slots 5, 6, 7 mean plant traits for plants (aggression, caution, reserved for animals).

D5. **Growth and maintenance.** Each tick, a plant: gains energy from its take; pays maintenance `0.5 + 0.01*health`; if
`g > 0` and energy above reserve 40, grows health by `min(1.0*g, max_health - health)` at 1 energy per health unit; if `g == 0`
takes 2.0 `Exposure` damage. Energy 0 gives `Starvation`, age at `max_lifespan` gives `OldAge` (existing ADR-0011 rules).

D6. **Plant phase is deterministic and draws no random numbers.** Plants in ascending id order; the phase returns
`PlantReport { taken, gained, regenerated }` for tests and metrics.

D7. **Parameters are constants in `ecology.rs`**, not configuration keys. Changing the fixed config contract is out of scope.

D8. **Genome decode per tick, not cached.** Avoids drift between a cache and the genome. Cost measured in IMPLEMENT (risk R3).

## 3. Ordered implementation plan (for IMPLEMENT; no code yet)

1. **`crates/evosim-core/src/entities.rs`**: add `Entities::living_mut(&mut self) -> impl Iterator<Item = &mut Organism>`
   (alive only, ascending id). Document it as the living-only mutable accessor that closes the convention part of G-040 for
   the plant phase. Do not change `get_mut`.
2. **`crates/evosim-core/src/ecology.rs` (new)**, depends only on `climate`, `entities`, `genome`, `world`:
   - `pub const` constants listed in ADR-0012 (CAP_MAX, REGEN_RATE, T limits, P_MIN, K range, REQUEST_MAX, MAINT_*, GROWTH_*,
     HOSTILE_DAMAGE, NEUTRAL).
   - `pub struct PlantTraits { cold_tolerance, drought_tolerance, yield_per_unit: f32 }`, `PlantTraits::from_genome(&Genome)`.
   - `pub struct GrowthFactors { temperature: f32, water: f32 }` with `product()`; `pub fn growth_factors(cond: Conditions, traits: &PlantTraits) -> GrowthFactors`.
   - `pub fn temperature_factor(t: f32, cold_tolerance: f32) -> f32`, `pub fn water_factor(p: f32, drought_tolerance: f32) -> f32`.
   - `pub fn capacity(cond: Conditions) -> f32` (neutral tolerances, `CAP_MAX * f_T * f_W`).
   - `pub struct ResourceField { values: Vec<f32> }`: `full(&Torus, &Climate)` (initial pool = capacity at tick 0),
     `get(&self, cell)`, `values()`, `from_values(&Torus, Vec<f32>) -> Result<_, EcologyError>` for checkpoint restore.
   - `pub struct PlantReport { pub taken: f64, pub gained: f64, pub regenerated: f64 }`.
   - `pub fn plants_phase(entities: &mut Entities, resources: &mut ResourceField, climate: &Climate) -> PlantReport`:
     pass 1 computes per-plant demand (ids ascending) and per-cell demand sums in `Vec<f32>` of cell count; pass 2 applies
     shares, gain, maintenance, growth, hostile damage (via `living_mut`); pass 3 regenerates every cell.
   - `EcologyError` for `from_values` length mismatch and non-finite or negative values.
3. **`crates/evosim-core/src/lib.rs`**: `pub mod ecology;`.
4. **`crates/evosim-core/src/sim.rs`**:
   - `World` gains `pub resources: ResourceField`; `Simulation::new` builds it with `ResourceField::full(&topology, &climate)`.
   - `from_parts` takes the world as given (it already carries resources).
   - `run_phase`: `Phase::Plants => { let _ = ecology::plants_phase(&mut self.entities, &mut self.world.resources, &self.world.climate); }`
     (the report is discarded here; metrics later). Field borrows are disjoint, so no clone.
   - Keep `populate_initial` unchanged (founders have energy 50, full health).
5. **Documentation**: `docs/ARCHITECTURE.md` (module row `core::ecology` gets its TASK-011 status and the energy source statement;
   `World` gains `resources`), `docs/decisions/ADR-0004-genome-and-species.md` (amendment: slots 5, 6, 7 for plants),
   `docs/decisions/ADR-0012` status to Accepted at REVIEW PASS only, `docs/decisions/README.md` index line,
   `scripts/check_adrs.sh` (add `ADR-0012-plant-resources-and-growth.md` to the list, as ADR-0011 was added in TASK-008).
6. **Tests** (see section 4), then run the command set in section 5.

Files expected to change in IMPLEMENT: `crates/evosim-core/src/ecology.rs` (new), `lib.rs`, `entities.rs`, `sim.rs`,
`docs/ARCHITECTURE.md`, `docs/decisions/ADR-0004`, `docs/decisions/ADR-0012`, `docs/decisions/README.md`, `scripts/check_adrs.sh`,
`docs/STATE.md`, `tasks/TASK-011/handoffs/implement-cycle1.{md,json}`.

## 4. Tests planned (each Must-have mapped)

Must-have 1, energy from the cell's temperature and water:
- `growth_factors_zero_when_too_cold_or_too_dry`, `temperature_factor_triangle_shape`, `water_factor_monotone_and_bounded` (unit).
- `ecology_factors_in_unit_range_over_random_inputs` (seeded, 10,000 samples, property style, no new crate).

Must-have 2, the required test (slower or no growth in cold or dry cells):
- `same_plant_grows_less_in_cold_cell` and `same_plant_grows_less_in_dry_cell` (pure: favourable vs cold/dry `Conditions`, same traits).
- `same_plant_does_not_grow_in_too_cold_cell` (`g == 0`, health does not rise).
- `two_cells_polar_vs_equator_same_genome` (Simulation test: `weather_amplitude = 0`, two identical-genome plants alone in one
  polar-row cell and one equator-row cell, run N ticks; the equator plant has more energy/health or more ticks alive than the polar one).

Must-have 3, limited resources and competition:
- `pool_never_negative_and_taken_within_pool` (random sequence of cells/demands).
- `crowded_cell_shares_pool_proportionally` (two plants with different demand, one cell; shares ratio equals demand ratio).
- `plants_in_one_cell_cannot_exceed_pool_plus_regeneration` (many plants in one cell, one tick: sum taken <= pool before + regeneration).
- `plant_population_stays_bounded_by_capacity` (plant-only run of 500 ticks, 16x12 torus, fixed seed; count stays below the cap-based bound and above zero).

Must-have 4, ageing and death:
- `plant_dies_of_old_age_at_max_lifespan` (existing rule through `Simulation`).
- `plant_starves_when_pool_is_empty` (pool set to 0 by test helper in the same module; drain to 0 gives `Starvation`).
- `plant_in_hostile_cell_dies_of_exposure` (`g == 0`; health reaches 0; cause `Exposure`).

Must-have 5, documented energy source and no energy without it:
- `energy_gain_never_exceeds_resource_taken` (`gained <= taken` in the report over a seeded 500-tick run; `yield <= 1` test on
  `PlantTraits::from_genome` over random genomes).
- `pool_change_equals_regeneration_minus_take` (per tick: pool sum after = before + regenerated - taken, within f64 tolerance).
- `no_plant_energy_without_pool` (a cell with pool 0 and regeneration disabled in the test gives zero gain).

Must-have 6, genome traits influence growth or tolerance:
- `cold_tolerance_gene_changes_growth_in_cold_cell` (same cell, two genomes with cold mean 0.9 vs 0.1 via slot-5 loci set to
  255 / 0: the tolerant one grows, the other gets `g = 0`).
- `drought_tolerance_gene_changes_growth_in_dry_cell` (same with slot 6).
- `yield_gene_changes_energy_per_unit` (slot 7).
- `traits_decode_in_range_for_random_genomes` (10,000 seeded genomes, all three in `[0,1]`, yield in `[0.5,1]`).

Determinism and integration (regression):
- `plant_phase_is_deterministic` (same seed, same state after 200 ticks with plants; equal `state`/`PartialEq`).
- `rng_state_unchanged_by_plant_phase` (the plant phase draws nothing; RNG state equal before and after the phase).
- `index_and_balance_hold_over_plant_run` (existing `check_balance`/`check_invariants`/`check_spatial` pass over 200 ticks with plants).
- Existing 206 core tests still pass; the state hash regression values, if any, are re-recorded only if they change (none planned).

## 5. Commands for IMPLEMENT and REVIEW

- `export PATH=/opt/rust/cargo/bin:$PATH; cargo test -p evosim-core --locked` (expect 206 + new tests, 1 ignored).
- `cargo test --workspace --locked`
- `cargo test -p evosim-core --locked ecology` (focused)
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`
- `rustfmt --edition 2021 --check crates/evosim-core/src/ecology.rs crates/evosim-core/src/entities.rs crates/evosim-core/src/sim.rs`
- `bash scripts/check_adrs.sh`, `bash scripts/test.sh`, `git remote -v | wc -l` (expect 0).
- Benchmark (timing, recorded in ARCHITECTURE): `cargo test -p evosim-core --release --locked -- --ignored --nocapture` only if a
  plant benchmark test is added; otherwise a measured per-tick timing of 2,000 plants is recorded from a short release run.

## 6. Risks

R1. Founder tolerance spread is small (block means of 16 uniform bytes, sd about 0.07), so early plants are almost identical.
Selection on tolerance needs TASK-012 reproduction and mutation to act. Not a TASK-011 failure: the must-have needs genome
traits to matter, and the mapping does that.
R2. Plant `max_lifespan` maps to about 5,000 ticks on average (ADR-0011 range), so old age is rare in 10,000-tick runs.
Calibration belongs to TASK-017/018; recorded, not changed here.
R3. Per-tick genome decode for every plant (128 byte reads each) and two climate queries per plant. Measured in IMPLEMENT; if it
costs more than 10 % of a 2,000-entity tick, cache `PlantTraits` in `Organism` (would need an ADR-0011 amendment).
R4. Proportional sharing ignores plant size and height. Acceptable simplification; documented in ADR-0012.
R5. Climate capacity uses `Climate::conditions`, which follows `weather_tick`. The plant phase runs after the Climate phase, so
values are for the current tick. Tests must set `weather_amplitude = 0` where the expected values are exact.
R6. Regeneration is the only inflow and is climate-bounded. A reviewer may still ask whether a pool that refills itself is an
energy source "without a source". ADR-0012 states the source explicitly (the climate capacity, a bounded function of temperature
and precipitation). The test `pool_change_equals_regeneration_minus_take` shows where every unit comes from.
R7. Checkpoint (TASK-022) must save `World.resources`; `from_parts` alone does not persist it. Recorded for TASK-022.
R8. Herbivores (TASK-014) will remove plant energy by grazing. The pool is shared; the grazing rule must go through the same
pool so the invariant holds. Noted for TASK-014.
R9. `living_mut` makes a living-only mutable accessor available; `get_mut` still accepts dead organisms (G-040 remains open
for other callers).

## 7. Gaps and reviewer questions

- G-040 partly addressed (new `living_mut`); `get_mut`, `heal`, `add_energy`, `set_cell` unchanged.
- G-037 (founders from config in CLI) remains open for TASK-019; the tests use `populate_initial` directly.
- Reviewer question: is `REQUEST_MAX`, `REGEN_RATE` and the temperature and water limits plausible? They are chosen values
  (not measured). They are documented as constants in ADR-0012 and can be calibrated in TASK-017/018.

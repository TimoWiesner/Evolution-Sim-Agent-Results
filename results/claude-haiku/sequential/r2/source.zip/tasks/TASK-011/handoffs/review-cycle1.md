# TASK-011 REVIEW cycle 1: plant growth and resources

Verdict: PASS (all six acceptance criteria met by code and tests; gaps non-blocking).

## Criteria check
1. Energy from cell resources, gain depends on temperature and water: `ecology.rs` `plants_phase`; demand = 4 * g * (1 - energy/100), g = f_T * f_W. Gain = take * yield.
2. Cold/dry plant grows slower or not at all: `same_plant_grows_less_in_cold_cell_than_warm_cell`, `cold_intolerant_plant_does_not_grow_in_too_cold_cell`, `drought_tolerance_gene_changes_growth_in_dry_cell`, `growth_factors_zero_when_too_cold_or_too_dry`.
3. Limited resources and competition: `two_plants_in_one_cell_share_the_pool_in_proportion_to_demand`, `crowded_cell_cannot_take_more_than_its_pool`, `pool_change_equals_regeneration_minus_take_over_run` (500 ticks).
4. Ageing and death: `plant_dies_of_old_age_at_max_lifespan`, `plant_starves_when_pool_is_empty`, `plant_in_hostile_cell_dies_of_exposure`.
5. Documentation of the energy source: ADR-0012 "Energy source" and ARCHITECTURE TASK-011 notes. Energy appears only as taken * yield with yield <= 1.
6. Genome traits: slots 5, 6, 7 in `PlantTraits::from_genome`; tests `genome_slots_change_tolerance_and_yield`, `cold_tolerance_gene_changes_growth_in_coldest_cell`.

## Commands run (exit 0 each)
- `cargo test --workspace --locked`: 228 core passed, 1 ignored; 16 CLI passed.
- `cargo test -p evosim-core --locked ecology`: 22 passed.
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`.
- `bash scripts/check_adrs.sh`: checks=109 failed=0.
- `git remote -v | wc -l`: 0.

## Probe (scratch copy in /tmp, removed afterwards)
Seeds 1-3, 64x48: sub-zero cells exist (about -3 to -5 C) and their pool is 0 at tick 0. A cold-tolerant plant there grows
only from stored energy (50 -> 42.7 energy, 10 -> 11.3 health over 10 ticks), with no gain from the pool. This is the documented
ADR-0012 limitation (gap G-051), not a violation of energy conservation.

## Non-blocking gaps
- G-049: ADR-0012 promised a plant-only population test; not implemented.
- G-050: one gene test uses `>=`, which can pass with both plants dead.
- G-051: tolerances cannot widen the habitable range (neutral-capacity pool is empty at T <= 0 C or P < 20).
- Release timing at 2,000 plants not measured; full `scripts/test.sh` (setup.sh, build.sh, dist) not run in REVIEW.

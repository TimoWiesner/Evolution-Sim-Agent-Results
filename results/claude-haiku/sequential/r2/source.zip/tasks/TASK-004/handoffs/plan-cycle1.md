# TASK-004 PLAN cycle 1 — notes

Scope: grid coordinates and toroidal topology (`tasks/TASK-004/task.md`). No feature code changed in PLAN.
Decisions are in `docs/decisions/ADR-0007-torus-topology-and-distance.md` (Proposed). This file is the ordered recipe
for IMPLEMENT.

## Inputs read
AGENTS.md; docs/PROJECT.md; docs/CONTRACT.md (sections 1, 3, 5, 6); docs/STATE.md; docs/ARCHITECTURE.md (module table
`core::topology`, determinism rules); ADR-0001, ADR-0003 (per-axis torus distance and box query), ADR-0005, ADR-0006
(world.width/height range 1..4096); tasks/TASK-004/task.md and task.json; TASK-002 and TASK-003 handoffs (plan,
implement, review); dependent tasks TASK-005 (climate; depends on 003 and 004), TASK-006 (seam test), TASK-010
(spatial index; depends on 004). No TASK-004 handoffs existed before this one.

## Environment (verified in PLAN)
- `cargo 1.100.0`, `rustc 1.100.0`; `git remote -v | wc -l` = 0.
- `cargo test -p evosim-core --locked` exit 0 (44 tests before this task: 43 config tests plus the contract test). Log `/tmp/plan-t4-baseline.log`.
- `bash scripts/check_adrs.sh` checks=54 failed=0, exit 0 (before the ADR-0007 file was added; that script only checks
  ADR-0001..0004, so ADR-0007 adds no checks).
- No system packages needed. None installed.

## Decisions (summary; full text in ADR-0007)
1. Distance: Chebyshev `max(|dx|,|dy|)` on the torus, each axis by the shortest wrapped displacement. Matches the
   square query box of ADR-0003.
2. Tie rule: for an even axis length L and displacement exactly L/2, the displacement is `+L/2`.
3. Types: `Torus { width: u32, height: u32 }` (both >= 1); `Coord { x: i64, y: i64 }` (any integer, unwrapped);
   `Cell { x: u32, y: u32 }` (wrapped); `Offset { dx: i64, dy: i64 }` (signed displacement); `Direction` (8 compass
   steps with `Offset`).
4. Neighbourhood: all cells with distance <= r, centre included, each once, ascending index order `y*W + x`.
   Radius is `u32`; any radius is valid.

## Ordered IMPLEMENT recipe
1. `crates/evosim-core/src/lib.rs`: add `pub mod world;` (keep `pub mod config;` and `CONTRACT_VERSION`).
2. Create `crates/evosim-core/src/world.rs` with:
   - `#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]` on `Cell`, `Coord`, `Offset`, `Direction`; `Torus` also `Copy`.
   - `pub enum TopologyError { ZeroSize { width: u32, height: u32 } }` implementing `Display` and `std::error::Error`.
   - `Torus::new(width, height) -> Result<Torus, TopologyError>`; `width()`, `height()`, `cell_count() -> usize`
     (`W*H` as usize).
   - `Torus::wrap(Coord) -> Cell` using `rem_euclid` on `i64`, then `as u32` (value < W <= u32::MAX).
   - `Torus::index(Cell) -> usize` (`y*W + x`) and `Torus::cell_at(usize) -> Cell` (inverse).
   - `Torus::delta(from: Cell, to: Cell) -> Offset` per axis: `d = (b - a).rem_euclid(L)` in i64; if `2*d > L` then
     `d - L` else `d`.
   - `Torus::distance(from, to) -> u32` = `max(|dx|, |dy|)` (value <= 2^31, fits u32).
   - `Torus::step(cell, Direction) -> Cell` = `wrap(Coord { x: cell.x + dx, y: cell.y + dy })`.
   - `Torus::neighbours(centre: Cell, radius: u32) -> Vec<Cell>`: distinct wrapped xs and ys (full range when
     `2r+1 >= L`), sorted ascending, then product in row-major order. Capacity hint `min(cell_count, (2r+1)^2)`.
   - Inline `#[cfg(test)] mod tests` in `world.rs` (no new files; no test crates).
3. Tests (names are the acceptance check; each must exist):
   - Wrap: `wrap_negative_and_zero`, `wrap_far_outside_world` (values like `-3W-1`, `5W+W-1`), `wrap_i64_extremes_do_not_overflow`.
   - Edges and corners: `step_east_from_right_edge_wraps_to_left`, `step_west_from_left_edge_wraps_to_right`,
     `step_south_and_north_wrap_on_height`, `step_all_four_corners_wrap_diagonally`.
   - Shortest path: `delta_takes_short_way_across_edge` (W=10: 0->9 is -1; 1->8 is -3), `delta_tie_on_even_axis_is_positive`
     (W=10: 0->5 is +5; 5->0 is +5), `distance_is_symmetric_and_chebyshev`, `distance_bounded_by_half_world`.
   - Degenerate worlds: `one_by_one_world_everything_is_the_same_cell` (all steps return (0,0), distance 0,
     `neighbours` = [(0,0)] for any radius), `one_by_n_and_n_by_one_wrap` (1x5 and 5x1 steps and neighbours).
   - Non-square: `non_square_world_axes_wrap_independently` (e.g. 7x3).
   - Neighbourhood: `neighbours_radius_zero_is_centre`, `neighbours_have_no_duplicates_and_are_ascending`,
     `neighbours_radius_larger_than_world_visits_each_cell_once` (r = 100 on 3x4 gives 12 cells),
     `neighbours_cross_all_four_edges` (corner cell radius 1 gives 9 cells on a 5x5 world, including the wrapped ones),
     `neighbours_match_brute_force` (all W,H in 1..=7, centre every cell, r in 0..=10, compare with
     `distance <= r` over all cells, sorted vectors equal).
   - Seeded random: `distance_triangle_inequality_seeded` (LCG `state = state*6364136223846793005 + 1442695040888963407`
     with wrapping_mul; 2000 triples on random sizes 1..=50) and `delta_antisymmetric_except_tie` (for non-tie
     pairs `delta(a,b) == -delta(b,a)`).
   - Errors: `zero_size_is_error` (`Torus::new(0,5)` and `(5,0)`).
4. Documentation after code:
   - `docs/ARCHITECTURE.md`: the module row is already updated in PLAN; add a short "Topology conventions" line only
     if IMPLEMENT changes names.
   - `docs/decisions/ADR-0007...md`: status to Accepted only at REVIEW; IMPLEMENT adds an "Implementation notes"
     paragraph with any deviation.
   - `docs/STATE.md`: IMPLEMENT block with exact commands and exit codes.
5. Do not change `config.rs`, `config/*`, the CLI, UI or scripts.

## Tests to run in IMPLEMENT (record exact command and exit code)
- `cargo test -p evosim-core --locked` (exit 0; expect 44 + the new `world` tests).
- `cargo clippy -p evosim-core --locked --all-targets` (exit 0, no `warning` lines).
- `cargo test --workspace --locked` (exit 0).
- `bash scripts/check_adrs.sh` (exit 0, checks=54 failed=0).
- `bash scripts/test.sh` (exit 0, "ALL TESTS PASSED").
- `git remote -v | wc -l` (0).

## Risks
- Chebyshev perception is a square; a round field would need a different filter (ADR-0007 alternatives). Calibration
  is TASK-010 / ecology tasks.
- Tie rule makes `delta` non-antisymmetric on even axes at exactly half a world; documented and tested.
- `Coord` uses `i64`; if the later spatial code needs wider coordinates, the wrap function is the only place to change.
- The module name in ARCHITECTURE (`core::topology`) and file (`world.rs`) differ by design (the table lists both); the
  code uses file `world.rs`, exported as `evosim_core::world`.
- Not verified: performance of `neighbours` at large radius (bounded by `W*H`; measured in TASK-010 if needed).

## Non-goals (unchanged from task.md)
- Organisms, spatial index (TASK-010), climate (TASK-005/006).

# TASK-004 REVIEW cycle 1 — notes

Verdict: PASS. All five acceptance criteria in tasks/TASK-004/task.md are met and each is covered by named tests in
crates/evosim-core/src/world.rs. Reviewed commit 93f82e2 (IMPLEMENT cycle 1); the working tree was clean at the start.

## Commands run (from /workspace, PATH includes /opt/rust/cargo/bin)
- `cargo test -p evosim-core --locked` -> exit 0, 74 passed, 0 failed (44 existing + 30 world tests).
- `cargo clippy -p evosim-core --locked --all-targets` -> exit 0, 0 `warning` lines.
- `cargo test --workspace --locked` -> exit 0 (core 74, cli 9, doc-tests 0).
- `bash scripts/check_adrs.sh` -> exit 0, checks=54 failed=0 (run before the ADR status edit; the script does not check the status line).
- `git remote -v | wc -l` -> 0.
- `bash scripts/test.sh` was NOT re-run in REVIEW; IMPLEMENT recorded exit 0 and nothing in world.rs touches setup/build.

## Acceptance criteria
1. Any integer coordinate maps to a valid cell (negatives, several worlds away, i64 extremes): `Torus::wrap` uses
   `rem_euclid` on i64; tests `wrap_negative_and_zero`, `wrap_far_outside_world`, `wrap_i64_extremes_do_not_overflow`,
   `wrap_identity_for_valid_cells`. Reviewed the arithmetic: `i64::from(width)` with width <= u32::MAX, result < width, `as u32` is lossless.
2. Shortest way per axis, across an edge when shorter: `axis_delta` gives the representative of (b-a) mod L in (-L/2, L/2].
   Tests `delta_takes_short_way_across_edge`, `delta_tie_on_even_axis_is_positive`, `delta_odd_axis_has_no_tie`,
   `distance_is_symmetric_and_chebyshev`, `distance_bounded_by_half_world`, seeded `delta_antisymmetric_except_tie` and
   `distance_triangle_inequality_seeded`. The tie case (exactly L/2 on an even axis) is the only non-antisymmetric case; the test
   confirms both directions return +L/2. Distance magnitude is the same in both directions.
3. Neighbours without duplicates, radius larger than the world: `axis_window` returns the full axis when 2r+1 >= L, otherwise
   2r+1 < L consecutive residues, which are distinct. Tests `neighbours_have_no_duplicates_and_are_ascending`,
   `neighbours_radius_larger_than_world_visits_each_cell_once` (r=100 and u32::MAX), `neighbours_match_brute_force`
   (all W,H in 1..=7, every centre, r in 0..=10; compared with a filter over `distance <= r`).
4. Non-square and 1x1 / 1xN / Nx1 worlds: `non_square_world_axes_wrap_independently` (7x3), `one_by_one_world_everything_is_the_same_cell`,
   `one_by_n_and_n_by_one_wrap`.
5. Tests cover the four edges, corners, negative and multiply wrapped coordinates and a 1x1 world: `step_east_from_right_edge_wraps_to_left`,
   `step_west_from_left_edge_wraps_to_right`, `step_south_and_north_wrap_on_height`, `step_all_four_corners_wrap_diagonally`,
   `neighbours_cross_all_four_edges`, `wrap_far_outside_world`, `one_by_one_world_everything_is_the_same_cell`.

## Decisions checked
- Chebyshev distance on the torus, per-axis shortest displacement, matching the ADR-0003 square box (ADR-0007). Accepted.
- Tie rule +L/2 on even axes (ADR-0007). Documented and tested.
- Private `Cell` fields with checked `Torus::cell` and `wrap` as the only sources of valid cells: a stronger invariant than the plan.
  Accepted; ADR-0007 notes the deviation.

## Non-blocking observations
- G-023: the Must-have wording "distance and direction between two cells" is met by `Torus::delta` (signed per-axis Offset) and
  `Torus::distance`. There is no function that returns a compass `Direction` (one of the eight) from two cells. If a later task
  needs a heading (e.g. perception or pursuit), add `Torus::heading(from, to) -> Option<Direction>` in world.rs. Not a blocker here.
- G-024: `Torus::neighbours` returns a `Vec` (allocation per query). Not measured; performance is TASK-010's concern.
- Later modules (TASK-005 climate, TASK-006 seam tests, TASK-010 spatial index) must use these functions, not their own wrap
  arithmetic. Nothing enforces this yet; check it in their REVIEW.
- Cosmetic: the ARCHITECTURE status sentence was stale (it said evosim-core holds only CONTRACT_VERSION). Fixed in this REVIEW.
- Formatting: `cargo fmt --check` reports diffs only in TASK-003 config files (out of scope; no CI enforces rustfmt).

## Docs updated in this REVIEW
- `docs/decisions/ADR-0007-torus-topology-and-distance.md`: status Proposed -> Accepted.
- `docs/STATE.md`: status header updated to REVIEW cycle 1 PASS.
- `docs/ARCHITECTURE.md`: status sentence corrected.
No code, tests, task.md/task.json, scripts or commits were changed.

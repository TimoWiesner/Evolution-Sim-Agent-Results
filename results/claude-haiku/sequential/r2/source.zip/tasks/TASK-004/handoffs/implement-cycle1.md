# TASK-004 IMPLEMENT cycle 1 — notes

Scope: grid coordinates and toroidal topology (`tasks/TASK-004/task.md`). Implements the ordered recipe in
`tasks/TASK-004/handoffs/plan-cycle1.md` and ADR-0007 (still Proposed; REVIEW sets Accepted on PASS).

## What was built
- `crates/evosim-core/src/world.rs` (new): `TopologyError`, `Coord` (i64), `Cell` (u32, private fields), `Offset`,
  `Direction` (8 compass steps, `North` is dy = -1, `Direction::ALL`), `Torus` (width/height u32 >= 1).
- `Torus` methods: `new`, `width`, `height`, `cell_count`, `cell` (checked), `wrap`, `translate`, `step`, `index`,
  `cell_from_index`, `delta`, `distance`, `neighbours`.
- `crates/evosim-core/src/lib.rs`: `pub mod world;`.

## Deviation from the plan
- `Cell` has private fields (accessors `x()`, `y()`), not public ones, so `x < width` and `y < height` cannot be
  broken from outside. Recorded in ADR-0007 Implementation notes and docs/STATE.md.

## Acceptance criteria -> tests (names in `world::tests`)
1. Any integer coordinate maps to a valid cell, including negatives and several worlds away:
   `wrap_negative_and_zero`, `wrap_far_outside_world`, `wrap_i64_extremes_do_not_overflow`, `wrap_identity_for_valid_cells`.
2. Shortest way per axis, across an edge when shorter: `delta_takes_short_way_across_edge`,
   `delta_tie_on_even_axis_is_positive`, `delta_odd_axis_has_no_tie`, `distance_is_symmetric_and_chebyshev`,
   `distance_bounded_by_half_world`, `delta_antisymmetric_except_tie` (seeded, 2000 pairs),
   `distance_triangle_inequality_seeded` (seeded, 2000 triples).
3. Neighbours within radius, no duplicates, radius larger than the world: `neighbours_radius_zero_is_centre`,
   `neighbours_have_no_duplicates_and_are_ascending`, `neighbours_radius_larger_than_world_visits_each_cell_once`,
   `neighbours_match_brute_force` (all W,H in 1..=7, every centre, r in 0..=10),
   `neighbours_radius_two_on_large_world_has_25_cells`.
4. Non-square and very small worlds: `non_square_world_axes_wrap_independently` (7x3),
   `one_by_one_world_everything_is_the_same_cell`, `one_by_n_and_n_by_one_wrap` (1x5, 5x1).
5. Four edges, corners, negative and multiply wrapped coordinates, 1x1 world:
   `step_east_from_right_edge_wraps_to_left`, `step_west_from_left_edge_wraps_to_right`,
   `step_south_and_north_wrap_on_height`, `step_all_four_corners_wrap_diagonally`,
   `neighbours_cross_all_four_edges`, `axis_steps_cycle_back_to_start_after_one_lap`,
   `step_equals_translate_by_offset_for_all_directions`, `zero_size_is_error`, `cell_constructor_rejects_out_of_range`,
   `index_round_trips`.

## Commands and exit codes (run from /workspace, PATH includes /opt/rust/cargo/bin)
| Command | Exit | Result |
|---|---|---|
| `cargo test -p evosim-core --locked` | 0 | 74 passed (44 before + 30 new) |
| `cargo clippy -p evosim-core --locked --all-targets` | 0 | 0 warnings in the final run (3 found in the first run and fixed) |
| `cargo test --workspace --locked` | 0 | core 74, cli 9 |
| `bash scripts/check_adrs.sh` | 0 | checks=54 failed=0 |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED |
| `git remote -v \| wc -l` | 0 | 0 (no remote) |
| `cargo fmt -p evosim-core -- --check` | 1 | diffs only in TASK-003 config files (not touched); world.rs formatted |

No system packages were installed.

## Known limits (for REVIEW)
- `neighbours` is not benchmarked; the cost is bounded by W*H cells.
- Tie rule: `delta(a,b) != -delta(b,a)` only when an axis difference is exactly half an even axis.
- Later modules must use these functions instead of their own wrap arithmetic (not enforced yet).

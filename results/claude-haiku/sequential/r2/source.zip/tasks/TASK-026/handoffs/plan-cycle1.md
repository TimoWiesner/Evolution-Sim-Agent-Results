# TASK-026 PLAN cycle 1: performance measurement and optimisation

Status: plan only. No product code changed, no commit. Decision record: `docs/decisions/ADR-0027-performance-measurement-and-optimisation.md` (Proposed).

## Environment (measured in PLAN)
- Hardware: AMD Ryzen 5 7500F 6-Core Processor, 12 logical CPUs, 32 GB RAM (`/proc/cpuinfo`, `/proc/meminfo`). Kernel 7.0.0-42-generic.
- Toolchain: rustc/cargo 1.100.0 at `/opt/rust/cargo/bin` (export PATH first). No system packages added.
- No profiler installed (`perf`, `valgrind` absent).
- `git remote -v | wc -l` = 0.

## Baseline gates (before any change)
- `cargo test --workspace --locked --offline` -> exit 0, 24 s: evosim-cli 36, batch 8, checkpoint 2, run 9, evosim-core 423 passed + 1 ignored, evosim-ui 95 passed + 1 ignored.
- `bash scripts/check_adrs.sh` -> exit 0, checks=197 failed=0 (after adding ADR-0027 to its list).

## What the probes showed (facts for IMPLEMENT)
1. The population does NOT stay at 2,000 under the current ecology. Probes (release binary, `evosim run`, seed 42):
   - 64x48, 1,600 plants + 280 herbivores + 120 carnivores: herbivores 0 by tick 48; 962 plants at tick 300.
   - 128x96, 2,000 plants + 300 herbivores + 60 carnivores: 611 living organisms at tick 1,000 (herbivores 0 from about tick 600).
   - 128x96, 2,400 plants + 400 herbivores + 100 carnivores: 1,223 plants at tick 1,000, animals 0 by tick 600.
   - 128x96 plant-only 2,000: 1,133 plants at tick 1,000. 256x192 plant-only 2,000: 1,055 at tick 1,000.
   - Plant parameters (`plants.growth_rate` 0.5, `reproduction_chance` 0.3) raise the plant count only briefly (2,143 at tick 150, 1,636 at tick 600 for plants-only 128x96).
   - 128x96, 2,000 plants + 300 herbivores + 60 carnivores with growth 0.5 and reproduction 0.3: living 2,110 at tick 150 (1,973 + 118 + 19), 1,000 at tick 600.
   Conclusion: "about 2,000 alive throughout a long window" is impossible with the current ecology and the product rules. The fixed benchmark must measure windows that start from about 2,000 organisms (see D1 in ADR-0027). The collapse is TASK-027's topic; TASK-026 must not change the ecology.
2. Throughput probes: plant-only 2,000 at 128x96: 1,699 ticks/s (1,000 ticks); mixed 2,000 at 128x96: 1,272 ticks/s (1,000 ticks); 64x48 mixed: about 1,985 ticks/s over 300 ticks. The 100 ticks/s target is probably met; this is not yet measured with the fixed benchmark.
3. Determinism: two `evosim run` calls with the same config (`/tmp`, 200 ticks) give the same `state_hash` (f7983cbf...). The hash is the behaviour-unchanged check.

## Ordered implementation plan (IMPLEMENT)
1. Fixed configuration: create `examples/perf-2000.json` (`seed` 42; world and initial populations so that the first N ticks have living >= 2,000 on every tick; choose N from a probe with living counts per tick, expected N about 50 to 100 with a 128x96 world). Record the chosen values.
2. Module `crates/evosim-core/src/perf.rs` (new, `pub mod perf` in `lib.rs`): `PhaseTimes` (nine `Duration` accumulators keyed by `Phase`, plus query counters), `benchmark(config, warm, reps, ticks)` returning median/min/max ticks/s and per-tick living counts, and the guard test. Timing uses `Instant`, only in this module and the profiler, never in state.
3. `sim.rs`: `pub fn tick_profiled(&mut self, times: &mut PhaseTimes)` running the same `PHASE_ORDER` through `run_phase`, timing each phase; `tick()` unchanged. Test: `tick_profiled` and `tick` give the same `state_hash` after 300 ticks (checkpoint::state_hash).
4. Example `crates/evosim-core/examples/perf_tps.rs` (new): reads `--config`, `--ticks`, `--warm`, `--reps`, prints the JSON summary and the phase profile. Script `scripts/perf.sh` (new, executable): runs the example in release with the fixed arguments and prints the hardware line (`/proc/cpuinfo` model, `nproc`, rustc version).
5. Baseline measurement, before any optimisation: run `scripts/perf.sh` twice (median, min, max, living per tick, phase profile, `state_hash`). Record in `docs/PERFORMANCE.md` (new): hardware, command, numbers, profile. Also a 1,000-tick secondary run.
6. Profile reading: name the top phases and the top functions inside them (phase timers; counters of `within`/`neighbours` calls, candidates returned, stale-overlay entries scanned). Candidate hot spots (to be confirmed or rejected by the profile, not assumed): spatial queries and the stale overlay (G-046 in STATE), per-query `Vec` allocation, per-plant climate query (ADR-0012), genome decode per plant per tick, genetic distance in mating (ADR-0017), species check (ADR-0018, every 25 ticks).
7. Optimisations, one per trial, each recorded in `docs/PERFORMANCE.md` with expectation and measured result (including ones that do not help). Gate after each: `state_hash` of `examples/perf-2000.json` (seed 42, 1,000 ticks) and of three other seeds equal to the baseline values; `cargo test -p evosim-core --locked --offline` exit 0.
8. Guard test (in `perf.rs`): runs the fixed configuration for a short window (a few seconds at most) and asserts ticks/s >= floor; floor about one quarter of the measured median, separate for debug (`cfg!(debug_assertions)`) and release. Measure the debug speed first and set the floor from it. Verify once by hand that the test fails with a floor set above the measured value, and record that.
9. Final measurement: `scripts/perf.sh` after the chosen changes (two runs), the same secondary 1,000-tick number, and `docs/PERFORMANCE.md` before/after table. If the 100 ticks/s target is missed, record the measured value, what was tried and the bottleneck.
10. Docs: `docs/PERFORMANCE.md`, ADR-0027 (status Proposed in IMPLEMENT; REVIEW sets Accepted), `docs/ARCHITECTURE.md` (module table row for `perf`, `tick_profiled`, measured-performance pointer), `docs/STATE.md` (IMPLEMENT section, commands with exit codes, system dependencies: none unless a profiler is installed, then the exact `apt-get` command), `README.md` (one line: how to run `scripts/perf.sh`). Add ADR-0027 mention in ARCHITECTURE if needed.
11. Gates for IMPLEMENT: `cargo test --workspace --locked --offline` exit 0; `cargo clippy --workspace --all-targets --locked --offline` exit 0; `bash scripts/check_adrs.sh` exit 0; `./build.sh` exit 0; `./evosim run --config examples/perf-2000.json --ticks 1000 --out ...` exit 0 with the same `state_hash` as before the change; `git remote -v | wc -l` = 0.

## Files
- New: `docs/PERFORMANCE.md`, `docs/decisions/ADR-0027-performance-measurement-and-optimisation.md` (done in PLAN), `crates/evosim-core/src/perf.rs`, `crates/evosim-core/examples/perf_tps.rs`, `scripts/perf.sh`, `examples/perf-2000.json`.
- Changed: `crates/evosim-core/src/lib.rs` (`pub mod perf`), `crates/evosim-core/src/sim.rs` (`tick_profiled`), optimisation targets (`spatial.rs`, `ecology.rs`, `reproduction.rs`, `genome.rs`, `climate.rs` as the profile decides), `scripts/check_adrs.sh` (ADR-0027 listed; done in PLAN), `docs/ARCHITECTURE.md`, `docs/STATE.md`, `README.md`.

## Tests (planned)
- `perf::guard_ticks_per_second_floor` (in `cargo test --workspace`).
- `perf::tick_profiled_matches_tick` (state hash equality).
- Existing determinism and checkpoint tests unchanged and passing (`checkpoint_cli.rs`, `run_cli.rs`, `batch_cli.rs`, core `checkpoint`).
- `state_hash` before/after comparisons for the fixed configuration and three further seeds (recorded commands).

## Risks
- Population collapse (see fact 1): the "about 2,000 alive" condition holds only for the early window of each measured repetition. Reported openly; TASK-027 changes the ecology and the benchmark must be re-run there.
- Timing noise on a shared host (about 5 % seen in TASK-010); use median of 5 and state min/max.
- Guard floor flakiness on slow machines: floor about 4x below the measured value; debug floor set separately.
- Any float or iteration-order change alters `state_hash`; each optimisation is checked by hash before it is kept.
- `Instant` in core: allowed only in `perf.rs` and `tick_profiled` (ARCHITECTURE rule 4: never in state).
- Debug-build test time: guard test must stay within a few seconds in debug.

## Next steps for the orchestrator
- Run IMPLEMENT for TASK-026 (cycle 1) following the ordered plan above.
- TASK-027 must re-run the benchmark after changing ecology defaults.

# TASK-026 IMPLEMENT cycle 1: performance measurement and optimisation

Status: implemented and gated; REVIEW not run. No commit by the agent. Machine-readable handoff: `implement-cycle1.json`.

## Result
- Benchmark: `bash scripts/perf.sh` on `examples/perf-2000.json` (seed 42, 128x96, 2000 plants, 300 herbivores, 60 carnivores). Median 577.8 ticks/s over five timed 60-tick repetitions (four script runs gave 576 to 580). Living count at least 2164 on every measured tick. Target 100 ticks/s: met.
- Profile (60 ticks, `tick_profiled`): Herbivores 30.8 %, Plants 28.1 %, Carnivores 23.6 %, Species 11.3 %, Reproduction 4.8 %, Deaths 0.5 %, SpatialIndex 0.9 %.
- No optimisation of product code was applied; the target is met with a margin of about 5.8x. `docs/PERFORMANCE.md` lists the candidates.
- Behaviour unchanged: `tick()` untouched; state hash of the 128x96 probe after 120 ticks identical before and after (c009fdd55c268389...). All workspace tests pass.

## Files
See the `changed_files` list in the JSON. Main ones: `crates/evosim-core/src/perf.rs`, `crates/evosim-core/src/sim.rs` (`tick_profiled`), `crates/evosim-core/examples/perf_tps.rs`, `scripts/perf.sh`, `examples/perf-2000.json`, `docs/PERFORMANCE.md`.

## Gates
- `cargo test --workspace --locked --offline`: exit 0 (core 430 + 1 ignored, cli 36/8/2/9, ui 95 + 1 ignored).
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0.
- `./build.sh`, `./evosim version`, `./dist/evosim version`: exit 0.
- Guard floor check: floor 1000000 fails the guard (exit 101); restored floors (release 140, debug 6) pass.
- `git remote -v | wc -l`: 0.

## Open points for REVIEW
- The 2000-organism level holds only for about the first 100 ticks under the current ecology (611 at tick 1000). The benchmark measures 60-tick windows that start at 2000; TASK-027 must re-run.
- Per-function costs inside each phase are from code reading, not measured.
- ADR-0027 stays Proposed.

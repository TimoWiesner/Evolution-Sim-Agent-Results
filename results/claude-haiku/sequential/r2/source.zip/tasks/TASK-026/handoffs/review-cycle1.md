# TASK-026 REVIEW cycle 1: performance measurement and optimisation

Verdict: **FAIL** (one blocking gap, G-1). Machine-readable handoff: `review-cycle1.json`. Commit d8cee94 reviewed (IMPLEMENT cycle 1). ADR-0027 stays Proposed.

## What was checked (fresh process, independent re-runs)
- `cargo test --workspace --locked --offline`: exit 0 (cli 36/8/2/9, core 430 + 1 ignored, ui 95 + 1 ignored).
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0.
- `bash scripts/perf.sh`: exit 0. Median 578.7 ticks/s (min 475.6 in the first timed repetition, max 579.3); min living on measured ticks 2,164; state hash identical in all repetitions and equal to docs. Secondary 1,000 ticks: 1,444.7 ticks/s, final living 611.
- Behaviour: `git diff 9ad82af d8cee94` changes `sim.rs` only by adding `tick_profiled`. `tick()` is untouched. A 120-tick run of the 128x96 2,000/300/60 seed-42 configuration gives `c009fdd55c268389...`, the value recorded by IMPLEMENT.
- `git remote -v | wc -l` = 0.

## Acceptance criteria
| # | Criterion | Result |
|---|---|---|
| 1 | Documented command, fixed config keeping about 2,000+ alive, fixed seed, warm-up, stated tick count | **Not met.** Command, seed, warm-up and tick count are fixed and documented. The configuration does not keep 2,000 alive: 2,360 at tick 0, 2,003 at tick 100, 1,209 at tick 200, 611 at tick 1,000. The benchmark measures 60-tick windows from the start (see G-1). |
| 2 | `docs/PERFORMANCE.md`: hardware, command, numbers before and after | Met as written. The before and after numbers are identical because nothing was optimised (see G-2). |
| 3 | Profile names the most expensive parts and what was done | Met at phase level (Herbivores 31 %, Plants 28 %, Carnivores 24 %, Species 11 %). The split inside phases was not measured (G-3). |
| 4 | Target 100 ticks/s at about 2,000 organisms | Met: 578.7 ticks/s median on this host. |
| 5 | Behaviour unchanged; all tests pass, incl. determinism and checkpoints | Met (see above). |
| 6 | Guard test against large slowdowns with a loose threshold | Met: `perf::tests::guard_ticks_per_second_floor`, release floor 140 and debug floor 6 ticks/s, against measured 578 and 26. |

## Population probes (REVIEW, release binary, seed 42, 600 ticks)
| Configuration | tick 0 | tick 100 | tick 200 | tick 600 |
|---|---|---|---|---|
| 128x96, 2,000 / 300 / 60 (benchmark) | 2,360 | 2,003 | 1,209 | 615 |
| 128x96, 3,000 / 400 / 60 | 3,460 | 2,917 | 1,748 | 918 |
| 192x144, 3,000 / 300 / 60 | 3,360 | 3,061 | 1,932 | 1,121 |
| 256x192, 4,000 / 400 / 80 | 4,480 | 3,899 | 2,428 | 1,402 |
| 128x96, 2,400 / 150 / 30 | 2,580 | 2,406 | 1,558 | 1,205 |

No configuration tested stays at or above 2,000 beyond about 200 ticks. This is consistent with the IMPLEMENT probes and with the PLAN finding that the current ecology cannot hold the population. The product rules (docs/PROJECT.md) forbid count-based replenishment, so the fix belongs in configuration choice or in TASK-027's ecology work, not in the benchmark.

## Gaps
- **G-1 (blocking).** Criterion 1 is not met as written. Remedy in the next PLAN: pick a configuration (existing keys only) that stays at or above 2,000 for the whole measured window, for example 256x192 with 4,000 founders, which is at 2,428 at tick 200, so a window of up to about 150 ticks qualifies. Alternatively, the operator records a decision that the start-window reading is acceptable, in ADR-0027 and PERFORMANCE.md. The reviewer cannot make that decision.
- **G-2 (non-blocking, goal).** No optimisation was applied, so the task's "make it faster" goal has no measured speedup. Apply and measure at least one optimisation with an unchanged `state_hash`, or record in ADR-0027 why none is attempted.
- **G-3 (non-blocking).** The profile is per phase. Query counts and the stale-overlay cost inside Herbivores and Carnivores are unmeasured. Count them, or state that the phase level is the accepted level.

## Notes
- The first timed repetition runs about 15 % slower than the rest. Warm-up is not fully settled, but the median is stable within about 0.5 %.
- Guard floors have about 4x margin. A slower or loaded host could still trip the debug floor.
- Docs changed in this phase: `docs/PERFORMANCE.md` (section 'REVIEW cycle 1') and `docs/STATE.md` (section 'TASK-026 REVIEW cycle 1'). Nothing committed. `task.md` and `task.json` untouched.

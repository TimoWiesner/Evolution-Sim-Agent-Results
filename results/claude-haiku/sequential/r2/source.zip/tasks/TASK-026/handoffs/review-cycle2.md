# TASK-026 REVIEW cycle 2: performance measurement and optimisation

Verdict: **PASS**. Reviewed commit d3d40ef (IMPLEMENT cycle 2). Machine-readable handoff: `review-cycle2.json`.
Details and the numbers: `docs/PERFORMANCE.md` section "REVIEW cycle 2"; state: `docs/STATE.md` "TASK-026 REVIEW cycle 2".

## Acceptance criteria
| # | Result |
|---|---|
| 1 | Met. `examples/perf-2000.json` (seed 42, 128x96, 2,200/250/50), `scripts/perf.sh`: 2 warm-up + 5 timed reps of 100 ticks. Living >= 2,000 on every measured tick (min 2,173), enforced by `perf::tests::fixed_benchmark_living_holds_for_the_window`. |
| 2 | Met. `docs/PERFORMANCE.md` has hardware, command, before/after table. |
| 3 | Met at phase level: Plants about half the tick (O1 applied), Species about 20 % (not changed), Herbivores/Carnivores about 10 % each after O2. |
| 4 | Met. Median 1,081.7 ticks/s on this host (target 100). |
| 5 | Met. Full workspace tests pass; state hashes identical to the pre-optimisation build (8 pairs plus the 120-tick old-configuration probe). |
| 6 | Met. Guard test with floors 140 (release) and 6 (debug) against measured 1,050 and 72. |

## Independent checks (this phase)
- `cargo test --workspace --locked --offline`: exit 0.
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, 197 checks, 0 failed.
- `bash scripts/perf.sh`: exit 0, median 1,081.7 ticks/s, min living 2,173, hash `9fee0117...`.
- Old commit 8966e78 built from `git archive` into a separate directory, compared with the current build: identical hashes.
- `git remote -v | wc -l`: 0.

## Gaps (non-blocking)
- Per-call-site query split (G-3) not measured; totals only.
- O1 and O2 not timed separately.
- Plants phase not profiled inside the phase.
- Debug guard figure 72 vs 26 ticks/s in REVIEW cycle 1, unexplained.
- The 2,000-living window is 100 ticks by design (population falls to 1,770 by tick 150); the next ecology task (TASK-027) determines how long it holds.
- Commit 8966e78 is titled "review cycle 1 PASS" although the cycle 1 verdict was FAIL (orchestrator naming anomaly).

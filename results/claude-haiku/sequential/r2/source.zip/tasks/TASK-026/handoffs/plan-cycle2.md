# TASK-026 PLAN cycle 2: performance measurement and optimisation

Status: plan only. No product code changed, no commit. Machine-readable handoff: `plan-cycle2.json`. Decision record: `docs/decisions/ADR-0027-performance-measurement-and-optimisation.md` ("PLAN cycle 2"). This replan closes every REVIEW cycle 1 gap (G-1, G-2, G-3).

## Gap G-1 (blocking): benchmark keeps 2,000 alive
Chosen fixed configuration (`examples/perf-2000.json`, to be changed in IMPLEMENT): seed 42, world 128 x 96, initial plants 2,200, herbivores 250, carnivores 50. Only fixed keys are used.
- Probed living count (release `evosim run`, `--sample-every 1`, deterministic): tick 0 = 2,500; minimum over ticks 0 to 100 = 2,173; mean over ticks 0 to 100 = 2,432; minimum over ticks 0 to 150 = 1,770.
- Window: 100 measured ticks, 2 untimed warm-up and 5 timed repetitions, each from a fresh simulation. `perf_tps` keeps its living floor of 2,000 on measured ticks.
- Rejected alternatives (ADR-0027 table): old 2,000 / 300 / 60 (falls to 2,003 at tick 100, 1,601 at tick 150); 2,100 / 280 / 60; 2,300 / 300 / 60; 2,600 / 300 / 60 (holds longer but mean about 2,900, far from "about 2,000"). The operator-decision route is not needed.
- No organisms are added and no count-based rule is used (docs/PROJECT.md).

## Gap G-2 (non-blocking, goal): apply and measure optimisation
IMPLEMENT must apply and measure at least two optimisations; each is kept only if `state_hash` is unchanged.
- O1, plant climate cache (Plants, 28 %): `ecology::plants_phase` calls `climate.conditions(cell)` for every plant. The phase takes `&Climate`, so the value is constant during the phase. Compute it once per cell and reuse it, with the same float operations. File: `crates/evosim-core/src/ecology.rs`.
- O2, O(1) stale check (Herbivores and Carnivores, about 55 % together): `SpatialIndex::within_into` (`crates/evosim-core/src/spatial.rs`) does a `BTreeSet::contains` for every bucket entry and scans the whole stale set. Replace it with an O(1) membership test. Results are sorted before return, so the change keeps every answer. Existing randomised brute-force tests in `spatial.rs` must still pass.
- O3, buffer reuse (only if counts show allocation matters): `movement::perceive`, `feeding::feed`, `hunting::attack` use allocating `within`; switch to `within_into` with a scratch buffer.
- Not in scope: Species re-classification (11 %, ADR-0018). Recorded as the next candidate.

## Gap G-3 (non-blocking): query counts
IMPLEMENT counts, per phase, `within`/`within_into` calls, candidates returned, stale entries scanned and plant climate queries, using a temporary patch that is reverted before the commit. The numbers go into `docs/PERFORMANCE.md`. Permitted alternative: state that the phase-level profile is the accepted level.

## Ordered plan (IMPLEMENT cycle 2)
1. Record the pre-change state. Build the unchanged release binary (commit 8966e78). Measure `scripts/perf.sh` for the **current** configuration only as context. For the **new** configuration, record `evosim run --config <new> --ticks 1000 --seed S --out ...` state hashes for S = 42, 1, 2, 3, plus the 120-tick hash of the 2,000/300/60 probe for comparison.
2. Change `examples/perf-2000.json` to the chosen values. Update `scripts/perf.sh` header comment, `perf.rs` docs and the `perf_tps` example comment from 60 to 100 measured ticks (default values too). Keep `REQUIRED_LIVING` at 2,000.
3. Add `perf::tests::fixed_benchmark_living_holds_for_the_window`: runs the benchmark configuration for 100 ticks and asserts living >= 2,000 on every tick. Debug time must stay within a few seconds.
4. Measure the "before" numbers with `scripts/perf.sh` (two runs) on the unchanged code and the new configuration. Run the G-3 counting patch (temporary, reverted). Record.
5. Apply O1. Gate: four hashes equal to step 1; `cargo test -p evosim-core --locked --offline` exit 0. Measure `perf.sh`.
6. Apply O2. Same gate. Measure `perf.sh`. Apply O3 only if the counts justify it, same gate.
7. Re-measure guard floors (debug and release) for the new configuration. Keep 140 and 6 unless the measured values change by more than about 25 %, and record the change.
8. Final gates: `cargo test --workspace --locked --offline`; `cargo clippy --workspace --all-targets --locked --offline`; `bash scripts/check_adrs.sh`; `./build.sh`; `./evosim version`; `./dist/evosim version`; `git remote -v | wc -l` = 0.
9. Docs: `docs/PERFORMANCE.md` (new configuration, before/after table with both optimisations, G-3 counts, guard floors); ADR-0027 (IMPLEMENT cycle 2 choices; status stays Proposed); `docs/ARCHITECTURE.md` if a function signature or rule changes; `docs/STATE.md` (IMPLEMENT cycle 2 section, commands and exit codes).

## Files
- Changed: `examples/perf-2000.json`, `scripts/perf.sh`, `crates/evosim-core/src/perf.rs`, `crates/evosim-core/examples/perf_tps.rs`, `crates/evosim-core/src/ecology.rs` (O1), `crates/evosim-core/src/spatial.rs` (O2), possibly `movement.rs`, `feeding.rs`, `hunting.rs` (O3), `docs/PERFORMANCE.md`, `docs/decisions/ADR-0027-*.md`, `docs/STATE.md`, `docs/ARCHITECTURE.md` (if needed), `README.md` (only if the command text changes).
- Not changed: `docs/CONTRACT.md`, `AGENTS.md`, `tasks/TASK-026/task.md`, `task.json`, `scripts/check_adrs.sh` (apart from its existing ADR-0027 entry).

## Tests
- Existing, unchanged: determinism and checkpoint tests (`checkpoint_cli.rs`, `run_cli.rs`, `batch_cli.rs`, core `checkpoint`); `perf::tests::guard_ticks_per_second_floor`; `perf::tests::tick_profiled_matches_tick`.
- New: `perf::tests::fixed_benchmark_living_holds_for_the_window` (G-1 as a test).
- Hash gates (recorded command output): four seeds x 1,000 ticks for the new configuration, before and after each optimisation.

## Risks
- Any change to iteration order or float operation order changes `state_hash`. Each optimisation is dropped if its hash differs.
- The new configuration's margin (173 living above the floor at tick 100) is deterministic for this seed. A different platform could shift it slightly; "minor inter-platform differences allowed" by CONTRACT section 5, and the new test would show it.
- The new configuration runs about 2,400 to 2,500 organisms. Throughput is expected to be a bit lower than the 578 ticks/s measured at 2,164 to 2,360, but still well above 100.
- Timing noise on this shared 12-thread host is about 0.5 % for the median; the first repetition runs about 15 % slower.
- The commit 8966e78 is titled "TASK-026 review cycle 1 PASS" although the REVIEW verdict is FAIL. This is an orchestrator naming anomaly, reported here and in STATE.md; it was not changed.
- The 60-minute phase limit: the optimisation steps are small; the full gate set (cargo test about 25 s, perf runs about seconds each) fits.

## Verification done in PLAN
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0 (after the ADR-0027 PLAN cycle 2 section was appended).
- `git remote -v | wc -l`: 0.
- Probes (release `evosim run`, scratch directory `/tmp/plan2`, nothing in the workspace): configurations listed in ADR-0027 "PLAN cycle 2". No product code was built or changed.
- Hardware, unchanged from IMPLEMENT: AMD Ryzen 5 7500F, 12 logical CPUs, 31 GiB; rustc 1.100.0 at `/opt/rust/cargo/bin`. No system packages were installed.

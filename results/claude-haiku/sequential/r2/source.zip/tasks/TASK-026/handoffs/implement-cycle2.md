# TASK-026 IMPLEMENT cycle 2: performance measurement and optimisation

Status: implemented and gated; REVIEW not run. No commit by the agent. Machine-readable handoff: `implement-cycle2.json`.
Numbers and commands: `docs/PERFORMANCE.md` section "IMPLEMENT cycle 2". Decision record: ADR-0027 "IMPLEMENT cycle 2" (Proposed).

## Result
- Configuration `examples/perf-2000.json` (seed 42, 128x96, 2,200 / 250 / 50). Living at least 2,173 on every measured tick (100 ticks, 5 timed repetitions after 2 warm-up).
- Throughput, median of repetitions: before 865 and 869 ticks/s; after 1,085 and 1,077 ticks/s (about 1.25x). Target 100 ticks/s: met.
- Optimisations applied: O1 (per-cell climate cache in `plants_phase`), O2 (stale overlay as a `HashMap` with current placement, O(1) membership). O3 not applied (264 queries per tick).
- Behaviour unchanged: state hashes identical before and after for seeds 42, 1, 2, 3 at 150 and 1,000 ticks, and for the 120-tick 2,000/300/60 probe.
- Deviation from PLAN: O2 also removes the `BTreeMap` lookup per stale entry, because the counts showed the stale scan (2.14 M entries per 100 ticks) was larger than the bucket checks (184 K).

## Gates (exit codes)
- `cargo test --workspace --locked --offline`: 0. `cargo clippy --workspace --all-targets --locked --offline`: 0. `bash scripts/check_adrs.sh`: 0 (197 checks, 0 failed). `./build.sh`, `./evosim version`, `./dist/evosim version`: 0. `git remote -v | wc -l`: 0.

## Open points for REVIEW
- Plants phase is about half the tick and not profiled inside the phase (likely: regeneration `conditions()` for all cells, `PlantTraits::from_genome` per plant).
- Guard floors kept (140 release, 6 debug). Measured release now 1,050 ticks/s, debug 72 (REVIEW had recorded 26 for debug; not explained).
- O1 and O2 gated together, not timed separately.

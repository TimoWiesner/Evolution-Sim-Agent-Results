# TASK-007 REVIEW cycle 1: Seasons and weather

Verdict: PASS. Reviewed independently from the IMPLEMENT notes: source read in `crates/evosim-core/src/climate.rs` and `sim.rs`,
ADR-0010 read, and every command re-run in this process. Handoff: `review-cycle1.json`.

## Commands re-run (from /workspace, PATH includes /opt/rust/cargo/bin)
- `cargo test --workspace --locked` -> exit 0 (core 123 passed, cli 16 passed).
- `cargo test -p evosim-core --locked weather -- --nocapture` -> exit 0, 8 passed.
- `cargo test -p evosim-core --locked bounds_hold -- --nocapture` -> exit 0; clamp diagnostic `9318` cell-ticks (matches IMPLEMENT).
- `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` -> exit 0, 0 warning or error lines.
- `rustfmt --edition 2021 --check crates/evosim-core/src/climate.rs crates/evosim-core/src/sim.rs` -> exit 0.
- `bash scripts/check_adrs.sh` -> exit 0, checks=87 failed=0.
- `bash scripts/test.sh` -> exit 0, "ALL TESTS PASSED".
- `git remote -v | wc -l` -> 0.

## Acceptance criteria, one by one
1. **Configurable year, seasonal cycle for every cell.** `climate.season_length` (config, 1..=100000, default 240) is passed in
   `Simulation::new` (sim.rs:134) and used by `season_sin`. Temperature swing `20 * lat/90 * sin` and precipitation multiplier
   `1 + 0.2 sin` apply to every cell. Interpretation to note: at the equator the temperature swing is about 0.02 C (row 23 of 48
   at latitude 0.10 degrees), so temperature there is almost flat; precipitation still cycles everywhere. This follows the
   "how they differ between zones" decision, and the test `seasonal_amplitude_follows_latitude` documents it.
2. **Weather from the simulation generator, same seed same weather.** `Climate::advance` draws from `Simulation.rng` in the Climate
   phase, one `next_f64` per node, only when `weather_amplitude > 0`. Tests: `weather_draws_once_per_node_per_tick`,
   `weather_is_seeded_and_uses_the_generator`, `climate_phase_draws_only_when_weather_is_on`, `trace_identical_for_same_seed_over_100_ticks`.
3. **Bounds.** `conditions` and `seasonal_conditions` clamp to temperature [-70, 50] C and precipitation [0, 5000] mm/yr.
   `bounds_hold_over_long_runs` checks every cell at every tick over 3 seeds x 1200 ticks at amplitude 1.0.
   Reading of the clamp (reasoned, consistent with the diagnostic): at the default amplitude 0.15 the precipitation multiplier is at
   least 1 - 0.2 - 0.15 = 0.65 and the temperature stays in about [-54, 41] C, so the clamp cannot be reached. It is reached only when
   the amplitude exceeds about 0.8 (multiplier below 0). Recorded as a risk, not a failure.
4. **Query at any tick.** `Climate::conditions(cell)` returns base + season + weather for the last applied Climate phase
   (`weather_tick`); `Climate::seasonal_conditions(cell, tick)` returns base + season for any tick. Reading accepted in REVIEW:
   "current" means the present tick, and the present tick is always queryable for every cell. Weather at an earlier tick is not
   reproducible without stored history, and the ADR says so. One-tick lag to note: after `run(N)` the tick counter is N and
   `conditions` reports tick N-1, the last finished tick. Consumers that want the season at the counter value can call
   `seasonal_conditions(cell, tick_count())`.
5. **Weather off: one year repeats exactly.** `one_year_repeats_exactly_with_weather_off` (climate level, 480 ticks, 64x48, bitwise
   `to_bits`) and `one_year_repeats_exactly_with_weather_off` (Simulation level, RNG state unchanged). Also: `assert_ne!(per_tick[0],
   per_tick[60])`, so the year is not constant.
6. **Weather state is part of the simulation state.** `Climate` holds `params`, `nodes`, `weather_tick` and derives `PartialEq`;
   `World` and `Simulation` inherit it. `restore_with_weather_continues_identically` (sim.rs) splits a 150-tick run at 100 ticks
   through `Simulation::from_parts` and compares the result with the uninterrupted run. The file checkpoint is TASK-022 and is not
   part of this criterion.

## Code review notes (no defect blocking PASS)
- `axis_weights` uses exact integer positions, so the periodicity test is exact. Node spacing is `W/ceil(W/8)` on both sides of
  the seam, so the seam is no different from an interior step (the Lipschitz test confirms this, with a loose bound).
- The seasonal part is symmetric in latitude, so the seam row pair (row H-1 and row 0) has equal latitude and no seasonal
  step across the seam.
- `from_parts` validates amplitude, season length, node count and node range. It does not validate the `terms` list (G-032).
- The base precipitation clamp is only hit at amplitude above about 0.8, as stated above.

## Gaps (non-blocking, recorded in STATE.md and the handoff)
- G-035 (new): no sim-level test sets a non-default `season_length` and checks the period, so the config wiring is covered only by reading
  sim.rs:134 and the climate-level tests (which pass the value directly). A one-line test would close it.
- G-036 (new): the seam test uses a Lipschitz bound (`6 * (lx/w + ly/h)`), which is loose; it cannot see small seam steps. Accepted:
  the periodicity test is exact.
- G-032, G-033, G-034 (from IMPLEMENT) stay open: `terms` not validated in `from_parts`; ADR-0006 wording of `weather_amplitude`
  not aligned; clamp reached at amplitude above about 0.8.
- Carried, unchanged: G-026 (stale `./evosim` after source edits), G-027 (no black-box climate step in `scripts/test.sh`), G-029
  (rustfmt on `args.rs`), G-030, G-031.

## Changes made in REVIEW
- `docs/decisions/ADR-0010-seasons-and-weather.md`: status changed from Proposed to Accepted.
- `docs/STATE.md`: REVIEW block added.
- This file and `review-cycle1.json`.
- No code, tests, task.md, task.json, benchmark files or commits were touched.

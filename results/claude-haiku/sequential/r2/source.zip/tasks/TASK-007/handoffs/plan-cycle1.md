# TASK-007 PLAN cycle 1: Seasons and weather

Scope: time dependence of the climate (seasonal cycle and seeded weather). No effects on plants or animals. No feature code changed
in PLAN. Decisions: `docs/decisions/ADR-0010-seasons-and-weather.md` (Proposed). This file gives the order, interfaces, tests and risks.

## Starting state (checked in PLAN)
- HEAD `f4efea9 TASK-006 review cycle 1 PASS`, working tree clean at start. `git remote -v | wc -l` = 0.
- `cargo test -p evosim-core --locked`: exit 0, 112 passed (baseline, PATH includes `/opt/rust/cargo/bin`).
- `bash scripts/check_adrs.sh`: exit 0, checks=76 failed=0 (ADR-0010 not yet in the list).
- `config.climate.season_length` (default 240, 1..=100000) and `config.climate.weather_amplitude` (default 0.15, 0.0..=1.0) already
  exist (ADR-0006). No config key is added by this task.
- `climate.rs`: base field only (`CellClimate` with `latitude`, `biome`, `temperature`, `precipitation`). `Climate::new(&Torus, seed)`,
  `Climate::from_parts(Torus, Vec<WaveTerm>)`, `TEMPERATURE_BOUNDS = (-25, 31)` for the base field.
- `sim.rs`: `Phase::Climate` arm of `run_phase` is empty; `World { topology, climate }`; `Simulation` derives `PartialEq` only.

## Decisions (short; full text in ADR-0010)
- Calendar: one global phase, `sin(2 pi (t mod Y)/Y)`, `Y = climate.season_length`. No hemispheric reversal: north and south poles are the
  same seam, so reversal would be a temperature jump at the poles. Seasonal temperature amplitude `20 * phi/90` C; precipitation
  multiplier `1 + 0.2 sin`.
- Weather: value-noise lattice `ceil(W/8) x ceil(H/8)`, node values in `[-1, 1]`, AR(1) per tick `n = clamp(0.9 n + 0.3 u)` with
  `u = 2 next_f64() - 1` from `Simulation.rng`, nodes in row-major order, drawn only in the Climate phase and only if
  `weather_amplitude > 0`. Field is bilinear with smoothstep, lattice index wraps, so it is periodic and seam-free.
- Effects: temperature `+ amp * 10 * w` C; precipitation multiplier `+ amp * w`.
- Query: `Climate::conditions(cell)` for the last finished tick (base + variation + season + weather, clamped);
  `Climate::seasonal_conditions(cell, tick)` pure for any tick. Full weather at arbitrary past ticks is not supported (no history).
- Bounds: temperature `[-70, 50]` C, precipitation `[0, 5000]` mm/yr (clamped and tested). ADR-0009 base bound `-25..31` kept for the base field.
- State: `Climate` gains `params`, `nodes`, `weather_tick`; `PartialEq` on `Climate`; `from_parts` validates. Checkpoint (TASK-022) must save
  these.

## Ordered IMPLEMENT steps
1. `crates/evosim-core/src/climate.rs`:
   - `pub struct ClimateParams { pub season_length: u64, pub weather_amplitude: f64 }` (validated in `from_parts`).
   - `pub struct Conditions { pub temperature: f32, pub precipitation: f32 }`.
   - Constants: `WEATHER_RHO = 0.9`, `WEATHER_SIGMA = 0.3`, `WEATHER_CELL = 8`, `SEASON_TEMPERATURE_SWING = 20.0`, `SEASON_PRECIPITATION_SWING = 0.2`,
     `WEATHER_TEMPERATURE_SCALE = 10.0`, `TEMPERATURE_RANGE = (-70.0, 50.0)`, `PRECIPITATION_RANGE = (0.0, 5000.0)`.
   - `Climate` fields added: `params`, `nodes: Vec<f64>`, `weather_tick: u64`, `lattice: (u32, u32)`.
   - `Climate::new(torus, seed)` keeps its signature for base fields; gains a `params` argument: `Climate::new(torus, seed, params)`.
     Nodes start at 0; `weather_tick = 0`. No draws at creation.
   - `pub fn advance(&mut self, rng: &mut Rng, tick: u64)`: if `weather_amplitude == 0` only sets `weather_tick = tick`; otherwise updates nodes in
     row-major order and sets `weather_tick = tick`.
   - `pub fn seasonal_conditions(&self, cell: Cell, tick: u64) -> Conditions` and `pub fn conditions(&self, cell: Cell) -> Conditions`
     (uses `weather_tick`). Both clamp to the ranges.
   - `fn weather_at(&self, x, y) -> f64` (bilinear + smoothstep, periodic).
   - `pub fn from_parts(torus, terms, params, nodes, weather_tick) -> Result<Climate, ClimateError>`: validates counts, finiteness, ranges.
     Existing `from_parts` callers (tests) updated.
   - `Climate` derives `PartialEq`; `CellClimate` already `PartialEq`? Check and derive as needed.
2. `crates/evosim-core/src/sim.rs`:
   - `Simulation::new` passes `ClimateParams { season_length: config.climate.season_length, weather_amplitude: config.climate.weather_amplitude }`.
   - `run_phase(Phase::Climate)` calls `self.world.climate.advance(&mut self.rng, self.tick)`. Update module doc (Climate phase now live).
   - `from_parts` unchanged in shape (World carries the climate).
   - `Simulation` keeps `PartialEq`; `World` keeps `PartialEq`.
3. `crates/evosim-core/src/lib.rs`: nothing new unless `ClimateError` is re-exported.
4. Tests in `climate.rs` (list in ADR-0010 Verification), plus one in `sim.rs`: the trace fingerprint changes after the Climate record when weather is on (G-025).
5. `scripts/check_adrs.sh`: add `ADR-0010-seasons-and-weather.md` to the checked list and its header comment. Check the six headings. No other change.
6. Docs:
   - `docs/ARCHITECTURE.md`: climate row (seasons and weather now in `core::climate`, phase `Climate` live); status paragraph for TASK-007.
   - `docs/decisions/ADR-0010`: keep Proposed in IMPLEMENT, add "Implementation notes"; status updated at REVIEW only.
   - `docs/decisions/ADR-0006` (wording of `weather_amplitude` comment only, if the implementer agrees; otherwise record as gap).
   - `docs/STATE.md`: IMPLEMENT block with commands and exit codes.
7. Run and record: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
   `bash scripts/check_adrs.sh`, `bash scripts/test.sh`, `./build.sh`, `./evosim climate --config <64x48 example> --format text` (base map
   unchanged: P 1024, U 256, T 512, D 256, R 1024). Record exact outputs.
8. Optional, if time allows: a text export of one year for a 64x48 world (not required by the task; do not add CLI keys beyond what the
   contract requires).

## Tests (planned; IMPLEMENT may add more)
- `seasonal_zero_at_equator`, `seasonal_amplitude_at_pole` (A_T(0)=0, A_T(pole)=20, sin peak at Y/4).
- `year_repeats_exactly_with_weather_off`: amplitude 0, Y=240, 480 ticks, compare `conditions` per cell at t and t+Y, bitwise (`to_bits`).
- `weather_is_seeded`: same seed identical, different seed different nodes.
- `weather_uses_simulation_rng` and the trace test above.
- `bounds_hold_over_long_runs`: 10 years at amplitude 1.0, seeds 1..=3, every cell every tick; ranges hold, values finite.
- `weather_field_periodic_and_continuous`: exact periodicity at `x=0` vs `x=W`, `y=0` vs `y=H`; seam step <= interior step.
- `small_worlds_weather`: 1x1, 1x7, 7x1, 2x2, 200x3, 100 ticks each.
- `from_parts_roundtrip_continues_identically`: restore mid-run, 50 more ticks, equal state.
- `from_parts_rejects_bad_weather`: node count, value 1.5, NaN, season_length 0, amplitude -0.1 are errors.
- `clamp_is_not_hit_in_normal_runs` (diagnostic): counts clamp hits over the bounds run; report the number, expect 0.

## Risks
- "Queried at any tick": only the seasonal part is available for arbitrary ticks; full values are for the last finished tick. Documented
  decision; consumers needing history must be designed separately.
- Calendar is global (one seasonal phase for the whole torus). Documented consequence of the fold; a reader expecting hemispheric
  opposition will not see it.
- Constants are plausible, not calibrated. Ecology tasks will depend on them.
- Checkpoint (TASK-022) must include `params`, `nodes`, `weather_tick`; otherwise a resumed run differs from an uninterrupted one. Recorded
  for the checkpoint task; not in TASK-007 scope.
- `weather_amplitude` wording in ADR-0006 differs from the reference scale used here.
- Float results use libm `sin` and `cos` (already linked since TASK-006; no new system library).
- `./evosim` uses a stale release binary after source edits (G-026, pre-existing): run `./build.sh` before black-box checks.
- Config default `season_length` is 240, so with weather on the first year already shows weather; no test relies on the default.

## Gaps carried in (not in TASK-007 scope)
- G-026 (stale `./evosim`), G-027 (`scripts/test.sh` lacks the `evosim climate` black-box step), G-029 (rustfmt on `args.rs`), G-030 (weak zero-width
  test), G-031 (seam test is weak at steep latitudes). G-025 is addressed by TASK-007 for the Climate phase (trace changes with weather).
  IMPLEMENT should not widen scope to close G-026..G-031 unless trivial; report them if unchanged.

## Next steps (for IMPLEMENT)
1. Write the climate state, advance, queries and `from_parts` validation in `climate.rs`; run `cargo test -p evosim-core --locked`.
2. Wire `Simulation::new` and the Climate phase in `sim.rs`; run the trace tests.
3. Add the test list; `cargo test --workspace --locked` and clippy.
4. Extend `scripts/check_adrs.sh` for ADR-0010; run it. Run `scripts/test.sh` and `./build.sh`.
5. Record evidence in `implement-cycle1.md/.json`, STATE and ARCHITECTURE.

## Environment in PLAN
- No system packages needed; no network use; `git remote -v` = 0 lines.
- Time limit respected: planning only.

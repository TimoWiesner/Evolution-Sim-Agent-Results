# TASK-019 IMPLEMENT cycle 1: headless `evosim run`

Verdict field: N/A (IMPLEMENT). Machine-readable record: `implement-cycle1.json`.

## What was built
- `evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K]` (CONTRACT sections 2, 4, 5; ADR-0020).
- Core: `sha256.rs` (std SHA-256), `checkpoint.rs` (canonical encoding and `state_hash`), `metrics.rs` (series, counts, result JSON),
  `encode_state` in the state modules, `SpeciesRegistry::living_now`.
- Tests: `crates/evosim-cli/tests/run_cli.rs` (9 end-to-end), plus unit tests in sha256, checkpoint, metrics, args and main.
- Black-box step 8 in `scripts/test.sh`; example configuration `examples/config.json`; README run section.

## Gate results (final code)
| Command | Exit | Result |
|---|---|---|
| `cargo test --workspace --locked` | 0 | core 388 passed, 1 ignored; cli 23 unit + 9 integration passed |
| `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` | 0 | 0 warnings |
| `bash scripts/check_adrs.sh` | 0 | checks=153 failed=0 |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED |
| `git remote -v \| wc -l` | 0 | 0 |

## Must-have points and where they are shown
- Flags, result JSON, determinism and errors (CONTRACT 2, 4, 5): `run_cli.rs` (same seed, different seed, error cases), `scripts/test.sh` step 8.
- Runs without a display: `run_cli.rs::runs_without_a_display_and_creates_parent_directories` (DISPLAY and WAYLAND_DISPLAY removed); `test.sh` step 8 runs with `env -u`.
- Exactly N ticks, also after extinction; `--ticks 0` valid: `run_cli.rs::zero_ticks_is_valid_and_writes_one_sample`, `all_extinct_still_runs_every_requested_tick`.
- Errors exit 2, message on stderr, no result file: `run_cli.rs::errors_exit_2_write_nothing_and_print_a_message`, `failed_run_keeps_an_existing_result_file`.
- `state_hash` covers the complete state: `checkpoint::tests` (one change per field group changes the hash; equal states hash equal; rebuilt state hashes equal; climate cache recomputed from parts).
- End-to-end same-seed comparison and README example: `run_cli.rs::same_seed_gives_identical_results_end_to_end`; README "Run" section; `test.sh` step 8.

## Decisions taken in IMPLEMENT (details in ADR-0020 "Implementation record")
- `config::json` made `pub` (visibility only) so tests and the result writer can use its parser.
- `Climate.torus` is encoded; only the `cells` cache is excluded.
- `series` samples are written inline, one per line; all other keys are one per line.
- `run_run` creates the output directory before the run; the result is written atomically.

## Manual observations (not a pass criterion)
- Example configuration, seed 42, 1000 ticks: 0.17 s wall clock; at tick 1000 herbivores and carnivores are extinct. This is the known balance issue (TASK-018 D-2, TASK-027), allowed by CONTRACT 5.3.

## Known gaps
- `deaths_by_cause` and `last_deaths` have no test that changes them alone (no public setter). They are covered by the compile-time destructuring.
- `--save`/`--load` (TASK-022) and `batch` (TASK-021) are not implemented, by design.
- The ADR-0020 status remains Proposed until REVIEW.

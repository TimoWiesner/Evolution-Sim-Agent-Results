# TASK-019 PLAN cycle 1: headless command line

Decisions: `docs/decisions/ADR-0020-headless-run-result-and-state-hash.md` (Proposed). No product code was changed in PLAN.

## Baseline (checked in PLAN, PATH includes /opt/rust/cargo/bin)
- `cargo test --workspace --locked` -> exit 0.
- `bash scripts/check_adrs.sh` -> exit 0, checks=153 failed=0.
- `git remote -v | wc -l` -> 0.
- `./target/release/evosim run --ticks 1` -> exit 2, "unknown command 'run'" (no run command exists yet).
- No crate registry is cached (`~/.cargo/registry` and `/opt/rust/cargo/registry` absent), so no new crate can be fetched
  offline. Std-only design is required. `sha256sum` (coreutils) exists and can cross-check digests in IMPLEMENT.

## Findings that shape the plan
- `Simulation` derives `PartialEq` and holds all state; it has no encoder. `checkpoint.rs` does not exist (TASK-022 owns load).
- `Simulation::populate_initial` places founders; `Simulation::new` does not. `run` must call both (G-037).
- `Entities` has the per-kind `initial/births/deaths` counters and `living_count`; `SpeciesRegistry::living_count` needs `tick < now`,
  so a final-species helper is needed (ADR-0020 D5).
- Private fields in `Organism`, `Entities`, `Climate`, `SpeciesRegistry`, `Genome`, `Torus`, `ResourceField`, `Rng` mean that the
  encoder must live in each module (method `encode_state`) or use `pub(crate)` accessors. Per-module methods are chosen.
- `Climate.cells` is a cache (`climate.rs` comment: "Everything except `cells` is simulation state"). Excluded from the hash
  by ADR-0020 D3; a test must show it is recomputed from the rest.
- `config/json.rs` has a writer (`write(&Value)`), but its `Value::Real` uses `{:?}`, which is valid JSON for finite values.
  The result writer can reuse it or write the fixed layout directly; the layout must be one key or element per line (ADR-0020 D2).

## Ordered implementation steps (for IMPLEMENT)
1. `crates/evosim-core/src/sha256.rs` (new, std only): `digest(bytes) -> [u8; 32]`, `hex(digest) -> String`. Tests: FIPS vectors
   (empty, `abc`, 448-bit two-block, one million `a`), cross-checked with `sha256sum`.
2. `crates/evosim-core/src/checkpoint.rs` (new): `Encoder` (little-endian writer with `u8/u32/u64/f32/f64/bool/bytes/len`),
   `encode_state(&Simulation) -> Vec<u8>` (magic `EVOSIMST`, format 1, fixed field order), `state_hash(&Simulation) -> String`.
   Per-module `encode_state(&self, enc: &mut Encoder)` added to: `rng.rs` (`Rng`: 4 words), `world.rs` (`Torus`: width, height),
   `climate.rs` (`params`, `terms`, `nodes`, `weather_tick`; not `cells`), `ecology.rs` (`ResourceField::values`),
   `genome.rs` (`Genome`: ploidy, loci), `entities.rs` (`Organism` all fields, `Entities` all fields, `LifespanRanges`), `species.rs`
   (`SpeciesRegistry` settings, records, candidates, name counters; `SpeciesRecord`, `Candidate`), `reproduction.rs`
   (`SeedingSettings`), `mating.rs` (`MatingSettings`), `sim.rs` (`Simulation` tick, rng, world (topology, climate, resources),
   entities, seeding, mating, species, lifespans; excludes `spatial` and `trace`). Every method destructures its struct without `..`.
3. `species.rs`: `SpeciesRegistry::living_now(kind) -> usize` (records of kind with `extinct_tick` absent).
4. `crates/evosim-core/src/metrics.rs` (new; ARCHITECTURE `core::metrics`): `KindCounts` (initial, births, deaths, living,
   species living, species recognised), `Sample { tick, counts per kind }`, `sample(&Simulation) -> KindCounts`,
   `series_ticks(tick_start, tick_end, K) -> Vec<u64>` (ADR-0020 D4, pure), `RunResult` with the fields of ADR-0020 D2 and
   `to_json(&self) -> String` (fixed layout, one element per line, valid JSON, finite numbers only).
   `lib.rs`: `pub mod sha256; pub mod checkpoint; pub mod metrics;`.
5. `crates/evosim-cli/src/args.rs`: `Command::Run(RunArgs)`, `RunArgs { config: PathBuf, ticks: u64, out: PathBuf, seed: Option<u64>,
   sample_every: Option<u64> }`, `parse_run` (ADR-0020 D1 and D7 errors; `--save`/`--load` rejected with the TASK-022 message).
   Existing `run_is_not_yet_available` parser test changes to "run needs --config, --ticks and --out".
6. `crates/evosim-cli/src/main.rs`: `run_run(&RunArgs) -> Result<(), String>`:
   load config (`Config::load`, key-named errors as `run_climate` does) -> apply `--seed` -> `K` default or check `>= 1` ->
   `Simulation::new` -> `populate_initial` -> `Instant` start -> loop `N` times `sim.tick()` (no early stop) with samples at
   `series_ticks` -> `elapsed` -> `final`, `totals`, `series`, hash -> `RunResult::to_json` -> write temp file in the target
   directory, rename to `--out` (create parents first). No stdout output. Help text lists `run`.
7. `crates/evosim-cli/tests/run_cli.rs` (new): end-to-end tests with `env!("CARGO_BIN_EXE_evosim")` in a temp directory.
8. `scripts/test.sh`: add a black-box step, `./evosim run` twice with the same seed on a small configuration written to a temp
   directory, `cmp` after removing the two wall-clock lines; exit-code checks for an invalid config and for `--save`.
   The step must run after `./build.sh` (G-026: `./evosim` does not rebuild a stale binary).
9. Documentation: `docs/ARCHITECTURE.md` (TASK-019 note and module rows `core::checkpoint`, `core::sha256`, `core::metrics`),
   `README.md` (run example, see below), `docs/STATE.md` (IMPLEMENT and REVIEW entries), ADR-0020 status at REVIEW.

## Planned tests (names are proposals)
- `sha256::tests::nist_vectors`, `sha256::tests::matches_sha256sum_for_a_fixed_input` (value recorded from `sha256sum`).
- `checkpoint::tests::equal_states_hash_equal`, `one_change_per_field_group_changes_the_hash` (RNG word, tick, organism energy
  bit, genome locus, species record, resource value, weather node, climate parameter, next_id, deaths_by_cause, settings),
  `hash_changes_after_a_tick`, `derived_cache_is_recomputed_from_parts` (climate cells after `from_parts` equal).
- `metrics::tests::series_ticks_*` (zero ticks, K larger than N, K = 1, last tick not on the grid), `to_json_is_valid` (parse with
  `config::json::parse`), `totals_balance` (initial + births - deaths = final for every kind after 1,000 ticks).
- `args::tests::run_*` (missing options, repeated option, `--sample-every 0`, `--ticks -1`, `--save`, `--load`, unknown option).
- `tests/run_cli.rs`: `same_seed_same_result` (final, totals, series, state_hash equal), `different_seed_different_hash`,
  `ticks_zero_is_valid` (tick_end 0, series one element), `all_extinct_still_runs_all_ticks` (initial plants 0, herbivores 0,
  carnivores 0 and 1000 ticks: tick_end 1000, series ends at 1000), `errors_exit_2_and_write_nothing` (bad config type, missing
  key range, unknown option, `--save`, `--sample-every 0`), `runs_without_display` (env cleared of DISPLAY and WAYLAND_DISPLAY).
- Gates: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`, `bash scripts/check_adrs.sh`,
  `bash scripts/test.sh` after `./build.sh`, `git remote -v | wc -l` = 0.

## README example (to add in IMPLEMENT)
```sh
./evosim run --config examples/config.json --ticks 1000 --out results/run.json   # any JSON configuration (CONTRACT section 3)
```
The example configuration of CONTRACT section 3 is written out as a file in the README or in `examples/`. `scenarios/demo.json`
is owned by TASK-028, not this task.

## Risks
- R1 Width of the change: about eight modules gain `encode_state`. Mitigation: exhaustive destructuring (compile error on a new
  field). Cost: moderate; no behaviour change.
- R2 Derived-cache mistakes: a cache wrongly left out of the hash is not caught by the compiler. Mitigation: the rebuild test for
  `Climate.cells`, and `check_spatial` in tests after each tick.
- R3 Float bits: the hash is bit-exact on one build; cross-platform differences are allowed by CONTRACT section 5.1.
- R4 Overlap with TASK-022: its checkpoint reuses `encode_state` and needs the decoder. Any change of encoding must bump the format
  version (ADR-0020 D3).
- R5 Performance: not a TASK-019 requirement. Measured elsewhere: 10,000 ticks at about 1 to 2.6 s per seed for the default
  configuration (`docs/results/TASK-018-survival.md`). The hash is computed once per run.
- R6 `./evosim` does not rebuild a stale binary (G-026). The test step runs `./build.sh` first.
- R7 Unwritable output at the end of a long run loses the run. Accepted: the error is reported with exit 2 and no file.
- R8 `--seed` changes the seed before `populate_initial`, so the founders follow the new seed; this is intended.

## Open items handed to IMPLEMENT
- Decide the exact text of the `checkpoint` error message for `--save` and `--load` (ADR-0020 D1 gives it).
- Confirm that `Climate` `cells` is a pure function of the included fields by test (R2); if not, include it and say so in ADR-0020.

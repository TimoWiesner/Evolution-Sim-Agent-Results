# TASK-019 REVIEW cycle 1: headless command line

Verdict: **PASS**. Machine-readable record: `review-cycle1.json`.

## Scope
Fresh review of the IMPLEMENT cycle 1 diff (commit `dafb1bf`) against `tasks/TASK-019/task.md` "Must have", `docs/CONTRACT.md`
sections 2, 4, 5 (checkpoint flags excepted), and ADR-0020. No product code was changed in REVIEW. Docs changed: ADR-0020 status
(Proposed to Accepted), `docs/STATE.md` (REVIEW entry).

## Acceptance criteria
1. **Flags, result JSON, determinism, errors (CONTRACT 2, 4, 5)**: met. Checked by `run_cli.rs` (9 tests), `scripts/test.sh` step 8,
   and manual runs. Result keys match CONTRACT section 4 plus the ADR-0020 additions (`totals.initial`, `sample_every`,
   `state_format`, `hash_algorithm`, `species_recognised`). Python `json` parses the output; `initial + births - deaths = final`
   holds for every kind.
2. **Runs without a display**: met. `runs_without_a_display_and_creates_parent_directories`; step 8 runs with `env -u DISPLAY -u WAYLAND_DISPLAY`.
3. **Exactly N ticks, also after extinction, `--ticks 0` valid**: met. `Simulation::run(n)` is a plain loop with no early exit; the CLI
   loop runs `target - tick_count` per sample. Tests `zero_ticks_is_valid_and_writes_one_sample`, `all_extinct_still_runs_every_requested_tick`.
4. **Errors exit 2, stderr message, no result file**: met. Manual probes (all exit 2, one stderr line, no file): `--ticks -1`,
   `--ticks 99999999999999999999`, unknown option, `--save`, `--load`, `--sample-every 0`, missing config, `seed` real or negative or
   above u64 max, `world.width` real, string, `1e3`, `u64::MAX`, 100000 and 0, `initial.plants` out of range, extra key,
   `season_length` 0, trailing JSON data, `{}`, empty input. No panic (101) or abort seen. Existing result file is kept on a failed run.
5. **`state_hash` covers the complete state**: met, with documented derived exclusions. Every module's `encode_state` destructures its
   struct without `..`, so a new field that is not encoded is a compile error. Excluded fields checked by reading the code:
   - `Simulation.spatial`: derived. `SpatialIndex::within_into` sorts its output by id, so bucket order cannot change behaviour.
   - `Climate.cells`: written only at construction (`fill`, `from_parts`), so it is a pure function of the encoded terms and parameters.
     `Climate::from_parts` test checks this.
   - `Simulation.trace`: diagnostic. `tick()` only pushes to it; nothing reads it back.
   Unit tests in `checkpoint::tests` change one field group at a time and check that the hash changes.
6. **End-to-end same-seed test and README example**: met. `same_seed_gives_identical_results_end_to_end`; step 8; README line 39
   `./evosim run --config examples/config.json --ticks 1000 --out results/run.json`.

## Gate results (run in REVIEW)
| Command | Exit | Result |
|---|---|---|
| `cargo test --workspace --locked` | 0 | core 388 passed, 1 ignored; cli 23 unit + 9 integration passed |
| `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets` | 0 | clean |
| `bash scripts/check_adrs.sh` | 0 | checks=153 failed=0 |
| `./build.sh` | 0 | release binary rebuilt |
| `bash scripts/test.sh` | 0 | ALL TESTS PASSED |

## Determinism and sanity (manual)
- Two `./evosim run --config examples/config.json --ticks 1000` runs (seed 42): identical after dropping `elapsed_seconds` and
  `ticks_per_second`. `state_hash` efb224ee... at tick 1000 in this container.
- `--ticks 0`: tick_end 0, one series element, `ticks_per_second` 0.0, hash present.
- Stdout empty for every successful run.

## Findings
- No blocking defect.
- Non-blocking gap (carried): `deaths_by_cause` and `last_deaths` have no test that changes them alone. They are encoded
  (`entities.rs` encode_state writes both) and compile-checked by destructuring, but no public setter exists to change them in
  isolation. Suggest a unit test once a setter or a sequence of deaths can isolate them (TASK-022 or later).
- Non-blocking observation: `--ticks` near `u64::MAX` is accepted and would run effectively forever. This is valid per CONTRACT
  and not an error. No change requested.
- Non-blocking observation: the default configuration collapses (herbivores and carnivores extinct by tick ~1000). This is the known
  balance issue (TASK-018 D-2, TASK-027). CONTRACT 5.3 allows extinction, and it is not a TASK-019 criterion.

## Not verified
- Cross-platform hash equality (CONTRACT 5.1 scope: same machine and build only).
- `--save`/`--load` and `batch` are out of scope (TASK-022, TASK-021).
- External JSON libraries beyond python3 `json` were not run.

## Documentation persisted
- `docs/decisions/ADR-0020-headless-run-result-and-state-hash.md`: status Accepted.
- `docs/STATE.md`: "TASK-019 REVIEW cycle 1" entry with the gate results and carried gaps.
- Not modified: `task.md`, `task.json`, benchmark state, tools. No commit made.

# TASK-017 REVIEW cycle 1: species and family tree

Verdict: **PASS**. Every acceptance point in `tasks/TASK-017/task.md` is met by a named test or a recorded command.
No product code was changed in REVIEW. Documents changed: `docs/decisions/ADR-0018-species-criterion-and-family-tree.md`
(Accepted; pair-count text corrected; Measurement section added), `docs/decisions/README.md` (status line), `docs/ARCHITECTURE.md`
(species row, status), `docs/STATE.md` (REVIEW section), this file and the JSON handoff. No commit made; `task.md` and `task.json` untouched.

## Acceptance points

1. **Every organism belongs to a species of its kind, by a documented rule based on genetic distance.** Rule: ADR-0018
   (single linkage, edge `d <= species.distance`, `d` = integer sum / (L*255)). Shown by `founding_gives_one_species_per_kind_at_tick_zero`,
   `every_organism_has_a_species_over_a_run_and_newborns_inherit_the_mothers` (300 ticks, every living organism checked after each tick),
   and the probe run (all living organisms had a species in every sampled state).
2. **Species IDs and names deterministic.** `same_seed_gives_identical_records_names_and_species_after_1000_ticks` (full registry, ids of
   living organisms and RNG state equal across two runs), `identical_inputs_give_identical_records_and_names`; names unique per kind
   (checked in the same test). Names are `PL/HE/CA` + 4-digit per-kind sequence (`PL0001`, `HE0001`, `CA0001` at tick 0).
3. **New species arises at divergence; test forces divergence and observes the split; behaviour at the threshold tested.**
   `threshold_boundary_is_inclusive_for_animals_and_plants` (distance exactly `3916/(L*255)` stays one cluster; one unit above splits;
   L = 256 and L = 128), `split_appears_only_after_persistence_checks` (no split after 3 checks, split at the 4th, parent and name checked),
   `candidate_that_disappears_resets_its_counter`. The divergence is forced with synthetic genomes at classifier level.
   Caveat (G-SP4, G-SP6): no simulation-level split was observed in calibration runs (see Measurement).
4. **Each species record keeps parent, arose tick, extinct tick.** `founding_gives_one_species_per_kind...` (arose 0, parent None,
   extinct None), `split_appears_only_after_persistence_checks` (parent = provisional species, arose tick 100),
   `extinction_is_recorded_at_the_death_tick_and_queries_answer_past_ticks` (extinct tick = tick of last death). The probe also
   recorded sim-level extinctions (carnivore species extinct at tick 269 and 284; plants and herbivores at 611, 696 in seed 2).
5. **Living species per kind queryable at any tick.** `living_count(kind, tick, now)` answers from the records and errors for a tick
   that is not finished. Tested by `extinction_is_recorded_at_the_death_tick_and_queries_answer_past_ticks` (past ticks, synthetic) and
   `living_count_answers_past_ticks_from_the_records` (simulation, plants only; see G-SP5 for its weakness).

## Commands run (exit codes)

| Command | Exit | Result |
|---|---|---|
| `cargo test -p evosim-core --locked` | 0 | 344 passed, 0 failed, 1 ignored |
| `cargo test --workspace --locked` | 0 | evosim-core 344 passed, 1 ignored; other crates 16 passed (evosim-cli) and 0 tests |
| `cargo clippy -p evosim-core --locked --all-targets` | 0 | no warnings |
| `rustfmt --edition 2021 --check species.rs sim.rs entities.rs` | 0 | formatted |
| `bash scripts/check_adrs.sh` | 0 | checks=153 failed=0 (run after each ADR edit) |
| `git remote -v \| wc -l` | 0 | 0 |
| temporary release probes (`cargo run --release --example ...`, removed afterwards) | 0 | see Measurement |

`scripts/test.sh` was not run separately; the workspace test run above covers the same crates.

## Measurement (release, recorded in ADR-0018 and ARCHITECTURE)

- One classifier call: 2,000 clonal animals 4.8 ms; 5,000 animals 28.4 ms; 5,000 plants 27.9 ms; 2,000 random (worst case) 66.9 ms.
  At `check_interval` 25 the 2,000-animal case is about 0.2 ms per tick on average. This meets the ADR-0018 budget, so the
  leader-clustering fallback is not needed.
- Default configuration (64 x 48, 400/120/20, 2,000 ticks, seeds 1, 2, 3): no split in any seed. Seeds 1 and 3 kept one plant and one
  herbivore species; carnivore species extinct at 269 (seed 1) and 284 (seed 3); seed 2 lost all kinds (extinct at 353, 611, 696).
- Plants only, 400 founders, 3,000 ticks, mutation rate 0.002 and 0.02: one plant species, no split.

Reading: single linkage keeps a continuous population as one species, which is the expected behaviour of the rule. Calibration of
`species.distance` is a configuration matter for TASK-018/027 and was not changed here.

## Review of the code (read, not only tested)

- `species.rs` `classify`: union-find clusters, identity by any member within threshold of a living recognised reference (lowest id
  wins), candidates continue only when unobserved in the current check, counter counts checks, recognition at `persistence_checks`,
  parent = most common provisional id (ties lowest id). No RNG draws, no hash maps, no member-count behaviour (the only count read is
  `record_count(kind) == 0` for founding, which counts records, not members).
- `within`: the early exit compares the exact integer partial sum to the threshold; the boundary is exact because both sides use the same
  float division.
- `Phase::Species` runs after Deaths, so `extinct_tick` is the tick of the last death (exact).
- `Organism.species` is `None` only before the founding check (classify and inherit_provisional always assign `Some` after founding).
- Newborn provisional id = mother's species (`parents()[0]`), set in the Reproduction arm.

## Gaps (non-blocking; none fails an acceptance point)

- **G-SP4**: no simulation-level test forces a split; the split is forced at classifier level only (synthetic genomes).
- **G-SP5**: `living_count_answers_past_ticks_from_the_records` has a comment that says the starved plant goes extinct, but the test only
  asserts count 1 at every tick; sim-level extinction is therefore covered only at unit level. Fix in a later cycle.
- **G-SP6**: default configuration gives no split in 2,000 ticks; single linkage chains continuous populations. Recalibrate the
  configuration (TASK-018/027); do not change the rule.
- **G-SP7**: the species state (records, candidates, name counters, `Organism.species`, settings) is not checkpointed; TASK-022.
- **G-037**: CLI wiring of `final.species` and founders is TASK-019.
- A species that dies before recognition leaves no record and no id (documented limitation, ADR-0018).

## Risks

- A loaded checkpoint cannot match an uninterrupted run until TASK-022 saves the species state.
- Split behaviour at realistic parameters is unknown until calibration; the species count may stay at one per kind for long runs.
- Per-tick cost at 5,000 entities (about 1.1 ms per tick per kind averaged) adds to the 100 ticks/s goal; not measured in the full loop.

## Next steps

1. TASK-018/027: calibrate `species.distance`, mutation and the other genetic settings so that splits can occur in long runs; record counts.
2. TASK-019: wire `final.species` from `living_count`; run the demo scenario.
3. TASK-022: checkpoint the species registry, candidates, name counters, settings and `Organism.species`.
4. Optional: make `living_count_answers_past_ticks_from_the_records` test a real extinction (G-SP5).

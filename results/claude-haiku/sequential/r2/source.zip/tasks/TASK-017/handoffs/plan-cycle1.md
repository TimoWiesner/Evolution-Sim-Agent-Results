# TASK-017 PLAN cycle 1: species and family tree

Scope: plan only. No product code, test, Cargo file, task file or benchmark file changed. Documents changed: ADR-0018 (new,
Proposed), `docs/decisions/README.md`, `docs/ARCHITECTURE.md`, `docs/STATE.md`, this file and the JSON handoff.

## 1. State found on entry
- `AGENTS.md`, `docs/PROJECT.md`, `docs/CONTRACT.md`, `docs/STATE.md`, `docs/ARCHITECTURE.md`, `tasks/TASK-017/task.md|json` read.
- Dependencies TASK-009 (genome, PASS), TASK-012 (plant reproduction, PASS), TASK-016 (animal reproduction, PASS) are done.
- Baseline: `cargo test -p evosim-core --locked` exit 0, **333 passed, 1 ignored** (`/tmp/plan17-baseline.txt`, not kept in the
  workspace). `git remote -v | wc -l` = 0.
- Existing species hooks: `config.rs` has `species.distance` (0.06), `species.check_interval` (25), `species.persistence_checks` (4),
  with validation and round-trip tests. `sim.rs` has `Phase::Species` as an empty arm (line ~574).
- No species code exists (`grep -i species crates/` finds config only).
- Relevant prior decisions: ADR-0004 (criterion, placeholders), ADR-0011 (organism fields, never-reused ids), ADR-0017
  (herbivore/carnivore mating; the mother is the lower-id parent; `Organism.next_mate_age`), TASK-016 STATE note on random
  founder distance (mean about 0.333).

## 2. Problem found in PLAN (changes the ADR-0004 plan)
1. **Random founders would each form their own species.** `populate_initial` gives every founder an independent random genome
   (pairwise distance about 0.333). With threshold 0.06 each founder is a singleton cluster, which gives N species at tick 0.
2. **The ADR-0004 cost claim was not measured.** Single linkage costs n(n-1)/2 * L byte comparisons per kind per check.
   Estimates (not measured): about 0.2 to 0.6 ms per tick averaged for 2,000 animals; must be measured.
3. **0.06 is not an attainable boundary.** Distance = S / (L * 255) with integer S. For L = 256, 0.06 * 65280 = 3916.8.
   The boundary test uses `k / (L * 255)` exactly.

## 3. Decisions (chosen; full reasons in ADR-0018)
- D1 **Clonal founders per kind.** `populate_initial` draws one ancestral genome per kind (`random_genome`), then each founder is
  `copy_child(&ancestor, mutation_from_config, rng)`. Amends TASK-009 D3. No new configuration key. Each kind starts as one species.
- D2 **Criterion (ADR-0004 kept):** single linkage over living organisms of one kind, edge when `d <= species.distance` (inclusive),
  union-find, ids ascending. Early exit allowed: the integer partial sum is compared with `floor(distance * L * 255)`.
- D3 **Identity:** a cluster matches a recognised species of the same kind when any member is within `species.distance` of that
  species' reference genome (its founder genome, stored, never changed). Several matches: lowest species id.
- D4 **Candidates and persistence:** an unmatched cluster becomes a candidate (matched to earlier candidates by the same reference
  rule). The counter counts checks, not ticks, and not member counts. A candidate not observed at a check is dropped (counter
  reset). Recognised at `persistence_checks` (default 4).
- D5 **Founding:** the first check after `populate_initial` (and any check where a kind has no recognised species) records clusters
  as recognised at once, `arose_tick` = that tick, parent None.
- D6 **Re-classification:** all living organisms of each kind at every tick `t` with `t > 0 && t % check_interval == 0`, in
  `Phase::Species`. Newborns take the mother's species (lower-id parent) as a provisional id until the next check. Candidate members
  keep their provisional id until recognition.
- D7 **Parent:** the most common provisional species among a new candidate's members at recognition (ties to lowest id).
- D8 **Extinction:** a recognised species with zero living members at the end of a tick gets `extinct_tick = t` (the tick of the last
  death). Checked each tick with an O(n) pass over organisms. Extinction is permanent.
- D9 **Ids and names:** `SpeciesId(u32)`, the registry index in creation order, never reused. Name `"<code><seq:04>"`, code PL / HE /
  CA, `seq` a per-kind counter from 1 (e.g. `HE0007`).
- D10 **Query:** `living_count(kind, tick)` = records with `arose_tick <= tick` and (`extinct_tick` none or `> tick`). Future tick: error.
- D11 **Storage (ADR-0011 amendment):** `Organism.species: Option<SpeciesId>`; `Simulation.species: SpeciesRegistry` (new
  argument of `from_parts`, as TASK-016 did for `mating`). TASK-022 must checkpoint the organism species, the records, open
  candidates and name counters.

## 4. Ordered IMPLEMENT plan
1. `crates/evosim-core/src/genome.rs`: no API change. Add `pub const` helpers only if needed for the boundary test.
2. `crates/evosim-core/src/species.rs` (new; `pub mod species;` in `lib.rs`):
   - `SpeciesId(u32)`, `SpeciesRecord { id, kind, name, parent, arose_tick, extinct_tick, reference: Genome }`,
     `Candidate { reference: Genome, parent: Option<SpeciesId>, checks: u64, members: Vec<OrganismId> }`,
     `SpeciesRegistry { records: Vec<SpeciesRecord>, candidates: Vec<Candidate> (per kind), name_seq: [u32; 3] }`,
     `SpeciesError` (zero interval, tick not a check, query in future).
   - Pure classifier: `pub fn classify(kind, members: &[Member { id, genome, provisional }], reg: &mut SpeciesRegistry, settings: SpeciesSettings, tick: u64) -> Result<Vec<Assignment>, SpeciesError>`
     where `SpeciesSettings { distance, persistence_checks }` (from `config.species`). Union-find over members sorted by id; returns
     `Assignment { id, species: Option<SpeciesId> }` for each member.
   - `pub fn extinction_pass(entities/iter, reg, tick)`: O(n) count of living members per recognised species; sets `extinct_tick`.
   - `living_count(&self, kind, tick) -> Result<usize, SpeciesError>`.
3. `crates/evosim-core/src/entities.rs`: `Organism.species: Option<SpeciesId>` (default None at spawn), `set_species`, getter `species()`.
   `Birth` gets `species: Option<SpeciesId>` set by `Simulation` from the mother. `check_invariants` checks that a species id is never
   reused for a different kind (cheap).
4. `crates/evosim-core/src/sim.rs`:
   - `populate_initial`: clonal founders (D1). Founding check (D5) right after placement, through `species::classify` with `tick == 0`
     and a founding flag. Test: one recognised species per kind at tick 0.
   - `from_parts` gets a `species: SpeciesRegistry` argument; `new` creates an empty registry. Update the existing call sites (TASK-016 precedent).
   - `run_phase(Phase::Species)`: if `tick > 0 && tick % interval == 0` run the classifier per kind (fixed order plants, herbivores,
     carnivores) and write back `species` ids; then always run `extinction_pass`.
   - Reproduction arm: the newborn's provisional species = mother's species (set in `mating.rs` / `reproduction.rs` at birth).
5. `crates/evosim-core/src/mating.rs`, `reproduction.rs`: set `Birth.species` from the mother (lower id). Only the birth path changes.
6. Tests (section 5).
7. Measurement: release-mode timing of one classification at 2,000 animals and 5,000 entities (probe test or example, removed or kept
   out of the default test run); three-seed 2,000-tick species counts. Record numbers in ADR-0018 and ARCHITECTURE.
8. Docs: ADR-0018 to Accepted at REVIEW only; ADR-0004 and ADR-0011 amendment notes; `docs/decisions/README.md` index line; ARCHITECTURE
   row for `core::species`; STATE.
9. Run commands (section 6), record exit codes in `implement-cycle1.json`.

## 5. Tests (each maps to a must-have)

| Must-have | Test |
|---|---|
| Every organism belongs to a species by a documented rule | `classify` assigns every member an id (none left None after founding and after a recognised check); the rule is ADR-0018. |
| Deterministic ids and names | Same synthetic input gives identical ids and names; a 1,000-tick sim with a fixed seed run twice gives identical records. |
| Split on divergence | Two groups of synthetic genomes at distance > threshold: after `persistence_checks` checks two recognised species; one check fewer: no split. |
| Threshold boundary | Distance exactly `k / (L*255)` with `k` such that the value equals threshold: one cluster. `k+1`: split. Test for animals (L=256) and plants (L=128). |
| Parent, arose tick, extinct tick | Split child has `parent` = the species of its members' provisional ids; `arose_tick` = recognition tick; a sim test kills the last member and checks `extinct_tick` equals the death tick. |
| Living count at any tick | `living_count(kind, t)` checked at several ticks in a run with a known split and an extinction, including past ticks. |
| Clonal founders | `populate_initial` one recognised species per kind at tick 0; founder pairwise distance < threshold. |
| No count-based rule | Grep-check in the test suite: no species code reads a count to change behaviour (review item; code search recorded). |

## 6. Commands for IMPLEMENT and REVIEW
- `cargo test -p evosim-core --locked` (baseline 333 passed, 1 ignored)
- `cargo test --workspace --locked`
- `cargo clippy -p evosim-core --locked --all-targets`
- `rustfmt --edition 2021 --check <touched .rs files>`
- `bash scripts/check_adrs.sh`
- `bash scripts/test.sh`
- `git remote -v | wc -l` (must be 0)
- release timing probe (IMPLEMENT only; command recorded with its output)

## 7. Risks
- R1 Single-linkage chaining: a continuous population stays one species; splits may never happen at the default threshold.
  Measured in IMPLEMENT; if so, recalibrate the config default and say so. Do not change the rule to force splits.
- R2 Cost: O(n^2 * L / 2) per check. Measured in IMPLEMENT; fallback is leader clustering (ADR-0018 alternative 2), with a new ADR.
- R3 Clonal founders change TASK-009 and TASK-016 founder genomes. Test expectations that depended on random founders (for example
  founder distance tests) must be re-run and explained, not silently edited.
- R4 Extinction is exact only for deaths in the same tick; a species extinct before recognition leaves no record.
- R5 Checkpoint (TASK-022) must save the registry, candidates, organism species and name counters; until then a loaded run cannot
  match an uninterrupted one (same as TASK-016 R4).
- R6 Calibration: 0.06 is a placeholder; founders at mutation rate 0.002 need many hundreds of generations to diverge that far.
  In a 2,000-tick run there may be no split at all. This is a result to record, not a failure of the criterion.

## 8. Gaps carried into IMPLEMENT
- G-SP1 (new): ADR-0004 cost estimate was not measured; closed by the timing probe in IMPLEMENT step 7.
- G-SP2 (new): 0.06 is not attainable as a genome-distance boundary for L=256; tests use `k/(L*255)`.
- G-037 remains open until TASK-019 wires `populate_initial` into the CLI.
- G-045 / G-A5 remain open until TASK-022 (checkpoint).

# TASK-017 IMPLEMENT cycle 1: species and family tree

Implemented ADR-0018 in `crates/evosim-core`: `species.rs` (new), `entities.rs` (`Organism.species`), `sim.rs` (clonal founders,
founding check, `Phase::Species` re-classification and extinction, newborn provisional ids, `from_parts` takes a `SpeciesRegistry`),
`lib.rs`, `docs/ARCHITECTURE.md` (row), `docs/STATE.md` (IMPLEMENT section).

Results: `cargo test -p evosim-core --locked` exit 0, 344 passed, 1 ignored. Clippy clean. `rustfmt --check` clean on `species.rs`.
`scripts/check_adrs.sh` exit 0. No remotes.

Not done (open for REVIEW): release timing of one species check at 2,000 animals and 5,000 entities; species counts after 2,000 ticks
for three seeds; ADR-0018 still Proposed and its pair-count text (0.5 M should be about 2.0 M) needs correcting; `cargo test --workspace`
and `scripts/test.sh` not run.

#!/usr/bin/env bash
# Produces the self-contained distributable dist/evosim (docs/CONTRACT.md section 6).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

log() { echo "[build] $*" >&2; }

find_cargo() {
    if command -v cargo >/dev/null 2>&1; then
        command -v cargo
    elif [ -x /opt/rust/cargo/bin/cargo ]; then
        echo /opt/rust/cargo/bin/cargo
    elif [ -x "${HOME:-/root}/.cargo/bin/cargo" ]; then
        echo "${HOME:-/root}/.cargo/bin/cargo"
    fi
}

CARGO="$(find_cargo || true)"
if [ -z "$CARGO" ]; then
    log "error: cargo not found; run ./setup.sh first"
    exit 1
fi
export PATH="$(dirname "$CARGO"):$PATH"

log "cargo build --release --locked"
cargo build --release --locked >&2

mkdir -p dist
cp target/release/evosim dist/evosim.tmp
chmod 755 dist/evosim.tmp
mv dist/evosim.tmp dist/evosim
log "wrote $ROOT/dist/evosim"

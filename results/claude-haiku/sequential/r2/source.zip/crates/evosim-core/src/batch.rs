//! Batch runs: parameter sweeps, per-kind aggregates, the summary and the CSV text (ADR-0022, TASK-021).
//!
//! Everything here is a pure function of its arguments: no files, no clock, no threads. The CLI runs the simulations
//! (through [`crate::runner`]), writes the texts and decides the order of the writes. Floats are written with `{:?}`,
//! the same shortest round-trip form as the result file (ADR-0020 D2).

use crate::config::json::{self, Value};
use crate::config::Config;
use crate::entities::Kind;
use crate::metrics::RunResult;

/// Format name of `summary.json` (ADR-0022 D3).
pub const SUMMARY_FORMAT: &str = "evosim-batch-summary";
/// Version of the summary layout (ADR-0022 D3).
pub const SUMMARY_FORMAT_VERSION: u32 = 1;
/// Names of the kinds in the order of the per-kind arrays.
pub const KIND_NAMES: [&str; 3] = ["plants", "herbivores", "carnivores"];

/// One `--vary KEY=V1,V2,...` sweep: a dotted configuration key and the scalar values it takes.
#[derive(Clone, Debug, PartialEq)]
pub struct Vary {
    pub key: String,
    pub values: Vec<Value>,
}

/// One combination of sweep values. `name` is `case-00`, `case-01`, ... (ADR-0022 D2).
#[derive(Clone, Debug, PartialEq)]
pub struct Case {
    pub name: String,
    /// The values, in the order of the `--vary` options.
    pub params: Vec<(String, Value)>,
}

/// The cartesian product of the sweeps, the first sweep varying slowest. With no sweep there is one case with no
/// parameters. Case numbers have the same width (at least two digits) so that they sort as text.
pub fn expand_cases(vary: &[Vary]) -> Vec<Case> {
    let mut combos: Vec<Vec<(String, Value)>> = vec![Vec::new()];
    for sweep in vary {
        let mut next = Vec::with_capacity(combos.len() * sweep.values.len());
        for combo in &combos {
            for value in &sweep.values {
                let mut extended = combo.clone();
                extended.push((sweep.key.clone(), value.clone()));
                next.push(extended);
            }
        }
        combos = next;
    }
    let last = combos.len() - 1;
    let width = last.to_string().len().max(2);
    combos
        .into_iter()
        .enumerate()
        .map(|(i, params)| Case {
            name: format!("case-{i:0width$}"),
            params,
        })
        .collect()
}

/// The configuration of one run (ADR-0022 D2): `base` with the case values set through the JSON tree, then `seed`,
/// then validated again by [`Config::from_json`]. An unknown key or an invalid value is an error naming the key.
pub fn run_config(base: &Config, params: &[(String, Value)], seed: u64) -> Result<Config, String> {
    let mut tree = json::parse(&base.to_json())?;
    for (key, value) in params {
        set_path(&mut tree, key, value.clone())?;
    }
    set_path(&mut tree, "seed", Value::Int(i128::from(seed)))?;
    Config::from_json(&json::write(&tree)).map_err(|e| match &e.key {
        Some(key) => format!("{key}: {}", e.message),
        None => e.message,
    })
}

/// Replaces the value at the dotted `key` of an object tree. Every segment must exist; a missing one is an error.
fn set_path(root: &mut Value, key: &str, value: Value) -> Result<(), String> {
    let parts: Vec<&str> = key.split('.').collect();
    let mut node = root;
    for (i, part) in parts.iter().enumerate() {
        let Value::Object(fields) = node else {
            return Err(format!("'{key}' is not a configuration key"));
        };
        let pos = fields
            .iter()
            .position(|(name, _)| name == part)
            .ok_or_else(|| format!("unknown configuration key '{key}'"))?;
        if i + 1 == parts.len() {
            fields[pos].1 = value;
            return Ok(());
        }
        node = &mut fields[pos].1;
    }
    Err(format!("'{key}' is not a configuration key"))
}

/// Mean, minimum, maximum and population standard deviation of the final population of one kind, and how many runs
/// ended with none of that kind (ADR-0022 D3). Extinct means zero living individuals at `tick_end`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct KindAggregate {
    pub runs: u64,
    pub final_mean: f64,
    pub final_min: u64,
    pub final_max: u64,
    pub final_sd: f64,
    pub extinct_runs: u64,
}

impl KindAggregate {
    /// `extinct_runs / runs`.
    pub fn extinct_fraction(&self) -> f64 {
        self.extinct_runs as f64 / self.runs as f64
    }
}

/// The aggregate of the final populations `finals` (one per run, in run order). `None` for no runs.
pub fn aggregate(finals: &[u64]) -> Option<KindAggregate> {
    if finals.is_empty() {
        return None;
    }
    let n = finals.len() as f64;
    let sum: u64 = finals.iter().sum();
    let mean = sum as f64 / n;
    let variance = finals
        .iter()
        .map(|&x| {
            let d = x as f64 - mean;
            d * d
        })
        .sum::<f64>()
        / n;
    Some(KindAggregate {
        runs: finals.len() as u64,
        final_mean: mean,
        final_min: *finals.iter().min().expect("non-empty"),
        final_max: *finals.iter().max().expect("non-empty"),
        final_sd: variance.sqrt(),
        extinct_runs: finals.iter().filter(|&&x| x == 0).count() as u64,
    })
}

/// One finished run of a batch.
#[derive(Clone, Debug)]
pub struct BatchRun {
    pub case: String,
    /// The case values (same order as the `--vary` options).
    pub params: Vec<(String, Value)>,
    pub seed: u64,
    /// Path of the per-seed result, relative to the batch directory.
    pub file: String,
    pub result: RunResult,
}

/// The aggregates of one case (ADR-0022 D3).
#[derive(Clone, Debug, PartialEq)]
pub struct CaseAggregate {
    pub case: String,
    pub params: Vec<(String, Value)>,
    /// Per kind, in [`KIND_NAMES`] order.
    pub kinds: [KindAggregate; 3],
}

/// The aggregates of every case, in case order, computed in run order.
pub fn case_aggregates(runs: &[BatchRun], cases: &[Case]) -> Vec<CaseAggregate> {
    cases
        .iter()
        .filter_map(|case| {
            let members: Vec<&BatchRun> = runs.iter().filter(|r| r.case == case.name).collect();
            Some(CaseAggregate {
                case: case.name.clone(),
                params: case.params.clone(),
                kinds: kind_aggregates(&members)?,
            })
        })
        .collect()
}

/// The aggregates of every run together (ADR-0022 D3, the `overall` object); `None` for no runs.
pub fn overall_aggregates(runs: &[BatchRun]) -> Option<[KindAggregate; 3]> {
    kind_aggregates(&runs.iter().collect::<Vec<_>>())
}

fn kind_aggregates(runs: &[&BatchRun]) -> Option<[KindAggregate; 3]> {
    let mut out = Vec::with_capacity(3);
    for kind in Kind::ALL {
        let finals: Vec<u64> = runs
            .iter()
            .map(|r| r.result.counts.living[kind.index()])
            .collect();
        out.push(aggregate(&finals)?);
    }
    out.try_into().ok()
}

/// A float as JSON text; an error for values JSON cannot hold (ADR-0020 D2).
pub fn float_text(v: f64) -> Result<String, String> {
    if v.is_finite() {
        Ok(format!("{v:?}"))
    } else {
        Err(format!("cannot write a non-finite number ({v}) to the summary"))
    }
}

/// A JSON value on one line: objects as `{"k": v, ...}`, arrays as `[a, b]`, scalars as the JSON writer writes them.
pub fn inline(v: &Value) -> String {
    match v {
        Value::Array(items) => format!(
            "[{}]",
            items.iter().map(inline).collect::<Vec<_>>().join(", ")
        ),
        Value::Object(fields) => format!(
            "{{{}}}",
            fields
                .iter()
                .map(|(k, v)| format!("{}: {}", json::write(&Value::Str(k.clone())), inline(v)))
                .collect::<Vec<_>>()
                .join(", ")
        ),
        scalar => json::write(scalar),
    }
}

/// The case values as a one-line object, for example `{"initial.plants": 200}`.
fn params_text(params: &[(String, Value)]) -> String {
    inline(&Value::Object(params.to_vec()))
}

/// `{"plants": a, "herbivores": b, "carnivores": c}` for per-kind integers.
fn kind_counts_text(values: [u64; 3]) -> String {
    format!(
        "{{\"{}\": {}, \"{}\": {}, \"{}\": {}}}",
        KIND_NAMES[0], values[0], KIND_NAMES[1], values[1], KIND_NAMES[2], values[2]
    )
}

fn kind_aggregate_text(a: &KindAggregate) -> Result<String, String> {
    Ok(format!(
        "{{\"final_mean\": {}, \"final_min\": {}, \"final_max\": {}, \"final_sd\": {}, \"extinct_runs\": {}, \"extinct_fraction\": {}}}",
        float_text(a.final_mean)?,
        a.final_min,
        a.final_max,
        float_text(a.final_sd)?,
        a.extinct_runs,
        float_text(a.extinct_fraction())?
    ))
}

fn kinds_text(kinds: &[KindAggregate; 3]) -> Result<String, String> {
    let mut parts = Vec::with_capacity(3);
    for (name, a) in KIND_NAMES.iter().zip(kinds) {
        parts.push(format!("\"{name}\": {}", kind_aggregate_text(a)?));
    }
    Ok(format!("{{{}}}", parts.join(", ")))
}

/// What the summary describes besides the runs.
pub struct SummarySpec<'a> {
    pub ticks: u64,
    pub sample_every: u64,
    pub seeds: &'a [u64],
    pub base: &'a Config,
    pub vary: &'a [Vary],
    pub cases: &'a [Case],
}

/// The text of `summary.json` (ADR-0022 D3): one run per line, no wall-clock value, so the same batch gives the same
/// text. Ends with a newline.
pub fn summary_json(spec: &SummarySpec<'_>, runs: &[BatchRun]) -> Result<String, String> {
    let base = inline(&json::parse(&spec.base.to_json())?);
    let seeds = spec
        .seeds
        .iter()
        .map(u64::to_string)
        .collect::<Vec<_>>()
        .join(", ");
    let vary = spec
        .vary
        .iter()
        .map(|v| {
            let values = v.values.iter().map(inline).collect::<Vec<_>>().join(", ");
            format!(
                "{{\"key\": {}, \"values\": [{values}]}}",
                json::write(&Value::Str(v.key.clone()))
            )
        })
        .collect::<Vec<_>>()
        .join(", ");
    let cases = spec
        .cases
        .iter()
        .map(|c| format!("{{\"case\": \"{}\", \"params\": {}}}", c.name, params_text(&c.params)))
        .collect::<Vec<_>>()
        .join(",\n    ");
    let mut run_lines = Vec::with_capacity(runs.len());
    for run in runs {
        let r = &run.result;
        let c = &r.counts;
        let extinct: [bool; 3] = c.living.map(|n| n == 0);
        run_lines.push(format!(
            "    {{\"case\": \"{}\", \"seed\": {}, \"params\": {}, \"file\": {}, \"tick_start\": {}, \"tick_end\": {}, \"initial\": {}, \"final\": {}, \"species\": {}, \"extinct\": {{\"{}\": {}, \"{}\": {}, \"{}\": {}}}, \"state_hash\": \"{}\"}}",
            run.case,
            run.seed,
            params_text(&run.params),
            json::write(&Value::Str(run.file.clone())),
            r.tick_start,
            r.tick_end,
            kind_counts_text(c.initial),
            kind_counts_text(c.living),
            kind_counts_text(c.species_living),
            KIND_NAMES[0], extinct[0],
            KIND_NAMES[1], extinct[1],
            KIND_NAMES[2], extinct[2],
            r.state_hash,
        ));
    }
    let aggregates = case_aggregates(runs, spec.cases)
        .iter()
        .map(|a| {
            Ok(format!(
                "    {{\"case\": \"{}\", \"params\": {}, \"runs\": {}, \"kinds\": {}}}",
                a.case,
                params_text(&a.params),
                a.kinds[0].runs,
                kinds_text(&a.kinds)?
            ))
        })
        .collect::<Result<Vec<_>, String>>()?
        .join(",\n");
    let overall = overall_aggregates(runs)
        .ok_or_else(|| "a batch needs at least one run".to_string())?;
    Ok(format!(
        "{{\n  \"format\": \"{SUMMARY_FORMAT}\",\n  \"format_version\": {SUMMARY_FORMAT_VERSION},\n  \"contract\": {contract},\n  \"tick_start\": 0,\n  \"ticks\": {ticks},\n  \"sample_every\": {sample_every},\n  \"seeds\": [{seeds}],\n  \"base\": {base},\n  \"vary\": [{vary}],\n  \"cases\": [\n    {cases}\n  ],\n  \"runs\": [\n{runs_text}\n  ],\n  \"aggregates\": [\n{aggregates}\n  ],\n  \"overall\": {{\"runs\": {n}, \"kinds\": {overall_kinds}}}\n}}\n",
        contract = crate::CONTRACT_VERSION,
        ticks = spec.ticks,
        sample_every = spec.sample_every,
        runs_text = run_lines.join(",\n"),
        n = runs.len(),
        overall_kinds = kinds_text(&overall)?,
    ))
}

/// The text of `runs.csv` (ADR-0022 D6): one row per run, in run order. The `--vary` keys are columns after `seed`.
pub fn runs_csv(vary: &[Vary], runs: &[BatchRun]) -> String {
    let mut out = String::from("case,seed");
    for v in vary {
        out.push(',');
        out.push_str(&v.key);
    }
    out.push_str(
        ",tick_start,tick_end,initial_plants,initial_herbivores,initial_carnivores,\
         final_plants,final_herbivores,final_carnivores,species_plants,species_herbivores,\
         species_carnivores,extinct_plants,extinct_herbivores,extinct_carnivores,state_hash\n",
    );
    for run in runs {
        let r = &run.result;
        let c = &r.counts;
        out.push_str(&format!("{},{}", run.case, run.seed));
        for (_, value) in &run.params {
            out.push(',');
            out.push_str(&json::write(value));
        }
        out.push_str(&format!(",{},{}", r.tick_start, r.tick_end));
        for values in [c.initial, c.living, c.species_living] {
            out.push_str(&format!(",{},{},{}", values[0], values[1], values[2]));
        }
        for n in c.living {
            out.push_str(&format!(",{}", u8::from(n == 0)));
        }
        out.push_str(&format!(",{}\n", r.state_hash));
    }
    out
}

/// The text of `aggregates.csv` (ADR-0022 D6): one row per case and kind, in case order.
pub fn aggregates_csv(aggregates: &[CaseAggregate]) -> Result<String, String> {
    let mut out = String::from(
        "case,kind,runs,final_mean,final_min,final_max,final_sd,extinct_runs,extinct_fraction\n",
    );
    for a in aggregates {
        for (name, k) in KIND_NAMES.iter().zip(&a.kinds) {
            out.push_str(&format!(
                "{},{},{},{},{},{},{},{},{}\n",
                a.case,
                name,
                k.runs,
                float_text(k.final_mean)?,
                k.final_min,
                k.final_max,
                float_text(k.final_sd)?,
                k.extinct_runs,
                float_text(k.extinct_fraction())?
            ));
        }
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::metrics::{KindCounts, Sample};

    fn base() -> Config {
        Config::from_json(
            r#"{"seed": 1, "world": {"width": 8, "height": 6},
                "initial": {"plants": 20, "herbivores": 5, "carnivores": 2}}"#,
        )
        .unwrap()
    }

    fn vary(key: &str, values: &[i128]) -> Vary {
        Vary {
            key: key.to_string(),
            values: values.iter().map(|&v| Value::Int(v)).collect(),
        }
    }

    #[test]
    fn aggregate_matches_hand_computed_values() {
        let a = aggregate(&[10, 20, 0]).unwrap();
        assert_eq!(a.runs, 3);
        assert_eq!(a.final_mean, 10.0);
        assert_eq!(a.final_min, 0);
        assert_eq!(a.final_max, 20);
        assert!((a.final_sd - (200.0f64 / 3.0).sqrt()).abs() < 1e-12);
        assert_eq!(a.extinct_runs, 1);
        assert!((a.extinct_fraction() - 1.0 / 3.0).abs() < 1e-12);
    }

    #[test]
    fn aggregate_of_no_runs_is_none() {
        assert_eq!(aggregate(&[]), None);
    }

    #[test]
    fn cases_are_the_cartesian_product_first_sweep_slowest() {
        let cases = expand_cases(&[vary("initial.plants", &[1, 2]), vary("initial.herbivores", &[7, 8, 9])]);
        assert_eq!(cases.len(), 6);
        let names: Vec<&str> = cases.iter().map(|c| c.name.as_str()).collect();
        assert_eq!(names, ["case-00", "case-01", "case-02", "case-03", "case-04", "case-05"]);
        let pairs: Vec<(i128, i128)> = cases
            .iter()
            .map(|c| match (&c.params[0].1, &c.params[1].1) {
                (Value::Int(a), Value::Int(b)) => (*a, *b),
                other => panic!("{other:?}"),
            })
            .collect();
        assert_eq!(pairs, [(1, 7), (1, 8), (1, 9), (2, 7), (2, 8), (2, 9)]);
    }

    #[test]
    fn no_sweep_is_one_case_without_parameters() {
        let cases = expand_cases(&[]);
        assert_eq!(cases, vec![Case { name: "case-00".into(), params: vec![] }]);
    }

    #[test]
    fn run_config_sets_case_values_and_seed() {
        let cfg = run_config(&base(), &[("initial.plants".into(), Value::Int(33))], 9).unwrap();
        assert_eq!(cfg.initial.plants, 33);
        assert_eq!(cfg.initial.herbivores, 5);
        assert_eq!(cfg.seed, 9);
    }

    #[test]
    fn run_config_names_unknown_keys_and_bad_values() {
        let unknown = run_config(&base(), &[("initial.nothing".into(), Value::Int(1))], 1).unwrap_err();
        assert!(unknown.contains("initial.nothing"), "{unknown}");
        let negative = run_config(&base(), &[("initial.plants".into(), Value::Int(-1))], 1).unwrap_err();
        assert!(negative.contains("initial.plants"), "{negative}");
    }

    fn fake_run(case: &str, seed: u64, params: &[(String, Value)], living: [u64; 3]) -> BatchRun {
        BatchRun {
            case: case.to_string(),
            params: params.to_vec(),
            seed,
            file: format!("{case}/seed-{seed}.json"),
            result: RunResult {
                seed,
                tick_start: 0,
                tick_end: 50,
                width: 8,
                height: 6,
                counts: KindCounts {
                    initial: [20, 5, 2],
                    births: [0; 3],
                    deaths: [0; 3],
                    living,
                    species_living: [1, 1, 0],
                    species_recognised: [1, 1, 0],
                },
                series: vec![Sample { tick: 0, living: [20, 5, 2] }],
                sample_every: 50,
                state_hash: format!("{:064x}", seed),
                elapsed_seconds: 1.0,
                ticks_per_second: 50.0,
            },
        }
    }

    #[test]
    fn summary_has_keys_in_order_and_parses() {
        let vary_list = [vary("initial.plants", &[200, 400])];
        let cases = expand_cases(&vary_list);
        let params0 = cases[0].params.clone();
        let params1 = cases[1].params.clone();
        let runs = vec![
            fake_run("case-00", 1, &params0, [3, 0, 0]),
            fake_run("case-00", 2, &params0, [0, 1, 0]),
            fake_run("case-01", 1, &params1, [4, 2, 1]),
            fake_run("case-01", 2, &params1, [5, 2, 1]),
        ];
        let text = summary_json(
            &SummarySpec { ticks: 50, sample_every: 1, seeds: &[1, 2], base: &base(), vary: &vary_list, cases: &cases },
            &runs,
        )
        .unwrap();
        let value = json::parse(&text).expect("summary parses");
        let keys: Vec<String> = match &value {
            Value::Object(fields) => fields.iter().map(|(k, _)| k.clone()).collect(),
            other => panic!("{other:?}"),
        };
        assert_eq!(
            keys,
            ["format", "format_version", "contract", "tick_start", "ticks", "sample_every", "seeds", "base", "vary", "cases", "runs", "aggregates", "overall"]
        );
        assert!(!text.contains("elapsed"), "no wall-clock value in the summary");
        assert_eq!(text.lines().filter(|l| l.contains("\"state_hash\"")).count(), 4);
    }

    #[test]
    fn csv_has_one_row_per_run_and_per_case_kind() {
        let vary_list = [vary("initial.plants", &[200, 400])];
        let cases = expand_cases(&vary_list);
        let runs = vec![
            fake_run("case-00", 1, &cases[0].params, [3, 0, 0]),
            fake_run("case-01", 1, &cases[1].params, [4, 2, 1]),
        ];
        let csv = runs_csv(&vary_list, &runs);
        assert_eq!(csv.lines().count(), 3);
        assert!(csv.lines().next().unwrap().starts_with("case,seed,initial.plants,tick_start"));
        assert!(csv.lines().nth(1).unwrap().starts_with("case-00,1,200,0,50,"));
        let aggs = case_aggregates(&runs, &cases);
        let agg_csv = aggregates_csv(&aggs).unwrap();
        assert_eq!(agg_csv.lines().count(), 1 + 2 * 3);
    }

    #[test]
    fn overall_is_none_without_runs() {
        assert!(overall_aggregates(&[]).is_none());
    }
}

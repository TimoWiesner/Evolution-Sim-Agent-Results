//! Herbivore feeding, climate cost and decision rule (TASK-014, ADR-0015).
//!
//! Rules, in short:
//! - A herbivore eats only living plants in its own cell or an adjacent one (`FEED_REACH`), never further.
//! - Per tick it takes at most `BITE_MAX` energy in total from those plants; each plant loses what is taken, and the
//!   herbivore gains `ASSIMILATION` times that amount. It takes nothing once it reaches `SATIATION_ENERGY`.
//! - Every tick it pays movement cost, `BASE_COST`, and a thermal cost outside the comfort band (see [`thermal_cost`]).
//! - Its heading follows food against danger: a carnivore in sight that it is more cautious than hungry about makes it
//!   flee; otherwise the nearest plant in sight attracts it; otherwise it wanders.
//!
//! All constants are uncalibrated and belong to TASK-018. Nothing here looks at population counts.

use crate::entities::{Entities, Kind, Organism, OrganismId, ENERGY_MAX};
use crate::movement::Heading;
use crate::spatial::SpatialIndex;

/// Chebyshev radius around a herbivore within which it may eat plants (0 = own cell, 1 = adjacent cells).
pub const FEED_REACH: u32 = 1;
/// Largest total energy a herbivore takes from plants in one tick.
pub const BITE_MAX: f32 = 0.5;
/// Fraction of the energy taken from a plant that the herbivore gains.
pub const ASSIMILATION: f32 = 0.8;
/// Herbivores at or above this energy take no bites (satiation).
pub const SATIATION_ENERGY: f32 = 80.0;
/// Energy paid every tick by a herbivore, whatever it does.
pub const BASE_COST: f32 = 0.3;
/// Lower edge of the comfort band in degrees Celsius; colder costs more.
pub const COMFORT_LOW: f32 = 5.0;
/// Upper edge of the comfort band in degrees Celsius; hotter costs more.
pub const COMFORT_HIGH: f32 = 30.0;
/// Extra energy per tick for each degree outside the comfort band.
pub const THERMAL_COST: f32 = 0.02;
/// Degrees outside the comfort band that count towards the thermal cost (caps it at 0.8 per tick).
pub const THERMAL_STRESS_MAX: f32 = 40.0;

/// Extra energy a herbivore pays this tick for temperature `t` (degrees C): zero inside
/// `[COMFORT_LOW, COMFORT_HIGH]`, then `THERMAL_COST` per degree outside, capped at `THERMAL_STRESS_MAX` degrees.
pub fn thermal_cost(temperature: f32) -> f32 {
    let excess = if temperature < COMFORT_LOW {
        COMFORT_LOW - temperature
    } else if temperature > COMFORT_HIGH {
        temperature - COMFORT_HIGH
    } else {
        0.0
    };
    THERMAL_COST * excess.min(THERMAL_STRESS_MAX)
}

/// Heading of a herbivore this tick (ADR-0015 decision rule, first match wins):
/// 1. the nearest living carnivore among `perceived` (Chebyshev, ties by lowest id) and `caution > hunger` give
///    `Away` from it, where `hunger = 1 - energy / ENERGY_MAX`;
/// 2. else the nearest living plant with energy above 0 gives `Towards` it, but only while the herbivore is below
///    `SATIATION_ENERGY`;
/// 3. else `Wander`.
///
/// `perceived` must be ascending by id (as [`crate::movement::perceive`] returns it). Draws no random numbers.
pub fn herbivore_heading(
    entities: &Entities,
    spatial: &SpatialIndex,
    o: &Organism,
    perceived: &[OrganismId],
) -> Heading {
    let torus = spatial.torus();
    let hunger = 1.0 - o.energy() / ENERGY_MAX;
    let caution = o.tendencies().map_or(0.0, |t| t.caution());

    let mut danger: Option<(u32, crate::world::Cell)> = None;
    let mut food: Option<(u32, crate::world::Cell)> = None;
    for &id in perceived {
        let Some(other) = entities.get(id).filter(|x| x.is_alive()) else {
            continue;
        };
        let d = torus.distance(o.cell(), other.cell());
        match other.kind() {
            Kind::Carnivore if danger.is_none_or(|(best, _)| d < best) => {
                danger = Some((d, other.cell()));
            }
            Kind::Plant
                if other.energy() > 0.0
                    && o.energy() < SATIATION_ENERGY
                    && food.is_none_or(|(best, _)| d < best) =>
            {
                food = Some((d, other.cell()));
            }
            _ => {}
        }
    }

    if let Some((_, threat)) = danger.filter(|_| caution > hunger) {
        return Heading::Away(threat);
    }
    if let Some((_, target)) = food {
        return Heading::Towards(target);
    }
    Heading::Wander
}

/// One feeding action of herbivore `id` this tick (ADR-0015). Takes bites from the living plants in its reach
/// (`FEED_REACH`), in ascending id order, until `BITE_MAX` is taken or the herbivore is satiated. Each bite drains the
/// plant (it may die of starvation in the Deaths phase) and the herbivore gains `ASSIMILATION` times the bite.
/// Returns the energy gained. Does nothing (returns 0) for a missing, dead or satiated herbivore.
pub fn feed(entities: &mut Entities, spatial: &SpatialIndex, id: OrganismId) -> f32 {
    let (cell, energy) = match entities.get(id) {
        Some(o) if o.is_alive() => (o.cell(), o.energy()),
        _ => return 0.0,
    };
    if energy >= SATIATION_ENERGY {
        return 0.0;
    }
    let mut cap = BITE_MAX;
    let mut gained = 0.0f32;
    for pid in spatial.within(cell, FEED_REACH, Some(Kind::Plant)) {
        if cap <= 0.0 {
            break;
        }
        let Some(plant) = entities.get_mut(pid) else {
            continue;
        };
        let available = plant.energy();
        if !plant.is_alive() || available <= 0.0 {
            continue;
        }
        let eaten = available.min(cap);
        plant.drain_energy(eaten);
        cap -= eaten;
        gained += ASSIMILATION * eaten;
    }
    if let Some(herbivore) = entities.get_mut(id) {
        herbivore.add_energy(gained);
    }
    gained
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::{Birth, Kind};
    use crate::genome::{random_genome, Genome};
    use crate::rng::Rng;
    use crate::world::{Cell, Torus};

    fn torus(w: u32, h: u32) -> Torus {
        Torus::new(w, h).unwrap()
    }

    fn c(t: &Torus, x: u32, y: u32) -> Cell {
        t.cell(x, y).unwrap()
    }

    /// Genome with slot 0 (speed), slot 6 (caution) and slot 7 (vision) set to the given loci, others 128.
    fn genome(speed: u8, caution: u8, vision: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + i] = speed;
                loci[hap * 128 + 6 * 16 + i] = caution;
                loci[hap * 128 + 7 * 16 + i] = vision;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn animal(kind: Kind, cell: Cell, g: Genome, energy: f32) -> Birth {
        let mut b = Birth::from_genome(kind, cell, g, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    fn plant(cell: Cell, energy: f32) -> Birth {
        let g = Genome::new(1, vec![128; 128]).unwrap();
        Birth::from_genome(Kind::Plant, cell, g, energy, 10.0).unwrap()
    }

    /// Entities and index with the given organisms placed; returns the ids in insertion order.
    fn world(t: &Torus, births: Vec<Birth>) -> (Entities, SpatialIndex, Vec<OrganismId>) {
        let mut ents = Entities::new();
        let mut sp = SpatialIndex::new(*t);
        let mut ids = Vec::new();
        for b in births {
            let (cell, kind) = (b.cell, b.kind);
            let id = ents.spawn_founder(b).unwrap();
            sp.insert(id, cell, kind).unwrap();
            ids.push(id);
        }
        (ents, sp, ids)
    }

    #[test]
    fn constants_are_the_documented_values() {
        assert_eq!(FEED_REACH, 1);
        assert_eq!(BITE_MAX, 0.5);
        assert_eq!(ASSIMILATION, 0.8);
        assert_eq!(SATIATION_ENERGY, 80.0);
        assert_eq!(BASE_COST, 0.3);
    }

    #[test]
    fn thermal_cost_is_zero_inside_the_band_and_grows_outside() {
        for t in [5.0f32, 12.5, 20.0, 30.0] {
            assert_eq!(thermal_cost(t), 0.0, "t={t}");
        }
        assert!(thermal_cost(4.0) > 0.0);
        assert!(thermal_cost(-20.0) > thermal_cost(0.0));
        assert!(thermal_cost(-10.0) > thermal_cost(0.0));
        assert!(thermal_cost(40.0) > thermal_cost(31.0));
        assert!((thermal_cost(-20.0) - THERMAL_COST * 25.0).abs() < 1e-6);
        // Capped: beyond 40 degrees outside the band the cost stops growing.
        assert!((thermal_cost(-100.0) - THERMAL_COST * THERMAL_STRESS_MAX).abs() < 1e-6);
        assert!((thermal_cost(-100.0) - thermal_cost(-60.0)).abs() < 1e-6);
    }

    #[test]
    fn feed_takes_from_own_cell_and_adjacent_cells_only() {
        let t = torus(10, 10);
        let h = animal(Kind::Herbivore, c(&t, 4, 4), genome(0, 0, 0), 30.0);
        let own = plant(c(&t, 4, 4), 10.0);
        let adj = plant(c(&t, 5, 3), 10.0);
        let far = plant(c(&t, 6, 4), 10.0); // Chebyshev distance 2
        let (mut ents, sp, ids) = world(&t, vec![h, own, adj, far]);
        let g = feed(&mut ents, &sp, ids[0]);
        // Plants are visited in ascending id order: the own-cell plant is inserted first, so it is eaten first.
        assert!((g - ASSIMILATION * BITE_MAX).abs() < 1e-6);
        assert!((ents.get(ids[1]).unwrap().energy() - (10.0 - BITE_MAX)).abs() < 1e-6);
        assert_eq!(ents.get(ids[2]).unwrap().energy(), 10.0);
        assert_eq!(
            ents.get(ids[3]).unwrap().energy(),
            10.0,
            "distance 2 is never eaten"
        );
    }

    #[test]
    fn feed_reaches_across_the_west_seam() {
        let t = torus(10, 10);
        let h = animal(Kind::Herbivore, c(&t, 0, 5), genome(0, 0, 0), 30.0);
        let p = plant(c(&t, 9, 5), 10.0); // adjacent across the seam
        let (mut ents, sp, ids) = world(&t, vec![h, p]);
        assert!(feed(&mut ents, &sp, ids[0]) > 0.0);
        assert!(ents.get(ids[1]).unwrap().energy() < 10.0);
    }

    #[test]
    fn feed_never_takes_more_than_the_cap_and_gains_no_more_than_it_takes() {
        let t = torus(10, 10);
        let h = animal(Kind::Herbivore, c(&t, 2, 2), genome(0, 0, 0), 10.0);
        let p = plant(c(&t, 2, 2), 90.0);
        let (mut ents, sp, ids) = world(&t, vec![h, p]);
        let before_plant = ents.get(ids[1]).unwrap().energy();
        let before_h = ents.get(ids[0]).unwrap().energy();
        let gained = feed(&mut ents, &sp, ids[0]);
        let taken = before_plant - ents.get(ids[1]).unwrap().energy();
        assert!((taken - BITE_MAX).abs() < 1e-6, "taken {taken}");
        assert!(gained <= taken + 1e-6);
        assert!((ents.get(ids[0]).unwrap().energy() - (before_h + gained)).abs() < 1e-6);
    }

    #[test]
    fn feed_sums_several_small_plants_up_to_the_cap() {
        let t = torus(10, 10);
        let h = animal(Kind::Herbivore, c(&t, 5, 5), genome(0, 0, 0), 20.0);
        let ps = vec![
            plant(c(&t, 5, 5), 0.125),
            plant(c(&t, 4, 5), 0.125),
            plant(c(&t, 6, 5), 0.125),
            plant(c(&t, 5, 6), 0.125),
        ];
        let mut births = vec![h];
        births.extend(ps);
        let (mut ents, sp, ids) = world(&t, births);
        let gained = feed(&mut ents, &sp, ids[0]);
        // Four plants of 0.125 give 0.5 = BITE_MAX, the cap; the herbivore gains 0.8 * 0.5.
        assert!((gained - ASSIMILATION * BITE_MAX).abs() < 1e-6);
        for pid in &ids[1..] {
            assert!(ents.get(*pid).unwrap().energy() < 1e-6);
        }
    }

    #[test]
    fn a_plant_eaten_to_zero_is_removed_by_the_deaths_phase_as_starvation() {
        use crate::sim::Simulation;
        let t = torus(10, 10);
        let cfg = crate::config::Config::new(
            3,
            10,
            10,
            crate::config::Initial {
                plants: 0,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let mut sim = Simulation::new(&cfg).unwrap();
        let h = sim
            .add_founder(animal(Kind::Herbivore, c(&t, 3, 3), genome(0, 0, 0), 20.0))
            .unwrap();
        let p = sim.add_founder(plant(c(&t, 3, 3), 0.5)).unwrap();
        let sp = sim.spatial().clone();
        let gained = feed(sim.entities_mut(), &sp, h);
        assert!((gained - 0.4).abs() < 1e-6, "gained {gained}");
        assert_eq!(sim.entities().get(p).unwrap().energy(), 0.0);
        sim.run(1);
        assert!(sim.entities().get(p).is_none());
        assert_eq!(sim.spatial().position(p), None);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn a_satiated_herbivore_takes_nothing() {
        let t = torus(10, 10);
        let h = animal(
            Kind::Herbivore,
            c(&t, 1, 1),
            genome(0, 0, 0),
            SATIATION_ENERGY,
        );
        let p = plant(c(&t, 1, 1), 50.0);
        let (mut ents, sp, ids) = world(&t, vec![h, p]);
        assert_eq!(feed(&mut ents, &sp, ids[0]), 0.0);
        assert_eq!(ents.get(ids[1]).unwrap().energy(), 50.0);
        assert_eq!(ents.get(ids[0]).unwrap().energy(), SATIATION_ENERGY);
    }

    #[test]
    fn dead_or_missing_herbivores_and_empty_cells_feed_nothing() {
        let t = torus(10, 10);
        let h = animal(Kind::Herbivore, c(&t, 1, 1), genome(0, 0, 0), 20.0);
        let (mut ents, sp, ids) = world(&t, vec![h]);
        assert_eq!(feed(&mut ents, &sp, ids[0]), 0.0);
        assert_eq!(feed(&mut ents, &sp, OrganismId(999)), 0.0);
    }

    #[test]
    fn vision_decides_whether_a_plant_at_distance_three_attracts_a_herbivore() {
        let t = torus(20, 20);
        let p = plant(c(&t, 3, 0), 40.0);
        let far_sighted = animal(Kind::Herbivore, c(&t, 0, 0), genome(0, 0, 255), 50.0); // vision 5
        let short_sighted = animal(Kind::Herbivore, c(&t, 0, 0), genome(0, 0, 0), 50.0); // vision 1
        let (ents, sp, ids) = world(&t, vec![far_sighted, short_sighted, p]);
        let perceived_far = crate::movement::perceive(&sp, ids[0], c(&t, 0, 0), 5);
        let perceived_short = crate::movement::perceive(&sp, ids[1], c(&t, 0, 0), 1);
        let far = herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived_far);
        let short = herbivore_heading(&ents, &sp, ents.get(ids[1]).unwrap(), &perceived_short);
        assert_eq!(far, Heading::Towards(c(&t, 3, 0)));
        assert_eq!(short, Heading::Wander);
    }

    #[test]
    fn caution_against_hunger_decides_flight_from_a_carnivore() {
        let t = torus(20, 20);
        let carnivore = animal(Kind::Carnivore, c(&t, 2, 2), genome(0, 0, 0), 50.0);
        let p = plant(c(&t, 0, 2), 40.0);
        let cautious = animal(Kind::Herbivore, c(&t, 0, 0), genome(0, 230, 128), 50.0);
        let bold = animal(Kind::Herbivore, c(&t, 0, 0), genome(0, 20, 128), 50.0);
        let (ents, sp, ids) = world(&t, vec![cautious, bold, carnivore, p]);
        let perceived = crate::movement::perceive(&sp, ids[0], c(&t, 0, 0), 2);
        let a = herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived);
        let b = herbivore_heading(&ents, &sp, ents.get(ids[1]).unwrap(), &perceived);
        assert_eq!(a, Heading::Away(c(&t, 2, 2)));
        assert_eq!(b, Heading::Towards(c(&t, 0, 2)));
    }

    #[test]
    fn hungry_herbivores_ignore_danger_they_are_not_cautious_about() {
        let t = torus(20, 20);
        let carnivore = animal(Kind::Carnivore, c(&t, 2, 2), genome(0, 0, 0), 50.0);
        // Energy 10 gives hunger 0.9; caution 0.5 is smaller, so it does not flee.
        let h = animal(Kind::Herbivore, c(&t, 0, 0), genome(0, 128, 128), 10.0);
        let (ents, sp, ids) = world(&t, vec![h, carnivore]);
        let perceived = crate::movement::perceive(&sp, ids[0], c(&t, 0, 0), 2);
        assert_eq!(
            herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived),
            Heading::Wander
        );
    }

    #[test]
    fn nearest_plant_wins_and_ties_go_to_the_lowest_id() {
        let t = torus(20, 20);
        let h = animal(Kind::Herbivore, c(&t, 5, 5), genome(0, 0, 128), 30.0);
        let near = plant(c(&t, 6, 5), 10.0); // id 2, distance 1
        let tie_a = plant(c(&t, 5, 3), 10.0); // id 3, distance 2
        let tie_b = plant(c(&t, 3, 5), 10.0); // id 4, distance 2
        let (ents, sp, ids) = world(&t, vec![h, near, tie_a, tie_b]);
        let perceived = crate::movement::perceive(&sp, ids[0], c(&t, 5, 5), 2);
        assert_eq!(
            herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived),
            Heading::Towards(c(&t, 6, 5))
        );
        // Without the nearest plant, the tie goes to the lower id.
        let (ents2, sp2, ids2) = world(
            &t,
            vec![
                animal(Kind::Herbivore, c(&t, 5, 5), genome(0, 0, 128), 30.0),
                plant(c(&t, 5, 3), 10.0),
                plant(c(&t, 3, 5), 10.0),
            ],
        );
        let perceived2 = crate::movement::perceive(&sp2, ids2[0], c(&t, 5, 5), 2);
        assert_eq!(
            herbivore_heading(&ents2, &sp2, ents2.get(ids2[0]).unwrap(), &perceived2),
            Heading::Towards(c(&t, 5, 3))
        );
    }

    #[test]
    fn satiated_herbivores_do_not_head_for_plants() {
        let t = torus(20, 20);
        let h = animal(
            Kind::Herbivore,
            c(&t, 5, 5),
            genome(0, 0, 128),
            SATIATION_ENERGY,
        );
        let p = plant(c(&t, 6, 5), 10.0);
        let (ents, sp, ids) = world(&t, vec![h, p]);
        let perceived = crate::movement::perceive(&sp, ids[0], c(&t, 5, 5), 2);
        assert_eq!(
            herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived),
            Heading::Wander
        );
    }

    #[test]
    fn heading_draws_no_random_numbers_and_is_pure() {
        let t = torus(8, 8);
        let mut rng = Rng::from_seed(4);
        let g = random_genome(2, &mut rng).unwrap();
        let (ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Herbivore, c(&t, 1, 1), g, 40.0),
                plant(c(&t, 2, 1), 5.0),
            ],
        );
        let before = rng.state();
        let perceived = crate::movement::perceive(&sp, ids[0], c(&t, 1, 1), 3);
        let a = herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived);
        let b = herbivore_heading(&ents, &sp, ents.get(ids[0]).unwrap(), &perceived);
        assert_eq!(a, b);
        assert_eq!(rng.state(), before);
    }
}

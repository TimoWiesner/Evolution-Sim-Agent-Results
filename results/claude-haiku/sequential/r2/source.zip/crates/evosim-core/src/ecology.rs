//! Plant resources, growth and competition (TASK-011, ADR-0012).
//!
//! Energy source for plants: the only source is the per-cell resource pool [`ResourceField`]. The pool is refilled
//! each tick toward a capacity that depends only on the cell's climate (temperature and precipitation). A plant takes
//! resource units from its cell and converts them to energy with its genome-derived yield (at most 1). Nothing else
//! adds energy to a plant. Growth needs a temperature and water factor above zero; the pool is shared by the plants in
//! a cell in proportion to their demand.
//!
//! The phase is deterministic and draws no random numbers. All constants are documented in ADR-0012 and are not
//! configuration keys.

use crate::climate::{Climate, Conditions};
use crate::entities::{DeathCause, Entities, ENERGY_MAX};
use crate::genome::Genome;
use crate::world::Torus;
use std::fmt;

/// Largest resource pool of a cell, in resource units. A cell never holds more than this.
pub const CAP_MAX: f32 = 100.0;
/// Fraction of the gap to the climate capacity that a pool refills each tick.
pub const REGEN_RATE: f32 = 0.1;
/// Temperature (degrees C) at which the temperature factor is 1.
pub const T_OPT: f32 = 20.0;
/// Temperature (degrees C) at and above which the temperature factor is 0.
pub const T_UPPER: f32 = 40.0;
/// Lower temperature limit (degrees C) at `cold_tolerance = 0` and at `cold_tolerance = 1`. The limit is
/// `T_LOWER_MAX - T_LOWER_SPAN * cold_tolerance`, so a more cold-tolerant plant can grow at lower temperatures.
pub const T_LOWER_MAX: f32 = 5.0;
pub const T_LOWER_SPAN: f32 = 10.0;
/// Precipitation (mm/yr) below which the water factor is 0.
pub const P_MIN: f32 = 20.0;
/// Half-saturation precipitation (mm/yr) at `drought_tolerance = 0` and at `= 1`.
pub const K_DRY_TOLERANT: f32 = 50.0;
pub const K_WET_ONLY: f32 = 400.0;
/// Resource units a plant asks for per tick at a growth factor of 1 and zero energy.
pub const REQUEST_MAX: f32 = 4.0;
/// Maintenance energy per tick: `MAINT_BASE + MAINT_HEALTH * health`.
pub const MAINT_BASE: f32 = 0.5;
pub const MAINT_HEALTH: f32 = 0.01;
/// Energy above which a plant may grow.
pub const GROWTH_RESERVE: f32 = 40.0;
/// Health gained per tick at a growth factor of 1 (paid with the same amount of energy).
pub const GROWTH_RATE: f32 = 1.0;
/// Health lost per tick in a cell where the growth factor is 0 (hostile climate).
pub const HOSTILE_DAMAGE: f32 = 2.0;
/// Tolerance value used for the capacity of a cell (the pool does not depend on a plant's own genome).
pub const NEUTRAL_TOLERANCE: f32 = 0.5;

/// Errors of the ecology module.
#[derive(Clone, Debug, PartialEq)]
pub enum EcologyError {
    /// The number of pool values does not match the number of cells.
    LengthMismatch { expected: usize, got: usize },
    /// A pool value is not finite or is outside `[0, CAP_MAX]`.
    BadValue { index: usize, value: f32 },
}

impl fmt::Display for EcologyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            EcologyError::LengthMismatch { expected, got } => {
                write!(
                    f,
                    "resource field has {got} values, the torus has {expected} cells"
                )
            }
            EcologyError::BadValue { index, value } => {
                write!(
                    f,
                    "resource value {value} at cell index {index} is outside [0, {CAP_MAX}]"
                )
            }
        }
    }
}

impl std::error::Error for EcologyError {}

/// Plant traits decoded from the genome (ADR-0012, ADR-0004 amendment). Slots 5, 6 and 7 are plant traits.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PlantTraits {
    /// Block mean of slot 5, in `[0, 1]`. Sets the lower temperature limit.
    pub cold_tolerance: f32,
    /// Block mean of slot 6, in `[0, 1]`. Sets the water half-saturation.
    pub drought_tolerance: f32,
    /// `0.5 + 0.5 * mean(slot 7)`, in `[0.5, 1]`. Energy per resource unit.
    pub yield_per_unit: f32,
}

impl PlantTraits {
    /// Decodes the plant traits from a genome. Pure: equal genomes give equal traits.
    pub fn from_genome(genome: &Genome) -> PlantTraits {
        let m = genome.trait_means();
        PlantTraits {
            cold_tolerance: m[5] as f32,
            drought_tolerance: m[6] as f32,
            yield_per_unit: (0.5 + 0.5 * m[7]) as f32,
        }
    }
}

/// Temperature factor in `[0, 1]`: 0 at and below the lower limit and at and above [`T_UPPER`], 1 at [`T_OPT`],
/// linear in between.
pub fn temperature_factor(t: f32, cold_tolerance: f32) -> f32 {
    let lower = T_LOWER_MAX - T_LOWER_SPAN * cold_tolerance.clamp(0.0, 1.0);
    if !t.is_finite() || t <= lower || t >= T_UPPER {
        0.0
    } else if t <= T_OPT {
        (t - lower) / (T_OPT - lower)
    } else {
        (T_UPPER - t) / (T_UPPER - T_OPT)
    }
}

/// Water factor in `[0, 1)`: 0 below [`P_MIN`]; otherwise `p / (p + K)` with `K` from the drought tolerance.
pub fn water_factor(p: f32, drought_tolerance: f32) -> f32 {
    if !p.is_finite() || p < P_MIN {
        return 0.0;
    }
    let d = drought_tolerance.clamp(0.0, 1.0);
    let k = K_WET_ONLY * (1.0 - d) + K_DRY_TOLERANT * d;
    p / (p + k)
}

/// The two factors of growth for one cell and one plant. Their product is the growth factor.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GrowthFactors {
    pub temperature: f32,
    pub water: f32,
}

impl GrowthFactors {
    /// `temperature * water`, in `[0, 1)`. Zero means no growth and a hostile cell.
    pub fn product(&self) -> f32 {
        self.temperature * self.water
    }
}

/// Growth factors for a plant with `traits` in a cell with conditions `cond`.
pub fn growth_factors(cond: Conditions, traits: &PlantTraits) -> GrowthFactors {
    GrowthFactors {
        temperature: temperature_factor(cond.temperature, traits.cold_tolerance),
        water: water_factor(cond.precipitation, traits.drought_tolerance),
    }
}

/// Climate capacity of a cell's pool, in `[0, CAP_MAX]`: `CAP_MAX * f_T * f_W` with neutral tolerances.
pub fn capacity(cond: Conditions) -> f32 {
    let f = growth_factors(
        cond,
        &PlantTraits {
            cold_tolerance: NEUTRAL_TOLERANCE,
            drought_tolerance: NEUTRAL_TOLERANCE,
            yield_per_unit: 1.0,
        },
    );
    CAP_MAX * f.product()
}

/// The resource pool of every cell, indexed by [`Torus::index`]. One value per cell in `[0, CAP_MAX]`.
#[derive(Clone, Debug, PartialEq)]
pub struct ResourceField {
    values: Vec<f32>,
}

impl ResourceField {
    /// A full pool: every cell starts at its climate capacity for the current climate state.
    pub fn full(torus: &Torus, climate: &Climate) -> ResourceField {
        let values = (0..torus.cell_count())
            .map(|i| {
                let cell = torus.cell_from_index(i).expect("index below cell_count");
                capacity(climate.conditions(cell))
            })
            .collect();
        ResourceField { values }
    }

    /// Restores a field from saved values (checkpoint, TASK-022). Checks the length and the range of every value.
    pub fn from_values(torus: &Torus, values: Vec<f32>) -> Result<ResourceField, EcologyError> {
        let expected = torus.cell_count();
        if values.len() != expected {
            return Err(EcologyError::LengthMismatch {
                expected,
                got: values.len(),
            });
        }
        for (index, &value) in values.iter().enumerate() {
            if !value.is_finite() || !(0.0..=CAP_MAX).contains(&value) {
                return Err(EcologyError::BadValue { index, value });
            }
        }
        Ok(ResourceField { values })
    }

    /// The pool of the cell with this index.
    pub fn get_index(&self, index: usize) -> f32 {
        self.values[index]
    }

    /// All pool values in index order.
    pub fn values(&self) -> &[f32] {
        &self.values
    }

    /// Sum of all pool values, in f64.
    pub fn total(&self) -> f64 {
        self.values.iter().map(|&v| f64::from(v)).sum()
    }
}

/// What the plant phase did in one tick, in f64 sums taken in id and cell order.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct PlantReport {
    /// Resource units removed from the pools by plants.
    pub taken: f64,
    /// Energy actually added to plants (after the [`ENERGY_MAX`] cap). Never more than `taken`.
    pub gained: f64,
    /// Resource units added to the pools by regeneration.
    pub regenerated: f64,
}

/// Per-plant values computed before any plant acts (pass 1). `take` is the share from the pool.
struct Plan {
    id: u64,
    cell: usize,
    growth: f32,
    yield_per_unit: f32,
    take: f32,
}

/// Runs the Plants phase of one tick (ADR-0012): demand, proportional sharing of each pool, gain, maintenance,
/// growth or hostile damage for every living plant in ascending id order, then regeneration of every pool.
pub fn plants_phase(
    entities: &mut Entities,
    resources: &mut ResourceField,
    climate: &Climate,
) -> PlantReport {
    let torus = climate.torus();
    let cells = torus.cell_count();
    let mut report = PlantReport::default();

    // The climate is fixed for the whole phase, so each cell's conditions are computed once and reused (TASK-026
    // ADR-0027 D3, O1). The same function gives the same values, so the results do not change.
    let mut cond_cache: Vec<Option<Conditions>> = vec![None; cells];

    // Pass 1: growth factor, demand and share of every living plant. Reads only.
    let mut plans: Vec<Plan> = Vec::new();
    let mut demand_sum = vec![0.0f64; cells];
    for o in entities.living() {
        if o.kind() != crate::entities::Kind::Plant {
            continue;
        }
        let traits = PlantTraits::from_genome(o.genome());
        let cell_index = torus.index(o.cell());
        let cond = *cond_cache[cell_index].get_or_insert_with(|| climate.conditions(o.cell()));
        let growth = growth_factors(cond, &traits).product();
        let satiation = 1.0 - o.energy() / ENERGY_MAX;
        let demand = REQUEST_MAX * growth * satiation;
        demand_sum[cell_index] += f64::from(demand);
        plans.push(Plan {
            id: o.id().0,
            cell: cell_index,
            growth,
            yield_per_unit: traits.yield_per_unit,
            take: demand,
        });
    }
    // Proportional sharing: each plant takes demand * R / D when the cell's demand exceeds its pool.
    let mut taken_per_cell = vec![0.0f64; cells];
    for p in plans.iter_mut() {
        let pool = f64::from(resources.get_index(p.cell));
        let d = demand_sum[p.cell];
        if d > pool {
            p.take = (f64::from(p.take) * pool / d) as f32;
        }
        taken_per_cell[p.cell] += f64::from(p.take);
        report.taken += f64::from(p.take);
    }

    // Pass 2: each living plant acts, in ascending id order. The iterator and `plans` have the same order.
    let mut k = 0usize;
    for o in entities.living_mut() {
        if o.kind() != crate::entities::Kind::Plant {
            continue;
        }
        let plan = &plans[k];
        debug_assert_eq!(
            o.id().0,
            plan.id,
            "plans and living plants are in the same order"
        );
        k += 1;

        let before = o.energy();
        o.add_energy(plan.take * plan.yield_per_unit);
        report.gained += f64::from(o.energy() - before);

        o.drain_energy(MAINT_BASE + MAINT_HEALTH * o.health());
        if !o.is_alive() {
            // Starved by maintenance in this tick: no growth or damage is applied on top.
            continue;
        }
        if plan.growth > 0.0 {
            let headroom = o.traits().max_health() - o.health();
            let spare = o.energy() - GROWTH_RESERVE;
            let dh = (GROWTH_RATE * plan.growth).min(headroom).min(spare);
            if dh > 0.0 {
                o.heal(dh);
                o.drain_energy(dh);
            }
        } else {
            o.damage(HOSTILE_DAMAGE, DeathCause::Exposure);
        }
    }
    debug_assert_eq!(k, plans.len());

    // Pool update: remove what plants took (never below 0), then regenerate every cell toward its capacity.
    for index in 0..cells {
        let cell = torus
            .cell_from_index(index)
            .expect("index below cell_count");
        let pool = f64::from(resources.values[index]) - taken_per_cell[index];
        let mut value = pool.max(0.0) as f32;
        let cond = *cond_cache[index].get_or_insert_with(|| climate.conditions(cell));
        let cap = capacity(cond);
        let next = value + REGEN_RATE * (cap - value);
        report.regenerated += f64::from(next - value);
        value = next.clamp(0.0, CAP_MAX);
        resources.values[index] = value;
    }
    report
}

impl ResourceField {
    /// Canonical encoding of the resource pool of every cell (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let ResourceField { values } = self;
        enc.count(values.len());
        for v in values {
            enc.f32(*v);
        }
    }

    /// Reads the pool of every cell and validates it against the torus (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
        torus: &crate::world::Torus,
    ) -> Result<ResourceField, crate::checkpoint::CheckpointError> {
        let count = dec.count("resource values")?;
        let mut values = Vec::with_capacity(count);
        for _ in 0..count {
            values.push(dec.f32()?);
        }
        ResourceField::from_values(torus, values)
            .map_err(|e| crate::checkpoint::invalid_because("resources", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::genome::Genome;

    fn traits_with(cold: f32, drought: f32) -> PlantTraits {
        PlantTraits {
            cold_tolerance: cold,
            drought_tolerance: drought,
            yield_per_unit: 1.0,
        }
    }

    fn cond(t: f32, p: f32) -> Conditions {
        Conditions {
            temperature: t,
            precipitation: p,
        }
    }

    fn genome_with_slots(values: [(usize, u8); 3]) -> Genome {
        let mut loci = vec![128u8; 128];
        for (slot, v) in values {
            for l in 0..16 {
                loci[slot * 16 + l] = v;
            }
        }
        Genome::new(1, loci).unwrap()
    }

    #[test]
    fn temperature_factor_triangle_shape() {
        let ct = 0.5; // lower limit 0 C
        assert_eq!(temperature_factor(0.0, ct), 0.0);
        assert_eq!(temperature_factor(-3.0, ct), 0.0);
        assert_eq!(temperature_factor(40.0, ct), 0.0);
        assert_eq!(temperature_factor(50.0, ct), 0.0);
        assert!((temperature_factor(20.0, ct) - 1.0).abs() < 1e-6);
        let rising = temperature_factor(10.0, ct);
        assert!(rising > 0.0 && rising < 1.0);
        assert!(temperature_factor(15.0, ct) < temperature_factor(18.0, ct));
        assert!(temperature_factor(25.0, ct) > temperature_factor(35.0, ct));
    }

    #[test]
    fn cold_tolerance_moves_lower_limit() {
        // A tolerant plant (limit -5 C) grows at -2 C, an intolerant one (limit +5 C) does not.
        assert!(temperature_factor(-2.0, 1.0) > 0.0);
        assert_eq!(temperature_factor(-2.0, 0.0), 0.0);
    }

    #[test]
    fn water_factor_monotone_and_bounded() {
        assert_eq!(water_factor(0.0, 0.5), 0.0);
        assert_eq!(water_factor(19.9, 0.5), 0.0);
        let mut last = 0.0;
        for p in (20..=5000).step_by(20) {
            let w = water_factor(p as f32, 0.5);
            assert!(w >= last && w < 1.0, "p={p} w={w}");
            last = w;
        }
        // Drought tolerance raises the factor at the same precipitation.
        assert!(water_factor(100.0, 1.0) > water_factor(100.0, 0.0));
    }

    #[test]
    fn ecology_factors_in_unit_range_over_random_inputs() {
        let mut rng = crate::rng::Rng::from_seed(7);
        for _ in 0..10_000 {
            let t = -60.0 + 120.0 * (rng.next_below(1_000_000) as f32 / 1_000_000.0);
            let p = 5000.0 * (rng.next_below(1_000_000) as f32 / 1_000_000.0);
            let ct = rng.next_below(1_000_001) as f32 / 1_000_000.0;
            let dt = rng.next_below(1_000_001) as f32 / 1_000_000.0;
            let f = growth_factors(cond(t, p), &traits_with(ct, dt));
            assert!((0.0..=1.0).contains(&f.temperature));
            assert!((0.0..=1.0).contains(&f.water));
            assert!((0.0..=1.0).contains(&f.product()));
            let cap = capacity(cond(t, p));
            assert!((0.0..=CAP_MAX).contains(&cap));
        }
    }

    #[test]
    fn growth_factors_zero_when_too_cold_or_too_dry() {
        let good = growth_factors(cond(20.0, 1000.0), &traits_with(0.5, 0.5));
        assert!(good.product() > 0.5);
        let cold = growth_factors(cond(-10.0, 1000.0), &traits_with(0.5, 0.5));
        assert_eq!(cold.product(), 0.0);
        let dry = growth_factors(cond(20.0, 5.0), &traits_with(0.5, 0.5));
        assert_eq!(dry.product(), 0.0);
    }

    #[test]
    fn same_plant_grows_less_in_cold_and_dry_cells() {
        let t = traits_with(0.5, 0.5);
        let good = growth_factors(cond(20.0, 1000.0), &t).product();
        let cold = growth_factors(cond(5.0, 1000.0), &t).product();
        let dry = growth_factors(cond(20.0, 100.0), &t).product();
        assert!(cold < good, "cold {cold} good {good}");
        assert!(dry < good, "dry {dry} good {good}");
    }

    #[test]
    fn genome_slots_change_tolerance_and_yield() {
        let tolerant = PlantTraits::from_genome(&genome_with_slots([(5, 255), (6, 255), (7, 255)]));
        let intolerant = PlantTraits::from_genome(&genome_with_slots([(5, 0), (6, 0), (7, 0)]));
        assert!(tolerant.cold_tolerance > 0.99 && intolerant.cold_tolerance < 0.01);
        assert!(tolerant.yield_per_unit > 0.99);
        assert!((intolerant.yield_per_unit - 0.5).abs() < 0.01);
        // Cold tolerance changes growth in the same cold cell.
        let c = cond(-2.0, 1000.0);
        assert!(growth_factors(c, &tolerant).product() > 0.0);
        assert_eq!(growth_factors(c, &intolerant).product(), 0.0);
    }

    #[test]
    fn traits_decode_in_range_for_random_genomes() {
        let mut rng = crate::rng::Rng::from_seed(11);
        for _ in 0..10_000 {
            let g = crate::genome::random_genome(1, &mut rng).unwrap();
            let t = PlantTraits::from_genome(&g);
            assert!((0.0..=1.0).contains(&t.cold_tolerance));
            assert!((0.0..=1.0).contains(&t.drought_tolerance));
            assert!((0.5..=1.0).contains(&t.yield_per_unit));
            assert_eq!(t, PlantTraits::from_genome(&g));
        }
    }

    #[test]
    fn resource_field_rejects_bad_values() {
        let torus = Torus::new(2, 2).unwrap();
        assert!(ResourceField::from_values(&torus, vec![1.0; 3]).is_err());
        assert!(ResourceField::from_values(&torus, vec![1.0, 1.0, f32::NAN, 1.0]).is_err());
        assert!(ResourceField::from_values(&torus, vec![1.0, 1.0, -1.0, 1.0]).is_err());
        assert!(ResourceField::from_values(&torus, vec![1.0, 1.0, 101.0, 1.0]).is_err());
        assert!(ResourceField::from_values(&torus, vec![1.0, 2.0, 3.0, 4.0]).is_ok());
    }
}

#[cfg(test)]
mod integration_tests {
    use super::*;
    use crate::climate::ClimateParams;
    use crate::config::{Config, Initial};
    use crate::entities::{Birth, DeathCause, Entities, Kind, OrganismId};
    use crate::genome::{random_genome, Genome};
    use crate::rng::Rng;
    use crate::sim::Simulation;
    use crate::world::{Cell, Torus};

    /// 128 loci with slot 3 (lifespan), 4 (max health), 5 (cold), 6 (drought), 7 (yield) set; others 128.
    fn loci(lifespan: u8, cold: u8, drought: u8, yield_: u8) -> Vec<u8> {
        let mut l = vec![128u8; 128];
        for (slot, v) in [
            (3, lifespan),
            (4, 255),
            (5, cold),
            (6, drought),
            (7, yield_),
        ] {
            for i in 0..16 {
                l[slot * 16 + i] = v;
            }
        }
        l
    }

    fn sim_with(seed: u64, w: u64, h: u64) -> Simulation {
        let mut c = Config::new(
            seed,
            w,
            h,
            Initial {
                plants: 0,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        c.climate.weather_amplitude = 0.0;
        Simulation::new(&c).unwrap()
    }

    fn add_plant(
        sim: &mut Simulation,
        cell: Cell,
        loci: Vec<u8>,
        energy: f32,
        health: f32,
    ) -> OrganismId {
        let genome = Genome::new(1, loci).unwrap();
        let birth = Birth::from_genome(Kind::Plant, cell, genome, energy, health).unwrap();
        sim.add_founder(birth).unwrap()
    }

    /// Coldest and driest cells at tick 0 (weather off).
    fn extreme_cells(sim: &Simulation) -> (Cell, Cell, Cell) {
        let w = sim.world();
        let (mut cold, mut warm, mut dry) = (
            None::<(Cell, f32)>,
            None::<(Cell, f32)>,
            None::<(Cell, f32)>,
        );
        for i in 0..w.topology.cell_count() {
            let c = w.topology.cell_from_index(i).unwrap();
            let cond = w.climate.conditions(c);
            if cold.is_none_or(|(_, t)| cond.temperature < t) {
                cold = Some((c, cond.temperature));
            }
            if warm.is_none_or(|(_, t)| cond.temperature > t) {
                warm = Some((c, cond.temperature));
            }
            if dry.is_none_or(|(_, p)| cond.precipitation < p) {
                dry = Some((c, cond.precipitation));
            }
        }
        (cold.unwrap().0, warm.unwrap().0, dry.unwrap().0)
    }

    /// Health of a plant; a plant removed by the Deaths phase has no health left.
    fn health(sim: &Simulation, id: OrganismId) -> f32 {
        sim.entities().get(id).map_or(0.0, |o| o.health())
    }

    #[test]
    fn same_plant_grows_less_in_cold_cell_than_warm_cell() {
        let mut sim = sim_with(5, 16, 12);
        let (cold, warm, _) = extreme_cells(&sim);
        let w = sim.world().climate.conditions(warm);
        let c = sim.world().climate.conditions(cold);
        assert!(w.temperature > c.temperature + 5.0, "warm {w:?} cold {c:?}");
        let warm_p = add_plant(&mut sim, warm, loci(255, 128, 128, 128), 50.0, 10.0);
        let cold_p = add_plant(&mut sim, cold, loci(255, 128, 128, 128), 50.0, 10.0);
        sim.run(20);
        let (hw, hc) = (health(&sim, warm_p), health(&sim, cold_p));
        assert!(hw > 10.0, "warm plant did not grow: {hw}");
        assert!(
            hc < hw,
            "cold plant grew as much as warm one: cold {hc} warm {hw}"
        );
    }

    #[test]
    fn cold_intolerant_plant_does_not_grow_in_too_cold_cell() {
        let mut sim = sim_with(5, 16, 12);
        let (cold, _, _) = extreme_cells(&sim);
        assert!(sim.world().climate.conditions(cold).temperature <= 5.0);
        let p = add_plant(&mut sim, cold, loci(255, 0, 128, 128), 50.0, 10.0);
        sim.run(10);
        assert!(health(&sim, p) < 10.0, "plant grew in a too-cold cell");
    }

    #[test]
    fn cold_tolerance_gene_changes_growth_in_coldest_cell() {
        // G-050: the coldest cell where growth is possible at all (temperature just above T_LOWER_MAX). The colder
        // cells are hostile to both plants, so they cannot show the gene. Here both plants have a positive factor
        // and the tolerant one must grow strictly more.
        let mut sim = sim_with(5, 16, 12);
        let cell = {
            let w = sim.world();
            let mut best: Option<(Cell, f32)> = None;
            for i in 0..w.topology.cell_count() {
                let c = w.topology.cell_from_index(i).unwrap();
                let t = w.climate.conditions(c).temperature;
                if t > T_LOWER_MAX && best.is_none_or(|(_, bt)| t < bt) {
                    best = Some((c, t));
                }
            }
            best.expect("some cell is above the lower limit").0
        };
        let tolerant = add_plant(&mut sim, cell, loci(255, 255, 128, 128), 50.0, 10.0);
        let intolerant = add_plant(&mut sim, cell, loci(255, 0, 128, 128), 50.0, 10.0);
        sim.run(10);
        let (ht, hi) = (health(&sim, tolerant), health(&sim, intolerant));
        assert!(ht > 10.0, "tolerant plant did not grow: {ht}");
        assert!(ht > hi, "tolerant {ht} not strictly above intolerant {hi}");
    }

    #[test]
    fn drought_tolerance_gene_changes_growth_in_dry_cell() {
        let mut sim = sim_with(5, 16, 12);
        // The driest cell above P_MIN with a temperature in the growing range: below P_MIN both plants would be
        // hostile, so the drought gene could not matter there.
        let dry = {
            let w = sim.world();
            let mut best: Option<(Cell, f32)> = None;
            for i in 0..w.topology.cell_count() {
                let c = w.topology.cell_from_index(i).unwrap();
                let cond = w.climate.conditions(c);
                let growing = (5.0..=35.0).contains(&cond.temperature);
                if growing
                    && cond.precipitation >= P_MIN + 40.0
                    && best.is_none_or(|(_, p)| cond.precipitation < p)
                {
                    best = Some((c, cond.precipitation));
                }
            }
            best.expect("a dry but habitable cell exists").0
        };
        let dry_p = sim.world().climate.conditions(dry).precipitation;
        assert!(
            (P_MIN + 40.0..400.0).contains(&dry_p),
            "precipitation {dry_p}"
        );
        let tolerant = add_plant(&mut sim, dry, loci(255, 128, 255, 128), 50.0, 10.0);
        let intolerant = add_plant(&mut sim, dry, loci(255, 128, 0, 128), 50.0, 10.0);
        sim.run(10);
        let (ht, hi) = (health(&sim, tolerant), health(&sim, intolerant));
        assert!(ht > hi, "tolerant {ht} intolerant {hi}");
    }

    #[test]
    fn plant_dies_of_old_age_at_max_lifespan() {
        let mut sim = sim_with(5, 16, 12);
        let (_, warm, _) = extreme_cells(&sim);
        // Lifespan centre 2 gives max_lifespan = floor(1 + 0) = 1 for slot 0 (ADR-0019 D2).
        let short = crate::entities::LifespanRanges {
            plants: 2,
            ..Default::default()
        };
        let birth = Birth::from_genome_in(
            Kind::Plant,
            warm,
            Genome::new(1, loci(0, 128, 128, 128)).unwrap(),
            50.0,
            100.0,
            &short,
        )
        .unwrap();
        sim.add_founder(birth).unwrap();
        sim.tick();
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::OldAge),
            1
        );
        assert_eq!(sim.entities().living_count(Kind::Plant), 0);
    }

    #[test]
    fn plant_in_hostile_cell_dies_of_exposure() {
        let mut sim = sim_with(5, 16, 12);
        let (cold, _, _) = extreme_cells(&sim);
        assert!(sim.world().climate.conditions(cold).temperature <= 5.0);
        add_plant(&mut sim, cold, loci(255, 0, 128, 128), 50.0, 10.0);
        sim.run(10);
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::Exposure),
            1
        );
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
            0
        );
    }

    #[test]
    fn two_plants_in_one_cell_share_the_pool_in_proportion_to_demand() {
        let torus = Torus::new(4, 4).unwrap();
        let climate = Climate::new(
            &torus,
            3,
            ClimateParams {
                season_length: 100,
                weather_amplitude: 0.0,
            },
        )
        .unwrap();
        let full = ResourceField::full(&torus, &climate);
        // The cell with the largest capacity. Its pool is set to 0.012 * capacity = 1.2 * g, below the total demand
        // 2.4 * g of the two plants below (g = capacity / 100), so the pool is shared.
        let k = (0..torus.cell_count())
            .max_by(|&a, &b| full.get_index(a).total_cmp(&full.get_index(b)))
            .unwrap();
        let cap_k = full.get_index(k);
        assert!(cap_k > 0.0);
        let pool = 0.012 * cap_k;
        let mut values = vec![0.0f32; torus.cell_count()];
        values[k] = pool;
        let mut field = ResourceField::from_values(&torus, values).unwrap();
        let cell = torus.cell_from_index(k).unwrap();
        let mut ents = Entities::new();
        let g = Genome::new(1, loci(255, 128, 128, 128)).unwrap();
        // Same genome, so same growth factor and yield. Demand ratio 4g*0.5 : 4g*0.1 = 5 : 1. Energies stay above
        // maintenance so the gain is not clamped.
        let a = ents
            .spawn_founder(Birth::from_genome(Kind::Plant, cell, g.clone(), 50.0, 100.0).unwrap())
            .unwrap();
        let b = ents
            .spawn_founder(Birth::from_genome(Kind::Plant, cell, g, 90.0, 100.0).unwrap())
            .unwrap();
        let report = plants_phase(&mut ents, &mut field, &climate);
        let ga = f64::from(ents.get(a).unwrap().energy()) - 50.0 + 1.5;
        let gb = f64::from(ents.get(b).unwrap().energy()) - 90.0 + 1.5;
        assert!(ga > 0.0 && gb > 0.0);
        assert!((ga / gb - 5.0).abs() < 1e-3, "ratio {}", ga / gb);
        assert!(report.taken <= pool as f64 + 1e-4);
        assert!(
            (report.taken - pool as f64).abs() < 1e-4,
            "pool not fully shared: {}",
            report.taken
        );
    }

    #[test]
    fn crowded_cell_cannot_take_more_than_its_pool() {
        let torus = Torus::new(4, 4).unwrap();
        let climate = Climate::new(
            &torus,
            3,
            ClimateParams {
                season_length: 100,
                weather_amplitude: 0.0,
            },
        )
        .unwrap();
        let mut values = vec![0.0f32; torus.cell_count()];
        values[5] = 10.0;
        let mut field = ResourceField::from_values(&torus, values).unwrap();
        let cell = torus.cell_from_index(5).unwrap();
        let mut ents = Entities::new();
        for _ in 0..50 {
            let g = Genome::new(1, loci(255, 128, 128, 128)).unwrap();
            ents.spawn_founder(Birth::from_genome(Kind::Plant, cell, g, 0.0, 100.0).unwrap())
                .unwrap();
        }
        let report = plants_phase(&mut ents, &mut field, &climate);
        assert!(report.taken <= 10.0 + 1e-3, "taken {}", report.taken);
        assert!(report.gained <= report.taken + 1e-6);
        assert!(field.values().iter().all(|&v| (0.0..=CAP_MAX).contains(&v)));
    }

    #[test]
    fn plant_starves_when_pool_is_empty() {
        let torus = Torus::new(4, 4).unwrap();
        let climate = Climate::new(
            &torus,
            3,
            ClimateParams {
                season_length: 100,
                weather_amplitude: 0.0,
            },
        )
        .unwrap();
        let mut field = ResourceField::from_values(&torus, vec![0.0; torus.cell_count()]).unwrap();
        let cell = torus.cell_from_index(0).unwrap();
        let mut ents = Entities::new();
        let g = Genome::new(1, loci(255, 128, 128, 128)).unwrap();
        // Energy 1.0 is below the maintenance of 1.5 per tick; with an empty pool nothing comes in.
        let id = ents
            .spawn_founder(Birth::from_genome(Kind::Plant, cell, g, 1.0, 100.0).unwrap())
            .unwrap();
        let report = plants_phase(&mut ents, &mut field, &climate);
        assert_eq!(report.taken, 0.0);
        assert_eq!(report.gained, 0.0);
        assert_eq!(ents.get(id).unwrap().cause(), Some(DeathCause::Starvation));
    }

    #[test]
    fn no_plant_energy_without_pool() {
        let torus = Torus::new(4, 4).unwrap();
        let climate = Climate::new(
            &torus,
            3,
            ClimateParams {
                season_length: 100,
                weather_amplitude: 0.0,
            },
        )
        .unwrap();
        let mut field = ResourceField::from_values(&torus, vec![0.0; torus.cell_count()]).unwrap();
        let cell = torus.cell_from_index(0).unwrap();
        let mut ents = Entities::new();
        let g = Genome::new(1, loci(255, 128, 128, 255)).unwrap();
        let id = ents
            .spawn_founder(Birth::from_genome(Kind::Plant, cell, g, 10.0, 100.0).unwrap())
            .unwrap();
        let report = plants_phase(&mut ents, &mut field, &climate);
        assert_eq!(report.gained, 0.0);
        assert_eq!(report.taken, 0.0);
        assert!(
            report.regenerated > 0.0,
            "the pool refills from the climate"
        );
        let e = ents.get(id).unwrap().energy();
        assert!((e - (10.0 - 1.5)).abs() < 1e-4, "energy {e}");
    }

    #[test]
    fn pool_change_equals_regeneration_minus_take_over_run() {
        let torus = Torus::new(16, 12).unwrap();
        let mut climate = Climate::new(
            &torus,
            42,
            ClimateParams {
                season_length: 200,
                weather_amplitude: 0.3,
            },
        )
        .unwrap();
        let mut field = ResourceField::full(&torus, &climate);
        let mut ents = Entities::new();
        let mut rng = Rng::from_seed(42);
        for _ in 0..300 {
            let cell = torus
                .cell_from_index(rng.next_below(torus.cell_count() as u64) as usize)
                .unwrap();
            let g = random_genome(1, &mut rng).unwrap();
            let mut birth = Birth::from_genome(Kind::Plant, cell, g, 50.0, 0.0).unwrap();
            birth.health = birth.traits.max_health();
            ents.spawn_founder(birth).unwrap();
        }
        for t in 0..500u64 {
            climate.advance(&mut rng, t);
            let before = field.total();
            let r = plants_phase(&mut ents, &mut field, &climate);
            let after = field.total();
            assert!(
                field.values().iter().all(|&v| (0.0..=CAP_MAX).contains(&v)),
                "tick {t}"
            );
            assert!(
                (after - (before + r.regenerated - r.taken)).abs() < 0.05,
                "tick {t}: {before} {after} {r:?}"
            );
            assert!(r.gained <= r.taken + 1e-6, "tick {t}");
            ents.deaths_phase(t);
        }
        assert!(ents.living_count(Kind::Plant) > 0);
    }

    #[test]
    fn plant_phase_is_deterministic_and_keeps_indexes_consistent() {
        let config = Config::new(
            9,
            16,
            12,
            Initial {
                plants: 300,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let mut a = Simulation::new(&config).unwrap();
        let mut b = Simulation::new(&config).unwrap();
        a.populate_initial(&config).unwrap();
        b.populate_initial(&config).unwrap();
        a.run(200);
        b.run(200);
        assert_eq!(a, b);
        assert!(a.entities().check_balance().is_ok());
        assert!(a.entities().check_invariants().is_ok());
        assert!(a.check_spatial().is_ok());
        assert!(a.entities().living_count(Kind::Plant) <= 300);
    }

    #[test]
    fn plant_only_run_keeps_pools_in_range() {
        let config = Config::new(
            9,
            16,
            12,
            Initial {
                plants: 300,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        sim.run(500);
        let total = sim.world().resources.total();
        assert!((0.0..=f64::from(CAP_MAX) * 192.0).contains(&total));
        assert!(sim.entities().living_count(Kind::Plant) <= 300);
    }
}

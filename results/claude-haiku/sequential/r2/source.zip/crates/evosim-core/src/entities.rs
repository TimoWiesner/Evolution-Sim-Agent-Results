//! Organisms, their traits and the life cycle shared by plants, herbivores and carnivores.
//!
//! Decisions are recorded in `docs/decisions/ADR-0011-organisms-and-life-cycle.md`. In short:
//! - [`Kind`] has three values; only animals carry [`Tendencies`] (checked by the constructor).
//! - Organisms are stored in [`Entities`] as a `Vec` sorted by [`OrganismId`]. Ids come from a counter and are never reused.
//! - Energy and health change only through clamping methods on [`Organism`]; constructors reject out-of-range input.
//! - Death: [`Entities::deaths_phase`] ages every living organism by one tick, assigns causes, and removes the dead in one
//!   order-preserving pass, recording a [`Death`] for each.
//! - Births (Reproduction) run before Deaths within a tick, so a parent that reproduces and dies in the same tick is recorded
//!   as both a birth and a death of that tick.
//!
//! Genomes are not part of this module (TASK-009); traits are plain values that are validated here.
//! No random numbers are drawn here, and no hash maps are used, so the order of every iteration is fixed.

use std::fmt;

use crate::checkpoint::{invalid, invalid_because, CheckpointError};
use crate::genome::Genome;
use crate::species::SpeciesId;
use crate::world::{Cell, Torus};

/// Upper bound of energy. Energy is always within `[0, ENERGY_MAX]`.
pub const ENERGY_MAX: f32 = 100.0;

/// Valid range of `speed` in cells per tick (inclusive).
pub const SPEED_RANGE: (f64, f64) = (0.0, 4.0);
/// Valid range of `strength` (inclusive).
pub const STRENGTH_RANGE: (f64, f64) = (0.0, 10.0);
/// Valid range of `fertility` (inclusive).
pub const FERTILITY_RANGE: (f64, f64) = (0.0, 1.0);
/// Valid range of `max_lifespan` in ticks (inclusive).
pub const MAX_LIFESPAN_RANGE: (f64, f64) = (1.0, 10_000.0);
/// Valid range of `max_health` (inclusive).
pub const MAX_HEALTH_RANGE: (f64, f64) = (1.0, 100.0);
/// Valid range of the behavioural tendencies `aggression` and `caution` (inclusive).
pub const TENDENCY_RANGE: (f64, f64) = (0.0, 1.0);

/// The three kinds of organism.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Kind {
    Plant,
    Herbivore,
    Carnivore,
}

impl Kind {
    /// All kinds in their fixed order. Per-kind arrays use [`Kind::index`].
    pub const ALL: [Kind; 3] = [Kind::Plant, Kind::Herbivore, Kind::Carnivore];

    /// Position in [`Kind::ALL`]: 0, 1 or 2.
    pub const fn index(self) -> usize {
        match self {
            Kind::Plant => 0,
            Kind::Herbivore => 1,
            Kind::Carnivore => 2,
        }
    }

    /// Herbivores and carnivores. Only animals have tendencies.
    pub const fn is_animal(self) -> bool {
        matches!(self, Kind::Herbivore | Kind::Carnivore)
    }
}

/// Identifier of an organism. Allocated from [`Entities`] and never reused, even after the organism died.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct OrganismId(pub u64);

/// Why an organism died. Set once; the first cause that applies wins.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum DeathCause {
    OldAge,
    Starvation,
    Predation,
    Exposure,
    Injury,
}

impl DeathCause {
    /// All causes in their fixed order. Per-cause arrays use [`DeathCause::index`].
    pub const ALL: [DeathCause; 5] = [
        DeathCause::OldAge,
        DeathCause::Starvation,
        DeathCause::Predation,
        DeathCause::Exposure,
        DeathCause::Injury,
    ];

    /// Position in [`DeathCause::ALL`].
    pub const fn index(self) -> usize {
        match self {
            DeathCause::OldAge => 0,
            DeathCause::Starvation => 1,
            DeathCause::Predation => 2,
            DeathCause::Exposure => 3,
            DeathCause::Injury => 4,
        }
    }
}

/// Record of one removed organism, written by the Deaths phase.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Death {
    pub id: OrganismId,
    pub kind: Kind,
    pub cell: Cell,
    pub tick: u64,
    pub cause: DeathCause,
}

/// Errors from creating organisms or from the consistency checks.
#[derive(Clone, Debug, PartialEq)]
pub enum EntityError {
    /// A value is outside its documented range (NaN included). `field` names the trait or state value.
    OutOfRange {
        field: &'static str,
        value: f64,
        min: f64,
        max: f64,
    },
    /// An herbivore or carnivore was created without tendencies.
    TendencyRequired { kind: Kind },
    /// A plant was created with tendencies.
    TendencyNotAllowed { kind: Kind },
    /// The number of parents does not match the kind (plants: one, animals: two distinct).
    ParentCount { kind: Kind },
    /// A named parent does not exist or is already dead.
    ParentNotAlive { id: OrganismId },
    /// The id counter reached its last value.
    IdsExhausted,
    /// Per kind: `initial + births - deaths` differs from the number of living organisms.
    BalanceMismatch {
        kind: Kind,
        initial: u64,
        births: u64,
        deaths: u64,
        living: u64,
    },
    /// A stored organism or counter breaks a rule. The message says which.
    Invariant { message: String },
    /// The stated traits or tendencies are not the ones decoded from the genome (ADR-0004, TASK-009).
    GenomeMismatch { kind: Kind },
    /// The genome's ploidy does not fit the kind (plants: 1, animals: 2).
    PloidyMismatch { kind: Kind, ploidy: u8 },
}

impl fmt::Display for EntityError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            EntityError::OutOfRange {
                field,
                value,
                min,
                max,
            } => write!(f, "{field} = {value} is outside [{min}, {max}]"),
            EntityError::TendencyRequired { kind } => {
                write!(f, "{kind:?} is an animal and needs tendencies")
            }
            EntityError::TendencyNotAllowed { kind } => {
                write!(f, "{kind:?} has no tendencies")
            }
            EntityError::ParentCount { kind } => {
                write!(f, "wrong number of parents for {kind:?}")
            }
            EntityError::ParentNotAlive { id } => {
                write!(f, "parent {} does not exist or is dead", id.0)
            }
            EntityError::IdsExhausted => write!(f, "organism ids are exhausted"),
            EntityError::BalanceMismatch {
                kind,
                initial,
                births,
                deaths,
                living,
            } => write!(
                f,
                "{kind:?}: initial {initial} + births {births} - deaths {deaths} != living {living}"
            ),
            EntityError::Invariant { message } => write!(f, "invariant broken: {message}"),
            EntityError::GenomeMismatch { kind } => {
                write!(f, "{kind:?}: traits or tendencies do not match the genome")
            }
            EntityError::PloidyMismatch { kind, ploidy } => {
                write!(f, "{kind:?} cannot have a genome of ploidy {ploidy}")
            }
        }
    }
}

impl std::error::Error for EntityError {}

/// Checks `value` against an inclusive range. NaN fails every comparison, so it is rejected too.
fn check_range(field: &'static str, value: f64, (min, max): (f64, f64)) -> Result<(), EntityError> {
    if value >= min && value <= max {
        Ok(())
    } else {
        Err(EntityError::OutOfRange {
            field,
            value,
            min,
            max,
        })
    }
}

/// Inherited, fixed-at-birth traits. Fields are private; [`Traits::new`] enforces the documented ranges.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Traits {
    speed: f32,
    strength: f32,
    fertility: f32,
    max_lifespan: u32,
    max_health: f32,
}

impl Traits {
    /// Creates validated traits. Out-of-range or non-finite values are errors that name the trait; nothing is clamped.
    pub fn new(
        speed: f32,
        strength: f32,
        fertility: f32,
        max_lifespan: u32,
        max_health: f32,
    ) -> Result<Traits, EntityError> {
        check_range("speed", f64::from(speed), SPEED_RANGE)?;
        check_range("strength", f64::from(strength), STRENGTH_RANGE)?;
        check_range("fertility", f64::from(fertility), FERTILITY_RANGE)?;
        check_range("max_lifespan", f64::from(max_lifespan), MAX_LIFESPAN_RANGE)?;
        check_range("max_health", f64::from(max_health), MAX_HEALTH_RANGE)?;
        Ok(Traits {
            speed,
            strength,
            fertility,
            max_lifespan,
            max_health,
        })
    }

    pub fn speed(&self) -> f32 {
        self.speed
    }

    pub fn strength(&self) -> f32 {
        self.strength
    }

    pub fn fertility(&self) -> f32 {
        self.fertility
    }

    /// Ticks after which the organism dies of old age.
    pub fn max_lifespan(&self) -> u32 {
        self.max_lifespan
    }

    /// Health at full strength; health never exceeds it.
    pub fn max_health(&self) -> f32 {
        self.max_health
    }
}

/// Behavioural tendencies, only for herbivores and carnivores.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Tendencies {
    aggression: f32,
    caution: f32,
}

impl Tendencies {
    /// Creates validated tendencies; both values must be in `[0, 1]`.
    pub fn new(aggression: f32, caution: f32) -> Result<Tendencies, EntityError> {
        check_range("aggression", f64::from(aggression), TENDENCY_RANGE)?;
        check_range("caution", f64::from(caution), TENDENCY_RANGE)?;
        Ok(Tendencies {
            aggression,
            caution,
        })
    }

    pub fn aggression(&self) -> f32 {
        self.aggression
    }

    pub fn caution(&self) -> f32 {
        self.caution
    }
}

/// Centres of the lifespan range of each kind, in ticks (ADR-0019 D2). The lifespan of an organism is
/// `floor(centre * (0.5 + m))`, with `m` in `[0, 1]` the block mean of its lifespan slot, so the range is
/// `[0.5, 1.5] * centre` and its mean is the centre. The centres are the configuration keys `plants.max_age`,
/// `herbivores.max_age` and `carnivores.max_age`. Values are clamped to [`MAX_LIFESPAN_RANGE`] when decoded.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LifespanRanges {
    pub plants: u32,
    pub herbivores: u32,
    pub carnivores: u32,
}

impl LifespanRanges {
    /// The centre for `kind`.
    pub fn centre(&self, kind: Kind) -> u32 {
        match kind {
            Kind::Plant => self.plants,
            Kind::Herbivore => self.herbivores,
            Kind::Carnivore => self.carnivores,
        }
    }

    /// Reads the three `max_age` keys of a configuration (ADR-0019 D2). Values above `u32::MAX` are not possible
    /// because the configuration allows at most 100,000; the conversion saturates to be safe.
    pub fn from_config(config: &crate::config::Config) -> LifespanRanges {
        let as_u32 = |v: u64| u32::try_from(v).unwrap_or(u32::MAX);
        LifespanRanges {
            plants: as_u32(config.plants.max_age),
            herbivores: as_u32(config.herbivores.max_age),
            carnivores: as_u32(config.carnivores.max_age),
        }
    }
}

impl Default for LifespanRanges {
    /// The centres of the default configuration (`config::DEFAULT_*_MAX_AGE`).
    fn default() -> LifespanRanges {
        use crate::config::{
            DEFAULT_CARNIVORES_MAX_AGE, DEFAULT_HERBIVORES_MAX_AGE, DEFAULT_PLANTS_MAX_AGE,
        };
        LifespanRanges {
            plants: DEFAULT_PLANTS_MAX_AGE as u32,
            herbivores: DEFAULT_HERBIVORES_MAX_AGE as u32,
            carnivores: DEFAULT_CARNIVORES_MAX_AGE as u32,
        }
    }
}

/// Decodes a genome into traits and tendencies (ADR-0004, ADR-0011) with the default lifespan centres. Pure: the same
/// genome and kind always give the same values. Each trait is `min + (max - min) * mean`, where `mean` is the block mean
/// of [`Genome::trait_means`] (in `[0, 1]`). `max_lifespan` is floored. Plants need ploidy 1 and get no tendencies;
/// animals need ploidy 2.
pub fn decode_traits(
    genome: &Genome,
    kind: Kind,
) -> Result<(Traits, Option<Tendencies>), EntityError> {
    decode_traits_with(genome, kind, &LifespanRanges::default())
}

/// As [`decode_traits`], with the lifespan range centred on `lifespans` (ADR-0019 D2).
pub fn decode_traits_with(
    genome: &Genome,
    kind: Kind,
    lifespans: &LifespanRanges,
) -> Result<(Traits, Option<Tendencies>), EntityError> {
    let expected = if kind.is_animal() { 2 } else { 1 };
    if genome.ploidy() != expected {
        return Err(EntityError::PloidyMismatch {
            kind,
            ploidy: genome.ploidy(),
        });
    }
    let m = genome.trait_means();
    let map = |mean: f64, (min, max): (f64, f64)| (min + (max - min) * mean).clamp(min, max);
    let centre = f64::from(lifespans.centre(kind));
    let lifespan_range = (0.5 * centre, 1.5 * centre);
    let traits = Traits::new(
        map(m[0], SPEED_RANGE) as f32,
        map(m[1], STRENGTH_RANGE) as f32,
        map(m[2], FERTILITY_RANGE) as f32,
        map(m[3], lifespan_range)
            .clamp(MAX_LIFESPAN_RANGE.0, MAX_LIFESPAN_RANGE.1)
            .floor() as u32,
        map(m[4], MAX_HEALTH_RANGE) as f32,
    )?;
    let tendencies = if kind.is_animal() {
        Some(Tendencies::new(
            map(m[5], TENDENCY_RANGE) as f32,
            map(m[6], TENDENCY_RANGE) as f32,
        )?)
    } else {
        None
    };
    Ok((traits, tendencies))
}

/// Smallest vision range of an animal, in cells (ADR-0014).
pub const VISION_MIN: u32 = 1;
/// Largest vision range of an animal, in cells (ADR-0014).
pub const VISION_MAX: u32 = 5;

/// Vision range in cells of an animal, from genome slot 7 (ADR-0014, ADR-0004 amendment). Pure: it is derived from the
/// genome at use time and never stored. `vision = min(VISION_MAX, VISION_MIN + floor((VISION_MAX - VISION_MIN + 1) * m))`
/// with `m` the mean of slot 7 in `[0, 1]`, so the result is always an integer in `[VISION_MIN, VISION_MAX]`.
/// Only animals (ploidy 2) perceive; the genome must be an animal genome.
pub fn vision_radius(genome: &Genome) -> u32 {
    debug_assert_eq!(genome.ploidy(), 2, "vision is an animal trait");
    let m = genome.trait_means()[7];
    let scaled = f64::from(VISION_MAX - VISION_MIN + 1) * m;
    // `m` is in [0, 1], so `scaled` is in [0, 5] and the floor fits u32.
    (VISION_MIN + scaled.floor() as u32).min(VISION_MAX)
}

/// Everything needed to create an organism, before it has an id.
#[derive(Clone, Debug, PartialEq)]
pub struct Birth {
    pub kind: Kind,
    pub cell: Cell,
    pub traits: Traits,
    /// `Some` for herbivores and carnivores, `None` for plants.
    pub tendencies: Option<Tendencies>,
    /// Must be in `[0, ENERGY_MAX]`.
    pub energy: f32,
    /// Must be in `[0, traits.max_health()]`.
    pub health: f32,
    /// The heritable DNA. `traits` and `tendencies` must equal [`decode_traits`] of it.
    pub genome: Genome,
}

impl Birth {
    /// Builds a birth whose traits and tendencies are decoded from `genome`.
    pub fn from_genome(
        kind: Kind,
        cell: Cell,
        genome: Genome,
        energy: f32,
        health: f32,
    ) -> Result<Birth, EntityError> {
        Birth::from_genome_in(
            kind,
            cell,
            genome,
            energy,
            health,
            &LifespanRanges::default(),
        )
    }

    /// As [`Birth::from_genome`], with the lifespan centred on `lifespans` (ADR-0019 D2). Founders and newborns of the
    /// simulation use this with the configuration's centres.
    pub fn from_genome_in(
        kind: Kind,
        cell: Cell,
        genome: Genome,
        energy: f32,
        health: f32,
        lifespans: &LifespanRanges,
    ) -> Result<Birth, EntityError> {
        let (traits, tendencies) = decode_traits_with(&genome, kind, lifespans)?;
        Ok(Birth {
            kind,
            cell,
            traits,
            tendencies,
            energy,
            health,
            genome,
        })
    }
}

/// A living or dying organism. Fields are private; state changes only through the methods below.
#[derive(Clone, Debug, PartialEq)]
pub struct Organism {
    id: OrganismId,
    kind: Kind,
    cell: Cell,
    age: u32,
    energy: f32,
    health: f32,
    traits: Traits,
    tendencies: Option<Tendencies>,
    parents: [Option<OrganismId>; 2],
    generation: u32,
    cause: Option<DeathCause>,
    genome: Genome,
    /// Age from which the organism may mate again (TASK-016, ADR-0017). 0 at birth; set to `age + MATE_COOLDOWN`
    /// for both parents after a mating. Saved with the organism (TASK-022).
    next_mate_age: u32,
    /// Species (TASK-017, ADR-0018): provisional between checks (the mother's species for a newborn), `None` only before
    /// the founding check. Saved with the organism (TASK-022).
    species: Option<SpeciesId>,
}

/// Clamps `value` to `[min, max]`. Returns the bound itself at either end, so the result is never `-0.0`.
fn clamp_to(value: f32, min: f32, max: f32) -> f32 {
    if value <= min {
        min
    } else if value >= max {
        max
    } else {
        value
    }
}

/// True for amounts the event methods accept: finite and not negative.
fn valid_amount(amount: f32) -> bool {
    amount.is_finite() && amount >= 0.0
}

impl Organism {
    pub fn id(&self) -> OrganismId {
        self.id
    }

    pub fn kind(&self) -> Kind {
        self.kind
    }

    pub fn cell(&self) -> Cell {
        self.cell
    }

    /// Ticks lived. 0 at birth; +1 for each tick survived in the Deaths phase.
    pub fn age(&self) -> u32 {
        self.age
    }

    pub fn energy(&self) -> f32 {
        self.energy
    }

    pub fn health(&self) -> f32 {
        self.health
    }

    pub fn traits(&self) -> Traits {
        self.traits
    }

    pub fn tendencies(&self) -> Option<Tendencies> {
        self.tendencies
    }

    pub fn parents(&self) -> [Option<OrganismId>; 2] {
        self.parents
    }

    /// 0 for founders, otherwise 1 + the largest generation among the parents.
    pub fn generation(&self) -> u32 {
        self.generation
    }

    /// `None` while the organism is alive.
    /// The heritable DNA; traits and tendencies are decoded from it.
    pub fn genome(&self) -> &Genome {
        &self.genome
    }

    pub fn cause(&self) -> Option<DeathCause> {
        self.cause
    }

    /// True until a death cause is set. A dead organism stays stored until the Deaths phase and must not act.
    pub fn is_alive(&self) -> bool {
        self.cause.is_none()
    }

    /// Moves the organism to another cell. Callers pass a cell from the same torus.
    pub fn set_cell(&mut self, cell: Cell) {
        self.cell = cell;
    }

    /// Age from which the organism may mate again (ADR-0017).
    pub fn next_mate_age(&self) -> u32 {
        self.next_mate_age
    }

    /// The species of the organism (ADR-0018). `None` only before the founding check.
    pub fn species(&self) -> Option<SpeciesId> {
        self.species
    }

    /// Sets the species. Only the species module (classification and inheritance) calls this.
    pub fn set_species(&mut self, species: Option<SpeciesId>) {
        self.species = species;
    }

    /// Adds energy, capped at [`ENERGY_MAX`]. Negative or non-finite amounts are a debug assertion and a no-op in release.
    pub fn add_energy(&mut self, amount: f32) {
        if !valid_amount(amount) {
            debug_assert!(false, "add_energy: invalid amount {amount}");
            return;
        }
        self.energy = clamp_to(self.energy + amount, 0.0, ENERGY_MAX);
    }

    /// Removes energy, floored at 0. Reaching 0 sets the cause `Starvation` if no cause is set yet.
    /// Invalid amounts are a debug assertion and a no-op in release.
    pub fn drain_energy(&mut self, amount: f32) {
        if !valid_amount(amount) {
            debug_assert!(false, "drain_energy: invalid amount {amount}");
            return;
        }
        self.energy = clamp_to(self.energy - amount, 0.0, ENERGY_MAX);
        if self.energy == 0.0 && self.cause.is_none() {
            self.cause = Some(DeathCause::Starvation);
        }
    }

    /// Removes health, floored at 0. Reaching 0 sets `cause` if no cause is set yet.
    /// `cause` should be `Predation`, `Exposure` or `Injury`. Invalid amounts are a debug assertion and a no-op in release.
    pub fn damage(&mut self, amount: f32, cause: DeathCause) {
        if !valid_amount(amount) {
            debug_assert!(false, "damage: invalid amount {amount}");
            return;
        }
        debug_assert!(
            !matches!(cause, DeathCause::OldAge | DeathCause::Starvation),
            "damage must not carry {cause:?}"
        );
        self.health = clamp_to(self.health - amount, 0.0, self.traits.max_health);
        if self.health == 0.0 && self.cause.is_none() {
            self.cause = Some(cause);
        }
    }

    /// Adds health, capped at `traits.max_health()`. Invalid amounts are a debug assertion and a no-op in release.
    pub fn heal(&mut self, amount: f32) {
        if !valid_amount(amount) {
            debug_assert!(false, "heal: invalid amount {amount}");
            return;
        }
        self.health = clamp_to(self.health + amount, 0.0, self.traits.max_health);
    }
}

/// Validates the parts of a birth that do not depend on the store: tendency rule, ranges, and that the traits and
/// tendencies are the ones decoded from the genome.
fn validate_birth(birth: &Birth) -> Result<(), EntityError> {
    validate_state(
        birth.kind,
        birth.traits,
        birth.tendencies,
        birth.energy,
        birth.health,
    )?;
    validate_genome(birth.kind, &birth.genome, birth.traits, birth.tendencies)
}

fn validate_state(
    kind: Kind,
    traits: Traits,
    tendencies: Option<Tendencies>,
    energy: f32,
    health: f32,
) -> Result<(), EntityError> {
    match (kind.is_animal(), tendencies) {
        (true, None) => return Err(EntityError::TendencyRequired { kind }),
        (false, Some(_)) => return Err(EntityError::TendencyNotAllowed { kind }),
        _ => {}
    }
    check_range("energy", f64::from(energy), (0.0, f64::from(ENERGY_MAX)))?;
    check_range(
        "health",
        f64::from(health),
        (0.0, f64::from(traits.max_health)),
    )?;
    Ok(())
}

/// The stated traits and tendencies must equal the values decoded from the genome (ADR-0004). The lifespan is checked
/// only for its valid range: its centre is a configuration value that the store does not hold (ADR-0019 D2), and
/// [`Birth::from_genome_in`] is the constructor that applies it.
fn validate_genome(
    kind: Kind,
    genome: &Genome,
    traits: Traits,
    tendencies: Option<Tendencies>,
) -> Result<(), EntityError> {
    let (decoded, decoded_tendencies) = decode_traits(genome, kind)?;
    let same_but_lifespan = decoded.speed() == traits.speed()
        && decoded.strength() == traits.strength()
        && decoded.fertility() == traits.fertility()
        && decoded.max_health() == traits.max_health();
    let lifespan_ok = f64::from(traits.max_lifespan()) >= MAX_LIFESPAN_RANGE.0
        && f64::from(traits.max_lifespan()) <= MAX_LIFESPAN_RANGE.1;
    if !same_but_lifespan || !lifespan_ok || decoded_tendencies != tendencies {
        return Err(EntityError::GenomeMismatch { kind });
    }
    Ok(())
}

/// The organism store of one simulation: sorted by id, with per-kind bookkeeping since tick 0.
#[derive(Clone, Debug, PartialEq)]
pub struct Entities {
    /// Ascending by id. New ids are larger than all existing ids, so pushing keeps the order.
    organisms: Vec<Organism>,
    next_id: u64,
    initial: [u64; 3],
    births: [u64; 3],
    deaths: [u64; 3],
    deaths_by_cause: [[u64; 5]; 3],
    /// Deaths written by the most recent Deaths phase. Not part of checkpoints (ADR-0011).
    last_deaths: Vec<Death>,
}

impl Default for Entities {
    fn default() -> Self {
        Entities::new()
    }
}

impl Entities {
    /// An empty store with the id counter at 0.
    pub fn new() -> Entities {
        Entities {
            organisms: Vec::new(),
            next_id: 0,
            initial: [0; 3],
            births: [0; 3],
            deaths: [0; 3],
            deaths_by_cause: [[0; 5]; 3],
            last_deaths: Vec::new(),
        }
    }

    /// Creates a founder (no parents, generation 0). Counted in `initial`, never in `births`.
    /// The simulation allows founders only at tick 0.
    pub fn spawn_founder(&mut self, birth: Birth) -> Result<OrganismId, EntityError> {
        validate_birth(&birth)?;
        let id = self.allocate_id()?;
        self.push(id, &birth, [None, None], 0);
        self.initial[birth.kind.index()] += 1;
        Ok(id)
    }

    /// Creates a child. Plants name one parent; animals name two distinct parents. Every named parent must be alive.
    /// Counted in `births`. Nothing is changed if an error is returned.
    pub fn spawn_child(
        &mut self,
        birth: Birth,
        parents: [Option<OrganismId>; 2],
    ) -> Result<OrganismId, EntityError> {
        validate_birth(&birth)?;
        let kind = birth.kind;
        let [p0, p1] = parents;
        let parent_count_ok = if kind.is_animal() {
            matches!((p0, p1), (Some(a), Some(b)) if a != b)
        } else {
            p0.is_some() && p1.is_none()
        };
        if !parent_count_ok {
            return Err(EntityError::ParentCount { kind });
        }
        let mut generation = 0u32;
        for id in parents.iter().flatten() {
            let parent = self
                .get(*id)
                .filter(|p| p.is_alive())
                .ok_or(EntityError::ParentNotAlive { id: *id })?;
            generation = generation.max(parent.generation.saturating_add(1));
        }
        let id = self.allocate_id()?;
        self.push(id, &birth, parents, generation);
        self.births[kind.index()] += 1;
        Ok(id)
    }

    /// The organism with this id, alive or dying (not yet removed). Binary search by id.
    pub fn get(&self, id: OrganismId) -> Option<&Organism> {
        self.position(id).map(|i| &self.organisms[i])
    }

    /// Mutable access for the action phases. Same lookup as [`Entities::get`].
    pub fn get_mut(&mut self, id: OrganismId) -> Option<&mut Organism> {
        self.position(id).map(move |i| &mut self.organisms[i])
    }

    /// Organisms that are still alive, in ascending id order. Every action phase iterates this.
    pub fn living(&self) -> impl Iterator<Item = &Organism> {
        self.organisms.iter().filter(|o| o.is_alive())
    }

    /// Mutable access to the organisms that are still alive, in ascending id order. Action phases use this so that
    /// dead organisms are never changed (TASK-011, closes the convention part of G-040 for the plant phase). `get_mut`
    /// is unchanged and still accepts dead organisms.
    pub fn living_mut(&mut self) -> impl Iterator<Item = &mut Organism> {
        self.organisms.iter_mut().filter(|o| o.is_alive())
    }

    /// Number of living organisms of one kind.
    pub fn living_count(&self, kind: Kind) -> u64 {
        self.living().filter(|o| o.kind == kind).count() as u64
    }

    /// Deaths written by the most recent Deaths phase, in ascending id order.
    pub fn last_deaths(&self) -> &[Death] {
        &self.last_deaths
    }

    /// Founders of one kind (tick 0 only).
    pub fn initial(&self, kind: Kind) -> u64 {
        self.initial[kind.index()]
    }

    /// Cumulative births of one kind since tick 0 (children only).
    pub fn births(&self, kind: Kind) -> u64 {
        self.births[kind.index()]
    }

    /// Cumulative deaths of one kind since tick 0.
    pub fn deaths(&self, kind: Kind) -> u64 {
        self.deaths[kind.index()]
    }

    /// Cumulative deaths of one kind for one cause since tick 0.
    pub fn deaths_by_cause(&self, kind: Kind, cause: DeathCause) -> u64 {
        self.deaths_by_cause[kind.index()][cause.index()]
    }

    /// Sets the mating cooldown of a living organism: it may mate again from age `next_mate_age` on (ADR-0017).
    /// Only the mating phase calls this. Refused for unknown or dead ids, nothing is changed then.
    pub(crate) fn set_next_mate_age(
        &mut self,
        id: OrganismId,
        next_mate_age: u32,
    ) -> Result<(), EntityError> {
        match self.get_mut(id) {
            Some(o) if o.is_alive() => {
                o.next_mate_age = next_mate_age;
                Ok(())
            }
            _ => Err(EntityError::ParentNotAlive { id }),
        }
    }

    /// The next id that will be allocated. Part of the state (checkpoint, TASK-022).
    pub fn next_id(&self) -> u64 {
        self.next_id
    }

    /// The Deaths phase of tick `tick`:
    /// 1. every living organism ages by one;
    /// 2. in ascending id order, every living organism without a cause gets one: health 0 is `Injury`, energy 0 is
    ///    `Starvation`, age at or above `max_lifespan` is `OldAge`;
    /// 3. every organism with a cause is removed in one order-preserving pass, and a [`Death`] is recorded for it.
    pub fn deaths_phase(&mut self, tick: u64) {
        self.last_deaths.clear();
        for o in self.organisms.iter_mut().filter(|o| o.is_alive()) {
            o.age = o.age.saturating_add(1);
            o.cause = if o.health <= 0.0 {
                Some(DeathCause::Injury)
            } else if o.energy <= 0.0 {
                Some(DeathCause::Starvation)
            } else if o.age >= o.traits.max_lifespan {
                Some(DeathCause::OldAge)
            } else {
                None
            };
        }
        let Entities {
            organisms,
            deaths,
            deaths_by_cause,
            last_deaths,
            ..
        } = self;
        organisms.retain(|o| match o.cause {
            None => true,
            Some(cause) => {
                let k = o.kind.index();
                deaths[k] += 1;
                deaths_by_cause[k][cause.index()] += 1;
                last_deaths.push(Death {
                    id: o.id,
                    kind: o.kind,
                    cell: o.cell,
                    tick,
                    cause,
                });
                false
            }
        });
    }

    /// Checks `initial + births - deaths = living` for every kind. Read-only.
    pub fn check_balance(&self) -> Result<(), EntityError> {
        for kind in Kind::ALL {
            let k = kind.index();
            let living = self.living_count(kind);
            if self.initial[k] + self.births[k] != self.deaths[k] + living {
                return Err(EntityError::BalanceMismatch {
                    kind,
                    initial: self.initial[k],
                    births: self.births[k],
                    deaths: self.deaths[k],
                    living,
                });
            }
        }
        Ok(())
    }

    /// Checks every stored organism and counter: ids strictly ascending and below `next_id`, ranges, the animal and
    /// tendency rule, parent counts, no pending cause (valid between phases), and per-cause deaths summing to deaths.
    pub fn check_invariants(&self) -> Result<(), EntityError> {
        let fail = |message: String| Err(EntityError::Invariant { message });
        let mut previous: Option<OrganismId> = None;
        for o in &self.organisms {
            if previous.is_some_and(|p| p >= o.id) {
                return fail(format!("ids not strictly ascending at {}", o.id.0));
            }
            previous = Some(o.id);
            if o.id.0 >= self.next_id {
                return fail(format!(
                    "id {} is not below next_id {}",
                    o.id.0, self.next_id
                ));
            }
            if o.cause.is_some() {
                return fail(format!("organism {} has a pending cause", o.id.0));
            }
            if validate_state(o.kind, o.traits, o.tendencies, o.energy, o.health).is_err() {
                return fail(format!(
                    "organism {} breaks a range or the tendency rule",
                    o.id.0
                ));
            }
            if validate_genome(o.kind, &o.genome, o.traits, o.tendencies).is_err() {
                return fail(format!(
                    "organism {} has traits that do not match its genome",
                    o.id.0
                ));
            }
            let parent_ok = match (o.kind.is_animal(), o.parents) {
                (_, [None, None]) => o.generation == 0,
                (false, [Some(_), None]) => true,
                (true, [Some(a), Some(b)]) => a != b,
                _ => false,
            };
            if !parent_ok {
                return fail(format!("organism {} has an invalid parent set", o.id.0));
            }
        }
        for kind in Kind::ALL {
            let k = kind.index();
            let by_cause: u64 = self.deaths_by_cause[k].iter().sum();
            if by_cause != self.deaths[k] {
                return fail(format!(
                    "{kind:?}: deaths by cause {by_cause} != deaths {}",
                    self.deaths[k]
                ));
            }
        }
        self.check_balance()
    }

    fn allocate_id(&mut self) -> Result<OrganismId, EntityError> {
        let id = OrganismId(self.next_id);
        self.next_id = self
            .next_id
            .checked_add(1)
            .ok_or(EntityError::IdsExhausted)?;
        Ok(id)
    }

    fn push(
        &mut self,
        id: OrganismId,
        birth: &Birth,
        parents: [Option<OrganismId>; 2],
        generation: u32,
    ) {
        self.organisms.push(Organism {
            id,
            kind: birth.kind,
            cell: birth.cell,
            age: 0,
            energy: birth.energy,
            health: birth.health,
            traits: birth.traits,
            tendencies: birth.tendencies,
            parents,
            generation,
            cause: None,
            genome: birth.genome.clone(),
            next_mate_age: 0,
            species: None,
        });
    }

    fn position(&self, id: OrganismId) -> Option<usize> {
        self.organisms.binary_search_by_key(&id, |o| o.id).ok()
    }
}

impl Traits {
    /// Canonical encoding of the inherited traits (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Traits {
            speed,
            strength,
            fertility,
            max_lifespan,
            max_health,
        } = self;
        enc.f32(*speed);
        enc.f32(*strength);
        enc.f32(*fertility);
        enc.u32(*max_lifespan);
        enc.f32(*max_health);
    }
}

impl Tendencies {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Tendencies {
            aggression,
            caution,
        } = self;
        enc.f32(*aggression);
        enc.f32(*caution);
    }
}

impl LifespanRanges {
    /// Canonical encoding of the lifespan centres (ADR-0019 D2, ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let LifespanRanges {
            plants,
            herbivores,
            carnivores,
        } = self;
        enc.u32(*plants);
        enc.u32(*herbivores);
        enc.u32(*carnivores);
    }
}

/// Tag of an optional death cause: 0 for `None`, otherwise 1 plus the cause's index.
fn cause_tag(cause: Option<DeathCause>) -> u8 {
    cause.map_or(0, |c| 1 + c.index() as u8)
}

impl Death {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Death {
            id,
            kind,
            cell,
            tick,
            cause,
        } = self;
        enc.u64(id.0);
        enc.u8(kind.index() as u8);
        enc.u32(cell.x());
        enc.u32(cell.y());
        enc.u64(*tick);
        enc.u8(cause_tag(Some(*cause)));
    }
}

impl Organism {
    /// Canonical encoding of one organism: every field, including the genome, parents, cause, mating age and species
    /// (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Organism {
            id,
            kind,
            cell,
            age,
            energy,
            health,
            traits,
            tendencies,
            parents,
            generation,
            cause,
            genome,
            next_mate_age,
            species,
        } = self;
        enc.u64(id.0);
        enc.u8(kind.index() as u8);
        enc.u32(cell.x());
        enc.u32(cell.y());
        enc.u32(*age);
        enc.f32(*energy);
        enc.f32(*health);
        traits.encode_state(enc);
        match tendencies {
            None => enc.u8(0),
            Some(t) => {
                enc.u8(1);
                t.encode_state(enc);
            }
        }
        for parent in parents {
            enc.opt_u64(parent.map(|p| p.0));
        }
        enc.u32(*generation);
        enc.u8(cause_tag(*cause));
        genome.encode_state(enc);
        enc.u32(*next_mate_age);
        enc.opt_u64(species.map(|s| u64::from(s.0)));
    }
}

impl Entities {
    /// Canonical encoding of the organism store and its bookkeeping (ADR-0020 D3). Per-kind arrays are in
    /// [`Kind::index`] order, per-cause arrays in [`DeathCause::index`] order.
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Entities {
            organisms,
            next_id,
            initial,
            births,
            deaths,
            deaths_by_cause,
            last_deaths,
        } = self;
        enc.count(organisms.len());
        for o in organisms {
            o.encode_state(enc);
        }
        enc.u64(*next_id);
        for counts in [initial, births, deaths] {
            for n in counts {
                enc.u64(*n);
            }
        }
        for per_cause in deaths_by_cause {
            for n in per_cause {
                enc.u64(*n);
            }
        }
        enc.count(last_deaths.len());
        for d in last_deaths {
            d.encode_state(enc);
        }
    }

    /// Reads the organism store (ADR-0023 D3). Organisms must be strictly ascending by id and below `next_id`; the
    /// counters must satisfy the balance and the invariants of [`Entities::check_balance`] and
    /// [`Entities::check_invariants`]. Nothing is repaired: any violation is an error.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
        torus: &Torus,
    ) -> Result<Entities, CheckpointError> {
        let count = dec.count("organism count")?;
        let mut organisms = Vec::with_capacity(count);
        for _ in 0..count {
            let organism = Organism::decode_state(dec, torus)?;
            if let Some(previous) = organisms.last().map(|o: &Organism| o.id) {
                if organism.id <= previous {
                    return Err(invalid("organism ids are not strictly ascending"));
                }
            }
            organisms.push(organism);
        }
        let next_id = dec.u64()?;
        if organisms.last().is_some_and(|o| o.id.0 >= next_id) {
            return Err(invalid("organism id is not below next_id"));
        }
        let initial = decode_kind_counts(dec)?;
        let births = decode_kind_counts(dec)?;
        let deaths = decode_kind_counts(dec)?;
        let mut deaths_by_cause = [[0u64; 5]; 3];
        for per_kind in &mut deaths_by_cause {
            for n in per_kind.iter_mut() {
                *n = dec.u64()?;
            }
        }
        let death_count = dec.count("last deaths")?;
        let mut last_deaths = Vec::with_capacity(death_count);
        for _ in 0..death_count {
            last_deaths.push(Death::decode_state(dec, torus)?);
        }
        let entities = Entities {
            organisms,
            next_id,
            initial,
            births,
            deaths,
            deaths_by_cause,
            last_deaths,
        };
        entities
            .check_balance()
            .map_err(|e| invalid_because("entity counters", e))?;
        entities
            .check_invariants()
            .map_err(|e| invalid_because("entity invariants", e))?;
        Ok(entities)
    }
}

/// Three `u64` counters, one per kind, in [`Kind::index`] order.
fn decode_kind_counts(dec: &mut crate::checkpoint::Decoder) -> Result<[u64; 3], CheckpointError> {
    Ok([dec.u64()?, dec.u64()?, dec.u64()?])
}

/// Reads a kind tag written by `Kind::index` (ADR-0023 D3).
pub(crate) fn decode_kind(dec: &mut crate::checkpoint::Decoder) -> Result<Kind, CheckpointError> {
    Kind::ALL
        .get(usize::from(dec.u8()?))
        .copied()
        .ok_or_else(|| invalid("kind tag"))
}

/// Reads a death cause tag: 0 for none, otherwise 1 plus the index (see `cause_tag`).
fn decode_cause(dec: &mut crate::checkpoint::Decoder) -> Result<Option<DeathCause>, CheckpointError> {
    match dec.u8()? {
        0 => Ok(None),
        tag => DeathCause::ALL
            .get(usize::from(tag) - 1)
            .copied()
            .map(Some)
            .ok_or_else(|| invalid("death cause tag")),
    }
}

impl Traits {
    /// Reads the traits and validates them with [`Traits::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(dec: &mut crate::checkpoint::Decoder) -> Result<Traits, CheckpointError> {
        let speed = dec.f32()?;
        let strength = dec.f32()?;
        let fertility = dec.f32()?;
        let max_lifespan = dec.u32()?;
        let max_health = dec.f32()?;
        Traits::new(speed, strength, fertility, max_lifespan, max_health)
            .map_err(|e| invalid_because("traits", e))
    }
}

impl Tendencies {
    /// Reads the tendencies and validates them with [`Tendencies::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(dec: &mut crate::checkpoint::Decoder) -> Result<Tendencies, CheckpointError> {
        let aggression = dec.f32()?;
        let caution = dec.f32()?;
        Tendencies::new(aggression, caution).map_err(|e| invalid_because("tendencies", e))
    }
}

impl LifespanRanges {
    /// Reads the lifespan centres (ADR-0023 D3).
    pub(crate) fn decode_state(dec: &mut crate::checkpoint::Decoder) -> Result<LifespanRanges, CheckpointError> {
        Ok(LifespanRanges {
            plants: dec.u32()?,
            herbivores: dec.u32()?,
            carnivores: dec.u32()?,
        })
    }
}

impl Death {
    /// Reads one death record (ADR-0023 D3). The cell must lie on the torus; a death has a cause, so tag 0 is refused.
    pub(crate) fn decode_state(dec: &mut crate::checkpoint::Decoder, torus: &Torus) -> Result<Death, CheckpointError> {
        let id = OrganismId(dec.u64()?);
        let kind = decode_kind(dec)?;
        let cell = decode_cell(dec, torus)?;
        let tick = dec.u64()?;
        let cause = decode_cause(dec)?.ok_or_else(|| invalid("death without a cause"))?;
        Ok(Death {
            id,
            kind,
            cell,
            tick,
            cause,
        })
    }
}

/// Reads a cell as two `u32` and checks that it lies on the torus.
fn decode_cell(dec: &mut crate::checkpoint::Decoder, torus: &Torus) -> Result<Cell, CheckpointError> {
    let x = dec.u32()?;
    let y = dec.u32()?;
    torus.cell(x, y).ok_or_else(|| invalid("cell outside the torus"))
}

impl Organism {
    /// Reads one organism, every field (ADR-0023 D3). Energy and health must be finite and not negative; the traits,
    /// tendencies and genome are validated by their own constructors.
    pub(crate) fn decode_state(dec: &mut crate::checkpoint::Decoder, torus: &Torus) -> Result<Organism, CheckpointError> {
        let id = OrganismId(dec.u64()?);
        let kind = decode_kind(dec)?;
        let cell = decode_cell(dec, torus)?;
        let age = dec.u32()?;
        let energy = dec.f32()?;
        let health = dec.f32()?;
        if !valid_amount(energy) || !valid_amount(health) {
            return Err(invalid("organism energy or health"));
        }
        let traits = Traits::decode_state(dec)?;
        let tendencies = if dec.bool("tendencies presence")? {
            Some(Tendencies::decode_state(dec)?)
        } else {
            None
        };
        let parents = [dec.opt_u64("parent")?, dec.opt_u64("parent")?].map(|p| p.map(OrganismId));
        let generation = dec.u32()?;
        let cause = decode_cause(dec)?;
        let genome = Genome::decode_state(dec)?;
        let next_mate_age = dec.u32()?;
        let species = match dec.opt_u64("species")? {
            None => None,
            Some(s) => Some(SpeciesId(
                u32::try_from(s).map_err(|_| invalid("species id"))?,
            )),
        };
        Ok(Organism {
            id,
            kind,
            cell,
            age,
            energy,
            health,
            traits,
            tendencies,
            parents,
            generation,
            cause,
            genome,
            next_mate_age,
            species,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;
    use crate::world::Torus;
    use std::collections::BTreeSet;

    fn cell() -> Cell {
        Torus::new(8, 8).unwrap().cell(1, 1).unwrap()
    }

    /// A genome with every locus at 128 (all trait means about one half): ploidy 1 for plants, 2 for animals.
    fn base_genome(kind: Kind) -> Genome {
        let ploidy = if kind.is_animal() { 2 } else { 1 };
        Genome::new(ploidy, vec![128; usize::from(ploidy) * 128]).unwrap()
    }

    /// A genome whose trait block `slot` has the given integer locus sum, filled from the first locus of each haplotype.
    fn genome_with_slot_sum(kind: Kind, slot: usize, sum: u64) -> Genome {
        let ploidy = if kind.is_animal() { 2 } else { 1 };
        let mut loci = vec![0u8; usize::from(ploidy) * 128];
        let mut left = sum;
        for h in 0..usize::from(ploidy) {
            for i in 0..16 {
                let v = left.min(255) as u8;
                loci[h * 128 + slot * 16 + i] = v;
                left -= u64::from(v);
            }
        }
        Genome::new(ploidy, loci).unwrap()
    }

    fn traits() -> Traits {
        decode_traits(&base_genome(Kind::Herbivore), Kind::Herbivore)
            .unwrap()
            .0
    }

    fn tendencies() -> Tendencies {
        decode_traits(&base_genome(Kind::Herbivore), Kind::Herbivore)
            .unwrap()
            .1
            .unwrap()
    }

    fn plant(energy: f32, health: f32) -> Birth {
        Birth::from_genome(
            Kind::Plant,
            cell(),
            base_genome(Kind::Plant),
            energy,
            health,
        )
        .unwrap()
    }

    fn animal(kind: Kind, energy: f32, health: f32) -> Birth {
        Birth::from_genome(kind, cell(), base_genome(kind), energy, health).unwrap()
    }

    fn single_organism(energy: f32, health: f32) -> Organism {
        let mut e = Entities::new();
        let id = e.spawn_founder(plant(energy, health)).unwrap();
        e.get(id).unwrap().clone()
    }

    #[test]
    fn kinds_are_three_distinct_values_in_fixed_order() {
        assert_eq!(Kind::ALL, [Kind::Plant, Kind::Herbivore, Kind::Carnivore]);
        for (i, k) in Kind::ALL.iter().enumerate() {
            assert_eq!(k.index(), i);
        }
        assert!(!Kind::Plant.is_animal());
        assert!(Kind::Herbivore.is_animal());
        assert!(Kind::Carnivore.is_animal());
    }

    #[test]
    fn death_causes_have_fixed_indices() {
        for (i, c) in DeathCause::ALL.iter().enumerate() {
            assert_eq!(c.index(), i);
        }
        assert_eq!(DeathCause::ALL.len(), 5);
    }

    #[test]
    fn each_trait_accepts_its_bounds_and_rejects_outside_values() {
        // (field, lower ok, upper ok, below, above) built through Traits::new with the other fields valid.
        let build = |field: &str, v: f64| -> Result<Traits, EntityError> {
            let (mut s, mut g, mut f, mut l, mut h) = (1.0f32, 1.0f32, 0.5f32, 100u32, 50.0f32);
            match field {
                "speed" => s = v as f32,
                "strength" => g = v as f32,
                "fertility" => f = v as f32,
                "max_lifespan" => l = v as u32,
                _ => h = v as f32,
            }
            Traits::new(s, g, f, l, h)
        };
        let cases: [(&str, (f64, f64)); 5] = [
            ("speed", SPEED_RANGE),
            ("strength", STRENGTH_RANGE),
            ("fertility", FERTILITY_RANGE),
            ("max_lifespan", MAX_LIFESPAN_RANGE),
            ("max_health", MAX_HEALTH_RANGE),
        ];
        for (field, (min, max)) in cases {
            assert!(build(field, min).is_ok(), "{field} accepts min");
            assert!(build(field, max).is_ok(), "{field} accepts max");
            let below = build(field, min - 1.0).unwrap_err();
            let above = build(field, max + 1.0).unwrap_err();
            let nan = build(field, f64::NAN).unwrap_err();
            let inf = build(field, f64::INFINITY).unwrap_err();
            for err in [below, above, nan, inf] {
                match err {
                    EntityError::OutOfRange { field: name, .. } => assert_eq!(name, field),
                    other => panic!("unexpected error {other:?}"),
                }
            }
        }
    }

    #[test]
    fn tendencies_accept_bounds_and_reject_outside_values() {
        assert!(Tendencies::new(0.0, 1.0).is_ok());
        assert!(Tendencies::new(-0.01, 0.5).is_err());
        assert!(Tendencies::new(0.5, 1.01).is_err());
        assert!(Tendencies::new(f32::NAN, 0.5).is_err());
        match Tendencies::new(0.5, f32::INFINITY) {
            Err(EntityError::OutOfRange { field, .. }) => assert_eq!(field, "caution"),
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn animals_need_tendencies_and_plants_reject_them() {
        let mut e = Entities::new();
        let mut no_tend = animal(Kind::Herbivore, 10.0, 10.0);
        no_tend.tendencies = None;
        assert_eq!(
            e.spawn_founder(no_tend),
            Err(EntityError::TendencyRequired {
                kind: Kind::Herbivore
            })
        );
        let mut with_tend = plant(10.0, 10.0);
        with_tend.tendencies = Some(tendencies());
        assert_eq!(
            e.spawn_founder(with_tend),
            Err(EntityError::TendencyNotAllowed { kind: Kind::Plant })
        );
        assert_eq!(e.next_id(), 0, "rejected births allocate no id");
        assert!(e.spawn_founder(animal(Kind::Carnivore, 10.0, 10.0)).is_ok());
    }

    #[test]
    fn birth_energy_and_health_must_be_in_range() {
        let mut e = Entities::new();
        assert!(e.spawn_founder(plant(ENERGY_MAX + 0.5, 10.0)).is_err());
        assert!(e.spawn_founder(plant(-1.0, 10.0)).is_err());
        assert!(
            e.spawn_founder(plant(10.0, 51.0)).is_err(),
            "health above max_health"
        );
        assert!(e.spawn_founder(plant(f32::NAN, 10.0)).is_err());
        assert!(e.spawn_founder(plant(ENERGY_MAX, 50.0)).is_ok());
        assert!(e.spawn_founder(plant(0.0, 0.0)).is_ok());
    }

    #[test]
    fn ids_strictly_increase_and_are_never_reused_over_random_operations() {
        let mut rng = Rng::from_seed(11);
        let mut e = Entities::new();
        let mut all_ids: BTreeSet<OrganismId> = BTreeSet::new();
        let mut last: Option<OrganismId> = None;
        for op in 0..1000u64 {
            let living: Vec<OrganismId> = e.living().map(|o| o.id()).collect();
            if living.is_empty() || rng.chance(0.6) {
                let id = if living.is_empty() || rng.chance(0.5) {
                    e.spawn_founder(plant(10.0, 10.0)).unwrap()
                } else {
                    let parent = living[rng.next_below(living.len() as u64) as usize];
                    e.spawn_child(plant(10.0, 10.0), [Some(parent), None])
                        .unwrap()
                };
                assert!(last.is_none_or(|p| p < id), "ids increase");
                assert!(all_ids.insert(id), "id {} reused", id.0);
                last = Some(id);
            } else {
                let victim = living[rng.next_below(living.len() as u64) as usize];
                e.get_mut(victim).unwrap().drain_energy(1000.0);
            }
            e.deaths_phase(op);
            let ids: Vec<OrganismId> = e.living().map(|o| o.id()).collect();
            assert!(ids.windows(2).all(|w| w[0] < w[1]), "living() ascending");
        }
        assert!(all_ids.len() > 300, "enough ids were allocated");
        assert_eq!(e.next_id(), all_ids.len() as u64);
        assert_eq!(e.check_invariants(), Ok(()));
        // Every removed id is gone for good.
        let alive: BTreeSet<OrganismId> = e.living().map(|o| o.id()).collect();
        let removed: Vec<OrganismId> = all_ids.difference(&alive).copied().collect();
        assert!(!removed.is_empty(), "some organisms died");
        for id in removed {
            assert!(e.get(id).is_none(), "removed id {} is gone", id.0);
        }
    }

    #[test]
    fn energy_and_health_stay_in_range_over_random_operations() {
        let mut rng = Rng::from_seed(5);
        let mut o = single_organism(50.0, 30.0);
        let max_health = o.traits().max_health();
        for _ in 0..10_000 {
            let amount = (rng.next_f64() * 150.0) as f32;
            match rng.next_below(4) {
                0 => o.add_energy(amount),
                1 => o.drain_energy(amount),
                2 => o.damage(amount, DeathCause::Predation),
                _ => o.heal(amount),
            }
            assert!(
                (0.0..=ENERGY_MAX).contains(&o.energy()),
                "energy {}",
                o.energy()
            );
            assert!(
                (0.0..=max_health).contains(&o.health()),
                "health {}",
                o.health()
            );
        }
    }

    #[test]
    fn energy_and_health_hit_their_bounds_exactly() {
        let mut o = single_organism(50.0, 30.0);
        o.add_energy(1000.0);
        assert_eq!(o.energy(), ENERGY_MAX);
        o.heal(1000.0);
        assert_eq!(o.health(), traits().max_health());
        o.drain_energy(1000.0);
        assert_eq!(o.energy(), 0.0);
        assert!(o.energy().is_sign_positive(), "no negative zero");
        o.damage(1000.0, DeathCause::Exposure);
        assert_eq!(o.health(), 0.0);
        assert!(o.health().is_sign_positive(), "no negative zero");
    }

    #[test]
    #[cfg(debug_assertions)]
    #[should_panic(expected = "invalid amount")]
    fn negative_amount_is_a_debug_assertion() {
        let mut o = single_organism(50.0, 30.0);
        o.add_energy(-1.0);
    }

    #[test]
    #[cfg(not(debug_assertions))]
    fn invalid_amounts_are_no_ops_in_release() {
        let mut o = single_organism(50.0, 30.0);
        o.add_energy(-1.0);
        o.drain_energy(f32::NAN);
        o.heal(f32::INFINITY);
        assert_eq!(o.energy(), 50.0);
        assert_eq!(o.health(), 30.0);
    }

    #[test]
    fn energy_zero_gives_starvation() {
        let mut e = Entities::new();
        let id = e.spawn_founder(plant(5.0, 10.0)).unwrap();
        e.get_mut(id).unwrap().drain_energy(5.0);
        assert_eq!(e.get(id).unwrap().cause(), Some(DeathCause::Starvation));
        e.deaths_phase(7);
        assert!(e.get(id).is_none());
        let d = e.last_deaths()[0];
        assert_eq!(
            (d.id, d.kind, d.tick, d.cause),
            (id, Kind::Plant, 7, DeathCause::Starvation)
        );
    }

    #[test]
    fn health_zero_gives_the_damage_cause() {
        for cause in [
            DeathCause::Predation,
            DeathCause::Exposure,
            DeathCause::Injury,
        ] {
            let mut e = Entities::new();
            let id = e
                .spawn_founder(animal(Kind::Herbivore, 50.0, 10.0))
                .unwrap();
            e.get_mut(id).unwrap().damage(10.0, cause);
            e.deaths_phase(0);
            assert_eq!(e.last_deaths()[0].cause, cause);
            assert_eq!(e.deaths_by_cause(Kind::Herbivore, cause), 1);
        }
    }

    #[test]
    fn first_cause_wins() {
        let mut e = Entities::new();
        let id = e.spawn_founder(plant(5.0, 10.0)).unwrap();
        let o = e.get_mut(id).unwrap();
        o.drain_energy(5.0);
        o.damage(10.0, DeathCause::Predation);
        assert_eq!(o.cause(), Some(DeathCause::Starvation));

        let mut o = single_organism(50.0, 10.0);
        o.damage(10.0, DeathCause::Exposure);
        o.drain_energy(50.0);
        assert_eq!(o.cause(), Some(DeathCause::Exposure));
    }

    #[test]
    fn dead_organism_is_skipped_by_living_until_removed() {
        let mut e = Entities::new();
        let dead = e.spawn_founder(plant(5.0, 10.0)).unwrap();
        let alive = e.spawn_founder(plant(5.0, 10.0)).unwrap();
        e.get_mut(dead).unwrap().drain_energy(5.0);
        let ids: Vec<OrganismId> = e.living().map(|o| o.id()).collect();
        assert_eq!(ids, vec![alive]);
        assert!(e.get(dead).is_some(), "still stored until the Deaths phase");
        assert_eq!(e.living_count(Kind::Plant), 1);
        e.deaths_phase(0);
        assert!(e.get(dead).is_none());
        assert!(e.get(alive).is_some());
    }

    #[test]
    fn death_record_has_cell_kind_tick_and_cause() {
        let mut e = Entities::new();
        let id = e.spawn_founder(animal(Kind::Carnivore, 0.0, 10.0)).unwrap();
        e.deaths_phase(3);
        let d = e.last_deaths()[0];
        assert_eq!(d.id, id);
        assert_eq!(d.kind, Kind::Carnivore);
        assert_eq!(d.cell, cell());
        assert_eq!(d.tick, 3);
        assert_eq!(d.cause, DeathCause::Starvation);
    }

    #[test]
    fn old_age_at_max_lifespan_and_founder_ages_through_its_lifetime() {
        let mut e = Entities::new();
        // Trait block 3 with locus sum 2 has mean 2 / 4080. With centre 10 the lifespan is floor(5 + 10 * 2 / 4080) = 5;
        // max_health is 1.
        let genome = genome_with_slot_sum(Kind::Plant, 3, 2);
        let centres = LifespanRanges {
            plants: 10,
            herbivores: 10,
            carnivores: 10,
        };
        let b = Birth::from_genome_in(Kind::Plant, cell(), genome, 50.0, 1.0, &centres).unwrap();
        assert_eq!(b.traits.max_lifespan(), 5);
        let id = e.spawn_founder(b).unwrap();
        for t in 0..5u64 {
            // Action phases of tick t see the organism alive.
            assert!(e.living().any(|o| o.id() == id), "alive in tick {t}");
            e.deaths_phase(t);
            if t < 4 {
                assert_eq!(e.get(id).unwrap().age(), (t + 1) as u32);
            }
        }
        assert!(e.get(id).is_none());
        let d = e.last_deaths()[0];
        assert_eq!((d.tick, d.cause), (4, DeathCause::OldAge));
        assert_eq!(e.deaths_by_cause(Kind::Plant, DeathCause::OldAge), 1);
    }

    #[test]
    fn zero_energy_at_birth_is_starvation_in_the_first_deaths_phase() {
        let mut e = Entities::new();
        let id = e.spawn_founder(plant(0.0, 10.0)).unwrap();
        assert_eq!(e.get(id).unwrap().cause(), None, "no event has run yet");
        e.deaths_phase(0);
        assert_eq!(e.last_deaths()[0].cause, DeathCause::Starvation);
    }

    #[test]
    fn zero_health_at_birth_is_injury() {
        let mut e = Entities::new();
        e.spawn_founder(plant(10.0, 0.0)).unwrap();
        e.deaths_phase(0);
        assert_eq!(e.last_deaths()[0].cause, DeathCause::Injury);
    }

    #[test]
    fn bookkeeping_balances_at_every_tick_over_1000_ticks() {
        let mut rng = Rng::from_seed(77);
        let mut e = Entities::new();
        for _ in 0..20 {
            e.spawn_founder(plant(20.0, 10.0)).unwrap();
        }
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            for _ in 0..5 {
                e.spawn_founder(animal(kind, 20.0, 10.0)).unwrap();
            }
        }
        let initial: Vec<u64> = Kind::ALL.iter().map(|&k| e.initial(k)).collect();
        let mut child_count = [0u64; 3];
        for t in 0..1000u64 {
            // Reproduction: asexual plant children from a random living plant.
            let plants: Vec<OrganismId> = e
                .living()
                .filter(|o| o.kind() == Kind::Plant)
                .map(|o| o.id())
                .collect();
            if !plants.is_empty() && rng.chance(0.5) {
                let parent = plants[rng.next_below(plants.len() as u64) as usize];
                e.spawn_child(
                    plant(rng.next_f64() as f32 * 10.0, 5.0),
                    [Some(parent), None],
                )
                .unwrap();
                child_count[Kind::Plant.index()] += 1;
            }
            // Starvation of a random living organism.
            let living: Vec<OrganismId> = e.living().map(|o| o.id()).collect();
            if !living.is_empty() && rng.chance(0.4) {
                let victim = living[rng.next_below(living.len() as u64) as usize];
                e.get_mut(victim).unwrap().drain_energy(1000.0);
            }
            e.deaths_phase(t);
            assert_eq!(e.check_balance(), Ok(()), "tick {t}");
            assert_eq!(e.check_invariants(), Ok(()), "tick {t}");
        }
        for k in Kind::ALL {
            assert_eq!(e.initial(k), initial[k.index()], "founders stay in initial");
        }
        assert_eq!(e.births(Kind::Plant), child_count[0]);
        assert_eq!(e.births(Kind::Herbivore), 0);
        assert_eq!(e.births(Kind::Carnivore), 0);
        assert!(e.births(Kind::Plant) > 100, "enough births to test");
    }

    #[test]
    fn child_born_with_zero_energy_dies_in_its_birth_tick() {
        let mut e = Entities::new();
        let parent = e.spawn_founder(plant(50.0, 10.0)).unwrap();
        e.deaths_phase(0);
        let child = e
            .spawn_child(plant(0.0, 10.0), [Some(parent), None])
            .unwrap();
        assert_eq!((e.births(Kind::Plant), e.deaths(Kind::Plant)), (1, 0));
        e.deaths_phase(1);
        assert_eq!((e.births(Kind::Plant), e.deaths(Kind::Plant)), (1, 1));
        let d = e.last_deaths();
        assert_eq!(d.len(), 1);
        assert_eq!(
            (d[0].id, d[0].tick, d[0].cause),
            (child, 1, DeathCause::Starvation)
        );
        assert_eq!(e.check_balance(), Ok(()));
    }

    #[test]
    fn parent_that_reproduces_then_starves_in_the_same_tick_is_both_birth_and_death() {
        let mut e = Entities::new();
        let parent = e.spawn_founder(plant(10.0, 10.0)).unwrap();
        e.deaths_phase(0);
        // Reproduction (before Deaths): the parent is alive and names the child.
        let child = e
            .spawn_child(plant(5.0, 5.0), [Some(parent), None])
            .unwrap();
        // The parent then loses all its energy; the cause is set but it is removed in the Deaths phase of this tick.
        e.get_mut(parent).unwrap().drain_energy(10.0);
        e.deaths_phase(1);
        let ids: Vec<OrganismId> = e.last_deaths().iter().map(|d| d.id).collect();
        assert_eq!(ids, vec![parent]);
        assert!(e.get(child).is_some(), "the child lives");
        assert_eq!(e.births(Kind::Plant), 1);
        assert_eq!(e.deaths(Kind::Plant), 1);
        assert_eq!(e.check_balance(), Ok(()));
    }

    #[test]
    fn child_with_unknown_or_dead_parent_is_rejected_without_side_effects() {
        let mut e = Entities::new();
        let before = e.clone();
        assert_eq!(
            e.spawn_child(plant(5.0, 5.0), [Some(OrganismId(99)), None]),
            Err(EntityError::ParentNotAlive { id: OrganismId(99) })
        );
        assert_eq!(e, before, "a rejected spawn changes nothing");

        let dead = e.spawn_founder(plant(0.0, 5.0)).unwrap();
        e.deaths_phase(0);
        assert_eq!(
            e.spawn_child(plant(5.0, 5.0), [Some(dead), None]),
            Err(EntityError::ParentNotAlive { id: dead })
        );
        assert_eq!(e.births(Kind::Plant), 0);
    }

    #[test]
    fn parent_count_must_match_the_kind() {
        let mut e = Entities::new();
        let p = e.spawn_founder(plant(5.0, 5.0)).unwrap();
        let q = e.spawn_founder(animal(Kind::Herbivore, 5.0, 5.0)).unwrap();
        assert_eq!(
            e.spawn_child(plant(5.0, 5.0), [None, None]),
            Err(EntityError::ParentCount { kind: Kind::Plant })
        );
        assert_eq!(
            e.spawn_child(plant(5.0, 5.0), [Some(p), Some(q)]),
            Err(EntityError::ParentCount { kind: Kind::Plant })
        );
        assert_eq!(
            e.spawn_child(animal(Kind::Herbivore, 5.0, 5.0), [Some(q), None]),
            Err(EntityError::ParentCount {
                kind: Kind::Herbivore
            })
        );
        assert_eq!(
            e.spawn_child(animal(Kind::Herbivore, 5.0, 5.0), [Some(q), Some(q)]),
            Err(EntityError::ParentCount {
                kind: Kind::Herbivore
            })
        );
        assert!(e
            .spawn_child(animal(Kind::Herbivore, 5.0, 5.0), [Some(q), Some(p)])
            .is_ok());
    }

    #[test]
    fn generation_is_one_plus_the_largest_parent_generation() {
        let mut e = Entities::new();
        let a = e
            .spawn_founder(animal(Kind::Herbivore, 50.0, 10.0))
            .unwrap();
        let b = e
            .spawn_founder(animal(Kind::Herbivore, 50.0, 10.0))
            .unwrap();
        assert_eq!(e.get(a).unwrap().generation(), 0);
        let c = e
            .spawn_child(animal(Kind::Herbivore, 50.0, 10.0), [Some(a), Some(b)])
            .unwrap();
        assert_eq!(e.get(c).unwrap().generation(), 1);
        let d = e
            .spawn_child(animal(Kind::Herbivore, 50.0, 10.0), [Some(c), Some(a)])
            .unwrap();
        assert_eq!(e.get(d).unwrap().generation(), 2);
        assert_eq!(e.get(d).unwrap().parents(), [Some(c), Some(a)]);
        assert_eq!(e.get(a).unwrap().parents(), [None, None]);
    }

    #[test]
    fn stored_organisms_are_sorted_by_id_and_lookup_finds_them() {
        let mut e = Entities::new();
        let ids: Vec<OrganismId> = (0..50)
            .map(|_| e.spawn_founder(plant(5.0, 5.0)).unwrap())
            .collect();
        for id in &ids {
            assert_eq!(e.get(*id).unwrap().id(), *id);
        }
        assert!(e.get(OrganismId(50)).is_none());
        assert_eq!(e.check_invariants(), Ok(()));
    }

    #[test]
    fn check_invariants_detects_a_broken_counter() {
        let mut e = Entities::new();
        e.spawn_founder(plant(5.0, 5.0)).unwrap();
        e.deaths[Kind::Plant.index()] = 1;
        assert!(matches!(
            e.check_balance(),
            Err(EntityError::BalanceMismatch {
                kind: Kind::Plant,
                ..
            })
        ));
        // The per-cause sum is checked first, so this reports an Invariant error, not a balance error.
        assert!(matches!(
            e.check_invariants(),
            Err(EntityError::Invariant { .. })
        ));
    }

    #[test]
    fn check_invariants_detects_a_pending_cause_between_phases() {
        let mut e = Entities::new();
        let id = e.spawn_founder(plant(5.0, 5.0)).unwrap();
        e.get_mut(id).unwrap().drain_energy(5.0);
        assert!(matches!(
            e.check_invariants(),
            Err(EntityError::Invariant { .. })
        ));
    }

    #[test]
    fn traits_getters_return_validated_values() {
        let t = Traits::new(4.0, 10.0, 1.0, 10_000, 100.0).unwrap();
        assert_eq!(
            (
                t.speed(),
                t.strength(),
                t.fertility(),
                t.max_lifespan(),
                t.max_health()
            ),
            (4.0, 10.0, 1.0, 10_000, 100.0)
        );
        let tn = Tendencies::new(0.25, 0.75).unwrap();
        assert_eq!((tn.aggression(), tn.caution()), (0.25, 0.75));
    }

    #[test]
    fn traits_must_match_the_genome_at_spawn() {
        let mut e = Entities::new();
        let mut b = plant(10.0, 1.0);
        // A different max_lifespan than the genome decodes to is rejected before any state change.
        b.traits = Traits::new(0.0, 0.0, 0.0, 7, 1.0).unwrap();
        assert_eq!(
            e.spawn_founder(b.clone()),
            Err(EntityError::GenomeMismatch { kind: Kind::Plant })
        );
        assert_eq!(e.next_id(), 0);
        assert_eq!(e.initial(Kind::Plant), 0);
        // Wrong ploidy for the kind: a diploid genome for a plant.
        let mut wrong = plant(10.0, 1.0);
        wrong.genome = Genome::new(2, vec![128; 256]).unwrap();
        assert_eq!(
            e.spawn_founder(wrong),
            Err(EntityError::PloidyMismatch {
                kind: Kind::Plant,
                ploidy: 2
            })
        );
    }

    #[test]
    fn decoded_traits_stay_in_range_for_random_genomes() {
        use crate::genome::random_genome;
        let mut rng = Rng::from_seed(99);
        for i in 0..10_000u64 {
            let kind = Kind::ALL[(i % 3) as usize];
            let ploidy = if kind.is_animal() { 2 } else { 1 };
            let g = random_genome(ploidy, &mut rng).unwrap();
            let (t, tend) = decode_traits(&g, kind).unwrap();
            assert!((SPEED_RANGE.0..=SPEED_RANGE.1).contains(&f64::from(t.speed())));
            assert!((STRENGTH_RANGE.0..=STRENGTH_RANGE.1).contains(&f64::from(t.strength())));
            assert!((FERTILITY_RANGE.0..=FERTILITY_RANGE.1).contains(&f64::from(t.fertility())));
            assert!((1..=10_000).contains(&t.max_lifespan()));
            assert!((MAX_HEALTH_RANGE.0..=MAX_HEALTH_RANGE.1).contains(&f64::from(t.max_health())));
            assert_eq!(tend.is_some(), kind.is_animal());
            if let Some(tend) = tend {
                assert!((0.0..=1.0).contains(&f64::from(tend.aggression())));
                assert!((0.0..=1.0).contains(&f64::from(tend.caution())));
            }
        }
    }

    #[test]
    fn check_invariants_detects_traits_that_drift_from_the_genome() {
        let mut e = Entities::new();
        e.spawn_founder(plant(10.0, 1.0)).unwrap();
        assert_eq!(e.check_invariants(), Ok(()));
        e.organisms[0].traits = Traits::new(3.0, 0.0, 0.0, 7, 1.0).unwrap();
        assert!(matches!(
            e.check_invariants(),
            Err(EntityError::Invariant { .. })
        ));
    }
}

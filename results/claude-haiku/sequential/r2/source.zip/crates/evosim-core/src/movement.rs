//! Animal perception and movement (TASK-013, ADR-0014).
//!
//! Rules, in short:
//! - An animal perceives the organisms within its vision range ([`crate::entities::vision_radius`]) across the torus edges.
//! - Per tick it takes `floor(speed)` steps; each step goes to one of the eight neighbour cells (or towards a target,
//!   see [`step_towards`]). An animal with speed below 1 does not move.
//! - Moving costs [`move_cost`] energy per tick, growing with the distance moved and with the speed.
//! - Any number of organisms may share a cell (ADR-0014, "cell sharing"); no move is refused for occupancy.
//!
//! [`plan_moves`] only reads the world: it computes every animal's destination from the positions at the start of the
//! phase, in ascending id order. The simulation applies the moves afterwards (`Simulation::move_organism`), so no decision
//! sees a move made in the same phase. Only this module draws random numbers for movement (the wander steps).

use crate::entities::{vision_radius, Entities, Kind, Organism, OrganismId, SPEED_RANGE};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;
use crate::world::{Cell, Direction, Offset, Torus};

/// Energy per cell moved (ADR-0014). Uncalibrated; see TASK-018.
pub const MOVE_COST_CELL: f32 = 0.2;
/// Extra cost per unit of speed, as a fraction of the base cost (ADR-0014). Uncalibrated; see TASK-018.
pub const MOVE_COST_SPEED: f32 = 0.25;

/// Largest number of steps per tick: the top of the speed range.
const MAX_STEPS: u32 = SPEED_RANGE.1 as u32;

/// Steps an animal may take this tick: `floor(speed)`, clamped to the speed range. A NaN or negative speed gives 0.
pub fn steps_per_tick(speed: f32) -> u32 {
    if speed.is_nan() || speed < 0.0 {
        return 0;
    }
    (speed.floor() as u32).min(MAX_STEPS)
}

/// Energy cost of one tick of movement: `MOVE_COST_CELL * distance * (1 + MOVE_COST_SPEED * speed)`.
/// Zero for zero distance; strictly increasing in `distance` and in `speed` (for distance above 0).
pub fn move_cost(distance: u32, speed: f32) -> f32 {
    MOVE_COST_CELL * distance as f32 * (1.0 + MOVE_COST_SPEED * speed)
}

/// Where an animal is heading this tick.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Heading {
    /// Nothing of interest: a random step in one of eight directions per step.
    Wander,
    /// Towards a target cell, by the shortest way (possibly across an edge).
    Towards(Cell),
    /// Away from a threat cell (TASK-014, ADR-0015). See [`step_away`].
    Away(Cell),
}

/// Takes up to `steps` steps from `from` towards `target` by the shortest way on the torus. Each step moves
/// diagonally while both axes still differ and then straight, so the path length is the Chebyshev torus distance.
/// Returns the end cell and the number of steps taken, `min(steps, torus.distance(from, target))`. Stops at the target.
pub fn step_towards(torus: &Torus, from: Cell, target: Cell, steps: u32) -> (Cell, u32) {
    let taken = steps.min(torus.distance(from, target));
    let Offset { mut dx, mut dy } = torus.delta(from, target);
    let mut cur = from;
    for _ in 0..taken {
        let (sx, sy) = (dx.signum(), dy.signum());
        cur = torus.translate(cur, Offset { dx: sx, dy: sy });
        dx -= sx;
        dy -= sy;
    }
    (cur, taken)
}

/// Takes up to `steps` steps from `from` away from `threat` (ADR-0015). Each step moves by `-sign` of the torus offset from
/// the threat on each axis, diagonally while both axes differ, and the offset is recomputed after every step, so the
/// direction stays correct across the seams. Returns `(from, 0)` when `from` is the threat cell itself; the caller then
/// falls back to another heading. Otherwise it returns the end cell and `steps` (the animal never stops while fleeing).
pub fn step_away(torus: &Torus, from: Cell, threat: Cell, steps: u32) -> (Cell, u32) {
    if from == threat {
        return (from, 0);
    }
    let mut cur = from;
    for _ in 0..steps {
        let Offset { dx, dy } = torus.delta(threat, cur);
        let (sx, sy) = (dx.signum(), dy.signum());
        if sx == 0 && sy == 0 {
            // Only possible on the threat cell itself, which the first check excludes; stop defensively.
            break;
        }
        cur = torus.translate(cur, Offset { dx: sx, dy: sy });
    }
    (cur, steps)
}

/// Takes `steps` random steps from `from`. Each step draws one direction with `rng.next_below(8)` and indexes
/// [`Direction::ALL`]; no draw is made when `steps` is 0. Returns the end cell and the number of steps taken (= `steps`).
pub fn wander(torus: &Torus, from: Cell, steps: u32, rng: &mut Rng) -> (Cell, u32) {
    let mut cur = from;
    for _ in 0..steps {
        let i = rng.next_below(Direction::ALL.len() as u64) as usize;
        cur = torus.step(cur, Direction::ALL[i]);
    }
    (cur, steps)
}

/// Organisms within `vision` cells of `cell` across the torus, excluding `id` itself. Ids ascending, no duplicates.
pub fn perceive(
    spatial: &SpatialIndex,
    id: OrganismId,
    cell: Cell,
    vision: u32,
) -> Vec<OrganismId> {
    let mut seen = spatial.within(cell, vision, None);
    seen.retain(|&other| other != id);
    seen
}

/// Chooses the heading of an animal this tick. TASK-013 has no target choice yet (what animals do with food, prey or
/// mates is TASK-014 to TASK-016), so every animal wanders. `perceived` is passed for those later rules.
pub fn choose_heading(_kind: Kind, _perceived: &[OrganismId]) -> Heading {
    Heading::Wander
}

/// The planned move of one animal: destination, cells travelled and the speed that sets its cost.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PlannedMove {
    pub id: OrganismId,
    pub to: Cell,
    /// Steps taken this tick (cells moved, the value charged by [`move_cost`]).
    pub distance: u32,
    pub speed: f32,
}

/// Plans the moves of every living animal of `kind` for this tick, in ascending id order. Reads the positions in
/// `entities` and `spatial` as they are now (the phase start); it changes nothing. `choose` gives each animal's heading
/// from the animal and its perceived organisms (ascending ids). Random draws (wander) come from `rng` in id order.
///
/// # Panics
/// Debug builds assert that `kind` is an animal kind.
pub fn plan_moves(
    entities: &Entities,
    spatial: &SpatialIndex,
    torus: &Torus,
    kind: Kind,
    rng: &mut Rng,
    choose: impl Fn(&Organism, &[OrganismId]) -> Heading,
) -> Vec<PlannedMove> {
    debug_assert!(kind.is_animal(), "only animals move");
    let mut plans = Vec::new();
    for o in entities.living().filter(|o| o.kind() == kind) {
        let perceived = perceive(spatial, o.id(), o.cell(), vision_radius(o.genome()));
        let speed = o.traits().speed();
        let steps = steps_per_tick(speed);
        let (to, distance) = match choose(o, &perceived) {
            Heading::Wander => wander(torus, o.cell(), steps, rng),
            Heading::Towards(target) => step_towards(torus, o.cell(), target, steps),
            Heading::Away(threat) if threat != o.cell() => {
                step_away(torus, o.cell(), threat, steps)
            }
            // A threat on the animal's own cell has no direction to flee from: wander instead (ADR-0015, G-051).
            Heading::Away(_) => wander(torus, o.cell(), steps, rng),
        };
        plans.push(PlannedMove {
            id: o.id(),
            to,
            distance,
            speed,
        });
    }
    plans
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::{Birth, Entities, VISION_MAX, VISION_MIN};
    use crate::genome::{random_genome, Genome};
    use crate::world::Torus;

    fn torus(w: u32, h: u32) -> Torus {
        Torus::new(w, h).unwrap()
    }

    fn c(t: &Torus, x: u32, y: u32) -> Cell {
        t.cell(x, y).unwrap()
    }

    /// Genome of an animal whose slot 7 has every locus at `v` (0..=255) and the other slots at 128.
    fn genome_with_vision_locus(v: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + 7 * 16 + i] = v;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    #[test]
    fn steps_follow_floor_of_speed() {
        assert_eq!(steps_per_tick(0.0), 0);
        assert_eq!(steps_per_tick(0.99), 0);
        assert_eq!(steps_per_tick(1.0), 1);
        assert_eq!(steps_per_tick(3.5), 3);
        assert_eq!(steps_per_tick(4.0), 4);
        assert_eq!(steps_per_tick(-1.0), 0);
        assert_eq!(steps_per_tick(f32::NAN), 0);
        assert_eq!(steps_per_tick(9.0), 4);
    }

    #[test]
    fn move_cost_is_zero_without_distance_and_grows_with_distance_and_speed() {
        assert_eq!(move_cost(0, 0.0), 0.0);
        assert_eq!(move_cost(0, 4.0), 0.0);
        for speed in [0.0f32, 1.0, 2.5, 4.0] {
            assert!(move_cost(1, speed) > 0.0);
            assert!(move_cost(2, speed) > move_cost(1, speed));
            assert!(move_cost(3, speed) > move_cost(2, speed));
        }
        for d in [1u32, 2, 4] {
            assert!(move_cost(d, 2.0) > move_cost(d, 1.0));
            assert!(move_cost(d, 4.0) > move_cost(d, 2.0));
        }
        // Concrete value: 0.2 * 2 * (1 + 0.25 * 4) = 0.8.
        assert!((move_cost(2, 4.0) - 0.8).abs() < 1e-6);
    }

    #[test]
    fn step_towards_takes_the_short_way_across_the_west_edge() {
        let t = torus(10, 8);
        // From x=0 to x=9: one step west across the seam, not nine steps east.
        let (end, taken) = step_towards(&t, c(&t, 0, 3), c(&t, 9, 3), 5);
        assert_eq!((end, taken), (c(&t, 9, 3), 1));
    }

    #[test]
    fn step_towards_crosses_the_north_edge_diagonally() {
        let t = torus(10, 8);
        // From (1,0) to (8,7) on a 10x8 torus: dx = -3 (west, across the x=0 seam) and dy = -1 (north, across the y=0 seam).
        let from = c(&t, 1, 0);
        let target = c(&t, 8, 7);
        let d = t.delta(from, target);
        assert_eq!((d.dx, d.dy), (-3, -1));
        let (end, taken) = step_towards(&t, from, target, 10);
        assert_eq!(taken, 3);
        assert_eq!(end, target);
        // The first step is diagonal (both axes differ): (1,0) -> (0,7).
        let (first, n) = step_towards(&t, from, target, 1);
        assert_eq!((first, n), (c(&t, 0, 7), 1));
    }

    #[test]
    fn step_towards_is_diagonal_then_straight_and_stops_at_target() {
        let t = torus(20, 20);
        let (end, taken) = step_towards(&t, c(&t, 5, 5), c(&t, 8, 6), 10);
        assert_eq!(taken, 3); // Chebyshev distance max(3, 1)
        assert_eq!(end, c(&t, 8, 6));
        // Two steps from (5,5) towards (8,6): one diagonal (6,6), then east (7,6).
        let (mid, n) = step_towards(&t, c(&t, 5, 5), c(&t, 8, 6), 2);
        assert_eq!((mid, n), (c(&t, 7, 6), 2));
        // Already at the target: no steps.
        assert_eq!(
            step_towards(&t, c(&t, 3, 3), c(&t, 3, 3), 4),
            (c(&t, 3, 3), 0)
        );
    }

    #[test]
    fn step_towards_taken_steps_equal_torus_distance_everywhere_on_small_torus() {
        let t = torus(6, 5);
        for fx in 0..6 {
            for fy in 0..5 {
                for tx in 0..6 {
                    for ty in 0..5 {
                        let (from, to) = (c(&t, fx, fy), c(&t, tx, ty));
                        let (end, taken) = step_towards(&t, from, to, 100);
                        assert_eq!(taken, t.distance(from, to));
                        assert_eq!(end, to);
                    }
                }
            }
        }
    }

    #[test]
    fn step_towards_even_size_tie_is_deterministic() {
        // Width 6: from x=0 to x=3 is a tie (+3 or -3). The torus rule gives +3, so the path goes east.
        let t = torus(6, 1);
        let (end, taken) = step_towards(&t, c(&t, 0, 0), c(&t, 3, 0), 10);
        assert_eq!((end, taken), (c(&t, 3, 0), 3));
        let (once, _) = step_towards(&t, c(&t, 0, 0), c(&t, 3, 0), 1);
        assert_eq!(once, c(&t, 1, 0));
    }

    #[test]
    fn wander_lands_on_torus_cells_and_takes_exact_steps() {
        let t = torus(3, 2); // tiny torus: many steps wrap
        let mut rng = Rng::from_seed(9);
        let mut cur = c(&t, 0, 0);
        for _ in 0..500 {
            let (next, n) = wander(&t, cur, 4, &mut rng);
            assert_eq!(n, 4);
            assert_eq!(t.cell(next.x(), next.y()), Some(next));
            cur = next;
        }
    }

    #[test]
    fn wander_with_zero_steps_draws_nothing() {
        let t = torus(5, 5);
        let mut rng = Rng::from_seed(1);
        let before = rng.state();
        assert_eq!(wander(&t, c(&t, 2, 2), 0, &mut rng), (c(&t, 2, 2), 0));
        assert_eq!(rng.state(), before);
    }

    #[test]
    fn wander_is_reproducible_from_the_same_seed() {
        let t = torus(16, 9);
        let run = |seed| {
            let mut rng = Rng::from_seed(seed);
            let mut cur = c(&t, 0, 0);
            for _ in 0..200 {
                cur = wander(&t, cur, 3, &mut rng).0;
            }
            cur
        };
        assert_eq!(run(7), run(7));
    }

    #[test]
    fn vision_radius_has_the_documented_range() {
        assert_eq!(vision_radius(&genome_with_vision_locus(0)), VISION_MIN);
        assert_eq!(vision_radius(&genome_with_vision_locus(255)), VISION_MAX);
        // Mean 0.2 gives 1 + floor(5 * 0.2) = 2; mean 0.8 gives 1 + floor(4.0) = 5 (boundary at 4/5).
        assert_eq!(vision_radius(&genome_with_vision_locus(51)), 2);
        assert_eq!(vision_radius(&genome_with_vision_locus(204)), 5);
    }

    #[test]
    fn vision_radius_seeded_sweep_stays_in_range() {
        let mut rng = Rng::from_seed(77);
        for _ in 0..2000 {
            let g = random_genome(2, &mut rng).unwrap();
            let v = vision_radius(&g);
            assert!((VISION_MIN..=VISION_MAX).contains(&v), "vision {v}");
        }
    }

    #[test]
    fn perceive_across_the_west_edge_sees_the_east_column() {
        let t = torus(10, 6);
        let mut sp = SpatialIndex::new(t);
        sp.insert(OrganismId(1), c(&t, 0, 2), Kind::Herbivore)
            .unwrap();
        sp.insert(OrganismId(2), c(&t, 9, 2), Kind::Carnivore)
            .unwrap(); // across the seam
        sp.insert(OrganismId(3), c(&t, 5, 2), Kind::Plant).unwrap(); // too far at vision 1
        assert_eq!(
            perceive(&sp, OrganismId(1), c(&t, 0, 2), 1),
            vec![OrganismId(2)]
        );
        assert_eq!(
            perceive(&sp, OrganismId(1), c(&t, 0, 2), 5),
            vec![OrganismId(2), OrganismId(3)]
        );
    }

    #[test]
    fn perceive_across_the_north_edge_and_corner() {
        let t = torus(10, 6);
        let mut sp = SpatialIndex::new(t);
        sp.insert(OrganismId(1), c(&t, 0, 0), Kind::Herbivore)
            .unwrap();
        sp.insert(OrganismId(2), c(&t, 9, 5), Kind::Herbivore)
            .unwrap(); // diagonal across both seams
        assert_eq!(
            perceive(&sp, OrganismId(1), c(&t, 0, 0), 1),
            vec![OrganismId(2)]
        );
        // The self-entry is never returned.
        assert!(!perceive(&sp, OrganismId(1), c(&t, 0, 0), 5).contains(&OrganismId(1)));
    }

    #[test]
    fn perceive_on_thin_worlds_returns_each_organism_once() {
        let t = torus(1, 7);
        let mut sp = SpatialIndex::new(t);
        for y in 0..7u32 {
            sp.insert(OrganismId(u64::from(y) + 1), c(&t, 0, y), Kind::Plant)
                .unwrap();
        }
        let seen = perceive(&sp, OrganismId(1), c(&t, 0, 0), 3);
        assert_eq!(seen, (2..=7).map(OrganismId).collect::<Vec<_>>());
        let t2 = torus(7, 1);
        let mut sp2 = SpatialIndex::new(t2);
        for x in 0..7u32 {
            sp2.insert(OrganismId(u64::from(x) + 1), c(&t2, x, 0), Kind::Plant)
                .unwrap();
        }
        assert_eq!(perceive(&sp2, OrganismId(4), c(&t2, 3, 0), 20).len(), 6);
    }

    fn animal_birth(t: &Torus, x: u32, y: u32, genome: Genome) -> Birth {
        let mut b = Birth::from_genome(Kind::Herbivore, c(t, x, y), genome, 50.0, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    #[test]
    fn plan_moves_reads_start_positions_and_is_ascending() {
        let t = torus(12, 12);
        let mut ents = Entities::new();
        let mut sp = SpatialIndex::new(t);
        let mut rng = Rng::from_seed(5);
        for k in 0..6u32 {
            let g = random_genome(2, &mut rng).unwrap();
            let id = ents.spawn_founder(animal_birth(&t, k, 0, g)).unwrap();
            sp.insert(id, c(&t, k, 0), Kind::Herbivore).unwrap();
        }
        let before = rng.state();
        let plans = plan_moves(&ents, &sp, &t, Kind::Herbivore, &mut rng, |o, p| {
            choose_heading(o.kind(), p)
        });
        assert_ne!(rng.state(), before, "wander draws from the generator");
        assert_eq!(plans.len(), 6);
        assert!(plans.windows(2).all(|w| w[0].id < w[1].id));
        // Planning changes nothing: positions and index still hold the start-of-phase state.
        for o in ents.living() {
            assert_eq!(sp.position(o.id()), Some((o.cell(), Kind::Herbivore)));
        }
        for p in &plans {
            let start = ents.get(p.id).unwrap().cell();
            assert!(p.distance <= steps_per_tick(p.speed));
            assert!(t.distance(start, p.to) <= p.distance);
        }
    }

    #[test]
    fn plan_moves_only_selects_the_requested_kind() {
        let t = torus(8, 8);
        let mut ents = Entities::new();
        let mut sp = SpatialIndex::new(t);
        let mut rng = Rng::from_seed(3);
        let g = random_genome(2, &mut rng).unwrap();
        let h = ents.spawn_founder(animal_birth(&t, 1, 1, g)).unwrap();
        sp.insert(h, c(&t, 1, 1), Kind::Herbivore).unwrap();
        let gc = random_genome(2, &mut rng).unwrap();
        let mut carn = Birth::from_genome(Kind::Carnivore, c(&t, 2, 2), gc, 50.0, 0.0).unwrap();
        carn.health = carn.traits.max_health();
        let k = ents.spawn_founder(carn).unwrap();
        sp.insert(k, c(&t, 2, 2), Kind::Carnivore).unwrap();
        let plans = plan_moves(&ents, &sp, &t, Kind::Carnivore, &mut rng, |o, p| {
            choose_heading(o.kind(), p)
        });
        assert_eq!(plans.len(), 1);
        assert_eq!(plans[0].id, k);
    }

    #[test]
    fn away_from_a_threat_on_the_same_cell_wanders() {
        // G-051 (TASK-015): `Away(own cell)` must give exactly the plan of `Wander` from the same generator state.
        let t = torus(12, 12);
        let mut ents = Entities::new();
        let mut sp = SpatialIndex::new(t);
        let mut setup = Rng::from_seed(9);
        let g = random_genome(2, &mut setup).unwrap();
        let id = ents.spawn_founder(animal_birth(&t, 4, 4, g)).unwrap();
        sp.insert(id, c(&t, 4, 4), Kind::Herbivore).unwrap();

        let mut rng_away = Rng::from_seed(77);
        let away = plan_moves(&ents, &sp, &t, Kind::Herbivore, &mut rng_away, |o, _| {
            Heading::Away(o.cell())
        });
        let mut rng_wander = Rng::from_seed(77);
        let wander_plan = plan_moves(&ents, &sp, &t, Kind::Herbivore, &mut rng_wander, |_, _| {
            Heading::Wander
        });
        assert_eq!(away, wander_plan);
        assert_eq!(away.len(), 1);
        assert_eq!(away[0].distance, steps_per_tick(away[0].speed));
        assert_eq!(rng_away.state(), rng_wander.state());
    }
}

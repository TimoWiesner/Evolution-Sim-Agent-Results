//! Result model of `evosim run` (docs/CONTRACT.md section 4, ADR-0020 D2, D4, D5, D6) and the read-only sampling that feeds it.
//!
//! Sampling reads the simulation and never changes it (ADR-0008). The wall-clock fields are reported here but are
//! measured by the CLI and never enter the state. The JSON layout puts every key and every series element on its own
//! line, so that two runs can be compared after dropping the two wall-clock lines (ADR-0020 D2).

use crate::checkpoint;
use crate::entities::Kind;
use crate::sim::Simulation;

/// Per-kind values (index `Kind::index()`: plants, herbivores, carnivores).
pub type PerKind = [u64; 3];

/// Cumulative and current counts of a simulation, per kind.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct KindCounts {
    pub initial: PerKind,
    pub births: PerKind,
    pub deaths: PerKind,
    /// Living individuals.
    pub living: PerKind,
    /// Species alive after the last tick (ADR-0020 D5).
    pub species_living: PerKind,
    /// Species records ever created, extinct or not.
    pub species_recognised: PerKind,
}

/// The counts of `sim` at its current tick.
pub fn kind_counts(sim: &Simulation) -> KindCounts {
    let entities = sim.entities();
    let species = sim.species();
    let per = |f: &dyn Fn(Kind) -> u64| Kind::ALL.map(f);
    KindCounts {
        initial: per(&|k| entities.initial(k)),
        births: per(&|k| entities.births(k)),
        deaths: per(&|k| entities.deaths(k)),
        living: per(&|k| entities.living_count(k)),
        species_living: per(&|k| species.living_now(k) as u64),
        species_recognised: per(&|k| species.record_count(k) as u64),
    }
}

/// One entry of the time series: the living individuals per kind at `tick`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Sample {
    pub tick: u64,
    pub living: PerKind,
}

/// The living individuals per kind of `sim` at its current tick.
pub fn sample(sim: &Simulation) -> Sample {
    Sample {
        tick: sim.tick_count(),
        living: Kind::ALL.map(|k| sim.entities().living_count(k)),
    }
}

/// Default sample spacing for a run of `ticks` ticks: 1/100 of the run, at least 1 (CONTRACT section 2).
pub fn default_sample_every(ticks: u64) -> u64 {
    (ticks / 100).max(1)
}

/// The ticks at which the series is sampled (ADR-0020 D4): `tick_start`, then every `k` ticks while not after
/// `tick_end`, then `tick_end` if it was not already reached. Ascending, no duplicates.
///
/// Panics if `tick_end < tick_start` or `k == 0`; the CLI rejects both before a run starts.
pub fn series_ticks(tick_start: u64, tick_end: u64, k: u64) -> Vec<u64> {
    assert!(k >= 1, "sample interval must be at least 1");
    assert!(tick_end >= tick_start, "run must not end before it starts");
    let mut ticks = vec![tick_start];
    let mut next = tick_start.checked_add(k);
    while let Some(t) = next.filter(|t| *t <= tick_end) {
        ticks.push(t);
        next = t.checked_add(k);
    }
    if *ticks.last().expect("non-empty") != tick_end {
        ticks.push(tick_end);
    }
    ticks
}

/// Everything `evosim run` writes to the result file (ADR-0020 D2).
#[derive(Clone, Debug, PartialEq)]
pub struct RunResult {
    pub seed: u64,
    pub tick_start: u64,
    pub tick_end: u64,
    pub width: u32,
    pub height: u32,
    pub counts: KindCounts,
    pub series: Vec<Sample>,
    pub sample_every: u64,
    /// Lowercase hex, 64 digits (ADR-0020 D3).
    pub state_hash: String,
    pub elapsed_seconds: f64,
    pub ticks_per_second: f64,
}

/// Ticks per second: `ticks / elapsed`, or 0.0 when no time was measured (ADR-0020 D6).
pub fn ticks_per_second(ticks: u64, elapsed_seconds: f64) -> f64 {
    if elapsed_seconds > 0.0 {
        ticks as f64 / elapsed_seconds
    } else {
        0.0
    }
}

/// A JSON value with a fixed layout: objects and arrays are broken into one entry per line; series samples are inline.
pub(crate) enum Node {
    Obj(Vec<(&'static str, Node)>),
    Arr(Vec<Node>),
    /// An already formatted scalar or inline object.
    Raw(String),
}

pub(crate) fn write_node(out: &mut String, node: &Node, indent: usize) {
    match node {
        Node::Raw(text) => out.push_str(text),
        Node::Obj(entries) => write_container(
            out,
            '{',
            '}',
            entries.iter().map(|(k, v)| (Some(*k), v)),
            indent,
        ),
        Node::Arr(items) => write_container(out, '[', ']', items.iter().map(|v| (None, v)), indent),
    }
}

fn write_container<'a>(
    out: &mut String,
    open: char,
    close: char,
    items: impl Iterator<Item = (Option<&'static str>, &'a Node)>,
    indent: usize,
) {
    let items: Vec<_> = items.collect();
    if items.is_empty() {
        out.push(open);
        out.push(close);
        return;
    }
    out.push(open);
    out.push('\n');
    for (i, (key, value)) in items.iter().enumerate() {
        out.push_str(&" ".repeat(indent + 2));
        if let Some(k) = key {
            out.push('"');
            out.push_str(k);
            out.push_str("\": ");
        }
        write_node(out, value, indent + 2);
        if i + 1 < items.len() {
            out.push(',');
        }
        out.push('\n');
    }
    out.push_str(&" ".repeat(indent));
    out.push(close);
}

pub(crate) fn int(v: u64) -> Node {
    Node::Raw(v.to_string())
}

pub(crate) fn float(v: f64) -> Result<Node, String> {
    if !v.is_finite() {
        return Err(format!(
            "cannot write a non-finite number ({v}) to the result"
        ));
    }
    // Debug formatting of a finite f64 is a valid JSON number ("0.0", "238.1", "1e-7").
    Ok(Node::Raw(format!("{v:?}")))
}

fn text(v: &str) -> Node {
    debug_assert!(
        v.bytes().all(|b| b.is_ascii_alphanumeric()),
        "result strings are plain ASCII"
    );
    Node::Raw(format!("\"{v}\""))
}

fn per_kind(values: PerKind) -> Node {
    Node::Obj(vec![
        ("plants", int(values[Kind::Plant.index()])),
        ("herbivores", int(values[Kind::Herbivore.index()])),
        ("carnivores", int(values[Kind::Carnivore.index()])),
    ])
}

impl RunResult {
    /// The result JSON (CONTRACT section 4 keys in order, then the ADR-0020 D2 additions), with a final newline.
    /// Fails only if a number is not finite.
    pub fn to_json(&self) -> Result<String, String> {
        let c = &self.counts;
        let series = self
            .series
            .iter()
            .map(|s| {
                Node::Raw(format!(
                    "{{\"tick\": {}, \"plants\": {}, \"herbivores\": {}, \"carnivores\": {}}}",
                    s.tick,
                    s.living[Kind::Plant.index()],
                    s.living[Kind::Herbivore.index()],
                    s.living[Kind::Carnivore.index()],
                ))
            })
            .collect();
        let root = Node::Obj(vec![
            ("contract", int(u64::from(crate::CONTRACT_VERSION))),
            ("seed", int(self.seed)),
            ("tick_start", int(self.tick_start)),
            ("tick_end", int(self.tick_end)),
            (
                "world",
                Node::Obj(vec![
                    ("width", int(u64::from(self.width))),
                    ("height", int(u64::from(self.height))),
                ]),
            ),
            (
                "final",
                Node::Obj(vec![
                    ("plants", int(c.living[Kind::Plant.index()])),
                    ("herbivores", int(c.living[Kind::Herbivore.index()])),
                    ("carnivores", int(c.living[Kind::Carnivore.index()])),
                    ("species", per_kind(c.species_living)),
                ]),
            ),
            (
                "totals",
                Node::Obj(vec![
                    ("births", per_kind(c.births)),
                    ("deaths", per_kind(c.deaths)),
                    ("initial", per_kind(c.initial)),
                ]),
            ),
            ("series", Node::Arr(series)),
            ("state_hash", text(&self.state_hash)),
            ("elapsed_seconds", float(self.elapsed_seconds)?),
            ("ticks_per_second", float(self.ticks_per_second)?),
            ("sample_every", int(self.sample_every)),
            ("state_format", int(u64::from(checkpoint::FORMAT_VERSION))),
            ("hash_algorithm", text(checkpoint::HASH_ALGORITHM)),
            ("species_recognised", per_kind(c.species_recognised)),
        ]);
        let mut out = String::new();
        write_node(&mut out, &root, 0);
        out.push('\n');
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{json, Config};

    #[test]
    fn series_ticks_zero_ticks_is_only_the_start() {
        assert_eq!(series_ticks(0, 0, 5), vec![0]);
        assert_eq!(series_ticks(7, 7, 1), vec![7]);
    }

    #[test]
    fn series_ticks_k_larger_than_n_gives_start_and_end() {
        assert_eq!(series_ticks(0, 10, 100), vec![0, 10]);
    }

    #[test]
    fn series_ticks_k_one_samples_every_tick() {
        assert_eq!(series_ticks(0, 3, 1), vec![0, 1, 2, 3]);
    }

    #[test]
    fn series_ticks_last_tick_not_on_the_grid_is_added() {
        assert_eq!(series_ticks(0, 10, 3), vec![0, 3, 6, 9, 10]);
        assert_eq!(series_ticks(0, 9, 3), vec![0, 3, 6, 9]);
    }

    #[test]
    fn series_ticks_with_an_offset_start_is_ascending_without_duplicates() {
        assert_eq!(series_ticks(5, 12, 3), vec![5, 8, 11, 12]);
    }

    #[test]
    fn series_ticks_does_not_overflow_near_u64_max() {
        let ticks = series_ticks(u64::MAX - 5, u64::MAX, 4);
        assert_eq!(ticks, vec![u64::MAX - 5, u64::MAX - 1, u64::MAX]);
    }

    #[test]
    fn default_sample_interval_is_one_hundredth_at_least_one() {
        assert_eq!(default_sample_every(0), 1);
        assert_eq!(default_sample_every(50), 1);
        assert_eq!(default_sample_every(1000), 10);
        assert_eq!(default_sample_every(1050), 10);
    }

    #[test]
    fn ticks_per_second_is_zero_without_elapsed_time() {
        assert_eq!(ticks_per_second(0, 0.0), 0.0);
        assert_eq!(ticks_per_second(100, 0.0), 0.0);
        assert_eq!(ticks_per_second(100, 2.0), 50.0);
    }

    fn sample_result() -> RunResult {
        RunResult {
            seed: 42,
            tick_start: 0,
            tick_end: 2,
            width: 64,
            height: 48,
            counts: KindCounts {
                initial: [400, 120, 20],
                births: [9, 3, 1],
                deaths: [2, 1, 0],
                living: [407, 122, 21],
                species_living: [1, 1, 1],
                species_recognised: [1, 1, 1],
            },
            series: vec![
                Sample {
                    tick: 0,
                    living: [400, 120, 20],
                },
                Sample {
                    tick: 2,
                    living: [407, 122, 21],
                },
            ],
            sample_every: 1,
            state_hash: "ab".repeat(32),
            elapsed_seconds: 0.25,
            ticks_per_second: 8.0,
        }
    }

    #[test]
    fn to_json_is_valid_and_has_the_contract_keys() {
        let text = sample_result().to_json().unwrap();
        let value = json::parse(&text).expect("result JSON parses");
        assert!(matches!(value, json::Value::Object(_)));
        for key in [
            "\"contract\": 1",
            "\"seed\": 42",
            "\"tick_end\": 2",
            "\"state_hash\": \"",
            "\"elapsed_seconds\": 0.25",
            "\"state_format\": 1",
            "\"hash_algorithm\": \"sha256\"",
        ] {
            assert!(text.contains(key), "missing {key}");
        }
    }

    #[test]
    fn to_json_puts_each_key_and_series_element_on_its_own_line() {
        let text = sample_result().to_json().unwrap();
        let line_of = |needle: &str| text.lines().filter(|l| l.contains(needle)).count();
        assert_eq!(line_of("\"elapsed_seconds\""), 1);
        assert_eq!(line_of("\"ticks_per_second\""), 1);
        assert_eq!(line_of("{\"tick\": "), 2);
    }

    #[test]
    fn to_json_rejects_non_finite_numbers() {
        let mut r = sample_result();
        r.elapsed_seconds = f64::NAN;
        assert!(r.to_json().is_err());
    }

    #[test]
    fn totals_balance_after_1000_ticks_for_every_kind() {
        let config = Config::from_json(
            r#"{"seed": 3, "world": {"width": 32, "height": 24},
                "initial": {"plants": 200, "herbivores": 60, "carnivores": 10}}"#,
        )
        .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        sim.run(1000);
        let c = kind_counts(&sim);
        for k in 0..3 {
            assert_eq!(
                c.initial[k] + c.births[k] - c.deaths[k],
                c.living[k],
                "kind {k}"
            );
        }
        assert_eq!(sample(&sim).tick, 1000);
    }
}

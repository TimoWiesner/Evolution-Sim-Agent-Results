//! Genome: heritable DNA, copy and crossover, mutation and genetic distance (ADR-0004, TASK-009).
//!
//! Decisions are recorded in `docs/decisions/ADR-0004-genome-and-species.md` (section "Implementation notes").
//! In short:
//! - A [`Genome`] is `ploidy` haplotypes of [`LOCI_PER_HAPLOTYPE`] loci, each locus a `u8`. Plants have ploidy 1,
//!   animals ploidy 2.
//! - Each haplotype is split into [`TRAIT_SLOTS`] blocks of [`LOCI_PER_SLOT`] loci. [`Genome::trait_means`] returns the
//!   mean of each block over all haplotypes, in `[0, 1]`. The mapping from a mean to a trait range lives in
//!   `entities::decode_traits`, so this module depends only on [`Rng`].
//! - Copy (one parent) and meiosis plus crossover (two parents) build children; then [`mutate`] runs.
//! - Mutation draws only from the simulation generator. A rate of 0 draws nothing.
//!
//! No hash maps are used and every loop has a fixed order, so results depend only on the seed and the inputs.

use std::fmt;

use crate::rng::Rng;

/// Loci in one haplotype (one linkage group).
pub const LOCI_PER_HAPLOTYPE: usize = 128;
/// Loci in one trait block of one haplotype.
pub const LOCI_PER_SLOT: usize = 16;
/// Number of trait blocks per haplotype. Slot 7 is reserved for later plant-only traits.
pub const TRAIT_SLOTS: usize = 8;
/// Largest value of one locus.
pub const LOCUS_MAX: u8 = u8::MAX;

/// Errors from building genomes, mutation settings or comparisons.
#[derive(Clone, Debug, PartialEq)]
pub enum GenomeError {
    /// Ploidy must be 1 (plants) or 2 (animals).
    BadPloidy { ploidy: u8 },
    /// The number of loci does not equal `ploidy * LOCI_PER_HAPLOTYPE`.
    BadLength { ploidy: u8, length: usize },
    /// The mutation rate is not a number in `[0, 1]`.
    BadRate { rate: f64 },
    /// The mutation strength is outside `[1, 255]`.
    BadStrength { strength: u64 },
    /// Two genomes of different ploidy or length were compared or combined.
    Mismatch,
    /// Crossover needs two diploid parents.
    NotDiploid { ploidy: u8 },
}

impl fmt::Display for GenomeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            GenomeError::BadPloidy { ploidy } => write!(f, "ploidy {ploidy} is not 1 or 2"),
            GenomeError::BadLength { ploidy, length } => write!(
                f,
                "{length} loci do not match ploidy {ploidy} times {LOCI_PER_HAPLOTYPE}"
            ),
            GenomeError::BadRate { rate } => write!(f, "mutation rate {rate} is outside [0, 1]"),
            GenomeError::BadStrength { strength } => {
                write!(f, "mutation strength {strength} is outside [1, 255]")
            }
            GenomeError::Mismatch => write!(f, "genomes differ in ploidy or length"),
            GenomeError::NotDiploid { ploidy } => {
                write!(f, "crossover needs diploid parents, found ploidy {ploidy}")
            }
        }
    }
}

impl std::error::Error for GenomeError {}

/// Heritable DNA. Fields are private; [`Genome::new`] checks the length against the ploidy.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Genome {
    ploidy: u8,
    loci: Vec<u8>,
}

impl Genome {
    /// Creates a genome from its loci. The length must be `ploidy * LOCI_PER_HAPLOTYPE`.
    pub fn new(ploidy: u8, loci: Vec<u8>) -> Result<Genome, GenomeError> {
        check_ploidy(ploidy)?;
        let expected = usize::from(ploidy) * LOCI_PER_HAPLOTYPE;
        if loci.len() != expected {
            return Err(GenomeError::BadLength {
                ploidy,
                length: loci.len(),
            });
        }
        Ok(Genome { ploidy, loci })
    }

    /// Number of haplotypes (1 for plants, 2 for animals).
    pub fn ploidy(&self) -> u8 {
        self.ploidy
    }

    /// All loci, haplotype after haplotype.
    pub fn loci(&self) -> &[u8] {
        &self.loci
    }

    /// Mean of every trait block over all haplotypes, in `[0, 1]`, indexed by slot.
    /// The mean of a block is `sum / (ploidy * LOCI_PER_SLOT * 255)`, computed from an exact integer sum.
    pub fn trait_means(&self) -> [f64; TRAIT_SLOTS] {
        let mut means = [0.0; TRAIT_SLOTS];
        let count = f64::from(self.ploidy) * LOCI_PER_SLOT as f64 * f64::from(LOCUS_MAX);
        for (slot, mean) in means.iter_mut().enumerate() {
            let mut sum: u64 = 0;
            for haplotype in 0..usize::from(self.ploidy) {
                let start = haplotype * LOCI_PER_HAPLOTYPE + slot * LOCI_PER_SLOT;
                sum += self.loci[start..start + LOCI_PER_SLOT]
                    .iter()
                    .map(|&v| u64::from(v))
                    .sum::<u64>();
            }
            *mean = sum as f64 / count;
        }
        means
    }
}

fn check_ploidy(ploidy: u8) -> Result<(), GenomeError> {
    if ploidy == 1 || ploidy == 2 {
        Ok(())
    } else {
        Err(GenomeError::BadPloidy { ploidy })
    }
}

/// A random genome of the given ploidy: every locus is drawn uniformly from `0..=255` by the simulation generator.
pub fn random_genome(ploidy: u8, rng: &mut Rng) -> Result<Genome, GenomeError> {
    check_ploidy(ploidy)?;
    let loci = (0..usize::from(ploidy) * LOCI_PER_HAPLOTYPE)
        .map(|_| rng.next_below(256) as u8)
        .collect();
    Genome::new(ploidy, loci)
}

/// Mutation settings. `rate` is the chance per locus per child; `strength` is the largest step.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Mutation {
    pub rate: f64,
    pub strength: u8,
}

impl Mutation {
    /// Validates the settings: `rate` in `[0, 1]` (NaN rejected), `strength` in `[1, 255]`.
    pub fn new(rate: f64, strength: u64) -> Result<Mutation, GenomeError> {
        if !(0.0..=1.0).contains(&rate) {
            // also rejects NaN
            return Err(GenomeError::BadRate { rate });
        }
        if !(1..=255).contains(&strength) {
            return Err(GenomeError::BadStrength { strength });
        }
        Ok(Mutation {
            rate,
            strength: strength as u8,
        })
    }
}

/// Mutates loci in place. With `rate == 0` nothing is drawn. Otherwise, for each locus in index order: with
/// probability `rate` a step `1 + next_below(strength)` with a random sign is added, and the result is clamped to
/// `[0, 255]` (clamping, not wrapping, so a small mutation stays a small change).
pub fn mutate(loci: &mut [u8], mutation: Mutation, rng: &mut Rng) {
    if mutation.rate <= 0.0 {
        return;
    }
    for locus in loci.iter_mut() {
        if rng.chance(mutation.rate) {
            let step = 1 + rng.next_below(u64::from(mutation.strength)) as i32;
            let signed = if rng.next_below(2) == 0 { step } else { -step };
            *locus = (i32::from(*locus) + signed).clamp(0, i32::from(LOCUS_MAX)) as u8;
        }
    }
}

/// One parent, asexual copy (plants): the child has the parent's loci, then mutation.
pub fn copy_child(parent: &Genome, mutation: Mutation, rng: &mut Rng) -> Genome {
    let mut loci = parent.loci.clone();
    mutate(&mut loci, mutation, rng);
    Genome {
        ploidy: parent.ploidy,
        loci,
    }
}

/// Meiosis for one diploid parent: one crossover point `c` uniform in `1..=127`, then a coin chooses which haplotype
/// supplies the first segment. The gamete is `first[0..c]` followed by `second[c..128]`.
fn gamete(parent: &Genome, rng: &mut Rng) -> Vec<u8> {
    let cut = 1 + rng.next_below(LOCI_PER_HAPLOTYPE as u64 - 1) as usize;
    let (first, second) = if rng.next_below(2) == 0 {
        (
            &parent.loci[..LOCI_PER_HAPLOTYPE],
            &parent.loci[LOCI_PER_HAPLOTYPE..],
        )
    } else {
        (
            &parent.loci[LOCI_PER_HAPLOTYPE..],
            &parent.loci[..LOCI_PER_HAPLOTYPE],
        )
    };
    let mut out = Vec::with_capacity(LOCI_PER_HAPLOTYPE);
    out.extend_from_slice(&first[..cut]);
    out.extend_from_slice(&second[cut..]);
    out
}

/// Two diploid parents, sexual reproduction: mother's gamete, then father's gamete, then mutation.
/// Both parents must be diploid with the same length. Draws: mother (cut, coin), then father (cut, coin), then mutation.
pub fn crossover_child(
    mother: &Genome,
    father: &Genome,
    mutation: Mutation,
    rng: &mut Rng,
) -> Result<Genome, GenomeError> {
    for parent in [mother, father] {
        if parent.ploidy != 2 {
            return Err(GenomeError::NotDiploid {
                ploidy: parent.ploidy,
            });
        }
    }
    if mother.loci.len() != father.loci.len() {
        return Err(GenomeError::Mismatch);
    }
    let mut loci = gamete(mother, rng);
    loci.extend(gamete(father, rng));
    mutate(&mut loci, mutation, rng);
    Genome::new(2, loci)
}

/// Genetic distance `sum_i |a_i - b_i| / (len * 255)`: zero for identical genomes, symmetric, in `[0, 1]`, and
/// larger for more different genomes. Genomes of different ploidy or length are an error.
pub fn genetic_distance(a: &Genome, b: &Genome) -> Result<f64, GenomeError> {
    if a.ploidy != b.ploidy || a.loci.len() != b.loci.len() {
        return Err(GenomeError::Mismatch);
    }
    let sum: u64 = a
        .loci
        .iter()
        .zip(&b.loci)
        .map(|(&x, &y)| u64::from(x.abs_diff(y)))
        .sum();
    Ok(sum as f64 / (a.loci.len() as f64 * f64::from(LOCUS_MAX)))
}

impl Genome {
    /// Canonical encoding of the DNA: ploidy, then every locus (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Genome { ploidy, loci } = self;
        enc.u8(*ploidy);
        enc.bytes(loci);
    }

    /// Reads the ploidy and the loci and validates them with [`Genome::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Genome, crate::checkpoint::CheckpointError> {
        let ploidy = dec.u8()?;
        let loci = dec.bytes("genome loci")?.to_vec();
        Genome::new(ploidy, loci).map_err(|e| crate::checkpoint::invalid_because("genome", e))
    }
}

impl Mutation {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Mutation { rate, strength } = self;
        enc.f64(*rate);
        enc.u8(*strength);
    }

    /// Reads the rate and strength and validates them with [`Mutation::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Mutation, crate::checkpoint::CheckpointError> {
        let rate = dec.f64()?;
        let strength = u64::from(dec.u8()?);
        Mutation::new(rate, strength).map_err(|e| crate::checkpoint::invalid_because("mutation", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const NO_MUTATION: fn() -> Mutation = || Mutation::new(0.0, 8).unwrap();

    fn haploid(seed: u64) -> Genome {
        random_genome(1, &mut Rng::from_seed(seed)).unwrap()
    }

    fn diploid(seed: u64) -> Genome {
        random_genome(2, &mut Rng::from_seed(seed)).unwrap()
    }

    #[test]
    fn genome_length_must_match_ploidy() {
        assert!(Genome::new(1, vec![0; 128]).is_ok());
        assert!(Genome::new(2, vec![0; 256]).is_ok());
        assert_eq!(
            Genome::new(2, vec![0; 128]),
            Err(GenomeError::BadLength {
                ploidy: 2,
                length: 128
            })
        );
        assert_eq!(
            Genome::new(0, vec![]),
            Err(GenomeError::BadPloidy { ploidy: 0 })
        );
        assert_eq!(
            Genome::new(3, vec![0; 384]),
            Err(GenomeError::BadPloidy { ploidy: 3 })
        );
    }

    #[test]
    fn trait_means_are_exact_at_the_extremes_and_stay_in_unit_range() {
        let low = Genome::new(2, vec![0; 256]).unwrap();
        assert_eq!(low.trait_means(), [0.0; TRAIT_SLOTS]);
        let high = Genome::new(2, vec![255; 256]).unwrap();
        assert_eq!(high.trait_means(), [1.0; TRAIT_SLOTS]);
        for seed in 0..1_000 {
            for m in diploid(seed).trait_means() {
                assert!((0.0..=1.0).contains(&m));
            }
        }
    }

    #[test]
    fn trait_block_only_reads_its_own_loci() {
        // Raise only slot 3 of the first haplotype: only mean 3 changes.
        let mut loci = vec![0u8; 256];
        for locus in &mut loci[3 * LOCI_PER_SLOT..4 * LOCI_PER_SLOT] {
            *locus = 255;
        }
        let means = Genome::new(2, loci).unwrap().trait_means();
        for (slot, m) in means.iter().enumerate() {
            if slot == 3 {
                assert_eq!(*m, 255.0 * 16.0 / (2.0 * 16.0 * 255.0));
            } else {
                assert_eq!(*m, 0.0);
            }
        }
    }

    #[test]
    fn random_genome_is_seeded_and_has_the_right_shape() {
        assert_eq!(diploid(7), diploid(7));
        assert_ne!(diploid(7), diploid(8));
        assert_eq!(diploid(1).loci().len(), 256);
        assert_eq!(haploid(1).loci().len(), 128);
        assert_eq!(
            random_genome(0, &mut Rng::from_seed(1)),
            Err(GenomeError::BadPloidy { ploidy: 0 })
        );
    }

    #[test]
    fn copy_with_rate_zero_is_the_parent_and_draws_nothing() {
        let parent = haploid(3);
        let mut rng = Rng::from_seed(9);
        let before = rng.state();
        for _ in 0..1_000 {
            assert_eq!(copy_child(&parent, NO_MUTATION(), &mut rng), parent);
        }
        assert_eq!(rng.state(), before, "rate 0 must not advance the generator");
    }

    #[test]
    fn crossover_with_rate_zero_takes_only_parental_material() {
        let mother = diploid(10);
        let father = diploid(11);
        let mut rng = Rng::from_seed(12);
        let mut first_from_a = 0usize;
        let mut first_from_b = 0usize;
        for _ in 0..1_000 {
            let child = crossover_child(&mother, &father, NO_MUTATION(), &mut rng).unwrap();
            assert_eq!(child.ploidy(), 2);
            assert_eq!(child.loci().len(), 256);
            // Each child haplotype is a splice `first[..c] ++ second[c..]` of the two haplotypes of its parent,
            // with a cut point strictly inside the haplotype (both segments non-empty).
            for (half, parent) in [(0usize, &mother), (1, &father)] {
                let gam = &child.loci()[half * 128..(half + 1) * 128];
                let a = &parent.loci()[..128];
                let b = &parent.loci()[128..];
                let mut found = false;
                for c in 1..=127 {
                    if gam[..c] == a[..c] && gam[c..] == b[c..] {
                        found = true;
                        first_from_a += 1;
                        break;
                    }
                    if gam[..c] == b[..c] && gam[c..] == a[c..] {
                        found = true;
                        first_from_b += 1;
                        break;
                    }
                }
                assert!(found, "gamete must be a splice of the parent's haplotypes");
            }
        }
        assert!(
            first_from_a > 0 && first_from_b > 0,
            "both haplotypes must start gametes"
        );
    }

    #[test]
    fn crossover_rejects_haploid_parents() {
        let d = diploid(1);
        let h = haploid(1);
        let mut rng = Rng::from_seed(1);
        let m = NO_MUTATION();
        assert_eq!(
            crossover_child(&h, &d, m, &mut rng),
            Err(GenomeError::NotDiploid { ploidy: 1 })
        );
        assert_eq!(
            crossover_child(&d, &h, m, &mut rng),
            Err(GenomeError::NotDiploid { ploidy: 1 })
        );
    }

    #[test]
    fn mutation_settings_are_validated() {
        assert!(Mutation::new(0.0, 1).is_ok());
        assert!(Mutation::new(1.0, 255).is_ok());
        assert_eq!(
            Mutation::new(-0.1, 8),
            Err(GenomeError::BadRate { rate: -0.1 })
        );
        assert!(Mutation::new(1.5, 8).is_err());
        assert!(Mutation::new(f64::NAN, 8).is_err());
        assert_eq!(
            Mutation::new(0.1, 0),
            Err(GenomeError::BadStrength { strength: 0 })
        );
        assert_eq!(
            Mutation::new(0.1, 256),
            Err(GenomeError::BadStrength { strength: 256 })
        );
    }

    #[test]
    fn mutation_with_positive_rate_creates_small_differences_over_many_offspring() {
        let parent = diploid(20);
        let m = Mutation::new(0.01, 8).unwrap();
        let mut rng = Rng::from_seed(21);
        let mut differing = 0usize;
        for _ in 0..1_000 {
            let child = copy_child(&parent, m, &mut rng);
            for (c, p) in child.loci().iter().zip(parent.loci()) {
                if c != p {
                    differing += 1;
                    let d = i32::from(*c) - i32::from(*p);
                    assert!(d != 0 && d.abs() <= 8, "step {d} exceeds strength 8");
                }
            }
        }
        // 1,000 children * 256 loci * 0.01 = about 2,560 expected changes; allow a wide band.
        assert!(
            differing > 1_500 && differing < 3_500,
            "differing = {differing}"
        );
    }

    #[test]
    fn mutation_clamps_at_the_bounds_and_never_wraps() {
        // With strength 1 at rate 1, a locus at 255 becomes 254 or 255 (never a wrap to 0); a locus at 0 becomes 0 or 1.
        let one = Mutation::new(1.0, 1).unwrap();
        for seed in 0..500 {
            let mut loci = vec![255u8; 4];
            mutate(&mut loci, one, &mut Rng::from_seed(seed));
            assert!(loci.iter().all(|&v| v == 254 || v == 255), "{loci:?}");
            let mut zeros = vec![0u8; 4];
            mutate(&mut zeros, one, &mut Rng::from_seed(seed));
            assert!(zeros.iter().all(|&v| v == 0 || v == 1), "{zeros:?}");
        }
    }

    #[test]
    fn mutation_is_deterministic_for_the_same_generator_seed() {
        let parent = diploid(30);
        let m = Mutation::new(0.05, 8).unwrap();
        let a = crossover_child(&parent, &diploid(31), m, &mut Rng::from_seed(77)).unwrap();
        let b = crossover_child(&parent, &diploid(31), m, &mut Rng::from_seed(77)).unwrap();
        assert_eq!(a, b);
        let mut rng = Rng::from_seed(77);
        let before = rng.state();
        let _ = copy_child(&parent, m, &mut rng);
        assert_ne!(
            rng.state(),
            before,
            "positive rate must draw from the generator"
        );
    }

    #[test]
    fn genetic_distance_is_zero_for_identical_symmetric_and_bounded() {
        for seed in 0..1_000u64 {
            let a = diploid(seed);
            let b = diploid(seed + 5_000);
            assert_eq!(genetic_distance(&a, &a).unwrap(), 0.0);
            let ab = genetic_distance(&a, &b).unwrap();
            let ba = genetic_distance(&b, &a).unwrap();
            assert_eq!(ab, ba);
            assert!((0.0..=1.0).contains(&ab));
        }
    }

    #[test]
    fn genetic_distance_grows_with_difference() {
        let base = Genome::new(2, vec![100; 256]).unwrap();
        let mut one = base.clone();
        one.loci[0] = 110;
        let mut two = one.clone();
        two.loci[1] = 120;
        let d0 = genetic_distance(&base, &base).unwrap();
        let d1 = genetic_distance(&base, &one).unwrap();
        let d2 = genetic_distance(&base, &two).unwrap();
        assert!(d0 < d1 && d1 < d2);
        // Moving a locus further from its partner increases the distance strictly.
        let mut farther = one.clone();
        farther.loci[0] = 150;
        assert!(genetic_distance(&base, &farther).unwrap() > d1);
        assert_eq!(d1, 10.0 / (256.0 * 255.0));
    }

    #[test]
    fn genetic_distance_rejects_mismatched_genomes() {
        assert_eq!(
            genetic_distance(&haploid(1), &diploid(1)),
            Err(GenomeError::Mismatch)
        );
    }
}

//! The headless run loop shared by `evosim run` and `evosim batch` (ADR-0022 D4).
//!
//! The loop was in the CLI until TASK-021; it moved here unchanged in behaviour so that a batch run with seed `S` and
//! a run with `--seed S` on the same configuration give the same `state_hash`, `final`, `totals` and `series`. The core
//! does not touch the filesystem: the caller writes the result.

use std::time::Instant;

use crate::analytics::MetricsLog;
use crate::checkpoint;
use crate::config::Config;
use crate::metrics::{self, RunResult};
use crate::sim::Simulation;

/// What one headless run produces: the result, the metrics log when asked for (ADR-0021) and the final state when
/// asked for (`keep_state`, used by `--save`, ADR-0023 D5).
#[derive(Debug)]
pub struct RunOutput {
    pub result: RunResult,
    pub metrics: Option<MetricsLog>,
    pub state: Option<Simulation>,
}

/// Options shared by [`run`] and [`resume`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RunOptions {
    /// Spacing of the series in ticks (ADR-0020 D4).
    pub sample_every: u64,
    /// Record the metrics log (it only reads the simulation).
    pub with_metrics: bool,
    /// Return the final state in [`RunOutput::state`].
    pub keep_state: bool,
}

/// Runs `config` for exactly `ticks` ticks from its founders, sampling the series every `sample_every` ticks
/// (ADR-0020 D4) and recording the metrics log if `with_metrics` is set (it only reads the simulation).
///
/// `config.seed` is used as it is; the caller applies any `--seed` override first. `elapsed_seconds` covers the
/// simulation loop only, not the start-up. Errors are returned as text for the CLI to report (exit 2).
pub fn run(config: &Config, ticks: u64, sample_every: u64, with_metrics: bool) -> Result<RunOutput, String> {
    run_config(
        config,
        ticks,
        RunOptions {
            sample_every,
            with_metrics,
            keep_state: false,
        },
    )
}

/// [`run`] with all options, for the CLI's `--save` (the final state is returned).
pub fn run_config(config: &Config, ticks: u64, options: RunOptions) -> Result<RunOutput, String> {
    let mut sim = Simulation::new(config).map_err(|e| format!("cannot build the world: {e}"))?;
    sim.populate_initial(config)
        .map_err(|e| format!("cannot place the founders: {e}"))?;
    run_from(sim, config.seed, ticks, options)
}

/// Continues a restored checkpoint for `ticks` more ticks (ADR-0023 D5). Founders are never placed again: the state
/// carries its own organisms, initial counts and settings. `seed` and `world` in the result come from the checkpoint.
pub fn resume(checkpoint: checkpoint::Checkpoint, ticks: u64, options: RunOptions) -> Result<RunOutput, String> {
    run_from(checkpoint.sim, checkpoint.seed, ticks, options)
}

/// The tick loop shared by [`run`], [`run_config`] and [`resume`].
fn run_from(mut sim: Simulation, seed: u64, ticks: u64, options: RunOptions) -> Result<RunOutput, String> {
    let RunOptions {
        sample_every,
        with_metrics,
        keep_state,
    } = options;
    if sample_every == 0 {
        return Err("the sampling interval must be at least 1".to_string());
    }
    let tick_start = sim.tick_count();
    let tick_end = tick_start
        .checked_add(ticks)
        .ok_or_else(|| format!("--ticks {ticks} runs past the largest tick number"))?;

    let targets = metrics::series_ticks(tick_start, tick_end, sample_every);
    let mut series = vec![metrics::sample(&sim)];
    let mut log = with_metrics.then(MetricsLog::new);
    if let Some(log) = log.as_mut() {
        log.record(&sim);
    }
    let started = Instant::now();
    for &target in &targets[1..] {
        sim.run(target - sim.tick_count());
        series.push(metrics::sample(&sim));
        if let Some(log) = log.as_mut() {
            log.record(&sim);
        }
    }
    let elapsed_seconds = started.elapsed().as_secs_f64();
    debug_assert_eq!(sim.tick_count(), tick_end);

    let topology = sim.world().topology;
    let result = RunResult {
        seed,
        tick_start,
        tick_end,
        width: topology.width(),
        height: topology.height(),
        counts: metrics::kind_counts(&sim),
        series,
        sample_every,
        state_hash: checkpoint::state_hash(&sim),
        elapsed_seconds,
        ticks_per_second: metrics::ticks_per_second(ticks, elapsed_seconds),
    };
    let state = keep_state.then_some(sim);
    Ok(RunOutput {
        result,
        metrics: log,
        state,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn config(seed: u64) -> Config {
        Config::from_json(&format!(
            r#"{{"seed": {seed}, "world": {{"width": 8, "height": 6}},
                "initial": {{"plants": 20, "herbivores": 5, "carnivores": 2}}}}"#
        ))
        .unwrap()
    }

    #[test]
    fn metrics_recording_does_not_change_the_run() {
        let plain = run(&config(5), 40, 4, false).unwrap();
        let with = run(&config(5), 40, 4, true).unwrap();
        assert!(plain.metrics.is_none());
        assert!(with.metrics.is_some());
        assert_eq!(plain.result.state_hash, with.result.state_hash);
        assert_eq!(plain.result.series, with.result.series);
        assert_eq!(plain.result.counts, with.result.counts);
    }

    #[test]
    fn ticks_and_series_follow_contract_section_four() {
        let out = run(&config(5), 10, 4, false).unwrap().result;
        assert_eq!(out.tick_start, 0);
        assert_eq!(out.tick_end, 10);
        let ticks: Vec<u64> = out.series.iter().map(|s| s.tick).collect();
        assert_eq!(ticks, vec![0, 4, 8, 10]);
        assert_eq!(out.seed, 5);
    }

    #[test]
    fn zero_ticks_gives_one_sample_at_tick_zero() {
        let out = run(&config(5), 0, 1, false).unwrap().result;
        assert_eq!(out.tick_end, 0);
        assert_eq!(out.series.len(), 1);
        assert_eq!(out.series[0].tick, 0);
    }

    #[test]
    fn same_seed_gives_same_hash_and_other_seed_does_not() {
        let a = run(&config(9), 30, 10, false).unwrap().result.state_hash;
        let b = run(&config(9), 30, 10, false).unwrap().result.state_hash;
        let c = run(&config(10), 30, 10, false).unwrap().result.state_hash;
        assert_eq!(a, b);
        assert_ne!(a, c);
    }

    /// Weather on (ADR-0010), so that the weather nodes and the generator take part in the state.
    fn weather_config(seed: u64) -> Config {
        Config::from_json(&format!(
            r#"{{"seed": {seed}, "world": {{"width": 16, "height": 12}},
                "initial": {{"plants": 60, "herbivores": 12, "carnivores": 4}},
                "climate": {{"season_length": 40, "weather_amplitude": 0.5}}}}"#
        ))
        .unwrap()
    }

    fn save_at(config: &Config, split: u64) -> checkpoint::Checkpoint {
        let out = run_config(
            config,
            split,
            RunOptions {
                sample_every: 1,
                with_metrics: false,
                keep_state: true,
            },
        )
        .unwrap();
        let file = checkpoint::write_file(&out.state.unwrap(), config.seed);
        checkpoint::read_file(&file).unwrap()
    }

    #[test]
    fn split_run_equals_uninterrupted_run() {
        // ADR-0023 D6 / CONTRACT 5.2: save at A ticks, resume for B more, same final, totals and state_hash.
        let c = weather_config(42);
        let total = 300;
        let reference = run(&c, total, 50, false).unwrap().result;
        for split in [0u64, 1, 37, 150, 299] {
            let restored = save_at(&c, split);
            assert_eq!(restored.sim.tick_count(), split);
            let options = RunOptions {
                sample_every: 50,
                with_metrics: false,
                keep_state: false,
            };
            let resumed = resume(restored, total - split, options).unwrap().result;
            assert_eq!(resumed.state_hash, reference.state_hash, "split {split}");
            assert_eq!(resumed.counts, reference.counts, "split {split}");
            assert_eq!((resumed.tick_start, resumed.tick_end), (split, total));
            assert_eq!(resumed.seed, c.seed);
            assert_eq!(resumed.series.last(), reference.series.last(), "split {split}");
        }
    }

    #[test]
    fn split_states_match_the_uninterrupted_run_at_every_later_tick() {
        // Catches a divergence that would be hidden at the final tick.
        let c = weather_config(7);
        let mut reference = Simulation::new(&c).unwrap();
        reference.populate_initial(&c).unwrap();
        let mut hashes = vec![checkpoint::state_hash(&reference)];
        for _ in 0..120 {
            reference.run(1);
            hashes.push(checkpoint::state_hash(&reference));
        }
        for split in [0u64, 37, 90] {
            let mut resumed = save_at(&c, split).sim;
            assert_eq!(checkpoint::state_hash(&resumed), hashes[split as usize]);
            for tick in split + 1..=120 {
                resumed.run(1);
                assert_eq!(checkpoint::state_hash(&resumed), hashes[tick as usize], "split {split}, tick {tick}");
            }
        }
    }

    #[test]
    fn resume_never_populates_founders() {
        // A restored state keeps its own organisms; the initial counts are the ones of tick 0, not added again.
        let c = weather_config(5);
        let restored = save_at(&c, 20);
        let before = metrics::kind_counts(&restored.sim).living;
        let out = resume(
            restored,
            0,
            RunOptions {
                sample_every: 1,
                with_metrics: false,
                keep_state: false,
            },
        )
        .unwrap()
        .result;
        assert_eq!(out.counts.living, before);
        assert_eq!(out.counts.initial, [60, 12, 4]);
    }
}

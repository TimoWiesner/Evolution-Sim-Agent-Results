//! Animal sexual reproduction (TASK-016, ADR-0017).
//!
//! A herbivore or carnivore mates with the nearest compatible animal of its own kind within [`MATE_RANGE`] cells.
//! Both must be alive, mature, have enough energy for their kind, and not be cooling down. The child's genome is a
//! crossover of both parents plus mutation. Both parents pay energy, and then wait [`MATE_COOLDOWN`] ticks of age.
//! No rule reads a global count: every condition is per animal, per partner, or per cell.

use std::fmt;

use crate::config::Config;
use crate::entities::{Birth, Entities, EntityError, Kind, LifespanRanges, Organism, OrganismId};
use crate::genome::{crossover_child, genetic_distance, GenomeError, Mutation};
use crate::rng::Rng;
use crate::sim::mutation_settings;
use crate::spatial::{SpatialError, SpatialIndex};

/// Partner search radius in cells (Chebyshev distance on the torus).
pub const MATE_RANGE: u32 = 2;
/// Largest genetic distance a mating pair may have (mating barrier, ADR-0017).
pub const COMPAT_MAX: f64 = 0.40;
/// Maturity age is `max(1, floor(MATURITY_FRACTION * max_lifespan))`.
pub const MATURITY_FRACTION: f64 = 0.20;
/// Chance per tick per eligible animal with a partner, before the fertility scaling.
pub const MATE_CHANCE: f64 = 0.20;
/// Ticks of age after a mating during which a parent cannot mate again.
pub const MATE_COOLDOWN: u32 = 20;
/// Energy each child starts with.
pub const CHILD_ENDOWMENT: f32 = 20.0;
/// Energy each parent loses per mating beyond its share of the children's endowment (an energy sink).
pub const MATE_OVERHEAD: f32 = 5.0;
/// Largest litter.
pub const LITTER_MAX: usize = 2;
/// Child health as a fraction of its own `max_health`.
pub const CHILD_HEALTH_FRACTION: f32 = 0.5;

/// Error when mating settings are invalid or a mating step cannot be applied.
#[derive(Clone, Debug, PartialEq)]
pub enum MatingError {
    /// An energy threshold is not a finite number that is at least 0.
    BadThreshold { kind: Kind, value: f64 },
    /// The mutation settings are invalid.
    Genome(GenomeError),
    /// An organism could not be created or updated.
    Entity(EntityError),
    /// The neighbour index rejected a change.
    Spatial(SpatialError),
}

impl fmt::Display for MatingError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MatingError::BadThreshold { kind, value } => write!(
                f,
                "reproduction energy {value} for {kind:?} is not a finite number >= 0"
            ),
            MatingError::Genome(e) => write!(f, "{e}"),
            MatingError::Entity(e) => write!(f, "{e}"),
            MatingError::Spatial(e) => write!(f, "{e}"),
        }
    }
}

impl std::error::Error for MatingError {}

impl From<GenomeError> for MatingError {
    fn from(e: GenomeError) -> Self {
        MatingError::Genome(e)
    }
}

impl From<EntityError> for MatingError {
    fn from(e: EntityError) -> Self {
        MatingError::Entity(e)
    }
}

impl From<SpatialError> for MatingError {
    fn from(e: SpatialError) -> Self {
        MatingError::Spatial(e)
    }
}

/// Settings of the mating phase: mutation, and the energy an animal needs to start a mating, per kind.
/// Built from the configuration; saved by the checkpoint (TASK-022).
#[derive(Clone, Debug, PartialEq)]
pub struct MatingSettings {
    pub mutation: Mutation,
    /// `[herbivore, carnivore]` energy needed to start a mating (`reproduction_energy` of the configuration).
    pub threshold: [f32; 2],
}

impl MatingSettings {
    /// Reads `genetics.*` and the two `reproduction_energy` keys.
    pub fn from_config(config: &Config) -> Result<MatingSettings, MatingError> {
        let herb = threshold(Kind::Herbivore, config.herbivores.reproduction_energy)?;
        let carn = threshold(Kind::Carnivore, config.carnivores.reproduction_energy)?;
        Ok(MatingSettings {
            mutation: mutation_settings(config)?,
            threshold: [herb, carn],
        })
    }

    /// Energy an animal of `kind` needs to start a mating.
    /// Plants never mate, so their threshold is infinite.
    pub fn threshold_for(&self, kind: Kind) -> f32 {
        match kind {
            Kind::Herbivore => self.threshold[0],
            Kind::Carnivore => self.threshold[1],
            Kind::Plant => f32::INFINITY,
        }
    }
}

fn threshold(kind: Kind, value: f64) -> Result<f32, MatingError> {
    if value.is_finite() && value >= 0.0 {
        Ok(value as f32)
    } else {
        Err(MatingError::BadThreshold { kind, value })
    }
}

/// Maturity age of an organism with this maximum lifespan: `max(1, floor(0.20 × max_lifespan))`.
/// At least 1, so a newborn (age 0) is never mature.
pub fn maturity_age(max_lifespan: u32) -> u32 {
    ((f64::from(max_lifespan) * MATURITY_FRACTION).floor() as u32).max(1)
}

/// Chance that an eligible pair mates this tick: `MATE_CHANCE × 2 × mean fertility`, clamped to `[0, 1]`.
/// Fertility 0 gives 0, fertility 0.5 gives [`MATE_CHANCE`], fertility 1 gives `2 × MATE_CHANCE`.
pub fn mating_chance(fertility_mean: f64) -> f64 {
    (MATE_CHANCE * 2.0 * fertility_mean).clamp(0.0, 1.0)
}

/// Litter size: 1 child, or 2 when the fertility draw succeeded (`LITTER_MAX`).
pub fn litter_size(second_child: bool) -> usize {
    1 + usize::from(second_child)
}

/// Energy one parent pays for a mating with this litter: its share of the children's endowment plus the overhead.
pub fn parent_cost(litter: usize) -> f32 {
    litter as f32 * CHILD_ENDOWMENT / 2.0 + MATE_OVERHEAD
}

/// True when an animal may start or join a mating: alive, an animal, mature, out of cooldown, and with at least
/// `threshold` energy (the surplus rule). Dead organisms are never ready.
pub fn is_mate_ready(o: &Organism, threshold: f32) -> bool {
    o.is_alive()
        && o.kind().is_animal()
        && o.age() >= maturity_age(o.traits().max_lifespan())
        && o.age() >= o.next_mate_age()
        && o.energy() >= threshold
}

/// True when two genomes are close enough to mate: `genetic_distance <= COMPAT_MAX`.
pub fn compatible(a: &Organism, b: &Organism) -> Result<bool, GenomeError> {
    Ok(genetic_distance(a.genome(), b.genome())? <= COMPAT_MAX)
}

/// Chooses the partner of `initiator` among the animals of its kind within [`MATE_RANGE`]: the nearest mate-ready,
/// compatible one by torus distance. Ties go to the lowest id, since `within` lists ids in ascending order. The
/// initiator itself is never chosen. Draws nothing.
pub fn choose_partner(
    entities: &Entities,
    spatial: &SpatialIndex,
    settings: &MatingSettings,
    initiator: OrganismId,
) -> Result<Option<OrganismId>, MatingError> {
    let Some(me) = entities.get(initiator) else {
        return Ok(None);
    };
    let kind = me.kind();
    let torus = spatial.torus();
    let mut best: Option<(u32, OrganismId)> = None;
    for id in spatial.within(me.cell(), MATE_RANGE, Some(kind)) {
        if id == initiator {
            continue;
        }
        let Some(other) = entities.get(id) else {
            continue;
        };
        if !is_mate_ready(other, settings.threshold_for(kind)) || !compatible(me, other)? {
            continue;
        }
        let d = torus.distance(me.cell(), other.cell());
        if best.is_none_or(|(bd, _)| d < bd) {
            best = Some((d, id));
        }
    }
    Ok(best.map(|(_, id)| id))
}

/// Counts of one Mating phase. Integers, so tests can compare them exactly.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct MatingReport {
    /// Initiators that found a partner.
    pub pairs_found: u64,
    /// Pairs whose chance draw failed.
    pub draws_failed: u64,
    /// Matings that produced children.
    pub litters: u64,
    /// Children born.
    pub children: u64,
}

/// The Mating phase (ADR-0017 procedure). Runs in the Reproduction arm after plant seeding, with the simulation
/// generator. Initiators are the living animals at phase start, in ascending id order. Each initiator is checked again
/// against the current state, so an earlier mating in this phase can make it ineligible.
pub fn mating_phase(
    entities: &mut Entities,
    spatial: &mut SpatialIndex,
    settings: &MatingSettings,
    lifespans: &LifespanRanges,
    rng: &mut Rng,
) -> Result<MatingReport, MatingError> {
    let mut report = MatingReport::default();
    let initiators: Vec<OrganismId> = entities
        .living()
        .filter(|o| o.kind().is_animal())
        .map(|o| o.id())
        .collect();
    for id in initiators {
        let Some(me) = entities.get(id) else {
            continue;
        };
        if !is_mate_ready(me, settings.threshold_for(me.kind())) {
            continue;
        }
        let Some(partner) = choose_partner(entities, spatial, settings, id)? else {
            continue;
        };
        report.pairs_found += 1;
        let kind = me.kind();
        let cell = me.cell();
        let my_age = me.age();
        let (mother_id, father_id) = if id < partner {
            (id, partner)
        } else {
            (partner, id)
        };
        let fertility_mean = {
            let a = f64::from(me.traits().fertility());
            let b = f64::from(
                entities
                    .get(partner)
                    .map_or(0.0, |p| p.traits().fertility()),
            );
            (a + b) / 2.0
        };
        if !rng.chance(mating_chance(fertility_mean)) {
            report.draws_failed += 1;
            continue;
        }
        let litter = litter_size(rng.chance(fertility_mean));
        let cost = parent_cost(litter);
        let mut children = Vec::with_capacity(litter);
        {
            let mother = entities.get(mother_id).expect("partner was just checked");
            let father = entities.get(father_id).expect("partner was just checked");
            for _ in 0..litter {
                let genome =
                    crossover_child(mother.genome(), father.genome(), settings.mutation, rng)?;
                let max_health = mother.traits().max_health();
                children.push(Birth::from_genome_in(
                    kind,
                    cell,
                    genome,
                    CHILD_ENDOWMENT,
                    CHILD_HEALTH_FRACTION * max_health,
                    lifespans,
                )?);
            }
        }
        for parent in [mother_id, father_id] {
            if let Some(o) = entities.get_mut(parent) {
                o.drain_energy(cost);
            }
        }
        for birth in children {
            let child = entities.spawn_child(birth, [Some(mother_id), Some(father_id)])?;
            spatial.insert(child, cell, kind)?;
            report.children += 1;
        }
        let cooldown_until = my_age + MATE_COOLDOWN;
        entities.set_next_mate_age(mother_id, cooldown_until)?;
        entities.set_next_mate_age(father_id, cooldown_until)?;
        report.litters += 1;
    }
    Ok(report)
}

impl MatingSettings {
    /// Canonical encoding of the animal mating settings (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let MatingSettings {
            mutation,
            threshold,
        } = self;
        mutation.encode_state(enc);
        for t in threshold {
            enc.f32(*t);
        }
    }

    /// Reads the mating settings (ADR-0023 D3). The fields are public, so no constructor check applies beyond the
    /// mutation's own.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<MatingSettings, crate::checkpoint::CheckpointError> {
        let mutation = crate::genome::Mutation::decode_state(dec)?;
        let threshold = [dec.f32()?, dec.f32()?];
        Ok(MatingSettings {
            mutation,
            threshold,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::{decode_traits, Birth, DeathCause};
    use crate::genome::Genome;
    use crate::rng::Rng;
    use crate::world::{Cell, Torus};

    fn settings() -> MatingSettings {
        MatingSettings {
            mutation: Mutation::new(0.0, 1).unwrap(),
            threshold: [60.0, 90.0],
        }
    }

    /// A diploid genome with every locus `base`, except the max-lifespan slot (slot 3) which is `life`. A small
    /// `life` gives a short lifespan (locus 3 gives about 119 ticks), so maturity and ageing stay cheap in tests.
    fn genome(base: u8, life: u8) -> Genome {
        let mut loci = vec![base; 256];
        for h in 0..2 {
            for i in 3 * 16..4 * 16 {
                loci[h * 128 + i] = life;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    /// Like [`genome`], with the fertility slot (2) set to `fert`.
    fn genome_f(base: u8, fert: u8, life: u8) -> Genome {
        let mut loci = vec![base; 256];
        for h in 0..2 {
            for i in 2 * 16..3 * 16 {
                loci[h * 128 + i] = fert;
            }
            for i in 3 * 16..4 * 16 {
                loci[h * 128 + i] = life;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn cell(w: u32, h: u32, x: u32, y: u32) -> Cell {
        Torus::new(w, h).unwrap().cell(x, y).unwrap()
    }

    /// Adds a founder animal (energy as given, age 0).
    fn add(
        e: &mut Entities,
        sp: &mut SpatialIndex,
        kind: Kind,
        c: Cell,
        g: Genome,
        energy: f32,
    ) -> OrganismId {
        let (traits, tendencies) = decode_traits(&g, kind).unwrap();
        let birth = Birth {
            kind,
            cell: c,
            traits,
            tendencies,
            energy,
            health: traits.max_health(),
            genome: g,
        };
        let id = e.spawn_founder(birth).unwrap();
        sp.insert(id, c, kind).unwrap();
        id
    }

    /// Ages every living organism by `n` ticks without changing energy (only ages and old-age deaths).
    fn age_all(e: &mut Entities, n: u32) {
        for _ in 0..n {
            e.deaths_phase(0);
        }
    }

    fn world(w: u32, h: u32) -> (Entities, SpatialIndex) {
        (
            Entities::new(),
            SpatialIndex::new(Torus::new(w, h).unwrap()),
        )
    }

    #[test]
    fn constants_match_adr_0017() {
        assert_eq!(MATE_RANGE, 2);
        assert_eq!(COMPAT_MAX, 0.40);
        assert_eq!(MATURITY_FRACTION, 0.20);
        assert_eq!(MATE_CHANCE, 0.20);
        assert_eq!(MATE_COOLDOWN, 20);
        assert_eq!(CHILD_ENDOWMENT, 20.0);
        assert_eq!(MATE_OVERHEAD, 5.0);
        assert_eq!(LITTER_MAX, 2);
        assert_eq!(CHILD_HEALTH_FRACTION, 0.5);
    }

    #[test]
    fn maturity_is_twenty_percent_of_lifespan_and_at_least_one() {
        assert_eq!(maturity_age(300), 60);
        assert_eq!(maturity_age(400), 80);
        assert_eq!(maturity_age(7), 1);
        assert_eq!(maturity_age(1), 1);
        assert_eq!(maturity_age(4), 1);
        assert_eq!(maturity_age(5), 1);
        assert_eq!(maturity_age(10), 2);
    }

    #[test]
    fn chance_scales_with_fertility_and_is_clamped() {
        assert_eq!(mating_chance(0.0), 0.0);
        assert!((mating_chance(0.5) - MATE_CHANCE).abs() < 1e-12);
        assert!((mating_chance(1.0) - 0.4).abs() < 1e-12);
        assert_eq!(mating_chance(3.0), 1.0);
    }

    #[test]
    fn litter_is_one_or_two_and_costs_match_the_formula() {
        assert_eq!(litter_size(false), 1);
        assert_eq!(litter_size(true), 2);
        assert_eq!(parent_cost(1), 15.0);
        assert_eq!(parent_cost(2), 25.0);
    }

    #[test]
    fn settings_read_thresholds_and_reject_bad_values() {
        let mut c = Config::new(
            1,
            8,
            8,
            crate::config::Initial {
                plants: 0,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let s = MatingSettings::from_config(&c).unwrap();
        assert_eq!(s.threshold, [60.0, 90.0]);
        assert_eq!(s.threshold_for(Kind::Herbivore), 60.0);
        assert_eq!(s.threshold_for(Kind::Carnivore), 90.0);
        assert_eq!(s.threshold_for(Kind::Plant), f32::INFINITY);
        c.herbivores.reproduction_energy = -1.0;
        assert!(matches!(
            MatingSettings::from_config(&c),
            Err(MatingError::BadThreshold {
                kind: Kind::Herbivore,
                ..
            })
        ));
        c.herbivores.reproduction_energy = f64::NAN;
        assert!(MatingSettings::from_config(&c).is_err());
    }

    #[test]
    fn readiness_requires_maturity_energy_cooldown_and_life() {
        let (mut e, mut sp) = world(8, 8);
        let c = cell(8, 8, 1, 1);
        let id = add(&mut e, &mut sp, Kind::Herbivore, c, genome(128, 3), 70.0);
        let maturity = maturity_age(e.get(id).unwrap().traits().max_lifespan());
        assert!((2..119).contains(&maturity), "maturity {maturity}");
        // Immature: age 0.
        assert!(!is_mate_ready(e.get(id).unwrap(), 60.0));
        age_all(&mut e, maturity);
        let o = e.get(id).unwrap();
        assert!(is_mate_ready(o, 60.0), "mature, 70 energy, no cooldown");
        // Energy below threshold.
        assert!(!is_mate_ready(o, 70.5));
        // Cooldown in force until the stored age.
        e.set_next_mate_age(id, maturity + 1).unwrap();
        assert!(!is_mate_ready(e.get(id).unwrap(), 60.0));
        e.set_next_mate_age(id, maturity).unwrap();
        assert!(is_mate_ready(e.get(id).unwrap(), 60.0));
        // Dead: never ready.
        e.get_mut(id).unwrap().damage(1000.0, DeathCause::Predation);
        assert!(!is_mate_ready(e.get(id).unwrap(), 60.0));
    }

    #[test]
    fn set_next_mate_age_refuses_unknown_and_dead_ids() {
        let (mut e, mut sp) = world(8, 8);
        let id = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 0, 0),
            genome(128, 3),
            70.0,
        );
        assert!(e.set_next_mate_age(OrganismId(999), 5).is_err());
        e.get_mut(id).unwrap().damage(1000.0, DeathCause::Predation);
        e.deaths_phase(0);
        assert!(e.set_next_mate_age(id, 5).is_err());
    }

    #[test]
    fn plants_are_never_ready() {
        let (mut e, mut sp) = world(8, 8);
        let g = Genome::new(1, vec![128; 128]).unwrap();
        let id = add(&mut e, &mut sp, Kind::Plant, cell(8, 8, 1, 1), g, 90.0);
        assert!(!is_mate_ready(e.get(id).unwrap(), 0.0));
    }

    #[test]
    fn compatibility_uses_the_distance_barrier() {
        let (mut e, mut sp) = world(8, 8);
        let c = cell(8, 8, 1, 1);
        let a = add(&mut e, &mut sp, Kind::Herbivore, c, genome(128, 3), 70.0);
        let same = add(&mut e, &mut sp, Kind::Herbivore, c, genome(128, 3), 70.0);
        // Differs from `a` in 224 loci by 127 each: distance about 0.44 > 0.40.
        let other = add(&mut e, &mut sp, Kind::Herbivore, c, genome(255, 3), 70.0);
        assert!(compatible(e.get(a).unwrap(), e.get(same).unwrap()).unwrap());
        assert!(!compatible(e.get(a).unwrap(), e.get(other).unwrap()).unwrap());
    }

    #[test]
    fn partner_choice_skips_self_other_kinds_and_non_mates() {
        let (mut e, mut sp) = world(8, 8);
        let c = cell(8, 8, 3, 3);
        let s = settings();
        let me = add(&mut e, &mut sp, Kind::Herbivore, c, genome(128, 3), 70.0);
        // A carnivore and an immature herbivore in the same cell: neither is a partner.
        let _carn = add(
            &mut e,
            &mut sp,
            Kind::Carnivore,
            c,
            genome_f(128, 255, 3),
            95.0,
        );
        let _young = add(&mut e, &mut sp, Kind::Herbivore, c, genome(128, 3), 70.0);
        age_all(&mut e, 0);
        assert_eq!(choose_partner(&e, &sp, &s, me).unwrap(), None);
    }

    #[test]
    fn partner_across_the_seam_is_found() {
        let (mut e, mut sp) = world(8, 8);
        let s = settings();
        // Only partner is at x = 7; the initiator is at x = 0. Torus distance 1 across the seam.
        let me = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 0, 4),
            genome(128, 3),
            70.0,
        );
        let across = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 7, 4),
            genome(128, 3),
            70.0,
        );
        let m_age = maturity_age(e.get(me).unwrap().traits().max_lifespan());
        age_all(&mut e, m_age);
        assert_eq!(choose_partner(&e, &sp, &s, me).unwrap(), Some(across));
    }

    #[test]
    fn nearest_partner_wins_and_ties_go_to_the_lowest_id() {
        let s = settings();
        // Nearest: partners at distance 2 (id lower) and distance 1 (id higher) -> the distance-1 one.
        let (mut e, mut sp) = world(8, 8);
        let me = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 4, 4),
            genome(128, 3),
            70.0,
        );
        let far = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 6, 4),
            genome(128, 3),
            70.0,
        );
        let near = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 5, 4),
            genome(128, 3),
            70.0,
        );
        let m_age = maturity_age(e.get(me).unwrap().traits().max_lifespan());
        age_all(&mut e, m_age);
        assert_eq!(choose_partner(&e, &sp, &s, me).unwrap(), Some(near));
        assert_ne!(far, near);
        // Tie: partners at distance 1 on both sides; the lower id wins.
        let (mut e2, mut sp2) = world(8, 8);
        let m = add(
            &mut e2,
            &mut sp2,
            Kind::Herbivore,
            cell(8, 8, 4, 4),
            genome(128, 3),
            70.0,
        );
        let left = add(
            &mut e2,
            &mut sp2,
            Kind::Herbivore,
            cell(8, 8, 3, 4),
            genome(128, 3),
            70.0,
        );
        let _right = add(
            &mut e2,
            &mut sp2,
            Kind::Herbivore,
            cell(8, 8, 5, 4),
            genome(128, 3),
            70.0,
        );
        let m_age = maturity_age(e2.get(m).unwrap().traits().max_lifespan());
        age_all(&mut e2, m_age);
        assert_eq!(choose_partner(&e2, &sp2, &s, m).unwrap(), Some(left));
    }

    #[test]
    fn partner_outside_range_or_incompatible_is_not_chosen() {
        let (mut e, mut sp) = world(16, 16);
        let s = settings();
        let me = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(16, 16, 2, 2),
            genome(128, 3),
            70.0,
        );
        let _outside = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(16, 16, 9, 2),
            genome(128, 3),
            70.0,
        );
        let _incompatible = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(16, 16, 3, 2),
            genome(255, 3),
            70.0,
        );
        let m_age = maturity_age(e.get(me).unwrap().traits().max_lifespan());
        age_all(&mut e, m_age);
        assert_eq!(choose_partner(&e, &sp, &s, me).unwrap(), None);
    }

    /// Two adjacent mature herbivores (energy 100, full fertility) in a world; returns (entities, index, ids).
    fn pair_world(seed_energy: f32) -> (Entities, SpatialIndex, OrganismId, OrganismId) {
        let (mut e, mut sp) = world(8, 8);
        let a = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 3, 3),
            genome_f(128, 255, 3),
            seed_energy,
        );
        let b = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 4, 3),
            genome_f(128, 255, 3),
            seed_energy,
        );
        let m_age = maturity_age(e.get(a).unwrap().traits().max_lifespan());
        age_all(&mut e, m_age);
        (e, sp, a, b)
    }

    /// Runs the mating phase on the pair with generator seed `seed` until a litter is born; None if no litter.
    fn first_litter(seed: u64) -> Option<(Entities, SpatialIndex, MatingReport)> {
        let (mut e, mut sp, _, _) = pair_world(100.0);
        let mut rng = Rng::from_seed(seed);
        let r = mating_phase(
            &mut e,
            &mut sp,
            &settings(),
            &crate::entities::LifespanRanges::default(),
            &mut rng,
        )
        .unwrap();
        (r.litters == 1).then_some((e, sp, r))
    }

    #[test]
    fn mating_pays_both_parents_exactly_and_children_record_parents_and_generation() {
        let (e, sp, r) = (0..200)
            .find_map(first_litter)
            .expect("some seed gives a litter at full fertility");
        let litter = r.children as usize;
        assert!(litter == 1 || litter == 2);
        let cost = parent_cost(litter);
        assert_eq!(e.get(OrganismId(0)).unwrap().energy(), 100.0 - cost);
        assert_eq!(e.get(OrganismId(1)).unwrap().energy(), 100.0 - cost);
        // Children: energy 20, generation 1, parents are the two founders (mother = lower id = 0).
        for id in 2..2 + litter as u64 {
            let c = e.get(OrganismId(id)).unwrap();
            assert_eq!(c.energy(), CHILD_ENDOWMENT);
            assert_eq!(c.generation(), 1);
            assert_eq!(c.parents(), [Some(OrganismId(0)), Some(OrganismId(1))]);
            assert_eq!(c.cell(), e.get(OrganismId(0)).unwrap().cell());
            assert_eq!(sp.position(c.id()).map(|p| p.1), Some(Kind::Herbivore));
        }
        // Energy: the sink is exactly 2 × MATE_OVERHEAD.
        let total_before = 200.0;
        let total_after: f32 = e.living().map(|o| o.energy()).sum();
        assert!((total_before - 2.0 * MATE_OVERHEAD - total_after).abs() < 1e-4);
        assert_eq!(e.births(Kind::Herbivore), litter as u64);
        assert_eq!(e.check_balance(), Ok(()));
    }

    #[test]
    fn parents_wait_out_the_cooldown_and_are_not_mate_ready_meanwhile() {
        let (mut e, mut sp, a, b) = pair_world(100.0);
        let s = settings();
        let r = (0..200)
            .find_map(|seed| {
                let (mut e2, mut sp2, a2, b2) = pair_world(100.0);
                let mut rng = Rng::from_seed(seed);
                let r = mating_phase(
                    &mut e2,
                    &mut sp2,
                    &s,
                    &crate::entities::LifespanRanges::default(),
                    &mut rng,
                )
                .unwrap();
                (r.litters == 1).then(|| {
                    e = e2;
                    sp = sp2;
                    (r, a2, b2)
                })
            })
            .map(|(r, _, _)| r);
        assert!(r.is_some());
        let cooldown = e.get(a).unwrap().next_mate_age();
        let age = e.get(a).unwrap().age();
        assert_eq!(cooldown, age + MATE_COOLDOWN);
        assert_eq!(e.get(b).unwrap().next_mate_age(), cooldown);
        assert!(!is_mate_ready(e.get(a).unwrap(), 60.0));
        // Without ageing, a second phase call gives no new litter from these parents.
        let mut rng = Rng::from_seed(7);
        let again = mating_phase(
            &mut e,
            &mut sp,
            &s,
            &crate::entities::LifespanRanges::default(),
            &mut rng,
        )
        .unwrap();
        assert_eq!(again.litters, 0);
        // After the waiting time they may be ready again (energy and maturity permitting).
        age_all(&mut e, MATE_COOLDOWN);
        assert!(is_mate_ready(e.get(a).unwrap(), 60.0) || e.get(a).unwrap().energy() < 60.0);
    }

    #[test]
    fn zero_fertility_never_mates() {
        for seed in 0..200 {
            let (mut e, mut sp, _, _) = {
                let (mut e, mut sp) = world(8, 8);
                let a = add(
                    &mut e,
                    &mut sp,
                    Kind::Herbivore,
                    cell(8, 8, 3, 3),
                    genome_f(128, 0, 3),
                    100.0,
                );
                let b = add(
                    &mut e,
                    &mut sp,
                    Kind::Herbivore,
                    cell(8, 8, 4, 3),
                    genome_f(128, 0, 3),
                    100.0,
                );
                let m_age = maturity_age(e.get(a).unwrap().traits().max_lifespan());
                age_all(&mut e, m_age);
                (e, sp, a, b)
            };
            let mut rng = Rng::from_seed(seed);
            let r = mating_phase(
                &mut e,
                &mut sp,
                &settings(),
                &crate::entities::LifespanRanges::default(),
                &mut rng,
            )
            .unwrap();
            assert_eq!(r.litters, 0);
            assert_eq!(r.draws_failed, r.pairs_found);
        }
    }

    #[test]
    fn no_partner_means_no_draw() {
        let (mut e, mut sp) = world(8, 8);
        let a = add(
            &mut e,
            &mut sp,
            Kind::Herbivore,
            cell(8, 8, 3, 3),
            genome_f(128, 255, 3),
            100.0,
        );
        let m_age = maturity_age(e.get(a).unwrap().traits().max_lifespan());
        age_all(&mut e, m_age);
        let mut rng = Rng::from_seed(3);
        let before = rng.state();
        let r = mating_phase(
            &mut e,
            &mut sp,
            &settings(),
            &crate::entities::LifespanRanges::default(),
            &mut rng,
        )
        .unwrap();
        assert_eq!(r, MatingReport::default());
        assert_eq!(rng.state(), before);
    }
}

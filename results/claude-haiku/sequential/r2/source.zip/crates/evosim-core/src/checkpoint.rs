//! Canonical binary encoding of the complete simulation state, and `state_hash` (ADR-0020 D3).
//!
//! The encoding is little-endian; integers have fixed width; `f32`/`f64` are written by their bit patterns; vectors and
//! strings have a `u64` length prefix; enums are one-byte tags. Each module encodes its own state in an
//! `encode_state(&self, &mut Encoder)` method that destructures its struct without `..`, so a new field that is not
//! encoded is a compile error. The layout is versioned by [`FORMAT_VERSION`]; any change of the encoding must bump it.
//!
//! The derived caches (spatial index, climate cell values) and the optional trace are not encoded.

use crate::sha256;
use crate::sim::Simulation;

/// Magic bytes at the start of every encoding.
pub const MAGIC: &[u8; 8] = b"EVOSIMST";

/// Version of the canonical encoding (ADR-0020 D3). Reported as `state_format` in the result JSON.
pub const FORMAT_VERSION: u32 = 1;

/// Name of the digest algorithm written to the result JSON as `hash_algorithm`.
pub const HASH_ALGORITHM: &str = "sha256";

/// Appends the canonical encoding of state values to a byte buffer.
#[derive(Debug, Default)]
pub struct Encoder {
    buf: Vec<u8>,
}

impl Encoder {
    pub fn new() -> Encoder {
        Encoder { buf: Vec::new() }
    }

    /// The bytes written so far.
    pub fn into_bytes(self) -> Vec<u8> {
        self.buf
    }

    pub fn u8(&mut self, v: u8) {
        self.buf.push(v);
    }

    pub fn bool(&mut self, v: bool) {
        self.u8(u8::from(v));
    }

    pub fn u32(&mut self, v: u32) {
        self.buf.extend_from_slice(&v.to_le_bytes());
    }

    pub fn u64(&mut self, v: u64) {
        self.buf.extend_from_slice(&v.to_le_bytes());
    }

    /// Writes the bit pattern, so that `-0.0` and `0.0` (and NaN payloads) are distinct.
    pub fn f32(&mut self, v: f32) {
        self.u32(v.to_bits());
    }

    /// Writes the bit pattern (see [`Encoder::f32`]).
    pub fn f64(&mut self, v: f64) {
        self.u64(v.to_bits());
    }

    /// A length prefix: a count of items or bytes.
    pub fn count(&mut self, n: usize) {
        self.u64(n as u64);
    }

    /// A length-prefixed byte string.
    pub fn bytes(&mut self, v: &[u8]) {
        self.count(v.len());
        self.buf.extend_from_slice(v);
    }

    /// A length-prefixed UTF-8 string.
    pub fn str(&mut self, v: &str) {
        self.bytes(v.as_bytes());
    }

    /// An optional `u64`: a presence byte, then the value when present.
    pub fn opt_u64(&mut self, v: Option<u64>) {
        match v {
            None => self.u8(0),
            Some(x) => {
                self.u8(1);
                self.u64(x);
            }
        }
    }
}

/// The canonical encoding of the complete state of `sim` (magic, format version, then the state).
pub fn encode_state(sim: &Simulation) -> Vec<u8> {
    let mut enc = Encoder::new();
    enc.buf.extend_from_slice(MAGIC);
    enc.u32(FORMAT_VERSION);
    sim.encode_state(&mut enc);
    enc.into_bytes()
}

/// `state_hash`: lowercase hex SHA-256 of [`encode_state`] (64 digits).
pub fn state_hash(sim: &Simulation) -> String {
    sha256::hex(&sha256::digest(&encode_state(sim)))
}

/// Magic bytes of a checkpoint file (ADR-0023 D1).
pub const FILE_MAGIC: &[u8; 8] = b"EVOSIMCK";

/// Version of the checkpoint file container (ADR-0023 D1). Readers of other versions refuse the file.
pub const FILE_VERSION: u32 = 1;

/// Bytes before the body: magic, file version, seed, body length.
const FILE_HEADER_LEN: usize = 28;

/// Bytes after the body: the SHA-256 digest of everything before it.
const DIGEST_LEN: usize = 32;

/// Why a checkpoint cannot be read (ADR-0023 D2). Every variant is an input error: exit status 2, no result file.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CheckpointError {
    /// The file or a field ends before its declared length.
    Truncated { len: usize },
    /// The file does not start with the checkpoint magic, or the body is not a state encoding.
    NotACheckpoint,
    /// The container version is not one this build reads.
    UnsupportedVersion { found: u32, expected: u32 },
    /// The state format version inside the body is not one this build reads.
    UnsupportedStateVersion { found: u32, expected: u32 },
    /// The file is longer or shorter than its header declares.
    LengthMismatch { expected: u128, found: usize },
    /// The digest trailer does not match the file contents.
    DigestMismatch,
    /// Bytes are left over after the state has been decoded.
    Trailing { extra: usize },
    /// The decoded state does not encode back to the same bytes.
    NotCanonical,
    /// A field has a value that the state does not allow.
    Invalid { what: String },
    /// The organisms do not match the neighbour index rebuilt from them.
    Spatial { message: String },
}

impl std::fmt::Display for CheckpointError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CheckpointError::Truncated { len } => {
                write!(f, "checkpoint is truncated ({len} bytes)")
            }
            CheckpointError::NotACheckpoint => write!(f, "file is not an evosim checkpoint"),
            CheckpointError::UnsupportedVersion { found, expected } => write!(
                f,
                "checkpoint file version {found} is not supported (this build reads version {expected})"
            ),
            CheckpointError::UnsupportedStateVersion { found, expected } => write!(
                f,
                "checkpoint state format {found} is not supported (this build reads format {expected})"
            ),
            CheckpointError::LengthMismatch { expected, found } => write!(
                f,
                "checkpoint length is {found} bytes but its header declares {expected}"
            ),
            CheckpointError::DigestMismatch => {
                write!(f, "checkpoint digest does not match (the file is damaged)")
            }
            CheckpointError::Trailing { extra } => {
                write!(f, "checkpoint has {extra} unexpected trailing bytes")
            }
            CheckpointError::NotCanonical => {
                write!(f, "checkpoint state does not re-encode to the same bytes")
            }
            CheckpointError::Invalid { what } => write!(f, "invalid checkpoint: {what}"),
            CheckpointError::Spatial { message } => {
                write!(f, "checkpoint neighbour index check failed: {message}")
            }
        }
    }
}

impl std::error::Error for CheckpointError {}

/// Shorthand for an [`CheckpointError::Invalid`] that names the field.
pub(crate) fn invalid(what: &str) -> CheckpointError {
    CheckpointError::Invalid {
        what: what.to_string(),
    }
}

/// [`CheckpointError::Invalid`] that also keeps the reason reported by a constructor.
pub(crate) fn invalid_because<E: std::fmt::Debug>(what: &str, reason: E) -> CheckpointError {
    CheckpointError::Invalid {
        what: format!("{what}: {reason:?}"),
    }
}

/// Reads the canonical encoding back (the inverse of [`Encoder`]). Every read is bounds-checked: a read past the end
/// is [`CheckpointError::Truncated`], and no length prefix is trusted beyond the bytes that remain (ADR-0023 D3).
#[derive(Debug)]
pub(crate) struct Decoder<'a> {
    buf: &'a [u8],
    pos: usize,
}

impl<'a> Decoder<'a> {
    pub(crate) fn new(buf: &'a [u8]) -> Decoder<'a> {
        Decoder { buf, pos: 0 }
    }

    /// Bytes not read yet.
    pub(crate) fn remaining(&self) -> usize {
        self.buf.len() - self.pos
    }

    pub(crate) fn take(&mut self, n: usize) -> Result<&'a [u8], CheckpointError> {
        if n > self.remaining() {
            return Err(CheckpointError::Truncated {
                len: self.buf.len(),
            });
        }
        let bytes = &self.buf[self.pos..self.pos + n];
        self.pos += n;
        Ok(bytes)
    }

    fn array<const N: usize>(&mut self) -> Result<[u8; N], CheckpointError> {
        let mut out = [0u8; N];
        out.copy_from_slice(self.take(N)?);
        Ok(out)
    }

    pub(crate) fn u8(&mut self) -> Result<u8, CheckpointError> {
        Ok(self.array::<1>()?[0])
    }

    pub(crate) fn bool(&mut self, what: &str) -> Result<bool, CheckpointError> {
        match self.u8()? {
            0 => Ok(false),
            1 => Ok(true),
            _ => Err(invalid(what)),
        }
    }

    pub(crate) fn u32(&mut self) -> Result<u32, CheckpointError> {
        Ok(u32::from_le_bytes(self.array()?))
    }

    pub(crate) fn u64(&mut self) -> Result<u64, CheckpointError> {
        Ok(u64::from_le_bytes(self.array()?))
    }

    pub(crate) fn f32(&mut self) -> Result<f32, CheckpointError> {
        Ok(f32::from_bits(self.u32()?))
    }

    pub(crate) fn f64(&mut self) -> Result<f64, CheckpointError> {
        Ok(f64::from_bits(self.u64()?))
    }

    /// A length prefix. It must not exceed the bytes that remain: every item takes at least one byte.
    pub(crate) fn count(&mut self, what: &str) -> Result<usize, CheckpointError> {
        let n = self.u64()?;
        if n > self.remaining() as u64 {
            return Err(invalid(what));
        }
        Ok(n as usize)
    }

    /// A length-prefixed byte string.
    pub(crate) fn bytes(&mut self, what: &str) -> Result<&'a [u8], CheckpointError> {
        let n = self.count(what)?;
        self.take(n)
    }

    /// A length-prefixed UTF-8 string.
    pub(crate) fn str(&mut self, what: &str) -> Result<String, CheckpointError> {
        let bytes = self.bytes(what)?;
        String::from_utf8(bytes.to_vec()).map_err(|_| invalid(what))
    }

    /// An optional `u64`: the presence byte must be 0 or 1.
    pub(crate) fn opt_u64(&mut self, what: &str) -> Result<Option<u64>, CheckpointError> {
        match self.u8()? {
            0 => Ok(None),
            1 => Ok(Some(self.u64()?)),
            _ => Err(invalid(what)),
        }
    }

    /// Succeeds only when every byte has been read.
    pub(crate) fn finish(self) -> Result<(), CheckpointError> {
        match self.remaining() {
            0 => Ok(()),
            extra => Err(CheckpointError::Trailing { extra }),
        }
    }
}

/// A checkpoint read from a file: the seed of the run that created it and the restored state.
#[derive(Debug)]
pub struct Checkpoint {
    pub seed: u64,
    pub sim: Simulation,
}

/// The checkpoint file of `sim` (ADR-0023 D1): magic, file version, seed, body length, the canonical body
/// ([`encode_state`]) and a SHA-256 trailer over everything before it.
pub fn write_file(sim: &Simulation, seed: u64) -> Vec<u8> {
    let body = encode_state(sim);
    let mut out = Vec::with_capacity(FILE_HEADER_LEN + body.len() + DIGEST_LEN);
    out.extend_from_slice(FILE_MAGIC);
    out.extend_from_slice(&FILE_VERSION.to_le_bytes());
    out.extend_from_slice(&seed.to_le_bytes());
    out.extend_from_slice(&(body.len() as u64).to_le_bytes());
    out.extend_from_slice(&body);
    let digest = sha256::digest(&out);
    out.extend_from_slice(&digest);
    out
}

/// Restores a checkpoint from file bytes, checking them in the order of ADR-0023 D2. Nothing is returned unless every
/// check passes.
pub fn read_file(bytes: &[u8]) -> Result<Checkpoint, CheckpointError> {
    let len = bytes.len();
    if len < FILE_HEADER_LEN + DIGEST_LEN {
        return Err(CheckpointError::Truncated { len });
    }
    let mut header = Decoder::new(bytes);
    if header.take(8)? != FILE_MAGIC {
        return Err(CheckpointError::NotACheckpoint);
    }
    let found = header.u32()?;
    if found != FILE_VERSION {
        return Err(CheckpointError::UnsupportedVersion {
            found,
            expected: FILE_VERSION,
        });
    }
    let seed = header.u64()?;
    let body_len = header.u64()?;
    let expected = (FILE_HEADER_LEN + DIGEST_LEN) as u128 + u128::from(body_len);
    if (len as u128) < expected {
        return Err(CheckpointError::Truncated { len });
    }
    if (len as u128) != expected {
        return Err(CheckpointError::LengthMismatch {
            expected,
            found: len,
        });
    }
    let (signed, digest) = bytes.split_at(len - DIGEST_LEN);
    if sha256::digest(signed).as_slice() != digest {
        return Err(CheckpointError::DigestMismatch);
    }
    let sim = decode_body(&signed[FILE_HEADER_LEN..])?;
    Ok(Checkpoint { seed, sim })
}

/// Decodes a state body (the bytes of [`encode_state`]) and checks that it is canonical and consistent.
fn decode_body(body: &[u8]) -> Result<Simulation, CheckpointError> {
    let mut dec = Decoder::new(body);
    if dec.take(8)? != MAGIC {
        return Err(CheckpointError::NotACheckpoint);
    }
    let found = dec.u32()?;
    if found != FORMAT_VERSION {
        return Err(CheckpointError::UnsupportedStateVersion {
            found,
            expected: FORMAT_VERSION,
        });
    }
    let sim = Simulation::decode_state(&mut dec)?;
    dec.finish()?;
    if encode_state(&sim) != body {
        return Err(CheckpointError::NotCanonical);
    }
    sim.check_spatial()
        .map_err(|e| CheckpointError::Spatial {
            message: format!("{e:?}"),
        })?;
    Ok(sim)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn encoder_writes_little_endian_fixed_width_values() {
        let mut e = Encoder::new();
        e.u8(0xAB);
        e.u32(0x0102_0304);
        e.u64(1);
        e.bool(true);
        e.f32(1.0);
        e.opt_u64(None);
        e.opt_u64(Some(7));
        e.str("ab");
        let b = e.into_bytes();
        assert_eq!(b[0], 0xAB);
        assert_eq!(&b[1..5], &[4, 3, 2, 1]);
        assert_eq!(&b[5..13], &[1, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(b[13], 1);
        assert_eq!(&b[14..18], &1.0f32.to_bits().to_le_bytes());
        assert_eq!(b[18], 0);
        assert_eq!(b[19], 1);
        assert_eq!(&b[20..28], &7u64.to_le_bytes());
        assert_eq!(&b[28..36], &2u64.to_le_bytes());
        assert_eq!(&b[36..], b"ab");
    }

    #[test]
    fn floats_are_distinguished_by_bit_pattern() {
        let mut a = Encoder::new();
        a.f64(0.0);
        let mut b = Encoder::new();
        b.f64(-0.0);
        assert_ne!(a.into_bytes(), b.into_bytes());
    }

    use crate::climate::{Climate, ClimateParams};
    use crate::config::Config;
    use crate::ecology::ResourceField;
    use crate::entities::{Birth, Entities, Kind, LifespanRanges};
    use crate::genome::Genome;
    use crate::reproduction::SeedingSettings;
    use crate::sim::{Simulation, World};
    use crate::species::SpeciesRegistry;
    use crate::world::Torus;

    fn config(seed: u64) -> Config {
        Config::from_json(&format!(
            r#"{{"seed": {seed}, "world": {{"width": 12, "height": 10}},
                "initial": {{"plants": 30, "herbivores": 6, "carnivores": 3}}}}"#
        ))
        .unwrap()
    }

    fn populated(seed: u64, ticks: u64) -> Simulation {
        let c = config(seed);
        let mut sim = Simulation::new(&c).unwrap();
        sim.populate_initial(&c).unwrap();
        sim.run(ticks);
        sim
    }

    fn hash(sim: &Simulation) -> String {
        state_hash(sim)
    }

    /// Rebuilds a simulation from clones of its parts, with one part replaced by the caller.
    fn with_parts(sim: &Simulation, change: impl FnOnce(&mut Parts)) -> Simulation {
        let mut p = Parts {
            tick: sim.tick_count(),
            rng: sim.rng_state(),
            world: sim.world().clone(),
            entities: sim.entities().clone(),
            seeding: sim.seeding().clone(),
            mating: sim.mating().clone(),
            species: sim.species().clone(),
            lifespans: *sim.lifespans(),
        };
        change(&mut p);
        Simulation::from_parts(
            p.tick,
            p.rng,
            p.world,
            p.entities,
            p.seeding,
            p.mating,
            p.species,
            p.lifespans,
        )
        .unwrap()
    }

    struct Parts {
        tick: u64,
        rng: [u64; 4],
        world: World,
        entities: Entities,
        seeding: SeedingSettings,
        mating: crate::mating::MatingSettings,
        species: SpeciesRegistry,
        lifespans: LifespanRanges,
    }

    #[test]
    fn encoding_starts_with_magic_and_format_version() {
        let bytes = encode_state(&populated(1, 0));
        assert_eq!(&bytes[..8], MAGIC);
        assert_eq!(&bytes[8..12], &FORMAT_VERSION.to_le_bytes());
        assert_eq!(hash(&populated(1, 0)).len(), 64);
    }

    #[test]
    fn equal_states_hash_equal() {
        let a = populated(4, 30);
        let b = populated(4, 30);
        assert_eq!(a, b);
        assert_eq!(encode_state(&a), encode_state(&b));
        assert_eq!(hash(&a), hash(&b));
    }

    #[test]
    fn hash_changes_after_a_tick() {
        let mut sim = populated(2, 10);
        let before = hash(&sim);
        sim.tick();
        assert_ne!(before, hash(&sim));
    }

    #[test]
    fn different_seeds_hash_differently() {
        assert_ne!(hash(&populated(1, 0)), hash(&populated(2, 0)));
    }

    #[test]
    fn rng_word_change_changes_the_hash() {
        let base = populated(3, 5);
        let mut changed = base.clone();
        changed.rng_mut().next_u64();
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn tick_counter_change_changes_the_hash() {
        let base = populated(3, 5);
        let changed = with_parts(&base, |p| p.tick += 1);
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn organism_energy_bit_change_changes_the_hash() {
        let base = populated(5, 5);
        let id = base.entities().living().next().unwrap().id();
        let mut changed = base.clone();
        changed
            .entities_mut()
            .get_mut(id)
            .unwrap()
            .add_energy(0.001);
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn genome_locus_change_changes_the_hash() {
        let c = config(6);
        let cell = Torus::new(12, 10).unwrap().cell(1, 1).unwrap();
        let loci: Vec<u8> = vec![100; 256];
        let mut other = loci.clone();
        other[200] = 101;
        let make = |loci: Vec<u8>| {
            let mut sim = Simulation::new(&c).unwrap();
            let genome = Genome::new(2, loci).unwrap();
            let birth = Birth::from_genome(Kind::Herbivore, cell, genome, 50.0, 1.0).unwrap();
            sim.add_founder(birth).unwrap();
            sim
        };
        assert_ne!(hash(&make(loci)), hash(&make(other)));
    }

    #[test]
    fn species_record_change_changes_the_hash() {
        let base = populated(7, 5);
        let changed = with_parts(&base, |p| {
            // No living organisms in an empty store: every recorded species is marked extinct at this tick.
            p.species.update_extinction(&Entities::new(), p.tick);
        });
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn settings_changes_change_the_hash() {
        let base = populated(8, 0);
        let seeding = with_parts(&base, |p| {
            p.seeding = SeedingSettings::new(0.5, p.seeding.radius, p.seeding.mutation).unwrap();
        });
        let mating = with_parts(&base, |p| p.mating.threshold[0] += 1.0);
        let lifespans = with_parts(&base, |p| p.lifespans.plants += 1);
        assert_ne!(hash(&base), hash(&seeding));
        assert_ne!(hash(&base), hash(&mating));
        assert_ne!(hash(&base), hash(&lifespans));
    }

    #[test]
    fn resource_value_change_changes_the_hash() {
        let base = populated(9, 0);
        let changed = with_parts(&base, |p| {
            let mut values = p.world.resources.values().to_vec();
            values[0] = if values[0] > 0.0 {
                values[0] - 1.0
            } else {
                1.0
            };
            p.world.resources = ResourceField::from_values(&p.world.topology, values).unwrap();
        });
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn weather_node_and_climate_parameter_changes_change_the_hash() {
        let base = populated(10, 0);
        let node = with_parts(&base, |p| {
            let c = &p.world.climate;
            let mut nodes = c.nodes().to_vec();
            nodes[0] = 0.5;
            p.world.climate = Climate::from_parts(
                c.torus(),
                c.terms().to_vec(),
                c.params(),
                nodes,
                c.weather_tick(),
            )
            .unwrap();
        });
        let season = with_parts(&base, |p| {
            let c = &p.world.climate;
            let params = ClimateParams {
                season_length: c.params().season_length + 1,
                ..c.params()
            };
            p.world.climate = Climate::from_parts(
                c.torus(),
                c.terms().to_vec(),
                params,
                c.nodes().to_vec(),
                c.weather_tick(),
            )
            .unwrap();
        });
        assert_ne!(hash(&base), hash(&node));
        assert_ne!(hash(&base), hash(&season));
    }

    #[test]
    fn next_id_change_changes_the_hash() {
        // Adding a founder advances the never-reused id counter and adds an organism.
        let base = populated(11, 0);
        let mut changed = base.clone();
        let cell = Torus::new(12, 10).unwrap().cell(0, 0).unwrap();
        let birth = Birth::from_genome(
            Kind::Plant,
            cell,
            Genome::new(1, vec![7; 128]).unwrap(),
            50.0,
            1.0,
        )
        .unwrap();
        changed.add_founder(birth).unwrap();
        assert_ne!(hash(&base), hash(&changed));
    }

    #[test]
    fn derived_cache_is_recomputed_from_parts() {
        // The climate cells are not encoded; a climate rebuilt from its encoded parts must have the same conditions in
        // every cell, and a simulation rebuilt from its parts must hash equal.
        let sim = populated(12, 40);
        let c = sim.world().climate.clone();
        let rebuilt = Climate::from_parts(
            c.torus(),
            c.terms().to_vec(),
            c.params(),
            c.nodes().to_vec(),
            c.weather_tick(),
        )
        .unwrap();
        let torus = c.torus();
        for i in 0..torus.cell_count() {
            let cell = torus.cell_from_index(i).unwrap();
            assert_eq!(c.conditions(cell), rebuilt.conditions(cell), "cell {i}");
        }
        let same = with_parts(&sim, |_| {});
        assert_eq!(hash(&sim), hash(&same));
        assert_eq!(same.check_spatial(), Ok(()));
    }

    /// Recomputes the trailer of a container after its header or body was edited on purpose.
    fn reseal(mut bytes: Vec<u8>) -> Vec<u8> {
        let n = bytes.len() - DIGEST_LEN;
        let digest = sha256::digest(&bytes[..n]);
        bytes[n..].copy_from_slice(&digest);
        bytes
    }

    mod file {
        use super::*;
        use crate::runner::{self, RunOptions};

        /// Weather on, so that the weather nodes and the RNG are both part of the state.
        fn config(seed: u64) -> Config {
            Config::from_json(&format!(
                r#"{{"seed": {seed}, "world": {{"width": 16, "height": 12}},
                    "initial": {{"plants": 60, "herbivores": 12, "carnivores": 4}},
                    "climate": {{"season_length": 40, "weather_amplitude": 0.5}}}}"#
            ))
            .unwrap()
        }

        fn founders(config: &Config) -> Simulation {
            let mut sim = Simulation::new(config).unwrap();
            sim.populate_initial(config).unwrap();
            sim
        }

        fn small_file() -> Vec<u8> {
            let c = config(3);
            let mut sim = founders(&c);
            sim.run(2);
            write_file(&sim, c.seed)
        }

        #[test]
        fn decoder_primitives_reject_truncation_bad_tags_and_bad_utf8() {
            let mut e = Encoder::new();
            e.u8(7);
            e.str("ok");
            e.opt_u64(Some(5));
            e.bool(true);
            let bytes = e.into_bytes();
            let mut d = Decoder::new(&bytes);
            assert_eq!(d.u8(), Ok(7));
            assert_eq!(d.str("name").unwrap(), "ok");
            assert_eq!(d.opt_u64("x"), Ok(Some(5)));
            assert_eq!(d.bool("b"), Ok(true));
            assert_eq!(d.finish(), Ok(()));

            // Truncation: a u64 with only 3 bytes.
            let mut d = Decoder::new(&[1, 2, 3]);
            assert!(matches!(d.u64(), Err(CheckpointError::Truncated { .. })));
            // A length prefix larger than the remaining bytes.
            let mut e = Encoder::new();
            e.count(1000);
            let b = e.into_bytes();
            assert!(matches!(
                Decoder::new(&b).count("x"),
                Err(CheckpointError::Invalid { .. })
            ));
            // Bad tags.
            assert!(Decoder::new(&[2]).opt_u64("x").is_err());
            assert!(Decoder::new(&[2]).bool("b").is_err());
            // Bad UTF-8.
            let mut e = Encoder::new();
            e.bytes(&[0xFF, 0xFE]);
            let b = e.into_bytes();
            assert!(Decoder::new(&b).str("s").is_err());
            // Trailing bytes.
            assert_eq!(
                Decoder::new(&[0, 1]).finish(),
                Err(CheckpointError::Trailing { extra: 2 })
            );
        }

        #[test]
        fn round_trip_is_byte_equal_at_several_ticks() {
            let c = config(5);
            let mut sim = founders(&c);
            for tick in [0u64, 1, 37, 150] {
                while sim.tick_count() < tick {
                    sim.tick();
                }
                let file = write_file(&sim, c.seed);
                let restored = read_file(&file).unwrap();
                assert_eq!(restored.seed, c.seed);
                assert_eq!(encode_state(&restored.sim), encode_state(&sim), "tick {tick}");
                assert_eq!(restored.sim, sim, "tick {tick}");
                assert_eq!(restored.sim.check_spatial(), Ok(()));
            }
        }

        #[test]
        fn file_round_trip_restores_every_field_group() {
            let c = config(6);
            let base = {
                let mut s = founders(&c);
                s.run(20);
                s
            };
            let restored = |s: &Simulation| read_file(&write_file(s, c.seed)).unwrap().sim;
            let before = state_hash(&base);
            assert_eq!(state_hash(&restored(&base)), before);

            // One change per group: each must change the hash and survive the file round trip.
            let mut tick = base.clone();
            tick.run(1);
            let mut rng = base.clone();
            rng.rng_mut().next_u64();
            let mut energy = base.clone();
            let id = energy.entities().living().next().unwrap().id();
            energy.entities_mut().get_mut(id).unwrap().add_energy(0.25);
            let resource = with_parts(&base, |p| {
                let mut values = p.world.resources.values().to_vec();
                values[0] = if values[0] > 0.0 { values[0] - 1.0 } else { 1.0 };
                p.world.resources = ResourceField::from_values(&p.world.topology, values).unwrap();
            });
            let weather = with_parts(&base, |p| {
                let c = &p.world.climate;
                let mut nodes = c.nodes().to_vec();
                nodes[0] = 0.5;
                p.world.climate =
                    Climate::from_parts(c.torus(), c.terms().to_vec(), c.params(), nodes, c.weather_tick())
                        .unwrap();
            });
            let mating = with_parts(&base, |p| p.mating.threshold[0] += 1.0);
            let seeding = with_parts(&base, |p| {
                p.seeding = SeedingSettings::new(0.25, p.seeding.radius, p.seeding.mutation).unwrap();
            });
            let lifespans = with_parts(&base, |p| p.lifespans.plants += 1);
            let species = with_parts(&base, |p| {
                p.species.update_extinction(&Entities::new(), p.tick);
            });

            for (name, changed) in [
                ("tick", &tick),
                ("rng", &rng),
                ("organism energy", &energy),
                ("resource", &resource),
                ("weather node", &weather),
                ("mating", &mating),
                ("seeding", &seeding),
                ("lifespan", &lifespans),
                ("species", &species),
            ] {
                assert_ne!(state_hash(changed), before, "{name} change is not in the hash");
                assert_eq!(state_hash(&restored(changed)), state_hash(changed), "{name} lost");
                assert_eq!(restored(changed), *changed, "{name} not restored exactly");
            }
        }

        #[test]
        fn every_truncation_length_is_an_error_and_never_a_panic() {
            let file = small_file();
            for len in 0..file.len() {
                assert!(read_file(&file[..len]).is_err(), "length {len} accepted");
            }
            assert!(read_file(&file).is_ok());
        }

        #[test]
        fn every_single_byte_flip_is_an_error() {
            let file = small_file();
            for i in 0..file.len() {
                let mut damaged = file.clone();
                damaged[i] ^= 0x01;
                assert!(read_file(&damaged).is_err(), "flip at byte {i} accepted");
            }
        }

        #[test]
        fn wrong_file_version_with_recomputed_digest_is_unsupported_version() {
            let mut file = small_file();
            file[8..12].copy_from_slice(&2u32.to_le_bytes());
            let file = reseal(file);
            assert_eq!(
                read_file(&file).unwrap_err(),
                CheckpointError::UnsupportedVersion {
                    found: 2,
                    expected: FILE_VERSION
                }
            );
        }

        #[test]
        fn wrong_state_version_with_recomputed_digest_is_refused() {
            let mut file = small_file();
            file[FILE_HEADER_LEN + 8..FILE_HEADER_LEN + 12].copy_from_slice(&9u32.to_le_bytes());
            let file = reseal(file);
            assert_eq!(
                read_file(&file).unwrap_err(),
                CheckpointError::UnsupportedStateVersion {
                    found: 9,
                    expected: FORMAT_VERSION
                }
            );
        }

        #[test]
        fn wrong_magic_is_not_a_checkpoint() {
            let mut file = small_file();
            file[0] = b'X';
            assert_eq!(read_file(&reseal(file)).unwrap_err(), CheckpointError::NotACheckpoint);
            // A result JSON is not a checkpoint either (it is refused before any state is built).
            let json = b"{\"contract\": 1, \"seed\": 1, \"tick_start\": 0, \"tick_end\": 0, \"pad\": \"................................\"}";
            assert!(read_file(json).is_err());
        }

        #[test]
        fn every_truncated_body_with_a_valid_digest_is_an_error() {
            // A forged digest must not reach the decoder with a body that is short: every prefix of a valid body
            // fails the decoder (Truncated, Invalid or Trailing), never a panic.
            let c = config(7);
            let sim = founders(&c);
            let body = encode_state(&sim);
            for len in 0..body.len() {
                let mut file = Vec::new();
                file.extend_from_slice(FILE_MAGIC);
                file.extend_from_slice(&FILE_VERSION.to_le_bytes());
                file.extend_from_slice(&c.seed.to_le_bytes());
                file.extend_from_slice(&(len as u64).to_le_bytes());
                file.extend_from_slice(&body[..len]);
                file.extend_from_slice(&[0u8; DIGEST_LEN]);
                let file = reseal(file);
                assert!(read_file(&file).is_err(), "body prefix {len} accepted");
            }
        }

        #[test]
        fn garbage_body_with_a_valid_digest_is_an_error_not_a_panic() {
            let mut rng = crate::rng::Rng::from_seed(99);
            for round in 0..200 {
                let len = 12 + (round % 40) * 7;
                let mut body = Vec::new();
                body.extend_from_slice(MAGIC);
                body.extend_from_slice(&FORMAT_VERSION.to_le_bytes());
                while body.len() < len {
                    body.push((rng.next_u64() & 0xFF) as u8);
                }
                let mut file = Vec::new();
                file.extend_from_slice(FILE_MAGIC);
                file.extend_from_slice(&FILE_VERSION.to_le_bytes());
                file.extend_from_slice(&0u64.to_le_bytes());
                file.extend_from_slice(&(body.len() as u64).to_le_bytes());
                file.extend_from_slice(&body);
                file.extend_from_slice(&[0u8; DIGEST_LEN]);
                assert!(read_file(&reseal(file)).is_err(), "round {round} accepted");
            }
        }

        #[test]
        fn a_file_with_extra_bytes_is_a_length_mismatch() {
            let mut file = small_file();
            let n = file.len() - DIGEST_LEN;
            file.insert(n, 0);
            assert!(matches!(
                read_file(&reseal(file)),
                Err(CheckpointError::LengthMismatch { .. })
            ));
        }

        #[test]
        fn runner_resume_is_used_for_checkpoint_restore() {
            // Smoke test of the resume path at tick 0: the restored run keeps the saved initial counts.
            let c = config(8);
            let fresh = runner::run(&c, 0, 1, false).unwrap().result;
            let restored = read_file(&write_file(&founders(&c), c.seed)).unwrap();
            let resumed = runner::resume(
                restored,
                0,
                RunOptions {
                    sample_every: 1,
                    with_metrics: false,
                    keep_state: false,
                },
            )
            .unwrap()
            .result;
            assert_eq!(resumed.state_hash, fresh.state_hash);
            assert_eq!(resumed.counts, fresh.counts);
        }
    }
}

//! Simulation state and the tick scheduler.
//!
//! [`Simulation`] owns the tick counter, the random generator and the world. [`Simulation::tick`] advances it by
//! exactly one tick by running every [`Phase`] of [`PHASE_ORDER`] once, in that order. Decisions are recorded in
//! `docs/decisions/ADR-0008-random-generator-and-tick-scheduler.md`.
//!
//! Fixed order inside one tick `t` (the tick counter equals `t` while the phases run):
//! 1. `Climate`: the weather advances one step (ADR-0010); seasons follow from the tick. The base climate is built in `Simulation::new` (TASK-006).
//! 2. `SpatialIndex`: compact the per-cell index (ADR-0003 amendment, TASK-010). Inserts, moves and removals keep it
//!    correct at all times; this phase only bounds the query cost.
//! 3. `Plants`, 4. `Herbivores`, 5. `Carnivores`: each acts over its organisms in ascending id order.
//! 6. `Reproduction`.
//! 7. `Deaths`: order-preserving removal (no swap-remove).
//! 8. `Species`: species check, which runs internally only every `species_check_interval` ticks (no-op until TASK-011).
//! 9. `Counters`: cumulative births and deaths per kind.
//!
//! Then the tick counter increases by exactly one.
//!
//! Ties between organisms are broken by ascending id everywhere. Sampling for time series is read-only and runs
//! outside `tick()`. The core has no dependency on UI or CLI code.
//!
//! Phase bodies are empty in TASK-005. Later tasks add their code in the matching arm of [`Simulation::run_phase`]
//! and must not reorder [`PHASE_ORDER`] without a new ADR.

use std::fmt;

use crate::climate::{Climate, ClimateError, ClimateParams};
use crate::config::Config;
use crate::ecology::{self, ResourceField};
use crate::entities::{Birth, Entities, EntityError, Kind, LifespanRanges, OrganismId};
use crate::feeding;
use crate::genome::{copy_child, random_genome, GenomeError, Mutation};
use crate::hunting;
use crate::mating::{self, MatingError, MatingSettings};
use crate::movement;
use crate::reproduction::{self, ReproductionError, SeedingSettings};
use crate::spatial::{SpatialError, SpatialIndex};
use crate::species::{self, Member, SpeciesRegistry, SpeciesSettings};
use crate::world::Cell;

/// Energy of a founder at tick 0 (half of [`crate::entities::ENERGY_MAX`]). A documented starting value.
pub const FOUNDER_ENERGY: f32 = 50.0;

/// Mutation settings from `config.genetics` (rate and strength, ADR-0004). Validated again by [`Mutation::new`].
pub fn mutation_settings(config: &Config) -> Result<Mutation, GenomeError> {
    Mutation::new(
        config.genetics.mutation_rate,
        config.genetics.mutation_strength,
    )
}
use crate::rng::{fingerprint, Rng, RngError};
use crate::world::{TopologyError, Torus};

/// One step of a tick. Each phase runs exactly once per tick.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Phase {
    Climate,
    SpatialIndex,
    Plants,
    Herbivores,
    Carnivores,
    Reproduction,
    Deaths,
    Species,
    Counters,
}

/// The fixed order of phases inside one tick.
pub const PHASE_ORDER: [Phase; 9] = [
    Phase::Climate,
    Phase::SpatialIndex,
    Phase::Plants,
    Phase::Herbivores,
    Phase::Carnivores,
    Phase::Reproduction,
    Phase::Deaths,
    Phase::Species,
    Phase::Counters,
];

/// One entry of the optional trace: the state after a phase ran, identified by tick and phase.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TraceRecord {
    /// The tick being simulated (the counter value while its phases ran).
    pub tick: u64,
    pub phase: Phase,
    /// `fingerprint` of the generator state right after the phase.
    pub rng_fingerprint: u64,
}

/// The spatial part of the simulation: the torus and its base climate. Organisms are added by later tasks.
#[derive(Clone, Debug, PartialEq)]
pub struct World {
    pub topology: Torus,
    /// Climate of every cell: the base field (TASK-006) plus seasons and weather state (TASK-007, ADR-0010).
    pub climate: Climate,
    /// Plant resource pool of every cell (TASK-011, ADR-0012). The only energy source for plants.
    pub resources: ResourceField,
}

/// Error when a simulation cannot be created from a configuration.
#[derive(Clone, Debug, PartialEq)]
pub enum SimError {
    /// The world size is not a valid torus.
    Topology(TopologyError),
    /// A side does not fit in the `u32` used by the topology.
    SideTooLarge { value: u64 },
    /// The climate settings are invalid.
    Climate(ClimateError),
    /// A founder was added after tick 0 (founders exist only at tick 0, ADR-0011).
    FounderAfterStart { tick: u64 },
    /// An organism could not be created or the bookkeeping is inconsistent.
    Entity(EntityError),
    /// The neighbour index rejected a change (the cell is not on the torus, or the id is already indexed).
    Spatial(SpatialError),
    /// The plant seeding settings are invalid (TASK-012, ADR-0013).
    Reproduction(ReproductionError),
    /// An organism is not stored or is already dead, so it cannot move (TASK-013).
    NotAlive { id: OrganismId },
    /// The mating settings are invalid or a mating could not be applied (TASK-016, ADR-0017).
    Mating(MatingError),
}

impl fmt::Display for SimError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SimError::Topology(e) => write!(f, "{e}"),
            SimError::SideTooLarge { value } => {
                write!(f, "world side {value} does not fit in 32 bits")
            }
            SimError::Climate(e) => write!(f, "{e}"),
            SimError::FounderAfterStart { tick } => {
                write!(
                    f,
                    "founders can only be added at tick 0, the simulation is at tick {tick}"
                )
            }
            SimError::Entity(e) => write!(f, "{e}"),
            SimError::Spatial(e) => write!(f, "{e}"),
            SimError::Reproduction(e) => write!(f, "{e}"),
            SimError::NotAlive { id } => write!(f, "organism {} is not alive", id.0),
            SimError::Mating(e) => write!(f, "{e}"),
        }
    }
}

impl std::error::Error for SimError {}

impl From<TopologyError> for SimError {
    fn from(e: TopologyError) -> Self {
        SimError::Topology(e)
    }
}

impl From<ClimateError> for SimError {
    fn from(e: ClimateError) -> Self {
        SimError::Climate(e)
    }
}

impl From<EntityError> for SimError {
    fn from(e: EntityError) -> Self {
        SimError::Entity(e)
    }
}

impl From<SpatialError> for SimError {
    fn from(e: SpatialError) -> Self {
        SimError::Spatial(e)
    }
}

impl From<ReproductionError> for SimError {
    fn from(e: ReproductionError) -> Self {
        SimError::Reproduction(e)
    }
}

impl From<MatingError> for SimError {
    fn from(e: MatingError) -> Self {
        SimError::Mating(e)
    }
}

/// The complete simulation state: tick counter, random generator, world and optional trace.
#[derive(Clone, Debug, PartialEq)]
pub struct Simulation {
    tick: u64,
    rng: Rng,
    world: World,
    entities: Entities,
    /// Neighbour index over the living organisms. Derived state: kept in step with `entities` by
    /// `add_founder`, `populate_initial` and the Deaths phase; checked by [`Simulation::check_spatial`].
    spatial: SpatialIndex,
    /// Plant seeding settings (TASK-012, ADR-0013). Set from the configuration; saved by the checkpoint (TASK-022).
    seeding: SeedingSettings,
    /// Animal mating settings (TASK-016, ADR-0017). Set from the configuration; saved by the checkpoint (TASK-022).
    mating: MatingSettings,
    /// Species records, open candidates and name counters (TASK-017, ADR-0018). Saved by the checkpoint (TASK-022).
    species: SpeciesRegistry,
    /// Lifespan centres per kind, from `plants.max_age`, `herbivores.max_age`, `carnivores.max_age` (ADR-0019 D2).
    /// Set from the configuration; saved by the checkpoint (TASK-022).
    lifespans: LifespanRanges,
    trace: Option<Vec<TraceRecord>>,
}

impl Simulation {
    /// Creates tick 0 from a configuration: the generator is seeded with `config.seed` and the world has
    /// `config.world` size.
    pub fn new(config: &Config) -> Result<Simulation, SimError> {
        let width = u32::try_from(config.world.width).map_err(|_| SimError::SideTooLarge {
            value: config.world.width,
        })?;
        let height = u32::try_from(config.world.height).map_err(|_| SimError::SideTooLarge {
            value: config.world.height,
        })?;
        let topology = Torus::new(width, height)?;
        let params = ClimateParams {
            season_length: config.climate.season_length,
            weather_amplitude: config.climate.weather_amplitude,
        };
        let climate = Climate::new(&topology, config.seed, params)?;
        let seeding = SeedingSettings::from_config(config)?;
        let mating = MatingSettings::from_config(config)?;
        let species = SpeciesRegistry::new(SpeciesSettings::from_config(config));
        let lifespans = LifespanRanges::from_config(config);
        Ok(Simulation {
            tick: 0,
            rng: Rng::from_seed(config.seed),
            world: World {
                topology,
                resources: ResourceField::full(&topology, &climate),
                climate,
            },
            entities: Entities::new(),
            spatial: SpatialIndex::new(topology),
            seeding,
            mating,
            species,
            lifespans,
            trace: None,
        })
    }

    /// Assembles a state from parts, for checkpoint restore (TASK-022). Tracing starts off. The seeding settings
    /// are not derivable from the saved state, so the caller supplies them (ADR-0013). The lifespan centres are
    /// supplied the same way (ADR-0019 D2). Eight arguments until the checkpoint groups the settings (TASK-022).
    #[allow(clippy::too_many_arguments)]
    pub fn from_parts(
        tick: u64,
        rng_state: [u64; 4],
        world: World,
        entities: Entities,
        seeding: SeedingSettings,
        mating: MatingSettings,
        species: SpeciesRegistry,
        lifespans: LifespanRanges,
    ) -> Result<Simulation, RngError> {
        Ok(Simulation::assemble(
            tick,
            Rng::from_state(rng_state)?,
            world,
            entities,
            seeding,
            mating,
            species,
            lifespans,
        ))
    }

    /// Builds the struct from checked parts and rebuilds the derived neighbour index (ADR-0003).
    #[allow(clippy::too_many_arguments)]
    fn assemble(
        tick: u64,
        rng: Rng,
        world: World,
        entities: Entities,
        seeding: SeedingSettings,
        mating: MatingSettings,
        species: SpeciesRegistry,
        lifespans: LifespanRanges,
    ) -> Simulation {
        // The index is derived, so it is rebuilt from the living organisms. An organism on a cell outside the
        // torus is left out here; `check_spatial` reports it.
        let mut spatial = SpatialIndex::new(world.topology);
        for o in entities.living() {
            let _ = spatial.insert(o.id(), o.cell(), o.kind());
        }
        Simulation {
            tick,
            rng,
            world,
            entities,
            spatial,
            seeding,
            mating,
            species,
            lifespans,
            trace: None,
        }
    }

    /// Adds a founder organism. Allowed only at tick 0, so that `initial` always means "tick 0" (ADR-0011).
    pub fn add_founder(&mut self, birth: Birth) -> Result<OrganismId, SimError> {
        if self.tick != 0 {
            return Err(SimError::FounderAfterStart { tick: self.tick });
        }
        self.check_birth_cell(&birth)?;
        let id = self.entities.spawn_founder(birth)?;
        self.index_spawned(id);
        Ok(id)
    }

    /// Moves a living organism to `cell` and keeps the entity store and the neighbour index in step (TASK-013, G-047).
    /// Refused, with nothing changed, if the cell is not on the torus or the organism is missing or dead. Occupancy is
    /// not checked: any number of organisms may share a cell (ADR-0014).
    pub fn move_organism(&mut self, id: OrganismId, cell: Cell) -> Result<(), SimError> {
        if self.world.topology.cell(cell.x(), cell.y()) != Some(cell) {
            return Err(SimError::Spatial(SpatialError::CellOutsideTorus {
                x: cell.x(),
                y: cell.y(),
            }));
        }
        match self.entities.get(id) {
            Some(o) if o.is_alive() => {}
            _ => return Err(SimError::NotAlive { id }),
        }
        self.spatial.move_to(id, cell)?;
        self.entities
            .get_mut(id)
            .expect("checked above")
            .set_cell(cell);
        Ok(())
    }

    /// Carnivore phase (TASK-015, ADR-0016): plans and applies the moves of the living carnivores (pursuit of herbivores
    /// in sight, or wander), then each carnivore attacks in ascending id order (at most one attempt, reach 1), paying
    /// `ATTACK_COST` for every attempt, then every living carnivore pays its costs: movement, base metabolism and the
    /// thermal cost at its cell after the move.
    fn carnivore_phase(&mut self) {
        let plans = movement::plan_moves(
            &self.entities,
            &self.spatial,
            &self.world.topology,
            Kind::Carnivore,
            &mut self.rng,
            |o, perceived| hunting::carnivore_heading(&self.entities, &self.spatial, o, perceived),
        );
        for plan in &plans {
            // Cells come from the torus and the organism is alive (planned this phase, not yet killed): cannot fail.
            let moved = self.move_organism(plan.id, plan.to);
            debug_assert!(moved.is_ok(), "planned move refused: {moved:?}");
        }
        for plan in &plans {
            let outcome =
                hunting::attack(&mut self.entities, &self.spatial, &mut self.rng, plan.id);
            if outcome != hunting::AttackOutcome::NoAttempt {
                if let Some(o) = self.entities.get_mut(plan.id) {
                    o.drain_energy(hunting::ATTACK_COST);
                }
            }
        }
        for plan in &plans {
            let Some(o) = self.entities.get(plan.id) else {
                continue;
            };
            if !o.is_alive() {
                continue;
            }
            let temperature = self.world.climate.conditions(o.cell()).temperature;
            let cost = hunting::carnivore_costs(plan.distance, plan.speed, temperature);
            if let Some(o) = self.entities.get_mut(plan.id) {
                o.drain_energy(cost);
            }
        }
    }

    /// Herbivore phase (TASK-014, ADR-0015): plans and applies the moves of the living herbivores (food against danger,
    /// by their genes), then each herbivore feeds in its reach in ascending id order, then every herbivore pays its
    /// costs: movement (ADR-0014), base metabolism and the thermal cost at its cell after the move.
    fn herbivore_phase(&mut self) {
        let plans = movement::plan_moves(
            &self.entities,
            &self.spatial,
            &self.world.topology,
            Kind::Herbivore,
            &mut self.rng,
            |o, perceived| feeding::herbivore_heading(&self.entities, &self.spatial, o, perceived),
        );
        for plan in &plans {
            // Cells come from the torus and the organism is alive (planned this phase, not yet killed): cannot fail.
            let moved = self.move_organism(plan.id, plan.to);
            debug_assert!(moved.is_ok(), "planned move refused: {moved:?}");
        }
        for plan in &plans {
            let _gained = feeding::feed(&mut self.entities, &self.spatial, plan.id);
        }
        for plan in &plans {
            let Some(o) = self.entities.get(plan.id) else {
                continue;
            };
            if !o.is_alive() {
                continue;
            }
            let temperature = self.world.climate.conditions(o.cell()).temperature;
            let cost = movement::move_cost(plan.distance, plan.speed)
                + feeding::BASE_COST
                + feeding::thermal_cost(temperature);
            if let Some(o) = self.entities.get_mut(plan.id) {
                o.drain_energy(cost);
            }
        }
    }

    /// Refuses a birth whose cell is not on this torus. Checked before spawning, so a refused birth changes nothing.
    fn check_birth_cell(&self, birth: &Birth) -> Result<(), SimError> {
        let c = birth.cell;
        if self.world.topology.cell(c.x(), c.y()) == Some(c) {
            Ok(())
        } else {
            Err(SimError::Spatial(SpatialError::CellOutsideTorus {
                x: c.x(),
                y: c.y(),
            }))
        }
    }

    /// Adds a just-spawned organism to the neighbour index. Ids from `Entities` are fresh and the cell was
    /// checked before spawning, so this cannot fail.
    fn index_spawned(&mut self, id: OrganismId) {
        let o = self
            .entities
            .get(id)
            .expect("the organism was spawned just before");
        self.spatial
            .insert(id, o.cell(), o.kind())
            .expect("fresh id on a checked cell");
    }

    /// Places the founders of `config.initial` at tick 0 (TASK-009). Cells are drawn uniformly from the torus and
    /// genomes at random, both from the simulation generator, in the order plants, herbivores, carnivores. Each founder
    /// starts with energy [`FOUNDER_ENERGY`] and full health. Not called by [`Simulation::new`], so that existing
    /// generator states stay unchanged; the CLI run wiring calls it (TASK-019). Tick 0 only.
    pub fn populate_initial(&mut self, config: &Config) -> Result<(), SimError> {
        if self.tick != 0 {
            return Err(SimError::FounderAfterStart { tick: self.tick });
        }
        let plan = [
            (Kind::Plant, config.initial.plants),
            (Kind::Herbivore, config.initial.herbivores),
            (Kind::Carnivore, config.initial.carnivores),
        ];
        let (width, height) = (self.world.topology.width(), self.world.topology.height());
        // Clonal founders (TASK-017, ADR-0018 D1): one ancestral genome per kind, each founder a mutated copy of it, so
        // that all founders of a kind start as one species.
        let mutation =
            mutation_settings(config).map_err(|e| SimError::Mating(MatingError::Genome(e)))?;
        for (kind, count) in plan {
            let ploidy = if kind.is_animal() { 2 } else { 1 };
            let ancestor =
                random_genome(ploidy, &mut self.rng).expect("ploidy is 1 or 2 by construction");
            for _ in 0..count {
                let x = self.rng.next_below(u64::from(width)) as u32;
                let y = self.rng.next_below(u64::from(height)) as u32;
                let cell = self
                    .world
                    .topology
                    .cell(x, y)
                    .expect("drawn coordinates lie inside the torus");
                let genome = copy_child(&ancestor, mutation, &mut self.rng);
                let mut birth = Birth::from_genome_in(
                    kind,
                    cell,
                    genome,
                    FOUNDER_ENERGY,
                    0.0,
                    &self.lifespans,
                )?;
                birth.health = birth.traits.max_health();
                let id = self.entities.spawn_founder(birth)?;
                self.index_spawned(id);
            }
        }
        // Founding check (TASK-017, ADR-0018): each kind's founders become its first species.
        for kind in Kind::ALL {
            self.classify_kind(kind);
        }
        Ok(())
    }

    /// The lifespan centres in use (ADR-0019 D2).
    pub fn lifespans(&self) -> &LifespanRanges {
        &self.lifespans
    }

    /// The species records, open candidates and name counters (TASK-017).
    pub fn species(&self) -> &SpeciesRegistry {
        &self.species
    }

    /// Classifies the living organisms of one kind at the current tick and stores the species ids (ADR-0018).
    fn classify_kind(&mut self, kind: Kind) {
        let members: Vec<Member> = self
            .entities
            .living()
            .filter(|o| o.kind() == kind)
            .map(|o| Member {
                id: o.id(),
                genome: o.genome(),
                provisional: o.species(),
            })
            .collect();
        let assignments = species::classify(&mut self.species, kind, &members, self.tick);
        species::apply(&mut self.entities, &assignments);
    }

    /// The organism store and its per-kind bookkeeping.
    pub fn entities(&self) -> &Entities {
        &self.entities
    }

    /// Mutable organism store, for the action phases of later tasks. A change of an organism's cell or kind made
    /// here bypasses the neighbour index; [`Simulation::check_spatial`] reports it. Organisms move through
    /// [`Simulation::move_organism`], which keeps the index in step.
    pub fn entities_mut(&mut self) -> &mut Entities {
        &mut self.entities
    }

    /// The plant seeding settings in use (TASK-012, ADR-0013). Read by checkpoint save.
    /// Animal mating settings (TASK-016).
    pub fn mating(&self) -> &MatingSettings {
        &self.mating
    }

    pub fn seeding(&self) -> &SeedingSettings {
        &self.seeding
    }

    /// The neighbour index over the living organisms (ADR-0003, TASK-010).
    pub fn spatial(&self) -> &SpatialIndex {
        &self.spatial
    }

    /// Checks that the neighbour index indexes exactly the living organisms, each at its own cell and kind.
    pub fn check_spatial(&self) -> Result<(), SpatialError> {
        for o in self.entities.living() {
            if self.spatial.position(o.id()) != Some((o.cell(), o.kind())) {
                return Err(SpatialError::OutOfSync(o.id()));
            }
        }
        for id in self.spatial.ids() {
            if !self.entities.get(id).is_some_and(|o| o.is_alive()) {
                return Err(SpatialError::OutOfSync(id));
            }
        }
        Ok(())
    }

    /// Advances the simulation by exactly one tick.
    pub fn tick(&mut self) {
        for phase in PHASE_ORDER {
            self.run_phase(phase);
            if let Some(trace) = self.trace.as_mut() {
                trace.push(TraceRecord {
                    tick: self.tick,
                    phase,
                    rng_fingerprint: fingerprint(self.rng.state()),
                });
            }
        }
        self.tick += 1;
    }

    /// Advances the simulation by exactly one tick, like [`Simulation::tick`], and adds the wall-clock time of each
    /// phase to `times` (TASK-026, ADR-0027 D2). Runs the same phases in the same order, so the state is identical to
    /// the one `tick` produces; only the timers differ. `Instant` is used here and in `perf.rs` only.
    pub fn tick_profiled(&mut self, times: &mut crate::perf::PhaseTimes) {
        for (index, phase) in PHASE_ORDER.into_iter().enumerate() {
            let started = std::time::Instant::now();
            self.run_phase(phase);
            times.add(index, started.elapsed());
            if let Some(trace) = self.trace.as_mut() {
                trace.push(TraceRecord {
                    tick: self.tick,
                    phase,
                    rng_fingerprint: fingerprint(self.rng.state()),
                });
            }
        }
        self.tick += 1;
        times.ticks += 1;
    }

    /// Advances the simulation by `n` ticks.
    pub fn run(&mut self, n: u64) {
        for _ in 0..n {
            self.tick();
        }
    }

    /// The number of completed ticks. Also the tick number that the next `tick()` simulates.
    pub fn tick_count(&self) -> u64 {
        self.tick
    }

    /// Exact generator state, for checkpoints.
    pub fn rng_state(&self) -> [u64; 4] {
        self.rng.state()
    }

    /// The random generator. Phases draw from it in the fixed order above.
    pub fn rng_mut(&mut self) -> &mut Rng {
        &mut self.rng
    }

    pub fn world(&self) -> &World {
        &self.world
    }

    /// Turns the per-phase trace on (empty buffer) or off (buffer dropped). Off by default.
    pub fn set_trace(&mut self, on: bool) {
        self.trace = if on {
            Some(self.trace.take().unwrap_or_default())
        } else {
            None
        };
    }

    /// The trace recorded since tracing was turned on. Empty when tracing is off.
    pub fn trace(&self) -> &[TraceRecord] {
        self.trace.as_deref().unwrap_or(&[])
    }

    /// Body of one phase. Empty in TASK-005; later tasks add code to the matching arm.
    fn run_phase(&mut self, phase: Phase) {
        match phase {
            Phase::Climate => self.world.climate.advance(&mut self.rng, self.tick),
            Phase::SpatialIndex => self.spatial.rebuild(),
            Phase::Plants => {
                // The report is discarded here; metrics are added in a later task (TASK-011, ADR-0012).
                let _ = ecology::plants_phase(
                    &mut self.entities,
                    &mut self.world.resources,
                    &self.world.climate,
                );
            }
            Phase::Herbivores => self.herbivore_phase(),
            Phase::Carnivores => self.carnivore_phase(),
            Phase::Reproduction => {
                // Newborns are the organisms spawned from here on (ids are never reused).
                let first_new = OrganismId(self.entities.next_id());
                // The report is discarded here; metrics are added in a later task (TASK-012, ADR-0013).
                let result = reproduction::reproduction_phase(
                    &mut self.entities,
                    &mut self.spatial,
                    &self.world.resources,
                    &self.world.topology,
                    &self.seeding,
                    &self.lifespans,
                    &mut self.rng,
                );
                debug_assert!(result.is_ok(), "reproduction failed: {result:?}");
                // Animals mate after plants have seeded (ADR-0017). The report is discarded here, as above.
                let mated = mating::mating_phase(
                    &mut self.entities,
                    &mut self.spatial,
                    &self.mating,
                    &self.lifespans,
                    &mut self.rng,
                );
                debug_assert!(mated.is_ok(), "mating failed: {mated:?}");
                // Provisional species of the newborns: the mother's (TASK-017, ADR-0018).
                species::inherit_provisional(&mut self.entities, first_new);
            }
            Phase::Deaths => {
                self.entities.deaths_phase(self.tick);
                for death in self.entities.last_deaths() {
                    // An id that was never indexed is reported by `check_spatial` in the Counters phase.
                    let _ = self.spatial.remove(death.id);
                }
            }
            Phase::Species => {
                // Full re-classification at checks `t > 0`, `t % check_interval == 0` (ADR-0018). Extinction is
                // checked every tick, after the Deaths phase, so the death tick is exact.
                let interval = self.species.settings().check_interval;
                if self.tick > 0 && self.tick.is_multiple_of(interval) {
                    for kind in Kind::ALL {
                        self.classify_kind(kind);
                    }
                }
                self.species.update_extinction(&self.entities, self.tick);
            }
            Phase::Counters => {
                debug_assert_eq!(self.entities.check_balance(), Ok(()));
                debug_assert_eq!(self.entities.check_invariants(), Ok(()));
                debug_assert_eq!(self.check_spatial(), Ok(()));
            }
        }
    }
}

impl World {
    /// Canonical encoding of the world: topology, climate state and resource pool (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let World {
            topology,
            climate,
            resources,
        } = self;
        topology.encode_state(enc);
        climate.encode_state(enc);
        resources.encode_state(enc);
    }

    /// Reads the world (ADR-0023 D3). The topology is written twice, once here and once by the climate; both must agree.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<World, crate::checkpoint::CheckpointError> {
        let topology = Torus::decode_state(dec)?;
        let climate = Climate::decode_state(dec)?;
        if climate.torus() != topology {
            return Err(crate::checkpoint::invalid(
                "climate torus differs from the world topology",
            ));
        }
        let resources = ResourceField::decode_state(dec, &topology)?;
        Ok(World {
            topology,
            climate,
            resources,
        })
    }
}

impl Simulation {
    /// Canonical encoding of the complete state at the current tick (ADR-0020 D3). Excluded, with reason: the spatial
    /// index (derived from the organisms, see `check_spatial`) and the optional trace (diagnostic, not state).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Simulation {
            tick,
            rng,
            world,
            entities,
            spatial: _,
            seeding,
            mating,
            species,
            lifespans,
            trace: _,
        } = self;
        enc.u64(*tick);
        rng.encode_state(enc);
        world.encode_state(enc);
        entities.encode_state(enc);
        seeding.encode_state(enc);
        mating.encode_state(enc);
        species.encode_state(enc);
        lifespans.encode_state(enc);
    }

    /// Reads the complete state in the order of [`Simulation::encode_state`] (ADR-0023 D3). The neighbour index is
    /// rebuilt; the trace starts off.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Simulation, crate::checkpoint::CheckpointError> {
        let tick = dec.u64()?;
        let rng = Rng::decode_state(dec)?;
        let world = World::decode_state(dec)?;
        let entities = Entities::decode_state(dec, &world.topology)?;
        let seeding = SeedingSettings::decode_state(dec)?;
        let mating = MatingSettings::decode_state(dec)?;
        let species = SpeciesRegistry::decode_state(dec)?;
        let lifespans = LifespanRanges::decode_state(dec)?;
        Ok(Simulation::assemble(
            tick, rng, world, entities, seeding, mating, species, lifespans,
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{Config, Initial};

    fn config(seed: u64) -> Config {
        Config::new(
            seed,
            64,
            48,
            Initial {
                plants: 400,
                herbivores: 120,
                carnivores: 20,
            },
        )
        .unwrap()
    }

    fn default_seeding() -> SeedingSettings {
        SeedingSettings::from_config(&config(1)).unwrap()
    }

    fn default_mating() -> MatingSettings {
        MatingSettings::from_config(&config(1)).unwrap()
    }

    fn default_species() -> SpeciesRegistry {
        SpeciesRegistry::new(SpeciesSettings::from_config(&config(1)))
    }

    fn traced_run(seed: u64, ticks: u64) -> Vec<TraceRecord> {
        let mut sim = Simulation::new(&config(seed)).unwrap();
        sim.set_trace(true);
        sim.run(ticks);
        sim.trace().to_vec()
    }

    #[test]
    fn phase_order_is_fixed() {
        assert_eq!(
            PHASE_ORDER,
            [
                Phase::Climate,
                Phase::SpatialIndex,
                Phase::Plants,
                Phase::Herbivores,
                Phase::Carnivores,
                Phase::Reproduction,
                Phase::Deaths,
                Phase::Species,
                Phase::Counters,
            ]
        );
    }

    #[test]
    fn tick_advances_counter_by_exactly_one() {
        let mut sim = Simulation::new(&config(1)).unwrap();
        assert_eq!(sim.tick_count(), 0);
        sim.tick();
        assert_eq!(sim.tick_count(), 1);
        sim.tick();
        assert_eq!(sim.tick_count(), 2);
        sim.run(5);
        assert_eq!(sim.tick_count(), 7);
        sim.run(0);
        assert_eq!(sim.tick_count(), 7);
    }

    #[test]
    fn new_uses_config_seed_and_world_size() {
        let sim = Simulation::new(&config(42)).unwrap();
        assert_eq!(sim.rng_state(), Rng::from_seed(42).state());
        assert_eq!(sim.world().topology.width(), 64);
        assert_eq!(sim.world().topology.height(), 48);
    }

    #[test]
    fn new_maps_zero_sized_world_to_error() {
        let mut cfg = config(1);
        cfg.world.width = 0;
        assert_eq!(
            Simulation::new(&cfg),
            Err(SimError::Topology(TopologyError::ZeroSize {
                width: 0,
                height: 48
            }))
        );
    }

    #[test]
    fn new_maps_oversized_side_to_error() {
        let mut cfg = config(1);
        cfg.world.height = u64::from(u32::MAX) + 1;
        assert_eq!(
            Simulation::new(&cfg),
            Err(SimError::SideTooLarge {
                value: u64::from(u32::MAX) + 1
            })
        );
    }

    #[test]
    fn trace_has_nine_records_per_tick_in_order() {
        let trace = traced_run(3, 3);
        assert_eq!(trace.len(), 27);
        for (i, rec) in trace.iter().enumerate() {
            assert_eq!(rec.tick, (i / 9) as u64);
            assert_eq!(rec.phase, PHASE_ORDER[i % 9]);
        }
        let ticks: Vec<u64> = trace.iter().map(|r| r.tick).collect();
        assert!(ticks.windows(2).all(|w| w[0] <= w[1]));
    }

    #[test]
    fn trace_identical_for_same_seed_over_100_ticks() {
        let a = traced_run(2024, 100);
        let b = traced_run(2024, 100);
        assert_eq!(a.len(), 900);
        assert_eq!(a, b);
    }

    #[test]
    fn trace_differs_for_different_seed_over_100_ticks() {
        let a = traced_run(1, 100);
        let b = traced_run(2, 100);
        assert_ne!(a, b);
    }

    #[test]
    fn trace_off_by_default_and_records_nothing() {
        let mut sim = Simulation::new(&config(5)).unwrap();
        sim.run(10);
        assert!(sim.trace().is_empty());
        sim.set_trace(true);
        sim.run(2);
        assert_eq!(sim.trace().len(), 18);
        sim.set_trace(false);
        assert!(sim.trace().is_empty());
        sim.run(2);
        assert!(sim.trace().is_empty());
    }

    #[test]
    fn restore_rng_mid_run_reproduces_rest_of_trace() {
        let full = traced_run(77, 100);

        let mut first = Simulation::new(&config(77)).unwrap();
        first.set_trace(true);
        first.run(50);
        let rng_state = first.rng_state();
        let tick = first.tick_count();
        let world = first.world().clone();

        let mut second = Simulation::from_parts(
            tick,
            rng_state,
            world,
            Entities::new(),
            default_seeding(),
            default_mating(),
            default_species(),
            LifespanRanges::default(),
        )
        .unwrap();
        second.set_trace(true);
        second.run(50);

        assert_eq!(second.tick_count(), 100);
        assert_eq!(second.trace(), &full[450..]);
        assert_eq!(first.trace(), &full[..450]);
    }

    #[test]
    fn from_parts_rejects_all_zero_rng_state() {
        let world = Simulation::new(&config(1)).unwrap().world().clone();
        assert!(Simulation::from_parts(
            0,
            [0; 4],
            world,
            Entities::new(),
            default_seeding(),
            default_mating(),
            default_species(),
            LifespanRanges::default(),
        )
        .is_err());
    }

    fn weather_config(seed: u64, amplitude: f64, season_length: u64) -> Config {
        let mut cfg = config(seed);
        cfg.climate.weather_amplitude = amplitude;
        cfg.climate.season_length = season_length;
        cfg
    }

    #[test]
    fn climate_phase_draws_only_when_weather_is_on() {
        for (amplitude, changes) in [(0.0, false), (0.5, true)] {
            let before = fingerprint(Rng::from_seed(9).state());
            let mut sim = Simulation::new(&weather_config(9, amplitude, 240)).unwrap();
            sim.set_trace(true);
            sim.tick();
            let first = sim.trace()[0];
            assert_eq!(first.phase, Phase::Climate);
            assert_eq!(
                first.rng_fingerprint != before,
                changes,
                "amplitude {amplitude}: the Climate phase changes the generator state"
            );
        }
    }

    #[test]
    fn one_year_repeats_exactly_with_weather_off() {
        let mut sim = Simulation::new(&weather_config(42, 0.0, 240)).unwrap();
        let torus = sim.world().topology;
        let rng_before = sim.rng_state();
        let mut per_tick: Vec<Vec<(u32, u32)>> = Vec::new();
        for _ in 0..480 {
            sim.tick();
            let row = (0..torus.cell_count())
                .map(|i| {
                    let cell = torus.cell_from_index(i).unwrap();
                    let c = sim.world().climate.conditions(cell);
                    (c.temperature.to_bits(), c.precipitation.to_bits())
                })
                .collect();
            per_tick.push(row);
        }
        assert_eq!(sim.rng_state(), rng_before, "no draws with weather off");
        for k in 0..240 {
            assert_eq!(
                per_tick[k],
                per_tick[k + 240],
                "tick {k} and tick {}",
                k + 240
            );
        }
    }

    #[test]
    fn restore_with_weather_continues_identically() {
        let cfg = weather_config(31, 0.8, 120);
        let mut full = Simulation::new(&cfg).unwrap();
        full.run(150);

        let mut first = Simulation::new(&cfg).unwrap();
        first.run(100);
        let mut second = Simulation::from_parts(
            first.tick_count(),
            first.rng_state(),
            first.world().clone(),
            first.entities().clone(),
            first.seeding().clone(),
            first.mating().clone(),
            first.species().clone(),
            *first.lifespans(),
        )
        .unwrap();
        second.run(50);

        assert_eq!(
            second, full,
            "weather state is part of the simulation state"
        );
    }

    fn plant_birth(energy: f32) -> Birth {
        let torus = Simulation::new(&config(1)).unwrap().world().topology;
        let genome = crate::genome::Genome::new(1, vec![128; 128]).unwrap();
        Birth::from_genome(
            crate::entities::Kind::Plant,
            torus.cell(0, 0).unwrap(),
            genome,
            energy,
            10.0,
        )
        .unwrap()
    }

    #[test]
    fn founder_added_at_tick_zero_and_refused_after() {
        let mut sim = Simulation::new(&config(8)).unwrap();
        assert!(sim.add_founder(plant_birth(50.0)).is_ok());
        sim.tick();
        assert_eq!(
            sim.add_founder(plant_birth(50.0)),
            Err(SimError::FounderAfterStart { tick: 1 })
        );
        assert_eq!(sim.entities().initial(crate::entities::Kind::Plant), 1);
    }

    #[test]
    fn tick_removes_a_starved_founder_and_records_it() {
        use crate::entities::{DeathCause, Kind};
        let mut sim = Simulation::new(&config(8)).unwrap();
        let id = sim.add_founder(plant_birth(0.0)).unwrap();
        sim.tick();
        assert!(sim.entities().get(id).is_none());
        assert_eq!(sim.entities().living_count(Kind::Plant), 0);
        assert_eq!(sim.entities().deaths(Kind::Plant), 1);
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
            1
        );
        let d = sim.entities().last_deaths();
        assert_eq!((d.len(), d[0].id, d[0].tick), (1, id, 0));
        assert_eq!(sim.entities().check_invariants(), Ok(()));
    }

    #[test]
    fn founders_die_of_old_age_in_the_tick_their_lifespan_ends() {
        use crate::entities::{DeathCause, Kind};
        let mut sim = Simulation::new(&config(8)).unwrap();
        // Trait block 3 with locus sum 1 has mean 1 / 4080. With plant centre 6 the lifespan is floor(3 + 6 / 4080) = 3;
        // max_health is 1 (ADR-0019 D2).
        let lifespans = LifespanRanges {
            plants: 6,
            ..LifespanRanges::default()
        };
        let mut loci = vec![0u8; 128];
        loci[3 * 16] = 1;
        // Max health 100 (slot 4 block mean 1): seasons can turn the cell hostile after tick 0, and a hostile tick
        // costs 2 health (TASK-011). Health 1 would then end the plant of exposure, not of old age.
        for i in 0..16 {
            loci[4 * 16 + i] = 255;
        }
        let genome = crate::genome::Genome::new(1, loci).unwrap();
        // A cell where this genome can grow at tick 0.
        let cell = {
            let w = sim.world();
            let traits = crate::ecology::PlantTraits::from_genome(&genome);
            (0..w.topology.cell_count())
                .map(|i| w.topology.cell_from_index(i).unwrap())
                .find(|&c| {
                    crate::ecology::growth_factors(w.climate.conditions(c), &traits).product() > 0.0
                })
                .expect("a cell where the plant can grow exists")
        };
        let b = crate::entities::Birth::from_genome_in(
            Kind::Plant,
            cell,
            genome,
            50.0,
            100.0,
            &lifespans,
        )
        .unwrap();
        assert_eq!(b.traits.max_lifespan(), 3);
        let id = sim.add_founder(b).unwrap();
        sim.run(2);
        assert!(sim.entities().get(id).is_some());
        sim.tick();
        assert!(sim.entities().get(id).is_none());
        assert_eq!(sim.entities().last_deaths()[0].tick, 2);
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::OldAge),
            1
        );
    }

    #[test]
    fn empty_world_ticks_without_organisms() {
        let mut sim = Simulation::new(&config(8)).unwrap();
        sim.run(20);
        assert_eq!(sim.entities().next_id(), 0);
        assert_eq!(sim.entities().check_invariants(), Ok(()));
    }

    fn populated(seed: u64) -> Simulation {
        let mut sim = Simulation::new(&config(seed)).unwrap();
        sim.populate_initial(&config(seed)).unwrap();
        sim
    }

    #[test]
    fn populate_initial_places_the_configured_founders_with_genome_derived_traits() {
        use crate::entities::Kind;
        let sim = populated(3);
        let e = sim.entities();
        assert_eq!(e.initial(Kind::Plant), 400);
        assert_eq!(e.initial(Kind::Herbivore), 120);
        assert_eq!(e.initial(Kind::Carnivore), 20);
        assert_eq!(e.living_count(Kind::Plant), 400);
        assert_eq!(e.births(Kind::Plant), 0);
        assert_eq!(e.check_invariants(), Ok(()));
        for o in e.living() {
            assert_eq!(
                o.genome().ploidy(),
                if o.kind().is_animal() { 2 } else { 1 }
            );
            let (t, tend) = crate::entities::decode_traits(o.genome(), o.kind()).unwrap();
            assert_eq!(o.traits(), t);
            assert_eq!(o.tendencies(), tend);
            assert_eq!(o.health(), o.traits().max_health());
            assert_eq!(o.energy(), FOUNDER_ENERGY);
            let c = o.cell();
            assert!(c.x() < 64 && c.y() < 48);
        }
    }

    #[test]
    fn populate_initial_is_deterministic_per_seed_and_differs_between_seeds() {
        let a = populated(11);
        let b = populated(11);
        let c = populated(12);
        assert_eq!(a, b);
        assert_ne!(a, c);
        assert_eq!(a.rng_state(), b.rng_state());
    }

    #[test]
    fn populate_initial_is_tick_zero_only() {
        let mut sim = Simulation::new(&config(4)).unwrap();
        sim.tick();
        assert_eq!(
            sim.populate_initial(&config(4)),
            Err(SimError::FounderAfterStart { tick: 1 })
        );
    }

    #[test]
    fn new_does_not_place_founders_so_existing_generator_states_are_unchanged() {
        let sim = Simulation::new(&config(5)).unwrap();
        assert_eq!(sim.entities().living().count(), 0);
        assert_eq!(sim.rng_state(), Rng::from_seed(5).state());
    }

    #[test]
    fn populated_world_keeps_invariants_over_ticks() {
        let mut sim = populated(6);
        sim.run(50);
        assert_eq!(sim.entities().check_invariants(), Ok(()));
    }

    #[test]
    fn mutation_settings_come_from_the_config_genetics_section() {
        let cfg = config(1);
        let m = mutation_settings(&cfg).unwrap();
        assert_eq!(m.rate, cfg.genetics.mutation_rate);
        assert_eq!(u64::from(m.strength), cfg.genetics.mutation_strength);
    }
}

#[cfg(test)]
mod spatial_sync_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::entities::DeathCause;
    use crate::genome::Genome;
    use crate::world::Cell;

    fn config(seed: u64, plants: u64, herbivores: u64, carnivores: u64) -> Config {
        Config::new(
            seed,
            16,
            12,
            Initial {
                plants,
                herbivores,
                carnivores,
            },
        )
        .unwrap()
    }

    fn plant_birth(cell: Cell, energy: f32) -> Birth {
        let genome = Genome::new(1, vec![128; 128]).unwrap();
        Birth::from_genome(Kind::Plant, cell, genome, energy, 10.0).unwrap()
    }

    #[test]
    fn add_founder_is_indexed_at_its_cell() {
        let mut sim = Simulation::new(&config(1, 0, 0, 0)).unwrap();
        let cell = sim.world().topology.cell(3, 4).unwrap();
        let id = sim.add_founder(plant_birth(cell, 50.0)).unwrap();
        assert_eq!(sim.spatial().position(id), Some((cell, Kind::Plant)));
        assert_eq!(sim.spatial().within(cell, 0, None), vec![id]);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn founder_outside_the_torus_is_refused_and_changes_nothing() {
        let big = Torus::new(40, 40).unwrap();
        let mut sim = Simulation::new(&config(1, 0, 0, 0)).unwrap();
        let outside = big.cell(30, 30).unwrap();
        let before = sim.clone();
        assert_eq!(
            sim.add_founder(plant_birth(outside, 50.0)),
            Err(SimError::Spatial(SpatialError::CellOutsideTorus {
                x: 30,
                y: 30
            }))
        );
        assert_eq!(sim, before);
        assert_eq!(sim.entities().initial(Kind::Plant), 0);
    }

    #[test]
    fn populate_initial_indexes_every_founder() {
        let cfg = config(2, 30, 10, 4);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        assert_eq!(sim.spatial().len(), 44);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn starved_founder_is_removed_from_the_index_by_the_deaths_phase() {
        let mut sim = Simulation::new(&config(3, 0, 0, 0)).unwrap();
        // A cell where the plant cannot grow, so it gets no energy from the resource pool (ADR-0012) and starves.
        let cell = {
            let w = sim.world();
            let traits =
                crate::ecology::PlantTraits::from_genome(&Genome::new(1, vec![128; 128]).unwrap());
            (0..w.topology.cell_count())
                .map(|i| w.topology.cell_from_index(i).unwrap())
                .find(|&c| {
                    crate::ecology::growth_factors(w.climate.conditions(c), &traits).product()
                        == 0.0
                })
                .expect("a cell where the plant cannot grow exists")
        };
        let id = sim.add_founder(plant_birth(cell, 0.0)).unwrap();
        sim.tick();
        assert_eq!(sim.spatial().position(id), None);
        assert!(sim.spatial().within(cell, 3, None).is_empty());
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Plant, DeathCause::Starvation),
            1
        );
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn index_stays_in_step_over_a_populated_run() {
        let cfg = config(4, 60, 20, 6);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        for _ in 0..60 {
            sim.tick();
            assert_eq!(sim.check_spatial(), Ok(()));
        }
    }

    #[test]
    fn a_cell_changed_behind_the_index_back_is_reported() {
        let cfg = config(5, 5, 0, 0);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        let id = sim.entities().living().next().unwrap().id();
        let other = sim.world().topology.cell(0, 0).unwrap();
        sim.entities_mut().get_mut(id).unwrap().set_cell(other);
        assert_eq!(sim.check_spatial(), Err(SpatialError::OutOfSync(id)));
    }

    #[test]
    fn restored_simulation_rebuilds_the_index_from_the_organisms() {
        let cfg = config(6, 20, 5, 2);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        sim.run(10);
        let restored = Simulation::from_parts(
            sim.tick_count(),
            sim.rng_state(),
            sim.world().clone(),
            sim.entities().clone(),
            sim.seeding().clone(),
            sim.mating().clone(),
            sim.species().clone(),
            *sim.lifespans(),
        )
        .unwrap();
        assert_eq!(restored.check_spatial(), Ok(()));
        assert_eq!(restored.spatial().len(), sim.spatial().len());
    }
}

/// Animal movement inside the simulation (TASK-013, ADR-0014): index sync, edges, energy, cell sharing, determinism.
#[cfg(test)]
mod movement_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::entities::DeathCause;
    use crate::genome::Genome;

    fn config(seed: u64, w: u64, h: u64, herb: u64, carn: u64) -> Config {
        Config::new(
            seed,
            w,
            h,
            Initial {
                plants: 0,
                herbivores: herb,
                carnivores: carn,
            },
        )
        .unwrap()
    }

    /// Animal genome: slot 0 (speed) and slot 7 (vision) set to the given loci, others 128.
    fn animal_genome(speed_locus: u8, vision_locus: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + i] = speed_locus;
                loci[hap * 128 + 7 * 16 + i] = vision_locus;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn animal(kind: Kind, cell: Cell, genome: Genome, energy: f32) -> Birth {
        let mut b = Birth::from_genome(kind, cell, genome, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    fn cell(sim: &Simulation, x: u32, y: u32) -> Cell {
        sim.world().topology.cell(x, y).unwrap()
    }

    fn snapshot(sim: &Simulation) -> Vec<(u64, Cell, f32)> {
        sim.entities()
            .living()
            .map(|o| (o.id().0, o.cell(), o.energy()))
            .collect()
    }

    #[test]
    fn move_organism_updates_entities_and_index_together() {
        let mut sim = Simulation::new(&config(1, 10, 8, 0, 0)).unwrap();
        let id = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 2, 2),
                animal_genome(128, 128),
                50.0,
            ))
            .unwrap();
        sim.move_organism(id, cell(&sim, 7, 5)).unwrap();
        assert_eq!(sim.entities().get(id).unwrap().cell(), cell(&sim, 7, 5));
        assert_eq!(
            sim.spatial().position(id),
            Some((cell(&sim, 7, 5), Kind::Herbivore))
        );
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn move_organism_refuses_off_torus_dead_and_unknown_without_changes() {
        let mut sim = Simulation::new(&config(1, 10, 8, 0, 0)).unwrap();
        let id = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 2, 2),
                animal_genome(128, 128),
                50.0,
            ))
            .unwrap();
        let before = sim.clone();
        // A cell outside the torus cannot be built through Torus, so compare against a wider torus cell.
        let off = Torus::new(20, 20).unwrap().cell(15, 15).unwrap();
        assert!(matches!(
            sim.move_organism(id, off),
            Err(SimError::Spatial(SpatialError::CellOutsideTorus { .. }))
        ));
        assert_eq!(
            sim.move_organism(OrganismId(999), cell(&sim, 1, 1)),
            Err(SimError::NotAlive {
                id: OrganismId(999)
            })
        );
        assert_eq!(sim, before, "a refused move changes nothing");

        // A dead organism (cause set, not yet removed) cannot move.
        sim.entities_mut().get_mut(id).unwrap().drain_energy(1000.0);
        let dead_state = sim.clone();
        assert_eq!(
            sim.move_organism(id, cell(&sim, 4, 4)),
            Err(SimError::NotAlive { id })
        );
        assert_eq!(sim, dead_state);
    }

    #[test]
    fn two_animals_may_share_a_cell_and_both_are_indexed_there() {
        let mut sim = Simulation::new(&config(1, 10, 8, 0, 0)).unwrap();
        let a = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 0, 0),
                animal_genome(128, 128),
                50.0,
            ))
            .unwrap();
        let b = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 9, 7),
                animal_genome(128, 128),
                50.0,
            ))
            .unwrap();
        // Both move onto (4, 4); no move is refused for occupancy.
        sim.move_organism(a, cell(&sim, 4, 4)).unwrap();
        sim.move_organism(b, cell(&sim, 4, 4)).unwrap();
        let here = sim.spatial().within(cell(&sim, 4, 4), 0, None);
        assert_eq!(here, vec![a, b]);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn a_tick_moves_animals_by_at_most_their_speed_and_charges_the_cost() {
        let mut sim = Simulation::new(&config(5, 32, 24, 0, 0)).unwrap();
        // Speed locus 255 gives speed 4 (4 steps per tick); energy is high enough to survive.
        let g = animal_genome(255, 128);
        let id = sim
            .add_founder(animal(Kind::Herbivore, cell(&sim, 3, 3), g, 90.0))
            .unwrap();
        let traits = sim.entities().get(id).unwrap().traits();
        assert_eq!(traits.speed(), 4.0);
        let start = cell(&sim, 3, 3);
        sim.tick();
        let o = sim.entities().get(id).unwrap();
        assert!(sim.world().topology.distance(start, o.cell()) <= 4);
        // Four steps are always taken: movement 0.2 * 4 * 2 = 1.6, plus base metabolism (TASK-014, ADR-0015) and the
        // thermal cost at the cell after the move (the climate does not change within the tick).
        let temperature = sim.world().climate.conditions(o.cell()).temperature;
        let expected = 90.0
            - movement::move_cost(4, 4.0)
            - feeding::BASE_COST
            - feeding::thermal_cost(temperature);
        assert!(
            (o.energy() - expected).abs() < 1e-4,
            "energy {}",
            o.energy()
        );
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn slow_animals_do_not_move_and_pay_only_metabolism_and_climate() {
        let mut sim = Simulation::new(&config(5, 32, 24, 0, 0)).unwrap();
        // Speed locus 0 gives speed 0: floor(0) = 0 steps.
        let id = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 3, 3),
                animal_genome(0, 128),
                60.0,
            ))
            .unwrap();
        sim.run(10);
        let o = sim.entities().get(id).unwrap();
        assert_eq!(o.cell(), cell(&sim, 3, 3));
        // No movement cost, but base metabolism (0.3 per tick) and a thermal cost of at most 0.8 per tick (TASK-014).
        let e = o.energy();
        assert!(e < 60.0, "energy {e}");
        assert!(e <= 60.0 - 10.0 * feeding::BASE_COST + 1e-3, "energy {e}");
        assert!(
            e >= 60.0 - 10.0 * (feeding::BASE_COST + 0.8) - 1e-3,
            "energy {e}"
        );
    }

    #[test]
    fn moving_organism_starves_through_the_phase_and_leaves_the_index() {
        let mut sim = Simulation::new(&config(5, 32, 24, 0, 0)).unwrap();
        // Speed 4 costs 1.6 per tick; with 1.0 energy the animal starves in its first tick.
        let id = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 3, 3),
                animal_genome(255, 128),
                1.0,
            ))
            .unwrap();
        sim.tick();
        assert!(
            sim.entities().get(id).is_none(),
            "removed by the Deaths phase"
        );
        assert_eq!(sim.entities().deaths(Kind::Carnivore), 1);
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Carnivore, DeathCause::Starvation),
            1
        );
        assert_eq!(sim.spatial().position(id), None);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn founders_populate_and_index_stays_in_sync_over_500_ticks_with_edges() {
        let cfg = config(2024, 24, 16, 60, 10);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        assert_eq!(sim.check_spatial(), Ok(()));
        for _ in 0..500 {
            sim.tick();
            assert_eq!(sim.check_spatial(), Ok(()));
            for o in sim.entities().living() {
                assert_eq!(
                    sim.world().topology.cell(o.cell().x(), o.cell().y()),
                    Some(o.cell())
                );
                let e = o.energy();
                assert!((0.0..=crate::entities::ENERGY_MAX).contains(&e));
            }
        }
        // Founders without food starve: the run is long enough that some have died, and nothing is lost in bookkeeping.
        assert!(sim.entities().deaths(Kind::Herbivore) > 0);
        assert_eq!(sim.entities().check_balance(), Ok(()));
    }

    #[test]
    fn perception_across_the_edge_finds_the_organism_across_the_seam() {
        // A herbivore at x = 0 finds a carnivore at x = W - 1 through the seam (vision 1).
        let sim_cfg = config(1, 12, 6, 0, 0);
        let mut sim = Simulation::new(&sim_cfg).unwrap();
        let a = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 0, 2),
                animal_genome(0, 0),
                50.0,
            ))
            .unwrap();
        let b = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 11, 2),
                animal_genome(0, 0),
                50.0,
            ))
            .unwrap();
        let vision = crate::entities::vision_radius(&animal_genome(0, 0));
        assert_eq!(vision, 1);
        assert_eq!(
            movement::perceive(sim.spatial(), a, cell(&sim, 0, 2), vision),
            vec![b]
        );
    }

    #[test]
    fn same_seed_gives_identical_animal_positions_and_different_seeds_differ() {
        let run = |seed: u64| {
            let cfg = config(seed, 24, 16, 40, 8);
            let mut sim = Simulation::new(&cfg).unwrap();
            sim.populate_initial(&cfg).unwrap();
            sim.run(50);
            (snapshot(&sim), sim.rng_state())
        };
        assert_eq!(run(77), run(77));
        assert_ne!(run(77), run(78));
    }
}

#[cfg(test)]
mod herbivore_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::entities::DeathCause;
    use crate::genome::Genome;
    use crate::movement::Heading;

    fn config(seed: u64, w: u64, h: u64, plants: u64, herbivores: u64, carnivores: u64) -> Config {
        Config::new(
            seed,
            w,
            h,
            Initial {
                plants,
                herbivores,
                carnivores,
            },
        )
        .unwrap()
    }

    /// Genome with slot 0 (speed), slot 6 (caution) and slot 7 (vision) set to the given loci; others 128.
    fn genome(speed: u8, caution: u8, vision: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + i] = speed;
                loci[hap * 128 + 6 * 16 + i] = caution;
                loci[hap * 128 + 7 * 16 + i] = vision;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn birth(kind: Kind, cell: Cell, g: Genome, energy: f32) -> Birth {
        if kind == Kind::Plant {
            // Plants are haploid (ploidy 1); the genome argument is ignored for them.
            let plant_genome = Genome::new(1, vec![128; 128]).unwrap();
            return Birth::from_genome(kind, cell, plant_genome, energy, 10.0).unwrap();
        }
        let mut b = Birth::from_genome(kind, cell, g, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    fn cell(sim: &Simulation, x: u32, y: u32) -> Cell {
        sim.world().topology.cell(x, y).unwrap()
    }

    #[test]
    fn two_herbivores_with_different_caution_act_differently_in_the_same_situation() {
        // Same cell, same energy, a carnivore one cell south and a plant two cells east; both see everything.
        let mut sim = Simulation::new(&config(11, 32, 24, 0, 0, 0)).unwrap();
        let fast_vision = |c: u8| genome(255, c, 255);
        let cautious = sim
            .add_founder(birth(
                Kind::Herbivore,
                cell(&sim, 5, 5),
                fast_vision(230),
                50.0,
            ))
            .unwrap();
        let bold = sim
            .add_founder(birth(
                Kind::Herbivore,
                cell(&sim, 5, 5),
                fast_vision(20),
                50.0,
            ))
            .unwrap();
        sim.add_founder(birth(
            Kind::Carnivore,
            cell(&sim, 5, 6),
            genome(0, 0, 0),
            50.0,
        ))
        .unwrap();
        sim.add_founder(birth(Kind::Plant, cell(&sim, 7, 5), genome(0, 0, 0), 40.0))
            .unwrap();
        // Speed locus 255 gives 4 steps per tick: the cautious one flees north, the bold one reaches the plant.
        let sp = sim.spatial().clone();
        let h_c = sim.entities().get(cautious).unwrap();
        let h_b = sim.entities().get(bold).unwrap();
        let perceived = movement::perceive(
            &sp,
            cautious,
            h_c.cell(),
            crate::entities::vision_radius(h_c.genome()),
        );
        assert_eq!(
            feeding::herbivore_heading(sim.entities(), &sp, h_c, &perceived),
            Heading::Away(cell(&sim, 5, 6))
        );
        let perceived_b = movement::perceive(
            &sp,
            bold,
            h_b.cell(),
            crate::entities::vision_radius(h_b.genome()),
        );
        assert_eq!(
            feeding::herbivore_heading(sim.entities(), &sp, h_b, &perceived_b),
            Heading::Towards(cell(&sim, 7, 5))
        );
        sim.herbivore_phase();
        let c_cell = sim.entities().get(cautious).unwrap().cell();
        let b_cell = sim.entities().get(bold).unwrap().cell();
        assert_ne!(c_cell, b_cell);
        assert_eq!(
            b_cell,
            cell(&sim, 7, 5),
            "the bold herbivore reaches the plant and feeds"
        );
        assert!(sim.entities().get(bold).unwrap().energy() > 40.0 - 10.0);
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn a_herbivore_starves_through_the_phase_when_it_has_no_food() {
        let mut sim = Simulation::new(&config(3, 16, 16, 0, 0, 0)).unwrap();
        let id = sim
            .add_founder(birth(
                Kind::Herbivore,
                cell(&sim, 4, 4),
                genome(0, 0, 0),
                0.2,
            ))
            .unwrap();
        sim.herbivore_phase();
        let o = sim.entities().get(id).unwrap();
        assert_eq!(o.energy(), 0.0);
        assert_eq!(o.cause(), Some(DeathCause::Starvation));
        sim.run(1); // Deaths phase
        assert!(sim.entities().get(id).is_none());
        assert_eq!(sim.check_spatial(), Ok(()));
    }

    #[test]
    fn a_still_herbivore_pays_base_metabolism_and_climate_cost_each_tick() {
        let mut sim = Simulation::new(&config(9, 24, 16, 0, 0, 0)).unwrap();
        let id = sim
            .add_founder(birth(
                Kind::Herbivore,
                cell(&sim, 2, 2),
                genome(0, 0, 0),
                50.0,
            ))
            .unwrap();
        let temperature = sim.world().climate.conditions(cell(&sim, 2, 2)).temperature;
        sim.herbivore_phase();
        let expected = 50.0 - feeding::BASE_COST - feeding::thermal_cost(temperature);
        assert!((sim.entities().get(id).unwrap().energy() - expected).abs() < 1e-5);
    }

    #[test]
    fn colder_cells_cost_a_herbivore_more_energy_than_mild_ones() {
        let mut sim = Simulation::new(&config(21, 24, 16, 0, 0, 0)).unwrap();
        let mut coldest: Option<(f32, Cell)> = None;
        let mut mildest: Option<(f32, Cell)> = None;
        for y in 0..16 {
            for x in 0..24 {
                let c = cell(&sim, x, y);
                let t = sim.world().climate.conditions(c).temperature;
                if coldest.is_none_or(|(best, _)| t < best) {
                    coldest = Some((t, c));
                }
                let dist = (t - 17.5).abs();
                if mildest.is_none_or(|(best, _)| dist < (best - 17.5).abs()) {
                    mildest = Some((t, c));
                }
            }
        }
        let (t_cold, c_cold) = coldest.unwrap();
        let (t_mild, c_mild) = mildest.unwrap();
        assert!(
            t_cold < feeding::COMFORT_LOW,
            "the world has a cold cell ({t_cold})"
        );
        assert!(
            (feeding::COMFORT_LOW..=feeding::COMFORT_HIGH).contains(&t_mild),
            "the world has a comfortable cell ({t_mild})"
        );
        let cold = sim
            .add_founder(birth(Kind::Herbivore, c_cold, genome(0, 0, 0), 50.0))
            .unwrap();
        let mild = sim
            .add_founder(birth(Kind::Herbivore, c_mild, genome(0, 0, 0), 50.0))
            .unwrap();
        sim.herbivore_phase();
        let loss_cold = 50.0 - sim.entities().get(cold).unwrap().energy();
        let loss_mild = 50.0 - sim.entities().get(mild).unwrap().energy();
        assert!(
            loss_cold > loss_mild + 1e-4,
            "cold {loss_cold} mild {loss_mild}"
        );
        assert!((loss_mild - feeding::BASE_COST).abs() < 1e-5);
    }

    #[test]
    fn feeding_never_creates_energy_in_the_herbivore_phase() {
        let mut sim = Simulation::new(&config(77, 16, 12, 0, 0, 0)).unwrap();
        let mut rng = Rng::from_seed(5);
        for k in 0..20u32 {
            let g = crate::genome::random_genome(2, &mut rng).unwrap();
            sim.add_founder(birth(Kind::Herbivore, cell(&sim, k % 16, k % 12), g, 60.0))
                .unwrap();
        }
        for k in 0..30u32 {
            sim.add_founder(birth(
                Kind::Plant,
                cell(&sim, (k * 3) % 16, (k * 5) % 12),
                genome(0, 0, 0),
                30.0,
            ))
            .unwrap();
        }
        let total = |sim: &Simulation| -> f64 {
            sim.entities()
                .living()
                .filter(|o| o.kind() != Kind::Carnivore)
                .map(|o| f64::from(o.energy()))
                .sum()
        };
        for _ in 0..25 {
            let before = total(&sim);
            sim.herbivore_phase();
            assert!(
                total(&sim) <= before + 1e-3,
                "energy grew: {before} -> {}",
                total(&sim)
            );
            // Organisms that reached 0 energy stay indexed until the Deaths phase (ADR-0011), so run it first.
            sim.run_phase(Phase::Deaths);
            assert_eq!(sim.check_spatial(), Ok(()));
        }
    }

    #[test]
    fn same_seed_gives_identical_herbivores_and_different_seeds_differ() {
        let run = |seed: u64| -> Vec<(u64, Cell, f32)> {
            let cfg = config(seed, 32, 24, 300, 60, 0);
            let mut sim = Simulation::new(&cfg).unwrap();
            sim.populate_initial(&cfg).unwrap();
            sim.run(50);
            sim.entities()
                .living()
                .filter(|o| o.kind() == Kind::Herbivore)
                .map(|o| (o.id().0, o.cell(), o.energy()))
                .collect()
        };
        let a = run(4242);
        assert!(!a.is_empty());
        assert_eq!(a, run(4242));
        assert_ne!(a, run(4243));
    }
}

/// Carnivore hunting inside the simulation (TASK-015, ADR-0016): exact energy per tick, starvation, bookkeeping, determinism.
#[cfg(test)]
mod hunting_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::entities::DeathCause;
    use crate::genome::Genome;
    use crate::hunting::{ASSIMILATION_CARNIVORE, ATTACK_COST, BASE_COST_CARNIVORE, MEAL_MAX};

    fn config(seed: u64, w: u64, h: u64, herb: u64, carn: u64) -> Config {
        Config::new(
            seed,
            w,
            h,
            Initial {
                plants: 0,
                herbivores: herb,
                carnivores: carn,
            },
        )
        .unwrap()
    }

    /// Animal genome: slot 0 (speed), slot 1 (strength), slot 6 (caution), slot 7 (vision) set to the loci given.
    fn genome(speed: u8, strength: u8, caution: u8, vision: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + i] = speed;
                loci[hap * 128 + 16 + i] = strength;
                loci[hap * 128 + 6 * 16 + i] = caution;
                loci[hap * 128 + 7 * 16 + i] = vision;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn animal(kind: Kind, cell: Cell, genome: Genome, energy: f32) -> Birth {
        let mut b = Birth::from_genome(kind, cell, genome, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    fn cell(sim: &Simulation, x: u32, y: u32) -> Cell {
        sim.world().topology.cell(x, y).unwrap()
    }

    /// Full state for determinism checks: id, cell, energy bits, cause.
    fn snapshot(sim: &Simulation) -> Vec<(u64, u32, u32, u32, u32, Option<DeathCause>)> {
        sim.entities()
            .living()
            .map(|o| {
                (
                    o.id().0,
                    o.cell().x(),
                    o.cell().y(),
                    o.energy().to_bits(),
                    o.health().to_bits(),
                    o.cause(),
                )
            })
            .collect()
    }

    #[test]
    fn carnivore_pays_attack_and_base_costs_and_gains_at_most_the_prey_energy() {
        let mut kills = 0;
        let mut escapes = 0;
        for seed in 0..200u64 {
            let mut sim = Simulation::new(&config(seed, 16, 16, 0, 0)).unwrap();
            // Speed 0: nobody moves, so the distance is 0 and only the attack and the metabolism are charged.
            let hunter = sim
                .add_founder(animal(
                    Kind::Carnivore,
                    cell(&sim, 4, 4),
                    genome(0, 128, 128, 128),
                    50.0,
                ))
                .unwrap();
            let prey = sim
                .add_founder(animal(
                    Kind::Herbivore,
                    cell(&sim, 4, 4),
                    genome(0, 128, 128, 128),
                    50.0,
                ))
                .unwrap();
            // Herbivores phase first (as in `tick`): it changes only the herbivore's energy here.
            sim.run_phase(Phase::Herbivores);
            let prey_energy = sim.entities().get(prey).unwrap().energy();
            let before = sim.entities().get(hunter).unwrap().energy();
            let temperature = sim.world().climate.conditions(cell(&sim, 4, 4)).temperature;
            sim.run_phase(Phase::Carnivores);

            let p = sim.entities().get(prey).unwrap();
            let killed = p.cause() == Some(DeathCause::Predation);
            let gain = if killed {
                ASSIMILATION_CARNIVORE * prey_energy.min(MEAL_MAX)
            } else {
                assert!(p.is_alive(), "an escape leaves the prey alive");
                assert_eq!(
                    p.energy(),
                    prey_energy,
                    "an escape changes nothing for the prey"
                );
                0.0
            };
            let expected = before + gain
                - ATTACK_COST
                - (BASE_COST_CARNIVORE + crate::feeding::thermal_cost(temperature));
            let after = sim.entities().get(hunter).unwrap().energy();
            assert!(
                (after - expected).abs() < 1e-4,
                "seed {seed}: after {after} expected {expected}"
            );
            assert!(gain <= prey_energy + 1e-6);
            if killed {
                kills += 1;
            } else {
                escapes += 1;
            }
        }
        assert!(kills > 0 && escapes > 0, "kills={kills} escapes={escapes}");
    }

    #[test]
    fn attack_from_across_the_seam_is_resolved_and_outside_reach_is_not() {
        // Adjacent across the west seam (x=0 and x=7 on an 8-wide torus): an attempt is made and paid for.
        let mut sim = Simulation::new(&config(21, 8, 8, 0, 0)).unwrap();
        let hunter = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 0, 4),
                genome(0, 128, 128, 128),
                50.0,
            ))
            .unwrap();
        let prey = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 7, 4),
                genome(0, 128, 128, 128),
                50.0,
            ))
            .unwrap();
        let temperature = sim.world().climate.conditions(cell(&sim, 0, 4)).temperature;
        let before = sim.entities().get(hunter).unwrap().energy();
        sim.run_phase(Phase::Carnivores);
        let after = sim.entities().get(hunter).unwrap().energy();
        // The attempt is resolved: a kill gains 0.8 * min(50, 30) = 24, an escape gains nothing.
        let gain = if sim.entities().get(prey).unwrap().cause() == Some(DeathCause::Predation) {
            ASSIMILATION_CARNIVORE * 50.0f32.min(MEAL_MAX)
        } else {
            0.0
        };
        let expected = before + gain
            - ATTACK_COST
            - (BASE_COST_CARNIVORE + crate::feeding::thermal_cost(temperature));
        assert!(
            (after - expected).abs() < 1e-4,
            "after {after} expected {expected}"
        );

        // Two cells away across the seam (x=6): no attempt, so only the metabolism and the climate are paid.
        let mut sim = Simulation::new(&config(21, 8, 8, 0, 0)).unwrap();
        let hunter = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 0, 4),
                genome(0, 128, 128, 128),
                50.0,
            ))
            .unwrap();
        let prey = sim
            .add_founder(animal(
                Kind::Herbivore,
                cell(&sim, 6, 4),
                genome(0, 128, 128, 128),
                50.0,
            ))
            .unwrap();
        let temperature = sim.world().climate.conditions(cell(&sim, 0, 4)).temperature;
        let before = sim.entities().get(hunter).unwrap().energy();
        sim.run_phase(Phase::Carnivores);
        let after = sim.entities().get(hunter).unwrap().energy();
        let expected = before - (BASE_COST_CARNIVORE + crate::feeding::thermal_cost(temperature));
        assert!(
            (after - expected).abs() < 1e-4,
            "after {after} expected {expected}"
        );
        assert!(sim.entities().get(prey).unwrap().is_alive());
    }

    #[test]
    fn carnivore_without_prey_starves() {
        let mut sim = Simulation::new(&config(5, 16, 16, 0, 0)).unwrap();
        let id = sim
            .add_founder(animal(
                Kind::Carnivore,
                cell(&sim, 3, 3),
                genome(64, 128, 128, 128),
                5.0,
            ))
            .unwrap();
        let mut last = sim.entities().get(id).unwrap().energy();
        let mut ticks = 0;
        while sim.entities().get(id).is_some() {
            sim.tick();
            ticks += 1;
            assert!(ticks <= 20, "still alive after 20 ticks");
            if let Some(o) = sim.entities().get(id) {
                assert!(
                    o.energy() < last,
                    "no gain without prey: {last} -> {}",
                    o.energy()
                );
                last = o.energy();
            }
        }
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Carnivore, DeathCause::Starvation),
            1
        );
        assert_eq!(
            sim.entities()
                .deaths_by_cause(Kind::Carnivore, DeathCause::Predation),
            0
        );
    }

    #[test]
    fn predation_counts_once_in_bookkeeping_over_a_mixed_run() {
        let c = config(31, 24, 24, 60, 12);
        let mut sim = Simulation::new(&c).unwrap();
        sim.populate_initial(&c).unwrap();
        let mut predated: Vec<u64> = Vec::new();
        for _ in 0..150 {
            sim.tick();
            assert_eq!(sim.entities().check_balance(), Ok(()));
            assert_eq!(sim.check_spatial(), Ok(()));
            for d in sim.entities().last_deaths() {
                if d.cause == DeathCause::Predation {
                    predated.push(d.id.0);
                }
            }
        }
        let mut unique = predated.clone();
        unique.sort_unstable();
        unique.dedup();
        assert_eq!(
            unique.len(),
            predated.len(),
            "a prey is recorded as killed once"
        );
        let counted = sim
            .entities()
            .deaths_by_cause(Kind::Herbivore, DeathCause::Predation);
        assert!(counted > 0, "the run must contain kills to be meaningful");
        assert_eq!(counted, predated.len() as u64);
        // The Deaths phase removed the killed herbivores from the store and from the index.
        for id in &predated {
            assert!(sim.entities().get(OrganismId(*id)).is_none());
            assert!(
                sim.spatial().position(OrganismId(*id)).is_none(),
                "dead prey is out of the index"
            );
        }
    }

    #[test]
    fn same_seed_same_hunts_and_different_seeds_differ() {
        let run = |seed: u64| {
            let c = config(seed, 24, 24, 60, 12);
            let mut sim = Simulation::new(&c).unwrap();
            sim.populate_initial(&c).unwrap();
            sim.run(120);
            (
                snapshot(&sim),
                sim.entities()
                    .deaths_by_cause(Kind::Herbivore, DeathCause::Predation),
            )
        };
        let a = run(77);
        assert_eq!(a, run(77));
        assert_ne!(a, run(78));
        assert!(a.1 > 0, "the compared runs contain predation");
    }
}

#[cfg(test)]
mod mating_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::entities::{Birth, Kind};
    use crate::genome::Genome;

    fn config(seed: u64, w: u64, h: u64, plants: u64, herb: u64, carn: u64) -> Config {
        Config::new(
            seed,
            w,
            h,
            Initial {
                plants,
                herbivores: herb,
                carnivores: carn,
            },
        )
        .unwrap()
    }

    /// Diploid genome: every locus `base`, fertility slot (2) at `fert`, lifespan slot (3) at `life`.
    /// Locus 3 gives a lifespan of about 119 ticks (maturity about 23), so animals are mature after a short time.
    fn genome(base: u8, fert: u8, life: u8) -> Genome {
        let mut loci = vec![base; 256];
        for h in 0..2 {
            for i in 2 * 16..3 * 16 {
                loci[h * 128 + i] = fert;
            }
            for i in 3 * 16..4 * 16 {
                loci[h * 128 + i] = life;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn animal(kind: Kind, cell: crate::world::Cell, g: Genome, energy: f32) -> Birth {
        let mut b = Birth::from_genome(kind, cell, g, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    fn cell(sim: &Simulation, x: u32, y: u32) -> crate::world::Cell {
        sim.world().topology.cell(x, y).unwrap()
    }

    #[test]
    fn single_animal_never_produces_offspring() {
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            for seed in 1..=4 {
                let cfg = config(seed, 16, 16, 0, 0, 0);
                let mut sim = Simulation::new(&cfg).unwrap();
                // Full energy, a short lifespan and a high fertility: everything except a partner is in place.
                let c = cell(&sim, 5, 5);
                sim.add_founder(animal(kind, c, genome(128, 255, 3), 100.0))
                    .unwrap();
                sim.run(300);
                assert_eq!(sim.entities().births(kind), 0, "{kind:?} seed {seed}");
                assert_eq!(
                    sim.entities().births(Kind::Herbivore) + sim.entities().births(Kind::Carnivore),
                    0
                );
            }
        }
    }

    #[test]
    fn two_mature_neighbours_can_produce_offspring() {
        // Positive control: the single-animal test is not vacuous. Two identical adjacent herbivores with full
        // fertility mate within a few ticks of maturity.
        let mut total = 0;
        for seed in 1..=4 {
            let cfg = config(seed, 16, 16, 0, 0, 0);
            let mut sim = Simulation::new(&cfg).unwrap();
            let c = cell(&sim, 5, 5);
            sim.add_founder(animal(Kind::Herbivore, c, genome(128, 255, 3), 100.0))
                .unwrap();
            let c2 = cell(&sim, 6, 5);
            sim.add_founder(animal(Kind::Herbivore, c2, genome(128, 255, 3), 100.0))
                .unwrap();
            sim.run(60);
            total += sim.entities().births(Kind::Herbivore);
            assert_eq!(sim.check_spatial(), Ok(()));
            assert_eq!(sim.entities().check_balance(), Ok(()));
        }
        assert!(total > 0, "no offspring in any control run");
    }

    #[test]
    fn mating_run_keeps_bookkeeping_and_index_in_step() {
        let cfg = config(9, 24, 16, 200, 60, 10);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        for _ in 0..500 {
            sim.tick();
            assert_eq!(sim.check_spatial(), Ok(()));
            assert_eq!(sim.entities().check_balance(), Ok(()));
            assert_eq!(sim.entities().check_invariants(), Ok(()));
        }
    }
}

//! Carnivore pursuit, hunting, predation and energy (TASK-015, ADR-0016).
//!
//! Rules, in short:
//! - A carnivore below `SATIATION_CARNIVORE` energy heads for the nearest living herbivore it perceives (vision range,
//!   ADR-0014); otherwise it wanders. Herbivores are the only prey.
//! - It attacks at most once per tick, and only a living herbivore in its own cell or an adjacent one (`HUNT_REACH`).
//!   Target: the nearest such herbivore, ties by lowest id.
//! - The attack succeeds with [`attack_chance`], a function of both animals' speed and strength and of the prey's
//!   caution. One draw from the simulation generator decides each attempt.
//! - A kill gives the prey `DeathCause::Predation` (once; a dead prey is never attacked again) and gains the carnivore
//!   `ASSIMILATION_CARNIVORE` times at most `MEAL_MAX` of the prey's energy, so never more than the prey had.
//! - Every attempt costs `ATTACK_COST`; every living carnivore pays movement, `BASE_COST_CARNIVORE` and the thermal cost.
//!
//! Attacks are resolved one after another in ascending attacker id order against the current state, so several
//! carnivores in reach of one herbivore give exactly one kill (the first to roll successfully). Nothing here looks at
//! population counts. All constants are uncalibrated (TASK-018, TASK-027).

use crate::entities::{
    DeathCause, Entities, Kind, Organism, OrganismId, Traits, SPEED_RANGE, STRENGTH_RANGE,
};
use crate::feeding;
use crate::movement::{self, Heading};
use crate::rng::Rng;
use crate::spatial::SpatialIndex;
use crate::world::{Cell, Torus};

/// Chebyshev radius around a carnivore within which it may attack (0 = own cell, 1 = adjacent cells).
pub const HUNT_REACH: u32 = 1;
/// Carnivores at or above this energy neither pursue nor attack (stateless handling time, ADR-0016).
pub const SATIATION_CARNIVORE: f32 = 95.0;
/// Largest amount of prey energy a kill can turn into energy for the carnivore.
pub const MEAL_MAX: f32 = 30.0;
/// Fraction of the taken prey energy that the carnivore gains.
pub const ASSIMILATION_CARNIVORE: f32 = 0.8;
/// Energy paid by a carnivore for every attack attempt, successful or not.
pub const ATTACK_COST: f32 = 0.5;
/// Energy paid every tick by a carnivore, whatever it does.
pub const BASE_COST_CARNIVORE: f32 = 0.4;
/// Attack chance when attacker and prey are equal in speed, strength and caution (before the caution term).
pub const P_BASE: f64 = 0.5;
/// Weight of the speed difference (attacker minus prey, normalised by the speed range).
pub const W_SPEED: f64 = 0.3;
/// Weight of the strength difference (attacker minus prey, normalised by the strength range).
pub const W_STRENGTH: f64 = 0.2;
/// Weight of the prey's caution in `[0, 1]`.
pub const W_CAUTION: f64 = 0.3;
/// TASK-027 trial T1 (ADR-0028): crowding dilutes predation; 0 = off (chosen default, trials 0.5 and 0.1 did not help).
/// Each living herbivore in the attacker's own cell beyond
/// the first divides the attack chance by `1 + DILUTION` more (see [`dilution_factor`]). Local: only the carnivore's
/// own cell is read, which it perceives.
pub const DILUTION: f64 = 0.0;
/// Lowest attack chance: even a hopeless attack sometimes succeeds.
pub const P_MIN: f64 = 0.05;
/// Highest attack chance: even an easy prey sometimes escapes.
pub const P_MAX: f64 = 0.9;

/// Probability that an attack by a carnivore with `attacker` traits on a herbivore with `prey` traits and
/// `prey_caution` succeeds (ADR-0016):
/// `clamp(P_BASE + W_SPEED * dv/range_v + W_STRENGTH * ds/range_s - W_CAUTION * caution, P_MIN, P_MAX)`, where `dv` and
/// `ds` are the attacker's minus the prey's speed and strength. Pure; increasing in the attacker's traits and decreasing
/// in the prey's. Never draws random numbers.
pub fn attack_chance(attacker: &Traits, prey: &Traits, prey_caution: f32) -> f64 {
    let speed_range = SPEED_RANGE.1 - SPEED_RANGE.0;
    let strength_range = STRENGTH_RANGE.1 - STRENGTH_RANGE.0;
    let dv = f64::from(attacker.speed() - prey.speed()) / speed_range;
    let ds = f64::from(attacker.strength() - prey.strength()) / strength_range;
    let p = P_BASE + W_SPEED * dv + W_STRENGTH * ds - W_CAUTION * f64::from(prey_caution);
    p.clamp(P_MIN, P_MAX)
}

/// Factor applied to [`attack_chance`] when `herbivores_in_own_cell` living herbivores share the attacker's cell
/// (TASK-027 trial T1, ADR-0028): `1 / (1 + DILUTION * (n - 1))` for `n >= 1`, and 1 for `n <= 1`. Pure, non-increasing
/// in `n`, in `(0, 1]`; reads the attacker's own cell only.
pub fn dilution_factor(herbivores_in_own_cell: usize) -> f64 {
    let others = herbivores_in_own_cell.saturating_sub(1) as f64;
    1.0 / (1.0 + DILUTION * others)
}

/// Energy a carnivore pays in one tick: movement (ADR-0014), base metabolism and the thermal cost at the cell it
/// stands on (`temperature` in degrees C, ADR-0015). Pure.
pub fn carnivore_costs(distance: u32, speed: f32, temperature: f32) -> f32 {
    movement::move_cost(distance, speed) + BASE_COST_CARNIVORE + feeding::thermal_cost(temperature)
}

/// Nearest living herbivore among `ids` (ascending) to `from`, by Chebyshev torus distance; ties go to the lowest id.
fn nearest_living_herbivore(
    entities: &Entities,
    torus: &Torus,
    from: Cell,
    ids: &[OrganismId],
) -> Option<OrganismId> {
    let mut best: Option<(u32, OrganismId)> = None;
    for &id in ids {
        let Some(o) = entities
            .get(id)
            .filter(|o| o.is_alive() && o.kind() == Kind::Herbivore)
        else {
            continue;
        };
        let d = torus.distance(from, o.cell());
        if best.is_none_or(|(bd, _)| d < bd) {
            best = Some((d, id));
        }
    }
    best.map(|(_, id)| id)
}

/// Heading of a carnivore this tick (ADR-0016): `Towards` the nearest living herbivore among `perceived` (ascending by id,
/// as [`movement::perceive`] returns it) while below `SATIATION_CARNIVORE`; otherwise `Wander`. Draws no random numbers.
pub fn carnivore_heading(
    entities: &Entities,
    spatial: &SpatialIndex,
    o: &Organism,
    perceived: &[OrganismId],
) -> Heading {
    if o.energy() >= SATIATION_CARNIVORE {
        return Heading::Wander;
    }
    match nearest_living_herbivore(entities, &spatial.torus(), o.cell(), perceived) {
        Some(prey) => Heading::Towards(entities.get(prey).expect("found above").cell()),
        None => Heading::Wander,
    }
}

/// Result of one attack by a carnivore.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum AttackOutcome {
    /// No attempt was made: the carnivore is dead, satiated, or has no living herbivore in reach. No cost is paid.
    NoAttempt,
    /// The prey died of predation; the carnivore gained `gained` energy.
    Kill { prey: OrganismId, gained: f32 },
    /// The attempt failed; the prey is unchanged. The attempt still costs `ATTACK_COST` (charged by the caller).
    Escape { prey: OrganismId },
}

/// One attack attempt by carnivore `id` (ADR-0016). Picks the nearest living herbivore in reach (`HUNT_REACH`), rolls
/// once with [`attack_chance`] from `rng`, and applies a kill or an escape. Does not charge the attack cost: the phase
/// charges [`ATTACK_COST`] for every outcome other than [`AttackOutcome::NoAttempt`].
pub fn attack(
    entities: &mut Entities,
    spatial: &SpatialIndex,
    rng: &mut Rng,
    id: OrganismId,
) -> AttackOutcome {
    let (cell, energy, traits) = match entities.get(id) {
        Some(o) if o.is_alive() && o.kind() == Kind::Carnivore => {
            (o.cell(), o.energy(), o.traits())
        }
        _ => return AttackOutcome::NoAttempt,
    };
    if energy >= SATIATION_CARNIVORE {
        return AttackOutcome::NoAttempt;
    }
    let torus = spatial.torus();
    let in_reach = spatial.within(cell, HUNT_REACH, Some(Kind::Herbivore));
    let Some(prey_id) = nearest_living_herbivore(entities, &torus, cell, &in_reach) else {
        return AttackOutcome::NoAttempt;
    };
    let prey = entities.get(prey_id).expect("found above");
    let prey_traits = prey.traits();
    let prey_caution = prey.tendencies().map_or(0.0, |t| t.caution());
    let prey_health = prey.health();
    let prey_energy = prey.energy();

    let crowd = spatial
        .within(cell, 0, Some(Kind::Herbivore))
        .into_iter()
        .filter(|&h| entities.get(h).is_some_and(|o| o.is_alive()))
        .count();
    let chance = attack_chance(&traits, &prey_traits, prey_caution) * dilution_factor(crowd);
    if !rng.chance(chance) {
        return AttackOutcome::Escape { prey: prey_id };
    }
    // A living prey has energy above 0 and health above 0; `damage` sets the cause only if none is set yet.
    let gained = ASSIMILATION_CARNIVORE * prey_energy.min(MEAL_MAX);
    if let Some(prey) = entities.get_mut(prey_id) {
        prey.damage(prey_health, DeathCause::Predation);
    }
    if let Some(hunter) = entities.get_mut(id) {
        hunter.add_energy(gained);
    }
    AttackOutcome::Kill {
        prey: prey_id,
        gained,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::{Birth, Kind};
    use crate::genome::Genome;
    use crate::world::Torus;

    fn torus(w: u32, h: u32) -> Torus {
        Torus::new(w, h).unwrap()
    }

    fn c(t: &Torus, x: u32, y: u32) -> Cell {
        t.cell(x, y).unwrap()
    }

    /// Animal genome with slot 0 (speed), slot 1 (strength), slot 6 (caution) and slot 7 (vision) set to the loci given;
    /// the other slots are 128.
    fn genome(speed: u8, strength: u8, caution: u8, vision: u8) -> Genome {
        let mut loci = vec![128u8; 2 * 128];
        for hap in 0..2 {
            for i in 0..16 {
                loci[hap * 128 + i] = speed;
                loci[hap * 128 + 16 + i] = strength;
                loci[hap * 128 + 6 * 16 + i] = caution;
                loci[hap * 128 + 7 * 16 + i] = vision;
            }
        }
        Genome::new(2, loci).unwrap()
    }

    fn animal(kind: Kind, cell: Cell, g: Genome, energy: f32) -> Birth {
        let mut b = Birth::from_genome(kind, cell, g, energy, 0.0).unwrap();
        b.health = b.traits.max_health();
        b
    }

    /// Entities and index with the given organisms placed; returns their ids in insertion order.
    fn world(t: &Torus, births: Vec<Birth>) -> (Entities, SpatialIndex, Vec<OrganismId>) {
        let mut ents = Entities::new();
        let mut sp = SpatialIndex::new(*t);
        let mut ids = Vec::new();
        for b in births {
            let (cell, kind) = (b.cell, b.kind);
            let id = ents.spawn_founder(b).unwrap();
            sp.insert(id, cell, kind).unwrap();
            ids.push(id);
        }
        (ents, sp, ids)
    }

    /// Traits of a genome, for the pure formula tests.
    fn traits_of(g: Genome) -> Traits {
        crate::entities::decode_traits(&g, Kind::Herbivore)
            .unwrap()
            .0
    }

    fn mid() -> Genome {
        genome(128, 128, 128, 128)
    }

    #[test]
    fn constants_are_the_documented_values() {
        assert_eq!(HUNT_REACH, 1);
        // Above the carnivore mating threshold of 90 (ADR-0017, ADR-0019 D3): a carnivore must be able to reach it.
        assert_eq!(SATIATION_CARNIVORE, 95.0);
        assert_eq!(MEAL_MAX, 30.0);
        assert_eq!(ASSIMILATION_CARNIVORE, 0.8);
        assert_eq!(ATTACK_COST, 0.5);
        assert_eq!(BASE_COST_CARNIVORE, 0.4);
    }

    #[test]
    fn dilution_factor_is_one_alone_and_does_not_rise_with_crowding() {
        assert_eq!(dilution_factor(0), 1.0);
        assert_eq!(dilution_factor(1), 1.0);
        let mut prev = 1.0;
        for n in 2..=50 {
            let f = dilution_factor(n);
            assert!(f > 0.0 && f <= prev, "n={n}: {f} above {prev}");
            // Strictly falling when the trial is switched on (`DILUTION > 0`); the default 0 gives exactly 1.
            assert!(DILUTION == 0.0 || f < prev, "n={n}: {f} not below {prev}");
            prev = f;
        }
        assert!((dilution_factor(3) - 1.0 / (1.0 + 2.0 * DILUTION)).abs() < 1e-12);
    }

    #[test]
    fn attack_chance_stays_in_bounds_and_is_monotone() {
        let steps = [0u8, 64, 128, 192, 255];
        for &sa in &steps {
            for &ra in &steps {
                for &sp in &steps {
                    for &rp in &steps {
                        let att = traits_of(genome(sa, ra, 0, 128));
                        let prey = traits_of(genome(sp, rp, 0, 128));
                        for caution in [0.0f32, 0.5, 1.0] {
                            let p = attack_chance(&att, &prey, caution);
                            assert!((P_MIN..=P_MAX).contains(&p), "p={p}");
                        }
                    }
                }
            }
        }
        // More attacker speed (and strength) is never worse; more prey speed, strength or caution is never better.
        let prey = traits_of(mid());
        let weak = traits_of(genome(0, 0, 0, 128));
        let strong = traits_of(genome(255, 255, 0, 128));
        assert!(attack_chance(&strong, &prey, 0.5) >= attack_chance(&weak, &prey, 0.5));
        assert!(attack_chance(&weak, &prey, 0.0) >= attack_chance(&weak, &prey, 1.0));
        assert!(attack_chance(&strong, &weak, 0.0) >= attack_chance(&weak, &weak, 0.0));
        // Equal animals at mid traits with no caution: exactly the base chance.
        let p0 = attack_chance(&prey, &prey, 0.0);
        assert!((p0 - P_BASE).abs() < 1e-9, "p0={p0}");
    }

    #[test]
    fn many_attacks_give_kills_and_escapes() {
        let t = torus(6, 6);
        let mut kills = 0u32;
        let mut escapes = 0u32;
        for seed in 0..2000u64 {
            let (mut ents, sp, ids) = world(
                &t,
                vec![
                    animal(Kind::Carnivore, c(&t, 2, 2), mid(), 40.0),
                    animal(Kind::Herbivore, c(&t, 2, 2), mid(), 50.0),
                ],
            );
            let mut rng = Rng::from_seed(seed);
            match attack(&mut ents, &sp, &mut rng, ids[0]) {
                AttackOutcome::Kill { .. } => kills += 1,
                AttackOutcome::Escape { .. } => escapes += 1,
                AttackOutcome::NoAttempt => panic!("in reach, must attempt"),
            }
        }
        assert!(kills > 0 && escapes > 0, "kills={kills} escapes={escapes}");
        // The kill fraction is near the formula's chance for these two animals (loose bound for 2000 draws).
        let prey_caution = crate::entities::decode_traits(&mid(), Kind::Herbivore)
            .unwrap()
            .1
            .unwrap()
            .caution();
        let expected = attack_chance(&traits_of(mid()), &traits_of(mid()), prey_caution);
        let frac = f64::from(kills) / 2000.0;
        assert!(
            (frac - expected).abs() < 0.05,
            "frac={frac} expected={expected}"
        );
    }

    #[test]
    fn fast_strong_attackers_kill_more() {
        let t = torus(6, 6);
        let count = |att: Genome, prey: Genome| {
            let mut kills = 0u32;
            for seed in 0..2000u64 {
                let (mut ents, sp, ids) = world(
                    &t,
                    vec![
                        animal(Kind::Carnivore, c(&t, 1, 1), att.clone(), 40.0),
                        animal(Kind::Herbivore, c(&t, 1, 1), prey.clone(), 50.0),
                    ],
                );
                let mut rng = Rng::from_seed(seed);
                if matches!(
                    attack(&mut ents, &sp, &mut rng, ids[0]),
                    AttackOutcome::Kill { .. }
                ) {
                    kills += 1;
                }
            }
            kills
        };
        let fast_strong = count(genome(255, 255, 0, 128), genome(0, 0, 255, 128));
        let slow_weak = count(genome(0, 0, 0, 128), genome(255, 255, 0, 128));
        // Formula: fast/strong against slow/weak/cautious prey is 0.7; slow/weak against fast/strong prey is clamped to P_MIN.
        assert!(
            fast_strong > slow_weak + 1000,
            "fast={fast_strong} slow={slow_weak}"
        );
        assert!(
            fast_strong > 1300 && slow_weak < 200,
            "fast={fast_strong} slow={slow_weak}"
        );
    }

    #[test]
    fn kill_marks_prey_once_as_predation() {
        let t = torus(6, 6);
        // Find a seed that kills with this pair, then check the record.
        for seed in 0..100u64 {
            let (mut ents, sp, ids) = world(
                &t,
                vec![
                    animal(Kind::Carnivore, c(&t, 3, 3), mid(), 40.0),
                    animal(Kind::Herbivore, c(&t, 3, 3), mid(), 50.0),
                ],
            );
            let mut rng = Rng::from_seed(seed);
            if let AttackOutcome::Kill { prey, .. } = attack(&mut ents, &sp, &mut rng, ids[0]) {
                assert_eq!(prey, ids[1]);
                let p = ents.get(prey).unwrap();
                assert!(!p.is_alive());
                assert_eq!(p.cause(), Some(DeathCause::Predation));
                assert_eq!(p.health(), 0.0);
                return;
            }
        }
        panic!("no kill in 100 seeds");
    }

    #[test]
    fn second_attacker_finds_no_second_kill() {
        let t = torus(6, 6);
        for seed in 0..100u64 {
            let (mut ents, sp, ids) = world(
                &t,
                vec![
                    animal(Kind::Carnivore, c(&t, 2, 2), mid(), 40.0),
                    animal(Kind::Carnivore, c(&t, 2, 2), mid(), 40.0),
                    animal(Kind::Herbivore, c(&t, 2, 2), mid(), 50.0),
                ],
            );
            let mut rng = Rng::from_seed(seed);
            let first = attack(&mut ents, &sp, &mut rng, ids[0]);
            if !matches!(first, AttackOutcome::Kill { .. }) {
                continue;
            }
            let before = ents.get(ids[1]).unwrap().energy();
            let second = attack(&mut ents, &sp, &mut rng, ids[1]);
            assert_eq!(second, AttackOutcome::NoAttempt);
            assert_eq!(ents.get(ids[1]).unwrap().energy(), before);
            assert_eq!(
                ents.deaths_by_cause(Kind::Herbivore, DeathCause::Predation),
                0,
                "not yet removed"
            );
            return;
        }
        panic!("no kill in 100 seeds");
    }

    #[test]
    fn gain_never_exceeds_prey_energy() {
        let t = torus(6, 6);
        for &prey_energy in &[0.5f32, 2.0, 10.0, 30.0, 37.5, 60.0, 100.0] {
            let mut checked = 0;
            for seed in 0..200u64 {
                let (mut ents, sp, ids) = world(
                    &t,
                    vec![
                        animal(Kind::Carnivore, c(&t, 0, 0), mid(), 10.0),
                        animal(Kind::Herbivore, c(&t, 0, 0), mid(), prey_energy),
                    ],
                );
                let mut rng = Rng::from_seed(seed);
                if let AttackOutcome::Kill { gained, .. } = attack(&mut ents, &sp, &mut rng, ids[0])
                {
                    assert!(gained <= prey_energy, "gained {gained} from {prey_energy}");
                    assert!(
                        (gained - ASSIMILATION_CARNIVORE * prey_energy.min(MEAL_MAX)).abs() < 1e-5
                    );
                    checked += 1;
                }
            }
            assert!(checked > 0, "no kill for prey energy {prey_energy}");
        }
    }

    #[test]
    fn attacks_reach_only_same_or_adjacent_cells_including_seams() {
        let t = torus(8, 8);
        // Prey at distance 2 (across the west seam: x=0 and x=6 on an 8-wide torus is distance 2): never attacked.
        let (mut ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 0, 4), mid(), 40.0),
                animal(Kind::Herbivore, c(&t, 6, 4), mid(), 50.0),
            ],
        );
        let mut rng = Rng::from_seed(1);
        let before = rng.state();
        assert_eq!(
            attack(&mut ents, &sp, &mut rng, ids[0]),
            AttackOutcome::NoAttempt
        );
        assert_eq!(rng.state(), before, "no attempt, no draw");
        // Prey one cell away across the seam (x=7 is adjacent to x=0): attacked.
        let (mut ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 0, 4), mid(), 40.0),
                animal(Kind::Herbivore, c(&t, 7, 3), mid(), 50.0),
            ],
        );
        let mut rng = Rng::from_seed(1);
        assert_ne!(
            attack(&mut ents, &sp, &mut rng, ids[0]),
            AttackOutcome::NoAttempt
        );
        // Same cell: attacked.
        let (mut ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 5, 5), mid(), 40.0),
                animal(Kind::Herbivore, c(&t, 5, 5), mid(), 50.0),
            ],
        );
        let mut rng = Rng::from_seed(2);
        assert_ne!(
            attack(&mut ents, &sp, &mut rng, ids[0]),
            AttackOutcome::NoAttempt
        );
    }

    #[test]
    fn attack_draws_exactly_one_random_number_when_it_attempts() {
        let t = torus(6, 6);
        let (mut ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 1, 1), mid(), 40.0),
                animal(Kind::Herbivore, c(&t, 1, 1), mid(), 50.0),
            ],
        );
        let mut rng = Rng::from_seed(42);
        let mut reference = Rng::from_seed(42);
        // One attempt = one `chance` call = one `next_f64` draw (the 64-bit generator advances once per draw).
        let _ = reference.next_f64();
        let outcome = attack(&mut ents, &sp, &mut rng, ids[0]);
        assert_ne!(outcome, AttackOutcome::NoAttempt);
        assert_eq!(rng.state(), reference.state());
    }

    #[test]
    fn satiated_carnivore_neither_pursues_nor_attacks() {
        let t = torus(8, 8);
        let (ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 2, 2), mid(), SATIATION_CARNIVORE),
                animal(Kind::Herbivore, c(&t, 2, 2), mid(), 50.0),
                animal(Kind::Herbivore, c(&t, 4, 2), mid(), 50.0),
            ],
        );
        let perceived = movement::perceive(&sp, ids[0], c(&t, 2, 2), 3);
        let o = ents.get(ids[0]).unwrap();
        assert_eq!(
            carnivore_heading(&ents, &sp, o, &perceived),
            Heading::Wander
        );
        let mut ents = ents;
        let mut rng = Rng::from_seed(3);
        assert_eq!(
            attack(&mut ents, &sp, &mut rng, ids[0]),
            AttackOutcome::NoAttempt
        );
    }

    #[test]
    fn pursuit_uses_vision_range() {
        let t = torus(20, 20);
        // Vision 1 for both genomes below: vision locus 0 gives radius VISION_MIN (1).
        let short = genome(128, 128, 0, 0);
        let vision = crate::entities::vision_radius(&short);
        assert_eq!(vision, 1);
        let (ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 5, 5), short.clone(), 40.0),
                animal(Kind::Herbivore, c(&t, 7, 5), mid(), 50.0), // distance 2: out of sight
            ],
        );
        let perceived = movement::perceive(&sp, ids[0], c(&t, 5, 5), vision);
        let o = ents.get(ids[0]).unwrap();
        assert_eq!(
            carnivore_heading(&ents, &sp, o, &perceived),
            Heading::Wander
        );

        let (ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 5, 5), short, 40.0),
                animal(Kind::Herbivore, c(&t, 6, 5), mid(), 50.0), // distance 1: in sight
            ],
        );
        let perceived = movement::perceive(&sp, ids[0], c(&t, 5, 5), vision);
        let o = ents.get(ids[0]).unwrap();
        assert_eq!(
            carnivore_heading(&ents, &sp, o, &perceived),
            Heading::Towards(c(&t, 6, 5))
        );
    }

    #[test]
    fn dead_prey_still_in_the_index_is_not_a_target() {
        let t = torus(8, 8);
        let (mut ents, sp, ids) = world(
            &t,
            vec![
                animal(Kind::Carnivore, c(&t, 2, 2), mid(), 40.0),
                animal(Kind::Herbivore, c(&t, 2, 2), mid(), 50.0),
            ],
        );
        ents.get_mut(ids[1])
            .unwrap()
            .damage(1000.0, DeathCause::Injury);
        let mut rng = Rng::from_seed(4);
        assert_eq!(
            attack(&mut ents, &sp, &mut rng, ids[0]),
            AttackOutcome::NoAttempt
        );
    }

    #[test]
    fn carnivore_costs_add_movement_base_and_thermal() {
        // Comfortable temperature: movement plus base only.
        let c0 = carnivore_costs(2, 4.0, 20.0);
        assert!((c0 - (movement::move_cost(2, 4.0) + BASE_COST_CARNIVORE)).abs() < 1e-6);
        // Cold: the thermal term of ADR-0015 is added.
        let c1 = carnivore_costs(0, 0.0, -5.0);
        assert!((c1 - (BASE_COST_CARNIVORE + feeding::thermal_cost(-5.0))).abs() < 1e-6);
        assert!(c1 > BASE_COST_CARNIVORE);
    }
}

//! Torus geometry: wrapping, shortest displacement, distance and radius neighbourhoods.
//!
//! Decisions are recorded in `docs/decisions/ADR-0007-torus-topology-and-distance.md`.
//! Summary:
//! - The world is a `width x height` grid whose left/right and top/bottom edges are joined.
//! - Distance is Chebyshev on the torus: `max(|dx|, |dy|)`, each axis taking the shortest wrapped displacement.
//! - Tie rule: on an even axis, a displacement of exactly half the axis length is `+L/2` in both directions.
//! - Coordinates: `y` grows southwards (row index); `Direction::North` is `dy = -1`.
//! - Only integer arithmetic is used, so results are deterministic.

use std::fmt;

/// Error returned when a torus is requested with a zero-sized axis.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TopologyError {
    /// `width` or `height` was zero; both must be at least 1.
    ZeroSize { width: u32, height: u32 },
}

impl fmt::Display for TopologyError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TopologyError::ZeroSize { width, height } => {
                write!(f, "torus size must be at least 1x1, got {width}x{height}")
            }
        }
    }
}

impl std::error::Error for TopologyError {}

/// An arbitrary integer position, possibly negative or several worlds away. Not yet wrapped.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Coord {
    pub x: i64,
    pub y: i64,
}

/// A signed displacement between two positions, in cells.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Offset {
    pub dx: i64,
    pub dy: i64,
}

/// One of the eight compass steps. Each has a fixed [`Offset`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Direction {
    North,
    NorthEast,
    East,
    SouthEast,
    South,
    SouthWest,
    West,
    NorthWest,
}

impl Direction {
    /// All eight directions in a fixed order (clockwise from north).
    pub const ALL: [Direction; 8] = [
        Direction::North,
        Direction::NorthEast,
        Direction::East,
        Direction::SouthEast,
        Direction::South,
        Direction::SouthWest,
        Direction::West,
        Direction::NorthWest,
    ];

    /// The single-cell step for this direction.
    pub const fn offset(self) -> Offset {
        let (dx, dy) = match self {
            Direction::North => (0, -1),
            Direction::NorthEast => (1, -1),
            Direction::East => (1, 0),
            Direction::SouthEast => (1, 1),
            Direction::South => (0, 1),
            Direction::SouthWest => (-1, 1),
            Direction::West => (-1, 0),
            Direction::NorthWest => (-1, -1),
        };
        Offset { dx, dy }
    }
}

/// A wrapped position on the torus. Always `x < width` and `y < height`.
///
/// Fields are private so that a `Cell` can only be created through [`Torus`], which keeps the invariant.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Cell {
    x: u32,
    y: u32,
}

impl Cell {
    pub fn x(self) -> u32 {
        self.x
    }

    pub fn y(self) -> u32 {
        self.y
    }
}

/// A finite grid whose opposite edges are joined. Both axes have length at least 1.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Torus {
    width: u32,
    height: u32,
}

/// Shortest signed displacement from `a` to `b` on one axis of length `len` (`a`, `b` < `len`).
///
/// Result lies in `(-len/2, len/2]`. On an even axis, an exact half-way displacement is `+len/2`.
fn axis_delta(a: u32, b: u32, len: u32) -> i64 {
    let l = i64::from(len);
    let d = (i64::from(b) - i64::from(a)).rem_euclid(l);
    if 2 * d > l {
        d - l
    } else {
        d
    }
}

/// Distinct wrapped values of `[centre - radius, centre + radius]` on an axis of length `len`, ascending.
/// Covers the whole axis when the range is at least as long as the axis.
fn axis_window(centre: u32, radius: u32, len: u32) -> Vec<u32> {
    let l = i64::from(len);
    let r = i64::from(radius);
    if 2 * r + 1 >= l {
        return (0..len).collect();
    }
    let c = i64::from(centre);
    // The range has fewer than `len` values, so the residues are distinct.
    let mut values: Vec<u32> = (c - r..=c + r).map(|v| v.rem_euclid(l) as u32).collect();
    values.sort_unstable();
    values
}

impl Torus {
    /// Creates a `width x height` torus. Both must be at least 1.
    pub fn new(width: u32, height: u32) -> Result<Torus, TopologyError> {
        if width == 0 || height == 0 {
            return Err(TopologyError::ZeroSize { width, height });
        }
        Ok(Torus { width, height })
    }

    pub fn width(&self) -> u32 {
        self.width
    }

    pub fn height(&self) -> u32 {
        self.height
    }

    /// Number of cells, `width * height`.
    pub fn cell_count(&self) -> usize {
        self.width as usize * self.height as usize
    }

    /// The wrapped cell for `(x, y)` if it is inside the grid, otherwise `None`.
    pub fn cell(&self, x: u32, y: u32) -> Option<Cell> {
        (x < self.width && y < self.height).then_some(Cell { x, y })
    }

    /// Maps any integer coordinate to the cell it lies on (`rem_euclid` on each axis).
    pub fn wrap(&self, c: Coord) -> Cell {
        // rem_euclid by a positive value below 2^32 yields a value in 0..width, which fits u32.
        let x = c.x.rem_euclid(i64::from(self.width)) as u32;
        let y = c.y.rem_euclid(i64::from(self.height)) as u32;
        Cell { x, y }
    }

    /// Moves `cell` by `offset` and wraps the result.
    pub fn translate(&self, cell: Cell, offset: Offset) -> Cell {
        self.wrap(Coord {
            x: i64::from(cell.x) + offset.dx,
            y: i64::from(cell.y) + offset.dy,
        })
    }

    /// Moves `cell` one step in `direction`, wrapping across an edge if needed.
    pub fn step(&self, cell: Cell, direction: Direction) -> Cell {
        self.translate(cell, direction.offset())
    }

    /// Row-major index `y * width + x`, in `0..cell_count()`.
    pub fn index(&self, cell: Cell) -> usize {
        cell.y as usize * self.width as usize + cell.x as usize
    }

    /// Inverse of [`Torus::index`]. `None` if `index >= cell_count()`.
    pub fn cell_from_index(&self, index: usize) -> Option<Cell> {
        if index >= self.cell_count() {
            return None;
        }
        let w = self.width as usize;
        Some(Cell {
            x: (index % w) as u32,
            y: (index / w) as u32,
        })
    }

    /// Shortest displacement from `from` to `to`, per axis, possibly across an edge.
    /// See the tie rule in the module documentation.
    pub fn delta(&self, from: Cell, to: Cell) -> Offset {
        Offset {
            dx: axis_delta(from.x, to.x, self.width),
            dy: axis_delta(from.y, to.y, self.height),
        }
    }

    /// Chebyshev distance on the torus: `max(|dx|, |dy|)` using [`Torus::delta`].
    pub fn distance(&self, from: Cell, to: Cell) -> u32 {
        let d = self.delta(from, to);
        // Each magnitude is at most half an axis length, so it fits u32.
        d.dx.unsigned_abs().max(d.dy.unsigned_abs()) as u32
    }

    /// All cells at distance `<= radius` from `centre`, the centre included, each exactly once,
    /// in ascending [`Torus::index`] order. Any radius is valid; radii at or beyond the world size
    /// return every cell.
    pub fn neighbours(&self, centre: Cell, radius: u32) -> Vec<Cell> {
        let xs = axis_window(centre.x, radius, self.width);
        let ys = axis_window(centre.y, radius, self.height);
        let mut out = Vec::with_capacity(xs.len() * ys.len());
        for &y in &ys {
            for &x in &xs {
                out.push(Cell { x, y });
            }
        }
        out
    }
}

impl Torus {
    /// Canonical encoding of the torus size (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Torus { width, height } = self;
        enc.u32(*width);
        enc.u32(*height);
    }

    /// Reads width and height and validates them with [`Torus::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Torus, crate::checkpoint::CheckpointError> {
        let width = dec.u32()?;
        let height = dec.u32()?;
        Torus::new(width, height).map_err(|e| crate::checkpoint::invalid_because("torus", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn torus(w: u32, h: u32) -> Torus {
        Torus::new(w, h).expect("valid size")
    }

    fn cell(t: &Torus, x: u32, y: u32) -> Cell {
        t.cell(x, y).expect("in range")
    }

    fn c(x: i64, y: i64) -> Coord {
        Coord { x, y }
    }

    /// Deterministic LCG for seeded random tests (same constants as Knuth's MMIX-style LCG).
    struct Lcg(u64);

    impl Lcg {
        fn next(&mut self) -> u64 {
            self.0 = self
                .0
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            self.0 >> 11
        }

        fn below(&mut self, n: u64) -> u64 {
            self.next() % n
        }
    }

    // ---- construction and errors ----

    #[test]
    fn zero_size_is_error() {
        assert_eq!(
            Torus::new(0, 5),
            Err(TopologyError::ZeroSize {
                width: 0,
                height: 5
            })
        );
        assert_eq!(
            Torus::new(5, 0),
            Err(TopologyError::ZeroSize {
                width: 5,
                height: 0
            })
        );
        assert!(Torus::new(1, 1).is_ok());
        assert!(TopologyError::ZeroSize {
            width: 0,
            height: 5
        }
        .to_string()
        .contains("0x5"));
    }

    #[test]
    fn cell_constructor_rejects_out_of_range() {
        let t = torus(4, 3);
        assert!(t.cell(3, 2).is_some());
        assert!(t.cell(4, 0).is_none());
        assert!(t.cell(0, 3).is_none());
    }

    // ---- wrapping ----

    #[test]
    fn wrap_negative_and_zero() {
        let t = torus(10, 7);
        assert_eq!(t.wrap(c(0, 0)), cell(&t, 0, 0));
        assert_eq!(t.wrap(c(-1, -1)), cell(&t, 9, 6));
        assert_eq!(t.wrap(c(-10, -7)), cell(&t, 0, 0));
        assert_eq!(t.wrap(c(-11, -8)), cell(&t, 9, 6));
    }

    #[test]
    fn wrap_on_edges_and_just_past_them() {
        let t = torus(10, 7);
        assert_eq!(t.wrap(c(9, 6)), cell(&t, 9, 6)); // last cell, no wrap
        assert_eq!(t.wrap(c(10, 7)), cell(&t, 0, 0)); // one past the far edge
        assert_eq!(t.wrap(c(10, 6)), cell(&t, 0, 6));
        assert_eq!(t.wrap(c(9, 7)), cell(&t, 9, 0));
    }

    #[test]
    fn wrap_far_outside_world() {
        let t = torus(10, 7);
        // -3W - 1 on x and -3H - 1 on y: multiple wraps in the negative direction.
        assert_eq!(t.wrap(c(-31, -22)), cell(&t, 9, 6));
        // 5W + W - 1 = 59 on x; 4H + 0 = 28 on y.
        assert_eq!(t.wrap(c(59, 28)), cell(&t, 9, 0));
        // 1_000_003 mod 10 = 3 and -1_000_003 mod 7 = 3 (since 1_000_003 = 7*142857 + 4).
        assert_eq!(t.wrap(c(1_000_003, -1_000_003)), cell(&t, 3, 3));
    }

    #[test]
    fn wrap_i64_extremes_do_not_overflow() {
        let t = torus(10, 7);
        let lo = t.wrap(c(i64::MIN, i64::MIN));
        let hi = t.wrap(c(i64::MAX, i64::MAX));
        assert_eq!(lo.x(), i64::MIN.rem_euclid(10) as u32);
        assert_eq!(lo.y(), i64::MIN.rem_euclid(7) as u32);
        assert_eq!(hi.x(), i64::MAX.rem_euclid(10) as u32);
        assert_eq!(hi.y(), i64::MAX.rem_euclid(7) as u32);
        assert!(lo.x() < 10 && lo.y() < 7 && hi.x() < 10 && hi.y() < 7);
        // Largest world on both axes: no overflow in the wrap arithmetic.
        let big = torus(u32::MAX, u32::MAX);
        let b = big.wrap(c(i64::MIN, i64::MAX));
        assert_eq!(b.x(), i64::MIN.rem_euclid(i64::from(u32::MAX)) as u32);
        assert_eq!(b.y(), i64::MAX.rem_euclid(i64::from(u32::MAX)) as u32);
    }

    #[test]
    fn wrap_identity_for_valid_cells() {
        let t = torus(6, 5);
        for y in 0..5 {
            for x in 0..6 {
                let k = cell(&t, x, y);
                assert_eq!(t.wrap(c(i64::from(x), i64::from(y))), k);
            }
        }
    }

    // ---- edges and corners ----

    #[test]
    fn step_east_from_right_edge_wraps_to_left() {
        let t = torus(5, 4);
        assert_eq!(t.step(cell(&t, 4, 2), Direction::East), cell(&t, 0, 2));
        assert_eq!(t.step(cell(&t, 4, 2), Direction::SouthEast), cell(&t, 0, 3));
        assert_eq!(t.step(cell(&t, 4, 2), Direction::NorthEast), cell(&t, 0, 1));
    }

    #[test]
    fn step_west_from_left_edge_wraps_to_right() {
        let t = torus(5, 4);
        assert_eq!(t.step(cell(&t, 0, 2), Direction::West), cell(&t, 4, 2));
        assert_eq!(t.step(cell(&t, 0, 2), Direction::SouthWest), cell(&t, 4, 3));
        assert_eq!(t.step(cell(&t, 0, 2), Direction::NorthWest), cell(&t, 4, 1));
    }

    #[test]
    fn step_south_and_north_wrap_on_height() {
        let t = torus(5, 4);
        assert_eq!(t.step(cell(&t, 1, 3), Direction::South), cell(&t, 1, 0));
        assert_eq!(t.step(cell(&t, 1, 3), Direction::SouthEast), cell(&t, 2, 0));
        assert_eq!(t.step(cell(&t, 1, 0), Direction::North), cell(&t, 1, 3));
        assert_eq!(t.step(cell(&t, 1, 0), Direction::NorthWest), cell(&t, 0, 3));
    }

    #[test]
    fn step_all_four_corners_wrap_diagonally() {
        let t = torus(5, 4);
        // top-left corner going NW, top-right going NE, bottom-left going SW, bottom-right going SE
        assert_eq!(t.step(cell(&t, 0, 0), Direction::NorthWest), cell(&t, 4, 3));
        assert_eq!(t.step(cell(&t, 4, 0), Direction::NorthEast), cell(&t, 0, 3));
        assert_eq!(t.step(cell(&t, 0, 3), Direction::SouthWest), cell(&t, 4, 0));
        assert_eq!(t.step(cell(&t, 4, 3), Direction::SouthEast), cell(&t, 0, 0));
    }

    #[test]
    fn axis_steps_cycle_back_to_start_after_one_lap() {
        let t = torus(5, 4);
        let start = cell(&t, 2, 1);
        let mut at = start;
        for _ in 0..5 {
            at = t.step(at, Direction::East);
        }
        assert_eq!(at, start, "five East steps on width 5");
        at = start;
        for _ in 0..4 {
            at = t.step(at, Direction::South);
        }
        assert_eq!(at, start, "four South steps on height 4");
    }

    #[test]
    fn step_equals_translate_by_offset_for_all_directions() {
        let t = torus(5, 4);
        for y in 0..4 {
            for x in 0..5 {
                let k = cell(&t, x, y);
                for d in Direction::ALL {
                    let o = d.offset();
                    assert_eq!(t.step(k, d), t.translate(k, o));
                    assert!(o.dx.abs() <= 1 && o.dy.abs() <= 1 && (o.dx, o.dy) != (0, 0));
                }
            }
        }
    }

    // ---- shortest displacement and distance ----

    #[test]
    fn delta_takes_short_way_across_edge() {
        let t = torus(10, 10);
        assert_eq!(
            t.delta(cell(&t, 0, 0), cell(&t, 9, 0)),
            Offset { dx: -1, dy: 0 }
        );
        assert_eq!(
            t.delta(cell(&t, 1, 0), cell(&t, 8, 0)),
            Offset { dx: -3, dy: 0 }
        );
        assert_eq!(
            t.delta(cell(&t, 0, 9), cell(&t, 0, 0)),
            Offset { dx: 0, dy: 1 }
        );
        assert_eq!(
            t.delta(cell(&t, 0, 1), cell(&t, 0, 8)),
            Offset { dx: 0, dy: -3 }
        );
    }

    #[test]
    fn delta_tie_on_even_axis_is_positive() {
        let t = torus(10, 8);
        assert_eq!(
            t.delta(cell(&t, 0, 0), cell(&t, 5, 0)),
            Offset { dx: 5, dy: 0 }
        );
        assert_eq!(
            t.delta(cell(&t, 5, 0), cell(&t, 0, 0)),
            Offset { dx: 5, dy: 0 }
        );
        assert_eq!(
            t.delta(cell(&t, 0, 0), cell(&t, 0, 4)),
            Offset { dx: 0, dy: 4 }
        );
        assert_eq!(
            t.delta(cell(&t, 0, 4), cell(&t, 0, 0)),
            Offset { dx: 0, dy: 4 }
        );
    }

    #[test]
    fn delta_odd_axis_has_no_tie() {
        // On odd axes the half-way point does not exist: displacements are -3..=3 on width 7.
        for a in 0..7 {
            for b in 0..7 {
                let d = axis_delta(a, b, 7);
                assert!((-3..=3).contains(&d), "a={a} b={b} d={d}");
                assert_eq!((a as i64 + d).rem_euclid(7), b as i64);
            }
        }
    }

    #[test]
    fn distance_is_symmetric_and_chebyshev() {
        let t = torus(10, 8);
        let a = cell(&t, 1, 1);
        let b = cell(&t, 4, 3); // dx=3, dy=2
        assert_eq!(t.distance(a, b), 3);
        assert_eq!(t.distance(b, a), 3);
        // across the x edge: 0 -> 9 is 1 step, y 0 -> 6 is 2 steps (8-6 = 2)
        assert_eq!(t.distance(cell(&t, 0, 0), cell(&t, 9, 6)), 2);
        assert_eq!(t.distance(cell(&t, 0, 0), cell(&t, 0, 0)), 0);
    }

    #[test]
    fn distance_bounded_by_half_world() {
        let t = torus(9, 6);
        for ay in 0..6 {
            for ax in 0..9 {
                for by in 0..6 {
                    for bx in 0..9 {
                        let d = t.distance(cell(&t, ax, ay), cell(&t, bx, by));
                        // floor(9/2)=4 on x and floor(6/2)=3 on y, so the Chebyshev maximum is 4.
                        assert!(d <= 4, "d={d}");
                    }
                }
            }
        }
        // The maximum is reached, e.g. half a world away on x.
        let far = t.distance(cell(&t, 0, 0), cell(&t, 4, 3));
        assert_eq!(far, 4);
    }

    #[test]
    fn distance_triangle_inequality_seeded() {
        let mut rng = Lcg(0x5EED_0004);
        for _ in 0..2000 {
            let w = 1 + rng.below(50) as u32;
            let h = 1 + rng.below(50) as u32;
            let t = torus(w, h);
            let pick = |rng: &mut Lcg| {
                let x = rng.below(u64::from(w)) as u32;
                let y = rng.below(u64::from(h)) as u32;
                cell(&t, x, y)
            };
            let a = pick(&mut rng);
            let b = pick(&mut rng);
            let m = pick(&mut rng);
            assert!(t.distance(a, b) <= t.distance(a, m) + t.distance(m, b));
            assert_eq!(t.distance(a, b), t.distance(b, a));
        }
    }

    #[test]
    fn delta_antisymmetric_except_tie() {
        let mut rng = Lcg(0xD17A_0004);
        for _ in 0..2000 {
            let w = 1 + rng.below(50) as u32;
            let h = 1 + rng.below(50) as u32;
            let t = torus(w, h);
            let a = cell(
                &t,
                rng.below(u64::from(w)) as u32,
                rng.below(u64::from(h)) as u32,
            );
            let b = cell(
                &t,
                rng.below(u64::from(w)) as u32,
                rng.below(u64::from(h)) as u32,
            );
            let ab = t.delta(a, b);
            let ba = t.delta(b, a);
            // Axis-wise: equal to the negative unless that axis is an exact half-way tie.
            let x_tie = w.is_multiple_of(2) && ab.dx.abs() == i64::from(w / 2);
            let y_tie = h.is_multiple_of(2) && ab.dy.abs() == i64::from(h / 2);
            if !x_tie {
                assert_eq!(ab.dx, -ba.dx);
            } else {
                assert_eq!(ab.dx, i64::from(w / 2));
                assert_eq!(ba.dx, i64::from(w / 2));
            }
            if !y_tie {
                assert_eq!(ab.dy, -ba.dy);
            } else {
                assert_eq!(ab.dy, i64::from(h / 2));
                assert_eq!(ba.dy, i64::from(h / 2));
            }
        }
    }

    #[test]
    fn index_round_trips() {
        let t = torus(7, 3);
        for i in 0..t.cell_count() {
            let k = t.cell_from_index(i).expect("in range");
            assert_eq!(t.index(k), i);
        }
        assert!(t.cell_from_index(t.cell_count()).is_none());
    }

    // ---- degenerate worlds ----

    #[test]
    fn one_by_one_world_everything_is_the_same_cell() {
        let t = torus(1, 1);
        let only = cell(&t, 0, 0);
        assert_eq!(t.cell_count(), 1);
        assert_eq!(t.wrap(c(-7, 12)), only);
        assert_eq!(t.wrap(c(i64::MIN, i64::MAX)), only);
        for d in Direction::ALL {
            assert_eq!(t.step(only, d), only);
        }
        assert_eq!(t.delta(only, only), Offset { dx: 0, dy: 0 });
        assert_eq!(t.distance(only, only), 0);
        for r in [0u32, 1, 2, 100, u32::MAX] {
            assert_eq!(t.neighbours(only, r), vec![only], "radius {r}");
        }
    }

    #[test]
    fn one_by_n_and_n_by_one_wrap() {
        let row = torus(1, 5); // 1 column, 5 rows
        for y in 0..5 {
            let k = cell(&row, 0, y);
            assert_eq!(row.step(k, Direction::East), k);
            assert_eq!(row.step(k, Direction::West), k);
            assert_eq!(row.step(k, Direction::South), cell(&row, 0, (y + 1) % 5));
            assert_eq!(row.step(k, Direction::North), cell(&row, 0, (y + 4) % 5));
        }
        assert_eq!(row.distance(cell(&row, 0, 0), cell(&row, 0, 3)), 2); // 0->3 is -2 across the edge
        let all: Vec<Cell> = (0..5).map(|y| cell(&row, 0, y)).collect();
        assert_eq!(row.neighbours(cell(&row, 0, 0), 2), all);
        assert_eq!(row.neighbours(cell(&row, 0, 0), 1).len(), 3);

        let col = torus(5, 1); // 5 columns, 1 row
        for x in 0..5 {
            let k = cell(&col, x, 0);
            assert_eq!(col.step(k, Direction::North), k);
            assert_eq!(col.step(k, Direction::South), k);
            assert_eq!(col.step(k, Direction::West), cell(&col, (x + 4) % 5, 0));
            assert_eq!(col.step(k, Direction::East), cell(&col, (x + 1) % 5, 0));
        }
        assert_eq!(col.distance(cell(&col, 0, 0), cell(&col, 4, 0)), 1);
        let all: Vec<Cell> = (0..5).map(|x| cell(&col, x, 0)).collect();
        assert_eq!(col.neighbours(cell(&col, 2, 0), 9), all);
    }

    // ---- non-square worlds ----

    #[test]
    fn non_square_world_axes_wrap_independently() {
        let t = torus(7, 3);
        assert_eq!(t.wrap(c(7, 3)), cell(&t, 0, 0));
        assert_eq!(t.wrap(c(-1, -1)), cell(&t, 6, 2));
        assert_eq!(t.wrap(c(14, -4)), cell(&t, 0, 2));
        assert_eq!(t.step(cell(&t, 6, 0), Direction::NorthEast), cell(&t, 0, 2));
        assert_eq!(t.step(cell(&t, 3, 2), Direction::South), cell(&t, 3, 0));
        assert_eq!(t.cell_count(), 21);
    }

    // ---- neighbourhoods ----

    #[test]
    fn neighbours_radius_zero_is_centre() {
        let t = torus(5, 4);
        for y in 0..4 {
            for x in 0..5 {
                let k = cell(&t, x, y);
                assert_eq!(t.neighbours(k, 0), vec![k]);
            }
        }
    }

    #[test]
    fn neighbours_have_no_duplicates_and_are_ascending() {
        let t = torus(6, 5);
        for r in 0..=8 {
            let n = t.neighbours(cell(&t, 0, 0), r);
            let idx: Vec<usize> = n.iter().map(|k| t.index(*k)).collect();
            assert!(
                idx.windows(2).all(|w| w[0] < w[1]),
                "radius {r} not ascending"
            );
            let mut sorted = idx.clone();
            sorted.dedup();
            assert_eq!(sorted.len(), idx.len(), "radius {r} has duplicates");
        }
    }

    #[test]
    fn neighbours_radius_larger_than_world_visits_each_cell_once() {
        let t = torus(3, 4);
        let all: Vec<Cell> = (0..t.cell_count())
            .map(|i| t.cell_from_index(i).unwrap())
            .collect();
        assert_eq!(t.neighbours(cell(&t, 1, 2), 100), all);
        assert_eq!(t.neighbours(cell(&t, 0, 0), u32::MAX), all);
        assert_eq!(t.neighbours(cell(&t, 2, 3), 100).len(), 12);
    }

    #[test]
    fn neighbours_cross_all_four_edges() {
        let t = torus(5, 5);
        let n = t.neighbours(cell(&t, 0, 0), 1);
        assert_eq!(n.len(), 9);
        for (x, y) in [
            (4, 4),
            (0, 4),
            (1, 4),
            (4, 0),
            (4, 1),
            (0, 1),
            (1, 0),
            (0, 0),
            (1, 1),
        ] {
            assert!(n.contains(&cell(&t, x, y)), "missing ({x},{y})");
        }
        // Edge-only check: west wrap, east wrap, north wrap, south wrap at radius 1 from a middle cell on each edge.
        assert!(t.neighbours(cell(&t, 0, 2), 1).contains(&cell(&t, 4, 2)));
        assert!(t.neighbours(cell(&t, 4, 2), 1).contains(&cell(&t, 0, 2)));
        assert!(t.neighbours(cell(&t, 2, 0), 1).contains(&cell(&t, 2, 4)));
        assert!(t.neighbours(cell(&t, 2, 4), 1).contains(&cell(&t, 2, 0)));
    }

    #[test]
    fn neighbours_match_brute_force() {
        for w in 1..=7u32 {
            for h in 1..=7u32 {
                let t = torus(w, h);
                for ci in 0..t.cell_count() {
                    let centre = t.cell_from_index(ci).unwrap();
                    for r in 0..=10u32 {
                        let got = t.neighbours(centre, r);
                        let mut got_idx: Vec<usize> = got.iter().map(|k| t.index(*k)).collect();
                        let len_before = got_idx.len();
                        got_idx.sort_unstable();
                        got_idx.dedup();
                        assert_eq!(got_idx.len(), len_before, "duplicates {w}x{h} r={r}");
                        let want: Vec<usize> = (0..t.cell_count())
                            .filter(|&i| t.distance(centre, t.cell_from_index(i).unwrap()) <= r)
                            .collect();
                        assert_eq!(got_idx, want, "{w}x{h} centre={ci} r={r}");
                    }
                }
            }
        }
    }

    #[test]
    fn neighbours_radius_two_on_large_world_has_25_cells() {
        let t = torus(64, 48);
        assert_eq!(t.neighbours(cell(&t, 0, 0), 2).len(), 25);
        assert_eq!(t.neighbours(cell(&t, 63, 47), 2).len(), 25);
    }
}

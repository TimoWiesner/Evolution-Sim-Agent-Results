//! Base climate: latitude zones, biomes, base temperature and base precipitation for every cell.
//!
//! Decisions and the torus compromise are in `docs/decisions/ADR-0009-climate-zones-and-biomes.md`.
//! Summary: latitude depends only on the row, `phi(y) = 90 * cos^2(pi * (y + 0.5) / H)` degrees, so the middle row is
//! the equator and the top/bottom seam is polar. The biome follows from latitude only. A seeded, torus-periodic
//! regional variation (integer wave numbers on `x/W` and `y/H`) is added to temperature and precipitation.
//! The variation uses its own generator (`seed XOR CLIMATE_SALT`), so the simulation random stream is not touched.
//!
//! Seasons and weather (TASK-007, ADR-0010) are layered on top of the base field. The base fields
//! (`CellClimate`) never change. [`Climate::advance`] moves the weather one tick (Climate phase, draws from the
//! simulation generator), and [`Climate::conditions`] / [`Climate::seasonal_conditions`] give the current values.
//! Seasonal values depend only on the tick and the configured year length; the weather is a periodic value-noise
//! lattice whose state is part of the simulation state.

use std::f64::consts::PI;
use std::fmt;

use crate::rng::Rng;
use crate::world::{Cell, Torus};

/// Salt XORed with the configuration seed to seed the climate variation (ADR-0009).
pub const CLIMATE_SALT: u64 = 0x434C_494D_4154_4500;

/// Largest temperature offset of the regional variation, in degrees Celsius (ADR-0009).
pub const VARIATION_TEMPERATURE_AMPLITUDE: f64 = 2.5;

/// Largest relative precipitation change of the regional variation (ADR-0009).
pub const VARIATION_PRECIPITATION_AMPLITUDE: f64 = 0.08;

/// Documented bounds of the temperature in degrees Celsius: the base runs from -22 (pole) to 28 (equator),
/// and the variation adds at most 2.5 in either direction.
pub const TEMPERATURE_BOUNDS: (f32, f32) = (-25.0, 31.0);

/// Weather persistence per tick: `n <- clamp(RHO * n + SIGMA * u)`, `u` uniform in `-1..1` (ADR-0010).
pub const WEATHER_RHO: f64 = 0.9;
/// Weather step size per tick (ADR-0010).
pub const WEATHER_SIGMA: f64 = 0.3;
/// Spacing of the weather lattice in cells (ADR-0010).
pub const WEATHER_CELL: u32 = 8;
/// Seasonal temperature swing at the poles in degrees C; scales with latitude as `20 * phi / 90` (ADR-0010).
pub const SEASON_TEMPERATURE_SWING: f64 = 20.0;
/// Seasonal precipitation swing: multiplier `1 + 0.2 * sin` (ADR-0010).
pub const SEASON_PRECIPITATION_SWING: f64 = 0.2;
/// Temperature change in degrees C for a weather value of 1 at amplitude 1 (ADR-0010).
pub const WEATHER_TEMPERATURE_SCALE: f64 = 10.0;
/// Documented bounds of the current temperature in degrees C (ADR-0010); values are clamped to them.
pub const TEMPERATURE_RANGE: (f32, f32) = (-70.0, 50.0);
/// Documented bounds of the current precipitation in mm per year (ADR-0010); values are clamped to them.
pub const PRECIPITATION_RANGE: (f32, f32) = (0.0, 5000.0);

/// Time-dependence settings, copied from the configuration `climate` section.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ClimateParams {
    /// Ticks in one year (at least 1).
    pub season_length: u64,
    /// Weather strength in `0..=1`; 0 switches the weather off (no draws, no weather term).
    pub weather_amplitude: f64,
}

/// Current temperature and precipitation of one cell.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Conditions {
    /// Degrees Celsius, within [`TEMPERATURE_RANGE`].
    pub temperature: f32,
    /// Millimetres per year, within [`PRECIPITATION_RANGE`].
    pub precipitation: f32,
}

/// Error when climate state is built or restored from invalid parts.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum ClimateError {
    /// `season_length` is 0.
    ZeroYear,
    /// `weather_amplitude` is not a finite number in `0..=1`.
    Amplitude(f64),
    /// The node list does not match the weather lattice.
    NodeCount { expected: usize, found: usize },
    /// A weather node is not a finite number in `-1..=1`.
    NodeValue(f64),
}

impl fmt::Display for ClimateError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ClimateError::ZeroYear => write!(f, "climate.season_length must be at least 1"),
            ClimateError::Amplitude(v) => {
                write!(f, "climate.weather_amplitude must be in 0..=1, got {v}")
            }
            ClimateError::NodeCount { expected, found } => {
                write!(f, "weather lattice needs {expected} nodes, got {found}")
            }
            ClimateError::NodeValue(v) => write!(f, "weather node {v} is outside -1..=1"),
        }
    }
}

impl std::error::Error for ClimateError {}

/// Size of the weather lattice: one node per `WEATHER_CELL` cells, rounded up, on each axis.
fn lattice_dims(torus: &Torus) -> (u32, u32) {
    (
        torus.width().div_ceil(WEATHER_CELL),
        torus.height().div_ceil(WEATHER_CELL),
    )
}

/// Lattice position of cell coordinate `c` on an axis of `size` cells and `nodes` lattice nodes: the two wrapped
/// node indices and the smoothstep weight of the second. The position is `(c + 0.5) * nodes / size`, computed in
/// exact integers, so `c` and `c + size` give bit-equal results (periodicity on the torus).
fn axis_weights(c: u32, size: u32, nodes: u32) -> (usize, usize, f64) {
    let den = 2 * u64::from(size);
    let num = (2 * u64::from(c) + 1) * u64::from(nodes);
    let n = u64::from(nodes);
    let i0 = (num / den) % n;
    let i1 = (i0 + 1) % n;
    let f = (num % den) as f64 / den as f64;
    (i0 as usize, i1 as usize, f * f * (3.0 - 2.0 * f))
}

/// Latitude zones from cold to hot (ADR-0009). `Ord` follows the declaration order, which is also the rank.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub enum Biome {
    Polar,
    Tundra,
    Temperate,
    Dry,
    Tropical,
}

impl Biome {
    /// Position from cold (0) to hot (4).
    pub fn rank(self) -> u8 {
        self as u8
    }

    /// Lower-case name used in text and JSON output.
    pub fn name(self) -> &'static str {
        match self {
            Biome::Polar => "polar",
            Biome::Tundra => "tundra",
            Biome::Temperate => "temperate",
            Biome::Dry => "dry",
            Biome::Tropical => "tropical",
        }
    }

    /// One character used in the text map.
    pub fn glyph(self) -> char {
        match self {
            Biome::Polar => 'P',
            Biome::Tundra => 'U',
            Biome::Temperate => 'T',
            Biome::Dry => 'D',
            Biome::Tropical => 'R',
        }
    }
}

/// The base climate of one cell.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CellClimate {
    /// Latitude in degrees, `0..=90` (0 is the equator).
    pub latitude: f32,
    pub biome: Biome,
    /// Base temperature in degrees Celsius.
    pub temperature: f32,
    /// Base precipitation in millimetres per year.
    pub precipitation: f32,
}

/// One term of the regional variation: `weight * cos(2 pi (i x / W + j y / H) + phase)`.
/// The weights of all terms sum to 1, so the variation stays in `-1..=1`.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct WaveTerm {
    pub i: u32,
    pub j: u32,
    pub phase: f64,
    pub weight: f64,
}

/// The climate of a whole torus: the base field, the seasonal and weather settings, and the weather state.
/// Everything except `cells` is simulation state (checkpoint, TASK-022).
#[derive(Clone, Debug, PartialEq)]
pub struct Climate {
    torus: Torus,
    cells: Vec<CellClimate>,
    terms: Vec<WaveTerm>,
    params: ClimateParams,
    /// Weather nodes in `-1..=1`, row-major, `lattice_dims` many.
    nodes: Vec<f64>,
    /// The tick whose Climate phase was applied last; the weather nodes are the state after it.
    weather_tick: u64,
}

/// Latitude in degrees of row `y` on a torus of height `height`: `90 * cos^2(pi * (y + 0.5) / height)`.
/// The function is periodic in `y` with period `height`, so the top/bottom seam has no jump.
pub fn latitude_of_row(height: u32, y: u32) -> f64 {
    let u = (f64::from(y) + 0.5) / f64::from(height);
    let c = (PI * u).cos();
    90.0 * c * c
}

/// Base temperature in degrees Celsius at latitude `lat_deg`: `28 - 50 * (1 - cos(phi))`.
pub fn base_temperature(lat_deg: f64) -> f64 {
    28.0 - 50.0 * (1.0 - lat_deg.to_radians().cos())
}

/// Base precipitation in mm per year at latitude `lat_deg` (ADR-0009): a tropical maximum, a dry dip near 28
/// degrees and a temperate maximum near 50 degrees.
pub fn base_precipitation(lat_deg: f64) -> f64 {
    let a = (lat_deg / 14.0).powi(2);
    let b = ((lat_deg - 50.0) / 14.0).powi(2);
    150.0 + 1600.0 * (-a).exp() + 700.0 * (-b).exp()
}

/// Biome of latitude `lat_deg`, with half-open thresholds (ADR-0009).
pub fn biome_for_latitude(lat_deg: f64) -> Biome {
    if lat_deg < 20.0 {
        Biome::Tropical
    } else if lat_deg < 35.0 {
        Biome::Dry
    } else if lat_deg < 55.0 {
        Biome::Temperate
    } else if lat_deg < 70.0 {
        Biome::Tundra
    } else {
        Biome::Polar
    }
}

/// Draws the regional variation terms (3 to 5 terms, wave numbers in `0..=3`, not both zero) from `rng`.
fn draw_terms(rng: &mut Rng) -> Vec<WaveTerm> {
    let count = 3 + rng.next_below(3) as usize;
    let mut raw = Vec::with_capacity(count);
    for _ in 0..count {
        let (i, j) = loop {
            let i = rng.next_below(4) as u32;
            let j = rng.next_below(4) as u32;
            if i != 0 || j != 0 {
                break (i, j);
            }
        };
        let phase = rng.next_f64() * 2.0 * PI;
        // A weight in (0, 1]: zero would make the term vanish without changing the stream length.
        let r = 1.0 - rng.next_f64();
        raw.push((i, j, phase, r));
    }
    let total: f64 = raw.iter().map(|t| t.3).sum();
    raw.into_iter()
        .map(|(i, j, phase, r)| WaveTerm {
            i,
            j,
            phase,
            weight: r / total,
        })
        .collect()
}

/// The regional variation at cell `(x, y)`, in `-1..=1`. Periodic in `x` with period `W` and in `y` with period `H`.
fn variation(torus: &Torus, terms: &[WaveTerm], x: u32, y: u32) -> f64 {
    let fx = f64::from(x) / f64::from(torus.width());
    let fy = f64::from(y) / f64::from(torus.height());
    terms
        .iter()
        .map(|t| {
            t.weight * (2.0 * PI * (f64::from(t.i) * fx + f64::from(t.j) * fy) + t.phase).cos()
        })
        .sum()
}

/// Computes every cell from the terms, in row-major index order.
fn fill(torus: &Torus, terms: &[WaveTerm]) -> Vec<CellClimate> {
    let mut cells = Vec::with_capacity(torus.cell_count());
    for index in 0..torus.cell_count() {
        let cell = torus
            .cell_from_index(index)
            .expect("index is below cell_count");
        let v = variation(torus, terms, cell.x(), cell.y());
        let lat = latitude_of_row(torus.height(), cell.y());
        let temperature = base_temperature(lat) + VARIATION_TEMPERATURE_AMPLITUDE * v;
        let precipitation = base_precipitation(lat) * (1.0 + VARIATION_PRECIPITATION_AMPLITUDE * v);
        cells.push(CellClimate {
            latitude: lat as f32,
            biome: biome_for_latitude(lat),
            temperature: temperature as f32,
            precipitation: precipitation as f32,
        });
    }
    cells
}

impl Climate {
    /// Creates the climate of `torus` from `seed` (the configuration seed). Draws the variation terms from a
    /// generator seeded with `seed XOR CLIMATE_SALT`. Weather nodes start at 0 and nothing is drawn for them.
    pub fn new(torus: &Torus, seed: u64, params: ClimateParams) -> Result<Climate, ClimateError> {
        let mut rng = Rng::from_seed(seed ^ CLIMATE_SALT);
        let terms = draw_terms(&mut rng);
        let (lx, ly) = lattice_dims(torus);
        let nodes = vec![0.0; lx as usize * ly as usize];
        Climate::from_parts(*torus, terms, params, nodes, 0)
    }

    /// Rebuilds a climate from its parts (checkpoint restore). The base cells are recomputed from the terms.
    /// Fails if the parameters or the weather nodes are invalid.
    pub fn from_parts(
        torus: Torus,
        terms: Vec<WaveTerm>,
        params: ClimateParams,
        nodes: Vec<f64>,
        weather_tick: u64,
    ) -> Result<Climate, ClimateError> {
        if params.season_length == 0 {
            return Err(ClimateError::ZeroYear);
        }
        let a = params.weather_amplitude;
        if !a.is_finite() || !(0.0..=1.0).contains(&a) {
            return Err(ClimateError::Amplitude(a));
        }
        let (lx, ly) = lattice_dims(&torus);
        let expected = lx as usize * ly as usize;
        if nodes.len() != expected {
            return Err(ClimateError::NodeCount {
                expected,
                found: nodes.len(),
            });
        }
        if let Some(bad) = nodes
            .iter()
            .copied()
            .find(|v| !v.is_finite() || !(-1.0..=1.0).contains(v))
        {
            return Err(ClimateError::NodeValue(bad));
        }
        let cells = fill(&torus, &terms);
        Ok(Climate {
            torus,
            cells,
            terms,
            params,
            nodes,
            weather_tick,
        })
    }

    /// The torus this climate covers.
    pub fn torus(&self) -> Torus {
        self.torus
    }

    /// The variation terms, for checkpoints.
    pub fn terms(&self) -> &[WaveTerm] {
        &self.terms
    }

    /// The seasonal and weather settings.
    pub fn params(&self) -> ClimateParams {
        self.params
    }

    /// The weather nodes, for checkpoints.
    pub fn nodes(&self) -> &[f64] {
        &self.nodes
    }

    /// The tick whose Climate phase was applied last.
    pub fn weather_tick(&self) -> u64 {
        self.weather_tick
    }

    /// The base climate of `cell` (no season, no weather).
    pub fn at(&self, cell: Cell) -> &CellClimate {
        &self.cells[self.torus.index(cell)]
    }

    /// Applies the Climate phase of `tick`: when the weather is on, every node takes one AR(1) step with a draw
    /// from `rng`, in ascending row-major order; then `weather_tick = tick`. With weather off nothing is drawn.
    pub fn advance(&mut self, rng: &mut Rng, tick: u64) {
        if self.params.weather_amplitude > 0.0 {
            for node in self.nodes.iter_mut() {
                let u = 2.0 * rng.next_f64() - 1.0;
                *node = (WEATHER_RHO * *node + WEATHER_SIGMA * u).clamp(-1.0, 1.0);
            }
        }
        self.weather_tick = tick;
    }

    /// Current temperature and precipitation of `cell` for the last finished tick (`weather_tick`): base field,
    /// season, and weather, clamped to the documented bounds.
    pub fn conditions(&self, cell: Cell) -> Conditions {
        let sin_t = self.season_sin(self.weather_tick);
        self.clamped(cell, sin_t, self.weather_at(cell))
    }

    /// Base field plus the season at `tick`, without weather. Defined for any tick: it depends only on the tick and
    /// the year length. Weather at other ticks is not reproducible without history (ADR-0010).
    pub fn seasonal_conditions(&self, cell: Cell, tick: u64) -> Conditions {
        self.clamped(cell, self.season_sin(tick), 0.0)
    }

    /// `sin(2 pi (tick mod Y) / Y)`: the seasonal phase, shared by all cells.
    fn season_sin(&self, tick: u64) -> f64 {
        let year = self.params.season_length;
        let phase = (tick % year) as f64 / year as f64;
        (2.0 * PI * phase).sin()
    }

    /// Weather value at `cell` in `-1..=1`: bilinear interpolation of the nodes with smoothstep weights, periodic.
    fn weather_at(&self, cell: Cell) -> f64 {
        let (lx, ly) = lattice_dims(&self.torus);
        let (x0, x1, sx) = axis_weights(cell.x(), self.torus.width(), lx);
        let (y0, y1, sy) = axis_weights(cell.y(), self.torus.height(), ly);
        let node = |x: usize, y: usize| self.nodes[y * lx as usize + x];
        let top = (1.0 - sx) * node(x0, y0) + sx * node(x1, y0);
        let bottom = (1.0 - sx) * node(x0, y1) + sx * node(x1, y1);
        (1.0 - sy) * top + sy * bottom
    }

    /// Unclamped temperature and precipitation of `cell` for the given seasonal sine and weather value.
    fn raw_conditions(&self, cell: Cell, sin_t: f64, weather: f64) -> (f64, f64) {
        let c = self.cells[self.torus.index(cell)];
        let lat = latitude_of_row(self.torus.height(), cell.y());
        let amp = self.params.weather_amplitude;
        let temperature = f64::from(c.temperature)
            + SEASON_TEMPERATURE_SWING * lat / 90.0 * sin_t
            + WEATHER_TEMPERATURE_SCALE * amp * weather;
        let multiplier = 1.0 + SEASON_PRECIPITATION_SWING * sin_t + amp * weather;
        (temperature, f64::from(c.precipitation) * multiplier)
    }

    fn clamped(&self, cell: Cell, sin_t: f64, weather: f64) -> Conditions {
        let (t, p) = self.raw_conditions(cell, sin_t, weather);
        Conditions {
            temperature: t.clamp(
                f64::from(TEMPERATURE_RANGE.0),
                f64::from(TEMPERATURE_RANGE.1),
            ) as f32,
            precipitation: p.clamp(
                f64::from(PRECIPITATION_RANGE.0),
                f64::from(PRECIPITATION_RANGE.1),
            ) as f32,
        }
    }

    /// The text map: one line per row (top row first), one glyph per cell, each line ends with `\n`.
    pub fn biome_map_text(&self) -> String {
        let w = self.torus.width() as usize;
        let mut out = String::with_capacity((w + 1) * self.torus.height() as usize);
        for (index, c) in self.cells.iter().enumerate() {
            out.push(c.biome.glyph());
            if (index + 1) % w == 0 {
                out.push('\n');
            }
        }
        out
    }

    /// JSON export: `width`, `height`, the zone and value bounds, and one object per cell in row-major order.
    /// Values are finite, so the output is valid JSON.
    pub fn to_json(&self) -> String {
        let mut out = format!(
            "{{\"width\": {}, \"height\": {}, \"temperature_bounds\": [{}, {}], \"cells\": [",
            self.torus.width(),
            self.torus.height(),
            TEMPERATURE_BOUNDS.0,
            TEMPERATURE_BOUNDS.1
        );
        let w = self.torus.width() as usize;
        for (index, c) in self.cells.iter().enumerate() {
            if index > 0 {
                out.push_str(", ");
            }
            out.push_str(&format!(
                "{{\"x\": {}, \"y\": {}, \"biome\": \"{}\", \"latitude\": {}, \"temperature\": {}, \"precipitation\": {}}}",
                index % w,
                index / w,
                c.biome.name(),
                c.latitude,
                c.temperature,
                c.precipitation
            ));
        }
        out.push_str("]}");
        out
    }
}

impl WaveTerm {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let WaveTerm {
            i,
            j,
            phase,
            weight,
        } = self;
        enc.u32(*i);
        enc.u32(*j);
        enc.f64(*phase);
        enc.f64(*weight);
    }

    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<WaveTerm, crate::checkpoint::CheckpointError> {
        Ok(WaveTerm {
            i: dec.u32()?,
            j: dec.u32()?,
            phase: dec.f64()?,
            weight: dec.f64()?,
        })
    }
}

impl Climate {
    /// Canonical encoding of the climate state (ADR-0020 D3). `cells` is a derived cache, recomputed from the terms,
    /// the parameters and the nodes by [`Climate::from_parts`]; it is deliberately not encoded (see the destructuring).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Climate {
            torus,
            cells: _,
            terms,
            params,
            nodes,
            weather_tick,
        } = self;
        torus.encode_state(enc);
        enc.count(terms.len());
        for t in terms {
            t.encode_state(enc);
        }
        enc.u64(params.season_length);
        enc.f64(params.weather_amplitude);
        enc.count(nodes.len());
        for n in nodes {
            enc.f64(*n);
        }
        enc.u64(*weather_tick);
    }

    /// Reads the torus, the terms, the parameters, the weather nodes and the weather tick, then rebuilds the climate
    /// with [`Climate::from_parts`] (ADR-0023 D3). The torus is read here and again by `World`; the caller checks
    /// that the two agree.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Climate, crate::checkpoint::CheckpointError> {
        let torus = Torus::decode_state(dec)?;
        let term_count = dec.count("climate terms")?;
        let mut terms = Vec::with_capacity(term_count);
        for _ in 0..term_count {
            terms.push(WaveTerm::decode_state(dec)?);
        }
        let season_length = dec.u64()?;
        let weather_amplitude = dec.f64()?;
        let node_count = dec.count("weather nodes")?;
        let mut nodes = Vec::with_capacity(node_count);
        for _ in 0..node_count {
            nodes.push(dec.f64()?);
        }
        let weather_tick = dec.u64()?;
        let params = ClimateParams {
            season_length,
            weather_amplitude,
        };
        Climate::from_parts(torus, terms, params, nodes, weather_tick)
            .map_err(|e| crate::checkpoint::invalid_because("climate", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Sizes used by the seam and validity tests, including the smallest worlds.
    const SIZES: [(u32, u32); 7] = [(1, 1), (1, 7), (7, 1), (2, 2), (3, 5), (64, 48), (200, 3)];
    const SEEDS: [u64; 3] = [1, 42, 0xDEAD_BEEF];

    /// The default configuration values (ADR-0006): one year is 240 ticks, weather amplitude 0.15.
    fn params(season_length: u64, weather_amplitude: f64) -> ClimateParams {
        ClimateParams {
            season_length,
            weather_amplitude,
        }
    }

    fn climate(w: u32, h: u32, seed: u64) -> Climate {
        Climate::new(&Torus::new(w, h).unwrap(), seed, params(240, 0.15)).unwrap()
    }

    /// Bitwise key of a `Conditions` value, for exact comparisons.
    fn bits(c: Conditions) -> (u32, u32) {
        (c.temperature.to_bits(), c.precipitation.to_bits())
    }

    /// Every neighbour pair of the torus as (cell, cell, is_seam). The seam pairs are the ones across the
    /// top/bottom and the left/right edges.
    fn neighbour_pairs(torus: &Torus) -> Vec<(Cell, Cell, bool)> {
        let (w, h) = (torus.width(), torus.height());
        let mut pairs = Vec::new();
        for y in 0..h {
            for x in 0..w {
                let c = torus.cell(x, y).unwrap();
                let right = torus.cell((x + 1) % w, y).unwrap();
                let down = torus.cell(x, (y + 1) % h).unwrap();
                pairs.push((c, right, x + 1 == w));
                pairs.push((c, down, y + 1 == h));
            }
        }
        pairs
    }

    /// Maximum absolute difference of latitude, temperature and precipitation over the pairs selected by `want`.
    fn max_diff(cl: &Climate, want: impl Fn(bool) -> bool) -> f32 {
        let mut worst = 0.0f32;
        for (a, b, seam) in neighbour_pairs(&cl.torus()) {
            if !want(seam) {
                continue;
            }
            let (ca, cb) = (cl.at(a), cl.at(b));
            worst = worst
                .max((ca.latitude - cb.latitude).abs())
                .max((ca.temperature - cb.temperature).abs())
                .max((ca.precipitation - cb.precipitation).abs());
        }
        worst
    }

    #[test]
    fn biome_rank_is_cold_to_hot() {
        let order = [
            Biome::Polar,
            Biome::Tundra,
            Biome::Temperate,
            Biome::Dry,
            Biome::Tropical,
        ];
        for (i, b) in order.iter().enumerate() {
            assert_eq!(b.rank() as usize, i);
        }
        for pair in order.windows(2) {
            assert!(pair[0] < pair[1]);
        }
    }

    #[test]
    fn biome_names_and_glyphs_are_distinct() {
        let all = [
            Biome::Polar,
            Biome::Tundra,
            Biome::Temperate,
            Biome::Dry,
            Biome::Tropical,
        ];
        let glyphs: Vec<char> = all.iter().map(|b| b.glyph()).collect();
        assert_eq!(glyphs, vec!['P', 'U', 'T', 'D', 'R']);
        assert_eq!(all[3].name(), "dry");
    }

    #[test]
    fn latitude_formula_points() {
        assert!(latitude_of_row(1, 0).abs() < 1e-9, "one row is the equator");
        // Seam row: close to the pole, within 90 * (1 - cos^2(pi / (2H))).
        let h = 60u32;
        let seam = latitude_of_row(h, 0);
        let bound = 90.0 * (PI / (2.0 * f64::from(h))).sin().powi(2);
        assert!(
            90.0 - seam <= bound + 1e-9,
            "seam row distance from the pole"
        );
        assert!(seam <= 90.0);
        // Symmetry: the last row has the same latitude as the first (the seam is smooth).
        assert!((latitude_of_row(h, h - 1) - seam).abs() < 1e-12);
        // Middle rows of an even height are the equator.
        assert!(latitude_of_row(h, h / 2 - 1) < 0.1);
    }

    #[test]
    fn temperature_and_precipitation_points() {
        assert!((base_temperature(0.0) - 28.0).abs() < 1e-9);
        assert!((base_temperature(90.0) - (-22.0)).abs() < 1e-9);
        assert!((base_precipitation(0.0) - 1750.0).abs() < 1.0);
        assert!(base_precipitation(28.0) < 300.0, "dry dip near 28 degrees");
        assert!(
            base_precipitation(50.0) > 800.0,
            "temperate maximum near 50 degrees"
        );
        assert!(base_precipitation(90.0) > 0.0);
    }

    #[test]
    fn biome_thresholds_half_open() {
        assert_eq!(biome_for_latitude(19.999), Biome::Tropical);
        assert_eq!(biome_for_latitude(20.0), Biome::Dry);
        assert_eq!(biome_for_latitude(34.999), Biome::Dry);
        assert_eq!(biome_for_latitude(35.0), Biome::Temperate);
        assert_eq!(biome_for_latitude(54.999), Biome::Temperate);
        assert_eq!(biome_for_latitude(55.0), Biome::Tundra);
        assert_eq!(biome_for_latitude(69.999), Biome::Tundra);
        assert_eq!(biome_for_latitude(70.0), Biome::Polar);
        assert_eq!(biome_for_latitude(90.0), Biome::Polar);
    }

    #[test]
    fn biome_order_from_pole_to_equator() {
        let h = 60u32;
        let cl = climate(4, h, 7);
        // Along column 0 from the seam (row 0) to the equator (middle row) the rank never decreases.
        let mut prev = 0u8;
        let mut seen = [false; 5];
        for y in 0..h / 2 {
            let b = cl.at(cl.torus().cell(0, y).unwrap()).biome;
            assert!(b.rank() >= prev, "rank drops at row {y}");
            prev = b.rank();
            seen[b.rank() as usize] = true;
        }
        assert!(
            seen.iter().all(|&s| s),
            "all five zones appear from pole to equator: {seen:?}"
        );
        // The other half mirrors it (the equator is in the middle, the seam is the poles).
        let top = cl.at(cl.torus().cell(0, 0).unwrap()).biome;
        let bottom = cl.at(cl.torus().cell(0, h - 1).unwrap()).biome;
        assert_eq!(top, Biome::Polar);
        assert_eq!(bottom, Biome::Polar);
    }

    #[test]
    fn variation_is_periodic_on_torus() {
        for &(w, h) in &SIZES {
            let torus = Torus::new(w, h).unwrap();
            let cl = Climate::new(&torus, 99, params(240, 0.15)).unwrap();
            for y in 0..h {
                let a = variation(&torus, cl.terms(), 0, y);
                let b = variation(&torus, cl.terms(), w, y);
                assert!((a - b).abs() < 1e-9, "x period broken at y={y} for {w}x{h}");
            }
            for x in 0..w {
                let a = variation(&torus, cl.terms(), x, 0);
                let b = variation(&torus, cl.terms(), x, h);
                assert!((a - b).abs() < 1e-9, "y period broken at x={x} for {w}x{h}");
            }
        }
    }

    #[test]
    fn seam_is_no_worse_than_interior() {
        for &(w, h) in &SIZES {
            for &seed in &SEEDS {
                let cl = climate(w, h, seed);
                let seam = max_diff(&cl, |s| s);
                let interior = max_diff(&cl, |s| !s);
                assert!(
                    seam <= interior + 1e-6,
                    "{w}x{h} seed {seed}: seam difference {seam} exceeds interior {interior}"
                );
            }
        }
    }

    #[test]
    fn every_cell_has_values_and_biome() {
        for &(w, h) in &SIZES {
            for &seed in &SEEDS {
                let cl = climate(w, h, seed);
                assert_eq!(
                    cl.biome_map_text().chars().filter(|c| *c != '\n').count(),
                    (w * h) as usize
                );
                for index in 0..cl.torus().cell_count() {
                    let cell = cl.torus().cell_from_index(index).unwrap();
                    let c = cl.at(cell);
                    assert!(
                        c.latitude.is_finite()
                            && c.temperature.is_finite()
                            && c.precipitation.is_finite()
                    );
                    assert!(c.precipitation >= 0.0);
                    assert!(
                        c.temperature >= TEMPERATURE_BOUNDS.0
                            && c.temperature <= TEMPERATURE_BOUNDS.1
                    );
                    assert_eq!(c.biome, biome_for_latitude(f64::from(c.latitude)));
                }
            }
        }
    }

    #[test]
    fn variation_weights_are_bounded() {
        for &seed in &SEEDS {
            let cl = climate(8, 8, seed);
            let terms = cl.terms();
            assert!((3..=5).contains(&terms.len()));
            let total: f64 = terms.iter().map(|t| t.weight).sum();
            assert!((total - 1.0).abs() < 1e-12);
            for t in terms {
                assert!(t.i <= 3 && t.j <= 3 && (t.i, t.j) != (0, 0));
                assert!(t.weight > 0.0);
            }
        }
    }

    #[test]
    fn same_seed_same_climate_and_different_seed_differs() {
        let a = climate(64, 48, 42);
        let b = climate(64, 48, 42);
        assert_eq!(a, b);
        let c = climate(64, 48, 43);
        let differing = a
            .cells
            .iter()
            .zip(c.cells.iter())
            .filter(|(x, y)| x.temperature != y.temperature)
            .count();
        assert!(
            differing > 0,
            "different seeds must change the regional variation"
        );
    }

    #[test]
    fn from_parts_reproduces_the_climate() {
        let mut a = climate(16, 9, 5);
        let mut rng = Rng::from_seed(3);
        for t in 0..20 {
            a.advance(&mut rng, t);
        }
        let b = Climate::from_parts(
            a.torus(),
            a.terms().to_vec(),
            a.params(),
            a.nodes().to_vec(),
            a.weather_tick(),
        )
        .unwrap();
        assert_eq!(a, b);
    }

    #[test]
    fn from_parts_rejects_bad_state() {
        let cl = climate(64, 48, 1);
        let torus = cl.torus();
        let (terms, nodes) = (cl.terms().to_vec(), cl.nodes().to_vec());
        let ok = |p: ClimateParams, n: Vec<f64>| Climate::from_parts(torus, terms.clone(), p, n, 0);
        assert!(ok(params(240, 0.15), nodes.clone()).is_ok());
        assert_eq!(
            ok(params(0, 0.15), nodes.clone()),
            Err(ClimateError::ZeroYear)
        );
        assert_eq!(
            ok(params(240, -0.1), nodes.clone()),
            Err(ClimateError::Amplitude(-0.1))
        );
        assert!(matches!(
            ok(params(240, f64::NAN), nodes.clone()),
            Err(ClimateError::Amplitude(_))
        ));
        assert!(matches!(
            ok(params(240, 0.15), nodes[1..].to_vec()),
            Err(ClimateError::NodeCount { .. })
        ));
        let mut bad = nodes.clone();
        bad[0] = 1.5;
        assert_eq!(
            ok(params(240, 0.15), bad),
            Err(ClimateError::NodeValue(1.5))
        );
        let mut nan = nodes.clone();
        nan[0] = f64::NAN;
        assert!(matches!(
            ok(params(240, 0.15), nan),
            Err(ClimateError::NodeValue(_))
        ));
    }

    #[test]
    fn seasonal_amplitude_follows_latitude() {
        let torus = Torus::new(64, 48).unwrap();
        let cl = Climate::new(&torus, 42, params(240, 0.0)).unwrap();
        let quarter = 60; // sin(2 pi * 60 / 240) = 1: the peak of the season.
                          // Row 0 is the seam, nearest the pole: the seasonal temperature swing is 20 * phi / 90, about 20 C.
        let pole = torus.cell(0, 0).unwrap();
        let lat = latitude_of_row(torus.height(), 0);
        let swing = cl.seasonal_conditions(pole, quarter).temperature - cl.at(pole).temperature;
        assert!(
            (f64::from(swing) - 20.0 * lat / 90.0).abs() < 1e-3,
            "swing {swing}"
        );
        assert!(f64::from(swing) > 19.9);
        // Middle rows are at the equator: no seasonal temperature swing.
        let equator = torus.cell(0, 23).unwrap();
        let eq_swing =
            cl.seasonal_conditions(equator, quarter).temperature - cl.at(equator).temperature;
        assert!(eq_swing.abs() < 0.05, "equator swing {eq_swing}");
        // Precipitation is multiplied by 1 + 0.2 sin: 1.2 at the peak, 0.8 at the trough.
        let p = cl.at(pole).precipitation;
        let peak = cl.seasonal_conditions(pole, quarter).precipitation;
        let trough = cl.seasonal_conditions(pole, 3 * quarter).precipitation;
        assert!((peak / p - 1.2).abs() < 1e-5);
        assert!((trough / p - 0.8).abs() < 1e-5);
    }

    #[test]
    fn year_repeats_exactly_with_weather_off() {
        let torus = Torus::new(64, 48).unwrap();
        let mut cl = Climate::new(&torus, 42, params(240, 0.0)).unwrap();
        let mut rng = Rng::from_seed(7);
        let rng_before = rng.state();
        let mut per_tick: Vec<Vec<(u32, u32)>> = Vec::new();
        for t in 0..480u64 {
            cl.advance(&mut rng, t);
            let row: Vec<(u32, u32)> = (0..torus.cell_count())
                .map(|i| bits(cl.conditions(torus.cell_from_index(i).unwrap())))
                .collect();
            per_tick.push(row);
        }
        assert_eq!(rng.state(), rng_before, "weather off draws nothing");
        for t in 0..240 {
            assert_eq!(
                per_tick[t],
                per_tick[t + 240],
                "tick {t} vs tick {}",
                t + 240
            );
        }
        // The year is not constant: the season moves the temperature.
        assert_ne!(per_tick[0], per_tick[60]);
    }

    #[test]
    fn weather_is_seeded_and_uses_the_generator() {
        let torus = Torus::new(64, 48).unwrap();
        let run = |sim_seed: u64| {
            let mut cl = Climate::new(&torus, 42, params(240, 1.0)).unwrap();
            let mut rng = Rng::from_seed(sim_seed);
            for t in 0..500 {
                cl.advance(&mut rng, t);
            }
            cl
        };
        let a = run(1);
        let b = run(1);
        assert_eq!(a, b, "same seed gives the same weather");
        let c = run(2);
        assert_ne!(
            a.nodes(),
            c.nodes(),
            "different seed gives different weather"
        );
        assert!(a.nodes().iter().any(|v| v.abs() > 0.1), "weather moves");
    }

    #[test]
    fn weather_draws_once_per_node_per_tick() {
        let torus = Torus::new(64, 48).unwrap();
        let mut cl = Climate::new(&torus, 42, params(240, 0.5)).unwrap();
        let nodes = cl.nodes().len();
        assert_eq!(nodes, 8 * 6, "64x48 with 8-cell spacing: 8 x 6 nodes");
        let mut rng = Rng::from_seed(9);
        let mut reference = Rng::from_seed(9);
        cl.advance(&mut rng, 0);
        for _ in 0..nodes {
            reference.next_f64();
        }
        assert_eq!(rng.state(), reference.state(), "one draw per node");
        assert_eq!(cl.weather_tick(), 0);
    }

    #[test]
    fn weather_field_is_periodic_and_has_no_seam_jump() {
        for &(w, h) in &SIZES {
            let torus = Torus::new(w, h).unwrap();
            let (lx, ly) = lattice_dims(&torus);
            // Random-looking nodes in -1..=1 (deterministic).
            let mut rng = Rng::from_seed(u64::from(w) * 1000 + u64::from(h));
            let n = (lx * ly) as usize;
            let nodes: Vec<f64> = (0..n).map(|_| 2.0 * rng.next_f64() - 1.0).collect();
            let cl = Climate::from_parts(torus, Vec::new(), params(240, 1.0), nodes, 0).unwrap();
            // Exact periodicity: position c and c + size give identical weights.
            for c in 0..w {
                assert_eq!(
                    axis_weights(c, w, lx),
                    axis_weights(c + w, w, lx),
                    "x {c} in {w}"
                );
            }
            for c in 0..h {
                assert_eq!(
                    axis_weights(c, h, ly),
                    axis_weights(c + h, h, ly),
                    "y {c} in {h}"
                );
            }
            // Continuity: every neighbour step (seam or interior) is within the Lipschitz bound of the
            // bilinear smoothstep field, 6 * (lx / w + ly / h) for values in -1..=1 (the bound does not depend on
            // the position, so a seam jump would show as a violation).
            let bound = 6.0 * (f64::from(lx) / f64::from(w) + f64::from(ly) / f64::from(h));
            for y in 0..h {
                for x in 0..w {
                    let here = cl.weather_at(torus.cell(x, y).unwrap());
                    let right = cl.weather_at(torus.cell((x + 1) % w, y).unwrap());
                    let down = cl.weather_at(torus.cell(x, (y + 1) % h).unwrap());
                    assert!(
                        (here - right).abs() <= bound,
                        "x step at {x},{y} in {w}x{h}"
                    );
                    assert!((here - down).abs() <= bound, "y step at {x},{y} in {w}x{h}");
                    assert!((-1.0..=1.0).contains(&here));
                }
            }
        }
    }

    #[test]
    fn bounds_hold_over_long_runs() {
        let torus = Torus::new(64, 48).unwrap();
        let mut clamp_hits = 0u64;
        for seed in 1..=3u64 {
            let mut cl = Climate::new(&torus, seed, params(120, 1.0)).unwrap();
            let mut rng = Rng::from_seed(seed);
            for t in 0..1200u64 {
                cl.advance(&mut rng, t);
                for i in 0..torus.cell_count() {
                    let cell = torus.cell_from_index(i).unwrap();
                    let c = cl.conditions(cell);
                    assert!(c.temperature.is_finite() && c.precipitation.is_finite());
                    assert!(
                        (TEMPERATURE_RANGE.0..=TEMPERATURE_RANGE.1).contains(&c.temperature),
                        "temperature {} at tick {t}",
                        c.temperature
                    );
                    assert!(
                        (PRECIPITATION_RANGE.0..=PRECIPITATION_RANGE.1).contains(&c.precipitation),
                        "precipitation {} at tick {t}",
                        c.precipitation
                    );
                    // Diagnostic: how often the clamp is needed (ADR-0010 expects it to be rare or absent).
                    let (rt, rp) = cl.raw_conditions(cell, cl.season_sin(t), cl.weather_at(cell));
                    let out_t =
                        rt < f64::from(TEMPERATURE_RANGE.0) || rt > f64::from(TEMPERATURE_RANGE.1);
                    let out_p = rp < f64::from(PRECIPITATION_RANGE.0)
                        || rp > f64::from(PRECIPITATION_RANGE.1);
                    if out_t || out_p {
                        clamp_hits += 1;
                    }
                }
            }
        }
        eprintln!("clamp hits over 3 runs of 1200 ticks x 3072 cells: {clamp_hits}");
    }

    #[test]
    fn small_worlds_weather_runs_and_stays_in_bounds() {
        for &(w, h) in &[(1u32, 1u32), (1, 7), (7, 1), (2, 2), (200, 3)] {
            let torus = Torus::new(w, h).unwrap();
            let mut cl = Climate::new(&torus, 5, params(30, 1.0)).unwrap();
            let mut rng = Rng::from_seed(5);
            for t in 0..100u64 {
                cl.advance(&mut rng, t);
                for i in 0..torus.cell_count() {
                    let c = cl.conditions(torus.cell_from_index(i).unwrap());
                    assert!(
                        c.temperature.is_finite() && c.precipitation >= 0.0,
                        "{w}x{h}"
                    );
                }
            }
        }
    }

    #[test]
    fn small_worlds_work() {
        for &(w, h) in &[(1u32, 1u32), (1, 7), (7, 1), (2, 2)] {
            let cl = climate(w, h, 3);
            let map = cl.biome_map_text();
            assert_eq!(map.lines().count(), h as usize, "{w}x{h}");
            assert!(map.lines().all(|l| l.chars().count() == w as usize));
        }
        // A 1x1 world is the equator: tropical.
        assert_eq!(
            climate(1, 1, 3)
                .at(Torus::new(1, 1).unwrap().cell(0, 0).unwrap())
                .biome,
            Biome::Tropical
        );
    }

    #[test]
    fn text_map_shape_and_glyphs() {
        let cl = climate(64, 48, 42);
        let map = cl.biome_map_text();
        assert_eq!(map.lines().count(), 48);
        assert!(map.lines().all(|l| l.chars().count() == 64));
        assert!(map.chars().all(|c| c == '\n' || "PUTDR".contains(c)));
        // Top row is the seam (polar); the middle row is tropical.
        assert!(map.lines().next().unwrap().chars().all(|c| c == 'P'));
        assert!(map.lines().nth(23).unwrap().chars().all(|c| c == 'R'));
    }

    #[test]
    fn json_export_is_finite_and_complete() {
        for &(w, h) in &[(1u32, 1u32), (5, 3), (64, 48)] {
            let cl = climate(w, h, 11);
            let json = cl.to_json();
            assert!(
                !json.contains("NaN") && !json.contains("inf"),
                "non-finite value in JSON"
            );
            assert_eq!(json.matches("\"biome\"").count(), (w * h) as usize);
            assert!(json.starts_with("{\"width\": "));
            assert!(json.ends_with("]}"));
        }
    }
}

//! Minimal strict JSON reader and canonical writer (ADR-0001: no JSON crate).
//!
//! Grammar: RFC 8259 values. Integers are numbers without fraction or exponent and are kept
//! as `i128`; an integer literal beyond `i128` is kept as its text (`BigInt`) so that
//! validation can name its key; any other number is a `f64`. Duplicate object keys, trailing data, leading
//! zeros, leading `+`, NaN and Infinity are errors. Parse errors carry line and column.

/// A parsed JSON value. Objects keep their key order.
#[derive(Clone, Debug, PartialEq)]
pub enum Value {
    Null,
    Bool(bool),
    Int(i128),
    /// Integer literal that does not fit `i128`, kept as written (with its sign).
    BigInt(String),
    Real(f64),
    Str(String),
    Array(Vec<Value>),
    Object(Vec<(String, Value)>),
}

const MAX_DEPTH: usize = 64;

/// Parses one complete JSON document.
pub fn parse(text: &str) -> Result<Value, String> {
    let mut p = Parser { s: text.as_bytes(), i: 0 };
    p.skip_ws();
    let v = p.value(0)?;
    p.skip_ws();
    if p.i != p.s.len() {
        return Err(p.err("trailing data after the value"));
    }
    Ok(v)
}

/// Writes a value with two-space indentation and no trailing newline.
pub fn write(v: &Value) -> String {
    let mut out = String::new();
    write_value(v, 0, &mut out);
    out
}

fn write_value(v: &Value, depth: usize, out: &mut String) {
    match v {
        Value::Null => out.push_str("null"),
        Value::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Value::Int(i) => out.push_str(&i.to_string()),
        Value::BigInt(text) => out.push_str(text),
        // Debug formatting of f64 is the shortest representation that parses back exactly.
        Value::Real(f) => out.push_str(&format!("{:?}", f)),
        Value::Str(s) => write_string(s, out),
        Value::Array(items) => {
            if items.is_empty() {
                out.push_str("[]");
                return;
            }
            out.push_str("[\n");
            for (n, item) in items.iter().enumerate() {
                if n > 0 {
                    out.push_str(",\n");
                }
                push_indent(depth + 1, out);
                write_value(item, depth + 1, out);
            }
            out.push('\n');
            push_indent(depth, out);
            out.push(']');
        }
        Value::Object(fields) => {
            if fields.is_empty() {
                out.push_str("{}");
                return;
            }
            out.push_str("{\n");
            for (n, (k, item)) in fields.iter().enumerate() {
                if n > 0 {
                    out.push_str(",\n");
                }
                push_indent(depth + 1, out);
                write_string(k, out);
                out.push_str(": ");
                write_value(item, depth + 1, out);
            }
            out.push('\n');
            push_indent(depth, out);
            out.push('}');
        }
    }
}

fn push_indent(depth: usize, out: &mut String) {
    for _ in 0..depth {
        out.push_str("  ");
    }
}

fn write_string(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
}

struct Parser<'a> {
    s: &'a [u8],
    i: usize,
}

impl Parser<'_> {
    fn err(&self, msg: &str) -> String {
        let upto = &self.s[..self.i.min(self.s.len())];
        let line = upto.iter().filter(|&&b| b == b'\n').count() + 1;
        let column = upto.iter().rev().take_while(|&&b| b != b'\n').count() + 1;
        format!("JSON syntax error at line {line}, column {column}: {msg}")
    }

    fn peek(&self) -> Option<u8> {
        self.s.get(self.i).copied()
    }

    fn skip_ws(&mut self) {
        while matches!(self.peek(), Some(b' ' | b'\t' | b'\n' | b'\r')) {
            self.i += 1;
        }
    }

    fn value(&mut self, depth: usize) -> Result<Value, String> {
        if depth > MAX_DEPTH {
            return Err(self.err("nesting is too deep"));
        }
        match self.peek() {
            Some(b'{') => self.object(depth),
            Some(b'[') => self.array(depth),
            Some(b'"') => Ok(Value::Str(self.string()?)),
            Some(b't') => self.literal("true", Value::Bool(true)),
            Some(b'f') => self.literal("false", Value::Bool(false)),
            Some(b'n') => self.literal("null", Value::Null),
            Some(b'-' | b'0'..=b'9') => self.number(),
            _ => Err(self.err("unexpected character")),
        }
    }

    fn object(&mut self, depth: usize) -> Result<Value, String> {
        self.i += 1; // '{'
        let mut fields: Vec<(String, Value)> = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b'}') {
            self.i += 1;
            return Ok(Value::Object(fields));
        }
        loop {
            self.skip_ws();
            if self.peek() != Some(b'"') {
                return Err(self.err("expected a string key"));
            }
            let key = self.string()?;
            if fields.iter().any(|(k, _)| *k == key) {
                return Err(self.err(&format!("duplicate key \"{key}\"")));
            }
            self.skip_ws();
            if self.peek() != Some(b':') {
                return Err(self.err("expected ':' after the key"));
            }
            self.i += 1;
            self.skip_ws();
            let v = self.value(depth + 1)?;
            fields.push((key, v));
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.i += 1,
                Some(b'}') => {
                    self.i += 1;
                    return Ok(Value::Object(fields));
                }
                _ => return Err(self.err("expected ',' or '}'")),
            }
        }
    }

    fn array(&mut self, depth: usize) -> Result<Value, String> {
        self.i += 1; // '['
        let mut items = Vec::new();
        self.skip_ws();
        if self.peek() == Some(b']') {
            self.i += 1;
            return Ok(Value::Array(items));
        }
        loop {
            self.skip_ws();
            items.push(self.value(depth + 1)?);
            self.skip_ws();
            match self.peek() {
                Some(b',') => self.i += 1,
                Some(b']') => {
                    self.i += 1;
                    return Ok(Value::Array(items));
                }
                _ => return Err(self.err("expected ',' or ']'")),
            }
        }
    }

    fn literal(&mut self, word: &str, v: Value) -> Result<Value, String> {
        if self.s[self.i..].starts_with(word.as_bytes()) {
            self.i += word.len();
            Ok(v)
        } else {
            Err(self.err("unexpected character"))
        }
    }

    fn hex4(&mut self) -> Result<u32, String> {
        let digits = self
            .s
            .get(self.i..self.i + 4)
            .ok_or_else(|| self.err("truncated \\u escape"))?;
        if !digits.iter().all(|b| b.is_ascii_hexdigit()) {
            return Err(self.err("invalid \\u escape"));
        }
        let text = std::str::from_utf8(digits).map_err(|_| self.err("invalid \\u escape"))?;
        self.i += 4;
        u32::from_str_radix(text, 16).map_err(|_| self.err("invalid \\u escape"))
    }

    fn string(&mut self) -> Result<String, String> {
        self.i += 1; // opening quote
        let mut buf: Vec<u8> = Vec::new();
        loop {
            match self.peek() {
                None => return Err(self.err("unterminated string")),
                Some(b'"') => {
                    self.i += 1;
                    // The input is a &str and escapes produce valid chars, so this cannot fail.
                    return String::from_utf8(buf).map_err(|_| self.err("invalid UTF-8"));
                }
                Some(b'\\') => {
                    self.i += 1;
                    let c = self.peek().ok_or_else(|| self.err("unterminated escape"))?;
                    self.i += 1;
                    let ch = match c {
                        b'"' => '"',
                        b'\\' => '\\',
                        b'/' => '/',
                        b'b' => '\u{8}',
                        b'f' => '\u{c}',
                        b'n' => '\n',
                        b'r' => '\r',
                        b't' => '\t',
                        b'u' => {
                            let code = self.hex4()?;
                            if (0xDC00..=0xDFFF).contains(&code) {
                                return Err(self.err("lone low surrogate in \\u escape"));
                            }
                            let scalar = if (0xD800..=0xDBFF).contains(&code) {
                                // A high surrogate must be followed by an escaped low surrogate (RFC 8259 7).
                                if !self.s.get(self.i..).is_some_and(|rest| rest.starts_with(b"\\u")) {
                                    return Err(self.err("high surrogate without a following low surrogate"));
                                }
                                self.i += 2;
                                let low = self.hex4()?;
                                if !(0xDC00..=0xDFFF).contains(&low) {
                                    return Err(self.err("high surrogate not followed by a low surrogate"));
                                }
                                0x10000 + ((code - 0xD800) << 10) + (low - 0xDC00)
                            } else {
                                code
                            };
                            char::from_u32(scalar).ok_or_else(|| self.err("invalid \\u escape"))?
                        }
                        _ => return Err(self.err("invalid escape")),
                    };
                    let mut tmp = [0u8; 4];
                    buf.extend_from_slice(ch.encode_utf8(&mut tmp).as_bytes());
                }
                Some(c) if c < 0x20 => return Err(self.err("control character in string")),
                Some(c) => {
                    buf.push(c);
                    self.i += 1;
                }
            }
        }
    }

    fn skip_digits(&mut self) -> usize {
        let start = self.i;
        while matches!(self.peek(), Some(b'0'..=b'9')) {
            self.i += 1;
        }
        self.i - start
    }

    fn number(&mut self) -> Result<Value, String> {
        let start = self.i;
        if self.peek() == Some(b'-') {
            self.i += 1;
        }
        match self.peek() {
            Some(b'0') => {
                self.i += 1;
                if matches!(self.peek(), Some(b'0'..=b'9')) {
                    return Err(self.err("leading zeros are not allowed"));
                }
            }
            Some(b'1'..=b'9') => {
                self.skip_digits();
            }
            _ => return Err(self.err("expected a digit")),
        }
        let mut is_real = false;
        if self.peek() == Some(b'.') {
            is_real = true;
            self.i += 1;
            if self.skip_digits() == 0 {
                return Err(self.err("expected a digit after '.'"));
            }
        }
        if matches!(self.peek(), Some(b'e' | b'E')) {
            is_real = true;
            self.i += 1;
            if matches!(self.peek(), Some(b'+' | b'-')) {
                self.i += 1;
            }
            if self.skip_digits() == 0 {
                return Err(self.err("expected a digit in the exponent"));
            }
        }
        let text = std::str::from_utf8(&self.s[start..self.i]).map_err(|_| self.err("invalid number"))?;
        if is_real {
            text.parse::<f64>()
                .map(Value::Real)
                .map_err(|_| self.err("invalid number"))
        } else {
            // Only overflow can make this fail; the literal already follows the JSON grammar.
            Ok(match text.parse::<i128>() {
                Ok(i) => Value::Int(i),
                Err(_) => Value::BigInt(text.to_string()),
            })
        }
    }
}

//! Typed simulation configuration (ADR-0006).
//!
//! Every parameter has a type, an inclusive range and a default. The fixed keys of
//! `docs/CONTRACT.md` section 3 are required; everything else may be absent.
//! Unknown keys are errors. All validation runs in [`Config::from_json`] (and therefore in
//! [`Config::new`], [`Config::load`] and every preset), so a `Config` value is always valid.

pub mod json;
pub mod presets;
#[cfg(test)]
mod tests;

use std::fmt;
use std::path::Path;

use json::Value;

/// Largest allowed world side in cells.
pub const MAX_SIDE: u64 = 4096;
/// Largest allowed `width * height` in cells. Implied by `MAX_SIDE`, so it is not checked again.
pub const MAX_CELLS: u64 = MAX_SIDE * MAX_SIDE;
/// Largest allowed initial population of one kind.
pub const MAX_INITIAL: u64 = 1_000_000;

pub const DEFAULT_CLIMATE_SEASON_LENGTH: u64 = 240;
pub const DEFAULT_CLIMATE_WEATHER_AMPLITUDE: f64 = 0.15;
pub const DEFAULT_PLANTS_GROWTH_RATE: f64 = 0.1;
pub const DEFAULT_PLANTS_REPRODUCTION_CHANCE: f64 = 0.05;
pub const DEFAULT_PLANTS_SEED_RADIUS: u64 = 2;
pub const DEFAULT_PLANTS_MAX_AGE: u64 = 1500;
pub const DEFAULT_HERBIVORES_METABOLISM: f64 = 0.8;
pub const DEFAULT_HERBIVORES_REPRODUCTION_ENERGY: f64 = 60.0;
pub const DEFAULT_HERBIVORES_MAX_AGE: u64 = 300;
pub const DEFAULT_CARNIVORES_METABOLISM: f64 = 1.2;
pub const DEFAULT_CARNIVORES_REPRODUCTION_ENERGY: f64 = 90.0;
pub const DEFAULT_CARNIVORES_MAX_AGE: u64 = 400;
pub const DEFAULT_GENETICS_MUTATION_RATE: f64 = 0.002;
pub const DEFAULT_GENETICS_MUTATION_STRENGTH: u64 = 8;
pub const DEFAULT_SPECIES_DISTANCE: f64 = 0.06;
pub const DEFAULT_SPECIES_CHECK_INTERVAL: u64 = 25;
pub const DEFAULT_SPECIES_PERSISTENCE_CHECKS: u64 = 4;

/// A configuration error. `key` is the dotted path of the offending key when there is one;
/// parse errors have no key and carry line and column in `message`.
#[derive(Clone, Debug, PartialEq)]
pub struct ConfigError {
    pub key: Option<String>,
    pub message: String,
}

impl ConfigError {
    fn key(key: impl Into<String>, message: impl Into<String>) -> Self {
        ConfigError { key: Some(key.into()), message: message.into() }
    }

    fn plain(message: impl Into<String>) -> Self {
        ConfigError { key: None, message: message.into() }
    }
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match &self.key {
            Some(k) => write!(f, "config key \"{}\": {}", k, self.message),
            None => write!(f, "config: {}", self.message),
        }
    }
}

impl std::error::Error for ConfigError {}

/// Complete simulation configuration. Integer parameters are stored as `u64`.
#[derive(Clone, Debug, PartialEq)]
pub struct Config {
    pub seed: u64,
    pub world: World,
    pub initial: Initial,
    pub climate: Climate,
    pub plants: Plants,
    pub herbivores: Animal,
    pub carnivores: Animal,
    pub genetics: Genetics,
    pub species: Species,
}

#[derive(Clone, Debug, PartialEq)]
pub struct World {
    pub width: u64,
    pub height: u64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Initial {
    pub plants: u64,
    pub herbivores: u64,
    pub carnivores: u64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Climate {
    /// Ticks per seasonal cycle.
    pub season_length: u64,
    /// Size of weather variation relative to the seasonal swing.
    pub weather_amplitude: f64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Plants {
    /// Fraction of the energy deficit regained per tick.
    pub growth_rate: f64,
    /// Chance per tick of seeding when mature.
    pub reproduction_chance: f64,
    /// Dispersal radius in cells (torus distance).
    pub seed_radius: u64,
    pub max_age: u64,
}

/// Shared shape of the herbivore and carnivore parameter groups.
#[derive(Clone, Debug, PartialEq)]
pub struct Animal {
    /// Energy spent per tick.
    pub metabolism: f64,
    /// Energy needed to breed.
    pub reproduction_energy: f64,
    pub max_age: u64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Genetics {
    /// Per locus, per reproduction (ADR-0004).
    pub mutation_rate: f64,
    /// Largest step per mutation (ADR-0004).
    pub mutation_strength: u64,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Species {
    /// Genetic distance threshold (ADR-0004 `species_distance`).
    pub distance: f64,
    /// Ticks between species checks.
    pub check_interval: u64,
    /// Consecutive checks needed to recognise a species.
    pub persistence_checks: u64,
}

const ROOT_KEYS: &[&str] = &[
    "seed", "world", "initial", "climate", "plants", "herbivores", "carnivores", "genetics", "species",
];

impl Config {
    /// Builds a configuration from the fixed keys; every other parameter takes its default.
    pub fn new(seed: u64, width: u64, height: u64, initial: Initial) -> Result<Config, ConfigError> {
        let root = vec![
            ("seed".to_string(), Value::Int(seed as i128)),
            (
                "world".to_string(),
                obj(&[("width", Value::Int(width as i128)), ("height", Value::Int(height as i128))]),
            ),
            (
                "initial".to_string(),
                obj(&[
                    ("plants", Value::Int(initial.plants as i128)),
                    ("herbivores", Value::Int(initial.herbivores as i128)),
                    ("carnivores", Value::Int(initial.carnivores as i128)),
                ]),
            ),
        ];
        from_fields(&root)
    }

    /// Parses and validates a JSON configuration text.
    pub fn from_json(text: &str) -> Result<Config, ConfigError> {
        match json::parse(text).map_err(ConfigError::plain)? {
            Value::Object(fields) => from_fields(&fields),
            other => Err(ConfigError::plain(format!("expected a JSON object at top level, found {}", kind(&other)))),
        }
    }

    /// Writes every parameter in fixed order. `from_json(to_json(c)) == c` for every valid `c`.
    pub fn to_json(&self) -> String {
        json::write(&self.to_value())
    }

    /// Reads and validates a configuration file.
    pub fn load(path: &Path) -> Result<Config, ConfigError> {
        let text = std::fs::read_to_string(path)
            .map_err(|e| ConfigError::plain(format!("cannot read {}: {}", path.display(), e)))?;
        Config::from_json(&text)
    }

    /// Writes the configuration as JSON followed by a newline.
    pub fn save(&self, path: &Path) -> Result<(), ConfigError> {
        if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
            std::fs::create_dir_all(parent)
                .map_err(|e| ConfigError::plain(format!("cannot write {}: {}", path.display(), e)))?;
        }
        std::fs::write(path, self.to_json() + "\n")
            .map_err(|e| ConfigError::plain(format!("cannot write {}: {}", path.display(), e)))
    }

    fn to_value(&self) -> Value {
        let real = Value::Real;
        let int = |v: u64| Value::Int(v as i128);
        obj(&[
            ("seed", int(self.seed)),
            ("world", obj(&[("width", int(self.world.width)), ("height", int(self.world.height))])),
            (
                "initial",
                obj(&[
                    ("plants", int(self.initial.plants)),
                    ("herbivores", int(self.initial.herbivores)),
                    ("carnivores", int(self.initial.carnivores)),
                ]),
            ),
            (
                "climate",
                obj(&[
                    ("season_length", int(self.climate.season_length)),
                    ("weather_amplitude", real(self.climate.weather_amplitude)),
                ]),
            ),
            (
                "plants",
                obj(&[
                    ("growth_rate", real(self.plants.growth_rate)),
                    ("reproduction_chance", real(self.plants.reproduction_chance)),
                    ("seed_radius", int(self.plants.seed_radius)),
                    ("max_age", int(self.plants.max_age)),
                ]),
            ),
            ("herbivores", animal_value(&self.herbivores)),
            ("carnivores", animal_value(&self.carnivores)),
            (
                "genetics",
                obj(&[
                    ("mutation_rate", real(self.genetics.mutation_rate)),
                    ("mutation_strength", int(self.genetics.mutation_strength)),
                ]),
            ),
            (
                "species",
                obj(&[
                    ("distance", real(self.species.distance)),
                    ("check_interval", int(self.species.check_interval)),
                    ("persistence_checks", int(self.species.persistence_checks)),
                ]),
            ),
        ])
    }
}

fn animal_value(a: &Animal) -> Value {
    obj(&[
        ("metabolism", Value::Real(a.metabolism)),
        ("reproduction_energy", Value::Real(a.reproduction_energy)),
        ("max_age", Value::Int(a.max_age as i128)),
    ])
}

fn obj(pairs: &[(&str, Value)]) -> Value {
    Value::Object(pairs.iter().map(|(k, v)| (k.to_string(), v.clone())).collect())
}

fn kind(v: &Value) -> &'static str {
    match v {
        Value::Null => "null",
        Value::Bool(_) => "boolean",
        Value::Int(_) | Value::BigInt(_) => "integer",
        Value::Real(_) => "real number",
        Value::Str(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}

fn wrong_type(key: String, expected: &str, found: &Value) -> ConfigError {
    ConfigError::key(key, format!("expected {}, found {}", expected, kind(found)))
}

/// One JSON object together with its dotted path. `fields` is `None` when the group is absent.
struct Section<'a> {
    prefix: &'static str,
    fields: Option<&'a [(String, Value)]>,
}

impl<'a> Section<'a> {
    fn key(&self, leaf: &str) -> String {
        if self.prefix.is_empty() {
            leaf.to_string()
        } else {
            format!("{}.{}", self.prefix, leaf)
        }
    }

    fn value(&self, leaf: &str) -> Option<&'a Value> {
        self.fields?.iter().find(|(k, _)| k == leaf).map(|(_, v)| v)
    }

    /// Integer in `min..=max`. `default: None` makes the key required.
    fn int(&self, leaf: &str, min: u64, max: u64, default: Option<u64>) -> Result<u64, ConfigError> {
        let key = self.key(leaf);
        match self.value(leaf) {
            None => default.ok_or_else(|| ConfigError::key(key, "missing required key")),
            Some(Value::Int(i)) => {
                if *i < min as i128 || *i > max as i128 {
                    Err(ConfigError::key(key, format!("{} is out of range {}..={}", i, min, max)))
                } else {
                    Ok(*i as u64)
                }
            }
            // Beyond i128: still an integer, so the range error names the key and the literal.
            Some(Value::BigInt(text)) => Err(ConfigError::key(key, format!("{} is out of range {}..={}", text, min, max))),
            Some(v) => Err(wrong_type(key, "integer", v)),
        }
    }

    /// Real in `min..=max`; an integer literal is accepted and read as a real.
    fn real(&self, leaf: &str, min: f64, max: f64, default: f64) -> Result<f64, ConfigError> {
        let key = self.key(leaf);
        let x = match self.value(leaf) {
            None => return Ok(default),
            Some(Value::Real(f)) => *f,
            Some(Value::Int(i)) => *i as f64,
            // Huge magnitudes that do not fit f64 become infinity and fail the range check.
            Some(Value::BigInt(text)) => text.parse::<f64>().unwrap_or(f64::INFINITY),
            Some(v) => return Err(wrong_type(key, "number", v)),
        };
        if min <= x && x <= max {
            Ok(x)
        } else {
            Err(ConfigError::key(key, format!("{:?} is out of range {:?}..={:?}", x, min, max)))
        }
    }
}

fn check_keys(fields: &[(String, Value)], prefix: &str, allowed: &[&str]) -> Result<(), ConfigError> {
    for (k, _) in fields {
        if !allowed.contains(&k.as_str()) {
            let key = if prefix.is_empty() { k.clone() } else { format!("{}.{}", prefix, k) };
            return Err(ConfigError::key(key, "unknown key"));
        }
    }
    Ok(())
}

fn section<'a>(root: &'a [(String, Value)], name: &'static str, allowed: &[&str]) -> Result<Section<'a>, ConfigError> {
    match root.iter().find(|(k, _)| k == name).map(|(_, v)| v) {
        None => Ok(Section { prefix: name, fields: None }),
        Some(Value::Object(f)) => {
            check_keys(f, name, allowed)?;
            Ok(Section { prefix: name, fields: Some(f) })
        }
        Some(v) => Err(wrong_type(name.to_string(), "object", v)),
    }
}

/// Reads and validates every parameter. This is the only place where validation happens.
fn from_fields(root: &[(String, Value)]) -> Result<Config, ConfigError> {
    check_keys(root, "", ROOT_KEYS)?;
    let top = Section { prefix: "", fields: Some(root) };
    let seed = top.int("seed", 0, u64::MAX, None)?;

    let w = section(root, "world", &["width", "height"])?;
    let width = w.int("width", 1, MAX_SIDE, None)?;
    let height = w.int("height", 1, MAX_SIDE, None)?;

    let ini = section(root, "initial", &["plants", "herbivores", "carnivores"])?;
    let initial = Initial {
        plants: ini.int("plants", 0, MAX_INITIAL, None)?,
        herbivores: ini.int("herbivores", 0, MAX_INITIAL, None)?,
        carnivores: ini.int("carnivores", 0, MAX_INITIAL, None)?,
    };

    let c = section(root, "climate", &["season_length", "weather_amplitude"])?;
    let climate = Climate {
        season_length: c.int("season_length", 1, 100_000, Some(DEFAULT_CLIMATE_SEASON_LENGTH))?,
        weather_amplitude: c.real("weather_amplitude", 0.0, 1.0, DEFAULT_CLIMATE_WEATHER_AMPLITUDE)?,
    };

    let p = section(root, "plants", &["growth_rate", "reproduction_chance", "seed_radius", "max_age"])?;
    let plants = Plants {
        growth_rate: p.real("growth_rate", 0.0, 1.0, DEFAULT_PLANTS_GROWTH_RATE)?,
        reproduction_chance: p.real("reproduction_chance", 0.0, 1.0, DEFAULT_PLANTS_REPRODUCTION_CHANCE)?,
        seed_radius: p.int("seed_radius", 0, 16, Some(DEFAULT_PLANTS_SEED_RADIUS))?,
        max_age: p.int("max_age", 1, 100_000, Some(DEFAULT_PLANTS_MAX_AGE))?,
    };

    let herbivores = animal(root, "herbivores", DEFAULT_HERBIVORES_METABOLISM,
        DEFAULT_HERBIVORES_REPRODUCTION_ENERGY, DEFAULT_HERBIVORES_MAX_AGE)?;
    let carnivores = animal(root, "carnivores", DEFAULT_CARNIVORES_METABOLISM,
        DEFAULT_CARNIVORES_REPRODUCTION_ENERGY, DEFAULT_CARNIVORES_MAX_AGE)?;

    let g = section(root, "genetics", &["mutation_rate", "mutation_strength"])?;
    let genetics = Genetics {
        mutation_rate: g.real("mutation_rate", 0.0, 1.0, DEFAULT_GENETICS_MUTATION_RATE)?,
        mutation_strength: g.int("mutation_strength", 1, 255, Some(DEFAULT_GENETICS_MUTATION_STRENGTH))?,
    };

    let s = section(root, "species", &["distance", "check_interval", "persistence_checks"])?;
    let species = Species {
        distance: s.real("distance", 0.0, 1.0, DEFAULT_SPECIES_DISTANCE)?,
        check_interval: s.int("check_interval", 1, 10_000, Some(DEFAULT_SPECIES_CHECK_INTERVAL))?,
        persistence_checks: s.int("persistence_checks", 1, 1000, Some(DEFAULT_SPECIES_PERSISTENCE_CHECKS))?,
    };

    Ok(Config {
        seed,
        world: World { width, height },
        initial,
        climate,
        plants,
        herbivores,
        carnivores,
        genetics,
        species,
    })
}

fn animal(root: &[(String, Value)], name: &'static str, metabolism: f64, reproduction_energy: f64,
    max_age: u64) -> Result<Animal, ConfigError> {
    let s = section(root, name, &["metabolism", "reproduction_energy", "max_age"])?;
    Ok(Animal {
        metabolism: s.real("metabolism", 0.0, 100.0, metabolism)?,
        reproduction_energy: s.real("reproduction_energy", 0.0, 1000.0, reproduction_energy)?,
        max_age: s.int("max_age", 1, 100_000, Some(max_age))?,
    })
}

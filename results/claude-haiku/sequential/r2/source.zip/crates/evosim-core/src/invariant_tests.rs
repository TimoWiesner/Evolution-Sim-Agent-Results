//! Randomised invariant tests (TASK-028, docs/VERIFICATION.md section 3).
//!
//! A fixed master seed draws many random configurations (world size, initial counts, parameters inside their documented
//! ranges, simulation seed). For each one the tests run the library directly (`Config`, `Simulation`, `checkpoint`) and
//! check after every tick:
//! - birth/death accounting: `initial + births - deaths = living` per kind, cumulative counters never decrease, and
//!   the living count equals the number of stored living organisms;
//! - value ranges and storage invariants (`Entities::check_invariants`), plant resources within `[0, 100]`;
//! - wrapping: every organism is on the torus, and `SpatialIndex::within` equals a brute-force torus search for centres
//!   across the seams (x = 0, x = width - 1, y = 0, y = height - 1);
//! - the spatial index stays in step with the organisms (`check_spatial`);
//! - determinism: equal configurations give equal `state_hash`; a checkpoint split run equals the uninterrupted run;
//!   a different seed gives a different `state_hash`.
//!
//! The number of random cases comes from `EVOSIM_INVARIANT_CASES` (default 24, sized for a debug test run). The release
//! run in `scripts/test.sh` uses a larger count. Failures name the case so they can be reproduced from the master seed.

use crate::checkpoint;
use crate::config::{Config, Initial};
use crate::entities::Kind;
use crate::rng::Rng;
use crate::sim::Simulation;
use crate::world::{Cell, Torus};

const MASTER_SEED: u64 = 0x5EED_0028_0000_0001;
const DEFAULT_CASES: u64 = 24;

fn cases() -> u64 {
    match std::env::var("EVOSIM_INVARIANT_CASES") {
        Ok(text) => text
            .trim()
            .parse::<u64>()
            .unwrap_or_else(|_| panic!("EVOSIM_INVARIANT_CASES is not an integer: {text:?}")),
        Err(_) => DEFAULT_CASES,
    }
}

/// One random case: a configuration and the number of ticks to simulate.
struct Case {
    index: u64,
    config: Config,
    ticks: u64,
}

/// Draws a random configuration. Every value is inside the range that `config.rs` accepts.
fn random_case(rng: &mut Rng, index: u64) -> Case {
    let width = 1 + rng.next_below(64);
    let height = 1 + rng.next_below(48);
    let initial = Initial {
        plants: rng.next_below(301),
        herbivores: rng.next_below(301),
        carnivores: rng.next_below(101),
    };
    let seed = rng.next_u64();
    let mut config = Config::new(seed, width, height, initial).expect("random configuration is valid");
    config.climate.weather_amplitude = rng.next_f64();
    config.climate.season_length = 1 + rng.next_below(600);
    config.plants.growth_rate = rng.next_f64();
    config.plants.reproduction_chance = rng.next_f64();
    config.plants.seed_radius = rng.next_below(5);
    config.plants.max_age = 1 + rng.next_below(3000);
    config.herbivores.metabolism = 0.2 + rng.next_f64();
    config.herbivores.reproduction_energy = 30.0 + 60.0 * rng.next_f64();
    config.herbivores.max_age = 1 + rng.next_below(600);
    config.carnivores.metabolism = 0.2 + 1.5 * rng.next_f64();
    config.carnivores.reproduction_energy = 40.0 + 80.0 * rng.next_f64();
    config.carnivores.max_age = 1 + rng.next_below(800);
    config.genetics.mutation_rate = 0.02 * rng.next_f64();
    config.genetics.mutation_strength = 1 + rng.next_below(16);
    config.species.check_interval = 1 + rng.next_below(40);
    config.species.persistence_checks = 1 + rng.next_below(5);
    let ticks = 50 + rng.next_below(251);
    Case { index, config, ticks }
}

fn fail(case: &Case, tick: u64, message: String) -> ! {
    panic!(
        "invariant violated in case {} (world {}x{}, seed {}, tick {}): {}",
        case.index, case.config.world.width, case.config.world.height, case.config.seed, tick, message
    )
}

fn new_sim(config: &Config) -> Simulation {
    let mut sim = Simulation::new(config).expect("simulation is created");
    sim.populate_initial(config).expect("initial population is placed");
    sim
}

/// Brute-force Chebyshev torus search over every living organism, ascending by id.
fn brute_within(sim: &Simulation, torus: &Torus, centre: Cell, radius: u32, filter: Option<Kind>) -> Vec<u64> {
    let mut out: Vec<u64> = sim
        .entities()
        .living()
        .filter(|o| filter.is_none_or(|k| o.kind() == k))
        .filter(|o| torus.distance(centre, o.cell()) <= radius)
        .map(|o| o.id().0)
        .collect();
    out.sort_unstable();
    out
}

/// Checks everything that must hold after one tick. `previous` holds the cumulative counters of the last tick.
fn check_tick(case: &Case, sim: &Simulation, tick: u64, rng: &mut Rng, previous: &mut [(u64, u64); 3]) {
    let entities = sim.entities();
    if let Err(e) = entities.check_invariants() {
        fail(case, tick, format!("entity invariants: {e:?}"));
    }
    if let Err(e) = sim.check_spatial() {
        fail(case, tick, format!("spatial index out of step: {e:?}"));
    }
    let torus = sim.world().topology;
    for kind in Kind::ALL {
        let k = kind.index();
        let living = entities.living().filter(|o| o.kind() == kind).count() as u64;
        if living != entities.living_count(kind) {
            fail(case, tick, format!("{kind:?}: living_count {} != stored {living}", entities.living_count(kind)));
        }
        let initial = entities.initial(kind);
        if initial + entities.births(kind) != entities.deaths(kind) + living {
            fail(case, tick, format!("{kind:?}: initial + births - deaths != living"));
        }
        let (births, deaths) = (entities.births(kind), entities.deaths(kind));
        if births < previous[k].0 || deaths < previous[k].1 {
            fail(case, tick, format!("{kind:?}: cumulative counters decreased"));
        }
        previous[k] = (births, deaths);
    }
    for o in entities.living() {
        if o.energy() < 0.0 || o.health() < 0.0 || !o.energy().is_finite() || !o.health().is_finite() {
            fail(case, tick, format!("organism {} has energy {} or health {}", o.id().0, o.energy(), o.health()));
        }
        let c = o.cell();
        if torus.cell_from_index(torus.index(c)) != Some(c) {
            fail(case, tick, format!("organism {} is off the torus", o.id().0));
        }
    }
    let resources = &sim.world().resources;
    for i in 0..torus.cell_count() {
        let r = resources.get_index(i);
        if !(0.0..=100.0).contains(&r) {
            fail(case, tick, format!("plant resource {r} at index {i} is out of [0, 100]"));
        }
    }
    // Wrapping: random centres, with seam cells forced in every few draws.
    let (w, h) = (torus.width(), torus.height());
    for probe in 0..4u64 {
        let x = match probe {
            0 => 0,
            1 => w - 1,
            _ => rng.next_below(w as u64) as u32,
        };
        let y = match probe {
            2 => 0,
            3 => h - 1,
            _ => rng.next_below(h as u64) as u32,
        };
        let centre = torus.cell(x, y).expect("centre is on the torus");
        let radius = rng.next_below(7) as u32;
        let filter = match rng.next_below(4) {
            0 => None,
            1 => Some(Kind::Plant),
            2 => Some(Kind::Herbivore),
            _ => Some(Kind::Carnivore),
        };
        let got: Vec<u64> = sim.spatial().within(centre, radius, filter).into_iter().map(|id| id.0).collect();
        let want = brute_within(sim, &torus, centre, radius, filter);
        if got != want {
            fail(case, tick, format!("within({x},{y},r={radius},{filter:?}) gave {} ids, brute force {}", got.len(), want.len()));
        }
    }
}

#[test]
fn randomised_invariants_hold_for_every_tick() {
    let mut rng = Rng::from_seed(MASTER_SEED);
    for index in 0..cases() {
        let case = random_case(&mut rng, index);
        let mut sim = new_sim(&case.config);
        let mut previous = [(0u64, 0u64); 3];
        check_tick(&case, &sim, 0, &mut rng, &mut previous);
        for tick in 1..=case.ticks {
            sim.tick();
            check_tick(&case, &sim, tick, &mut rng, &mut previous);
        }
    }
}

#[test]
fn same_configuration_gives_same_state_hash() {
    let mut rng = Rng::from_seed(MASTER_SEED ^ 0xA5A5);
    for index in 0..cases() {
        let case = random_case(&mut rng, index);
        let ticks = case.ticks.min(120);
        let mut a = new_sim(&case.config);
        let mut b = new_sim(&case.config);
        for _ in 0..ticks {
            a.tick();
            b.tick();
        }
        if checkpoint::state_hash(&a) != checkpoint::state_hash(&b) {
            fail(&case, ticks, "two runs of the same configuration have different state hashes".into());
        }
    }
}

#[test]
fn checkpoint_split_run_equals_uninterrupted_run() {
    let mut rng = Rng::from_seed(MASTER_SEED ^ 0x5171);
    for index in 0..cases() {
        let case = random_case(&mut rng, index);
        let total = case.ticks.min(160);
        let split = 1 + rng.next_below(total - 1);
        let mut whole = new_sim(&case.config);
        for _ in 0..total {
            whole.tick();
        }
        let mut first = new_sim(&case.config);
        for _ in 0..split {
            first.tick();
        }
        let bytes = checkpoint::write_file(&first, case.config.seed);
        let mut resumed = checkpoint::read_file(&bytes)
            .unwrap_or_else(|e| fail(&case, split, format!("checkpoint does not read back: {e:?}")))
            .sim;
        for _ in split..total {
            resumed.tick();
        }
        if checkpoint::state_hash(&whole) != checkpoint::state_hash(&resumed) {
            fail(&case, total, format!("split at {split} differs from the uninterrupted run"));
        }
        for kind in Kind::ALL {
            if whole.entities().living_count(kind) != resumed.entities().living_count(kind) {
                fail(&case, total, format!("{kind:?}: living counts differ after resume"));
            }
        }
    }
}

#[test]
fn different_seeds_give_different_state_hashes() {
    let mut rng = Rng::from_seed(MASTER_SEED ^ 0x0D1F);
    for index in 0..cases() {
        let case = random_case(&mut rng, index);
        let mut other = case.config.clone();
        other.seed = case.config.seed.wrapping_add(1);
        let mut a = new_sim(&case.config);
        let mut b = new_sim(&other);
        for _ in 0..20 {
            a.tick();
            b.tick();
        }
        if checkpoint::state_hash(&a) == checkpoint::state_hash(&b) {
            fail(&case, 20, "seeds differ but the state hashes are equal".into());
        }
    }
}

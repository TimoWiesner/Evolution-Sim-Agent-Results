//! Evolution Simulation core library.
//!
//! The simulation engine lives here. It must not depend on the UI or CLI crates
//! (ADR-0001, docs/ARCHITECTURE.md). TASK-002 only provides the contract version constant.

pub mod analytics;
pub mod batch;
pub mod checkpoint;
pub mod climate;
pub mod config;
pub mod ecology;
pub mod entities;
pub mod feeding;
pub mod genome;
pub mod hunting;
pub mod mating;
pub mod metrics;
pub mod movement;
pub mod perf;
pub mod reproduction;
pub mod rng;
pub mod runner;
pub mod sha256;
pub mod sim;
pub mod spatial;
pub mod species;
pub mod world;

#[cfg(test)]
mod food_chain_tests;

#[cfg(test)]
mod invariant_tests;

/// Version of the external interface defined in `docs/CONTRACT.md`.
pub const CONTRACT_VERSION: u32 = 1;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn contract_version_is_one() {
        assert_eq!(CONTRACT_VERSION, 1);
    }
}

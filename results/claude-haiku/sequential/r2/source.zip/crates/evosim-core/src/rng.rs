//! The only random number generator of the simulation core.
//!
//! Algorithm: xoshiro256** (Blackman and Vigna) with its 256-bit state seeded from a single `u64`
//! through SplitMix64. Decisions are recorded in `docs/decisions/ADR-0008-random-generator-and-tick-scheduler.md`.
//!
//! - No wall clock, no OS entropy, no global or thread-local generator. The state is four `u64` words and can be
//!   exported with [`Rng::state`] and restored exactly with [`Rng::from_state`].
//! - Only integer arithmetic is used for draws; [`Rng::next_f64`] is derived from the top 53 bits.

use std::fmt;

/// Error returned when a generator is restored from an invalid state.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RngError {
    /// The all-zero state is a fixed point of xoshiro256** and never leaves it, so it is not a valid state.
    AllZeroState,
}

impl fmt::Display for RngError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            RngError::AllZeroState => write!(f, "random generator state must not be all zero"),
        }
    }
}

impl std::error::Error for RngError {}

/// SplitMix64 step: advances `state` and returns the next output. Used only for seeding.
fn splitmix64(state: &mut u64) -> u64 {
    *state = state.wrapping_add(0x9E37_79B9_7F4A_7C15);
    let mut z = *state;
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

/// Fixed 64-bit mix of a generator state, used for the trace fingerprint. Not a generator itself.
pub(crate) fn fingerprint(state: [u64; 4]) -> u64 {
    let mut h: u64 = 0x243F_6A88_85A3_08D3;
    for word in state {
        h ^= word;
        // SplitMix64 finaliser applied to the running value.
        h = (h ^ (h >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        h = (h ^ (h >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        h ^= h >> 31;
    }
    h
}

/// xoshiro256** generator. The only source of randomness in the core.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Rng {
    s: [u64; 4],
}

impl Rng {
    /// Creates a generator from a seed. Every seed is valid, including zero.
    pub fn from_seed(seed: u64) -> Rng {
        let mut sm = seed;
        let mut s = [0u64; 4];
        for word in &mut s {
            *word = splitmix64(&mut sm);
        }
        // Not reachable in practice for SplitMix64 output, but the all-zero state must never be produced.
        if s == [0; 4] {
            s[0] = 1;
        }
        Rng { s }
    }

    /// Restores a generator from an exported state. Fails only for the all-zero state.
    pub fn from_state(state: [u64; 4]) -> Result<Rng, RngError> {
        if state == [0; 4] {
            return Err(RngError::AllZeroState);
        }
        Ok(Rng { s: state })
    }

    /// Exports the exact state. `from_state(rng.state())` continues the same stream.
    pub fn state(&self) -> [u64; 4] {
        self.s
    }

    /// Returns the next 64 random bits.
    pub fn next_u64(&mut self) -> u64 {
        let s = &mut self.s;
        let result = s[1].wrapping_mul(5).rotate_left(7).wrapping_mul(9);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        result
    }

    /// Returns a uniform integer in `0..n` without modulo bias (rejection sampling).
    ///
    /// # Panics
    /// Panics if `n == 0`.
    pub fn next_below(&mut self, n: u64) -> u64 {
        assert!(n > 0, "next_below requires n >= 1");
        // Values below `threshold` are the only ones that would make `x % n` non-uniform.
        let threshold = n.wrapping_neg() % n;
        loop {
            let x = self.next_u64();
            if x >= threshold {
                return x % n;
            }
        }
    }

    /// Returns a uniform `f64` in `[0, 1)` built from the top 53 bits.
    pub fn next_f64(&mut self) -> f64 {
        (self.next_u64() >> 11) as f64 * (1.0 / (1u64 << 53) as f64)
    }

    /// Returns `true` with probability `p`. `p <= 0` never succeeds and `p >= 1` always does.
    pub fn chance(&mut self, p: f64) -> bool {
        self.next_f64() < p
    }
}

impl Rng {
    /// Canonical encoding of the generator state (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Rng { s } = self;
        for word in s {
            enc.u64(*word);
        }
    }

    /// Reads the four state words (ADR-0023 D3). The all-zero state is refused by [`Rng::from_state`].
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Rng, crate::checkpoint::CheckpointError> {
        let mut s = [0u64; 4];
        for word in &mut s {
            *word = dec.u64()?;
        }
        Rng::from_state(s).map_err(|e| crate::checkpoint::invalid_because("rng state", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn splitmix64_seed0_first_output_matches_reference() {
        let mut s = 0u64;
        assert_eq!(splitmix64(&mut s), 0xE220_A839_7B1D_CDAF);
    }

    #[test]
    fn xoshiro_reference_vector_state_1_2_3_4() {
        let mut rng = Rng::from_state([1, 2, 3, 4]).unwrap();
        assert_eq!(rng.next_u64(), 11520);
    }

    #[test]
    fn same_seed_same_sequence() {
        let mut a = Rng::from_seed(12345);
        let mut b = Rng::from_seed(12345);
        for _ in 0..10_000 {
            assert_eq!(a.next_u64(), b.next_u64());
        }
    }

    #[test]
    fn different_seed_different_sequence() {
        let mut a = Rng::from_seed(1);
        let mut b = Rng::from_seed(2);
        let differs = (0..16).any(|_| a.next_u64() != b.next_u64());
        assert!(differs);
        assert_ne!(Rng::from_seed(1).state(), Rng::from_seed(2).state());
    }

    #[test]
    fn seed_zero_is_valid() {
        let rng = Rng::from_seed(0);
        assert_ne!(rng.state(), [0; 4]);
        let mut rng = rng;
        let _ = rng.next_u64();
    }

    #[test]
    fn from_state_rejects_all_zero() {
        assert_eq!(Rng::from_state([0; 4]), Err(RngError::AllZeroState));
        assert!(Rng::from_state([0, 0, 0, 1]).is_ok());
    }

    #[test]
    fn state_export_restore_continues_identically() {
        let mut rng = Rng::from_seed(99);
        for _ in 0..1000 {
            rng.next_u64();
        }
        let mut restored = Rng::from_state(rng.state()).unwrap();
        for _ in 0..1000 {
            assert_eq!(rng.next_u64(), restored.next_u64());
        }
    }

    #[test]
    fn next_below_stays_in_range_and_covers_small_n() {
        let mut rng = Rng::from_seed(7);
        for _ in 0..1000 {
            assert_eq!(rng.next_below(1), 0);
        }
        for n in [3u64, 7] {
            let mut seen = vec![false; n as usize];
            for _ in 0..10_000 {
                let v = rng.next_below(n);
                assert!(v < n);
                seen[v as usize] = true;
            }
            assert!(seen.iter().all(|&s| s), "n = {n} did not hit every value");
        }
    }

    #[test]
    #[should_panic(expected = "n >= 1")]
    fn next_below_zero_panics() {
        Rng::from_seed(1).next_below(0);
    }

    #[test]
    fn next_f64_in_unit_interval() {
        let mut rng = Rng::from_seed(3);
        for _ in 0..10_000 {
            let v = rng.next_f64();
            assert!((0.0..1.0).contains(&v));
        }
    }

    #[test]
    fn chance_extremes() {
        let mut rng = Rng::from_seed(5);
        for _ in 0..1000 {
            assert!(!rng.chance(0.0));
            assert!(rng.chance(1.0));
        }
    }

    #[test]
    fn fingerprint_depends_on_state() {
        assert_eq!(fingerprint([1, 2, 3, 4]), fingerprint([1, 2, 3, 4]));
        assert_ne!(fingerprint([1, 2, 3, 4]), fingerprint([1, 2, 3, 5]));
    }
}

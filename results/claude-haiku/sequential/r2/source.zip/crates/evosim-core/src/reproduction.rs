//! Plant reproduction and seed dispersal (TASK-012, ADR-0013).
//!
//! Plants are asexual: a mature plant produces a seed whose genome is a mutated copy of its own. The seed lands on one
//! uniformly drawn cell within `seed_radius` of the parent (torus distance, wrapping over both edges). A seed is
//! placed only if the target cell has room (fewer than [`CELL_PLANT_CAP`] living plants) and resources (pool of at
//! least [`SEED_RESOURCE_MIN`]). Every rule is local: the parent's own energy, the target cell's plants and pool.
//! No global count is consulted.

use std::fmt;

use crate::config::Config;
use crate::ecology::ResourceField;
use crate::entities::{Birth, Entities, EntityError, Kind, LifespanRanges, OrganismId};
use crate::genome::{copy_child, GenomeError, Mutation};
use crate::rng::Rng;
use crate::sim::mutation_settings;
use crate::spatial::{SpatialError, SpatialIndex};
use crate::world::Torus;

/// A plant may seed only with at least this much energy (ADR-0013). Set to 45, below the 70 of the first plan: under
/// the TASK-011 energy economy (growth reserve 40, satiation) plant energy plateaus near 35 with a maximum near 55, so
/// 70 was never reached (0 seeds in 500 ticks). 45 gives about 1% mature plants and a slowly growing, bounded population.
pub const SEED_ENERGY_MIN: f32 = 45.0;
/// Energy the parent pays for every seed attempt, including refused ones.
pub const SEED_COST: f32 = 20.0;
/// Energy the seedling starts with. `SEED_COST - SEED_ENDOWMENT` is lost; no energy is created.
pub const SEED_ENDOWMENT: f32 = 10.0;
/// Seedling health as a fraction of its own `max_health`.
pub const SEED_HEALTH_FRACTION: f32 = 0.5;
/// Room rule: at most this many living plants in the target cell.
pub const CELL_PLANT_CAP: usize = 6;
/// Resource rule: the target cell's pool must hold at least this much.
pub const SEED_RESOURCE_MIN: f32 = 5.0;
const _: () = assert!(SEED_ENDOWMENT < SEED_COST);

/// Largest accepted seed radius (the configuration allows 0..=16).
pub const MAX_SEED_RADIUS: u32 = 16;

/// Error when seeding settings or a reproduction step are invalid.
#[derive(Clone, Debug, PartialEq)]
pub enum ReproductionError {
    /// The per-plant chance is not a number in `[0, 1]`.
    BadChance { chance: f64 },
    /// The seed radius is above [`MAX_SEED_RADIUS`].
    BadRadius { radius: u32 },
    /// The mutation settings are invalid.
    Genome(GenomeError),
    /// An organism could not be created.
    Entity(EntityError),
    /// The neighbour index rejected a change.
    Spatial(SpatialError),
}

impl fmt::Display for ReproductionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ReproductionError::BadChance { chance } => {
                write!(f, "reproduction chance {chance} is not in [0, 1]")
            }
            ReproductionError::BadRadius { radius } => {
                write!(f, "seed radius {radius} is above {MAX_SEED_RADIUS}")
            }
            ReproductionError::Genome(e) => write!(f, "{e}"),
            ReproductionError::Entity(e) => write!(f, "{e}"),
            ReproductionError::Spatial(e) => write!(f, "{e}"),
        }
    }
}

impl std::error::Error for ReproductionError {}

impl From<GenomeError> for ReproductionError {
    fn from(e: GenomeError) -> Self {
        ReproductionError::Genome(e)
    }
}

impl From<EntityError> for ReproductionError {
    fn from(e: EntityError) -> Self {
        ReproductionError::Entity(e)
    }
}

impl From<SpatialError> for ReproductionError {
    fn from(e: SpatialError) -> Self {
        ReproductionError::Spatial(e)
    }
}

/// Settings of plant seeding, taken from the configuration and stored in `Simulation`.
#[derive(Clone, Debug, PartialEq)]
pub struct SeedingSettings {
    /// `plants.reproduction_chance`: per-tick chance of a mature plant with mean fertility (0.5).
    pub chance: f64,
    /// `plants.seed_radius`: dispersal radius in cells (Chebyshev, on the torus).
    pub radius: u32,
    /// `genetics.mutation_rate` and `genetics.mutation_strength`.
    pub mutation: Mutation,
}

impl SeedingSettings {
    /// Validates the settings. `chance` must be in `[0, 1]` (NaN rejected) and `radius` at most [`MAX_SEED_RADIUS`].
    pub fn new(
        chance: f64,
        radius: u32,
        mutation: Mutation,
    ) -> Result<SeedingSettings, ReproductionError> {
        if !(0.0..=1.0).contains(&chance) {
            // also rejects NaN
            return Err(ReproductionError::BadChance { chance });
        }
        if radius > MAX_SEED_RADIUS {
            return Err(ReproductionError::BadRadius { radius });
        }
        Ok(SeedingSettings {
            chance,
            radius,
            mutation,
        })
    }

    /// Builds the settings from `plants.reproduction_chance`, `plants.seed_radius` and the genetics section.
    pub fn from_config(config: &Config) -> Result<SeedingSettings, ReproductionError> {
        let radius = u32::try_from(config.plants.seed_radius)
            .map_err(|_| ReproductionError::BadRadius { radius: u32::MAX })?;
        SeedingSettings::new(
            config.plants.reproduction_chance,
            radius,
            mutation_settings(config)?,
        )
    }
}

/// Counts of one Reproduction phase. Integers, so they can be compared exactly in tests.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ReproductionReport {
    /// Seed attempts (a mature plant passed the chance draw and paid [`SEED_COST`]).
    pub seeds: u64,
    /// Seeds that became organisms.
    pub placed: u64,
    /// Seeds refused because the target cell was full.
    pub refused_room: u64,
    /// Seeds refused because the target cell's pool was too small.
    pub refused_resources: u64,
}

/// Runs the Reproduction phase once (ADR-0013). Only plants living at the start of the phase may seed, in ascending
/// id order, so a newborn never seeds in its birth tick.
pub fn reproduction_phase(
    entities: &mut Entities,
    spatial: &mut SpatialIndex,
    resources: &ResourceField,
    torus: &Torus,
    settings: &SeedingSettings,
    lifespans: &LifespanRanges,
    rng: &mut Rng,
) -> Result<ReproductionReport, ReproductionError> {
    let mut report = ReproductionReport::default();
    let parents: Vec<OrganismId> = entities
        .living()
        .filter(|o| o.kind() == Kind::Plant)
        .map(|o| o.id())
        .collect();
    for id in parents {
        // Read the parent's state first; the borrow ends before any mutation.
        let (energy, cell, fertility) = match entities.get(id) {
            Some(p) if p.is_alive() => (p.energy(), p.cell(), p.traits().fertility()),
            _ => continue,
        };
        if energy < SEED_ENERGY_MIN {
            continue;
        }
        let p = (settings.chance * 2.0 * f64::from(fertility)).clamp(0.0, 1.0);
        if !rng.chance(p) {
            continue;
        }
        report.seeds += 1;
        entities
            .get_mut(id)
            .expect("the parent was read just above")
            .drain_energy(SEED_COST);

        // Dispersal: one uniform draw over the square of radius `settings.radius` (the parent's cell included).
        let cells = torus.neighbours(cell, settings.radius);
        let target = cells[rng.next_below(cells.len() as u64) as usize];

        // Room and resources: local checks on the target cell. A refused seed changes no organism and no pool.
        if spatial.within(target, 0, Some(Kind::Plant)).len() >= CELL_PLANT_CAP {
            report.refused_room += 1;
            continue;
        }
        if resources.get_index(torus.index(target)) < SEED_RESOURCE_MIN {
            report.refused_resources += 1;
            continue;
        }

        // Inheritance: a mutated copy of the parent's genome, then the birth bookkeeping.
        let genome = {
            let parent = entities.get(id).expect("the parent is still stored");
            copy_child(parent.genome(), settings.mutation, rng)
        };
        let mut birth =
            Birth::from_genome_in(Kind::Plant, target, genome, SEED_ENDOWMENT, 0.0, lifespans)?;
        birth.health = birth.traits.max_health() * SEED_HEALTH_FRACTION;
        let child = entities.spawn_child(birth, [Some(id), None])?;
        spatial.insert(child, target, Kind::Plant)?;
        report.placed += 1;
    }
    Ok(report)
}

impl SeedingSettings {
    /// Canonical encoding of the plant seeding settings (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let SeedingSettings {
            chance,
            radius,
            mutation,
        } = self;
        enc.f64(*chance);
        enc.u32(*radius);
        mutation.encode_state(enc);
    }

    /// Reads the seeding settings and validates them with [`SeedingSettings::new`] (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<SeedingSettings, crate::checkpoint::CheckpointError> {
        let chance = dec.f64()?;
        let radius = dec.u32()?;
        let mutation = crate::genome::Mutation::decode_state(dec)?;
        SeedingSettings::new(chance, radius, mutation)
            .map_err(|e| crate::checkpoint::invalid_because("seeding", e))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::Initial;
    use crate::genome::{Genome, LOCI_PER_HAPLOTYPE};
    use crate::sim::Simulation;
    use crate::world::Cell;

    fn mutation(rate: f64, strength: u64) -> Mutation {
        Mutation::new(rate, strength).unwrap()
    }

    /// Settings with chance 1.0: a mature plant with mean fertility (0.5) seeds on every call.
    fn always(radius: u32, mutation: Mutation) -> SeedingSettings {
        SeedingSettings::new(1.0, radius, mutation).unwrap()
    }

    /// A small world with every pool at `pool`, and a store holding nothing yet.
    struct World2 {
        torus: Torus,
        entities: Entities,
        spatial: SpatialIndex,
        resources: ResourceField,
    }

    fn world2(w: u32, h: u32, pool: f32) -> World2 {
        let torus = Torus::new(w, h).unwrap();
        World2 {
            resources: ResourceField::from_values(&torus, vec![pool; torus.cell_count()]).unwrap(),
            entities: Entities::new(),
            spatial: SpatialIndex::new(torus),
            torus,
        }
    }

    /// Adds a plant founder with the given loci value (128 = mean 0.5), energy and health.
    fn add_plant(w: &mut World2, cell: Cell, energy: f32, locus: u8) -> OrganismId {
        let genome = Genome::new(1, vec![locus; LOCI_PER_HAPLOTYPE]).unwrap();
        let birth = Birth::from_genome(Kind::Plant, cell, genome, energy, 10.0).unwrap();
        let id = w.entities.spawn_founder(birth).unwrap();
        w.spatial.insert(id, cell, Kind::Plant).unwrap();
        id
    }

    fn cell(w: &World2, x: u32, y: u32) -> Cell {
        w.torus.cell(x, y).unwrap()
    }

    fn phase(w: &mut World2, s: &SeedingSettings, rng: &mut Rng) -> ReproductionReport {
        reproduction_phase(
            &mut w.entities,
            &mut w.spatial,
            &w.resources,
            &w.torus,
            s,
            &crate::entities::LifespanRanges::default(),
            rng,
        )
        .unwrap()
    }

    fn energy(w: &World2, id: OrganismId) -> f32 {
        w.entities.get(id).unwrap().energy()
    }

    /// Every living plant id, ascending, with its cell.
    fn living_plants(w: &World2) -> Vec<(OrganismId, Cell)> {
        w.entities
            .living()
            .filter(|o| o.kind() == Kind::Plant)
            .map(|o| (o.id(), o.cell()))
            .collect()
    }

    #[test]
    fn seeding_settings_reject_bad_chance() {
        for bad in [f64::NAN, -0.1, 1.1, f64::INFINITY] {
            let r = SeedingSettings::new(bad, 2, mutation(0.0, 1));
            assert!(
                matches!(r, Err(ReproductionError::BadChance { .. })),
                "chance {bad} accepted"
            );
        }
        assert!(SeedingSettings::new(0.0, 0, mutation(0.0, 1)).is_ok());
        assert!(SeedingSettings::new(1.0, 16, mutation(0.0, 1)).is_ok());
    }

    #[test]
    fn seeding_settings_reject_bad_radius() {
        assert_eq!(
            SeedingSettings::new(0.5, 17, mutation(0.0, 1)),
            Err(ReproductionError::BadRadius { radius: 17 })
        );
    }

    #[test]
    fn from_config_maps_plant_and_genetics_keys() {
        let mut c = Config::new(
            1,
            8,
            8,
            Initial {
                plants: 0,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        c.plants.reproduction_chance = 0.3;
        c.plants.seed_radius = 5;
        c.genetics.mutation_rate = 0.25;
        c.genetics.mutation_strength = 9;
        let s = SeedingSettings::from_config(&c).unwrap();
        assert_eq!(s.chance, 0.3);
        assert_eq!(s.radius, 5);
        assert_eq!(s.mutation.rate, 0.25);
        assert_eq!(s.mutation.strength, 9);
    }

    #[test]
    fn plant_below_threshold_never_seeds() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 0, 0);
        let p = add_plant(&mut w, c, SEED_ENERGY_MIN - 0.1, 128);
        let s = always(2, mutation(0.0, 1));
        let mut rng = Rng::from_seed(1);
        for _ in 0..1000 {
            let r = phase(&mut w, &s, &mut rng);
            assert_eq!(r, ReproductionReport::default());
        }
        assert_eq!(w.entities.births(Kind::Plant), 0);
        assert_eq!(w.entities.next_id(), p.0 + 1);
        assert_eq!(energy(&w, p), SEED_ENERGY_MIN - 0.1);
    }

    #[test]
    fn plant_at_threshold_seeds_and_pays_the_cost() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 3, 3);
        let p = add_plant(&mut w, c, SEED_ENERGY_MIN, 128);
        let mut rng = Rng::from_seed(2);
        let r = phase(&mut w, &always(0, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.seeds, 1);
        assert_eq!(r.placed, 1);
        assert_eq!(energy(&w, p), SEED_ENERGY_MIN - SEED_COST);
    }

    #[test]
    fn seed_costs_parent_and_endows_child() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 4, 4);
        let parent = add_plant(&mut w, c, 100.0, 128);
        let mut rng = Rng::from_seed(3);
        let r = phase(&mut w, &always(1, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.placed, 1);
        let child = w.entities.get(OrganismId(parent.0 + 1)).unwrap();
        assert_eq!(child.kind(), Kind::Plant);
        assert_eq!(child.energy(), SEED_ENDOWMENT);
        assert_eq!(
            child.health(),
            child.traits().max_health() * SEED_HEALTH_FRACTION
        );
        assert_eq!(energy(&w, parent), 100.0 - SEED_COST);
        // Total energy never grows: the parent loses SEED_COST, the child gains SEED_ENDOWMENT (checked at compile time).
    }

    /// One fresh seed from a plant at (0, 0) of an 8x8 world, with the given settings and generator seed.
    fn one_seed_landing(radius: u32, rng_seed: u64) -> Option<Cell> {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 0, 0);
        let parent = add_plant(&mut w, c, 100.0, 128);
        let mut rng = Rng::from_seed(rng_seed);
        let r = phase(&mut w, &always(radius, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.seeds, 1);
        if r.placed == 1 {
            let child = OrganismId(parent.0 + 1);
            Some(w.entities.get(child).unwrap().cell())
        } else {
            None
        }
    }

    #[test]
    fn seeds_land_within_radius_on_the_torus_and_wrap_over_both_edges() {
        let torus = Torus::new(8, 8).unwrap();
        let origin = torus.cell(0, 0).unwrap();
        let mut seen = std::collections::BTreeSet::new();
        for k in 0..2000u64 {
            let landing =
                one_seed_landing(2, 1000 + k).expect("empty pools and no crowding: always placed");
            assert!(
                torus.distance(origin, landing) <= 2,
                "landed at ({}, {}), torus distance {}",
                landing.x(),
                landing.y(),
                torus.distance(origin, landing)
            );
            seen.insert((landing.x(), landing.y()));
        }
        // Across the seams: x = 6, 7 (left of the origin) and y = 6, 7 (above it) are reached.
        assert!(
            seen.iter().any(|&(x, _)| x == 6 || x == 7),
            "no x-wrap landing"
        );
        assert!(
            seen.iter().any(|&(_, y)| y == 6 || y == 7),
            "no y-wrap landing"
        );
        // The square has 25 cells; a uniform draw over 2000 seeds reaches all of them.
        assert_eq!(seen.len(), 25, "landing cells: {seen:?}");
    }

    #[test]
    fn radius_zero_seeds_stay_on_the_parent_cell() {
        for k in 0..50u64 {
            let landing = one_seed_landing(0, 77 + k).expect("placed");
            assert_eq!((landing.x(), landing.y()), (0, 0));
        }
    }

    #[test]
    fn child_records_parent_and_generation() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 2, 2);
        let parent = add_plant(&mut w, c, 100.0, 128);
        let mut rng = Rng::from_seed(9);
        phase(&mut w, &always(1, mutation(0.0, 1)), &mut rng);
        let child = OrganismId(parent.0 + 1);
        let child_ref = w.entities.get(child).unwrap();
        assert_eq!(child_ref.parents(), [Some(parent), None]);
        assert_eq!(child_ref.generation(), 1);
        // A grandchild: feed the child to the threshold and let it seed.
        w.entities.get_mut(child).unwrap().add_energy(100.0);
        let r = phase(&mut w, &always(1, mutation(0.0, 1)), &mut rng);
        assert!(r.placed >= 1);
        let grandchild = living_plants(&w)
            .into_iter()
            .map(|(id, _)| w.entities.get(id).unwrap())
            .find(|o| o.parents()[0] == Some(child))
            .expect("the child seeded");
        assert_eq!(grandchild.generation(), 2);
    }

    #[test]
    fn mutation_rate_zero_copies_the_genome_exactly() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 1, 1);
        let parent = add_plant(&mut w, c, 100.0, 77);
        let mut rng = Rng::from_seed(4);
        phase(&mut w, &always(1, mutation(0.0, 8)), &mut rng);
        let child = w.entities.get(OrganismId(parent.0 + 1)).unwrap();
        assert_eq!(
            child.genome().loci(),
            w.entities.get(parent).unwrap().genome().loci()
        );
    }

    #[test]
    fn child_genome_is_parent_with_bounded_mutation() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 1, 1);
        let parent = add_plant(&mut w, c, 100.0, 128);
        let strength = 8u8;
        let mut rng = Rng::from_seed(5);
        phase(
            &mut w,
            &always(1, mutation(1.0, u64::from(strength))),
            &mut rng,
        );
        let child = w.entities.get(OrganismId(parent.0 + 1)).unwrap();
        let parent_loci = w.entities.get(parent).unwrap().genome().loci().to_vec();
        let mut changed = 0usize;
        for (a, b) in child.genome().loci().iter().zip(&parent_loci) {
            let d = (i32::from(*a) - i32::from(*b)).abs();
            assert!(d <= i32::from(strength), "locus moved by {d}");
            if d != 0 {
                changed += 1;
            }
        }
        assert!(changed > 0, "rate 1.0 changed no locus");
        // The child's traits decode from its own genome (Birth::from_genome checked this at spawn).
        assert_eq!(child.genome().loci().len(), LOCI_PER_HAPLOTYPE);
    }

    #[test]
    fn full_cell_refuses_the_seed_and_creates_nothing() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 5, 5);
        let parent = add_plant(&mut w, c, 100.0, 128);
        for _ in 0..(CELL_PLANT_CAP - 1) {
            add_plant(&mut w, c, 0.0, 128);
        }
        assert_eq!(
            w.spatial.within(c, 0, Some(Kind::Plant)).len(),
            CELL_PLANT_CAP
        );
        let next_before = w.entities.next_id();
        let births_before = w.entities.births(Kind::Plant);
        let mut rng = Rng::from_seed(6);
        let r = phase(&mut w, &always(0, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.seeds, 1);
        assert_eq!(r.refused_room, 1);
        assert_eq!(r.placed, 0);
        assert_eq!(w.entities.next_id(), next_before);
        assert_eq!(w.entities.births(Kind::Plant), births_before);
        // The refused seed still cost the parent.
        assert_eq!(energy(&w, parent), 100.0 - SEED_COST);
    }

    #[test]
    fn empty_pool_refuses_the_seed_and_creates_nothing() {
        let mut w = world2(8, 8, SEED_RESOURCE_MIN - 0.1);
        let c = cell(&w, 0, 0);
        add_plant(&mut w, c, 100.0, 128);
        let next_before = w.entities.next_id();
        let mut rng = Rng::from_seed(7);
        let r = phase(&mut w, &always(0, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.refused_resources, 1);
        assert_eq!(r.placed, 0);
        assert_eq!(w.entities.next_id(), next_before);
        assert_eq!(w.entities.births(Kind::Plant), 0);
        // The pool is not changed by seeding.
        assert_eq!(
            w.resources.get_index(w.torus.index(c)),
            SEED_RESOURCE_MIN - 0.1
        );
    }

    #[test]
    fn newborns_do_not_seed_in_their_birth_tick() {
        let mut w = world2(8, 8, 100.0);
        let c = cell(&w, 0, 0);
        // Only one parent is mature; its child (energy 20) cannot seed in the same call either way.
        add_plant(&mut w, c, 100.0, 128);
        let mut rng = Rng::from_seed(8);
        let r = phase(&mut w, &always(1, mutation(0.0, 1)), &mut rng);
        assert_eq!(r.seeds, 1, "only the parent alive at the start may seed");
    }

    #[test]
    fn reproduction_phase_is_repeatable_for_the_same_generator_state() {
        let run = |seed: u64| {
            let mut w = world2(16, 12, 100.0);
            let mut rng = Rng::from_seed(seed);
            for k in 0..6u32 {
                let c = cell(&w, k * 2, k);
                add_plant(&mut w, c, 100.0, 128);
            }
            let s = SeedingSettings::new(0.5, 2, mutation(0.2, 8)).unwrap();
            for _ in 0..40 {
                for (id, _) in living_plants(&w) {
                    w.entities.get_mut(id).unwrap().add_energy(100.0);
                }
                phase(&mut w, &s, &mut rng);
            }
            (living_plants(&w), w.entities.next_id(), rng.state())
        };
        assert_eq!(run(11), run(11));
        assert_ne!(run(11).2, run(12).2);
    }

    #[test]
    fn zero_initial_plants_stay_zero_with_animals_present() {
        let config = Config::new(
            21,
            32,
            24,
            Initial {
                plants: 0,
                herbivores: 60,
                carnivores: 12,
            },
        )
        .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        sim.run(500);
        assert_eq!(sim.entities().living_count(Kind::Plant), 0);
        assert_eq!(sim.entities().births(Kind::Plant), 0);
        assert_eq!(
            sim.entities().next_id(),
            72,
            "only the 72 founders were ever created"
        );
    }

    #[test]
    fn balance_holds_over_a_seeded_reproduction_run() {
        let config = Config::new(
            31,
            24,
            16,
            Initial {
                plants: 150,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        for _ in 0..200 {
            sim.tick();
            sim.entities().check_balance().unwrap();
            sim.entities().check_invariants().unwrap();
            sim.check_spatial().unwrap();
        }
        assert!(
            sim.entities().births(Kind::Plant) > 0,
            "no plant seeded in 200 ticks"
        );
    }

    #[test]
    fn reproduction_run_is_repeatable_per_seed() {
        let config = |seed| {
            Config::new(
                seed,
                24,
                16,
                Initial {
                    plants: 120,
                    herbivores: 10,
                    carnivores: 2,
                },
            )
            .unwrap()
        };
        let run = |seed| {
            let c = config(seed);
            let mut sim = Simulation::new(&c).unwrap();
            sim.populate_initial(&c).unwrap();
            sim.run(150);
            sim
        };
        assert_eq!(run(41), run(41));
        assert_ne!(run(41), run(42));
    }

    #[test]
    fn plant_only_population_is_bounded_and_survives() {
        let config = Config::new(
            51,
            64,
            48,
            Initial {
                plants: 400,
                herbivores: 0,
                carnivores: 0,
            },
        )
        .unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        let cells = sim.world().topology.cell_count() as u64;
        for t in 0..500 {
            sim.tick();
            let living = sim.entities().living_count(Kind::Plant);
            assert!(
                living <= CELL_PLANT_CAP as u64 * cells,
                "tick {t}: {living} plants"
            );
            assert!(sim.world().resources.values().iter().all(|&v| v >= 0.0));
        }
        assert!(
            sim.entities().living_count(Kind::Plant) > 0,
            "plants died out in 500 ticks"
        );
        assert!(sim.entities().births(Kind::Plant) > 0);
    }
}

use super::json::{self, Value};
use super::*;

const CONTRACT_EXAMPLE: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

fn example_initial() -> Initial {
    Initial { plants: 400, herbivores: 120, carnivores: 20 }
}

fn defaults() -> Config {
    Config::new(42, 64, 48, example_initial()).expect("defaults are valid")
}

/// Parses `text`, expects a ConfigError, and returns it.
fn expect_err(text: &str) -> ConfigError {
    match Config::from_json(text) {
        Ok(_) => panic!("expected an error for: {text}"),
        Err(e) => e,
    }
}

/// Asserts that the error names `key` and its message contains `fragment`.
fn assert_key_error(text: &str, key: &str, fragment: &str) {
    let e = expect_err(text);
    assert_eq!(e.key.as_deref(), Some(key), "wrong key for {text}: {e}");
    assert!(e.message.contains(fragment), "message {:?} lacks {:?}", e.message, fragment);
    assert!(e.to_string().contains(key), "Display must name the key: {e}");
}

/// Replaces `"seed": 42` etc. by editing a JSON document built from the contract example.
fn with_root(extra: &str) -> String {
    // Adds a top-level member to the contract example (which ends with the `initial` object).
    let body = CONTRACT_EXAMPLE.trim_end();
    let body = &body[..body.len() - 1]; // drop only the root closing brace
    format!("{body}, {extra} }}")
}

// ---- acceptance: fixed keys, defaults, zero populations -------------------------------------

#[test]
fn fixed_keys_only_file_is_valid() {
    let c = Config::from_json(CONTRACT_EXAMPLE).expect("fixed-keys-only file must load");
    assert_eq!(c.seed, 42);
    assert_eq!((c.world.width, c.world.height), (64, 48));
    assert_eq!(c.initial, example_initial());
    assert_eq!(c, defaults());
}

#[test]
fn zero_initial_populations_are_valid() {
    let text = r#"{"seed":0,"world":{"width":1,"height":1},
        "initial":{"plants":0,"herbivores":0,"carnivores":0}}"#;
    let c = Config::from_json(text).expect("zero populations are valid");
    assert_eq!(c.initial, Initial { plants: 0, herbivores: 0, carnivores: 0 });
    assert_eq!(Config::from_json(&c.to_json()).unwrap(), c);
}

#[test]
fn zero_plants_only_is_valid() {
    let c = Config::new(1, 8, 8, Initial { plants: 0, herbivores: 5, carnivores: 0 }).unwrap();
    assert_eq!(c.initial.plants, 0);
}

#[test]
fn every_extra_parameter_has_default() {
    let c = defaults();
    assert_eq!(c.climate.season_length, DEFAULT_CLIMATE_SEASON_LENGTH);
    assert_eq!(c.climate.weather_amplitude, DEFAULT_CLIMATE_WEATHER_AMPLITUDE);
    assert_eq!(c.plants.growth_rate, DEFAULT_PLANTS_GROWTH_RATE);
    assert_eq!(c.plants.reproduction_chance, DEFAULT_PLANTS_REPRODUCTION_CHANCE);
    assert_eq!(c.plants.seed_radius, DEFAULT_PLANTS_SEED_RADIUS);
    assert_eq!(c.plants.max_age, DEFAULT_PLANTS_MAX_AGE);
    assert_eq!(c.herbivores.metabolism, DEFAULT_HERBIVORES_METABOLISM);
    assert_eq!(c.herbivores.reproduction_energy, DEFAULT_HERBIVORES_REPRODUCTION_ENERGY);
    assert_eq!(c.herbivores.max_age, DEFAULT_HERBIVORES_MAX_AGE);
    assert_eq!(c.carnivores.metabolism, DEFAULT_CARNIVORES_METABOLISM);
    assert_eq!(c.carnivores.reproduction_energy, DEFAULT_CARNIVORES_REPRODUCTION_ENERGY);
    assert_eq!(c.carnivores.max_age, DEFAULT_CARNIVORES_MAX_AGE);
    assert_eq!(c.genetics.mutation_rate, DEFAULT_GENETICS_MUTATION_RATE);
    assert_eq!(c.genetics.mutation_strength, DEFAULT_GENETICS_MUTATION_STRENGTH);
    assert_eq!(c.species.distance, DEFAULT_SPECIES_DISTANCE);
    assert_eq!(c.species.check_interval, DEFAULT_SPECIES_CHECK_INTERVAL);
    assert_eq!(c.species.persistence_checks, DEFAULT_SPECIES_PERSISTENCE_CHECKS);
}

#[test]
fn explicit_defaults_equal_absent_groups() {
    // Writing every default out explicitly must give the same configuration as omitting them.
    let explicit = r#"{"seed":42,"world":{"width":64,"height":48},
      "initial":{"plants":400,"herbivores":120,"carnivores":20},
      "climate":{"season_length":240,"weather_amplitude":0.15},
      "plants":{"growth_rate":0.1,"reproduction_chance":0.05,"seed_radius":2,"max_age":1500},
      "herbivores":{"metabolism":0.8,"reproduction_energy":60.0,"max_age":300},
      "carnivores":{"metabolism":1.2,"reproduction_energy":90.0,"max_age":400},
      "genetics":{"mutation_rate":0.002,"mutation_strength":8},
      "species":{"distance":0.06,"check_interval":25,"persistence_checks":4}}"#;
    assert_eq!(Config::from_json(explicit).unwrap(), defaults());
}

#[test]
fn a_single_group_key_overrides_only_that_key() {
    let c = Config::from_json(&with_root(r#""plants": {"max_age": 7}"#)).unwrap();
    assert_eq!(c.plants.max_age, 7);
    assert_eq!(c.plants.growth_rate, DEFAULT_PLANTS_GROWTH_RATE);
}

#[test]
fn integer_literal_is_accepted_for_a_real() {
    let c = Config::from_json(&with_root(r#""plants": {"growth_rate": 1}"#)).unwrap();
    assert_eq!(c.plants.growth_rate, 1.0);
}

// ---- acceptance: wrong type ------------------------------------------------------------------

#[test]
fn wrong_type_string_for_width() {
    let t = r#"{"seed":1,"world":{"width":"64","height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#;
    assert_key_error(t, "world.width", "expected integer, found string");
}

#[test]
fn wrong_type_real_for_width() {
    let t = r#"{"seed":1,"world":{"width":64.0,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#;
    assert_key_error(t, "world.width", "expected integer, found real number");
}

#[test]
fn wrong_type_bool_for_seed() {
    let t = r#"{"seed":true,"world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#;
    assert_key_error(t, "seed", "expected integer, found boolean");
}

#[test]
fn wrong_type_array_for_initial() {
    let t = r#"{"seed":1,"world":{"width":64,"height":48},"initial":[1,2,3]}"#;
    assert_key_error(t, "initial", "expected object, found array");
}

#[test]
fn wrong_type_object_for_height() {
    let t = r#"{"seed":1,"world":{"width":64,"height":{"v":48}},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#;
    assert_key_error(t, "world.height", "expected integer, found object");
}

#[test]
fn wrong_type_string_for_season_length() {
    assert_key_error(&with_root(r#""climate": {"season_length": "240"}"#), "climate.season_length", "expected integer, found string");
}

#[test]
fn wrong_type_null_for_real() {
    assert_key_error(&with_root(r#""genetics": {"mutation_rate": null}"#), "genetics.mutation_rate", "expected number, found null");
}

// ---- acceptance: missing fixed key -----------------------------------------------------------

#[test]
fn missing_fixed_keys_are_named() {
    let cases = [
        (r#"{"world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#, "seed"),
        (r#"{"seed":1,"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#, "world.width"),
        (r#"{"seed":1,"world":{"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#, "world.width"),
        (r#"{"seed":1,"world":{"width":64},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#, "world.height"),
        (r#"{"seed":1,"world":{"width":64,"height":48}}"#, "initial.plants"),
        (r#"{"seed":1,"world":{"width":64,"height":48},"initial":{"herbivores":1,"carnivores":1}}"#, "initial.plants"),
        (r#"{"seed":1,"world":{"width":64,"height":48},"initial":{"plants":1,"carnivores":1}}"#, "initial.herbivores"),
        (r#"{"seed":1,"world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1}}"#, "initial.carnivores"),
    ];
    for (text, key) in cases {
        let e = expect_err(text);
        assert_eq!(e.key.as_deref(), Some(key), "{text}");
        assert_eq!(e.message, "missing required key");
    }
}

// ---- acceptance: out of range ----------------------------------------------------------------

#[test]
fn out_of_range_values_name_the_key() {
    let world = |w: &str, h: &str| {
        format!(r#"{{"seed":1,"world":{{"width":{w},"height":{h}}},"initial":{{"plants":1,"herbivores":1,"carnivores":1}}}}"#)
    };
    let initial = |v: &str| {
        format!(r#"{{"seed":1,"world":{{"width":64,"height":48}},"initial":{{"plants":{v},"herbivores":1,"carnivores":1}}}}"#)
    };
    assert_key_error(&world("0", "48"), "world.width", "0 is out of range 1..=4096");
    assert_key_error(&world("4097", "1"), "world.width", "4097 is out of range 1..=4096");
    assert_key_error(&world("64", "0"), "world.height", "0 is out of range 1..=4096");
    assert_key_error(&world("4096", "4097"), "world.height", "4097 is out of range");
    assert_key_error(&initial("-1"), "initial.plants", "-1 is out of range 0..=1000000");
    assert_key_error(&initial("1000001"), "initial.plants", "out of range");
    assert_key_error(r#"{"seed":-1,"world":{"width":64,"height":48},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#,
        "seed", "-1 is out of range");
    assert_key_error(&with_root(r#""genetics": {"mutation_strength": 0}"#), "genetics.mutation_strength", "0 is out of range 1..=255");
    assert_key_error(&with_root(r#""genetics": {"mutation_strength": 256}"#), "genetics.mutation_strength", "256 is out of range 1..=255");
    assert_key_error(&with_root(r#""plants": {"growth_rate": -0.1}"#), "plants.growth_rate", "out of range");
    assert_key_error(&with_root(r#""plants": {"growth_rate": 1.5}"#), "plants.growth_rate", "1.5 is out of range");
    assert_key_error(&with_root(r#""plants": {"growth_rate": 1e400}"#), "plants.growth_rate", "out of range");
    assert_key_error(&with_root(r#""climate": {"season_length": 0}"#), "climate.season_length", "0 is out of range 1..=100000");
    assert_key_error(&with_root(r#""species": {"check_interval": 0}"#), "species.check_interval", "0 is out of range 1..=10000");
    assert_key_error(&with_root(r#""species": {"persistence_checks": 0}"#), "species.persistence_checks", "out of range");
    assert_key_error(&with_root(r#""plants": {"seed_radius": 17}"#), "plants.seed_radius", "17 is out of range 0..=16");
    assert_key_error(&with_root(r#""herbivores": {"max_age": 0}"#), "herbivores.max_age", "out of range");
    assert_key_error(&with_root(r#""carnivores": {"metabolism": 101.0}"#), "carnivores.metabolism", "out of range");
    assert_key_error(&with_root(r#""herbivores": {"reproduction_energy": -1.0}"#), "herbivores.reproduction_energy", "out of range");
    assert_key_error(&with_root(r#""genetics": {"mutation_rate": 1.1}"#), "genetics.mutation_rate", "out of range");
    assert_key_error(&with_root(r#""species": {"distance": 2}"#), "species.distance", "2.0 is out of range");
}

#[test]
fn largest_world_is_accepted() {
    // Each side is capped at MAX_SIDE, so the product never exceeds MAX_CELLS (4096 * 4096).
    assert_eq!(MAX_CELLS, MAX_SIDE * MAX_SIDE);
    let none = Initial { plants: 0, herbivores: 0, carnivores: 0 };
    assert!(Config::new(1, 4096, 4096, none).is_ok());
    let e = Config::new(1, 4097, 4096, none).unwrap_err();
    assert_eq!(e.key.as_deref(), Some("world.width"));
}

#[test]
fn seed_range_accepts_u64_max() {
    let c = Config::new(u64::MAX, 2, 2, Initial { plants: 1, herbivores: 0, carnivores: 0 }).unwrap();
    assert_eq!(c.seed, u64::MAX);
}

// ---- acceptance: unknown keys ----------------------------------------------------------------

#[test]
fn unknown_keys_are_errors_with_full_path() {
    assert_key_error(&with_root(r#""foo": 1"#), "foo", "unknown key");
    assert_key_error(&with_root(r#""climate": {"weathr": 1}"#), "climate.weathr", "unknown key");
    assert_key_error(&with_root(r#""fish": {"count": 1}"#), "fish", "unknown key");
    let depth = r#"{"seed":1,"world":{"width":64,"height":48,"depth":1},"initial":{"plants":1,"herbivores":1,"carnivores":1}}"#;
    assert_key_error(depth, "world.depth", "unknown key");
}

// ---- acceptance: parse errors ----------------------------------------------------------------

#[test]
fn parse_errors_have_no_key_and_report_position() {
    let cases = [
        r#"{"seed":1,}"#,                                  // trailing comma
        r#"{"seed":1"#,                                    // unclosed brace
        r#"{"seed":1,"seed":2}"#,                          // duplicate key
        r#"{"seed":01}"#,                                  // leading zero
        r#"{"seed":NaN}"#,                                 // NaN
        r#"{"seed":1.}"#,                                  // digit required after '.'
        r#"{"seed":1} x"#,                                 // trailing data
        r#"{"seed":1e}"#,                                  // digit required in exponent
        r#"[1,2,]"#,                                       // trailing comma in array (not an object)
        "{\n\"seed\": +1\n}",                              // leading plus
    ];
    for text in cases {
        let e = expect_err(text);
        assert_eq!(e.key, None, "parse error must have no key: {text}");
        assert!(e.message.contains("line") && e.message.contains("column"), "{}", e.message);
    }
    let e = expect_err("{\n\"seed\": +1\n}");
    assert!(e.message.contains("line 2"), "{}", e.message);
}

#[test]
fn top_level_must_be_object() {
    let e = expect_err("[1]");
    assert_eq!(e.key, None);
    assert!(e.message.contains("expected a JSON object"));
}

// ---- acceptance: round trip ------------------------------------------------------------------

#[test]
fn round_trip_defaults_equal() {
    let c = defaults();
    assert_eq!(Config::from_json(&c.to_json()).unwrap(), c);
}

#[test]
fn round_trip_boundary_values() {
    let mut c = defaults();
    c.seed = u64::MAX;
    c.world = World { width: 4096, height: 4096 };
    c.initial = Initial { plants: MAX_INITIAL, herbivores: 0, carnivores: MAX_INITIAL };
    c.climate = Climate { season_length: 100_000, weather_amplitude: 1.0 };
    c.plants = Plants { growth_rate: 1e-300, reproduction_chance: 0.0, seed_radius: 16, max_age: 1 };
    c.herbivores = Animal { metabolism: 100.0, reproduction_energy: 1000.0, max_age: 100_000 };
    c.carnivores = Animal { metabolism: 0.0, reproduction_energy: 0.0, max_age: 1 };
    c.genetics = Genetics { mutation_rate: 1.0, mutation_strength: 255 };
    c.species = Species { distance: 1e-7, check_interval: 10_000, persistence_checks: 1000 };
    let text = c.to_json();
    let back = Config::from_json(&text).expect("boundary values are valid");
    assert_eq!(back, c);
    assert_eq!(back.to_json(), text, "writing is stable");
}

#[test]
fn round_trip_awkward_floats() {
    let mut c = defaults();
    let samples: [f64; 6] = [0.1 + 0.2, 1e300, 1e-300, 1.0 / 3.0, 0.0, 123456.789];
    for v in samples {
        c.herbivores.reproduction_energy = v.min(1000.0);
        c.plants.growth_rate = (v / 1e6).min(1.0);
        let back = Config::from_json(&c.to_json()).unwrap();
        assert_eq!(back, c, "value {v}");
    }
}

#[test]
fn float_edge_is_written_and_read_back() {
    let mut c = defaults();
    c.genetics.mutation_rate = 1e-7;
    let text = c.to_json();
    assert!(text.contains("\"mutation_rate\": 1e-7"), "{text}");
    assert_eq!(Config::from_json(&text).unwrap(), c);
}

// ---- acceptance: presets ---------------------------------------------------------------------

#[test]
fn presets_are_valid_and_selectable_by_name() {
    assert_eq!(presets::NAMES.len(), 4);
    for name in presets::NAMES {
        let c = presets::get(name).unwrap_or_else(|| panic!("preset {name} must exist"));
        assert_eq!(Config::from_json(&c.to_json()).unwrap(), c, "preset {name} round trip");
    }
    assert!(presets::get("no-such-preset").is_none());
}

#[test]
fn presets_differ_meaningfully() {
    let all: Vec<Config> = presets::NAMES.iter().map(|n| presets::get(n).unwrap()).collect();
    for i in 0..all.len() {
        for j in i + 1..all.len() {
            assert_ne!(all[i], all[j], "presets {} and {} must differ", presets::NAMES[i], presets::NAMES[j]);
        }
    }
    let arid = presets::get("arid").unwrap();
    assert!(arid.plants.growth_rate < defaults().plants.growth_rate);
    let continent = presets::get("continent").unwrap();
    assert_ne!((continent.world.width, continent.world.height), (64, 48));
    assert_eq!(presets::get("herbivore-only").unwrap().initial.carnivores, 0);
}

#[test]
fn balanced_preset_is_contract_example_with_defaults() {
    assert_eq!(presets::get("balanced").unwrap(), defaults());
}

// ---- writer ----------------------------------------------------------------------------------

#[test]
fn writer_emits_every_key_once_in_fixed_order() {
    let text = defaults().to_json();
    let keys = [
        "\"seed\"", "\"width\"", "\"height\"", "\"plants\": 400", "\"herbivores\": 120", "\"carnivores\": 20",
        "\"season_length\"", "\"weather_amplitude\"", "\"growth_rate\"", "\"reproduction_chance\"",
        "\"seed_radius\"", "\"max_age\"", "\"metabolism\"", "\"reproduction_energy\"", "\"mutation_rate\"",
        "\"mutation_strength\"", "\"distance\"", "\"check_interval\"", "\"persistence_checks\"",
    ];
    let mut last = 0;
    for k in keys {
        // Shared leaf names appear once per group that has them: max_age in plants, herbivores
        // and carnivores; metabolism and reproduction_energy in herbivores and carnivores.
        let expected = match k {
            "\"max_age\"" => 3,
            "\"metabolism\"" | "\"reproduction_energy\"" => 2,
            _ => 1,
        };
        assert_eq!(text.matches(k).count(), expected, "key {k}");
        let pos = text.find(k).unwrap_or_else(|| panic!("key {k} missing"));
        assert!(pos >= last, "key {k} out of order");
        last = pos;
    }
}

#[test]
fn file_round_trip_through_temp_dir() {
    let dir = std::env::temp_dir().join(format!("evosim-config-test-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("c.json");
    let c = presets::get("arid").unwrap();
    c.save(&path).unwrap();
    let back = Config::load(&path).unwrap();
    std::fs::remove_dir_all(&dir).unwrap();
    assert_eq!(back, c);
}

#[test]
fn load_missing_file_is_an_error_without_key() {
    let e = Config::load(Path::new("/nonexistent/evosim/none.json")).unwrap_err();
    assert_eq!(e.key, None);
    assert!(e.message.contains("cannot read"));
}

// ---- JSON reader details ---------------------------------------------------------------------

#[test]
fn json_values_and_escapes() {
    let v = json::parse(r#"{"a":[true,false,null,-0,12,1.5e2,"x\"\\\/\né\uD800"]}"#);
    // The lone surrogate is invalid and must be rejected, not panic.
    assert!(v.is_err());
    let ok = json::parse(r#"{"a":[true,false,null,-0,12,1.5e2,"x\"\\\/\né"],"b":{}}"#).unwrap();
    match ok {
        Value::Object(f) => {
            assert_eq!(f[0].0, "a");
            assert_eq!(f[1].0, "b");
            assert_eq!(f[1].1, Value::Object(vec![]));
            match &f[0].1 {
                Value::Array(items) => {
                    assert_eq!(items[0], Value::Bool(true));
                    assert_eq!(items[2], Value::Null);
                    assert_eq!(items[3], Value::Int(0));
                    assert_eq!(items[4], Value::Int(12));
                    assert_eq!(items[5], Value::Real(150.0));
                    assert_eq!(items[6], Value::Str("x\"\\/\n\u{e9}".to_string()));
                }
                other => panic!("expected array, found {other:?}"),
            }
        }
        other => panic!("expected object, found {other:?}"),
    }
}

#[test]
fn json_big_integer_is_kept_as_text() {
    let text = "1000000000000000000000000000000000000000000";
    assert_eq!(json::parse(text).unwrap(), Value::BigInt(text.to_string()));
    let neg = format!("-{text}");
    assert_eq!(json::parse(&neg).unwrap(), Value::BigInt(neg.clone()));
}

#[test]
fn json_surrogate_pair_decodes() {
    assert_eq!(json::parse(r#""\uD83D\uDE00""#).unwrap(), Value::Str("\u{1F600}".to_string()));
    assert_eq!(json::parse(r#""a\uD83D\uDE00b""#).unwrap(), Value::Str("a\u{1F600}b".to_string()));
}

#[test]
fn json_lone_high_surrogate_is_error() {
    for text in [r#""\uD83D""#, r#""\uD83Dx""#, r#""\uD83DA""#, r#""\uD83D\u0041""#] {
        let e = json::parse(text).unwrap_err();
        assert!(e.contains("surrogate"), "{text}: {e}");
    }
}

#[test]
fn json_lone_low_surrogate_is_error() {
    let e = json::parse(r#""\uDE00""#).unwrap_err();
    assert!(e.contains("surrogate"), "{e}");
}

/// Root object with the fixed keys; `seed` and `width` are raw JSON literals, `extra` is appended
/// as further members (it must start with a comma when not empty).
fn root_with(seed: &str, width: &str, extra: &str) -> String {
    format!(
        r#"{{"seed": {seed}, "world": {{"width": {width}, "height": 48}}, "initial": {{"plants": 400, "herbivores": 120, "carnivores": 20}}{extra}}}"#
    )
}

const HUGE: &str = "10000000000000000000000000000000000000000"; // 10^40, beyond i128

#[test]
fn huge_integer_for_seed_names_key() {
    assert_key_error(&root_with(HUGE, "64", ""), "seed", "out of range 0..=18446744073709551615");
    assert_key_error(&root_with(HUGE, "64", ""), "seed", HUGE);
}

#[test]
fn huge_negative_integer_for_seed_names_key() {
    assert_key_error(&root_with(&format!("-{HUGE}"), "64", ""), "seed", "out of range 0..=");
}

#[test]
fn huge_integer_for_width_names_key() {
    assert_key_error(&root_with("42", HUGE, ""), "world.width", "out of range 1..=4096");
}

#[test]
fn huge_integer_for_real_key_names_key() {
    let extra = format!(r#", "plants": {{"growth_rate": {HUGE}}}"#);
    assert_key_error(&root_with("42", "64", &extra), "plants.growth_rate", "out of range 0.0..=1.0");
}

#[test]
fn huge_integer_for_object_key_is_wrong_type() {
    let extra = format!(r#", "climate": {HUGE}"#);
    assert_key_error(&root_with("42", "64", &extra), "climate", "expected object, found integer");
}

#[test]
fn save_creates_parent_directories() {
    let base = std::env::temp_dir().join(format!("evosim-config-save-{}", std::process::id()));
    let path = base.join("a").join("b").join("config.json");
    let c = presets::get("continent").unwrap();
    c.save(&path).unwrap();
    let back = Config::load(&path).unwrap();
    std::fs::remove_dir_all(&base).unwrap();
    assert_eq!(back, c);
}

#[test]
fn json_writer_round_trips_strings() {
    let v = Value::Str("a\"b\\c\n\u{1}".to_string());
    let text = json::write(&v);
    assert_eq!(json::parse(&text).unwrap(), v);
}

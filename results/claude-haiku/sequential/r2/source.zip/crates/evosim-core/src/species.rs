//! Species recognition and the family tree (TASK-017, ADR-0018; criterion from ADR-0004).
//!
//! - Genetic distance is [`crate::genome::genetic_distance`]: integer sum of locus differences over `len * 255`.
//! - Clustering per kind: single linkage over the living organisms of that kind, edge when `d <= settings.distance`
//!   (inclusive). Union-find; clusters are ordered by their lowest organism id.
//! - Identity: a cluster matches the lowest-id living recognised species of its kind when any member lies within the
//!   threshold of that species' reference genome (its founder genome, fixed at recognition).
//! - Candidates: an unmatched cluster becomes (or continues) a candidate. A candidate's counter counts consecutive checks
//!   in which it is observed; it is dropped at the first check where it is not. It is recognised when the counter reaches
//!   `persistence_checks`. Counts are checks, never member counts.
//! - Founding: while a kind has no record at all, its clusters are recognised at once (no parent).
//! - Provisional ids: newborns take the species of their mother (`parents()[0]`) until the next check; candidate members
//!   keep their provisional id until recognition.
//! - Extinction: a recognised species with no living member at the end of a tick gets `extinct_tick` (permanent).
//!
//! The classifier is a pure function of the members, the registry and the tick: no random numbers, fixed iteration
//! orders, no hash maps. Nothing here reads member counts to change behaviour (ADR-0018).

use std::fmt;

use crate::config::Config;
use crate::entities::{Entities, Kind, OrganismId};
use crate::genome::{Genome, LOCUS_MAX};

/// Identifier of a recognised species: its index in the registry's record list. Never reused.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct SpeciesId(pub u32);

/// Settings of the species criterion, copied from `config.species` (ADR-0018).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SpeciesSettings {
    /// Inclusive threshold on genetic distance.
    pub distance: f64,
    /// Ticks between checks (`t > 0`, `t % check_interval == 0`).
    pub check_interval: u64,
    /// Consecutive checks needed to recognise a candidate.
    pub persistence_checks: u64,
}

impl SpeciesSettings {
    /// Reads `config.species`. The configuration has already validated the ranges.
    pub fn from_config(config: &Config) -> SpeciesSettings {
        SpeciesSettings {
            distance: config.species.distance,
            check_interval: config.species.check_interval,
            persistence_checks: config.species.persistence_checks,
        }
    }
}

/// One recognised species and its place in the family tree.
#[derive(Clone, Debug, PartialEq)]
pub struct SpeciesRecord {
    pub id: SpeciesId,
    pub kind: Kind,
    /// `"<code><seq:04>"`, code `PL`, `HE` or `CA`, seq a per-kind counter from 1 (e.g. `HE0007`).
    pub name: String,
    /// The species this one split from; `None` for founding species.
    pub parent: Option<SpeciesId>,
    /// Tick at which the species was recognised.
    pub arose_tick: u64,
    /// Tick of the death of its last living member; `None` while it has living members.
    pub extinct_tick: Option<u64>,
    /// Genome the species is identified by (fixed at recognition).
    pub reference: Genome,
}

/// A candidate species that is not yet recognised (ADR-0018).
#[derive(Clone, Debug, PartialEq)]
pub struct Candidate {
    pub reference: Genome,
    /// Consecutive checks in which the candidate has been observed.
    pub checks: u64,
}

/// Errors of registry queries.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SpeciesError {
    /// The queried tick has not finished yet (`tick >= now`).
    FutureTick { tick: u64, now: u64 },
}

impl fmt::Display for SpeciesError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SpeciesError::FutureTick { tick, now } => {
                write!(
                    f,
                    "tick {tick} has not finished yet (the simulation is at {now})"
                )
            }
        }
    }
}

impl std::error::Error for SpeciesError {}

/// Records, open candidates and name counters of one simulation. Saved by the checkpoint (TASK-022).
#[derive(Clone, Debug, PartialEq)]
pub struct SpeciesRegistry {
    settings: SpeciesSettings,
    records: Vec<SpeciesRecord>,
    candidates: [Vec<Candidate>; 3],
    name_seq: [u32; 3],
}

/// One living organism as seen by the classifier.
#[derive(Clone, Copy, Debug)]
pub struct Member<'a> {
    pub id: OrganismId,
    pub genome: &'a Genome,
    pub provisional: Option<SpeciesId>,
}

/// The species of one organism after a check. `None` only if the organism had no provisional id and is not yet
/// in a recognised species.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Assignment {
    pub id: OrganismId,
    pub species: Option<SpeciesId>,
}

/// How one cluster is resolved at a check.
#[derive(Clone, Copy)]
enum Plan {
    Species(SpeciesId),
    /// Index into the working candidate list of its kind.
    Candidate(usize),
}

/// True when the two genomes are within `threshold` (inclusive). Same arithmetic as `genetic_distance`, so the
/// boundary is exact: `d == threshold` gives true. The partial sum is checked every 32 loci; the sum only grows, so
/// once it exceeds the threshold the pair cannot come back within it.
fn within(a: &Genome, b: &Genome, threshold: f64) -> bool {
    if a.ploidy() != b.ploidy() || a.loci().len() != b.loci().len() {
        return false;
    }
    let denom = a.loci().len() as f64 * f64::from(LOCUS_MAX);
    let mut sum: u64 = 0;
    for (x, y) in a.loci().chunks(32).zip(b.loci().chunks(32)) {
        sum += x
            .iter()
            .zip(y)
            .map(|(&p, &q)| u64::from(p.abs_diff(q)))
            .sum::<u64>();
        if sum as f64 / denom > threshold {
            return false;
        }
    }
    sum as f64 / denom <= threshold
}

fn find(parent: &mut [usize], mut i: usize) -> usize {
    while parent[i] != i {
        parent[i] = parent[parent[i]];
        i = parent[i];
    }
    i
}

fn kind_code(kind: Kind) -> &'static str {
    match kind {
        Kind::Plant => "PL",
        Kind::Herbivore => "HE",
        Kind::Carnivore => "CA",
    }
}

impl SpeciesRegistry {
    /// An empty registry with the given criterion settings.
    pub fn new(settings: SpeciesSettings) -> SpeciesRegistry {
        SpeciesRegistry {
            settings,
            records: Vec::new(),
            candidates: [Vec::new(), Vec::new(), Vec::new()],
            name_seq: [0; 3],
        }
    }

    pub fn settings(&self) -> SpeciesSettings {
        self.settings
    }

    /// All records in creation order (ids ascending).
    pub fn records(&self) -> &[SpeciesRecord] {
        &self.records
    }

    pub fn record(&self, id: SpeciesId) -> Option<&SpeciesRecord> {
        self.records.get(id.0 as usize)
    }

    /// Open candidates of one kind, in creation order.
    pub fn candidates(&self, kind: Kind) -> &[Candidate] {
        &self.candidates[kind.index()]
    }

    /// Number of species of `kind` that have been recognised, extinct or not.
    pub fn record_count(&self, kind: Kind) -> usize {
        self.records.iter().filter(|r| r.kind == kind).count()
    }

    /// Living species of `kind` at the end of tick `tick`: `arose_tick <= tick` and not extinct by `tick`
    /// (`extinct_tick > tick` or absent). `now` is the simulation's tick counter: `tick` must be finished, that is
    /// `tick < now`. Answered from the records alone.
    pub fn living_count(&self, kind: Kind, tick: u64, now: u64) -> Result<usize, SpeciesError> {
        if tick >= now {
            return Err(SpeciesError::FutureTick { tick, now });
        }
        Ok(self
            .records
            .iter()
            .filter(|r| {
                r.kind == kind
                    && r.arose_tick <= tick
                    && r.extinct_tick.is_none_or(|extinct| extinct > tick)
            })
            .count())
    }

    /// Species of `kind` that are alive after the last completed tick: records with no `extinct_tick` (ADR-0020 D5).
    /// Unlike [`SpeciesRegistry::living_count`] this needs no tick argument, so it also answers for the current tick.
    pub fn living_now(&self, kind: Kind) -> usize {
        self.records
            .iter()
            .filter(|r| r.kind == kind && r.extinct_tick.is_none())
            .count()
    }

    /// Adds a recognised species and returns its id. The name counter of the kind advances.
    fn record_species(
        &mut self,
        kind: Kind,
        tick: u64,
        parent: Option<SpeciesId>,
        reference: Genome,
    ) -> SpeciesId {
        let k = kind.index();
        self.name_seq[k] += 1;
        let id = SpeciesId(self.records.len() as u32);
        self.records.push(SpeciesRecord {
            id,
            kind,
            name: format!("{}{:04}", kind_code(kind), self.name_seq[k]),
            parent,
            arose_tick: tick,
            extinct_tick: None,
            reference,
        });
        id
    }

    /// Sets `extinct_tick = tick` for every recognised species without a living member. `entities` must hold only
    /// living organisms (after the Deaths phase). Permanent: a species already extinct is not touched.
    pub fn update_extinction(&mut self, entities: &Entities, tick: u64) {
        let mut counts = vec![0u64; self.records.len()];
        for o in entities.living() {
            if let Some(s) = o.species() {
                if let Some(c) = counts.get_mut(s.0 as usize) {
                    *c += 1;
                }
            }
        }
        for (record, count) in self.records.iter_mut().zip(counts) {
            if record.extinct_tick.is_none() && count == 0 {
                record.extinct_tick = Some(tick);
            }
        }
    }
}

/// Classifies the living members of one kind at tick `tick` (ADR-0018) and updates the registry. Returns one
/// assignment per member, in ascending id order. Members of unrecognised candidates keep their provisional id.
/// Pure apart from the registry: no world, no random numbers.
pub fn classify(
    reg: &mut SpeciesRegistry,
    kind: Kind,
    members: &[Member],
    tick: u64,
) -> Vec<Assignment> {
    let mut sorted: Vec<Member> = members.to_vec();
    sorted.sort_by_key(|m| m.id);
    let n = sorted.len();
    let threshold = reg.settings.distance;
    let persistence = reg.settings.persistence_checks;
    let founding = reg.record_count(kind) == 0;

    // Single-linkage clusters (union-find). Pairs already in one set are skipped; that changes no result.
    let mut parent: Vec<usize> = (0..n).collect();
    for i in 0..n {
        for j in (i + 1)..n {
            let (ri, rj) = (find(&mut parent, i), find(&mut parent, j));
            if ri != rj && within(sorted[i].genome, sorted[j].genome, threshold) {
                parent[rj] = ri;
            }
        }
    }
    let mut cluster_of_root: Vec<Option<usize>> = vec![None; n];
    let mut clusters: Vec<Vec<usize>> = Vec::new();
    for i in 0..n {
        let root = find(&mut parent, i);
        let c = *cluster_of_root[root].get_or_insert_with(|| {
            clusters.push(Vec::new());
            clusters.len() - 1
        });
        clusters[c].push(i);
    }

    let mut plans: Vec<Plan> = Vec::with_capacity(clusters.len());
    if founding {
        // Founders: every cluster is a species at once, with no parent (ADR-0018, founding).
        for cluster in &clusters {
            let first = cluster[0];
            let reference = sorted[first].genome.clone();
            let id = reg.record_species(kind, tick, None, reference);
            plans.push(Plan::Species(id));
        }
    } else {
        let mut cands = std::mem::take(&mut reg.candidates[kind.index()]);
        let mut observed = vec![false; cands.len()];
        let mut recognised_now = vec![false; cands.len()];
        for cluster in &clusters {
            let first = cluster[0];
            // 1. Identity: the lowest-id living recognised species of this kind with a member near its reference.
            let matched = reg
                .records
                .iter()
                .filter(|r| r.kind == kind && r.extinct_tick.is_none())
                .find(|r| {
                    cluster
                        .iter()
                        .any(|&i| within(sorted[i].genome, &r.reference, threshold))
                })
                .map(|r| r.id);
            if let Some(id) = matched {
                plans.push(Plan::Species(id));
                continue;
            }
            // 2. An unobserved candidate near a member continues; the counter counts this check.
            let continued = (0..cands.len()).find(|&k| {
                !observed[k]
                    && cluster
                        .iter()
                        .any(|&i| within(sorted[i].genome, &cands[k].reference, threshold))
            });
            match continued {
                Some(k) => {
                    observed[k] = true;
                    cands[k].checks += 1;
                    plans.push(Plan::Candidate(k));
                }
                None => {
                    cands.push(Candidate {
                        reference: sorted[first].genome.clone(),
                        checks: 1,
                    });
                    observed.push(true);
                    recognised_now.push(false);
                    plans.push(Plan::Candidate(cands.len() - 1));
                }
            }
        }

        // 3. Recognition: a candidate with enough consecutive checks becomes a species. Its parent is the most common
        //    provisional species among its members (ties to the lowest id).
        for (cluster, plan) in clusters.iter().zip(plans.iter_mut()) {
            let Plan::Candidate(k) = *plan else { continue };
            if cands[k].checks < persistence {
                continue;
            }
            let mut tally: Vec<(SpeciesId, usize)> = Vec::new();
            for &i in cluster {
                if let Some(p) = sorted[i].provisional {
                    match tally.iter_mut().find(|(s, _)| *s == p) {
                        Some(entry) => entry.1 += 1,
                        None => tally.push((p, 1)),
                    }
                }
            }
            tally.sort_by(|a, b| b.1.cmp(&a.1).then(a.0.cmp(&b.0)));
            let parent_species = tally.first().map(|(s, _)| *s);
            let reference = cands[k].reference.clone();
            let id = reg.record_species(kind, tick, parent_species, reference);
            recognised_now[k] = true;
            *plan = Plan::Species(id);
        }

        // 4. Candidates not observed in this check are dropped (counter reset); recognised ones leave the list.
        let kept: Vec<Candidate> = cands
            .into_iter()
            .enumerate()
            .filter(|(k, _)| observed[*k] && !recognised_now[*k])
            .map(|(_, c)| c)
            .collect();
        // Remap the surviving candidate plans to their new indices (plans are only needed below).
        let mut new_index = vec![None; recognised_now.len()];
        let mut next = 0usize;
        for k in 0..recognised_now.len() {
            if observed[k] && !recognised_now[k] {
                new_index[k] = Some(next);
                next += 1;
            }
        }
        for plan in plans.iter_mut() {
            if let Plan::Candidate(k) = *plan {
                if let Some(nk) = new_index[k] {
                    *plan = Plan::Candidate(nk);
                }
            }
        }
        reg.candidates[kind.index()] = kept;
    }

    // Assignments: each member takes its cluster's species; members of unrecognised candidates keep their provisional id.
    let mut out: Vec<Option<SpeciesId>> = vec![None; n];
    for (cluster, plan) in clusters.iter().zip(&plans) {
        for &i in cluster {
            out[i] = match *plan {
                Plan::Species(id) => Some(id),
                Plan::Candidate(_) => sorted[i].provisional,
            };
        }
    }
    sorted
        .iter()
        .zip(out)
        .map(|(m, species)| Assignment { id: m.id, species })
        .collect()
}

/// Gives every organism with id `>= first_new` and no species the species of its mother (`parents()[0]`, the lower-id
/// parent for animals, ADR-0017). Used for newborns of the Reproduction phase (ADR-0018, provisional ids).
pub fn inherit_provisional(entities: &mut Entities, first_new: OrganismId) {
    let pending: Vec<(OrganismId, Option<SpeciesId>)> = entities
        .living()
        .filter(|o| o.id() >= first_new && o.species().is_none())
        .map(|o| {
            let mother = o.parents()[0]
                .and_then(|p| entities.get(p))
                .and_then(|m| m.species());
            (o.id(), mother)
        })
        .collect();
    for (id, species) in pending {
        if let Some(o) = entities.get_mut(id) {
            o.set_species(species);
        }
    }
}

/// Assigns the classifier's result to the stored organisms.
pub fn apply(entities: &mut Entities, assignments: &[Assignment]) {
    for a in assignments {
        if let Some(o) = entities.get_mut(a.id) {
            o.set_species(a.species);
        }
    }
}

impl SpeciesSettings {
    /// Canonical encoding of the species criterion settings (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let SpeciesSettings {
            distance,
            check_interval,
            persistence_checks,
        } = self;
        enc.f64(*distance);
        enc.u64(*check_interval);
        enc.u64(*persistence_checks);
    }
}

impl SpeciesRecord {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let SpeciesRecord {
            id,
            kind,
            name,
            parent,
            arose_tick,
            extinct_tick,
            reference,
        } = self;
        enc.u32(id.0);
        enc.u8(kind.index() as u8);
        enc.str(name);
        enc.opt_u64(parent.map(|p| u64::from(p.0)));
        enc.u64(*arose_tick);
        enc.opt_u64(*extinct_tick);
        reference.encode_state(enc);
    }
}

impl Candidate {
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let Candidate { reference, checks } = self;
        reference.encode_state(enc);
        enc.u64(*checks);
    }
}

impl SpeciesRegistry {
    /// Canonical encoding of the species registry: settings, records, open candidates and name counters (ADR-0020 D3).
    pub(crate) fn encode_state(&self, enc: &mut crate::checkpoint::Encoder) {
        let SpeciesRegistry {
            settings,
            records,
            candidates,
            name_seq,
        } = self;
        settings.encode_state(enc);
        enc.count(records.len());
        for r in records {
            r.encode_state(enc);
        }
        for list in candidates {
            enc.count(list.len());
            for c in list {
                c.encode_state(enc);
            }
        }
        for n in name_seq {
            enc.u32(*n);
        }
    }

    /// Reads the registry (ADR-0023 D3). Record ids must equal their positions; the interval must be at least 1.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<SpeciesRegistry, crate::checkpoint::CheckpointError> {
        use crate::checkpoint::invalid;
        let settings = SpeciesSettings::decode_state(dec)?;
        let record_count = dec.count("species records")?;
        let mut records = Vec::with_capacity(record_count);
        for position in 0..record_count {
            let record = SpeciesRecord::decode_state(dec)?;
            if record.id.0 as usize != position {
                return Err(invalid("species record id does not match its position"));
            }
            records.push(record);
        }
        let mut candidates: [Vec<Candidate>; 3] = [Vec::new(), Vec::new(), Vec::new()];
        for list in &mut candidates {
            let count = dec.count("species candidates")?;
            for _ in 0..count {
                list.push(Candidate::decode_state(dec)?);
            }
        }
        let name_seq = [dec.u32()?, dec.u32()?, dec.u32()?];
        Ok(SpeciesRegistry {
            settings,
            records,
            candidates,
            name_seq,
        })
    }
}

impl SpeciesSettings {
    /// Reads the criterion settings (ADR-0023 D3). `check_interval` must be at least 1, since it divides the tick.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<SpeciesSettings, crate::checkpoint::CheckpointError> {
        let distance = dec.f64()?;
        let check_interval = dec.u64()?;
        let persistence_checks = dec.u64()?;
        if check_interval == 0 {
            return Err(crate::checkpoint::invalid("species check interval is zero"));
        }
        Ok(SpeciesSettings {
            distance,
            check_interval,
            persistence_checks,
        })
    }
}

impl SpeciesRecord {
    /// Reads one species record (ADR-0023 D3). The id is checked against the position by the registry.
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<SpeciesRecord, crate::checkpoint::CheckpointError> {
        let id = SpeciesId(dec.u32()?);
        let kind = crate::entities::decode_kind(dec)?;
        let name = dec.str("species name")?;
        let parent = decode_species_id(dec)?;
        let arose_tick = dec.u64()?;
        let extinct_tick = dec.opt_u64("extinct tick")?;
        let reference = Genome::decode_state(dec)?;
        Ok(SpeciesRecord {
            id,
            kind,
            name,
            parent,
            arose_tick,
            extinct_tick,
            reference,
        })
    }
}

impl Candidate {
    /// Reads one open candidate (ADR-0023 D3).
    pub(crate) fn decode_state(
        dec: &mut crate::checkpoint::Decoder,
    ) -> Result<Candidate, crate::checkpoint::CheckpointError> {
        let reference = Genome::decode_state(dec)?;
        let checks = dec.u64()?;
        Ok(Candidate { reference, checks })
    }
}

/// An optional species id stored as `u64` in the encoding; it must fit the `u32` of [`SpeciesId`].
fn decode_species_id(
    dec: &mut crate::checkpoint::Decoder,
) -> Result<Option<SpeciesId>, crate::checkpoint::CheckpointError> {
    match dec.opt_u64("species id")? {
        None => Ok(None),
        Some(v) => u32::try_from(v)
            .map(|id| Some(SpeciesId(id)))
            .map_err(|_| crate::checkpoint::invalid("species id")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::entities::{Birth, Entities};
    use crate::world::Torus;

    fn settings(distance: f64, persistence_checks: u64) -> SpeciesSettings {
        SpeciesSettings {
            distance,
            check_interval: 25,
            persistence_checks,
        }
    }

    /// A genome of `ploidy` whose loci are all `value`.
    fn uniform(ploidy: u8, value: u8) -> Genome {
        let len = usize::from(ploidy) * 128;
        Genome::new(ploidy, vec![value; len]).unwrap()
    }

    /// A genome `k` away from `uniform(ploidy, 0)`: the sum of differences is exactly `k` (fills loci with 255).
    fn offset_by_sum(ploidy: u8, k: u64) -> Genome {
        let len = usize::from(ploidy) * 128;
        let mut loci = vec![0u8; len];
        let mut left = k;
        for locus in loci.iter_mut() {
            let step = left.min(255);
            *locus = step as u8;
            left -= step;
        }
        assert_eq!(left, 0, "k does not fit the genome");
        Genome::new(ploidy, loci).unwrap()
    }

    fn member(id: u64, genome: &Genome, provisional: Option<SpeciesId>) -> Member<'_> {
        Member {
            id: OrganismId(id),
            genome,
            provisional,
        }
    }

    /// Runs one classifier check with the given (id, genome, provisional) members and returns the assignments.
    fn check(
        reg: &mut SpeciesRegistry,
        kind: Kind,
        tick: u64,
        members: &[(u64, &Genome, Option<SpeciesId>)],
    ) -> Vec<Assignment> {
        let ms: Vec<Member> = members.iter().map(|&(id, g, p)| member(id, g, p)).collect();
        classify(reg, kind, &ms, tick)
    }

    fn species_of(out: &[Assignment], id: u64) -> Option<SpeciesId> {
        out.iter().find(|a| a.id == OrganismId(id)).unwrap().species
    }

    #[test]
    fn threshold_boundary_is_inclusive_for_animals_and_plants() {
        for (ploidy, loci) in [(2u8, 256.0f64), (1u8, 128.0f64)] {
            let kind = if ploidy == 2 {
                Kind::Herbivore
            } else {
                Kind::Plant
            };
            let denom = loci * 255.0;
            // The threshold is the attainable value 3916 / (L * 255) (0.06 itself is not attainable for L = 256, ADR-0018).
            let threshold = 3916.0 / denom;
            let a = uniform(ploidy, 0);
            let b_at = offset_by_sum(ploidy, 3916);
            let b_above = offset_by_sum(ploidy, 3916 + 1);

            // Exactly at the threshold: one cluster, one founding species.
            let mut reg = SpeciesRegistry::new(settings(threshold, 4));
            let out = check(&mut reg, kind, 0, &[(1, &a, None), (2, &b_at, None)]);
            assert_eq!(
                reg.records().len(),
                1,
                "{kind:?}: distance == threshold must stay one species"
            );
            assert_eq!(species_of(&out, 1), species_of(&out, 2));

            // One unit above: two clusters, two founding species.
            let mut reg = SpeciesRegistry::new(settings(threshold, 4));
            let out = check(&mut reg, kind, 0, &[(1, &a, None), (2, &b_above, None)]);
            assert_eq!(
                reg.records().len(),
                2,
                "{kind:?}: distance above threshold must split"
            );
            assert_ne!(species_of(&out, 1), species_of(&out, 2));
        }
    }

    #[test]
    fn founding_makes_each_cluster_a_species_with_no_parent_and_names_are_per_kind() {
        let a = uniform(2, 0);
        let b = uniform(2, 255);
        let mut reg = SpeciesRegistry::new(settings(0.06, 4));
        let out = check(
            &mut reg,
            Kind::Herbivore,
            0,
            &[(5, &a, None), (3, &b, None)],
        );
        assert_eq!(reg.records().len(), 2);
        let first = reg.record(SpeciesId(0)).unwrap();
        assert_eq!(first.name, "HE0001");
        assert_eq!(first.parent, None);
        assert_eq!(first.arose_tick, 0);
        assert_eq!(first.extinct_tick, None);
        // Member 3 has the lower id, so its cluster is created first.
        assert_eq!(species_of(&out, 3), Some(SpeciesId(0)));
        assert_eq!(species_of(&out, 5), Some(SpeciesId(1)));
        assert_eq!(reg.record(SpeciesId(1)).unwrap().name, "HE0002");
        // Plants have their own counter.
        let p = uniform(1, 9);
        check(&mut reg, Kind::Plant, 0, &[(1, &p, None)]);
        assert_eq!(reg.records().last().unwrap().name, "PL0001");
    }

    /// Two-group divergence: the group `A` stays at distance 0 and the group `B` is `far` away from it.
    fn divergence_run(reg: &mut SpeciesRegistry, checks: u64) -> Vec<usize> {
        let a = uniform(2, 0);
        let b = offset_by_sum(2, 256 * 255 / 2); // distance 0.5, far above 0.1
        let parent = check(reg, Kind::Herbivore, 0, &[(1, &a, None)]);
        let s0 = species_of(&parent, 1);
        let mut counts = Vec::new();
        for c in 1..=checks {
            check(reg, Kind::Herbivore, 25 * c, &[(1, &a, s0), (2, &b, s0)]);
            counts.push(reg.record_count(Kind::Herbivore));
        }
        counts
    }

    #[test]
    fn split_appears_only_after_persistence_checks() {
        let mut reg = SpeciesRegistry::new(settings(0.1, 4));
        let counts = divergence_run(&mut reg, 6);
        // Founding gives one record. Checks 1..3 observe the new cluster 3 times: no split. Check 4 is the 4th.
        assert_eq!(
            &counts[..3],
            &[1, 1, 1],
            "one check short of persistence must not split"
        );
        assert_eq!(
            counts[3], 2,
            "the fourth consecutive check recognises the split"
        );
        let child = reg.record(SpeciesId(1)).unwrap();
        assert_eq!(child.arose_tick, 100);
        assert_eq!(
            child.parent,
            Some(SpeciesId(0)),
            "parent is the provisional species of its members"
        );
        assert_eq!(child.name, "HE0002");
    }

    #[test]
    fn candidate_that_disappears_resets_its_counter() {
        let mut reg = SpeciesRegistry::new(settings(0.1, 4));
        let a = uniform(2, 0);
        let b = offset_by_sum(2, 256 * 255 / 2);
        let out = check(&mut reg, Kind::Herbivore, 0, &[(1, &a, None)]);
        let s0 = species_of(&out, 1);
        // Observed at checks 1 and 2, absent at check 3.
        check(&mut reg, Kind::Herbivore, 25, &[(1, &a, s0), (2, &b, s0)]);
        check(&mut reg, Kind::Herbivore, 50, &[(1, &a, s0), (2, &b, s0)]);
        check(&mut reg, Kind::Herbivore, 75, &[(1, &a, s0)]);
        assert!(
            reg.candidates(Kind::Herbivore).is_empty(),
            "unobserved candidate is dropped"
        );
        // Observed again at checks 4..6 is only 3 in a row: still no split.
        for t in [100, 125, 150] {
            check(&mut reg, Kind::Herbivore, t, &[(1, &a, s0), (2, &b, s0)]);
        }
        assert_eq!(reg.record_count(Kind::Herbivore), 1);
        // The fourth consecutive check recognises it.
        check(&mut reg, Kind::Herbivore, 175, &[(1, &a, s0), (2, &b, s0)]);
        assert_eq!(reg.record_count(Kind::Herbivore), 2);
    }

    #[test]
    fn identical_inputs_give_identical_records_and_names() {
        let run = || {
            let mut reg = SpeciesRegistry::new(settings(0.1, 2));
            divergence_run(&mut reg, 5);
            reg
        };
        assert_eq!(run(), run());
    }

    #[test]
    fn extinction_is_recorded_at_the_death_tick_and_queries_answer_past_ticks() {
        let mut reg = SpeciesRegistry::new(settings(0.06, 4));
        let torus = Torus::new(4, 4).unwrap();
        let cell = torus.cell(1, 1).unwrap();
        let mut entities = Entities::new();
        // One plant with energy 0: it starves in the next Deaths phase (tick 7 here).
        let g = uniform(1, 40);
        let birth = Birth::from_genome(Kind::Plant, cell, g.clone(), 0.0, 10.0).unwrap();
        let id = entities.spawn_founder(birth).unwrap();
        let out = check(&mut reg, Kind::Plant, 0, &[(id.0, &g, None)]);
        crate::species::apply(&mut entities, &out);
        assert_eq!(reg.living_count(Kind::Plant, 0, 8), Ok(1));
        reg.update_extinction(&entities, 3);
        assert_eq!(
            reg.record(SpeciesId(0)).unwrap().extinct_tick,
            None,
            "a living member keeps it alive"
        );
        entities.deaths_phase(7);
        reg.update_extinction(&entities, 7);
        assert_eq!(reg.record(SpeciesId(0)).unwrap().extinct_tick, Some(7));
        assert_eq!(reg.living_count(Kind::Plant, 6, 8), Ok(1));
        assert_eq!(reg.living_count(Kind::Plant, 7, 8), Ok(0));
        assert_eq!(
            reg.living_count(Kind::Plant, 8, 8),
            Err(SpeciesError::FutureTick { tick: 8, now: 8 })
        );
        // Extinction is permanent: a later check does not change the tick.
        reg.update_extinction(&entities, 9);
        assert_eq!(reg.record(SpeciesId(0)).unwrap().extinct_tick, Some(7));
    }

    #[test]
    fn a_species_that_died_out_is_not_matched_again() {
        // A new organism close to an extinct species' reference is not assigned to it (no birth from zero members).
        let mut reg = SpeciesRegistry::new(settings(0.06, 4));
        let g = uniform(2, 0);
        check(&mut reg, Kind::Herbivore, 0, &[(1, &g, None)]);
        reg.records.get_mut(0).unwrap().extinct_tick = Some(5);
        let out = check(&mut reg, Kind::Herbivore, 25, &[(9, &g, None)]);
        assert_eq!(
            species_of(&out, 9),
            None,
            "a new candidate keeps its (missing) provisional id"
        );
        assert_eq!(reg.candidates(Kind::Herbivore).len(), 1);
    }
}

#[cfg(test)]
mod sim_tests {
    use super::*;
    use crate::config::{Config, Initial};
    use crate::sim::Simulation;

    fn config(seed: u64, plants: u64, herbivores: u64, carnivores: u64) -> Config {
        Config::new(
            seed,
            16,
            12,
            Initial {
                plants,
                herbivores,
                carnivores,
            },
        )
        .unwrap()
    }

    /// Every living organism has a species, and its kind matches the record's kind.
    fn assert_every_organism_has_a_species(sim: &Simulation) {
        for o in sim.entities().living() {
            let s = o
                .species()
                .unwrap_or_else(|| panic!("organism {} has no species", o.id().0));
            assert_eq!(sim.species().record(s).unwrap().kind, o.kind());
        }
    }

    #[test]
    fn founding_gives_one_species_per_kind_at_tick_zero() {
        let mut sim = Simulation::new(&config(3, 30, 12, 6)).unwrap();
        sim.populate_initial(&config(3, 30, 12, 6)).unwrap();
        let records = sim.species().records();
        assert_eq!(records.len(), 3, "clonal founders: one species per kind");
        for (rec, kind) in records.iter().zip(Kind::ALL) {
            assert_eq!(rec.kind, kind);
            assert_eq!(rec.arose_tick, 0);
            assert_eq!(rec.parent, None);
            assert_eq!(rec.extinct_tick, None);
        }
        assert_eq!(
            records.iter().map(|r| r.name.as_str()).collect::<Vec<_>>(),
            ["PL0001", "HE0001", "CA0001"]
        );
        assert_every_organism_has_a_species(&sim);
    }

    #[test]
    fn every_organism_has_a_species_over_a_run_and_newborns_inherit_the_mothers() {
        let cfg = config(11, 40, 20, 8);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        for _ in 0..300 {
            sim.tick();
            assert_every_organism_has_a_species(&sim);
        }
        // A newborn whose mother was classified takes the mother's species until the next check.
        assert!(
            sim.entities().births(Kind::Plant) > 0,
            "plants reproduce in this run"
        );
    }

    #[test]
    fn same_seed_gives_identical_records_names_and_species_after_1000_ticks() {
        let cfg = config(7, 60, 30, 10);
        let run = || {
            let mut sim = Simulation::new(&cfg).unwrap();
            sim.populate_initial(&cfg).unwrap();
            sim.run(1000);
            let species: Vec<Option<SpeciesId>> =
                sim.entities().living().map(|o| o.species()).collect();
            (sim.species().clone(), species, sim.rng_state())
        };
        let (a, b) = (run(), run());
        assert_eq!(a, b);
        // Names are unique within a kind.
        let mut names: Vec<&str> = a.0.records().iter().map(|r| r.name.as_str()).collect();
        let before = names.len();
        names.sort();
        names.dedup();
        assert_eq!(names.len(), before);
    }

    #[test]
    fn living_count_answers_past_ticks_from_the_records() {
        // A plants-only world: a starved plant is removed and its species goes extinct at that tick.
        let cfg = config(5, 1, 0, 0);
        let mut sim = Simulation::new(&cfg).unwrap();
        sim.populate_initial(&cfg).unwrap();
        assert_eq!(
            sim.species().living_count(Kind::Plant, 0, sim.tick_count()),
            Err(SpeciesError::FutureTick { tick: 0, now: 0 })
        );
        sim.run(5);
        let now = sim.tick_count();
        for t in 0..now {
            assert_eq!(sim.species().living_count(Kind::Plant, t, now), Ok(1));
        }
        assert!(sim.species().living_count(Kind::Plant, now, now).is_err());
    }
}

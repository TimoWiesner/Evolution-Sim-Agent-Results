//! Built-in presets (ADR-0006). Each preset is a JSON text read through `Config::from_json`,
//! so it is validated by the same code as a user file.

use super::Config;

/// Names accepted by [`get`], in display order.
pub const NAMES: &[&str] = &["balanced", "arid", "continent", "herbivore-only"];

/// Contract example with every other parameter at its default.
const BALANCED: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

/// Same world and start as `balanced`, but scarce, strongly fluctuating food.
const ARID: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 },
  "climate": { "season_length": 120, "weather_amplitude": 0.45 },
  "plants": { "growth_rate": 0.04 }
}"#;

/// Larger world and populations, faster mutation and wider species splitting.
const CONTINENT: &str = r#"{
  "seed": 42,
  "world": { "width": 128, "height": 96 },
  "initial": { "plants": 1600, "herbivores": 500, "carnivores": 80 },
  "genetics": { "mutation_rate": 0.005, "mutation_strength": 16 },
  "species": { "distance": 0.08 }
}"#;

/// Food chain without predators: no carnivores at tick 0.
const HERBIVORE_ONLY: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 0 }
}"#;

/// Returns the preset with this name, or `None` for an unknown name.
pub fn get(name: &str) -> Option<Config> {
    let text = match name {
        "balanced" => BALANCED,
        "arid" => ARID,
        "continent" => CONTINENT,
        "herbivore-only" => HERBIVORE_ONLY,
        _ => return None,
    };
    // A built-in preset that fails validation is a bug in this file; tests check all of them.
    Some(Config::from_json(text).expect("built-in preset must be valid"))
}

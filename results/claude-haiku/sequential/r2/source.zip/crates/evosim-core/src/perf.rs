//! Performance measurement (TASK-026, ADR-0027).
//!
//! Everything here reads the clock and reports numbers; nothing here changes the simulation state. The fixed benchmark
//! configuration is `examples/perf-2000.json`; `scripts/perf.sh` runs it through `examples/perf_tps.rs`.
//!
//! Method (ADR-0027 D1): each repetition builds a fresh simulation from the same configuration (outside the timer),
//! then times `tick()` for a fixed number of ticks. Warm-up repetitions are run first and discarded. The living count
//! is read after each tick, outside the timer, so the report can state that the population stayed at or above the
//! required level on every measured tick.

use std::time::{Duration, Instant};

use crate::checkpoint;
use crate::config::Config;
use crate::metrics;
use crate::sim::{Simulation, PHASE_ORDER};

/// The fixed benchmark configuration (ADR-0027 D1). Shared by the guard test and `scripts/perf.sh`.
pub const BENCH_CONFIG_JSON: &str = include_str!("../../../examples/perf-2000.json");

/// Organisms that every measured tick of the benchmark must have at least (the target setting, ADR-0027 D1).
pub const REQUIRED_LIVING: u64 = 2_000;

/// Ticks per second the simulation must reach on the benchmark configuration (docs/CONTRACT.md section 4 goal,
/// `docs/PROJECT.md`, TASK-026 target).
pub const TARGET_TICKS_PER_SECOND: f64 = 100.0;

/// Guard floor for release builds: about a quarter of the measured median (ADR-0027 D4). Set from the measurement
/// recorded in `docs/PERFORMANCE.md`.
pub const GUARD_FLOOR_RELEASE_TPS: f64 = 140.0;

/// Guard floor for debug builds (`cargo test` without `--release`), set from the measured debug speed (ADR-0027 D4).
pub const GUARD_FLOOR_DEBUG_TPS: f64 = 6.0;

/// Wall-clock time per phase, accumulated over ticks. Index `i` is `PHASE_ORDER[i]`.
#[derive(Clone, Debug, PartialEq, Eq, Default)]
pub struct PhaseTimes {
    pub elapsed: [Duration; PHASE_ORDER.len()],
    pub ticks: u64,
}

impl PhaseTimes {
    /// Adds `d` to the time of phase `index` (position in `PHASE_ORDER`).
    pub fn add(&mut self, index: usize, d: Duration) {
        self.elapsed[index] += d;
    }

    /// Sum of all phase times.
    pub fn total(&self) -> Duration {
        self.elapsed.iter().sum()
    }

    /// Name of phase `index`, in the spelling of `Phase` (for reports).
    pub fn phase_name(index: usize) -> &'static str {
        match PHASE_ORDER[index] {
            crate::sim::Phase::Climate => "Climate",
            crate::sim::Phase::SpatialIndex => "SpatialIndex",
            crate::sim::Phase::Plants => "Plants",
            crate::sim::Phase::Herbivores => "Herbivores",
            crate::sim::Phase::Carnivores => "Carnivores",
            crate::sim::Phase::Reproduction => "Reproduction",
            crate::sim::Phase::Deaths => "Deaths",
            crate::sim::Phase::Species => "Species",
            crate::sim::Phase::Counters => "Counters",
        }
    }
}

/// One timed repetition.
#[derive(Clone, Debug, PartialEq)]
pub struct Repetition {
    /// Wall-clock seconds spent inside `tick()`, summed over the measured ticks.
    pub seconds: f64,
    pub ticks_per_second: f64,
    /// Living organisms after each measured tick (index 0 is after the first tick).
    pub living: Vec<u64>,
    /// `state_hash` at the end of the repetition.
    pub state_hash: String,
}

/// Summary of a benchmark: the timed repetitions and their median, minimum and maximum (ADR-0027 D1).
#[derive(Clone, Debug, PartialEq)]
pub struct BenchReport {
    pub warm_up: u32,
    pub ticks: u64,
    pub reps: Vec<Repetition>,
    pub median_tps: f64,
    pub min_tps: f64,
    pub max_tps: f64,
    /// Smallest living count after any measured tick of any repetition.
    pub min_living: u64,
}

/// Median of a non-empty list (mean of the two middle values for an even count).
pub fn median(values: &[f64]) -> f64 {
    assert!(!values.is_empty(), "median of an empty list");
    let mut v = values.to_vec();
    v.sort_by(|a, b| a.partial_cmp(b).expect("no NaN in timings"));
    let n = v.len();
    if n % 2 == 1 {
        v[n / 2]
    } else {
        (v[n / 2 - 1] + v[n / 2]) / 2.0
    }
}

/// Builds the start state of a repetition: a fresh simulation with its founders placed (not timed).
pub fn fresh(config: &Config) -> Result<Simulation, String> {
    let mut sim = Simulation::new(config).map_err(|e| format!("cannot build the world: {e}"))?;
    sim.populate_initial(config)
        .map_err(|e| format!("cannot place the founders: {e}"))?;
    Ok(sim)
}

/// One repetition: `ticks` ticks of `tick()` from the fresh start state, timed per tick.
pub fn repetition(config: &Config, ticks: u64) -> Result<Repetition, String> {
    let mut sim = fresh(config)?;
    let mut living = Vec::with_capacity(ticks as usize);
    let mut spent = Duration::ZERO;
    for _ in 0..ticks {
        let started = Instant::now();
        sim.tick();
        spent += started.elapsed();
        living.push(metrics::kind_counts(&sim).living.iter().sum());
    }
    let seconds = spent.as_secs_f64();
    Ok(Repetition {
        seconds,
        ticks_per_second: metrics::ticks_per_second(ticks, seconds),
        living,
        state_hash: checkpoint::state_hash(&sim),
    })
}

/// The benchmark: `warm_up` untimed repetitions, then `reps` timed repetitions of `ticks` ticks each.
pub fn benchmark(
    config: &Config,
    warm_up: u32,
    reps: u32,
    ticks: u64,
) -> Result<BenchReport, String> {
    if reps == 0 || ticks == 0 {
        return Err("the benchmark needs at least one repetition and one tick".to_string());
    }
    for _ in 0..warm_up {
        repetition(config, ticks)?;
    }
    let mut timed = Vec::with_capacity(reps as usize);
    for _ in 0..reps {
        timed.push(repetition(config, ticks)?);
    }
    let tps: Vec<f64> = timed.iter().map(|r| r.ticks_per_second).collect();
    let min_living = timed
        .iter()
        .flat_map(|r| r.living.iter().copied())
        .min()
        .unwrap_or(0);
    Ok(BenchReport {
        warm_up,
        ticks,
        median_tps: median(&tps),
        min_tps: tps.iter().copied().fold(f64::INFINITY, f64::min),
        max_tps: tps.iter().copied().fold(f64::NEG_INFINITY, f64::max),
        min_living,
        reps: timed,
    })
}

/// Phase profile of `ticks` ticks from the fresh start state, run with `tick_profiled` (ADR-0027 D2).
pub fn profile(config: &Config, ticks: u64) -> Result<(PhaseTimes, String), String> {
    let mut sim = fresh(config)?;
    let mut times = PhaseTimes::default();
    for _ in 0..ticks {
        sim.tick_profiled(&mut times);
    }
    Ok((times, checkpoint::state_hash(&sim)))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bench_config() -> Config {
        Config::from_json(BENCH_CONFIG_JSON)
            .expect("examples/perf-2000.json is a valid configuration")
    }

    fn small_config(seed: u64) -> Config {
        Config::from_json(&format!(
            r#"{{"seed": {seed}, "world": {{"width": 24, "height": 18}},
                "initial": {{"plants": 300, "herbivores": 60, "carnivores": 12}},
                "climate": {{"season_length": 40, "weather_amplitude": 0.5}}}}"#
        ))
        .unwrap()
    }

    #[test]
    fn median_takes_the_middle_value_or_the_mean_of_the_middle_pair() {
        assert_eq!(median(&[3.0, 1.0, 2.0]), 2.0);
        assert_eq!(median(&[4.0, 1.0, 3.0, 2.0]), 2.5);
        assert_eq!(median(&[7.0]), 7.0);
    }

    #[test]
    fn phase_times_accumulate_per_index_and_name_every_phase() {
        let mut t = PhaseTimes::default();
        t.add(0, Duration::from_micros(5));
        t.add(0, Duration::from_micros(7));
        t.add(8, Duration::from_micros(1));
        assert_eq!(t.elapsed[0], Duration::from_micros(12));
        assert_eq!(t.total(), Duration::from_micros(13));
        assert_eq!(PhaseTimes::phase_name(0), "Climate");
        assert_eq!(PhaseTimes::phase_name(2), "Plants");
        assert_eq!(PhaseTimes::phase_name(8), "Counters");
    }

    #[test]
    fn tick_profiled_gives_the_same_state_as_tick() {
        // ADR-0027 D2: the profiled tick runs the same phases, so the state (and its hash) must not differ.
        for seed in [1u64, 42] {
            let c = small_config(seed);
            let mut plain = fresh(&c).unwrap();
            let mut timed = fresh(&c).unwrap();
            let mut times = PhaseTimes::default();
            for t in 0..120 {
                plain.tick();
                timed.tick_profiled(&mut times);
                assert_eq!(
                    checkpoint::state_hash(&plain),
                    checkpoint::state_hash(&timed),
                    "seed {seed}, tick {t}"
                );
            }
            assert_eq!(times.ticks, 120);
            assert_eq!(plain.tick_count(), timed.tick_count());
        }
    }

    #[test]
    fn benchmark_repetitions_have_the_same_state_for_the_same_configuration() {
        let c = small_config(9);
        let a = repetition(&c, 40).unwrap();
        let b = repetition(&c, 40).unwrap();
        assert_eq!(a.state_hash, b.state_hash);
        assert_eq!(a.living, b.living);
        assert_eq!(a.living.len(), 40);
    }

    #[test]
    fn benchmark_rejects_empty_windows() {
        assert!(benchmark(&small_config(1), 0, 0, 10).is_err());
        assert!(benchmark(&small_config(1), 0, 1, 0).is_err());
    }

    #[test]
    fn fixed_benchmark_configuration_has_the_required_founders() {
        let c = bench_config();
        let founders = c.initial.plants + c.initial.herbivores + c.initial.carnivores;
        assert!(founders >= REQUIRED_LIVING, "founders {founders}");
        assert_eq!(c.seed, 42);
    }

    /// ADR-0027 D1 / TASK-026 criterion 1: the fixed benchmark configuration keeps at least `REQUIRED_LIVING`
    /// organisms alive on every one of the 100 measured ticks (seed 42, fresh start state).
    #[test]
    fn fixed_benchmark_living_holds_for_the_window() {
        let c = bench_config();
        let rep = repetition(&c, 100).unwrap();
        assert_eq!(rep.living.len(), 100);
        let (tick, low) = rep
            .living
            .iter()
            .enumerate()
            .min_by_key(|(_, &n)| n)
            .map(|(i, &n)| (i + 1, n))
            .unwrap();
        assert!(
            low >= REQUIRED_LIVING,
            "living fell to {low} at tick {tick}, below {REQUIRED_LIVING}"
        );
    }

    /// Guard against large slowdowns (ADR-0027 D4). The floor is about a quarter of the measured median, so a slower
    /// machine or a noisy host still passes. A slowdown of more than about four times fails the test.
    #[test]
    fn guard_ticks_per_second_floor() {
        let c = bench_config();
        let floor = if cfg!(debug_assertions) {
            GUARD_FLOOR_DEBUG_TPS
        } else {
            GUARD_FLOOR_RELEASE_TPS
        };
        let report = benchmark(&c, 1, 3, 20).unwrap();
        eprintln!(
            "perf guard: median {:.1} ticks/s (min {:.1}, max {:.1}), floor {:.1}, min living {}",
            report.median_tps, report.min_tps, report.max_tps, floor, report.min_living
        );
        assert!(
            report.median_tps >= floor,
            "median {:.1} ticks/s is below the floor {:.1} ticks/s",
            report.median_tps,
            floor
        );
    }
}

//! Food-chain integration tests (TASK-018, ADR-0019 Verification). Library level only: `Config`, `Simulation::new`,
//! `populate_initial`, `tick`, so they do not depend on the command line (TASK-019).

use crate::config::{Config, Initial};
use crate::entities::{Birth, Kind, LifespanRanges, MAX_LIFESPAN_RANGE};
use crate::genome::{random_genome, Genome, LOCI_PER_HAPLOTYPE, LOCI_PER_SLOT};
use crate::rng::Rng;
use crate::sim::Simulation;
use crate::world::{Cell, Torus};

const WIDTH: u64 = 64;
const HEIGHT: u64 = 48;

fn config(seed: u64, plants: u64, herbivores: u64, carnivores: u64) -> Config {
    Config::new(
        seed,
        WIDTH,
        HEIGHT,
        Initial {
            plants,
            herbivores,
            carnivores,
        },
    )
    .unwrap()
}

/// A simulation of the default world with the initial population placed (`populate_initial`).
fn world(seed: u64, plants: u64, herbivores: u64, carnivores: u64) -> Simulation {
    let cfg = config(seed, plants, herbivores, carnivores);
    let mut sim = Simulation::new(&cfg).unwrap();
    sim.populate_initial(&cfg).unwrap();
    sim
}

fn cell0() -> Cell {
    Torus::new(WIDTH as u32, HEIGHT as u32)
        .unwrap()
        .cell(0, 0)
        .unwrap()
}

fn living(sim: &Simulation, kind: Kind) -> u64 {
    sim.entities().living_count(kind)
}

/// Genome of `ploidy` haplotypes whose loci in trait block `slot` all have value `value`, the other blocks at 128.
fn genome_with_slot(ploidy: u8, slot: usize, value: u8) -> Genome {
    let mut loci = vec![128u8; usize::from(ploidy) * LOCI_PER_HAPLOTYPE];
    for h in 0..usize::from(ploidy) {
        let start = h * LOCI_PER_HAPLOTYPE + slot * LOCI_PER_SLOT;
        for v in &mut loci[start..start + LOCI_PER_SLOT] {
            *v = value;
        }
    }
    Genome::new(ploidy, loci).unwrap()
}

// ---- Lifespan scale (ADR-0019 D2) ----

#[test]
fn lifespan_range_is_half_to_one_and_a_half_times_the_centre() {
    let centres = LifespanRanges::default();
    assert_eq!(
        (centres.plants, centres.herbivores, centres.carnivores),
        (1500, 300, 400)
    );
    let cell = cell0();
    for (kind, centre, ploidy) in [
        (Kind::Plant, 1500u32, 1u8),
        (Kind::Herbivore, 300, 2),
        (Kind::Carnivore, 400, 2),
    ] {
        let lo = (f64::from(centre) * 0.5).floor() as u32;
        let hi = (f64::from(centre) * 1.5).ceil() as u32;
        let mut sum = 0u64;
        let mut rng = Rng::from_seed(7);
        let samples = 400;
        for _ in 0..samples {
            let g = random_genome(ploidy, &mut rng).unwrap();
            let b = Birth::from_genome_in(kind, cell, g, 50.0, 1.0, &centres).unwrap();
            let life = b.traits.max_lifespan();
            assert!(
                (lo..=hi).contains(&life),
                "{kind:?} lifespan {life} outside [{lo}, {hi}]"
            );
            sum += u64::from(life);
        }
        let mean = sum as f64 / f64::from(samples);
        assert!(
            (mean - f64::from(centre)).abs() < f64::from(centre) * 0.05,
            "{kind:?} mean lifespan {mean} not near the centre {centre}"
        );
    }
}

#[test]
fn from_genome_equals_from_genome_in_at_the_default_centres() {
    let g = genome_with_slot(2, 3, 77);
    let a = Birth::from_genome(Kind::Herbivore, cell0(), g.clone(), 50.0, 10.0).unwrap();
    let b = Birth::from_genome_in(
        Kind::Herbivore,
        cell0(),
        g,
        50.0,
        10.0,
        &LifespanRanges::default(),
    )
    .unwrap();
    assert_eq!(a, b);
}

#[test]
fn lifespan_bounds_are_clamped_to_the_allowed_range() {
    let huge = LifespanRanges {
        plants: 100_000,
        herbivores: 100_000,
        carnivores: 100_000,
    };
    let g = genome_with_slot(2, 3, 255);
    let b = Birth::from_genome_in(Kind::Carnivore, cell0(), g, 50.0, 1.0, &huge).unwrap();
    assert_eq!(f64::from(b.traits.max_lifespan()), MAX_LIFESPAN_RANGE.1);
}

#[test]
fn herbivore_with_max_age_300_matures_between_30_and_90_ticks() {
    use crate::mating::maturity_age;
    let centres = LifespanRanges::default();
    let cell = cell0();
    let lo = Birth::from_genome_in(
        Kind::Herbivore,
        cell,
        genome_with_slot(2, 3, 0),
        50.0,
        1.0,
        &centres,
    )
    .unwrap();
    let hi = Birth::from_genome_in(
        Kind::Herbivore,
        cell,
        genome_with_slot(2, 3, 255),
        50.0,
        1.0,
        &centres,
    )
    .unwrap();
    assert_eq!(lo.traits.max_lifespan(), 150);
    assert_eq!(hi.traits.max_lifespan(), 450);
    assert_eq!(maturity_age(lo.traits.max_lifespan()), 30);
    assert_eq!(maturity_age(hi.traits.max_lifespan()), 90);
}

// ---- Scenario tests (ADR-0019 Verification) ----

const SCENARIO_TICKS: u64 = 1_000;

/// First tick (1-based) at which `kind` has no living organism, within `ticks`; `None` if it lives on.
fn first_zero(sim: &mut Simulation, kind: Kind, ticks: u64) -> Option<u64> {
    for _ in 0..ticks {
        if living(sim, kind) == 0 {
            return Some(sim.tick_count());
        }
        sim.tick();
    }
    if living(sim, kind) == 0 {
        Some(sim.tick_count())
    } else {
        None
    }
}

#[test]
fn without_plants_herbivores_then_carnivores_die_out() {
    for seed in 1..=3 {
        let mut sim = world(seed, 0, 120, 20);
        let herb = first_zero(&mut sim, Kind::Herbivore, SCENARIO_TICKS)
            .unwrap_or_else(|| panic!("seed {seed}: herbivores survive without plants"));
        let carn = first_zero(&mut sim, Kind::Carnivore, SCENARIO_TICKS)
            .unwrap_or_else(|| panic!("seed {seed}: carnivores survive without plants"));
        assert!(
            carn >= herb,
            "seed {seed}: carnivores ({carn}) died before herbivores ({herb})"
        );
        assert_eq!(living(&sim, Kind::Plant), 0);
    }
}

#[test]
fn without_herbivores_carnivores_die_out() {
    for seed in 1..=3 {
        let mut sim = world(seed, 400, 0, 20);
        assert!(
            first_zero(&mut sim, Kind::Carnivore, SCENARIO_TICKS).is_some(),
            "seed {seed}: carnivores survive without herbivores"
        );
    }
}

#[test]
fn plants_alone_persist() {
    for seed in 1..=3 {
        let mut sim = world(seed, 400, 0, 0);
        sim.run(SCENARIO_TICKS);
        assert!(
            living(&sim, Kind::Plant) > 0,
            "seed {seed}: plants died out in {SCENARIO_TICKS} ticks"
        );
    }
}

// ---- Default-parameter tests ----

#[test]
fn default_plants_survive_and_reproduce_on_their_own_for_1000_ticks() {
    for seed in 1..=3 {
        let mut sim = world(seed, 400, 0, 0);
        sim.run(SCENARIO_TICKS);
        assert!(living(&sim, Kind::Plant) > 0, "seed {seed}: plants died");
        assert!(
            sim.entities().births(Kind::Plant) > 0,
            "seed {seed}: no plant births"
        );
    }
}

#[test]
fn herbivores_with_plenty_of_plants_survive_and_breed_for_500_ticks() {
    for seed in 1..=3 {
        let mut sim = world(seed, 1500, 120, 0);
        sim.run(500);
        assert!(
            living(&sim, Kind::Herbivore) > 0,
            "seed {seed}: herbivores died within 500 ticks"
        );
        assert!(
            sim.entities().births(Kind::Herbivore) > 0,
            "seed {seed}: no herbivore births in 500 ticks"
        );
    }
}

// ---- Conservation and never-revive ----

#[test]
fn per_kind_balance_holds_after_every_tick() {
    let mut sim = world(3, 400, 120, 20);
    for t in 1..=SCENARIO_TICKS {
        sim.tick();
        for kind in Kind::ALL {
            let e = sim.entities();
            let expected = e.initial(kind) + e.births(kind) - e.deaths(kind);
            assert_eq!(
                expected,
                living(&sim, kind),
                "tick {t}: {kind:?} initial + births - deaths != living"
            );
        }
        sim.entities()
            .check_balance()
            .unwrap_or_else(|e| panic!("tick {t}: check_balance failed: {e:?}"));
    }
}

#[test]
fn a_kind_that_reaches_zero_stays_at_zero() {
    let mut sim = world(4, 400, 120, 20);
    let mut dead = [false; 3];
    for _ in 0..10_000 {
        sim.tick();
        for kind in Kind::ALL {
            let n = living(&sim, kind);
            if dead[kind.index()] {
                assert_eq!(n, 0, "{kind:?} revived at tick {}", sim.tick_count());
            } else if n == 0 {
                dead[kind.index()] = true;
            }
        }
    }
}

#[test]
fn fixed_key_configuration_runs_1000_ticks_without_error() {
    let mut sim = world(11, 400, 120, 20);
    sim.run(1_000);
    assert_eq!(sim.tick_count(), 1_000);
    assert!(sim.check_spatial().is_ok());
    assert!(sim.entities().check_balance().is_ok());
}

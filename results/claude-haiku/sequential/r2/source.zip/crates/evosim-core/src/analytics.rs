//! Evolution analytics (ADR-0021, `docs/METRICS.md`): per-sample numbers of a running simulation.
//!
//! [`MetricsLog::record`] only reads the simulation (`&Simulation`), so sampling cannot change the state (ADR-0008,
//! ADR-0021 D5). The CLI calls it at the series ticks, never inside `tick()`. The log keeps the cumulative birth and death
//! counts of the previous sample, so that the values since the last sample can be reported.

use crate::ecology::PlantTraits;
use crate::entities::{vision_radius, DeathCause, Kind, Organism};
use crate::metrics::{float, int, write_node, Node};
use crate::sim::Simulation;

/// Format name written to the metrics file (ADR-0021 D4).
pub const FORMAT: &str = "evosim-metrics";
/// Version of the metrics file layout (ADR-0021 D6).
pub const FORMAT_VERSION: u32 = 1;

/// Trait names of plants (order of the `traits` list and of the sample objects).
const PLANT_TRAITS: [&str; 8] = [
    "speed",
    "strength",
    "fertility",
    "max_lifespan",
    "max_health",
    "cold_tolerance",
    "drought_tolerance",
    "yield",
];
/// Trait names of herbivores and carnivores.
const ANIMAL_TRAITS: [&str; 8] = [
    "speed",
    "strength",
    "fertility",
    "max_lifespan",
    "max_health",
    "aggression",
    "caution",
    "vision",
];

/// Trait names of a kind, in the order used by the metrics file.
pub fn trait_names(kind: Kind) -> &'static [&'static str] {
    match kind {
        Kind::Plant => &PLANT_TRAITS,
        Kind::Herbivore | Kind::Carnivore => &ANIMAL_TRAITS,
    }
}

/// Mean, population standard deviation (divisor n), minimum and maximum of a set of values.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Stat {
    pub mean: f64,
    pub sd: f64,
    pub min: f64,
    pub max: f64,
}

/// Statistics of `values`, summed in the given order (so one build gives one result). `None` for an empty slice.
pub fn stat(values: &[f64]) -> Option<Stat> {
    if values.is_empty() {
        return None;
    }
    let n = values.len() as f64;
    let mean = values.iter().sum::<f64>() / n;
    let variance = values.iter().map(|x| (x - mean) * (x - mean)).sum::<f64>() / n;
    Some(Stat {
        mean,
        sd: variance.sqrt(),
        min: values.iter().copied().fold(f64::INFINITY, f64::min),
        max: values.iter().copied().fold(f64::NEG_INFINITY, f64::max),
    })
}

/// Mean of a set of values, summed in the given order. `None` for an empty slice.
fn mean(values: &[f64]) -> Option<f64> {
    stat(values).map(|s| s.mean)
}

/// Highest and mean generation of the living organisms of a kind (founders are generation 0).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Generation {
    pub max: u32,
    pub mean: f64,
}

/// The metrics of one kind at one sample tick (ADR-0021 D2).
#[derive(Clone, Debug, PartialEq)]
pub struct KindSnapshot {
    /// Living individuals.
    pub population: u64,
    /// Cumulative since tick 0.
    pub births: u64,
    /// Cumulative since tick 0.
    pub deaths: u64,
    /// Births since the previous sample; 0 at the first sample of a log.
    pub births_since_last: u64,
    /// Deaths since the previous sample; 0 at the first sample of a log.
    pub deaths_since_last: u64,
    /// Cumulative deaths per cause, in `DeathCause::ALL` order.
    pub deaths_by_cause: [u64; 5],
    /// Species alive after the last completed tick (lags by up to one species check, ADR-0018).
    pub species_living: u64,
    /// Species records ever created for the kind, extinct or not.
    pub species_recognised: u64,
    /// `None` when no organism of the kind is alive.
    pub generation: Option<Generation>,
    /// Mean energy of the living organisms; `None` when none is alive.
    pub mean_energy: Option<f64>,
    /// Mean age of the living organisms; `None` when none is alive.
    pub mean_age: Option<f64>,
    /// Statistics of every trait of the kind, in `trait_names` order; `None` when none is alive.
    pub traits: Option<Vec<(&'static str, Stat)>>,
}

/// One sample: the metrics of every kind at `tick`, indexed by `Kind::index()`.
#[derive(Clone, Debug, PartialEq)]
pub struct Snapshot {
    pub tick: u64,
    pub kinds: [KindSnapshot; 3],
}

/// The decoded trait values of one living organism, in `trait_names(kind)` order.
pub fn trait_values(o: &Organism) -> Vec<f64> {
    let t = o.traits();
    let mut values = vec![
        f64::from(t.speed()),
        f64::from(t.strength()),
        f64::from(t.fertility()),
        f64::from(t.max_lifespan()),
        f64::from(t.max_health()),
    ];
    match o.kind() {
        Kind::Plant => {
            let p = PlantTraits::from_genome(o.genome());
            values.extend([
                f64::from(p.cold_tolerance),
                f64::from(p.drought_tolerance),
                f64::from(p.yield_per_unit),
            ]);
        }
        Kind::Herbivore | Kind::Carnivore => {
            if let Some(tend) = o.tendencies() {
                values.push(f64::from(tend.aggression()));
                values.push(f64::from(tend.caution()));
            }
            values.push(f64::from(vision_radius(o.genome())));
        }
    }
    debug_assert_eq!(values.len(), trait_names(o.kind()).len());
    values
}

/// The metrics of one kind. `previous` is the cumulative (births, deaths) at the previous sample, if any.
fn kind_snapshot(sim: &Simulation, kind: Kind, previous: Option<(u64, u64)>) -> KindSnapshot {
    let entities = sim.entities();
    let births = entities.births(kind);
    let deaths = entities.deaths(kind);
    let (births_before, deaths_before) = previous.unwrap_or((births, deaths));

    let names = trait_names(kind);
    let mut columns: Vec<Vec<f64>> = vec![Vec::new(); names.len()];
    let mut generations: Vec<u32> = Vec::new();
    let mut energies: Vec<f64> = Vec::new();
    let mut ages: Vec<f64> = Vec::new();
    // Ascending id order (`Entities::living`), so the sums are fixed for one state.
    for o in entities.living().filter(|o| o.kind() == kind) {
        generations.push(o.generation());
        energies.push(f64::from(o.energy()));
        ages.push(f64::from(o.age()));
        for (column, value) in columns.iter_mut().zip(trait_values(o)) {
            column.push(value);
        }
    }

    let generation = if generations.is_empty() {
        None
    } else {
        let sum: f64 = generations.iter().map(|&g| f64::from(g)).sum();
        Some(Generation {
            max: generations.iter().copied().max().unwrap_or(0),
            mean: sum / generations.len() as f64,
        })
    };
    let traits = if generations.is_empty() {
        None
    } else {
        Some(
            names
                .iter()
                .zip(&columns)
                .filter_map(|(name, column)| stat(column).map(|s| (*name, s)))
                .collect(),
        )
    };

    KindSnapshot {
        population: generations.len() as u64,
        births,
        deaths,
        births_since_last: births - births_before,
        deaths_since_last: deaths - deaths_before,
        deaths_by_cause: DeathCause::ALL.map(|cause| entities.deaths_by_cause(kind, cause)),
        species_living: sim.species().living_now(kind) as u64,
        species_recognised: sim.species().record_count(kind) as u64,
        generation,
        mean_energy: mean(&energies),
        mean_age: mean(&ages),
        traits,
    }
}

/// Cumulative (births, deaths) of every kind, indexed by `Kind::index()`.
pub fn cumulative_events(sim: &Simulation) -> [(u64, u64); 3] {
    let entities = sim.entities();
    Kind::ALL.map(|k| (entities.births(k), entities.deaths(k)))
}

/// The metrics of `sim` at its current tick, without keeping a log (ADR-0026 D6). `previous` is the cumulative
/// (births, deaths) per kind at the previous sample, as returned by [`cumulative_events`]. Read-only.
pub fn sample(sim: &Simulation, previous: Option<[(u64, u64); 3]>) -> Snapshot {
    let kinds = Kind::ALL.map(|k| kind_snapshot(sim, k, previous.map(|p| p[k.index()])));
    Snapshot { tick: sim.tick_count(), kinds }
}

/// Parameters of a run that the metrics file records in its header (ADR-0021 D4).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RunInfo {
    pub seed: u64,
    pub tick_start: u64,
    pub tick_end: u64,
    pub sample_every: u64,
}

/// The samples taken so far, in the order they were recorded.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct MetricsLog {
    samples: Vec<Snapshot>,
    /// Cumulative (births, deaths) per kind at the last sample.
    previous: Option<[(u64, u64); 3]>,
}

impl MetricsLog {
    /// An empty log.
    pub fn new() -> MetricsLog {
        MetricsLog::default()
    }

    /// Records the metrics of `sim` at its current tick. Read-only: `sim` is not changed.
    pub fn record(&mut self, sim: &Simulation) {
        let snapshot = sample(sim, self.previous);
        self.previous = Some(cumulative_events(sim));
        self.samples.push(snapshot);
    }

    /// The recorded samples, oldest first.
    pub fn samples(&self) -> &[Snapshot] {
        &self.samples
    }

    /// The metrics file (ADR-0021 D4, `docs/METRICS.md`): one JSON object with a line per key of the header and a line
    /// per sample, with a final newline. Fails only if a number is not finite.
    pub fn to_json(&self, run: &RunInfo) -> Result<String, String> {
        let samples = self
            .samples
            .iter()
            .map(|s| sample_node(s).map(|n| Node::Raw(inline(&n))))
            .collect::<Result<Vec<_>, _>>()?;
        let trait_list = Node::Obj(
            Kind::ALL
                .iter()
                .map(|&k| {
                    let names = trait_names(k)
                        .iter()
                        .map(|n| quoted_node(n))
                        .collect::<Vec<_>>();
                    (kind_key(k), Node::Raw(inline(&Node::Arr(names))))
                })
                .collect(),
        );
        let root = Node::Obj(vec![
            ("format", quoted_node(FORMAT)),
            ("format_version", int(u64::from(FORMAT_VERSION))),
            ("contract", int(u64::from(crate::CONTRACT_VERSION))),
            ("seed", int(run.seed)),
            ("tick_start", int(run.tick_start)),
            ("tick_end", int(run.tick_end)),
            ("sample_every", int(run.sample_every)),
            ("traits", trait_list),
            ("samples", Node::Arr(samples)),
        ]);
        let mut out = String::new();
        write_node(&mut out, &root, 0);
        out.push('\n');
        Ok(out)
    }
}

fn kind_key(kind: Kind) -> &'static str {
    match kind {
        Kind::Plant => "plants",
        Kind::Herbivore => "herbivores",
        Kind::Carnivore => "carnivores",
    }
}

fn cause_key(cause: DeathCause) -> &'static str {
    match cause {
        DeathCause::OldAge => "old_age",
        DeathCause::Starvation => "starvation",
        DeathCause::Predation => "predation",
        DeathCause::Exposure => "exposure",
        DeathCause::Injury => "injury",
    }
}

/// A JSON string of a fixed ASCII name (no escaping needed for the names used here).
fn quoted(name: &str) -> String {
    format!("\"{name}\"")
}

fn quoted_node(name: &str) -> Node {
    Node::Raw(quoted(name))
}

/// A number, or `null` for an empty set.
fn opt_float(v: Option<f64>) -> Result<Node, String> {
    match v {
        Some(x) => float(x),
        None => Ok(Node::Raw("null".to_string())),
    }
}

fn stat_node(s: &Stat) -> Result<Node, String> {
    Ok(Node::Obj(vec![
        ("mean", float(s.mean)?),
        ("sd", float(s.sd)?),
        ("min", float(s.min)?),
        ("max", float(s.max)?),
    ]))
}

fn kind_node(k: &KindSnapshot) -> Result<Node, String> {
    let generation = match k.generation {
        Some(g) => Node::Obj(vec![("max", int(u64::from(g.max))), ("mean", float(g.mean)?)]),
        None => Node::Raw("null".to_string()),
    };
    let traits = match &k.traits {
        Some(list) => Node::Obj(
            list.iter()
                .map(|(name, s)| Ok((*name, stat_node(s)?)))
                .collect::<Result<Vec<_>, String>>()?,
        ),
        None => Node::Raw("null".to_string()),
    };
    Ok(Node::Obj(vec![
        ("population", int(k.population)),
        ("births", int(k.births)),
        ("deaths", int(k.deaths)),
        ("births_since_last", int(k.births_since_last)),
        ("deaths_since_last", int(k.deaths_since_last)),
        (
            "deaths_by_cause",
            Node::Obj(
                DeathCause::ALL
                    .iter()
                    .zip(k.deaths_by_cause)
                    .map(|(&c, n)| (cause_key(c), int(n)))
                    .collect(),
            ),
        ),
        ("species_living", int(k.species_living)),
        ("species_recognised", int(k.species_recognised)),
        ("generation", generation),
        ("mean_energy", opt_float(k.mean_energy)?),
        ("mean_age", opt_float(k.mean_age)?),
        ("traits", traits),
    ]))
}

fn sample_node(s: &Snapshot) -> Result<Node, String> {
    let mut entries = vec![("tick", int(s.tick))];
    for k in Kind::ALL {
        entries.push((kind_key(k), kind_node(&s.kinds[k.index()])?));
    }
    Ok(Node::Obj(entries))
}

/// One compact line of JSON for a node (used for the samples, one per line).
fn inline(node: &Node) -> String {
    match node {
        Node::Raw(text) => text.clone(),
        Node::Obj(entries) => {
            let items: Vec<String> = entries
                .iter()
                .map(|(k, v)| format!("\"{k}\": {}", inline(v)))
                .collect();
            format!("{{{}}}", items.join(", "))
        }
        Node::Arr(items) => {
            let items: Vec<String> = items.iter().map(inline).collect();
            format!("[{}]", items.join(", "))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::{json, Config};
    use crate::entities::{Birth, Kind};
    use crate::genome::{Genome, LOCI_PER_SLOT};

    /// A genome whose eight trait blocks are all `slots[i]` (the locus value), for each haplotype.
    fn genome(ploidy: u8, slots: [u8; 8]) -> Genome {
        let mut loci = Vec::new();
        for _ in 0..ploidy {
            for s in slots {
                loci.extend(std::iter::repeat_n(s, LOCI_PER_SLOT));
            }
        }
        Genome::new(ploidy, loci).unwrap()
    }

    fn empty_world() -> Config {
        Config::from_json(
            r#"{"seed": 1, "world": {"width": 4, "height": 4},
                "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
        )
        .unwrap()
    }

    fn plant(sim: &Simulation, x: u32, y: u32, slots: [u8; 8], energy: f32) -> Birth {
        let cell = sim.world().topology.cell(x, y).unwrap();
        Birth::from_genome(Kind::Plant, cell, genome(1, slots), energy, 10.0).unwrap()
    }

    /// Plant slots: speed = `speed`, every other block at 255 (so the plant is viable).
    fn plant_speed(speed: u8) -> [u8; 8] {
        [speed, 255, 255, 255, 255, 255, 255, 255]
    }

    #[test]
    fn stat_of_two_values_is_hand_checkable() {
        let s = stat(&[0.0, 4.0]).unwrap();
        assert_eq!((s.mean, s.sd, s.min, s.max), (2.0, 2.0, 0.0, 4.0));
        let one = stat(&[3.0]).unwrap();
        assert_eq!((one.mean, one.sd), (3.0, 0.0));
        assert_eq!(stat(&[]), None);
    }

    #[test]
    fn plant_population_traits_births_and_deaths_match_a_hand_checked_world() {
        let mut sim = Simulation::new(&empty_world()).unwrap();
        let a = sim
            .add_founder(plant(&sim, 0, 0, plant_speed(0), 10.0))
            .unwrap();
        let b = sim
            .add_founder(plant(&sim, 1, 0, plant_speed(255), 20.0))
            .unwrap();
        let mut log = MetricsLog::new();
        log.record(&sim);

        // A child of the second plant (generation 1), then the first plant is injured to death.
        let child = plant(&sim, 2, 0, plant_speed(255), 4.0);
        sim.entities_mut()
            .spawn_child(child, [Some(b), None])
            .unwrap();
        sim.entities_mut()
            .get_mut(a)
            .unwrap()
            .damage(10.0, DeathCause::Injury);
        sim.entities_mut().deaths_phase(0);
        log.record(&sim);

        let [first, second] = [&log.samples()[0], &log.samples()[1]];
        let p0 = &first.kinds[Kind::Plant.index()];
        assert_eq!(p0.population, 2);
        assert_eq!((p0.births, p0.deaths), (0, 0));
        assert_eq!((p0.births_since_last, p0.deaths_since_last), (0, 0));
        assert_eq!(p0.deaths_by_cause, [0; 5]);
        assert_eq!(p0.generation, Some(Generation { max: 0, mean: 0.0 }));
        assert_eq!(p0.mean_energy, Some(15.0));
        assert_eq!(p0.mean_age, Some(0.0));
        let speed0 = p0.traits.as_ref().unwrap()[0];
        assert_eq!(speed0.0, "speed");
        assert_eq!(speed0.1, Stat { mean: 2.0, sd: 2.0, min: 0.0, max: 4.0 });

        let p1 = &second.kinds[Kind::Plant.index()];
        assert_eq!(p1.population, 2);
        assert_eq!((p1.births, p1.deaths), (1, 1));
        assert_eq!((p1.births_since_last, p1.deaths_since_last), (1, 1));
        // OldAge, Starvation, Predation, Exposure, Injury
        assert_eq!(p1.deaths_by_cause, [0, 0, 0, 0, 1]);
        assert_eq!(p1.generation, Some(Generation { max: 1, mean: 0.5 }));
        assert_eq!(p1.mean_energy, Some(12.0));
        assert_eq!(p1.mean_age, Some(1.0));
        let speed1 = p1.traits.as_ref().unwrap()[0].1;
        assert_eq!(speed1, Stat { mean: 4.0, sd: 0.0, min: 4.0, max: 4.0 });

        // Plant-only traits are listed; animal traits are not. No herbivores or carnivores: null statistics.
        let names: Vec<&str> = p1.traits.as_ref().unwrap().iter().map(|t| t.0).collect();
        assert_eq!(names, trait_names(Kind::Plant));
        for kind in [Kind::Herbivore, Kind::Carnivore] {
            let k = &second.kinds[kind.index()];
            assert_eq!(k.population, 0);
            assert_eq!((k.births, k.deaths), (0, 0));
            assert_eq!(k.generation, None);
            assert_eq!(k.mean_energy, None);
            assert_eq!(k.mean_age, None);
            assert_eq!(k.traits, None);
        }
    }

    #[test]
    fn plant_only_traits_decode_from_slots_five_to_seven() {
        let mut sim = Simulation::new(&empty_world()).unwrap();
        let cell = sim.world().topology.cell(0, 0).unwrap();
        let birth = Birth::from_genome(
            Kind::Plant,
            cell,
            genome(1, [0, 255, 255, 255, 255, 255, 0, 0]),
            10.0,
            10.0,
        )
        .unwrap();
        sim.add_founder(birth).unwrap();
        let mut log = MetricsLog::new();
        log.record(&sim);
        let traits = log.samples()[0].kinds[Kind::Plant.index()]
            .traits
            .clone()
            .unwrap();
        let get = |name: &str| traits.iter().find(|t| t.0 == name).unwrap().1;
        assert_eq!(get("cold_tolerance").mean, 1.0);
        assert_eq!(get("drought_tolerance").mean, 0.0);
        assert_eq!(get("yield").mean, 0.5);
    }

    #[test]
    fn herbivore_traits_use_the_animal_slots_and_vision_is_decoded() {
        let mut sim = Simulation::new(&empty_world()).unwrap();
        let cell = sim.world().topology.cell(0, 0).unwrap();
        // A: aggression 1.0, caution 0.0, vision 1. B: aggression 0.0, caution 1.0, vision 5.
        let a = genome(2, [255, 255, 255, 255, 255, 255, 0, 0]);
        let b = genome(2, [0, 0, 0, 0, 255, 0, 255, 255]);
        sim.add_founder(Birth::from_genome(Kind::Herbivore, cell, a, 50.0, 50.0).unwrap())
            .unwrap();
        let cell = sim.world().topology.cell(1, 0).unwrap();
        sim.add_founder(Birth::from_genome(Kind::Herbivore, cell, b, 30.0, 50.0).unwrap())
            .unwrap();
        let mut log = MetricsLog::new();
        log.record(&sim);
        let k = &log.samples()[0].kinds[Kind::Herbivore.index()];
        assert_eq!(k.population, 2);
        assert_eq!(k.mean_energy, Some(40.0));
        let traits = k.traits.clone().unwrap();
        let get = |name: &str| traits.iter().find(|t| t.0 == name).unwrap().1;
        assert_eq!(get("vision"), Stat { mean: 3.0, sd: 2.0, min: 1.0, max: 5.0 });
        assert_eq!(get("aggression"), Stat { mean: 0.5, sd: 0.5, min: 0.0, max: 1.0 });
        assert_eq!(get("caution"), Stat { mean: 0.5, sd: 0.5, min: 0.0, max: 1.0 });
        assert_eq!(get("speed"), Stat { mean: 2.0, sd: 2.0, min: 0.0, max: 4.0 });
        assert!(traits.iter().all(|t| t.0 != "yield"));
    }

    #[test]
    fn births_since_last_are_differences_of_the_cumulative_births() {
        let mut sim = Simulation::new(&empty_world()).unwrap();
        let parent = sim
            .add_founder(plant(&sim, 0, 0, plant_speed(128), 10.0))
            .unwrap();
        let mut log = MetricsLog::new();
        log.record(&sim);
        for x in 1..=2 {
            let child = plant(&sim, x, 0, plant_speed(128), 5.0);
            sim.entities_mut()
                .spawn_child(child, [Some(parent), None])
                .unwrap();
            log.record(&sim);
        }
        let s = log.samples();
        let births: Vec<u64> = s.iter().map(|x| x.kinds[0].births).collect();
        assert_eq!(births, vec![0, 1, 2]);
        let since: Vec<u64> = s.iter().map(|x| x.kinds[0].births_since_last).collect();
        assert_eq!(since, vec![0, 1, 1]);
    }

    #[test]
    fn json_writes_the_header_and_nulls_for_empty_sets() {
        let mut sim = Simulation::new(&empty_world()).unwrap();
        sim.add_founder(plant(&sim, 0, 0, plant_speed(255), 10.0))
            .unwrap();
        let mut log = MetricsLog::new();
        log.record(&sim);
        let info = RunInfo {
            seed: 1,
            tick_start: 0,
            tick_end: 0,
            sample_every: 1,
        };
        let text = log.to_json(&info).unwrap();
        let value = json::parse(&text).expect("metrics JSON parses");
        assert!(matches!(value, json::Value::Object(_)));
        for key in [
            "\"format\": \"evosim-metrics\"",
            "\"format_version\": 1",
            "\"contract\": 1",
            "\"seed\": 1",
            "\"sample_every\": 1",
            "\"traits\": {",
        ] {
            assert!(text.contains(key), "missing {key}");
        }
        // One sample line, and the carnivores' generation, traits and means are null.
        let sample_lines: Vec<&str> = text.lines().filter(|l| l.contains("\"tick\": 0")).collect();
        assert_eq!(sample_lines.len(), 1);
        assert!(sample_lines[0].contains("\"generation\": null"));
        assert!(sample_lines[0].contains("\"mean_energy\": null"));
        assert!(sample_lines[0].contains("\"traits\": null"));
        assert!(text.contains("\"yield\""));
    }

    #[test]
    fn sampling_at_every_tick_does_not_change_the_simulation() {
        let config = Config::from_json(
            r#"{"seed": 3, "world": {"width": 32, "height": 24},
                "initial": {"plants": 200, "herbivores": 60, "carnivores": 10}}"#,
        )
        .unwrap();
        let mut sampled = Simulation::new(&config).unwrap();
        sampled.populate_initial(&config).unwrap();
        let mut plain = sampled.clone();
        let mut log = MetricsLog::new();
        // The first sample is taken before the first tick, as the CLI does at `tick_start`.
        log.record(&sampled);
        for _ in 0..300 {
            sampled.tick();
            log.record(&sampled);
            plain.tick();
        }
        assert_eq!(sampled, plain);
        assert_eq!(
            crate::checkpoint::state_hash(&sampled),
            crate::checkpoint::state_hash(&plain)
        );
        assert_eq!(log.samples().len(), 301);
        assert_eq!(log.samples()[300].tick, 300);
        // Interval values add up to the cumulative totals of the run.
        for kind in Kind::ALL {
            let i = kind.index();
            let births: u64 = log.samples().iter().map(|s| s.kinds[i].births_since_last).sum();
            let deaths: u64 = log.samples().iter().map(|s| s.kinds[i].deaths_since_last).sum();
            assert_eq!(births, sampled.entities().births(kind));
            assert_eq!(deaths, sampled.entities().deaths(kind));
            let last = &log.samples()[300].kinds[i];
            assert!(last.species_recognised >= last.species_living);
            assert_eq!(
                last.population,
                sampled.entities().living_count(kind),
                "kind {i}"
            );
        }
    }
}

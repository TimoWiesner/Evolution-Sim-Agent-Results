//! Neighbour search on the wrapping grid (ADR-0003 and its TASK-010 amendment).
//!
//! [`SpatialIndex`] answers "which organisms lie within radius `r` of cell `c`, optionally of one kind?".
//! It has three parts:
//! 1. `positions`: the current position and kind of every indexed organism (the truth).
//! 2. A CSR per-cell snapshot (`cell_start`, `items`) taken from `positions` in ascending id order by counting
//!    sort, so every bucket is sorted by id.
//! 3. `stale`: the ids inserted, moved or removed since the snapshot. Their snapshot entries are ignored and
//!    their answers come from `positions`.
//!
//! Every mutation updates `positions` and `stale` at once, so a query is always correct. The snapshot is rebuilt
//! when the stale set grows past a bound (compaction); a rebuild never changes a result.
//!
//! Results are ascending by [`OrganismId`] and never contain duplicates. Distance is the torus Chebyshev
//! distance of ADR-0007; the cells searched are exactly [`Torus::neighbours`].

use std::collections::{BTreeMap, HashMap};
use std::fmt;

use crate::entities::{Kind, OrganismId};
use crate::world::{Cell, Torus};

/// Errors of [`SpatialIndex`] mutations and of the consistency check.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SpatialError {
    /// `insert` of an id that is already indexed. The index is unchanged.
    DuplicateId(OrganismId),
    /// `move_to` or `remove` of an id that is not indexed. The index is unchanged.
    UnknownId(OrganismId),
    /// A cell that does not lie on this torus. The index is unchanged.
    CellOutsideTorus { x: u32, y: u32 },
    /// An organism and the index disagree (missing, wrong cell or kind, or indexed but not alive).
    OutOfSync(OrganismId),
}

impl fmt::Display for SpatialError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            SpatialError::DuplicateId(id) => write!(f, "organism {} is already indexed", id.0),
            SpatialError::UnknownId(id) => write!(f, "organism {} is not indexed", id.0),
            SpatialError::CellOutsideTorus { x, y } => {
                write!(f, "cell ({x}, {y}) lies outside the torus")
            }
            SpatialError::OutOfSync(id) => {
                write!(f, "spatial index is out of sync for organism {}", id.0)
            }
        }
    }
}

impl std::error::Error for SpatialError {}

/// Current placement of one indexed organism.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Placed {
    cell: Cell,
    kind: Kind,
}

/// One entry of the snapshot buckets.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SnapEntry {
    id: OrganismId,
    kind: Kind,
}

/// Minimum stale-set size before compaction is considered.
const COMPACT_MIN: usize = 32;

/// Per-cell neighbour index over a [`Torus`]. See the module documentation.
#[derive(Clone, Debug)]
pub struct SpatialIndex {
    torus: Torus,
    positions: BTreeMap<OrganismId, Placed>,
    /// Length `cell_count + 1`; bucket `b` is `items[cell_start[b]..cell_start[b + 1]]`.
    cell_start: Vec<u32>,
    items: Vec<SnapEntry>,
    /// Organisms inserted, moved or removed since the snapshot, with their current placement (`None` once removed).
    /// Hash map: the membership test in a query is O(1), and the answers are sorted, so the order of this map does
    /// not reach a result (TASK-026 ADR-0027 D3).
    stale: HashMap<OrganismId, Option<Placed>>,
}

/// Two indexes are equal when they index the same organisms at the same places. The snapshot layout and
/// the stale set are derived state and may differ while the answers are the same.
impl PartialEq for SpatialIndex {
    fn eq(&self, other: &Self) -> bool {
        self.torus == other.torus && self.positions == other.positions
    }
}

impl SpatialIndex {
    /// An empty index over `torus`.
    pub fn new(torus: Torus) -> SpatialIndex {
        SpatialIndex {
            torus,
            positions: BTreeMap::new(),
            cell_start: vec![0; torus.cell_count() + 1],
            items: Vec::new(),
            stale: HashMap::new(),
        }
    }

    /// The torus this index covers.
    pub fn torus(&self) -> Torus {
        self.torus
    }

    /// Number of indexed organisms.
    pub fn len(&self) -> usize {
        self.positions.len()
    }

    /// True when no organism is indexed.
    pub fn is_empty(&self) -> bool {
        self.positions.is_empty()
    }

    /// Current cell and kind of an indexed organism.
    pub fn position(&self, id: OrganismId) -> Option<(Cell, Kind)> {
        self.positions.get(&id).map(|p| (p.cell, p.kind))
    }

    /// Ids of all indexed organisms, ascending.
    pub fn ids(&self) -> impl Iterator<Item = OrganismId> + '_ {
        self.positions.keys().copied()
    }

    /// Adds an organism. Fails if the id is already indexed or the cell is not on the torus.
    pub fn insert(&mut self, id: OrganismId, cell: Cell, kind: Kind) -> Result<(), SpatialError> {
        self.check_cell(cell)?;
        if self.positions.contains_key(&id) {
            return Err(SpatialError::DuplicateId(id));
        }
        let placed = Placed { cell, kind };
        self.positions.insert(id, placed);
        self.stale.insert(id, Some(placed));
        self.compact_if_needed();
        Ok(())
    }

    /// Moves an indexed organism to `cell`. From the next query on, it is not returned from its old cell.
    pub fn move_to(&mut self, id: OrganismId, cell: Cell) -> Result<(), SpatialError> {
        self.check_cell(cell)?;
        let placed = self
            .positions
            .get_mut(&id)
            .ok_or(SpatialError::UnknownId(id))?;
        placed.cell = cell;
        let now = *placed;
        self.stale.insert(id, Some(now));
        self.compact_if_needed();
        Ok(())
    }

    /// Removes an indexed organism. From the next query on, it is never returned.
    pub fn remove(&mut self, id: OrganismId) -> Result<(), SpatialError> {
        if self.positions.remove(&id).is_none() {
            return Err(SpatialError::UnknownId(id));
        }
        self.stale.insert(id, None);
        self.compact_if_needed();
        Ok(())
    }

    /// Rebuilds the snapshot and clears the stale set. Changes no result; it only bounds the query cost.
    pub fn rebuild(&mut self) {
        let cells = self.torus.cell_count();
        let mut start = vec![0u32; cells + 1];
        for placed in self.positions.values() {
            start[self.torus.index(placed.cell) + 1] += 1;
        }
        for b in 0..cells {
            start[b + 1] += start[b];
        }
        let total = start[cells] as usize;
        let mut next = start.clone();
        let mut items = vec![
            SnapEntry {
                id: OrganismId(0),
                kind: Kind::Plant,
            };
            total
        ];
        // Ascending id order (BTreeMap), so each bucket is filled in ascending id order.
        for (&id, placed) in &self.positions {
            let b = self.torus.index(placed.cell);
            items[next[b] as usize] = SnapEntry {
                id,
                kind: placed.kind,
            };
            next[b] += 1;
        }
        self.cell_start = start;
        self.items = items;
        self.stale.clear();
    }

    /// All indexed organisms within Chebyshev distance `radius` of `centre`, ascending by id, no duplicates.
    /// `filter` of `None` returns every kind; `Some(kind)` only that kind. A radius of any size is valid.
    pub fn within(&self, centre: Cell, radius: u32, filter: Option<Kind>) -> Vec<OrganismId> {
        let mut out = Vec::new();
        self.within_into(centre, radius, filter, &mut out);
        out
    }

    /// Same as [`SpatialIndex::within`], writing into `out` (cleared first) to reuse its allocation.
    /// A centre that is not on the torus gives an empty result.
    pub fn within_into(
        &self,
        centre: Cell,
        radius: u32,
        filter: Option<Kind>,
        out: &mut Vec<OrganismId>,
    ) {
        out.clear();
        if self.check_cell(centre).is_err() {
            return;
        }
        let matches = |kind: Kind| filter.is_none_or(|k| k == kind);
        // Every cell of the list is within `radius`, so no per-organism distance test is needed here.
        for cell in self.torus.neighbours(centre, radius) {
            let b = self.torus.index(cell);
            let bucket = &self.items[self.cell_start[b] as usize..self.cell_start[b + 1] as usize];
            for entry in bucket {
                if !self.stale.contains_key(&entry.id) && matches(entry.kind) {
                    out.push(entry.id);
                }
            }
        }
        // Stale organisms are answered from the current positions, so each id is counted once.
        for (id, placed) in &self.stale {
            if let Some(placed) = placed {
                if matches(placed.kind) && self.torus.distance(centre, placed.cell) <= radius {
                    out.push(*id);
                }
            }
        }
        out.sort_unstable();
    }

    fn check_cell(&self, cell: Cell) -> Result<(), SpatialError> {
        if self.torus.cell(cell.x(), cell.y()) == Some(cell) {
            Ok(())
        } else {
            Err(SpatialError::CellOutsideTorus {
                x: cell.x(),
                y: cell.y(),
            })
        }
    }

    fn compact_if_needed(&mut self) {
        let limit = COMPACT_MIN.max(self.positions.len() / 4);
        if self.stale.len() > limit {
            self.rebuild();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::rng::Rng;

    fn torus(w: u32, h: u32) -> Torus {
        Torus::new(w, h).expect("valid size")
    }

    fn cell(t: &Torus, x: u32, y: u32) -> Cell {
        t.cell(x, y).expect("in range")
    }

    fn id(n: u64) -> OrganismId {
        OrganismId(n)
    }

    /// Independent reference: per-axis wrapped distance, computed without `Torus::distance`.
    fn reference_distance(w: u32, h: u32, a: Cell, b: Cell) -> u32 {
        let axis = |p: u32, q: u32, len: u32| {
            let l = i64::from(len);
            let d = (i64::from(p) - i64::from(q)).rem_euclid(l);
            d.min(l - d)
        };
        axis(a.x(), b.x(), w).max(axis(a.y(), b.y(), h)) as u32
    }

    /// Brute-force answer over a list of (id, cell, kind), ascending by id.
    fn brute(
        t: &Torus,
        live: &[(OrganismId, Cell, Kind)],
        centre: Cell,
        radius: u32,
        filter: Option<Kind>,
    ) -> Vec<OrganismId> {
        let mut out: Vec<OrganismId> = live
            .iter()
            .filter(|(_, c, k)| {
                filter.is_none_or(|f| f == *k)
                    && reference_distance(t.width(), t.height(), centre, *c) <= radius
            })
            .map(|(i, _, _)| *i)
            .collect();
        out.sort();
        out
    }

    fn random_kind(rng: &mut Rng) -> Kind {
        Kind::ALL[rng.next_below(3) as usize]
    }

    fn random_cell(t: &Torus, rng: &mut Rng) -> Cell {
        let x = rng.next_below(u64::from(t.width())) as u32;
        let y = rng.next_below(u64::from(t.height())) as u32;
        cell(t, x, y)
    }

    #[test]
    fn empty_index_answers_empty() {
        let t = torus(5, 4);
        let idx = SpatialIndex::new(t);
        assert!(idx.is_empty());
        assert_eq!(idx.len(), 0);
        assert!(idx.within(cell(&t, 0, 0), 10, None).is_empty());
    }

    #[test]
    fn corners_find_each_other_across_both_seams() {
        let t = torus(8, 6);
        let mut idx = SpatialIndex::new(t);
        let corners = [(0, 0), (7, 0), (0, 5), (7, 5)];
        for (n, (x, y)) in corners.iter().enumerate() {
            idx.insert(id(n as u64), cell(&t, *x, *y), Kind::Plant)
                .unwrap();
        }
        // From (0,0) with radius 1, the corners at x=7 and y=5 are neighbours through the seams.
        assert_eq!(
            idx.within(cell(&t, 0, 0), 1, None),
            vec![id(0), id(1), id(2), id(3)]
        );
        // The diagonal corner (7,5) is at Chebyshev distance 1 from (0,0).
        assert_eq!(
            idx.within(cell(&t, 7, 5), 1, None),
            vec![id(0), id(1), id(2), id(3)]
        );
        // A cell that is more than one step from every corner finds none of them.
        assert_eq!(
            idx.within(cell(&t, 0, 3), 1, None),
            Vec::<OrganismId>::new()
        );
    }

    #[test]
    fn seam_column_is_found_from_the_edge_only() {
        let t = torus(10, 10);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 9, 4), Kind::Herbivore).unwrap();
        assert_eq!(idx.within(cell(&t, 0, 4), 1, None), vec![id(1)]);
        assert_eq!(
            idx.within(cell(&t, 0, 4), 0, None),
            Vec::<OrganismId>::new()
        );
        // From x=2 to x=9 on a 10-wide torus the short way is 3 steps (2 -> 1 -> 0 -> 9).
        assert_eq!(
            idx.within(cell(&t, 2, 4), 2, None),
            Vec::<OrganismId>::new()
        );
        assert_eq!(idx.within(cell(&t, 2, 4), 3, None), vec![id(1)]);
    }

    #[test]
    fn radius_zero_is_the_centre_cell_only() {
        let t = torus(6, 6);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 2, 2), Kind::Plant).unwrap();
        idx.insert(id(2), cell(&t, 2, 2), Kind::Carnivore).unwrap();
        idx.insert(id(3), cell(&t, 3, 2), Kind::Plant).unwrap();
        assert_eq!(idx.within(cell(&t, 2, 2), 0, None), vec![id(1), id(2)]);
    }

    #[test]
    fn kind_filter_selects_one_kind_or_all() {
        let t = torus(6, 6);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 1, 1), Kind::Plant).unwrap();
        idx.insert(id(2), cell(&t, 2, 1), Kind::Herbivore).unwrap();
        idx.insert(id(3), cell(&t, 1, 2), Kind::Carnivore).unwrap();
        let c = cell(&t, 1, 1);
        assert_eq!(idx.within(c, 2, None), vec![id(1), id(2), id(3)]);
        assert_eq!(idx.within(c, 2, Some(Kind::Plant)), vec![id(1)]);
        assert_eq!(idx.within(c, 2, Some(Kind::Herbivore)), vec![id(2)]);
        assert_eq!(
            idx.within(c, 0, Some(Kind::Carnivore)),
            Vec::<OrganismId>::new()
        );
    }

    #[test]
    fn results_are_ascending_whatever_the_insertion_order() {
        let t = torus(7, 7);
        let mut idx = SpatialIndex::new(t);
        for n in (0..6).rev() {
            idx.insert(id(n), cell(&t, n as u32, 3), Kind::Plant)
                .unwrap();
        }
        assert_eq!(
            idx.within(cell(&t, 3, 3), 6, None),
            (0..6).map(id).collect::<Vec<_>>()
        );
    }

    #[test]
    fn one_by_one_world_returns_each_organism_once() {
        let t = torus(1, 1);
        let mut idx = SpatialIndex::new(t);
        for n in 0..5 {
            idx.insert(id(n), cell(&t, 0, 0), Kind::Plant).unwrap();
        }
        assert_eq!(
            idx.within(cell(&t, 0, 0), 5, None),
            (0..5).map(id).collect::<Vec<_>>()
        );
        assert_eq!(idx.within(cell(&t, 0, 0), 0, None).len(), 5);
    }

    #[test]
    fn radius_larger_than_world_returns_everything_once() {
        let t = torus(3, 2);
        let mut idx = SpatialIndex::new(t);
        let mut n = 0;
        for x in 0..3 {
            for y in 0..2 {
                idx.insert(id(n), cell(&t, x, y), Kind::Herbivore).unwrap();
                n += 1;
            }
        }
        assert_eq!(
            idx.within(cell(&t, 1, 1), 100, None),
            (0..6).map(id).collect::<Vec<_>>()
        );
    }

    #[test]
    fn insert_rejects_duplicates_and_leaves_index_unchanged() {
        let t = torus(4, 4);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(7), cell(&t, 1, 1), Kind::Plant).unwrap();
        assert_eq!(
            idx.insert(id(7), cell(&t, 2, 2), Kind::Carnivore),
            Err(SpatialError::DuplicateId(id(7)))
        );
        assert_eq!(idx.position(id(7)), Some((cell(&t, 1, 1), Kind::Plant)));
        assert_eq!(idx.len(), 1);
    }

    #[test]
    fn cell_from_another_torus_is_rejected() {
        let big = torus(10, 10);
        let small = torus(4, 4);
        let mut idx = SpatialIndex::new(small);
        let outside = cell(&big, 8, 8);
        assert_eq!(
            idx.insert(id(1), outside, Kind::Plant),
            Err(SpatialError::CellOutsideTorus { x: 8, y: 8 })
        );
        assert!(idx.is_empty());
        assert!(idx.within(outside, 3, None).is_empty());
    }

    #[test]
    fn move_leaves_the_old_cell_and_appears_in_the_new_one() {
        let t = torus(9, 9);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 4, 4), Kind::Plant).unwrap();
        idx.rebuild();
        idx.move_to(id(1), cell(&t, 6, 4)).unwrap();
        assert!(idx.within(cell(&t, 4, 4), 0, None).is_empty());
        assert_eq!(idx.within(cell(&t, 6, 4), 0, None), vec![id(1)]);
        idx.rebuild();
        assert!(idx.within(cell(&t, 4, 4), 0, None).is_empty());
        assert_eq!(idx.within(cell(&t, 6, 4), 0, None), vec![id(1)]);
        assert_eq!(idx.position(id(1)), Some((cell(&t, 6, 4), Kind::Plant)));
    }

    #[test]
    fn move_of_unknown_id_is_an_error() {
        let t = torus(3, 3);
        let mut idx = SpatialIndex::new(t);
        assert_eq!(
            idx.move_to(id(9), cell(&t, 0, 0)),
            Err(SpatialError::UnknownId(id(9)))
        );
        assert!(idx.is_empty());
    }

    #[test]
    fn removed_organism_is_never_returned_before_or_after_rebuild() {
        let t = torus(5, 5);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 2, 2), Kind::Plant).unwrap();
        idx.insert(id(2), cell(&t, 2, 2), Kind::Plant).unwrap();
        idx.rebuild();
        idx.remove(id(1)).unwrap();
        assert_eq!(idx.within(cell(&t, 2, 2), 1, None), vec![id(2)]);
        idx.rebuild();
        assert_eq!(idx.within(cell(&t, 2, 2), 1, None), vec![id(2)]);
        assert_eq!(idx.position(id(1)), None);
        assert_eq!(idx.len(), 1);
    }

    #[test]
    fn remove_twice_or_unknown_is_an_error() {
        let t = torus(3, 3);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(4), cell(&t, 1, 1), Kind::Plant).unwrap();
        assert_eq!(idx.remove(id(5)), Err(SpatialError::UnknownId(id(5))));
        assert_eq!(idx.remove(id(4)), Ok(()));
        assert_eq!(idx.remove(id(4)), Err(SpatialError::UnknownId(id(4))));
    }

    #[test]
    fn removed_then_reinserted_id_is_found_only_at_its_new_place() {
        let t = torus(6, 6);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(3), cell(&t, 0, 0), Kind::Plant).unwrap();
        idx.rebuild();
        idx.remove(id(3)).unwrap();
        idx.insert(id(3), cell(&t, 5, 5), Kind::Carnivore).unwrap();
        assert!(idx.within(cell(&t, 0, 0), 0, None).is_empty());
        assert_eq!(idx.within(cell(&t, 5, 5), 0, None), vec![id(3)]);
        idx.rebuild();
        assert!(idx.within(cell(&t, 0, 0), 0, None).is_empty());
        assert_eq!(idx.within(cell(&t, 5, 5), 0, None), vec![id(3)]);
    }

    #[test]
    fn within_into_clears_the_buffer_first() {
        let t = torus(4, 4);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 0, 0), Kind::Plant).unwrap();
        let mut buf = vec![id(99), id(98)];
        idx.within_into(cell(&t, 3, 3), 0, None, &mut buf);
        assert!(buf.is_empty());
        idx.within_into(cell(&t, 0, 0), 0, None, &mut buf);
        assert_eq!(buf, vec![id(1)]);
    }

    #[test]
    fn torus_distance_is_chebyshev_with_wrap() {
        let t = torus(10, 10);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(1), cell(&t, 9, 9), Kind::Plant).unwrap();
        // x and y both differ by 1 across the seams.
        assert_eq!(idx.within(cell(&t, 0, 0), 1, None), vec![id(1)]);
        // Chebyshev, not Manhattan: (0,0) to (9,9) is distance 1, so radius 1 must contain it.
        assert!(idx.within(cell(&t, 0, 0), 0, None).is_empty());
    }

    #[test]
    fn compaction_does_not_change_results() {
        let t = torus(8, 8);
        let mut rng = Rng::from_seed(0xC0FFEE);
        let mut plain = SpatialIndex::new(t);
        let mut compacted = SpatialIndex::new(t);
        for n in 0..60u64 {
            let c = random_cell(&t, &mut rng);
            let k = random_kind(&mut rng);
            plain.insert(id(n), c, k).unwrap();
            compacted.insert(id(n), c, k).unwrap();
            compacted.rebuild();
        }
        for n in 0..60u64 {
            let c = random_cell(&t, &mut rng);
            plain.move_to(id(n), c).unwrap();
            compacted.move_to(id(n), c).unwrap();
        }
        compacted.rebuild();
        for centre in t.neighbours(cell(&t, 0, 0), 8) {
            for r in 0..4 {
                assert_eq!(
                    plain.within(centre, r, None),
                    compacted.within(centre, r, None)
                );
            }
        }
    }

    /// The randomised comparison of TASK-010: seeded random operation sequences on small and odd worlds,
    /// every query compared with a brute-force scan. 60 seeds x 60 queries = 3,600 queries.
    #[test]
    fn randomised_queries_match_brute_force() {
        let mut queries = 0usize;
        for seed in 1..=60u64 {
            let mut rng = Rng::from_seed(seed);
            let w = 1 + rng.next_below(9) as u32;
            let h = 1 + rng.next_below(9) as u32;
            let t = torus(w, h);
            let mut idx = SpatialIndex::new(t);
            let mut live: Vec<(OrganismId, Cell, Kind)> = Vec::new();
            let mut next_id = 0u64;
            let initial = rng.next_below(41) as usize;
            for _ in 0..initial {
                let c = random_cell(&t, &mut rng);
                let k = random_kind(&mut rng);
                idx.insert(id(next_id), c, k).unwrap();
                live.push((id(next_id), c, k));
                next_id += 1;
            }
            let mut answered = 0usize;
            for _ in 0..200 {
                match rng.next_below(10) {
                    0 | 1 => {
                        let c = random_cell(&t, &mut rng);
                        let k = random_kind(&mut rng);
                        idx.insert(id(next_id), c, k).unwrap();
                        live.push((id(next_id), c, k));
                        next_id += 1;
                    }
                    2..=4 if !live.is_empty() => {
                        let pick = rng.next_below(live.len() as u64) as usize;
                        let c = random_cell(&t, &mut rng);
                        idx.move_to(live[pick].0, c).unwrap();
                        live[pick].1 = c;
                    }
                    5 if !live.is_empty() => {
                        let pick = rng.next_below(live.len() as u64) as usize;
                        let (gone, _, _) = live.swap_remove(pick);
                        idx.remove(gone).unwrap();
                    }
                    6 => idx.rebuild(),
                    _ => {
                        let centre = random_cell(&t, &mut rng);
                        let radius = rng.next_below(u64::from(w.max(h)) + 4) as u32;
                        let filter = match rng.next_below(4) {
                            0 => Some(Kind::Plant),
                            1 => Some(Kind::Herbivore),
                            2 => Some(Kind::Carnivore),
                            _ => None,
                        };
                        let got = idx.within(centre, radius, filter);
                        let want = brute(&t, &live, centre, radius, filter);
                        assert_eq!(
                            got, want,
                            "seed {seed}, world {w}x{h}, centre {:?}, radius {radius}, filter {filter:?}",
                            (centre.x(), centre.y())
                        );
                        answered += 1;
                    }
                }
            }
            // Also check every query with every radius up to the world size at the end of the run.
            for cx in 0..w {
                for cy in 0..h {
                    let centre = cell(&t, cx, cy);
                    for radius in 0..=w.max(h) + 1 {
                        assert_eq!(
                            idx.within(centre, radius, None),
                            brute(&t, &live, centre, radius, None),
                            "seed {seed}, final sweep, centre ({cx},{cy}), radius {radius}"
                        );
                        answered += 1;
                    }
                }
            }
            assert_eq!(idx.len(), live.len());
            queries += answered;
        }
        assert!(queries >= 1000, "only {queries} queries were compared");
    }

    /// Larger world with about 2,000 organisms and small radii, compared with brute force, with
    /// seam-crossing centres included by drawing centres uniformly on the torus.
    #[test]
    fn randomised_large_world_matches_brute_force() {
        let t = torus(64, 48);
        let mut rng = Rng::from_seed(0x2000);
        let mut idx = SpatialIndex::new(t);
        let mut live = Vec::new();
        for n in 0..2000u64 {
            let c = random_cell(&t, &mut rng);
            let k = random_kind(&mut rng);
            idx.insert(id(n), c, k).unwrap();
            live.push((id(n), c, k));
        }
        for q in 0..1000 {
            if q % 10 == 0 {
                // Move 50 organisms, then rebuild every few rounds, to mix overlay and snapshot answers.
                for _ in 0..50 {
                    let pick = rng.next_below(live.len() as u64) as usize;
                    let c = random_cell(&t, &mut rng);
                    idx.move_to(live[pick].0, c).unwrap();
                    live[pick].1 = c;
                }
                if q % 30 == 0 {
                    idx.rebuild();
                }
            }
            let centre = random_cell(&t, &mut rng);
            let radius = rng.next_below(7) as u32;
            let filter = if q % 3 == 0 {
                None
            } else {
                Some(random_kind(&mut rng))
            };
            assert_eq!(
                idx.within(centre, radius, filter),
                brute(&t, &live, centre, radius, filter),
                "query {q}"
            );
        }
    }

    #[test]
    fn ids_and_positions_follow_mutations() {
        let t = torus(4, 4);
        let mut idx = SpatialIndex::new(t);
        idx.insert(id(5), cell(&t, 1, 2), Kind::Carnivore).unwrap();
        idx.insert(id(2), cell(&t, 0, 0), Kind::Plant).unwrap();
        assert_eq!(idx.ids().collect::<Vec<_>>(), vec![id(2), id(5)]);
        assert_eq!(idx.position(id(5)), Some((cell(&t, 1, 2), Kind::Carnivore)));
        idx.remove(id(2)).unwrap();
        assert_eq!(idx.ids().collect::<Vec<_>>(), vec![id(5)]);
    }

    /// Timing measurement, run by hand in release mode (see `docs/ARCHITECTURE.md`, "Measured performance"):
    /// `cargo test -p evosim-core --release --locked -- --ignored --nocapture bench_index_vs_brute_force`.
    /// Both methods run the same workload and must return the same total number of hits.
    #[test]
    #[ignore]
    fn bench_index_vs_brute_force() {
        for &(w, h, radius) in &[(64u32, 48u32, 2u32), (64, 48, 5), (256, 192, 2)] {
            let t = torus(w, h);
            let mut rng = Rng::from_seed(0xBE7C);
            let n = 2000usize;
            let mut kinds = Vec::with_capacity(n);
            let mut cells = Vec::with_capacity(n);
            for i in 0..n {
                kinds.push(if i < 1600 {
                    Kind::Plant
                } else if i < 1880 {
                    Kind::Herbivore
                } else {
                    Kind::Carnivore
                });
                cells.push(random_cell(&t, &mut rng));
            }
            // Per tick: 10 % of the organisms move one step (random cell here, same for both methods).
            let ticks = 200usize;
            let mut moves: Vec<Vec<(usize, Cell)>> = Vec::with_capacity(ticks);
            for _ in 0..ticks {
                let mut m = Vec::new();
                for _ in 0..n / 10 {
                    let pick = rng.next_below(n as u64) as usize;
                    m.push((pick, random_cell(&t, &mut rng)));
                }
                moves.push(m);
            }
            let queries = (ticks * n) as f64;

            let mut brute_ns = Vec::new();
            let mut index_ns = Vec::new();
            let mut brute_hits = 0usize;
            let mut index_hits = 0usize;
            for _rep in 0..3 {
                // Brute force: scan all organisms for every query.
                let mut pos = cells.clone();
                let mut hits = 0usize;
                let start = std::time::Instant::now();
                for m in &moves {
                    for &(i, c) in m {
                        pos[i] = c;
                    }
                    for centre in &pos {
                        for other in &pos {
                            if t.distance(*centre, *other) <= radius {
                                hits += 1;
                            }
                        }
                    }
                }
                brute_ns.push(start.elapsed().as_nanos() as f64 / queries);
                brute_hits = hits;

                // Index: moves, then the queries of the tick, then the compaction at the end of the tick.
                let mut idx = SpatialIndex::new(t);
                for i in 0..n {
                    idx.insert(id(i as u64), cells[i], kinds[i]).unwrap();
                }
                idx.rebuild();
                let mut cur = cells.clone();
                let mut out = Vec::new();
                let mut hits = 0usize;
                let start = std::time::Instant::now();
                for m in &moves {
                    for &(i, c) in m {
                        idx.move_to(id(i as u64), c).unwrap();
                        cur[i] = c;
                    }
                    for &centre in &cur {
                        idx.within_into(centre, radius, None, &mut out);
                        hits += out.len();
                    }
                    idx.rebuild();
                }
                index_ns.push(start.elapsed().as_nanos() as f64 / queries);
                index_hits = hits;
            }
            assert_eq!(
                index_hits, brute_hits,
                "index and brute force disagree on the total hit count"
            );
            brute_ns.sort_by(|a, b| a.partial_cmp(b).unwrap());
            index_ns.sort_by(|a, b| a.partial_cmp(b).unwrap());
            let (b, i) = (brute_ns[1], index_ns[1]);
            eprintln!(
                "bench world {w}x{h} organisms {n} (plants 1600, herbivores 280, carnivores 120) radius {radius} \
                 ticks {ticks} moves/tick {} : brute {:.1} ns/query, index {:.1} ns/query, speed-up {:.2}x \
                 (median of 3 reps; hits per run {brute_hits})",
                n / 10,
                b,
                i,
                b / i
            );
            if !cfg!(debug_assertions) {
                assert!(
                    i < b,
                    "index ({i:.1} ns) must be faster than brute force ({b:.1} ns)"
                );
            }
        }
    }
}

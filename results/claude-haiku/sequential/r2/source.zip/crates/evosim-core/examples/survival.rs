//! Survival run of the default food chain (TASK-018, ADR-0019 D5).
//!
//! For each seed, builds the configuration from the fixed keys (default parameters otherwise), populates the initial
//! population and ticks the simulation. Per seed and kind it prints the tick at which the kind died out, or `survived`
//! when it was still alive at the last tick. It also prints the births, deaths and final living count per kind, and the
//! wall-clock time. Progress goes to stderr.
//!
//! Usage (run from the workspace root, see `scripts/survival.sh`):
//!
//! ```text
//! cargo run --release -p evosim-core --example survival -- --ticks 10000 --seeds 1,2,3,4,5
//! ```
//!
//! Options: `--ticks N` (default 10000), `--seeds a,b,...` (default 1,2,3,4,5), `--initial P,H,C` (default 400,120,20),
//! `--world W,H` (default 64,48). Exit status is non-zero on bad arguments or a simulation error.

use std::process::ExitCode;
use std::time::Instant;

use evosim_core::config::{Config, Initial};
use evosim_core::entities::{DeathCause, Kind};
use evosim_core::sim::Simulation;

struct Args {
    ticks: u64,
    seeds: Vec<u64>,
    initial: Initial,
    width: u64,
    height: u64,
}

fn parse_list(text: &str) -> Result<Vec<u64>, String> {
    text.split(',')
        .map(|t| {
            t.trim()
                .parse::<u64>()
                .map_err(|_| format!("not a number: {t:?}"))
        })
        .collect()
}

fn parse_args(mut raw: impl Iterator<Item = String>) -> Result<Args, String> {
    let mut args = Args {
        ticks: 10_000,
        seeds: vec![1, 2, 3, 4, 5],
        initial: Initial {
            plants: 400,
            herbivores: 120,
            carnivores: 20,
        },
        width: 64,
        height: 48,
    };
    while let Some(flag) = raw.next() {
        let mut value = || raw.next().ok_or_else(|| format!("{flag} needs a value"));
        match flag.as_str() {
            "--ticks" => {
                args.ticks = value()?
                    .parse()
                    .map_err(|_| "--ticks needs a number".to_string())?
            }
            "--seeds" => args.seeds = parse_list(&value()?)?,
            "--initial" => {
                let v = parse_list(&value()?)?;
                if v.len() != 3 {
                    return Err("--initial needs P,H,C".to_string());
                }
                args.initial = Initial {
                    plants: v[0],
                    herbivores: v[1],
                    carnivores: v[2],
                };
            }
            "--world" => {
                let v = parse_list(&value()?)?;
                if v.len() != 2 {
                    return Err("--world needs W,H".to_string());
                }
                args.width = v[0];
                args.height = v[1];
            }
            other => return Err(format!("unknown argument {other:?}")),
        }
    }
    if args.seeds.is_empty() {
        return Err("--seeds needs at least one seed".to_string());
    }
    Ok(args)
}

/// Runs one seed. Returns the extinction tick per kind (`None` = survived) and the per-kind counters.
fn run_seed(args: &Args, seed: u64) -> Result<SeedResult, String> {
    let config =
        Config::new(seed, args.width, args.height, args.initial).map_err(|e| e.to_string())?;
    let mut sim = Simulation::new(&config).map_err(|e| format!("{e:?}"))?;
    sim.populate_initial(&config)
        .map_err(|e| format!("{e:?}"))?;
    let mut died: [Option<u64>; 3] = [None; 3];
    let start = Instant::now();
    for _ in 0..args.ticks {
        sim.tick();
        let t = sim.tick_count();
        for kind in Kind::ALL {
            if died[kind.index()].is_none() && sim.entities().living_count(kind) == 0 {
                died[kind.index()] = Some(t);
            }
        }
        if t % 1000 == 0 {
            eprintln!(
                "seed {seed} tick {t}: plants {} herbivores {} carnivores {} ({:.1} s)",
                sim.entities().living_count(Kind::Plant),
                sim.entities().living_count(Kind::Herbivore),
                sim.entities().living_count(Kind::Carnivore),
                start.elapsed().as_secs_f64()
            );
        }
    }
    sim.entities()
        .check_balance()
        .map_err(|e| format!("seed {seed}: balance check failed: {e:?}"))?;
    let mut counts = [[0u64; 4]; 3];
    for kind in Kind::ALL {
        let i = kind.index();
        counts[i] = [
            sim.entities().initial(kind),
            sim.entities().births(kind),
            sim.entities().deaths(kind),
            sim.entities().living_count(kind),
        ];
    }
    let causes = Kind::ALL.map(|kind| {
        DeathCause::ALL
            .iter()
            .map(|&c| format!("{c:?}={}", sim.entities().deaths_by_cause(kind, c)))
            .collect()
    });
    Ok(SeedResult {
        seed,
        died,
        counts,
        causes,
        ticks: sim.tick_count(),
        seconds: start.elapsed().as_secs_f64(),
    })
}

struct SeedResult {
    seed: u64,
    died: [Option<u64>; 3],
    /// Per kind: initial, births, deaths, living at the last tick.
    counts: [[u64; 4]; 3],
    /// Per kind: death counts per cause, as `Cause=n` strings (diagnostics, `SURVIVAL_CAUSES=1`).
    causes: [Vec<String>; 3],
    ticks: u64,
    seconds: f64,
}

fn describe(tick: Option<u64>) -> String {
    match tick {
        Some(t) => format!("died out at tick {t}"),
        None => "survived".to_string(),
    }
}

fn main() -> ExitCode {
    let args = match parse_args(std::env::args().skip(1)) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("survival: {e}");
            eprintln!(
                "usage: survival [--ticks N] [--seeds a,b,...] [--initial P,H,C] [--world W,H]"
            );
            return ExitCode::from(2);
        }
    };
    println!(
        "survival: world {}x{}, initial plants {} herbivores {} carnivores {}, ticks {}",
        args.width,
        args.height,
        args.initial.plants,
        args.initial.herbivores,
        args.initial.carnivores,
        args.ticks
    );
    let mut failed = false;
    for &seed in &args.seeds {
        match run_seed(&args, seed) {
            Ok(r) => {
                println!(
                    "seed {}: ticks run {}, time {:.2} s",
                    r.seed, r.ticks, r.seconds
                );
                for kind in Kind::ALL {
                    let i = kind.index();
                    let [initial, births, deaths, living] = r.counts[i];
                    println!(
                        "  {:?}: {} ; initial {} births {} deaths {} living {}",
                        kind,
                        describe(r.died[i]),
                        initial,
                        births,
                        deaths,
                        living
                    );
                    if std::env::var_os("SURVIVAL_CAUSES").is_some() {
                        println!("    causes: {}", r.causes[i].join(" "));
                    }
                }
            }
            Err(e) => {
                eprintln!("survival: {e}");
                failed = true;
            }
        }
    }
    if failed {
        ExitCode::from(1)
    } else {
        ExitCode::SUCCESS
    }
}

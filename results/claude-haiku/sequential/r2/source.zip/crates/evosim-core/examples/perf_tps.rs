//! Ticks-per-second benchmark and phase profile (TASK-026, ADR-0027). Run through `scripts/perf.sh`.
//!
//! ```text
//! cargo run --release --locked -p evosim-core --example perf_tps -- --config examples/perf-2000.json --ticks 100 --warm 2 --reps 5
//! ```
//!
//! Options: `--config FILE` (required), `--ticks N` (measured ticks per repetition, default 100), `--warm N` (untimed
//! repetitions, default 2), `--reps N` (timed repetitions, default 5), `--profile-ticks N` (ticks of the phase profile,
//! default equal to `--ticks`, 0 disables it), `--living-floor N` (default 2,000: exit status 1 if the living count
//! falls below N on a measured tick; the secondary run uses 0). Prints one JSON object on stdout; progress and errors
//! go to stderr. Exit status 2 on bad arguments or an invalid configuration.

use std::path::PathBuf;
use std::process::ExitCode;

use evosim_core::config::Config;
use evosim_core::perf::{self, PhaseTimes, REQUIRED_LIVING};

struct Args {
    config: PathBuf,
    ticks: u64,
    warm: u32,
    reps: u32,
    profile_ticks: Option<u64>,
    living_floor: u64,
}

fn parse_args(raw: impl Iterator<Item = String>) -> Result<Args, String> {
    let mut config = None;
    let mut ticks = 100u64;
    let mut warm = 2u32;
    let mut reps = 5u32;
    let mut profile_ticks = None;
    let mut living_floor = REQUIRED_LIVING;
    let mut raw = raw;
    while let Some(flag) = raw.next() {
        let mut value = || raw.next().ok_or_else(|| format!("{flag} needs a value"));
        match flag.as_str() {
            "--config" => config = Some(PathBuf::from(value()?)),
            "--ticks" => {
                ticks = value()?
                    .parse()
                    .map_err(|_| "--ticks needs a number".to_string())?
            }
            "--warm" => {
                warm = value()?
                    .parse()
                    .map_err(|_| "--warm needs a number".to_string())?
            }
            "--reps" => {
                reps = value()?
                    .parse()
                    .map_err(|_| "--reps needs a number".to_string())?
            }
            "--profile-ticks" => {
                profile_ticks = Some(
                    value()?
                        .parse()
                        .map_err(|_| "--profile-ticks needs a number".to_string())?,
                )
            }
            "--living-floor" => {
                living_floor = value()?
                    .parse()
                    .map_err(|_| "--living-floor needs a number".to_string())?
            }
            other => return Err(format!("unknown argument {other:?}")),
        }
    }
    Ok(Args {
        config: config.ok_or("--config FILE is required")?,
        ticks,
        warm,
        reps,
        profile_ticks,
        living_floor,
    })
}

fn json_f64(v: f64) -> String {
    format!("{v:.3}")
}

fn json_seconds(v: f64) -> String {
    format!("{v:.6}")
}

fn main() -> ExitCode {
    let args = match parse_args(std::env::args().skip(1)) {
        Ok(a) => a,
        Err(e) => {
            eprintln!("perf_tps: {e}");
            return ExitCode::from(2);
        }
    };
    let config = match Config::load(&args.config) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("perf_tps: {e}");
            return ExitCode::from(2);
        }
    };
    let report = match perf::benchmark(&config, args.warm, args.reps, args.ticks) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("perf_tps: {e}");
            return ExitCode::from(2);
        }
    };
    let profile_ticks = args.profile_ticks.unwrap_or(args.ticks);
    let profile = if profile_ticks > 0 {
        match perf::profile(&config, profile_ticks) {
            Ok(p) => Some(p),
            Err(e) => {
                eprintln!("perf_tps: {e}");
                return ExitCode::from(2);
            }
        }
    } else {
        None
    };

    let reps: Vec<String> = report
        .reps
        .iter()
        .map(|r| {
            format!(
                "{{\"seconds\": {}, \"ticks_per_second\": {}, \"state_hash\": \"{}\"}}",
                json_seconds(r.seconds),
                json_f64(r.ticks_per_second),
                r.state_hash
            )
        })
        .collect();
    let phases = match &profile {
        Some((times, _)) => {
            let total = times.total().as_secs_f64();
            let rows: Vec<String> = (0..PhaseTimes::default().elapsed.len())
                .map(|i| {
                    let s = times.elapsed[i].as_secs_f64();
                    let share = if total > 0.0 { 100.0 * s / total } else { 0.0 };
                    format!(
                        "{{\"phase\": \"{}\", \"seconds\": {}, \"share_percent\": {}}}",
                        PhaseTimes::phase_name(i),
                        json_seconds(s),
                        json_f64(share)
                    )
                })
                .collect();
            format!(
                "{{\"ticks\": {}, \"total_seconds\": {}, \"state_hash\": \"{}\", \"phases\": [{}]}}",
                times.ticks,
                json_seconds(total),
                profile_hash(&profile),
                rows.join(", ")
            )
        }
        None => "null".to_string(),
    };
    println!(
        "{{\n  \"config\": \"{}\",\n  \"seed\": {},\n  \"world\": {{\"width\": {}, \"height\": {}}},\n  \"warm_up_repetitions\": {},\n  \"measured_ticks\": {},\n  \"timed_repetitions\": {},\n  \"median_ticks_per_second\": {},\n  \"min_ticks_per_second\": {},\n  \"max_ticks_per_second\": {},\n  \"min_living_on_measured_ticks\": {},\n  \"required_living\": {},\n  \"repetitions\": [{}],\n  \"profile\": {}\n}}",
        args.config.display(),
        config.seed,
        config.world.width,
        config.world.height,
        report.warm_up,
        report.ticks,
        report.reps.len(),
        json_f64(report.median_tps),
        json_f64(report.min_tps),
        json_f64(report.max_tps),
        report.min_living,
        REQUIRED_LIVING,
        reps.join(", "),
        phases
    );
    if report.min_living < args.living_floor {
        eprintln!(
            "perf_tps: population fell to {} on a measured tick (required {})",
            report.min_living, args.living_floor
        );
        return ExitCode::from(1);
    }
    ExitCode::SUCCESS
}

fn profile_hash(profile: &Option<(PhaseTimes, String)>) -> String {
    profile.as_ref().map(|(_, h)| h.clone()).unwrap_or_default()
}

// Evolution Simulation: the New world form (ADR-0026 D1-D5). The page sends every field as the text the user typed;
// the server checks the text with the core rules and returns errors by field. Invalid input never starts a world.
(() => {
  // Field keys, labels and groups. The keys and the groups match FIELDS in crates/evosim-ui/src/setup.rs.
  const FIELDS = [
    ["seed", "Seed", "World"],
    ["world.width", "Width (cells)", "World"],
    ["world.height", "Height (cells)", "World"],
    ["initial.plants", "Plants at start", "Start"],
    ["initial.herbivores", "Herbivores at start", "Start"],
    ["initial.carnivores", "Carnivores at start", "Start"],
    ["climate.season_length", "Season length (ticks)", "Climate"],
    ["climate.weather_amplitude", "Weather swing", "Climate"],
    ["plants.reproduction_chance", "Seeding chance per tick", "Plants"],
    ["plants.seed_radius", "Seed radius (cells)", "Plants"],
    ["plants.max_age", "Plant max age (ticks)", "Plants"],
    ["herbivores.reproduction_energy", "Herbivore breeding energy", "Herbivores"],
    ["herbivores.max_age", "Herbivore max age (ticks)", "Herbivores"],
    ["carnivores.reproduction_energy", "Carnivore breeding energy", "Carnivores"],
    ["carnivores.max_age", "Carnivore max age (ticks)", "Carnivores"],
    ["genetics.mutation_rate", "Mutation rate per locus", "Genetics"],
    ["genetics.mutation_strength", "Mutation strength", "Genetics"],
    ["species.distance", "Species distance", "Species"],
  ];

  const fieldsEl = document.getElementById("fields");
  const presetsEl = document.getElementById("presets");
  const statusEl = document.getElementById("setup-status");
  const fileInput = document.getElementById("file-import");
  // Text of the configuration whose parameters the form does not show (a preset or an imported file).
  let base = null;

  function el(tag, attrs = {}, text = null) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    if (text !== null) node.textContent = text;
    return node;
  }

  function inputOf(key) {
    return document.getElementById(`field-${key}`);
  }

  function buildFields() {
    let group = null;
    let fieldset = null;
    for (const [key, label, groupName] of FIELDS) {
      if (groupName !== group) {
        group = groupName;
        fieldset = el("fieldset", { class: "group" });
        fieldset.append(el("legend", {}, groupName));
        fieldsEl.append(fieldset);
      }
      const wrap = el("div", { class: "field" });
      const input = el("input", {
        type: "text",
        id: `field-${key}`,
        name: key,
        autocomplete: "off",
        spellcheck: "false",
        "aria-describedby": `err-${key}`,
      });
      const labelEl = el("label", { for: `field-${key}` }, label);
      const error = el("span", { class: "field-error", id: `err-${key}` });
      input.addEventListener("input", () => clearError(key));
      wrap.append(labelEl, input, error);
      fieldset.append(wrap);
    }
  }

  function values() {
    const out = {};
    for (const [key] of FIELDS) out[key] = inputOf(key).value;
    return out;
  }

  function setFields(fields) {
    for (const [key] of FIELDS) {
      if (typeof fields[key] === "string") inputOf(key).value = fields[key];
    }
  }

  function clearError(key) {
    const input = inputOf(key);
    const error = document.getElementById(`err-${key}`);
    if (error) error.textContent = "";
    if (input) {
      input.classList.remove("invalid");
      input.removeAttribute("aria-invalid");
    }
  }

  function clearErrors() {
    for (const [key] of FIELDS) clearError(key);
  }

  // Shows each error next to its field; errors without a known field go to the status line.
  function showErrors(errors) {
    clearErrors();
    const other = [];
    for (const e of errors) {
      const input = e.key ? inputOf(e.key) : null;
      if (input) {
        document.getElementById(`err-${e.key}`).textContent = e.message;
        input.classList.add("invalid");
        input.setAttribute("aria-invalid", "true");
      } else {
        other.push(e.key ? `${e.key}: ${e.message}` : e.message);
      }
    }
    return other;
  }

  function setStatus(message, kind = "") {
    statusEl.textContent = message;
    statusEl.className = `status ${kind}`.trim();
  }

  function requestBody() {
    const body = values();
    if (base !== null) body.base = base;
    return JSON.stringify(body);
  }

  // POST to a configuration route. Returns { status, body } where body is parsed JSON when the response is JSON.
  async function post(url, text) {
    const res = await fetch(url, { method: "POST", body: text, cache: "no-store" });
    const raw = await res.text();
    let body = raw;
    try {
      body = JSON.parse(raw);
    } catch (_) {
      // Plain text answers (400 for a malformed body) stay as text.
    }
    return { status: res.status, body };
  }

  function reportFailure(answer, prefix) {
    if (answer.body && Array.isArray(answer.body.errors)) {
      const rest = showErrors(answer.body.errors);
      const first = answer.body.errors.length;
      setStatus(`${prefix}: ${first} problem${first === 1 ? "" : "s"} marked in the form.${rest.length ? " " + rest.join(" ") : ""}`, "error");
    } else if (answer.body && answer.body.error) {
      setStatus(`${prefix}: ${answer.body.error}`, "error");
    } else {
      setStatus(`${prefix}: ${typeof answer.body === "string" ? answer.body : "the server did not answer"}`, "error");
    }
  }

  async function startWorld() {
    clearErrors();
    setStatus("Starting the world…");
    const answer = await post("/api/world", requestBody());
    if (answer.status === 200) {
      const seed = values().seed;
      setStatus(`New world started: seed ${seed}, tick 0, paused. Press run to watch it.`, "ok");
    } else {
      reportFailure(answer, "The world was not started");
    }
  }

  async function exportConfig() {
    clearErrors();
    const answer = await post("/api/config/check", requestBody());
    if (answer.status !== 200) {
      reportFailure(answer, "Export failed");
      return;
    }
    const blob = new Blob([answer.body.config + "\n"], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = el("a", { href: url, download: "evosim-config.json" });
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setStatus("Configuration exported as evosim-config.json.", "ok");
  }

  async function importConfig(file) {
    const text = await file.text();
    const answer = await post("/api/config/import", text);
    if (answer.status !== 200) {
      reportFailure(answer, "Import failed; the form is unchanged");
      return;
    }
    clearErrors();
    setFields(answer.body.fields);
    base = text;
    setStatus(`Imported ${file.name}. Check the values, then start the world.`, "ok");
  }

  async function loadPresets() {
    const res = await fetch("/api/presets", { cache: "no-store" });
    if (!res.ok) {
      presetsEl.textContent = "Presets are not available.";
      return;
    }
    const presets = await res.json();
    for (const preset of presets) {
      const card = el("button", { type: "button", class: "preset", "aria-pressed": "false", "data-preset": preset.name });
      card.append(el("strong", {}, preset.name), el("span", { class: "preset-text" }, preset.description));
      card.addEventListener("click", () => {
        for (const other of presetsEl.querySelectorAll(".preset")) other.setAttribute("aria-pressed", "false");
        card.setAttribute("aria-pressed", "true");
        clearErrors();
        setFields(preset.fields);
        base = preset.config;
        setStatus(`Preset ${preset.name} loaded. Edit any field, then start the world.`, "ok");
      });
      presetsEl.append(card);
    }
  }

  buildFields();
  document.getElementById("btn-start").addEventListener("click", () => startWorld().catch((e) => setStatus(String(e), "error")));
  document.getElementById("btn-export").addEventListener("click", () => exportConfig().catch((e) => setStatus(String(e), "error")));
  fileInput.addEventListener("change", () => {
    const file = fileInput.files && fileInput.files[0];
    fileInput.value = "";
    if (file) importConfig(file).catch((e) => setStatus(String(e), "error"));
  });
  loadPresets().catch(() => {
    presetsEl.textContent = "Presets are not available.";
  });
})();

// Evolution Simulation: world view (ADR-0024 D5). Biome base from /api/climate, organisms from /api/state.
(() => {
  // Biome colours (base layer). Keep in step with the legend swatches in index.html.
  const BIOME_RGB = {
    P: [220, 233, 242], // polar
    U: [183, 201, 180], // tundra
    T: [140, 191, 118], // temperate
    D: [226, 191, 122], // dry
    R: [201, 160, 214], // tropical
  };
  const BACKGROUND = "#15191c";
  const POLL_MS = 200; // 5 updates per second (ADR-0024 D5)
  const MIN_SCALE = 2; // pixels per cell
  const MAX_SCALE = 64;

  const params = new URLSearchParams(window.location.search);
  const smokeMode = params.has("smoke");
  const shotMode = params.has("shot");
  // view=charts: the charts take the main area (the second screenshot, ADR-0026 D9).
  if (params.get("view") === "charts") document.body.classList.add("view-charts");
  const checkMode = params.has("check");
  // Renderer-only fixture (ADR-0024 D14a): 1,000 synthetic organisms on the real climate grid, no simulation state.
  const fixtureMode = params.get("fixture") === "1000";

  const canvas = document.getElementById("world");
  const ctx = canvas.getContext("2d");
  const el = {
    tick: document.getElementById("tick"),
    plants: document.getElementById("n-plants"),
    herbivores: document.getElementById("n-herbivores"),
    carnivores: document.getElementById("n-carnivores"),
  };

  let climate = null; // { width, height, layer: offscreen canvas with one pixel per cell }
  let organisms = []; // [id, kind, x, y] rows, ascending id
  let tick = null;
  let frames = 0; // frames drawn from a state response
  let stateUpdates = 0; // successful /api/state responses (state updates received by the page)
  let polling = true;
  let cssW = 0;
  let cssH = 0;
  let dpr = 1;
  let dirty = true;
  const view = { scale: 8, ox: 0, oy: 0, fit: true };
  let drag = null;
  let climateVersion = null; // control.climate_version of the loaded base layer
  let control = null; // latest control block of /api/state (ADR-0025 D3)
  let selectedId = null; // organism under the inspector, or null
  const ui = {}; // control and inspector elements, built once by buildPanels()
  const CLICK_PX = 4; // a pointer that moves less than this is a click (ADR-0025 D5)
  const PICK_PX = 6; // a click selects the nearest organism within this distance of its drawn position

  function fitView() {
    if (!climate) return;
    const s = Math.min(cssW / climate.width, cssH / climate.height);
    view.scale = s;
    view.ox = (cssW - climate.width * s) / 2;
    view.oy = (cssH - climate.height * s) / 2;
  }

  function resize() {
    const rect = canvas.getBoundingClientRect();
    dpr = window.devicePixelRatio || 1;
    cssW = rect.width;
    cssH = rect.height;
    canvas.width = Math.max(1, Math.round(cssW * dpr));
    canvas.height = Math.max(1, Math.round(cssH * dpr));
    if (view.fit) fitView();
    dirty = true;
  }

  // Synthetic organisms for the fixture: a fixed LCG places 700 plants, 250 herbivores and 50 carnivores (display only).
  function makeFixture() {
    let seed = 12345;
    const rnd = (n) => {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      return seed % n;
    };
    const rows = [];
    for (let i = 0; i < 1000; i++) {
      const kind = i < 700 ? 0 : i < 950 ? 1 : 2;
      rows.push([i + 1, kind, rnd(climate.width), rnd(climate.height)]);
    }
    organisms = rows;
    tick = 0;
    document.title = "Evolution Simulation (synthetic fixture, 1000 organisms)";
    el.tick.textContent = "synthetic fixture";
    el.plants.textContent = "plants 700";
    el.herbivores.textContent = "herbivores 250";
    el.carnivores.textContent = "carnivores 50";
  }

  async function loadClimate(version) {
    const res = await fetch("/api/climate", { cache: "no-store" });
    const data = await res.json();
    const layer = document.createElement("canvas");
    layer.width = data.width;
    layer.height = data.height;
    const lctx = layer.getContext("2d");
    const image = lctx.createImageData(data.width, data.height);
    for (let i = 0; i < data.biome.length; i++) {
      const [r, g, b] = BIOME_RGB[data.biome[i]] || [0, 0, 0];
      image.data[i * 4] = r;
      image.data[i * 4 + 1] = g;
      image.data[i * 4 + 2] = b;
      image.data[i * 4 + 3] = 255;
    }
    lctx.putImageData(image, 0, 0);
    const resized = !climate || climate.width !== data.width || climate.height !== data.height;
    climate = { width: data.width, height: data.height, layer };
    climateVersion = version;
    // A reset keeps the view; a loaded checkpoint of another size refits it.
    if (resized || view.fit) fitView();
    if (fixtureMode) makeFixture();
    dirty = true;
  }

  // Deterministic position of an organism inside its cell, from its id (display only).
  function offsetInCell(id) {
    const a = (id * 0.6180339887498949) % 1;
    const b = (id * 0.3247179572447460) % 1;
    return [0.2 + 0.6 * a, 0.2 + 0.6 * b];
  }

  // Highlight of the selected organism (ADR-0025 D5).
  function drawRing(px, py, s) {
    ctx.beginPath();
    ctx.arc(px, py, Math.max(6, s * 0.75), 0, Math.PI * 2);
    ctx.strokeStyle = "#7dd3fc";
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  function drawOrganisms(s, ox, oy) {
    const pad = 8;
    for (const [id, kind, x, y] of organisms) {
      const [fx, fy] = offsetInCell(id);
      const px = ox + (x + fx) * s;
      const py = oy + (y + fy) * s;
      if (px < -pad || py < -pad || px > cssW + pad || py > cssH + pad) continue;
      if (id === selectedId) drawRing(px, py, s);
      if (kind === 0) {
        // plant: dark green square with a white rim
        const side = Math.max(2, s * 0.42);
        ctx.fillStyle = "#1b7a2b";
        ctx.fillRect(px - side / 2, py - side / 2, side, side);
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.strokeRect(px - side / 2, py - side / 2, side, side);
      } else if (kind === 1) {
        // herbivore: amber circle with a dark rim
        const r = Math.max(2, s * 0.3);
        ctx.beginPath();
        ctx.arc(px, py, r, 0, Math.PI * 2);
        ctx.fillStyle = "#ffb020";
        ctx.fill();
        ctx.strokeStyle = "#3b2a00";
        ctx.lineWidth = 1;
        ctx.stroke();
      } else {
        // carnivore: red upward triangle with a white rim
        const r = Math.max(2.5, s * 0.36);
        ctx.beginPath();
        ctx.moveTo(px, py - r);
        ctx.lineTo(px + r, py + r * 0.8);
        ctx.lineTo(px - r, py + r * 0.8);
        ctx.closePath();
        ctx.fillStyle = "#e03131";
        ctx.fill();
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
  }

  function draw() {
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = BACKGROUND;
    ctx.fillRect(0, 0, cssW, cssH);
    if (!climate) return;
    const { scale: s, ox, oy } = view;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(climate.layer, ox, oy, climate.width * s, climate.height * s);
    if (s >= 6) {
      ctx.strokeStyle = "rgba(0, 0, 0, 0.12)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let x = 0; x <= climate.width; x++) {
        const px = Math.round(ox + x * s) + 0.5;
        ctx.moveTo(px, oy);
        ctx.lineTo(px, oy + climate.height * s);
      }
      for (let y = 0; y <= climate.height; y++) {
        const py = Math.round(oy + y * s) + 0.5;
        ctx.moveTo(ox, py);
        ctx.lineTo(ox + climate.width * s, py);
      }
      ctx.stroke();
    }
    drawOrganisms(s, ox, oy);
    dirty = false;
  }

  // Draws the current state, then applies the smoke and screenshot rules (ADR-0024 D7, D8).
  function render() {
    draw();
    frames += 1;
    if (smokeMode && tick !== null && tick >= 10 && frames >= 1) {
      document.title = `smoke frames=${frames} tick=${tick}`;
      polling = false;
    }
    if (shotMode && frames >= 2) {
      polling = false;
    }
  }

  function updateHeader(state) {
    el.tick.textContent = `tick ${state.tick}`;
    el.plants.textContent = `plants ${state.counts.plants}`;
    el.herbivores.textContent = `herbivores ${state.counts.herbivores}`;
    el.carnivores.textContent = `carnivores ${state.counts.carnivores}`;
  }

  async function poll() {
    if (!polling) return;
    try {
      // The base layer is retried until it loads (ADR-0024 D3); the organisms poll runs regardless.
      if (!climate || (control && control.climate_version !== climateVersion)) {
        await loadClimate(control ? control.climate_version : 0);
      }
      // The fixture has no simulation: it never polls the state (ADR-0024 D14a).
      const res = fixtureMode ? null : await fetch("/api/state", { cache: "no-store" });
      if (res && res.ok) {
        const state = await res.json();
        stateUpdates += 1;
        tick = state.tick;
        organisms = state.organisms;
        updateHeader(state);
        control = state.control;
        selectedId = control.selected;
        updateControls();
        if (climate) render();
        await refreshInspector();
        if (checkMode && !checkDone && climate && tick >= 1) runChecks();
      }
    } catch (err) {
      // The server is gone or busy, or the climate is not loaded yet: keep the last frame and try again.
    }
    if (polling) setTimeout(poll, POLL_MS);
  }

  // ---- Run controls and inspector (ADR-0025 D5) ----
  function make(tag, attrs, ...kids) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs || {})) {
      if (key === "text") node.textContent = value;
      else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
      else node.setAttribute(key, value);
    }
    node.append(...kids);
    return node;
  }
  const fmt = (n) => Number(n).toFixed(2);

  function setStatus(line, isError) {
    if (!ui.status) return;
    ui.status.textContent = line;
    ui.status.className = isError ? "status error" : "status";
  }

  // Reads a reply of /api/command or /api/checkpoint; a non-JSON answer (HTTP error text) becomes an error.
  async function readReply(res) {
    try {
      return JSON.parse(await res.text());
    } catch (err) {
      return { ok: false, error: "unexpected answer from the server" };
    }
  }

  async function command(action, extra) {
    try {
      const body = new URLSearchParams(Object.assign({ action }, extra || {}));
      const res = await fetch("/api/command", { method: "POST", body, cache: "no-store" });
      const data = await readReply(res);
      if (!data.ok) setStatus(data.error, true);
      else if (ui.status && ui.status.classList.contains("error")) setStatus("", false);
      return data.ok;
    } catch (err) {
      setStatus("the server did not answer", true);
      return false;
    }
  }

  function buildPanels() {
    ui.run = make("button", { type: "button", id: "btn-run", onclick: () => command(control && control.running ? "pause" : "run") });
    ui.step = make("button", { type: "button", id: "btn-step", text: "Step", onclick: () => command("step") });
    ui.reset = make("button", { type: "button", id: "btn-reset", text: "Reset", onclick: () => command("reset") });
    ui.slower = make("button", { type: "button", id: "btn-slower", text: "Slower", onclick: () => command("slower") });
    ui.faster = make("button", { type: "button", id: "btn-faster", text: "Faster", onclick: () => command("faster") });
    ui.speed = make("span", { class: "speed", id: "speed-label", text: "" });
    ui.save = make("a", { href: "/api/checkpoint", download: "", id: "btn-save", text: "Save checkpoint" });
    ui.file = make("input", { type: "file", accept: ".evockpt", id: "file-load", "aria-label": "checkpoint file to load" });
    ui.file.addEventListener("change", async () => {
      const file = ui.file.files[0];
      if (!file) return;
      try {
        const res = await fetch("/api/checkpoint", { method: "POST", body: file, cache: "no-store" });
        const data = await readReply(res);
        setStatus(data.ok ? `loaded ${file.name}` : data.error, !data.ok);
      } catch (err) {
        setStatus("the server did not answer", true);
      }
      ui.file.value = "";
    });
    ui.status = make("p", { class: "status", id: "ctl-status", "aria-live": "polite", text: "" });
    const controls = document.getElementById("controls");
    controls.append(
      make("div", { class: "row" }, ui.run, ui.step, ui.reset),
      make("div", { class: "row" }, ui.slower, ui.speed, ui.faster),
      make("div", { class: "row" }, ui.save),
      make("label", { class: "row file" }, make("span", { text: "Load checkpoint" }), ui.file),
      ui.status,
      make("p", { class: "keys", text: "Space run/pause · . or n step · r reset · - + speed · Esc clear" })
    );
    ui.inspectorBody = make("div", { id: "inspector-body" });
    document.getElementById("inspector").append(ui.inspectorBody);
    renderInspector(null);
  }

  function updateControls() {
    if (!control || !ui.run) return;
    ui.run.textContent = control.running ? "Pause" : "Run";
    ui.run.setAttribute("aria-pressed", String(control.running));
    ui.step.disabled = control.running;
    ui.slower.disabled = control.speed_index <= 0;
    ui.faster.disabled = control.speed_index >= control.speeds.length - 1;
    ui.speed.textContent = `${control.speed} ticks/s`;
  }

  // Keyboard shortcuts; ignored while a text field has focus (ADR-0025 D5).
  window.addEventListener("keydown", (e) => {
    if (e.target && /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
    if (e.ctrlKey || e.metaKey || e.altKey || !control) return;
    const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    if (key === " ") {
      e.preventDefault();
      command(control.running ? "pause" : "run");
    } else if (key === "." || key === "n") {
      if (!control.running) command("step");
    } else if (key === "r") {
      command("reset");
    } else if (key === "-") {
      command("slower");
    } else if (key === "+" || key === "=") {
      command("faster");
    } else if (key === "Escape") {
      command("deselect");
    }
  });

  // A click selects the nearest living organism within PICK_PX; a click on empty ground clears the selection.
  function selectAt(cx, cy) {
    if (!climate) return;
    const rect = canvas.getBoundingClientRect();
    const mx = cx - rect.left;
    const my = cy - rect.top;
    const s = view.scale;
    let best = null;
    let bestDistance = PICK_PX;
    for (const [id, , x, y] of organisms) {
      const [fx, fy] = offsetInCell(id);
      const d = Math.hypot(view.ox + (x + fx) * s - mx, view.oy + (y + fy) * s - my);
      if (d <= bestDistance) {
        best = id;
        bestDistance = d;
      }
    }
    if (best === null) command("deselect");
    else command("select", { id: best });
  }

  async function refreshInspector() {
    if (selectedId === null) {
      renderInspector(null);
      return;
    }
    const res = await fetch(`/api/organism?id=${selectedId}`, { cache: "no-store" });
    if (!res.ok) {
      renderInspector(null, "The selected organism is no longer selected.");
      return;
    }
    renderInspector(await res.json());
  }

  function bar(label, value, max) {
    const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
    return make(
      "div",
      { class: "bar" },
      make("span", { class: "bar-label", text: label }),
      make("span", { class: "bar-track" }, make("span", { class: "bar-fill", style: `width:${pct.toFixed(1)}%` })),
      make("span", { class: "bar-value", text: fmt(value) })
    );
  }

  function kv(pairs) {
    return make("dl", { class: "kv" }, ...pairs.flatMap(([k, v]) => [make("dt", { text: k }), make("dd", { text: String(v) })]));
  }

  // Inspector: id, kind, species, status (alive or the death), age, energy, health, traits, genome slots, haplotypes,
  // parents as buttons (ADR-0025 D4, D5). `w` is the /api/organism body, or null for no selection.
  function renderInspector(w, note) {
    const box = ui.inspectorBody;
    if (!box) return;
    box.replaceChildren();
    if (!w) {
      box.append(make("p", { class: "muted", text: note || "Click an organism in the world view to inspect it." }));
      return;
    }
    const o = w.organism;
    const dead = w.status === "dead";
    const species = o.species ? o.species.name : "not yet recognised";
    box.append(
      make("h3", { text: `${o.kind.name} #${o.id}` }),
      make("p", { class: "muted", text: `species ${species}` }),
      make("p", {
        class: dead ? "status error" : "status ok",
        text: dead
          ? `died at tick ${w.death.tick}: ${w.death.cause}, cell (${w.death.cell[0]}, ${w.death.cell[1]})`
          : "alive",
      }),
    );
    if (dead) box.append(make("p", { class: "muted", text: "Values below are from its last tick alive." }));
    box.append(
      kv([
        ["age", o.age],
        ["energy", fmt(o.energy)],
        ["health", fmt(o.health)],
        ["cell", `${o.cell[0]}, ${o.cell[1]}`],
        ["generation", o.generation],
      ]),
      bar("health", o.health, o.traits.max_health)
    );
    const traitPairs = [
      ["speed", fmt(o.traits.speed)],
      ["strength", fmt(o.traits.strength)],
      ["fertility", fmt(o.traits.fertility)],
      ["max lifespan", o.traits.max_lifespan],
      ["max health", fmt(o.traits.max_health)],
    ];
    if (o.kind.name !== "plant") {
      traitPairs.push(["aggression", fmt(o.traits.aggression)], ["caution", fmt(o.traits.caution)], ["vision", o.traits.vision]);
    }
    box.append(make("h3", { text: "Traits" }), kv(traitPairs));
    box.append(make("h3", { text: "Genome" }));
    o.genome.slot_means.forEach((mean, n) => box.append(bar(o.genome.slot_names[n], mean, 1)));
    o.genome.haplotypes.forEach((hex, n) => box.append(make("p", { class: "hex-line" }, make("span", { class: "muted", text: `haplotype ${n + 1} ` }), make("code", { class: "hex", text: hex }))));
    const parents = o.parents.map((pid) =>
      pid === null ? make("span", { class: "muted", text: "founder" }) : make("button", { type: "button", class: "parent", text: `#${pid}`, onclick: () => command("select", { id: pid }) })
    );
    box.append(make("h3", { text: "Parents" }), make("div", { class: "row" }, ...parents));
    box.append(make("div", { class: "row" }, make("button", { type: "button", id: "btn-clear", text: "Clear selection", onclick: () => command("deselect") })));
  }

  // Pan (drag), zoom (wheel around the cursor), reset (double-click).
  canvas.addEventListener("pointerdown", (e) => {
    drag = { x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY };
    try {
      canvas.setPointerCapture(e.pointerId);
    } catch (err) {
      // Synthetic events (check mode) have no active pointer to capture; dragging still works without it.
    }
    canvas.classList.add("dragging");
  });
  canvas.addEventListener("pointermove", (e) => {
    if (!drag) return;
    view.ox += e.clientX - drag.x;
    view.oy += e.clientY - drag.y;
    drag.x = e.clientX;
    drag.y = e.clientY;
    view.fit = false;
    dirty = true;
  });
  const endDrag = () => {
    drag = null;
    canvas.classList.remove("dragging");
  };
  canvas.addEventListener("pointerup", (e) => {
    const click = drag && Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) < CLICK_PX;
    endDrag();
    if (click) selectAt(e.clientX, e.clientY);
  });
  canvas.addEventListener("pointercancel", endDrag);
  canvas.addEventListener(
    "wheel",
    (e) => {
      e.preventDefault();
      if (!climate) return;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      const next = Math.min(MAX_SCALE, Math.max(MIN_SCALE, view.scale * Math.exp(-e.deltaY * 0.0015)));
      const k = next / view.scale;
      view.ox = mx - (mx - view.ox) * k;
      view.oy = my - (my - view.oy) * k;
      view.scale = next;
      view.fit = false;
      dirty = true;
    },
    { passive: false }
  );
  canvas.addEventListener("dblclick", () => {
    view.fit = true;
    fitView();
    dirty = true;
  });
  window.addEventListener("resize", resize);

  function frame() {
    if (dirty || fixtureMode) draw();
    window.requestAnimationFrame(frame);
  }

  // Check mode (`?check=1`, ADR-0024 D11): dispatches synthetic pointer, wheel and double-click events on the canvas
  // and compares the view with the expected result. The verdict is written to the title as `check=PASS|FAIL ...`.
  let checkDone = false;
  function fire(type, x, y, extra) {
    const rect = canvas.getBoundingClientRect();
    const init = Object.assign({ clientX: rect.left + x, clientY: rect.top + y, bubbles: true, cancelable: true }, extra || {});
    const ev = type === "wheel" ? new WheelEvent("wheel", init) : type.startsWith("pointer") ? new PointerEvent(type, Object.assign({ pointerId: 1, isPrimary: true }, init)) : new MouseEvent(type, init);
    canvas.dispatchEvent(ev);
  }
  function runChecks() {
    checkDone = true;
    const results = [];
    const check = (name, ok, detail) => results.push(`${name}:${ok ? "ok" : "FAIL"}${detail ? "(" + detail + ")" : ""}`);
    const near = (a, b, tol) => Math.abs(a - b) <= tol;
    // 1. drag pans by exactly the pointer delta and leaves fit mode
    const v0 = { ox: view.ox, oy: view.oy };
    fire("pointerdown", 300, 200);
    for (let i = 1; i <= 5; i++) fire("pointermove", 300 + (100 * i) / 5, 200 + (50 * i) / 5);
    fire("pointerup", 400, 250);
    const dOx = view.ox - v0.ox, dOy = view.oy - v0.oy;
    check("drag", near(dOx, 100, 0.01) && near(dOy, 50, 0.01) && !view.fit, `dx=${dOx.toFixed(2)} dy=${dOy.toFixed(2)} fit=${view.fit}`);
    // 2. wheel zoom keeps the world point under the cursor fixed
    const P = { x: 300, y: 200 };
    const before = { x: (P.x - view.ox) / view.scale, y: (P.y - view.oy) / view.scale };
    const s0 = view.scale;
    fire("wheel", P.x, P.y, { deltaY: -300 });
    const px = view.ox + before.x * view.scale, py = view.oy + before.y * view.scale;
    check("zoom-anchor", view.scale > s0 && near(px, P.x, 0.5) && near(py, P.y, 0.5), `scale ${s0.toFixed(2)}->${view.scale.toFixed(2)} at=${px.toFixed(2)},${py.toFixed(2)}`);
    // 3. zoom is clamped to [2, 64] pixels per cell
    for (let i = 0; i < 40; i++) fire("wheel", P.x, P.y, { deltaY: -300 });
    const maxOk = view.scale === MAX_SCALE;
    for (let i = 0; i < 40; i++) fire("wheel", P.x, P.y, { deltaY: 300 });
    const minOk = view.scale === MIN_SCALE;
    check("zoom-clamp", maxOk && minOk, `max=${maxOk} min=${minOk}`);
    // 4. double-click fits the whole world again
    fire("dblclick", cssW / 2, cssH / 2, { detail: 2 });
    const fit = Math.min(cssW / climate.width, cssH / climate.height);
    check("dblclick-fit", view.fit && near(view.scale, fit, 1e-9), `scale=${view.scale.toFixed(3)} expected=${fit.toFixed(3)}`);
    const failed = results.filter((r) => r.includes(":FAIL")).length;
    document.title = `check=${failed ? "FAIL" : "PASS"} ${results.join(" ")}`;
    polling = false;
  }

  // Read-only hook for the browser checks (ADR-0024 D10). It exposes state; it does not change it.
  window.evosim = {
    view: () => ({ scale: view.scale, ox: view.ox, oy: view.oy, fit: view.fit, cssW, cssH, worldW: climate ? climate.width : 0, worldH: climate ? climate.height : 0 }),
    stats: () => ({ tick, living: organisms.length, frames, updates: stateUpdates }),
    // Fixture only (ADR-0024 D14a): redraws the current frame n times and returns the mean and max redraw time in ms.
    timing: (n) => {
      let sum = 0;
      let max = 0;
      for (let i = 0; i < n; i++) {
        const t0 = performance.now();
        draw();
        const dt = performance.now() - t0;
        sum += dt;
        if (dt > max) max = dt;
      }
      return { n, meanMs: sum / n, maxMs: max, organisms: organisms.length };
    },
  };

  buildPanels();
  resize();
  poll();
  window.requestAnimationFrame(frame);
})();

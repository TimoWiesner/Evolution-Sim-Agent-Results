// Evolution Simulation: charts (ADR-0026 D6-D9). Own canvas drawing, no library. Data from /api/series (incremental,
// by tick) and /api/distribution (histogram of the living population). A reset or a new world clears the charts.
(() => {
  const KINDS = ["plant", "herbivore", "carnivore"];
  const COLORS = { plant: "#2f9e44", herbivore: "#ffb020", carnivore: "#e03131" };
  const LABELS = { plant: "Plants", herbivore: "Herbivores", carnivore: "Carnivores" };
  // Trait names per kind, as core::analytics::trait_names lists them (ADR-0021).
  const TRAITS = {
    plant: ["speed", "strength", "fertility", "max_lifespan", "max_health", "cold_tolerance", "drought_tolerance", "yield"],
    herbivore: ["speed", "strength", "fertility", "max_lifespan", "max_health", "aggression", "caution", "vision"],
    carnivore: ["speed", "strength", "fertility", "max_lifespan", "max_health", "aggression", "caution", "vision"],
  };
  const ALL_TRAITS = [...new Set([...TRAITS.plant, ...TRAITS.herbivore])];
  const POLL_MS = 1000;
  const HIST_MS = 2000;
  const BINS = 20;

  const root = document.getElementById("charts");
  const data = { ticks: [], population: {}, births: {}, deaths: {}, species: {}, mean: {} };
  let lastTick = null;
  let climateVersion = null;
  let trait = "speed";
  let histKind = "herbivore";
  let histogram = null; // latest /api/distribution body
  let stopped = false; // set by the page when the charts are no longer needed
  const panels = {};

  function resetData() {
    data.ticks = [];
    for (const k of KINDS) {
      data.population[k] = [];
      data.births[k] = [];
      data.deaths[k] = [];
      data.species[k] = [];
      data.mean[k] = [];
    }
    lastTick = null;
    histogram = null;
    redrawAll();
  }

  function el(tag, attrs = {}, text = null) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    if (text !== null) node.textContent = text;
    return node;
  }

  function buildSelectors() {
    const bar = el("div", { class: "chart-bar" });
    const traitLabel = el("label", {}, "Trait ");
    const traitSelect = el("select", { id: "trait-select", "aria-label": "Trait for the mean and the distribution" });
    for (const t of ALL_TRAITS) traitSelect.append(el("option", { value: t }, t));
    traitSelect.value = trait;
    traitSelect.addEventListener("change", () => {
      trait = traitSelect.value;
      for (const k of KINDS) data.mean[k] = [];
      lastTick = null;
      data.ticks = [];
      for (const k of KINDS) {
        data.population[k] = [];
        data.births[k] = [];
        data.deaths[k] = [];
        data.species[k] = [];
      }
      histogram = null;
        redrawAll();
      poll();
    });
    traitLabel.append(traitSelect);
    const kindLabel = el("label", {}, "Distribution of ");
    const kindSelect = el("select", { id: "kind-select", "aria-label": "Kind for the distribution" });
    for (const k of KINDS) kindSelect.append(el("option", { value: k }, LABELS[k]));
    kindSelect.value = histKind;
    kindSelect.addEventListener("change", () => {
      histKind = kindSelect.value;
      histogram = null;
        drawHistogram();
      pollHistogram();
    });
    kindLabel.append(kindSelect);
    bar.append(traitLabel, kindLabel);
    return bar;
  }

  function buildPanel(id, title, legend) {
    const figure = el("figure", { class: "chart", id: `chart-${id}` });
    figure.append(el("figcaption", {}, title));
    const canvas = el("canvas", { "aria-label": title, role: "img" });
    figure.append(canvas);
    const list = el("ul", { class: "legend" });
    for (const [label, color, dashed] of legend) {
      const item = el("li");
      const swatch = el("i", { class: dashed ? "dashed" : "" });
      swatch.style.borderColor = color;
      if (!dashed) swatch.style.background = color;
      item.append(swatch, document.createTextNode(label));
      list.append(item);
    }
    figure.append(list);
    root.append(figure);
    panels[id] = { canvas, figure, title, legend };
  }

  function build() {
    root.textContent = "";
    root.append(buildSelectors());
    const grid = el("div", { class: "chart-grid" });
    root.append(grid);
    const lineLegend = KINDS.map((k) => [LABELS[k], COLORS[k], false]);
    const eventLegend = KINDS.flatMap((k) => [
      [`${LABELS[k]} births`, COLORS[k], false],
      [`${LABELS[k]} deaths`, COLORS[k], true],
    ]);
    const gridFigures = [
      ["population", "Population over time", lineLegend],
      ["events", "Births and deaths per tick", eventLegend],
      ["species", "Species alive", lineLegend],
      ["mean", "Mean of the selected trait", lineLegend],
      ["histogram", "Distribution of the selected trait", [["Living organisms", "#7dd3fc", false]]],
    ];
    for (const [id, title, legend] of gridFigures) buildPanel(id, title, legend);
    for (const id of Object.keys(panels)) grid.append(panels[id].figure);
    if (window.evosim) window.evosim.charts = describe;
  }

  // Read-only description of the charts for tests and the page's checks (ADR-0024 D13 style).
  function describe() {
    return {
      points: data.ticks.length,
      lastTick,
      trait,
      histogramKind: histKind,
      histogramN: histogram ? histogram.n : null,
      panels: Object.entries(panels).map(([id, p]) => ({
        id,
        title: p.title,
        legend: p.legend.map((l) => l[0]),
        width: p.canvas.clientWidth,
        height: p.canvas.clientHeight,
      })),
    };
  }

  // ---- drawing -----------------------------------------------------------------------------------------------

  function fitCanvas(canvas) {
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, canvas.clientWidth);
    const h = Math.max(1, canvas.clientHeight);
    if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
    }
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    return { ctx, w, h };
  }

  function niceMax(v) {
    if (!(v > 0)) return 1;
    const p = Math.pow(10, Math.floor(Math.log10(v)));
    const f = v / p;
    const nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
    return nice * p;
  }

  // Frame with axis labels, ticks and the plotted area. Returns the mapping helpers.
  function frame(ctx, w, h, { xLabel, yLabel, xMin, xMax, yMax }) {
    const left = 58, right = 12, top = 10, bottom = 40;
    const pw = w - left - right, ph = h - top - bottom;
    ctx.strokeStyle = "#2c343a";
    ctx.fillStyle = "#9aa8b2";
    ctx.font = "11px system-ui, sans-serif";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const v = (yMax * i) / 4;
      const y = top + ph - (ph * i) / 4;
      ctx.beginPath();
      ctx.moveTo(left, y);
      ctx.lineTo(left + pw, y);
      ctx.stroke();
      ctx.textAlign = "right";
      ctx.textBaseline = "middle";
      ctx.fillText(formatNumber(v), left - 6, y);
    }
    ctx.strokeRect(left, top, pw, ph);
    for (let i = 0; i <= 4; i++) {
      const v = xMin + ((xMax - xMin) * i) / 4;
      const x = left + (pw * i) / 4;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";
      ctx.fillText(formatNumber(v), x, top + ph + 4);
    }
    ctx.fillStyle = "#e8eef2";
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    ctx.fillText(xLabel, left + pw / 2, h - 3);
    ctx.save();
    ctx.translate(12, top + ph / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textBaseline = "middle";
    ctx.fillText(yLabel, 0, 0);
    ctx.restore();
    return {
      x: (v) => left + ((v - xMin) / Math.max(1e-9, xMax - xMin)) * pw,
      y: (v) => top + ph - (v / yMax) * ph,
      left, top, pw, ph,
    };
  }

  function formatNumber(v) {
    if (!Number.isFinite(v)) return "";
    if (Math.abs(v) >= 1000) return Math.round(v).toString();
    if (Number.isInteger(v)) return v.toString();
    return Number(v.toPrecision(3)).toString();
  }

  // One line chart: series = [{ values, color, dashed }]; values may hold null (gaps).
  function drawLines(id, { xLabel, yLabel, series }) {
    const panel = panels[id];
    if (!panel) return;
    const { ctx, w, h } = fitCanvas(panel.canvas);
    const ticks = data.ticks;
    if (ticks.length === 0) {
      ctx.fillStyle = "#9aa8b2";
      ctx.font = "13px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("waiting for data", w / 2, h / 2);
      return;
    }
    let yMax = 0;
    for (const s of series) for (const v of s.values) if (v !== null && v > yMax) yMax = v;
    yMax = niceMax(yMax);
    const xMin = ticks[0];
    const xMax = Math.max(ticks[ticks.length - 1], xMin + 1);
    const map = frame(ctx, w, h, { xLabel, yLabel, xMin, xMax, yMax });
    for (const s of series) {
      ctx.strokeStyle = s.color;
      ctx.lineWidth = 1.6;
      ctx.setLineDash(s.dashed ? [5, 4] : []);
      ctx.beginPath();
      let pen = false;
      s.values.forEach((v, i) => {
        if (v === null) {
          pen = false;
          return;
        }
        const x = map.x(ticks[i]);
        const y = map.y(v);
        if (pen) ctx.lineTo(x, y);
        else ctx.moveTo(x, y);
        pen = true;
      });
      ctx.stroke();
    }
    ctx.setLineDash([]);
  }

  function drawHistogram() {
    const panel = panels.histogram;
    if (!panel) return;
    const { ctx, w, h } = fitCanvas(panel.canvas);
    const traitName = trait;
    const label = `${traitName} (${LABELS[histKind].toLowerCase()})`;
    if (!TRAITS[histKind].includes(traitName)) {
      ctx.fillStyle = "#9aa8b2";
      ctx.font = "13px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`${LABELS[histKind]} have no ${traitName} trait`, w / 2, h / 2);
      panel.figure.querySelector("figcaption").textContent = `Distribution of ${traitName}`;
      return;
    }
    panel.figure.querySelector("figcaption").textContent = `Distribution of ${traitName}, ${LABELS[histKind].toLowerCase()}`;
    if (!histogram || histogram.kind !== histKind || histogram.trait !== traitName) {
      ctx.fillStyle = "#9aa8b2";
      ctx.font = "13px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("waiting for data", w / 2, h / 2);
      return;
    }
    if (histogram.n === 0) {
      ctx.fillStyle = "#9aa8b2";
      ctx.font = "13px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(`no living ${LABELS[histKind].toLowerCase()} now (n = 0)`, w / 2, h / 2);
      return;
    }
    const yMax = niceMax(Math.max(1, ...histogram.counts));
    const xMin = histogram.edges[0];
    const xMax = histogram.edges[histogram.edges.length - 1];
    const map = frame(ctx, w, h, { xLabel: label, yLabel: "Organisms", xMin, xMax, yMax });
    ctx.fillStyle = COLORS[histKind];
    histogram.counts.forEach((c, i) => {
      const x0 = map.x(histogram.edges[i]);
      const x1 = map.x(histogram.edges[i + 1]);
      const y = map.y(c);
      ctx.fillRect(x0 + 1, y, Math.max(1, x1 - x0 - 2), map.top + map.ph - y);
    });
  }

  function redrawAll() {
    if (!root.firstChild) return;
    const series = (name) => KINDS.map((k) => ({ values: data[name][k], color: COLORS[k] }));
    drawLines("population", { xLabel: "Tick", yLabel: "Individuals", series: series("population") });
    drawLines("events", {
      xLabel: "Tick",
      yLabel: "Events per tick",
      series: [
        ...KINDS.map((k) => ({ values: data.births[k], color: COLORS[k] })),
        ...KINDS.map((k) => ({ values: data.deaths[k], color: COLORS[k], dashed: true })),
      ],
    });
    drawLines("species", { xLabel: "Tick", yLabel: "Species alive", series: series("species") });
    drawLines("mean", { xLabel: "Tick", yLabel: `Mean ${trait}`, series: series("mean") });
    drawHistogram();
  }

  // ---- data --------------------------------------------------------------------------------------------------

  async function getJSON(url) {
    const res = await fetch(url, { cache: "no-store" });
    if (!res.ok) return null;
    return res.json();
  }

  // Reads /api/state for the tick and the base-layer version: a reset or a new world starts the charts again.
  async function checkWorld() {
    const state = await getJSON("/api/state");
    if (!state) return;
    const version = state.control ? state.control.climate_version : null;
    const tickBack = lastTick !== null && state.tick < lastTick;
    if ((climateVersion !== null && version !== climateVersion) || tickBack) {
      resetData();
    }
    climateVersion = version;
  }

  async function poll() {
    if (stopped) return;
    try {
      await checkWorld();
      const since = lastTick === null ? "" : `&since=${lastTick}`;
      const body = await getJSON(`/api/series?trait=${encodeURIComponent(trait)}${since}`);
      if (body && body.tick.length > 0) {
        data.ticks.push(...body.tick);
        for (const k of KINDS) {
          data.population[k].push(...body.population[k]);
          data.births[k].push(...body.births[k]);
          data.deaths[k].push(...body.deaths[k]);
          data.species[k].push(...body.species[k]);
          data.mean[k].push(...body.trait.mean[k]);
        }
        lastTick = data.ticks[data.ticks.length - 1];
        redrawAll();
      }
    } catch (_) {
      // The next poll tries again.
    }
  }

  async function pollHistogram() {
    if (stopped) return;
    try {
      const body = await getJSON(`/api/distribution?kind=${histKind}&trait=${encodeURIComponent(trait)}&bins=${BINS}`);
      if (body) {
        histogram = { ...body, kind: histKind, trait };
        drawHistogram();
      }
    } catch (_) {
      // The next poll tries again.
    }
  }

  function start() {
    build();
    resetData();
    poll();
    pollHistogram();
    setInterval(poll, POLL_MS);
    setInterval(pollHistogram, HIST_MS);
    window.addEventListener("resize", redrawAll);
  }

  start();
})();

//! Chart data of the UI (ADR-0026 D6, D7): a bounded log of per-tick points taken from `core::analytics`, the JSON of
//! the series endpoint, and the histogram of one trait in the living population. Pure: no display, no threads.

use evosim_core::analytics::{self, Snapshot};
use evosim_core::entities::Kind;
use evosim_core::sim::Simulation;

/// Most points the log keeps (ADR-0026 D6). At the limit every second point is merged and the stride doubles.
pub const MAX_POINTS: usize = 2000;
/// Histogram bins: the default and the allowed range (ADR-0026 D7).
pub const DEFAULT_BINS: usize = 20;
pub const MAX_BINS: usize = 100;

/// Name of a kind in the JSON of the chart endpoints.
pub fn kind_name(kind: Kind) -> &'static str {
    match kind {
        Kind::Plant => "plant",
        Kind::Herbivore => "herbivore",
        Kind::Carnivore => "carnivore",
    }
}

/// The kind named in a request, or `None`.
pub fn kind_from_name(name: &str) -> Option<Kind> {
    Kind::ALL.into_iter().find(|k| kind_name(*k) == name)
}

/// One point of the charts: the metrics of every kind at `tick`. Indexed by `Kind::index()`.
/// `births` and `deaths` are the events since the previous point (merged points add up).
#[derive(Clone, Debug, PartialEq)]
pub struct ChartPoint {
    pub tick: u64,
    pub population: [u64; 3],
    pub births: [u64; 3],
    pub deaths: [u64; 3],
    pub species: [u64; 3],
    /// Mean of every trait of the kind, in `analytics::trait_names` order; `None` when no organism is alive.
    pub trait_mean: [Vec<Option<f64>>; 3],
}

fn point_of(s: &Snapshot) -> ChartPoint {
    ChartPoint {
        tick: s.tick,
        population: Kind::ALL.map(|k| s.kinds[k.index()].population),
        births: Kind::ALL.map(|k| s.kinds[k.index()].births_since_last),
        deaths: Kind::ALL.map(|k| s.kinds[k.index()].deaths_since_last),
        species: Kind::ALL.map(|k| s.kinds[k.index()].species_living),
        trait_mean: Kind::ALL.map(|k| {
            let kind = &s.kinds[k.index()];
            analytics::trait_names(k)
                .iter()
                .map(|name| {
                    kind.traits
                        .as_ref()
                        .and_then(|traits| traits.iter().find(|(n, _)| n == name))
                        .map(|(_, stat)| stat.mean)
                })
                .collect()
        }),
    }
}

/// Folds a later point into an earlier one: events add up, every level takes the later value.
fn merge(earlier: &mut ChartPoint, later: ChartPoint) {
    for i in 0..3 {
        earlier.births[i] += later.births[i];
        earlier.deaths[i] += later.deaths[i];
    }
    earlier.tick = later.tick;
    earlier.population = later.population;
    earlier.species = later.species;
    earlier.trait_mean = later.trait_mean;
}

/// The bounded per-tick log of a session.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ChartLog {
    points: Vec<ChartPoint>,
    /// Ticks per kept point: 1 until the log first reaches [`MAX_POINTS`], then doubles at each thinning.
    stride: u64,
    /// Ticks merged since the last kept point, not yet in `points`.
    pending: Option<ChartPoint>,
    pending_ticks: u64,
    /// Cumulative (births, deaths) at the previous recorded tick.
    previous: Option<[(u64, u64); 3]>,
}

impl ChartLog {
    /// An empty log that keeps every tick.
    pub fn new() -> ChartLog {
        ChartLog { stride: 1, ..ChartLog::default() }
    }

    /// Records the state of `sim` at its current tick. Read-only for `sim`.
    pub fn record(&mut self, sim: &Simulation) {
        let snapshot = analytics::sample(sim, self.previous);
        self.previous = Some(analytics::cumulative_events(sim));
        let point = point_of(&snapshot);
        match &mut self.pending {
            Some(acc) => merge(acc, point),
            None => self.pending = Some(point),
        }
        self.pending_ticks += 1;
        if self.pending_ticks >= self.stride {
            if let Some(done) = self.pending.take() {
                self.points.push(done);
            }
            self.pending_ticks = 0;
            if self.points.len() >= MAX_POINTS {
                self.thin();
            }
        }
    }

    /// Merges every pair of kept points and doubles the stride. Totals of births and deaths stay exact.
    fn thin(&mut self) {
        let old = std::mem::take(&mut self.points);
        let mut kept = Vec::with_capacity(old.len() / 2 + 1);
        let mut rest = old.into_iter();
        while let Some(mut first) = rest.next() {
            if let Some(second) = rest.next() {
                merge(&mut first, second);
            }
            kept.push(first);
        }
        self.points = kept;
        self.stride *= 2;
    }

    /// The kept points, oldest first (the merged point still being filled is not included).
    pub fn points(&self) -> &[ChartPoint] {
        &self.points
    }

    /// Ticks per kept point.
    pub fn stride(&self) -> u64 {
        self.stride
    }

    /// Births of every kind summed over the kept points and the pending one: the exact total since the log started.
    pub fn births_total(&self) -> [u64; 3] {
        let mut total = [0u64; 3];
        for p in self.points.iter().chain(self.pending.iter()) {
            for i in 0..3 {
                total[i] += p.births[i];
            }
        }
        total
    }

    /// Deaths of every kind summed over the kept points and the pending one.
    pub fn deaths_total(&self) -> [u64; 3] {
        let mut total = [0u64; 3];
        for p in self.points.iter().chain(self.pending.iter()) {
            for i in 0..3 {
                total[i] += p.deaths[i];
            }
        }
        total
    }

    /// The `/api/series` body: points with `tick > since` (all points when `since` is `None`) for the named trait.
    /// The trait must be a trait of at least one kind; a kind without it gets `null`.
    pub fn series_json(&self, since: Option<u64>, trait_name: &str) -> Result<String, String> {
        let known = Kind::ALL.iter().any(|k| analytics::trait_names(*k).contains(&trait_name));
        if !known {
            return Err(format!("unknown trait {trait_name}"));
        }
        let points: Vec<&ChartPoint> = self.points.iter().filter(|p| since.is_none_or(|s| p.tick > s)).collect();
        let ticks = join(points.iter().map(|p| p.tick.to_string()));
        let level = |pick: &dyn Fn(&ChartPoint, usize) -> String| {
            let parts: Vec<String> = Kind::ALL
                .iter()
                .map(|k| {
                    let values = join(points.iter().map(|p| pick(p, k.index())));
                    format!("\"{}\":[{}]", kind_name(*k), values)
                })
                .collect();
            format!("{{{}}}", parts.join(","))
        };
        let mean = |p: &ChartPoint, kind: usize| {
            let k = Kind::ALL[kind];
            match analytics::trait_names(k).iter().position(|n| *n == trait_name) {
                Some(i) => p.trait_mean[kind][i].map(num).unwrap_or_else(|| "null".to_string()),
                None => "null".to_string(),
            }
        };
        Ok(format!(
            "{{\"tick\":[{ticks}],\"population\":{},\"births\":{},\"deaths\":{},\"species\":{},\"trait\":{{\"name\":{},\"mean\":{}}}}}",
            level(&|p, i| p.population[i].to_string()),
            level(&|p, i| p.births[i].to_string()),
            level(&|p, i| p.deaths[i].to_string()),
            level(&|p, i| p.species[i].to_string()),
            evosim_core::config::json::write(&evosim_core::config::json::Value::Str(trait_name.to_string())),
            level(&mean),
        ))
    }
}

fn join(items: impl Iterator<Item = String>) -> String {
    items.collect::<Vec<_>>().join(",")
}

/// A finite number as JSON text, otherwise `null`.
fn num(x: f64) -> String {
    if x.is_finite() {
        format!("{x}")
    } else {
        "null".to_string()
    }
}

/// A histogram of one trait. A bin is `[edge_i, edge_i+1)`; the last bin is closed.
#[derive(Clone, Debug, PartialEq)]
pub struct Histogram {
    pub n: u64,
    /// `None` when `n == 0`.
    pub stat: Option<evosim_core::analytics::Stat>,
    pub edges: Vec<f64>,
    pub counts: Vec<u64>,
}

/// Bins `values` into `bins` equal bins over their range. With one distinct value the range is widened by half a
/// unit on each side so that the bars stay meaningful. `bins` must be in `1..=MAX_BINS` (checked by the caller).
pub fn histogram(values: &[f64], bins: usize) -> Histogram {
    let stat = analytics::stat(values);
    let Some(s) = stat else {
        return Histogram { n: 0, stat: None, edges: Vec::new(), counts: Vec::new() };
    };
    let (mut lo, mut hi) = (s.min, s.max);
    if hi <= lo {
        lo -= 0.5;
        hi += 0.5;
    }
    let edges: Vec<f64> = (0..=bins).map(|i| lo + (hi - lo) * i as f64 / bins as f64).collect();
    let mut counts = vec![0u64; bins];
    for &v in values {
        let at = ((v - lo) / (hi - lo) * bins as f64).floor();
        let index = if at < 0.0 { 0 } else { (at as usize).min(bins - 1) };
        counts[index] += 1;
    }
    Histogram { n: values.len() as u64, stat: Some(s), edges, counts }
}

/// The `/api/distribution` body for the living organisms of `kind`, or an error text for an unknown trait or bin count.
pub fn distribution_json(sim: &Simulation, kind: Kind, trait_name: &str, bins: usize) -> Result<String, String> {
    if !(1..=MAX_BINS).contains(&bins) {
        return Err(format!("bins must be 1..={MAX_BINS}"));
    }
    let index = analytics::trait_names(kind)
        .iter()
        .position(|n| *n == trait_name)
        .ok_or_else(|| format!("{trait_name} is not a trait of {}", kind_name(kind)))?;
    let values: Vec<f64> = sim
        .entities()
        .living()
        .filter(|o| o.kind() == kind)
        .map(|o| analytics::trait_values(o)[index])
        .collect();
    let h = histogram(&values, bins);
    let (mean, sd, min, max) = match h.stat {
        Some(s) => (num(s.mean), num(s.sd), num(s.min), num(s.max)),
        None => ("null".into(), "null".into(), "null".into(), "null".into()),
    };
    let edges = join(h.edges.iter().map(|e| num(*e)));
    let counts = join(h.counts.iter().map(|c| c.to_string()));
    Ok(format!(
        "{{\"kind\":\"{}\",\"trait\":\"{}\",\"n\":{},\"mean\":{mean},\"sd\":{sd},\"min\":{min},\"max\":{max},\"edges\":[{edges}],\"counts\":[{counts}]}}",
        kind_name(kind),
        trait_name,
        h.n
    ))
}

#[cfg(test)]
mod tests {
    use super::*;
    use evosim_core::config::Config;
    use evosim_core::config::json;

    const WORLD: &str = r#"{"seed": 42, "world": {"width": 24, "height": 16},
        "initial": {"plants": 120, "herbivores": 30, "carnivores": 6}}"#;

    fn sim_at(ticks: u64) -> Simulation {
        let config = Config::from_json(WORLD).unwrap();
        let mut sim = Simulation::new(&config).unwrap();
        sim.populate_initial(&config).unwrap();
        for _ in 0..ticks {
            sim.tick();
        }
        sim
    }

    fn point(tick: u64, births: u64) -> ChartPoint {
        ChartPoint {
            tick,
            population: [1, 2, 3],
            births: [births, 0, 0],
            deaths: [0, births, 0],
            species: [1, 1, 1],
            trait_mean: [vec![None; 8], vec![None; 8], vec![None; 8]],
        }
    }

    #[test]
    fn kind_names_round_trip() {
        for k in Kind::ALL {
            assert_eq!(kind_from_name(kind_name(k)), Some(k));
        }
        assert_eq!(kind_from_name("tree"), None);
    }

    #[test]
    fn log_keeps_every_tick_below_the_limit() {
        let mut log = ChartLog::new();
        let mut sim = sim_at(0);
        log.record(&sim);
        for _ in 0..50 {
            sim.tick();
            log.record(&sim);
        }
        assert_eq!(log.points().len(), 51);
        assert_eq!(log.stride(), 1);
        assert_eq!(log.points().last().unwrap().tick, 50);
        assert_eq!(log.points()[0].births, [0, 0, 0], "the first point has no earlier tick");
    }

    #[test]
    fn thinning_keeps_the_totals_and_bounds_the_points() {
        let mut log = ChartLog::new();
        let mut sim = sim_at(0);
        log.record(&sim);
        for _ in 0..(MAX_POINTS as u64 * 2 + 37) {
            sim.tick();
            log.record(&sim);
        }
        assert!(log.points().len() < MAX_POINTS, "{}", log.points().len());
        assert!(log.stride() >= 2);
        let entities = sim.entities();
        for k in Kind::ALL {
            assert_eq!(log.births_total()[k.index()], entities.births(k), "births of {k:?}");
            assert_eq!(log.deaths_total()[k.index()], entities.deaths(k), "deaths of {k:?}");
        }
        let ticks: Vec<u64> = log.points().iter().map(|p| p.tick).collect();
        assert!(ticks.windows(2).all(|w| w[0] < w[1]), "ticks increase");
    }

    #[test]
    fn merge_sums_events_and_takes_the_later_levels() {
        let mut a = point(4, 2);
        merge(&mut a, point(5, 3));
        assert_eq!(a.births[0], 5);
        assert_eq!(a.deaths[1], 5);
        assert_eq!(a.tick, 5);
        assert_eq!(a.population, [1, 2, 3]);
    }

    #[test]
    fn series_returns_only_newer_ticks_and_is_valid_json() {
        let mut log = ChartLog::new();
        let mut sim = sim_at(0);
        log.record(&sim);
        for _ in 0..10 {
            sim.tick();
            log.record(&sim);
        }
        let all = json::parse(&log.series_json(None, "speed").unwrap()).unwrap();
        let json_all = log.series_json(None, "speed").unwrap();
        assert!(json_all.contains("\"tick\":[0,1,2,3,4,5,6,7,8,9,10]"), "{json_all}");
        let newer = log.series_json(Some(7), "speed").unwrap();
        assert!(newer.contains("\"tick\":[8,9,10]"), "{newer}");
        assert!(matches!(all, json::Value::Object(_)));
        for body in [&json_all, &newer] {
            json::parse(body).expect("valid JSON");
        }
    }

    #[test]
    fn series_population_and_species_end_at_the_last_recorded_values() {
        let mut log = ChartLog::new();
        let mut sim = sim_at(0);
        log.record(&sim);
        for _ in 0..20 {
            sim.tick();
            log.record(&sim);
        }
        let last = log.points().last().unwrap().clone();
        assert_eq!(last.population, Kind::ALL.map(|k| sim.entities().living_count(k)));
        let body = log.series_json(None, "speed").unwrap();
        let herb = format!("\"herbivore\":[{}]", join(log.points().iter().map(|p| p.population[1].to_string())));
        assert!(body.contains(&herb), "{body}");
    }

    #[test]
    fn series_trait_must_exist_and_the_mean_follows_the_kind() {
        let log = ChartLog::new();
        assert!(log.series_json(None, "no_such_trait").is_err());
        let mut log = ChartLog::new();
        log.record(&sim_at(0));
        let body = log.series_json(None, "aggression").unwrap();
        assert!(body.contains("\"mean\":{\"plant\":[null]"), "plants have no aggression: {body}");
        let speed = log.series_json(None, "speed").unwrap();
        assert!(!speed.contains("\"mean\":{\"plant\":[null]"), "plants have speed: {speed}");
    }

    #[test]
    fn histogram_counts_sum_to_n_and_bins_are_closed_at_the_top() {
        let values = [0.0, 0.5, 1.0, 1.0, 2.0];
        let h = histogram(&values, 4);
        assert_eq!(h.n, 5);
        assert_eq!(h.counts.iter().sum::<u64>(), 5);
        assert_eq!(h.edges, vec![0.0, 0.5, 1.0, 1.5, 2.0]);
        assert_eq!(h.counts, vec![1, 1, 2, 1], "0 in bin 0, 0.5 in bin 1, both 1.0 in bin 2, the maximum in the closed last bin");
    }

    #[test]
    fn histogram_of_one_distinct_value_and_of_no_value() {
        let h = histogram(&[3.0, 3.0], 5);
        assert_eq!(h.counts.iter().sum::<u64>(), 2);
        assert_eq!(h.counts[2], 2, "the middle bin holds the single value");
        let empty = histogram(&[], 5);
        assert_eq!(empty.n, 0);
        assert!(empty.edges.is_empty() && empty.counts.is_empty());
        assert!(empty.stat.is_none());
    }

    #[test]
    fn distribution_sums_to_the_living_count_of_the_kind() {
        let sim = sim_at(30);
        let body = distribution_json(&sim, Kind::Herbivore, "speed", 10).unwrap();
        let n = sim.entities().living_count(Kind::Herbivore);
        assert!(body.contains(&format!("\"n\":{n}")), "{body}");
        let Some(counts) = body.split("\"counts\":[").nth(1) else { panic!("{body}") };
        let total: u64 = counts.split(']').next().unwrap().split(',').map(|c| c.parse::<u64>().unwrap()).sum();
        assert_eq!(total, n);
        json::parse(&body).expect("valid JSON");
    }

    #[test]
    fn distribution_rejects_bad_bins_and_unknown_traits() {
        let sim = sim_at(0);
        assert!(distribution_json(&sim, Kind::Plant, "speed", 0).is_err());
        assert!(distribution_json(&sim, Kind::Plant, "speed", MAX_BINS + 1).is_err());
        assert!(distribution_json(&sim, Kind::Plant, "aggression", 5).is_err());
        assert!(distribution_json(&sim, Kind::Carnivore, "aggression", 5).is_ok());
    }

    #[test]
    fn distribution_with_no_organism_is_empty() {
        let config = Config::from_json(
            r#"{"seed": 1, "world": {"width": 8, "height": 8},
                "initial": {"plants": 4, "herbivores": 2, "carnivores": 0}}"#,
        )
        .unwrap();
        let mut empty = Simulation::new(&config).unwrap();
        empty.populate_initial(&config).unwrap();
        let body2 = distribution_json(&empty, Kind::Carnivore, "speed", 4).unwrap();
        assert!(body2.contains("\"n\":0"), "{body2}");
        assert!(body2.contains("\"edges\":[]"), "{body2}");
        assert!(body2.contains("\"mean\":null"), "{body2}");
    }
}

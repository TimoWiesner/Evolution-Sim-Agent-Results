//! Local HTTP server on `127.0.0.1` (ADR-0002, ADR-0024 D2, ADR-0025 D2). std only: one thread per connection,
//! `Connection: close`. Reads `GET` requests and, for the control routes, `POST` bodies up to [`MAX_BODY`].
//! [`route`] is pure apart from the command channel and is unit-tested; the socket code only reads and writes bytes.

use crate::charts::{kind_from_name, DEFAULT_BINS};
use crate::control::{Command, Reply};
use crate::setup;
use evosim_core::config::Config;
use std::io::{self, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{self, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::Duration;

/// The embedded page and its assets (`include_str!`, so the binary needs no files beside it).
pub const INDEX_HTML: &str = include_str!("../web/index.html");
pub const APP_JS: &str = include_str!("../web/app.js");
pub const STYLE_CSS: &str = include_str!("../web/style.css");
pub const SETUP_JS: &str = include_str!("../web/setup.js");
pub const CHARTS_JS: &str = include_str!("../web/charts.js");

/// Largest request body accepted (checkpoint uploads, ADR-0025 D2). Larger bodies get HTTP 413 before they are read.
pub const MAX_BODY: usize = 64 * 1024 * 1024;
/// Longest wait for the simulation thread to answer a command (ADR-0025 D2). Longer waits are HTTP 503.
pub const REPLY_TIMEOUT: Duration = Duration::from_secs(5);
/// Largest request head (request line and headers).
const MAX_HEAD: usize = 8192;

/// A command with the channel on which the simulation thread sends its reply.
pub struct Envelope {
    pub command: Command,
    pub reply: Sender<Reply>,
}

/// State shared by the simulation thread (writer) and the HTTP threads (readers and command senders).
pub struct Shared {
    /// Latest `/api/state` bytes. The lock is held only for the swap or the clone of the `Arc`.
    state: Mutex<Arc<Vec<u8>>>,
    /// `/api/climate` bytes. Replaced after a reset or a load, when the world size may have changed (ADR-0025 D3).
    climate: Mutex<Arc<Vec<u8>>>,
    /// Selected organism and its `/api/organism` bytes, or `None` when nothing is selected.
    watch: Mutex<Option<(u64, Arc<Vec<u8>>)>>,
    /// Tick of the latest published state; read by the driver for its waits.
    tick: AtomicU64,
    /// Queue to the simulation thread.
    commands: Mutex<Sender<Envelope>>,
}

impl Shared {
    pub fn new(climate: Vec<u8>, state: Vec<u8>, tick: u64, commands: Sender<Envelope>) -> Shared {
        Shared {
            state: Mutex::new(Arc::new(state)),
            climate: Mutex::new(Arc::new(climate)),
            watch: Mutex::new(None),
            tick: AtomicU64::new(tick),
            commands: Mutex::new(commands),
        }
    }

    /// Replaces the published state. Called only by the simulation thread.
    pub fn publish(&self, state: Vec<u8>, tick: u64) {
        let mut slot = self.state.lock().unwrap_or_else(|e| e.into_inner());
        *slot = Arc::new(state);
        self.tick.store(tick, Ordering::SeqCst);
    }

    /// Replaces the climate base layer. Called only by the simulation thread, before the state that announces it.
    pub fn publish_climate(&self, climate: Vec<u8>) {
        *self.climate.lock().unwrap_or_else(|e| e.into_inner()) = Arc::new(climate);
    }

    /// Replaces the inspector body: `Some((id, body))` while an organism is selected, `None` otherwise.
    pub fn publish_watch(&self, watch: Option<(u64, Vec<u8>)>) {
        *self.watch.lock().unwrap_or_else(|e| e.into_inner()) = watch.map(|(id, body)| (id, Arc::new(body)));
    }

    fn snapshot(&self) -> Arc<Vec<u8>> {
        self.state.lock().unwrap_or_else(|e| e.into_inner()).clone()
    }

    fn climate(&self) -> Arc<Vec<u8>> {
        self.climate.lock().unwrap_or_else(|e| e.into_inner()).clone()
    }

    /// The inspector body for `id`, if that organism is the selected one.
    fn watch_for(&self, id: u64) -> Option<Arc<Vec<u8>>> {
        let slot = self.watch.lock().unwrap_or_else(|e| e.into_inner());
        match &*slot {
            Some((selected, body)) if *selected == id => Some(body.clone()),
            _ => None,
        }
    }

    pub fn tick(&self) -> u64 {
        self.tick.load(Ordering::SeqCst)
    }
}

/// Creates the command channel: the sender goes into [`Shared::new`], the receiver to the simulation thread.
pub fn command_channel() -> (Sender<Envelope>, Receiver<Envelope>) {
    mpsc::channel()
}

/// An HTTP response ready to be written.
#[derive(Debug, PartialEq, Eq)]
pub struct Response {
    pub status: u16,
    pub content_type: &'static str,
    pub body: Vec<u8>,
    /// `Content-Disposition` value, for downloads.
    pub disposition: Option<String>,
}

fn ok(content_type: &'static str, body: Vec<u8>) -> Response {
    Response { status: 200, content_type, body, disposition: None }
}

fn json(status: u16, body: String) -> Response {
    Response { status, content_type: "application/json", body: body.into_bytes(), disposition: None }
}

fn text(status: u16, message: &str) -> Response {
    Response {
        status,
        content_type: "text/plain; charset=utf-8",
        body: message.as_bytes().to_vec(),
        disposition: None,
    }
}

/// `{"ok":true}` or `{"ok":false,"error":"..."}`.
fn reply_json(reply: &Reply, failure_status: u16) -> Response {
    match reply {
        Reply::Error(message) => json(failure_status, format!("{{\"ok\":false,\"error\":{}}}", json_string(message))),
        _ => json(200, "{\"ok\":true}".to_string()),
    }
}

/// Methods accepted by each path; `None` for an unknown path.
fn allowed_methods(path: &str) -> Option<&'static [&'static str]> {
    match path {
        "/" | "/index.html" | "/app.js" | "/style.css" | "/setup.js" | "/charts.js" | "/api/climate" | "/api/state"
        | "/api/organism" | "/api/presets" | "/api/series" | "/api/distribution" => Some(&["GET"]),
        "/api/checkpoint" => Some(&["GET", "POST"]),
        "/api/command" => Some(&["POST"]),
        "/api/config/check" | "/api/config/import" | "/api/world" => Some(&["POST"]),
        _ => None,
    }
}

/// Routes one request. The query string is ignored by the page routes. Unknown paths are 404; a known path with
/// another method is 405. Control routes wait up to [`REPLY_TIMEOUT`] for the simulation thread.
pub fn route(method: &str, target: &str, body: &[u8], shared: &Shared) -> Response {
    let (path, query) = target.split_once('?').unwrap_or((target, ""));
    let Some(methods) = allowed_methods(path) else {
        return text(404, "not found");
    };
    if !methods.contains(&method) {
        return text(405, "method not allowed");
    }
    match (method, path) {
        ("GET", "/" | "/index.html") => ok("text/html; charset=utf-8", INDEX_HTML.as_bytes().to_vec()),
        ("GET", "/app.js") => ok("application/javascript; charset=utf-8", APP_JS.as_bytes().to_vec()),
        ("GET", "/style.css") => ok("text/css; charset=utf-8", STYLE_CSS.as_bytes().to_vec()),
        ("GET", "/setup.js") => ok("application/javascript; charset=utf-8", SETUP_JS.as_bytes().to_vec()),
        ("GET", "/charts.js") => ok("application/javascript; charset=utf-8", CHARTS_JS.as_bytes().to_vec()),
        ("GET", "/api/presets") => ok("application/json", setup::presets_json().into_bytes()),
        ("POST", "/api/config/check") => config_check(body),
        ("POST", "/api/config/import") => config_import(body),
        ("POST", "/api/world") => new_world(body, shared),
        ("GET", "/api/series") => series(query, shared),
        ("GET", "/api/distribution") => distribution(query, shared),
        ("GET", "/api/climate") => ok("application/json", shared.climate().to_vec()),
        ("GET", "/api/state") => ok("application/json", shared.snapshot().to_vec()),
        ("GET", "/api/organism") => organism(query, shared),
        ("POST", "/api/command") => command(body, shared),
        ("GET", "/api/checkpoint") => checkpoint_download(shared),
        ("POST", "/api/checkpoint") => checkpoint_upload(body, shared),
        _ => text(405, "method not allowed"),
    }
}

/// The configuration of a request body, or the HTTP error to send: 400 for a malformed body, 422 with the field
/// errors for an invalid configuration (ADR-0026 D2).
fn config_from_body(body: &[u8]) -> Result<Config, Response> {
    let request = setup::parse_request(body).map_err(|m| text(400, &m))?;
    setup::request_config(&request).map_err(|errors| json(422, setup::errors_json(&errors)))
}

/// `POST /api/config/check`: validates the form and returns the configuration text (the page's export, ADR-0026 D3).
fn config_check(body: &[u8]) -> Response {
    match config_from_body(body) {
        Ok(config) => json(200, format!("{{\"ok\":true,\"config\":{}}}", setup::json_string(&config.to_json()))),
        Err(response) => response,
    }
}

/// `POST /api/config/import`: the body is the file text. Returns the form fields of the configuration (ADR-0026 D3).
fn config_import(body: &[u8]) -> Response {
    let text = match std::str::from_utf8(body) {
        Ok(text) => text,
        Err(_) => return text(400, "the file is not UTF-8"),
    };
    match Config::from_json(text) {
        Ok(config) => json(200, setup::import_json(&config)),
        Err(e) => json(422, setup::errors_json(&[setup::FieldError { key: e.key, message: e.message }])),
    }
}

/// `POST /api/world`: starts a new world from the form (ADR-0026 D4). An invalid form never reaches the session.
fn new_world(body: &[u8], shared: &Shared) -> Response {
    let config = match config_from_body(body) {
        Ok(config) => config,
        Err(response) => return response,
    };
    match send(shared, Command::NewWorld(Box::new(config))) {
        Ok(reply) => reply_json(&reply, 422),
        Err(response) => response,
    }
}

/// `GET /api/series?since=T&trait=NAME` (ADR-0026 D6).
fn series(query: &str, shared: &Shared) -> Response {
    let since = match query_value(query, "since") {
        None => None,
        Some(v) => match v.parse::<u64>() {
            Ok(t) => Some(t),
            Err(_) => return text(400, "since must be a tick number"),
        },
    };
    let Some(trait_name) = query_value(query, "trait").filter(|t| !t.is_empty()) else {
        return text(400, "trait is required");
    };
    match send(shared, Command::Series { since, trait_name: trait_name.to_string() }) {
        Ok(Reply::Bytes(bytes)) => ok("application/json", bytes),
        Ok(Reply::Error(message)) => text(400, &message),
        Ok(Reply::Done) => text(500, "no series produced"),
        Err(response) => response,
    }
}

/// `GET /api/distribution?kind=K&trait=NAME&bins=N` (ADR-0026 D7). Kinds: plant, herbivore, carnivore.
fn distribution(query: &str, shared: &Shared) -> Response {
    let Some(kind) = query_value(query, "kind").and_then(kind_from_name) else {
        return text(400, "kind must be plant, herbivore or carnivore");
    };
    let Some(trait_name) = query_value(query, "trait").filter(|t| !t.is_empty()) else {
        return text(400, "trait is required");
    };
    let bins = match query_value(query, "bins") {
        None => DEFAULT_BINS,
        Some(v) => match v.parse::<usize>() {
            Ok(b) => b,
            Err(_) => return text(400, "bins must be a number"),
        },
    };
    let command = Command::Distribution { kind, trait_name: trait_name.to_string(), bins };
    match send(shared, command) {
        Ok(Reply::Bytes(bytes)) => ok("application/json", bytes),
        Ok(Reply::Error(message)) => text(400, &message),
        Ok(Reply::Done) => text(500, "no distribution produced"),
        Err(response) => response,
    }
}

fn organism(query: &str, shared: &Shared) -> Response {
    let Some(id) = query_value(query, "id").and_then(|v| v.parse::<u64>().ok()) else {
        return text(400, "id must be an organism number");
    };
    match shared.watch_for(id) {
        Some(body) => ok("application/json", body.to_vec()),
        None => text(404, "organism is not selected"),
    }
}

/// `POST /api/command` with `action=run|pause|step|reset|faster|slower|select|deselect` and `id=N` for `select`.
fn command(body: &[u8], shared: &Shared) -> Response {
    let form = std::str::from_utf8(body).unwrap_or("");
    let command = match query_value(form, "action") {
        Some("run") => Command::Run,
        Some("pause") => Command::Pause,
        Some("step") => Command::Step,
        Some("reset") => Command::Reset,
        Some("faster") => Command::Faster,
        Some("slower") => Command::Slower,
        Some("deselect") => Command::Deselect,
        Some("select") => match query_value(form, "id").and_then(|v| v.parse::<u64>().ok()) {
            Some(id) => Command::Select(id),
            None => return text(400, "select needs id=N"),
        },
        _ => return text(400, "unknown or missing action"),
    };
    match send(shared, command) {
        Ok(reply) => reply_json(&reply, 200),
        Err(response) => response,
    }
}

fn checkpoint_download(shared: &Shared) -> Response {
    match send(shared, Command::Save) {
        Ok(Reply::Bytes(bytes)) => Response {
            status: 200,
            content_type: "application/octet-stream",
            body: bytes,
            disposition: Some(format!("attachment; filename=\"evosim-tick-{}.evockpt\"", shared.tick())),
        },
        Ok(Reply::Error(message)) => text(500, &message),
        Ok(Reply::Done) => text(500, "no checkpoint produced"),
        Err(response) => response,
    }
}

/// `POST /api/checkpoint`: the raw file is the body. An invalid file is 422 and leaves the session unchanged.
fn checkpoint_upload(body: &[u8], shared: &Shared) -> Response {
    match send(shared, Command::Load(body.to_vec())) {
        Ok(reply) => reply_json(&reply, 422),
        Err(response) => response,
    }
}

/// Sends one command and waits for its reply, or returns the HTTP error to send instead.
fn send(shared: &Shared, command: Command) -> Result<Reply, Response> {
    let (reply, answer) = mpsc::channel();
    let sender = shared.commands.lock().unwrap_or_else(|e| e.into_inner()).clone();
    sender
        .send(Envelope { command, reply })
        .map_err(|_| text(503, "the simulation has stopped"))?;
    answer
        .recv_timeout(REPLY_TIMEOUT)
        .map_err(|_| text(503, "the simulation did not answer in time"))
}

/// The value of `key` in a `&`-separated `key=value` list (no percent-decoding; the control values are plain ASCII).
pub fn query_value<'a>(query: &'a str, key: &str) -> Option<&'a str> {
    query
        .split('&')
        .filter_map(|pair| pair.split_once('='))
        .find(|(k, _)| *k == key)
        .map(|(_, v)| v)
}

/// A JSON string literal for `s`.
fn json_string(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 2);
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

/// Binds the listener on loopback only. Port 0 asks the system for a free port.
pub fn bind(port: u16) -> io::Result<TcpListener> {
    TcpListener::bind(("127.0.0.1", port))
}

/// Accepts connections forever; each connection is served on its own thread.
pub fn serve(listener: TcpListener, shared: Arc<Shared>) {
    for connection in listener.incoming() {
        match connection {
            Ok(stream) => {
                let shared = shared.clone();
                std::thread::spawn(move || {
                    let _ = handle(stream, &shared);
                });
            }
            Err(_) => std::thread::sleep(Duration::from_millis(10)),
        }
    }
}

fn handle(mut stream: TcpStream, shared: &Shared) -> io::Result<()> {
    stream.set_read_timeout(Some(Duration::from_secs(5)))?;
    let response = match read_head(&mut stream)? {
        None => text(400, "bad request"),
        Some((head, mut body)) => match parse_request_line(&head) {
            None => text(400, "bad request"),
            Some((method, target)) => match content_length(&head) {
                None => text(400, "bad content length"),
                // Refused before the body is read (ADR-0025 D2).
                Some(len) if len > MAX_BODY => text(413, "request body too large"),
                Some(len) => {
                    read_body(&mut stream, &mut body, len)?;
                    body.truncate(len);
                    route(method, target, &body, shared)
                }
            },
        },
    };
    write_response(&mut stream, &response)
}

/// Reads up to the blank line that ends the header block. Returns the head and any body bytes already read.
/// `None` when the head is incomplete or longer than [`MAX_HEAD`].
fn read_head(stream: &mut TcpStream) -> io::Result<Option<(String, Vec<u8>)>> {
    let mut buf = Vec::new();
    let mut chunk = [0u8; 1024];
    loop {
        if let Some(at) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            let head = String::from_utf8_lossy(&buf[..at]).into_owned();
            return Ok(Some((head, buf[at + 4..].to_vec())));
        }
        if buf.len() > MAX_HEAD {
            return Ok(None);
        }
        let n = stream.read(&mut chunk)?;
        if n == 0 {
            return Ok(None);
        }
        buf.extend_from_slice(&chunk[..n]);
    }
}

/// Reads the rest of a body of `len` bytes; `body` already holds the bytes read with the head.
fn read_body(stream: &mut TcpStream, body: &mut Vec<u8>, len: usize) -> io::Result<()> {
    let mut chunk = vec![0u8; 64 * 1024];
    while body.len() < len {
        let n = stream.read(&mut chunk)?;
        if n == 0 {
            break;
        }
        body.extend_from_slice(&chunk[..n]);
    }
    Ok(())
}

/// The `Content-Length` of a request head: `Some(0)` when absent, `None` when it is not a number.
pub fn content_length(head: &str) -> Option<usize> {
    for line in head.lines().skip(1) {
        if let Some((name, value)) = line.split_once(':') {
            if name.trim().eq_ignore_ascii_case("content-length") {
                return value.trim().parse::<usize>().ok();
            }
        }
    }
    Some(0)
}

/// The method and target of the request line, e.g. `GET /api/state?x=1 HTTP/1.1`.
pub fn parse_request_line(head: &str) -> Option<(&str, &str)> {
    let line = head.lines().next()?;
    let mut parts = line.split_whitespace();
    let method = parts.next()?;
    let target = parts.next()?;
    parts.next()?; // the HTTP version must be present
    Some((method, target))
}

fn write_response(stream: &mut TcpStream, response: &Response) -> io::Result<()> {
    let reason = match response.status {
        200 => "OK",
        400 => "Bad Request",
        404 => "Not Found",
        405 => "Method Not Allowed",
        413 => "Payload Too Large",
        422 => "Unprocessable Entity",
        500 => "Internal Server Error",
        503 => "Service Unavailable",
        _ => "Error",
    };
    let disposition = match &response.disposition {
        Some(value) => format!("Content-Disposition: {value}\r\n"),
        None => String::new(),
    };
    let head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\n{}Cache-Control: no-store\r\nConnection: close\r\n\r\n",
        response.status,
        reason,
        response.content_type,
        response.body.len(),
        disposition
    );
    stream.write_all(head.as_bytes())?;
    stream.write_all(&response.body)?;
    stream.flush()
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::SocketAddr;

    /// Shared state whose command queue has no reader: commands fail with 503.
    fn shared() -> Shared {
        let (tx, _rx) = command_channel();
        Shared::new(b"{\"width\":1}".to_vec(), b"{\"tick\":3}".to_vec(), 3, tx)
    }

    /// Shared state with a simulation stand-in that answers every command with `reply`.
    fn answering(reply: Reply) -> (Shared, std::thread::JoinHandle<Vec<Command>>) {
        let (tx, rx) = command_channel();
        let shared = Shared::new(b"{}".to_vec(), b"{\"tick\":3}".to_vec(), 3, tx);
        let handle = std::thread::spawn(move || {
            let mut seen = Vec::new();
            while let Ok(env) = rx.recv() {
                seen.push(env.command.clone());
                let _ = env.reply.send(reply.clone());
                if seen.len() >= 8 {
                    break;
                }
            }
            seen
        });
        (shared, handle)
    }

    #[test]
    fn routes_pages_and_api() {
        let s = shared();
        assert_eq!(route("GET", "/", &[], &s).status, 200);
        assert!(route("GET", "/", &[], &s).content_type.starts_with("text/html"));
        assert_eq!(route("GET", "/app.js", &[], &s).status, 200);
        assert_eq!(route("GET", "/style.css", &[], &s).content_type, "text/css; charset=utf-8");
        assert_eq!(route("GET", "/api/climate", &[], &s).body, b"{\"width\":1}".to_vec());
        assert_eq!(route("GET", "/api/state", &[], &s).body, b"{\"tick\":3}".to_vec());
    }

    #[test]
    fn unknown_path_is_404_and_wrong_method_is_405() {
        let s = shared();
        assert_eq!(route("GET", "/nope", &[], &s).status, 404);
        assert_eq!(route("POST", "/api/state", &[], &s).status, 405);
        assert_eq!(route("POST", "/", &[], &s).status, 405);
        assert_eq!(route("GET", "/api/command", &[], &s).status, 405, "commands are POST only");
        assert_eq!(route("PUT", "/api/checkpoint", &[], &s).status, 405);
    }

    #[test]
    fn query_string_is_ignored_by_page_routes() {
        let s = shared();
        assert_eq!(route("GET", "/api/state?x=1&y=2", &[], &s).body, b"{\"tick\":3}".to_vec());
        assert_eq!(route("GET", "/?smoke=1", &[], &s).status, 200);
    }

    #[test]
    fn publish_replaces_the_state_and_tick() {
        let s = shared();
        s.publish(b"{\"tick\":9}".to_vec(), 9);
        assert_eq!(s.tick(), 9);
        assert_eq!(route("GET", "/api/state", &[], &s).body, b"{\"tick\":9}".to_vec());
    }

    #[test]
    fn climate_is_replaced_by_publish_climate() {
        let s = shared();
        s.publish_climate(b"{\"width\":2}".to_vec());
        assert_eq!(route("GET", "/api/climate", &[], &s).body, b"{\"width\":2}".to_vec());
    }

    #[test]
    fn organism_route_answers_only_the_selected_id() {
        let s = shared();
        assert_eq!(route("GET", "/api/organism?id=5", &[], &s).status, 404, "nothing selected");
        s.publish_watch(Some((5, b"{\"id\":5}".to_vec())));
        let ok = route("GET", "/api/organism?id=5", &[], &s);
        assert_eq!((ok.status, ok.body.clone()), (200, b"{\"id\":5}".to_vec()));
        assert_eq!(route("GET", "/api/organism?id=6", &[], &s).status, 404);
        assert_eq!(route("GET", "/api/organism", &[], &s).status, 400, "id is required");
        assert_eq!(route("GET", "/api/organism?id=x", &[], &s).status, 400);
        s.publish_watch(None);
        assert_eq!(route("GET", "/api/organism?id=5", &[], &s).status, 404);
    }

    #[test]
    fn command_route_maps_actions_and_rejects_bad_ones() {
        let (s, handle) = answering(Reply::Done);
        let r = route("POST", "/api/command", b"action=run", &s);
        assert_eq!((r.status, r.body.clone()), (200, b"{\"ok\":true}".to_vec()));
        assert_eq!(route("POST", "/api/command", b"action=fly", &s).status, 400);
        assert_eq!(route("POST", "/api/command", b"", &s).status, 400);
        assert_eq!(route("POST", "/api/command", b"action=select", &s).status, 400, "select needs id");
        assert_eq!(route("POST", "/api/command", b"action=select&id=7", &s).status, 200);
        assert_eq!(route("POST", "/api/command", b"action=faster", &s).status, 200);
        drop(s); // the queue closes, so the stand-in simulation thread ends
        let seen = handle.join().unwrap();
        assert_eq!(seen, vec![Command::Run, Command::Select(7), Command::Faster]);
    }

    #[test]
    fn command_error_reply_is_ok_false_with_message() {
        let (s, _handle) = answering(Reply::Error("step needs a paused simulation".to_string()));
        let r = route("POST", "/api/command", b"action=step", &s);
        assert_eq!(r.status, 200);
        assert_eq!(
            String::from_utf8(r.body).unwrap(),
            "{\"ok\":false,\"error\":\"step needs a paused simulation\"}"
        );
    }

    #[test]
    fn command_without_a_simulation_is_503() {
        let s = shared();
        assert_eq!(route("POST", "/api/command", b"action=run", &s).status, 503);
    }

    #[test]
    fn checkpoint_download_is_an_attachment() {
        let (s, _handle) = answering(Reply::Bytes(b"EVOSIMCK-bytes".to_vec()));
        let r = route("GET", "/api/checkpoint", &[], &s);
        assert_eq!(r.status, 200);
        assert_eq!(r.content_type, "application/octet-stream");
        assert_eq!(r.body, b"EVOSIMCK-bytes".to_vec());
        assert_eq!(r.disposition.as_deref(), Some("attachment; filename=\"evosim-tick-3.evockpt\""));
    }

    #[test]
    fn checkpoint_upload_passes_the_body_and_reports_invalid_files_as_422() {
        let (s, handle) = answering(Reply::Done);
        let r = route("POST", "/api/checkpoint", b"file-bytes", &s);
        assert_eq!(r.status, 200);
        let (s2, _h2) = answering(Reply::Error("checkpoint is truncated".to_string()));
        let bad = route("POST", "/api/checkpoint", b"x", &s2);
        assert_eq!(bad.status, 422);
        assert!(String::from_utf8(bad.body).unwrap().contains("checkpoint is truncated"));
        drop(s);
        let seen = handle.join().unwrap();
        assert_eq!(seen, vec![Command::Load(b"file-bytes".to_vec())]);
    }

    #[test]
    fn request_line_and_headers_parse() {
        assert_eq!(
            parse_request_line("GET /api/state?x HTTP/1.1\r\nHost: a\r\n\r\n"),
            Some(("GET", "/api/state?x"))
        );
        assert_eq!(parse_request_line("GET /"), None);
        assert_eq!(parse_request_line(""), None);
        assert_eq!(content_length("POST / HTTP/1.1\r\nContent-Length: 12\r\n"), Some(12));
        assert_eq!(content_length("POST / HTTP/1.1\r\ncontent-length:  3 \r\n"), Some(3));
        assert_eq!(content_length("GET / HTTP/1.1\r\nHost: a\r\n"), Some(0));
        assert_eq!(content_length("POST / HTTP/1.1\r\nContent-Length: many\r\n"), None);
    }

    #[test]
    fn query_values_are_found() {
        assert_eq!(query_value("action=select&id=42", "id"), Some("42"));
        assert_eq!(query_value("action=select&id=42", "action"), Some("select"));
        assert_eq!(query_value("ids=1", "id"), None);
    }

    #[test]
    fn oversized_body_is_refused_before_it_is_read() {
        let (tx, rx) = command_channel();
        drop(rx);
        let shared = Arc::new(Shared::new(b"{}".to_vec(), b"{}".to_vec(), 0, tx));
        let listener = bind(0).unwrap();
        let addr: SocketAddr = listener.local_addr().unwrap();
        {
            let shared = shared.clone();
            std::thread::spawn(move || serve(listener, shared));
        }
        use std::io::{Read as _, Write as _};
        let mut stream = TcpStream::connect(addr).unwrap();
        // Only the head is sent: the server must answer 413 without waiting for the body.
        let head = format!("POST /api/checkpoint HTTP/1.1\r\nHost: x\r\nContent-Length: {}\r\n\r\n", MAX_BODY + 1);
        stream.write_all(head.as_bytes()).unwrap();
        let mut text_out = String::new();
        stream.read_to_string(&mut text_out).unwrap();
        assert!(text_out.starts_with("HTTP/1.1 413 "), "{text_out}");
    }
}

#[cfg(test)]
mod config_route_tests {
    use super::*;
    use crate::setup;
    use evosim_core::config::json::{self, Value};
    use evosim_core::config::presets;

    /// Shared state with no reader on the command queue: a command sent here would answer 503.
    fn unread() -> Shared {
        let (tx, _rx) = command_channel();
        Shared::new(b"{}".to_vec(), b"{\"tick\":3}".to_vec(), 3, tx)
    }

    /// Shared state whose simulation stand-in answers the first command with `reply` and returns the command.
    fn one_reply(reply: Reply) -> (Shared, std::thread::JoinHandle<Command>) {
        let (tx, rx) = command_channel();
        let shared = Shared::new(b"{}".to_vec(), b"{\"tick\":3}".to_vec(), 3, tx);
        let handle = std::thread::spawn(move || {
            let env = rx.recv().expect("one command");
            let command = env.command.clone();
            let _ = env.reply.send(reply);
            command
        });
        (shared, handle)
    }

    /// The form body of a configuration: every field text, plus the base text when `with_base` is set.
    fn form(c: &Config, with_base: bool) -> Vec<u8> {
        let fields = setup::fields_json(&setup::fields_of(c));
        if !with_base {
            return fields.into_bytes();
        }
        let pairs = &fields[1..fields.len() - 1];
        format!("{{{pairs},\"base\":{}}}", setup::json_string(&c.to_json())).into_bytes()
    }

    fn with_field(c: &Config, key: &str, value: &str) -> Vec<u8> {
        let mut fields = setup::fields_of(c);
        for f in fields.iter_mut().filter(|(k, _)| k == key) {
            f.1 = value.to_string();
        }
        setup::fields_json(&fields).into_bytes()
    }

    fn balanced() -> Config {
        presets::get("balanced").unwrap()
    }

    #[test]
    fn presets_are_served_as_json() {
        let r = route("GET", "/api/presets", &[], &unread());
        assert_eq!(r.status, 200);
        assert!(r.content_type.starts_with("application/json"));
        let text = String::from_utf8(r.body).unwrap();
        assert!(json::parse(&text).is_ok());
        assert!(text.contains("\"name\":\"continent\""));
    }

    #[test]
    fn check_returns_the_configuration_text_on_success() {
        let c = presets::get("arid").unwrap();
        let r = route("POST", "/api/config/check", &form(&c, true), &unread());
        assert_eq!(r.status, 200);
        let Value::Object(top) = json::parse(&String::from_utf8(r.body).unwrap()).unwrap() else { panic!() };
        let Some((_, Value::Str(text))) = top.iter().find(|(k, _)| k == "config") else { panic!("no config") };
        assert_eq!(Config::from_json(text).unwrap(), c);
    }

    #[test]
    fn check_names_the_invalid_field_with_422() {
        let r = route("POST", "/api/config/check", &with_field(&balanced(), "world.width", "0"), &unread());
        assert_eq!(r.status, 422);
        let text = String::from_utf8(r.body).unwrap();
        assert!(text.contains("\"key\":\"world.width\""), "{text}");
    }

    #[test]
    fn check_refuses_non_string_values_with_400() {
        let r = route("POST", "/api/config/check", br#"{"seed":42}"#, &unread());
        assert_eq!(r.status, 400);
        let r = route("POST", "/api/config/check", b"not json", &unread());
        assert_eq!(r.status, 400);
    }

    #[test]
    fn import_returns_the_fields_and_422_for_a_bad_file() {
        let c = presets::get("continent").unwrap();
        let r = route("POST", "/api/config/import", c.to_json().as_bytes(), &unread());
        assert_eq!(r.status, 200);
        assert!(String::from_utf8(r.body).unwrap().contains("\"seed\":\"42\""));
        let r = route("POST", "/api/config/import", br#"{"seed": -5}"#, &unread());
        assert_eq!(r.status, 422);
        assert!(String::from_utf8(r.body).unwrap().contains("\"key\":\"seed\""));
        let r = route("POST", "/api/config/import", b"{", &unread());
        assert_eq!(r.status, 422);
    }

    #[test]
    fn invalid_world_is_422_and_never_reaches_the_simulation() {
        // The queue has no reader: a command that was sent would answer 503.
        let r = route("POST", "/api/world", &with_field(&balanced(), "initial.plants", "1.5"), &unread());
        assert_eq!(r.status, 422);
        assert!(String::from_utf8(r.body).unwrap().contains("not a whole number"));
    }

    #[test]
    fn valid_world_is_sent_as_a_new_world_command() {
        let c = presets::get("herbivore-only").unwrap();
        let (shared, handle) = one_reply(Reply::Done);
        let r = route("POST", "/api/world", &form(&c, true), &shared);
        assert_eq!(r.status, 200, "{}", String::from_utf8_lossy(&r.body));
        match handle.join().unwrap() {
            Command::NewWorld(sent) => assert_eq!(*sent, c),
            other => panic!("unexpected command {other:?}"),
        }
    }

    #[test]
    fn series_routes_answer_200_400_and_503() {
        let (shared, handle) = one_reply(Reply::Bytes(b"{\"tick\":[]}".to_vec()));
        let r = route("GET", "/api/series?since=4&trait=speed", &[], &shared);
        assert_eq!(r.status, 200);
        assert_eq!(
            handle.join().unwrap(),
            Command::Series { since: Some(4), trait_name: "speed".to_string() }
        );
        let (shared, _h) = one_reply(Reply::Error("unknown trait x".to_string()));
        assert_eq!(route("GET", "/api/series?trait=x", &[], &shared).status, 400);
        assert_eq!(route("GET", "/api/series", &[], &unread()).status, 400, "trait is required");
        assert_eq!(route("GET", "/api/series?trait=speed&since=abc", &[], &unread()).status, 400);
        assert_eq!(route("GET", "/api/series?trait=speed", &[], &unread()).status, 503, "no reader");
    }

    #[test]
    fn distribution_routes_check_kind_and_bins_before_sending() {
        assert_eq!(route("GET", "/api/distribution?kind=tree&trait=speed", &[], &unread()).status, 400);
        assert_eq!(route("GET", "/api/distribution?kind=plant&trait=speed&bins=many", &[], &unread()).status, 400);
        assert_eq!(route("GET", "/api/distribution?kind=plant", &[], &unread()).status, 400);
        let (shared, handle) = one_reply(Reply::Bytes(b"{\"n\":0}".to_vec()));
        assert_eq!(route("GET", "/api/distribution?kind=carnivore&trait=speed", &[], &shared).status, 200);
        assert_eq!(
            handle.join().unwrap(),
            Command::Distribution { kind: evosim_core::entities::Kind::Carnivore, trait_name: "speed".to_string(), bins: 20 }
        );
    }

    #[test]
    fn new_routes_have_their_methods_and_pages_are_served() {
        let s = unread();
        assert_eq!(route("GET", "/api/world", &[], &s).status, 405);
        assert_eq!(route("POST", "/api/presets", &[], &s).status, 405);
        assert_eq!(route("GET", "/api/config/check", &[], &s).status, 405);
        assert_eq!(route("POST", "/api/series", &[], &s).status, 405);
        assert_eq!(route("GET", "/api/nope", &[], &s).status, 404);
        assert_eq!(route("GET", "/setup.js", &[], &s).status, 200);
        assert_eq!(route("GET", "/charts.js", &[], &s).status, 200);
    }
}

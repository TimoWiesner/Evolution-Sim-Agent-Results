//! Configuration of a world set up in the page (ADR-0026 D1, D2, D3, D5). Pure: no threads, sockets or display.
//!
//! The page sends every field as the text the user typed. [`parse_fields`] checks the grammar of each value per
//! field, then builds a [`Config`] and validates it with the core rules (`Config::from_json`), so the page and the
//! simulation can never disagree about a range. Integers stay exact as text (the seed reaches 2^64-1).
//! Parameters the form does not show keep the value of the `base` configuration the page holds (a preset or an
//! imported file), so export followed by import gives the same `Config`.

use evosim_core::config::json::{self, Value};
use evosim_core::config::{presets, Config};

/// How a field is written: a whole number (`u64`) or a real number (`f64`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Number {
    Whole,
    Real,
}

/// One editable parameter: its dotted key (the same key as the configuration file), label and group.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct FieldSpec {
    pub key: &'static str,
    pub label: &'static str,
    pub group: &'static str,
    pub number: Number,
}

/// The editable parameters: the six required ones first, then the twelve further ones (ADR-0026 D1).
pub const FIELDS: &[FieldSpec] = &[
    FieldSpec { key: "seed", label: "Seed", group: "World", number: Number::Whole },
    FieldSpec { key: "world.width", label: "Width (cells)", group: "World", number: Number::Whole },
    FieldSpec { key: "world.height", label: "Height (cells)", group: "World", number: Number::Whole },
    FieldSpec { key: "initial.plants", label: "Plants at start", group: "Start", number: Number::Whole },
    FieldSpec { key: "initial.herbivores", label: "Herbivores at start", group: "Start", number: Number::Whole },
    FieldSpec { key: "initial.carnivores", label: "Carnivores at start", group: "Start", number: Number::Whole },
    FieldSpec { key: "climate.season_length", label: "Season length (ticks)", group: "Climate", number: Number::Whole },
    FieldSpec { key: "climate.weather_amplitude", label: "Weather swing", group: "Climate", number: Number::Real },
    FieldSpec { key: "plants.reproduction_chance", label: "Seeding chance per tick", group: "Plants", number: Number::Real },
    FieldSpec { key: "plants.seed_radius", label: "Seed radius (cells)", group: "Plants", number: Number::Whole },
    FieldSpec { key: "plants.max_age", label: "Plant max age (ticks)", group: "Plants", number: Number::Whole },
    FieldSpec { key: "herbivores.reproduction_energy", label: "Herbivore breeding energy", group: "Herbivores", number: Number::Real },
    FieldSpec { key: "herbivores.max_age", label: "Herbivore max age (ticks)", group: "Herbivores", number: Number::Whole },
    FieldSpec { key: "carnivores.reproduction_energy", label: "Carnivore breeding energy", group: "Carnivores", number: Number::Real },
    FieldSpec { key: "carnivores.max_age", label: "Carnivore max age (ticks)", group: "Carnivores", number: Number::Whole },
    FieldSpec { key: "genetics.mutation_rate", label: "Mutation rate per locus", group: "Genetics", number: Number::Real },
    FieldSpec { key: "genetics.mutation_strength", label: "Mutation strength", group: "Genetics", number: Number::Whole },
    FieldSpec { key: "species.distance", label: "Species distance", group: "Species", number: Number::Real },
];

/// Keys that must be present in every payload (the fixed keys of ADR-0026 D1).
pub const REQUIRED: &[&str] = &[
    "seed",
    "world.width",
    "world.height",
    "initial.plants",
    "initial.herbivores",
    "initial.carnivores",
];

/// One-line descriptions of the built-in presets (held here, not in the core; ADR-0026 D5).
const DESCRIPTIONS: &[(&str, &str)] = &[
    ("balanced", "The contract example: 64 x 48 cells, 400 plants, 120 herbivores, 20 carnivores, default rules."),
    ("arid", "The balanced start with scarce plants and strong seasonal swings."),
    ("continent", "A larger 128 x 96 world with more founders, faster mutation and wider species splitting."),
    ("herbivore-only", "The balanced start without carnivores: a food chain with no predators at tick 0."),
];

/// A problem with one field. `key` is `None` for an error that belongs to the whole form.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FieldError {
    pub key: Option<String>,
    pub message: String,
}

impl FieldError {
    fn at(key: &str, message: impl Into<String>) -> FieldError {
        FieldError { key: Some(key.to_string()), message: message.into() }
    }
}

/// A typed value of one field.
#[derive(Clone, Copy, Debug, PartialEq)]
enum Typed {
    Whole(u64),
    Real(f64),
}

/// Minimal configuration with every value at a valid placeholder, used when the page has no base configuration.
const BLANK: &str = r#"{"seed": 0, "world": {"width": 1, "height": 1}, "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#;

/// Looks up an editable field by key.
pub fn spec(key: &str) -> Option<&'static FieldSpec> {
    FIELDS.iter().find(|f| f.key == key)
}

/// Grammar of a whole number: optional sign, then digits. Negative values and values above `u64::MAX` are errors here;
/// the core range rules handle the rest.
pub fn parse_whole(text: &str) -> Result<u64, String> {
    if text.is_empty() {
        return Err("missing value".to_string());
    }
    let digits = text.strip_prefix('-').unwrap_or(text);
    if digits.is_empty() || !digits.bytes().all(|b| b.is_ascii_digit()) {
        return Err("not a whole number".to_string());
    }
    if text.starts_with('-') {
        return Err("must not be negative".to_string());
    }
    digits.parse::<u64>().map_err(|_| "is too large".to_string())
}

/// Grammar of a real number: digits, one sign per exponent, a point and `e`. Infinity and NaN are not numbers here.
pub fn parse_real(text: &str) -> Result<f64, String> {
    if text.is_empty() {
        return Err("missing value".to_string());
    }
    if !text.bytes().all(|b| b.is_ascii_digit() || matches!(b, b'.' | b'-' | b'+' | b'e' | b'E')) {
        return Err("not a number".to_string());
    }
    match text.parse::<f64>() {
        Ok(x) if x.is_finite() => Ok(x),
        _ => Err("not a number".to_string()),
    }
}

fn parse_typed(number: Number, text: &str) -> Result<Typed, String> {
    match number {
        Number::Whole => parse_whole(text).map(Typed::Whole),
        Number::Real => parse_real(text).map(Typed::Real),
    }
}

fn assign(c: &mut Config, key: &str, value: Typed) {
    match (key, value) {
        ("seed", Typed::Whole(v)) => c.seed = v,
        ("world.width", Typed::Whole(v)) => c.world.width = v,
        ("world.height", Typed::Whole(v)) => c.world.height = v,
        ("initial.plants", Typed::Whole(v)) => c.initial.plants = v,
        ("initial.herbivores", Typed::Whole(v)) => c.initial.herbivores = v,
        ("initial.carnivores", Typed::Whole(v)) => c.initial.carnivores = v,
        ("climate.season_length", Typed::Whole(v)) => c.climate.season_length = v,
        ("climate.weather_amplitude", Typed::Real(v)) => c.climate.weather_amplitude = v,
        ("plants.reproduction_chance", Typed::Real(v)) => c.plants.reproduction_chance = v,
        ("plants.seed_radius", Typed::Whole(v)) => c.plants.seed_radius = v,
        ("plants.max_age", Typed::Whole(v)) => c.plants.max_age = v,
        ("herbivores.reproduction_energy", Typed::Real(v)) => c.herbivores.reproduction_energy = v,
        ("herbivores.max_age", Typed::Whole(v)) => c.herbivores.max_age = v,
        ("carnivores.reproduction_energy", Typed::Real(v)) => c.carnivores.reproduction_energy = v,
        ("carnivores.max_age", Typed::Whole(v)) => c.carnivores.max_age = v,
        ("genetics.mutation_rate", Typed::Real(v)) => c.genetics.mutation_rate = v,
        ("genetics.mutation_strength", Typed::Whole(v)) => c.genetics.mutation_strength = v,
        ("species.distance", Typed::Real(v)) => c.species.distance = v,
        _ => {}
    }
}

/// The text of one editable field of `c`. Reals use the shortest text that reads back to the same `f64`.
fn read(c: &Config, key: &str) -> String {
    match key {
        "seed" => c.seed.to_string(),
        "world.width" => c.world.width.to_string(),
        "world.height" => c.world.height.to_string(),
        "initial.plants" => c.initial.plants.to_string(),
        "initial.herbivores" => c.initial.herbivores.to_string(),
        "initial.carnivores" => c.initial.carnivores.to_string(),
        "climate.season_length" => c.climate.season_length.to_string(),
        "climate.weather_amplitude" => c.climate.weather_amplitude.to_string(),
        "plants.reproduction_chance" => c.plants.reproduction_chance.to_string(),
        "plants.seed_radius" => c.plants.seed_radius.to_string(),
        "plants.max_age" => c.plants.max_age.to_string(),
        "herbivores.reproduction_energy" => c.herbivores.reproduction_energy.to_string(),
        "herbivores.max_age" => c.herbivores.max_age.to_string(),
        "carnivores.reproduction_energy" => c.carnivores.reproduction_energy.to_string(),
        "carnivores.max_age" => c.carnivores.max_age.to_string(),
        "genetics.mutation_rate" => c.genetics.mutation_rate.to_string(),
        "genetics.mutation_strength" => c.genetics.mutation_strength.to_string(),
        "species.distance" => c.species.distance.to_string(),
        _ => String::new(),
    }
}

/// The form fields of `c`, in `FIELDS` order (ADR-0026 D2).
pub fn fields_of(c: &Config) -> Vec<(String, String)> {
    FIELDS.iter().map(|f| (f.key.to_string(), read(c, f.key))).collect()
}

/// Builds the configuration from the typed fields. `base` supplies every parameter the form does not show; without
/// it the core defaults apply. Fails with per-field errors, or with the first core rule that the values break.
pub fn parse_fields(fields: &[(String, String)], base: Option<&Config>) -> Result<Config, Vec<FieldError>> {
    let mut errors = Vec::new();
    let mut typed = Vec::new();
    for (key, text) in fields {
        match spec(key) {
            None => errors.push(FieldError::at(key, "unknown field")),
            Some(f) => match parse_typed(f.number, text) {
                Ok(value) => typed.push((f.key, value)),
                Err(message) => errors.push(FieldError::at(key, message)),
            },
        }
    }
    for required in REQUIRED {
        if !fields.iter().any(|(k, _)| k == required) {
            errors.push(FieldError::at(required, "missing required field"));
        }
    }
    if !errors.is_empty() {
        return Err(errors);
    }
    let mut c = match base {
        Some(b) => b.clone(),
        None => Config::from_json(BLANK).map_err(|e| vec![FieldError { key: e.key, message: e.message }])?,
    };
    for (key, value) in typed {
        assign(&mut c, key, value);
    }
    // The core rules check every range; the text is re-read by the same path as a configuration file.
    Config::from_json(&c.to_json()).map_err(|e| vec![FieldError { key: e.key, message: e.message }])
}

/// A JSON string literal (escapes done by the core's JSON writer).
pub fn json_string(s: &str) -> String {
    json::write(&Value::Str(s.to_string()))
}

/// `{"key":"value",...}` for the given pairs.
pub fn fields_json(fields: &[(String, String)]) -> String {
    let pairs: Vec<String> = fields.iter().map(|(k, v)| format!("{}:{}", json_string(k), json_string(v))).collect();
    format!("{{{}}}", pairs.join(","))
}

/// `{"ok":false,"errors":[{"key":...,"message":...}]}`, the body of every HTTP 422 of the configuration routes.
pub fn errors_json(errors: &[FieldError]) -> String {
    let items: Vec<String> = errors
        .iter()
        .map(|e| {
            let key = match &e.key {
                Some(k) => json_string(k),
                None => "null".to_string(),
            };
            format!("{{\"key\":{key},\"message\":{}}}", json_string(&e.message))
        })
        .collect();
    format!("{{\"ok\":false,\"errors\":[{}]}}", items.join(","))
}

/// The body of `POST /api/config/check` and `POST /api/world`: a JSON object of field texts, plus `"base"`, the text
/// of the configuration whose hidden parameters the form keeps.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Request {
    pub fields: Vec<(String, String)>,
    pub base: Option<String>,
}

/// Reads a request body. Every value except `base` must be a string.
pub fn parse_request(body: &[u8]) -> Result<Request, String> {
    let text = std::str::from_utf8(body).map_err(|_| "the body is not UTF-8".to_string())?;
    let Value::Object(pairs) = json::parse(text)? else {
        return Err("the body must be a JSON object".to_string());
    };
    let mut fields = Vec::new();
    let mut base = None;
    for (key, value) in pairs {
        match (key.as_str(), value) {
            ("base", Value::Str(s)) => base = Some(s),
            ("base", _) => return Err("base must be a string".to_string()),
            (_, Value::Str(s)) => fields.push((key, s)),
            (_, _) => return Err(format!("field {key} must be a string")),
        }
    }
    Ok(Request { fields, base })
}

/// The configuration of a request: the base text (if any) is parsed first, then the fields are applied.
pub fn request_config(request: &Request) -> Result<Config, Vec<FieldError>> {
    let base = match &request.base {
        Some(text) => Some(Config::from_json(text).map_err(|e| vec![FieldError { key: e.key, message: e.message }])?),
        None => None,
    };
    parse_fields(&request.fields, base.as_ref())
}

/// `GET /api/presets`: every built-in preset with its description, its field texts and its full configuration text.
pub fn presets_json() -> String {
    let items: Vec<String> = presets::NAMES
        .iter()
        .filter_map(|name| {
            let config = presets::get(name)?;
            let description = DESCRIPTIONS.iter().find(|(n, _)| n == name).map(|(_, d)| *d).unwrap_or("");
            Some(format!(
                "{{\"name\":{},\"description\":{},\"fields\":{},\"config\":{}}}",
                json_string(name),
                json_string(description),
                fields_json(&fields_of(&config)),
                json_string(&config.to_json())
            ))
        })
        .collect();
    format!("[{}]", items.join(","))
}

/// The form fields of an imported configuration (the response of `POST /api/config/import`).
pub fn import_json(c: &Config) -> String {
    format!("{{\"ok\":true,\"fields\":{}}}", fields_json(&fields_of(c)))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn base() -> Config {
        presets::get("balanced").unwrap()
    }

    fn with(fields: &[(&str, &str)]) -> Vec<(String, String)> {
        let mut all = fields_of(&base());
        for (k, v) in fields {
            let slot = all.iter_mut().find(|(key, _)| key == k).expect("known key");
            slot.1 = v.to_string();
        }
        all
    }

    fn first_error(fields: &[(String, String)]) -> FieldError {
        let errors = parse_fields(fields, Some(&base())).unwrap_err();
        assert_eq!(errors.len(), 1, "{errors:?}");
        errors.into_iter().next().unwrap()
    }

    #[test]
    fn form_has_six_required_and_twelve_further_fields() {
        assert_eq!(FIELDS.len(), 18);
        assert_eq!(REQUIRED.len(), 6);
        for key in REQUIRED {
            assert!(spec(key).is_some(), "{key}");
        }
        let keys: Vec<&str> = FIELDS.iter().map(|f| f.key).collect();
        for hidden in ["plants.growth_rate", "herbivores.metabolism", "carnivores.metabolism"] {
            assert!(!keys.contains(&hidden), "{hidden} is not used by the engine and is not offered");
        }
    }

    #[test]
    fn whole_numbers_follow_the_grammar() {
        assert_eq!(parse_whole("64"), Ok(64));
        assert_eq!(parse_whole("007"), Ok(7));
        assert_eq!(parse_whole("18446744073709551615"), Ok(u64::MAX));
        assert_eq!(parse_whole(""), Err("missing value".to_string()));
        assert_eq!(parse_whole("abc"), Err("not a whole number".to_string()));
        assert_eq!(parse_whole("64.0"), Err("not a whole number".to_string()));
        assert_eq!(parse_whole("1e3"), Err("not a whole number".to_string()));
        assert_eq!(parse_whole(" 64"), Err("not a whole number".to_string()));
        assert_eq!(parse_whole("-3"), Err("must not be negative".to_string()));
        assert_eq!(parse_whole("18446744073709551616"), Err("is too large".to_string()));
    }

    #[test]
    fn real_numbers_follow_the_grammar() {
        assert_eq!(parse_real("0.1"), Ok(0.1));
        assert_eq!(parse_real("1e-7"), Ok(1e-7));
        assert_eq!(parse_real("0.5"), Ok(0.5));
        assert_eq!(parse_real("inf"), Err("not a number".to_string()));
        assert_eq!(parse_real("NaN"), Err("not a number".to_string()));
        assert_eq!(parse_real("1,5"), Err("not a number".to_string()));
        assert_eq!(parse_real("1e400"), Err("not a number".to_string()));
        assert_eq!(parse_real(""), Err("missing value".to_string()));
    }

    #[test]
    fn non_numeric_text_is_an_error_at_its_field() {
        let e = first_error(&with(&[("world.width", "wide")]));
        assert_eq!(e, FieldError::at("world.width", "not a whole number"));
    }

    #[test]
    fn whole_field_with_a_real_text_is_an_error_at_its_field() {
        let e = first_error(&with(&[("initial.plants", "64.0")]));
        assert_eq!(e, FieldError::at("initial.plants", "not a whole number"));
    }

    #[test]
    fn empty_field_is_an_error_at_its_field() {
        let e = first_error(&with(&[("species.distance", "")]));
        assert_eq!(e, FieldError::at("species.distance", "missing value"));
    }

    #[test]
    fn out_of_range_values_name_the_core_key() {
        let e = first_error(&with(&[("world.width", "0")]));
        assert_eq!(e.key.as_deref(), Some("world.width"));
        assert!(e.message.contains("out of range"), "{}", e.message);
        let e = first_error(&with(&[("climate.weather_amplitude", "1.5")]));
        assert_eq!(e.key.as_deref(), Some("climate.weather_amplitude"));
        let e = first_error(&with(&[("genetics.mutation_strength", "300")]));
        assert_eq!(e.key.as_deref(), Some("genetics.mutation_strength"));
    }

    #[test]
    fn unknown_field_and_missing_required_field_are_errors() {
        let mut fields = with(&[]);
        fields.push(("plants.growth_rate".to_string(), "0.1".to_string()));
        let e = first_error(&fields);
        assert_eq!(e, FieldError::at("plants.growth_rate", "unknown field"));
        let fields: Vec<(String, String)> = fields_of(&base()).into_iter().filter(|(k, _)| k != "seed").collect();
        let e = first_error(&fields);
        assert_eq!(e, FieldError::at("seed", "missing required field"));
    }

    #[test]
    fn every_error_of_one_payload_is_reported() {
        let errors = parse_fields(&with(&[("world.width", "x"), ("seed", "-1")]), Some(&base())).unwrap_err();
        assert_eq!(errors.len(), 2, "{errors:?}");
    }

    #[test]
    fn round_trip_of_defaults_and_presets() {
        let blank = Config::from_json(BLANK).unwrap();
        assert_eq!(parse_fields(&fields_of(&blank), Some(&blank)).unwrap(), blank);
        assert_eq!(parse_fields(&fields_of(&blank), None).unwrap(), blank);
        for name in presets::NAMES {
            let c = presets::get(name).unwrap();
            assert_eq!(parse_fields(&fields_of(&c), Some(&c)).unwrap(), c, "{name}");
        }
    }

    #[test]
    fn export_then_import_gives_an_equal_configuration() {
        let mut c = presets::get("arid").unwrap();
        c.seed = u64::MAX;
        c.climate.weather_amplitude = 0.1;
        c.genetics.mutation_rate = 1e-7;
        c.species.distance = 0.1;
        c.plants.growth_rate = 0.04; // hidden parameter, kept through the base
        let exported = c.to_json();
        let imported = Config::from_json(&exported).unwrap();
        assert_eq!(imported, c);
        let fields = fields_of(&imported);
        assert_eq!(fields.iter().find(|(k, _)| k == "seed").unwrap().1, "18446744073709551615");
        let back = parse_fields(&fields, Some(&imported)).unwrap();
        assert_eq!(back, c);
        assert_eq!(Config::from_json(&back.to_json()).unwrap(), c);
    }

    #[test]
    fn hidden_parameters_come_from_the_base_configuration() {
        let arid = presets::get("arid").unwrap();
        assert_eq!(parse_fields(&fields_of(&arid), Some(&arid)).unwrap().plants.growth_rate, 0.04);
        let without = parse_fields(&fields_of(&arid), None).unwrap();
        assert_ne!(without.plants.growth_rate, 0.04, "no base means the core default");
    }

    #[test]
    fn typed_values_reach_the_configuration() {
        let c = parse_fields(&with(&[("seed", "7"), ("world.width", "80"), ("climate.season_length", "300")]), None)
            .unwrap();
        assert_eq!((c.seed, c.world.width, c.climate.season_length), (7, 80, 300));
    }

    #[test]
    fn presets_json_lists_every_preset_with_its_text() {
        let json = presets_json();
        let Value::Array(items) = json::parse(&json).unwrap() else {
            panic!("not an array: {json}");
        };
        assert_eq!(items.len(), presets::NAMES.len());
        for item in &items {
            let Value::Object(fields) = item else { panic!() };
            let config_text = fields.iter().find(|(k, _)| k == "config").map(|(_, v)| v).unwrap();
            let Value::Str(text) = config_text else { panic!() };
            assert!(Config::from_json(text).is_ok());
        }
        assert!(json.contains("\"name\":\"herbivore-only\""));
    }

    #[test]
    fn request_body_must_be_an_object_of_strings() {
        assert!(parse_request(b"[1,2]").is_err());
        assert!(parse_request(b"{\"seed\":42}").is_err(), "numbers are not accepted: they lose precision");
        assert!(parse_request(b"not json").is_err());
        assert!(parse_request(&[0xff, 0xfe]).is_err());
        let r = parse_request(br#"{"seed":"42","base":"{}"}"#).unwrap();
        assert_eq!(r.fields, vec![("seed".to_string(), "42".to_string())]);
        assert_eq!(r.base.as_deref(), Some("{}"));
        assert!(parse_request(br#"{"base":5}"#).is_err());
    }

    #[test]
    fn request_base_errors_are_reported_as_configuration_errors() {
        let r = Request { fields: fields_of(&base()), base: Some("{\"seed\":-1}".to_string()) };
        let errors = request_config(&r).unwrap_err();
        assert_eq!(errors.len(), 1);
        assert_eq!(errors[0].key.as_deref(), Some("seed"));
    }

    #[test]
    fn errors_json_names_keys_and_form_level_errors() {
        let json = errors_json(&[
            FieldError::at("world.width", "not a whole number"),
            FieldError { key: None, message: "bad \"quote\"".to_string() },
        ]);
        let v = json::parse(&json).unwrap();
        let Value::Object(top) = v else { panic!() };
        assert!(top.iter().any(|(k, v)| k == "ok" && matches!(v, Value::Bool(false))));
        assert!(json.contains("\"key\":\"world.width\""), "{json}");
        assert!(json.contains("\"key\":null"), "{json}");
        assert!(json.contains("bad \\\"quote\\\""), "{json}");
    }

    #[test]
    fn import_response_round_trips_the_fields() {
        let c = presets::get("continent").unwrap();
        let body = import_json(&c);
        let Value::Object(top) = json::parse(&body).unwrap() else { panic!() };
        let Some((_, Value::Object(fields))) = top.iter().find(|(k, _)| k == "fields") else { panic!() };
        assert_eq!(fields.len(), FIELDS.len());
    }
}

//! Simulation thread, the three UI modes (serve, smoke test, screenshots) and the Chromium driver (ADR-0024 D2, D7, D8;
//! ADR-0025 D1, D2: the thread applies queued commands and runs the ticks due at the current speed).

use crate::control::Session;
use crate::server::{self, Envelope, Shared};
use crate::snapshot;
use evosim_core::config::Config;
use std::fs::File;
use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::sync::mpsc::Receiver;
use std::sync::Arc;
use std::time::{Duration, Instant};

/// How long the simulation thread sleeps between passes. Ticks due are computed from the elapsed time, so the
/// speed does not depend on this value.
pub const LOOP_SLEEP: Duration = Duration::from_millis(5);

/// Budgets of the UI modes (CONTRACT section 2 allows 60 s for `--smoke-test` and 120 s for `--screenshots`).
/// Worst case: smoke 10 s + 35 s = 45 s; screenshots 30 s + 60 s = 90 s. Normal runs take about 1 s and 5 s.
pub const SMOKE_WAIT: Duration = Duration::from_secs(10);
pub const SMOKE_CHROMIUM: Duration = Duration::from_secs(35);
pub const SHOT_WAIT: Duration = Duration::from_secs(30);
pub const SHOT_CHROMIUM: Duration = Duration::from_secs(60);

/// A started UI: the server address and the shared state. The simulation and server threads run until the process exits.
pub struct Running {
    pub addr: SocketAddr,
    pub shared: Arc<Shared>,
}

/// Builds the session for `config` (the session starts running) and starts the server on `127.0.0.1:port` and the
/// simulation thread.
pub fn start(config: &Config, port: u16) -> Result<Running, String> {
    let session = Session::new(config)?;
    let (commands, queue) = server::command_channel();
    let shared = Arc::new(Shared::new(
        snapshot::climate_json(session.simulation()).into_bytes(),
        snapshot::state_json(&session).into_bytes(),
        session.simulation().tick_count(),
        commands,
    ));
    let listener = server::bind(port).map_err(|e| format!("cannot listen on 127.0.0.1:{port}: {e}"))?;
    let addr = listener
        .local_addr()
        .map_err(|e| format!("cannot read the listening address: {e}"))?;
    {
        let shared = shared.clone();
        std::thread::spawn(move || server::serve(listener, shared));
    }
    {
        let shared = shared.clone();
        std::thread::spawn(move || simulate(session, queue, shared));
    }
    Ok(Running { addr, shared })
}

/// Publishes what the page reads: the climate first when the base layer changed, then the state, then the inspector.
fn publish(session: &Session, shared: &Shared, climate_version: &mut u64) {
    if session.climate_version() != *climate_version {
        shared.publish_climate(snapshot::climate_json(session.simulation()).into_bytes());
        *climate_version = session.climate_version();
    }
    shared.publish(snapshot::state_json(session).into_bytes(), session.simulation().tick_count());
    shared.publish_watch(session.watch_body().map(|(id, body)| (id, body.into_bytes())));
}

/// The simulation thread (ADR-0025 D2): applies the queued commands between ticks, runs the ticks due at the current
/// speed, and publishes after every change. The HTTP threads never touch the session.
fn simulate(mut session: Session, queue: Receiver<Envelope>, shared: Arc<Shared>) {
    let mut climate_version = session.climate_version();
    publish(&session, &shared, &mut climate_version);
    let mut last = Instant::now();
    loop {
        let mut changed = false;
        while let Ok(envelope) = queue.try_recv() {
            let reply = session.apply(envelope.command);
            // The page that sent the command may have gone away; the change still stands.
            let _ = envelope.reply.send(reply);
            changed = true;
        }
        let now = Instant::now();
        let ticks = session.pump(now - last);
        last = now;
        if changed || ticks > 0 {
            publish(&session, &shared, &mut climate_version);
        }
        std::thread::sleep(LOOP_SLEEP);
    }
}

/// `evosim ui`: serves until the process is stopped.
pub fn serve(config: &Config, port: u16) -> Result<(), String> {
    let running = start(config, port)?;
    eprintln!("evosim ui: http://{}/", running.addr);
    loop {
        std::thread::park();
    }
}

/// Waits until the simulation has reached `target` ticks or `timeout` has passed.
pub fn wait_for_tick(running: &Running, target: u64, timeout: Duration) -> Result<(), String> {
    let start = Instant::now();
    while running.shared.tick() < target {
        if start.elapsed() > timeout {
            return Err(format!("simulation reached only tick {} of {target}", running.shared.tick()));
        }
        std::thread::sleep(Duration::from_millis(20));
    }
    Ok(())
}

/// `evosim ui --smoke-test` (CONTRACT section 2): the real page runs in Chromium against the live server; it
/// polls until tick >= 10 and writes `<title>smoke frames=N tick=T</title>`. Accepted only with N >= 1 and T >= 10.
/// Returns the marker text on success.
pub fn smoke_test(config: &Config) -> Result<String, String> {
    let running = start(config, 0)?;
    wait_for_tick(&running, 10, SMOKE_WAIT)?;
    let url = format!("http://{}/?smoke=1", running.addr);
    let dom = run_chromium(&[url], &["--dump-dom"], SMOKE_CHROMIUM)?;
    let text = String::from_utf8_lossy(&dom).into_owned();
    let marker = text
        .find("<title>smoke frames=")
        .map(|at| &text[at + "<title>".len()..])
        .and_then(|rest| rest.split("</title>").next())
        .ok_or_else(|| "smoke test: the page did not write its marker".to_string())?;
    let (frames, tick) = parse_marker(marker).ok_or_else(|| format!("smoke test: bad marker '{marker}'"))?;
    if frames < 1 || tick < 10 {
        return Err(format!("smoke test: marker '{marker}' is below the required frames >= 1, tick >= 10"));
    }
    Ok(marker.to_string())
}

/// Parses `smoke frames=N tick=T`.
pub fn parse_marker(marker: &str) -> Option<(u64, u64)> {
    let mut frames = None;
    let mut tick = None;
    for word in marker.split_whitespace() {
        if let Some(v) = word.strip_prefix("frames=") {
            frames = v.parse().ok();
        } else if let Some(v) = word.strip_prefix("tick=") {
            tick = v.parse().ok();
        }
    }
    Some((frames?, tick?))
}

/// `evosim ui --screenshots DIR` (CONTRACT section 2): waits for tick >= 100, then Chromium takes two PNGs of the real
/// page: `DIR/main.png` (`?shot=1`, the whole interface) and `DIR/charts.png` (`?shot=1&view=charts`, the charts in the
/// main area, ADR-0026 D9). Both files are checked to be PNGs of at least 1280 x 720 pixels. Returns both paths.
pub fn screenshots(config: &Config, dir: &Path) -> Result<Vec<PathBuf>, String> {
    let running = start(config, 0)?;
    wait_for_tick(&running, 100, SHOT_WAIT)?;
    let mut written = Vec::new();
    for (name, query) in [("main.png", "?shot=1"), ("charts.png", "?shot=1&view=charts")] {
        let out = dir.join(name);
        let url = format!("http://{}/{query}", running.addr);
        let shot_arg = format!("--screenshot={}", out.display());
        run_chromium(&[url], &[shot_arg.as_str()], SHOT_CHROMIUM)?;
        check_png_size(&out, 1280, 720)?;
        written.push(out);
    }
    Ok(written)
}

/// Reads the IHDR chunk of a PNG and checks the size is at least `min_w` x `min_h`.
pub fn check_png_size(path: &Path, min_w: u32, min_h: u32) -> Result<(), String> {
    let bytes = std::fs::read(path).map_err(|e| format!("cannot read {}: {e}", path.display()))?;
    if bytes.len() < 24 || &bytes[..8] != b"\x89PNG\r\n\x1a\n" || &bytes[12..16] != b"IHDR" {
        return Err(format!("{} is not a PNG file", path.display()));
    }
    let w = u32::from_be_bytes([bytes[16], bytes[17], bytes[18], bytes[19]]);
    let h = u32::from_be_bytes([bytes[20], bytes[21], bytes[22], bytes[23]]);
    if w < min_w || h < min_h {
        return Err(format!("{} is {w}x{h}, need at least {min_w}x{min_h}", path.display()));
    }
    Ok(())
}

/// The Chromium binary: `CHROME_BIN` when set, otherwise `chromium` on `PATH` (ADR-0002).
pub fn find_chromium() -> Result<PathBuf, String> {
    if let Some(bin) = std::env::var_os("CHROME_BIN").filter(|v| !v.is_empty()) {
        return Ok(PathBuf::from(bin));
    }
    let path = std::env::var_os("PATH").unwrap_or_default();
    std::env::split_paths(&path)
        .map(|dir| dir.join("chromium"))
        .find(|candidate| candidate.is_file())
        .ok_or_else(|| "chromium not found: set CHROME_BIN or put chromium on PATH".to_string())
}

/// Runs headless Chromium with the given URL(s) and extra flags, as root-safe as the container needs. Stdout goes to a
/// temporary file (not a pipe, so lingering Chromium children cannot block the reader). The child is killed after
/// `timeout`. Returns the stdout bytes on exit status 0.
pub fn run_chromium(urls: &[String], extra: &[&str], timeout: Duration) -> Result<Vec<u8>, String> {
    let bin = find_chromium()?;
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    let scratch = std::env::temp_dir().join(format!("evosim-ui-{}-{stamp}", std::process::id()));
    std::fs::create_dir_all(&scratch).map_err(|e| format!("cannot create {}: {e}", scratch.display()))?;
    let stdout_path = scratch.join("stdout");
    let stdout = File::create(&stdout_path).map_err(|e| format!("cannot create {}: {e}", stdout_path.display()))?;
    let mut child = Command::new(&bin)
        .args([
            "--headless",
            "--no-sandbox",
            "--disable-gpu",
            "--disable-dev-shm-usage",
            "--no-first-run",
            // Headless Chromium 131 reserves about 87 px of window chrome: 807 px of window gives a 1280x720 viewport.
            "--window-size=1280,807",
            "--virtual-time-budget=5000",
        ])
        .arg(format!("--user-data-dir={}", scratch.join("profile").display()))
        .args(extra)
        .args(urls)
        .stdin(Stdio::null())
        .stdout(Stdio::from(stdout))
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("cannot start {}: {e}", bin.display()))?;
    let start = Instant::now();
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break Some(status),
            Ok(None) if start.elapsed() > timeout => {
                let _ = child.kill();
                let _ = child.wait();
                break None;
            }
            Ok(None) => std::thread::sleep(Duration::from_millis(50)),
            Err(e) => return Err(format!("cannot wait for chromium: {e}")),
        }
    };
    let output = std::fs::read(&stdout_path).unwrap_or_default();
    let _ = std::fs::remove_dir_all(&scratch);
    match status {
        None => Err(format!("chromium did not finish within {} s", timeout.as_secs())),
        Some(s) if !s.success() => Err(format!("chromium exited with {s}")),
        Some(_) => Ok(output),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn marker_is_parsed() {
        assert_eq!(parse_marker("smoke frames=3 tick=12"), Some((3, 12)));
        assert_eq!(parse_marker("smoke frames=3"), None);
    }

    #[test]
    fn mode_budgets_stay_inside_the_contract_limits() {
        assert!(SMOKE_WAIT + SMOKE_CHROMIUM <= Duration::from_secs(60));
        assert!(SHOT_WAIT + SHOT_CHROMIUM <= Duration::from_secs(120));
    }

    #[test]
    fn png_size_check_reads_ihdr() {
        let dir = std::env::temp_dir().join(format!("evosim-ui-png-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("a.png");
        let mut bytes = b"\x89PNG\r\n\x1a\n".to_vec();
        bytes.extend_from_slice(&13u32.to_be_bytes());
        bytes.extend_from_slice(b"IHDR");
        bytes.extend_from_slice(&1280u32.to_be_bytes());
        bytes.extend_from_slice(&720u32.to_be_bytes());
        std::fs::write(&path, &bytes).unwrap();
        assert!(check_png_size(&path, 1280, 720).is_ok());
        assert!(check_png_size(&path, 1281, 720).is_err());
        std::fs::write(&path, b"not a png at all, just text").unwrap();
        assert!(check_png_size(&path, 1, 1).is_err());
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn live_server_answers_state_with_increasing_tick() {
        let config = Config::from_json(
            r#"{"seed": 42, "world": {"width": 16, "height": 12},
                "initial": {"plants": 40, "herbivores": 10, "carnivores": 3}}"#,
        )
        .unwrap();
        let running = start(&config, 0).unwrap();
        let first = running.shared.tick();
        wait_for_tick(&running, first + 3, Duration::from_secs(10)).unwrap();
        let body = http_get(running.addr, "/api/state");
        assert!(body.starts_with("{\"tick\":"), "{body}");
        let tick: u64 = body[8..].split(',').next().unwrap().parse().unwrap();
        assert!(tick >= first + 3);
        // The founders are present: 40 plants, 10 herbivores, 3 carnivores at the start, so the counts are not zero.
        assert!(!body.contains("\"organisms\":[]"), "organisms listed: {body}");
    }

    /// Minimal HTTP/1.1 GET for the test: returns the body.
    fn http_get(addr: SocketAddr, path: &str) -> String {
        use std::io::{Read, Write};
        let mut stream = std::net::TcpStream::connect(addr).unwrap();
        write!(stream, "GET {path} HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n").unwrap();
        let mut text = String::new();
        stream.read_to_string(&mut text).unwrap();
        assert!(text.starts_with("HTTP/1.1 200"), "{text}");
        text.split("\r\n\r\n").nth(1).unwrap().to_string()
    }

    /// Ignored by default: builds the 1,000-organism world, times `step` and `state_json` over 200 ticks.
    /// Run with `cargo test -p evosim-ui --release -- --ignored --nocapture ui_1000_organisms_timing`.
    #[test]
    #[ignore]
    fn ui_1000_organisms_timing() {
        // The same config the UI runs (ADR-0024 D16): examples/ui-1000.json, 1,000 organisms at tick 0.
        let config = Config::from_json(include_str!("../../../examples/ui-1000.json")).unwrap();
        let mut session = Session::new(&config).unwrap();
        session.pause();
        let mut encode = Duration::ZERO;
        let mut ticks = Duration::ZERO;
        for _ in 0..200 {
            let t = Instant::now();
            session.step().unwrap();
            ticks += t.elapsed();
            let t = Instant::now();
            let _ = snapshot::state_json(&session);
            encode += t.elapsed();
        }
        let living = session.simulation().entities().living().count();
        println!(
            "ui-1000: living={living} tick={} sim_tick_avg={:.3} ms snapshot_avg={:.3} ms",
            session.simulation().tick_count(),
            ticks.as_secs_f64() * 1000.0 / 200.0,
            encode.as_secs_f64() * 1000.0 / 200.0
        );
    }
}

//! Pure JSON builders for the UI API (ADR-0024 D3, D4). No I/O, no threads: unit-testable on any simulation.

use crate::control::Session;
use evosim_core::entities::Kind;
use evosim_core::sim::Simulation;

/// Upper bound of organisms in one `/api/state` snapshot (ADR-0024 D4).
pub const MAX_ORGANISMS: usize = 10_000;

/// Live state: `{"tick", "counts", "control", "organisms": [[id, kind, x, y], ...]}` (ADR-0025 D3). Organisms are in
/// ascending id order; `kind` is 0 plant, 1 herbivore, 2 carnivore. `counts` are complete; `organisms` is capped at
/// [`MAX_ORGANISMS`]. `control` is the session's run controls (running, speed, selection, seed, climate version).
pub fn state_json(session: &Session) -> String {
    let sim = session.simulation();
    let entities = sim.entities();
    let mut out = format!(
        "{{\"tick\":{},\"counts\":{{\"plants\":{},\"herbivores\":{},\"carnivores\":{}}},\"control\":{},\"organisms\":[",
        sim.tick_count(),
        entities.living_count(Kind::Plant),
        entities.living_count(Kind::Herbivore),
        entities.living_count(Kind::Carnivore),
        session.control_json(),
    );
    for (n, organism) in entities.living().take(MAX_ORGANISMS).enumerate() {
        if n > 0 {
            out.push(',');
        }
        let cell = organism.cell();
        out.push_str(&format!(
            "[{},{},{},{}]",
            organism.id().0,
            organism.kind().index(),
            cell.x(),
            cell.y()
        ));
    }
    out.push_str("]}");
    out
}

/// Static base layer: `{"width", "height", "biome"}` where `biome` holds one glyph per cell, row-major (ADR-0024 D3).
pub fn climate_json(sim: &Simulation) -> String {
    let world = sim.world();
    let torus = &world.topology;
    let mut biome = String::with_capacity(torus.cell_count());
    for index in 0..torus.cell_count() {
        if let Some(cell) = torus.cell_from_index(index) {
            biome.push(world.climate.at(cell).biome.glyph());
        }
    }
    format!(
        "{{\"width\":{},\"height\":{},\"biome\":\"{}\"}}",
        torus.width(),
        torus.height(),
        biome
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use evosim_core::config::Config;

    fn session_from(json: &str) -> Session {
        Session::new(&Config::from_json(json).unwrap()).unwrap()
    }

    fn sim_from(json: &str) -> Simulation {
        Simulation::new(&Config::from_json(json).unwrap()).unwrap()
    }

    #[test]
    fn state_lists_living_organisms_in_id_order_with_kind_codes() {
        let mut session = session_from(
            r#"{"seed": 3, "world": {"width": 10, "height": 8},
                "initial": {"plants": 12, "herbivores": 4, "carnivores": 2}}"#,
        );
        session.pause();
        for _ in 0..5 {
            session.step().unwrap();
        }
        let sim = session.simulation();
        let json = state_json(&session);
        assert!(json.starts_with("{\"tick\":5,"), "{json}");
        let total = sim.entities().living().count();
        let organisms = &json[json.find("\"organisms\":[").unwrap() + "\"organisms\":[".len()..];
        assert_eq!(organisms.matches('[').count(), total, "one entry per living organism");
        let ids: Vec<u64> = sim.entities().living().map(|o| o.id().0).collect();
        assert!(ids.windows(2).all(|w| w[0] < w[1]), "ascending ids");
        assert!(json.contains("\"plants\":"));
        assert!(json.contains(&format!(
            "\"herbivores\":{}",
            sim.entities().living_count(Kind::Herbivore)
        )));
    }

    #[test]
    fn state_has_the_control_block() {
        let mut session = session_from(
            r#"{"seed": 3, "world": {"width": 6, "height": 6},
                "initial": {"plants": 4, "herbivores": 1, "carnivores": 0}}"#,
        );
        let json = state_json(&session);
        assert!(json.contains("\"control\":{\"running\":true,\"speed\":20,\"speed_index\":2"), "{json}");
        assert!(json.contains("\"seed\":3,\"climate_version\":0}"), "{json}");
        session.pause();
        session.reset().unwrap();
        let json = state_json(&session);
        assert!(json.contains("\"running\":false"), "{json}");
        assert!(json.contains("\"climate_version\":1"), "{json}");
    }

    #[test]
    fn climate_has_one_glyph_per_cell_in_the_allowed_set() {
        let sim = sim_from(
            r#"{"seed": 1, "world": {"width": 7, "height": 5},
                "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
        );
        let json = climate_json(&sim);
        assert!(json.contains("\"width\":7,\"height\":5"));
        let start = json.find("\"biome\":\"").unwrap() + "\"biome\":\"".len();
        let glyphs = &json[start..json.len() - 2];
        assert_eq!(glyphs.len(), 35);
        assert!(glyphs.chars().all(|c| "PUTDR".contains(c)));
    }

    #[test]
    fn empty_world_gives_empty_organism_list() {
        let session = session_from(
            r#"{"seed": 1, "world": {"width": 4, "height": 4},
                "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
        );
        assert!(state_json(&session).ends_with("\"organisms\":[]}"));
    }
}

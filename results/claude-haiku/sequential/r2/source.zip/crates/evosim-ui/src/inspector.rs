//! Pure JSON builders of the inspector (ADR-0025 D4): one organism's detail, a death record and the watch body.
//! No I/O: unit-tested on any simulation.

use crate::control::Watch;
use evosim_core::analytics::trait_names;
use evosim_core::entities::{vision_radius, Death, DeathCause, Kind, Organism};
use evosim_core::sim::Simulation;
use std::fmt::Write;

/// Lowercase name of a death cause, as shown in the inspector.
pub fn cause_name(cause: DeathCause) -> &'static str {
    match cause {
        DeathCause::OldAge => "old age",
        DeathCause::Starvation => "starvation",
        DeathCause::Predation => "predation",
        DeathCause::Exposure => "exposure",
        DeathCause::Injury => "injury",
    }
}

/// Lowercase name of a kind.
pub fn kind_name(kind: Kind) -> &'static str {
    match kind {
        Kind::Plant => "plant",
        Kind::Herbivore => "herbivore",
        Kind::Carnivore => "carnivore",
    }
}

/// Detail of a living organism: `{"id", "kind", "species", "age", "energy", "health", "cell", "generation",
/// "parents", "traits", "genome"}`. `species` is `null` until the organism's species is recognised. `traits` holds the
/// animal-only `aggression`, `caution` and `vision` for herbivores and carnivores. `genome.haplotypes` is one hex string
/// per haplotype; `genome.slot_means` are the eight trait-slot means, named by `genome.slot_names`.
pub fn detail_json(sim: &Simulation, organism: &Organism) -> String {
    let kind = organism.kind();
    let traits = organism.traits();
    let genome = organism.genome();
    let cell = organism.cell();
    let [p0, p1] = organism.parents();
    let species = match organism.species().and_then(|id| sim.species().record(id).map(|r| (id, r))) {
        Some((id, record)) => format!("{{\"id\":{},\"name\":\"{}\"}}", id.0, record.name),
        None => "null".to_string(),
    };
    let mut out = String::with_capacity(512);
    let _ = write!(
        out,
        "{{\"id\":{},\"kind\":{{\"code\":{},\"name\":\"{}\"}},\"species\":{},\"age\":{},\"energy\":{},\"health\":{},\"cell\":[{},{}],\"generation\":{},\"parents\":[{},{}],",
        organism.id().0,
        kind.index(),
        kind_name(kind),
        species,
        organism.age(),
        organism.energy(),
        organism.health(),
        cell.x(),
        cell.y(),
        organism.generation(),
        opt_id(p0),
        opt_id(p1),
    );
    let _ = write!(
        out,
        "\"traits\":{{\"speed\":{},\"strength\":{},\"fertility\":{},\"max_lifespan\":{},\"max_health\":{}",
        traits.speed(),
        traits.strength(),
        traits.fertility(),
        traits.max_lifespan(),
        traits.max_health(),
    );
    if kind.is_animal() {
        let tendencies = organism.tendencies();
        let (aggression, caution) = tendencies.map_or((0.0, 0.0), |t| (t.aggression(), t.caution()));
        let _ = write!(
            out,
            ",\"aggression\":{},\"caution\":{},\"vision\":{}",
            aggression,
            caution,
            vision_radius(genome)
        );
    }
    out.push_str("},");
    let ploidy = genome.ploidy().max(1) as usize;
    let loci = genome.loci();
    let per_haplotype = loci.len() / ploidy;
    out.push_str("\"genome\":{\"ploidy\":");
    let _ = write!(out, "{}", genome.ploidy());
    out.push_str(",\"haplotypes\":[");
    for (n, chunk) in loci.chunks(per_haplotype.max(1)).enumerate() {
        if n > 0 {
            out.push(',');
        }
        out.push('"');
        for byte in chunk {
            let _ = write!(out, "{byte:02x}");
        }
        out.push('"');
    }
    out.push_str("],\"slot_means\":[");
    let means = genome.trait_means();
    for (n, mean) in means.iter().enumerate() {
        if n > 0 {
            out.push(',');
        }
        let _ = write!(out, "{mean}");
    }
    out.push_str("],\"slot_names\":[");
    for (n, name) in trait_names(kind).iter().enumerate() {
        if n > 0 {
            out.push(',');
        }
        let _ = write!(out, "\"{name}\"");
    }
    out.push_str("]}}");
    out
}

/// Death record: `{"tick", "cause", "cell": [x, y]}`.
pub fn death_json(death: &Death) -> String {
    format!(
        "{{\"tick\":{},\"cause\":\"{}\",\"cell\":[{},{}]}}",
        death.tick,
        cause_name(death.cause),
        death.cell.x(),
        death.cell.y()
    )
}

/// Watch body of `/api/organism`: `{"id", "status": "alive"|"dead", "death": null|{...}, "organism": <last detail>}`.
/// `organism` is the last detail seen while the organism was alive.
pub fn watch_json(watch: &Watch) -> String {
    let (status, death) = match &watch.death {
        Some(d) => ("dead", death_json(d)),
        None => ("alive", "null".to_string()),
    };
    format!(
        "{{\"id\":{},\"status\":\"{}\",\"death\":{},\"organism\":{}}}",
        watch.id.0, status, death, watch.last_alive
    )
}

fn opt_id(id: Option<evosim_core::entities::OrganismId>) -> String {
    match id {
        Some(id) => id.0.to_string(),
        None => "null".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::control::Session;
    use evosim_core::config::Config;
    use evosim_core::genome::TRAIT_SLOTS;

    fn session() -> Session {
        Session::new(
            &Config::from_json(
                r#"{"seed": 5, "world": {"width": 16, "height": 12},
                    "initial": {"plants": 30, "herbivores": 8, "carnivores": 3}}"#,
            )
            .unwrap(),
        )
        .unwrap()
    }

    fn animal_detail(s: &Session) -> (u64, String) {
        let o = s
            .simulation()
            .entities()
            .living()
            .find(|o| o.kind() == Kind::Herbivore)
            .unwrap();
        (o.id().0, detail_json(s.simulation(), o))
    }

    #[test]
    fn founder_detail_has_every_required_field() {
        let s = session();
        let (id, json) = animal_detail(&s);
        for key in [
            "\"id\":", "\"kind\":", "\"species\":", "\"age\":", "\"energy\":", "\"health\":", "\"traits\":",
            "\"genome\":", "\"parents\":", "\"cell\":", "\"generation\":", "\"aggression\":", "\"caution\":",
            "\"vision\":", "\"haplotypes\":", "\"slot_means\":", "\"slot_names\":",
        ] {
            assert!(json.contains(key), "missing {key} in {json}");
        }
        assert!(json.starts_with(&format!("{{\"id\":{id},")), "{json}");
        assert!(json.contains("\"name\":\"herbivore\""));
        assert!(json.contains("\"parents\":[null,null]"), "founders have no parents: {json}");
        assert!(json.contains("\"generation\":0"), "{json}");
    }

    #[test]
    fn founders_show_their_species_name() {
        // Founders are classified when they are placed (tick 0), so their species is known.
        let s = session();
        let (_, json) = animal_detail(&s);
        assert!(json.contains("\"species\":{\"id\":"), "{json}");
        assert!(json.contains("\"name\":\"HE"), "{json}");
    }

    #[test]
    fn genome_is_hex_per_haplotype_with_eight_slot_means_equal_to_trait_means() {
        let s = session();
        let o = s.simulation().entities().living().find(|o| o.kind() == Kind::Herbivore).unwrap();
        let json = detail_json(s.simulation(), o);
        let genome = o.genome();
        let hex = format!("\"haplotypes\":[\"{}\"", {
            let per = genome.loci().len() / genome.ploidy() as usize;
            genome.loci()[..per].iter().map(|b| format!("{b:02x}")).collect::<String>()
        });
        assert!(json.contains(&hex), "first haplotype hex: {json}");
        assert_eq!(genome.trait_means().len(), TRAIT_SLOTS);
        for mean in genome.trait_means() {
            assert!(json.contains(&format!("{mean}")), "slot mean {mean} in {json}");
        }
        assert_eq!(json.matches("\"slot_names\":[").count(), 1);
        assert_eq!(trait_names(Kind::Herbivore).len(), TRAIT_SLOTS, "one name per slot");
    }

    #[test]
    fn plants_have_no_animal_fields() {
        let s = session();
        let o = s.simulation().entities().living().find(|o| o.kind() == Kind::Plant).unwrap();
        let json = detail_json(s.simulation(), o);
        assert!(!json.contains("\"aggression\""), "{json}");
        assert!(!json.contains("\"vision\""), "{json}");
        assert!(json.contains("\"name\":\"plant\""));
    }

    #[test]
    fn death_record_and_watch_body_show_the_death() {
        let death = Death {
            id: evosim_core::entities::OrganismId(9),
            kind: Kind::Herbivore,
            cell: evosim_core::world::Torus::new(8, 8).unwrap().cell(3, 4).unwrap(),
            tick: 77,
            cause: DeathCause::Starvation,
        };
        assert_eq!(death_json(&death), "{\"tick\":77,\"cause\":\"starvation\",\"cell\":[3,4]}");
        let alive = Watch {
            id: evosim_core::entities::OrganismId(9),
            last_alive: "{\"id\":9}".to_string(),
            death: None,
        };
        assert!(watch_json(&alive).contains("\"status\":\"alive\",\"death\":null"));
        let dead = Watch { death: Some(death), ..alive };
        let body = watch_json(&dead);
        assert!(body.contains("\"status\":\"dead\""), "{body}");
        assert!(body.contains("\"cause\":\"starvation\""), "{body}");
        assert!(body.ends_with("\"organism\":{\"id\":9}}"), "{body}");
    }

    #[test]
    fn cause_and_kind_names_cover_every_variant() {
        for cause in DeathCause::ALL {
            assert!(!cause_name(cause).is_empty());
        }
        for kind in Kind::ALL {
            assert!(!kind_name(kind).is_empty());
        }
    }
}

//! Evolution Simulation user interface: a local browser world view served by `evosim ui` (ADR-0002, ADR-0024).
//! The page is embedded in the binary; the simulation runs on its own thread and the page polls its JSON API.

pub mod charts;
pub mod control;
pub mod driver;
pub mod inspector;
pub mod server;
pub mod setup;
pub mod snapshot;

use evosim_core::config::Config;
use std::path::{Path, PathBuf};

/// The example configuration of CONTRACT section 3, used when `--config` is not given (ADR-0024 D1).
pub const DEFAULT_CONFIG: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

/// What `evosim ui` does after it starts.
#[derive(Debug, PartialEq, Eq, Clone)]
pub enum UiMode {
    /// Serve until stopped.
    Serve,
    /// `--smoke-test`: run the real page once and check its marker, then exit.
    SmokeTest,
    /// `--screenshots DIR`: write `DIR/main.png` and `DIR/charts.png` from the real page, then exit.
    Screenshots(PathBuf),
}

/// Parsed options of `evosim ui`.
#[derive(Debug, PartialEq, Eq, Clone)]
pub struct UiArgs {
    pub config: Option<PathBuf>,
    /// Loopback port; 0 picks a free one.
    pub port: u16,
    pub mode: UiMode,
}

/// A failed `evosim ui`. `usage` errors (bad configuration or directory) exit 2; the others exit 1.
#[derive(Debug, PartialEq, Eq)]
pub struct UiError {
    pub usage: bool,
    pub message: String,
}

fn usage(message: String) -> UiError {
    UiError { usage: true, message }
}

fn runtime(message: String) -> UiError {
    UiError { usage: false, message }
}

fn load_config(path: &Path) -> Result<Config, String> {
    Config::load(path).map_err(|e| match &e.key {
        Some(key) => format!("{}: {key}: {}", path.display(), e.message),
        None => format!("{}: {}", path.display(), e.message),
    })
}

/// Runs `evosim ui` with the parsed options.
pub fn run(args: &UiArgs) -> Result<(), UiError> {
    if let UiMode::Screenshots(dir) = &args.mode {
        if !dir.is_dir() {
            return Err(usage(format!("screenshot directory {} does not exist", dir.display())));
        }
    }
    let config = match &args.config {
        Some(path) => load_config(path).map_err(usage)?,
        None => Config::from_json(DEFAULT_CONFIG).map_err(|e| usage(e.message))?,
    };
    match &args.mode {
        UiMode::Serve => driver::serve(&config, args.port).map_err(runtime),
        UiMode::SmokeTest => {
            let marker = driver::smoke_test(&config).map_err(runtime)?;
            println!("evosim ui: smoke test passed ({marker})");
            Ok(())
        }
        UiMode::Screenshots(dir) => {
            for file in driver::screenshots(&config, dir).map_err(runtime)? {
                println!("evosim ui: wrote {}", file.display());
            }
            Ok(())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_config_is_the_contract_example() {
        let c = Config::from_json(DEFAULT_CONFIG).unwrap();
        assert_eq!((c.world.width, c.world.height), (64, 48));
        assert_eq!(c.seed, 42);
    }

    #[test]
    fn missing_config_is_a_usage_error() {
        let err = run(&UiArgs {
            config: Some(PathBuf::from("/nonexistent/evosim-missing.json")),
            port: 0,
            mode: UiMode::Serve,
        })
        .unwrap_err();
        assert!(err.usage);
    }

    #[test]
    fn missing_screenshot_directory_is_a_usage_error() {
        let err = run(&UiArgs {
            config: None,
            port: 0,
            mode: UiMode::Screenshots(PathBuf::from("/nonexistent/evosim-shots")),
        })
        .unwrap_err();
        assert!(err.usage);
    }
}

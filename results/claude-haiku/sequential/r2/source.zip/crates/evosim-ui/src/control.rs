//! Run controls of the UI (ADR-0025 D1, D6): a pure `Session` that owns the simulation and applies commands.
//! No threads, sockets or display are involved; the simulation thread in `driver` calls these methods.

use crate::charts::{self, ChartLog};
use crate::inspector;
use evosim_core::checkpoint;
use evosim_core::config::Config;
use evosim_core::entities::{Death, Kind, OrganismId};
use evosim_core::sim::Simulation;
use std::time::Duration;

/// Speed levels in ticks per second (ADR-0025 D1). Every level is at least 1.
pub const SPEED_LEVELS: [u32; 4] = [1, 5, 20, 60];
/// Index of the default speed: 20 ticks per second, the pace the UI had before TASK-024.
pub const DEFAULT_SPEED_INDEX: usize = 2;
/// Most ticks one `pump` call may run. Bounds the work after a long stall (for example a debugger pause).
pub const MAX_TICKS_PER_PUMP: u64 = 120;

/// A request from the HTTP side, applied by the simulation thread between ticks (ADR-0025 D2).
#[derive(Debug, Clone, PartialEq)]
pub enum Command {
    Run,
    Pause,
    Step,
    Reset,
    Faster,
    Slower,
    Select(u64),
    Deselect,
    Save,
    Load(Vec<u8>),
    /// Starts a new world from a validated configuration (ADR-0026 D4).
    NewWorld(Box<Config>),
    /// Chart points with `tick > since` (all when `None`) and the mean of the named trait (ADR-0026 D6).
    Series { since: Option<u64>, trait_name: String },
    /// Histogram of a trait of the living organisms of a kind (ADR-0026 D7).
    Distribution { kind: Kind, trait_name: String, bins: usize },
}

/// The answer to a command.
#[derive(Debug, Clone, PartialEq)]
pub enum Reply {
    Done,
    Bytes(Vec<u8>),
    Error(String),
}

/// The organism under the inspector (ADR-0025 D4): its last detail while alive, and the death once it happened.
#[derive(Debug, Clone, PartialEq)]
pub struct Watch {
    pub id: OrganismId,
    pub last_alive: String,
    pub death: Option<Death>,
}

/// The simulation and its run controls.
pub struct Session {
    config: Config,
    sim: Simulation,
    seed: u64,
    running: bool,
    speed_index: usize,
    /// Fractional ticks not yet run, carried from one `pump` to the next. Cleared while paused.
    carry: f64,
    watch: Option<Watch>,
    climate_version: u64,
    /// Per-tick chart data since the world was started, loaded or reset (ADR-0026 D6).
    chart: ChartLog,
}

impl Session {
    /// Builds tick 0 of `config` with its founders, running at the default speed.
    pub fn new(config: &Config) -> Result<Session, String> {
        let sim = build(config)?;
        let mut chart = ChartLog::new();
        chart.record(&sim);
        Ok(Session {
            config: config.clone(),
            sim,
            seed: config.seed,
            running: true,
            speed_index: DEFAULT_SPEED_INDEX,
            carry: 0.0,
            watch: None,
            climate_version: 0,
            chart,
        })
    }

    /// Starts a new world from `config` (ADR-0026 D4): tick 0, paused, with no selection and an empty chart log.
    /// The configuration becomes the one that [`Session::reset`] returns to. A failure leaves the session unchanged.
    pub fn new_world(&mut self, config: &Config) -> Result<(), String> {
        let sim = build(config)?;
        self.config = config.clone();
        self.seed = config.seed;
        self.sim = sim;
        self.running = false;
        self.carry = 0.0;
        self.watch = None;
        self.climate_version += 1;
        self.restart_chart();
        Ok(())
    }

    /// Number of kept chart points (the log's length, for the page's point count and the tests).
    pub fn chart_points(&self) -> usize {
        self.chart.points().len()
    }

    fn restart_chart(&mut self) {
        self.chart = ChartLog::new();
        self.chart.record(&self.sim);
    }

    /// The `/api/series` body (ADR-0026 D6).
    pub fn series(&self, since: Option<u64>, trait_name: &str) -> Result<String, String> {
        self.chart.series_json(since, trait_name)
    }

    /// The `/api/distribution` body (ADR-0026 D7).
    pub fn distribution(&self, kind: Kind, trait_name: &str, bins: usize) -> Result<String, String> {
        charts::distribution_json(&self.sim, kind, trait_name, bins)
    }

    pub fn simulation(&self) -> &Simulation {
        &self.sim
    }

    pub fn running(&self) -> bool {
        self.running
    }

    pub fn speed(&self) -> u32 {
        SPEED_LEVELS[self.speed_index]
    }

    pub fn speed_index(&self) -> usize {
        self.speed_index
    }

    pub fn seed(&self) -> u64 {
        self.seed
    }

    /// Increases by one each time the base layer changes (reset or load), so the page refetches the climate.
    pub fn climate_version(&self) -> u64 {
        self.climate_version
    }

    pub fn watch(&self) -> Option<&Watch> {
        self.watch.as_ref()
    }

    pub fn run(&mut self) {
        self.running = true;
    }

    pub fn pause(&mut self) {
        self.running = false;
        self.carry = 0.0;
    }

    /// Advances exactly one tick. Refused while running, so that a step is always a single tick from a paused world.
    pub fn step(&mut self) -> Result<(), String> {
        if self.running {
            return Err("step needs a paused simulation".to_string());
        }
        self.tick_once();
        Ok(())
    }

    /// Runs the ticks due for `elapsed` wall-clock time at the current speed. Paused: runs nothing.
    /// Returns the number of ticks run.
    pub fn pump(&mut self, elapsed: Duration) -> u64 {
        if !self.running {
            self.carry = 0.0;
            return 0;
        }
        self.carry += elapsed.as_secs_f64() * f64::from(self.speed());
        let whole = self.carry.floor();
        let due = if whole > MAX_TICKS_PER_PUMP as f64 {
            self.carry = 0.0;
            MAX_TICKS_PER_PUMP
        } else {
            self.carry -= whole;
            whole as u64
        };
        for _ in 0..due {
            self.tick_once();
        }
        due
    }

    /// Rebuilds the world from the configuration the session started with (its seed included). Keeps run or pause,
    /// clears the selection, and bumps the climate version. A loaded checkpoint is not restored by reset.
    pub fn reset(&mut self) -> Result<(), String> {
        self.sim = build(&self.config)?;
        self.watch = None;
        self.carry = 0.0;
        self.climate_version += 1;
        self.restart_chart();
        Ok(())
    }

    pub fn faster(&mut self) {
        if self.speed_index + 1 < SPEED_LEVELS.len() {
            self.speed_index += 1;
        }
    }

    pub fn slower(&mut self) {
        self.speed_index = self.speed_index.saturating_sub(1);
    }

    /// Selects a living organism. An unknown or dead id is an error and leaves the current selection unchanged.
    pub fn select(&mut self, id: u64) -> Result<(), String> {
        let organism = self
            .sim
            .entities()
            .get(OrganismId(id))
            .filter(|o| o.is_alive())
            .ok_or_else(|| format!("organism {id} is not alive"))?;
        self.watch = Some(Watch {
            id: OrganismId(id),
            last_alive: inspector::detail_json(&self.sim, organism),
            death: None,
        });
        Ok(())
    }

    pub fn deselect(&mut self) {
        self.watch = None;
    }

    /// The checkpoint file of the current state (ADR-0023 D1), the same bytes as `--save`.
    pub fn save(&self) -> Vec<u8> {
        checkpoint::write_file(&self.sim, self.seed)
    }

    /// Replaces the world with a checkpoint. On an invalid file the session is unchanged.
    pub fn load(&mut self, bytes: &[u8]) -> Result<(), String> {
        let restored = checkpoint::read_file(bytes).map_err(|e| e.to_string())?;
        self.sim = restored.sim;
        self.seed = restored.seed;
        self.watch = None;
        self.carry = 0.0;
        self.climate_version += 1;
        self.restart_chart();
        Ok(())
    }

    /// Applies one command. Used by the simulation thread only.
    pub fn apply(&mut self, command: Command) -> Reply {
        let result = match command {
            Command::Run => {
                self.run();
                Ok(())
            }
            Command::Pause => {
                self.pause();
                Ok(())
            }
            Command::Step => self.step(),
            Command::Reset => self.reset(),
            Command::Faster => {
                self.faster();
                Ok(())
            }
            Command::Slower => {
                self.slower();
                Ok(())
            }
            Command::Select(id) => self.select(id),
            Command::Deselect => {
                self.deselect();
                Ok(())
            }
            Command::Save => return Reply::Bytes(self.save()),
            Command::Load(bytes) => self.load(&bytes),
            Command::NewWorld(config) => self.new_world(&config),
            Command::Series { since, trait_name } => {
                return match self.series(since, &trait_name) {
                    Ok(body) => Reply::Bytes(body.into_bytes()),
                    Err(message) => Reply::Error(message),
                };
            }
            Command::Distribution { kind, trait_name, bins } => {
                return match self.distribution(kind, &trait_name, bins) {
                    Ok(body) => Reply::Bytes(body.into_bytes()),
                    Err(message) => Reply::Error(message),
                };
            }
        };
        match result {
            Ok(()) => Reply::Done,
            Err(message) => Reply::Error(message),
        }
    }

    /// The `control` block of `/api/state` (ADR-0025 D3).
    pub fn control_json(&self) -> String {
        let speeds: Vec<String> = SPEED_LEVELS.iter().map(|s| s.to_string()).collect();
        let selected = match &self.watch {
            Some(w) => w.id.0.to_string(),
            None => "null".to_string(),
        };
        format!(
            "{{\"running\":{},\"speed\":{},\"speed_index\":{},\"speeds\":[{}],\"selected\":{},\"seed\":{},\"climate_version\":{}}}",
            self.running,
            self.speed(),
            self.speed_index,
            speeds.join(","),
            selected,
            self.seed,
            self.climate_version
        )
    }

    /// The `/api/organism` body for the current selection, or `None` when nothing is selected.
    pub fn watch_body(&self) -> Option<(u64, String)> {
        self.watch.as_ref().map(|w| (w.id.0, inspector::watch_json(w)))
    }

    /// One tick, then the watch: a living organism refreshes its detail; a death is recorded from `last_deaths`
    /// (the removed organism cannot be looked up afterwards, ADR-0025 D4).
    fn tick_once(&mut self) {
        self.sim.tick();
        self.chart.record(&self.sim);
        let Some(watch) = self.watch.as_mut() else {
            return;
        };
        if watch.death.is_some() {
            return;
        }
        match self.sim.entities().get(watch.id) {
            Some(organism) if organism.is_alive() => {
                watch.last_alive = inspector::detail_json(&self.sim, organism);
            }
            _ => {
                if let Some(death) = self.sim.entities().last_deaths().iter().find(|d| d.id == watch.id) {
                    watch.death = Some(*death);
                }
            }
        }
    }
}

fn build(config: &Config) -> Result<Simulation, String> {
    let mut sim = Simulation::new(config).map_err(|e| format!("cannot build the world: {e}"))?;
    // The founders are placed separately from the world (as in `runner::run_config`).
    sim.populate_initial(config)
        .map_err(|e| format!("cannot place the initial population: {e}"))?;
    Ok(sim)
}

#[cfg(test)]
mod tests {
    use super::*;
    use evosim_core::checkpoint::state_hash;

    const WORLD: &str = r#"{"seed": 42, "world": {"width": 16, "height": 12},
        "initial": {"plants": 40, "herbivores": 10, "carnivores": 3}}"#;
    // No plants: herbivores starve (CONTRACT section 5.3), so a followed herbivore dies.
    const STARVING: &str = r#"{"seed": 7, "world": {"width": 8, "height": 8},
        "initial": {"plants": 0, "herbivores": 12, "carnivores": 0}}"#;

    fn session(json: &str) -> Session {
        Session::new(&Config::from_json(json).unwrap()).unwrap()
    }

    #[test]
    fn speed_levels_are_positive_and_there_are_at_least_three() {
        assert!(SPEED_LEVELS.len() >= 3);
        assert!(SPEED_LEVELS.iter().all(|&s| s >= 1));
        assert!(SPEED_LEVELS.windows(2).all(|w| w[0] < w[1]));
    }

    #[test]
    fn step_advances_exactly_one_tick_when_paused() {
        let mut s = session(WORLD);
        s.pause();
        assert_eq!(s.simulation().tick_count(), 0);
        s.step().unwrap();
        assert_eq!(s.simulation().tick_count(), 1);
        s.step().unwrap();
        assert_eq!(s.simulation().tick_count(), 2);
    }

    #[test]
    fn step_is_refused_while_running_and_changes_nothing() {
        let mut s = session(WORLD);
        assert!(s.running());
        assert!(s.step().is_err());
        assert_eq!(s.simulation().tick_count(), 0);
    }

    #[test]
    fn paused_pump_advances_nothing_for_any_elapsed_time() {
        let mut s = session(WORLD);
        s.pause();
        assert_eq!(s.pump(Duration::from_secs(10)), 0);
        assert_eq!(s.simulation().tick_count(), 0);
    }

    #[test]
    fn running_pump_follows_the_speed() {
        let mut s = session(WORLD);
        assert_eq!(s.speed(), 20);
        assert_eq!(s.pump(Duration::from_secs(1)), 20);
        assert_eq!(s.pump(Duration::from_millis(500)), 10);
        assert_eq!(s.simulation().tick_count(), 30);
    }

    #[test]
    fn pause_discards_fractional_time() {
        let mut s = session(WORLD);
        assert_eq!(s.pump(Duration::from_millis(40)), 0); // 0.8 tick carried
        s.pause();
        s.run();
        assert_eq!(s.pump(Duration::from_millis(40)), 0); // not 1 tick: the carry was cleared by the pause
    }

    #[test]
    fn long_stall_runs_at_most_the_pump_limit() {
        let mut s = session(WORLD);
        assert_eq!(s.pump(Duration::from_secs(3600)), MAX_TICKS_PER_PUMP);
    }

    #[test]
    fn speed_index_stays_in_range() {
        let mut s = session(WORLD);
        for _ in 0..10 {
            s.faster();
        }
        assert_eq!(s.speed_index(), SPEED_LEVELS.len() - 1);
        assert_eq!(s.speed(), 60);
        for _ in 0..10 {
            s.slower();
        }
        assert_eq!(s.speed_index(), 0);
        assert_eq!(s.speed(), 1);
        assert!(s.speed() >= 1);
    }

    #[test]
    fn reset_gives_the_same_starting_world_and_keeps_run_state() {
        let mut fresh = session(WORLD);
        fresh.pause();
        let start = state_hash(fresh.simulation());
        let mut s = session(WORLD);
        s.pause();
        for _ in 0..5 {
            s.step().unwrap();
        }
        assert_ne!(state_hash(s.simulation()), start);
        s.reset().unwrap();
        assert_eq!(state_hash(s.simulation()), start, "reset returns to tick 0 of the configuration");
        assert!(!s.running(), "reset keeps the paused state");
        s.reset().unwrap();
        assert_eq!(state_hash(s.simulation()), start, "two resets give identical starting states");
    }

    #[test]
    fn steps_after_reset_match_a_fresh_session() {
        let mut a = session(WORLD);
        a.pause();
        for _ in 0..4 {
            a.step().unwrap();
        }
        a.reset().unwrap();
        for _ in 0..6 {
            a.step().unwrap();
        }
        let mut b = session(WORLD);
        b.pause();
        for _ in 0..6 {
            b.step().unwrap();
        }
        assert_eq!(state_hash(a.simulation()), state_hash(b.simulation()));
    }

    #[test]
    fn reset_clears_the_selection_and_bumps_the_climate_version() {
        let mut s = session(WORLD);
        let v = s.climate_version();
        let id = first_living(&s);
        s.select(id).unwrap();
        s.reset().unwrap();
        assert!(s.watch().is_none());
        assert_eq!(s.climate_version(), v + 1);
    }

    fn first_living(s: &Session) -> u64 {
        s.simulation().entities().living().next().unwrap().id().0
    }

    #[test]
    fn watch_records_a_death_and_keeps_the_last_detail_seen_alive() {
        let mut s = session(STARVING);
        s.pause();
        let id = first_living(&s);
        s.select(id).unwrap();
        let alive_detail = s.watch().unwrap().last_alive.clone();
        assert!(alive_detail.contains(&format!("\"id\":{id}")), "{alive_detail}");
        let mut steps = 0;
        while s.watch().unwrap().death.is_none() {
            s.step().unwrap();
            steps += 1;
            assert!(steps < 5000, "the followed herbivore never died");
        }
        let watch = s.watch().unwrap();
        let death = watch.death.unwrap();
        assert_eq!(death.id.0, id);
        assert_eq!(death.tick + 1, s.simulation().tick_count(), "death is recorded on the tick it happened");
        assert!(watch.last_alive.contains(&format!("\"id\":{id}")), "last alive detail kept");
        let body = inspector::watch_json(watch);
        assert!(body.contains("\"status\":\"dead\""), "{body}");
        assert!(body.contains("\"tick\":"), "{body}");
        // further ticks do not change the record
        let before = s.watch().unwrap().clone();
        s.step().unwrap();
        assert_eq!(s.watch().unwrap(), &before);
    }

    #[test]
    fn selecting_unknown_or_dead_id_is_an_error_and_keeps_the_selection() {
        let mut s = session(WORLD);
        let id = first_living(&s);
        s.select(id).unwrap();
        let before = s.watch().unwrap().clone();
        assert!(s.select(u64::MAX).is_err());
        assert_eq!(s.watch().unwrap(), &before);
        assert_eq!(s.apply(Command::Select(u64::MAX)), Reply::Error(format!("organism {} is not alive", u64::MAX)));
    }

    #[test]
    fn save_then_load_continues_to_the_same_state() {
        let mut a = session(WORLD);
        a.pause();
        for _ in 0..10 {
            a.step().unwrap();
        }
        let bytes = a.save();
        for _ in 0..10 {
            a.step().unwrap();
        }
        let mut b = session(WORLD);
        b.load(&bytes).unwrap();
        assert_eq!(b.simulation().tick_count(), 10);
        assert_eq!(b.seed(), 42);
        b.pause();
        for _ in 0..10 {
            b.step().unwrap();
        }
        assert_eq!(state_hash(a.simulation()), state_hash(b.simulation()));
    }

    #[test]
    fn invalid_checkpoint_leaves_the_session_unchanged() {
        let mut a = session(WORLD);
        a.pause();
        a.step().unwrap();
        let good = a.save();
        let hash = state_hash(a.simulation());
        let v = a.climate_version();
        let mut flipped = good.clone();
        let mid = flipped.len() / 2;
        flipped[mid] ^= 0x01;
        for bad in [&good[..good.len() - 5], &flipped[..]] {
            assert!(a.load(bad).is_err());
            assert_eq!(state_hash(a.simulation()), hash);
            assert_eq!(a.climate_version(), v);
        }
    }

    #[test]
    fn load_bumps_the_climate_version_and_clears_the_watch() {
        let mut a = session(WORLD);
        let bytes = a.save();
        let id = first_living(&a);
        a.select(id).unwrap();
        let v = a.climate_version();
        a.load(&bytes).unwrap();
        assert_eq!(a.climate_version(), v + 1);
        assert!(a.watch().is_none());
    }

    #[test]
    fn apply_maps_commands_to_replies() {
        let mut s = session(WORLD);
        assert_eq!(s.apply(Command::Pause), Reply::Done);
        assert_eq!(s.apply(Command::Step), Reply::Done);
        assert_eq!(s.apply(Command::Run), Reply::Done);
        assert!(matches!(s.apply(Command::Step), Reply::Error(_)));
        assert!(matches!(s.apply(Command::Save), Reply::Bytes(b) if !b.is_empty()));
        assert!(matches!(s.apply(Command::Load(vec![1, 2, 3])), Reply::Error(_)));
    }

    #[test]
    fn control_block_has_every_key() {
        let s = session(WORLD);
        let json = s.control_json();
        for key in ["running", "speed", "speed_index", "speeds", "selected", "seed", "climate_version"] {
            assert!(json.contains(&format!("\"{key}\":")), "{json}");
        }
        assert!(json.contains("\"speeds\":[1,5,20,60]"), "{json}");
        assert!(json.contains("\"selected\":null"), "{json}");
    }
}

#[cfg(test)]
mod world_tests {
    use super::*;
    use evosim_core::checkpoint::state_hash;
    use evosim_core::config::presets;

    fn config(json: &str) -> Config {
        Config::from_json(json).unwrap()
    }

    #[test]
    fn new_world_starts_paused_at_tick_zero_with_the_given_seed_and_size() {
        let mut s = Session::new(&config(r#"{"seed": 1, "world": {"width": 8, "height": 8},
            "initial": {"plants": 10, "herbivores": 2, "carnivores": 0}}"#))
        .unwrap();
        s.run();
        s.pump(Duration::from_secs(1));
        let c = presets::get("arid").unwrap();
        s.new_world(&c).unwrap();
        assert!(!s.running());
        assert_eq!(s.simulation().tick_count(), 0);
        assert_eq!(s.seed(), 42);
        assert_eq!((s.simulation().world().topology.width(), s.simulation().world().topology.height()), (64, 48));
        assert_eq!(s.chart_points(), 1, "the chart log starts with tick 0 only");
    }

    #[test]
    fn reset_after_a_new_world_returns_to_that_world() {
        let mut s = Session::new(&presets::get("balanced").unwrap()).unwrap();
        s.pause();
        let c = config(r#"{"seed": 9, "world": {"width": 10, "height": 6},
            "initial": {"plants": 20, "herbivores": 4, "carnivores": 1}}"#);
        s.new_world(&c).unwrap();
        let start = state_hash(s.simulation());
        for _ in 0..3 {
            s.step().unwrap();
        }
        s.reset().unwrap();
        assert_eq!(state_hash(s.simulation()), start);
        assert_eq!(s.seed(), 9);
        assert_eq!(s.simulation().tick_count(), 0);
    }

    #[test]
    fn a_new_world_clears_the_selection_and_the_chart_log() {
        let mut s = Session::new(&presets::get("balanced").unwrap()).unwrap();
        s.pause();
        for _ in 0..5 {
            s.step().unwrap();
        }
        let id = s.simulation().entities().living().next().unwrap().id().0;
        s.select(id).unwrap();
        let v = s.climate_version();
        s.new_world(&presets::get("herbivore-only").unwrap()).unwrap();
        assert!(s.watch().is_none());
        assert_eq!(s.climate_version(), v + 1);
        assert_eq!(s.chart_points(), 1);
    }

    #[test]
    fn chart_log_grows_with_ticks_and_is_bounded() {
        let mut s = Session::new(&presets::get("balanced").unwrap()).unwrap();
        s.pause();
        for _ in 0..12 {
            s.step().unwrap();
        }
        assert_eq!(s.chart_points(), 13);
        let body = s.series(Some(10), "speed").unwrap();
        assert!(body.contains("\"tick\":[11,12]"), "{body}");
    }

    #[test]
    fn series_and_distribution_replies_go_through_apply() {
        let mut s = Session::new(&presets::get("balanced").unwrap()).unwrap();
        s.pause();
        s.step().unwrap();
        match s.apply(Command::Series { since: None, trait_name: "speed".to_string() }) {
            Reply::Bytes(b) => assert!(String::from_utf8(b).unwrap().contains("\"tick\":[0,1]")),
            other => panic!("{other:?}"),
        }
        assert!(matches!(
            s.apply(Command::Series { since: None, trait_name: "nope".to_string() }),
            Reply::Error(_)
        ));
        match s.apply(Command::Distribution { kind: Kind::Herbivore, trait_name: "speed".to_string(), bins: 5 }) {
            Reply::Bytes(b) => assert!(String::from_utf8(b).unwrap().contains("\"counts\":[")),
            other => panic!("{other:?}"),
        }
        assert!(matches!(
            s.apply(Command::Distribution { kind: Kind::Herbivore, trait_name: "speed".to_string(), bins: 0 }),
            Reply::Error(_)
        ));
    }

    #[test]
    fn apply_new_world_with_a_config_replies_done() {
        let mut s = Session::new(&presets::get("balanced").unwrap()).unwrap();
        let c = presets::get("continent").unwrap();
        assert_eq!(s.apply(Command::NewWorld(Box::new(c.clone()))), Reply::Done);
        assert_eq!(s.simulation().tick_count(), 0);
        assert_eq!(s.seed(), c.seed);
    }
}

//! `evosim batch` (ADR-0022): plans every (case, seed) run, executes them (optionally on several threads), then writes
//! the per-seed results, the CSV files and `summary.json`, in that order. `summary.json` is written last, so its absence
//! marks an incomplete batch. Nothing is printed to stdout.

use crate::args::BatchArgs;
use crate::{load_config, parent_dir, write_atomically};
use evosim_core::batch::{self, BatchRun, SummarySpec};
use evosim_core::config::Config;
use evosim_core::metrics::{self, RunResult};
use evosim_core::runner;
use std::sync::atomic::{AtomicUsize, Ordering};

/// Above this many runs a warning is printed to stderr (ADR-0022 Consequences).
const WARN_RUNS: usize = 1000;

/// One run before it is executed: its case, seed, configuration and output path relative to the batch directory.
struct PlannedRun {
    case: usize,
    seed: u64,
    config: Config,
    file: String,
}

/// Runs `evosim batch`. Every configuration is built before the first run starts, so an invalid sweep value or key
/// fails with no run and no file written.
pub fn run_batch(args: &BatchArgs) -> Result<(), String> {
    let base = load_config(&args.config)?;
    let cases = batch::expand_cases(&args.vary);
    let mut planned = Vec::with_capacity(cases.len() * args.seeds.len());
    for (index, case) in cases.iter().enumerate() {
        for &seed in &args.seeds {
            let config = batch::run_config(&base, &case.params, seed)?;
            let file = if args.vary.is_empty() {
                format!("seed-{seed}.json")
            } else {
                format!("{}/seed-{seed}.json", case.name)
            };
            planned.push(PlannedRun {
                case: index,
                seed,
                config,
                file,
            });
        }
    }
    if planned.len() > WARN_RUNS {
        eprintln!(
            "evosim: warning: the batch has {} runs and may take a long time",
            planned.len()
        );
    }

    let sample_every = args
        .sample_every
        .unwrap_or_else(|| metrics::default_sample_every(args.ticks));
    let results = execute(&planned, args.ticks, sample_every, args.jobs)?;
    let runs: Vec<BatchRun> = planned
        .iter()
        .zip(results)
        .map(|(p, result)| BatchRun {
            case: cases[p.case].name.clone(),
            params: cases[p.case].params.clone(),
            seed: p.seed,
            file: p.file.clone(),
            result,
        })
        .collect();

    // Every text is built before anything is written (ADR-0022 D7).
    let seed_texts = runs
        .iter()
        .map(|run| run.result.to_json())
        .collect::<Result<Vec<_>, _>>()?;
    let spec = SummarySpec {
        ticks: args.ticks,
        sample_every,
        seeds: &args.seeds,
        base: &base,
        vary: &args.vary,
        cases: &cases,
    };
    let summary = batch::summary_json(&spec, &runs)?;
    let csv = if args.csv {
        Some((
            batch::runs_csv(&args.vary, &runs),
            batch::aggregates_csv(&batch::case_aggregates(&runs, &cases))?,
        ))
    } else {
        None
    };

    std::fs::create_dir_all(&args.out_dir)
        .map_err(|e| format!("cannot create {}: {e}", args.out_dir.display()))?;
    for (run, text) in runs.iter().zip(&seed_texts) {
        let path = args.out_dir.join(&run.file);
        let dir = parent_dir(&path);
        std::fs::create_dir_all(&dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
        write_atomically(&path, text)?;
    }
    if let Some((runs_csv, aggregates_csv)) = csv {
        write_atomically(&args.out_dir.join("runs.csv"), &runs_csv)?;
        write_atomically(&args.out_dir.join("aggregates.csv"), &aggregates_csv)?;
    }
    write_atomically(&args.out_dir.join("summary.json"), &summary)
}

/// Executes the planned runs with `jobs` worker threads (ADR-0022 D5). Each worker takes the next run index, builds its
/// own simulation and stores the result under that index, so the output does not depend on `jobs` or on timing.
/// Returns the first error in run order.
fn execute(planned: &[PlannedRun], ticks: u64, sample_every: u64, jobs: usize) -> Result<Vec<RunResult>, String> {
    let next = AtomicUsize::new(0);
    let workers = jobs.clamp(1, planned.len().max(1));
    let mut slots: Vec<Option<Result<RunResult, String>>> = planned.iter().map(|_| None).collect();
    std::thread::scope(|scope| {
        let handles: Vec<_> = (0..workers)
            .map(|_| {
                scope.spawn(|| {
                    let mut done = Vec::new();
                    loop {
                        let i = next.fetch_add(1, Ordering::Relaxed);
                        if i >= planned.len() {
                            break;
                        }
                        let out = runner::run(&planned[i].config, ticks, sample_every, false).map(|o| o.result);
                        done.push((i, out));
                    }
                    done
                })
            })
            .collect();
        for handle in handles {
            for (i, out) in handle.join().expect("a batch worker thread panicked") {
                slots[i] = Some(out);
            }
        }
    });
    slots
        .into_iter()
        .map(|slot| slot.expect("every run index is taken by exactly one worker"))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use evosim_core::batch::Vary;
    use evosim_core::config::json::Value;

    fn base() -> Config {
        Config::from_json(
            r#"{"seed": 1, "world": {"width": 8, "height": 6},
                "initial": {"plants": 20, "herbivores": 5, "carnivores": 2}}"#,
        )
        .unwrap()
    }

    #[test]
    fn execute_result_does_not_depend_on_worker_count() {
        let cases = batch::expand_cases(&[Vary { key: "initial.plants".into(), values: vec![Value::Int(10), Value::Int(30)] }]);
        let mut planned = Vec::new();
        for (index, case) in cases.iter().enumerate() {
            for seed in [3u64, 4] {
                planned.push(PlannedRun {
                    case: index,
                    seed,
                    config: batch::run_config(&base(), &case.params, seed).unwrap(),
                    file: String::new(),
                });
            }
        }
        let one = execute(&planned, 30, 10, 1).unwrap();
        let four = execute(&planned, 30, 10, 4).unwrap();
        assert_eq!(one.len(), 4);
        let hashes = |v: &[RunResult]| v.iter().map(|r| r.state_hash.clone()).collect::<Vec<_>>();
        assert_eq!(hashes(&one), hashes(&four));
        // Wall-clock fields differ between runs; everything the simulation determines must be equal.
        for (a, b) in one.iter().zip(&four) {
            assert_eq!(a.counts, b.counts);
            assert_eq!(a.series, b.series);
            assert_eq!(a.tick_end, b.tick_end);
        }
    }
}

//! `evosim` command-line entry point.
//!
//! Only this binary writes to stdout; diagnostics go to stderr (docs/ARCHITECTURE.md).
//! Exit status: 0 success, 2 invalid invocation (docs/CONTRACT.md section 5.4).

mod args;
mod batch;

use args::{ArgError, ClimateArgs, ClimateFormat, Command, RunArgs};
use evosim_core::analytics;
use evosim_core::checkpoint;
use evosim_core::config::Config;
use evosim_core::metrics;
use evosim_core::runner;
use evosim_core::sim::Simulation;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process::ExitCode;

const PROGRAM_NAME: &str = "evosim";
const PROGRAM_VERSION: &str = env!("CARGO_PKG_VERSION");

/// The JSON printed by `evosim version` (docs/CONTRACT.md section 2), without the trailing newline.
fn version_json() -> String {
    format!(
        "{{\"name\": \"{}\", \"version\": \"{}\", \"contract\": {}}}",
        PROGRAM_NAME,
        PROGRAM_VERSION,
        evosim_core::CONTRACT_VERSION
    )
}

/// Help text listing the commands available in this build.
fn help_text() -> String {
    format!(
        "Usage: {p} <command>\n\
         \n\
         Evolution Simulation (version {v}).\n\
         \n\
         Commands:\n  \
         version    print the program name, version and contract version as JSON\n  \
         --help     show this help (also -h)\n\
         climate    print the base climate map of a configuration (--config FILE [--format text|json] [--out FILE])\n  \
         run        simulate headless and write the result JSON (--config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--metrics FILE])\n  \
         batch      run each seed (and each --vary KEY=V1,V2 combination) and write per-seed results and summary.json (--config FILE --seeds S1,S2 --ticks N --out-dir DIR [--vary KEY=V1,V2]... [--sample-every K] [--jobs J] [--csv])\n\
         ui         start the world view in the browser (--config FILE, --port N, --smoke-test, --screenshots DIR)\n\
         \n",
        p = PROGRAM_NAME,
        v = PROGRAM_VERSION
    )
}

fn main() -> ExitCode {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    match args::parse(&argv) {
        Ok(Command::Version) => {
            println!("{}", version_json());
            ExitCode::SUCCESS
        }
        Ok(Command::Help) => {
            print!("{}", help_text());
            ExitCode::SUCCESS
        }
        Ok(Command::Climate(args)) => match run_climate(&args) {
            Ok(()) => ExitCode::SUCCESS,
            Err(message) => {
                eprintln!("{PROGRAM_NAME}: {message}");
                ExitCode::from(2)
            }
        },
        Ok(Command::Run(args)) => match run_run(&args) {
            Ok(()) => ExitCode::SUCCESS,
            Err(message) => {
                eprintln!("{PROGRAM_NAME}: {message}");
                ExitCode::from(2)
            }
        },
        Ok(Command::Ui(args)) => match evosim_ui::run(&args) {
            Ok(()) => ExitCode::SUCCESS,
            Err(error) => {
                eprintln!("{PROGRAM_NAME}: {}", error.message);
                // Invalid configuration or directory: 2 (CONTRACT section 5.4). Smoke or screenshot failure: 1.
                ExitCode::from(if error.usage { 2 } else { 1 })
            }
        },
        Ok(Command::Batch(args)) => match batch::run_batch(&args) {
            Ok(()) => ExitCode::SUCCESS,
            Err(message) => {
                eprintln!("{PROGRAM_NAME}: {message}");
                ExitCode::from(2)
            }
        },
        Err(ArgError::NoCommand) => {
            eprint!("{}", help_text());
            ExitCode::from(2)
        }
        Err(err) => {
            eprintln!("{PROGRAM_NAME}: {err} (see {PROGRAM_NAME} --help)");
            ExitCode::from(2)
        }
    }
}

/// Loads a configuration; the message names the key that is wrong (ADR-0006, CONTRACT section 3).
pub(crate) fn load_config(path: &Path) -> Result<Config, String> {
    Config::load(path).map_err(|e| match &e.key {
        Some(key) => format!("{}: {key}: {}", path.display(), e.message),
        None => e.message.clone(),
    })
}

/// Runs `evosim run` (CONTRACT section 2, ADR-0020). Headless: nothing is printed to stdout. The simulation advances
/// exactly `ticks` ticks, sampling outside `tick()` at the ticks of `metrics::series_ticks`. The result is built in
/// memory and only then written (through a temporary file, then renamed), so a failed run writes no result file.
fn run_run(args: &RunArgs) -> Result<(), String> {
    let sample_every = args
        .sample_every
        .unwrap_or_else(|| metrics::default_sample_every(args.ticks));
    let options = runner::RunOptions {
        sample_every,
        with_metrics: args.metrics.is_some(),
        keep_state: args.save.is_some(),
    };
    // Create the output directories first, so an unusable location is reported before the run starts.
    for path in [Some(&args.out), args.save.as_ref(), args.metrics.as_ref()]
        .into_iter()
        .flatten()
    {
        let dir = parent_dir(path);
        std::fs::create_dir_all(&dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
    }

    let output = match (&args.load, &args.config) {
        (Some(path), _) => {
            // A checkpoint is read and checked before anything runs (ADR-0023 D2); any failure is exit 2.
            let bytes = std::fs::read(path).map_err(|e| format!("cannot read {}: {e}", path.display()))?;
            let checkpoint = checkpoint::read_file(&bytes)
                .map_err(|e| format!("{}: {e}", path.display()))?;
            runner::resume(checkpoint, args.ticks, options)?
        }
        (None, Some(config_path)) => {
            let mut config = load_config(config_path)?;
            if let Some(seed) = args.seed {
                config.seed = seed;
            }
            runner::run_config(&config, args.ticks, options)?
        }
        (None, None) => return Err("'run' requires --config FILE or --load FILE".to_string()),
    };
    let (result, log, state) = (output.result, output.metrics, output.state);
    // Every text and checkpoint is built before anything is written, so a failure writes no result file.
    let text = result.to_json()?;
    let checkpoint_bytes = match (&args.save, state) {
        (Some(_), Some(state)) => Some(checkpoint::write_file(&state, result.seed)),
        _ => None,
    };
    let metrics_text = match (&args.metrics, &log) {
        (Some(path), Some(log)) => {
            let info = analytics::RunInfo {
                seed: result.seed,
                tick_start: result.tick_start,
                tick_end: result.tick_end,
                sample_every,
            };
            Some((path, log.to_json(&info)?))
        }
        _ => None,
    };
    if let (Some(path), Some(bytes)) = (&args.save, &checkpoint_bytes) {
        write_bytes_atomically(path, bytes)?;
    }
    if let Some((path, text)) = metrics_text {
        write_atomically(path, &text)?;
    }
    write_atomically(&args.out, &text)
}

/// The directory a file is written into; `.` for a bare file name.
pub(crate) fn parent_dir(path: &Path) -> PathBuf {
    match path.parent() {
        Some(p) if !p.as_os_str().is_empty() => p.to_path_buf(),
        _ => PathBuf::from("."),
    }
}

/// Writes `text` to `path` through a temporary file in the same directory, then renames it over `path`. On failure the
/// temporary file is removed and an existing `path` is left unchanged.
pub(crate) fn write_atomically(path: &Path, text: &str) -> Result<(), String> {
    write_bytes_atomically(path, text.as_bytes())
}

/// [`write_atomically`] for binary data such as a checkpoint (ADR-0023 D1).
pub(crate) fn write_bytes_atomically(path: &Path, data: &[u8]) -> Result<(), String> {
    let name = path
        .file_name()
        .ok_or_else(|| format!("{} is not a file name", path.display()))?;
    let tmp = parent_dir(path).join(format!(
        ".{}.tmp-{}",
        name.to_string_lossy(),
        std::process::id()
    ));
    let fail = |e: std::io::Error| {
        let _ = std::fs::remove_file(&tmp);
        format!("cannot write {}: {e}", path.display())
    };
    std::fs::write(&tmp, data).map_err(fail)?;
    std::fs::rename(&tmp, path).map_err(fail)
}

/// The text of `evosim climate` for a configuration: the biome map, or the JSON export.
fn climate_text(config: &Config, format: ClimateFormat) -> Result<String, String> {
    let sim = Simulation::new(config).map_err(|e| format!("cannot build the world: {e}"))?;
    let climate = &sim.world().climate;
    Ok(match format {
        ClimateFormat::Text => climate.biome_map_text(),
        ClimateFormat::Json => climate.to_json() + "\n",
    })
}

/// Runs `evosim climate`. Errors are returned before anything is written, so a failed run leaves no output file.
/// The map is the requested output, so it goes to stdout (or to `--out`), not to stderr.
fn run_climate(args: &ClimateArgs) -> Result<(), String> {
    let config = Config::load(&args.config).map_err(|e| match &e.key {
        Some(key) => format!("{}: {key}: {}", args.config.display(), e.message),
        None => e.message.clone(),
    })?;
    let text = climate_text(&config, args.format)?;
    match &args.out {
        None => {
            let mut stdout = std::io::stdout().lock();
            stdout
                .write_all(text.as_bytes())
                .and_then(|_| stdout.flush())
                .map_err(|e| format!("cannot write to stdout: {e}"))
        }
        Some(path) => {
            if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
                std::fs::create_dir_all(parent)
                    .map_err(|e| format!("cannot create {}: {e}", parent.display()))?;
            }
            std::fs::write(path, text).map_err(|e| format!("cannot write {}: {e}", path.display()))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn small_config() -> Config {
        Config::from_json(
            r#"{"seed": 7, "world": {"width": 5, "height": 4},
                "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
        )
        .unwrap()
    }

    #[test]
    fn climate_text_has_one_line_per_row() {
        let text = climate_text(&small_config(), ClimateFormat::Text).unwrap();
        assert_eq!(text.lines().count(), 4);
        assert!(text.lines().all(|l| l.chars().count() == 5));
    }

    #[test]
    fn climate_json_is_one_object_with_all_cells() {
        let text = climate_text(&small_config(), ClimateFormat::Json).unwrap();
        assert!(text.starts_with('{') && text.trim_end().ends_with('}'));
        assert_eq!(text.matches("\"biome\"").count(), 20);
    }

    #[test]
    fn climate_run_writes_file_and_creates_parents() {
        let dir = std::env::temp_dir().join(format!("evosim-climate-test-{}", std::process::id()));
        let cfg_path = dir.join("cfg").join("c.json");
        small_config().save(&cfg_path).unwrap();
        let out = dir.join("out").join("map.txt");
        let args = ClimateArgs {
            config: cfg_path,
            format: ClimateFormat::Text,
            out: Some(out.clone()),
        };
        run_climate(&args).unwrap();
        let written = std::fs::read_to_string(&out).unwrap();
        assert_eq!(written.lines().count(), 4);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn climate_run_with_unreadable_config_is_an_error_and_writes_nothing() {
        let dir = std::env::temp_dir().join(format!("evosim-climate-bad-{}", std::process::id()));
        let out = dir.join("map.txt");
        let args = ClimateArgs {
            config: dir.join("missing.json"),
            format: ClimateFormat::Text,
            out: Some(out.clone()),
        };
        assert!(run_climate(&args).is_err());
        assert!(!out.exists());
    }

    #[test]
    fn climate_run_with_zero_width_is_an_error() {
        let bad = Config::from_json(
            r#"{"seed": 1, "world": {"width": 0, "height": 4},
                "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
        );
        // The configuration validator rejects zero sizes; if it ever accepted one, the world builder must too.
        match bad {
            Err(_) => {}
            Ok(c) => assert!(climate_text(&c, ClimateFormat::Text).is_err()),
        }
    }

    fn run_args(dir: &std::path::Path, ticks: u64) -> RunArgs {
        std::fs::create_dir_all(dir).unwrap();
        let cfg = dir.join("cfg.json");
        std::fs::write(
            &cfg,
            r#"{"seed": 5, "world": {"width": 8, "height": 6},
                "initial": {"plants": 20, "herbivores": 5, "carnivores": 2}}"#,
        )
        .unwrap();
        RunArgs {
            config: Some(cfg),
            load: None,
            save: None,
            ticks,
            out: dir.join("out").join("r.json"),
            seed: None,
            sample_every: None,
            metrics: None,
        }
    }

    #[test]
    fn run_writes_result_with_contract_keys_and_no_stale_temp_file() {
        let dir = std::env::temp_dir().join(format!("evosim-run-ok-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let args = run_args(&dir, 25);
        run_run(&args).unwrap();
        let text = std::fs::read_to_string(&args.out).unwrap();
        assert!(text.contains("\"tick_end\": 25"));
        assert!(text.contains("\"state_hash\": \""));
        let leftovers: Vec<_> = std::fs::read_dir(args.out.parent().unwrap())
            .unwrap()
            .map(|e| e.unwrap().file_name())
            .collect();
        assert_eq!(
            leftovers.len(),
            1,
            "only the result file remains: {leftovers:?}"
        );
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn run_metrics_file_is_written_and_leaves_the_result_state_hash_unchanged() {
        let dir = std::env::temp_dir().join(format!("evosim-run-metrics-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let plain = run_args(&dir, 25);
        run_run(&plain).unwrap();
        let with = RunArgs {
            out: dir.join("metrics-run").join("r.json"),
            metrics: Some(dir.join("metrics-run").join("m.json")),
            ..run_args(&dir, 25)
        };
        run_run(&with).unwrap();

        let hash_line = |path: &Path| {
            std::fs::read_to_string(path)
                .unwrap()
                .lines()
                .find(|l| l.contains("\"state_hash\""))
                .unwrap()
                .to_string()
        };
        assert_eq!(hash_line(&plain.out), hash_line(&with.out));

        let metrics_text = std::fs::read_to_string(dir.join("metrics-run").join("m.json")).unwrap();
        let value = evosim_core::config::json::parse(&metrics_text).expect("metrics file parses");
        assert!(matches!(value, evosim_core::config::json::Value::Object(_)));
        assert!(metrics_text.contains("\"format\": \"evosim-metrics\""));
        assert!(metrics_text.contains("\"tick_end\": 25"));
        // Default spacing for 25 ticks is 1: one sample per tick plus the start.
        let samples = metrics_text.lines().filter(|l| l.starts_with("    {\"tick\"")).count();
        assert_eq!(samples, 26, "{metrics_text}");
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn run_without_metrics_writes_no_metrics_file() {
        let dir = std::env::temp_dir().join(format!("evosim-run-nometrics-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        let args = run_args(&dir, 3);
        run_run(&args).unwrap();
        let files: Vec<_> = std::fs::read_dir(args.out.parent().unwrap()).unwrap().collect();
        assert_eq!(files.len(), 1);
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn run_with_bad_config_writes_nothing() {
        let dir = std::env::temp_dir().join(format!("evosim-run-bad-{}", std::process::id()));
        let _ = std::fs::remove_dir_all(&dir);
        std::fs::create_dir_all(&dir).unwrap();
        let cfg = dir.join("bad.json");
        std::fs::write(&cfg, r#"{"seed": "x", "world": {"width": 8, "height": 6}, "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#).unwrap();
        let args = RunArgs {
            config: Some(cfg),
            load: None,
            save: None,
            ticks: 1,
            out: dir.join("r.json"),
            seed: None,
            sample_every: None,
            metrics: None,
        };
        let err = run_run(&args).unwrap_err();
        assert!(err.contains("seed"), "message names the key: {err}");
        assert!(!args.out.exists());
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn version_json_matches_contract_shape() {
        assert_eq!(
            version_json(),
            format!(
                "{{\"name\": \"evosim\", \"version\": \"{}\", \"contract\": 1}}",
                PROGRAM_VERSION
            )
        );
        assert_eq!(PROGRAM_VERSION, "0.1.0");
    }

    #[test]
    fn help_lists_version_and_help_only() {
        let text = help_text();
        assert!(text.contains("version"));
        assert!(text.contains("--help"));
        assert!(text.contains("Usage: evosim"));
    }
}

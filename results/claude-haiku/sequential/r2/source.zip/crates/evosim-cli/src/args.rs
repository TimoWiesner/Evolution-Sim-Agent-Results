//! Hand-written command-line parsing (no third-party crates, see ADR-0001/ADR-0005).

use evosim_core::batch::Vary;
use evosim_core::config::json::{self, Value};
use evosim_ui::{UiArgs, UiMode};
use std::fmt;
use std::path::PathBuf;

/// A successfully parsed invocation.
#[derive(Debug, PartialEq)]
pub enum Command {
    /// `evosim version`
    Version,
    /// `evosim --help` or `evosim -h`
    Help,
    /// `evosim climate --config FILE [--format text|json] [--out FILE]` (ADR-0009)
    Climate(ClimateArgs),
    /// `evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--metrics FILE]` (ADR-0020 D1, ADR-0021 D4)
    Run(RunArgs),
    /// `evosim batch --config FILE --seeds S1,S2,... --ticks N --out-dir DIR [--vary KEY=V1,V2,...]... [...]` (ADR-0022 D1)
    Batch(BatchArgs),
    /// `evosim ui [--config FILE] [--port N] [--smoke-test | --screenshots DIR]` (ADR-0024 D1)
    Ui(UiArgs),
}

/// Parsed options of `evosim batch` (ADR-0022 D1). `vary` holds one entry per `--vary` in the order given; `jobs` is
/// the number of runs at the same time (default 1).
#[derive(Debug, PartialEq)]
pub struct BatchArgs {
    pub config: PathBuf,
    pub seeds: Vec<u64>,
    pub ticks: u64,
    pub out_dir: PathBuf,
    pub vary: Vec<Vary>,
    pub sample_every: Option<u64>,
    pub jobs: usize,
    pub csv: bool,
}

/// Parsed options of `evosim run`. `ticks` and `out` are required. Exactly one of `config` (a fresh run) and `load`
/// (a checkpoint, ADR-0023 D5) is given. `seed` and `sample_every` override the configuration seed and the default
/// sample spacing (1/100 of `ticks`, at least 1). `metrics` asks for the metrics file (ADR-0021 D4); `save` writes a
/// checkpoint of the final state (ADR-0023).
#[derive(Debug, PartialEq, Eq)]
pub struct RunArgs {
    pub config: Option<PathBuf>,
    pub load: Option<PathBuf>,
    pub ticks: u64,
    pub out: PathBuf,
    pub seed: Option<u64>,
    pub sample_every: Option<u64>,
    pub metrics: Option<PathBuf>,
    pub save: Option<PathBuf>,
}

/// Output format of `evosim climate`.
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum ClimateFormat {
    Text,
    Json,
}

/// Parsed options of `evosim climate`.
#[derive(Debug, PartialEq, Eq)]
pub struct ClimateArgs {
    pub config: PathBuf,
    pub format: ClimateFormat,
    /// `None` writes to stdout.
    pub out: Option<PathBuf>,
}

/// Why an invocation could not be parsed.
#[derive(Debug, PartialEq, Eq)]
pub enum ArgError {
    /// No command was given at all (help is printed to stderr, exit 2).
    NoCommand,
    /// The first word is not a known command.
    UnknownCommand(String),
    /// A known command received arguments it does not accept.
    UnexpectedArguments { command: String, extra: String },
    /// A required option is missing.
    MissingOption { command: String, option: String },
    /// An option was given without its value.
    MissingValue { command: String, option: String },
    /// A value is not one of the allowed values of its option.
    BadValue { option: String, value: String },
    /// An option was given more than once.
    RepeatedOption { command: String, option: String },
    /// Two options that cannot be given together (ADR-0023 D5).
    Conflict { first: String, second: String },
}

impl fmt::Display for ArgError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ArgError::NoCommand => write!(f, "no command given"),
            ArgError::UnknownCommand(c) => write!(f, "unknown command '{c}'"),
            ArgError::UnexpectedArguments { command, extra } => {
                write!(f, "unexpected argument '{extra}' for '{command}'")
            }
            ArgError::MissingOption { command, option } => {
                write!(f, "'{command}' requires {option}")
            }
            ArgError::MissingValue { command, option } => {
                write!(f, "{option} of '{command}' needs a value")
            }
            ArgError::BadValue { option, value } => {
                write!(f, "invalid value '{value}' for {option}")
            }
            ArgError::RepeatedOption { command, option } => {
                write!(f, "{option} given more than once for '{command}'")
            }
            ArgError::Conflict { first, second } => {
                write!(f, "{first} cannot be combined with {second}")
            }
        }
    }
}

/// Parses the arguments after the program name.
pub fn parse(args: &[String]) -> Result<Command, ArgError> {
    match args.split_first() {
        None => Err(ArgError::NoCommand),
        Some((first, rest)) => match first.as_str() {
            "--help" | "-h" => match rest.first() {
                None => Ok(Command::Help),
                Some(extra) => Err(ArgError::UnexpectedArguments {
                    command: first.clone(),
                    extra: extra.clone(),
                }),
            },
            "version" => match rest.first() {
                None => Ok(Command::Version),
                Some(extra) => Err(ArgError::UnexpectedArguments {
                    command: first.clone(),
                    extra: extra.clone(),
                }),
            },
            "climate" => parse_climate(rest),
            "run" => parse_run(rest),
            "batch" => parse_batch(rest),
            "ui" => parse_ui(rest),
            other => Err(ArgError::UnknownCommand(other.to_string())),
        },
    }
}

/// Parses the options of `evosim ui` (ADR-0024 D1). `--smoke-test` and `--screenshots` cannot be combined.
fn parse_ui(args: &[String]) -> Result<Command, ArgError> {
    let command = "ui";
    let mut config: Option<PathBuf> = None;
    let mut port: Option<u16> = None;
    let mut smoke = false;
    let mut screenshots: Option<PathBuf> = None;
    let mut it = args.iter();
    while let Some(option) = it.next() {
        let value = |it: &mut std::slice::Iter<'_, String>| {
            it.next().cloned().ok_or_else(|| ArgError::MissingValue {
                command: command.to_string(),
                option: option.clone(),
            })
        };
        let repeated = || ArgError::RepeatedOption {
            command: command.to_string(),
            option: option.clone(),
        };
        match option.as_str() {
            "--config" => {
                if config.is_some() {
                    return Err(repeated());
                }
                config = Some(PathBuf::from(value(&mut it)?));
            }
            "--port" => {
                if port.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                port = Some(v.parse::<u16>().map_err(|_| ArgError::BadValue {
                    option: "--port".into(),
                    value: v.clone(),
                })?);
            }
            "--smoke-test" => {
                if smoke {
                    return Err(repeated());
                }
                smoke = true;
            }
            "--screenshots" => {
                if screenshots.is_some() {
                    return Err(repeated());
                }
                screenshots = Some(PathBuf::from(value(&mut it)?));
            }
            other => {
                return Err(ArgError::UnexpectedArguments {
                    command: command.to_string(),
                    extra: other.to_string(),
                })
            }
        }
    }
    let mode = match (smoke, screenshots) {
        (true, Some(_)) => {
            return Err(ArgError::Conflict {
                first: "--smoke-test".into(),
                second: "--screenshots".into(),
            })
        }
        (true, None) => UiMode::SmokeTest,
        (false, Some(dir)) => UiMode::Screenshots(dir),
        (false, None) => UiMode::Serve,
    };
    Ok(Command::Ui(UiArgs {
        config,
        port: port.unwrap_or(0),
        mode,
    }))
}

/// Parses the options of `evosim climate`. `--config` is required; `--format` defaults to `text`.
fn parse_climate(args: &[String]) -> Result<Command, ArgError> {
    let command = "climate";
    let mut config: Option<PathBuf> = None;
    let mut format = ClimateFormat::Text;
    let mut out: Option<PathBuf> = None;
    let mut it = args.iter();
    while let Some(option) = it.next() {
        let value = |it: &mut std::slice::Iter<'_, String>| {
            it.next().cloned().ok_or_else(|| ArgError::MissingValue {
                command: command.to_string(),
                option: option.clone(),
            })
        };
        match option.as_str() {
            "--config" => config = Some(PathBuf::from(value(&mut it)?)),
            "--out" => out = Some(PathBuf::from(value(&mut it)?)),
            "--format" => {
                let v = value(&mut it)?;
                format = match v.as_str() {
                    "text" => ClimateFormat::Text,
                    "json" => ClimateFormat::Json,
                    _ => {
                        return Err(ArgError::BadValue {
                            option: "--format".into(),
                            value: v,
                        })
                    }
                };
            }
            other => {
                return Err(ArgError::UnexpectedArguments {
                    command: command.to_string(),
                    extra: other.to_string(),
                })
            }
        }
    }
    let config = config.ok_or_else(|| ArgError::MissingOption {
        command: command.to_string(),
        option: "--config FILE".to_string(),
    })?;
    Ok(Command::Climate(ClimateArgs {
        config,
        format,
        out,
    }))
}

/// Parses an unsigned integer option value; anything else (sign, text, overflow) is a `BadValue`.
fn parse_u64(option: &str, value: &str) -> Result<u64, ArgError> {
    value.parse::<u64>().map_err(|_| ArgError::BadValue {
        option: option.to_string(),
        value: value.to_string(),
    })
}

/// Parses the options of `evosim run` (ADR-0020 D1, ADR-0023 D5). Every option may appear at most once.
fn parse_run(args: &[String]) -> Result<Command, ArgError> {
    let command = "run";
    let mut config: Option<PathBuf> = None;
    let mut load: Option<PathBuf> = None;
    let mut save: Option<PathBuf> = None;
    let mut ticks: Option<u64> = None;
    let mut out: Option<PathBuf> = None;
    let mut seed: Option<u64> = None;
    let mut sample_every: Option<u64> = None;
    let mut metrics: Option<PathBuf> = None;
    let mut it = args.iter();
    while let Some(option) = it.next() {
        let value = |it: &mut std::slice::Iter<'_, String>| {
            it.next().cloned().ok_or_else(|| ArgError::MissingValue {
                command: command.to_string(),
                option: option.clone(),
            })
        };
        let repeated = || ArgError::RepeatedOption {
            command: command.to_string(),
            option: option.clone(),
        };
        match option.as_str() {
            "--config" => {
                if config.is_some() {
                    return Err(repeated());
                }
                config = Some(PathBuf::from(value(&mut it)?));
            }
            "--out" => {
                if out.is_some() {
                    return Err(repeated());
                }
                out = Some(PathBuf::from(value(&mut it)?));
            }
            "--ticks" => {
                if ticks.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                ticks = Some(parse_u64("--ticks", &v)?);
            }
            "--seed" => {
                if seed.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                seed = Some(parse_u64("--seed", &v)?);
            }
            "--sample-every" => {
                if sample_every.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                let k = parse_u64("--sample-every", &v)?;
                if k == 0 {
                    return Err(ArgError::BadValue {
                        option: "--sample-every".into(),
                        value: v,
                    });
                }
                sample_every = Some(k);
            }
            "--metrics" => {
                if metrics.is_some() {
                    return Err(repeated());
                }
                metrics = Some(PathBuf::from(value(&mut it)?));
            }
            "--save" => {
                if save.is_some() {
                    return Err(repeated());
                }
                save = Some(PathBuf::from(value(&mut it)?));
            }
            "--load" => {
                if load.is_some() {
                    return Err(repeated());
                }
                load = Some(PathBuf::from(value(&mut it)?));
            }
            other => {
                return Err(ArgError::UnexpectedArguments {
                    command: command.to_string(),
                    extra: other.to_string(),
                })
            }
        }
    }
    let missing = |option: &str| ArgError::MissingOption {
        command: command.to_string(),
        option: option.to_string(),
    };
    let out = out.ok_or_else(|| missing("--out FILE"))?;
    // Files written by the same run must have different names; the second write would overwrite the first.
    for (option, path) in [("--metrics", &metrics), ("--save", &save)] {
        if path.as_deref() == Some(out.as_path()) {
            return Err(ArgError::BadValue {
                option: option.into(),
                value: out.display().to_string(),
            });
        }
    }
    if let (Some(s), Some(m)) = (save.as_deref(), metrics.as_deref()) {
        if s == m {
            return Err(ArgError::BadValue {
                option: "--save".into(),
                value: s.display().to_string(),
            });
        }
    }
    if let (Some(s), Some(l)) = (save.as_deref(), load.as_deref()) {
        if s == l {
            return Err(ArgError::BadValue {
                option: "--save".into(),
                value: s.display().to_string(),
            });
        }
    }
    if load.is_some() {
        // A checkpoint carries its own configuration and seed (ADR-0023 D5).
        if config.is_some() {
            return Err(ArgError::Conflict {
                first: "--load".into(),
                second: "--config".into(),
            });
        }
        if seed.is_some() {
            return Err(ArgError::Conflict {
                first: "--load".into(),
                second: "--seed".into(),
            });
        }
    } else if config.is_none() {
        return Err(missing("--config FILE or --load FILE"));
    }
    if load.as_deref() == Some(out.as_path()) {
        return Err(ArgError::BadValue {
            option: "--load".into(),
            value: out.display().to_string(),
        });
    }
    Ok(Command::Run(RunArgs {
        config,
        load,
        ticks: ticks.ok_or_else(|| missing("--ticks N"))?,
        out,
        seed,
        sample_every,
        metrics,
        save,
    }))
}

/// Parses a `--seeds` list: at least one `u64`, no duplicates (ADR-0022 D1).
fn parse_seeds(list: &str) -> Result<Vec<u64>, ArgError> {
    let bad = |item: &str| ArgError::BadValue {
        option: "--seeds".into(),
        value: item.to_string(),
    };
    let mut seeds = Vec::new();
    for item in list.split(',') {
        let seed = item.parse::<u64>().map_err(|_| bad(item))?;
        if seeds.contains(&seed) {
            return Err(bad(item));
        }
        seeds.push(seed);
    }
    Ok(seeds)
}

/// Parses one `--vary KEY=V1,V2,...`. The key is a dotted configuration key except `seed`; each value is an integer,
/// a real number or `true`/`false` (ADR-0022 D1). Whether the key exists is checked when the runs are planned.
fn parse_vary(spec: &str) -> Result<Vary, ArgError> {
    let bad = |value: &str| ArgError::BadValue {
        option: "--vary".into(),
        value: value.to_string(),
    };
    let (key, list) = spec.split_once('=').ok_or_else(|| bad(spec))?;
    if key.is_empty() || key == "seed" {
        return Err(bad(spec));
    }
    let mut values = Vec::new();
    for item in list.split(',') {
        match json::parse(item) {
            Ok(v @ (Value::Int(_) | Value::Real(_) | Value::Bool(_))) => values.push(v),
            _ => return Err(bad(item)),
        }
    }
    Ok(Vary {
        key: key.to_string(),
        values,
    })
}

/// Parses the options of `evosim batch` (ADR-0022 D1). Every option may appear once, except `--vary`.
fn parse_batch(args: &[String]) -> Result<Command, ArgError> {
    let command = "batch";
    let mut config: Option<PathBuf> = None;
    let mut seeds: Option<Vec<u64>> = None;
    let mut ticks: Option<u64> = None;
    let mut out_dir: Option<PathBuf> = None;
    let mut vary: Vec<Vary> = Vec::new();
    let mut sample_every: Option<u64> = None;
    let mut jobs: Option<usize> = None;
    let mut csv = false;
    let mut it = args.iter();
    while let Some(option) = it.next() {
        let value = |it: &mut std::slice::Iter<'_, String>| {
            it.next().cloned().ok_or_else(|| ArgError::MissingValue {
                command: command.to_string(),
                option: option.clone(),
            })
        };
        let repeated = || ArgError::RepeatedOption {
            command: command.to_string(),
            option: option.clone(),
        };
        match option.as_str() {
            "--config" => {
                if config.is_some() {
                    return Err(repeated());
                }
                config = Some(PathBuf::from(value(&mut it)?));
            }
            "--out-dir" => {
                if out_dir.is_some() {
                    return Err(repeated());
                }
                out_dir = Some(PathBuf::from(value(&mut it)?));
            }
            "--seeds" => {
                if seeds.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                seeds = Some(parse_seeds(&v)?);
            }
            "--ticks" => {
                if ticks.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                ticks = Some(parse_u64("--ticks", &v)?);
            }
            "--sample-every" => {
                if sample_every.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                let k = parse_u64("--sample-every", &v)?;
                if k == 0 {
                    return Err(ArgError::BadValue {
                        option: "--sample-every".into(),
                        value: v,
                    });
                }
                sample_every = Some(k);
            }
            "--jobs" => {
                if jobs.is_some() {
                    return Err(repeated());
                }
                let v = value(&mut it)?;
                let j = parse_u64("--jobs", &v)?;
                jobs = Some(match usize::try_from(j) {
                    Ok(j) if j >= 1 => j,
                    _ => {
                        return Err(ArgError::BadValue {
                            option: "--jobs".into(),
                            value: v,
                        })
                    }
                });
            }
            "--vary" => {
                let v = value(&mut it)?;
                let sweep = parse_vary(&v)?;
                if vary.iter().any(|s| s.key == sweep.key) {
                    return Err(ArgError::BadValue {
                        option: "--vary".into(),
                        value: format!("{} (key given twice)", sweep.key),
                    });
                }
                vary.push(sweep);
            }
            "--csv" => {
                if csv {
                    return Err(repeated());
                }
                csv = true;
            }
            other => {
                return Err(ArgError::UnexpectedArguments {
                    command: command.to_string(),
                    extra: other.to_string(),
                })
            }
        }
    }
    let missing = |option: &str| ArgError::MissingOption {
        command: command.to_string(),
        option: option.to_string(),
    };
    Ok(Command::Batch(BatchArgs {
        config: config.ok_or_else(|| missing("--config FILE"))?,
        seeds: seeds.ok_or_else(|| missing("--seeds S1,S2,..."))?,
        ticks: ticks.ok_or_else(|| missing("--ticks N"))?,
        out_dir: out_dir.ok_or_else(|| missing("--out-dir DIR"))?,
        vary,
        sample_every,
        jobs: jobs.unwrap_or(1),
        csv,
    }))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ui(parts: &[&str]) -> Result<Command, ArgError> {
        let args: Vec<String> = std::iter::once("ui").chain(parts.iter().copied()).map(String::from).collect();
        parse(&args)
    }

    #[test]
    fn ui_defaults_to_serving_on_an_ephemeral_port() {
        assert_eq!(
            ui(&[]),
            Ok(Command::Ui(UiArgs { config: None, port: 0, mode: UiMode::Serve }))
        );
    }

    #[test]
    fn ui_accepts_config_port_and_both_test_modes() {
        assert_eq!(
            ui(&["--config", "c.json", "--port", "8080"]),
            Ok(Command::Ui(UiArgs {
                config: Some(PathBuf::from("c.json")),
                port: 8080,
                mode: UiMode::Serve
            }))
        );
        assert_eq!(
            ui(&["--smoke-test", "--config", "c.json"]),
            Ok(Command::Ui(UiArgs {
                config: Some(PathBuf::from("c.json")),
                port: 0,
                mode: UiMode::SmokeTest
            }))
        );
        assert_eq!(
            ui(&["--screenshots", "/tmp/shots"]),
            Ok(Command::Ui(UiArgs {
                config: None,
                port: 0,
                mode: UiMode::Screenshots(PathBuf::from("/tmp/shots"))
            }))
        );
    }

    #[test]
    fn ui_rejects_invalid_combinations_and_values() {
        assert!(matches!(ui(&["--smoke-test", "--screenshots", "d"]), Err(ArgError::Conflict { .. })));
        assert!(matches!(ui(&["--screenshots"]), Err(ArgError::MissingValue { .. })));
        assert!(matches!(ui(&["--port", "x"]), Err(ArgError::BadValue { .. })));
        assert!(matches!(ui(&["--port", "70000"]), Err(ArgError::BadValue { .. })));
        assert!(matches!(ui(&["--port"]), Err(ArgError::MissingValue { .. })));
        assert!(matches!(ui(&["--smoke-test", "--smoke-test"]), Err(ArgError::RepeatedOption { .. })));
        assert!(matches!(ui(&["--bogus"]), Err(ArgError::UnexpectedArguments { .. })));
    }

    fn v(items: &[&str]) -> Vec<String> {
        items.iter().map(|s| s.to_string()).collect()
    }

    #[test]
    fn version_command() {
        assert_eq!(parse(&v(&["version"])), Ok(Command::Version));
    }

    #[test]
    fn help_flags() {
        assert_eq!(parse(&v(&["--help"])), Ok(Command::Help));
        assert_eq!(parse(&v(&["-h"])), Ok(Command::Help));
    }

    #[test]
    fn no_arguments_is_no_command() {
        assert_eq!(parse(&[]), Err(ArgError::NoCommand));
    }

    #[test]
    fn unknown_command_is_rejected() {
        assert_eq!(
            parse(&v(&["frobnicate"])),
            Err(ArgError::UnknownCommand("frobnicate".to_string()))
        );
    }

    #[test]
    fn run_needs_config_ticks_and_out() {
        assert!(matches!(
            parse(&v(&["run"])),
            Err(ArgError::MissingOption { .. })
        ));
        assert!(matches!(
            parse(&v(&["run", "--ticks", "5", "--out", "o.json"])),
            Err(ArgError::MissingOption { .. })
        ));
        assert!(matches!(
            parse(&v(&["run", "--config", "c.json", "--out", "o.json"])),
            Err(ArgError::MissingOption { .. })
        ));
        assert!(matches!(
            parse(&v(&["run", "--config", "c.json", "--ticks", "5"])),
            Err(ArgError::MissingOption { .. })
        ));
    }

    #[test]
    fn run_parses_all_options_and_zero_ticks() {
        assert_eq!(
            parse(&v(&[
                "run",
                "--config",
                "c.json",
                "--ticks",
                "0",
                "--out",
                "o/r.json",
                "--seed",
                "9",
                "--sample-every",
                "2",
            ])),
            Ok(Command::Run(RunArgs {
                config: Some(PathBuf::from("c.json")),
                load: None,
                ticks: 0,
                out: PathBuf::from("o/r.json"),
                seed: Some(9),
                sample_every: Some(2),
                metrics: None,
                save: None,
            }))
        );
        match parse(&v(&[
            "run", "--config", "c", "--ticks", "1000", "--out", "r",
        ])) {
            Ok(Command::Run(a)) => {
                assert_eq!((a.seed, a.sample_every, a.ticks), (None, None, 1000));
            }
            other => panic!("unexpected {other:?}"),
        }
    }

    #[test]
    fn run_rejects_repeated_options() {
        let base = ["run", "--config", "c", "--ticks", "1", "--out", "o"];
        for option in ["--config", "--ticks", "--out"] {
            let mut args = base.to_vec();
            args.extend([option, "x"]);
            assert!(
                matches!(parse(&v(&args)), Err(ArgError::RepeatedOption { .. })),
                "{option}"
            );
        }
        assert!(matches!(
            parse(&v(&[
                "run", "--config", "c", "--ticks", "1", "--out", "o", "--seed", "1", "--seed", "2"
            ])),
            Err(ArgError::RepeatedOption { .. })
        ));
    }

    #[test]
    fn run_parses_metrics_and_refuses_repeats_and_the_result_name() {
        match parse(&v(&[
            "run", "--config", "c", "--ticks", "3", "--out", "r.json", "--metrics", "m/m.json",
        ])) {
            Ok(Command::Run(a)) => assert_eq!(a.metrics, Some(PathBuf::from("m/m.json"))),
            other => panic!("unexpected {other:?}"),
        }
        let base = ["run", "--config", "c", "--ticks", "1", "--out", "o"];
        let mut repeated = base.to_vec();
        repeated.extend(["--metrics", "a", "--metrics", "b"]);
        assert!(matches!(
            parse(&v(&repeated)),
            Err(ArgError::RepeatedOption { .. })
        ));
        let mut same = base.to_vec();
        same.extend(["--metrics", "o"]);
        assert!(matches!(
            parse(&v(&same)),
            Err(ArgError::BadValue { ref option, .. }) if option == "--metrics"
        ));
        let mut missing = base.to_vec();
        missing.push("--metrics");
        assert!(matches!(
            parse(&v(&missing)),
            Err(ArgError::MissingValue { .. })
        ));
    }

    #[test]
    fn run_rejects_bad_numbers_and_zero_sample_interval() {
        let cases: [&[&str]; 5] = [
            &["run", "--config", "c", "--ticks", "-1", "--out", "o"],
            &["run", "--config", "c", "--ticks", "1.5", "--out", "o"],
            &[
                "run", "--config", "c", "--ticks", "1", "--out", "o", "--seed", "-3",
            ],
            &[
                "run",
                "--config",
                "c",
                "--ticks",
                "1",
                "--out",
                "o",
                "--sample-every",
                "0",
            ],
            &[
                "run",
                "--config",
                "c",
                "--ticks",
                "1",
                "--out",
                "o",
                "--sample-every",
                "x",
            ],
        ];
        for args in cases {
            assert!(
                matches!(parse(&v(args)), Err(ArgError::BadValue { .. })),
                "{args:?}"
            );
        }
    }

    #[test]
    fn run_rejects_missing_value_and_unknown_options() {
        assert!(matches!(
            parse(&v(&["run", "--config", "c", "--ticks", "1", "--out"])),
            Err(ArgError::MissingValue { .. })
        ));
        assert!(matches!(
            parse(&v(&[
                "run", "--config", "c", "--ticks", "1", "--out", "o", "--zoom", "3"
            ])),
            Err(ArgError::UnexpectedArguments { .. })
        ));
    }

    #[test]
    fn run_accepts_save_from_config_and_load_without_config() {
        assert_eq!(
            parse(&v(&[
                "run", "--config", "c", "--ticks", "1", "--out", "o", "--save", "s.bin",
            ])),
            Ok(Command::Run(RunArgs {
                config: Some(PathBuf::from("c")),
                load: None,
                ticks: 1,
                out: PathBuf::from("o"),
                seed: None,
                sample_every: None,
                metrics: None,
                save: Some(PathBuf::from("s.bin")),
            }))
        );
        assert_eq!(
            parse(&v(&["run", "--load", "s.bin", "--ticks", "0", "--out", "o", "--save", "t.bin"])),
            Ok(Command::Run(RunArgs {
                config: None,
                load: Some(PathBuf::from("s.bin")),
                ticks: 0,
                out: PathBuf::from("o"),
                seed: None,
                sample_every: None,
                metrics: None,
                save: Some(PathBuf::from("t.bin")),
            }))
        );
    }

    #[test]
    fn run_refuses_the_combinations_of_adr_0023_d5() {
        // --load with --config or --seed: the checkpoint carries its own configuration and seed.
        assert!(matches!(
            parse(&v(&["run", "--load", "s", "--config", "c", "--ticks", "1", "--out", "o"])),
            Err(ArgError::Conflict { .. })
        ));
        assert!(matches!(
            parse(&v(&["run", "--load", "s", "--seed", "3", "--ticks", "1", "--out", "o"])),
            Err(ArgError::Conflict { .. })
        ));
        // Neither --config nor --load.
        assert!(matches!(
            parse(&v(&["run", "--ticks", "1", "--out", "o"])),
            Err(ArgError::MissingOption { .. })
        ));
        // --save or --load given the same path as --out, or --save as --metrics.
        for args in [
            vec!["run", "--config", "c", "--ticks", "1", "--out", "o", "--save", "o"],
            vec!["run", "--load", "o", "--ticks", "1", "--out", "o"],
            vec!["run", "--config", "c", "--ticks", "1", "--out", "o", "--save", "m", "--metrics", "m"],
            vec!["run", "--load", "s", "--ticks", "1", "--out", "o", "--save", "s"],
        ] {
            assert!(matches!(parse(&v(&args)), Err(ArgError::BadValue { .. })), "{args:?}");
        }
        // Repeated --save is refused like any repeated option.
        assert!(matches!(
            parse(&v(&["run", "--config", "c", "--ticks", "1", "--out", "o", "--save", "a", "--save", "b"])),
            Err(ArgError::RepeatedOption { .. })
        ));
        // A missing value is refused.
        assert!(matches!(
            parse(&v(&["run", "--config", "c", "--ticks", "1", "--out", "o", "--save"])),
            Err(ArgError::MissingValue { .. })
        ));
    }

    #[test]
    fn extra_arguments_are_rejected() {
        assert_eq!(
            parse(&v(&["version", "--json"])),
            Err(ArgError::UnexpectedArguments {
                command: "version".to_string(),
                extra: "--json".to_string(),
            })
        );
        assert!(parse(&v(&["--help", "x"])).is_err());
    }

    #[test]
    fn climate_defaults_and_options() {
        assert_eq!(
            parse(&v(&["climate", "--config", "c.json"])),
            Ok(Command::Climate(ClimateArgs {
                config: PathBuf::from("c.json"),
                format: ClimateFormat::Text,
                out: None,
            }))
        );
        assert_eq!(
            parse(&v(&[
                "climate", "--format", "json", "--config", "c.json", "--out", "o/m.json"
            ])),
            Ok(Command::Climate(ClimateArgs {
                config: PathBuf::from("c.json"),
                format: ClimateFormat::Json,
                out: Some(PathBuf::from("o/m.json")),
            }))
        );
    }

    #[test]
    fn climate_rejects_bad_invocations() {
        assert!(matches!(
            parse(&v(&["climate"])),
            Err(ArgError::MissingOption { .. })
        ));
        assert!(matches!(
            parse(&v(&["climate", "--config"])),
            Err(ArgError::MissingValue { .. })
        ));
        assert!(matches!(
            parse(&v(&["climate", "--config", "c", "--format", "bogus"])),
            Err(ArgError::BadValue { .. })
        ));
        assert!(matches!(
            parse(&v(&["climate", "--config", "c", "--zoom", "3"])),
            Err(ArgError::UnexpectedArguments { .. })
        ));
    }

    #[test]
    fn error_messages_name_the_problem() {
        let msg = ArgError::UnknownCommand("zap".into()).to_string();
        assert!(msg.contains("zap"));
    }

    /// `batch --config c.json --ticks 10 --out-dir d` plus `extra`; tests add `--seeds` themselves.
    fn batch(extra: &[&str]) -> Result<BatchArgs, ArgError> {
        let mut all = vec!["batch", "--config", "c.json", "--ticks", "10", "--out-dir", "d"];
        all.extend_from_slice(extra);
        match parse(&v(&all))? {
            Command::Batch(args) => Ok(args),
            other => panic!("{other:?}"),
        }
    }

    #[test]
    fn batch_parses_the_required_options_and_defaults() {
        let args = batch(&["--seeds", "1,2"]).unwrap();
        assert_eq!(args.seeds, vec![1, 2]);
        assert_eq!(args.ticks, 10);
        assert_eq!(args.jobs, 1);
        assert!(!args.csv);
        assert!(args.vary.is_empty());
        assert_eq!(args.sample_every, None);
    }

    #[test]
    fn batch_parses_vary_csv_and_jobs() {
        let args = batch(&[
            "--seeds", "1,2", "--vary", "initial.plants=200,400", "--vary", "herbivores.metabolism=0.5,1", "--csv", "--jobs", "4",
        ])
        .unwrap();
        assert_eq!(args.vary.len(), 2);
        assert_eq!(args.vary[0].key, "initial.plants");
        assert_eq!(args.vary[0].values, vec![Value::Int(200), Value::Int(400)]);
        assert_eq!(args.vary[1].values, vec![Value::Real(0.5), Value::Int(1)]);
        assert!(args.csv);
        assert_eq!(args.jobs, 4);
    }

    #[test]
    fn batch_refuses_bad_seeds_and_vary_specs() {
        let bad: [&[&str]; 8] = [
            &["--seeds", "1,1"],
            &["--seeds", ""],
            &["--seeds", "x"],
            &["--seeds", "1", "--vary", "initial.plants"],
            &["--seeds", "1", "--vary", "=1,2"],
            &["--seeds", "1", "--vary", "seed=1,2"],
            &["--seeds", "1", "--vary", "initial.plants=1,,2"],
            &["--seeds", "1", "--vary", "initial.plants=\"a\""],
        ];
        for extra in bad {
            assert!(matches!(batch(extra), Err(ArgError::BadValue { .. })), "{extra:?}");
        }
    }

    #[test]
    fn batch_refuses_repeats_and_bad_numbers() {
        fn with<'a>(extra: &[&'a str]) -> Vec<&'a str> {
            let mut all = vec!["--seeds", "1"];
            all.extend_from_slice(extra);
            all
        }
        let jobs0 = with(&["--jobs", "0"]);
        assert!(matches!(batch(&jobs0), Err(ArgError::BadValue { .. })));
        let twice = with(&["--vary", "initial.plants=1", "--vary", "initial.plants=2"]);
        assert!(matches!(batch(&twice), Err(ArgError::BadValue { .. })));
        let sample0 = with(&["--sample-every", "0"]);
        assert!(matches!(batch(&sample0), Err(ArgError::BadValue { .. })));
        let unknown = with(&["--bogus"]);
        assert!(matches!(batch(&unknown), Err(ArgError::UnexpectedArguments { .. })));
        let csv2 = with(&["--csv", "--csv"]);
        assert!(matches!(batch(&csv2), Err(ArgError::RepeatedOption { .. })));
    }

    #[test]
    fn batch_requires_config_seeds_ticks_and_out_dir() {
        let full = ["batch", "--config", "c", "--seeds", "1", "--ticks", "1", "--out-dir", "d"];
        assert!(parse(&v(&full)).is_ok());
        for drop in [1usize, 3, 5, 7] {
            let cut: Vec<&str> = full.iter().enumerate().filter(|(i, _)| *i != drop && *i != drop + 1).map(|(_, s)| *s).collect();
            assert!(matches!(parse(&v(&cut)), Err(ArgError::MissingOption { .. })), "without {}", full[drop]);
        }
    }
}

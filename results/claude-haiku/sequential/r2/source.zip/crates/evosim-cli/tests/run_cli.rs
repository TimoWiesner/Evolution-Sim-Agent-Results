//! End-to-end tests of `evosim run` (docs/CONTRACT.md sections 2, 4, 5; ADR-0020). They start the built binary, so they
//! check the real flags, exit statuses, stdout/stderr and files.

use evosim_core::config::json::{self, Value};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

const CONFIG: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

/// A fresh, empty scratch directory for one test.
fn scratch(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("evosim-run-cli-{name}-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

fn write(dir: &Path, name: &str, text: &str) -> PathBuf {
    let path = dir.join(name);
    std::fs::write(&path, text).unwrap();
    path
}

/// Runs `evosim` with `args`, with DISPLAY and WAYLAND_DISPLAY removed (the run must not need a display).
fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .env_remove("DISPLAY")
        .env_remove("WAYLAND_DISPLAY")
        .output()
        .expect("evosim starts")
}

/// The result text without the two wall-clock lines (ADR-0020 D2), for byte comparison.
fn without_wall_clock(text: &str) -> String {
    text.lines()
        .filter(|l| !l.contains("\"elapsed_seconds\"") && !l.contains("\"ticks_per_second\""))
        .collect::<Vec<_>>()
        .join("\n")
}

fn parse(text: &str) -> Value {
    json::parse(text).expect("result is valid JSON")
}

fn get<'a>(v: &'a Value, key: &str) -> &'a Value {
    match v {
        Value::Object(entries) => entries
            .iter()
            .find(|(k, _)| k == key)
            .map(|(_, v)| v)
            .unwrap_or_else(|| panic!("missing key {key}")),
        _ => panic!("not an object while looking for {key}"),
    }
}

fn int(v: &Value) -> i128 {
    match v {
        Value::Int(i) => *i,
        other => panic!("not an integer: {other:?}"),
    }
}

/// Runs `evosim run` with the given configuration text, ticks and extra arguments, and returns the result text.
fn run_ok(dir: &Path, config_text: &str, out_name: &str, ticks: &str, extra: &[&str]) -> String {
    let cfg = write(dir, &format!("{out_name}.cfg.json"), config_text);
    let out = dir.join("results").join(out_name);
    let mut args = vec![
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        ticks,
        "--out",
        out.to_str().unwrap(),
    ];
    args.extend_from_slice(extra);
    let result = evosim(&args);
    assert_eq!(
        result.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&result.stderr)
    );
    assert!(result.stdout.is_empty(), "run prints nothing to stdout");
    std::fs::read_to_string(&out).unwrap()
}

#[test]
fn same_seed_gives_identical_results_end_to_end() {
    let dir = scratch("same-seed");
    let a = run_ok(&dir, CONFIG, "a.json", "300", &[]);
    let b = run_ok(&dir, CONFIG, "b.json", "300", &[]);
    assert_eq!(without_wall_clock(&a), without_wall_clock(&b));
    let (va, vb) = (parse(&a), parse(&b));
    for key in ["final", "totals", "series", "state_hash"] {
        assert_eq!(get(&va, key), get(&vb, key), "{key}");
    }
    assert_eq!(
        get(&va, "state_hash").clone(),
        get(&vb, "state_hash").clone()
    );
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn different_seed_gives_different_state_hash() {
    let dir = scratch("other-seed");
    let a = parse(&run_ok(&dir, CONFIG, "a.json", "50", &[]));
    let b = parse(&run_ok(&dir, CONFIG, "b.json", "50", &["--seed", "43"]));
    assert_ne!(get(&a, "state_hash"), get(&b, "state_hash"));
    assert_eq!(get(&b, "seed"), &Value::Int(43));
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn zero_ticks_is_valid_and_writes_one_sample() {
    let dir = scratch("zero");
    let v = parse(&run_ok(&dir, CONFIG, "z.json", "0", &[]));
    assert_eq!(int(get(&v, "tick_end")), 0);
    assert_eq!(int(get(&v, "tick_start")), 0);
    match get(&v, "series") {
        Value::Array(items) => assert_eq!(items.len(), 1),
        other => panic!("series is not an array: {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn all_extinct_still_runs_every_requested_tick() {
    // Only one carnivore and no food: it starves, then nothing is left. The run must still advance all 1,000 ticks.
    let dir = scratch("extinct");
    let config = r#"{"seed": 3, "world": {"width": 8, "height": 6},
                     "initial": {"plants": 0, "herbivores": 0, "carnivores": 1}}"#;
    let v = parse(&run_ok(
        &dir,
        config,
        "e.json",
        "1000",
        &["--sample-every", "100"],
    ));
    assert_eq!(int(get(&v, "tick_end")), 1000);
    let final_ = get(&v, "final");
    assert_eq!(int(get(final_, "carnivores")), 0);
    match get(&v, "series") {
        Value::Array(items) => {
            let last = &items[items.len() - 1];
            assert_eq!(int(get(last, "tick")), 1000);
            assert_eq!(items.len(), 11);
        }
        other => panic!("series is not an array: {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn default_sampling_is_one_hundredth_of_the_run() {
    let dir = scratch("default-k");
    let v = parse(&run_ok(&dir, CONFIG, "k.json", "1000", &[]));
    assert_eq!(int(get(&v, "sample_every")), 10);
    match get(&v, "series") {
        Value::Array(items) => assert_eq!(items.len(), 101),
        other => panic!("series is not an array: {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn totals_balance_in_the_result_file() {
    let dir = scratch("balance");
    let v = parse(&run_ok(&dir, CONFIG, "t.json", "500", &[]));
    let totals = get(&v, "totals");
    for kind in ["plants", "herbivores", "carnivores"] {
        let initial = int(get(get(totals, "initial"), kind));
        let births = int(get(get(totals, "births"), kind));
        let deaths = int(get(get(totals, "deaths"), kind));
        let living = int(get(get(&v, "final"), kind));
        assert_eq!(initial + births - deaths, living, "{kind}");
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn errors_exit_2_write_nothing_and_print_a_message() {
    let dir = scratch("errors");
    let good = write(&dir, "good.json", CONFIG);
    let good_s = good.to_str().unwrap();
    let out = dir.join("out").join("r.json");
    let out_s = out.to_str().unwrap();
    let wrong_type = write(
        &dir,
        "type.json",
        r#"{"seed": "x", "world": {"width": 8, "height": 6}, "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
    );
    let missing_key = write(
        &dir,
        "missing.json",
        r#"{"seed": 1, "world": {"width": 8}, "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
    );
    let out_of_range = write(
        &dir,
        "range.json",
        r#"{"seed": 1, "world": {"width": 0, "height": 6}, "initial": {"plants": 0, "herbivores": 0, "carnivores": 0}}"#,
    );
    let unreadable = dir.join("no-such.json");

    let cases: Vec<Vec<&str>> = vec![
        vec![
            "run",
            "--config",
            wrong_type.to_str().unwrap(),
            "--ticks",
            "5",
            "--out",
            out_s,
        ],
        vec![
            "run",
            "--config",
            missing_key.to_str().unwrap(),
            "--ticks",
            "5",
            "--out",
            out_s,
        ],
        vec![
            "run",
            "--config",
            out_of_range.to_str().unwrap(),
            "--ticks",
            "5",
            "--out",
            out_s,
        ],
        vec![
            "run",
            "--config",
            unreadable.to_str().unwrap(),
            "--ticks",
            "5",
            "--out",
            out_s,
        ],
        vec![
            "run", "--config", good_s, "--ticks", "5", "--out", out_s, "--zoom", "3",
        ],
        vec!["run", "--config", good_s, "--ticks", "-5", "--out", out_s],
        vec![
            "run",
            "--config",
            good_s,
            "--ticks",
            "5",
            "--out",
            out_s,
            "--sample-every",
            "0",
        ],
        // A missing checkpoint (ADR-0023 D2): exit 2, no result file.
        vec!["run", "--load", "missing.bin", "--ticks", "5", "--out", out_s],
        // --load with --config (ADR-0023 D5).
        vec![
            "run", "--load", "missing.bin", "--config", good_s, "--ticks", "5", "--out", out_s,
        ],
        vec!["run", "--config", good_s, "--out", out_s],
    ];
    for args in cases {
        let result = evosim(&args);
        assert_eq!(result.status.code(), Some(2), "args {args:?}");
        assert!(
            !result.stderr.is_empty(),
            "args {args:?} prints a message on stderr"
        );
        assert!(
            result.stdout.is_empty(),
            "args {args:?} prints nothing on stdout"
        );
        assert!(!out.exists(), "args {args:?} wrote no result file");
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn failed_run_keeps_an_existing_result_file() {
    let dir = scratch("keep");
    let out = dir.join("r.json");
    std::fs::write(&out, "previous").unwrap();
    let bad = write(&dir, "bad.json", "{ not json");
    let result = evosim(&[
        "run",
        "--config",
        bad.to_str().unwrap(),
        "--ticks",
        "1",
        "--out",
        out.to_str().unwrap(),
    ]);
    assert_eq!(result.status.code(), Some(2));
    assert_eq!(std::fs::read_to_string(&out).unwrap(), "previous");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn runs_without_a_display_and_creates_parent_directories() {
    let dir = scratch("nodisplay");
    let cfg = write(&dir, "c.json", CONFIG);
    let out = dir.join("deep").join("er").join("r.json");
    let result = evosim(&[
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        "10",
        "--out",
        out.to_str().unwrap(),
    ]);
    assert_eq!(
        result.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&result.stderr)
    );
    assert!(out.exists());
    std::fs::remove_dir_all(&dir).unwrap();
}

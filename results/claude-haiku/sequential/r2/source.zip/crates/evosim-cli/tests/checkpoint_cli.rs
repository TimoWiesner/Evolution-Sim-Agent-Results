//! End-to-end tests of `evosim run --save` and `evosim run --load` (docs/CONTRACT.md sections 2, 5.2, 5.4; ADR-0023).
//! They start the built binary, so they check the real flags, exit statuses, stderr and files.

use evosim_core::config::json::{self, Value};
use evosim_core::sha256;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

/// Small world with weather on, so that the weather, the generator and every organism group take part.
const CONFIG: &str = r#"{
  "seed": 11,
  "world": { "width": 16, "height": 12 },
  "initial": { "plants": 60, "herbivores": 12, "carnivores": 4 },
  "climate": { "season_length": 40, "weather_amplitude": 0.5 }
}"#;

fn scratch(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("evosim-ckpt-cli-{name}-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

/// Runs `evosim` with `args`, with DISPLAY and WAYLAND_DISPLAY removed (the run must not need a display).
fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .env_remove("DISPLAY")
        .env_remove("WAYLAND_DISPLAY")
        .output()
        .expect("evosim starts")
}

/// The debug form of one top-level field of a result, for comparisons.
fn field(text: &str, key: &str) -> String {
    match json::parse(text).expect("result is valid JSON") {
        Value::Object(entries) => {
            let found = entries
                .into_iter()
                .find(|(k, _)| k == key)
                .unwrap_or_else(|| panic!("missing key {key}"));
            format!("{:?}", found.1)
        }
        _ => panic!("result is not an object"),
    }
}

fn config_path(dir: &Path) -> PathBuf {
    let path = dir.join("cfg.json");
    std::fs::write(&path, CONFIG).unwrap();
    path
}

fn ok(output: &Output) {
    assert_eq!(
        output.status.code(),
        Some(0),
        "stderr: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(output.stdout.is_empty(), "run prints nothing on stdout");
}

/// Asserts a failure of exit status 2 with a message on stderr, and no result file at `out`.
fn refused(output: &Output, out: &Path, why: &str) {
    assert_eq!(output.status.code(), Some(2), "{why}: exit status");
    assert!(!output.stderr.is_empty(), "{why}: message on stderr");
    assert!(output.stdout.is_empty(), "{why}: nothing on stdout");
    assert!(!out.exists(), "{why}: no result file");
}

/// Writes a checkpoint at `ticks` (from the configuration) and returns the checkpoint path and the saving run's
/// `state_hash`.
fn save_at(dir: &Path, cfg: &Path, ticks: &str, name: &str) -> (PathBuf, String) {
    let out = dir.join(format!("{name}.json"));
    let ckpt = dir.join(format!("{name}.bin"));
    let result = evosim(&[
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        ticks,
        "--out",
        out.to_str().unwrap(),
        "--save",
        ckpt.to_str().unwrap(),
    ]);
    ok(&result);
    let hash = field(&std::fs::read_to_string(&out).unwrap(), "state_hash");
    (ckpt, hash)
}

#[test]
fn save_and_resume_match_an_uninterrupted_run_at_several_split_points() {
    let dir = scratch("split");
    let cfg = config_path(&dir);
    let full = dir.join("full.json");
    ok(&evosim(&[
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        "60",
        "--out",
        full.to_str().unwrap(),
    ]));
    let full_text = std::fs::read_to_string(&full).unwrap();

    // Split at tick 0 (a save of the founders) and mid-run (ADR-0023 D6).
    for (split, name) in [(0u64, "t0"), (25, "t25")] {
        let (ckpt, saved_hash) = save_at(&dir, &cfg, &split.to_string(), name);
        let resumed = dir.join(format!("{name}-resumed.json"));
        ok(&evosim(&[
            "run",
            "--load",
            ckpt.to_str().unwrap(),
            "--ticks",
            &(60 - split).to_string(),
            "--out",
            resumed.to_str().unwrap(),
        ]));
        let text = std::fs::read_to_string(&resumed).unwrap();
        for key in ["state_hash", "final", "totals", "seed", "world"] {
            assert_eq!(field(&text, key), field(&full_text, key), "{key} at split {split}");
        }
        assert_eq!(field(&text, "tick_start"), format!("{:?}", Value::Int(split as i128)));
        assert_eq!(field(&text, "tick_end"), format!("{:?}", Value::Int(60)));

        // --ticks 0 writes the state of the checkpoint itself (ADR-0023 D5).
        let zero = dir.join(format!("{name}-zero.json"));
        ok(&evosim(&[
            "run",
            "--load",
            ckpt.to_str().unwrap(),
            "--ticks",
            "0",
            "--out",
            zero.to_str().unwrap(),
        ]));
        assert_eq!(
            field(&std::fs::read_to_string(&zero).unwrap(), "state_hash"),
            saved_hash,
            "split {split}"
        );
    }
}

#[test]
fn damaged_missing_and_wrong_checkpoints_exit_2_and_write_no_result() {
    let dir = scratch("errors");
    let cfg = config_path(&dir);
    let (ckpt, _) = save_at(&dir, &cfg, "10", "good");
    let good = std::fs::read(&ckpt).unwrap();
    let load = |path: &Path, extra: &[&str], out: &Path| {
        let mut args = vec!["run", "--load", path.to_str().unwrap(), "--ticks", "5"];
        args.extend_from_slice(extra);
        args.extend(["--out", out.to_str().unwrap()]);
        evosim(&args)
    };

    // Missing file.
    let out = dir.join("missing.json");
    refused(&load(&dir.join("nope.bin"), &[], &out), &out, "missing");

    // Truncated, and a flipped byte in the body.
    let truncated = dir.join("truncated.bin");
    std::fs::write(&truncated, &good[..good.len() / 2]).unwrap();
    let out = dir.join("truncated.json");
    refused(&load(&truncated, &[], &out), &out, "truncated");

    let mut flipped = good.clone();
    let mid = flipped.len() / 2;
    flipped[mid] ^= 0x10;
    let flipped_path = dir.join("flipped.bin");
    std::fs::write(&flipped_path, &flipped).unwrap();
    let out = dir.join("flipped.json");
    refused(&load(&flipped_path, &[], &out), &out, "flipped byte");

    // Wrong file version, with the digest recomputed so that only the version is wrong.
    let mut wrong = good.clone();
    wrong[8..12].copy_from_slice(&2u32.to_le_bytes());
    let n = wrong.len() - 32;
    let digest = sha256::digest(&wrong[..n]);
    wrong[n..].copy_from_slice(&digest);
    let wrong_path = dir.join("wrong-version.bin");
    std::fs::write(&wrong_path, &wrong).unwrap();
    let out = dir.join("wrong-version.json");
    let result = load(&wrong_path, &[], &out);
    refused(&result, &out, "wrong version");
    assert!(String::from_utf8_lossy(&result.stderr).contains("version"));

    // A result file given as a checkpoint.
    let result_file = dir.join("good.json");
    ok(&evosim(&[
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        "3",
        "--out",
        result_file.to_str().unwrap(),
    ]));
    let out = dir.join("as-checkpoint.json");
    let as_ckpt = dir.join("not-a-checkpoint.bin");
    std::fs::copy(&result_file, &as_ckpt).unwrap();
    refused(&load(&as_ckpt, &[], &out), &out, "result file as checkpoint");

    // Options that cannot be combined with --load.
    let out = dir.join("conflict.json");
    refused(&load(&ckpt, &["--seed", "3"], &out), &out, "--seed with --load");
    let out = dir.join("conflict2.json");
    refused(
        &load(&ckpt, &["--config", cfg.to_str().unwrap()], &out),
        &out,
        "--config with --load",
    );

    // A save that cannot be written (its directory is a file) leaves no result file.
    let blocker = dir.join("blocker");
    std::fs::write(&blocker, "x").unwrap();
    let out = dir.join("unsaved.json");
    let result = evosim(&[
        "run",
        "--config",
        cfg.to_str().unwrap(),
        "--ticks",
        "3",
        "--out",
        out.to_str().unwrap(),
        "--save",
        blocker.join("s.bin").to_str().unwrap(),
    ]);
    refused(&result, &out, "unwritable save directory");

    std::fs::remove_dir_all(&dir).unwrap();
}

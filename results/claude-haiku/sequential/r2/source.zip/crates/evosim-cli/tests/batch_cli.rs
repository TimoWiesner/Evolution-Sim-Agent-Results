//! End-to-end tests of `evosim batch` (docs/CONTRACT.md section 2; ADR-0022 D1-D7). They start the built binary and
//! check the real flags, exit statuses, files and the summary content.

use evosim_core::config::json::{self, Value};
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

const CONFIG: &str = r#"{
  "seed": 42,
  "world": { "width": 64, "height": 48 },
  "initial": { "plants": 400, "herbivores": 120, "carnivores": 20 }
}"#;

const KINDS: [&str; 3] = ["plants", "herbivores", "carnivores"];

fn scratch(name: &str) -> PathBuf {
    let dir = std::env::temp_dir().join(format!("evosim-batch-cli-{name}-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

fn evosim(args: &[&str]) -> Output {
    Command::new(env!("CARGO_BIN_EXE_evosim"))
        .args(args)
        .env_remove("DISPLAY")
        .env_remove("WAYLAND_DISPLAY")
        .output()
        .expect("evosim starts")
}

/// Runs `evosim batch` over the configuration in `dir` with the given extra arguments; asserts exit 0 and no stdout.
fn batch_ok(dir: &Path, out: &str, extra: &[&str]) -> PathBuf {
    let cfg = dir.join("cfg.json");
    if !cfg.exists() {
        std::fs::write(&cfg, CONFIG).unwrap();
    }
    let out_dir = dir.join(out);
    let mut args = vec!["batch", "--config", cfg.to_str().unwrap(), "--out-dir", out_dir.to_str().unwrap()];
    args.extend_from_slice(extra);
    let result = evosim(&args);
    assert_eq!(result.status.code(), Some(0), "stderr: {}", String::from_utf8_lossy(&result.stderr));
    assert!(result.stdout.is_empty(), "batch prints nothing to stdout");
    out_dir
}

/// A result text without the two wall-clock lines (ADR-0020 D2).
fn without_time(text: &str) -> String {
    text.lines()
        .filter(|l| !l.contains("\"elapsed_seconds\"") && !l.contains("\"ticks_per_second\""))
        .collect::<Vec<_>>()
        .join("\n")
}

fn get<'a>(v: &'a Value, key: &str) -> &'a Value {
    match v {
        Value::Object(fields) => &fields.iter().find(|(k, _)| k == key).unwrap_or_else(|| panic!("missing {key}")).1,
        other => panic!("not an object looking for {key}: {other:?}"),
    }
}

fn items(v: &Value) -> &[Value] {
    match v {
        Value::Array(items) => items,
        other => panic!("not an array: {other:?}"),
    }
}

fn as_f64(v: &Value) -> f64 {
    match v {
        Value::Int(i) => *i as f64,
        Value::Real(r) => *r,
        other => panic!("not a number: {other:?}"),
    }
}

fn as_u64(v: &Value) -> u64 {
    match v {
        Value::Int(i) => u64::try_from(*i).unwrap(),
        other => panic!("not an integer: {other:?}"),
    }
}

fn read_json(path: &Path) -> Value {
    let text = std::fs::read_to_string(path).unwrap_or_else(|e| panic!("{}: {e}", path.display()));
    json::parse(&text).unwrap_or_else(|e| panic!("{}: {e}", path.display()))
}

/// The 2 values x 2 seeds matrix of TASK-021: `--vary initial.plants=200,400 --seeds 1,2 --ticks 50`.
fn matrix(dir: &Path, out: &str, extra: &[&str]) -> PathBuf {
    let mut args = vec!["--vary", "initial.plants=200,400", "--seeds", "1,2", "--ticks", "50"];
    args.extend_from_slice(extra);
    batch_ok(dir, out, &args)
}

#[test]
fn matrix_writes_one_file_per_case_and_seed_and_a_summary_of_every_run() {
    let dir = scratch("matrix");
    let out = matrix(&dir, "m", &[]);
    for case in ["case-00", "case-01"] {
        for seed in [1, 2] {
            let f = out.join(case).join(format!("seed-{seed}.json"));
            assert!(f.is_file(), "{}", f.display());
            let r = read_json(&f);
            assert_eq!(as_u64(get(&r, "tick_end")), 50);
            assert_eq!(as_u64(get(&r, "seed")), seed);
        }
    }
    let summary = read_json(&out.join("summary.json"));
    assert_eq!(get(&summary, "format"), &Value::Str("evosim-batch-summary".into()));
    let runs = items(get(&summary, "runs"));
    assert_eq!(runs.len(), 4);
    let expected = [("case-00", 1, 200), ("case-00", 2, 200), ("case-01", 1, 400), ("case-01", 2, 400)];
    for (run, (case, seed, plants)) in runs.iter().zip(expected) {
        assert_eq!(get(run, "case"), &Value::Str(case.into()));
        assert_eq!(as_u64(get(run, "seed")), seed);
        assert_eq!(as_u64(get(get(run, "params"), "initial.plants")), plants);
        assert_eq!(as_u64(get(run, "tick_end")), 50);
        assert_eq!(as_u64(get(get(run, "initial"), "plants")), plants);
        assert!(get(run, "state_hash").clone() != Value::Str(String::new()));
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn aggregates_equal_values_recomputed_from_the_per_seed_files() {
    let dir = scratch("aggregates");
    let out = matrix(&dir, "m", &[]);
    let summary = read_json(&out.join("summary.json"));
    let aggregates = items(get(&summary, "aggregates"));
    assert_eq!(aggregates.len(), 2);
    for (case, agg) in ["case-00", "case-01"].iter().zip(aggregates) {
        assert_eq!(get(agg, "case"), &Value::Str((*case).into()));
        for kind in KINDS {
            let finals: Vec<f64> = [1, 2]
                .iter()
                .map(|seed| {
                    let r = read_json(&out.join(case).join(format!("seed-{seed}.json")));
                    as_f64(get(get(&r, "final"), kind))
                })
                .collect();
            let mean = finals.iter().sum::<f64>() / finals.len() as f64;
            let min = finals.iter().cloned().fold(f64::INFINITY, f64::min);
            let max = finals.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
            let sd = (finals.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / finals.len() as f64).sqrt();
            let extinct = finals.iter().filter(|x| **x == 0.0).count();
            let a = get(get(agg, "kinds"), kind);
            assert!((as_f64(get(a, "final_mean")) - mean).abs() < 1e-9, "{case} {kind} mean");
            assert!((as_f64(get(a, "final_min")) - min).abs() < 1e-9, "{case} {kind} min");
            assert!((as_f64(get(a, "final_max")) - max).abs() < 1e-9, "{case} {kind} max");
            assert!((as_f64(get(a, "final_sd")) - sd).abs() < 1e-9, "{case} {kind} sd");
            assert_eq!(as_u64(get(a, "extinct_runs")), extinct as u64, "{case} {kind} extinct");
        }
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn without_vary_the_files_are_the_contract_layout_and_equal_run_with_the_same_seed() {
    let dir = scratch("no-vary");
    let out = batch_ok(&dir, "b", &["--seeds", "1,2", "--ticks", "30"]);
    let cfg = dir.join("cfg.json");
    for seed in [1, 2] {
        let solo = dir.join(format!("solo-{seed}.json"));
        let seed_text = seed.to_string();
        let r = evosim(&["run", "--config", cfg.to_str().unwrap(), "--ticks", "30", "--seed", &seed_text, "--out", solo.to_str().unwrap()]);
        assert_eq!(r.status.code(), Some(0));
        let batch_file = std::fs::read_to_string(out.join(format!("seed-{seed}.json"))).unwrap();
        assert_eq!(without_time(&batch_file), without_time(&std::fs::read_to_string(&solo).unwrap()), "seed {seed}");
    }
    assert!(!out.join("case-00").exists(), "no case directories without --vary");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn the_same_batch_twice_gives_the_same_summary_and_per_seed_results() {
    let dir = scratch("repeat");
    let a = matrix(&dir, "a", &["--csv"]);
    let b = matrix(&dir, "b", &["--csv"]);
    assert_eq!(std::fs::read(a.join("summary.json")).unwrap(), std::fs::read(b.join("summary.json")).unwrap());
    assert_eq!(std::fs::read(a.join("runs.csv")).unwrap(), std::fs::read(b.join("runs.csv")).unwrap());
    assert_eq!(std::fs::read(a.join("aggregates.csv")).unwrap(), std::fs::read(b.join("aggregates.csv")).unwrap());
    for case in ["case-00", "case-01"] {
        for seed in [1, 2] {
            let rel = format!("{case}/seed-{seed}.json");
            assert_eq!(
                without_time(&std::fs::read_to_string(a.join(&rel)).unwrap()),
                without_time(&std::fs::read_to_string(b.join(&rel)).unwrap()),
                "{rel}"
            );
        }
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn jobs_two_gives_the_same_output_as_jobs_one() {
    let dir = scratch("jobs");
    let one = matrix(&dir, "one", &["--csv", "--jobs", "1"]);
    let two = matrix(&dir, "two", &["--csv", "--jobs", "2"]);
    assert_eq!(std::fs::read(one.join("summary.json")).unwrap(), std::fs::read(two.join("summary.json")).unwrap());
    assert_eq!(std::fs::read(one.join("runs.csv")).unwrap(), std::fs::read(two.join("runs.csv")).unwrap());
    for case in ["case-00", "case-01"] {
        for seed in [1, 2] {
            let rel = format!("{case}/seed-{seed}.json");
            assert_eq!(
                without_time(&std::fs::read_to_string(one.join(&rel)).unwrap()),
                without_time(&std::fs::read_to_string(two.join(&rel)).unwrap()),
                "{rel}"
            );
        }
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn csv_has_one_row_per_run_and_one_per_case_and_kind_and_agrees_with_the_summary() {
    let dir = scratch("csv");
    let out = matrix(&dir, "m", &["--csv"]);
    let runs_csv = std::fs::read_to_string(out.join("runs.csv")).unwrap();
    let agg_csv = std::fs::read_to_string(out.join("aggregates.csv")).unwrap();
    assert_eq!(runs_csv.lines().count(), 1 + 4);
    assert_eq!(agg_csv.lines().count(), 1 + 2 * 3);
    assert!(runs_csv.lines().next().unwrap().starts_with("case,seed,initial.plants,"));
    let summary = read_json(&out.join("summary.json"));
    for (line, run) in runs_csv.lines().skip(1).zip(items(get(&summary, "runs"))) {
        let hash = match get(run, "state_hash") {
            Value::Str(s) => s.clone(),
            other => panic!("{other:?}"),
        };
        assert!(line.ends_with(&hash), "{line}");
        let fields: Vec<&str> = line.split(',').collect();
        assert_eq!(fields[1], as_u64(get(run, "seed")).to_string());
        assert_eq!(fields[8], as_u64(get(get(run, "final"), "plants")).to_string());
    }
    let first = agg_csv.lines().nth(1).unwrap();
    assert!(first.starts_with("case-00,plants,2,"), "{first}");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn zero_ticks_writes_one_sample_per_run() {
    let dir = scratch("zero");
    let out = batch_ok(&dir, "z", &["--seeds", "5", "--ticks", "0"]);
    let r = read_json(&out.join("seed-5.json"));
    assert_eq!(as_u64(get(&r, "tick_end")), 0);
    assert_eq!(items(get(&r, "series")).len(), 1);
    std::fs::remove_dir_all(&dir).unwrap();
}

/// Each error exits 2, prints a message on stderr, writes nothing to stdout, and leaves no summary.json.
#[test]
fn invalid_batches_exit_two_and_write_no_summary() {
    let dir = scratch("errors");
    let cfg = dir.join("cfg.json");
    std::fs::write(&cfg, CONFIG).unwrap();
    let cases: [(&[&str], &str); 7] = [
        (&["--seeds", "1,1", "--ticks", "5"], "--seeds"),
        (&["--seeds", "1", "--ticks", "-1"], "--ticks"),
        (&["--seeds", "1", "--ticks", "5", "--vary", "initial.nothing=1,2"], "initial.nothing"),
        (&["--seeds", "1", "--ticks", "5", "--vary", "initial.plants=-1,2"], "initial.plants"),
        (&["--seeds", "1", "--ticks", "5", "--vary", "seed=1,2"], "--vary"),
        (&["--seeds", "1", "--ticks", "5", "--vary", "initial.plants=1,"], "--vary"),
        (&["--seeds", "1", "--ticks", "5", "--jobs", "0"], "--jobs"),
    ];
    for (i, (extra, needle)) in cases.iter().enumerate() {
        let out = dir.join(format!("e{i}"));
        let mut args = vec!["batch", "--config", cfg.to_str().unwrap(), "--out-dir", out.to_str().unwrap()];
        args.extend_from_slice(extra);
        let result = evosim(&args);
        assert_eq!(result.status.code(), Some(2), "{extra:?}");
        assert!(result.stdout.is_empty());
        let stderr = String::from_utf8_lossy(&result.stderr);
        assert!(stderr.contains(needle), "{extra:?}: {stderr}");
        assert!(!out.join("summary.json").exists(), "{extra:?}");
        assert!(!out.exists() || std::fs::read_dir(&out).unwrap().next().is_none(), "{extra:?} wrote files");
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#!/usr/bin/env python3
"""TASK-027 cause analysis (ADR-0028 D3): death causes and population curves from `evosim run --metrics` files.

Usage: python3 -I scripts/balance_causes.py METRICS_DIR SEED [SEED ...]

Reads `m<seed>.json` (metrics, `--sample-every 100`) and `s<seed>.json` (result, `--sample-every 100`) from METRICS_DIR.
For each seed prints: the first kind to reach zero living individuals (ties: both listed), its extinction tick (from the
result series, first zero), the cumulative deaths by cause and births of every kind up to that tick, and the living
count of every kind at ticks 0, 100, 200, 500, 1000, 2000 and the last tick. Writes to stdout only.
"""

import json
import os
import sys

KINDS = ("plants", "herbivores", "carnivores")
CAUSES = ("old_age", "starvation", "predation", "exposure", "injury")


def first_zero(series):
    out = {}
    for kind in KINDS:
        out[kind] = next((row["tick"] for row in series if row[kind] == 0), None)
    return out


def sample_at(samples, tick):
    best = None
    for s in samples:
        if s["tick"] <= tick:
            best = s
    return best


def main(argv):
    if len(argv) < 3:
        print(__doc__, file=sys.stderr)
        return 2
    directory = argv[1]
    for seed in argv[2:]:
        with open(os.path.join(directory, f"s{seed}.json"), encoding="utf-8") as fh:
            result = json.load(fh)
        with open(os.path.join(directory, f"m{seed}.json"), encoding="utf-8") as fh:
            metrics = json.load(fh)
        ext = first_zero(result["series"])
        dead = {k: t for k, t in ext.items() if t is not None and k != "plants"}
        first_kind = None
        if dead:
            first_tick = min(dead.values())
            first_kind = [k for k, t in dead.items() if t == first_tick]
        print(f"## seed {seed}")
        print(f"extinction ticks: " + ", ".join(f"{k} {ext[k] if ext[k] is not None else 'survives'}" for k in KINDS))
        print(f"first animal kind to die out: {first_kind if first_kind else 'none'}")
        samples = metrics["samples"]
        if first_kind:
            t_stop = first_tick
            s = sample_at(samples, t_stop)
            for kind in first_kind:
                print(f"deaths by cause for {kind} up to tick {t_stop} (sample at {s['tick']}):")
                print("  " + json.dumps(s[kind]["deaths_by_cause"]))
                print(f"  births of {kind} up to {s['tick']}: {s[kind]['births']}")
                print(f"  mean energy of {kind} at {s['tick']}: {s[kind]['mean_energy']}")
        print("population (plants / herbivores / carnivores) at ticks:")
        for t in (0, 100, 200, 500, 1000, 2000, metrics["tick_end"]):
            s = sample_at(samples, t)
            if s is None:
                continue
            print(
                f"  t={s['tick']}: "
                + " / ".join(str(s[k]["population"]) for k in KINDS)
                + "  herb-mean-energy "
                + str(s["herbivores"]["mean_energy"])
                + "  carn-mean-energy "
                + str(s["carnivores"]["mean_energy"])
            )
        print("death causes at the end of the run (herbivores / carnivores):")
        last = samples[-1]
        print("  herbivores " + json.dumps(last["herbivores"]["deaths_by_cause"]))
        print("  carnivores " + json.dumps(last["carnivores"]["deaths_by_cause"]))
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

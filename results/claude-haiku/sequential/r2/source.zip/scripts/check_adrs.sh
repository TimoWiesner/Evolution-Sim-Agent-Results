#!/usr/bin/env bash
# Checks the architecture records (docs/decisions/ADR-0001..0004, 0008..0014) and docs/ARCHITECTURE.md.
# Plain bash, no network. Exit 0 if every check passes, 1 otherwise. Prints one line per check.
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DOCS="$ROOT/docs"
fails=0
checks=0

pass() { checks=$((checks + 1)); echo "PASS  $1"; }
fail() { checks=$((checks + 1)); fails=$((fails + 1)); echo "FAIL  $1"; }

check() { # check <description> <command...>
    local desc="$1"; shift
    if "$@" >/dev/null 2>&1; then pass "$desc"; else fail "$desc"; fi
}

# Print the body of a "## <name>" section (up to the next "## " heading) of file $1.
section() {
    awk -v h="## $2" '
        index($0, h) == 1 && (length($0) == length(h) || substr($0, length(h)+1, 1) == " ") { on = 1; next }
        on && /^## / { on = 0 }
        on { print }
    ' "$1"
}

# True if the Consequences section of file $1 contains the whole word 'dist' (matches 'dist/' but not 'distance').
has_dist_word() { section "$1" "Consequences" | grep -qw 'dist'; }

# Self-test: the dist/ matcher must reject substrings. If this matched, the dist/ check would be a false pass.
if printf 'distance distinct\n' | grep -qw 'dist'; then
    fail "self-test: whole-word dist matcher must not match 'distance' or 'distinct'"
else
    pass "self-test: whole-word dist matcher rejects 'distance' and 'distinct'"
fi
if printf 'the dist/ folder\n' | grep -qw 'dist'; then
    pass "self-test: whole-word dist matcher accepts 'dist/'"
else
    fail "self-test: whole-word dist matcher accepts 'dist/'"
fi

ADRS=(
    "ADR-0001-language-and-runtime.md"
    "ADR-0002-ui-technology.md"
    "ADR-0003-neighbour-search.md"
    "ADR-0004-genome-and-species.md"
    "ADR-0008-random-generator-and-tick-scheduler.md"
    "ADR-0009-climate-zones-and-biomes.md"
    "ADR-0010-seasons-and-weather.md"
    "ADR-0011-organisms-and-life-cycle.md"
    "ADR-0012-plant-resources-and-growth.md"
    "ADR-0013-plant-reproduction-and-dispersal.md"
    "ADR-0014-animal-sensing-movement-and-sharing.md"
    "ADR-0015-herbivore-feeding-and-behaviour.md"
    "ADR-0016-carnivore-hunting-and-predation.md"
    "ADR-0024-ui-world-view.md"
    "ADR-0025-ui-run-controls-inspector-and-checkpoints.md"
    "ADR-0026-ui-scenarios-presets-and-charts.md"
    "ADR-0027-performance-measurement-and-optimisation.md"
)

for adr in "${ADRS[@]}"; do
    f="$DOCS/decisions/$adr"
    name="${adr:0:8}"
    check "$name exists" test -f "$f"
    [ -f "$f" ] || continue

    check "$name has Status line" grep -q '^Status: ' "$f"
    for h in "Context" "Considered alternatives" "Decision" "Consequences" "Verification strategy"; do
        check "$name has section '## $h'" grep -q "^## $h\$" "$f"
    done

    alts=$(section "$f" "Considered alternatives" | grep -cE '^[0-9]+\. \*\*')
    if [ "$alts" -ge 2 ]; then pass "$name lists $alts alternatives (need >= 2)"
    else fail "$name lists $alts alternatives (need >= 2)"; fi

    # Keyword checks. 'performance' and 'testab' are specific stems; 'testab' is used instead of the bare
    # 'test' because 'test' also matches inside unrelated words. The dist/ check is whole-word and
    # restricted to the Consequences section, so 'distance' or 'distinct' cannot satisfy it.
    check "$name covers performance" grep -qi 'performance' "$f"
    check "$name covers testability" grep -qi 'testab' "$f"
    check "$name covers dist/ folder (whole word, in Consequences)" has_dist_word "$f"
done

check "README has review checklist" grep -q '^## Review checklist' "$DOCS/decisions/README.md"

ARCH="$DOCS/ARCHITECTURE.md"
check "ARCHITECTURE.md exists" test -f "$ARCH"
if [ -f "$ARCH" ]; then
    check "ARCHITECTURE.md has Determinism section" grep -q '^## Determinism' "$ARCH"
    check "ARCHITECTURE.md has 'may depend on' dependency rule" grep -qi 'may depend on' "$ARCH"
    check "ARCHITECTURE.md forbids wall clock in state" grep -q 'Instant' "$ARCH"
    check "ARCHITECTURE.md forbids HashMap iteration" grep -q 'HashMap' "$ARCH"
    check "ARCHITECTURE.md module table present" grep -q '^| Module (crate path)' "$ARCH"
fi

# Dependency rule: once the core crate exists, it must not reference the UI or CLI crates.
if [ -d "$ROOT/crates/evosim-core" ]; then
    if grep -rqE 'evosim_ui|evosim_cli|evosim-ui|evosim-cli' "$ROOT/crates/evosim-core"; then
        fail "evosim-core does not reference evosim-ui/evosim-cli"
    else
        pass "evosim-core does not reference evosim-ui/evosim-cli"
    fi
else
    echo "SKIP  evosim-core dependency grep (crates/evosim-core not created until TASK-002)"
fi

echo "checks=$checks failed=$fails"
[ "$fails" -eq 0 ]

#!/usr/bin/env python3
"""TASK-027 balance table (ADR-0028 D3): extinction ticks per seed and kind from a `evosim batch` output directory.

Usage: python3 -I scripts/balance_table.py DIR

For each seed-*.json in DIR: the first tick of the series with zero living individuals of a kind is that kind's
extinction tick (the batch is run with --sample-every 1, so it is exact); "survives" if the kind is alive at the end.
Per seed `L` = minimum extinction tick over the three kinds (`tick_end` if none dies out). Prints a table, the median
of `L`, the number of seeds in which all three kinds are alive at `tick_end`, and the minimum `L`.
Reads only the result JSON files; writes to stdout only.
"""

import glob
import json
import os
import statistics
import sys

KINDS = ("plants", "herbivores", "carnivores")


def extinction_ticks(doc):
    series = doc["series"]
    end = doc["tick_end"]
    out = {}
    for kind in KINDS:
        tick = None
        for row in series:
            if row[kind] == 0:
                tick = row["tick"]
                break
        out[kind] = tick  # None = survives to tick_end
    return out, end


def main(argv):
    if len(argv) < 2:
        print(__doc__, file=sys.stderr)
        return 2
    directory = argv[1]
    files = sorted(
        glob.glob(os.path.join(directory, "seed-*.json")),
        key=lambda p: int(os.path.basename(p)[5:-5]),
    )
    if not files:
        print(f"no seed-*.json in {directory}", file=sys.stderr)
        return 2
    rows = []
    for path in files:
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)
        ext, end = extinction_ticks(doc)
        dead = [t for t in ext.values() if t is not None]
        lowest = min(dead) if dead else end
        all_alive = all(ext[k] is None for k in KINDS)
        rows.append((doc["seed"], ext, lowest, all_alive, doc["totals"], doc["final"]))
    lows = [r[2] for r in rows]
    print("| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |")
    print("|---|---|---|---|---|---|---|---|")
    fmt = lambda t: "survives" if t is None else str(t)  # noqa: E731
    for seed, ext, low, alive, totals, _final in rows:
        print(
            f"| {seed} | {fmt(ext['plants'])} | {fmt(ext['herbivores'])} | {fmt(ext['carnivores'])} | {low} | "
            f"{'yes' if alive else 'no'} | {totals['births']['herbivores']} | {totals['births']['carnivores']} |"
        )
    print()
    print(f"seeds: {len(rows)}")
    print(f"median L: {statistics.median(lows)}")
    print(f"min L: {min(lows)}")
    print(f"seeds with all three kinds alive at tick_end: {sum(1 for r in rows if r[3])} of {len(rows)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))

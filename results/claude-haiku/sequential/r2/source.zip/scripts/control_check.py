#!/usr/bin/env python3
"""Black-box check of the UI control API (TASK-024, ADR-0025 D6, D7).

Starts `./evosim ui` on a free loopback port and drives the HTTP API it serves: run/pause/step/reset/speed, the
checkpoint download and upload, the inspector of a selected organism through its death, and the HTTP error codes.
Stdlib only; run as `python3 -I scripts/control_check.py`. Exit 0 only if every check passes.
The page's buttons are not clicked here (no display): this checks the commands the page sends.
"""
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EVOSIM = os.path.join(ROOT, "evosim")
STARVING = {"seed": 7, "world": {"width": 8, "height": 8}, "initial": {"plants": 0, "herbivores": 12, "carnivores": 0}}

failures = []


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f" ({detail})" if detail and not ok else ""))
    if not ok:
        failures.append(name)


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class Server:
    def __init__(self, config=None):
        self.port = free_port()
        self.dir = tempfile.mkdtemp(prefix="evosim-control-")
        args = [EVOSIM, "ui", "--port", str(self.port)]
        if config is not None:
            path = os.path.join(self.dir, "config.json")
            with open(path, "w", encoding="utf-8") as f:
                json.dump(config, f)
            args += ["--config", path]
        self.proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.base = f"http://127.0.0.1:{self.port}"
        for _ in range(200):
            try:
                self.state()
                return
            except OSError:
                time.sleep(0.05)
        raise RuntimeError("server did not start")

    def close(self):
        self.proc.kill()
        self.proc.wait()

    def request(self, method, path, body=None):
        req = urllib.request.Request(self.base + path, data=body, method=method)
        try:
            with urllib.request.urlopen(req, timeout=10) as res:
                return res.status, res.read(), dict(res.headers)
        except urllib.error.HTTPError as err:
            return err.code, err.read(), dict(err.headers)

    def state(self):
        return json.loads(self.request("GET", "/api/state")[1])

    def command(self, action, **fields):
        form = "&".join([f"action={action}"] + [f"{k}={v}" for k, v in fields.items()])
        status, body, _ = self.request("POST", "/api/command", form.encode())
        return status, json.loads(body) if status == 200 else {"ok": False}

    def wait_tick(self, tick):
        for _ in range(500):
            if self.state()["tick"] >= tick:
                return
            time.sleep(0.02)
        raise RuntimeError(f"tick {tick} not reached")


def run_main_checks():
    srv = Server()
    try:
        st = srv.state()
        ctl = st["control"]
        check("state has the control block", all(k in ctl for k in ["running", "speed", "speed_index", "speeds", "selected", "seed", "climate_version"]))
        check("starts running at the default speed (20 ticks/s)", ctl["running"] and ctl["speed"] == 20 and ctl["speeds"] == [1, 5, 20, 60])

        # Pause and a single step advances exactly one tick.
        status, reply = srv.command("pause")
        check("pause is accepted", status == 200 and reply["ok"])
        time.sleep(0.3)
        t0 = srv.state()["tick"]
        time.sleep(0.4)
        check("paused: the tick does not advance", srv.state()["tick"] == t0)
        status, reply = srv.command("step")
        check("step while paused is accepted", status == 200 and reply["ok"], str(reply))
        time.sleep(0.4)
        check("one step advances exactly one tick", srv.state()["tick"] == t0 + 1, f"from {t0}")
        srv.command("step")
        time.sleep(0.3)
        check("a second step advances exactly one more tick", srv.state()["tick"] == t0 + 2)

        # Step refused while running; run resumes ticks.
        srv.command("run")
        time.sleep(0.2)
        status, reply = srv.command("step")
        check("step while running is refused", status == 200 and not reply["ok"], str(reply))
        t1 = srv.state()["tick"]
        time.sleep(0.6)
        check("running: ticks advance", srv.state()["tick"] > t1)

        # Speed: three or more levels, never negative.
        for _ in range(10):
            srv.command("slower")
        ctl = srv.state()["control"]
        check("slower clamps at the lowest level (1 tick/s)", ctl["speed_index"] == 0 and ctl["speed"] == 1)
        for _ in range(10):
            srv.command("faster")
        ctl = srv.state()["control"]
        check("faster clamps at the highest level (60 ticks/s)", ctl["speed_index"] == 3 and ctl["speed"] == 60)
        srv.command("slower")
        srv.command("slower")
        check("slower steps down one level each time", srv.state()["control"]["speed"] == 5)
        srv.command("faster")
        check("faster from 5 returns to the default level (20)", srv.state()["control"]["speed"] == 20)

        # Reset: same starting world each time; checkpoint bytes equal.
        srv.command("pause")
        srv.command("reset")
        start_a = srv.request("GET", "/api/checkpoint")[1]
        for _ in range(7):
            srv.command("step")
        check("steps after the start change the world", srv.request("GET", "/api/checkpoint")[1] != start_a)
        srv.command("reset")
        start_b = srv.request("GET", "/api/checkpoint")[1]
        check("reset gives the same starting world (checkpoint bytes equal)", start_a == start_b)
        check("reset returns to tick 0", srv.state()["tick"] == 0)
        srv.command("reset")
        check("second reset gives the same starting world", srv.request("GET", "/api/checkpoint")[1] == start_a)

        # Checkpoint: save, load, continue; equal to an uninterrupted run.
        srv.command("reset")
        for _ in range(10):
            srv.command("step")
        after_ten = srv.request("GET", "/api/checkpoint")[1]
        srv.command("reset")
        for _ in range(5):
            srv.command("step")
        saved = srv.request("GET", "/api/checkpoint")
        check("checkpoint download is an attachment", saved[0] == 200 and "attachment" in saved[2].get("Content-Disposition", ""))
        status, body, _ = srv.request("POST", "/api/checkpoint", saved[1])
        check("checkpoint upload is accepted", status == 200 and json.loads(body)["ok"], body.decode()[:120])
        check("loaded checkpoint restores tick 5", srv.state()["tick"] == 5)
        for _ in range(5):
            srv.command("step")
        check("load then 5 steps equals an uninterrupted 10 steps", srv.request("GET", "/api/checkpoint")[1] == after_ten)

        # Invalid uploads are refused and leave the world unchanged.
        before = srv.request("GET", "/api/checkpoint")[1]
        status, _, _ = srv.request("POST", "/api/checkpoint", saved[1][:-7])
        check("truncated checkpoint is HTTP 422", status == 422)
        flipped = bytearray(saved[1])
        flipped[len(flipped) // 2] ^= 0x01
        status, body, _ = srv.request("POST", "/api/checkpoint", bytes(flipped))
        check("corrupted checkpoint is HTTP 422 with a message", status == 422 and b"error" in body)
        check("invalid uploads leave the world unchanged", srv.request("GET", "/api/checkpoint")[1] == before)

        # Method and argument errors.
        check("GET on the command route is 405", srv.request("GET", "/api/command")[0] == 405)
        check("unknown action is 400", srv.request("POST", "/api/command", b"action=fly")[0] == 400)
        check("organism route without selection is 404", srv.request("GET", "/api/organism?id=1")[0] == 404)
        check("select of an unknown id is refused and not selected", srv.command("select", id=10**12)[1]["ok"] is False and srv.state()["control"]["selected"] is None)

        # Body limit: refused from the head alone (413), before any body is read.
        s = socket.create_connection(("127.0.0.1", srv.port), timeout=10)
        s.sendall(f"POST /api/checkpoint HTTP/1.1\r\nHost: x\r\nContent-Length: {64 * 1024 * 1024 + 1}\r\n\r\n".encode())
        line = s.recv(64).decode(errors="replace")
        s.close()
        check("body over 64 MiB is HTTP 413", line.startswith("HTTP/1.1 413"), line.strip())
    finally:
        srv.close()


def run_inspector_checks():
    srv = Server(STARVING)
    try:
        srv.command("pause")
        herbivore = next(o for o in srv.state()["organisms"] if o[1] == 1)
        oid = herbivore[0]
        status, reply = srv.command("select", id=oid)
        check("select a living herbivore", status == 200 and reply["ok"], str(reply))
        status, body, _ = srv.request("GET", f"/api/organism?id={oid}")
        w = json.loads(body)
        check("inspector shows the organism as alive", status == 200 and w["status"] == "alive")
        o = w["organism"]
        required = ["id", "kind", "species", "age", "energy", "health", "traits", "genome", "parents", "cell"]
        check("inspector has id, kind, species, age, energy, health, traits, genome and parents",
              all(k in o for k in required), str(sorted(o)))
        check("inspector genome has eight slot means and hex haplotypes",
              len(o["genome"]["slot_means"]) == 8 and all(len(h) == 256 for h in o["genome"]["haplotypes"]))
        check("the selection shows in the state", srv.state()["control"]["selected"] == oid)
        # Follow the organism while the simulation runs.
        srv.command("run")
        time.sleep(0.5)
        status, body, _ = srv.request("GET", f"/api/organism?id={oid}")
        check("inspector keeps following while running", status == 200 and json.loads(body)["id"] == oid)
        srv.command("pause")
        died = None
        for _ in range(4000):
            srv.command("step")
            status, body, _ = srv.request("GET", f"/api/organism?id={oid}")
            w = json.loads(body)
            if w["status"] == "dead":
                died = w
                break
        check("the inspector shows when the organism died", died is not None)
        if died is not None:
            check("the death record has tick, cause and cell", all(k in died["death"] for k in ["tick", "cause", "cell"]), str(died["death"]))
            check("the last alive detail is kept", died["organism"]["id"] == oid)
    finally:
        srv.close()


def main():
    if not os.access(EVOSIM, os.X_OK):
        print("control_check: ./evosim is not built; run ./setup.sh or ./build.sh first")
        return 2
    run_main_checks()
    run_inspector_checks()
    print(f"control_check: {len(failures)} failed")
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Real-time frame and update measurement of the UI (TASK-023, ADR-0024 D14, D15).

Drives the real page in headless Chromium through the DevTools Protocol (stdlib WebSocket client, no virtual time).
Usage (run with -I):  python3 -I scripts/ui_fps.py fixture|live [CONFIG]

fixture  renderer cost with 1,000 synthetic organisms (`?fixture=1000`, never a simulation result).
         PASS: >= 30 rAF frames/s over 5 s of real time and mean redraw <= 16 ms (window.evosim.timing(50)).
live     the live server running CONFIG (default examples/ui-1000.json) while the page is open.
         The window is the contiguous run of ticks from the first sample with living >= 1,000 (sampled from /api/state).
         A window under 2 s is reported as too short; a window not seen by the page is reported as not observed.
         PASS: window >= 2 s, page frames >= 30/s and state updates >= 3/s inside the window.

Exit codes: 0 PASS, 1 threshold FAIL, 2 setup error (no Chromium, no DevTools, no server), 3 window too short or not observed.
"""
import base64
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FPS_MIN = 30.0
REDRAW_MAX_MS = 16.0
UPDATES_MIN = 3.0
WINDOW_MIN_S = 2.0
LIVING_MIN = 1000


class WS:
    """Minimal RFC 6455 client: text frames out (masked), text frames in (server frames are unmasked)."""

    def __init__(self, url):
        assert url.startswith("ws://")
        hostport, path = url[5:].split("/", 1)
        host, port = hostport.split(":")
        self.sock = socket.create_connection((host, int(port)), timeout=30)
        key = base64.b64encode(os.urandom(16)).decode()
        self.sock.sendall(
            (f"GET /{path} HTTP/1.1\r\nHost: {hostport}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
             f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode()
        )
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("websocket handshake closed")
            buf += chunk
        head, self.buf = buf.split(b"\r\n\r\n", 1)
        if b" 101 " not in head.split(b"\r\n")[0]:
            raise ConnectionError("websocket handshake refused")
        self.id = 0

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ConnectionError("websocket closed")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def _send(self, text):
        data = text.encode()
        head = bytearray([0x81])
        n = len(data)
        if n < 126:
            head.append(0x80 | n)
        elif n < 65536:
            head.append(0x80 | 126)
            head += struct.pack(">H", n)
        else:
            head.append(0x80 | 127)
            head += struct.pack(">Q", n)
        mask = os.urandom(4)
        self.sock.sendall(bytes(head) + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def _recv(self):
        payload = b""
        while True:
            b1, b2 = self._read(2)
            fin, op, ln = b1 & 0x80, b1 & 0x0F, b2 & 0x7F
            if ln == 126:
                ln = struct.unpack(">H", self._read(2))[0]
            elif ln == 127:
                ln = struct.unpack(">Q", self._read(8))[0]
            data = self._read(ln)
            if op == 0x9:  # ping: not expected from Chromium during these short runs; ignored
                continue
            payload += data
            if fin:
                return payload.decode()

    def call(self, method, params=None):
        self.id += 1
        mine = self.id
        self._send(json.dumps({"id": mine, "method": method, "params": params or {}}))
        while True:
            msg = json.loads(self._recv())
            if msg.get("id") == mine:
                if "error" in msg:
                    raise RuntimeError(f"{method}: {msg['error']}")
                return msg.get("result", {})

    def evaluate(self, expr, await_promise=False):
        r = self.call("Runtime.evaluate", {"expression": expr, "returnByValue": True, "awaitPromise": await_promise})
        if "exceptionDetails" in r:
            raise RuntimeError(f"evaluate failed: {r['exceptionDetails'].get('text')}")
        return r["result"].get("value")


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def start_chromium(chrome, url):
    prof = tempfile.mkdtemp(prefix="ui_fps_")
    proc = subprocess.Popen(
        [chrome, "--headless", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage", "--no-first-run",
         "--remote-debugging-port=0", "--window-size=1280,807", f"--user-data-dir={prof}", "about:blank"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    port_file = os.path.join(prof, "DevToolsActivePort")
    deadline = time.time() + 20
    while not os.path.exists(port_file) and time.time() < deadline:
        time.sleep(0.05)
    if not os.path.exists(port_file):
        proc.kill()
        raise RuntimeError("DevTools port file did not appear")
    port = open(port_file).read().split("\n")[0].strip()
    targets = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list", timeout=10).read())
    page = next(t for t in targets if t.get("type") == "page")
    ws = WS(page["webSocketDebuggerUrl"])
    ws.call("Runtime.enable")
    ws.call("Page.enable")
    ws.call("Page.navigate", {"url": url})
    return proc, prof, ws


def stop(proc, prof):
    proc.kill()
    proc.wait()
    shutil.rmtree(prof, ignore_errors=True)


def wait_for(ws, expr, timeout):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if ws.evaluate(expr):
                return True
        except (RuntimeError, ConnectionError, KeyError):
            pass
        time.sleep(0.1)
    return False


RAF_COUNTER = ("if(!window.__raf){window.__raf={n:0};(function f(){window.__raf.n++;"
               "requestAnimationFrame(f);})();} 'ok'")


def start_server(config, port):
    proc = subprocess.Popen([os.path.join(ROOT, "evosim"), "ui", "--port", str(port), "--config", config],
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    deadline = time.time() + 20
    while time.time() < deadline:
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/climate", timeout=2).read()
            return proc
        except OSError:
            time.sleep(0.05)
    proc.kill()
    raise RuntimeError("server did not answer")


def run_fixture(chrome):
    port = free_port()
    server = start_server(os.path.join(ROOT, "examples", "ui-1000.json"), port)
    proc = prof = None
    try:
        proc, prof, ws = start_chromium(chrome, f"http://127.0.0.1:{port}/?fixture=1000")
        if ws.evaluate("1 + 1") != 2:
            raise RuntimeError("the page did not answer")
        if not wait_for(ws, "!!window.evosim && window.evosim.stats().living === 1000", 20):
            raise RuntimeError("fixture did not load 1,000 organisms")
        ws.evaluate(RAF_COUNTER)
        m = ws.evaluate(
            "new Promise(r=>{const a=window.__raf.n;const t0=performance.now();"
            "setTimeout(()=>r({frames:window.__raf.n-a,seconds:(performance.now()-t0)/1000}),5000)})",
            await_promise=True,
        )
        t = json.loads(ws.evaluate("JSON.stringify(window.evosim.timing(50))"))
        fps = m["frames"] / m["seconds"]
        ok = fps >= FPS_MIN and t["meanMs"] <= REDRAW_MAX_MS and m["frames"] > 0
        print(f"fixture: organisms={t['organisms']} rAF frames={m['frames']} in {m['seconds']:.2f} s -> {fps:.1f} fps")
        print(f"fixture: redraw n={t['n']} mean={t['meanMs']:.2f} ms max={t['maxMs']:.2f} ms")
        print("PASS" if ok else "FAIL", f"(thresholds: >= {FPS_MIN:.0f} fps, mean redraw <= {REDRAW_MAX_MS:.0f} ms)")
        return 0 if ok else 1
    finally:
        if proc:
            stop(proc, prof)
        server.kill()
        server.wait()


def run_live(chrome, config):
    port = free_port()
    server = start_server(config, port)
    proc = prof = None
    samples = []  # (t, tick, living) from /api/state
    pages = []  # (t, rAF frames, updates, page tick)
    try:
        t_start = time.time()
        proc, prof, ws = start_chromium(chrome, f"http://127.0.0.1:{port}/")
        counter_ready = False
        page_loaded_at = None
        while time.time() - t_start < 12:
            t = time.time()
            d = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{port}/api/state", timeout=5).read())
            samples.append((t, d["tick"], sum(d["counts"].values())))
            if len(samples) % 2 == 0:
                try:
                    if not counter_ready and ws.evaluate("!!window.evosim"):
                        ws.evaluate(RAF_COUNTER)
                        counter_ready = True
                        page_loaded_at = time.time()
                    if counter_ready:
                        raw = ws.evaluate("JSON.stringify({n:window.__raf.n,s:window.evosim.stats()})")
                        v = json.loads(raw)
                        pages.append((time.time(), v["n"], v["s"]["updates"], v["s"]["tick"]))
                except (RuntimeError, ConnectionError, KeyError, TypeError):
                    pass
            time.sleep(0.05)
    finally:
        if proc:
            stop(proc, prof)
        server.kill()
        server.wait()
    # Window: contiguous samples from the first one with living >= LIVING_MIN.
    first = next((i for i, s in enumerate(samples) if s[2] >= LIVING_MIN), None)
    if first is None:
        print(f"live: no sample with living >= {LIVING_MIN}; first living={samples[0][2] if samples else None}")
        return 3
    last = first
    while last + 1 < len(samples) and samples[last + 1][2] >= LIVING_MIN:
        last += 1
    w0, w1 = samples[first][0], samples[last][0]
    print(f"live: window ticks {samples[first][1]}..{samples[last][1]} living>={LIVING_MIN} for {w1 - w0:.2f} s "
          f"(samples={len(samples)}, page loaded {'never' if page_loaded_at is None else f'{page_loaded_at - t_start:.2f} s after start'})")
    print("live: living by tick (first samples): " +
          ", ".join(f"{t}:{n}" for _, t, n in samples[:: max(1, len(samples) // 12)]))
    if w1 - w0 < WINDOW_MIN_S:
        print(f"live: window {w1 - w0:.2f} s is under {WINDOW_MIN_S:.0f} s: too short, not a pass")
        return 3
    inside = [p for p in pages if w0 <= p[0] <= w1 and p[1] is not None]
    if len(inside) < 2:
        print("live: the page did not sample inside the window: not observed in the browser, not a pass")
        return 3
    a, b = inside[0], inside[-1]
    dt = b[0] - a[0]
    fps = (b[1] - a[1]) / dt
    ups = (b[2] - a[2]) / dt
    ok = fps >= FPS_MIN and ups >= UPDATES_MIN
    print(f"live: in window page frames {fps:.1f}/s, state updates {ups:.2f}/s over {dt:.2f} s")
    print("PASS" if ok else "FAIL", f"(thresholds: >= {FPS_MIN:.0f} fps, >= {UPDATES_MIN:.0f} updates/s)")
    return 0 if ok else 1


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    chrome = os.environ.get("CHROME_BIN") or shutil.which("chromium") or "/usr/local/bin/chromium"
    if mode not in ("fixture", "live") or not os.access(chrome, os.X_OK):
        print("usage: ui_fps.py fixture|live [CONFIG] (chromium via CHROME_BIN or PATH)")
        return 2
    try:
        if mode == "fixture":
            return run_fixture(chrome)
        config = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "examples", "ui-1000.json")
        return run_live(chrome, config)
    except (RuntimeError, OSError, ConnectionError) as e:
        print(f"ui_fps: setup error: {e}")
        return 2


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env bash
# The one documented command that runs the whole test suite (ADR-0005).
# Stops at the first failing step; prints each command before running it.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

export PATH="/opt/rust/cargo/bin:${HOME:-/root}/.cargo/bin:$PATH"

step() { echo; echo "== $*"; }
run() { echo "+ $*"; "$@"; }

# expect_exit CODE CMD... : runs CMD, requires exit status CODE.
expect_exit() {
    local want="$1"; shift
    echo "+ $* (expect exit $want)"
    set +e
    "$@" >/tmp/evosim-test-out.$$ 2>/tmp/evosim-test-err.$$
    local got=$?
    set -e
    if [ "$got" -ne "$want" ]; then
        echo "FAIL: exit $got, expected $want"; cat /tmp/evosim-test-err.$$ >&2
        rm -f /tmp/evosim-test-out.$$ /tmp/evosim-test-err.$$
        exit 1
    fi
    LAST_STDOUT="$(cat /tmp/evosim-test-out.$$)"
    LAST_STDERR="$(cat /tmp/evosim-test-err.$$)"
    rm -f /tmp/evosim-test-out.$$ /tmp/evosim-test-err.$$
}

# expect_eq ACTUAL EXPECTED LABEL
expect_eq() {
    if [ "$1" != "$2" ]; then
        echo "FAIL: $3"; echo "  expected: $2"; echo "  actual:   $1"; exit 1
    fi
    echo "ok: $3"
}

VERSION_JSON='{"name": "evosim", "version": "0.1.0", "contract": 1}'

step "1. ADR and record checks"
run bash scripts/check_adrs.sh

step "2. cargo unit tests (whole workspace)"
run cargo test --workspace --locked

step "3. setup.sh"
run ./setup.sh

step "4. build.sh"
run ./build.sh

step "5. ./evosim entry point (black-box)"
expect_exit 0 ./evosim version
expect_eq "$LAST_STDOUT" "$VERSION_JSON" "./evosim version prints contract JSON"
(cd /tmp && expect_exit 0 "$ROOT/evosim" version)
expect_eq "$LAST_STDOUT" "$VERSION_JSON" "./evosim version works from another directory"
expect_exit 0 ./evosim --help
case "$LAST_STDOUT" in *version*) echo "ok: --help lists version";; *) echo "FAIL: --help does not list version"; exit 1;; esac
expect_exit 2 ./evosim no-such-command
[ -z "$LAST_STDOUT" ] && echo "ok: unknown command prints nothing on stdout" || { echo "FAIL: stdout not empty"; exit 1; }
[ -n "$LAST_STDERR" ] && echo "ok: unknown command prints a message on stderr" || { echo "FAIL: no stderr message"; exit 1; }

step "6. dist/evosim (distributable)"
expect_exit 0 dist/evosim version
expect_eq "$LAST_STDOUT" "$VERSION_JSON" "dist/evosim version prints contract JSON"
expect_exit 0 dist/evosim --help
expect_exit 2 dist/evosim no-such-command

step "7. dist/evosim dynamic dependencies (allowed: glibc incl. libm, libgcc_s, loader, vdso)"
LDD_OUT="$(ldd dist/evosim)"
echo "$LDD_OUT"
UNEXPECTED="$(echo "$LDD_OUT" | awk '{print $1}' | grep -vE '^(linux-vdso\.so\.1|libgcc_s\.so\.1|libc\.so\.6|libm\.so\.6|/lib64/ld-linux-x86-64\.so\.2|ld-linux-x86-64\.so\.2|/lib/x86_64-linux-gnu/libc\.so\.6)$' | grep -v '^$' || true)"
if [ -n "$UNEXPECTED" ]; then
    echo "FAIL: unexpected dynamic dependencies:"; echo "$UNEXPECTED"; exit 1
fi
echo "ok: only allowed dynamic dependencies"

step "8. ./evosim run (headless, black-box; TASK-019, ADR-0020)"
RUN_DIR="$(mktemp -d)"
trap 'rm -rf "$RUN_DIR"' EXIT
# Two runs with the same seed on the example configuration of docs/CONTRACT.md section 3 (fixed keys only).
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --config examples/config.json --ticks 300 --seed 7 --out "$RUN_DIR/a/run.json"
[ -z "$LAST_STDOUT" ] && echo "ok: run prints nothing on stdout" || { echo "FAIL: run wrote to stdout"; exit 1; }
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --config examples/config.json --ticks 300 --seed 7 --out "$RUN_DIR/b/run.json"
# Only the two wall-clock lines may differ (ADR-0020 D2).
grep -v -E '"(elapsed_seconds|ticks_per_second)"' "$RUN_DIR/a/run.json" > "$RUN_DIR/a.cmp"
grep -v -E '"(elapsed_seconds|ticks_per_second)"' "$RUN_DIR/b/run.json" > "$RUN_DIR/b.cmp"
cmp -s "$RUN_DIR/a.cmp" "$RUN_DIR/b.cmp" && echo "ok: same seed gives identical result (except wall-clock lines)" \
    || { echo "FAIL: same-seed runs differ"; diff "$RUN_DIR/a.cmp" "$RUN_DIR/b.cmp" | head -20; exit 1; }
grep -q '"tick_end": 300,' "$RUN_DIR/a/run.json" && echo "ok: tick_end is 300" || { echo "FAIL: tick_end"; exit 1; }
expect_exit 2 ./evosim run --config "$RUN_DIR/missing.json" --ticks 1 --out "$RUN_DIR/c/run.json"
[ ! -e "$RUN_DIR/c/run.json" ] && echo "ok: missing configuration exits 2 and writes no result" || { echo "FAIL: result written"; exit 1; }
# Checkpoints (TASK-022, ADR-0023): 37 ticks with --save, then --load for 263 more, against the uninterrupted 300 above.
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --config examples/config.json --ticks 37 --seed 7 --out "$RUN_DIR/e/part.json" --save "$RUN_DIR/e/s.bin"
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --load "$RUN_DIR/e/s.bin" --ticks 263 --out "$RUN_DIR/e/resumed.json"
python3 -I -c 'import json,sys; a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2])); sys.exit(0 if all(a[k]==b[k] for k in ["final","totals","state_hash","seed"]) and b["tick_end"]==300 else 1)' "$RUN_DIR/a/run.json" "$RUN_DIR/e/resumed.json" \
    && echo "ok: save at 37 and resume to 300 give the same final, totals and state_hash" \
    || { echo "FAIL: resumed run differs from the uninterrupted run"; exit 1; }
head -c 100 "$RUN_DIR/e/s.bin" > "$RUN_DIR/e/truncated.bin"
expect_exit 2 ./evosim run --load "$RUN_DIR/e/truncated.bin" --ticks 1 --out "$RUN_DIR/e/bad.json"
[ ! -e "$RUN_DIR/e/bad.json" ] && echo "ok: truncated checkpoint exits 2 and writes no result" || { echo "FAIL: result written"; exit 1; }

step "9. ./evosim batch (black-box; TASK-021, ADR-0022)"
BATCH_DIR="$RUN_DIR/batch"
# 2 values x 2 seeds matrix on the example configuration, run twice (once on two threads): summaries must be equal.
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim batch --config examples/config.json --seeds 1,2 --ticks 50 --vary initial.plants=200,400 --csv --out-dir "$BATCH_DIR/a"
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim batch --config examples/config.json --seeds 1,2 --ticks 50 --vary initial.plants=200,400 --csv --jobs 2 --out-dir "$BATCH_DIR/b"
[ -z "$LAST_STDOUT" ] && echo "ok: batch prints nothing on stdout" || { echo "FAIL: batch wrote to stdout"; exit 1; }
cmp -s "$BATCH_DIR/a/summary.json" "$BATCH_DIR/b/summary.json" && echo "ok: same batch gives identical summary.json (jobs 1 and 2)" \
    || { echo "FAIL: summaries differ"; diff "$BATCH_DIR/a/summary.json" "$BATCH_DIR/b/summary.json" | head -20; exit 1; }
cmp -s "$BATCH_DIR/a/runs.csv" "$BATCH_DIR/b/runs.csv" && cmp -s "$BATCH_DIR/a/aggregates.csv" "$BATCH_DIR/b/aggregates.csv" \
    && echo "ok: CSV files identical" || { echo "FAIL: CSV files differ"; exit 1; }
for f in case-00/seed-1.json case-00/seed-2.json case-01/seed-1.json case-01/seed-2.json; do
    grep -v -E '"(elapsed_seconds|ticks_per_second)"' "$BATCH_DIR/a/$f" > "$RUN_DIR/x.cmp"
    grep -v -E '"(elapsed_seconds|ticks_per_second)"' "$BATCH_DIR/b/$f" > "$RUN_DIR/y.cmp"
    cmp -s "$RUN_DIR/x.cmp" "$RUN_DIR/y.cmp" || { echo "FAIL: $f differs"; exit 1; }
done
echo "ok: per-seed results identical (except wall-clock lines)"
[ "$(grep -c '"state_hash"' "$BATCH_DIR/a/summary.json")" -eq 4 ] && echo "ok: summary lists four runs" || { echo "FAIL: run count"; exit 1; }
[ "$(wc -l < "$BATCH_DIR/a/aggregates.csv")" -eq 7 ] && echo "ok: aggregates.csv has one row per case and kind" || { echo "FAIL: aggregates.csv rows"; exit 1; }
expect_exit 2 ./evosim batch --config examples/config.json --seeds 1 --ticks 5 --vary initial.nothing=1,2 --out-dir "$BATCH_DIR/c"
[ ! -e "$BATCH_DIR/c/summary.json" ] && echo "ok: unknown sweep key exits 2 and writes no summary" || { echo "FAIL: summary written"; exit 1; }

step "10. demo scenario and example configuration (TASK-028, CONTRACT section 7)"
# Ten-thousand-tick runs of the demo scenario and of the example configuration, seeds 1 to 3 (docs/VERIFICATION.md section 4).
for cfg in scenarios/demo.json examples/config.json; do
    for seed in 1 2 3; do
        expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --config "$cfg" --ticks 10000 --seed "$seed" --out "$RUN_DIR/long/$(basename "$(dirname "$cfg")")-$(basename "$cfg" .json)-$seed.json"
    done
done
python3 -I - "$RUN_DIR/long" <<'PY' || { echo "FAIL: long-run checks"; exit 1; }
import glob, json, sys
files = sorted(glob.glob(sys.argv[1] + "/*.json"))
assert len(files) == 6, files
for f in files:
    d = json.load(open(f))
    assert d["tick_end"] == 10000, (f, d["tick_end"])
    for k in ("plants", "herbivores", "carnivores"):
        assert d["totals"]["initial"][k] + d["totals"]["births"][k] - d["totals"]["deaths"][k] == d["final"][k], (f, k)
print("ok: six runs of 10,000 ticks; initial + births - deaths = final for every kind")
PY
expect_exit 0 env -u DISPLAY -u WAYLAND_DISPLAY ./evosim run --config scenarios/demo.json --ticks 300 --seed 7 --out "$RUN_DIR/demo/run.json"
echo "ok: demo scenario loads through run"

step "11. ui (headless browser checks, TASK-023..025)"
expect_exit 0 ./evosim ui --smoke-test --config scenarios/demo.json
SHOTS_DIR="$RUN_DIR/shots"; mkdir -p "$SHOTS_DIR"
expect_exit 0 ./evosim ui --screenshots "$SHOTS_DIR" --config examples/config.json
python3 -I - "$SHOTS_DIR/main.png" <<'PY' || { echo "FAIL: main.png is not a PNG of at least 1280x720"; exit 1; }
import struct, sys
data = open(sys.argv[1], "rb").read(24)
assert data[:8] == b"\x89PNG\r\n\x1a\n", "not a PNG"
w, h = struct.unpack(">II", data[16:24])
assert w >= 1280 and h >= 720, (w, h)
print(f"ok: main.png is a PNG {w}x{h}")
PY

step "12. release-mode randomised invariants (TASK-028, docs/VERIFICATION.md section 3)"
run env EVOSIM_INVARIANT_CASES=200 cargo test --release -p evosim-core --locked invariant

echo
echo "ALL TESTS PASSED"

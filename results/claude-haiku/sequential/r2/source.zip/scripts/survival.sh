#!/usr/bin/env bash
# TASK-018 survival command (ADR-0019 D5): the default parameters for 10,000 ticks, per seed and kind the tick at which the
# kind died out, or "survived". Seeds 1-5 are the report seeds; 101-105 are the held-out seeds (ADR-0019 D4).
# Usage: bash scripts/survival.sh [--ticks N] [--seeds a,b,...]   (defaults: 10000 ticks, seeds 1,2,3,4,5)
# Exit status is that of the example (0 on success).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PATH="/opt/rust/cargo/bin:${HOME:-/root}/.cargo/bin:$PATH"

exec cargo run --release --locked -q -p evosim-core --example survival -- --ticks 10000 --seeds 1,2,3,4,5 "$@"

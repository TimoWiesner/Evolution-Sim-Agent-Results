#!/usr/bin/env bash
# UI browser check (TASK-023, ADR-0024 D11): starts `evosim ui` on a free loopback port, runs the real page in headless
# Chromium with `?check=1` (synthetic pointer, wheel and double-click events; verdict in the title), then measures the
# server's state-response rate over 10 s of wall-clock time. Usage: scripts/ui_check.sh [CONFIG]. Exit 0 only if all pass.
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${1:-$ROOT/examples/ui-1000.json}"
BIN="${CHROME_BIN:-$(command -v chromium || true)}"
[ -x "$BIN" ] || { echo "ui_check: chromium not found (set CHROME_BIN)"; exit 2; }
PORT="$(python3 -I -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1]); s.close()')"
PROFILE="$(mktemp -d)"
"$ROOT/evosim" ui --port "$PORT" --config "$CONFIG" >/dev/null 2>"$PROFILE/server.log" &
SERVER=$!
cleanup() { kill "$SERVER" 2>/dev/null; wait "$SERVER" 2>/dev/null; rm -rf "$PROFILE"; }
trap cleanup EXIT
# Wait until the simulation has run a few ticks (the page check needs tick >= 1).
for _ in $(seq 1 100); do
    curl -sf "http://127.0.0.1:$PORT/api/state" 2>/dev/null | grep -q '"tick":[1-9]' && break
    sleep 0.2
done
# Interaction checks in the real page (synthetic events; the result is written to the title by app.js).
DOM="$(timeout 60 "$BIN" --headless --no-sandbox --disable-gpu --disable-dev-shm-usage --no-first-run \
    --window-size=1280,807 --virtual-time-budget=5000 --user-data-dir="$PROFILE/chrome" --dump-dom \
    "http://127.0.0.1:$PORT/?check=1" 2>/dev/null)"
TITLE="$(printf '%s' "$DOM" | grep -o '<title>check=[^<]*</title>' | sed -e 's/<[^>]*>//g')"
echo "interaction: ${TITLE:-no verdict from the page}"
# Real-time rate: state responses per second over 10 s of wall-clock time (server side, not virtual time).
python3 -I - "$PORT" <<'PY'
import sys, time, urllib.request, json
port = sys.argv[1]
t0 = time.time(); n = 0; first = None; last = None; living_min = None; living_max = None
while time.time() - t0 < 10:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/state", timeout=5) as r:
        d = json.loads(r.read())
    n += 1
    living = sum(d["counts"].values())
    first = first if first is not None else d["tick"]
    last = d["tick"]
    living_min = living if living_min is None else min(living_min, living)
    living_max = living if living_max is None else max(living_max, living)
    time.sleep(0.2)
rate = n / (time.time() - t0)
print(f"realtime: responses={n} rate={rate:.2f}/s tick {first}->{last} living min={living_min} max={living_max}")
ok_rate = rate >= 3.0
print("PASS  state poll at least 3 responses per second" if ok_rate else "FAIL  state poll below 3 responses per second")
sys.exit(0 if ok_rate else 1)
PY
RATE_RC=$?
case "$TITLE" in *"check=PASS"*) CHECK_RC=0 ;; *) CHECK_RC=1 ;; esac
[ "$CHECK_RC" -eq 0 ] && [ "$RATE_RC" -eq 0 ] && { echo "ui_check: PASS"; exit 0; }
echo "ui_check: FAIL (interaction=$CHECK_RC rate=$RATE_RC)"; exit 1

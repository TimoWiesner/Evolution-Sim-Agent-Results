#!/usr/bin/env bash
# TASK-026 benchmark command (ADR-0027 D1): ticks per second of examples/perf-2000.json (seed 42, 128x96 cells,
# 2,200 plants + 250 herbivores + 50 carnivores at tick 0), 2 untimed warm-up repetitions, 5 timed repetitions of
# 100 ticks each (each repetition starts from the same fresh state), plus the phase profile of 100 ticks.
# Then a secondary run: 1,000 ticks, one repetition, no warm-up (the population falls; reported, not a target).
# Prints the hardware line first, then one JSON object per run. Exit status is that of the example (0 on success).
# Usage: bash scripts/perf.sh
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export PATH="/opt/rust/cargo/bin:${HOME:-/root}/.cargo/bin:$PATH"

model="$(grep -m1 'model name' /proc/cpuinfo | cut -d: -f2- | sed 's/^ *//')"
echo "hardware: ${model:-unknown CPU}; logical CPUs: $(nproc); memory: $(awk '/MemTotal/ {printf "%.1f GiB", $2/1048576}' /proc/meminfo); $(rustc --version 2>/dev/null || echo rustc unknown); kernel $(uname -r)" >&2

cargo build --release --locked --offline -q -p evosim-core --example perf_tps
BIN="$ROOT/target/release/examples/perf_tps"
CFG="examples/perf-2000.json"

echo "== benchmark: $BIN --config $CFG --ticks 100 --warm 2 --reps 5" >&2
"$BIN" --config "$CFG" --ticks 100 --warm 2 --reps 5
echo "== secondary: $BIN --config $CFG --ticks 1000 --warm 0 --reps 1 --profile-ticks 0 --living-floor 0" >&2
"$BIN" --config "$CFG" --ticks 1000 --warm 0 --reps 1 --profile-ticks 0 --living-floor 0

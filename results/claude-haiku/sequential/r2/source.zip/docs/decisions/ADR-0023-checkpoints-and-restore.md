# ADR-0023: Checkpoint file format, integrity checks and restore

Status: Accepted (drafted in TASK-022 PLAN cycle 1; accepted at TASK-022 REVIEW cycle 1 PASS).

## Context
`docs/CONTRACT.md` section 2 adds `--save FILE` and `--load FILE` to `evosim run`. Section 5.2 requires that running A ticks,
saving, loading and running B more ticks gives the same `final`, `totals` and `state_hash` as one uninterrupted run of A+B
ticks. Section 5.4 requires that a missing, unreadable or invalid checkpoint gives exit status 2, a message on stderr and no
result file. `docs/PROJECT.md` requires a save/load of the full state including DNA, RNG and climate.

The state is already fully described by ADR-0020 D3: `checkpoint::encode_state` writes the canonical bytes of the complete
`Simulation` (magic `EVOSIMST`, state format `1`, then every field in fixed order). Every state module has an `encode_state`
method with exhaustive destructuring. The restore side is partly in place: `Simulation::from_parts`, `Climate::from_parts`,
`ResourceField::from_values`, `Rng::from_state` and `SpeciesRegistry`/`Entities` storage exist. What is missing is a decoder
for each encoded struct, a file container with integrity checks, the CLI options and the runner path that starts from a
checkpoint instead of founders.

Constraints: std-only core (ADR-0020: no crate registry is cached in the container, so no `sha2`, no `flate2`, no `zstd`);
the state hash is SHA-256 (`core::sha256`); no time or OS entropy in state; the CLI is the only writer of files.

## Considered alternatives
1. **Serde-style or text format (JSON/TOML) of the state (rejected).** Readable, but floats need exact text round-trip,
   the genome loci would be large arrays of numbers, and the parser and writer for every struct would be a second, non-canonical
   encoding that the hash does not cover. The binary canonical encoding already exists and is what the hash is computed over.
2. **Save the configuration and replay from tick 0 to the checkpoint tick (rejected).** Tiny file, but the load time grows with
   the save tick, and it does not save "the state" as the contract asks; a changed build would silently change the replay.
3. **Binary state body plus a container with magic, file version, seed, length and a SHA-256 trailer (chosen).** The body is the
   existing `encode_state` output, so the saved state and `state_hash` cannot diverge. The container adds what the body does not
   carry: the file version, the seed for the result JSON, a length that detects truncation and a digest that detects damage.
4. **Compression (gzip/zlib/RLE) (rejected for format version 1).** Would need a hand-written DEFLATE or a crate. The state is
   dominated by genome loci (one byte each) and f32/f64 values, which compress poorly, and a 64x48 world with the default
   population is well under a megabyte. Revisit with a new file version only if measured sizes at 5,000 entities are a problem
   (IMPLEMENT must record the byte size of a checkpoint at about 5,000 entities).

## Decision

### D1 File layout (all integers little-endian)
| Offset | Size | Field |
|---|---|---|
| 0 | 8 | magic `EVOSIMCK` |
| 8 | 4 | file format version `u32`, currently `1` |
| 12 | 8 | `seed` `u64`: the seed of the run that created the state (metadata; the result JSON reports it; not read by the engine) |
| 20 | 8 | `body_len` `u64` |
| 28 | `body_len` | body: exactly the bytes of `checkpoint::encode_state(sim)` (starts with `EVOSIMST` and state format `1`) |
| 28 + body_len | 32 | trailer: SHA-256 of all preceding bytes (header and body) |

The file length must be exactly `28 + body_len + 32`. Written through a temporary file in the target directory and renamed (as the
result file, ADR-0020 D7).

### D2 Restore and validation order
`checkpoint::read_file(bytes) -> Result<Checkpoint, CheckpointError>` checks, in this order, and stops at the first failure:
1. length at least 60 bytes, otherwise `Truncated`;
2. magic `EVOSIMCK`, otherwise `NotACheckpoint`;
3. file format version equals `1`, otherwise `UnsupportedVersion { found, expected: 1 }` (checked before the digest so that a
   future-version file is reported as such);
4. `file length == 28 + body_len + 32`, otherwise `LengthMismatch` (catches truncation and trailing data);
5. SHA-256 trailer matches, otherwise `DigestMismatch` (catches any damage);
6. body starts with `EVOSIMST` and state format `1`, otherwise `UnsupportedStateVersion` or `NotACheckpoint`;
7. the body is decoded by `Simulation` decoders (D3); every read is bounds-checked, every enum tag and length checked,
   and every value passes the constructor validation of its type (`Genome::new`, `Tendencies::new`, `Rng::from_state`,
   `ResourceField::from_values`, `Climate::from_parts`, `SeedingSettings::new`, `MatingSettings` ranges). The decoder must consume
   the body exactly, otherwise `Trailing`;
8. the decoded state is encoded again and must be byte-equal to the body (`NotCanonical` otherwise);
9. `Simulation::check_spatial()` must pass (the derived index matches the organisms).

Any failure is reported as one message on stderr, exit status 2, and no result file (CONTRACT section 5.4). No panic on any
input: a damaged body that passes steps 1 to 5 is still caught by 7 to 9.

### D3 Decoder design
- `checkpoint::Decoder<'a>`: a cursor over the body with `u8`, `bool`, `u32`, `u64`, `f32`/`f64` (from bit patterns), `count`
  (a length prefix that must not exceed the remaining bytes), `bytes`, `str` (UTF-8 checked), `opt_u64` (tag 0 or 1 only),
  `finish()` (no bytes left). Errors are `CheckpointError::Invalid { what }` with the name of the field.
- Each state module gains `pub(crate) fn decode_state(dec: &mut Decoder) -> Result<Self, CheckpointError>` next to its
  `encode_state`, in the same order and with the same tags. Decoders live in the module that owns the private fields.
- Order of construction is the order of `Simulation::encode_state`: tick, rng, world (topology, climate, resources), entities,
  seeding, mating, species, lifespans. `Simulation::from_parts` assembles the result; its spatial index is rebuilt from the
  organisms, as in ADR-0003.
- Enum tags are the ones written by `encode_state` (`Kind::index`, `DeathCause::index`, `cause_tag`); an unknown tag is `Invalid`.
- Organisms must be strictly ascending by id and every id must be below `next_id`; `SpeciesRecord.id` must equal its position in
  `records`. Violations are `Invalid`, not silently repaired.

### D4 `last_deaths`
ADR-0011 says `last_deaths` is "not part of checkpoints". ADR-0020 D3 (accepted) encodes it, so the hash covers it. This ADR
follows ADR-0020: `last_deaths` is saved and restored, so that the re-encode check (D2 step 8) passes and the state is complete.
ADR-0011 is updated with a pointer to this decision. The value is rewritten by the Deaths phase of every tick, so it cannot
change the behaviour of a resumed run; the test in D6 would show it if it did.

### D5 CLI and runner
- `evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K] [--save FILE] [--metrics FILE]` (save and load as
  described here; `--metrics` as in ADR-0021).
- `evosim run --load FILE --ticks N --out FILE [--sample-every K] [--save FILE] [--metrics FILE]`.
- Refused with exit 2 (message on stderr, no file): `--load` with `--config` or `--seed` (the contract's second form has neither);
  `--config` missing and `--load` missing; `--save` or `--load` given the same path as `--out`; `--save` and `--out` the same path.
- Flow of a run with `--save`: build or restore the state, run `N` ticks, encode the checkpoint in memory, write it atomically
  (creating the parent directory), then write the result. If the checkpoint write fails, exit 2 and no result file is written.
- `--save` after `--ticks 0` is valid and saves the state at the starting tick.
- `runner::run` is split: `run_from(sim, seed, ticks, sample_every, with_metrics)` holds the loop; `run` builds founders and calls
  it; `resume(checkpoint, ticks, sample_every, with_metrics)` calls it without `populate_initial`. A checkpoint is never populated
  again.
- Result JSON of a resumed run: `seed` is the checkpoint seed; `tick_start` is the checkpoint tick; `totals.initial` is the
  initial count saved in the checkpoint (so `initial + births - deaths = final` still holds over the whole history); `series`
  starts at `tick_start`; `world`, `final`, `state_hash` and `species_recognised` come from the restored state. `sample_every`
  defaults to `max(1, N/100)` of the ticks of this invocation, as in CONTRACT section 2.
- The metrics log (`--metrics`) of a resumed run starts at the checkpoint tick; its earlier history is not in the checkpoint
  (analytics is read-only and is not state). This is documented, not hidden.

### D6 Verification strategy
Stated in full in `tasks/TASK-022/handoffs/plan-cycle1.md`. In short: decoder round-trip (`encode(decode(b)) == b`) for states at
several ticks; container tests (every truncation length and every single-byte flip gives an error, never a panic; wrong file
version with a recomputed digest gives `UnsupportedVersion`); equivalence of an uninterrupted run and save-and-resume at split
points 0, 1, 37 and 150 of a 300-tick run on `examples/config.json` (with weather on), comparing `final`, `totals`, `state_hash`
and the per-tick `state_hash` after the split; CLI end-to-end tests (`crates/evosim-cli/tests/checkpoint_cli.rs`) and a
black-box step in `scripts/test.sh`.

## Consequences
- Positive: the saved state and `state_hash` come from one encoder, so a resumed run is compared with the same bytes the hash
  uses; the format is small, std-only and versioned; damage and truncation are detected before any state is built.
- Negative: every state module gains a decoder (a wide but mechanical change, roughly 20 types); the body is not human-readable;
  files are not compressed (size recorded in IMPLEMENT).
- Risk: a field that the encoder does not write is not saved, and the hash does not see it either. The equivalence tests over
  300 ticks catch behavioural differences; the per-kind rules in ADR-0020 (no derived cache may be left out) remain the guard.
- Format change rule: any change to the body needs a new state format version; any change to the container needs a new file
  format version. Readers of version 1 must reject other versions with exit 2.

## Verification strategy
- `checkpoint`: container unit tests (D2), decoder primitives (bounds, tags, UTF-8, `finish`), round-trip per module and for the
  whole state, equivalence of save-and-resume at split points (in `runner` or `checkpoint` tests).
- `crates/evosim-cli/tests/checkpoint_cli.rs`: save at tick 0 and mid-run, then load; compare `final`, `totals`, `state_hash` with
  an uninterrupted run; each error class of D2 and D5 exits 2 with no result file; a failed save leaves no result file.
- `scripts/test.sh`: black-box step that splits a run of `examples/config.json` through the CLI and compares with an uninterrupted
  run (wall-clock lines removed).
- Byte size of a checkpoint at about 5,000 entities is measured and recorded in the IMPLEMENT handoff.

## Implementation notes (TASK-022 IMPLEMENT cycle 1)
- Status stays Proposed until REVIEW PASS. Decisions D1 to D6 are implemented as written, with these additions:
  - `Simulation::assemble` is the one constructor used by `from_parts` and by the decoder (the neighbour index is rebuilt there).
  - `runner::RunOptions { sample_every, with_metrics, keep_state }`; `keep_state` returns the final state for `--save`, so batch
    runs do not hold states. `runner::run` keeps its signature.
  - CLI refusals beyond D5: `--save` equal to `--metrics` and `--load` equal to `--out` are refused (exit 2).
  - Checkpoint write order: checkpoint, metrics, result. A failed checkpoint write leaves no result file.
- Size (measured): 145 KB for the example configuration at tick 0; 1.36 MB for 5,000 founders. No compression (as decided).
- Test deviation: the round-trip test uses a 16x12 world with weather, not `examples/config.json` (speed); the black-box step in
  `scripts/test.sh` uses `examples/config.json`.


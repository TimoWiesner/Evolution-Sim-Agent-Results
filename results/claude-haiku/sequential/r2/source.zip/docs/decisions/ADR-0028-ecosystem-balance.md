# ADR-0028: Ecosystem balance trials, mechanism candidates and acceptance protocol

Status: Accepted (TASK-027 REVIEW cycle 1 PASS). Drafted in TASK-027 PLAN cycle 1; trials, chosen defaults and outcome
recorded in `docs/BALANCE.md`. Correction (REVIEW): the PLAN probe statement below that herbivores die out first in all
10 seeds is wrong; the official 20-seed baseline has carnivores first in 18 seeds (see the implementation record).

## Context
TASK-018 joined the food chain, but no seed keeps plants, herbivores and carnivores together to 10,000 ticks. The
PLAN probe (`docs/results/TASK-027-plan-probe.md`) on the example configuration (64x48, 400/120/20) shows:
- herbivores die out first in all 10 probe seeds (ticks 309 to 610), carnivores later in all 10 (167 to 411);
- in seed 1, 117 of 120 herbivores are killed by predation in the first 100 ticks; herbivores have 0 to 31 births in
  10,000 ticks in total;
- founders start at energy 50, below the herbivore mating threshold of 60, so few herbivores breed before they are eaten;
- carnivores have 0 to 4 births in 10 seeds and starve once their prey is gone.

Constraints (`docs/PROJECT.md`, `docs/CONTRACT.md` section 5.3 and 5.4): no forced anti-extinction rule; no rule that
reads how many members a kind or species has left; births only from the initial population or reproduction; no
immortality; no energy without a documented source. A mechanism may react to what an organism perceives or to its own
cell (food, crowding, danger), never to global counts. Determinism and one RNG stream are kept.

## Decision
**D1. Mechanisms are tried before parameters.** The task requires at least one mechanism change. Candidates, in the order
they are tried (each is one trial, see D3):

- **T1 Crowding dilutes predation (local).** `hunting::attack_chance` is multiplied by a factor that falls with the number
  of living herbivores in the attacker's own cell (the cell is perceivable to the carnivore, so this is a local rule).
  Form to be fixed in IMPLEMENT: `1 / (1 + DILUTION * (n_cell - 1))` with `n_cell` the herbivores in the carnivore's cell
  at the attack step. Expected: fewer kills per tick in dense herbivore clusters; herbivores survive longer; a risk that
  carnivores starve sooner (measured).
- **T2 Handling time after a kill (per organism).** After a successful kill a carnivore cannot attack for `HANDLING_TICKS`
  ticks (a timer stored with the organism; no count-based rule). Expected: kills per carnivore per tick fall, which
  protects herbivores when carnivores are many; intake per carnivore is also capped (satiation already caps it).
- **T3 Mating energy reached before maturity pressure (check, not a count rule).** Diagnose first with a read-only counter
  of mating refusals by reason (energy, maturity, cooldown, compatibility, no partner). Only if energy is the dominant
  reason, a mechanism is tried: the herbivore's grazing intake is applied before predation in the same tick. This is a
  trial only if T1 or T2 do not help.
- **T4 (optional, only if T1 to T3 are inconclusive) Refuge in the cell.** Prey caution reduces attack success further
  when the prey has eaten recently (local). Not planned unless time remains.

**D2. Parameters are tried only after a mechanism trial, and only inside the mechanism's range.** Candidate constants:
`hunting::P_BASE`, `MEAL_MAX`, `SATIATION_CARNIVORE`, `ecology::REGEN_RATE`, `feeding::BITE_MAX`, and the mating constants.
At most three parameter-only trials in total.

**D3. Trial protocol (per trial, recorded whether it helps or not).**
- Tuning seeds: 1 to 20, 10,000 ticks, example configuration (`./evosim batch --sample-every 1` gives exact extinction
  ticks). Metric per seed: `L = min(extinction tick of the three kinds)`, with `L = 10,000` if none dies out. Primary score:
  median of `L`; secondary: number of seeds in which all three kinds survive to 10,000; tie-break: minimum `L`.
- Held-out seeds: 101 to 110 (ten seeds, at least five required). Run once, on the final defaults only.
- Each trial records: the change (code and constant), the expected result, the measured result (table), and whether it helped.
- Stop rule: stop after the first mechanism trial that improves the primary score and one follow-up trial, or when two
  consecutive trials do not improve it, or at 40 minutes of IMPLEMENT time, whichever comes first. Nothing is hidden: failed
  trials stay in `docs/BALANCE.md`.
- A trial that changes any rule is checked against D4 before its numbers are used.

**D4. Forbidden-rule check.** Each trial is checked for: (a) no rule that reads a count of a kind or species (grep for
`living`, `count`, `population` in the new code paths, and a review note); (b) births only from `populate_initial` and
reproduction (existing counter test `per_kind_balance_holds_after_every_tick` and `check_balance`); (c) determinism
(same seed twice gives the same `state_hash`).

**D5. Diagnostics may be added.** Read-only counters (mating refusals by reason, attacks by outcome, handling-time count)
may be added to the metrics output. They must not change state or random draws, and the state hash of a run without the
new mechanism must stay identical; this is checked before the first trial (IMPLEMENT step 2).

**D6. Regression values.** Changing `attack_chance` or the handling rule changes state hashes. The affected regression values
and the reasons are recorded in `docs/BALANCE.md` and in this ADR's implementation record. The earlier must-haves (TASK-018
scenario and conservation tests, TASK-026 hashes) are re-checked after the chosen change.

**D7. Performance.** After the chosen defaults: `bash scripts/perf.sh` (TASK-026 measurement, 2,000 entities) is re-run. The
target is 100 ticks per second; the last measured median is 1,081.7 ticks/s (TASK-026 REVIEW cycle 2). A slowdown is recorded
and explained, even if the target is still met.

## Alternatives considered
1. Parameter-only tuning (founder energy, `BITE_MAX`, `P_BASE`): rejected as the first step. The task asks for a mechanism
   change, and parameter sweeps already happened in TASK-018 (about 60 candidates) without a food chain.
2. A herbivore refuge given by climate or terrain: deferred; needs new world data (a bigger change than this task).
3. A global population floor or a predator-count rule: rejected by `docs/PROJECT.md` (forced anti-extinction).
4. Removing the unused config keys (`plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism`, ADR-0019):
   not part of the balance question; left as is.

## Consequences
- The chosen mechanism is a rule change with state-hash consequences; the CLI and UI presets follow the new defaults only
  where the task allows (`task.md`: only presets may follow).
- Measurement cost is small: one 10,000-tick seed takes about 1.5 to 3 s, so 20 tuning seeds take under a minute per
  trial. The trial budget is therefore bounded by the 40-minute rule, not by compute.
- Coexistence is not guaranteed; the outcome is reported, whatever it is (task.md, "Not part of this task").

## Verification (IMPLEMENT)
- Unit tests for each new mechanism: the attack factor is 1 in a cell with one herbivore and falls monotonically with
  crowding; handling time blocks attacks for exactly `HANDLING_TICKS` ticks and then allows them; both are deterministic.
- Existing tests (`cargo test --workspace --locked --offline`) pass after the regression values are re-recorded.
- Official baseline and held-out results are produced by `./evosim batch` and stored under `docs/results/TASK-027/`.

## Implementation record (TASK-027 IMPLEMENT cycle 1)
Status stays Proposed (REVIEW sets it). Full data and reading: `docs/BALANCE.md`; tables in `docs/results/TASK-027/`.
- Baseline (official, before any change): `./evosim batch` seeds 1 to 20, 10,000 ticks, example configuration: median L 337,
  min 157, 0 of 20 seeds with all three kinds alive at 10,000. Carnivores die out first in 18 of 20 seeds (herbivores in
  seeds 1 and 12). **The PLAN probe's claim that herbivores die out first in all 10 seeds was wrong** (corrected in BALANCE.md).
- Mechanism trials: T1 (crowding dilutes predation, `hunting::DILUTION`, factor `dilution_factor`), trial 0.5: median L
  312.5 (worse); follow-up 0.1: median L 337 (no change). Two non-improving trials: stop rule reached.
- T2 (handling time) and T3 (mating diagnostic) were not implemented; parameter trials were not run.
- Chosen defaults: `DILUTION = 0.0` (mechanism present, factor exactly 1; state hashes unchanged: seeds 1 and 2 at 1,000
  ticks, `fc057bf2...` and `8f813a8a...`). No regression value re-recorded.
- Held-out seeds 101 to 110 on the chosen defaults: median L 258.5, min 143, 0 of 10 all alive.
- Rule check: the T1 factor reads only the living herbivores in the attacker's own cell (perceivable, local). No rule reads a
  species or kind count; no organism is created outside the initial population and reproduction.
- Outcome: the goal (coexistence to 10,000 ticks) was not reached. Not a guarantee required by the task.

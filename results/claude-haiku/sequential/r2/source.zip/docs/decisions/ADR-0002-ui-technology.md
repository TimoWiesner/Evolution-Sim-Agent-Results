# ADR-0002: UI technology

Status: Accepted (drafted in TASK-001 PLAN cycle 1, confirmed in TASK-001 IMPLEMENT cycle 2). The browser
smoke and screenshot path is not yet executed; its feasibility is unverified until the UI task.

## Context
`evosim ui` must offer pan/zoom, run/pause/reset/step, speed control, entity inspection and climate-coloured
map view. `evosim ui --smoke-test` and `evosim ui --screenshots DIR` must run without user input, produce a
PNG of at least 1280x720 from the real interface, and exit within 60 s / 120 s. The container provides
`chromium` 131 (`/usr/local/bin/chromium`, runs as root, supports `--headless --screenshot` and
`--remote-debugging-port`) and `xvfb-run`. The core must keep no UI dependency (ADR-0001).

## Considered alternatives
1. **Local browser UI served by the Rust binary.** `evosim ui` starts a tiny HTTP server on `127.0.0.1` (std
   `TcpListener`, one worker thread, no async runtime) serving HTML/CSS/JS embedded in the binary with
   `include_str!`. The page draws the world on a `<canvas>` and polls a JSON state endpoint; buttons post
   commands. Screenshots are made by the same binary launching `chromium --headless --screenshot` against its
   own URL.
2. **Native desktop UI with egui/eframe.** Single process and no HTTP, but it needs an OpenGL context for
   screenshots (Mesa software rendering under `xvfb-run`), has long compile times and a large dependency
   tree, and screenshot capture from the real window is fiddly and driver-dependent.
3. **Tauri (Rust + system webview).** Needs webkit2gtk and a Node toolchain not present in the container;
   heavy `setup.sh`, and the webview is not Chromium 131, so the screenshot path differs from the browser path.
4. **Python GUI (Tk or Qt).** Adds a runtime dependency that `dist/` must bundle; Tk visuals are weak; poor
   testability of drawing.

## Decision
**Local browser UI** (option 1), in crate `crates/evosim-ui`.
- Server: `std::net::TcpListener` bound to `127.0.0.1` on an ephemeral port (or `--port` if given). The sim
  runs in a dedicated thread owned by the UI; the HTTP thread reads a snapshot protected by a `Mutex`.
- API: `GET /` (embedded page), `GET /api/state` (JSON snapshot: tick, counts, sampled entities, climate
  layer), `POST /api/cmd` (run, pause, step, reset, speed, inspect), `GET /api/entity?id=N`.
- Rendering: the page draws the grid on canvas, climate colours for the base layer, entity glyphs by kind,
  pan/zoom with mouse wheel and drag. Chart panels (population, births/deaths, diversity) are optional extra
  screenshots.
- `--smoke-test`: start the server, run `chromium --headless --virtual-time-budget=... --dump-dom URL?smoke=1`;
  the page advances the world via the API until tick >= 10 and writes a `frames=N` marker into the DOM. The
  command checks the marker, shuts the server down and exits 0 (<= 60 s).
- `--screenshots DIR`: start the server with the world pre-advanced to >= 100 ticks in a `?shot=1` session;
  run `chromium --headless --no-sandbox --window-size=1280,720 --virtual-time-budget=5000 --screenshot=DIR/main.png URL?shot=1`.
  Optional extra views use the same mechanism with `&view=charts` or `&view=inspector`.
- Chromium flags needed as root: `--no-sandbox`. `CHROME_BIN` is used when set, otherwise `chromium` on PATH.

## Consequences
- The UI is a browser page, so the same binary runs headless with `evosim run` without any display.
- `dist/evosim` does not need to support screenshots (contract section 2); it may still serve `ui` through
  the same code if chromium is available, but the smoke test is only required of `./evosim`.
- Assets are embedded, so `dist/evosim` needs no extra files.
- Requires a Chromium on the machine for screenshots and smoke tests; this is the benchmark container
  standard and is recorded in `docs/STATE.md`.
- Live UI speed is bounded by polling and JSON size; the snapshot is sampled, not full state, to keep frames
  cheap at 5,000 entities.
- Performance: the simulation runs in its own thread and the UI never blocks it, so UI rendering does not reduce
  headless ticks/s. Snapshot size is capped by sampling; the headless target (ADR-0001) is the reference.
- Testability: the HTTP and command layers are testable without a browser; only the screenshot and smoke runs need
  chromium.

## Verification strategy
- Rust unit tests for the HTTP routing and command parsing (no browser needed).
- `./evosim ui --smoke-test` and `./evosim ui --screenshots /tmp/shots` run in the container; the PNG
  dimensions are checked with `file` or a small PNG-header reader in a test.
- Exit codes and timings recorded in the phase handoff.
- Feasibility status: the chromium smoke and screenshot commands above have not been run in TASK-001. Until the UI
  task runs them, the browser path is unverified, and this record must not be read as proof that it works.

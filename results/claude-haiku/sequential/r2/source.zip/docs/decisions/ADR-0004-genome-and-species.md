# ADR-0004: Genome design, inheritance, mutation and species

Status: Accepted (drafted in TASK-001 PLAN cycle 1, confirmed in TASK-001 IMPLEMENT cycle 1). Numeric defaults
(`species_distance`, `mutation_rate`) are placeholders until calibrated by TASK-009 and later.

## Context
Every organism needs heritable DNA from which traits are derived. Plants reproduce asexually (pollination is
optional and later). Herbivores and carnivores reproduce sexually with two parents. Species must emerge from
genetic divergence, using an explicit and stable criterion that does not look at population counts (forbidden
by `docs/PROJECT.md`: no rule that looks at how many members a kind or species has left).

## Considered alternatives
1. **Named trait floats only (no genome).** Simple, but traits cannot diverge into separate lineages or carry
   a meaningful genetic distance; fails the species requirement.
2. **Bit-string genome with one gene per trait (Holland-style).** Easy crossover, but the trait-to-bit mapping
   is coarse and mutation of a single bit causes big jumps.
3. **Diploid polygenic genome of `u8` loci, each trait is the sum of its loci (chosen).** Each trait is an
   additive function of many loci, so small mutations give small trait changes; diploidy lets recessive-like
   variation persist and gives meiosis-style recombination; genetic distance is a simple locus-wise mean.
4. **Neural-network weights as genome.** Rich behaviour, but far too large for 2,000 organisms in the target
   time, hard to make deterministic-testable, and out of scope for the first milestones.

## Decision
**Option 3.** Implemented in `crates/evosim-core/src/genome.rs`.

### Representation
- `Genome { ploidy: u8, loci: Vec<u8> }`, length `ploidy * LOCI_PER_HAPLOTYPE`. Plants: `ploidy = 1`
  (asexual). Animals: `ploidy = 2` (sexual). `LOCI_PER_HAPLOTYPE = 128` as a starting value.
- Traits: a fixed table of named traits (speed, strength, health, fertility, aggression, risk, lifespan, plus
  plant-only traits such as growth, seed dispersal, and a `niche` trait used for species separation). Each
  trait owns a fixed block of loci (for example 8 loci per trait per haplotype). Trait value
  `v = min + (max-min) * mean(loci_of_trait) / 255`, clamped to the trait range.
- Behavioural tendencies (aggression, risk) are heritable traits from the genome, as required by the task.

### Inheritance
- Asexual (plants): child copies parent's haplotype.
- Sexual (animals): a **chromosome** is one haplotype, i.e. the `LOCI_PER_HAPLOTYPE` loci of one ploidy copy, one
  linkage group. Meiosis for each parent builds a gamete from its two chromosomes (haplotypes A and B) with exactly
  **one** crossover point `c`, drawn uniformly from `1..L-1` with the simulation RNG (`L = LOCI_PER_HAPLOTYPE`).
  The gamete takes loci `0..c` from haplotype A and loci `c..L` from haplotype B. There is no crossover-rate
  config key.
- Child = gamete of the mother + gamete of the father, length `2L` (ploidy 2). Random numbers come only from the
  simulation RNG (ADR-0001 / architecture).
- Copy one parent: `child = copy(parent)` followed by mutation. Two parents: meiosis then mutation.

### Mutation
- Per locus, with probability `mutation_rate` (config, default 0.002), add a signed step `±1..=mutation_strength`
  (default 8) clamped to `[0, 255]`. Clamping (not wrapping) keeps a +1 step near 255 at 255 instead of jumping
  to 0, so a small mutation always gives a small change. Rate 0 gives exact copies (tested). Strength is a config key.
- Mutations happen only at reproduction, from the simulation RNG.

### Genetic distance
- `d(a, b) = (1/L) * sum_i |a_i - b_i| / 255` over corresponding loci of the two genomes, with `L` the number of
  loci of the common ploidy. Properties: `d(a,a) = 0`, symmetric, in `[0, 1]`, larger for more different genomes
  (tested with proptest). Genomes of different ploidy (plant vs animal) are never compared.

### Species criterion (the rule that defines a species)
- Threshold `species_distance` (config, default 0.06, from calibration in IMPLEMENT).
- Checked every `species_check_interval` ticks (default 25), per kind (plants and animals separately).
- Clustering: single-linkage over living organisms of that kind (edge if `d <= species_distance`), computed with
  a union-find over id-sorted organisms (O(n^2) worst case; n <= 5,000 every 25 ticks is acceptable).
- Identity: each cluster is matched to an existing species if any member is within `species_distance` of that
  species' founder genome. Otherwise a **candidate** species is created with a fresh id. A candidate becomes a
  **recognised** species only after it has been observed as a separate cluster for `species_persistence`
  consecutive checks (counted in checks, not in ticks: default 4 consecutive checks, which is 100 ticks at
  interval 25). It does not depend on how many members the cluster has.
- Extinction: a species with zero living members is recorded as extinct. Its id is never reused. No rule uses
  member counts to keep a species alive.
- Result JSON: `final.species` counts recognised species with at least one living member per kind.

### Mating
- Animals of the same kind within perception radius may pair; mate choice may later use the heritable
  `aggression`/`risk` tendencies, but no rule forces reproduction across or within species. Speciation can emerge
  because cross-cluster matings produce intermediate genomes.

## Consequences
- Genetic distance and speciation are cheap enough to compute at the checks above.
- Calibrating `species_distance` and `mutation_rate` is a tuning task; the defaults are placeholders until
  IMPLEMENT measures them on the demo scenario.
- Using `u8` loci keeps genomes compact (256 bytes per animal with ploidy 2 and 128 loci per haplotype), which
  helps checkpoint size and hashing.
- Performance: distance is O(L) per pair with L = 128 to 256 bytes; species checks run every 25 ticks only, so
  the O(n^2) single-linkage cost is paid rarely. Testability: all genome rules are pure functions over `Genome`
  and the RNG, so they run in `cargo test` without a world. `dist/`: the genome code is plain Rust with no extra
  runtime, so it ships inside the single binary.

## Verification strategy
- Unit tests: zero mutation gives parental material only; positive mutation rate creates differences over many
  offspring; crossover children draw each locus from one of the two parents.
- Property tests: distance symmetry, zero on identity, range `[0, 1]`.
- Species tests: two disjoint synthetic clusters separated by more than the threshold are recognised after the
  persistence window; a cluster that disappears for fewer checks than the persistence window is not recognised.

## Implementation notes (TASK-009 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/genome.rs` (`Genome`, `random_genome`, `Mutation`, `mutate`, `copy_child`, `crossover_child`,
  `genetic_distance`, `trait_means`); the mapping from block means to trait ranges is `entities::decode_traits`.
- Slots: 8 blocks of 16 loci per haplotype: 0 speed, 1 strength, 2 fertility, 3 max_lifespan, 4 max_health, 5 aggression,
  6 caution, 7 reserved. Names and ranges as ADR-0011. Plant-only traits (growth, seed dispersal, niche) are deferred.
- Mapping: block mean `sum / (ploidy * 16 * 255)` over all haplotypes; `value = min + (max - min) * mean`; `max_lifespan` floored.
- Meiosis: one cut `c` uniform in `1..=127` and a coin per parent, segments `0..c` and `c..128` (disjoint; resolves G-009).
- Mutation: `rate == 0` draws nothing; otherwise per locus `chance(rate)`, then `1 + next_below(strength)` and a sign;
  clamped to `[0, 255]`. Rate and strength validated by `Mutation::new` (NaN rejected).
- Distance: `sum |a_i - b_i| / (len * 255)` over `u64` sums; error for different ploidy or length.
- Deviation: the property tests use seeded loops, not proptest (no proptest in the workspace).
- Deviation: `Simulation::populate_initial` is not called by `Simulation::new` (keeps RNG-state tests); the CLI call is TASK-019.

## Amendment (TASK-011, ADR-0012)
Plants (ploidy 1) read slots 5, 6 and 7 as plant traits: `cold_tolerance` (slot 5), `drought_tolerance` (slot 6) and
`yield` (slot 7, `0.5 + 0.5 * mean`). For animals slots 5 and 6 keep their meaning (aggression, caution). Slot 7 is still
unused for animals. The plant meaning is decoded by `ecology::PlantTraits::from_genome`.

## Amendment (TASK-013 PLAN, ADR-0014)
Animals (ploidy 2) read slot 7 as `vision`: `entities::vision_radius(genome)`, integer cells in `[1, 5]`, from the slot mean
(ADR-0014). It is derived from the genome at use time and is not stored. Slot 7 keeps its plant meaning (`yield`) for plants.

**Amendment (TASK-018 IMPLEMENT cycle 1).** Slot 3 (`max_lifespan`) is mapped onto `[0.5, 1.5] * max_age` of the kind, not onto
`[1, 10000]` (ADR-0019 D2). The genome slot meaning is unchanged; the decoded value is.

# ADRs
Create numbered ADRs for language and runtime, UI technology, spatial indexing and genome design in TASK-001. State status, context, considered alternatives, decision, consequences and verification strategy.

## Index
- ADR-0001 Language and runtime of the simulation core (Rust, Cargo workspace)
- ADR-0002 UI technology (local browser UI served by the binary)
- ADR-0003 Neighbour search on the wrapping grid (per-cell CSR buckets)
- ADR-0004 Genome design, inheritance, mutation and species criterion
- ADR-0005 Project skeleton and quality gates
- ADR-0006 Configuration format and presets
- ADR-0007 Torus topology, distance (Chebyshev, shortest wrapped displacement) and neighbourhood
- ADR-0008 Random generator (xoshiro256**, SplitMix64 seeding), fixed tick order and step/trace representation (TASK-005)
- ADR-0009 Climate zones, biomes and the torus compromise (polar seam, equator in the middle row) (TASK-006)
- ADR-0010 Seasons, weather and the time-dependent climate (global calendar on the torus, value-noise weather lattice) (TASK-007)
- ADR-0011 Organisms, traits, storage and the life cycle (sorted vector, never-reused ids, death causes, same-tick rule) (TASK-008)

## Review checklist
Every record must contain these headings, in this order:
1. `Status:` line (Proposed, Accepted or Superseded, with the task and cycle)
2. `## Context`
3. `## Considered alternatives` with at least two numbered items (each names the alternative and its trade-off)
4. `## Decision`
5. `## Consequences`
6. `## Verification strategy`

Each record's reasons must cover performance, testability and the self-contained `dist/` folder where they apply.
`scripts/check_adrs.sh` checks items 1 to 6 mechanically (exit 0 if all pass).

Changing a decision requires a new ADR or an update to the existing record before the code changes
(TASK-009 and TASK-010 depend on ADR-0004 and ADR-0003).
- ADR-0012 Plant resources, growth, tolerance and ageing (TASK-011; Accepted at REVIEW cycle 1 PASS)
- ADR-0013 Plant reproduction, seed dispersal and mutation (TASK-012; Accepted at REVIEW cycle 1)
- ADR-0014 Animal perception, movement, movement energy and cell sharing (TASK-013; Accepted at REVIEW cycle 1)
- ADR-0015 Herbivore feeding, metabolism, climate cost and decision rule (TASK-014; Accepted at REVIEW cycle 1)
- ADR-0016 Carnivore pursuit, hunting, predation, metabolism and energy gain (TASK-015; Accepted at REVIEW cycle 1)
- ADR-0017 Animal sexual reproduction: mate search, compatibility barrier, energy costs, litter, cooldown (TASK-016; Proposed at PLAN cycle 1)
- ADR-0018 Species criterion (single linkage, distance threshold, persistence in checks), founders as clones of one ancestor per kind, re-classification, naming, parent links and extinction ticks (TASK-017; Accepted at REVIEW cycle 1)
- ADR-0019 Food-chain integration: tick order, lifespan centred on the config `max_age` keys (fixes the maturity gap), changed defaults (plant max age 1500, BITE_MAX 0.5, REGEN_RATE 0.1, carnivore satiation 95), survival command (TASK-018; Proposed at IMPLEMENT cycle 1; coexistence not met, see record)
- ADR-0020 Headless `run` command, result JSON and state hash (TASK-019; Accepted at REVIEW cycle 1 PASS)
- ADR-0021 Evolution metrics: read-only per-sample analytics, `--metrics` file and its format (TASK-020; Accepted at REVIEW cycle 1)
- ADR-0022 Batch runs, parameter sweeps (`--vary`), summary format, CSV export and shared run path (TASK-021; Accepted at REVIEW cycle 1 PASS)
- ADR-0023 Checkpoint file format (magic, file version, seed, body, SHA-256 trailer), validation order, decoders, `last_deaths` saved, `run --load` rules (TASK-022; Accepted at REVIEW cycle 1)
- ADR-0024 UI world view: `evosim ui` modes, snapshot API (`/api/state`, `/api/climate`), drawing of biomes and organisms, smoke and screenshot mechanics, layout ids for TASK-024/025 (TASK-023; Proposed at PLAN cycle 1)

# ADR-0005: Project skeleton, entry points and quality gates

Status: Accepted (drafted in TASK-002 PLAN cycle 1; implemented in IMPLEMENT cycle 1; confirmed in REVIEW cycle 1).
Known limit (REVIEW cycle 1, G-011): the cargo lookup in `setup.sh`, `build.sh` and `evosim` does not set or check
`RUSTUP_HOME`/`CARGO_HOME`; a shell without them fails with a rustup error instead of falling back.

## Context
TASK-002 creates the empty product skeleton: the three contract entry points (`docs/CONTRACT.md` section 1), the
Cargo workspace from ADR-0001, the `evosim version` and `--help` commands, one command that runs the whole test
suite, a self-contained `dist/evosim` (CONTRACT section 6) and a README. No simulation code is in scope.
The container has Rust 1.100 at `/opt/rust/cargo/bin`, glibc 2.39 (Ubuntu 24.04) with `libc.a` and
`libgcc_s.so.1`, and Chromium 131. crates.io is reachable (HTTP 200), but TASK-002 adds no third-party crate,
so the build needs no network once the toolchain is present.

## Considered alternatives
1. **Cargo workspace with a root `Cargo.toml`, three member crates, shell wrappers at the root.** Matches
   ADR-0001 and `docs/ARCHITECTURE.md`. Shell wrappers keep the contract entry points independent of the
   Rust build layout. Trade-off: two layers (bash and cargo) to keep in step.
2. **Single crate with modules.** Simpler, but the rule "core must not depend on UI or CLI" (ADR-0001, checked by
   `scripts/check_adrs.sh`) would only be a convention, not a compile-time boundary. Rejected.
3. **Makefile or just-file as the build tool.** Adds a tool that the container does not guarantee. Rejected: cargo
   already gives build, test and fetch; the shell wrappers are plain bash.
4. **Test runner as a fourth root file (`./test.sh`).** Convenient, but CONTRACT section 1 names exactly three root
   executables. Chosen instead: `scripts/test.sh`, documented in README.

## Decision
- **Layout.** `Cargo.toml` (workspace, `resolver = "2"`, `edition = "2021"`, `version = "0.1.0"`, members below),
  `crates/evosim-core` (library, placeholder `pub const CONTRACT_VERSION: u32 = 1;`, no dependencies),
  `crates/evosim-cli` (binary `evosim`: `main.rs` dispatch, `args.rs` hand-written parsing; commands `version`
  and `--help`), `crates/evosim-ui` (library placeholder, no dependencies). `Cargo.lock` is committed (binary
  product). `scripts/check_adrs.sh` and `scripts/test.sh` are the quality gates.
- **Build tool.** Cargo only. `[profile.release]`: `lto = "thin"`, `codegen-units = 1`, `panic = "abort"`, no
  `target-cpu=native` (ADR-0001).
- **Entry points.**
  - `setup.sh`: finds `cargo` on PATH, then `/opt/rust/cargo/bin`, then `$HOME/.cargo/bin`; if none exists it
    installs a minimal stable toolchain with rustup (the only network use); then `cargo fetch --locked` and
    `cargo build --release --locked`. Idempotent. Installs no apt packages.
  - `evosim`: resolves its own directory (works from any cwd), executes `target/release/evosim "$@"`. If that
    binary is missing it runs `cargo build --release --locked --offline -p evosim-cli` first and reports a clear
    error on stderr if that fails.
  - `build.sh`: `cargo build --release --locked`, then `mkdir -p dist` and copies the binary to `dist/evosim`
    (mode 755). No other file is needed.
- **Commands.** `evosim version` prints exactly `{"name": "evosim", "version": "0.1.0", "contract": 1}` and a
  newline on stdout, exit 0. `evosim --help` (also `-h`, and no argument) lists the commands available in this
  build on stdout (no argument: exit 2 with the help on stderr; `--help`: exit 0). Any unknown command, or
  unexpected extra argument to `version`, prints `evosim: <message> (see evosim --help)` to stderr and exits 2.
  `run`, `batch` and `ui` are added by their own tasks and are not listed in TASK-002.
- **Self-contained `dist/`.** Dynamic glibc linking is kept (the default for `x86_64-unknown-linux-gnu`). The
  binary depends only on glibc, `libgcc_s` and the dynamic loader, which every Ubuntu 24.04 x86-64 system has.
  `ldd dist/evosim` is checked in the test script; any other library fails the check. A fully static
  `+crt-static` build was considered and deferred: `libc.a` is present here, but static glibc warns on NSS
  functions and the gain is not needed for the target system.
- **Tests.** Unit tests with `cargo test --workspace` (core constant, CLI argument parsing and version
  output). `scripts/test.sh` is the one documented command. It runs, in order: `scripts/check_adrs.sh`,
  `cargo test --workspace --locked`, `./setup.sh`, `./build.sh`, then black-box checks of `./evosim version`
  (exact output), `./evosim --help` (exit 0, lists `version`), `./evosim no-such-command` (exit 2), the same
  checks from `/tmp` (cwd independence), `dist/evosim version`, and `ldd dist/evosim`. It exits non-zero on the
  first failure and prints the exact command for each check.
- **Git.** `dist/`, `target/` are already ignored in `.gitignore`. No remote, no commit by the agent.

## Consequences
- Adding `evosim-core` makes the core-to-UI/CLI dependency grep in `scripts/check_adrs.sh` run instead of SKIP
  (expected: one more PASS; total checks rise from 53 to 54 or more). This is the G-008 closure.
- The skeleton has no third-party crates, so `setup.sh` needs no network when Rust is present. `sha2` arrives
  with the checkpoint task; then `setup.sh` needs crates.io (reachable here) and `Cargo.lock` must be committed.
- `dist/` needs only `dist/evosim`; the same binary will carry the embedded UI assets (ADR-0002), so no file
  beside it is needed. Performance: no effect yet; release profile fixed here for the 100 ticks/s target
  (ADR-0001). Testability: the core and CLI are testable with `cargo test` without a display or browser.
- `./evosim ui --smoke-test` and `--screenshots` are not part of TASK-002 and are not tested here.

## Verification strategy
- `scripts/test.sh` exits 0 and prints each check; the IMPLEMENT phase records its exit code and output.
- Fresh-state check: remove `target/` and `dist/`, run `./setup.sh`, then `./evosim version` (exact output).
- `ldd dist/evosim` shows only `linux-vdso`, `libgcc_s.so.1`, `libc.so.6`, `ld-linux-x86-64.so.2`.
- `git remote -v | wc -l` = 0; `git status --short` shows no `dist/` or `target/` entries.

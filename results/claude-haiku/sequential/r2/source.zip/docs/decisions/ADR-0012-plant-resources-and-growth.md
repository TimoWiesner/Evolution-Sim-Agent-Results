# ADR-0012: Plant resources, growth, tolerance and ageing

Status: Accepted (drafted in TASK-011 PLAN cycle 1; accepted at TASK-011 REVIEW cycle 1 PASS).
Extends ADR-0004 (genome slots for plants, amendment below) and ADR-0011 (organism fields and death causes). Uses ADR-0009 and ADR-0010 (climate).

## Context
TASK-011 makes plants live off their environment: they gain energy from the resources of their cell, the gain depends on the
cell's current temperature and water, resources are limited so plants compete, plants age and die (old age, lack of energy,
hostile climate), and genome-derived traits influence growth or tolerance. The energy source and its limits must be documented,
and no energy may appear without a source (docs/PROJECT.md, docs/CONTRACT.md section 5; no forced anti-extinction).
Reproduction and spreading are TASK-012; being eaten is TASK-014, so the resource pool is not yet drawn on by animals.

## Considered alternatives
1. **Photosynthesis from light only (energy from climate directly, no pool).** Simple, but energy would appear from climate
   without any limit, so plants could never compete. Rejected.
2. **Three resource pools (light, water, nutrients), each a per-cell field.** Closest to ecology, but triples the state, adds
   nutrient cycling without a consumer to test it against, and needs three checkpoint sections. Deferred; the single pool
   below leaves room for it.
3. **One per-cell pool of plant-available resource (chosen), regenerated toward a capacity set by the climate.** The pool is
   the only energy source for plants; the capacity is a function of the cell's temperature and precipitation. Competition is
   sharing of the same pool. This matches the ecology idea "cell resources that regenerate slowly up to a cap set by the climate".
4. **Crowding-dependent growth only (no pool).** Gives levelling-off but no source, so energy would still be unbounded. Rejected
   as the source; crowding may be added later as a multiplier.

## Decision

### Energy source (the only one for plants)
- Each cell `c` has a resource pool `R[c]` in `[0, CAP_MAX]`, stored in `World.resources` (a `ResourceField`, one `f32` per cell,
  indexed by `Torus::index`). `CAP_MAX = 100.0` resource units.
- **Source**: every tick, each cell regenerates toward its climate capacity:
  `R[c] += REGEN_RATE * (cap(c) - R[c])`, with `REGEN_RATE = 0.05` per tick and `cap(c) = CAP_MAX * suit(c)`.
  This is the only way resource enters the simulation. It is bounded by the climate; the cap never exceeds `CAP_MAX`.
- **Capacity from climate**: `suit(c) = temp_factor(T, NEUTRAL) * water_factor(P, NEUTRAL)` with `T, P` from `Climate::conditions(c)`
  (current tick, ADR-0010), and `NEUTRAL = 0.5` for the tolerances. Plants' own tolerances do not change the pool's capacity;
  they change how much of the pool a plant can use.
- **Conversion**: a plant takes resource units `u` and gains `u * yield` energy, with `yield` in `[0.5, 1.0]` (genome, below).
  `yield <= 1` means energy gain never exceeds the resource removed. Energy is capped at `ENERGY_MAX` by `add_energy`; the
  overflow is lost, not created.
- Energy is removed by maintenance (below) and by growth spending; it never leaves a plant to another place except by death.

### Environmental response (the climate-dependent gain)
Per plant, with `c` its cell and `cond = Climate::conditions(c)`, and tolerances from the genome (below):
- Temperature factor `f_T(T, cold_tol)`: lower limit `L = 5 - 10 * cold_tol` (degrees C, range `[-5, 5]`; a higher cold tolerance
  lowers the limit, so the plant grows in colder cells; the first PLAN draft had the sign reversed, corrected at IMPLEMENT), optimum `T_OPT = 20`,
  upper limit `U = 40`. `f_T = 0` for `T <= L` or `T >= U`; linear rise from 0 at `L` to 1 at `T_OPT`; linear fall from 1 at
  `T_OPT` to 0 at `U`.
- Water factor `f_W(P, drought_tol)`: `f_W = 0` if `P < P_MIN = 20` mm/yr (too dry, no growth). Otherwise
  `f_W = P / (P + K)` with half-saturation `K = 400 * (1 - drought_tol) + 50 * drought_tol` mm/yr, so `K` in `[50, 400]`.
  `f_W < 1` always.
- Both factors are in `[0, 1]`, and the product is the growth factor `g = f_T * f_W`.

### Plant traits (genome, ploidy 1, ADR-0004 amendment)
Plants read three genome blocks of their single haplotype; the block means are `Genome::trait_means()` in `[0, 1]`:
| Slot | Plant trait | Mapping | Use |
|---|---|---|---|
| 5 | `cold_tolerance` | `mean` | sets `L` (lower temperature limit) |
| 6 | `drought_tolerance` | `mean` | sets `K` (water half-saturation) |
| 7 | `yield` | `0.5 + 0.5 * mean` | energy per resource unit (Rust field `yield_per_unit`, `yield` is a keyword) |
Existing plant traits from ADR-0011 are unchanged and used as follows: `max_health` is the biomass cap (growth stops there),
`max_lifespan` is the age limit (old age), `speed` and `strength` and `fertility` are not used by plants in TASK-011
(`fertility` is for TASK-012). Animal slots 5 and 6 (aggression, caution) keep their meaning for animals; the meaning of a slot
depends on the kind, as decided here.
Decoding is a pure function `PlantTraits::from_genome(&Genome)`, computed each tick (no cache, so no drift; cost noted in risks).

### Per-tick plant phase (`Phase::Plants`, ADR-0008 order: after Climate and SpatialIndex, before animals)
The phase is deterministic and draws no random numbers. Plants are processed in ascending id order; the order of sharing does
not matter because sharing is proportional (below).
1. **Demand**: for each living plant, `demand = REQUEST_MAX * g * (1 - energy / ENERGY_MAX)` with `REQUEST_MAX = 4.0` units per
   tick. The `(1 - energy / ENERGY_MAX)` term is satiation: a full plant asks for nothing.
2. **Competition (proportional sharing)**: per cell, `D[c]` is the sum of demands of plants in `c`. If `D[c] <= R[c]`, each plant takes
   its demand. Otherwise each takes `demand * R[c] / D[c]`. The total taken from `c` is `<= R[c]`, so the pool never goes negative.
   This makes competition explicit: the more plants in a cell, the less each gets, so growth is bounded by the pool and the
   regeneration (the carrying capacity).
3. **Gain**: `energy += taken * yield` (through `add_energy`).
4. **Maintenance**: `drain_energy(MAINT_BASE + MAINT_HEALTH * health)` with `MAINT_BASE = 0.5`, `MAINT_HEALTH = 0.01` per tick.
   Energy reaching 0 gives `Starvation` (ADR-0011).
5. **Growth**: if `g > 0` and `energy > GROWTH_RESERVE = 40`, growth `dh = min(GROWTH_RATE * g, max_health - health, energy - GROWTH_RESERVE)` with
   `GROWTH_RATE = 1.0` health per tick, paid with `dh` energy (1 energy per health unit), but only from energy above the reserve.
   Growth is `heal(dh)` and `drain_energy(dh)`. A plant at `max_health` does not spend energy on growth.
6. **Hostile climate**: if `g == 0` (`f_T = 0` or `f_W = 0`), `damage(HOSTILE_DAMAGE = 2.0, Exposure)`. Health 0 gives `Exposure`.
7. **Regeneration** of every cell as above, after all plants have acted (the pool is refilled once per tick).
The phase returns a report `PlantReport { taken, gained, regenerated }` (f64 sums in id and cell order) for tests and metrics.
Invariant: `gained <= taken` (yield <= 1) and the pool never goes negative.

### Ageing and death (ADR-0011, unchanged)
Plants age in the Deaths phase. Causes: `OldAge` (age reaches `max_lifespan`), `Starvation` (energy 0), `Exposure` (hostile climate,
damage to health 0), `Injury` (health 0 from any other source). No plant death depends on the number of plants.

### Carrying capacity
With proportional sharing and the regeneration above, a cell at full suitability supports a number of plants whose total
uptake matches the regeneration flow (`REGEN_RATE * CAP_MAX` = 5 units per tick at most). Density levels off without any rule
that looks at global counts. Crowding (growth slowing with neighbours) is not added in TASK-011.

### Parameters
The constants above live in `ecology.rs` as `pub const`s. They are not configuration keys (adding keys to the fixed contract or
to ADR-0006 is a separate decision; calibration belongs to TASK-017/018).

## Consequences
- Determinism: no RNG draws in the plant phase; per-cell sums in fixed order; equal seeds give equal states.
- Checkpoint (TASK-022): must save `World.resources` (one `f32` per cell) in addition to the ADR-0011 fields and genomes.
- Performance: one climate query per plant and per cell per tick, one genome decode per plant per tick (about 128 byte reads).
  Measured in TASK-011 IMPLEMENT at 2,000 plants and reported in `docs/ARCHITECTURE.md`.
- Energy source: documented here and in `docs/ARCHITECTURE.md` (module `core::ecology`): plant energy comes only from the cell pool;
  the pool is refilled only by the climate capacity; yield <= 1.
- Distribution: `dist/` is rebuilt by `build.sh` and holds no plant-specific file; this ADR changes no file under `dist/` by hand.
- The genome decoding for plants is genetic variation only: founder genomes have block means near 0.5 with a spread of about 0.07,
  so founder tolerances differ little. Selection on tolerance is TASK-012 onwards.

## Verification strategy
Testability: every rule is a pure function or a seeded run, so each Must-have of TASK-011 has a named test (see the implementation notes).
- Pure functions: `f_T` is 0 at and below `L` and at and above `U`, 1 at `T_OPT`, monotone on each side; `f_W` is 0 below `P_MIN`,
  increasing in `P`, below 1; both in `[0, 1]` over random inputs (seeded, at least 10,000 samples).
- Decoding: `PlantTraits::from_genome` is in range for 10,000 seeded random genomes; equal genomes give equal traits.
- Required test (task.md): the same plant grows more slowly or not at all in a cold cell and in a dry cell than in a favourable
  cell (pure function test and a two-cell Simulation test with a polar and an equatorial row, weather off).
- Competition: in one cell with many plants, total taken `<= R` before the phase plus regeneration, `R >= 0`, each plant's take
  proportional to its demand.
- Source: `gained <= taken` and the pool change equals `regenerated - taken` over a seeded run of at least 500 ticks.
- Ageing and death: old age at `max_lifespan`; starvation when the pool is empty and maintenance drains energy; exposure in a
  hostile cell (`g == 0`) kills by health 0.
- Population: a seeded plant-only run of at least 500 ticks stays below the sum of the capacities (carrying capacity) and never
  goes to zero in a favourable world.
- Determinism: same seed twice gives equal state; `Simulation` equality includes `World.resources`.

## Implementation notes (TASK-011 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/ecology.rs` (constants, `PlantTraits`, `growth_factors`, `capacity`, `ResourceField`, `plants_phase`);
  `entities.rs` `living_mut`; `sim.rs` `World.resources` and the Plants arm of `run_phase`.
- Plant phase order inside `plants_phase`: pass 1 (demand, proportional shares, reads only); pass 2 (gain, maintenance,
  growth or hostile damage, living plants in ascending id order, animals skipped); pass 3 (pool minus takes, never below 0, then regeneration).
- Energy gain is the energy actually added after the `ENERGY_MAX` cap, so `gained <= taken` holds.
- Regeneration toward `capacity(climate.conditions(c))` uses the current climate; with weather on, capacity moves with the weather.
- Tests: 22 new tests in `ecology.rs` (pure factor tests, two-cell cold/warm and dry tests, genome slot tests, sharing, empty pool,
  old age, exposure, 500-tick pool accounting, determinism, index and balance invariants).
- Existing tests adjusted because plants now gain energy from the pool and can die of exposure: `sim.rs`
  `founders_die_of_old_age_in_the_tick_their_lifespan_ends` (favourable cell, full max health) and
  `starved_founder_is_removed_from_the_index_by_the_deaths_phase` (cell where the plant cannot grow). Assertions unchanged.

## Amendment note for ADR-0004
ADR-0004 slot 7 was "reserved" and the plant-only traits were "deferred". This ADR assigns slots 5, 6 and 7 to plant traits
(`cold_tolerance`, `drought_tolerance`, `yield`). ADR-0004 gets a matching amendment at IMPLEMENT.

**Amendment (TASK-018 IMPLEMENT cycle 1, ADR-0019 D4).** `REGEN_RATE` 0.05 to 0.1 (regeneration toward the cell capacity).
Chosen with `BITE_MAX` 0.5 (ADR-0015) so that herbivores with plenty of plants survive 500 ticks. Plant-only persistence was
kept (five seeds alive at 1,000 ticks with `plants.max_age` 1500). Calibration log: `docs/results/TASK-018-calibration.md`.

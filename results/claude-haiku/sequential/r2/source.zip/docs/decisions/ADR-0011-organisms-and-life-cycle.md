# ADR-0011: Organisms, traits, storage and the life cycle

Status: Accepted (drafted in TASK-008 PLAN cycle 1; accepted at TASK-008 REVIEW cycle 1 PASS).

## Context
TASK-008 defines what an organism is and the rules of birth, living and death shared by plants, herbivores and carnivores.
The Simulation has an empty `Entities` slot in the tick (ADR-0008) and the spatial index (ADR-0003), genome (ADR-0004) and
ecology (TASK-009 onwards) all read or write organisms. Their interface must be fixed here: the id rule, the trait list and
ranges, the storage order, the death causes, the births/deaths bookkeeping and the rule for births and deaths in the same tick.
Genomes are out of scope (TASK-009): in TASK-008 traits are plain values passed in and validated; TASK-009 derives them from
the genome. Feeding, movement and reproduction behaviour are out of scope (TASK-013 to TASK-016).

## Considered alternatives
1. **One struct per kind (`Plant`, `Herbivore`, `Carnivore`) in three vectors.** Typed fields per kind, but every phase that
   handles "any organism" (spatial index, death, counters, checkpoint) must iterate three vectors and merge them by id, and an
   id-ordered iteration across kinds needs extra code. Rejected.
2. **One `Organism` struct with a `Kind` tag, all organisms in one `Vec` sorted by id (chosen).** Single iteration order (ascending
   id, ADR-0008), single removal pass, single checkpoint section. Kind-specific data is an `Option` that is `Some` only for animals,
   checked by the constructor. Cost: plants carry an unused `Option` (one word), which is negligible.
3. **`HashMap<OrganismId, Organism>`.** O(1) lookup, but iteration order is not deterministic (ARCHITECTURE determinism rule 4).
   Rejected; a `BTreeMap` would work but costs more per iteration than a sorted `Vec`.
4. **Slot map with id reuse.** Compact, but violates the "id never reused" acceptance point. Rejected.

## Decision

### Kinds
`enum Kind { Plant, Herbivore, Carnivore }` with `Kind::ALL` in that order and `Kind::index()` (0, 1, 2) used for per-kind arrays.
Only animals (`Herbivore`, `Carnivore`) have behaviour tendencies and a diet; that is recorded here and enforced by the constructor.

### Identity
- `OrganismId(u64)`, a newtype. Allocated from `Entities::next_id`, starting at 0, incremented once per organism created
  (founder or child). Never reused, even after death. `next_id` is part of the simulation state (saved by the checkpoint, TASK-022).
- Parents are `[Option<OrganismId>; 2]`: founders have `[None, None]`; plants have one parent (asexual); animals have two.
  A child may only name parents that are alive at the moment of its birth (a dead organism never acts again).

### Organism fields (all private; read through getters)
| Field | Type | Range / rule |
|---|---|---|
| `id` | `OrganismId` | unique, never reused |
| `kind` | `Kind` | one of three |
| `cell` | `Cell` (ADR-0007) | a valid cell of the torus; set by constructor and movement (TASK-013) |
| `age` | `u32` | ticks lived; 0 at birth; +1 per survived tick |
| `energy` | `f32` | `[0, ENERGY_MAX]`, `ENERGY_MAX = 100.0` |
| `health` | `f32` | `[0, traits.max_health]` |
| `traits` | `Traits` | see below, all in documented ranges |
| `tendencies` | `Option<Tendencies>` | `Some` iff the kind is an animal |
| `parents` | `[Option<OrganismId>; 2]` | see Identity |
| `generation` | `u32` | founders 0; child = 1 + max(generation of its parents) |
| `cause` | `Option<DeathCause>` | `None` while alive; set once when the organism dies |

### Traits and ranges
| Trait | Type | Range | Applies to |
|---|---|---|---|
| `speed` | `f32` | `[0.0, 4.0]` cells per tick | all (plants 0 is valid, they do not move) |
| `strength` | `f32` | `[0.0, 10.0]` | all |
| `fertility` | `f32` | `[0.0, 1.0]` | all |
| `max_lifespan` | `u32` | `[1, 10_000]` ticks | all (config `*.max_age` is the intended centre, TASK-009) |
| `max_health` | `f32` | `[1.0, 100.0]` | all |
| `aggression` | `f32` | `[0.0, 1.0]` | animals only (`Tendencies`) |
| `caution` | `f32` | `[0.0, 1.0]` | animals only (`Tendencies`) |

`Traits::new` and `Tendencies::new` reject NaN, infinities and out-of-range values with an error naming the trait. No silent clamping
at construction. Trait ranges are constants in `entities.rs`; genome decoding (TASK-009) must map into them.

### Energy and health: the valid range
- Energy and health are changed only through methods that clamp: `add_energy(x)`, `drain_energy(x)`, `damage(x, cause)`,
  `heal(x)`. Inputs must be finite and `>= 0` (otherwise a debug assertion and a no-op in release; tests cover both paths).
- Clamping is the only protection in arithmetic. Constructors reject values outside the range (no silent fix of inputs).
- `Entities::check_invariants()` checks every stored organism (ranges, sorted ids, unique ids, the animal/tendency rule,
  `cause` is `Some` only for organisms that are about to be removed). It is run in tests and in a debug build at each tick.

### Death
`enum DeathCause { OldAge, Starvation, Predation, Exposure, Injury }`.
- An organism dies at the moment its `cause` is first set. The first event in the tick decides the cause:
  `drain_energy` to 0 gives `Starvation`; `damage` to 0 health gives the cause passed to `damage` (`Predation`, `Exposure` or `Injury`).
- In the Deaths phase (ADR-0008 step 7), first every alive organism ages by one (`age += 1`). Then, in ascending id order,
  every alive organism without a cause gets one, in this order of checks: `health == 0` gives `Injury`; `energy == 0` gives `Starvation`;
  `age >= max_lifespan` gives `OldAge`. (These checks catch values that were already zero at birth, which the event methods never see.)
  Then every organism with a cause is removed by one order-preserving `retain`, and a `Death` record
  `{ id, kind, cell, tick, cause }` is appended to `Entities::last_deaths`, which is cleared at the start of the Deaths phase.
  Consequence: an organism with `max_lifespan` L takes actions in ticks 0 to L-1 and dies in the Deaths phase of tick L-1 with `OldAge`.
- A dead organism (cause set, not yet removed) never acts again: every action phase iterates `Entities::living()`, which skips it.
  Removal happens only in the Deaths phase, after all action phases.
- Cumulative deaths are counted per kind and per cause (`deaths_by_cause[kind][cause]`).

### Births, deaths and bookkeeping
- `Entities` owns `initial[kind]`, `births[kind]`, `deaths[kind]` (all `u64`, since tick 0), `deaths_by_cause`, `next_id`, and the
  sorted organism vector. Founders are counted in `initial`, never in `births`.
- A child is created by `Entities::spawn_child(kind, cell, traits, energy, parents, tick)` (Reproduction phase, TASK-012/016).
  It increments `births[kind]`. Founders are created by `Entities::spawn_founder(...)`, which increments `initial[kind]`.
  `Simulation::add_founder` allows founders only at tick 0 (any later call is an error), so `initial` always means "tick 0".
- Invariant, checked by `Entities::check_balance()` in the Counters phase and in tests: for every kind,
  `initial + births - deaths = living count`.

### Same-tick rule (one documented rule)
Within one tick, phases run in the fixed order of ADR-0008: Reproduction (births) runs before Deaths. Therefore:
1. Births of a tick are committed before the deaths of that tick are evaluated. Newborns take part in the Deaths phase of their
   birth tick and can die there only from a cause already present at birth (for example energy 0 at birth).
2. A parent that reproduces and then dies of a cause in the same tick has its child recorded; the parent is in `deaths`, the child
   in `births`. Both counts refer to the same tick.
3. A newborn's age is 0 at birth and becomes 1 at the end of its birth tick if it survives.
4. Nothing created or removed in a tick is visible to the action phases of the same tick, except that a child is only created
   in Reproduction and so is never a target in the action phases of its birth tick (the action phases run before Reproduction).

### Storage and order
- `Entities { organisms: Vec<Organism> /* sorted by id, ascending */, next_id, initial, births, deaths, deaths_by_cause, last_deaths }`.
- New ids are always larger than all existing ids, so `push` keeps the vector sorted. Lookup by id is a binary search
  (`get(id)`, O(log n)). Removal is one `retain`, order preserving (ADR-0008 rule 3).
- Iteration: `living()` yields alive organisms in ascending id order. This is the only order allowed for processing.

### Simulation integration
- `Simulation` gains `entities: Entities` (part of equality and of the checkpoint later). `World` is unchanged.
- `Phase::Deaths` calls `entities.deaths_phase(tick)`. `Phase::Counters` calls `entities.check_balance()` (a check, no state change).
  Other phase arms stay empty until their tasks.
- The trace (ADR-0008) is unchanged for empty phases; no RNG draws are added in TASK-008.

## Consequences
- **Performance**: `Vec` of organisms; each tick one retain plus one pass for ageing; lookups O(log n). At 5,000 organisms this is
  microseconds, far below the 100 ticks/s budget. Organism size is about 64 bytes (estimate), so 5,000 organisms are about 0.3 MB.
- **Testability**: all rules are pure methods on `Organism`/`Entities` and run in `cargo test` without a world or UI.
- **Determinism**: ids, order and counters are integers; no hash maps; no RNG draws in TASK-008.
- **dist/**: plain Rust in the core; no new crate, no system dependency.
- **Checkpoint (TASK-022)**: must save `next_id`, `initial`, `births`, `deaths`, `deaths_by_cause`, every organism field (including
  `cause` and `parents`). `last_deaths` is not saved by the rule above; **superseded by ADR-0023 D4**, which saves it so that the
  checkpoint re-encodes byte for byte (ADR-0020 D3 already encodes it).
- **Trade-off**: plants carry the animal-only `tendencies` option. Accepted for a single store and a single order.
- **Trade-off**: founders are not placed from `config.initial` in TASK-008 (see gaps); the spawn API is ready for it.

## Verification strategy
- Unit: kinds and `Kind::ALL` order; trait and tendency range checks at the boundaries, NaN and infinity rejected; animal/tendency
  rule enforced; `Cell` from the torus only.
- Ids: ids strictly increase across a randomised sequence of spawns and deaths (seeded `Rng`, at least 1,000 operations); no id
  reappears after its organism died; `living()` is sorted by id.
- Energy/health: randomised sequences of add/drain/damage/heal (seeded, at least 10,000 operations) keep both within range; zero and
  full values hit the bounds exactly.
- Death: energy 0 gives `Starvation`; age reaching `max_lifespan` gives `OldAge`; health 0 gives the given cause; the first cause wins;
  a dead organism is skipped by `living()`; the death record has tick, kind, cell and cause; the organism is removed in the Deaths phase.
- Bookkeeping: over a seeded sequence of at least 1,000 ticks with spawns and deaths, `initial + births - deaths = living` holds per
  kind at every tick (`check_balance`); founders are not counted as births.
- Same-tick rule: test (1) a newborn with energy 0 dies in its birth tick and both counts change in that tick; test (2) a parent
  that reproduces and starves in the same tick is recorded as both a birth and a death of that tick.
- Simulation: `tick()` with founders present advances ageing and removes dead organisms; `add_founder` after tick 0 is an error.
- Static checks: `scripts/check_adrs.sh` (ADR-0011 added to the list in IMPLEMENT); grep for `HashMap`/`HashSet` in `entities.rs`
  returns nothing.

## Implementation notes (TASK-008 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/entities.rs` (types, `Entities`, Deaths phase, checks, 60+ unit tests), `sim.rs` (field `entities`,
  `add_founder` at tick 0 only, Deaths phase calls `deaths_phase(tick)`, Counters phase runs `check_balance` and `check_invariants`
  as debug assertions). `from_parts` takes `Entities` as a fourth argument (checkpoint TASK-022 saves it).
- Deviation: `spawn_child` also checks that animals name two distinct parents and that a child's parents are alive, both before any
  state change. `check_invariants` checks the per-cause death sums before the balance (an error of that kind is `Invariant`).
- Founders are still not placed from `config.initial` (G-037); `Entities::spawn_founder` and `Simulation::add_founder` are ready.
- Traits are plain validated values; genome decoding (TASK-009) must map into the ranges above.


## Amendment (TASK-009 IMPLEMENT cycle 1)
- `Birth` and `Organism` carry a `genome`. `Birth` is no longer `Copy`. `Birth::from_genome` decodes traits and tendencies with
  `entities::decode_traits`; spawn rejects traits or tendencies that differ from the decode (`GenomeMismatch`) and a ploidy that
  does not fit the kind (`PloidyMismatch`). `check_invariants` re-checks every stored organism against its genome.
- G-039 resolved: the trait ranges above are unchanged and the genome maps into them (ADR-0004 implementation notes).
- Checkpoint (TASK-022) must also save each organism's `genome` (ploidy and loci).
- Founders: `Simulation::populate_initial` places `config.initial` founders at tick 0 (energy 50, full health).

**Amendment (TASK-018 IMPLEMENT cycle 1, ADR-0019 D2).** The `max_lifespan` centre is now the config `*.max_age` key of the kind:
lifespan = `floor(max_age * (0.5 + m))` with `m` the block mean of the lifespan slot, clamped to `[1, 10000]`. Set through
`entities::LifespanRanges` and `Birth::from_genome_in`. `Birth::from_genome` keeps the default centres. `validate_genome` checks
only the range of `max_lifespan` (the centre is not stored with the entities). Default centres: plants 1500 (changed from 500 in
TASK-018), herbivores 300, carnivores 400.

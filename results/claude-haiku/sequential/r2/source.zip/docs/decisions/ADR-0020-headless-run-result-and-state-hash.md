# ADR-0020: Headless `run` command, result JSON and state hash

Status: Accepted (drafted in TASK-019 PLAN cycle 1, implemented in IMPLEMENT cycle 1; accepted at TASK-019 REVIEW cycle 1 PASS, see `tasks/TASK-019/handoffs/review-cycle1.md`).

## Context
`docs/CONTRACT.md` sections 2, 4 and 5 fix the external behaviour of `evosim run`: flags, the result JSON keys, determinism,
error behaviour (exit 2, message on stderr, no result file) and the rule that `state_hash` covers the complete state at
`tick_end`. The checkpoint flags `--save` and `--load` belong to TASK-022 and are not implemented here. The CLI has no `run`
command yet (`evosim run` exits 2 with "unknown command"). Founders are placed only by `Simulation::populate_initial`, which the
CLI does not call yet (gap G-037, TASK-009 and TASK-017 notes).

Constraints: `docs/PROJECT.md` (no count-based rules, deterministic, one RNG stream), `docs/ARCHITECTURE.md` (std-only core,
`core::checkpoint` owns the canonical serialization and `state_hash`, `core::metrics` owns the result model, the CLI is the only
writer of files and stdout, wall-clock time is reported but never enters state). No crate registry is cached in the container
and `sha2` was never fetched, so a hash crate would need network access at build time, which ADR-0001 and ADR-0005 avoid.
`state_hash` is also needed by TASK-020 (metrics must not change it) and TASK-022 (checkpoint must reproduce it).

## Considered alternatives
1. **Hash the `Debug` text of `Simulation` (rejected).** Short to write, but the output depends on the formatting of the Rust
   standard library and on derived `Debug` output, so it is not a documented, stable format and would change silently with a
   compiler or refactoring. It also cannot be reused as the checkpoint body.
2. **Use a non-cryptographic 64-bit hash such as FNV-1a over the canonical bytes (rejected).** Simple and fast, but a 64-bit
   accidental collision over benchmark-sized runs is not negligible enough to be called "different states give different hashes"
   without caveat, and a 256-bit digest costs nothing at one call per run.
3. **Add the `sha2` crate (rejected for now).** Standard choice and what ARCHITECTURE listed, but not available offline here, and
   it adds a dependency to the distributable. Revisit only if TASK-022 needs a crate for something else.
4. **Canonical little-endian encoding of all state, then SHA-256 implemented in `core::sha256` (chosen).** Std-only, checked
   against the NIST test vectors, and the same encoding is the body of the TASK-022 checkpoint.

## Decision

### D1 Command and flags (`evosim run`)
```
evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K]
```
- `--config`, `--ticks`, `--out` are required. `--ticks` is an integer `N >= 0` (`0` is valid). `--seed` is a `u64` that
  replaces `seed` of the configuration before the simulation is built. `--sample-every` is an integer `K >= 1`.
- Each option may appear once; a repeated option, an unknown option, a missing value or a non-integer value is an error.
- `--save FILE` and `--load FILE` are recognised but rejected with exit 2 and the message "checkpoints are not available in
  this build (TASK-022)", so that no run silently ignores them.
- `--out FILE`: parent directories are created (as `evosim climate` does).
- Default `K` = `max(1, N / 100)` (integer division), as in CONTRACT section 2.

### D2 Result JSON
Required keys of CONTRACT section 4, plus these additional keys (CONTRACT allows additions):
- `totals.initial` per kind (so that `initial + births - deaths = final` can be read from the file),
- `sample_every` (the `K` used),
- `state_format` (the version of the canonical encoding of D3, currently `1`),
- `hash_algorithm` (`"sha256"`),
- `species_recognised` per kind (species records ever created, extinct or not).

The file has one key or one array element per line, so that the determinism test and `scripts/test.sh` can compare two outputs
after dropping the two lines that hold wall-clock values (`elapsed_seconds`, `ticks_per_second`). Keys are written in the order of
CONTRACT section 4, then the additional keys.

### D3 `state_hash`
- Input: the canonical encoding of the complete `Simulation` at `tick_end`, produced by `core::checkpoint::encode_state`:
  a magic string `EVOSIMST`, the format version `1`, then every field in a fixed order, little-endian, integers as fixed width,
  `f32`/`f64` by their bit patterns (`to_bits`), vectors with a `u64` length prefix, enums as a one-byte tag. Each module encodes
  its own state in a method `encode_state` (`rng`, `climate`, `ecology::ResourceField`, `genome`, `entities`, `species`, the
  settings structs of `reproduction`, `mating`, `entities::LifespanRanges`, `sim`).
- Included: tick counter, generator state, world topology, climate parameters, terms, weather nodes and `weather_tick`,
  resource pool, the organism store (every field of every organism including genome, parents, cause, next_mate_age, species,
  and `next_id`), the per-kind counters (initial, births, deaths, deaths by cause), `last_deaths`, species registry (settings,
  records, candidates, name counters), seeding, mating and lifespan settings.
- Excluded, with reason: the spatial index (derived from the organism store, `check_spatial` verifies it), the climate `cells`
  cache (recomputed from the included terms, parameters, nodes and tick; a test checks this), and the optional phase trace
  (diagnostic, not state).
- Digest: SHA-256 (FIPS 180-4) of those bytes, implemented std-only in `core::sha256`, written as 64 lowercase hex digits.
- Stability: any change to the encoding must bump the format version. Encoders destructure their structs without `..`, so a new
  field that is not encoded is a compile error.

### D4 Series and sampling
- `series` holds the living individuals per kind at `tick_start`, then at `tick_start + j*K` for every `j >= 1` with
  `tick_start + j*K <= tick_end`, then at `tick_end` if that tick was not already sampled. Ticks ascend and do not repeat.
- Sampling is read-only and happens outside `Simulation::tick()` (ADR-0008), in the CLI loop. Its cost is one count per kind.

### D5 Final values and species
- `final.species` per kind = number of species records of that kind with `extinct_tick` absent, after the last tick. This uses
  the registry's extinction pass, which runs every tick (ADR-0018). A new helper `SpeciesRegistry::living_now(kind)` gives it
  (the existing `living_count(kind, tick, now)` requires `tick < now`).

### D6 Timing
- `elapsed_seconds` is measured by the CLI around the tick loop only (not start-up, not the file write). It never enters the
  state. `ticks_per_second` = `N / elapsed_seconds`, or `0.0` if `elapsed_seconds` is zero (for example `N = 0`).

### D7 Errors and output
- Every failure exits with status 2: invalid arguments, unreadable or invalid configuration (message names the key, through
  `ConfigError`), invalid simulation parameters, unwritable output. The message goes to stderr.
- Nothing is printed to stdout by `run`.
- The result is built completely in memory and then written to a temporary file in the target directory, which is renamed to
  `--out` only after the whole result is ready. A failed run therefore writes no result file. A file that already exists at
  `--out` is not removed by a failed run.

### D8 Founders and determinism
- `run` builds `Simulation::new(config)` and then calls `populate_initial(config)` before tick 0. Closes G-037 for the CLI.
- Determinism follows from ADR-0008 and ADR-0011: same configuration (after `--seed`), same `--ticks`, same build give identical
  `final`, `totals`, `series` and `state_hash`. Different seeds change `state_hash`.

## Consequences
- Positive: the result format is fixed by the contract plus a documented extension; the checkpoint of TASK-022 reuses
  `encode_state`, so the hash and the saved state cannot diverge; no new dependency.
- Negative: every module with simulation state gains an `encode_state` method, which is a wide but mechanical change. The hash
  costs one pass over the state at the end of a run (negligible at the default size).
- Risk: a field added later without an encoder entry is caught by the exhaustive destructuring, but a derived cache that is
  wrongly left out is not caught by the compiler; the cache tests in `checkpoint` are the guard.

## Verification strategy
- `core::sha256`: FIPS 180-4 vectors for the empty string, `abc`, the 448-bit two-block message and one million `a` characters.
- `core::checkpoint`: equal states give equal hashes; a state that differs in exactly one field (each field group listed in D3,
  for example one RNG word, one organism energy bit, one genome locus, one species record, one resource value, one weather
  node, one settings value) gives a different hash; the hash changes after a tick; a state rebuilt from its parts hashes equal.
- CLI unit tests: argument parsing (every error case in D1 and D7), `result` JSON shape.
- End-to-end (`crates/evosim-cli/tests/run_cli.rs`, uses `CARGO_BIN_EXE_evosim`): two runs with the same seed give identical
  `final`, `totals`, `series`, `state_hash`; a different seed gives a different `state_hash`; `--ticks 0` works; a run in which
  everything goes extinct still runs all `N` ticks; error cases exit 2 and leave no file; run with `DISPLAY` and `WAYLAND_DISPLAY`
  unset works.
- `scripts/test.sh` black-box step: `./evosim run` twice on the example configuration of CONTRACT section 3 with the same seed,
  compared after removing the two wall-clock lines.

## Implementation record (TASK-019 IMPLEMENT cycle 1)
Status stays Proposed until TASK-019 REVIEW. The decisions D1 to D8 are implemented as written, with these details and
deviations:
- Files: `core/sha256.rs` (new), `core/checkpoint.rs` (new: `Encoder`, `encode_state`, `state_hash`, `MAGIC`, `FORMAT_VERSION`),
  `core/metrics.rs` (new: `kind_counts`, `sample`, `series_ticks`, `default_sample_every`, `RunResult::to_json`,
  `ticks_per_second`), `encode_state` methods in `rng`, `world` (`Torus`), `climate` (`WaveTerm`, `Climate`), `ecology`
  (`ResourceField`), `genome` (`Genome`, `Mutation`), `entities` (`Traits`, `Tendencies`, `LifespanRanges`, `Death`,
  `Organism`, `Entities`), `species` (`SpeciesSettings`, `SpeciesRecord`, `Candidate`, `SpeciesRegistry`), `reproduction`
  (`SeedingSettings`), `mating` (`MatingSettings`), `sim` (`World`, `Simulation`), and `SpeciesRegistry::living_now`.
  CLI: `args.rs` (`Command::Run`, `RunArgs`, `parse_run`), `main.rs` (`run_run`, `write_atomically`).
- D1 detail: a repeated option is `RepeatedOption` (exit 2). `--save FILE` and `--load FILE` are parsed (the value is consumed)
  and then refused with "`<option>: checkpoints are not available in this build (TASK-022)`".
- D2 detail: the result is pretty-printed with one key per line; the `series` samples are one object per line. The
  `totals` object lists `births`, `deaths`, then `initial`.
- D3 detail: `Climate.torus` is encoded (it is state, and the cache check depends on it); only `Climate.cells` is excluded,
  with the destructuring `cells: _`. `Simulation` excludes `spatial: _` and `trace: _`. The hash is over
  `EVOSIMST` + `u32` format 1 + the encoding; `sha256::digest` is checked against NIST and `sha256sum` (values recorded in the
  tests).
- D4 detail: `series_ticks` uses checked addition, so ticks near `u64::MAX` do not overflow.
- D6 detail: `elapsed_seconds` covers the sampling loop (the ticks plus the O(1) samples), not start-up, not the hash, not the
  file write.
- D7 detail: `run_run` creates the parent directory of `--out` before the run (so an unusable location fails early); the file
  is written to a temporary name in the same directory and renamed; on failure the temporary file is removed.
- Verified by test (see `tasks/TASK-019/handoffs/implement-cycle1.md`): every field group of D3 changes the hash when changed
  alone (RNG word, tick, organism energy, genome locus, species record, settings, resource value, weather node, climate
  parameter, next id); a climate rebuilt from its parts has the same conditions in every cell; the same seed gives equal
  results end to end; `--ticks 0` and all-extinct runs advance all ticks.
- Not separately tested: `deaths_by_cause` and `last_deaths` (their encoding is compile-checked by the destructuring; no public
  setter exists to change them alone).
- Deviation from the PLAN: none in behaviour. Planned `checkpoint::tests` names were adjusted to the tests written.

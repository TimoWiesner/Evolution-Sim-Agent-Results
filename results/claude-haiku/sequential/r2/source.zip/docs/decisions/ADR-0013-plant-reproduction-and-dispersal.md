# ADR-0013: Plant reproduction, seed dispersal and mutation

Status: Accepted (drafted in TASK-012 PLAN cycle 1; accepted at TASK-012 REVIEW cycle 1 PASS).
Extends ADR-0011 (Reproduction phase, `spawn_child`, parents and generation) and ADR-0012 (plant energy comes only from the
cell pool; `fertility` was reserved for this task). Uses ADR-0004 (genome copy and mutation), ADR-0003 (spatial index),
ADR-0006 (`plants.reproduction_chance`, `plants.seed_radius`, `genetics.*`) and ADR-0007 (torus distance and neighbourhood).

## Context
TASK-012 lets plants multiply, spread over the torus and pass on mutated genomes. The acceptance points are: reproduction only
with enough energy and at a cost; offspring within a dispersal distance of the parent, also across the edges; inheritance with
mutation, with parent id and generation recorded; no offspring without room or resources; and a world with zero plants stays
at zero. Herbivores and carnivores still do not reproduce (TASK-016), and species are TASK-017. The Reproduction phase is the
empty arm of `Simulation::run_phase` (ADR-0008, after the animal phases and before Deaths).

## Considered alternatives
1. **Asexual seeding only (chosen).** A plant produces seeds from its own genome. Matches ADR-0011 (plants have one parent) and
   ADR-0004 (copy child for plants). Pollination between two plants would need a second parent, a mate search and a
   pollen-range rule, which adds code without a test in this task.
2. **Asexual plus pollination.** More ecological, but it doubles the mate search and the parent-validity cases before any
   animal mating exists (TASK-016). Deferred to a later task; the chosen design leaves the `parents` slots as they are.
3. **Uniform dispersal over the Chebyshev square of radius `seed_radius` (chosen).** One draw from `Torus::neighbours`, which
   already returns each cell once and wraps across both edges. Simple, testable, and it covers the "dispersal over several
   cells" idea. Trade-off: no long-distance tail, so recolonisation of far regions is slow.
4. **Distance-decay (for example exponential) dispersal kernel.** More realistic seed shadows, but the kernel must be sampled
   with floating-point arithmetic per seed and calibrated. Deferred to TASK-018 calibration if the uniform kernel is too local.
5. **Retry on refusal (try several cells until one has room).** Seeds would always land, but the refusal rate would hide the
   "no room, no resources" rule the task requires. Rejected: one draw per seed; a refused seed is lost.

## Decision

### Settings (from the configuration, stored in `Simulation`)
`SeedingSettings { chance: f64, radius: u32, mutation: Mutation }`, built by `SeedingSettings::from_config(&Config)` from
`plants.reproduction_chance`, `plants.seed_radius` (ADR-0006) and `mutation_settings(config)` (ADR-0004). `Simulation::new`
stores it. `Simulation::from_parts` takes it as a fifth argument; the checkpoint (TASK-022) must save these three values,
because they are not derivable from the saved state (see Consequences).

### Constants (`reproduction.rs`, `pub const`, not configuration keys)
| Constant | Value | Meaning |
|---|---|---|
| `SEED_ENERGY_MIN` | 45.0 | a plant may seed only with energy at or above this (IMPLEMENT: was 70, see Implementation notes) |
| `SEED_COST` | 20.0 | energy the parent pays per seed attempt (ADR-0011 `drain_energy`) (IMPLEMENT: was 30) |
| `SEED_ENDOWMENT` | 10.0 | energy the seedling starts with; `SEED_COST - SEED_ENDOWMENT` is lost (overhead) (IMPLEMENT: was 20) |
| `SEED_HEALTH_FRACTION` | 0.5 | seedling health = 0.5 × its own `max_health` (valid birth health) |
| `CELL_PLANT_CAP` | 6 | "room": at most 6 living plants in a cell, counted with the spatial index |
| `SEED_RESOURCE_MIN` | 5.0 | "resources": the target cell's pool must hold at least 5 units |

These are local, per-cell and per-organism rules, as ADR-0012 and docs/PROJECT.md require. None looks at a global count.

### Reproduction chance (per plant, per tick)
- Effective chance `p = clamp(chance × 2 × fertility, 0, 1)`, where `chance` is `plants.reproduction_chance` and `fertility` is the
  decoded trait (genome slot 2, ADR-0011, range `[0, 1]`). With mean fertility 0.5, `p` equals the configured chance.
- A plant is mature when `energy >= SEED_ENERGY_MIN` and it is alive. An immature plant draws nothing.
- Draws are made only for mature plants (`rng.chance(p)`), so the number of draws is a deterministic function of state.

### Phase procedure (`Phase::Reproduction`, ADR-0008 order, after Carnivores, before Deaths)
1. Collect the ids of living plants in ascending id order into a list. Children created in this phase are not in the list, so
   a newborn never seeds in its birth tick (ADR-0011 same-tick rule 4).
2. For each id in the list, if the plant is still alive and mature, and `rng.chance(p)` succeeds:
   a. **Pay the cost**: `drain_energy(SEED_COST)`. Paid for every attempt, including refused ones (the seed was produced).
   b. **Dispersal draw**: `cells = torus.neighbours(parent.cell, radius)`; target = `cells[rng.next_below(cells.len())]`
      (uniform; the parent's own cell is one of the candidates, so `radius = 0` gives the parent's cell).
   c. **Room**: `spatial.within(target, 0, Some(Plant)).len() < CELL_PLANT_CAP`, else refused (`RefusedRoom`).
   d. **Resources**: `resources[target] >= SEED_RESOURCE_MIN`, else refused (`RefusedResources`). The pool is not changed by seeding.
   e. **Genome**: `copy_child(parent.genome, mutation, rng)` (ADR-0004 copy child; mutation draws from the simulation generator).
   f. **Birth**: `Birth::from_genome(Plant, target, genome, SEED_ENDOWMENT, SEED_HEALTH_FRACTION × max_health)`, then
      `entities.spawn_child(birth, [Some(parent.id), None])`, which sets generation = parent generation + 1 and counts the birth;
      then `spatial.insert(child, target, Plant)`.
3. The phase returns a report `ReproductionReport { seeds, placed, refused_room, refused_resources }` (integers) for tests.

Order of draws per attempt: chance, dispersal, mutation. The order is fixed by the id order of step 1.

### Energy accounting
- No energy is created: the seedling receives `SEED_ENDOWMENT < SEED_COST`, and the difference is removed. Plant energy still
  comes only from the cell pool (ADR-0012). Energy after a seed is `energy - SEED_COST`, which is at least 40 (`SEED_ENERGY_MIN - SEED_COST`).

### Dispersal and edges
- `Torus::neighbours` wraps both axes (ADR-0007), so a seed from `x = 0` can land on `x = W-1`. Distance is the torus Chebyshev
  distance (`Torus::distance`), which is at most `radius` for every landing cell.

### Inheritance and records
- The child's genome is the parent's loci with mutation (`copy_child`). `parents = [Some(parent.id), None]`. `generation` is
  `parent.generation + 1` (ADR-0011 `spawn_child`). Mutation rate 0 gives an identical genome (no draws).

### Plants only from plants
- The only creation path in the Reproduction phase is a plant seed from a living plant. With `initial.plants = 0`, no plant is
  ever created (`spawn_child` needs a living parent), so the count stays at zero.

### Determinism
- One simulation generator; ascending-id processing; no hash maps; `within` returns ids ascending; `neighbours` returns cells in a
  fixed order. Same seed gives the same state (`state_hash`).

## Consequences
- **Performance**: one `within` query and one `neighbours` vector per attempt. Attempts are limited by the energy threshold and the
  chance `p`. The number of plants is bounded by `CELL_PLANT_CAP` times the number of cells, and by the pool. To be measured
  in IMPLEMENT at 2,000 plants (ADR-0012 R3 still open).
- **dist/**: no new crate, no system dependency. `dist/` is not changed by hand.
- **Checkpoint (TASK-022)**: must save `SeedingSettings` (chance, radius and the mutation pair) in addition to the ADR-0011 and
  ADR-0012 fields. Until then a loaded simulation has no settings (`from_parts` signature makes this explicit).
- **Trade-off**: uniform dispersal is local. Long-range recolonisation is left to TASK-018 calibration.
- **Trade-off**: a refused seed still costs `SEED_COST`. This makes crowded or barren cells costly for their plants.

## Verification strategy
- Energy threshold: a plant with energy below `SEED_ENERGY_MIN` never seeds (report shows zero seeds, no draw, 1,000 ticks of
  a single plant held below the threshold by a hostile cell).
- Cost: a placed seed reduces the parent's energy by `SEED_COST` and gives the child `SEED_ENDOWMENT`; the sum of energy changes is
  negative.
- Dispersal radius: over 2,000 seeded seeds from one plant with `radius = 2` in an 8×8 world, every landing cell has torus distance
  `<= 2`; landing cells include `x` in {6, 7} and `y` in {6, 7} (edge wrap); with `radius = 0` every seed lands on the parent's cell.
- Inheritance: `parents == [Some(parent), None]`; child generation equals parent generation + 1; mutation rate 0 gives equal loci;
  rate 1.0 changes loci by at most `strength` per locus; no locus leaves `[0, 255]`.
- Room: a target cell with `CELL_PLANT_CAP` plants gives `RefusedRoom` and no new organism (`next_id` unchanged, `births` unchanged).
- Resources: a target cell with pool below `SEED_RESOURCE_MIN` gives `RefusedResources` and no new organism.
- Zero plants: `initial.plants = 0` with animal founders for 500 ticks leaves the plant count at zero and the plant birth count at zero.
- Population (promised by ADR-0012, G-049): a plant-only favourable run of at least 500 ticks neither dies out nor exceeds the
  bound `CELL_PLANT_CAP × cells`, and the pool never goes negative.
- Balance: `initial + births - deaths = living` holds per kind at each tick of a seeded reproduction run (`check_balance`).
- Determinism: same seed gives equal state and `state_hash`; different seeds differ.
- Mutation pipeline: the genome of each child decodes with `decode_traits` (Plant) without `GenomeMismatch`.

## Implementation notes (TASK-012 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/reproduction.rs` (new: constants, `SeedingSettings`, `ReproductionReport`, `ReproductionError`,
  `reproduction_phase`, unit tests), `sim.rs` (field `seeding`, `Phase::Reproduction` arm, `from_parts` fifth argument,
  `seeding()` accessor, `SimError::Reproduction`), `lib.rs` (`pub mod reproduction`), `ecology.rs` (G-050 test rewritten).
- **Deviation: calibration.** The planned `SEED_ENERGY_MIN = 70` is unreachable under the TASK-011 economy. A probe over 500
  ticks (64x48, 400 plants, seed 51) showed plant energy plateauing near 35 (mean) with a maximum near 55: growth only converts
  energy above `GROWTH_RESERVE` (40), and satiation damps intake. With 70 there were 0 seeds. Measured with the cost and endowment
  shown: 70/30/20 gave 0 births; 50/20/10 gave 84 births and 230 living; 45/20/10 gave 362 births and 458 living (cap 6 x 3072 =
  18432); 40/20/10 gave 1960 births and 1868 living. 45/20/10 was chosen: about 1% of plants are mature at any tick and the
  population grows slowly and stays bounded. The constants stay uncalibrated for the ecology (TASK-018 may adjust them).
- `tick` is not a parameter of `reproduction_phase`: the phase does not use it.
- The report is discarded in the Simulation arm; errors are debug assertions.
- Tests (all pass): see `tasks/TASK-012/handoffs/implement-cycle1.json`, `tests`.
- Release timing at 2,000 plants (ADR-0012 R3) is NOT measured yet; open for REVIEW.
- Status stays Proposed; REVIEW sets Accepted on PASS.

## Review notes (TASK-012 REVIEW cycle 1)
- Acceptance points checked against the named tests (all pass in `cargo test --workspace --locked`, `scripts/test.sh` exit 0).
- Release timing at 2,000 plants (ADR-0012 R3, open since PLAN): a temporary release example (removed afterwards) ran 200
  ticks on 64x48 with 2,000 plant founders in 0.055 s, about 3,650 ticks/s, 1,462 living plants and 1,005 seed births at the end.
  Plants only; animal phases were not part of the measurement. This closes R3 for plants.
- Known gap: `newborns_do_not_seed_in_their_birth_tick` checks only that one mature parent gives one seed. It does not prove
  newborn exclusion; the exclusion rests on the id snapshot in `reproduction_phase` (code reading).
- The verification text above says "1,000 ticks"; the test calls the phase 1,000 times with energy fixed, not 1,000 ticks.

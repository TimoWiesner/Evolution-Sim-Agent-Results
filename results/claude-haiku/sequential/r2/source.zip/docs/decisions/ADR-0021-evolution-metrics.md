# ADR-0021: Evolution metrics (per-sample analytics, metrics file, format)

Status: Accepted (drafted in TASK-020 PLAN cycle 1; accepted at TASK-020 REVIEW cycle 1 PASS, see `tasks/TASK-020/handoffs/review-cycle1.json`).

## Context
`docs/PROJECT.md` asks that evolution can be seen in numbers, and `tasks/TASK-020/task.md` fixes what is recorded at every
sample tick: population per kind, births and deaths per kind, deaths by cause, living species per kind, mean and spread of
every trait per kind, and the highest and mean generation. Recording must not change the simulation (`state_hash` equal with
and without it), must be reachable from the command line (documented option or extra result keys), must have a documented
format, and must be checkable by hand in a small world.

What exists after TASK-019 (ADR-0020): `core::metrics` holds the result model of `evosim run` and the population sample
(`metrics::sample`, one count per kind). `Entities` keeps cumulative births, deaths and deaths by cause per kind, and
`Entities::living()` iterates the living organisms in ascending id. Each `Organism` has `traits()` (speed, strength,
fertility, max lifespan, max health), `tendencies()` (aggression, caution, animals only), `generation()`, `energy()`, `age()`
and `genome()`. Plant-only traits (cold tolerance, drought tolerance, yield) are decoded from the genome by
`ecology::PlantTraits::from_genome`; animal vision is `entities::vision_radius(genome)`. `SpeciesRegistry::living_now(kind)`
gives the living species count. CONTRACT section 2 fixes `run`'s options; section 4 allows extra result keys.
Constraints: `docs/PROJECT.md` (no rule may read counts to change behaviour; here metrics are output only), ADR-0008 (sampling
is read-only and outside `tick()`), ADR-0020 D4 (the sample ticks are the series ticks), no new dependency (std only).

## Considered alternatives
1. **Record inside `tick()` (rejected).** Every phase would write into a metrics store. This risks the state (any write
   path is a possible state change) and it breaks the ADR-0008 rule that sampling is an observer after `tick()`.
2. **Sampling read-only after `tick()` in a new core module, with the result written to a separate file (chosen).**
   `analytics::record(&Simulation, …)` only reads. It is called at the same ticks as the series (ADR-0020 D4). Testable,
   and no change to the result file except the optional new flag.
3. **Add the whole metrics block as extra keys of the result JSON (rejected for now).** Keeps one file, but the result becomes
   large for every run and the determinism check in `scripts/test.sh` compares it. A separate `--metrics FILE` is off by
   default, so the default result stays as it is in ADR-0020.
4. **A binary or CSV metrics file (rejected).** CSV cannot hold the nested per-kind, per-trait, per-cause structure without
   many columns. JSON matches the result file and is parsed by the same `config::json` module in tests and by TASK-021/025.

## Decision

### D1 Module and call pattern
- New module `core::analytics` (`crates/evosim-core/src/analytics.rs`). It depends on `sim` (read-only accessors),
  `entities` (organisms, traits, causes, `vision_radius`), `ecology` (`PlantTraits::from_genome`), `species`
  (`living_now`), and `metrics` (`KindCounts`, the JSON writer, `series_ticks`).
- Public API: `Snapshot` (one sample), `Stat { mean, sd, min, max }` (Option per trait), `MetricsLog` (keeps the previous
  cumulative counts to compute interval values), `MetricsLog::record(&mut self, sim: &Simulation)` (the only mutation is the
  log's own memory of the previous sample; `Simulation` is taken by `&`), `MetricsLog::to_json(run info) -> Result<String, String>`.
- The CLI calls `record` at each series tick in the same loop as `metrics::sample`. No core code calls it inside `tick()`.

### D2 What is recorded at each sample tick
Per kind (plants, herbivores, carnivores), with the index order of `Kind::ALL`:
- `population`: living individuals (`Entities::living_count`).
- `births`, `deaths`: cumulative since tick 0 (the same values as CONTRACT `totals`).
- `births_since_last`, `deaths_since_last`: births and deaths since the previous sample (the first sample gives 0).
- `deaths_by_cause`: cumulative per cause (`old_age`, `starvation`, `predation`, `exposure`, `injury`) for each kind.
- `species_living`: `SpeciesRegistry::living_now(kind)`. Species appear only at a species check (every `species.check_interval`
  ticks, ADR-0018), so this count can lag the population by up to one check interval.
- `species_recognised`: species records ever created for the kind (extinct or not).
- `generation`: `max` and `mean` of `Organism::generation()` over the living organisms of the kind.
- `traits`: for every trait of the kind, `mean`, `sd` (population standard deviation, divisor n), `min`, `max` of the decoded
  value over the living organisms of the kind. Traits per kind:
  - all kinds: `speed`, `strength`, `fertility`, `max_lifespan`, `max_health` (`Traits`);
  - herbivores and carnivores: `aggression`, `caution` (`Tendencies`), `vision` (`vision_radius`, cells);
  - plants: `cold_tolerance`, `drought_tolerance`, `yield` (`PlantTraits`).
  A kind with no trait of a name does not list it (so the plant list has no `aggression`).
- Further metrics (chosen here): `mean_energy` and `mean_age` of the living organisms per kind (state, not inherited;
  they show the food stress and the age structure that the traits alone do not show).

Empty sets: when a kind has no living organisms, `generation`, `traits` and the means are JSON `null`. A count is never
null. This keeps "no organisms" distinct from "value 0" for the charts of TASK-025.

### D3 Order and arithmetic
- Organisms are visited in ascending id (`Entities::living()`). Sums use `f64` in that order, two-pass for `sd`
  (`sqrt(sum((x - mean)^2) / n)`), so the values are a fixed function of the state on one build.
- Trait values are the decoded values (`f32` widened to `f64`), not the genome mean in `[0, 1]`.
- Non-finite results are impossible for finite traits; `to_json` still refuses non-finite numbers (as in ADR-0020 D2).

### D4 Metrics file (`--metrics FILE`)
- Option of `evosim run` only (`batch` is TASK-021). Optional; default off. The result file is not changed.
- File: one JSON object, layout as in ADR-0020 D2 (one key per line, one sample per line).
  Top level keys in order: `format` (`"evosim-metrics"`), `format_version` (`1`), `contract` (`1`), `seed`, `tick_start`,
  `tick_end`, `sample_every`, `traits` (per kind, the trait names in the order above), `samples`.
- Each sample object has the keys of D2 and `tick` first. The full format is written in `docs/METRICS.md`, which is the
  reference for readers (TASK-021, TASK-025).
- Written through a temporary file and renamed, as the result (ADR-0020 D7). Parent directories are created.
- Errors: the same exit 2 rules. `--metrics` may appear once; a value equal to `--out` is an error (exit 2).

### D5 Non-interference
- `record` takes `&Simulation`; accessors used are read-only (`living`, `living_count`, `species().living_now`, `deaths_by_cause`).
  No cache of the simulation is refreshed by them. The spatial index is not queried.
- Tests check that the state hash and the full `Simulation` equality are unchanged by sampling at every tick, and that the CLI
  result `state_hash` is equal with and without `--metrics`.

### D6 Format versioning
`format_version` is 1. A change of any key's meaning or unit bumps it. Adding a trait or a further metric is a change of the
`traits` list, which readers take from the file, so it does not bump the version.

## Consequences
- Positive: the numbers of TASK-020 are fixed in one documented format that TASK-021 (batch summary) and TASK-025 (charts) can
  read. Sampling is off the state path, so it cannot change behaviour; the default result and the `dist/` build are unchanged
  (no new dependency, std only).
- Negative: about 400 new lines in `analytics.rs` plus the tests; the trait decoding per sample costs O(living organisms × 128)
  loci reads per sample (about 1,000 operations per organism). Measured in IMPLEMENT at 2,000 and 5,000 organisms with
  `--sample-every 1` and reported there.
- Risk: the lag of `species_living` (D2) and the `null` rule (D2) must be understood by the readers; both are documented.

## IMPLEMENT notes (TASK-020 IMPLEMENT cycle 1)
- Implemented as decided. `analytics::MetricsLog` keeps every sample in memory; the file is produced by `to_json` at the end.
  `metrics.rs` JSON helpers (`Node`, `write_node`, `int`, `float`) are `pub(crate)` for reuse.
- Samples are written one per line in compact form; the header keys one per line (the `traits` object is multi-line).
- Sampling cost (debug build, `target/debug/evosim`, 120x120 world, about 2,000 plants + 340 animals, 100 ticks, `--sample-every 1`):
  2.67 s without `--metrics`, 2.97 s with it (101 samples, about 11% overhead in a debug build). Release-build numbers and the
  5,000-organism measurement are not taken yet (not done in this cycle).
- `elapsed_seconds` includes the in-loop sample recording (as the series sample already did); the first record before the timer
  starts is excluded.
- Serialisation of both files happens before any write; the metrics file is renamed before the result file.
- The black-box step in `scripts/test.sh` planned in the PLAN is not added yet (open item).

## Verification strategy
- Hand-checkable world (`analytics::tests`): width 4, height 4, no RNG draws (founders by `Simulation::add_founder` with explicit
  `Birth` genomes). Example: two plants whose slot 0 loci are all 0 and all 255 have speed 0.0 and 4.0, so `mean` 2.0, `sd` 2.0,
  `min` 0.0, `max` 4.0. A damaged organism (`Organism::damage`, `Injury`) followed by `Entities::deaths_phase` gives
  `deaths_by_cause.plants.injury` 1 and `deaths_since_last` 1. An empty herbivore set gives `null` herbivore stats and
  `population` 0.
- Interval values: two samples, `births_since_last` equals the difference of cumulative `births`.
- Generation: founders have generation 0; a child made with `Entities::spawn_child` from a generation-0 parent has 1 (the
  test checks the value that `spawn_child` actually assigns, recorded in IMPLEMENT).
- Non-interference: sampling at every tick does not change `Simulation` equality or `checkpoint::state_hash`.
- CLI (`crates/evosim-cli/tests/run_cli.rs`): `--metrics` file parses (python3 `json` is not required; `config::json::parse`
  in the test), has the keys of D4, and its `series` population matches the result `series`; `state_hash` equal with and
  without `--metrics`; `--metrics` equal to `--out` exits 2 with no file.
- Gates: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
  `bash scripts/check_adrs.sh`, `bash scripts/test.sh` after `./build.sh`, `git remote -v | wc -l` = 0.

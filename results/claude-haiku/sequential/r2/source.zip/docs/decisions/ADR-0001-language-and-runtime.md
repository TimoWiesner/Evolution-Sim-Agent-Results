# ADR-0001: Language and runtime of the simulation core

Status: Accepted (drafted in TASK-001 PLAN cycle 1, confirmed in TASK-001 IMPLEMENT cycle 1).

## Context
The simulation must reach >= 100 ticks/s with 2,000 organisms on reference hardware, be fully deterministic
for a given seed and build, run headless with no display, and be shipped as `dist/evosim` that runs on a plain
Ubuntu 24.04 x86-64 system with no language runtime installed. The benchmark container provides Rust 1.100
(`/opt/rust/cargo/bin`), Node 18, Python 3.12 and build tools. `./setup.sh` may use the network.

## Considered alternatives
1. **Rust (stable), Cargo workspace.** Compiled, no GC pauses, predictable float behaviour (no fast-math,
   no implicit FMA contraction), strong types for genome/config code, `cargo test` and `proptest` for
   property tests. Output is one native binary; `dist/` needs only the executable plus no runtime.
2. **Python 3 with NumPy.** Fastest to write, but per-organism logic in Python loops is far below 100 ticks/s
   at 2,000 organisms unless vectorised heavily, which makes the code hard to read and test. Shipping needs a
   bundled interpreter (PyInstaller-like), which is large and fragile for a "no runtime" requirement.
3. **TypeScript/Node 18.** Acceptable speed for 2,000 agents, same UI stack as the browser UI. Shipping needs a
   bundled Node binary (about 40 MB) and JIT floating-point results are deterministic on one machine but the
   engine is harder to keep allocation-free. Weaker guarantees for exact integer/float reproducibility.
4. **C++17/20.** Fast, but no package manager in the container for property tests, more undefined-behaviour
   risk, and more setup effort for a single-binary build.

## Decision
**Rust.** Three crates in one Cargo workspace (see `docs/ARCHITECTURE.md`):
- `crates/evosim-core`: library with no dependency on any UI or CLI crate.
- `crates/evosim-cli`: binary `evosim`, the only entry point of the product.
- `crates/evosim-ui`: local browser UI server (ADR-0002), depends on `evosim-core` only.

Allowed third-party crates are kept minimal: `sha2` (state hash digest), `proptest` (dev-dependency only).
The RNG (xoshiro256**, SplitMix64 seeding) and the checkpoint binary format are implemented in-house so that
they cannot change under a crate upgrade. CLI argument parsing and JSON output are hand-written or use a
minimal JSON writer, so no runtime dependency is pulled in. No JSON crate (serde, serde_json or similar) is used:
config and result JSON are read and written by hand-written modules (`core::config::json`, `core::metrics`).
Runtime crates are limited to `sha2` (used only by `core::checkpoint`).

Build profile for `dist/`: `cargo build --release` with `lto = "thin"`, `codegen-units = 1`, `panic = "abort"`,
no `target-cpu=native` (so the binary runs on any x86-64 machine). Floating-point: default `f32`/`f64`
semantics, no `-ffast-math` equivalent, no unsafe SIMD intrinsics in the core.

## Consequences
- `./setup.sh` runs `cargo fetch` and `cargo build --release`; `./build.sh` copies the release binary to
  `dist/evosim`. Network is needed only for the first fetch of crates.
- Reproducibility across machines is "minor differences allowed" by the contract; on one machine and one build
  the results are bit-identical. Transcendental functions (`sin`, `cos`, `exp`) come from the platform libm;
  climate code uses them only at world creation or through precomputed tables where practical (see ADR-0004 and
  the determinism section in `docs/ARCHITECTURE.md`).
- Compile times are longer than Python; acceptable for this project size.
- Performance: a compiled, allocation-controlled core is the only realistic option for the 100 ticks/s target at
  2,000 organisms, where the per-tick spatial index costs O(N + W*H) (ADR-0003). The number is a target, not a result,
  until the TASK-010 measurement is recorded in `docs/ARCHITECTURE.md`.

## Verification strategy
- `cargo test` in `crates/evosim-core` covers unit, property (`proptest`) and multi-thousand-tick tests.
- A benchmark command (`evosim run` on a 2,000-organism config, measured by `ticks_per_second`) is recorded in
  `docs/STATE.md` and in the result JSON.
- `dist/evosim version` and `dist/evosim run` are exercised after `./build.sh`; the dist binary is checked for
  dynamic dependencies with `ldd dist/evosim` (only glibc, libgcc_s, libm expected).
- Testability: the core is a library with no UI or CLI dependency, so its unit, property and multi-thousand-tick
  tests run with `cargo test` alone, without a display or browser.

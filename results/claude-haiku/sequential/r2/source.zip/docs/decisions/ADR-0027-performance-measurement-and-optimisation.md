# ADR-0027: Performance measurement, profiling and optimisation

Status: Proposed (drafted in TASK-026 PLAN cycle 1; set to Accepted at TASK-026 REVIEW PASS).

## Context
TASK-026 (`tasks/TASK-026/task.md`) asks for: one documented command that measures ticks per second (ticks/s) in a
reproducible setup with about 2,000 organisms alive, a fixed seed, a warm-up and a stated number of measured ticks;
`docs/PERFORMANCE.md` with hardware, command and numbers before and after; a profile that names the most expensive
parts; the target of at least 100 ticks/s at about 2,000 organisms; behaviour unchanged (all tests, determinism,
checkpoints); and a test that guards against large slowdowns with a loose threshold.

Facts measured in PLAN (release build, `target/release/evosim run`, this container, 12 logical CPUs, AMD Ryzen 5 7500F,
32 GB RAM, rustc 1.100.0):
- The population does not stay at 2,000 under the current ecology, with any tried setting. Mixed starts (1,600 plants,
  280 herbivores, 120 carnivores on 64x48) lose all herbivores within about 50 ticks. A 128x96 world with 300 herbivores
  and 60 carnivores still has 2,110 living at tick 150 (plants 1,973, herbivores 118, carnivores 19), and a plant-only
  start of 2,000 falls to about 1,100 to 1,650 by ticks 150 to 600 (plant growth and reproduction raised, animals absent).
  The plant equilibrium is about 900 to 1,150 in the default parameters for 64x48 to 256x192 worlds, so the plant
  count is limited by the ecology, not the world size. Making the ecology hold 2,000 organisms is TASK-027's job, and
  the performance task may not change behaviour.
- Throughput (single probes, one run each): plant-only 2,000 organisms at 128x96: 1,699 ticks/s over 1,000 ticks;
  mixed 2,000 organisms (300 herbivores, 60 carnivores) at 128x96: 1,272 ticks/s over 1,000 ticks (population falls
  to 611); with the boosted plant parameters of the probe, 830 ticks/s over 600 ticks. The TASK-024 UI probe measured
  0.79 ms per tick at 511 organisms. So the 100 ticks/s target is probably met already, but this is not yet measured
  with a fixed benchmark.
- `state_hash` of a fixed configuration is equal between two runs (determinism holds), so it can serve as the
  behaviour-unchanged check across optimisations.
- No profiler is installed (`perf`, `valgrind` absent). Per-phase wall-clock timers are the available profile.

## Considered alternatives
1. **Benchmark with a population kept at 2,000 by an artificial re-seeding inside the engine.** Rejected: the product
   forbids creating organisms other than from the initial population or reproduction (`docs/PROJECT.md`), and the
   benchmark must measure the product as it is.
2. **Benchmark by restarting from the same initial state (a checkpoint of the fixed configuration) for each timed
   window, so every measured tick starts from about 2,000 living organisms.** Chosen for the timed windows, see D1.
   It uses only the public product rules and the existing checkpoint format.
3. **Measure a long run (10,000 ticks) and report the mean ticks/s.** Rejected as the primary number: most of the
   long run has 1,000 or fewer organisms, which does not match "about 2,000". It is still recorded as a secondary
   number (D1).
4. **External profiler (`perf`, `valgrind`, `cargo flamegraph`).** Not installed; the install is not guaranteed to
   work on this kernel. Used as an optional extra in IMPLEMENT if it installs; the primary profile is in-process.
5. **Parallel tick (threads over phases).** Rejected for this task: ADR-0008 and the determinism rules make the
   core single-threaded, and the target does not need it. Recorded as a later option only.

## Decision
D1. **Benchmark command and setup.** A fixed configuration `examples/perf-2000.json` (fixed seed, world and initial
populations chosen in IMPLEMENT from the probes above so that all measured ticks start with at least 2,000 living
organisms; the exact values are written into the file and into `docs/PERFORMANCE.md`). The documented command is
`scripts/perf.sh` (it runs `cargo run --release --locked --offline -p evosim-core --example perf_tps -- ...` with the
fixed arguments). The measurement: warm-up of 2 untimed repetitions of the window; then 5 timed repetitions of a
window of N ticks (N fixed in IMPLEMENT, about 50 to 100, chosen so that living >= 2,000 holds on every measured
tick; each repetition is a fresh `Simulation::new` from the same configuration, built outside the timer). Reported:
median, minimum and maximum ticks/s, the living count per tick, the `state_hash` of the window, and the hardware line.
A secondary number is the ticks/s of a 1,000-tick run of the same configuration (population falls; reported, not a
target).

D2. **Profile.** New module `crates/evosim-core/src/perf.rs` (pure timing helpers, no state effect) and a method
`Simulation::tick_profiled(&mut PhaseTimes)` in `sim.rs` that runs the same nine phases in the same order as `tick()`
and adds the wall-clock time of each phase to `PhaseTimes`. Counters per phase: number of `within`/`neighbours`
queries, candidates returned, and stale-overlay entries scanned (G-046). The report names the phases and the
functions that dominate each phase. Output of the profile is recorded in `docs/PERFORMANCE.md`.

D3. **Optimisation rules.** Only changes that keep every `state_hash` of the fixed configurations and the test
seeds identical (or are re-recorded with a stated reason, see D5). Candidate changes, to be confirmed or rejected by
the profile in IMPLEMENT: (a) the stale overlay in `spatial.rs` (G-046): remove the cost of scanning moved organisms
during a phase, or compact the index before the behaviour phases; (b) allocation in `within`/`neighbours` (reuse
output buffers); (c) per-plant climate queries (ADR-0012): compute the climate per cell once per tick; (d) genome
decoding per plant per tick (ADR-0012): cache the decoded traits when the genome changes only at birth; (e) the
species check (ADR-0018) is already every 25 ticks, measure before touching it. Iteration order and floating-point
operation order are not changed (ARCHITECTURE determinism rules 2 and 5).

D4. **Guard test.** A test in `perf.rs` (runs in `cargo test --workspace`) runs the fixed configuration for a short
window and asserts that ticks/s is above a floor set at about one quarter of the measured release value, with
separate floors for debug and release builds (`cfg!(debug_assertions)`). The floor and the measured value are written
into `docs/PERFORMANCE.md`. The test prints the measured value; it must finish in a few seconds.

D5. **Regression values.** `state_hash` values of existing tests must stay the same. If an optimisation changes a
recorded value, it is re-recorded only with a stated reason in `docs/STATE.md`, and the change is then
behaviour-changing and needs its own justification. Target: no such re-recording.

D6. **Target.** Target: at least 100 ticks/s at about 2,000 organisms (median of D1). If it is missed, the report gives
the measured value, the trials and the remaining bottleneck. The result is not forced by changing the benchmark
configuration after measuring.

## Consequences
- Performance: the measurement is a headless, reproducible number on one machine (the benchmark container). Timers
  add a few `Instant::now()` calls per phase only in `tick_profiled`; `tick()` stays unchanged, so the default path has no
  extra cost. Optimisations must keep the per-tick work O(organisms) plus spatial queries (ADR-0003, ADR-0019).
- Testability: the guard test and the state-hash comparisons are plain Rust tests; the benchmark is a script plus an
  example, so it needs no network and no display. Floors are loose (about 4x below the measurement) so that slower
  machines and noisy shared hosts pass.
- The population curve of the fixed configuration falls within about 100 ticks. The benchmark therefore covers the
  early window with about 2,000 organisms, and the secondary 1,000-tick number covers the lower population. TASK-027
  changes the ecology; the benchmark must be run again there.
- The `dist/` folder is unaffected: the example and script are not part of `dist/evosim`, which keeps working without
  extra files.

## Verification strategy
- `scripts/perf.sh` run twice on the same machine: median within 10 % (recorded in `docs/PERFORMANCE.md`).
- `state_hash` before and after each optimisation for the fixed configuration and at least three other seeds over 1,000
  ticks: equal (recorded command output).
- `cargo test --workspace --locked --offline` exit 0, including the determinism and checkpoint tests and the guard test.
- `bash scripts/check_adrs.sh` exit 0 (this ADR is in its list).
- Testability: the guard test fails if the floor is set above the measured value (checked once by hand in IMPLEMENT and
  recorded).

## IMPLEMENT cycle 1 (choices made from the measurements)
- D1 fixed values: `examples/perf-2000.json` (seed 42, 128 x 96, 2,000 plants, 300 herbivores, 60 carnivores). Window N = 60
  ticks: living count stays at or above 2,164 over ticks 0 to 60 (it falls to 2,003 by tick 100). 2 warm-up and 5 timed
  repetitions. `scripts/perf.sh` also runs a 1,000-tick secondary run (no living floor).
- D2: `PhaseTimes` and `benchmark`/`profile` live in `core::perf`; `Simulation::tick_profiled` is added, `tick()` is
  unchanged. Spatial query counters were not added (no hot-path change in this task).
- D3: no optimisation was applied. The target is met with a margin of about 5.8x (577.8 ticks/s median), so each
  candidate would be a change without a need. Candidates and the profile are in `docs/PERFORMANCE.md`.
- D4: floors set to 140 ticks/s (release) and 6 ticks/s (debug); measured 578 and 26.3. The guard fails with a floor of
  1,000,000 (checked by hand).
- D5: no state-hash value was re-recorded. The benchmark configuration's hash is identical before and after the change.
- D6: target met (see `docs/PERFORMANCE.md`).
- Status is still Proposed; REVIEW sets Accepted.

## PLAN cycle 2 (closes REVIEW cycle 1 gaps G-1, G-2, G-3)
Status stays Proposed. Decided in PLAN, implemented in IMPLEMENT cycle 2.

- **G-1, benchmark configuration and window (supersedes the IMPLEMENT cycle 1 D1 values).** The shipped configuration
  (2,000 / 300 / 60) falls to 2,003 at tick 100, so a 60-tick window does not keep 2,000 organisms alive over its whole
  span. Probes (release `evosim run`, seed 42, 128 x 96, living count on every tick, deterministic):

  | Founders plants / herb / carn (128 x 96) | tick 0 | min ticks 0-60 | min ticks 0-100 | min ticks 0-150 | mean ticks 0-100 |
  |---|---|---|---|---|---|
  | 2,000 / 300 / 60 (old) | 2,360 | 2,164 | 2,003 | 1,601 | 2,293 |
  | 2,100 / 280 / 60 | 2,440 | 2,232 | 2,101 | 1,676 | 2,360 |
  | 2,200 / 250 / 50 | 2,500 | 2,293 | **2,173** | 1,770 | 2,432 |
  | 2,300 / 300 / 60 | 2,660 | 2,457 | 2,295 | 1,863 | 2,604 |
  | 2,600 / 300 / 60 | 2,960 | 2,756 | 2,598 | 2,096 | 2,923 |

  **Chosen: 2,200 plants, 250 herbivores, 50 carnivores, 128 x 96, seed 42** (`examples/perf-2000.json`). Its living
  count stays at or above 2,173 on every tick from 0 to 100, which is the whole measured window of 100 ticks, and its
  mean is 2,432, the closest to "about 2,000" of the configurations that hold 2,000 for 100 ticks. The margin of 173 is
  deterministic for this seed; `perf_tps` exits 1 if a measured tick is below the 2,000 floor. Rejected: the 2,600 row
  (holds longer but measures a mean load of about 2,900), and the 150-tick windows (no probed configuration
  holds 2,000 for 150 ticks). The window is 100 measured ticks, 2 warm-up repetitions, 5 timed repetitions, each from
  a fresh simulation. The secondary 1,000-tick run is unchanged.
  Not a benchmark trick: no organisms are added and no count-based rule is used (docs/PROJECT.md). The configuration
  uses only the fixed keys of docs/CONTRACT.md section 3.

- **G-2, optimisation (the "make it faster" goal).** IMPLEMENT must apply and measure at least two optimisations, each
  kept only if the state hash is unchanged. In order of the profile share:
  - O1, plant climate cache (Plants, 28 %): `ecology::plants_phase` computes `climate.conditions(cell)` once per plant.
    `conditions` depends on the cell and the climate state, and `plants_phase` takes `&Climate`, so the values are
    constant during the phase. Cache one `Conditions` per cell (computed on first use, in ascending cell order or as a
    per-tick table), with the same float operations. Expected: a reduction of the Plants share.
  - O2, spatial query stale check (Herbivores, Carnivores, 55 % together): `SpatialIndex::within_into` checks
    `self.stale.contains` (a `BTreeSet`, O(log n)) for every bucket entry, and then scans the whole stale set. Replace
    the membership test with an O(1) per-organism flag (or a `HashSet` used for membership only, never iterated, since
    results are sorted). Results must stay identical: the randomised brute-force tests in `spatial.rs` must still pass.
  - O3, buffer reuse (if the G-3 counts show allocation matters): `movement::perceive`, `feeding::feed` and
    `hunting::attack` call `spatial.within` (allocating); use `within_into` with a scratch `Vec` owned by the phase.
  - Not in IMPLEMENT scope: Species re-classification (11 %, ADR-0018). It is a single-linkage pass over all genomes; any
    change needs a separate justification. Recorded as the next candidate.
- **G-3, query counts.** Measured with a temporary, uncommitted counter patch (counts per phase of `within`/`within_into`
  calls, candidates returned, stale entries scanned, plant climate queries). The numbers go into `docs/PERFORMANCE.md`,
  and the patch is reverted before the IMPLEMENT commit so the product code carries no counters. Permitted alternative:
  state in PERFORMANCE.md that the phase-level profile is the accepted level.

- **Gate for every optimisation.** The baseline hashes of the new benchmark configuration are recorded from the
  unchanged build before any change: `evosim run --config examples/perf-2000.json --ticks 1000 --seed S` for S = 42, 1,
  2, 3. After each change the same four hashes must be identical. `cargo test --workspace --locked --offline` must pass,
  unchanged, including the determinism and checkpoint tests and the guard.
- **Target and guard.** Target stays 100 ticks/s at about 2,000 organisms (D6). The guard floors (140 release, 6 debug)
  are re-measured for the new configuration; the release floor stays about a quarter of the median. A new test
  `perf::tests::fixed_benchmark_living_holds_for_the_window` runs the benchmark configuration for 100 ticks and asserts
  living >= 2,000 on every tick, so criterion 1 is a test and not only a script check.

## IMPLEMENT cycle 2 (applies PLAN cycle 2; status stays Proposed)

Choices made in this phase, from the measurements in `docs/PERFORMANCE.md` ("IMPLEMENT cycle 2"):

- **Configuration (G-1).** `examples/perf-2000.json` = seed 42, 128 x 96, 2,200 plants, 250 herbivores, 50 carnivores,
  as planned. Measured living count: at least 2,173 on every tick of the 100 measured ticks, so the window keeps about
  2,000 alive (the criterion) and the benchmark asserts 2,000 on each tick (`perf::tests::fixed_benchmark_living_holds_for_the_window`).
  Window: 2 warm-up and 5 timed repetitions of 100 ticks (`scripts/perf.sh`).
- **O1 (plant climate cache), applied.** Per-cell cache of `Conditions` in `ecology::plants_phase`, also used by the
  regeneration loop of the same phase. Hash gate passed. Effect on the Plants phase is small (about 5 %): the regeneration
  loop still queries every cell each tick.
- **O2 (stale overlay), applied with a deviation.** PLAN cycle 2 proposed an O(1) membership test in place of
  `BTreeSet::contains`. The counts (G-3) showed that the stale scan itself is the larger cost (2.14 million stale entries
  against 184 thousand bucket checks per 100 ticks, each with a `BTreeMap` lookup). The stale set is therefore a
  `HashMap<OrganismId, Option<Placed>>` that stores the current placement, so the scan needs no lookup. The
  answers are still sorted before return, so the hash order does not reach a result. Hash gate passed.
- **O3 (scratch buffers), not applied.** 264 queries per tick: allocation is not measurable here.
- **Gate.** O1 and O2 were checked together (one state-hash set and one workspace test run), not separately. Hashes
  identical for seeds 42, 1, 2, 3 at 150 and 1,000 ticks and for the 120-tick 2,000/300/60 probe.
- **Result.** Median 867 to 1,081 ticks/s (about 1.25x) at about 2,200 founders; target 100 ticks/s met.
- **Guard floors.** Kept at 140 ticks/s (release) and 6 ticks/s (debug). The release median now is about 1,050 ticks/s.
- **Next candidates (not implemented).** The Plants phase (about half of the tick): per-cell capacity caching across the
  regeneration loop and decoding `PlantTraits` once per organism. The Species phase (about 20 %): ADR-0018 re-classification.
- **Status.** Proposed. The REVIEW phase decides whether the ADR is accepted.


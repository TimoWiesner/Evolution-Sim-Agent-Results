# ADR-0014: Animal perception, movement, movement energy and cell sharing

Status: Accepted (drafted in TASK-013 PLAN cycle 1; accepted at TASK-013 REVIEW cycle 1 PASS).

## Context
TASK-013 lets herbivores and carnivores perceive their surroundings and move cell to cell. It must fix four things that later
tasks (feeding TASK-014, hunting TASK-015, mating TASK-016) build on: the vision range (which trait gives it and how it is
decoded), the step rule (how far an animal moves per tick and how it picks a direction when nothing is in sight, and how it
takes the shortest way to a target across an edge), the energy cost of moving, and the rule for whether organisms may share a
cell. Behaviour on reaching food, prey or a mate is out of scope. Plants do not move. The spatial index (ADR-0003 with its TASK-010
amendment) already answers `within(centre, r, filter)` across the torus, and ADR-0003 says behaviour phases defer moves to the end
of the phase; ADR-0007 gives `Torus::delta`, `distance` and `neighbours`; ADR-0011 gives `Organism::set_cell` and the living-only
rule; ADR-0004 leaves genome slot 7 unused for animals. The constraints are: deterministic (one RNG, ascending id order, no hash
maps), no forced anti-extinction (no rule may look at population counts), movement and perception are per organism and local.

## Considered alternatives
1. **Vision from a new `vision` field in `Traits` (rejected).** Clean for readers, but `Traits::new` and every call site (plus the
   checkpoint layout) would change. Genome decoding already defines every trait; a function of the genome avoids a second source of
   truth.
2. **Vision decoded from genome slot 7 for animals, derived at use time (chosen).** Slot 7 is free for animals (ADR-0004 amendment),
   and slots 5 and 6 already change meaning by kind, so the precedent exists. The value is a pure function of the genome, so nothing
   new is stored and the checkpoint layout is unchanged.
3. **Fractional speed accumulated per organism (rejected for now).** An animal with speed 0.5 would move every second tick. That needs
   a stored carry per organism, which is new state for the checkpoint and the state hash. Speed below 1 gives no movement in this
   version (see Decision); evolution can still raise speed above 1.
4. **Random walk with persistent heading (rejected for now).** More realistic dispersal, but needs a stored heading per organism.
   The stateless walk below draws one direction per step and needs no new state.
5. **Cell capacity for animals (rejected for now).** A per-cell cap on animals would be a crowding rule that looks at the cell's
   occupants. It is allowed by PROJECT.md (a local mechanism), but it needs a tuned value and interacts with feeding and mating. It
   is left to TASK-014 and TASK-018, where crowding can be measured. Sharing is the default now.

## Decision

### Vision range (animals)
- `entities::vision_radius(genome: &Genome) -> u32`, pure. Only animals (ploidy 2) use it; plants never perceive.
- Mean `m` of genome slot 7 (`Genome::trait_means()[7]`, in `[0, 1]`):
  `vision = min(VISION_MAX, VISION_MIN + floor((VISION_MAX - VISION_MIN + 1) * m))` with `VISION_MIN = 1`, `VISION_MAX = 5` cells.
  Range 1 to 5 cells, integer. Not stored in `Organism`; the genome is the source of truth (ADR-0004).
- Perception: `perceive(spatial, id, cell, vision) = spatial.within(cell, vision, None)` minus the organism's own id. Returns ids ascending,
  no duplicates, across the torus seams (ADR-0003, ADR-0007). Filtering by kind is done by the caller (TASK-014 onwards).

### Movement per tick (the speed trait)
- Steps this tick: `steps = floor(speed)` (speed in `[0, 4]`, so 0 to 4 cells). Each step moves one cell, to any of the 8 neighbours,
  so the distance per tick is at most `speed`. An animal with speed below 1 does not move; no carry is stored (alternative 3).
- Plants never move (no speed use). Only the Herbivores and Carnivores phases move organisms.

### Heading: target or wander
- `enum Heading { Wander, Towards(Cell) }` in `core::movement`.
- `Towards(target)`: `movement::step_towards(torus, from, target, steps) -> Cell`. The offset is `torus.delta(from, target)` (the
  shortest wrapped displacement on each axis, ADR-0007), so the path crosses an edge when that is shorter. Each step moves
  diagonally when both axes still differ (`sign(dx), sign(dy)`) and stops at the target. Number of steps taken = `min(steps,
  torus.distance(from, target))`, which is the shortest 8-neighbour path length (Chebyshev).
- `Wander` (nothing interesting in sight, no target): each step draws one direction from the simulation generator with
  `rng.next_below(8)` indexed into `Direction::ALL`. No draw is made when `steps = 0`. Memoryless, so no state is stored.
- TASK-013 does not choose targets: the phase uses `Wander` for every animal, and `choose_heading` is a single function that
  returns `Wander` until TASK-014 to TASK-016 decide what is interesting (the target choice is "what animals do", out of scope).
  `Towards` is exercised by unit tests.

### Movement energy cost
- `move_cost(distance, speed) = MOVE_COST_CELL * distance * (1 + MOVE_COST_SPEED * speed)` with `MOVE_COST_CELL = 0.2` energy per
  cell and `MOVE_COST_SPEED = 0.25`. `distance` = steps taken this tick (for `Towards`, `min(steps, torus.distance)`; for `Wander`, every step counts even when the net
  displacement is smaller); `speed` = the trait.
- Zero when `distance = 0`; strictly increasing in `distance` for a fixed speed and in `speed` for a fixed distance above 0, so
  moving further or faster costs more. Charged once per organism per tick with `drain_energy` (reaching 0 gives `Starvation`).
- Constants are uncalibrated (TASK-018). No base metabolism is added here; that is part of feeding (TASK-014).

### Cell sharing (the one documented rule)
- **Any number of organisms of any kind may share a cell.** No movement is refused because of occupancy; the spatial index stores
  every organism with its own entry in its cell bucket.
- Crowding acts only through the local mechanisms that exist or will exist: per-cell plant resources (ADR-0012), plant seeding
  room (ADR-0013, `CELL_PLANT_CAP`, which refuses a plant birth, not a move), and the feeding and competition rules of TASK-014 to
  TASK-016. No rule counts organisms of a kind or a species.
- The plant birth cap of ADR-0013 is the only occupancy limit in the code. It limits births, not moves, and is kept unchanged.

### Phase rule: deferred moves
- The Herbivores phase (and then Carnivores) runs in three steps: (1) in ascending id order, for each living animal of the kind,
  compute its perception-based heading and its destination cell and step count, reading the index and positions as they were at the
  start of the phase; (2) in ascending id order, apply each move through one `Simulation`-level helper
  `move_organism(id, cell)` that calls `Entities::get_mut(id).set_cell` and `SpatialIndex::move_to` together (closes G-047) and then
  charges the movement cost; (3) nothing else changes in the phase. Decisions never see a move made in the same phase.
- Organisms with a cause set (dead, not removed) are skipped: iterate `living()` (G-040).
- Herbivores move before carnivores (fixed by ADR-0008 order), so carnivores see the herbivores' new cells in their own phase.

### Edges and state
- All cells come from `Torus` (`step`, `translate`, `cell`), so `set_cell` is only ever given a valid cell (G-041).
- No new state: vision is derived from the genome, no heading or carry is stored, and the only RNG use is the wander draw.
  The checkpoint (TASK-022) layout is unchanged by this ADR.

## Consequences
- **Performance**: perception is one `within` query per animal per tick (cost as measured in ARCHITECTURE for TASK-010, plus the
  stale overlay, G-046). Movement is O(steps) per animal. Expect a small cost per tick at 2,000 animals; measured in later tasks,
  not here.
- **Testability**: `movement` depends only on `world`, `spatial`, `entities`, `genome`, `rng`, so its rules run in `cargo test`
  without a UI or a checkpoint. Edge crossings are testable with exact cells.
- **Determinism**: integer steps, ascending id order, one RNG stream; the wander draws are part of the state hash through the RNG.
- **dist/**: plain Rust in the core; no crate, no file.
- **Ecology**: animals now lose energy by moving and have no food yet (TASK-014). A population with no feeding will starve; this
  is expected for TASK-013 and is recorded as a risk, not patched.
- **Trade-off**: speed below 1 gives no movement; wandering is memoryless (diffusive). Both are documented limits, to be revisited
  if TASK-018 shows they distort the food chain.

## Verification strategy
- Unit: `vision_radius` boundaries (mean 0 gives 1, mean 1 gives 5, never outside `[1, 5]`) and a seeded sweep over genomes.
- Perception: `perceive` returns ids ascending and without self; seam tests at each of the four edges and each corner (organism at
  x=0 sees one at x=W-1 when vision >= 1); 1 x N and N x 1 worlds; radius larger than the world returns each organism once.
- Movement: `steps = floor(speed)` exact for speeds 0, 0.99, 1, 3.5, 4; each tick moves `<= speed`; the index stays in sync
  (`check_spatial` after every phase); a `Wander` step always lands on a torus cell.
- Shortest path: `step_towards` from `x=0` to `x=W-1` takes one step west across the seam; diagonal steps when both axes differ;
  stops at target; the number of steps equals `torus.distance`; the even-size tie (`+L/2`) is deterministic.
- Energy: `move_cost(0, s) = 0`; strictly increasing in distance (1, 2, 3 cells) and in speed; a drain to 0 gives `Starvation`.
- Cell sharing: two animals moved onto one cell are both indexed there; `within` returns both; no move is refused for occupancy.
- Deferred moves: the result of a phase does not depend on the order of processing (a seeded test that reverses the id order of
  the decision loop gives the same decisions).
- Determinism: same seed gives identical positions after N ticks; different seeds differ.
- Commands recorded in the implement phase: `cargo test -p evosim-core --locked`, `cargo test --workspace --locked`,
  `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`, `bash scripts/check_adrs.sh`, `bash scripts/test.sh`.

## Review notes (TASK-013 REVIEW cycle 1)
- Verdict PASS. Independent re-run in REVIEW: `cargo test -p evosim-core --locked` 0 (273 passed, 1 ignored); `cargo clippy
  -p evosim-core -p evosim-cli --locked --all-targets` 0 with 0 warnings; `bash scripts/check_adrs.sh` 0 (checks=131 failed=0);
  `bash scripts/test.sh` 0 ("ALL TESTS PASSED"); rustfmt `--check` on movement.rs, sim.rs, entities.rs 0.
- Cell-sharing reading (PLAN risk R4) judged acceptable: moves and animal occupancy have no occupancy refusal anywhere. The one
  exception in the code is the ADR-0013 plant birth cap (`CELL_PLANT_CAP`), which refuses a plant birth in a full cell. It is a
  birth rule required by TASK-012, not a move rule, and it is the only occupancy limit. A stricter reader could call this a second
  sharing rule; if so, the fix is wording (state the birth cap as the only local room limit for births), not code.
- Perception is computed every tick in `plan_moves` (one `perceive` per animal), but its result only reaches `choose_heading`,
  which returns `Wander`. Perception is therefore verified through `perceive` tests, not through observed behaviour (TASK-014 onwards).
- The "reversed input order" plan test listed under Verification strategy was not written (noted as deviation in IMPLEMENT). The
  start-of-phase guarantee is structural: `plan_moves` takes shared references and only returns a plan.
- Calibration constants (`MOVE_COST_CELL`, `MOVE_COST_SPEED`, vision mapping) remain uncalibrated (TASK-018).

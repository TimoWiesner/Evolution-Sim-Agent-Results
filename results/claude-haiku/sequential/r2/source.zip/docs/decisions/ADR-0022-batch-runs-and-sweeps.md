# ADR-0022: Batch runs, parameter sweeps, summary format and CSV export

Status: Accepted (drafted in TASK-021 PLAN cycle 1, implemented in IMPLEMENT cycle 1; accepted at TASK-021 REVIEW cycle 1 PASS, see `tasks/TASK-021/handoffs/review-cycle1.json`).

## Context
`docs/CONTRACT.md` section 2 fixes `evosim batch --config FILE --seeds 1,2,3 --ticks N --out-dir DIR`: it runs the configuration
once per seed, writes `DIR/seed-<seed>.json` (same schema as `run`) and `DIR/summary.json` (format our own), and says that further
sweep options are our design. `tasks/TASK-021/task.md` adds: at least one parameter must be varied over several values (a test runs
a 2 values x 2 seeds matrix); `summary.json` lists every run with seed, parameters and ticks, and gives per-kind mean, minimum and
maximum of the final population and how often each kind went extinct; the summary can be exported as CSV; the same batch twice gives
the same summary apart from time measurements. Charts are out of scope (TASK-025).

What exists: `evosim run` (ADR-0020) and `--metrics` (ADR-0021) are implemented in `crates/evosim-cli/src/main.rs` (`run_run`), which
holds the whole run loop (populate founders, tick loop, sampling, `state_hash`, result model) in the CLI. `Config` (ADR-0006) is
validated, has `to_json` (`from_json(to_json(c)) == c`), rejects unknown keys by name, and `config::json` offers an ordered
`Value::Object` tree with `parse` and `write`. `metrics::RunResult::to_json` writes the per-seed result. `ARCHITECTURE.md` already
names a planned `core::batch` module ("runs many seeds, writes summary statistics").

Constraints: `docs/PROJECT.md` (no rule may read population counts; batch is output only), ADR-0008/ADR-0011 (determinism, one RNG
stream per simulation), ADR-0020 D7 (atomic file writes, exit 2 on errors, no result file on failure), CONTRACT section 5.5
(stdout only for documented output), std only (no new crate, ADR-0001).

## Considered alternatives
1. **Batch as a shell loop around `evosim run` (rejected).** Needs no code, but the benchmark calls `./evosim batch`, the sweep
   logic and the aggregates would live in scripts, and the summary could not be checked by the Rust tests. A loop also cannot
   refuse an invalid sweep before the first run starts.
2. **Sweep by named presets or by a fixed list of parameter names in the CLI (rejected).** Each new parameter would need a flag
   and a parser. A generic dotted-key path into the validated configuration covers every key of ADR-0006 with one rule.
3. **Sweep by a separate sweep file (TOML/JSON with a grid) (rejected for now).** Good for many parameters, but a second input
   format to document and test. The command line form covers the TASK-021 matrix and the benchmark's needs; a file can be added
   later as a front end that expands to the same case list.
4. **Generic `--vary KEY=V1,V2` with a cartesian product, shared runner, deterministic layout (chosen).** Described below.

## Decision

### D1 Command and options
```
evosim batch --config FILE --seeds S1,S2,... --ticks N --out-dir DIR
             [--vary KEY=V1,V2,...]... [--sample-every K] [--jobs J] [--csv]
```
- `--config`, `--seeds`, `--ticks`, `--out-dir` are required. `--seeds` is a non-empty comma-separated list of `u64`; duplicates
  are exit 2. `--ticks N >= 0`. `--sample-every K >= 1`, default `max(1, N/100)` as in `run`.
- `--vary KEY=V1,V2,...` may be repeated. `KEY` is a dotted path of a configuration key (for example `initial.plants`,
  `herbivores.reproduction_energy`, `plants.max_age`). `seed` cannot be varied (use `--seeds`). A key given twice is exit 2.
  Each value is a JSON scalar: an integer, a real number or `true`/`false`; anything else is exit 2. The path and each value are
  checked by building the configuration: an unknown key or an out-of-range value is exit 2 with the key named (ADR-0006 messages),
  and this happens before any run starts.
- `--jobs J` (default 1, `J >= 1`): number of runs executed at the same time (D5).
- `--csv`: also write the CSV files of D6.
- Options may appear once each, except `--vary`; unknown options, missing values and bad integers are exit 2 (as in `run`).
- Nothing is printed to stdout. Progress, if any, goes to stderr.

### D2 Cases and runs
- A **case** is one combination of the `--vary` values (cartesian product; the first `--vary` varies slowest). Without `--vary`
  there is exactly one case with no parameters. Cases are numbered `case-00`, `case-01`, ... in that order (the number of digits
  is the width of the largest index).
- A **run** is one (case, seed) pair. Runs are listed case-major, seeds in the order given on the command line. The run list is
  fixed before anything starts.
- A run's configuration is the base configuration with the case values set (through the JSON tree of `config::json`, then
  validated again with `Config::from_json`) and `seed` set to the run's seed. The run then uses the same code path as `evosim run`
  (D4).

### D3 Files and summary format
Layout (paths relative to `DIR`):
- No `--vary`: `seed-<seed>.json` for each seed (CONTRACT section 2 exactly).
- With `--vary`: `<case>/seed-<seed>.json` (for example `case-01/seed-7.json`).
- `seed-<seed>.json` is the `run` result of ADR-0020 (same keys, same key order, `elapsed_seconds` and `ticks_per_second` present).
- `summary.json` is written last, through a temporary file and a rename. A failed batch therefore leaves no `summary.json`.
  `DIR` is created if it does not exist. Existing files of the same names are replaced; other files are not touched.

`summary.json` (format `"evosim-batch-summary"`, `format_version` 1) has these keys in this order, one key per line:
- `format`, `format_version`, `contract` (1), `tick_start` (0), `ticks` (N), `sample_every` (K), `seeds` (array, as given),
  `base` (the base configuration as the object of `Config::to_json`), `vary` (array of `{"key": ..., "values": [...]}`, values as
  written by the JSON writer), `cases` (array of `{"case": "case-00", "params": {"initial.plants": 200}}`).
- `runs`: one object per run, in run order: `case`, `seed`, `params` (object, the case values), `file` (relative path),
  `tick_start`, `tick_end`, `initial` `{plants, herbivores, carnivores}`, `final` `{plants, herbivores, carnivores}`,
  `species` `{plants, herbivores, carnivores}` (living species at `tick_end`), `extinct` `{plants, herbivores, carnivores}`
  (booleans), `state_hash`.
- `aggregates`: one object per case, in case order: `case`, `params`, `runs` (number of seeds), `kinds`: for each kind
  `final_mean`, `final_min`, `final_max`, `final_sd` (population standard deviation, divisor `n`), `extinct_runs` (count),
  `extinct_fraction` (`extinct_runs / runs`). Floats are written with the result writer's float format (ADR-0020 D2).
- `overall`: the same `kinds` object over all runs of all cases (it is meaningful when there is no `--vary`; with `--vary` it
  mixes the cases and is labelled as such by the key name only, the reader must use `aggregates` for comparisons).

Rules:
- **Extinct** means the kind has zero living individuals at `tick_end`. Without replenishment (CONTRACT section 5.3) a kind that
  reached zero stays at zero, so this is the same as "went extinct at some tick". A kind with zero initial individuals is extinct
  at the end and is counted (its `initial` is in the run object).
- Aggregates are computed in run order from integers (sums as `u64`, the mean and sd as `f64` in that order), so they are a fixed
  function of the run values.
- The summary contains **no wall-clock value**. The only time values are in the per-seed files (`elapsed_seconds`,
  `ticks_per_second`). Two batches with the same arguments therefore give byte-identical `summary.json`, and the per-seed files
  are equal after the two lines with time values are removed (the test of TASK-021 and `scripts/test.sh` use this rule).
- `summary.json` lists paths relative to `DIR` and no absolute path, so it does not depend on where the batch ran.

### D4 Shared run path
- A new core module `core::runner` (`crates/evosim-core/src/runner.rs`, depends on `sim`, `metrics`, `analytics`, `checkpoint`):
  `run(config: &Config, ticks, sample_every, with_metrics: bool) -> Result<RunOutput, String>`. It holds the loop that is in
  `run_run` today (populate founders, tick loop, `metrics::sample` at `series_ticks`, optional `MetricsLog::record`,
  `state_hash`, `elapsed_seconds` around the loop only). `RunOutput` holds `RunResult` and `Option<MetricsLog>`.
- `evosim run` and `evosim batch` both call it, so a batch run with seed S gives the same `state_hash`, `final`, `totals` and
  `series` as `evosim run` with `--seed S` on the same configuration. This is a test (D7).
- `run_run` keeps its behaviour and error messages; only the loop moves. The core still does not touch the filesystem; the
  CLI writes.

### D5 Parallel runs and reproducibility
- With `--jobs J > 1` the runs are executed by `std::thread::scope` workers that take the next run index from an `AtomicUsize`.
  Each run owns its `Simulation`, its generator (seeded from its own seed) and its configuration; no state is shared. Results are
  stored in a vector indexed by run index and are written in run order. Therefore the summary and the per-seed files do not depend
  on `J` or on thread timing (only `elapsed_seconds` changes).
- If `Simulation` is not `Send` (not expected: the core is plain owned data, to be checked in IMPLEMENT), `--jobs` is refused
  with exit 2 and only `J = 1` is supported.
- Default `J = 1` so that the timing of a run is not disturbed by other runs of the same batch.

### D6 CSV export (`--csv`)
Two files in `DIR`. Both are built in memory with the summary and written before `summary.json`, so a failed CSV write leaves no summary:
- `runs.csv`: header `case,seed,<one column per --vary key>,tick_start,tick_end,initial_plants,...` - exactly: `case`, `seed`, the
  `--vary` keys in the order given, `tick_start`, `tick_end`, `initial_plants`, `initial_herbivores`, `initial_carnivores`,
  `final_plants`, `final_herbivores`, `final_carnivores`, `species_plants`, `species_herbivores`, `species_carnivores`,
  `extinct_plants`, `extinct_herbivores`, `extinct_carnivores` (0/1), `state_hash`. One row per run, run order.
- `aggregates.csv`: header `case,kind,runs,final_mean,final_min,final_max,final_sd,extinct_runs,extinct_fraction`, one row per
  case and kind (case order, then plants, herbivores, carnivores). The `--vary` values are the `params` of `summary.json` and are
  not repeated here; `case` joins them to `runs.csv`.
- CSV text: `,` separator, `\n` line ends, no quoting (keys and values contain no commas or quotes; the keys of ADR-0006 are plain
  ASCII and the values are numbers or booleans). Floats use the same float format as JSON.

### D7 Errors and exit status
- Invalid arguments, an invalid configuration or an invalid sweep value are exit 2 with a message on stderr; nothing is run and
  no file is written.
- A write error (for example an unwritable `DIR`) is exit 2; files written before it may remain, but `summary.json` is written
  last, so its absence marks an incomplete batch.
- Extinction of all kinds is not an error (CONTRACT section 5.4).

## Consequences
- Positive: `batch` shares the simulation loop with `run` (no second copy that could drift); the sweep rule is one generic path
  for every configuration key; the summary is deterministic and carries no timing, so the TASK-021 repeatability test is exact.
  `--jobs` gives speed-ups for TASK-027's baseline (10,000 ticks, at least ten seeds) without changing the output.
- Negative: `run_run`'s loop moves into `core::runner` (a refactor that must keep the ADR-0020 and ADR-0021 tests green); the
  summary is larger with many runs (one object per run; fine at benchmark sizes).
- Risk: the cartesian product grows fast (for example 5 values of 4 keys = 625 cases). The CLI does not cap it; a documented
  warning goes to stderr when the run count exceeds 1,000. Risk: `--jobs` with threads needs `Send` (checked in IMPLEMENT).
- Risk: the overall aggregate over cases mixes parameter values; readers must use `aggregates` for comparisons (documented).

## Verification strategy
- Unit tests in `core::runner`: `run` with `with_metrics` false and true gives the same `state_hash` and `series`; `tick_end`
  and series ticks as in ADR-0020 D4.
- Unit tests in `core::batch` (new module `crates/evosim-core/src/batch.rs`, pure functions, no files): case expansion order for
  two `--vary` keys (2 x 3 = 6 cases, order checked); seeds with duplicates rejected; `aggregate` on hand-written run values:
  for final plants `[10, 20, 0]` the mean is 10.0, min 0, max 20, population sd `sqrt(200/3)`, extinct_runs 1 and fraction 1/3;
  the summary JSON parses with `config::json::parse` and has the keys of D3 in order.
- CLI unit tests in `args.rs`: every error case of D1 (missing `--seeds`, empty list, bad seed, duplicate seed, `--vary` without `=`,
  empty values, duplicate key, `seed` in `--vary`, `--jobs 0`, unknown option).
- End-to-end (`crates/evosim-cli/tests/batch_cli.rs`, uses `CARGO_BIN_EXE_evosim`):
  - The 2 values x 2 seeds matrix: `--vary initial.plants=200,400 --seeds 1,2 --ticks 50`. Four files `case-0k/seed-S.json`
    exist; `summary.json` lists four runs with the right `seed` and `params`, `tick_end` 50; the aggregates equal values
    recomputed in the test from the four per-seed files.
  - Without `--vary`: files `seed-1.json`, `seed-2.json` in `DIR`; each `final`, `totals`, `series`, `state_hash` equals the
    result of `evosim run --seed S` on the same configuration (after removing the time lines).
  - Repeatability: the same command twice gives byte-identical `summary.json` and per-seed files equal after removing the two
    time lines.
  - `--jobs 2` gives the same `summary.json` and per-seed files as `--jobs 1`.
  - `--csv`: `runs.csv` has 1 + 4 lines and `aggregates.csv` has 1 + 2 x 3 lines; values agree with `summary.json`.
  - Errors exit 2 with a message and leave no `summary.json`: unknown `--vary` key (`initial.nothing`), value out of range
    (`initial.plants=-1`), `--seeds 1,1`, `--ticks -1`.
  - `--ticks 0` works (one sample at tick 0 per run).
- Gates: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
  `bash scripts/check_adrs.sh`, and `scripts/test.sh` gets a batch step (same matrix, compared as in the repeatability test),
  run after `./build.sh`.

## Implementation record (TASK-021 IMPLEMENT cycle 1)
Accepted at REVIEW cycle 1 PASS (status line above). REVIEW checks: see `tasks/TASK-021/handoffs/review-cycle1.md`.
- Built as decided in D1-D7. Modules: `crates/evosim-core/src/runner.rs`, `crates/evosim-core/src/batch.rs`,
  `crates/evosim-cli/src/batch.rs`, `args::parse_batch`. Tests: core runner 4, core batch 9, args batch 5 test functions,
  `crates/evosim-cli/tests/batch_cli.rs` 8 end-to-end tests.
- Deviation 1: `--jobs` needs no `Send` check; each worker builds its own `Simulation` inside the thread, and only the
  `RunResult` (plain data) crosses threads.
- Deviation 2: the summary's `base` is written on one line (inline JSON), and each run and aggregate is one line, so that the
  file is easy to diff. Still valid JSON; the key order is that of D3.
- Deviation 3: per-seed files are written before the CSV and the summary; `summary.json` is last (as D3/D7).
- Refactor check: example configuration, seed 7, 300 ticks: `state_hash` `1f613fac5c342bbd1c794dd7c5ae57bfef2f30b4aa812ea6101414a92f7db80b`
  before and after the move; the result file equal except the two time lines.
- Measured (release build, 12 cores, this container): `run` of 10,000 ticks on the example configuration, seed 42: 1.08 s
  (9,264 ticks/s); batch of 4 seeds x 1,000 ticks: `--jobs 1` 0.555 s, `--jobs 4` 0.151 s; the two summaries are byte-identical.


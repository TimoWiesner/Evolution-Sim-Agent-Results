# ADR-0026: UI scenarios, presets, configuration files and charts

Status: Accepted (drafted in TASK-025 PLAN cycle 1; accepted at TASK-025 REVIEW cycle 1 PASS).

## Context
TASK-025 (`tasks/TASK-025/task.md`) lets the user set up their own experiment in `evosim ui` and watch it in charts.
Today the page can only run the world given by `--config` (ADR-0024, ADR-0025). Required: start a new world from the
page (choose a preset, then edit seed, world size, initial populations and at least five further parameters); show
invalid input next to its field and do not start; export and import the configuration as JSON with an exact round
trip; charts that update while the simulation runs (population per kind, births and deaths, number of species, mean
of a trait); a chart of the trait distribution in the current population, with a selectable trait; axis labels and
legends; tests of configuration and chart-data logic that need no display.

Facts from the code that shape the design:
- `core::config` already validates every parameter with a key-named `ConfigError` (ADR-0006), has `Config::from_json`,
  `Config::to_json` (lossless, `from_json(to_json(c)) == c`) and `config::presets::{NAMES, get}`.
- `core::analytics::MetricsLog` records per-kind population, cumulative and per-interval births and deaths, species
  alive, and mean/sd/min/max of every trait (ADR-0021). Its `trait_values` helper is private.
- `Session` (ADR-0025) owns the `Simulation`, the started configuration (used by reset) and the organism watch.
- The seed is a 64-bit integer (0..2^64-1). A JavaScript number holds integers only up to 2^53, so the page must never
  carry the seed (or any integer) as a JavaScript number.
- The existing `ui --screenshots` produces `main.png` only. The contract allows up to five more PNGs.

## Considered alternatives
1. **Form payload as typed strings, parsed and validated by the server with the core rules.** The page sends each
   field as the text the user typed; the server maps the text to the core's parameter rules and returns errors keyed by
   dotted path. One parser, one set of rules, no precision loss. Trade-off: the page cannot validate without a request
   (acceptable on loopback; a local check for "empty" can run in the page).
2. **Validation in JavaScript.** Immediate feedback, but duplicates the range table in two languages and risks
   disagreement with the core. Rejected.
3. **Charting library (Chart.js, uPlot, d3) vendored into the binary.** Feature-rich but adds third-party assets that
   must be licensed, vendored and kept current, and the screenshot path must then wait for them. Rejected: the charts
   needed are line charts and one histogram; own canvas code is about 250 lines and fully under test control.
4. **Chart data pushed in the `/api/state` poll.** Simple, but the state is polled 5 times per second and would grow with
   the history. Rejected: charts use their own endpoints with `since=` for incremental reads.

## Decision
**D1. Editable parameters.** The "New world" panel edits:
- required: `seed`, `world.width`, `world.height`, `initial.plants`, `initial.herbivores`, `initial.carnivores`;
- further (12 keys): `climate.season_length`, `climate.weather_amplitude`, `plants.reproduction_chance`,
  `plants.seed_radius`, `plants.max_age`, `herbivores.reproduction_energy`, `herbivores.max_age`,
  `carnivores.reproduction_energy`, `carnivores.max_age`, `genetics.mutation_rate`, `genetics.mutation_strength`,
  `species.distance`.
Not offered: `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism`. ADR-0006 (amendment, TASK-018)
records that the engine does not use them; editing them would change nothing and would mislead. Every other key of the
file format stays at its default when the page does not set it, and is kept when a loaded file sets it (see D3).

**D2. Field payload and validation (`crates/evosim-ui/src/setup.rs`, pure).** A table maps each editable key to its
label, group and the core's type and range (taken from the core's error text, not duplicated as numbers where the core
already checks). `parse_fields(&[(String, String)]) -> Result<Config, Vec<FieldError>>` builds a JSON text from the
strings (a value is written as a JSON number only if it matches the decimal grammar of its type; otherwise the field
gets the error "not a whole number" or "not a number"), then calls `Config::from_json`. A `ConfigError` with a key
becomes a `FieldError { key, message }`; a `ConfigError` without a key becomes a form-level error. All errors are
collected per field where the parser can attribute them, so a single response can name several fields. Invalid input
never reaches the session.

**D3. Export and import.** Export: the page posts the form fields to `POST /api/config/check` (no simulation involved); on success the response
carries `Config::to_json()` and the page downloads it as `evosim-config.json`, on failure the errors are shown next to
the fields. Import posts the file text (`POST /api/config/import`);
on success the response holds the canonical field strings (`{"fields": {"seed": "18446744073709551615", ...}}`) and the
page fills the form from them; on failure it returns 422 with the errors and the form is left unchanged. A file
with only the fixed keys is valid. Export followed by import yields `Config` equal to the original (`PartialEq`), and
this is tested for a seed of 2^64-1 and for reals such as `0.1` and `1e-7`.

**D4. Starting a world (`POST /api/world`).** The body is the field payload (D2). A valid payload replaces the session
with `Session::new_world(config)`: a new `Simulation` built with `Simulation::new` and `populate_initial`, tick 0, the
chart log cleared, the watch cleared, `climate_version` bumped, and the run state set to paused. The new configuration
becomes the one that reset returns to (ADR-0025 D4 semantics unchanged). An invalid payload returns 422 with the errors,
and the running session is unchanged. The choice of paused start is recorded here so the user sees tick 0 before the
first run.

**D5. Presets.** `GET /api/presets` returns the names of `config::presets::NAMES`, each with its full field payload
and a one-line description held in the UI crate (not in core), for example "contract example: 64×48, 400 plants, 120
herbivores, 20 carnivores". The page shows one card per preset; choosing a card fills the form. The form fields remain
editable afterwards; a card does not lock anything.

**D6. Chart data (`crates/evosim-ui/src/charts.rs`).** `ChartLog` is owned by `Session` and holds `ChartPoint`s:
`{tick, population[3], births[3], deaths[3], species[3], trait_mean[3][k]}`. `Session` records a point after every tick
(the same place where the death record is taken, ADR-0025 D4). Values come from `core::analytics::Snapshot` built with
`MetricsLog`, so the chart numbers are the same numbers the metrics file reports.
Storage is bounded: while the log holds fewer than `MAX_POINTS = 2000` points every tick is kept; at the limit the
log keeps every second point and doubles the stride for later ticks. When two points merge, births and deaths are
summed, population and species take the later value, and trait means take the later value. Totals therefore stay
exact over the full span.
Endpoints: `GET /api/series?since=T&kind=K&trait=NAME` returns the points with `tick > T` as arrays
(`{"tick": [...], "population": {...}, "births": ..., "deaths": ..., "species": ..., "trait": {"kind": K, "name": NAME, "mean": [...]}}`).
Points are incremental, so the page polls with the last tick it holds. A trait name that the kind does not have is 400.
As ADR-0025 D2 requires, HTTP threads never read the `ChartLog` or the `Simulation`: both chart reads are read-only
commands (`Command::Series { since, kind, trait }`, `Command::Distribution { kind, trait, bins }`) that go through the
same queue, are answered by the simulation thread between ticks with `Reply::Bytes`, and time out with 503 after 5 s.

**D7. Distribution (`GET /api/distribution?kind=K&trait=NAME&bins=N`).** A histogram of the living organisms of the
kind, computed by the simulation thread (`Command::Distribution`) from `Entities::living()`. `bins` is 1..=100, default 20.
The response holds `n`, `mean`, `sd`, `min`, `max`, `edges` (N+1 values) and `counts` (N values). A bin is
`[edge_i, edge_i+1)`, the last bin is closed. With no living organism of the kind: `n = 0` and empty arrays. The
trait values come from `core::analytics` through a visibility change only: `trait_values` becomes `pub`. No
behaviour of the core changes.

**D8. Chart set and layout.** Drawn on canvas by own code in `web/charts.js` (embedded with `include_str!`, like the
other assets). Panels, each with axis labels and a legend:
1. Population per kind over ticks (x: "Tick", y: "Individuals").
2. Births and deaths per tick, per kind (solid = births, dashed = deaths; y: "Events per tick").
3. Species alive per kind (y: "Species").
4. Mean of the selected trait per kind over ticks (y: the trait name and unit).
5. Distribution histogram of the selected trait for the selected kind (x: the trait name, y: "Organisms").
The trait selector lists `analytics::trait_names(kind)`. Charts redraw when new points arrive (poll every 1 s while the
page is visible). The page layout: world view on the left, controls and the "New world" panel in the sidebar (the
form in a `<details>`), charts in the bottom strip (`#charts`), as reserved by ADR-0024.

**D9. Screenshots.** `ui --screenshots DIR` writes `main.png` from `?shot=1` (as now, 1280×720 or larger) and
`charts.png` from `?shot=1&view=charts`, where the same page lays the charts out in the main area. Both files come from
the real page and are checked by the binary (PNG header, at least 1280×720). The world is advanced to at least 100
ticks before both shots.

**D10. Tests that need no display.** Rust unit tests in `setup.rs` (each error class: non-numeric, wrong type, out of
range, unknown key, missing fixed key, empty field; round trip of defaults, presets and an extreme seed), in
`charts.rs` (thinning keeps totals; trait names; histogram counts sum to `n`; empty population), in `control.rs`
(`new_world` starts paused at tick 0; invalid payload leaves the session unchanged; reset returns to the new
configuration), and in `server.rs` (status codes 200, 400, 404, 405, 422 for the new routes). A black-box check
`scripts/config_charts_check.py` (stdlib, `python3 -I`) starts `evosim ui`, runs the HTTP flow (presets, invalid
payloads, world start, series growth while running, distribution sums, export and import) and, with the container's
Chromium over the DevTools protocol, drives the form, the import button and the trait selector with real input events.

## Consequences
- The page gains a second write path (`POST /api/world`) that replaces the simulation. It runs on the simulation thread
  between ticks, like the commands of ADR-0025.
- The configuration reaches the simulation only through `Config`, so every value the page shows went through
  `from_fields`.
- Chart memory is bounded at 2000 points per session. Per-tick trait statistics cost one pass over the living
  organisms per tick; the cost at 5,000 organisms is measured in IMPLEMENT (see the plan) and recorded in STATE.md.
- `core` changes by one visibility keyword. No simulation behaviour changes, so `state_hash` values are unchanged.
- The bundle grows by one JavaScript file and roughly 40 KB of page code. Nothing new is needed at run time, so
  `dist/evosim` keeps working without extra files.

- Performance: the chart log adds one `analytics::sample` pass per tick (the same statistics `MetricsLog` computes).
  Its cost is measured in TASK-025 IMPLEMENT and recorded in `docs/STATE.md`; the 60 ticks/s target is not changed.
- Testability: every rule of this record (field grammar, round trip, histogram, thinning, routes, new-world session
  state) has unit tests that need no display; the browser pass is a separate script.

## Implementation notes (TASK-025 IMPLEMENT cycle 1)
- `GET /api/series` takes `since` (optional) and `trait` only; the mean is returned for every kind (`null` where the
  kind has no such trait). The `kind` parameter of D6 was dropped: the chart draws all three kinds.
- The form is served as `web/setup.js` and the charts as `web/charts.js` (embedded like `app.js`).
- The request body of `POST /api/config/check` and `POST /api/world` is a JSON object of field texts plus `base`
  (the text of the preset or imported configuration whose hidden parameters are kept); a value that is not a string is 400.
- `core::analytics` gained `sample`, `cumulative_events` (new, read-only) besides `trait_values` made public.

## Verification strategy
- `cargo test -p evosim-ui --locked --offline`: the unit tests of D10.
- `cargo test --workspace --locked --offline` still exits 0 (core unchanged except the visibility keyword).
- `bash scripts/check_adrs.sh` exits 0 with ADR-0026 added to its list.
- `node --check crates/evosim-ui/web/app.js` and `charts.js`.
- `python3 -I scripts/config_charts_check.py` exits 0 (HTTP black box plus the Chromium pass).
- `./build.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR` (both PNGs viewed), `scripts/ui_check.sh`,
  `python3 -I scripts/control_check.py` exit 0; the tick rate at speed 60 with the charts active is recorded.

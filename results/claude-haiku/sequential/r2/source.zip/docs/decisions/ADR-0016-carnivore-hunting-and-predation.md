# ADR-0016: Carnivore pursuit, hunting, predation, metabolism and energy gain

Status: Accepted (drafted in TASK-015 PLAN cycle 1; implemented in IMPLEMENT cycle 1; accepted at TASK-015 REVIEW cycle 1 PASS).

## Context
TASK-015 makes carnivores live off herbivores through hunts that can succeed or fail. Before this task carnivores only wander
and pay the movement cost (ADR-0014), so they never gain energy. The rules must reuse what exists: `Entities` (`damage` with
`DeathCause::Predation`, `drain_energy`, `add_energy`, the living-only rule of ADR-0011), `SpatialIndex::within` (Chebyshev
radius, kind filter, ascending ids, across the torus), the deferred-move pattern of ADR-0014 (`plan_moves`,
`Simulation::move_organism`), the herbivore pattern of ADR-0015 (decide, move, act in ascending id, then charge costs),
`feeding::thermal_cost` (climate cost), and the genome traits (`speed` and `strength` for both animals, `caution` for prey,
`aggression` for carnivores, `vision_radius` from slot 7). Constraints as in PROJECT.md: deterministic (one RNG stream,
ascending id, no hash maps), no rule may look at population counts, every rule local to the organism and its surroundings.
The herbivore death rules of ADR-0011 apply: the predation cause is set once and the Deaths phase removes the organism.

## Considered alternatives
1. **Attack from a distance, within vision (rejected).** The brief allows attacks only from the same or an adjacent cell.
   Vision is for finding prey; the strike needs reach 1 (the same reach as herbivore feeding, ADR-0015).
2. **Wounds over several ticks (health loss per successful bite, kill later) (rejected for now).** It would make a prey
   escape with damage and need a stored wound state or a health-based recovery rule. A single roll per attempt keeps the
   outcome local to one tick and needs no new state; wounds can come later if TASK-018 shows the chain is too fragile.
3. **Deferred attacks in a planning pass like moves (rejected).** Two carnivores would both "kill" the same herbivore and both
   gain its energy. Attacks are resolved sequentially in ascending id order against the current state, so a prey killed
   earlier in the phase cannot be attacked again.
4. **Handling time as a stored timer after a kill (rejected for now).** It is the textbook mechanism (ecology idea), but a timer
   is new per-organism state that the checkpoint (TASK-022) and the state hash must carry. Satiation (below) limits intake per
   carnivore without new state; a timer remains an option for TASK-027.
5. **Hunting success from the predator's speed only (rejected).** It ignores the prey's traits, which the brief requires
   ("depends on the traits of both animals").
6. **Gain equal to the whole prey energy (rejected).** It breaks no rule, but a fixed assimilation fraction below 1 and a meal
   cap keep energy conservation visible and mirror ADR-0015 (gain = 0.8 times what is taken).

## Decision

### Pursuit (heading, in the Carnivores phase)
- The carnivore perceives living organisms within `entities::vision_radius(genome)` (ADR-0014 `perceive`).
- Heading, first match wins:
  1. the nearest living herbivore in sight (Chebyshev distance, ties by lowest id), **and** the carnivore is below
     `SATIATION_CARNIVORE` energy: `Heading::Towards(prey cell)`;
  2. otherwise `Heading::Wander`.
- Herbivores are the only prey (carnivores do not eat carnivores). Dead organisms still in the index are skipped (`is_alive`).
- Steps per tick are `floor(speed)` (ADR-0014). The pursuit draws no random numbers; wander draws are the ADR-0014 draws.

### Attack reach and target
- An attack is possible only on a living herbivore in the carnivore's own cell or an adjacent cell after all carnivore moves of
  the phase: `SpatialIndex::within(cell, HUNT_REACH = 1, Some(Kind::Herbivore))`, living only.
- Target at attack time: nearest such herbivore (Chebyshev, ties by lowest id). One attempt per carnivore per tick.
- A carnivore with no living herbivore in reach at its turn makes no attempt and pays no attack cost (it did not hunt).

### Attack formula (the success chance)
For attacker `c` (carnivore) and prey `p` (herbivore), with `speed` in `[0, 4]`, `strength` in `[0, 10]` and `caution` in `[0, 1]`:

    chance = clamp(P_BASE + W_SPEED * (c.speed - p.speed) / 4 + W_STRENGTH * (c.strength - p.strength) / 10 - W_CAUTION * p.caution,
                   P_MIN, P_MAX)

Constants (uncalibrated, TASK-018/027): `P_BASE` 0.5, `W_SPEED` 0.3, `W_STRENGTH` 0.2, `W_CAUTION` 0.3, `P_MIN` 0.05, `P_MAX` 0.9.
- Both animals' speed and strength, and the prey's caution, enter the formula. The prey's aggression is not a herbivore trait
  in use. The carnivore's `aggression` is recorded but not used in TASK-015 (no rule needs it yet; it is the candidate for
  pursuit willingness in TASK-027).
- One roll per attempt: `rng.chance(chance)` from the simulation generator, in ascending attacker id order.
- Pure function `attack_chance(attacker: &Traits, prey: &Traits, prey_caution: f32) -> f64`; the roll is the only random draw.

### Outcomes
- **Kill** (roll succeeds): the prey takes `damage(prey.health, DeathCause::Predation)`, so it dies exactly once with cause
  `Predation` (the first cause wins; a prey that is already dead is never attacked). The carnivore gains
  `ASSIMILATION_CARNIVORE * min(prey.energy, MEAL_MAX)` with `add_energy`. Since `ASSIMILATION_CARNIVORE` is 0.8 and the
  meal cap is `MEAL_MAX` = 30, the gain is at most the prey's energy at the time of the kill (energy is not created).
  The corpse keeps its energy until the Deaths phase removes it; it cannot be eaten.
- **Escape** (roll fails): nothing happens to the prey; the carnivore still pays `ATTACK_COST`.

### Costs (per carnivore, per tick, through `drain_energy`)
1. Attack cost `ATTACK_COST` = 0.5 for each attempt, successful or not ("hunting costs energy whether it succeeds or not").
2. Movement cost, `movement::move_cost(distance, speed)` (ADR-0014).
3. Base metabolism `BASE_COST_CARNIVORE` = 0.4 per tick (higher than herbivores' 0.3; predators are larger).
4. Thermal cost `feeding::thermal_cost(T)` at the cell after the move (ADR-0015).
A carnivore whose energy reaches 0 dies of `Starvation` in the Deaths phase. A carnivore with no prey gets no gain, so it
starves: this is the only way a predator dies without prey, and it is a local rule with no population count.

### Satiation (stateless handling time)
- A carnivore with energy `>= SATIATION_CARNIVORE` = 70 neither pursues nor attacks: it wanders and pays its costs. This limits
  how many herbivores one carnivore takes per unit of time without a stored timer (alternative 4). The ecology idea of a
  handling time is thereby approximated; the timer is deferred.

### Phase order (Carnivores arm, replaces `animal_phase(Kind::Carnivore)`)
1. Plan: `plan_moves(Kind::Carnivore, heading = carnivore_heading)` from the start-of-phase positions (ascending id).
2. Apply moves ascending id through `Simulation::move_organism`.
3. Attack ascending id: for each living carnivore, if it is below satiation and has a living herbivore in reach, one attempt
   (roll, outcome, gain, attack cost). Resolved against the state after the earlier attacks of this phase.
4. Charge costs ascending id: movement, base metabolism, thermal cost at the cell after the move.
Herbivores have already moved and fed in the Herbivores phase (ADR-0008 order), so carnivores see their final positions.
Deaths (including the predation kills) are removed in the Deaths phase; the index is updated there (`spatial.remove`).

### Several carnivores on one herbivore (documented rule)
- Attacks are sequential in ascending id. Each carnivore in reach of a living herbivore makes its own roll. The first kill
  makes the prey dead; any later carnivore re-targets at its own turn to another living herbivore in reach, or makes no
  attempt. Only one carnivore gains the prey's energy. Deterministic and cannot double-kill or over-gain.

### Edges and state
- Reach and sight use the torus (`SpatialIndex`, `Torus::distance`), so kills across the seams are possible.
- No new state: the satiation rule, the attack roll and the costs are functions of the organism, its surroundings and the RNG.
  The checkpoint (TASK-022) layout is unchanged.
- Carnivore `plan_moves` closure now calls `hunting::carnivore_heading`; `movement::choose_heading` stays for tests.

### Related fix in the same phase (G-051, from TASK-014 REVIEW)
- `plan_moves` maps `Heading::Away(threat)` with the threat on the animal's own cell to `(from, 0)`, so the animal stays put.
  ADR-0015 says it falls back to `Wander`. This phase touches `movement.rs`, so the fix is made here: in `plan_moves`, an
  `Away` heading whose threat is the animal's own cell becomes `wander`. A test covers it. ADR-0015 wording is then correct.

## Consequences
- **Energy conservation**: the gain of a carnivore is at most `0.8 * min(prey energy, 30)`, never more than the prey had;
  costs are only removed. The prey's energy above the meal share (`prey energy - gain`) is lost from the system with the corpse;
  this is a documented sink, not a source.
- **Predation cause**: every kill sets `Predation`; the `deaths_by_cause` bookkeeping counts it once. `initial + births - deaths =
  living` still holds (predation is a death).
- **Determinism**: ascending id order, one RNG stream; the attack rolls are part of the state hash through the generator state.
- **Testability**: `attack_chance` is pure; `carnivore_heading` and the attack resolution take `&Entities`, `&SpatialIndex` and
  `&mut Rng`, so they run in `cargo test` without a UI.
- **Population**: carnivores can starve without prey; a chain can collapse. Allowed (PROJECT.md). Whether the three kinds
  coexist is measured in TASK-018 and TASK-027.
- **Calibration**: all constants are uncalibrated (TASK-018, TASK-027). Founders' energy and the herbivore supply decide early
  survival; tests use small worlds with explicit outcomes.
- **Performance**: per carnivore per tick, one `within` for pursuit, one for reach, plus the herbivore pursuit lookup (perception).
  Measured in TASK-026/027 (G-046 applies).
- **dist/**: plain Rust in the core; no crate, no file, no change to `dist/`.

## Verification strategy
- Pursuit: a herbivore at vision distance is pursued; one at vision + 1 is not; a satiated carnivore wanders.
- Reach: prey at distance 2 is never attacked; prey at distance 0 and 1 is; a kill across the west seam works.
- Chance: `attack_chance` stays in `[P_MIN, P_MAX]`; increases with attacker speed and strength, decreases with prey speed,
  strength and caution (monotone sweeps over the trait ranges).
- Outcomes: over 2,000 seeded attacks at mid traits both kills and escapes occur, and the kill fraction is near the chance.
  With a fast strong attacker against a slow weak prey, kills are clearly more frequent than with the reverse pair.
- Death: a kill leaves the prey dead with `Predation` once; a second carnivore in reach makes no second kill; the Deaths phase
  removes it once (`deaths(Herbivore)` and `deaths_by_cause(Herbivore, Predation)` each increase by one).
- Energy: the carnivore's gain is `<= prey energy` for prey energies from 0.5 to 100; the exact gain is `0.8 * min(e, 30)`.
- Costs: after one tick with one attack (kill or escape), the energy change equals gain minus attack cost, movement, base and
  thermal costs (exact within float tolerance).
- Starvation: a carnivore with no herbivores loses energy every tick, never gains, and dies of `Starvation` within a bounded
  number of ticks.
- Several carnivores: two carnivores in reach of one herbivore produce exactly one kill; the first in id order is the one that
  rolled and won.
- Determinism: same seed gives identical positions, energies and death records after N ticks; different seeds differ.
- Index: `check_spatial` after every tick in a 500-tick mixed run; dead prey stay out of the index after the Deaths phase.
- G-051: `plan_moves` with `Away` and the threat on the own cell returns a wander step (ADR-0015 wording holds).

## Implementation notes (TASK-015 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/hunting.rs` (new; constants, `attack_chance`, `carnivore_heading`, `attack`, `carnivore_costs`,
  `AttackOutcome`). `sim.rs`: `carnivore_phase` replaces the old `animal_phase`, which is removed (herbivores use `herbivore_phase`).
  `lib.rs`: `pub mod hunting`.
- Deviation in naming: the "no attempt" outcome is `AttackOutcome::NoAttempt` (not `NoPrey`), because it also covers a dead or
  satiated carnivore. Costs are charged by the phase, not by `attack`, as planned.
- G-051 fixed in `movement::plan_moves`: `Away(own cell)` wanders. Test `movement::tests::away_from_a_threat_on_the_same_cell_wanders`.
- The attack chance is a test-checked formula, not calibrated. Measured in tests only: with mid traits and mid caution (prey caution
  about 0.5) the chance is about 0.35, which the 2,000-attack sweep reproduces (kills and escapes both occur).
- Test evidence: `cargo test -p evosim-core --locked` exit 0 (313 passed, 1 ignored). Named tests are listed in the handoff.
- Not measured yet: whether carnivores survive long runs (R1 and R5 of the plan); TASK-018 and TASK-027.

**Amendment (TASK-018 IMPLEMENT cycle 1, ADR-0019 D3/D4).** `SATIATION_CARNIVORE` 70 to 95. A carnivore at 70 stopped hunting and
could never reach the mating threshold of 90 (ADR-0017), so carnivores could not breed. The other hunting constants are unchanged
(`P_BASE`, `MEAL_MAX`, `ATTACK_COST`, `BASE_COST_CARNIVORE` were tried, see the calibration log). Carnivores still die out in all
measured seeds (`docs/results/TASK-018-survival.md`); the cause is open.

# ADR-0010: Seasons, weather and the time-dependent climate

Status: Accepted (TASK-007 REVIEW cycle 1 PASS; drafted in PLAN cycle 1, implemented in IMPLEMENT cycle 1). Extends ADR-0009 (base climate); does not change its biomes, base formulas or latitude.

## Context
TASK-006 gives every cell a fixed base climate: biome, base temperature and base precipitation from latitude plus a seeded,
torus-periodic regional variation. TASK-007 makes the climate change over time: a repeating year of `climate.season_length` ticks
(config key already present, ADR-0006, default 240) and seeded random weather on top of it. The requirements (task.md) are:
seasonal cycle for every cell; weather drawn from the simulation generator so equal seeds give equal weather; temperature and
precipitation within documented bounds; current values queryable for any cell; with weather off one year repeats exactly; weather
state that carries over between ticks is part of the simulation state.

Two facts of the torus shape the design. (1) The top and bottom seam joins the two polar belts (ADR-0009). (2) Earth's hemispheres
have opposite seasons, so an Earth-like reversal would have to put the northern and southern halves in opposite seasonal phase.
On this torus the north pole and the south pole are the same seam, so a phase reversal between the two halves would be a
temperature jump across the seam at the poles, where the seasonal swing is largest. That violates the seam requirement.

## Considered alternatives
1. **One global seasonal phase, amplitude depending on latitude (chosen).** `T_season(phi, t) = A_T(phi) * sin(2 pi t / Y)` with
   `A_T(phi) = 20 * phi / 90` (0 at the equator, 20 at the poles). Every cell shares the calendar, so the field is continuous
   across the seam and along latitude. Cost: no hemispheric contrast in the calendar. The world has one calendar, not two
   opposite ones. This is the honest consequence of the fold, documented here.
2. **Hemispheric reversal (phase offset `pi` between halves, `pi * sin^2(pi y / H)` as a smooth offset).** Smooth in `y`, but the
   offset is `pi` at the equator and `0` at the seam, so the two polar sides are in phase while the seasonal swing is maximal:
   visually plausible, but it moves the Earth-like pole reversal into the equator where amplitude is zero. Rejected: it adds a
   calendar that does not match any hemisphere and gains no visible realism at this grid scale.
3. **Independent per-cell AR(1) weather noise.** Simple, but neighbouring cells would be uncorrelated: the map looks like static,
   the seam is not special but neither is it smooth, and every tick draws `W*H` values and stores `W*H` state values. Rejected.
4. **Stateless counter-based noise `hash(seed, cell, tick)`.** Gives any tick for free, but violates the requirement that weather
   is drawn from the simulation generator. Rejected.
5. **Weather lattice: value noise on a coarse periodic lattice, AR(1) per node, drawn from the simulation generator (chosen).**
   See Decision.

## Decision
### Calendar and seasons
- Year length `Y = climate.season_length` (ticks, config key, ADR-0006, 1..=100000). No new config key.
- `sin_t = sin(2 pi * (t mod Y) / Y)`, computed in `f64` from the integer tick. It depends only on the tick, not the seed.
- Latitude `phi` from ADR-0009 (`90 cos^2(pi (y+0.5)/H)`), seasonal temperature amplitude `A_T(phi) = 20 * phi / 90` degrees C.
- Seasonal temperature: `T_season = A_T(phi) * sin_t`. Seasonal precipitation: `P_season = 1 + 0.2 * sin_t` (multiplier on
  the base precipitation; the same shape everywhere; the precipitation amplitude is a constant, not per-zone, to keep the
  seasonal part one formula).
- Biomes stay static (latitude only); a year does not change the biome.

### Weather (carries state between ticks)
- Lattice: `Lx = ceil(W / 8)`, `Ly = ceil(H / 8)` nodes (`1x1` world: one node). Node values `n[k] in [-1, 1]`, stored in `Climate`
  in row-major node order. All nodes start at 0 (neutral weather); creation draws nothing from the simulation generator.
- Per tick, in the Climate phase, only when `weather_amplitude > 0`: for each node in ascending row-major order,
  `u = 2 * rng.next_f64() - 1` (from `Simulation.rng`) and `n = clamp(0.9 * n + 0.3 * u, -1, 1)`. Persistence `rho = 0.9`
  (about ten ticks), step `sigma = 0.3`. Tunable constants in `climate.rs`; changing them needs an update here.
- Field at cell `(x, y)`: lattice coordinate `u = (x + 0.5) * Lx / W`, `v = (y + 0.5) * Ly / H`; bilinear interpolation of the four
  nodes `floor(u) mod Lx`, `(floor(u) + 1) mod Lx` (and the same in `y`) with smoothstep weights `s(f) = 3f^2 - 2f^3`. The
  interpolated value `w(x, y)` is in `[-1, 1]` (convex combination) and periodic in `x` (period `W`) and `y` (period `H`) because
  the lattice index wraps. The seam is therefore not a special case.
- Weather effects: temperature `+ weather_amplitude * 10 * w(x,y)` degrees C; precipitation multiplier `+ weather_amplitude * w(x,y)`.
  Default 0.15 gives about +-1.5 C and +-15 % of the base precipitation per cell. Note: the configuration comment "relative to the
  seasonal swing" is loosely honoured; the reference swing is 10 degrees C for temperature and 100 % for precipitation. ADR-0006
  wording may be aligned in IMPLEMENT (documentation only).
- `weather_amplitude = 0.0` is the weather switch: no draws happen and the weather term is exactly 0. There is no separate flag.

### Current values and bounds
- Base values stay as ADR-0009 (`CellClimate`, base only). New query `Climate::conditions(cell) -> Conditions { temperature: f32,
  precipitation: f32 }` gives the values for the last advanced tick (`Climate.weather_tick`): base + variation + seasonal + weather,
  then clamped to the documented bounds.
- `Climate::seasonal_conditions(cell, tick) -> Conditions` is a pure function of `(cell, tick)` with no weather. It answers for any
  tick. Interpretation of "queried at any tick": the full value (with weather) is available for the tick the simulation has just
  finished; for any other tick, the weather is not reproducible without history, which the design does not store. This is a
  decision with a cost; see Risks.
- Documented bounds (checked by tests, enforced by clamp): temperature `TEMPERATURE_RANGE = [-70, 50]` degrees C (worst case
  about -55 at the pole, 40.5 at the equator with weather amplitude 1); precipitation `PRECIPITATION_RANGE = [0, 5000]` mm/yr.
  `TEMPERATURE_BOUNDS` of ADR-0009 (-25..31) still applies to the base field only.

### State and checkpoints
- `Climate` gains: `params: { season_length: u64, weather_amplitude: f64 }`, `nodes: Vec<f64>` (length `Lx*Ly`), `weather_tick: u64`.
  `Climate` derives `PartialEq`, so `World` and `Simulation` equality include the weather state.
- `Climate::from_parts` takes all of them and validates: node count equals `Lx*Ly`, values finite and in `[-1, 1]`, `season_length >= 1`,
  `weather_amplitude` in `[0, 1]`. Checkpoint (TASK-022) must serialize these fields in the climate section. Not implemented here.
- `Simulation::new` builds the climate from `config.climate` and the seed; the Climate phase in `run_phase` calls
  `world.climate.advance(&mut rng)`. Disjoint field borrows, no clone.

### Ordering inside the tick
- Phase `Climate` runs first (ADR-0008). It advances the weather to tick `t` and sets `weather_tick = t`. Seasonal values need no
  phase: they are computed on query from `t`.
- This removes the constant-fingerprint limitation recorded as G-025 for the Climate phase: the trace now changes when weather is on.

### Performance
- Per tick: `Lx*Ly` node updates (48 nodes at 64x48, about 2600 at 512x384) and nothing per cell. Queries are O(1): four node
  reads, a few multiplies, and one `sin` for the season.
- No per-cell weather array is stored: weather is interpolated on demand.

## Consequences
- Determinism: draws happen only in the Climate phase, in a fixed order, from the one simulation generator. Same seed and config give
  identical weather. `f64` interpolation order is fixed in code. `sin` comes from the platform libm (ARCHITECTURE rule 5, ADR-0009).
- Seam: seasonal part uses `phi`, which is symmetric about the seam, and the weather is periodic on the lattice. Both are continuous.
- Repeatability: with `weather_amplitude = 0`, `sin_t` is a function of `t mod Y` and the state (nodes) never changes, so one year
  repeats exactly, bit for bit, for every cell.
- Ecology (later tasks): seasonal swing and weather become inputs to plants and animals. Their effects are not part of TASK-007.
- Checkpoint: the climate section grows by `Lx*Ly` values and the weather tick. Changing the lattice spacing, `rho`, `sigma` or the
  seasonal shapes changes the simulation and requires a new ADR and a checkpoint version bump.
- `dist/`: plain Rust, no new crate, no new system library (sin/cos/exp already linked through libm, ADR-0009).

## Verification strategy
- Unit tests in `climate.rs`:
  - `seasonal_zero_at_equator`: `A_T(0) = 0`; at the pole `A_T = 20`; seasonal temperature at tick `Y/4` is `A_T`.
  - `year_repeats_exactly_with_weather_off`: `weather_amplitude = 0`, `Y = 240`, `Simulation::run` 480 ticks, compare the `conditions`
    after tick `t` and after tick `t + Y` for every cell and `t` in `0..Y`; bitwise equal (`f32::to_bits`).
  - `weather_is_seeded`: same seed, same config, 500 ticks: identical nodes and conditions; different seed: different nodes.
  - `weather_uses_simulation_rng`: with weather on, `rng_state()` changes after each tick (the Climate phase draws); with weather
    off, `rng_state()` is unchanged by the Climate phase (no draws, so the stream is the same as before TASK-007). With weather on,
    the trace fingerprint after the Climate record differs from the one before it (closes G-025 for the Climate phase).
  - `bounds_hold_over_long_runs`: 10 years (`Y = 120`) at `weather_amplitude = 1.0`, seeds 1..=3, every cell every tick:
    temperature in `[-70, 50]`, precipitation in `[0, 5000]`, values finite.
  - `weather_field_periodic_and_continuous`: interpolated `w` at `x = 0` equals at `x = W`, at `y = 0` equals at `y = H` (exact f64
    equality); the largest neighbour step across the seam is no larger than the largest interior step (same test style as ADR-0009).
  - `small_worlds_weather`: `1x1`, `1x7`, `7x1`, `2x2`, `200x3` run 100 ticks without panic; bounds hold.
  - `from_parts_roundtrip_continues_identically`: run 100 ticks, clone the parts (`tick`, `rng_state`, `world`), `from_parts`, run 50 more
    on both; `Simulation` equal, `conditions` equal.
  - `from_parts_rejects_bad_weather`: wrong node count, value 1.5, NaN, `season_length 0`, amplitude `-0.1` are errors.
- Config: `season_length` and `weather_amplitude` are read from `config.climate` (existing tests in `config/tests.rs` unchanged).
- Commands at IMPLEMENT: `cargo test --workspace --locked`, `cargo clippy -p evosim-core -p evosim-cli --locked --all-targets`,
  `bash scripts/check_adrs.sh` (ADR-0010 added to the checked list, with its six headings), `bash scripts/test.sh`, `./build.sh`,
  `./evosim climate` still exit 0 (base map unchanged: TASK-006 expected counts P 1024, U 256, T 512, D 256, R 1024 at 64x48).
- Gap register (not blocking TASK-007): history of weather is not kept (see Risks).

## Risks
- "Queried at any tick" is met for the seasonal part at any tick and for the full value at the last finished tick only. A test or
  consumer that needs past weather must run the simulation or request a history feature (not designed here).
- The single calendar is a documented compromise of the torus fold; a reader expecting opposite northern and southern seasons will
  not find them. ADR-0009 already states that the world has one equator and one polar seam.
- Constants (`sigma`, `rho`, lattice spacing 8, amplitudes 20 C and 10 C, the 0.2 precipitation swing) are plausible values, not
  calibrated. Ecology tasks depend on them. Change only with this ADR updated.
- Clamping at the bounds would hide a formula error; the tests check the bounds, but the clamp should not be reached in practice.
  IMPLEMENT should count clamp hits in a debug test and report them.
- The configuration wording of `weather_amplitude` differs from the reference scale used here (documented above).
- Checkpoint (TASK-022) must include the new fields or a resumed run will differ from an uninterrupted one. This is a known risk
  for the checkpoint task, recorded in the plan handoff.

## Implementation notes (TASK-007 IMPLEMENT cycle 1)
Status stays Proposed until REVIEW. Code: `crates/evosim-core/src/climate.rs`, `sim.rs`; checker: `scripts/check_adrs.sh` (ADR-0010 added).
- Constants are in `climate.rs` with the values of this ADR: `WEATHER_RHO` 0.9, `WEATHER_SIGMA` 0.3, `WEATHER_CELL` 8,
  `SEASON_TEMPERATURE_SWING` 20, `SEASON_PRECIPITATION_SWING` 0.2, `WEATHER_TEMPERATURE_SCALE` 10, `TEMPERATURE_RANGE` (-70, 50),
  `PRECIPITATION_RANGE` (0, 5000).
- Deviations from the PLAN text:
  - `Climate::new(torus, seed, params)` returns `Result`; `Climate::from_parts(torus, terms, params, nodes, weather_tick)` returns
    `Result` and validates (`ClimateError`: zero year, amplitude, node count, node value). `SimError` gained `Climate(ClimateError)`;
    `SimError` is no longer `Copy`/`Eq` (`f64` in the error). Nothing else in the workspace matched on it.
  - The lattice size is computed from the torus (`ceil(W/8)` x `ceil(H/8)`), not stored. Same state, one fewer field.
  - Lattice position uses exact integer arithmetic: `(2c+1)*L / (2W)`. Then `c` and `c+W` give bit-equal weights (exact periodicity test).
  - The seam test checks exact periodicity plus a Lipschitz bound on every neighbour step (seam and interior alike). The PLAN's "seam no
    larger than the interior" claim does not hold for arbitrary random nodes (the wrap interval may have a larger node difference), so
    it was not used.
- Clamp diagnostic (`bounds_hold_over_long_runs`, amplitude 1.0, 3 seeds x 1200 ticks x 3072 cells = 11,059,200 cell-ticks): 9,318
  cell-ticks had a raw value outside the documented range and were clamped. The clamp is therefore reached rarely at amplitude 1.0,
  mostly where the precipitation multiplier goes below 0 (`1 - 0.2 - amplitude` at the extremes of the weather). Not measured at the
  default amplitude 0.15. Recorded as a risk; no formula was changed.
- `weather_tick` semantics: `conditions` answers for the last applied Climate phase. `seasonal_conditions(cell, tick)` answers for any tick.
- Testability: the new behaviour is covered by 11 tests (8 in `climate.rs`, 3 in `sim.rs`), listed in the TASK-007 IMPLEMENT handoff.

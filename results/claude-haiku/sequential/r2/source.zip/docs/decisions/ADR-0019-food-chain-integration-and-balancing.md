# ADR-0019: Food-chain integration, tick order, lifespan scale and default balancing

Status: Accepted (drafted in TASK-018 PLAN cycle 1; IMPLEMENT cycle 1 done with the amendments under "Implementation record"; Accepted at TASK-018 REVIEW cycle 1 PASS, see `tasks/TASK-018/handoffs/review-cycle1.md`). Coexistence of all three kinds is not met (not a pass point of TASK-018).

## Context
TASK-018 joins climate, plants, herbivores, carnivores, reproduction, deaths and species into one running food chain
(`task.md`). The parts exist (ADR-0008 to ADR-0018), but the joined run does not yet sustain herbivores or carnivores.
Measured in PLAN (release, scratch probe, removed; default configuration 64x48, 400 plants, 120 herbivores, 20 carnivores):

- Plants alone (0 herbivores, 0 carnivores), 2,000 ticks, seeds 1 to 5: plants survive in all five seeds (final 310 to 712);
  herbivores and carnivores are 0 from tick 1 (expected).
- No plants (120 herbivores, 20 carnivores, plants 0): herbivores die out at ticks 54 to 85, carnivores at 118 to 180 (seeds 1 to 5).
- Default (400/120/20), 2,000 ticks: herbivores die out in seeds 2, 4 and 5 (at ticks 697, 1,791 and 464); seeds 1 and 3 keep one
  herbivore alive at tick 2,000. Carnivores die out in all five seeds, between ticks 215 and 354. Herbivore births are 0 in seeds 1, 2,
  3 and 5, and 23 in seed 4.
- Diagnostic (seed 5, first 200 ticks): herbivores have mean energy about 78 (above the mating threshold 60), no starvation,
  no old-age death, yet zero births. Mean genome lifespan of herbivores is 5,331 ticks.

Root cause found: `entities::decode_traits` maps the lifespan slot to `MAX_LIFESPAN_RANGE = [1, 10_000]`, so the mean lifespan is
about 5,000 ticks. Maturity (`mating::maturity_age`) is 20 % of the lifespan, so a typical herbivore becomes mate-ready only
after about 1,000 ticks. ADR-0011 states that the config `*.max_age` keys are "the intended centre" of the lifespan range; TASK-009
did not wire them. The config keys `plants.max_age` (500), `herbivores.max_age` (300) and `carnivores.max_age` (400) therefore have no
effect. Two more config keys are also unused by the engine: `herbivores.metabolism` and `carnivores.metabolism` (superseded by the
ADR-0015 and ADR-0016 base costs), and `plants.growth_rate` (superseded by the ADR-0012 regeneration rate). Plant energy after grazing
is about 27 (below the growth reserve of 40) and plant numbers fall from 449 to 103 in 200 ticks with 120 herbivores present.

Constraints (`docs/PROJECT.md`, `docs/CONTRACT.md`): no forced anti-extinction rule, no count-based rule, births only from the
initial population or reproduction, deterministic, one RNG stream, the same engine for headless and UI, no new dependency.

## Considered alternatives
1. **Keep the lifespan range; lower the animals' energy costs or raise plant supply only (rejected as the first step).** It would
   not remove the maturity gap: a herbivore with lifespan 5,000 still cannot breed before about tick 1,000. Balancing energy can
   come later, on top of a correct scale.
2. **Change the constant `MAX_LIFESPAN_RANGE` per kind (for example herbivore `[1, 600]`) (rejected).** Simple, but it hard-codes
   the scale that ADR-0011 says the configuration sets, and leaves the three `max_age` keys dead.
3. **Centre the lifespan of each kind on its config `max_age` (chosen).** Lifespan = `floor(max_age * (0.5 + m))`, where `m` in
   `[0, 1]` is the block mean of the lifespan slot. Range `[0.5, 1.5] * max_age`, mean `max_age`. Herbivore maturity then lies
   between about 30 and 90 ticks, carnivore about 40 to 120, plant lifespan 250 to 750. Implemented with a `LifespanRanges`
   value from `Config`, passed to a new `Birth::from_genome_in`. The existing `Birth::from_genome` keeps the default centres,
   so the about 44 call sites in tests do not change.
4. **Remove the unused config keys (rejected for TASK-018).** The keys are documented in ADR-0006 and accepted by the parser.
   They are recorded as "not used by the engine" in ADR-0006 notes; wiring or removal is a later decision (TASK-027).
5. **Add a new stabilising rule (refuge, migration, handling timer, population floor) (rejected for now).** The existing local
   mechanisms (below) are enough to test whether the chain persists. A new mechanism is added only if the calibration in
   Verification shows that none of the existing ones can produce a food chain. Any new mechanism must be local and count-free.

## Decision
**D1. Tick order** (`sim::PHASE_ORDER`, unchanged, ADR-0008): Climate, SpatialIndex, Plants, Herbivores, Carnivores, Reproduction,
Deaths, Species, Counters.
- Plants first: they regenerate and grow from the cell pool (ADR-0012).
- Herbivores move, then feed, then pay costs (ADR-0014, ADR-0015). Carnivores move, attack, then pay costs (ADR-0016). Herbivores
  act before carnivores, so a herbivore that is eaten this tick has already fed.
- Reproduction: plant seeding, then animal mating, then newborns take their mother's species provisionally (ADR-0013, ADR-0017, ADR-0018).
- Deaths: a single order-preserving pass over organisms that reached zero energy, zero health or maximum age in this tick (ADR-0011).
  Newborns are checked in their birth tick.
- Species: full re-classification every `species.check_interval` ticks, extinction check every tick (ADR-0018).
- Counters: balance and spatial invariants (debug assertions; tests call `check_balance` after every tick).

**D2. Lifespan scale.** `LifespanRanges` (new, in `entities.rs`) holds the three centres from the config `max_age` keys. Founders
and newborns take their lifespan from it through `Birth::from_genome_in`. Maturity, old age and every other trait are unchanged.
This amends ADR-0011 (`max_lifespan` row) and ADR-0004 (slot meaning), as ADR-0011 already intended.

**D3. Stabilising mechanisms the chain relies on** (all local, all in ADR-0012 to ADR-0018; no new rule):
- Cell resource pool: refills toward the climate capacity; shared by the plants of a cell in proportion to demand. This limits plants per cell.
- Satiation: herbivores stop feeding at energy 80, carnivores stop hunting at 70. This limits intake per animal without a timer.
- Prey caution and speed: a hunt succeeds with a chance that depends on both animals' traits (ADR-0016). Herbivores flee a carnivore they
  see when their caution exceeds their hunger (ADR-0015).
- Climate zones: poles and the equator differ, so populations are uneven and cannot all sit in one cell.
- Cost of movement, base metabolism and thermal stress: a population pays for every tick it lives.

**D4. Default balance.** The defaults in `config.rs` (ADR-0006) keep their values unless calibration shows they cannot give a food
chain. Calibration order (each step is recorded in `docs/results/TASK-018-calibration.md`):
1. Apply D2 only, and measure the default runs.
2. If herbivores still die out in most seeds, change plant-side constants first (`REGEN_RATE`, `REQUEST_MAX`, `CAP_MAX` in ADR-0012,
   `SEED_*` in ADR-0013), then herbivore intake (`BITE_MAX`, `ASSIMILATION`, `SATIATION_ENERGY`), then herbivore costs.
3. Then carnivores: `P_BASE`, `W_*`, `MEAL_MAX`, `ATTACK_COST`, `BASE_COST_CARNIVORE`.
4. Calibration seeds are 1 to 5. A candidate is accepted only if it also passes on held-out seeds 101 to 105 (10,000 ticks).
   At most 24 candidates are tried. The rule: maximise the median coexistence length of the three kinds, then the minimum over seeds.
   The 1,000-tick, plants-alone and scenario tests are re-run after every change.
Engine logic never reads population counts (PROJECT.md). Changed constants are changed in their ADR and in the code together.

**D5. Measurement command.** `cargo run --release -p evosim-core --example survival -- --ticks 10000 --seeds 1,2,3,4,5`
prints, per seed and kind, the extinction tick or "survived", and the coexistence length. It is wrapped in `scripts/survival.sh`.
The output is recorded in `docs/results/TASK-018-survival.md`. TASK-019 may add the same run to `evosim batch`.

## Consequences
- Performance: the lifespan change does not add per-tick work. Each tick stays O(organisms) plus spatial queries. The per-tick cost at
  2,000 entities is measured in IMPLEMENT and recorded; the goal of 100 ticks per second is not claimed unless measured.
- Testability: the scenario and conservation tests use only library calls (`Config::from_json`, `Simulation::new`, `populate_initial`,
  `tick`), so they do not need the CLI (TASK-019). Determinism tests use `state_hash`-free comparisons (`entities` and `births`) until
  TASK-022 adds the checkpoint.
- Dist and portability: no new dependency and no system package. The example is not shipped in `dist/`.
- Checkpoint: `LifespanRanges` is derived from the configuration and must be saved with it in TASK-022 (as the other settings).
- Config keys: `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism` remain unused; recorded in ADR-0006 notes.

## Verification strategy
- Unit tests: `LifespanRanges` centres (mean equals `max_age` within rounding, bounds `[floor(0.5c), ceil(1.5c)]`), `Birth::from_genome_in`
  equals `from_genome` at the default centres, maturity of a herbivore with `max_age` 300 is between 30 and 90.
- Scenario tests (library level, default world 64x48): (a) plants 0: herbivores dead, then carnivores dead, with the carnivore death
  tick not earlier than the herbivore death tick; (b) herbivores 0, plants 400, carnivores 20: carnivores dead; (c) plants 400 only:
  plants alive at tick 1,000.
- Default-parameter tests: plants alone survive and reproduce for 1,000 ticks (births > 0); herbivores with plants 1,500 and carnivores 0
  are alive and have births > 0 at tick 500.
- Conservation: after every tick of a 1,000-tick run, per kind `initial + births - deaths == living` and `check_balance` is `Ok`.
- Never-revive: once a kind's living count is 0, it stays 0 for the rest of the run (checked every tick in a 10,000-tick run).
- 1,000-tick smoke test: the fixed-key configuration, `populate_initial`, no panic (debug assertions on).
- Survival run: `scripts/survival.sh` (10,000 ticks, seeds 1 to 5 for the report, plus held-out seeds 101 to 105) recorded in
  `docs/results/TASK-018-survival.md`, with the exact command and exit code.

## Implementation record (TASK-018 IMPLEMENT cycle 1)

**What was built.** D1 unchanged (`sim::PHASE_ORDER`). D2 as decided: `entities::LifespanRanges` (centres from `plants.max_age`,
`herbivores.max_age`, `carnivores.max_age`; `Default` = the config defaults), `entities::decode_traits_with`,
`Birth::from_genome_in`. `Simulation` holds `lifespans` (set in `new`, passed to `from_parts`, read by `lifespans()`);
`populate_initial`, `reproduction_phase` (plant seeding) and `mating_phase` (children) build births with it. `Birth::from_genome`
and `decode_traits` keep the default centres.

**Deviation 1 (validation).** `Entities::validate_genome` cannot know the centre (the store does not hold the configuration).
It compares speed, strength, fertility, health and tendencies exactly, and checks only that `max_lifespan` lies in
`MAX_LIFESPAN_RANGE`. The centre is applied by the constructor (`from_genome_in`), so a birth built with a different centre
is accepted. Storing the centre with the store is part of the checkpoint work (TASK-022).

**Deviation 2 (calibration).** D4 said "maximise median coexistence, at most 24 candidates, held-out seeds at the end". In
IMPLEMENT about 60 candidates were run in total (log: `docs/results/TASK-018-calibration.md`), so the 24-candidate limit was
exceeded, and candidates were chosen to pass the must-have points rather than by the median rule. The held-out seeds
101 to 105 were run only once for the final defaults. Both are recorded in the log.

**Changed defaults (D4 outcome).** Each change is also made in the constant's own ADR as an amendment note.

| constant | was | now | reason (measured, see log) |
|---|---|---|---|
| `DEFAULT_PLANTS_MAX_AGE` (config `plants.max_age`) | 500 | 1500 | Founders are clones of one ancestor and age together; at centre 500 seed 4 lost all plants at tick 588 (old age). At 1500 all five seeds survive 1000 ticks. |
| `feeding::BITE_MAX` (ADR-0015) | 2.0 | 0.5 | At 2.0 herbivores with 1,500 plants died at 290 to 300 ticks: plants crashed to zero in about 150 ticks. At 0.5 they survive 500 ticks with births. |
| `ecology::REGEN_RATE` (ADR-0012) | 0.05 | 0.1 | Works with BITE_MAX 0.5: pools regenerate faster than the lower bite removes. |
| `hunting::SATIATION_CARNIVORE` (ADR-0016) | 70 | 95 | Structural: a carnivore at 70 stops hunting and can never reach the mating threshold 90 (ADR-0017). Consistency fix. |

Not changed: `BASE_COST`, `ASSIMILATION`, `SATIATION_ENERGY`, `MEAL_MAX`, `ATTACK_COST`, `BASE_COST_CARNIVORE`, `P_BASE`, the
plant maintenance `MAINT_BASE`, `REQUEST_MAX`, `CAP_MAX`, the seeding constants and the mating constants. Each was tried and
did not give a food chain (log sections 1 to 7).

**Outcome against the must-have points (TASK-018 task.md).** Measured in tests (`food_chain_tests.rs`, seeds 1 to 3) and in
the command (`scripts/survival.sh`, seeds 1 to 5 and 101 to 105, 10,000 ticks, `docs/results/TASK-018-survival.md`):
- 1,000-tick fixed-key run without error: test `fixed_key_configuration_runs_1000_ticks_without_error`.
- Scenario tests: `without_plants_herbivores_then_carnivores_die_out`, `without_herbivores_carnivores_die_out`,
  `plants_alone_persist`.
- Never revive: `a_kind_that_reaches_zero_stays_at_zero` (10,000 ticks).
- Per-kind conservation after every tick: `per_kind_balance_holds_after_every_tick` (also `check_balance`).
- Default parameters: `default_plants_survive_and_reproduce_on_their_own_for_1000_ticks`,
  `herbivores_with_plenty_of_plants_survive_and_breed_for_500_ticks`.
- Survival command: recorded for 10 seeds; exit 0.

**Not met: coexistence.** No seed keeps all three kinds to 10,000 ticks. Carnivores die out in all ten seeds (167 to 409
ticks) and have 0 to 2 births per seed. Herbivores die out in all ten seeds (143 to 604 ticks). Plants survive in 7 of 10.
Coexistence is the goal and is measured, not a pass criterion of TASK-018 (task.md, "Not part of this task"); the
carnivore failure is recorded as the main open risk. The carnivore energy balance has not been diagnosed; the candidates
tried did not change it.

**Effect of the scale fix on plants.** Before D2 plants survived 1,000 to 2,000 ticks in all seeds at 400 founders.
With the lifespan centred at 500 (D2 alone, default world, 10,000 ticks), plants died out at ticks 146 to 514 in four seeds and at
1616 in one. Raising the plant centre to 1500 restores the plant-only result (all five seeds alive at 1,000 ticks). This is the reason for the plant change in the table above.

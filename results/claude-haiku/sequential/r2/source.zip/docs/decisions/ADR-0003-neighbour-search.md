# ADR-0003: Neighbour search on the wrapping grid

Status: Accepted (drafted in TASK-001 PLAN cycle 1, confirmed in TASK-001 IMPLEMENT cycle 1).

## Context
Perception, herbivore/carnivore hunting, mating search and plant pollination all ask "which organisms are within
radius r of cell (x, y), optionally of one kind?". The world is a finite torus `W x H` where x and y wrap
(climate continuous across seams). Target: 1,000-5,000 organisms, 100 ticks/s at 2,000. Ordering must be
deterministic (ADR-0004, determinism section).

## Considered alternatives
1. **Brute force scan of all organisms per query.** Trivially correct, zero state. Cost per tick is
   O(N * queries) = about 2,000 x 2,000 = 4 million distance tests, which is about 4-8 ms per tick and
   threatens the 100 ticks/s target as populations grow.
2. **Per-cell buckets (uniform grid index), rebuilt each tick by counting sort (CSR layout).** The world is
   already a grid of cells, and movement is cell-to-cell, so bucket = cell is the natural index. Query visits the
   wrapped cell box around (x, y), and buckets are already in ascending organism id order.
3. **k-d tree or R-tree with wrap-aware distance.** Good for continuous coordinates, but the world is discrete,
   so it adds complexity (wrapped splits, rebalancing) with no benefit here.
4. **Incremental bucket lists updated on each move/birth/death.** Lower per-tick cost but more code paths that
   can go stale; the per-tick rebuild is cheap (O(N + W*H)) and is easier to test against brute force.

## Decision
**Option 2: per-cell buckets (CSR) rebuilt once per tick, in `crates/evosim-core/src/spatial.rs`.**
- Data: `cell_start: Vec<u32>` of length `W*H + 1`, `items: Vec<u32>` (indices into the organism store), filled
  by counting sort over organisms taken in ascending id order, so each bucket is already id-sorted.
- Wrapping: a cell index is `(x.rem_euclid(W), y.rem_euclid(H))`. The torus distance along one axis is
  `d = min(|a-b|, L-|a-b|)`.
- Query `within(cx, cy, r, kind_filter)`: enumerate the distinct wrapped x-values in `[cx-r, cx+r]` and the
  distinct wrapped y-values in `[cy-r, cy+r]` (deduplicated, so small worlds and radii larger than the world do
  not return duplicates), test each organism's torus distance <= r, and return ids in ascending order.
- Mutation during a tick: organisms that move or die during processing are marked and the index is rebuilt at
  the next phase boundary. Queries inside a phase see the snapshot taken at the start of that phase, which keeps
  results independent of processing order within a phase. Tests check that moved/removed organisms are not
  returned from their old cell after a rebuild.
- No radius cap is applied to the result. The query accepts any radius `r >= 0`. The per-axis enumeration runs
  over the distinct wrapped values only, so when `2r+1` reaches the world size on an axis every wrapped value of
  that axis is visited exactly once. Results are exact and duplicate-free for radii larger than the world; the
  cost is then bounded by the number of organisms in the world, not by `r`.

## Consequences
- O(N + W*H) per tick to rebuild; queries cost O(cells in box + organisms in those cells).
- Memory: one `u32` per cell plus one per organism. For the default 64x48 world this is tiny.
- Density control matters: buckets stay small when each cell holds few organisms; the ecology rules (cell
  resource caps, crowding) keep that true.
- Performance will be recorded in `docs/ARCHITECTURE.md` by the IMPLEMENT phase (TASK-010 measurement).
- Testability: the index is a pure data structure over the topology and the organism store, so the brute-force
  comparison and the seam tests run in `cargo test` without a world, UI or browser.
- `dist/`: the index is plain Rust inside `evosim-core` with no runtime, data file or external crate. It is compiled
  into the single `dist/evosim` binary and needs no file next to it.

## Verification strategy
- Randomised test (`proptest` or a seeded loop) comparing at least 1,000 queries with brute force, including
  W or H of 1, radii larger than the world, and seam-crossing queries.
- Test that the result order is ascending id and contains no duplicates.
- Benchmark: index versus brute force with about 2,000 organisms, numbers written to `docs/ARCHITECTURE.md`.

## Amendment (TASK-010 PLAN cycle 1): snapshot plus change overlay

Status of this amendment: Accepted at TASK-010 REVIEW cycle 1 (PASS). Proposed in TASK-010 PLAN.

The text above says the index is "rebuilt at the next phase boundary" after a move or death. TASK-010 requires that
adding, moving and removing organisms keeps the index correct at all times, so the rule is changed as follows. The
CSR snapshot and the per-tick rebuild stay; a small change overlay is added on top of them.

- `SpatialIndex` (`crates/evosim-core/src/spatial.rs`) holds three parts:
  1. `positions: BTreeMap<OrganismId, Placed { cell, kind }>`: the current truth for every indexed organism. Ordered
     map, not `HashMap` (ARCHITECTURE determinism rule 4).
  2. The CSR snapshot (`cell_start: Vec<u32>` of length `W*H+1`, `items: Vec<SnapEntry { id, kind }>`), taken from
     `positions` in ascending id order by counting sort. Each bucket is id-sorted.
  3. `stale: BTreeSet<OrganismId>`: ids inserted, moved or removed since the snapshot. A stale id's snapshot entry is
     ignored; its answer comes from `positions`.
- Mutations `insert`, `move_to` and `remove` update `positions` and `stale` at once, so a query right after a mutation
  is already correct. When `stale.len()` exceeds `max(32, positions.len() / 4)` the snapshot is rebuilt and `stale` is
  cleared. Rebuild timing never changes a result: the result is always the current truth.
- `within(centre, radius, filter)` enumerates `Torus::neighbours(centre, radius)` (ADR-0007, each cell once), reads the
  snapshot bucket of each cell and skips stale ids, then tests each stale id against `positions`. The result is sorted by
  id and has no duplicates, because a stale id is never counted from the snapshot.
- The `SpatialIndex` phase of ADR-0008 calls `rebuild()` (compaction only; it does not change results).
- Phase rule (ARCHITECTURE determinism rule 2) still applies to behaviour phases from TASK-013 on: a behaviour phase
  reads the index without moving organisms, and it defers moves to the end of its phase, so processing order cannot
  change what a query sees. The index does not enforce this; it is a convention for the caller, recorded in ARCHITECTURE.
- The index is derived state. It is not saved in checkpoints. A loaded simulation rebuilds it from `Entities`
  (TASK-022 must do this and check it with `Simulation::check_spatial`).
- Dependencies: `spatial` may use `world` (topology) and `entities` (`OrganismId`, `Kind` only). `entities` never
  depends on `spatial`, so the graph stays acyclic.

### Implementation notes (TASK-010 IMPLEMENT cycle 1)
- Names as implemented: `SpatialIndex`, `SpatialError` (`DuplicateId`, `UnknownId`, `CellOutsideTorus`, `OutOfSync`) in
  `crates/evosim-core/src/spatial.rs`. Methods: `new`, `torus`, `len`, `is_empty`, `position`, `ids`, `insert`, `move_to`,
  `remove`, `rebuild`, `within`, `within_into`.
- Compaction bound: the stale set is rebuilt when it exceeds `max(32, positions.len() / 4)`.
- The query enumerates `Torus::neighbours(centre, radius)`, so no per-organism distance test is needed for snapshot entries.
  Stale ids are tested with `Torus::distance` (ADR-0007).
- Deviation: `Simulation::from_parts` builds the index from the living organisms (the plan left this to TASK-022).
  `check_spatial` reports organisms that could not be indexed.
- Deviation: `SimError::Spatial` and `Simulation::check_birth_cell` were added; a founder on a cell outside the torus is refused
  before it is spawned.
- `Simulation` equality compares the index by its positions only (`PartialEq` on `SpatialIndex`), not its snapshot layout.
- Measurements: see `docs/ARCHITECTURE.md`, "Measured performance".


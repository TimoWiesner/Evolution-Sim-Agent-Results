# ADR-0009: Climate zones, biomes and the torus compromise

Status: Accepted (TASK-006 REVIEW cycle 1 PASS; drafted in PLAN cycle 1, implemented in IMPLEMENT cycle 1).

## Context
TASK-006 gives every cell a biome, a base temperature and a base precipitation that follow from its position. The zones
must appear in Earth-like order from cold to hot: polar, tundra, temperate, dry (savanna/desert), tropical. The field
must have no seam across the top/bottom and left/right edges (docs/PROJECT.md, docs/CONTRACT.md). Earth has one
equator and two poles that are not joined; a torus has no edges, so latitude cannot be a plain y-ramp.
Seasons and weather are out of scope (TASK-007); the climate built here is the base state they will modulate.

## Considered alternatives
1. **Equator in the middle row, poles on the top/bottom seam (chosen).** Latitude `phi(y) = 90 deg * cos^2(pi * u)` with
   `u = (y + 0.5) / H`. The seam is polar (both sides give `phi` near 90), the middle row is the equator, and the
   function is smooth and periodic in `y`. Cold rows sit at both edges, so the wrap joins two polar belts instead of
   a cold belt against a hot belt. Trade-off: the world has one equator and one polar seam, not two separate poles.
2. **Equator on the seam, poles in the middle row (`phi = 90 deg * sin^2(pi u)`).** Also seamless, but the hottest band
   is cut by the edge, so the tropics are split between the top and bottom rows of the window and the poles sit in
   the middle of the screen. Rejected: the default view would start in a tropical strip, which reads less like Earth.
3. **Hard latitude ramp `phi = 90 deg * |2y/H - 1|` with a clamp at the edges.** Not periodic: the seam would be a
   temperature cliff of about 90 degrees over one row. Rejected; it fails the seam requirement.
4. **Two independent hemispheres (two copies of an Earth-like ramp).** Hot equator in the middle and an extra pole pair
   would need two ramps joined at the seam. Same effect as option 1 with more code and no added realism for a grid.

## Decision
- **Coordinates.** `u(y) = (y + 0.5) / H` (cell centre, so the formulas hold for every `H >= 1`).
- **Latitude.** `phi(y) = 90 * cos^2(pi * u(y))` degrees, `0 <= phi <= 90`. It depends only on the row, so it is the same for
  all `x`. For `H = 1` the single row is the equator (`phi = 0`).
- **Biome from latitude only** (so it "follows from position" without noise). Thresholds on `phi`, half-open intervals:
  - `Tropical`: `phi < 20`
  - `Dry` (savanna/desert): `20 <= phi < 35`
  - `Temperate`: `35 <= phi < 55`
  - `Tundra`: `55 <= phi < 70`
  - `Polar`: `phi >= 70`
  Five zones, ordered `Polar < Tundra < Temperate < Dry < Tropical` by rank (cold to hot), with a rank function
  and `Ord`. The thresholds are constants in `climate.rs`, not config keys (no change to ADR-0006 in TASK-006).
- **Base temperature (deg C).** `T(phi) = 28 - 50 * (1 - cos(phi))`: 28 at the equator, about 13 at 45 degrees, -22 at the pole.
- **Base precipitation (mm per year).** `P(phi) = 150 + 1600 * exp(-(phi/14)^2) + 700 * exp(-((phi - 50)/14)^2)`:
  about 1750 at the equator, a dry dip of about 240 near 28 degrees, a temperate maximum near 850 at 50 degrees, and
  about 150 at the pole. Earth-like shape, not calibrated.
- **Seeded regional variation.** A fixed set of three to five terms `a_k * cos(2 pi (i_k * x / W + j_k * y / H) + f_k)` with
  integers `i_k, j_k` in `0..=3` (not both zero), drawn once at world creation from a generator seeded with
  `config.seed XOR CLIMATE_SALT`. Being built from integer wave numbers on `x/W` and `y/H`, the variation is exactly
  periodic on the torus, so it adds no seam. Amplitudes: temperature up to 2.5 deg C, precipitation up to 8 percent of the base.
  The parameters are stored in `Climate` so a checkpoint (TASK-008, TASK-022) can save them.
  The simulation generator is not used here, so creating the climate does not change the simulation random stream.
- **Storage.** `Climate` holds the `Torus` and a `Vec<CellClimate>` indexed by `Torus::index`:
  `latitude: f32`, `biome: Biome`, `temperature: f32`, `precipitation: f32`. Values are computed once at creation with
  `f64` math and stored as `f32`. Lookup is `Climate::at(cell: Cell)`, O(1), always on a wrapped `Cell`.
- **Compromise, for the documentation.** A torus has no edges, so Earth's latitude ramp cannot run from pole to pole
  across the world. We fold it: the top and bottom edges are the two polar belts, the middle row is the equator, and
  each half of the world is a hemisphere from pole to equator. The climate is therefore symmetric about the middle row
  and about the seam. Consequence: the world has one equator and no separate north and south pole. Left and right
  edges have no latitude change; only the seeded variation depends on x, and it is periodic.
- **Export without UI.** `Climate::biome_map_text()` returns one glyph per cell (`P` polar, `U` tundra, `T` temperate,
  `D` dry, `R` tropical), one text line per row, and `Climate::to_json()` returns the full field (`width`, `height`, rows of
  biome names and values). The CLI command `evosim climate --config FILE [--format text|json] [--out FILE]` prints
  the same output (stdout when `--out` is absent; the map is the requested output, not a log).
- **Small worlds.** All formulas are finite for every `W, H >= 1`. Tests cover `1x1`, `1xN`, `Nx1`, `2x2`, non-square and
  `200x3` worlds.

## Consequences
- Performance: creation is O(W*H) with a few `cos`/`exp` calls per row (per cell for the variation terms) and happens
  once. Lookups are O(1) and allocation-free. Memory is about 16 bytes per cell (for example 3 MB at 512x384).
- Determinism: the values depend only on `(W, H, seed)`. Transcendental functions come from the platform libm, used only
  at creation (ARCHITECTURE determinism rule 5). Same machine and build give identical bytes; cross-platform differences
  of the last bit are the allowed kind (docs/CONTRACT.md section 5).
- Testability: a seam test compares every pair of neighbours across the top/bottom and left/right edges with every other
  neighbour pair in the same world. The seam maximum must not exceed the interior maximum. The seam for temperature is
  in fact smaller, because the seam row is the flat top of the cosine profile.
- Dependencies: `climate` depends on `world` (Torus, Cell) and `rng` (seeded variation) only (ARCHITECTURE table).
- `dist/`: plain Rust, no crate added, compiled into the binary.
- Risks: the thresholds and formulas are a plausible shape, not a calibrated Earth model. A 1-row world is all equator;
  a 2-row world has both rows at 45 degrees. Biome cut-offs will change ecology once plants use them (TASK-011), so
  they are constants and this ADR must be updated before changing them.

## Verification strategy
- `cargo test -p evosim-core --locked` with tests in `climate.rs`:
  - biome order: along one column, from the seam to the equator, biome rank is non-decreasing and covers all five zones
    for `H >= 40`;
  - formulas: equator, 45 degrees and pole values of temperature and the dry dip of precipitation;
  - seam: for `(W, H)` in a grid of sizes including `1x1`, `1x7`, `7x1`, `2x2`, `64x48`, `200x3`, the maximum absolute
    difference of temperature, precipitation and latitude across top/bottom and left/right pairs is at most the maximum
    over all other neighbour pairs;
  - periodicity: the seeded variation is equal at `x = 0` and `x = W` and at `y = 0` and `y = H` (exact up to f32);
  - seed: same seed gives identical fields; different seeds give different variation;
  - export: `biome_map_text` has `H` lines of `W` glyphs; `to_json` parses (the test uses a small hand-written check).
- CLI: `./evosim climate --config scenarios/... ` (or a config file from tests) exit 0, and `--format bogus` exit 2.
- `bash scripts/check_adrs.sh` (ADR-0009 added to the checked list) and `bash scripts/test.sh` exit 0.

## Implementation notes (TASK-006 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/climate.rs` (`Biome`, `CellClimate`, `WaveTerm`, `Climate`, formulas, `biome_map_text`,
  `to_json`); `sim.rs`: `World` gains `climate`, built in `Simulation::new` from `config.seed`; `World` and `Simulation`
  lose `Eq` (f32 fields). CLI: `evosim climate --config FILE [--format text|json] [--out FILE]` in `args.rs` and `main.rs`.
- Deviation from the plan text: the variation terms store a normalised `weight` (weights sum to 1) instead of separate
  temperature and precipitation amplitudes. The amplitudes are constants: 2.5 degrees C and 8 percent. Same bounds as above.
- Documented temperature bounds are `-25..=31` C (not `-25..=30`): the equator base of 28 C plus the 2.5 C variation
  reaches 30.5 C.
- Worlds of any size build: `1x1` is a single tropical cell (equator). The zone-order test uses `H = 60`.
- Seam test: the maximum difference of latitude, temperature and precipitation over top/bottom and left/right pairs is no
  larger than over all interior pairs, for seven sizes and three seeds.

# ADR-0006: Configuration format, parameters, validation and presets

Status: Accepted (drafted in TASK-003 PLAN cycle 1, implemented in IMPLEMENT cycles 1 and 2, confirmed in TASK-003 REVIEW cycle 2).

## Context
TASK-003 defines the simulation configuration: the fixed keys of `docs/CONTRACT.md` section 3 (`seed`,
`world.width`, `world.height`, `initial.plants|herbivores|carnivores`), every further tunable parameter with a type,
a valid range and a default, validation that names the offending key, a lossless JSON round trip, and at least three
built-in presets selectable by name. The configuration is read by `./evosim run` (TASK-019), `batch` (TASK-021) and
`ui --config` (TASK-024); this task does not use the parameters in the simulation. The core has no third-party JSON
crate (ADR-0001), so the reader and writer are hand-written. The numeric defaults for genetics and species are the
placeholders named in ADR-0004 and `docs/STATE.md`; they are calibrated later (TASK-009).

## Considered alternatives
1. **JSON only, hand-written reader/writer in `core::config::json`.** Matches ADR-0001 (no serde), needs no
   dependency, and the contract requires JSON. Trade-off: about 300 lines of parser to test; limited to JSON syntax.
2. **TOML or YAML in addition.** Nicer for humans but needs a parser crate (TOML/YAML crates are not allowed by
   ADR-0001) or another hand-written grammar. Deferred: the contract only requires JSON; the decision to add a
   second format can be taken later without changing this record's structure.
3. **Flat key list (`plant_growth_rate`, ...).** Simple to parse, but the fixed keys are nested (`world.width`), and a
   flat namespace mixes species. Rejected in favour of one nested object per group.
4. **Unknown keys ignored.** Lenient and forward compatible, but a typo such as `"climat"` silently keeps the default
   and the benchmark's results would not reflect the file. Rejected.

## Decision
**Format.** UTF-8 JSON object. Integer parameters take JSON numbers without fraction or exponent; a real
number (with `.` or an exponent, e.g. `64.0`) is a wrong-type error for them. Real parameters take either a JSON
integer (`1` is read as `1.0`) or a real number. Strings, booleans, null, arrays and objects are never valid for a
parameter. Duplicate keys are an error. Parse errors give line and column and no key.

**Unknown keys are an error.** Any key that is not a documented parameter is rejected with its full dotted path,
e.g. `config key "climate.weathr": unknown key`.

**Missing keys.** The fixed keys are required: `seed`, `world`, `world.width`, `world.height`, `initial`,
`initial.plants`, `initial.herbivores`, `initial.carnivores`. Every other parameter and every group may be absent
and then takes its default.

**Parameters.** Dotted key -> type, range (inclusive), default:

| Key | Type | Range | Default | Meaning |
|---|---|---|---|---|
| `seed` (fixed) | integer | 0 .. 2^64-1 | required | RNG seed (negative values are out of range) |
| `world.width` (fixed) | integer | 1 .. 4096 | required | cells in x; `width*height <= 16777216` holds by construction (both sides capped at 4096), so no separate cross-field check |
| `world.height` (fixed) | integer | 1 .. 4096 | required | cells in y |
| `initial.plants` (fixed) | integer | 0 .. 1000000 | required | plants at tick 0 |
| `initial.herbivores` (fixed) | integer | 0 .. 1000000 | required | herbivores at tick 0 |
| `initial.carnivores` (fixed) | integer | 0 .. 1000000 | required | carnivores at tick 0 |
| `climate.season_length` | integer | 1 .. 100000 | 240 | ticks per seasonal cycle |
| `climate.weather_amplitude` | real | 0.0 .. 1.0 | 0.15 | size of weather variation relative to the seasonal swing |
| `plants.growth_rate` | real | 0.0 .. 1.0 | 0.1 | fraction of the energy deficit regained per tick |
| `plants.reproduction_chance` | real | 0.0 .. 1.0 | 0.05 | chance per tick of seeding when mature |
| `plants.seed_radius` | integer | 0 .. 16 | 2 | dispersal radius in cells (torus distance) |
| `plants.max_age` | integer | 1 .. 100000 | 500 | ticks |
| `herbivores.metabolism` | real | 0.0 .. 100.0 | 0.8 | energy spent per tick |
| `herbivores.reproduction_energy` | real | 0.0 .. 1000.0 | 60.0 | energy needed to breed |
| `herbivores.max_age` | integer | 1 .. 100000 | 300 | ticks |
| `carnivores.metabolism` | real | 0.0 .. 100.0 | 1.2 | energy spent per tick |
| `carnivores.reproduction_energy` | real | 0.0 .. 1000.0 | 90.0 | energy needed to breed |
| `carnivores.max_age` | integer | 1 .. 100000 | 400 | ticks |
| `genetics.mutation_rate` | real | 0.0 .. 1.0 | 0.002 | per locus, per reproduction (ADR-0004) |
| `genetics.mutation_strength` | integer | 1 .. 255 | 8 | largest step per mutation (ADR-0004) |
| `species.distance` | real | 0.0 .. 1.0 | 0.06 | genetic distance threshold (ADR-0004 `species_distance`) |
| `species.check_interval` | integer | 1 .. 10000 | 25 | ticks between species checks (ADR-0004) |
| `species.persistence_checks` | integer | 1 .. 1000 | 4 | consecutive checks needed to recognise a species (ADR-0004) |

Groups: `climate`, `plants`, `herbivores`, `carnivores`, `genetics`, `species`. Ranges are checked per key. There are no cross-field
rules; energy values are not checked against each other (an energy above
`*_max` is not a configuration error; the simulation caps it in TASK-011 or later).

**Validation.** One function (`from_fields` in `config.rs`) runs for every load, every preset and every `Config::new`. The
first failure is returned as `ConfigError { key: Option<String>, message: String }`, whose `Display` contains the
key, for example `config key "initial.plants": expected integer, found string`,
`config key "world.width": 0 is out of range 1..=4096`, `config key "world": missing required key "height"` (the
key names the missing path, `world.height`). Non-finite reals (`1e400`) are out of range.

**Serialization.** `to_json()` writes every parameter in the fixed order of the table above, two-space indent,
reals with Rust's shortest round-trip `Debug` formatting (always with `.` or an exponent). Therefore
`from_json(to_json(c)) == c` for every valid `c` (tested with `PartialEq`).

**Presets.** Four built-in configurations, each valid and selectable by name with `config::presets::get(name)`;
`config::presets::NAMES` lists them:
- `balanced`: the contract example (64x48, 400 plants, 120 herbivores, 20 carnivores) with all defaults.
- `arid`: same world and start, but `plants.growth_rate` 0.04, `climate.weather_amplitude` 0.45,
  `climate.season_length` 120: scarce and fluctuating food.
- `continent`: 128x96 world, 1600 plants, 500 herbivores, 80 carnivores, `genetics.mutation_rate` 0.005,
  `genetics.mutation_strength` 16, `species.distance` 0.08: larger, more variable populations.
- `herbivore-only`: 64x48 world, 400 plants, 120 herbivores, 0 carnivores: shows a food chain without predators.

Selection by name in the CLI (`--preset`) is not part of this record; TASK-019 and TASK-024 decide how to expose it.

**Files.** `crates/evosim-core/src/config.rs` (types, defaults, validation, `Config::new`, `from_json`, `to_json`,
`load`/`save` taking a path), `config/json.rs` (value parser and canonical writer), `config/presets.rs`,
`config/tests.rs`. `core` keeps the filesystem access to these two functions only (ARCHITECTURE).

## Consequences
- Every parameter has a default, so `{"seed":42,"world":{"width":64,"height":48},"initial":{...}}` is valid.
- Strict unknown-key handling means config files written for a later version of the product are rejected by an
  older one. Acceptable: the product is not yet released, and the error names the key.
- Defaults for `genetics.*` and `species.*` are the ADR-0004 placeholders; changing them later changes `state_hash`
  for the same seed, which is allowed (a configuration change, not a determinism break).
- Hand-written JSON adds a parser that must be tested; the test list is in `tasks/TASK-003/handoffs/plan-cycle1.md`.
- Performance: configuration is read once per run; no effect on the tick loop.
- `dist/`: no new file or runtime dependency; the presets are compiled into the binary, so `dist/evosim` needs no
  data file beside it.

## Verification strategy
- `cargo test -p evosim-core --locked` (unit tests in `config/tests.rs`): each error class (wrong type, missing
  fixed key, out of range, unknown key, parse error, duplicate key, non-finite real), zero initial populations,
  a file with only the fixed keys, round trip for defaults and each preset, preset names and lookup, preset
  distinctness (pairwise different in at least one fixed-or-tuned parameter, and each valid).
- `cargo test --workspace --locked` and `bash scripts/test.sh` must still exit 0.
- `bash scripts/check_adrs.sh` must still exit 0 (this record has all six required headings).

## Implementation notes (TASK-003 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/config.rs`, `config/json.rs`, `config/presets.rs`, `config/tests.rs` (35 unit tests).
  The status stays Proposed until TASK-003 REVIEW confirms it.
- Herbivores and carnivores share one struct type, `config::Animal`, because their parameters are identical; the
  defaults differ and are set per group in `from_fields`.
- All integer parameters are stored as `u64`, reals as `f64`.
- Validation is in one place: `from_fields`. `Config::new`, `from_json`, `load` and every preset go through it.
  The presets are JSON texts, so they are validated by the same path as user files.
- The cell cap is not a separate check: both sides are capped at 4096, so `width * height <= 16777216` always holds.
- Missing-key errors name the missing path (for a missing `world` object, the key is `world.width`).
- Parser: recursion depth limit 64. Surrogate pairs (`😀`) decode to one scalar; lone or misordered surrogates are rejected (IMPLEMENT cycle 2, see below). Integers beyond i128 are not parse errors (IMPLEMENT cycle 2).

## Implementation notes (TASK-003 IMPLEMENT cycle 2)
- Closes REVIEW cycle 1 gaps G-019, G-020, G-016 and G-021 wording. The plan decisions above are implemented as written.
- `json::Value::BigInt(String)` holds an integer literal that does not fit `i128`, text kept with its sign. `int()` reports
  it as `config key "<key>": <literal> is out of range <min>..=<max>`; `real()` parses it as `f64` (infinity when too large,
  which fails the range check); any other kind reports `found integer`.
- Surrogate pairs are combined as `0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00)`. A high surrogate without a following
  low escape, or a low surrogate on its own, is a parse error with line and column.
- `Config::save` creates missing parent directories before writing.
- Tests: 43 in `config/tests.rs` (plus the contract test) (the old `json_integer_too_large_is_error` is replaced by `json_big_integer_is_kept_as_text`).
- Status stays Proposed until TASK-003 REVIEW.

## Plan decisions (TASK-003 PLAN cycle 2, closing REVIEW cycle 1 gaps)
- **G-019 (integers beyond i128).** The parser no longer fails on an integer literal that does not fit `i128`. It
  yields `Value::BigInt(text)` (the literal, with its sign, as written). A `BigInt` for an integer key is a range error
  `config key "<key>": <literal> is out of range <min>..=<max>`, so the key is named. For a real key it is read as
  `f64` (an out-of-range magnitude becomes `inf` and is rejected as out of range). For a non-numeric key it is a wrong-type
  error that says `found integer`. Syntax errors keep their line and column.
- **G-020 (surrogate pairs).** A high surrogate escape `\uD800..\uDBFF` must be followed by a low escape
  `\uDC00..\uDFFF`; the pair decodes to one scalar value. A lone or misordered surrogate is a parse error with
  line and column.
- **G-021 (naming).** The validation function is `from_fields`; this record now says so. The status becomes Accepted
  only in REVIEW, after the gaps are closed by reading the code and tests.
- **G-016 (save into a new directory).** `Config::save` creates the missing parent directories before writing. The CLI
  task (TASK-019) still owns the user-facing error text.

**Amendment (TASK-018 IMPLEMENT cycle 1, ADR-0019).** Changed default: `plants.max_age` 500 to 1500 (`DEFAULT_PLANTS_MAX_AGE`);
the `*.max_age` keys now set the lifespan centre of each kind (ADR-0011 amendment). Not used by the engine (kept in the file
format, no effect): `plants.growth_rate` (superseded by ADR-0012 `REGEN_RATE`), `herbivores.metabolism` and `carnivores.metabolism`
(superseded by the base costs in ADR-0015 and ADR-0016). Wiring or removing them is a later decision (TASK-027).

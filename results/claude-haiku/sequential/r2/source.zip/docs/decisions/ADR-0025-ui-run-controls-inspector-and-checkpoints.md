# ADR-0025: UI run controls, inspector and checkpoint files

Status: Accepted (drafted in TASK-024 PLAN cycle 1; accepted at TASK-024 REVIEW cycle 1 PASS).

## Context
TASK-024 (`tasks/TASK-024/task.md`) lets the user steer the simulation in `evosim ui` and look inside any organism:
run, pause, single step, reset, speed; selecting an organism in the world view opens an inspector that follows it and
shows when it has died; the state is saved to and loaded from a checkpoint file from the page. ADR-0024 deliberately
added no command endpoint and reserved `#controls` and `#inspector` (D6). This ADR decides the parts ADR-0024 leaves open.

Facts from the code that shape the design:
- `Entities::deaths_phase` removes dead organisms from the store (`entities.rs`). A dead organism cannot be looked up
  afterwards, so the cause and tick of a death are only visible in `Entities::last_deaths()` for one tick.
- `checkpoint::write_file(sim, seed) -> Vec<u8>` and `checkpoint::read_file(bytes) -> Result<Checkpoint, _>` already exist
  (ADR-0023). The UI needs no new core code.
- `Simulation::new` does not place founders; `populate_initial` must be called (ADR-0024 D1 note, TASK-023).
- The HTTP server (ADR-0024 D2) is GET-only and reads no request body. The climate (`/api/climate`) is fixed at start.
- `evosim-core` must not change for this task.

## Considered alternatives
1. **Client-side control and inspector, with the server only exposing read APIs (rejected).** The server would still need to
   know the death of a followed organism, and pause/step/reset need the simulation thread anyway.
2. **Commands through a shared lock on the `Simulation` (rejected).** The simulation thread would block HTTP threads for each
   tick. The command queue below keeps the lock-free publish of ADR-0024 D2.
3. **Command queue owned by the simulation thread, all control logic in a pure `Session` type (chosen).** HTTP threads send a
   command with a reply channel; the simulation thread applies commands between ticks, so every command sees a consistent
   state. The control rules are a plain struct that tests can drive without threads, sockets or a display.
4. **Dead-organism record kept by the core (rejected).** Would change `evosim-core` and grow memory with every death. The
   watch record below holds one death, for the followed organism only.

## Decision
D1. **Control model (`Session`, `crates/evosim-ui/src/control.rs`).** `Session` owns the `Simulation`, the configuration origin
  (`Config`), the current seed, a `running: bool`, `speed_index: usize`, `pending_steps: u64` and the watch record (D4).
  Operations: `run()`, `pause()`, `step()`, `reset()`, `faster()`, `slower()`, `select(id)`, `deselect()`,
  `load(bytes)`, `save() -> Vec<u8>`, and `pump(due_ticks: u64)` which advances the simulation.
  - Run and pause only set `running`. Ticks happen only in `pump`.
  - Step adds one pending step and is refused while running (the page then pauses first). A step advances exactly one tick
    (acceptance criterion) and is then published.
  - `pump`: while `running`, the simulation thread computes how many ticks are due from the elapsed time and the speed; while
    paused, it advances only pending steps.
  - Speed levels are fixed: `SPEED_LEVELS = [1, 5, 20, 60]` ticks per second, default index 2 (20, the value of
    `UI_TICKS_PER_SECOND` today). `faster`/`slower` clamp the index to `0..SPEED_LEVELS.len()`; no level is zero or negative.
  - Reset: rebuilds the world from `Config` (the configuration the session started with, including its seed) with
    `Simulation::new` and `populate_initial`. It keeps the run/pause state, sets tick 0, clears the watch, and bumps the
    climate version (D3). Two resets give identical starting states, checked by `checkpoint::state_hash`.
  - Load: `checkpoint::read_file` validates the bytes (ADR-0023 D2). On success the session takes the restored simulation and
    its seed, keeps run/pause state, clears the watch, and bumps the climate version. On failure the session is unchanged and
    the message is returned to the page. A loaded checkpoint replaces the current world; reset still rebuilds the configuration
    the session started with (checkpoints do not store the configuration).
  - Save: `checkpoint::write_file(sim, seed)`, the same bytes as `--save`.

D2. **Command transport.** `Shared` (ADR-0024 D2) gains an `mpsc::Sender<Command>`; each `Command` carries a reply
  `mpsc::Sender<Reply>`. The HTTP thread sends the command and waits up to 5 s for the reply (a timeout is HTTP 503). The
  simulation thread drains commands before every tick and while paused. Routes:
  - `POST /api/command` with an `application/x-www-form-urlencoded` body: `action=run|pause|step|reset|faster|slower|select|deselect`
    and `id=N` for `select`. Unknown action or missing `id` is HTTP 400; the reply is JSON `{"ok":true}` or `{"ok":false,"error":"..."}`.
  - `GET /api/checkpoint` returns the checkpoint bytes with `Content-Type: application/octet-stream` and
    `Content-Disposition: attachment; filename="evosim-tick-<tick>.evockpt"`.
  - `POST /api/checkpoint` with a raw binary body (`Content-Length` required, at most 64 MiB, otherwise HTTP 413). The reply is
    JSON; an invalid file is HTTP 422 with the `CheckpointError` text and the session unchanged.
  - `GET /api/organism?id=N` returns the watch record (D4). Unknown or never-existing id: HTTP 404.
  The request parser reads the body (up to `Content-Length`) and rejects bodies over the limit before reading them. Other
  methods keep HTTP 405. The query string is still ignored for the other routes.

D3. **Published state.** `/api/state` gains `"control":{"running":bool,"speed":N,"speed_index":i,"speeds":[1,5,20,60],
  "selected":id|null,"seed":N,"climate_version":V}`. `climate_version` changes after a reset or load; the page refetches
  `/api/climate` when it changes, because a loaded checkpoint can have another world size. `Shared.climate` becomes replaceable
  (published with the state). `counts` and `organisms` (ADR-0024 D4) are unchanged. Snapshot cost stays linear; it is built once
  per tick, as today.

D4. **Inspector and death record.** When an organism is selected, the simulation thread checks it after every tick:
  - if it is alive, the watch stores its detail JSON (the latest published `/api/organism` body);
  - if `Entities::last_deaths()` contains its id, the watch stores that `Death` (tick, cause, cell) and keeps the last detail
    seen while alive.
  The detail JSON (built by a pure function in `crates/evosim-ui/src/inspector.rs`) contains: `id`, `kind` (name and code),
  `species` (id and name from `SpeciesRegistry::record`, or `null` before the founding check), `age`, `energy`, `health`,
  `traits` (speed, strength, fertility, max_lifespan, max_health; animals add aggression, caution, vision), `genome`
  (`ploidy`, `loci` as hex per haplotype, `slot_means` per trait slot, 8 values, from `Genome::trait_means`), `parents`
  (ids or `null`, `generation`), `cell`, and `status`: `"alive"` or `"dead"` with `death: {tick, cause, cell}`. Founders show
  `parents: [null, null]`. Clearing the selection drops the watch.
  Dead organisms with an unknown id that was never selected are not reported (404).

D5. **Page.**
  - Controls in `#controls`: Run/Pause toggle, Step (enabled only when paused), Reset, Slower/Faster with the current speed
    label. Shortcuts: Space run/pause, `.` or `n` step, `r` reset, `-` and `+` speed, `Esc` clear selection. Shortcuts are ignored
    while a text input has focus.
  - Selection: a click (pointer moved less than 4 px) on the canvas selects the nearest living organism within 6 px of its drawn
    position (using the ADR-0024 D5 offsets). The selected organism gets a highlight ring. The inspector polls
    `/api/organism?id=` at the state rate.
  - Inspector in `#inspector`: header (id, kind, species), status line (alive, or "died at tick T: cause, cell"), age, energy and
    health bars, traits, tendencies and vision for animals, eight genome slot bars with per-haplotype hex, and parents as buttons
    that select that parent.
  - Checkpoint in `#controls`: Save is a link with the `download` attribute to `GET /api/checkpoint`; Load is a file input that
    POSTs the chosen file to `/api/checkpoint`. A status line shows the result of each action.
  - Each action shows its result in a status line; no alert dialogs.

D6. **Tests without a display.** `control.rs` and `inspector.rs` are plain Rust and are tested in `cargo test -p evosim-ui`:
  - `step` advances exactly one tick from paused, and one tick from running after a pause;
  - `pump` with paused state and any elapsed time advances no tick unless steps are pending;
  - speed index stays in range after any number of `faster`/`slower` calls; speeds are all at least 1;
  - reset twice gives the same `state_hash` at tick 0, and after N steps the same hash as a fresh session stepped N times;
  - select a living organism, run until it dies: `status` is `dead` with the tick and cause of the `last_deaths` record, and the
    last alive detail is kept;
  - select of an unknown or dead id is an error and leaves the watch unchanged;
  - save at tick k, continue the session to k+B, load the bytes into a second session and run B ticks: equal `state_hash`;
    invalid bytes (truncated, flipped byte) leave the session unchanged;
  - load and reset bump `climate_version` and clear the watch;
  - inspector JSON contains every required field, and `slot_means` equals `Genome::trait_means`.
  Route tests in `server.rs` cover: `POST /api/command` bad action (400), missing `id` (400), body over the limit (413), `GET` on
  command routes (405), unknown organism id (404).

D7. **Verification of the page.** `scripts/ui_check.sh` keeps its existing checks. IMPLEMENT extends `?check=1` with a control
  check (synthetic click on Step while paused increases the tick by exactly 1; Run then Pause). This is a synthetic-event check,
  recorded as such (ADR-0024 D10). The smoke test and the screenshots keep working: the session starts running at speed index 2.

## Consequences
- `evosim-core` is unchanged. The UI thread holds the only `Simulation`; HTTP threads never touch it.
- The death record costs one `Death` per watched organism; memory does not grow with the number of deaths.
- A checkpoint loaded into the UI can have a different size than the world the page showed; the climate version covers that.
- Reset returns to the configuration, not to the checkpoint that was loaded (recorded as a decision for TASK-024; a
  "reset to loaded checkpoint" would need the checkpoint bytes kept in memory).
- The POST body reader is new code in the std-only HTTP server; its limits are checked before the body is read.
- ADR-0025 is listed in `scripts/check_adrs.sh` in IMPLEMENT (the checker requires a `Status:` line).
- Performance: a control command waits for the simulation thread between ticks; at most one tick (about 0.8 ms at
  1,000 organisms) plus the publish delays a reply. A tick at speed 60 is measured in STATE.md, not assumed. The pump runs
  at most 120 ticks per pass (`MAX_TICKS_PER_PUMP`), so a stall never freezes the page for long.
- Testability: `control.rs` and `inspector.rs` are plain Rust and run in `cargo test -p evosim-ui` with no display; the HTTP
  routes are tested with a stand-in simulation thread and one real socket test (413); `scripts/control_check.py` drives the
  built binary over HTTP (synthetic, no page buttons).
- Dist: `dist/` is not affected; the control code is part of `evosim-ui`, built by `./build.sh` into `dist/evosim`.

### Implementation notes (IMPLEMENT cycle 1, deviations from the Proposed text)
- A step is applied at once inside `Session::step` (one tick, refused while running); there is no pending-step queue.
- `/api/organism?id=N` returns `{"id","status","death","organism"}`: `organism` is the detail with the last values seen
  alive; `status` is `alive` or `dead`. The detail does not carry the status keys itself.
- Command errors: `POST /api/command` answers HTTP 200 with `{"ok":false,"error":...}` for a refused command; 400 for a
  bad action or a missing id; 503 when the simulation does not answer within 5 s. Checkpoint upload: 422 for an invalid
  file, 413 over 64 MiB, 503 on timeout. Checkpoint download failures other than 503 are 500.
- The request parser ignores `Transfer-Encoding`; only `Content-Length` bodies are read.

## Verification strategy
As D6 and D7, plus the existing gates: `cargo test --workspace --locked --offline`, `cargo clippy -p evosim-ui --all-targets`,
`bash scripts/check_adrs.sh`, `./build.sh`, `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR` (main.png required;
`inspector.png` optional), `scripts/ui_check.sh`, `git remote -v | wc -l` = 0.

### Review evidence (TASK-024 REVIEW cycle 1)
- The page was driven in headless Chromium over CDP with real mouse and key events
  (`tasks/TASK-024/handoffs/review-evidence/review_ui_browser_check.py`, 40/40 checks): Run/Pause, Step (exactly one tick,
  also via `.`), Space, Faster/Slower with clamps at 1 and 60, Reset to tick 0, click selection, inspector fields, follow
  while running, death shown as `died at tick 14: predation`, Escape, checkpoint download and reload, invalid upload reported.
- Speed 60 measured over 5 s with `/api/state` sampling: 59.8 ticks/s.
- Inspector is in the sidebar below the legend and needs a scroll at 1280x807; a layout choice, not a criterion.

# ADR-0024: UI world view, live snapshot API and drawing

Status: Accepted (drafted in TASK-023 PLAN cycle 1; set to Accepted at TASK-023 REVIEW cycle 3 PASS. M5 is accepted on D14 (a) and (b); D14 (c) sustained 1,000 is not claimed, see REVIEW cycle 3).

## Context
TASK-023 adds `evosim ui` with a live world view: every cell coloured by climate or biome, living organisms drawn on top
with plants, herbivores and carnivores told apart at a glance, a legend, pan and zoom, and at least several view updates per
second with 1,000 organisms. `evosim ui --smoke-test` and `--screenshots DIR` must run without user input (CONTRACT section 2).
ADR-0002 already fixes the technology: a local browser page served by the `evosim` binary, using the container's
`chromium` 131 for the smoke test and the screenshot. This ADR decides the parts ADR-0002 leaves open: the snapshot
contract between the simulation thread and the page, what is drawn and how, and the test mechanics.

Run controls, inspector, parameter editing and charts are out of scope (TASK-024, TASK-025). Their space is reserved in the
layout (D6), but no API for them is added here.

## Considered alternatives

Drawing options (the list below).

1. **Canvas 2D, base layer pre-rendered once, organisms drawn each frame (chosen).** Simple, fast enough for 5,000 glyphs,
   no WebGL dependency; the base layer is an offscreen canvas redrawn only when the climate layer changes.
2. **WebGL.** Faster for very large worlds, but more code, and software WebGL under headless Chromium is less predictable
   for the screenshot path.
3. **SVG.** One DOM node per organism: too slow at 1,000+ updates per second of the DOM.
4. **Server-rendered PNG per frame.** Would make the screenshot path the same as the live path, but costs a PNG encode per
   frame and gives no interactive pan and zoom. Rejected.

## Decision
D1. **Entry point.** `evosim ui [--config FILE] [--port N]`, `evosim ui --smoke-test [--config FILE]`, and
`evosim ui --screenshots DIR [--config FILE]`. The CLI (`evosim-cli`) parses the arguments and calls `evosim_ui::run`. Without
`--config` the built-in default is the example configuration of CONTRACT section 3 (64x48, 400 plants, 120 herbivores,
20 carnivores, seed 42). Invalid arguments and a missing or invalid configuration exit 2. `--smoke-test` and `--screenshots`
are mutually exclusive. `DIR` must exist (CONTRACT section 2), otherwise exit 2. `--port` defaults to 0 (ephemeral).

D2. **Server and threads.** `std::net::TcpListener` bound to `127.0.0.1` only. Routes: `GET /` (embedded page),
`GET /app.js`, `GET /style.css`, `GET /api/climate` (static base layer, sent once per page load), `GET /api/state`
(live snapshot). Unknown routes give 404. No new crate: no async runtime, no serde. One simulation thread owns the
`Simulation`; it ticks, then builds the snapshot bytes and replaces an `Arc<Vec<u8>>` under a `Mutex` (the lock is held only
for the swap). HTTP worker threads clone the `Arc` and write it out. The simulation thread paces itself to
`UI_TICKS_PER_SECOND = 20` (wall clock is used only for pacing, ARCHITECTURE "Clocks and time"). No command endpoint exists yet.

D3. **Climate layer.** The base climate is static (ADR-0009: no change over time). `/api/climate` returns
`{"width":W,"height":H,"biome":"<W*H glyphs, row-major, one of P U T D R>"}`. Seasonal temperature and weather are not drawn in
this task; they may be added as an overlay in a later task without changing this contract.

D4. **Snapshot (`/api/state`).** JSON object with: `"tick"`, `"counts"` (`plants`, `herbivores`, `carnivores`, living
per kind), and `"organisms"`, a flat array of `[id, kind, x, y]` with `kind` 0 plant, 1 herbivore, 2 carnivore, in ascending
id order (`Entities::living()` order). The snapshot is a sample of living organisms only and is capped at 10,000 entries
(not reached by the contract's 1,000 to 5,000 target). Traits and genomes are not in the snapshot; the inspector of TASK-024
adds its own endpoint.

D5. **Drawing.** Canvas 2D.
- Base: each cell is a filled rectangle in its biome colour from a palette in `style.css`/`app.js`. The palette is a design
  choice and may change without a new ADR.
- Organisms are drawn above the base in three distinct shapes and colours so they are distinguishable without colour
  (colour-blind safe pairing): plant = small filled square (green), herbivore = filled circle (amber), carnivore = filled
  triangle (red). Shape size scales with zoom and is clamped to a minimum of 2 px.
- Organisms in the same cell are placed at deterministic offsets derived from their id (a hash of the id into the cell), so
  stacks are visible. Offsets are a display detail and do not change the simulation.
- Pan: drag with the mouse. Zoom: wheel, centred on the cursor, clamped to 2 to 64 px per cell. Default: fit the world into
  the canvas. Double-click resets to fit.
- Legend: a fixed panel listing the five biome colours and the three organism shapes with their names.
- Update: the page polls `/api/state` five times per second (200 ms) and redraws on each response and on each animation
  frame when the view changes (pan, zoom, resize).

D6. **Layout reserved for later tasks.** Header bar (title, tick, living counts per kind), main canvas (left and centre), right
sidebar (legend now; empty containers `#controls` and `#inspector` for TASK-024), bottom strip `#charts` (empty, for
TASK-025). Layout is plain and may be restyled; these element ids are part of the contract for later tasks.

D7. **Smoke test (`--smoke-test`).** The driver starts the server, waits until the simulation thread reaches tick 10, then runs
`chromium --headless --no-sandbox --disable-gpu --window-size=1280,720 --virtual-time-budget=5000 --dump-dom URL?smoke=1`.
In smoke mode the page loads the climate, polls state until `tick >= 10`, draws at least one frame and writes
`<title>smoke frames=N tick=T</title>` (N >= 1, T >= 10). The driver accepts exit 0 only when that marker is found. The total
budget is 60 s; the Chromium child is killed at 50 s, and the command then exits 1 with a message. Chromium is found by
`CHROME_BIN` if set, otherwise `chromium` on PATH.

D8. **Screenshots (`--screenshots DIR`).** The driver waits until tick >= 100 (the simulation thread runs at its normal pace,
so this takes about 5 s at 20 ticks/s; the 120 s budget is kept), then runs
`chromium --headless --no-sandbox --disable-gpu --window-size=1280,720 --virtual-time-budget=5000 --screenshot=DIR/main.png URL?shot=1`.
Shot mode disables the poll timer after the first two frames so the screenshot is stable. The image comes from the real page.
Optional extra views are not part of this task.

D9. **Performance target.** 1,000 organisms: the snapshot is built and encoded on the simulation thread in well under 5 ms
(to be measured and recorded); the page stays responsive at 60 fps on the container's software renderer (measured with a
real-time, non-virtual-time headless run if practical, otherwise recorded as not measured). The simulation rate is not
reduced by the UI thread (the UI never blocks it).

## Consequences
- The UI depends on `evosim-core` only. `evosim-core` does not reference UI or CLI crates (check_adrs.sh keeps this).
- `dist/evosim ui` is optional (CONTRACT section 2); it works for the live server if assets are embedded, which they are.
- Smoke and screenshot require Chromium (container standard, recorded in `docs/STATE.md`). The live server does not.
- Snapshot cost grows linearly with organisms; sampling is the later safeguard if the cap is reached.

## Verification strategy
- Testability: the route table and snapshot encoders are pure functions, so they are unit-tested without a socket or a browser;
  the page's behaviour is checked in headless Chromium by `?check=1` and by `scripts/ui_fps.py` (D14, D15).
- Rust unit tests: route table, 404, snapshot JSON (tick, counts, organisms order and kind codes, cap), climate string length
  and glyphs, argument parsing (exit 2 for invalid combinations), pacing loop reaching tick 10 and 100.
- Integration: `evosim ui` on an ephemeral port answers `/api/state` with increasing tick (test without chromium).
- `./evosim ui --smoke-test` exit 0 in under 60 s, and `./evosim ui --screenshots DIR` writes `main.png` whose IHDR gives
  at least 1280x720 (checked by a small PNG header reader in a script).
- 1,000-organism run: snapshot timing recorded with a test or command, and the tick rate recorded.

## PLAN cycle 2 amendments (after REVIEW cycle 1 FAIL)
Status stays Proposed until REVIEW PASS. The decisions D1 to D9 stand; the following are added.

D10. **Read-only test hook.** The page exposes `window.evosim` with `view()` (scale, ox, oy, fit, cssW, cssH, worldW, worldH),
`stats()` (polls, frames, lastTick, living, updates per second) and `timing(n)` (mean ms of n redraws of the current state, no state
change). No command endpoint is added (TASK-024 owns commands).

D11. **Recorded interaction check.** `scripts/ui_check.py` (run with `python3 -I`) drives headless Chromium through the DevTools
Protocol with a Python stdlib WebSocket client (Node 18 has no WebSocket; no pip package). It checks drag pan (offset changes by the
drag delta, fit off), wheel zoom anchored at the cursor (world point under the cursor stays within 0.5 px), zoom clamp 2 to 64 px per
cell, double-click fit, and the real-time rate of state responses (at least 3 per second over 10 s wall clock, no virtual time), with
the minimum living count in that window. Exit 0 only when all checks pass.

D12. **Sustained 1,000-organism configuration.** `examples/ui-1000.json` uses only existing keys and fixed keys. It is chosen by a
sweep with `evosim run --ticks 600 --sample-every 10` so that living stays at or above 1,000 at every sample for seeds 42 and one more
seed. The engine is not changed. If no candidate qualifies, the best candidate is used and the requirement is recorded as not met.

D13. **Driver budgets.** Smoke: tick 10 within 10 s, Chromium within 35 s. Screenshots: tick 100 within 30 s, Chromium within 60 s.
Worst cases stay within the CONTRACT budgets (60 s and 120 s).


## IMPLEMENT cycle 2 additions (D10 to D13)
- **D10 Test hook.** `window.evosim.view()` and `.stats()` are read-only. The page check mode `?check=1` dispatches synthetic events and writes `check=PASS|FAIL` to the title. Synthetic events, not OS input: this is recorded as a limitation.
- **D11 Interaction check.** `scripts/ui_check.sh [CONFIG]` runs the check against the real server in headless Chromium, then measures the state poll rate over 10 s wall clock (threshold 3/s). Exit 0 only if both pass.
- **D12 Configuration.** `examples/ui-1000.json` starts at 1,000 organisms. The sweep found no configuration that keeps 1,000 alive for 600 ticks (herbivores and carnivores die out), so M5 is not met. The engine was not changed.
- **D13 Timeouts.** Smoke: 10 s wait + 35 s Chromium. Screenshots: 30 s wait + 60 s Chromium. Worst cases 45 s and 90 s, within the CONTRACT budgets of 60 s and 120 s.
- Status stays Proposed until REVIEW PASS.

## PLAN cycle 3 amendments (after REVIEW cycle 2 FAIL, gap G2/M5 and G4)
Status stays Proposed until REVIEW PASS. D1 to D13 stand. Probe (scratch, not in the repo): `chromium --headless --dump-dom`
returns at load and does not wait for `setTimeout` or `requestAnimationFrame` counts, so a real-time frame rate needs the DevTools
Protocol (`--remote-debugging-port`), not `--dump-dom`.

D14. **What M5 measures.** M5 has two parts, measured separately and reported separately:
- (a) View cost at 1,000 organisms (renderer only): page mode `?fixture=1000` draws 1,000 synthetic organisms (plants, herbivores,
  carnivores in fixed proportions, deterministic from a seed, placed on the real climate grid) over the live base layer. The
  fixture is never used by `--smoke-test`, `--screenshots` or the live server, and the page and the output label it "synthetic fixture".
  Threshold: real-time (non-virtual) headless Chromium shows at least 30 requestAnimationFrame frames per second with the 1,000
  fixture, and the mean redraw (`window.evosim.timing(50)`) is at most 16 ms.
- (b) Live run at 1,000 organisms: `examples/ui-1000.json` from tick 0 in real time, while living is at or above 1,000. Report the
  exact tick window where living >= 1,000 (about the first 50 ticks, about 2.5 s at 20 ticks/s, from the sweep). In that window:
  at least 3 state updates per second and at least 30 frames per second. A window shorter than 2 s is reported as too short, not as a pass.
- (c) Sustained coexistence at 1,000 (living >= 1,000 for a long run): NOT claimed by this task. It is an engine balance property
  (TASK-018, TASK-027) and no UI change can fix it. M5 is therefore PASS only for (a) and (b) as recorded; the orchestrator decides
  whether the must-have wording is met. Do not add anti-extinction rules, do not fabricate population in the live run, and do not
  change `evosim-core` in this task.

D15. **Real-time measurement tool.** `scripts/ui_fps.py` (run with `python3 -I`). It starts `chromium --headless --no-sandbox
--disable-gpu --remote-debugging-port=0 --user-data-dir=<tmp>` on `http://127.0.0.1:<port>/?fps=1` (or `?fixture=1000`), reads the
DevTools port from `DevToolsActivePort`, connects over a stdlib WebSocket client (RFC 6455 handshake and masked text frames, about
60 lines, no pip), and calls `Runtime.evaluate` with `awaitPromise`: a requestAnimationFrame counter over 5 s of `performance.now()`,
plus `window.evosim.timing(50)`. It never uses virtual time. Exit 0 only when the thresholds of D14 hold. The browser and the server
are killed in a `finally` block. Budget: under 30 s.

D16. **Timing test.** `ui_1000_organisms_timing` (crates/evosim-ui/src/driver.rs) loads `examples/ui-1000.json` (the configuration
the UI uses), not the inline 700/250/50 world. It prints living per 10 ticks for 200 ticks, mean tick time and mean
`snapshot::state_json` time. It stays `#[ignore]`; its output is recorded in docs/STATE.md.

D17. **Gap closures.** G4: `ADR-0024-ui-world-view.md` added to the `ADRS` list in `scripts/check_adrs.sh` (status line checked as
Proposed or Accepted, not a fixed value). `docs/ARCHITECTURE.md` gets a "UI module (TASK-023)" section (files, routes, the
`window.evosim` hook, the fixture mode, the measurement tools). ADR stays Proposed until REVIEW PASS.

D18. **Plan verdict expectation.** With D14(c) unchanged, REVIEW cannot honestly report M5 as met in full. IMPLEMENT must record
(a) and (b) with numbers and must not present (c) as passed. Escalate to the orchestrator if REVIEW keeps M5 as a must-have that
depends on TASK-018 or TASK-027.

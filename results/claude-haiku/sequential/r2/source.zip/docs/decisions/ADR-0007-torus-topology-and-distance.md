# ADR-0007: Torus topology, distance and neighbourhood

Status: Accepted (drafted in TASK-004 PLAN cycle 1, implemented in IMPLEMENT cycle 1, confirmed in TASK-004 REVIEW cycle 1).

## Context
The world is a finite grid `W x H` whose left/right and top/bottom edges are joined (docs/PROJECT.md, docs/CONTRACT.md).
Every later module needs the same geometry: wrapping an integer coordinate to a cell (TASK-005 climate, TASK-006
seam tests), the distance and direction between two cells (perception, hunting, mating, dispersal), and the list of
cells in a radius (TASK-010 spatial index, ADR-0003). Movement is cell-to-cell. ADR-0003 already fixes the per-axis
torus distance `min(|a-b|, L-|a-b|)` and a square query box, so the metric must match that box. The geometry must be
one implementation, shared by all modules, and must be exact for 1 x 1, 1 x N and radii larger than the world.

## Considered alternatives
1. **Chebyshev distance `max(|dx|, |dy|)` on the torus (chosen).** Each axis takes its shortest wrapped
   displacement; the distance is the larger of the two. Its radius-r neighbourhood is the square box of ADR-0003,
   so the spatial index and the metric agree, and an integer test needs no square root. Cost: a square perception
   field, which is slightly larger than a circle in diagonal directions.
2. **Manhattan distance `|dx| + |dy|`.** Matches four-neighbour movement, but the radius-r set is a diamond, so
   ADR-0003's box enumeration would need an extra filter for every query, and the box would visit cells that
   are never returned.
3. **Euclidean distance `sqrt(dx^2 + dy^2)`.** Gives round perception fields, but needs a floating-point square
   root in every test, and the squared integer form still needs a separate box query. Rounding is a determinism
   risk for no gain in a discrete grid. Rejected for now; can be added later behind the same functions.

## Decision
- **Types** (`crates/evosim-core/src/world.rs`):
  - `Torus { width: u32, height: u32 }`, both `>= 1`; `Torus::new` returns `Err` for zero.
  - `Coord { x: i64, y: i64 }`: an arbitrary integer position, possibly negative or several worlds away.
  - `Cell { x: u32, y: u32 }`: a wrapped position, always `x < width` and `y < height`.
  - `Offset { dx: i64, dy: i64 }`: a signed displacement; the shortest one between two cells.
  - `Direction`: the eight compass steps, each with an `Offset`.
- **Wrapping:** `x.rem_euclid(W)`, `y.rem_euclid(H)`. Any `i64` is valid input; no overflow occurs.
- **Shortest signed displacement on one axis** from `a` to `b` (both wrapped, size `L`):
  `d = (b - a).rem_euclid(L)`; if `2*d > L` then `d - L`, else `d`. So the result lies in `(-L/2, L/2]`.
  **Tie rule:** when `L` is even and `d == L/2`, the displacement is `+L/2` (east/south), in both directions.
  This is deterministic and documented; it is the only case where `delta(a,b) != -delta(b,a)`.
- **Distance:** `distance(a, b) = max(|dx|, |dy|)` with `(dx, dy) = delta(a, b)`. It is symmetric, zero only for
  equal cells, and at most `floor(W/2)` on x and `floor(H/2)` on y.
- **Neighbourhood:** `neighbours(c, r)` returns every cell with `distance(c, cell) <= r`, the centre included, each
  exactly once, in ascending index order (`index = y*W + x`). Implementation: the distinct wrapped x-values of
  `[cx-r, cx+r]` and the distinct wrapped y-values of `[cy-r, cy+r]` (all values when `2r+1 >= W` resp. `H`), sorted,
  then their product. Distinctness holds because a range shorter than `W` has no repeated residues. Arithmetic is
  in `i64`, so any `u32` radius is accepted and radii larger than the world cost at most `W*H` cells.
- **Direction type:** the eight directions are the only steps used by movement; `Torus::step(cell, direction)`
  wraps the result. Organisms store `Cell`, not `Coord`.

## Consequences
- Performance: every function is O(1) per cell except `neighbours`, which is O(number of returned cells). The
  spatial index (TASK-010, ADR-0003) uses the same box, so its candidate set equals the returned set before the
  distance test.
- Testability: the module has no dependencies and no state. Tests cover the four edges, the corners, negative and
  multiply wrapped coordinates, non-square and 1 x 1 / 1 x N worlds, and a seeded brute-force comparison
  (`distance <= r` over all cells) for small worlds. They run in `cargo test` without any other module.
- Determinism: integer arithmetic only; output order is fixed by the index order.
- `dist/`: the module is plain Rust with no crates and no files, compiled into the single `dist/evosim` binary.
- Visible consequences for the ecology: perception and the neighbourhood are squares; a radius-2 query sees 25
  cells. The metric is one function (`Torus::distance`), so changing it to Euclidean or Manhattan later touches
  only `world.rs` and the spatial index filter.
- Risk: the tie rule makes direction slightly asymmetric on even-sized worlds. The effect is confined to cells
  exactly half a world apart.

## Verification strategy
- Unit tests in `world.rs`: wrap of negative, zero, `W-1`, `W`, `3W+1`, `i64::MIN`, `i64::MAX`; step across each of the
  four edges and each of the four corners; delta and distance on both axes including the tie case; symmetry
  and triangle inequality on seeded random samples.
- Neighbourhood: no duplicates (sorted and checked), radius larger than the world, 1 x 1, 1 x N, N x 1, non-square,
  and equality with a brute-force search over all `W, H` in `1..=7` and radii `0..=10`.
- Reproduction: `cargo test -p evosim-core --locked` and `bash scripts/test.sh` (exit 0). Results in
  `tasks/TASK-004/handoffs/implement-cycle1.md` once IMPLEMENT runs.

## Implementation notes (TASK-004 IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/world.rs`, exported as `evosim_core::world`. Names follow the Decision section, with these
  additions: `Torus::cell(x, y) -> Option<Cell>` (checked constructor), `Torus::translate(cell, Offset)`,
  `Torus::cell_from_index`, `Cell::x()` and `Cell::y()`.
- Deviation: `Cell` fields are private so that `x < width` and `y < height` cannot be broken from outside. The decision
  (wrapped cell with two `u32` coordinates) is unchanged.
- `Direction::North` is `dy = -1` (rows grow southwards). `Direction::ALL` lists the eight directions clockwise from north.
- Tests: 30 in `world::tests`, listed by name in `docs/STATE.md` (IMPLEMENT block). The brute-force check covers W, H in 1..=7 and r in 0..=10.
- Status remains Proposed until REVIEW.

# ADR-0015: Herbivore feeding, metabolism, climate cost and decision rule

Status: Accepted (drafted in TASK-014 PLAN cycle 1; accepted at TASK-014 REVIEW cycle 1 PASS).

## Context
TASK-014 makes herbivores live off plants (ADR-0012 pool, plant energy), pay for living every tick, feel the climate, and act
according to their genes. Carnivores, hunting (TASK-015) and mating/reproduction of animals (TASK-016) are out of scope. The
rules must reuse what exists: `Entities` (energy methods that clamp and set `Starvation` at 0), `SpatialIndex::within` (Chebyshev
radius, optional kind filter, ascending ids), the ADR-0014 movement rules (`plan_moves`, deferred moves, `move_organism`), and
`Climate::conditions(cell)` (the same source the Plants phase uses). Constraints: deterministic (ascending id, one RNG stream, no
hash maps), no rule may look at population counts (no forced anti-extinction), every rule local to the organism and its
surroundings. TASK-013 REVIEW gap 1 (perception did not change behaviour) is closed for herbivores by this ADR.

## Considered alternatives
1. **Feed at a distance: plants within vision are eaten by "reaching" (rejected).** The brief allows eating only in the own or an
   adjacent cell. Vision is for finding food, not for eating it.
2. **Feeding in a deferred pass like moves (rejected).** Two herbivores would both read a plant with 1 energy and both eat it, so
   the plant could go negative. Sequential feeding in ascending id order is deterministic and cannot over-draw a plant.
3. **Gain equal to intake, no assimilation loss (rejected).** Fine for the ceiling, but it gives no reason to eat in a cell with
   more energy than needed. A fixed assimilation fraction below 1 keeps energy conservation visible and is one constant.
4. **Danger = carnivore in sight, always flee (rejected).** Then the caution gene has no effect and the test "different genomes act
   differently" would rest on speed alone. A caution-versus-hunger balance keeps the gene meaningful and matches the "food against
   danger" decision the task asks for.
5. **Thermal cost as a per-cell capacity or as a kill (rejected).** Cost per tick outside a comfort band is the simplest local rule
   that reacts to climate; it is uncalibrated (TASK-018).

## Decision

### Feeding reach and intake
- A herbivore feeds only from living plants in its own cell or in an adjacent cell: `SpatialIndex::within(cell, FEED_REACH = 1,
  Some(Kind::Plant))`. Plants at Chebyshev distance 2 or more are never touched (torus seams included).
- Herbivores feed in the Herbivores phase, after the moves of that phase are applied, one herbivore at a time in ascending id
  order. Plants are visited in ascending id order.
- Intake per tick is capped: `BITE_MAX = 2.0` energy taken in total per herbivore per tick (the "amount eaten per tick is limited").
- Each bite takes `eaten = min(plant energy, remaining cap)` from the plant with `Organism::drain_energy(eaten)`. The plant can reach 0
  and dies of `Starvation` in the Deaths phase (ADR-0011).
- The herbivore gains `ASSIMILATION * eaten` with `add_energy`, where `ASSIMILATION = 0.8`. The gain is therefore at most the amount
  taken from the plants (ADR-0015 consequence: energy is not created).
- Satiation (ecology idea, adopted): a herbivore with `energy >= SATIATION_ENERGY = 80.0` takes no bites.
- Sequential feeding means a later herbivore in id order sees the plant already reduced by an earlier one. This is deterministic and
  is the only order-dependent rule in the phase (documented; see Consequences).

### Metabolism and movement cost (every tick)
- Every living herbivore pays, once per tick in the Herbivores phase, through `drain_energy`:
  1. the movement cost of ADR-0014, `move_cost(distance, speed)`;
  2. base metabolism `BASE_COST = 0.3` energy per tick;
  3. thermal cost `thermal_cost(T)` where `T` is `climate.conditions(cell).temperature` at the herbivore's cell after its move:
     `THERMAL_COST = 0.02` per degree outside the comfort band `[COMFORT_LOW = 5.0, COMFORT_HIGH = 30.0]` °C, the excess capped at
     40 degrees (maximum 0.8 per tick). Zero inside the band. Extreme cold and extreme heat both cost more.
- A herbivore whose energy reaches 0 dies of `Starvation` (ADR-0011 death rules, Deaths phase). No other rule kills herbivores.
- Carnivores: unchanged in TASK-014 (ADR-0014 movement cost only). Their metabolism belongs to TASK-015.

### Decision rule (food against danger, genes decide)
Per herbivore, from its vision range (`entities::vision_radius`) and the start-of-phase positions (ADR-0014 deferred moves):
- `hunger = 1 - energy / ENERGY_MAX` (0 full, 1 empty).
- `danger` = the nearest living carnivore in sight (Chebyshev distance, ties by lowest id), if any.
- `food` = the nearest living plant with energy above 0 in sight, only while `energy < SATIATION_ENERGY`, ties by lowest id.
- Rule, first match wins:
  1. danger exists and `caution > hunger` gives `Heading::Away(danger cell)`;
  2. food exists gives `Heading::Towards(food cell)`;
  3. otherwise `Heading::Wander`.
- `caution` is the herbivore's own gene (`Tendencies::caution`, genome slot 6). A cautious herbivore flees unless it is hungrier
  than it is cautious. `aggression` (slot 5) has no effect on herbivores in TASK-014; it is for carnivores and hunting (TASK-015).
- Movement: `Towards` is ADR-0014 `step_towards`; `Away` is the new `step_away` (each step moves by `-sign` of the torus delta on
  each axis, diagonal when both axes differ, `steps` steps, no stop). If the danger is on the same cell, `Away` falls back to
  `Wander`. Steps per tick are `floor(speed)` as in ADR-0014.
- The rule draws no random numbers. Wander draws are the ADR-0014 draws (one `next_below(8)` per step).

### Phase order for herbivores (replaces the TASK-013 arm for herbivores only)
1. Plan: `plan_moves(Kind::Herbivore)` with the heading rule above, all living herbivores, ascending id, start-of-phase positions.
2. Apply the moves in ascending id order through `Simulation::move_organism` (ADR-0014).
3. Feed in ascending id order (feeding reach and cap above).
4. Charge costs in ascending id order: movement, base metabolism, thermal cost (the cell after the move).
Carnivores keep the TASK-013 `animal_phase` (planned wander moves, movement cost).

## Consequences
- **Testability**: every rule above is a pure function or a single phase call with a unit or integration test (see
  Implementation notes); the rules read only the organism's own state and its perception (`feeding.rs`, `sim.rs`).
- **Distribution (`dist/`)**: this decision adds no release artifact and does not touch the `dist/` folder.
- **Determinism**: feeding order is ascending id; a plant shared by two herbivores is drawn down by the first and then by the second.
  Same seed, same result (tested).
- **Energy conservation**: each bite removes `eaten` from a plant and adds at most `eaten` to the herbivore. Costs are removed; none is
  added.
- **Population**: herbivores now starve if plants run short, so the population can fall to zero. This is allowed (PROJECT.md: no forced
  anti-extinction). Whether the three kinds coexist is measured in TASK-018 and TASK-027.
- **Calibration**: `BITE_MAX`, `ASSIMILATION`, `SATIATION_ENERGY`, `BASE_COST`, `COMFORT_*`, `THERMAL_COST` are uncalibrated
  (TASK-018). Founders (energy 50) may starve in the first hundreds of ticks if plants are scarce; the tests use small worlds that
  make the outcome explicit rather than tuned.
- **Performance**: two `within` queries per herbivore per tick (perception and feeding reach). Measured later (G-046 applies).
- **Dependencies**: `core::feeding` (new) depends on `entities`, `spatial`, `world`, `climate`; `sim` glues it to the phase.

## Verification strategy
- Reach: a plant at distance 2 is never eaten; plants at distance 0 and 1 are (including across an edge).
- Cap and conservation: a bite never exceeds `BITE_MAX`; the plant loses exactly what the herbivore gains divided by `ASSIMILATION`
  (within float tolerance); the gain never exceeds the amount taken.
- Plant death: a plant with energy below the bite is drawn to 0 and is removed by the Deaths phase with `Starvation`.
- Satiation: a herbivore at `SATIATION_ENERGY` takes no bite.
- Metabolism: a herbivore with no plants and speed 0 loses exactly `BASE_COST` in comfort climate; starvation at 0 gives `Starvation`
  through the phase.
- Climate: at the same energy and speed 0, a herbivore in a colder cell (outside the band) loses more energy than one in a comfort cell.
- Genes: two herbivores in the same situation (a carnivore and a plant in sight, same energy) with caution 0.9 and 0.1 choose
  `Away` and `Towards` respectively; the resulting cells differ after the phase.
- Vision: a plant at distance 3 is chosen only by a herbivore whose vision reaches 3.
- Determinism: same seed gives identical herbivore positions and energies after N ticks.

## Implementation notes (IMPLEMENT cycle 1)
- Code: `crates/evosim-core/src/feeding.rs` (new: constants, `thermal_cost`, `herbivore_heading`, `feed`, tests);
  `movement.rs` (`Heading::Away`, `step_away`, `plan_moves` takes the heading rule as a closure; TASK-013 tests updated to pass
  `choose_heading`); `sim.rs` (`herbivore_phase`; `animal_phase` keeps carnivores; tests in `herbivore_tests`).
- Satiation is checked once before the bites: a herbivore that starts below 80 may end slightly above 80 (gain at most 1.6).
- `step_away` recomputes the offset from the threat after every step, so the flight direction stays correct across seams.
  On an even-sized torus the offset at exactly half the width is a tie (the torus rule's choice applies); no test depends on it.
- TASK-013 expectations changed (reason: herbivores now pay base metabolism and the thermal cost): the
  `a_tick_moves_animals...` test subtracts `BASE_COST` and the thermal cost; `slow_animals_do_not_move_and_pay_nothing` is
  renamed `..._pay_only_metabolism_and_climate` and asserts a range (the climate changes over the 10 ticks).
- Test evidence and exit codes: see `tasks/TASK-014/handoffs/implement-cycle1.md`.

## Review notes (REVIEW cycle 1, verdict PASS)
- Acceptance points re-run and read against the code: `cargo test -p evosim-core --locked` exit 0 (294 passed, 1 ignored);
  `cargo test --workspace --locked` exit 0; clippy `-p evosim-core -p evosim-cli --all-targets` exit 0, no warnings;
  `bash scripts/check_adrs.sh` exit 0 (checks=142 failed=0).
- Deviation found (G-051, non-blocking): the Consequences/implementation text says `Away` falls back to `Wander` when the danger
  shares the herbivore's cell. The code does not: `plan_moves` maps `Heading::Away` straight to `step_away`, which returns
  `(from, 0)`, so the herbivore stays put and still pays its costs. Perception includes a carnivore on the same cell (distance 0).
  Fix in the next phase that touches `movement.rs` (either a wander fallback or this ADR wording), with a test.
- Test strength (non-blocking): the thermal cost is checked in the phase only for cold cells; the heat side is covered by the
  `thermal_cost` unit test. The bold-versus-cautious phase test checks the headings exactly but only loosely checks energy.

**Amendment (TASK-018 IMPLEMENT cycle 1, ADR-0019 D4).** `BITE_MAX` 2.0 to 0.5. At 2.0 plants crashed under 120 herbivores
within about 150 ticks, and the herbivores starved after them. The other feeding constants are unchanged.

# ADR-0008: Random number generator, tick order and step representation

Status: Accepted (TASK-005 REVIEW cycle 1 PASS; implementation matches the decision, see Implementation notes and the review note below).

## Context
TASK-005 builds the frame that every later feature plugs into: one `Simulation` state, one function that advances it
by exactly one tick, and one generator that is the only source of randomness. Checkpoints (TASK-022), the
determinism contract (`docs/CONTRACT.md` section 5.1 and 5.2) and the `state_hash` all depend on three things fixed
here: the generator algorithm and its exportable state, the order of phases inside a tick, and how a phase reports
what it did. The actual climate, plant and animal behaviour is out of scope (TASK-006 onwards).

## Considered alternatives
1. **xoshiro256\*\* seeded through SplitMix64 (chosen).** 256-bit state of four `u64` words, about 1 ns per draw,
   passes the usual statistical batteries, public reference algorithm, state is four words that serialize trivially.
   Seeding from a single `u64` through SplitMix64 avoids the all-zero state for practical seeds and gives a
   well-mixed start for adjacent seeds. Implemented in-house (no crate), so it cannot change under an upgrade.
2. **PCG64 (permuted congruential, 128-bit state).** Also good statistically and compact. Rejected because the 128-bit
   multiply needs care to be portable and its reference vectors are less familiar to reviewers; no advantage here.
3. **ChaCha8/ChaCha20 (`rand_chacha` crate).** Cryptographic-grade stream, but adds a third-party dependency
   (ADR-0001 keeps crates minimal), costs more per draw, and the simulation does not need unpredictability.
4. **SplitMix64 alone.** Simplest code (one `u64` state) but its period is only 2^64 and it is weaker for many
   parallel-looking streams. Kept only as the seeding function, not as the simulation generator.
5. **A generator per organism or per phase.** Gives independent streams, but the number of streams then depends on
   population history, and the checkpoint must store all of them. Rejected: one master stream, consumed in the fixed
   order below (ADR-0004 and `docs/ARCHITECTURE.md` determinism rules).

### Tick order alternatives
1. **Fixed phase list with every phase run every tick (chosen).** The order is `docs/ARCHITECTURE.md` section
   "Determinism", item 2: climate, spatial index rebuild, plants, herbivores, carnivores, reproduction, death removal,
   species check, counters. Each phase is a function on `&mut Simulation`. Easy to test, easy to checkpoint.
2. **Event queue (priority queue of timestamped events).** Flexible, but heap ordering of equal times is a stability
   risk, and it hides the simple "everything happens once per tick" model that the ecology needs. Rejected.
3. **Organisms act themselves in id order inside one loop.** Makes reproduction and death in the middle of a loop
   order-dependent and hard to explain. Rejected in favour of phases with explicit boundaries.

### Event representation alternatives
1. **No event objects: phases mutate state directly, counters live in the state (chosen).** Births and deaths are
   incremented in the counter phase from explicit counters, so no event bus is needed. Deterministic by construction.
2. **Typed event log (`Vec<Event>` per tick).** Useful for UI and analysis. Deferred: the trace in this ADR records
   phase boundaries only; a per-event log can be added later behind the same trace switch if TASK-024 or TASK-013
   needs it.

## Decision
- **Generator**: `core::rng` (`crates/evosim-core/src/rng.rs`), xoshiro256\*\* with SplitMix64 seeding.
  - `Rng::from_seed(u64)`: SplitMix64 produces four words; if they are all zero (not reachable in practice, guarded
    anyway) the first word is set to 1.
  - `Rng::from_state([u64; 4]) -> Result<Rng, RngError>`: rejects the all-zero state, the only invalid state.
  - `Rng::state() -> [u64; 4]`: exports the exact state; restoring it continues the stream identically.
  - `next_u64`, `next_below(n)` (n >= 1, unbiased by rejection, no float), `next_f64()` (53 bits: `(x >> 11) * 2^-53`,
    in `[0, 1)`), `chance(p)` (`next_f64() < p`).
  - The only generator in the core. No `thread_rng`, no OS entropy, no time-based seeding.
- **Simulation state**: `core::sim::Simulation` owns `tick: u64`, `rng: Rng`, `world: World`, and an optional trace.
  `World` holds the `Torus` (ADR-0007) and, from later tasks, climate and organisms. `Simulation::new(&Config)`
  takes `config.seed` and `config.world` (converted to `u32`; `MAX_SIDE` of 4096 fits).
- **Tick order** (`Phase` enum, fixed constant array `PHASE_ORDER`, every phase runs once per tick, in this order):
  1. `Climate`: climate update (no-op until TASK-006/007),
  2. `SpatialIndex`: rebuild the per-cell index from the start-of-phase snapshot (ADR-0003; no-op until TASK-010),
  3. `Plants`, 4. `Herbivores`, 5. `Carnivores`: each acts over organisms in ascending id order,
  6. `Reproduction`, 7. `Deaths`: removal with an order-preserving `retain` (no swap-remove),
  8. `Species`: the species check, which internally runs only when `tick % species_check_interval == 0` (no-op until TASK-011),
  9. `Counters`: updates the cumulative births and deaths per kind.
  Then `tick` increments by exactly one. Phases see `sim.tick` equal to the tick being simulated (`t`).
- **Sampling is not a phase.** Time-series sampling and result JSON are read-only observers that run after
  `tick()` returns, in the CLI or metrics module. This is a deliberate deviation from the list in `docs/ARCHITECTURE.md`
  ("counters and sampling"): sampling cannot change state, so it does not belong in the tick order.
- **Ties**: any ordering of organisms uses ascending id (ids are unique and never reused, from a `u64` counter stored in
  the checkpoint). Any sort with equal keys falls back to id. No hash-map iteration order is used.
- **Step and event representation**: the phase enum plus direct mutation of state. The trace is an optional
  `Vec<TraceRecord { tick, phase, rng_fingerprint }>`, one record per phase per tick, enabled explicitly
  (`Simulation::set_trace(true)`). `rng_fingerprint` is a fixed 64-bit mix of the four state words, so a trace
  depends on the generator state at each phase boundary.
- **Clock**: the tick counter is the only clock in the state. Wall-clock time is used only outside the state
  (`elapsed_seconds`, `ticks_per_second`), as `docs/ARCHITECTURE.md` already states.

## Consequences
- **Determinism and checkpoints**: the complete random state is four `u64` words plus the tick counter, which is
  cheap to write into the checkpoint (TASK-022) and to hash (`state_hash`).
- **Performance**: `next_u64` is a handful of shifts and xors; the phase loop is a `match` over nine variants. No
  allocation per tick when the trace is off. The trace costs 9 records per tick (about 25 bytes each), so 10,000 ticks
  take about 2 MB when enabled.
- **Testability**: the generator is pure and has published reference vectors. The scheduler runs in `cargo test`
  without a display, a world of organisms, or a UI. The core has no dependency on `evosim-ui` or `evosim-cli`.
- **dist/**: no new crate; the code is plain Rust in the core, so it ships inside `dist/evosim` unchanged.
- **Trade-off**: phases that draw nothing in TASK-005 make the trace depend only on the seeded initial state.
  This is acknowledged in the plan risks; later tasks make the trace depend on actual draws.
- Changing the algorithm, the seeding, or the phase order later requires a new ADR and a checkpoint format version bump.

## Verification strategy
- Reference vectors: SplitMix64 seed 0 first output `0xE220A8397B1DCDAF`; xoshiro256\*\* from state `[1, 2, 3, 4]`
  first output `11520`. Tests fail if either changes.
- Unit tests: same seed gives the same sequence; different seeds differ; `state()` then `from_state()` continues the
  stream identically; all-zero state rejected; `next_below` stays in range and hits every value for small `n`;
  `next_f64` stays in `[0, 1)`.
- Scheduler tests: `PHASE_ORDER` equals the documented list; one `tick()` advances the counter by exactly one; a
  100-tick trace with the same seed is identical; a different seed gives a different trace; a save of the RNG state
  at tick 50 restored into a new state reproduces ticks 51 to 100 of the trace.
- Static checks: `scripts/check_adrs.sh` (core does not reference UI or CLI); grep for `SystemTime`, `Instant`,
  `thread_rng` in `crates/evosim-core/src` returns nothing.

## Implementation notes (TASK-005 IMPLEMENT cycle 1)
Status stays Proposed until REVIEW. Deviations from the plan, all inside the decision above:
- `Simulation::from_parts(tick, rng_state, world)` returns `Result<Simulation, RngError>` (it rejects the all-zero state
  instead of accepting any array).
- `SimError` has a second variant, `SideTooLarge { value }`, for a side that does not fit in `u32`; `Simulation::new`
  maps `Torus::new` errors to `SimError::Topology`.
- Added accessors `Simulation::world()` and `Simulation::rng_mut()`. `rng_mut` is the only way later phases draw;
  nothing outside the core needs it yet.
- `rng::fingerprint` is `pub(crate)`, not public. The mix is SplitMix64's finaliser applied to each state word in turn.
- `scripts/check_adrs.sh` now also checks ADR-0008 (headings, two alternatives, performance, testability, `dist/`).
  The check count went from 54 to 65.
- Phase bodies are empty (`Simulation::run_phase` has one empty arm per phase). Consequence: no draw happens during a
  tick, so every trace record of a tick carries the same fingerprint (the state at the start of that tick). The
  seed-dependence of the trace comes from the initial state only. Tests still show the requested properties, but this
  is weak evidence for the trace; it becomes meaningful once TASK-006 and later draw from `rng_mut()`.

Verification (IMPLEMENT cycle 1, see `docs/STATE.md`): 23 new tests (12 in `rng`, 11 in `sim`), all passing; clippy
clean; `check_adrs.sh` checks=65 failed=0.

## Review note (TASK-005 REVIEW cycle 1)
Verdict PASS; status set to Accepted. Checked by reading the code and by running the tests (`tasks/TASK-005/handoffs/review-cycle1.md`).
- Reference vectors re-derived with an independent Python 3 script (`-I`, outside the workspace): SplitMix64 seed 0 gives
  `0xE220A8397B1DCDAF`; xoshiro256** from `[1,2,3,4]` gives `11520`. Both match the code.
- Known limit, non-blocking (gap G-025): with empty phase bodies the trace is a constant fingerprint per run, so the
  seed-dependence tests show only that the seed sets the initial state. The trace becomes evidence of the dynamics once
  TASK-006 and later draw from `rng_mut()`. Later tasks should add a test that a draw inside a phase changes the trace.
- Ties by ascending id are documented here but cannot be exercised until organisms exist (TASK-008); not a gap for TASK-005.

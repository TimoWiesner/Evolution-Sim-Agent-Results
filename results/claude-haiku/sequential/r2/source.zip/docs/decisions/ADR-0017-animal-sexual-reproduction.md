# ADR-0017: Animal sexual reproduction, mate search, compatibility, costs and cooldown

Status: Accepted (TASK-016 REVIEW cycle 1 PASS; drafted in PLAN cycle 1, implemented in IMPLEMENT cycle 1).

## Context
TASK-016 lets herbivores and carnivores reproduce with two parents. The acceptance points are: a mate must be a different living
animal of the same kind, close by, mature, with enough energy and genetically compatible; the child's genome is a crossover of both
parents plus mutation, and both parent ids and the generation are recorded; both parents pay energy; a parent waits after a birth;
the fertility trait changes the chance or the size of a litter; a single animal never produces offspring.

Existing facts this rests on:
- ADR-0011: `Entities::spawn_child(birth, [Some(a), Some(b)])` for animals, parents must be alive and distinct, generation =
  1 + max parent generation, `births` counted. `age` is 0 at birth and +1 per survived tick (Deaths phase).
- ADR-0004 / TASK-009: `genome::crossover_child(mother, father, mutation, rng)` (meiosis per parent, then mutation) and
  `genome::genetic_distance` (normalised, in `[0, 1]`). Random genomes are at mean distance about 1/3.
- ADR-0006 already has `herbivores.reproduction_energy` (60) and `carnivores.reproduction_energy` (90) and `*.max_age` (300 and 400).
  No new configuration key is needed.
- ADR-0014: animals share cells freely; there is no occupancy limit for animals.
- ADR-0003 / ADR-0007: `SpatialIndex::within` returns ascending ids, is torus-aware, and still lists dead organisms until the
  Deaths phase, so a candidate must be filtered with `is_alive`.
- ADR-0008 / ADR-0011: Reproduction runs after the action phases and before Deaths. A child is never a target in its birth tick.
- ADR-0013: the plant seeding arm of the Reproduction phase already exists and draws from the same generator.

## Considered alternatives
1. **Gestation (pregnancy state, delivery after N ticks) versus immediate birth (chosen).** Gestation needs a stored pregnancy
   with the mate's id, its own checkpoint fields and death rules for a pregnant parent. Immediate birth with a cooldown gives the
   same waiting-time rule with less state. Trade-off: no gestation cost is spread over time.
2. **Mate choice by a heritable preference (for example by `aggression` or `risk`) versus nearest compatible partner (chosen).**
   Preference is ecologically richer, and ADR-0004 allows it later. The nearest-partner rule is deterministic, needs no extra draws,
   and is testable. Preference can be added later without changing the phase skeleton.
3. **Mating reach: same cell only, versus Chebyshev torus radius `MATE_RANGE` (chosen, 2).** Same cell alone would almost never
   pair animals that move one step per tick. Radius 2 is "close to each other" and uses `within` with the kind filter.
4. **Compatibility rule.** Chosen: a pair is compatible when `genetic_distance <= COMPAT_MAX = 0.40`. Calibration check: random
   genomes have distance about 0.333 with spread about 0.015 (256 loci), so a threshold of 0.40 accepts almost all founder pairs
   and excludes only strongly diverged lineages. A threshold near the species distance (0.06, ADR-0004) would forbid every
   founder pair and end all animal reproduction at once. Species are not yet named (TASK-017), so this is a mating barrier, not
   the species criterion.
5. **Litter size.** Chosen: `litter = 1 + Bernoulli(mean fertility)`, so 1 or 2 children per event. A fixed litter ignores
   fertility; a Poisson litter needs a new sampler and an unbounded size.

## Decision

### Constants (`mating.rs`, `pub const`, not configuration keys)
| Constant | Value | Meaning |
|---|---|---|
| `MATE_RANGE` | 2 | partner search radius in cells (Chebyshev, torus) |
| `COMPAT_MAX` | 0.40 | largest `genetic_distance` a mating pair may have (mating barrier) |
| `MATURITY_FRACTION` | 0.20 | maturity age = `max(1, floor(0.20 * max_lifespan))` ticks |
| `MATE_CHANCE` | 0.20 | per tick, per eligible animal with a partner, scaled by fertility |
| `MATE_COOLDOWN` | 20 | ticks after a mating during which a parent cannot mate again |
| `CHILD_ENDOWMENT` | 20.0 | energy each child starts with |
| `MATE_OVERHEAD` | 5.0 | energy each parent loses per mating beyond its share of the children's endowment (a sink) |
| `LITTER_MAX` | 2 | largest litter |
| `CHILD_HEALTH_FRACTION` | 0.5 | child health = 0.5 × its own `max_health` |

Energy thresholds come from configuration: `herbivores.reproduction_energy` and `carnivores.reproduction_energy`.

### Settings (stored in `Simulation`)
`MatingSettings { mutation: Mutation, threshold: [f32; 2] }` (herbivore, carnivore), built by `MatingSettings::from_config(&Config)`
from `genetics.*` (through `mutation_settings`, ADR-0004) and the two `reproduction_energy` keys. `Simulation::from_parts` takes it
as a sixth argument. The checkpoint (TASK-022) must save it, like `SeedingSettings` (ADR-0013). Plants keep `SeedingSettings`
unchanged.

### Organism field (ADR-0011 amendment)
`Organism` gets `next_mate_age: u32` (0 at birth). It is the age from which the organism may mate again. Setting it is the
cooldown: after a mating at age `a`, both parents get `next_mate_age = a + MATE_COOLDOWN`. Expressing the cooldown in age, not in
ticks, needs no tick argument in `spawn_child`, and it is saved with the organism. `Entities::set_next_mate_age(id, age)` is the
only setter (crate-private to `core`).

### Eligibility (a mate-ready animal)
An animal is eligible to start a mating when all hold:
- alive (`is_alive`), kind is herbivore or carnivore;
- `age >= maturity(traits)` and `age >= next_mate_age`, with `maturity(traits) = max(1, floor(0.20 * max_lifespan))`;
- `energy >= threshold[kind]` (the energy surplus rule: no mating when food is short);
- it has a partner (below). The partner search runs before any random draw, so an animal without a partner draws nothing.

A partner is an animal that is also alive, of the same kind, not the animal itself, eligible by the same rules, and compatible:
`genetic_distance(a, b) <= COMPAT_MAX`. Among candidates the nearest by `Torus::distance` wins; ties go to the lowest id
(`within` returns ascending ids, and the first minimum is kept). Mate choice ignores traits in this task.

### Mating procedure (`mating::mating_phase`, run in the Reproduction arm after plant seeding)
1. Collect the ids of living animals (herbivores then carnivores, ascending id within a kind) into a list at phase start. Newborns
   are not in the list (ADR-0011 same-tick rule 4).
2. For each id in the list, re-check the initiator's eligibility against the current state (earlier matings in this phase may have
   changed it). Then search the partner (`spatial.within(cell, MATE_RANGE, Some(kind))`, minus self, filtered as above).
3. If there is no partner, stop for this initiator (no draw). Otherwise draw `rng.chance(p)` with
   `p = clamp(MATE_CHANCE × 2 × fertility_mean, 0, 1)` where `fertility_mean` is the mean of the two parents' fertility (0.5 gives
   `MATE_CHANCE`; 0 gives no matings; 1 gives 0.4). A failed draw ends this initiator.
4. Litter: `litter = 1 + (rng.chance(fertility_mean) as usize)`, so 1 or 2 (`LITTER_MAX`).
5. Parents: mother = lower id, father = higher id. Each parent pays
   `parent_cost(litter) = litter × CHILD_ENDOWMENT / 2 + MATE_OVERHEAD` with `drain_energy`. Energy: children receive
   `litter × CHILD_ENDOWMENT`, parents pay `litter × CHILD_ENDOWMENT + 2 × MATE_OVERHEAD`. The overhead is removed, so no energy is
   created (docs/PROJECT.md: energy needs a documented source).
6. Children: for each of the `litter` children, `genome::crossover_child(mother.genome, father.genome, mutation, rng)`, then
   `Birth::from_genome(kind, cell, genome, CHILD_ENDOWMENT, CHILD_HEALTH_FRACTION × max_health)`, where `cell` is the initiator's
   cell, then `entities.spawn_child(birth, [Some(mother), Some(father)])` and `spatial.insert(child, cell, kind)`.
   Generation is recorded by `spawn_child`.
7. Cooldown: `set_next_mate_age(mother, age + MATE_COOLDOWN)` and the same for the father, both before the next initiator.
8. Return `MatingReport { pairs_found, draws_failed, litters, children, ... }` (integers) for tests.

Draw order per initiator: partner search (no draws), chance, litter, then per child: crossover (cut and coin per parent), mutation.
The phase is single-threaded and ordered by id, so it is deterministic.

### Relation to existing rules
- Herbivores and carnivores still move, feed and hunt first (ADR-0014/15/16). Only the Reproduction phase creates animals.
- No forced anti-extinction: no rule reads a population count; every condition is per animal, per partner, or per cell.
- With `initial.herbivores = 0` and `initial.carnivores = 0`, there are no animals and the phase draws nothing. Plant-only runs keep
  their TASK-012 draw order.

## Consequences
- **Performance**: per eligible initiator, one `within` query and up to a few `genetic_distance` computations (256 loci each).
  Eligibility filters run before the distance; the cost is not yet measured (TASK-018 and the 2,000-entity target).
- **Checkpoint (TASK-022)**: must save `Organism.next_mate_age` and `MatingSettings` (mutation pair and the two thresholds).
- **Existing tests**: a test that runs animals for many ticks with exact energy arithmetic could change if an animal now reaches its
  threshold. Expected to fail only if an animal reaches 60 (herbivore) or 90 (carnivore) energy; the IMPLEMENT must run the full
  suite and report any such change.
- **Trade-off**: immediate birth and a nearest-partner rule are simple and testable; they do not model gestation or choice.
- **Risk**: `COMPAT_MAX = 0.40` is calibrated to random founders, not to ecology. Lineages that drift apart can be kept from mating
  only after they differ by more than 0.40, which is rarely reached within a run. This is recorded as a gap (see Verification).

## Verification strategy (IMPLEMENT must show each point by a test or a recorded command)
- Single animal: one herbivore and one carnivore alone for 1,000 ticks (energy set high at start) gives zero births
  (`single_animal_never_produces_offspring`). A positive control with two adjacent mature animals gives births, so the test is not
  vacuous.
- Self-mating refused: the partner search never returns the initiator; `spawn_child` with `a == b` is an error (existing).
- Same kind, distance, maturity, energy, compatibility: table-driven unit tests of the eligibility and partner choice (each
  condition fails alone, the others hold). Seam: a partner at `x = 0` and one at `x = W-1` are found (torus distance).
- Compatibility: pairs with distance `> 0.40` never mate; pairs with distance `<= 0.40` do. Founders: over 200 seeded pairs most
  pairs are compatible (documented, not a rule).
- Genome: with mutation rate 0, every child locus equals a locus of one of the parent's four haplotype loci at the same index;
  `parents == [Some(mother), Some(father)]`; generation = 1 + max parent generation.
- Costs: exact energy: each parent loses `parent_cost(litter)`; the sum over parents and children changes by
  `-2 × MATE_OVERHEAD` per mating.
- Cooldown: after a mating, repeated phase calls without ageing give no second mating for the same parent; after `MATE_COOLDOWN`
  ticks of ageing it may mate again.
- Fertility: fertility 0 gives no matings in 2,000 seeded trials; fertility 1 gives a mating rate near `MATE_CHANCE × 2` (band
  checked); litter sizes are 1 or 2 and both occur.
- Balance and spatial: `check_balance` and `check_spatial` hold after every tick of a 2,000-tick mixed run (plants and animals), and
  births of animals occur (non-vacuous).
- Determinism: same seed gives identical entity state (and `state_hash` once TASK-022 exists); different seeds differ.

## Gaps accepted at PLAN time
- G-A1: compatibility is a fixed barrier, not calibrated to any ecological value (TASK-018, TASK-027).
- G-A2: mate choice ignores traits and tendencies; a heritable preference is left for later (ADR-0004 allows it).
- G-A3: no gestation; no per-tick energy cost of a pregnancy.
- G-A4: whether all three kinds coexist over long runs is measured later (TASK-018, TASK-027).

# ADR-0018: Species criterion, re-classification, naming and the family tree

Status: Accepted (TASK-017 REVIEW cycle 1 PASS; proposed at PLAN cycle 1). Amends ADR-0004 (species
criterion, founders) and ADR-0011 (organism fields). It fixes the numbers and rules that ADR-0004 left as placeholders.

## Context
ADR-0004 defines the species criterion: single-linkage clustering of the living organisms of one kind with edge
`d <= species_distance`, identity by a founder genome, and recognition after `species_persistence_checks` consecutive
checks. The config keys already exist (`species.distance` 0.06, `check_interval` 25, `persistence_checks` 4).
Three facts found in PLAN block a direct implementation of that text:

1. **Random founders are all separate species.** `Simulation::populate_initial` (TASK-009, D3) gives every founder an
   independent uniform random genome. Pairwise distance is about 0.333 (sd about 0.015, TASK-016 PLAN). With threshold
   0.06, single-linkage makes every founder its own cluster, so a tick-0 population of N organisms would produce N
   candidate species. That is not a species structure.
2. **The ADR-0004 cost estimate is too optimistic.** "n <= 5,000 every 25 ticks is acceptable" was not measured. The
   pairwise cost is `n(n-1)/2 * L` byte comparisons per kind per check (L = 256 for animals, 128 for plants). Estimates:
   2,000 animals gives 2,000 * 1,999 / 2, about 2.0 M pairs (the PLAN text said 0.5 M, which was wrong), about 5e8 byte
   operations before early exit. Measured in TASK-017 REVIEW (see Measurement below): 4.8 ms per check, about 0.2 ms per tick averaged
   over 25 ticks.
3. **The default threshold cannot be hit exactly.** Genetic distance is `S / (L * 255)` with an integer sum `S`.
   For L = 256 the value 0.06 corresponds to `S = 3916.8`, which no genome pair attains. The boundary test therefore
   uses the attainable value `k / (L * 255)`.

## Considered alternatives
1. **Keep random founders and treat each kind's initial population as one ancestral species by definition.**
   Rejected: the first check would still cluster the founders into singletons, and every singleton would need a special
   exception to be matched to the founder species.
2. **Leader (representative) clustering: each organism joins the first species whose reference genome is within the
   threshold.** Cost O(n * S) per check, which is cheaper. Rejected for now: a species then has a fixed sphere around its
   founder genome, so long drift splits interbreeding populations that are continuous, and the species count grows with
   time. Kept as the fallback if the single-linkage measurement fails the time budget.
3. **Clonal founders per kind (chosen).** `populate_initial` draws one ancestral genome per kind and creates each founder
   as `copy_child(ancestor, configured mutation)`. Founder spread is then far below the threshold, so each kind starts as
   one species. The founders' genetic variation grows from mutation during the run, which is the mechanism the ecology is
   meant to act on anyway.
4. **Raise the threshold above the founder spread (for example 0.35).** Rejected: it contradicts the calibration logic of
   ADR-0004 (lineage divergence on the order of the mutation drift) and would hide real speciation.

## Decision

### Founders (amends ADR-0004 D3 and TASK-009 `populate_initial`)
- `populate_initial` draws one ancestral `Genome` per kind (`random_genome(ploidy, rng)`, kinds in the fixed order plants,
  herbivores, carnivores), then creates each founder by `copy_child(&ancestor, mutation, rng)`, where `mutation` comes from
  the configured `genetics` keys. No new configuration key.
- Consequence: founders of one kind are one species at tick 0. TASK-016 founder compatibility is unaffected in practice:
  all founder pairs are far below the mating barrier of 0.40.

### Species criterion (ADR-0004 kept; numbers fixed)
- Genetic distance: `genetic_distance` of ADR-0004 (integer sum over all loci, divided by `L * 255`).
- Clustering: single linkage over the living organisms of one kind, sorted by id. Edge when `d <= species.distance`
  (the boundary is inclusive). Union-find. Cost measured in IMPLEMENT; the comparison may stop early once the partial
  sum exceeds `floor(distance * L * 255)` (exact, because the sum is an integer).
- Identity: a cluster matches an existing recognised species of the same kind when any member is within
  `species.distance` of that species' reference genome (the genome of its founder, stored in the record, never changes).
  Several matches: the lowest species id wins.
- Candidate: an unmatched cluster becomes a candidate with a fresh internal key. The candidate is matched to an earlier
  candidate by the same reference-genome rule. A candidate's counter increments at each check where it is observed. It
  is dropped at the first check where it is not observed (the counter resets). It becomes a recognised species when the
  counter reaches `species.persistence_checks`. Counts are checks, never ticks, and never member counts.
- Founding: the first check after `populate_initial` (or any check in which a kind has no recognised species yet) records
  its clusters as recognised species immediately, with `arose_tick` equal to the founding tick and no parent. This avoids
  a 100-tick period in which founders have no species.

### When organisms are re-classified
- Full re-classification of all living organisms of each kind at every tick `t` with `t % species.check_interval == 0`
  (`t > 0`, or the founding check), inside `Phase::Species`.
- Between checks, a newborn takes the species of its mother (the lower-id parent, ADR-0017) as a provisional id. The
  provisional id is used until the next check. Members of a candidate cluster keep their provisional id until the
  candidate is recognised.
- Re-classification never changes an organism's behaviour. Species are a bookkeeping layer over the genome.

### Parent species and the family tree
- A recognised species record holds: `id`, `kind`, `name`, `parent: Option<SpeciesId>`, `arose_tick`, `extinct_tick:
  Option<u64>`, `reference: Genome`.
- Parent of a new candidate: the most common provisional species among its members at the check that recognises it
  (ties to the lowest id). Founder species have no parent.
- Extinction: a recognised species with zero living members at the end of a tick gets `extinct_tick = t` (the tick of
  the last death; this is exact, not check-granular). Extinction is permanent: no birth can come from zero members.
  Extinct species keep their record and id; ids are never reused.
- The records form the family tree: `parent` links, `arose_tick`, and `extinct_tick`.

### Identifiers and naming
- `SpeciesId(u32)`: an index into the registry in creation order; never reused. Creation order is deterministic because
  clusters are processed in ascending minimum-organism-id order within the fixed kind order.
- Name: `"<code><seq:04>"` where code is `PL` (plants), `HE` (herbivores) or `CA` (carnivores) and `seq` is a per-kind
  counter starting at 1 (example: `HE0007`). Names are unique within a kind and identical for identical runs.

### Query
- `Species::living_count(kind, tick)`: the number of records of that kind with `arose_tick <= tick` and
  (`extinct_tick` absent or `> tick`). This answers any past tick from the records alone, with no per-tick history. A
  query for a tick later than the current tick returns an error.

### Storage (amends ADR-0011)
- `Organism.species: Option<SpeciesId>` (None only before the first founding check). Saved by the checkpoint (TASK-022).
- `Simulation.species: SpeciesRegistry`, passed to `from_parts` (another argument, as in TASK-016). The registry holds the
  records, the open candidates (reference genome, parent, counter, observed member ids) and the per-kind name counters.
  TASK-022 must save all of it.

## Consequences
- Performance: single linkage costs O(n^2 * L / 2) per check and kind. This is paid every 25 ticks only. The early-exit
  bound and the union-find keep it near the measured floor. Fallback: alternative 2 if the measured cost is above budget.
- Testability: the classifier is a pure function of `(kind, members, registry, settings, tick)` with no world, so the
  split, the threshold boundary, persistence and extinction are unit-testable with synthetic genomes.
- Determinism: fixed iteration orders (ids ascending, kinds in fixed order), integer distance sums, no RNG draws in
  classification. `dist/`: plain Rust, no new dependency.
- Known limitation: single linkage chains a continuous population into one species. A split needs a gap larger than the
  threshold in the chain of genomes. Measured in IMPLEMENT as the number of species over a long run; if it stays at one
  species per kind, the threshold is recalibrated (a configuration change, not a code change).
- Known limitation: a candidate that dies out before recognition leaves no record and no id.

## Verification strategy
- Unit tests on the pure classifier (synthetic genomes): two clusters with distance above the threshold split after
  `persistence_checks` checks; one check short of persistence does not split; a cluster that disappears resets its
  counter; distance exactly equal to the threshold (`k / (L * 255)` for an integer `k`) stays in one cluster; one unit
  above (`(k+1) / (L * 255)`) splits. The same boundary is tested for plants (L = 128).
- Tests for founding: `populate_initial` yields one recognised species per kind at tick 0.
- Tests for the family tree: parent links, `arose_tick`, `extinct_tick` at the death tick, ids never reused, names unique
  and identical for identical seeds.
- Tests for `living_count(kind, t)` at several past ticks in a run with a known split and extinction.
- Determinism: the same seed gives identical records, names and provisional ids after 1,000 ticks.
- Measurement (IMPLEMENT): time one species check at 2,000 animals and at 5,000 entities in release; record the numbers in
  ADR-0018 and `docs/ARCHITECTURE.md`. Record the number of species per kind after 2,000 ticks at the default configuration
  for three seeds (calibration evidence, not a pass criterion).

## Measurement (TASK-017 REVIEW cycle 1)
Machine and build as in `docs/ARCHITECTURE.md` (AMD Ryzen 5 7500F, 12 logical CPUs, rustc 1.100.0), `--release`, one probe run,
temporary probe removed afterwards. Times are one classifier call (`species::classify`) on the given members, with a fresh registry.

| Members | Genomes | Time per check |
|---|---|---|
| 2,000 animals (L = 256) | clonal ancestor + mutation (rate 0.002, strength 8) | 4.8 ms |
| 5,000 animals (L = 256) | clonal ancestor + mutation | 28.4 ms |
| 5,000 plants (L = 128) | clonal ancestor + mutation | 27.9 ms |
| 2,000 animals (L = 256) | independent random genomes (worst case, all distinct) | 66.9 ms |

At the default `species.check_interval` of 25 ticks, the 2,000-animal case costs about 0.2 ms per tick on average; 5,000 animals
about 1.1 ms per tick per kind. The budget is met in this case, so the fallback (alternative 2) is not needed.

Calibration (default configuration, 64 x 48, 400 plants, 120 herbivores, 20 carnivores, 2,000 ticks, seeds 1, 2, 3): no split
occurred. Seeds 1 and 3 kept one plant and one herbivore species (plants and herbivores alive at tick 2,000); the carnivore species
went extinct at ticks 269 (seed 1) and 284 (seed 3). Seed 2 lost all three kinds (extinct at ticks 353, 611 and 696). Single linkage therefore did not split a continuous lineage, which
is the expected behaviour of the rule; a split is not forced by the calibration. Plants only, 400 founders over 3,000 ticks, mutation
rate 0.002 and 0.02: one plant species, no split (the drift probe found no spurious split at the higher rate either).


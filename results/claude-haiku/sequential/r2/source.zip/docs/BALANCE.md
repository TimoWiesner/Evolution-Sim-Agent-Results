# Ecosystem balance (TASK-027)

Outcome in one paragraph: **the goal was not reached.** With the example configuration of `docs/CONTRACT.md` section 3
(64x48 cells, 400 plants, 120 herbivores, 20 carnivores, 10,000 ticks), no seed keeps plants, herbivores and carnivores
together to tick 10,000, neither before nor after this task. The one mechanism tried (T1, crowding dilutes predation)
did not improve the measure and is **not active** in the chosen defaults (`DILUTION = 0.0`, behaviour identical to the
baseline). Coexistence of all three kinds lasted a median of **337 ticks** on the tuning seeds before (20 seeds) and a
median of **258.5 ticks** on the held-out seeds 101 to 110 with the chosen defaults. Both figures are the first
extinction tick per seed (`L`, defined below); they are not comparable as a before/after improvement because the seed
sets differ. The defaults are therefore the baseline defaults, measured again, with one mechanism implemented and
measured as a negative result.

All numbers below come from `./evosim batch` (exit 0) or `./evosim run --metrics` (exit 0). Raw tables are in
`docs/results/TASK-027/`. Scripts: `scripts/balance_table.py` (extinction table from a batch directory) and
`scripts/balance_causes.py` (death causes and population curves from metrics files).

## Measure
- Per seed and kind: the first sampled tick with zero living individuals (`--sample-every 1`, so exact).
- `L` per seed = minimum extinction tick over the three kinds; `L = 10,000` if none dies out. "Coexistence length".
- Primary score: median `L` over the tuning seeds 1 to 20. Secondary: seeds with all three kinds alive at tick 10,000
  (**0 of 20 in every trial**). Tie-break: minimum `L`.
- Held-out check: seeds 101 to 110, run once on the chosen defaults only (ADR-0028 D3).

## Baseline (before any change; unchanged code at HEAD f7b9081)
Command: `./evosim batch --config examples/config.json --seeds 1,...,20 --ticks 10000 --sample-every 1 --out-dir /tmp/t27/baseline`
exit 0, 63.6 s. Table: `docs/results/TASK-027/baseline-table.md`; timing: `baseline-batch-timing.txt`.

| measure | value |
|---|---|
| median L (20 seeds) | 337 |
| min / max L | 157 / 418 |
| seeds with all three alive at 10,000 | 0 of 20 |
| plants extinct (not survived to 10,000) | 7 of 20 (ticks 1,536 to 7,951) |
| herbivore births, all 20 seeds, 10,000 ticks | 0 to 31 per seed |
| carnivore births | 0 to 4 per seed |

## Cause analysis of the first extinction (written before the first change)
Data: `docs/results/TASK-027/baseline-causes.txt` (metrics, `--sample-every 100`, seeds 1 to 20).
Note: the extinction ticks printed in that file are on the 100-tick sample grid; the exact ticks are in `baseline-table.md`.

1. **Which kind dies out first.** Carnivores, in 18 of 20 seeds; herbivores in 2 (seed 1: 157 vs 221; seed 12: 286 vs
   410). This **corrects the PLAN probe** (`docs/results/TASK-027-plan-probe.md`), which said herbivores die out first in
   all 10 probe seeds: its own table shows carnivores first in 9 of 10. The first-extinction analysis below is for the
   carnivores unless stated.
2. **Causes of death of the carnivores (all 20 seeds).** At the end of the carnivore collapse, every carnivore death
   is **starvation** in all seeds except two single old-age deaths (seeds 11 and 16 have one each; 20 to 24 starvation
   deaths per seed, the extra ones being carnivores born); there are no predation carnivore deaths. Carnivore births are 0 to 4
   in 10,000 ticks in every seed: the carnivore population never reproduces (reproduction energy 90; satiation 95; the
   carnivores are at mean energy about 45 to 55 while prey exist and fall once prey are gone).
3. **Causes of death of the herbivores.** Predation dominates: over the run, 104 to 125 of the herbivores that died in
   seeds 1 to 4 died by predation (seed 1: 120 of 120; seed 2: 125 predation and 14 old age; seed 3: 104 and 22; seed 4:
   118 and 5). In seed 1, 117 of 120 herbivores were killed by tick 100. Herbivore births are 0 to 31
   per seed, so the herbivore population is fed by very few offspring.
4. **Population curves (seed 1; seed 5 below shows the other ordering).** Tick 0: 400 plants / 120 herbivores / 20 carnivores.
   Tick 100: 458 / 3 / 17 (herbivores eaten, carnivores almost whole, mean energy 55). Tick 200: 312 / 0 / 1. The
   last carnivore starves at tick 221. Plants survive. In seed 5 the carnivores die at tick 200 while 83 herbivores
   still live (curve: 214 / 83 / 0 at tick 200), so the carnivore collapse is not caused by the herbivores being gone.
5. **Mechanism read from the data (partly hypothesis).** Carnivores attack once per tick in reach, so 20 carnivores can kill
   most of 120 herbivores within 100 ticks (seed 1; each kill gives up to 24 energy). Once the herbivores are gone, the
   carnivores have no food and starve (seed 1: about 20 to 120 ticks after the herbivores are gone). In seed 5 the
   carnivores starve by tick 200 while 83 herbivores are still alive; why the carnivores do not kill those herbivores is
   not measured (hypothesis: few carnivores are in reach 1 of a herbivore, and an attack succeeds with only about 0.5 to 0.9
   chance at a cost of 0.5 per attempt; a per-tick count of attempts and misses was not recorded).
6. **Plants.** Plants do not go extinct because of the herbivores: plants die out in 7 seeds, after 1,536 to 7,951 ticks,
   long after the animals (seed 1: plants still 468 at 10,000). The hypothesis that founder cohort ageing causes this is
   **not tested** here (no read-only `old_age` count per plant cohort was added).

Conclusion of the analysis: the food chain fails because the **predators eat the herbivores faster than the herbivores can
reproduce, and the predators have no reproduction of their own**. Herbivores breed rarely (founders start at energy 50,
below the herbivore reproduction threshold of 60, and predation removes most of them before they breed); carnivores
never reach their reproduction threshold of 90 and starve when prey runs out.

## Trials
Each row: what changed, what was expected, what was measured. Tuning seeds 1 to 20 unless noted.

| trial | change | expected | measured | helped? |
|---|---|---|---|---|
| baseline | none | - | median L 337; min 157; 0 of 20 all alive | - |
| T1a | `hunting::DILUTION = 0.5`: attack chance divided by `1 + 0.5*(n-1)`, n = living herbivores in the carnivore's own cell | herbivores survive longer in dense clusters, so more breed | median L 312.5 (min 170); herbivore extinction later in 12 of 20 seeds, carnivore extinction earlier in 11 of 20; 0 of 20 all alive; table `trial-T1a-dilution-0.5.md` | no (median fell) |
| T1b | `DILUTION = 0.1` (follow-up, smaller effect) | a milder version of T1a; no clear change expected | median L 337 (same as baseline); min 157; 0 of 20 all alive; `trial-T1b-dilution-0.1.md` | no (no change in the score) |
| T1 final | `DILUTION = 0.0` (mechanism present in code, factor is exactly 1) | identical to baseline | state hash of seeds 1 and 2 at 1,000 ticks unchanged (`fc057bf2...`, `8f813a8a...`) | adopted as the default; no effect |

Stop rule (ADR-0028 D3): two consecutive non-improving trials (T1a, T1b) ended the search. T2 (handling time after a kill)
and T3 (energy before predation) were **not tried**; they need per-organism state in the checkpoint (T2) or a
mating-refusal diagnostic (T3) that did not fit the time budget of this phase. Parameter-only trials (founder energy,
`BITE_MAX`, `P_BASE`, the reproduction thresholds) were **not tried**.

Reading of the negative result: dilution slows predation on clustered herbivores, but carnivores then lose their prey
supply later and starve at about the same time (T1b shows the same medians). The limit is carnivore reproduction and
attack efficiency, not only the kill rate on herbivore clusters.

## Held-out check (seeds 101 to 110, chosen defaults, 10,000 ticks)
Command: `./evosim batch --config examples/config.json --seeds 101,...,110 --ticks 10000 --sample-every 1 --out-dir /tmp/t27/heldout`, exit 0.
Table: `docs/results/TASK-027/heldout-101-110-final-defaults.md`.

- median L 258.5; min 143 (seed 102); max 436 (seed 106).
- seeds with all three alive at 10,000: **0 of 10**.
- plants extinct in 3 seeds (1,497, 1,547, 1,550 ticks).

## Before and after
| | tuning seeds 1 to 20 | held-out seeds 101 to 110 |
|---|---|---|
| before (baseline) | median L 337, min 157, 0 of 20 all alive | not measured before the change |
| after (chosen defaults, `DILUTION = 0`) | median L 337 (identical behaviour), min 157 | median L 258.5, min 143, 0 of 10 all alive |

The "before" figure of the held-out seeds was not measured on the unchanged build, and the chosen defaults behave like
the baseline, so the held-out result is evidence of the baseline's behaviour on new seeds, not an improvement.

## Goal
Not reached. No seed keeps the three kinds to tick 10,000 (tuning 0 of 20; held-out 0 of 10). Coexistence is not
guaranteed by the task (task.md, "Not part of this task"); the result is reported as measured.

## Remaining limits
- Carnivores never reproduce in practice (0 to 4 births per seed); their reproduction threshold (90) is above what
  they reach while prey exists, and the satiation threshold (95) caps the intake they can store.
- Herbivores breed rarely: founders start below the reproduction threshold (60) and predation removes most before they
  breed. A founder-energy or threshold change was not tried (parameter trials were not reached).
- Attack efficiency: a carnivore in reach 1 attacks the nearest herbivore only, at about 0.5 success, and pays 0.5 per
  attempt; no handling time or satiation-after-kill exists (trial T2 not done).
- Plant extinction at 1,500 to 8,000 ticks in 7 of 20 seeds is unexplained (cohort ageing hypothesis untested).
- The tuning-seed sample is small (20) and the held-out sample is 10 seeds; the number of trials is 3 (1 mechanism, 1
  follow-up, 1 final check), with no parameter sweep.
- `scenarios/demo.json` (CONTRACT section 7) is still missing; not part of this task's files.

## Regression values
The chosen defaults (`DILUTION = 0.0`) reproduce the previous state hashes exactly (seeds 1 and 2 at 1,000 ticks checked
before and after the change). No regression value was re-recorded.

## Performance with the chosen defaults (TASK-026 target)
`bash scripts/perf.sh` (exit 0) with the chosen defaults: median **1,084.9 ticks/s** (min 1,081.3, max 1,086.5; 5 repetitions
of 100 ticks, 2,173 living on the measured ticks, target 100 ticks/s and 2,000 living). TASK-026 review measured 1,081.7 ticks/s.
The state hash of the benchmark configuration is unchanged (`9fee0117...`), consistent with `DILUTION = 0`. No slowdown to explain.

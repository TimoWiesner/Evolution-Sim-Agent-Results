# TASK-018 survival results (IMPLEMENT cycle 1)

Command (must-have 7, ADR-0019 D5): `bash scripts/survival.sh` (wraps `cargo run --release --locked -q -p evosim-core --example survival -- --ticks 10000 --seeds 1,2,3,4,5`).
Held-out check (ADR-0019 D4): `cargo run --release --locked -q -p evosim-core --example survival -- --ticks 10000 --seeds 101,102,103,104,105`.

Defaults in force: world 64 x 48; initial plants 400, herbivores 120, carnivores 20; plants.max_age 1500; BITE_MAX 0.5; REGEN_RATE 0.1; SATIATION_CARNIVORE 95 (see TASK-018-calibration.md).

Exit status: `bash scripts/survival.sh` exit 0 (recorded in IMPLEMENT). Held-out run exit 0. Wall time for the five report seeds: about 8.6 s in total (release, this container).

## Report seeds 1 to 5

```
survival: world 64x48, initial plants 400 herbivores 120 carnivores 20, ticks 10000
seed 1: ticks run 10000, time 1.28 s
  Plant: survived ; initial 400 births 2810 deaths 2742 living 468
  Herbivore: died out at tick 157 ; initial 120 births 0 deaths 120 living 0
  Carnivore: died out at tick 221 ; initial 20 births 0 deaths 20 living 0
seed 2: ticks run 10000, time 1.78 s
  Plant: survived ; initial 400 births 5622 deaths 5285 living 737
  Herbivore: died out at tick 480 ; initial 120 births 19 deaths 139 living 0
  Carnivore: died out at tick 385 ; initial 20 births 0 deaths 20 living 0
seed 3: ticks run 10000, time 1.05 s
  Plant: survived ; initial 400 births 957 deaths 1202 living 155
  Herbivore: died out at tick 540 ; initial 120 births 6 deaths 126 living 0
  Carnivore: died out at tick 258 ; initial 20 births 0 deaths 20 living 0
seed 4: ticks run 10000, time 0.96 s
  Plant: died out at tick 1547 ; initial 400 births 167 deaths 567 living 0
  Herbivore: died out at tick 487 ; initial 120 births 3 deaths 123 living 0
  Carnivore: died out at tick 262 ; initial 20 births 0 deaths 20 living 0
seed 5: ticks run 10000, time 0.97 s
  Plant: died out at tick 5255 ; initial 400 births 202 deaths 602 living 0
  Herbivore: died out at tick 592 ; initial 120 births 31 deaths 151 living 0
  Carnivore: died out at tick 167 ; initial 20 births 0 deaths 20 living 0
```

## Held-out seeds 101 to 105

```
survival: world 64x48, initial plants 400 herbivores 120 carnivores 20, ticks 10000
seed 101: ticks run 10000, time 0.96 s
  Plant: died out at tick 1497 ; initial 400 births 155 deaths 555 living 0
  Herbivore: died out at tick 291 ; initial 120 births 4 deaths 124 living 0
  Carnivore: died out at tick 382 ; initial 20 births 2 deaths 22 living 0
seed 102: ticks run 10000, time 2.64 s
  Plant: survived ; initial 400 births 10630 deaths 9800 living 1230
  Herbivore: died out at tick 143 ; initial 120 births 2 deaths 122 living 0
  Carnivore: died out at tick 281 ; initial 20 births 1 deaths 21 living 0
seed 103: ticks run 10000, time 8.32 s
  Plant: survived ; initial 400 births 28244 deaths 25021 living 3623
  Herbivore: died out at tick 604 ; initial 120 births 24 deaths 144 living 0
  Carnivore: died out at tick 398 ; initial 20 births 2 deaths 22 living 0
seed 104: ticks run 10000, time 15.49 s
  Plant: survived ; initial 400 births 49518 deaths 44541 living 5377
  Herbivore: died out at tick 540 ; initial 120 births 15 deaths 135 living 0
  Carnivore: died out at tick 226 ; initial 20 births 0 deaths 20 living 0
seed 105: ticks run 10000, time 1.71 s
  Plant: survived ; initial 400 births 5528 deaths 4923 living 1005
  Herbivore: died out at tick 560 ; initial 120 births 40 deaths 160 living 0
  Carnivore: died out at tick 409 ; initial 20 births 0 deaths 20 living 0
```

## Reading

- No seed keeps all three kinds alive to 10,000 ticks: this is not met. Coexistence is measured here, not required by TASK-018 (task.md, Not part of this task).
- Carnivores die out in all 10 seeds, with 0 to 2 births per seed; herbivores die out in all 10 seeds, between tick 143 and 604.
- Plants survive in 7 of 10 seeds (they die out in seeds 4 and 5 of the report at 1547 and 5255, and in seed 101 at 1497). Plants reach 1,000 to 5,400 individuals in some seeds, above the 1,000 to 5,000 target for the whole world with animals.
- Seed 104 took about 15 s of wall time because of about 5,000 plants; the cost of large plant populations is not optimised in this task.

## Timing (rough, one run, not a benchmark)

At about 2,000 organisms at the start (1,500 plants, 400 herbivores, 100 carnivores, seed 1): 200 ticks in 0.15 s
(about 0.75 ms per tick while the population is at its start size; the populations fall after tick 50 in this setting).
The 100 ticks/s goal of `docs/PROJECT.md` at 2,000 entities is not claimed here.

# TASK-018 calibration log (IMPLEMENT cycle 1)

Every candidate the implementer ran, with the measured outcome. All runs: release build, 64 x 48 world, fixed keys plus
the stated initial population, `populate_initial`, `tick`. "died@t" is the tick at which the kind had no living organism;
"S" is survived to the last tick. Numbers are per seed.

Calibration seeds are 1 to 5. The held-out seeds 101 to 105 were run only for the final defaults (see
`TASK-018-survival.md`). Candidates were applied with temporary `sed` edits of the constants and reverted after each run
(`/tmp` scripts, not part of the repository).

## 0. Starting point (after the lifespan scale fix, ADR-0019 D2, old defaults)

Defaults before calibration except D2: plants 400, herbivores 120, carnivores 20; `max_age` 500 / 300 / 400.
10,000 ticks, seeds 1 to 5:

| seed | plants | herbivores | carnivores (births) |
|---|---|---|---|
| 1 | died@1616 | died@638 | died@375 (0) |
| 2 | died@146 | died@207 | died@299 (0) |
| 3 | died@197 | died@277 | died@336 (0) |
| 4 | died@514 | died@493 | died@345 (0) |
| 5 | died@153 | died@256 | died@290 (0) |

Finding: the scale fix alone makes herbivores breed (births 87 to 139 per seed, where they had 0 to 23 before) but
the kinds still collapse. Plant-only runs also collapse (plants died@146 to 1616 with animals present); before the fix
plants survived in all five seeds, because the lifespan of the founders was about 5,000 ticks. Death causes (seed 1):
plants starve (427) and grow old (37); herbivores are eaten (183 predation) and starve (25); carnivores starve (19 of 20).

## 1. Plant-side and herbivore-side grid (single and paired constants), 3000 ticks, seeds 1 to 5, default animals

Grid on `MAINT_BASE` (plant maintenance, default 0.5), `REQUEST_MAX` (4.0), `REGEN_RATE` (0.05), 400/120/20:

| candidate | plants | herbivores | carnivores |
|---|---|---|---|
| maint 0.5, req 4, regen 0.05 (default) | died@2832, S, S(1), 588, 1582 | - | - |
| maint 0.5, req 4, regen 0.2 | S(4), S(175), died@2403, 605, 1622 | - | - |
| maint 0.5, req 8, regen 0.05 | all S (2,433 to 2,579 plants) | not run | not run |
| maint 0.5, req 8, regen 0.2 | all S (about 10,000 plants) | not run | not run |
| maint 0.2, req 4, regen 0.05 | all S (2,000 to 3,000) | not run | not run |
| maint 0.2, req 4, regen 0.2 | all S (about 9,000) | not run | not run |
| maint 0.2, req 8, regen 0.05 | all S (about 3,000) | not run | not run |
| maint 0.2, req 8, regen 0.2 | not completed (stopped: too many plants, very slow) | | |
| maint 0.2 with 120 herbivores and 20 carnivores (default world) | died@460, 176, S(234), 246, 188 | died@576, 262, 295, 374, 319 | died@353 to 379, births 0 |
| maint 0.35 (default world) | died@383, 151, 214, 398, 156 | died@253 to 523 | died@311 to 379, births 0 |
| maint 0.3 (default world) | died@311, 192, S(10), 404, 194 | died@270 to 529 | died@328 to 379, births 0 |

Reading: maintenance 0.2 keeps plants alive on their own but makes them explode (thousands of plants), and then the
herbivores still die. Maintenance 0.5 lets plants collapse with herbivores present. No value in between gave a food chain.

## 2. Herbivore intake and plant regeneration (2000 to 3000 ticks, seeds 1 to 5)

| candidate | herbivores | carnivores |
|---|---|---|
| BITE_MAX 1.0 (default world, 2000 ticks, seeds 1 to 5) | died@558, 332, 438, 561, 337 | died@374 to 407, births 0 |
| BITE_MAX 0.5 (default world, 3000 ticks) | died@317 to 590 | died@309 to 412, births 0 to 27 |
| BITE_MAX 2.0, REGEN 0.1 (default world, 2000 ticks) | died@212 to 509 | died@310 to 375, births 0 |

## 3. Carnivore satiation (must be above the mating threshold of 90, ADR-0017)

`SATIATION_CARNIVORE` 70 means a carnivore stops hunting at 70 and can never reach the mating threshold of 90, so
carnivores can never breed at 70 (0 carnivore births in all five seeds, 2000 ticks, BITE_MAX 2.0). This is a structural
consistency fix, not a tuning choice; 95 was chosen. At 95 carnivore births were 0 to 6 per seed, and carnivores still
starved (see section 7).

## 4. Herbivores with plenty of plants (1500 plants, 120 herbivores, 0 carnivores, 500 ticks, seeds 1 to 3)

This is the must-have "herbivores with plenty of plants survive and reproduce for several hundred ticks".

| BITE_MAX / REGEN_RATE | result |
|---|---|
| 2.0 / 0.05 (default) | herbivores died@290, 300 (seeds 1, 2) |
| 1.0 / 0.1 with plant maintenance 0.35 | died@372, 388, 380 |
| 0.75 / 0.1 | died@423 to 444 |
| 0.75 / 0.2 | died@410 to 482 |
| 0.5 / 0.1 | survived 500 ticks, births 63 to 72 per seed |
| 0.5 / 0.2 | survived 500 ticks, births 63 to 70 per seed |

## 5. Plant-only persistence (1000 ticks, seeds 1 to 5)

With the plant maximum age centre 500 (ADR-0019 D2 applied to `plants.max_age` 500), the founders of a seed are
clones of one ancestor (ADR-0018 D1) and grow old together: seed 4 lost all plants at tick 588, 317 of 592 plant
deaths by old age. Raising the centre `plants.max_age` to 1500 (lifespan 750 to 2250) makes all five seeds survive
1000 ticks, and survive 3000 ticks in four of five seeds (one seed died at tick 1546 to 1590 at other settings).

## 6. Chosen defaults (candidate D), 10,000 ticks

Changed defaults: `plants.max_age` 500 to 1500; `BITE_MAX` 2.0 to 0.5; `REGEN_RATE` 0.05 to 0.1;
`SATIATION_CARNIVORE` 70 to 95. Full output: `TASK-018-survival.md`.

Report seeds 1 to 5 (10,000 ticks): plants survived in seeds 1, 2, 3 and died out at 1547 (seed 4) and 5255 (seed 5);
herbivores died out at 157, 480, 540, 487, 592; carnivores at 221, 385, 258, 262, 167 (0 carnivore births in each of the five seeds).

Held-out seeds 101 to 105 (10,000 ticks): plants survived in 102 to 105 and died out at 1497 (seed 101); herbivores
died out at 143 to 604; carnivores at 226 to 409 (births 0 to 2 per seed).

Result: no seed keeps all three kinds alive to 10,000 ticks. The must-have points that are not about coexistence
are met (see the tests in `food_chain_tests.rs`).

## 7. Carnivore probes with candidate D (10,000 ticks, seeds 1 to 5), none adopted

| change | carnivores died out at (births per seed) |
|---|---|
| none (candidate D) | 221, 385, 258, 262, 167 (0, 0, 0, 0, 0) |
| `P_BASE` 0.5 to 0.9 | 199, 327, 312, 354, 365 (0, 0, 2, 0, 0) |
| `BASE_COST_CARNIVORE` 0.4 to 0.2 and `ATTACK_COST` 0.5 to 0.2 | 251, 412, 276, 217, 365 (0, 6, 0, 1, 0) |
| `MEAL_MAX` 30 to 60 | 224, 412, 374, 237, 365 (0, 1, 0, 0, 0) |
| `MEAL_MAX` 60, `ATTACK_COST` 0.2, `BASE_COST_CARNIVORE` 0.2 | 375, 412, 374, 377, 365 (5, 3, 6, 1, 0) |

Conclusion: no single or paired carnivore constant gives a carnivore population that breeds or survives. Carnivores die
of starvation within a few hundred ticks in every run. Their energy income from hunting does not cover their costs at
these constants, and the cause is not yet identified (see the STATE risks). Left for a later cycle.

## Not calibrated (kept)

`herbivores.metabolism`, `carnivores.metabolism`, `plants.growth_rate` remain unused by the engine (ADR-0006 notes).
`SEED_*`, `CAP_MAX`, `REQUEST_MAX`, `MATE_*`, `COMPAT_MAX` were not changed.

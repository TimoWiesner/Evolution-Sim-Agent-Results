| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 101 | 1497 | 291 | 382 | 291 | no | 4 | 2 |
| 102 | survives | 143 | 281 | 143 | no | 2 | 1 |
| 103 | survives | 604 | 398 | 398 | no | 24 | 2 |
| 104 | survives | 540 | 226 | 226 | no | 15 | 0 |
| 105 | survives | 560 | 409 | 409 | no | 40 | 0 |
| 106 | 1547 | 510 | 436 | 436 | no | 25 | 2 |
| 107 | survives | 602 | 198 | 198 | no | 11 | 0 |
| 108 | survives | 285 | 167 | 167 | no | 0 | 0 |
| 109 | survives | 444 | 171 | 171 | no | 4 | 0 |
| 110 | 1550 | 318 | 365 | 318 | no | 8 | 2 |

seeds: 10
median L: 258.5
min L: 143
seeds with all three kinds alive at tick_end: 0 of 10

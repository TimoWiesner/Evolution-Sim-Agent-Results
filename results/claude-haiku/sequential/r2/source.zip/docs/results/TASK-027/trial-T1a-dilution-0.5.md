| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 495 | 198 | 198 | no | 2 | 2 |
| 2 | survives | 514 | 208 | 208 | no | 23 | 0 |
| 3 | survives | 581 | 319 | 319 | no | 4 | 0 |
| 4 | 1537 | 521 | 272 | 272 | no | 8 | 0 |
| 5 | 7429 | 600 | 170 | 170 | no | 24 | 0 |
| 6 | survives | 307 | 190 | 190 | no | 0 | 0 |
| 7 | 1553 | 479 | 413 | 413 | no | 18 | 0 |
| 8 | survives | 511 | 279 | 279 | no | 7 | 0 |
| 9 | survives | 532 | 284 | 284 | no | 3 | 0 |
| 10 | survives | 621 | 404 | 404 | no | 27 | 0 |
| 11 | survives | 568 | 266 | 266 | no | 12 | 4 |
| 12 | 2505 | 463 | 352 | 352 | no | 5 | 1 |
| 13 | survives | 311 | 377 | 311 | no | 13 | 4 |
| 14 | survives | 392 | 379 | 379 | no | 11 | 0 |
| 15 | 1682 | 294 | 298 | 294 | no | 2 | 2 |
| 16 | survives | 567 | 338 | 338 | no | 14 | 0 |
| 17 | survives | 618 | 333 | 333 | no | 12 | 0 |
| 18 | survives | 611 | 322 | 322 | no | 17 | 0 |
| 19 | survives | 582 | 314 | 314 | no | 13 | 3 |
| 20 | 1634 | 316 | 347 | 316 | no | 5 | 3 |

seeds: 20
median L: 312.5
min L: 170
seeds with all three kinds alive at tick_end: 0 of 20

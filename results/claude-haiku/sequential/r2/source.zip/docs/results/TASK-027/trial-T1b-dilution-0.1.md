| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 | no | 0 | 0 |
| 2 | survives | 517 | 258 | 258 | no | 23 | 0 |
| 3 | survives | 590 | 266 | 266 | no | 17 | 0 |
| 4 | 1566 | 302 | 189 | 189 | no | 0 | 1 |
| 5 | 5473 | 604 | 365 | 365 | no | 35 | 0 |
| 6 | survives | 601 | 280 | 280 | no | 4 | 0 |
| 7 | 1536 | 564 | 394 | 394 | no | 21 | 0 |
| 8 | 6514 | 469 | 307 | 307 | no | 11 | 0 |
| 9 | survives | 512 | 303 | 303 | no | 5 | 0 |
| 10 | survives | 605 | 403 | 403 | no | 21 | 3 |
| 11 | survives | 543 | 356 | 356 | no | 9 | 2 |
| 12 | 3462 | 587 | 363 | 363 | no | 9 | 0 |
| 13 | survives | 615 | 364 | 364 | no | 11 | 3 |
| 14 | survives | 448 | 376 | 376 | no | 11 | 0 |
| 15 | 1679 | 440 | 360 | 360 | no | 8 | 0 |
| 16 | survives | 605 | 320 | 320 | no | 17 | 0 |
| 17 | survives | 648 | 247 | 247 | no | 18 | 0 |
| 18 | survives | 551 | 381 | 381 | no | 16 | 1 |
| 19 | survives | 594 | 354 | 354 | no | 10 | 1 |
| 20 | 1632 | 316 | 338 | 316 | no | 5 | 0 |

seeds: 20
median L: 337.0
min L: 157
seeds with all three kinds alive at tick_end: 0 of 20

| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 | no | 0 | 0 |
| 2 | survives | 480 | 385 | 385 | no | 19 | 0 |
| 3 | survives | 540 | 258 | 258 | no | 6 | 0 |
| 4 | 1547 | 487 | 262 | 262 | no | 3 | 0 |
| 5 | 5255 | 592 | 167 | 167 | no | 31 | 0 |
| 6 | survives | 544 | 189 | 189 | no | 2 | 1 |
| 7 | 1536 | 564 | 394 | 394 | no | 21 | 0 |
| 8 | 7951 | 466 | 411 | 411 | no | 7 | 0 |
| 9 | survives | 309 | 213 | 213 | no | 2 | 0 |
| 10 | survives | 610 | 410 | 410 | no | 23 | 4 |
| 11 | survives | 494 | 356 | 356 | no | 10 | 2 |
| 12 | 2985 | 286 | 410 | 286 | no | 5 | 2 |
| 13 | survives | 614 | 370 | 370 | no | 29 | 0 |
| 14 | survives | 417 | 188 | 188 | no | 4 | 0 |
| 15 | 1679 | 440 | 360 | 360 | no | 8 | 0 |
| 16 | survives | 587 | 418 | 418 | no | 15 | 2 |
| 17 | survives | 659 | 348 | 348 | no | 12 | 0 |
| 18 | survives | 606 | 388 | 388 | no | 25 | 0 |
| 19 | survives | 559 | 326 | 326 | no | 17 | 3 |
| 20 | 1621 | 446 | 308 | 308 | no | 3 | 0 |

seeds: 20
median L: 337.0
min L: 157
seeds with all three kinds alive at tick_end: 0 of 20

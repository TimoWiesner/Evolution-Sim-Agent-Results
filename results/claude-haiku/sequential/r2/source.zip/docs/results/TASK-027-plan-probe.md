# TASK-027 PLAN probe: baseline preview and first-extinction diagnostic

Status: PLAN probe, not the official baseline. The official baseline is measured in IMPLEMENT before any change
(task.md, must-have 1). No product code was changed in PLAN; the runs below used the unchanged HEAD build (commit 6c34696).
Scratch output was written to /tmp and is not kept; the commands are recorded so they can be repeated.

## Commands (exit codes)
1. `./evosim batch --config examples/config.json --seeds 1,2,...,10 --ticks 10000 --sample-every 1 --out-dir /tmp/t27probe/base10` -> exit 0, 27 s wall time (about 2.7 s per 10,000-tick seed, release build).
2. `./evosim run --config examples/config.json --seed 1 --ticks 10000 --out ... --metrics ... --sample-every 100` -> exit 0 (death causes, seed 1).
Extinction tick = first sample with living count 0 (`--sample-every 1`, so exact).

## Per-seed result (examples/config.json: 64x48, 400 plants, 120 herbivores, 20 carnivores; 10,000 ticks)
| seed | herbivores extinct at | carnivores extinct at | plants | herbivore births | carnivore births |
|---|---|---|---|---|---|
| 1 | 157 | 221 | survive (468) | 0 | 0 |
| 2 | 480 | 385 | survive (737) | 19 | 0 |
| 3 | 540 | 258 | survive (155) | 6 | 0 |
| 4 | 487 | 262 | extinct at 1547 | 3 | 0 |
| 5 | 592 | 167 | extinct at 5255 | 31 | 0 |
| 6 | 544 | 189 | survive (5645) | 2 | 1 |
| 7 | 564 | 394 | extinct at 1536 | 21 | 0 |
| 8 | 466 | 411 | extinct at 7951 | 7 | 0 |
| 9 | 309 | 213 | survive (629) | 2 | 0 |
| 10 | 610 | 410 | survive (213) | 23 | 4 |

Summary: herbivores die out first in all 10 seeds (309 to 610). Carnivores die out in all 10 (167 to 411). Coexistence
length (all three kinds alive) is therefore 157 to 610 ticks in every seed; no seed keeps the food chain to 10,000 ticks.
Plants survive to 10,000 in 6 of 10 seeds.

## Seed 1 death causes (metrics file, samples every 100 ticks)
| tick | plants | herbivores (deaths by cause) | carnivores (deaths by cause) |
|---|---|---|---|
| 0 | 400 | 120, mean energy 50.0 | 20, mean energy 50.0 |
| 100 | 458 | 3 living, 117 dead by **predation**, herbivore births 0, mean energy 55.3 | 17 living, 3 dead by starvation, mean energy 54.9 |
| 200 | 312 | 0 living, 120 dead by predation | 1 living, 19 dead by starvation |
| 300 onward | 308 to 434 | 0 | 0 (20 dead by starvation) |

## Reading of the diagnostic (hypotheses for IMPLEMENT to confirm on all 10 seeds)
1. The first extinction is herbivores, killed by predation: 117 of 120 herbivores are eaten in the first 100 ticks by 20
   carnivores. Herbivores have zero births in seed 1 and few in the others (0 to 31 in 10,000 ticks).
2. Herbivores never reach the mating threshold. Founders start at energy 50 (`sim::FOUNDER_ENERGY`), and the herbivore
   mating threshold is 60 (`reproduction_energy`); mating also needs maturity (20 % of a lifespan of about 300) and a
   compatible partner (ADR-0017). Predators cull them before most reach the threshold. Mating refusals by reason are
   not recorded yet; IMPLEMENT adds a read-only counter for this (diagnostic, no rule change).
3. Carnivores have zero births in 9 of 10 seeds. Their energy falls after the herbivores are gone (mean energy about 20
   at tick 200 in seed 1), and they starve. Their reproduction threshold is 90 and satiation is 95 (`hunting.rs`).
4. Plants: in the four seeds where plants die out (1,536 to 7,951), extinction comes long after the herbivores, so grazing
   is not the cause. Hypothesis: founders are clones of one ancestor and age together (ADR-0019 implementation record), so
   the plant cohort dies of old age around ticks 750 to 2,250 unless seeding replaces it. To be checked with the
   `old_age` death counts.
5. Predation rule (ADR-0016, `hunting::attack_chance`): the chance depends only on attacker and prey traits and the prey's
   caution. Nothing reduces it when many herbivores share a cell, so a cluster is eaten as fast as a single animal.

## Consequences for the plan
- Candidate mechanisms are listed in `docs/decisions/ADR-0028-ecosystem-balance.md` (dilution in a crowded cell, handling
  time after a kill, and a founder-energy/reproduction-threshold check).
- A parameter-only change (for example the founder energy) is not enough by itself; the task needs at least one
  mechanism change, which is planned as trial T1.

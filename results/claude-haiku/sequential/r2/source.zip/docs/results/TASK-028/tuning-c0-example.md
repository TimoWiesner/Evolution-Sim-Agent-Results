| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 | no | 0 | 0 |
| 2 | survives | 480 | 385 | 385 | no | 19 | 0 |
| 3 | survives | 540 | 258 | 258 | no | 6 | 0 |
| 4 | 1547 | 487 | 262 | 262 | no | 3 | 0 |
| 5 | 5255 | 592 | 167 | 167 | no | 31 | 0 |
| 6 | survives | 544 | 189 | 189 | no | 2 | 1 |
| 7 | 1536 | 564 | 394 | 394 | no | 21 | 0 |
| 8 | 7951 | 466 | 411 | 411 | no | 7 | 0 |
| 9 | survives | 309 | 213 | 213 | no | 2 | 0 |
| 10 | survives | 610 | 410 | 410 | no | 23 | 4 |

seeds: 10
median L: 260.0
min L: 157
seeds with all three kinds alive at tick_end: 0 of 10

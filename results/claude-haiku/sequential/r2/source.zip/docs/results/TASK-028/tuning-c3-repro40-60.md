| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 439 | 208 | 208 | no | 7 | 1 |
| 2 | survives | 374 | 412 | 374 | no | 39 | 6 |
| 3 | survives | 298 | 235 | 235 | no | 27 | 9 |
| 4 | 1546 | 575 | 239 | 239 | no | 23 | 2 |
| 5 | 7657 | 403 | 313 | 313 | no | 60 | 7 |
| 6 | survives | 306 | 296 | 296 | no | 10 | 4 |
| 7 | 1517 | 530 | 413 | 413 | no | 58 | 1 |
| 8 | 7971 | 295 | 336 | 295 | no | 19 | 2 |
| 9 | survives | 594 | 236 | 236 | no | 22 | 5 |
| 10 | survives | 533 | 404 | 404 | no | 61 | 6 |

seeds: 10
median L: 295.5
min L: 208
seeds with all three kinds alive at tick_end: 0 of 10

| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 317 | 230 | 230 | no | 0 | 0 |
| 2 | survives | 335 | 412 | 335 | no | 23 | 3 |
| 3 | survives | 572 | 374 | 374 | no | 15 | 2 |
| 4 | 1541 | 450 | 186 | 186 | no | 1 | 0 |
| 5 | 3812 | 569 | 178 | 178 | no | 26 | 0 |

seeds: 5
median L: 230
min L: 178
seeds with all three kinds alive at tick_end: 0 of 5

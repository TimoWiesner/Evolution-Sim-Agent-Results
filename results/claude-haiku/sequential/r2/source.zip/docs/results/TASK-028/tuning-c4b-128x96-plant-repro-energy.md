| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 699 | 263 | 263 | no | 36 | 0 |
| 2 | survives | 618 | 272 | 272 | no | 49 | 0 |
| 3 | survives | 547 | 374 | 374 | no | 46 | 0 |
| 4 | 2743 | 984 | 254 | 254 | no | 44 | 0 |
| 5 | survives | 960 | 96 | 96 | no | 74 | 0 |
| 6 | survives | 1747 | 302 | 302 | no | 71 | 0 |
| 7 | 1518 | 609 | 388 | 388 | no | 56 | 0 |
| 8 | survives | 562 | 244 | 244 | no | 36 | 1 |
| 9 | survives | 888 | 186 | 186 | no | 25 | 0 |
| 10 | survives | 532 | 353 | 353 | no | 62 | 0 |

seeds: 10
median L: 267.5
min L: 96
seeds with all three kinds alive at tick_end: 0 of 10

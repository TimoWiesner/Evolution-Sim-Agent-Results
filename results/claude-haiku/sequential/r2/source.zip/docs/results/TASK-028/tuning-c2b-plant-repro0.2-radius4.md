| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 317 | 230 | 230 | no | 0 | 0 |
| 2 | survives | 335 | 412 | 335 | no | 23 | 3 |
| 3 | survives | 572 | 374 | 374 | no | 15 | 2 |
| 4 | 1541 | 450 | 186 | 186 | no | 1 | 0 |
| 5 | 3812 | 569 | 178 | 178 | no | 26 | 0 |
| 6 | survives | 426 | 216 | 216 | no | 2 | 0 |
| 7 | 1521 | 592 | 413 | 413 | no | 23 | 0 |
| 8 | 6760 | 530 | 370 | 370 | no | 17 | 0 |
| 9 | survives | 471 | 380 | 380 | no | 8 | 0 |
| 10 | survives | 608 | 404 | 404 | no | 31 | 0 |

seeds: 10
median L: 352.5
min L: 178
seeds with all three kinds alive at tick_end: 0 of 10

| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 101 | 1493 | 555 | 411 | 411 | no | 19 | 2 |
| 102 | survives | 237 | 380 | 237 | no | 5 | 0 |
| 103 | survives | 635 | 398 | 398 | no | 26 | 0 |
| 104 | survives | 599 | 185 | 185 | no | 12 | 2 |
| 105 | survives | 618 | 409 | 409 | no | 42 | 0 |
| 106 | 1546 | 551 | 394 | 394 | no | 32 | 0 |
| 107 | survives | 569 | 224 | 224 | no | 12 | 2 |
| 108 | survives | 103 | 198 | 103 | no | 0 | 0 |
| 109 | survives | 316 | 194 | 194 | no | 0 | 0 |
| 110 | 1551 | 533 | 306 | 306 | no | 5 | 2 |

seeds: 10
median L: 271.5
min L: 103
seeds with all three kinds alive at tick_end: 0 of 10

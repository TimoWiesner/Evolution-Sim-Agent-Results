| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 629 | 229 | 229 | no | 14 | 0 |
| 2 | survives | 574 | 399 | 399 | no | 17 | 0 |
| 3 | survives | 499 | 130 | 130 | no | 17 | 0 |
| 4 | 2271 | 599 | 165 | 165 | no | 22 | 0 |
| 5 | survives | 608 | 94 | 94 | no | 13 | 0 |
| 6 | survives | 610 | 188 | 188 | no | 8 | 0 |
| 7 | 1614 | 616 | 272 | 272 | no | 18 | 0 |
| 8 | survives | 569 | 268 | 268 | no | 7 | 0 |
| 9 | survives | 608 | 180 | 180 | no | 10 | 0 |
| 10 | survives | 606 | 237 | 237 | no | 23 | 0 |

seeds: 10
median L: 208.5
min L: 94
seeds with all three kinds alive at tick_end: 0 of 10

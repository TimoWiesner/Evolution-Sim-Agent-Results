| seed | plants ext. | herbivores ext. | carnivores ext. | L (first ext.) | all 3 alive at end | herb births | carn births |
|---|---|---|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 | no | 0 | 0 |
| 2 | survives | 480 | 385 | 385 | no | 19 | 0 |
| 3 | survives | 540 | 258 | 258 | no | 6 | 0 |
| 4 | 1547 | 487 | 262 | 262 | no | 3 | 0 |
| 5 | 5255 | 592 | 167 | 167 | no | 31 | 0 |

seeds: 5
median L: 258
min L: 157
seeds with all three kinds alive at tick_end: 0 of 5

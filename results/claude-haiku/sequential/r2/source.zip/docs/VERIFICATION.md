# Verification, demo scenario and self-audit (TASK-028)

This file is the evidence record of the final product: every command of `docs/CONTRACT.md` with its exit status and the
test or script that proves it, the randomised invariant tests, the choice and the measured coexistence of the demo
scenario, the distributable check, the self-audit against `docs/PROJECT.md`, and the known limitations.
Raw outputs are in `docs/results/TASK-028/`. Everything here was produced in IMPLEMENT cycle 1 of TASK-028 unless
a row says otherwise. Where a claim is not checked it is marked as such.

Environment of the runs: AMD Ryzen 5 7500F (12 logical CPUs), Ubuntu 24.04 container, rustc 1.100.0 from
`/opt/rust/cargo/bin`, `chromium` 131 at `/usr/local/bin/chromium`. Date of the runs: 2026-11-18. No system package was
installed in this phase.

## 1. One-command gate

| command | exit | time | result |
|---|---|---|---|
| `./scripts/test.sh` (full run, after all changes of this phase) | 0 | 1 min 07 s wall | `ALL TESTS PASSED`; log saved as `docs/results/TASK-028/test-run.log` |
| `cargo test --workspace --locked --offline` (inside the script) | 0 | about 25 s | core 436 passed + 1 ignored; cli 36 / 8 / 2 / 9 passed; ui 95 passed + 1 ignored; core `invariant` 8 passed |
| `cargo clippy --workspace --all-targets --locked --offline` | 0 | - | 0 warnings |
| `bash scripts/check_adrs.sh` (inside the script) | 0 | - | ADR and record checks pass |
| `./build.sh` (inside the script) | 0 | - | writes `dist/evosim` |

`scripts/test.sh` runs these steps in order: 1 ADR checks; 2 `cargo test --workspace`; 3 `./setup.sh`; 4 `./build.sh`;
5 black-box `./evosim` (version, help, unknown command); 6 `dist/evosim` (version, help, unknown command); 7 `ldd`;
8 `run` (determinism, `tick_end`, missing configuration, checkpoint split run, truncated checkpoint); 9 `batch`
(determinism for two thread counts, CSV, run count, unknown sweep key); 10 demo and example configuration, six runs of
10,000 ticks (seeds 1 to 3) with the accounting check `initial + births - deaths = final`, and the demo through `run`;
11 `ui --smoke-test` and `ui --screenshots` on the demo and example configurations, with a PNG size check
(`main.png` 1280x807); 12 release-mode randomised invariants (`EVOSIM_INVARIANT_CASES=200`).

## 2. CONTRACT conformance matrix

Status key: **verified** = a recorded command with the expected exit status and output, run in this phase.

| CONTRACT item | command (as run) | expected | observed | status |
|---|---|---|---|---|
| 1 `./setup.sh` idempotent, root in a fresh container | `./setup.sh` (inside `test.sh`, twice in this phase) | exit 0 | exit 0 | verified (the fresh-state `rm -rf target dist` build was not repeated in this phase, see limitations) |
| 1 `./evosim` from any directory | `(cd /tmp && /workspace/evosim version)` | exact JSON | exact JSON | verified (`test.sh` 5) |
| 1 `./build.sh` writes `dist/evosim` | `./build.sh` | exit 0 | exit 0 | verified (`test.sh` 4) |
| 2 `version` | `./evosim version` | `{"name": "evosim", "version": "0.1.0", "contract": 1}` | exact | verified |
| 2 `run` options and output keys | `./evosim run --config examples/config.json --ticks 300 --seed 7 --out F` | result keys of section 4 | keys present (`test.sh` 8) | verified |
| 2 `run --ticks 0` | `./evosim run --config examples/config.json --ticks 0 --out F` | exit 0, `tick_end` 0, series one row | exit 0, `tick_end` 0, series `[tick 0]` | verified (`contract-checks/contract-checks.txt`) |
| 2 `--sample-every` | `--ticks 100 --seed 9 --sample-every 25` | series ticks 0, 25, 50, 75, 100 | `[0, 25, 50, 75, 100]` | verified (`contract-checks.txt`) |
| 2 `--seed` overrides the file | `--seed 9` on the example, `"seed"` in result | `seed` 9 | 9 | verified (`contract-checks.txt`) |
| 2 `--save` / `--load` | `test.sh` 8: 37 ticks saved, 263 loaded | same `final`, `totals`, `state_hash` as 300 ticks | equal | verified |
| 2 `--load` with `--config` | `run --config ... --load FILE` | exit 2 (not in contract text; our rule) | exit 2 with message | verified (`contract-checks.txt`) |
| 2 `batch` | `./evosim batch --config examples/config.json --seeds 3 --ticks 20 --out-dir D` | `D/seed-3.json` and `D/summary.json` | files present | verified (`contract-checks.txt`) |
| 2 `ui` without options | `./evosim ui` | starts a server and prints the URL | `ui --port 8080 --config ...` used in README; not re-run here | partly verified (the server path is exercised by the smoke test) |
| 2 `ui --smoke-test` | `./evosim ui --smoke-test --config scenarios/demo.json` | exit 0 within 60 s; at least 10 ticks; a frame | `smoke test passed (smoke frames=1 tick=14)`, exit 0, about 1 s | verified |
| 2 `ui --screenshots DIR` | `./evosim ui --screenshots DIR --config examples/config.json` | exit 0; `DIR/main.png` at least 1280x720 | exit 0; `main.png` 1280x807, `charts.png` | verified (`test.sh` 11) |
| 2 `ui --screenshots` with missing DIR | `./evosim ui --screenshots /no/such/dir` | exit 2 | exit 2 ("screenshot directory ... does not exist") | verified (`contract-checks.txt`) |
| 3 configuration: JSON, fixed keys only | `examples/config.json` (CONTRACT section 3 example) | valid | valid | verified (`test.sh` 8, 10) |
| 3 missing fixed key | `{"seed":1,"world":{...}}` | exit 2, names key | exit 2, `initial.plants: missing required key` | verified |
| 3 wrong type | `"seed":"x"` | exit 2 | exit 2, `seed: expected integer, found string` | verified |
| 3 out of range | `"width":0` | exit 2 | exit 2, `world.width: 0 is out of range 1..=4096` | verified |
| 3 unknown key | `"bogus":{...}` | exit 2 (our rule) | exit 2, `bogus: unknown key` | verified |
| 4 result JSON | `run` output | keys of section 4 | present; `totals.initial + births - deaths = final` holds for every kind in the 6 long runs (`test.sh` 10) | verified |
| 4 `state_hash` | two runs with the same seed | equal | equal (`test.sh` 8) | verified |
| 5.1 determinism, different seeds | `test.sh` 8; `invariant_tests::different_seeds_give_different_state_hashes` | equal / different | equal / different | verified |
| 5.2 checkpoints | `test.sh` 8; `invariant_tests::checkpoint_split_run_equals_uninterrupted_run` | equal | equal | verified |
| 5.3 no replenishment | `--initial plants 0`, 5 herbivores, 3 carnivores, 300 ticks | all kinds 0 | all kinds 0 at tick 300; totals show no births | verified (`contract-checks.txt`) |
| 5.4 errors | `test.sh` 8 and 9; `contract-checks.txt` | exit 2, stderr message, no result file | as listed above | verified |
| 5.5 clean output | `./evosim version` and `run`, `batch` stdout | only JSON from `version`; `run` and `batch` print nothing on stdout | as tested in `test.sh` 5, 8, 9 | verified |
| 6 `dist/` self-contained | copy of `dist/evosim` and `config.json` into an empty `mktemp -d` outside the workspace, `env -i PATH=/usr/bin:/bin` | `version`, `run` work | `version` exact JSON, `run --ticks 10000` exit 0, `--help` exit 0 | verified (not on a plain Ubuntu machine, see limitations) |
| 6 `dist/` dependencies | `ldd dist/evosim` | glibc, libgcc_s, loader only (plus libm, which glibc provides) | `linux-vdso`, `libgcc_s`, `libm`, `libc`, loader | verified (`test.sh` 7) |
| 7 demo scenario | `scenarios/demo.json` with `run`, `batch`, `ui --config` | loads and runs | loads (`test.sh` 10); batch and ui smoke (`test.sh` 11) | verified |
| 7 coexistence measured | 10,000 ticks, at least three seeds, demo and example | recorded | section 4 and 5 below, README | verified |

Not checked in this phase: `ui` opened in an interactive browser by a person (the screenshots and the smoke test are the
automated evidence); `setup.sh` with the rustup installation branch (cargo was present); a clean Ubuntu 24.04 install.

## 3. Randomised invariant tests

File: `crates/evosim-core/src/invariant_tests.rs` (module registered in `lib.rs`, `#[cfg(test)]`). No third-party crate:
random configurations are drawn from the simulation's own generator (`rng::Rng`) with a fixed master seed, so a
failure can be reproduced. Each case draws a world of 1 to 64 by 1 to 48 cells, initial counts (plants 0 to 300,
herbivores 0 to 300, carnivores 0 to 100), a simulation seed, and the parameters of the table in `config.rs`
(all inside their ranges; `climate.season_length`, `weather_amplitude`, `plants.reproduction_chance`, `plants.seed_radius`,
`plants.max_age`, the animal `reproduction_energy`, `max_age`, the genetics and species keys), and runs 50 to 300 ticks.

| test | checks | cases (debug, default) | cases (release, `test.sh` 12) |
|---|---|---|---|
| `randomised_invariants_hold_for_every_tick` | after every tick: `Entities::check_invariants` (ids ascending, ranges, trait/genome agreement, parent sets, deaths by cause sum to deaths, `initial + births - deaths = living`); living count equals stored organisms; cumulative births and deaths never decrease; energy and health finite and non-negative; every organism on the torus; plant resources in `[0, 100]`; `check_spatial` (index in step with organisms); `SpatialIndex::within` equals a brute-force torus search for four centres per tick including x = 0, x = width - 1, y = 0, y = height - 1, random radius 0 to 6, and a random kind filter | 24 | 200 |
| `same_configuration_gives_same_state_hash` | two runs of the same configuration give equal `state_hash` | 24 | 200 |
| `checkpoint_split_run_equals_uninterrupted_run` | a checkpoint written at a random tick and read back, then continued, gives the same `state_hash` and living counts as one uninterrupted run | 24 | 200 |
| `different_seeds_give_different_state_hashes` | seeds `s` and `s+1` give different hashes after 20 ticks | 24 | 200 |

Commands and results: `cargo test -p evosim-core --locked --offline invariant` (debug, 24 cases): 8 passed (this
includes 4 existing tests whose names contain "invariant"), finished in 17.2 s. `EVOSIM_INVARIANT_CASES=200 cargo test
--release -p evosim-core --locked invariant` (inside `test.sh`): 8 passed, 7.8 s. Both exit 0.

Limits: the generator is not a property-testing library (no shrinking; a failure reports the case index and the tick).
The wrapping check uses brute force on the torus distance, so it tests the index against the definition, not against an
independent implementation of the torus. Random configurations never use the example's fixed numbers, so the test does not
measure the demo or the example.

## 4. Demo scenario: choice and measurements

Goal (`task.md`): a world in which plants, herbivores and carnivores coexist as long as possible, without forced
anti-extinction. The product rules were not changed; only configuration keys were chosen.

Procedure, as run:
1. Six candidate configurations were measured on tuning seeds 1 to 10, 10,000 ticks, `--sample-every 1`, with the
   same binary. Score: median `L` (the first tick at which any kind has no living individual; `L = 10,000` if none),
   as in `docs/BALANCE.md`. Tie-break: seeds with all three kinds alive at 10,000. Stop rule: a candidate with all three
   kinds alive at 10,000 in at least 5 of 10 tuning seeds. No candidate reached it.
2. The candidate with the highest median `L` was chosen and run once on held-out seeds 101 to 110.
3. Candidate files: `docs/results/TASK-028/candidates/`. Tables: `docs/results/TASK-028/tuning-*.md`.

| candidate | keys changed from the example | median L (tuning 1-10) | min L | all three alive at 10,000 | note |
|---|---|---|---|---|---|
| c0 example | none (CONTRACT section 3) | 260.0 | 157 | 0 of 10 | baseline |
| c1 | world 128 x 96, same populations | 208.5 | 94 | 0 of 10 | worse |
| c2 | `plants.growth_rate` 0.3 | 260.0 | 157 | 0 of 10 | **identical to c0**: the key has no effect (ADR-0006 amendment, ADR-0012); this candidate was a check, not a change |
| c3 | `herbivores.reproduction_energy` 40, `carnivores.reproduction_energy` 60 | 295.5 | 208 | 0 of 10 | better than c0 |
| **c2b (chosen)** | `plants.reproduction_chance` 0.2, `plants.seed_radius` 4 | **352.5** | 178 | 0 of 10 | highest median; becomes `scenarios/demo.json` |
| c4b | 128 x 96, c2b plant keys, reproduction energies 40 and 60 | 267.5 | 96 | 0 of 10 | worse |
| c4 | 128 x 96, `plants.growth_rate` 0.3, energies 40 and 60 | not measured | - | - | killed by an error of the agent during the run (a shell `pkill` pattern matched the running command); its configuration contains a no-op key, so it was not re-run |

Held-out check (chosen candidate c2b, seeds 101 to 110, 10,000 ticks, run once): median `L` 271.5, min 103, 0 of 10 with
all three alive at 10,000 (`docs/results/TASK-028/heldout-demo-101-110.md`). The example configuration on the same
seeds in TASK-027: median 258.5, min 143, 0 of 10 (`docs/BALANCE.md`). The demo is therefore not clearly better than
the example; the difference on held-out seeds is 13 ticks in the median, within the seed spread.

Conclusion: no candidate reached the stop rule. The demo is the best of six parameter candidates, not an equilibrium.
Coexistence of all three kinds was not reached in any run.

Reproduce: `./evosim batch --config scenarios/demo.json --seeds 1,...,10 --ticks 10000 --sample-every 1 --out-dir D`
and `python3 -I scripts/balance_table.py D`. The candidate tuning outputs (about 6.6 MB each) were not kept in the
repository; the tables are.

## 5. Long runs (10,000 ticks, at least three seeds)

Commands (exit 0 each): `./evosim batch --config scenarios/demo.json --seeds 1,2,3,4,5 --ticks 10000 --sample-every 1 --jobs 4 --out-dir docs/results/TASK-028/long-demo` and the same for `examples/config.json` into `long-example`. Also `test.sh` 10 runs seeds 1 to 3 of both configurations through `run` (exit 0; `tick_end` 10,000; accounting holds).

Determinism check: the demo seed 1 run through `run` after the batch gives the same `state_hash` as the recorded batch
file (`ed0cc8863f714b68...`, checked with `python3 -I`).

Demo (`docs/results/TASK-028/long-demo.md`):

| seed | plants | herbivores | carnivores | L |
|---|---|---|---|---|
| 1 | survives | 317 | 230 | 230 |
| 2 | survives | 335 | 412 | 335 |
| 3 | survives | 572 | 374 | 374 |
| 4 | 1541 | 450 | 186 | 186 |
| 5 | 3812 | 569 | 178 | 178 |

Example (`docs/results/TASK-028/long-example.md`):

| seed | plants | herbivores | carnivores | L |
|---|---|---|---|---|
| 1 | survives | 157 | 221 | 157 |
| 2 | survives | 480 | 385 | 385 |
| 3 | survives | 540 | 258 | 258 |
| 4 | 1547 | 487 | 262 | 262 |
| 5 | 5255 | 592 | 167 | 167 |

Summary: demo median `L` 230 (min 178); example median `L` 258 (min 157). All three kinds alive at 10,000: 0 of 5 for both.
The first kind to die out (the one with the smallest extinction tick, `L`) was the carnivores in 8 of the 10 rows (4 of 5 in each configuration); the herbivores were first in the other two (demo seed 2, example seed 1). Plants died out in seeds 4 and 5 of both configurations, after the animals.

Note: the example's seed 1 extinction ticks (herbivores 157, carnivores 221) match TASK-027 (`docs/BALANCE.md`), so the
result is reproduced by an independent batch.

## 6. UI evidence

- `./evosim ui --smoke-test --config scenarios/demo.json`: exit 0, `smoke frames=1 tick=14`.
- `./evosim ui --screenshots DIR --config examples/config.json`: exit 0, `DIR/main.png` (1280 x 807) and `DIR/charts.png`.
  Copies: `docs/results/TASK-028/screenshots/main.png` and `charts.png`. The main image shows the climate map with
  biome bands, plants (squares), herbivores (circles), carnivores (triangles), the legend, the new-world presets, the
  run controls and the population, births and deaths, species and trait-mean charts.

## 7. Self-audit against `docs/PROJECT.md`

Status: **met** = implemented and verified by a test or a recorded command; **partly** = implemented with a stated gap;
**missing** = not implemented.

| requirement (PROJECT.md) | status | evidence and gap |
|---|---|---|
| Finite toroidal grid, cell-by-cell movement, wrap-aware perception and spatial lookup; user-configurable size and initial populations | met | `world.rs` (ADR-0007), `movement.rs`, `spatial.rs` (ADR-0003); invariant test wrapping check; config keys |
| Climate resembling latitudinal zones, smooth torus seam, temperature and precipitation; seasons and weather | met | ADR-0009 (zones and the seam compromise: top and bottom are the polar belt, the middle row is the equator), ADR-0010 (seasons, weather); UI legend shows the biomes; `evosim climate` |
| Plants consume resources, grow, reproduce, mutate and form species | partly | ADR-0012 (resource pool), ADR-0013 (asexual seeding; no pollination, which the brief allows as "and/or"), ADR-0004 and ADR-0018 (species). Gap: `plants.growth_rate` has no effect (regrowth is ADR-0012's constant) |
| Herbivores eat plants; carnivores eat herbivores | met | ADR-0014, ADR-0015, ADR-0016; food-chain tests (`food_chain_tests.rs`) |
| Traits: speed, strength, health, fertility, genetic behaviour (aggression, caution) | met | `entities.rs` traits and tendencies; `genome.rs` decoding; `check_invariants` |
| Lifespan, energy, nutrition, costs and reproduction controls, simplified and coherent | partly | ADR-0011, ADR-0015, ADR-0016, ADR-0017. Gap: `herbivores.metabolism` and `carnivores.metabolism` have no effect (base costs are in the ADRs) |
| Two-parent sexual reproduction for animals, inherited DNA, mutations | met | ADR-0017 (`mating.rs`, `reproduction.rs`), `genome.rs` (diploid animals, mutation) |
| Emergent new species via explicit stable species criterion | met | ADR-0018 (single linkage, persistence checks), `species.rs`; UI "Species alive" chart |
| No forced anti-extinction; no rule reads global or per-kind counts | met | Grep of the simulation rules: `living_count` and `initial` are used in `entities.rs` (accounting `check_balance`), `metrics.rs` and `analytics.rs` (reporting), and in tests; `ecology.rs`, `feeding.rs`, `hunting.rs`, `mating.rs`, `reproduction.rs`, `movement.rs` read only the cell, the perceived organisms and the organism's own state. No replenishment exists (CONTRACT 5.3) |
| Target population 1,000 to 5,000 entities | partly | Measured at 2,000 to 2,173 living (perf configuration). 5,000 is only checked once for the species check (ADR-0018, 28 ms). No run at 5,000 for ticks/s |
| At least 100 ticks/s headless at 2,000 entities (disclosed setup) | met | `docs/BALANCE.md`: median 1,084.9 ticks/s with 2,173 living (`scripts/perf.sh`, TASK-027 IMPLEMENT; the performance configuration, 2,000 plants start). `docs/PERFORMANCE.md` records the reference hardware. Not measured on other machines |
| Same engine for headless CLI and live UI | met | UI thread runs `Simulation`; CLI `run`, `batch` (`docs/ARCHITECTURE.md` CLI/UI boundary) |
| UI: climate-coloured map, entity differentiation, pan and zoom, run/pause/reset/step, adjustable speed, inspect an entity | met | UI controls `btn-run`, `btn-step`, `btn-reset`, `btn-faster`, `btn-slower`; inspector (`app.js`); screenshots (section 6) |
| Edit initial parameters in the UI; built-in presets; seed control | met | `setup.js`, `/api/world`, `/api/presets` (balanced, arid, continent, herbivore-only) |
| Import and export configuration: at least one of JSON, TOML, YAML | met | JSON only (`/api/config/import`, "Export JSON"); TOML and YAML not supported |
| Save and load the full state with DNA, RNG and climate | met | checkpoint format (ADR-0023); UI `/api/checkpoint` download and upload (`btn-save`, load); CLI `--save`, `--load`; `checkpoint_split_run_equals_uninterrupted_run` |
| Headless multi-seed and parameter batch runs with comparative statistics | met | `batch` with `--seeds`, `--vary` (cartesian product), `--jobs`, `--csv`; `summary.json` with mean, min, max, sd, extinct count per case and kind (ADR-0022) |
| Visualisation of population, births and deaths, diversity, genetic distributions and means, generation trends | partly | UI charts: population, births and deaths, species alive (diversity), distribution of a trait by kind, mean of a trait. Gap: no generation-trend chart in the UI (generation is shown in the inspector only); batch results are shown as CSV and summary, not as charts |
| Unit, integration, regression, property-based and multi-thousand-tick tests; seed repeatability | partly | Unit and integration tests (about 580 tests), regression of state hashes, multi-thousand-tick tests (`food_chain_tests`, 10,000-tick runs in `test.sh`). Property-based tests are hand-written randomised tests (section 3), not a property-testing library, and do not shrink |
| Operator may evaluate manually and with external checks | met | README commands; this file lists every command |
| Agent choice 1: language and framework | met | Rust workspace, local browser UI (ADR-0001, ADR-0002) |
| Agent choice 2: spatial neighbour search respecting the torus | met | ADR-0003, ADR-0007 |
| Agent choice 3: DNA structure, inheritance, mutation, speciation protocol | met | ADR-0004, ADR-0017, ADR-0018 |
| Agent choice 4: visual design of the UI (screenshots published) | met | `ui --screenshots` (CONTRACT section 2); screenshots in section 6 |
| Architecture ADRs for choices 1 to 3 with alternatives, trade-offs, performance and test consequences | met | ADR-0001 to ADR-0004 with alternatives; checked by `scripts/check_adrs.sh` |

Summary: 25 requirement rows: 20 met, 5 partly met, 0 missing. Partly met: plant reproduction and growth (unused key),
energy and cost keys (unused keys), population 5,000 (not measured for ticks/s), the visualisation of generation
trends and batch results, and the property-based testing style. The coexistence goal of "Extinction and stabilising
mechanisms" is **not reached** (section 4 and 5); the rule side of that section is met (no forced anti-extinction).

## 8. Known limitations (stated openly)

1. **Coexistence is not reached.** In every run recorded here (tuning, held-out and long runs of all candidates) the first extinction came before tick
   10,000: `L` ranged from 94 to 413. Carnivores were the first to go in most seeds. The cause analysis is in `docs/BALANCE.md`: carnivores almost never reproduce (0 to 4 births
   per seed), attack efficiency is low, and there is no handling time after a kill. The mechanisms that might help (T2
   handling time, T3 energy before predation, reproduction thresholds) were not implemented or tried in TASK-027 or here.
2. The demo scenario is the best of six parameter candidates. Its held-out result is not clearly better than the example.
3. Three configuration keys have no effect: `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism`
   (ADR-0006 amendment). They are validated and accepted.
4. Plant extinction after 1,500 to 8,000 ticks happens in some seeds; its cause is not analysed (BALANCE.md).
5. Plants are asexual only (no pollination).
6. Performance measured on one machine only (AMD Ryzen 5 7500F, container). The 5,000-entity case is not measured for ticks/s.
7. The `dist/evosim` self-containment was checked from an empty directory with a clean environment in this container, not on
   a plain Ubuntu 24.04 system.
8. `setup.sh` was run in this phase with cargo present; the rustup-install branch was not exercised. The fresh-state build
   (`rm -rf target dist` and `./setup.sh`) was checked in TASK-002 IMPLEMENT and not repeated here.
9. Randomised tests are hand-written (no property-testing library, no shrinking).
10. UI: only Chromium 131 was used for the headless checks; the interactive UI was not opened by a person in this phase.
11. Generation-trend charts and batch charts do not exist (CSV and summary only).
12. Git history: commit `8966e78` is titled "TASK-026 review cycle 1 PASS", although the TASK-026 REVIEW cycle 1 verdict
    was FAIL (recorded in STATE.md). The history was not rewritten.
13. The samples are small: 5 seeds (long runs), 10 (tuning of each candidate, held-out), 20 (TASK-027 tuning). The
    coexistence figures are estimates with wide spread.
14. Ecology parameters remain as TASK-027 left them: `hunting::DILUTION = 0.0`.

## 9. Reproduction

```sh
./scripts/test.sh                                                    # full gate, about 1 min 10 s
./evosim batch --config scenarios/demo.json --seeds 1,2,3,4,5 --ticks 10000 --sample-every 1 --jobs 4 --out-dir /tmp/demo
python3 -I scripts/balance_table.py /tmp/demo
./evosim ui --screenshots /tmp/shots --config examples/config.json
```

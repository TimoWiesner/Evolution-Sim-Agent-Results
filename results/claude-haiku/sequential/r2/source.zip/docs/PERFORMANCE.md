# Performance: measurement, profile and optimisation (TASK-026, ADR-0027)

> **Current state (IMPLEMENT cycle 2): read the section "IMPLEMENT cycle 2" at the end.** The sections above it describe
> the IMPLEMENT cycle 1 and REVIEW cycle 1 state (configuration 2,000 / 300 / 60, 60 ticks) and are kept as history.

## Result
- Target: at least 100 ticks per second at about 2,000 organisms. **Met**: median 577.8 ticks/s over five timed
  repetitions (min 575.2, max 578.4), with at least 2,164 living organisms on every measured tick.
- No product code was optimised in this task. The profile shows where the time goes, but the target is met with a
  margin of about 5.8x, so no optimisation was needed to reach it (see "Optimisation decisions").
- Behaviour is unchanged: `Simulation::tick()` is untouched, the new `Simulation::tick_profiled()` gives the same state
  hash as `tick()`, and the state hash of the benchmark configuration is the same in every run and in the pre-change
  binary (see "Verification").

## Hardware and setup (the benchmark container)
- CPU: AMD Ryzen 5 7500F 6-Core Processor, 12 logical CPUs (`/proc/cpuinfo`, `nproc`).
- Memory: 31.0 GiB (`/proc/meminfo`). Kernel 7.0.0-42-generic, Ubuntu 24.04 container.
- Toolchain: rustc 1.100.0 (0ef1bc386 2026-11-09), cargo from `/opt/rust/cargo/bin`, release profile, `--locked --offline`.
- Shared host: timings vary by about 0.5 % between runs here (see the three runs below).
- No system packages were installed for this task. No profiler is installed (`perf`, `valgrind` absent); the profile
  is an in-process wall-clock profile.

## Command
```
bash scripts/perf.sh
```
It prints the hardware line on stderr, then two JSON objects on stdout:
1. Main benchmark: `examples/perf-2000.json` (seed 42, world 128 x 96 cells, initial 2,000 plants, 300 herbivores,
   60 carnivores). Two untimed warm-up repetitions, then five timed repetitions of 60 ticks. Every repetition starts from
   a fresh simulation built from the same configuration, outside the timer. The timer covers only `tick()`. The
   benchmark fails (exit 1) if the living count falls below 2,000 on any measured tick; it did not.
   The phase profile is one additional 60-tick run with `tick_profiled`.
2. Secondary: the same configuration for 1,000 ticks, one repetition, no warm-up (reported, not a target; the population
   falls to 611 by tick 1,000).

The example itself: `cargo run --release --locked -p evosim-core --example perf_tps -- --config examples/perf-2000.json --ticks 60 --warm 2 --reps 5`.

Why windows that start from about 2,000: under the current ecology the population does not stay at 2,000 for long
(128 x 96, 2,000 plants + 300 herbivores + 60 carnivores: 2,164 at tick 60, 2,003 at tick 100, 611 at tick 1,000).
Keeping it there is TASK-027's topic and is not a benchmark trick (creating organisms outside the initial population
or by reproduction is forbidden by `docs/PROJECT.md`). The benchmark therefore measures the 60 ticks that start at about
2,000 organisms.

## Numbers
Main benchmark, four runs on the same machine (the same code; the medians agree to about 0.5 %):

| Run | Median ticks/s | Min | Max | Min living on measured ticks |
|---|---|---|---|---|
| 1 (earlier run: before the `--living-floor` flag and the finer timing output; same benchmark code) | 577.6 | 570.6 | 579.4 | 2,164 |
| 2 | 579.6 | 577.3 | 580.7 | 2,164 |
| 3 | 577.8 | 575.2 | 578.4 | 2,164 |
| 4 (after the rustfmt of the new files; `scripts/perf.sh` as documented) | 576.3 | not recorded | not recorded | 2,164 (not recorded; the run passed the 2,000 check) |

Per-repetition ticks/s of run 3: 576.1, 578.4, 578.3, 577.8, 575.2. Each repetition's state hash after 60 ticks:
`044113a943dfade03eebd4d9e070559ede1a808979ceebc8591d83b01262134d` (identical in all five).

Secondary (1,000 ticks, one repetition): 1,447.2 ticks/s (the population is lower later in the run, so each tick is
cheaper); final living 611; state hash `3d54be88059f882f92a6c46e94f2a0b416fc10cd752bd69cfd27c02b84d04b5d`.

### Before and after optimisation
| | Median ticks/s (2,000 organisms) | State hash after 60 ticks |
|---|---|---|
| Before optimisation (this build) | 577.8 | `044113a9...2134d` |
| After optimisation (no optimisation applied) | 577.8 | `044113a9...2134d` (unchanged) |

Before the perf module existed, the same configuration was run only as single probes of `evosim run` (PLAN, not the fixed
benchmark): about 536 ticks/s over 120 ticks. Those probes are not comparable with the table above.

## Profile (phase timers, `Simulation::tick_profiled`, 60 ticks)
| Phase | Time (ms) | Share |
|---|---|---|
| Plants | 29.2 | 28.1 % |
| Herbivores | 31.9 | 30.8 % |
| Carnivores | 24.5 | 23.6 % |
| Species | 11.7 | 11.3 % |
| Reproduction | 5.0 | 4.8 % |
| Deaths | 0.5 | 0.5 % |
| SpatialIndex | 0.9 | 0.9 % |
| Climate, Counters | < 0.1 | 0 % |
| Total | 103.7 | 100 % |

The total of the profiled run (103.7 ms) agrees with the timed repetitions (about 104 ms for 60 ticks).

Reading (what each phase does, from the code; the per-function split inside a phase was not measured with a counter, so
the functions named below are the likely costs, not measured shares):
- **Herbivores** (`Simulation::herbivore_phase`): `movement::plan_moves` (perception through `SpatialIndex::within` for
  every herbivore, heading choice in `feeding::herbivore_heading`), then the moves, `feeding::feed` (grazing), and the
  costs. Largest share: most organisms in the benchmark are plants and herbivores, and each herbivore queries the
  spatial index for food and danger.
- **Plants** (`ecology::plants_phase`): one climate and resource query per plant, genome decode per plant, growth,
  maintenance and damage (ADR-0012). Per-plant climate queries are the candidate noted in ADR-0027 D3(c).
- **Carnivores** (`Simulation::carnivore_phase`): the same movement planning, then `hunting::attack` for each carnivore.
- **Species** (`Simulation::run_phase` `Phase::Species`): full re-classification of each kind every
  `species.check_interval` ticks (25 by default, so ticks 25 and 50 inside the 60-tick profile), plus
  `species::update_extinction` every tick. The 60-tick profile contains the two re-classifications at ticks 25 and 50;
  the split between them and `update_extinction` was not measured. Classification is a single-linkage pass over the
  genomes of every living organism (ADR-0018); TASK-017 measured one check at 4.8 ms for 2,000 clonal animals.
- **Reproduction** (`reproduction::reproduction_phase`, `mating::mating_phase`): seeding and mating with genetic distance.
- **SpatialIndex** is small (0.9 %): the per-cell snapshot rebuild, once per tick.

The stale overlay (G-046, `spatial.rs`) was not measured separately. The SpatialIndex phase rebuilds the snapshot once
per tick, but the moves inside the Herbivores and Carnivores phases still add stale entries, so the overlay may be part of
the query cost inside those two phases. No counter was added, because the hot path was not changed in this task.

## Optimisation decisions
- Target met (577.8 ticks/s against 100). The optimisation candidates of ADR-0027 D3 were not applied, because a change
  that is not needed to meet the target adds risk to the determinism rules (every change must keep `state_hash`).
- If a later task needs more speed, the first candidates in order of phase share are: the two species re-classifications
  (Species, 11 %: skip members whose genome has not changed since the last check, or cache the distance per pair),
  the per-plant climate query (Plants, 28 %: one climate read per cell per tick), and the query cost in
  `SpatialIndex::within` (stale overlay and allocation) inside Herbivores and Carnivores (together 55 % of the tick time;
  the query share itself was not measured). Each needs its own profile and an
  unchanged `state_hash` for the benchmark configuration and three other seeds.

## Guard test
`perf::tests::guard_ticks_per_second_floor` (in `cargo test --workspace`) runs the benchmark configuration with one
warm-up and three repetitions of 20 ticks, and asserts that the median is above the floor:
- Release floor `GUARD_FLOOR_RELEASE_TPS` = 140 ticks/s, about a quarter of the measured 578 ticks/s.
- Debug floor `GUARD_FLOOR_DEBUG_TPS` = 6 ticks/s. Measured debug median: 26.3 ticks/s (`cargo test -p evosim-core perf:: -- --nocapture`).
- Checked by hand: with the debug floor raised to 1,000,000 the test fails with "median 26.2 ticks/s is below the floor
  1000000.0 ticks/s" (exit 101), and with the floors restored it passes.
- The whole `perf::` test group (7 tests, including the guard) runs in about 3.4 s in a debug test run.

## Verification (commands and exit status, IMPLEMENT cycle 1)
- `cargo test --workspace --locked --offline`: exit 0. evosim-cli 36 (+ batch 8, checkpoint 2, run 9), evosim-core 430
  passed with 1 ignored (7 of them new in `perf`), evosim-ui 95 passed with 1 ignored.
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0.
- `./build.sh`: exit 0, `dist/evosim` written; `./evosim version` and `./dist/evosim version` print the contract JSON.
- `./target/release/evosim run --config <p1> --ticks 120` gives state hash `c009fdd55c268389...` before and after the
  change (the fixed-seed probe configuration 128 x 96, 2,000 plants + 300 herbivores + 60 carnivores, seed 42).
- `git remote -v | wc -l`: 0.

## Known gaps
- Population: the benchmark measures early windows only (see above). The secondary number is the only long-run number;
  it is a 1,000-tick run that falls to 611. The 2,000-organism level holds for the first 100 ticks only, so the
  benchmark must be re-run after TASK-027 changes the ecology.
- One machine, one container. The numbers are not portable.
- The profile is wall-clock per phase; the split inside a phase was not measured with counters.

## REVIEW cycle 1 (TASK-026): verdict FAIL
Independent re-run in a fresh process (commit d8cee94): `bash scripts/perf.sh` exit 0, median 578.7 ticks/s, min living on measured ticks 2,164, state hash unchanged. `cargo test --workspace --locked --offline`, `cargo clippy --workspace --all-targets --locked --offline` and `bash scripts/check_adrs.sh` all exit 0. The 120-tick hash of the 128 x 96 probe is `c009fdd55c268389...` as before.

Blocking gap G-1: the criterion "a fixed configuration that keeps about 2,000 or more organisms alive" is not met by `examples/perf-2000.json`. Population probes (release, seed 42, 600 ticks, living count):

| Configuration (width x height, plants / herbivores / carnivores) | tick 0 | tick 100 | tick 200 | tick 600 |
|---|---|---|---|---|
| 128 x 96, 2,000 / 300 / 60 (benchmark) | 2,360 | 2,003 | 1,209 | 615 |
| 128 x 96, 3,000 / 400 / 60 | 3,460 | 2,917 | 1,748 | 918 |
| 192 x 144, 3,000 / 300 / 60 | 3,360 | 3,061 | 1,932 | 1,121 |
| 256 x 192, 4,000 / 400 / 80 | 4,480 | 3,899 | 2,428 | 1,402 |
| 128 x 96, 2,400 / 150 / 30 | 2,580 | 2,406 | 1,558 | 1,205 |

No configuration tested stays at or above 2,000 beyond about 200 ticks. The benchmark therefore measures a transient window that starts at the founder population. Remedy for the next PLAN: a configuration (existing keys only) that stays at or above 2,000 for the whole measured window, or an explicit operator decision accepting the start-window reading, recorded here and in ADR-0027. Adding organisms or count-based rules is not allowed (docs/PROJECT.md).

Non-blocking gaps: G-2, no optimisation applied (before and after identical; the "make it faster" goal has no measured speedup); G-3, the profile is per phase only. See `tasks/TASK-026/handoffs/review-cycle1.json`.

## PLAN cycle 2 (TASK-026): resolves REVIEW cycle 1 gaps G-1, G-2, G-3
Plan only; no product code changed in PLAN. Decisions are in ADR-0027 "PLAN cycle 2".

- **G-1 (blocking).** The benchmark configuration becomes `examples/perf-2000.json` = seed 42, 128 x 96, 2,200 plants,
  250 herbivores, 50 carnivores (fixed keys only). Living count on every tick 0 to 100 is at least 2,173 (mean 2,432)
  in probes (`evosim run --sample-every 1`, release). The main window becomes 100 measured ticks (2 warm-up and 5 timed
  repetitions, each from a fresh simulation). The old configuration (2,000 / 300 / 60) fell to 2,003 at tick 100 and
  1,601 at tick 150. Five other configurations were probed (ADR-0027 table). The new numbers are measured in IMPLEMENT
  and recorded here.
- **G-2 (non-blocking, goal).** IMPLEMENT applies and measures at least two optimisations (O1 plant climate cache per
  cell per tick; O2 O(1) stale check in `SpatialIndex::within_into`), each with an unchanged state hash for seeds 42, 1,
  2 and 3 over 1,000 ticks. Before and after are measured on the same build and configuration.
- **G-3 (non-blocking).** IMPLEMENT counts spatial queries, candidates returned, stale entries scanned and plant climate
  queries per phase with a temporary, uncommitted patch, and records the numbers here.
- Hardware and toolchain are as in "Hardware and setup" above (AMD Ryzen 5 7500F, 12 logical CPUs, rustc 1.100.0).

## IMPLEMENT cycle 2 (TASK-026): current configuration, optimisations and numbers

Resolves REVIEW cycle 1 gaps G-1 (configuration keeps 2,000 alive), G-2 (optimisation applied and measured) and G-3
(query counts). Handoff: `tasks/TASK-026/handoffs/implement-cycle2.json` and `.md`. Decision record: ADR-0027, "IMPLEMENT
cycle 2".

### Hardware and setup
- CPU: AMD Ryzen 5 7500F 6-Core Processor, 12 logical CPUs; memory 31.0 GiB; kernel 7.0.0-42-generic.
- rustc 1.100.0 (0ef1bc386 2026-11-09) at `/opt/rust/cargo/bin`. Release profile, `--locked --offline`.
- Shared container host: timing noise about 0.5 % on the median between runs.

### Command
- Benchmark: `bash scripts/perf.sh`. It runs `perf_tps` on `examples/perf-2000.json`:
  `--ticks 100 --warm 2 --reps 5` (2 untimed warm-up repetitions, then 5 timed repetitions of 100 measured ticks; each
  repetition starts from a fresh simulation built from the configuration, outside the timer). It also prints the phase
  profile of 100 ticks, and a secondary 1,000-tick run (one repetition, no warm-up, living floor off).
- Configuration `examples/perf-2000.json`: seed 42, world 128 x 96, initial plants 2,200, herbivores 250, carnivores 50.
  Only the existing keys are used. Living count: 2,500 at tick 0, at least 2,173 on every tick of 0 to 100 (probe, and
  the benchmark checks 2,000 on every measured tick).
- Guard test and the new living-floor test read the same file through `perf::BENCH_CONFIG_JSON`.

### Numbers (median of 5 timed repetitions of 100 ticks)
| Build | Run | Median ticks/s | Min | Max | Min living on measured ticks | State hash after 100 ticks |
|---|---|---|---|---|---|---|
| Before (unchanged product code, new configuration) | 1 | 865.0 | 858.3 | 866.2 | 2,173 | `9fee01174c39...` |
| Before | 2 | 869.1 | 868.0 | 870.0 | 2,173 | `9fee01174c39...` |
| After O1 + O2 | 1 | 1,085.3 | 1,079.9 | 1,087.6 | 2,173 | `9fee01174c39...` |
| After O1 + O2 | 2 | 1,076.7 | 1,055.9 | 1,086.9 | 2,173 | `9fee01174c39...` |

- Speed-up: about 1.25x (median 867 to 1,081 ticks/s). Target 100 ticks/s at about 2,000 organisms: **met**, with a
  margin of about 10x.
- Secondary run after the change: 1,000 ticks, 1,551.8 ticks/s, final living 1,146 (state hash `a79ec351...`, the same
  as the pre-change binary, see "Behaviour"). The secondary run was not repeated before the change.

### Profile (`tick_profiled`, 100 ticks from the fresh start, run 1 of each build)
| Phase | Before ms (share) | After ms (share) |
|---|---|---|
| Plants | 49.6 (42.9 %) | 47.4 (51.6 %) |
| Herbivores | 18.9 (16.3 %) | 9.3 (10.1 %) |
| Carnivores | 18.9 (16.3 %) | 8.7 (9.5 %) |
| Species | 19.6 (16.9 %) | 19.5 (21.3 %) |
| Reproduction | 6.4 (5.5 %) | 4.6 (5.0 %) |
| SpatialIndex | 1.6 (1.3 %) | 1.5 (1.7 %) |
| Deaths | 0.8 (0.7 %) | 0.8 (0.8 %) |
| Total | 115.8 | 91.9 |

The most expensive parts are, in order: the Plants phase (about half of the tick time after the change), the Species
phase (about one fifth, not changed), and the Herbivores and Carnivores phases (about 10 % each after the change).

### Spatial query counts (G-3, temporary instrumentation, reverted)
Counted over the 100 measured ticks of the benchmark configuration, before any optimisation, one run from the fresh start.
The counters were added to `spatial.rs` and `ecology.rs` for this measurement only and removed afterwards (the files
were restored from a backup, and the instrumentation is not in the tree).

| Quantity | Total over 100 ticks | Per tick |
|---|---|---|
| `SpatialIndex::within` / `within_into` calls | 26,383 | 264 |
| Neighbour cells visited | 752,799 | 7,528 |
| Bucket entries checked (stale test for each) | 184,437 | 1,844 |
| Stale-set entries scanned (per query loop, with a `BTreeMap` lookup each) | 2,144,130 | 21,441 |
| Candidates returned | 163,589 | 1,636 |
| Plant climate queries (`climate.conditions`, pass 1 of `plants_phase`) | 230,490 | 2,305 |

- The stale set is the larger cost: about 81 stale entries are scanned per query, about 11 times the number of bucket
  entries. Its scan is the main reason O2 was changed as described below.
- Phase attribution of the queries (by call site, not measured per phase): `movement::perceive` (`within` with no
  filter, vision radius), `feeding::feed` (plants within feed reach), `hunting::attack` (herbivores within hunt reach),
  `mating` (same kind within mate range), `reproduction` (plant count per cell, radius 0). The per-call-site split was
  not counted; the query counts above are totals.

### Optimisations
- **O1, plant climate cache (`ecology::plants_phase`).** `climate.conditions(cell)` is computed once per cell per tick and
  reused (per-cell `Option<Conditions>` cache). The climate is fixed during the phase. The regeneration loop at the end of
  the same phase reads the same cache. Effect: about 2,305 queries per tick are reduced to about one per occupied cell;
  the regeneration loop already calls `conditions` for every cell, so most of this cost stays. The Plants phase time is
  almost unchanged (49.6 to 47.4 ms per 100 ticks). Kept: hashes unchanged.
- **O2, O(1) stale check and cheaper stale scan (`spatial.rs`).** The stale set is a `HashMap<OrganismId,
  Option<Placed>>` holding the current placement, `None` once removed. `within_into` tests membership with
  `contains_key` (O(1)) and scans the stale map without a `BTreeMap` lookup per entry. The answers are sorted before return,
  so the map's iteration order does not reach a result. Effect: Herbivores 18.9 to 9.3 ms, Carnivores 18.9 to 8.7 ms per
  100 ticks. Kept: hashes unchanged, all `spatial.rs` brute-force tests pass.
- **O3, scratch buffers in `perceive` / `feed` / `attack`: not applied.** The counts show 264 queries per tick, so the
  allocations are not a measurable cost. Not attempted.
- **Not attempted: Species phase (about 21 % after the change).** Next candidate, see "Remaining bottleneck".

### Behaviour unchanged
- State hashes, identical before and after, for the new configuration (`evosim run`, release, see table below):
  seeds 42, 1, 2, 3 at 150 and 1,000 ticks, and the old 2,000 / 300 / 60 probe (seed 42, 120 ticks, `c009fdd55c26...`
  as recorded in IMPLEMENT cycle 1). Full hash lists: `/tmp/impl2/hash/base.txt` and `o12.txt` (scratch, not in the tree).
  The 150-tick runs keep animals alive; the 1,000-tick runs end with herbivores and carnivores extinct for these seeds.
- The benchmark hash after 100 ticks is the same in all repetitions and in the before and after builds (`9fee0117...`).
- The gates for O1 and O2 were applied together (one hash check and one test run after both changes), not one by one.

### Tests added or updated
- New: `perf::tests::fixed_benchmark_living_holds_for_the_window` (100 ticks of the benchmark configuration, living at least
  2,000 on every tick; passes with living at least 2,173).
- Unchanged and passing: `perf::tests::guard_ticks_per_second_floor`, `perf::tests::tick_profiled_matches_tick`, and the
  determinism and checkpoint tests (`checkpoint_cli.rs`, `run_cli.rs`, `batch_cli.rs`, core checkpoint).

### Guard floors
- Release: floor 140 ticks/s, measured now 1,050.3 ticks/s (min 1,044.4, max 1,052.8, living at least 2,533 over 20 ticks).
- Debug: floor 6 ticks/s, measured now 72.1 ticks/s (living at least 2,533 over 20 ticks).
- Decision: floors kept at 140 (release) and 6 (debug). The measured release median rose by about 80 % over IMPLEMENT
  cycle 1 (578 to 1,050). Raising the floor would make the guard tighter; the loose floor still catches a slowdown
  of more than about seven times. The debug figure is higher than the 26 ticks/s recorded in REVIEW cycle 1; the reason was
  not investigated (the configuration changed, and the debug run is not a target).

### Verification (commands and exit status, IMPLEMENT cycle 2)
- `cargo test --workspace --locked --offline`: exit 0. cli 36 / 8 / 2 / 9 passed; core 431 passed + 1 ignored; ui 95 passed + 1 ignored.
- `cargo test -p evosim-core --locked --offline perf::`: exit 0, 8 passed (including the new test).
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0.
- `bash scripts/perf.sh`: exit 0, four times in total (two before, two after).
- `./build.sh`: exit 0. `./evosim version` and `./dist/evosim version`: exit 0, `{"name": "evosim", "version": "0.1.0", "contract": 1}`.
- `git remote -v | wc -l`: 0.

### Remaining bottleneck and next candidates
- The Plants phase is now about half of the tick (47 ms per 100 ticks). Not measured inside the phase. Two likely costs,
  both from code reading: (a) the regeneration loop calls `Climate::conditions` for all 12,288 cells every tick (season
  sine and clamp); (b) `PlantTraits::from_genome` (`trait_means`) is evaluated for each plant every tick. Next step: measure
  both, then cache the per-cell capacity or decode the traits once per organism.
- The Species phase is about 20 % and was not changed (ADR-0018 re-classification, out of scope for this optimisation).


## REVIEW cycle 2 (TASK-026): verdict PASS
Independent re-run in a fresh process (commit d3d40ef, IMPLEMENT cycle 2). All six acceptance criteria are met; the
gaps left are non-blocking (see the list at the end of this section).

- `cargo test --workspace --locked --offline`: exit 0 (cli 36/8/2/9; core 431 passed + 1 ignored; ui 95 passed + 1 ignored).
- `cargo clippy --workspace --all-targets --locked --offline`: exit 0, no warnings.
- `bash scripts/check_adrs.sh`: exit 0, checks=197 failed=0.
- `bash scripts/perf.sh`: exit 0. Median 1,081.7 ticks/s (min 893.1 in the first timed repetition, max 1,086.1); min living
  on measured ticks 2,173; state hash `9fee0117...` identical in all repetitions and equal to the IMPLEMENT value.
  Secondary 1,000 ticks: 1,538.8 ticks/s, final living 1,146.
- Behaviour against the pre-optimisation code: a release build of commit 8966e78 (from `git archive`, separate target
  directory) and the current build give identical state hashes for seeds 42, 1, 2, 3 at 150 and 1,000 ticks (8 pairs),
  and for the 120-tick probe of the old 2,000 / 300 / 60 configuration (`c009fdd55c268389...`, both builds).
- Code read: the diff `8966e78..d3d40ef` touches `ecology.rs` (O1 cache, values unchanged) and `spatial.rs` (O2:
  `HashMap` stale overlay; the result is collected and `sort_unstable`d before return, and ids are unique, so the
  hash-map iteration order does not reach a result). No instrumentation remains in the tree.
- Criterion 1 is met as a 100-tick window: `perf::tests::fixed_benchmark_living_holds_for_the_window` asserts living
  >= 2,000 on each of the 100 measured ticks (minimum 2,173). The population falls below 2,000 after about 100 to 150
  ticks (1,770 minimum over ticks 0 to 150 per PLAN cycle 2), so the window is short by design; the REVIEW cycle 1
  remedy allowed a window of up to about 150 ticks.

Non-blocking gaps carried forward:
- The per-call-site split of the spatial query counts (G-3) was not measured; the totals are only.
- O1 and O2 were gated together; O1 alone changes the Plants phase by about 5 %, which is within noise.
- The Plants phase (about half of the tick) is not profiled inside the phase; the candidates are the regeneration
  `conditions()` loop over all cells and `PlantTraits::from_genome` per plant.
- Debug guard median is 72 ticks/s now, against 26 in REVIEW cycle 1; still unexplained (debug is not a target).
- The first timed repetition is about 15 % slower than the rest; the median is stable within about 0.5 %.

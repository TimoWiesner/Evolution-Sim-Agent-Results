# Evolution metrics file (`evosim run --metrics FILE`)

Reference for the metrics file written by `evosim run` (ADR-0021). Readers (TASK-021 batch summaries, TASK-025 charts) take
the layout and the names from this file, not from the code.

## Writing it

```
evosim run --config FILE --ticks N --out FILE [--metrics FILE] [--sample-every K] ...
```

- `--metrics FILE` is optional and off by default. Without it no metrics file is written and the result file is unchanged.
- The result JSON (`CONTRACT.md` section 4) is the same with and without `--metrics`, apart from the two wall-clock fields.
  The `state_hash` is the same too: sampling only reads the simulation.
- `--metrics` may appear once. Giving it the same path as `--out` is exit 2 (no file is written).
- Samples are taken at the series ticks of the result (`tick_start`, every `sample_every` ticks, `tick_end`; see ADR-0020 D4).
  The first sample is taken before the first tick, so every tick of the run belongs to exactly one sampling interval.
- Parent directories are created. The file is written through a temporary file and renamed. It is written before the result
  file, and both texts are built first, so a serialisation error writes neither file. If the second rename fails after the
  first succeeded, the metrics file exists without a result file and the exit code is 2 (accepted; ADR-0021 Risks).
- `elapsed_seconds` in the result includes the time spent recording the samples inside the run loop.

## Layout

One JSON object. Each header key and each sample is on its own line; the sample lines are compact.

| Key | Type | Meaning |
|---|---|---|
| `format` | string | always `"evosim-metrics"` |
| `format_version` | integer | `1` (ADR-0021 D6) |
| `contract` | integer | `1`, the version of `docs/CONTRACT.md` |
| `seed` | integer | seed used by the run (after `--seed` overrides the configuration) |
| `tick_start`, `tick_end` | integer | first and last tick of the run |
| `sample_every` | integer | sample spacing in ticks |
| `traits` | object | per kind (`plants`, `herbivores`, `carnivores`), the trait names in the order used by `samples[].<kind>.traits` |
| `samples` | array | one object per sample, in ascending `tick` order, without duplicates |

`traits` names:

- `plants`: `speed`, `strength`, `fertility`, `max_lifespan`, `max_health`, `cold_tolerance`, `drought_tolerance`, `yield`
- `herbivores` and `carnivores`: `speed`, `strength`, `fertility`, `max_lifespan`, `max_health`, `aggression`, `caution`, `vision`

Readers should take the names from this list rather than assume them: a future trait is added to the list without a format
version change (ADR-0021 D6).

## One sample

```
{"tick": 100, "plants": {...}, "herbivores": {...}, "carnivores": {...}}
```

Each kind object:

| Key | Type | Meaning |
|---|---|---|
| `population` | integer | living individuals at the sample tick |
| `births`, `deaths` | integer | cumulative since tick 0 (equal to the result's `totals`) |
| `births_since_last`, `deaths_since_last` | integer | births and deaths since the previous sample; `0` at the first sample |
| `deaths_by_cause` | object | cumulative deaths per cause: `old_age`, `starvation`, `predation`, `exposure`, `injury` |
| `species_living` | integer | species alive after the last completed tick (see Notes) |
| `species_recognised` | integer | species records ever created for the kind, extinct or not |
| `generation` | object or `null` | `{"max": int, "mean": number}` over the living organisms; founders are generation 0 |
| `mean_energy` | number or `null` | mean energy of the living organisms |
| `mean_age` | number or `null` | mean age in ticks of the living organisms |
| `traits` | object or `null` | per trait name, `{"mean", "sd", "min", "max"}` of the decoded trait values over the living organisms |

`null` means "no living organism of this kind" (the set is empty). It is distinct from `0`. Counts are never `null`.

## Arithmetic

- `sd` is the population standard deviation: `sqrt(sum((x - mean)^2) / n)`, divisor `n`.
- Trait values are the decoded values (for example speed in cells per tick, `max_lifespan` in ticks, `vision` in cells,
  `yield` as energy per resource unit), not the genome means in `[0, 1]`.
- `vision` is the integer vision range of the animal (ADR-0014).
- Sums run in ascending organism id, so one build gives identical numbers for one state. Floats are exact only on the same
  build and machine (`CONTRACT.md` section 5.1).

## Notes for readers

- `species_living` is read from the species records. A species is found at a species check (every `species.check_interval`
  ticks, ADR-0018), so this value can lag `population` by up to one check interval.
- Births and deaths since the last sample are the difference of the cumulative counts. The sum of `births_since_last` over all
  samples equals the cumulative `births` of the last sample, because the first sample starts at `tick_start`.
- The first sample of a metrics file is always taken at `tick_start`, so its since-last values are `0`. A `--load` run
  (TASK-022) follows the same rule.

## Example

```
{
 "format": "evosim-metrics",
 "format_version": 1,
 "contract": 1,
 "seed": 7,
 "tick_start": 0,
 "tick_end": 100,
 "sample_every": 50,
 "traits": {
  "plants": ["speed", "strength", ...],
  ...
 },
 "samples": [
{"tick": 0, "plants": {"population": 2000, ...}, ...},
{"tick": 50, ...},
{"tick": 100, ...}
 ]
}
```

(The example is abbreviated; the actual file has the full trait lists and every key of the table above.)

## Verified by

- `crates/evosim-core/src/analytics.rs` tests: a hand-checked 4x4 world (plant speed `0` and `4`: mean 2, sd 2, min 0, max 4;
  child of generation 1; injury death; `births_since_last`; null sets); herbivore vision and tendencies; plant-only traits;
  JSON header and nulls; sampling at every tick leaves `Simulation` equality and `state_hash` unchanged.
- `crates/evosim-cli/src/main.rs` tests: the file parses, has the header, one sample per series tick, and the result
  `state_hash` is equal with and without `--metrics`.
- `crates/evosim-cli/src/args.rs` tests: `--metrics` parsing, repeated option, `--metrics` equal to `--out`, missing value.

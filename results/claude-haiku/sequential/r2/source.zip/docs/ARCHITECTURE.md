# Architecture ledger

Status (TASK-004, REVIEW cycle 1 PASS): `core::topology` is implemented in `crates/evosim-core/src/world.rs` (ADR-0007, Accepted; tests in the module). `evosim-core` holds `config` (TASK-003), `world` (TASK-004) and `CONTRACT_VERSION`. The workspace skeleton from TASK-002 exists:
`evosim-cli` holds `version`/`--help`, `evosim-ui` is a placeholder). Simulation modules below are not written yet.
The layout matches the plan; ADR-0005 records the skeleton and test gate. Decisions are recorded in
`docs/decisions/ADR-0001` (language), `ADR-0002` (UI), `ADR-0003` (neighbour search) and `ADR-0004`
(genome and species). This file is the module map and the determinism rules.

TASK-005 (REVIEW cycle 1 PASS): `core::rng` (xoshiro256** seeded by SplitMix64, `crates/evosim-core/src/rng.rs`) and `core::sim`
(`Simulation`, fixed nine-phase `tick()`, optional trace, `crates/evosim-core/src/sim.rs`) are implemented as specified in
`docs/decisions/ADR-0008` (Accepted in REVIEW cycle 1). The tick order below is the same as the
determinism list, except that sampling is a read-only observer after `tick()`, not a phase.

TASK-006 (REVIEW cycle 1 PASS): the base climate is implemented in `crates/evosim-core/src/climate.rs` and built by `Simulation::new` into `World.climate`; `evosim climate` exports it without a UI. Design: `docs/decisions/ADR-0009-climate-zones-and-biomes.md` (Accepted in REVIEW cycle 1). The torus
compromise: the top/bottom seam is the polar belt and the middle row is the equator (latitude `90*cos^2(pi*(y+0.5)/H)`), so the
wrap joins two cold belts and the field is smooth and periodic. Biomes follow latitude only; a seeded, torus-periodic
regional variation is added on top, with its own generator so the simulation random stream is unchanged.

TASK-007 (IMPLEMENT cycle 1): seasons and weather are in `crates/evosim-core/src/climate.rs`. The Climate phase in `sim.rs` calls
`Climate::advance`, which draws one value per weather node from the simulation generator when `weather_amplitude > 0`. With weather off,
nothing is drawn and one year repeats bit for bit. Design: `docs/decisions/ADR-0010-seasons-and-weather.md` (Proposed until REVIEW).
Climate state (`params`, weather nodes, `weather_tick`) is part of `Simulation` equality; checkpoints (TASK-022) must save it.

TASK-008 (IMPLEMENT cycle 1): organisms and the life cycle are in `crates/evosim-core/src/entities.rs` (ADR-0011, Proposed until REVIEW).
`Entities` holds the organisms as a `Vec` sorted by id, `next_id`, and `initial`/`births`/`deaths`/`deaths_by_cause` per kind.
`Simulation` has an `entities` field; the Deaths phase runs `deaths_phase`, the Counters phase runs `check_balance` and `check_invariants`
(debug assertions). Founders are not yet placed from `config.initial` (G-037).

## Workspace layout (planned)

```
Cargo.toml                    workspace: members = crates/evosim-core, crates/evosim-cli, crates/evosim-ui
crates/evosim-core/           simulation library (no UI, no CLI dependency)
crates/evosim-cli/            binary `evosim` (commands: version, run, batch, ui)
crates/evosim-ui/             local browser UI server, embedded web assets (web/index.html, app.js, style.css)
setup.sh  evosim  build.sh    contract entry points (docs/CONTRACT.md section 1), bash wrappers around cargo (ADR-0005)
scripts/test.sh               the one documented test command (ADR-0005)
scripts/check_adrs.sh         ADR and architecture record checks
scripts/balance_table.py       TASK-027: extinction ticks per seed and kind from a batch directory (`python3 -I`)
scripts/balance_causes.py      TASK-027: death causes and population curves from `run --metrics` files (`python3 -I`)
scenarios/demo.json           demo configuration (TASK-019 or later)
dist/                         build output, git-ignored
```

## Modules and dependencies

| Module (crate path) | Responsibility | May depend on |
|---|---|---|
| `core::rng` (`evosim-core/src/rng.rs`) | xoshiro256** generator, SplitMix64 seeding, state export/import. Only source of randomness. | nothing |
| `core::config` (`config.rs`) | Typed configuration, defaults, validation with key names in errors, JSON read/write, presets. | std only; hand-written JSON reader/writer in `config/json.rs` (ADR-0001) |

Configuration keys, types, ranges and defaults: ADR-0006 (TASK-003 PLAN). Presets live in `config/presets.rs`.
| `core::topology` (`world.rs`) | Torus `W x H`, wrapping of any `i64` coordinate, shortest wrapped displacement, Chebyshev torus distance, radius neighbourhood without duplicates, eight directions (ADR-0007). | nothing |
| `core::climate` (`climate.rs`) | Latitude zones and biomes, base temperature and precipitation per cell, seeded periodic regional variation (TASK-006, ADR-0009). Seasons (one global phase from `climate.season_length`) and seeded weather (AR(1) value-noise lattice, drawn in the Climate phase only), with bounded `conditions` and `seasonal_conditions` (TASK-007, ADR-0010). | topology, rng |
| `core::spatial` (`spatial.rs`) | Current-position map plus CSR per-cell snapshot with a stale overlay (a hash map from id to current placement, `None` once removed; TASK-026 IMPLEMENT cycle 2, ADR-0027 D3); insert/move/remove keep it correct at all times; `within(centre,r,filter)` returns ids ascending, no duplicates (ADR-0003 and its TASK-010 amendment). Implemented in TASK-010 IMPLEMENT cycle 1; `Simulation` keeps it in step (`spatial()`, `check_spatial()`). | world, entities (`OrganismId`, `Kind` only) |
| `core::movement` (`movement.rs`) | Animal perception (`perceive` within vision range across edges), per-tick steps `floor(speed)`, wander and shortest-path headings, movement energy cost, `plan_moves` (deferred, ascending id) (TASK-013, ADR-0014). Moves are applied by `Simulation::move_organism`. | entities, spatial, world, rng |
| `core::genome` (`genome.rs`) | Genome type, trait decoding, copy/meiosis/crossover, mutation, genetic distance (ADR-0004). | rng |
| `core::species` (`species.rs`) | Species criterion (single linkage over living organisms per kind, inclusive threshold, early-exit distance), identity by reference genome, candidates with persistence in checks, founding, provisional ids from the mother, parent and extinction records, names `PL/HE/CA` + sequence, `living_count(kind, tick, now)` (TASK-017, ADR-0018; Accepted at TASK-017 REVIEW). Measured in REVIEW: one check 4.8 ms at 2,000 clonal animals, 28 ms at 5,000 entities (ADR-0018 Measurement). | genome, entities, config |
| `core::entities` (`entities.rs`) | Organism type, kinds, traits and ranges, death causes, organism store (ascending-id `Vec`, never-reused ids), per-kind births/deaths bookkeeping, same-tick death pass (TASK-008, ADR-0011). Genome field added by TASK-009. | genome, topology |
| `core::hunting` (`hunting.rs`) | Carnivore pursuit (nearest herbivore in vision, satiation), attack chance from both animals' traits, optional crowding dilution (`DILUTION`, TASK-027 T1, default 0 = off), kill as `Predation`, gain capped by the meal and the prey's energy, attack and base costs (TASK-015, ADR-0016). | entities, spatial, movement, feeding (`thermal_cost`), rng, world |
| `core::ecology` (`ecology.rs`) | Per-tick rules for plants: resource pool sharing, growth, maintenance, hostile damage, regeneration of the pools (ADR-0012). Herbivore grazing, carnivore hunting, mating and seeding live in `feeding`, `hunting`, `mating` and `reproduction`. | entities, spatial, climate, genome, rng, config |
| `core::sim` (`sim.rs`) | `Simulation` struct, `tick()` ordering (ADR-0008), counters (births/deaths/totals), optional per-phase trace. Time series sampling is read-only and lives outside `tick()`. | all core modules above |
| `core::perf` (`perf.rs`) | Benchmark and profile only (TASK-026, ADR-0027): fixed configuration `examples/perf-2000.json`, `benchmark` (warm-up, timed repetitions of `tick()`, median/min/max ticks/s, living count per measured tick), `profile` (`Simulation::tick_profiled`, wall-clock per phase), and the guard test. Reads the clock; never changes state. | sim, config, metrics, checkpoint |
| `core::checkpoint` (`checkpoint.rs`) | Canonical little-endian encoding of the full state (magic `EVOSIMST`, format 1, `Encoder`) and `state_hash` (SHA-256 hex of it). Each state module has an `encode_state` method (TASK-019, ADR-0020 D3). TASK-022 (ADR-0023): `Decoder` (bounded reads), file container `EVOSIMCK` (version 1, seed, body length, body, SHA-256 trailer) with `write_file`/`read_file` and `CheckpointError`, and a `decode_state` per module that mirrors its `encode_state`. | sim, sha256 |
| `core::sha256` (`sha256.rs`) | SHA-256 (FIPS 180-4), std only; NIST and `sha256sum` checked (TASK-019, ADR-0020). | nothing |
| `core::metrics` (`metrics.rs`) | Result model of `run` (`RunResult::to_json`), per-kind counts, read-only sampling and series ticks (TASK-019, ADR-0020 D2, D4, D5, D6). Diversity and genetic statistics for batch/UI charts come later. | sim, checkpoint (tests: config::json) |
| `core::analytics` (`analytics.rs`) | Read-only per-sample evolution metrics: population, births/deaths (cumulative and since last), deaths by cause, species, generation, trait mean/sd/min/max, mean energy and age; metrics file layout (TASK-020, ADR-0021, `docs/METRICS.md`). | sim, ecology (PlantTraits), entities, metrics (JSON writer), checkpoint (tests) |
| `core::runner` (`runner.rs`) | The headless run loop shared by `run`, `batch` and `resume` (TASK-021, ADR-0022 D4; TASK-022, ADR-0023 D5): `run`/`run_config` build the founders, `resume` continues a restored checkpoint without placing founders, `run_from` is the tick loop, series sampling, optional metrics log, `state_hash`, optional final state (`RunOptions.keep_state`). | sim, metrics, analytics, checkpoint |
| `core::batch` (`batch.rs`) | Pure batch logic (TASK-021, ADR-0022): `--vary` case expansion (cartesian product), run configurations through the JSON tree and validation, per-kind aggregates (mean, min, max, population sd, extinct count), `summary.json` and CSV texts. No files, no threads. | config, config::json, metrics, runner (types only), entities |
| CLI `batch` (`crates/evosim-cli/src/batch.rs`) | Plans and validates all runs before the first, runs them (`--jobs` threads, results by run index), writes per-seed files, CSV, then `summary.json` last. | args, core::batch, core::runner |
| `evosim-cli` (`main.rs`, `args.rs`, `commands/*.rs`) | Argument parsing, exit codes, stdout/stderr discipline, dispatch to core and UI. | core, ui |
| `evosim-ui` (`server.rs`, `api.rs`, `driver.rs`, `web/`) | HTTP server on 127.0.0.1, JSON API, simulation thread, chromium-driven smoke and screenshot runs. | core |

Dependency rule: each module may depend only on the modules listed in its "May depend on" column (and std or
the listed external crates). Dependencies are acyclic.

Rules:
- `evosim-core` must not depend on `evosim-ui` or `evosim-cli`. Enforced by the workspace manifest and reviewed
  in REVIEW.
- Only `evosim-cli` contains `main`. Only `evosim-cli` writes to stdout; logs go to stderr.
- Results and checkpoints are written by the CLI from core values; core never touches the filesystem except
  through explicit `save`/`load` functions taking a path.

## Data ownership and serialization
- The `Simulation` owns: the world topology, climate state, the organism store, the species registry, the RNG,
  the tick counter and the totals. Nothing else holds mutable simulation state.
- Organisms are kept in a `Vec` sorted by id. Ids come from a `u64` counter that is part of the checkpoint.
- Checkpoint format: little-endian binary with a magic string, format version and a section per module, in
  fixed field order. Loading an invalid or truncated file gives an error (CLI exit 2).
- `state_hash` = SHA-256 over the canonical serialization of the complete state at `tick_end`.

## Determinism (how it is achieved)

1. **Randomness.** One master `Rng` (xoshiro256**) seeded from the configuration seed through SplitMix64. It is
   the only random source. Its 4-word state is saved in checkpoints. No `thread_rng`, no OS entropy, no time
   based seeds.
2. **Processing order.** Organisms are processed in ascending id order in every phase. Phases run in a fixed
   order within `tick()`: climate update, spatial index rebuild, plant phase, herbivore phase, carnivore phase,
   reproduction, death removal, species check (every K ticks), counters. Sampling is read-only and runs after `tick()` (ADR-0008). Within a phase, queries see
   the index snapshot taken at the start of the phase (ADR-0003).
3. **Deletion.** Deaths are removed with an order-preserving pass (`retain`), never by swap-remove, so the order
   of remaining organisms is stable.
4. **Forbidden in simulation logic:** wall-clock time (`Instant`, `SystemTime`) except for `elapsed_seconds` (`runner.rs`), the benchmark and profiler (`perf.rs`, `Simulation::tick_profiled`, ADR-0027)
   reporting outside the state; `HashMap`/`HashSet` iteration order (use `Vec`, `BTreeMap` or sorted vectors);
   thread-scheduling-dependent results (the core is single-threaded; any future parallelism must use per-chunk
   RNG streams derived from the master seed and merge results in id order); pointer addresses as ids; `f32`
   accumulation order changes; fast-math flags.
5. **Floating point.** Core arithmetic uses `f32` for traits and climate and `f64` for totals where needed; the
   order of operations is fixed in code. Transcendental functions come from the platform libm; they are only
   used in climate construction and precomputed tables where possible. Same machine and build gives identical
   results; cross-platform differences are documented as allowed by the contract.
6. **Tests of determinism:** same seed twice gives equal result JSON and `state_hash`; checkpoint split run equals
   one uninterrupted run; different seeds give different hashes.

## Clocks and time
- The simulation clock is the integer tick counter. Climate seasons and weather are functions of the tick and the
  RNG only.
- Wall clock is used only by the CLI/UI for measuring `elapsed_seconds`, `ticks_per_second` and for UI speed
  throttling. It never influences state.

## CLI/UI boundary
- The UI runs the same `Simulation` in its own thread; commands (run, pause, step, reset, speed) are messages.
  The UI never changes state directly.
- `evosim ui --smoke-test` and `--screenshots` are implemented in `evosim-ui::driver` and call the real server.

## Validation
- Configuration validation happens once, in `config.rs`, returning errors that name the key. CLI maps errors to
  exit 2.

## Measured performance
### Spatial index versus brute force (TASK-010 IMPLEMENT cycle 1)
Command: `cargo test -p evosim-core --release --locked -- --ignored --nocapture bench_index_vs_brute_force` (exit 0).
Machine: AMD Ryzen 5 7500F 6-Core Processor, 12 logical CPUs; rustc 1.100.0 (0ef1bc386 2026-11-09); measured 2026-11-18.
Workload: 2,000 organisms (1,600 plants, 280 herbivores, 120 carnivores), seed fixed, 200 ticks. Each tick, 200 organisms (10 %)
move to a random cell, then every organism queries the radius given. Brute force scans all 2,000 organisms per query and uses
`Torus::distance`. The index is `SpatialIndex`: moves via `move_to` before the queries of the tick, then `rebuild()`.
Both methods must give the same total hit count (asserted). Numbers are the median of 3 repetitions, in ns per query.

| World | Radius | Brute force | Index | Speed-up |
|---|---|---|---|---|
| 64 x 48 | 2 | 7878 ns | 2908 ns | 2.71x |
| 64 x 48 | 5 | 7878 ns | 4481 ns | 1.76x |
| 256 x 192 | 2 | 7897 ns | 2365 ns | 3.34x |

Re-measurement in TASK-010 REVIEW cycle 1 (same command, same machine, same rustc, 2026-11-18, median of 3 repetitions
inside the run, a fresh process; the implement numbers above were not copied):

| World | Radius | Brute force | Index | Speed-up |
|---|---|---|---|---|
| 64 x 48 | 2 | 8170 ns | 2923 ns | 2.80x |
| 64 x 48 | 5 | 8180 ns | 4464 ns | 1.83x |
| 256 x 192 | 2 | 8190 ns | 2377 ns | 3.45x |

Both runs agree on the ordering: the index is faster in all three cases. The absolute numbers vary by about 5 % between
runs on this shared host. Only one machine was used, so the numbers are not portable.

Reading: the index is faster in all three cases. Most of the index cost in this workload is the stale overlay: the 200
moves of a tick are still unapplied to the snapshot when the queries run, so each query also visits about 200 stale ids.
A rebuild before the queries (the SpatialIndex phase of a tick) would remove that cost; the speed-up for the phase-ordered
use in later tasks is therefore a lower bound. Numbers were measured on one machine only.
Other targets (not measured in TASK-010): >= 100 ticks/s at 2,000 entities headless, recorded when the ecology exists.
TASK-026 (PLAN): the performance benchmark, profile and guard test are designed in `docs/decisions/ADR-0027-performance-measurement-and-optimisation.md`; results go to `docs/PERFORMANCE.md` (written in IMPLEMENT).

## TASK-011 REVIEW note (plant energy source and limits, cycle 1 PASS)
ADR-0012 is Accepted. Plant energy comes only from the per-cell pool `World.resources`; the pool is refilled only toward
`100 * f_T * f_W` with neutral tolerances (so tolerances do not raise the pool, only the uptake). Where the neutral capacity is 0
(temperature <= 0 C with neutral tolerance, or precipitation < 20 mm/yr) the pool is empty; a plant with a higher cold or drought
tolerance then grows only from its stored energy above 40 and starves afterwards (measured in a scratch probe: a cold-tolerant
plant at -3 C, pool 0, gained no energy). This is the documented ADR-0012 design, recorded as a limitation, not a fault.
Still not measured: release timing at 2,000 plants (R3). Full `scripts/test.sh` not run in REVIEW.

## TASK-011 IMPLEMENT note (plant energy source and limits)
Implemented in `crates/evosim-core/src/ecology.rs` (`plants_phase`, `ResourceField`, `PlantTraits`, `growth_factors`, `capacity`),
`entities.rs` (`living_mut`), `sim.rs` (`World.resources`, Plants arm). Energy source and limits as in the PLAN note below. Growth
of a plant needs energy above 40 and `g > 0`; ageing, starvation and exposure follow ADR-0011. Cold tolerance lowers the lower
temperature limit (`5 - 10 * tolerance`). No RNG draws in the phase. Not measured: per-tick cost at 2,000 plants (risk R3), no
release timing was run in this phase. Founder count in CLI remains TASK-019.

## TASK-011 PLAN note (plant energy source and limits)
Design: `docs/decisions/ADR-0012-plant-resources-and-growth.md` (Proposed). Module `core::ecology` (`ecology.rs`, new) depends on
`climate`, `entities`, `genome` and `world`. Plant energy comes only from the per-cell resource pool (`World.resources`, one
`f32` per cell, in `[0, 100]`). The pool is refilled only toward a climate capacity `100 * f_T * f_W` (temperature and water
factors from `Climate::conditions`) at 5 % of the gap per tick. A plant takes its demand, shared proportionally within a cell,
and gains `take * yield` energy with `yield <= 1`. Growth needs `g = f_T * f_W > 0`; `g = 0` causes exposure damage. Plant traits:
cold tolerance (genome slot 5), drought tolerance (slot 6), yield (slot 7). Planned in TASK-011 IMPLEMENT; the phase is the
`Phase::Plants` arm of `run_phase`. Checkpoints (TASK-022) must save `World.resources`.

## TASK-012 PLAN note (plant reproduction and dispersal)
Design: `docs/decisions/ADR-0013-plant-reproduction-and-dispersal.md` (Proposed). Plan: `tasks/TASK-012/handoffs/plan-cycle1.md`.
Planned module: `core::reproduction` (new file `reproduction.rs`, may depend on `entities`, `genome`, `spatial`, `world`, `rng`,
`ecology`, `config`-free settings struct). It runs the Reproduction arm of `Simulation::run_phase`. Asexual seeding, uniform dispersal
over the torus Chebyshev square of radius `plants.seed_radius`, room (`CELL_PLANT_CAP`) and resource (`SEED_RESOURCE_MIN`) refusals.
Planned `Simulation` change: a `SeedingSettings` field set from the configuration; `from_parts` takes it as a fifth argument, and the
checkpoint (TASK-022) must save it. No code changed in PLAN.

## TASK-012 IMPLEMENT note
- New module `core::reproduction` (`crates/evosim-core/src/reproduction.rs`, ADR-0013): asexual plant seeding in the
  Reproduction phase. `SeedingSettings` is stored in `Simulation` and passed as the fifth argument of `Simulation::from_parts`
  (checkpoint TASK-022 must save it). Constants: `SEED_ENERGY_MIN` 45, `SEED_COST` 20, `SEED_ENDOWMENT` 10, `CELL_PLANT_CAP` 6,
  `SEED_RESOURCE_MIN` 5 (ADR-0013, calibrated to the TASK-011 economy; see its implementation notes).

## TASK-013 PLAN note (animal sensing and movement)
Design: `docs/decisions/ADR-0014-animal-sensing-movement-and-sharing.md` (Proposed). Plan: `tasks/TASK-013/handoffs/plan-cycle1.md`.
Planned module: `core::movement` (new file `movement.rs`; depends on `world`, `spatial`, `entities`, `genome`, `rng`). Animal
vision is `entities::vision_radius(genome)` from genome slot 7 (ADR-0004 amendment, not stored). The Herbivores and Carnivores
arms of `Simulation::run_phase` plan moves for all living animals of the kind (ascending id, start-of-phase positions) and then apply
them through the planned `Simulation::move_organism` helper, which keeps `Entities` and `SpatialIndex` in step. Cell sharing: any
number of organisms per cell; the ADR-0013 plant birth cap is the only occupancy limit and it governs births. No code changed in PLAN.

## TASK-013 IMPLEMENT note (animal sensing and movement)
- New module `core::movement` (`movement.rs`, ADR-0014): `steps_per_tick`, `move_cost` (`MOVE_COST_CELL` 0.2, `MOVE_COST_SPEED` 0.25),
  `Heading { Wander, Towards }`, `step_towards`, `wander`, `perceive`, `choose_heading` (always `Wander` until TASK-014 to TASK-016),
  `plan_moves` (reads start-of-phase positions, ascending id, one RNG stream).
- `entities::vision_radius(genome)` with `VISION_MIN` 1 and `VISION_MAX` 5 (ADR-0014, ADR-0004 amendment: animal genome slot 7).
- `Simulation::move_organism(id, cell)`: the one move path. Refuses off-torus cells and dead or unknown organisms (`SimError::NotAlive`)
  without changing anything; updates `Entities` and `SpatialIndex` together (closes G-047). Herbivores and Carnivores phases call a
  private `animal_phase` that applies the planned moves and then charges `drain_energy(move_cost(...))`.
- Cell sharing: no occupancy check for moves. Only the ADR-0013 plant birth cap limits (births only).
- No checkpoint state added. `check_spatial` runs in the Counters phase (debug) and in the tests after every tick.

## TASK-014 PLAN note (herbivore feeding and behaviour)
Design: `docs/decisions/ADR-0015-herbivore-feeding-and-behaviour.md` (Proposed). Plan: `tasks/TASK-014/handoffs/plan-cycle1.md`.
Planned module: `core::feeding` (new; depends on `entities`, `spatial`, `world`, `climate`) with the herbivore heading rule, feeding
(reach 1, cap `BITE_MAX`, assimilation 0.8, satiation 80) and the metabolism and thermal cost. `movement::Heading` gains `Away`;
`plan_moves` takes the heading rule as a parameter. The Herbivores arm becomes plan, move, feed, charge; Carnivores keep TASK-013.
No code changed in PLAN.


## TASK-014 IMPLEMENT note (herbivore feeding and behaviour)
- New module `core::feeding` (`feeding.rs`, ADR-0015): `FEED_REACH` 1, `BITE_MAX` 2.0, `ASSIMILATION` 0.8, `SATIATION_ENERGY` 80,
  `BASE_COST` 0.3, `COMFORT_LOW`/`COMFORT_HIGH` 5/30 C, `THERMAL_COST` 0.02, `THERMAL_STRESS_MAX` 40; `thermal_cost`,
  `herbivore_heading` (food against danger, genes decide), `feed` (bites from `SpatialIndex::within(cell, 1, Plant)`).
- `movement`: `Heading::Away` and `step_away`; `plan_moves` takes the heading rule as a closure. `choose_heading` stays for carnivores.
- `Simulation::herbivore_phase` (plan, move, feed, charge movement + base + thermal cost). `animal_phase` is carnivores only.
- Dependencies: `feeding` -> `entities`, `spatial`, `movement`, `climate` (via `Simulation`), `world`. No cycle.

## TASK-015 PLAN note (carnivore hunting)
Design: `docs/decisions/ADR-0016-carnivore-hunting-and-predation.md` (Proposed). Plan: `tasks/TASK-015/handoffs/plan-cycle1.md`.
Planned module: `core::hunting` (new `hunting.rs`). The Carnivores arm of `Simulation::run_phase` becomes plan, move, attack, charge
(as the herbivore arm of TASK-014). Also planned: G-051 fix in `movement::plan_moves`. No code changed in PLAN.

## TASK-015 IMPLEMENT note (carnivore hunting)
- New module `core::hunting` (`crates/evosim-core/src/hunting.rs`, ADR-0016): `attack_chance` (pure), `carnivore_heading` (nearest
  living herbivore in sight below satiation 70), `attack` (reach 1, one roll from the simulation generator, kill as `Predation`,
  gain `0.8 * min(prey energy, 30)`), `carnivore_costs` (movement, base 0.4, thermal).
- `Simulation::carnivore_phase` replaces `animal_phase`: plan and apply moves, attacks in ascending id (`ATTACK_COST` 0.5 per attempt),
  then costs. `movement::plan_moves` falls back to `Wander` for `Away` on the own cell (G-051).
- No new checkpoint state. Full command results are in `tasks/TASK-015/handoffs/implement-cycle1.json`.

## TASK-015 REVIEW note (carnivore hunting)
- REVIEW cycle 1 PASS: ADR-0016 Accepted. `core::hunting` as in the IMPLEMENT note. Open: G-054 (the `core::ecology` row above
  still mentions hunting and handling time; the implemented rules live in `core::hunting`, handling time is approximated by satiation).

## TASK-016 PLAN note (animal sexual reproduction)
Design: `docs/decisions/ADR-0017-animal-sexual-reproduction.md` (Proposed). Plan: `tasks/TASK-016/handoffs/plan-cycle1.md`.
Planned module: `core::mating` (new `mating.rs`; depends on `entities`, `genome`, `spatial`, `world` (torus), `rng`, `config`-free
`MatingSettings`). It runs in the Reproduction arm of `Simulation::run_phase` after plant seeding. Planned changes: `Organism.next_mate_age`
(ADR-0011 amendment, saved by TASK-022), `Entities::set_next_mate_age`, `Simulation.mating: MatingSettings` and a sixth argument of
`from_parts`. Thresholds come from the existing `herbivores/carnivores.reproduction_energy` keys; no new configuration key.
No code changed in PLAN.

## TASK-017 PLAN note (species and family tree)
Design: `docs/decisions/ADR-0018-species-criterion-and-family-tree.md` (Proposed). Plan: `tasks/TASK-017/handoffs/plan-cycle1.md`.
Planned module: `core::species` (new `species.rs`; pure classifier over `(kind, members, registry, settings, tick)`, `SpeciesRegistry`,
`living_count(kind, tick)`). Runs in `Phase::Species` every `species.check_interval` ticks, plus an O(n) extinction pass every tick.
Changes planned: `populate_initial` founders become clones of one ancestor per kind (TASK-009 D3 amended); `Organism.species`
(ADR-0011 amendment); `Simulation.species` as a new `from_parts` argument; newborns take the mother's species provisionally.
Found in PLAN: random founders would form one species each at threshold 0.06; the ADR-0004 cost was not measured (IMPLEMENT measures it).
No product code changed in PLAN.

## TASK-018 PLAN note (food-chain integration and balancing)
Design: `docs/decisions/ADR-0019-food-chain-integration-and-balancing.md` (Proposed). Plan: `tasks/TASK-018/handoffs/plan-cycle1.md`.
Tick order (unchanged, ADR-0008): Climate, SpatialIndex, Plants, Herbivores, Carnivores, Reproduction (seeding, mating, provisional species),
Deaths, Species, Counters. Planned change: `entities::LifespanRanges` (lifespan centred on config `plants/herbivores/carnivores.max_age`) and
`Birth::from_genome_in`; `from_genome` keeps the default centres. Root cause of the herbivore collapse found in PLAN: the lifespan slot maps to
`[1, 10000]` (mean about 5,000), so herbivores mature only after about 1,000 ticks and bred 0 times in four of five default seeds in 2,000 ticks.
Planned command: `scripts/survival.sh` (example `survival`), results in `docs/results/TASK-018-survival.md`. No product code changed in PLAN.

## Food-chain integration (TASK-018, ADR-0019)
Tick order (`sim::PHASE_ORDER`, unchanged): Climate, SpatialIndex, Plants, Herbivores, Carnivores, Reproduction, Deaths, Species,
Counters. Reproduction runs plant seeding, then animal mating, then provisional species of the newborns. Deaths is one pass over
the organisms with zero energy, zero health or reached maximum age. Species are re-classified every `species.check_interval`
ticks and extinction is checked every tick. Counters check the balance and the spatial index.

Births: founders come only from `populate_initial` (tick 0). Newborns come only from `reproduction_phase` (plant seeding) and
`mating_phase` (animals). Both build births with `Birth::from_genome_in` and the `LifespanRanges` of the configuration
(`Simulation::lifespans`). No rule reads population counts (`docs/PROJECT.md`).

Survival command: `scripts/survival.sh` (`examples/survival.rs` in `evosim-core`). Results: `docs/results/TASK-018-survival.md`;
calibration log: `docs/results/TASK-018-calibration.md`. Library-level scenario and conservation tests: `src/food_chain_tests.rs`.

## Headless run (TASK-019 PLAN cycle 1)
Design: `docs/decisions/ADR-0020-headless-run-result-and-state-hash.md` (Proposed). Planned modules: `core::sha256` (std-only SHA-256),
`core::checkpoint` (`encode_state`: canonical little-endian encoding of all state, each module's `encode_state` method; `state_hash` =
SHA-256 hex of it; excludes the spatial index, the climate cell cache and the trace), `core::metrics` (sampling, series ticks, result
model and JSON). CLI: `args::Command::Run`, `main::run_run` (populate founders, tick loop, sample outside `tick()`, write the result
through a temporary file). Plan: `tasks/TASK-019/handoffs/plan-cycle1.md`.

## TASK-019 IMPLEMENT note (headless run)
- `evosim run --config FILE --ticks N --out FILE [--seed N] [--sample-every K]` (ADR-0020 D1). `run_run` in `evosim-cli/src/main.rs`
  loads the configuration, calls `Simulation::new` and `populate_initial` (closes G-037 for the CLI), advances exactly `N` ticks,
  samples outside `tick()` at `metrics::series_ticks`, computes `state_hash` and writes the result through a temporary file.
- `core::checkpoint::encode_state` is the single canonical encoding; `Simulation::encode_state` and every module's
  `encode_state` destructure their structs without `..`. Excluded: `spatial` (derived), `Climate.cells` (derived cache, rebuilt
  by `Climate::from_parts`, tested), `trace` (diagnostic). TASK-022 reuses this encoding for the checkpoint body.
- `SpeciesRegistry::living_now(kind)` answers the final species count after the last tick (ADR-0020 D5).
- `config::json` is now `pub` (the result writer and the tests use its parser); no other visibility changed.
- Dependency rule kept: `core::metrics` -> `sim`, `checkpoint`; `core::checkpoint` -> `sim`, `sha256`; the CLI only writes files.


## TASK-020 PLAN note (evolution metrics)
Design: `docs/decisions/ADR-0021-evolution-metrics.md` (Proposed). Plan: `tasks/TASK-020/handoffs/plan-cycle1.md`.
Planned module: `core::analytics` (new `analytics.rs`; depends on `sim` (read-only), `entities`, `ecology` (`PlantTraits`), `species`
(`living_now`), `metrics`). `MetricsLog::record(&Simulation)` runs at the series ticks of `evosim run` (ADR-0020 D4), never inside
`tick()`. CLI: optional `--metrics FILE` on `run` (default off, result unchanged). Format reference: `docs/METRICS.md` (written in IMPLEMENT).
No code changed in PLAN.

## TASK-021 PLAN note (batch runs and export)
Design: `docs/decisions/ADR-0022-batch-runs-and-sweeps.md` (Proposed). Plan: `tasks/TASK-021/handoffs/plan-cycle1.md`.
Planned modules: `core::runner` (new `runner.rs`: the run loop moved out of `evosim-cli` `run_run`, shared by `run` and `batch`;
depends on `sim`, `metrics`, `analytics`, `checkpoint`) and `core::batch` (`batch.rs`: sweep cases, run configurations, aggregates,
summary and CSV text; depends on `runner`, `config`, `metrics`). The CLI keeps all file writes and the `--jobs` worker threads
(`std::thread::scope`, results merged by run index). No code changed in PLAN.

## TASK-021 IMPLEMENT cycle 1 (batch runs and export)
Implemented ADR-0022 (status stays Proposed until REVIEW PASS). New modules: `core::runner`, `core::batch`; CLI `batch.rs` and
`args::parse_batch`. The run loop moved from `run_run` to `core::runner::run`; `run --seed S` and `batch` seed S give the same
`state_hash` (checked: example configuration, seed 7 at 300 ticks gave `1f613fac...7db80b` before and after the move).
`Simulation` is created inside each worker thread and never moved, so no `Send` check was needed for `--jobs`.
Dependency rule kept: `core::batch` does not depend on `core::sim` or files; the CLI writes all files.

## TASK-022 IMPLEMENT cycle 1 (savegames and checkpoints)
Implemented ADR-0023 (status stays Proposed until REVIEW PASS). `checkpoint::write_file`/`read_file` (container, validation
order D2), `Decoder`, and `decode_state` in each state module (`rng`, `world` (Torus), `climate`, `ecology`, `genome`, `entities`,
`species`, `reproduction`, `mating`, `sim` (World, Simulation)). `Simulation::assemble` is the one place that builds the struct
(used by `from_parts` and by the decoder), so the derived neighbour index is rebuilt in both. `read_file` ends with a re-encode
check (byte equality), `Entities::check_balance` and `check_invariants`, and `check_spatial`.
- Encoders are unchanged, so `state_hash` values are the same as before this task.
- Runner: `runner::run_config(config, ticks, RunOptions)` and `runner::resume(checkpoint, ticks, RunOptions)`; `run_from` is the loop.
- CLI: `run --load FILE` (no `--config`, no `--seed`), `run --save FILE`; the write order is checkpoint, metrics, result, and the
  checkpoint is written through `write_bytes_atomically`. `ArgError::Conflict` for `--load` with `--config` or `--seed`.


## TASK-023 PLAN note (UI window and world view)
Design: `docs/decisions/ADR-0024-ui-world-view.md` (Proposed), within ADR-0002. `evosim ui` runs the simulation on its own thread
(20 ticks/s, wall-clock pacing only) and publishes pre-encoded snapshot bytes; the HTTP layer (std `TcpListener`, 127.0.0.1) serves
`/api/climate` (static biome layer) and `/api/state` (tick, counts, `[id, kind, x, y]`). The page is `crates/evosim-ui/web/`, drawn
on canvas. Plan: `tasks/TASK-023/handoffs/plan-cycle1.md`.

## TASK-023 IMPLEMENT cycle 2 (UI architecture)
- `evosim ui` (crates/evosim-ui): one simulation thread paced at 20 ticks/s publishes pre-encoded `/api/state` bytes; HTTP threads only read them (ADR-0024 D2).
- Static biome layer from `/api/climate` once per page load; organisms from `/api/state` polled every 200 ms.
- Page: canvas world view with pan (drag), zoom (wheel, 2 to 64 px per cell), fit (double-click), legend, and reserved `#controls`, `#inspector`, `#charts`.
- Checks: `scripts/ui_check.sh` (interaction and poll rate), `./evosim ui --smoke-test`, `./evosim ui --screenshots DIR`.

## UI module (TASK-023, ADR-0024)
- Crate `crates/evosim-ui`: `driver.rs` (simulation thread at 20 ticks/s, the smoke, screenshot and serve modes, the Chromium driver),
  `server.rs` (std `TcpListener` on 127.0.0.1, `route` pure and unit-tested), `snapshot.rs` (`climate_json`, `state_json`), `lib.rs`.
- Web page `crates/evosim-ui/web/` (`index.html`, `app.js`, `style.css`), embedded in the binary; the page reads `/api/climate` once and
  `/api/state` every 200 ms. Canvas renderer: biome layer, then organisms (plant square, herbivore circle, carnivore triangle).
- Query modes: `?smoke=1` (smoke test), `?shot=1` (screenshots), `?check=1` (synthetic pointer checks, `scripts/ui_check.sh`),
  `?fixture=1000` (renderer-only fixture with 1,000 synthetic organisms, `scripts/ui_fps.py fixture`; never a simulation result).
- Read-only hook `window.evosim`: `view()`, `stats()` (tick, living, frames, state updates), `timing(n)` (fixture redraw timing).
- Measurement: `scripts/ui_fps.py` (python3 -I, DevTools Protocol over a stdlib WebSocket, real time). `fixture` and `live` modes
  (ADR-0024 D14 and D15). The ignored test `ui_1000_organisms_timing` times the `examples/ui-1000.json` world (D16).
- Engine boundary: the UI calls only `evosim-core` through `Simulation`; no UI code changes the simulation state.

## UI run controls and inspector (TASK-024, ADR-0025)
- `crates/evosim-ui/src/control.rs`: pure `Session` (owns the `Simulation`, run/pause, speed levels `[1, 5, 20, 60]` ticks/s,
  reset to the started configuration, save/load of checkpoint bytes, the organism watch). No threads or sockets.
- `crates/evosim-ui/src/inspector.rs`: pure JSON builders for an organism's detail, a death record and the `/api/organism` body.
- `crates/evosim-ui/src/server.rs`: a command channel to the simulation thread (`Envelope` = command + reply channel). New
  routes: `POST /api/command`, `GET|POST /api/checkpoint`, `GET /api/organism?id=N`. Request bodies are read up to
  `Content-Length`, at most 64 MiB (413 before the body is read).
- `crates/evosim-ui/src/driver.rs`: the simulation thread applies queued commands between ticks, runs the ticks due at the
  current speed (`Session::pump`), and publishes climate (when its version changes), state and watch after each change.
- `web/app.js`: controls (run/pause, step, reset, speed, save, load), keyboard shortcuts, click selection (a pointer moved
  less than 4 px selects the nearest organism within 6 px), highlight ring, inspector with genome slots and haplotype hex.
- Evidence: `scripts/control_check.py` (HTTP black box, stdlib), `cargo test -p evosim-ui` (control, inspector, server, snapshot).
- The page's buttons are not driven by a script in this task; only the commands they send are checked (see STATE.md).

## TASK-025 PLAN note (UI scenarios, presets and charts, ADR-0026)
- New modules planned in `crates/evosim-ui`: `setup.rs` (editable field table, string payload to `Config` via `Config::from_json`, field errors, presets JSON, export text) and `charts.rs` (`ChartLog` with bounded thinning, series JSON, histogram).
- `Session` gains `new_world`, a `ChartLog`, and the read-only commands `Series` and `Distribution`; HTTP routes `/api/presets`, `/api/config/check`, `/api/config/import`, `/api/world`, `/api/series`, `/api/distribution`.
- Page: `web/charts.js` (canvas charts with axis labels and legends) and a "New world" panel in the sidebar. `ui --screenshots` also writes `charts.png`.
- Core: `analytics::trait_values` made `pub`; no behaviour change.
- Plan: `tasks/TASK-025/handoffs/plan-cycle1.md`.


## TASK-025 UI scenarios, presets and charts (IMPLEMENT cycle 1)
Status: implemented; ADR-0026 Proposed until REVIEW. Modules added to `evosim-ui`: `setup.rs` (editable field table, typed parsing,
configuration <-> field texts, presets JSON, request bodies; pure), `charts.rs` (bounded `ChartLog` of per-tick points from
`core::analytics::sample`, series JSON, histogram; pure). `control.rs` owns the chart log and handles `NewWorld`, `Series` and
`Distribution` commands on the simulation thread. Page files: `web/setup.js` (New world form), `web/charts.js` (canvas charts).
`core::analytics` exposes `trait_values`, `sample` and `cumulative_events` (read-only).

## TASK-026 IMPLEMENT note (performance measurement, ADR-0027)
- Fixed benchmark: `examples/perf-2000.json` (seed 42, 128x96, 2,200 plants, 250 herbivores, 50 carnivores), run by
  `scripts/perf.sh` (example `evosim-core/examples/perf_tps.rs`): 2 warm-up and 5 timed repetitions of 100 ticks. Living
  count stays at or above 2,173 over the 100 measured ticks; every measured tick is checked against 2,000
  (`--living-floor`). Current numbers: `docs/PERFORMANCE.md` section "IMPLEMENT cycle 2".
- `Simulation::tick_profiled` runs the same phases through the same `run_phase`; `tick()` is unchanged. Its state hash
  equals `tick()`'s (test `perf::tests::tick_profiled_gives_the_same_state_as_tick`).
- Results and profile: `docs/PERFORMANCE.md`. Median about 580 ticks/s at about 2,000 organisms (target 100); no
  product code was optimised in IMPLEMENT (target met with a margin of about 5.8x).


## TASK-027 PLAN note (ecosystem balance, ADR-0028)
No module change in PLAN. IMPLEMENT adds: read-only diagnostics (mating refusals by reason, attack outcomes) and, if T1 or T2
is adopted, a crowding factor in `hunting::attack_chance` (or its call site in `attack`) and a per-carnivore handling timer
stored with the organism (checkpoint encoding in the state modules). Both are local rules; no rule reads population counts.
Probe evidence: `docs/results/TASK-027-plan-probe.md`.

## TASK-027 IMPLEMENT note (ecosystem balance)
Trial T1 added as `hunting::dilution_factor` and `hunting::DILUTION`; default 0 (factor 1, state hashes unchanged). Trials and
the outcome are in `docs/BALANCE.md`; decision record ADR-0028 (Proposed). Scripts above are read-only analysis tools.

## TASK-028 IMPLEMENT note (reliability and delivery)
- Test module `core::invariant_tests` (`crates/evosim-core/src/invariant_tests.rs`, `#[cfg(test)]`): randomised invariant
  tests over random configurations drawn from `rng::Rng` (fixed master seed). Checks birth/death accounting, value ranges,
  storage invariants, spatial index consistency, torus wrapping against brute force, same-configuration determinism,
  checkpoint split runs, and seed sensitivity. Case count from `EVOSIM_INVARIANT_CASES` (default 24; the release step of
  `scripts/test.sh` uses 200). It only reads the library API; no product code was changed by this task.
- `scenarios/demo.json` (CONTRACT section 7) is the demo configuration: the example with `plants.reproduction_chance` 0.2 and
  `plants.seed_radius` 4. Chosen by the measured search in `docs/VERIFICATION.md` section 4; no rule was added.
- `scripts/test.sh` gained steps 10 to 12: six 10,000-tick runs (demo and example, seeds 1 to 3) with the accounting check,
  the demo through `run`, UI smoke test and screenshots with a PNG size check, and the release invariant run.
- Evidence and the self-audit: `docs/VERIFICATION.md`; raw outputs under `docs/results/TASK-028/`.
- Config keys accepted but without effect: `plants.growth_rate`, `herbivores.metabolism`, `carnivores.metabolism` (see
  ADR-0006 amendment). Unchanged in this task.
